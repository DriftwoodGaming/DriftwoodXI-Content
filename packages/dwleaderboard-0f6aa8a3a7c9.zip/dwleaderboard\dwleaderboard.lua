--[[
* DriftwoodXI -- dwleaderboard
*
* The server's bragging boards in a window: most total job levels, most gil,
* most kills, the most enemies defeated without a death, the fullest
* mog-house storage, the highest of every craft and all crafts combined, who
* fills the market's buy orders, playtime, deaths, distance walked -- names
* and scores, ranked, with everyone tied for first sharing rank 1.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited
* whole). It holds no data of its own: the board list arrives from the server
* (`o|` records -- boards grow server-side without an addon release, the
* vocabulary rule) and every board's rows arrive ranked. Every read is
* `!dwl boards` or `!dwl board <key>`, which are the same server functions
* `!leaderboard` reaches typed. The server enforces the privacy line -- names
* and scores only, no deleted characters, no GMs -- and this window can never
* be told more than the typed tier says.
*
* RANKS ARE ASSIGNED HERE, ON PURPOSE. Rows arrive sorted; standard
* competition ranking (tied scores share the rank, the next rank skips) is
* presentation, and the one thing the player asked of it -- "persons tied for
* first all get their name listed" -- is exactly what sorted rows plus shared
* ranks give. The server never spells a rank, so the two tiers cannot
* disagree about one.
*
* SORTED IS NOT THE SAME AS DESCENDING (1.2.0). Every board shipped before
* the Grand Circuit was "more is better" and arrived score-descending; a
* speed board arrives score-ASCENDING, fastest first. Nothing in this window
* is allowed to assume which -- the rank pass asks whether a score CHANGED,
* never whether it fell, and the sentences say "leaders" rather than
* "highest".
*
* SCORES ARE RAW INTEGERS ON THE WIRE; the `unit` word in the h|/o| records
* says how to spell one (gil commas, craft tenths, playtime hours, circuit
* clocks). A unit this addon does not know renders as the raw number -- a
* server newer than the addon must not break it, and an OLDER server that
* never sends `clock` at all is exactly the addon before this one.
*
* THE LAZY ASK FIRES ONCE PER LOGIN, NOT WHENEVER THE LIST IS EMPTY
* (2026-09-06). A server that ANSWERS `!dwl boards` with a refusal -- dwl.lua's
* "not loaded on this server", or dispatch's "not in this build" when the C++
* store is absent -- sends a well-formed `d|1|status` envelope, which retires
* the ask and leaves the catalogue empty. The old condition ("empty and
* nothing pending") was therefore true again on the very next frame: the
* window asked once per throttle window for as long as it stayed open, and
* printed the refusal to the chat log every single time. The latch is cleared
* by the zone line, which is also the login, so a server that comes back
* answers the next probe.
*
* WHAT IS SPELLED ONCE AND WHAT IS SPELLED PER FRAME. A board is a snapshot:
* nothing about it changes between two answers. So the ranks, the rank text,
* the score text and each catalogue row's Selectable id are all fixed on the
* `z|` that commits them, and the render loop only reads them. What is left
* per frame is the find box's filter (a plain `find` over 25 lowercased
* strings) and the "how long ago" clock, which is one string.
*
* THE AGE CLOCK IS THE ONLY os.time() IN THE FILE, and deliberately so: every
* throttle and every timeout here is os.clock(), which is CPU seconds, and the
* two must never be compared. "Fetched 40s ago" is a sentence about the wall,
* so it is measured against the wall.
*
* TURN IT OFF AND NOTHING IS LOST. `!leaderboard` does all of it typed.
*
* HISTORY. 1.0.0 the window; 1.0.2 the Storage and Defeated w/o Death pair;
* 1.1.x the answer-clock and settings-file rounds. 1.2.0 (2026-09-14) is the
* GRAND CIRCUIT round: the server grew two speed boards and with them the
* first unit word where LESS IS MORE -- `clock`, spelled m:ss under an hour
* and h:mm:ss at an hour or more -- so this window learned that unit, learned
* to say so on hover, and stopped assuming anywhere that the rows it is handed
* run downhill. Nothing else moved: the boards themselves still arrive over
* the wire, so an older server that never sends `clock` renders exactly as it
* did before.
--]]

addon.name    = 'dwleaderboard';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.0';
addon.desc    = 'The DriftwoodXI leaderboards: job levels, gil, kills, no-death streaks, storage, crafts, market deeds.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line.
local DATA_SENDER = '_DWLDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

--[[
* Ceilings on what an answer may stage. The store ships 30 boards and 15 rows
* a board, so neither of these is ever reached by a healthy server -- they
* exist because a table that grows on packets and has no bound is the one
* shape this suite has agreed never to write. Records past the ceiling are
* dropped, not an error: the window still commits what it has.
--]]
local MAX_BOARDS = 100;
local MAX_ROWS   = 100;

--[[
* Persisted presentation state, through Ashita's settings library (the dwscan
* shape). One flat scalar: the board this character was last looking at, so
* the window opens where it was left rather than on whatever the server ships
* first. Every call is pcall'd -- a missing or corrupt file falls back to the
* defaults and the window opens on the catalogue's first board, which is
* exactly what it did before this existed.
--]]
local defaultConfig = T{
    board = '',
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

-- The remembered key, or nil. The settings file is a Lua file in the player's
-- config folder, so `board` is whatever the last writer put there, and a
-- boolean or a number reaching string.gsub in the catalogue commit and
-- string.format in the render used to cost the window itself: the render
-- pcall closes it, every frame. A key is a non-empty string or it is nothing.
local function rememberedBoard(cfg)
    if (type(cfg) ~= 'table' or type(cfg.board) ~= 'string' or cfg.board == '') then
        return nil;
    end

    return cfg.board;
end

local state = T{
    open      = T{ false },

    -- The board catalogue, in the server's shipping order, and the rows of
    -- the one board on screen. Both COMMIT ON z| from a pending copy, so a
    -- half-arrived reply can never half-fill the window.
    boards    = {},         -- { { key, label, unit, item, match }, ... }
    board     = nil,        -- { key, unit, at, rows = { { name, score } } }
    -- The key the player is looking at, restored from the settings file and
    -- VALIDATED against the catalogue when it arrives: a board the server has
    -- stopped offering falls back to the first one rather than leaving the
    -- window looking at nothing.
    selected  = rememberedBoard(config),
    wanted    = nil,        -- a name `/lb <name>` gave before the list arrived

    pendingBoards = nil,
    pendingBoard  = nil,

    inbound   = nil,        -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame
    lastError = nil,        -- the last e| text printed, so a server that says
                            -- the same refusal to every ask says it once

    -- What the window filters the board list by, and the width the list needs
    -- for the longest label in the CURRENT catalogue (measured once per
    -- catalogue, in a frame, because CalcTextSize needs one).
    find      = T{ '' },
    listWidth = nil,

    -- The lazy ask has fired for this login. NOT "the list is empty": a
    -- server that answers the ask with a refusal leaves it empty forever, and
    -- re-arming on emptiness asked once per throttle window for as long as
    -- the window stayed open (see the header).
    boardsAsked = false,

    -- The answer clock, per verb (the dwfame shape): one retry after five
    -- seconds, then the silent latch -- an unknown ! command falls through to
    -- PUBLIC /say on a server without dwl.lua, and the latch contains that.
    requested    = nil,     -- { verb, key, at, tries }
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until the
    -- zone line re-probes it (a map restart is also a login).
    refused   = false,

    -- Who is logged in, so their own row draws highlighted.
    charName  = nil,
    charCheckAt = nil,

    -- The two sentences the right pane shows while it has no rows to draw,
    -- spelled when the selection changes rather than while the wait runs.
    fetchingFor  = nil,
    fetchingText = '',
    stalledText  = '',
};

-- The settings profile changes when the CHARACTER does, and the library hands
-- the new one over here. Registered after `state` because that is what it has
-- to reach: a player who has not picked a board yet in this session takes the
-- board this character remembers, rather than the one the last character did.
pcall(settings.register, 'settings', 'dwleaderboard_settings_update', function (s)
    if (type(s) ~= 'table') then
        return;
    end

    config = s;

    if (state.selected == nil) then
        state.selected = rememberedBoard(config);
    end
end);

--[[
* Outbound: `!dwl` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat and
* answers a burst with "A command error occurred" before the server sees it.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    -- Queries collapse: asking twice for the same board is never useful and
    -- there are no writes on this wire at all.
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- Held, not dropped, while the client is zoning (dwecho's canSend).
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local function commandFor(verb, key)
    if (verb == 'board') then
        return string.format('!dwl board %s', key);
    end

    return '!dwl boards';
end

-- `force` is the Refresh button: a click is the player asking, and the
-- silent latch exists to contain AUTOMATIC re-asks, not to ignore the
-- player (the dwnemesis 1.1.0 finding: a Refresh gated on the latch is a
-- window that never recovers without a zone line). The protocol refusal is
-- not lifted by a click.
local function ask(verb, key, force)
    if (state.refused) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;

        -- The give-up sentence is about the ask that just failed, not the one
        -- being made now: left standing it made a Refresh look inert, because
        -- the status line outranks "asking...". Only a BAD status is dropped,
        -- so "copied to the clipboard" survives a refresh beside it.
        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end
    end

    state.requested = { verb = verb, key = key, at = os.clock(), tries = 1 };

    issue(commandFor(verb, key));
end

-- The retry pass, from the render loop. The clock never ages while the
-- client is zoning: a held queue is not an unanswered server.
local function checkAnswers()
    local asked = state.requested;

    if (asked == nil) then
        return;
    end

    -- The second door onto the same rule the `d|` mismatch branch keeps: a
    -- server whose layout this addon cannot read will answer the retry exactly
    -- the same way, so the retry is a line thrown at a wall. `ask()` already
    -- refuses to start one; this refuses to continue one that was already in
    -- flight when the refusal landed.
    if (state.refused) then
        state.requested = nil;

        return;
    end

    -- Re-stamped, not skipped, while the client is zoning: a clock started
    -- when the line was queued behind echo.canSend() has already expired
    -- when the line finally goes out, and the retry then fires into the
    -- same post-zone settle window that drops the first send.
    if (not echo.canSend()) then
        asked.at = os.clock();

        return;
    end

    if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
        return;
    end

    if (asked.tries >= ANSWER_TRIES) then
        state.requested    = nil;
        state.serverSilent = true;
        state.status       = 'No answer from the server. Is DriftwoodXI up to date?';
        state.statusBad    = true;

        return;
    end

    asked.at    = os.clock();
    asked.tries = asked.tries + 1;

    issue(commandFor(asked.verb, asked.key));
end

--[[
* Record parsing. Records are accepted only between a `d|` and its `z|`;
* anything unrecognised falls off the chain rather than being an error, which
* is what lets the server grow record kinds without breaking this addon.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* Spelling a score. These three used to live in the rendering section, which
* is where they were called from; they are up here now because the PARSER is
* what calls them -- every score is spelled once, on the `z|` that commits its
* row, rather than sixty times a second in the table loop.
--]]
local function comma(n)
    local value = math.floor(n);
    local sign  = '';

    -- The MINUS SIGN IS TAKEN OFF FIRST. It is a character like any other to
    -- the loop below, so -123 came out as "-,123": four characters, one group
    -- taken, an empty stem left in front of the comma. No board the server
    -- ships can go negative, but the reader must not be the thing that breaks
    -- if one ever does.
    if (value < 0) then
        sign  = '-';
        value = -value;
    end

    local left = tostring(value);
    local out  = '';

    while (#left > 3) do
        out  = ',' .. left:sub(-3) .. out;
        left = left:sub(1, -4);
    end

    return sign .. left .. out;
end

-- A score, spelled by its unit. An unknown unit is the raw number: a server
-- newer than this addon must not break it.
local function scoreText(unit, score)
    if (unit == 'tenths') then
        return string.format('%d.%d', math.floor(score / 10), math.floor(score % 10));
    end

    if (unit == 'seconds') then
        return string.format('%dh %02dm', math.floor(score / 3600), math.floor(score / 60) % 60);
    end

    -- A TIME, and not a duration of play (1.2.0): `clock` is the speed-board
    -- unit, so it is spelled the way a stopwatch is -- m:ss under an hour,
    -- h:mm:ss at an hour or more -- where `seconds` above rounds playtime off
    -- to whole hours and minutes. A circuit run shown as "0h 47m" would throw
    -- away the half of the number the board exists for. Spelled character for
    -- character the way modules/driftwoodxi/leaderboard_core.lua spells it:
    -- the typed `!leaderboard` tier and this window must never disagree about
    -- one score, and the harness pins both against the same three examples.
    --
    -- THE MINUS SIGN COMES OFF FIRST, for `comma`'s reason just above:
    -- math.floor(-5 / 60) is -1, so a negative spelled straight through reads
    -- "-1:-05". No board can send one -- but the reader must not be the thing
    -- that breaks if one ever does.
    if (unit == 'clock') then
        local value = math.floor(score);
        local sign  = '';

        if (value < 0) then
            sign  = '-';
            value = -value;
        end

        if (value >= 3600) then
            return string.format('%s%d:%02d:%02d', sign,
                math.floor(value / 3600), math.floor(value / 60) % 60, value % 60);
        end

        return string.format('%s%d:%02d', sign, math.floor(value / 60), value % 60);
    end

    if (unit == 'gil') then
        return comma(score) .. ' gil';
    end

    return comma(score);
end

--[[
* A wire score is a raw integer or it is nothing.
*
* `tonumber` on LuaJIT accepts 'nan', 'inf' and '2.5', and `or 0` catches none
* of them -- every one of those is truthy. A NaN then compares false against
* everything, so the shared-rank pass below it stops advancing and two
* unrelated rows read as the same rank; it also reaches `string.format('%d')`,
* which raises on the LuaJIT builds that refuse a number with no integer
* representation. So the number is made finite and integral HERE, once, rather
* than defended against in each of the three spellers.
--]]
local MAX_SCORE = 1000000000000;   -- a trillion: past every real board by far

local function wireScore(raw)
    local n = tonumber(raw);

    if (n == nil or n ~= n or n == math.huge or n == -math.huge) then
        return 0;
    end

    -- Clamped as well as floored. Nothing a board measures reaches a trillion
    -- -- the gil cap is a thousandth of it -- and past about 1e15 tostring
    -- starts spelling in exponent form, which `comma` then chops into
    -- "1e+,299". A number this large is a broken server, not a player.
    if (n > MAX_SCORE) then
        return MAX_SCORE;
    end

    if (n < -MAX_SCORE) then
        return -MAX_SCORE;
    end

    return math.floor(n);
end

--[[
* What the render loop reads instead of computing. Called on the `z|` that
* commits a board, so the table draw is Text() and nothing else.
*
* Standard competition ranking: tied scores share the rank and the next rank
* skips, so everyone tied for first is named at 1. Rows arrive sorted, which
* is what makes one pass enough.
*
* THE TEST IS "DIFFERENT", NOT "LOWER" (1.2.0). It read `row.score < last`
* while every board the server had was score-descending -- the same thing,
* right up until a board arrives sorted the other way. On the ascending Grand
* Circuit boards that test is false for every row after the first, so all
* fifteen would draw as rank 1 and the fastest run on the server would be
* indistinguishable from the slowest. A tie is a tie in either direction, and
* the server has already sorted these rows the way its board wants them.
--]]
local function dressBoard(board)
    local rank = 0;
    local last = nil;

    for index, row in ipairs(board.rows) do
        if (last == nil or row.score ~= last) then
            rank = index;
            last = row.score;
        end

        row.rank     = rank;
        row.rankText = tostring(rank);
        row.text     = scoreText(board.unit, row.score);
    end
end

-- The catalogue's per-row constants: the Selectable's own id (label plus the
-- key, so two boards that ever share a label still get their own widget) and
-- the lowercased haystack the find box searches.
local function dressCatalog(boards)
    for _, board in ipairs(boards) do
        board.item  = string.format('%s##dwl_%s', board.label, board.key);
        board.match = string.lower(board.label .. ' ' .. board.key);
    end
end

-- The catalogue row a key belongs to, or nil. The `h|` record carries only a
-- key and a unit, so the LABEL a board is drawn under comes from here -- once,
-- on the commit, rather than by scanning the catalogue every frame.
local function catalogEntry(key)
    for _, board in ipairs(state.boards) do
        if (board.key == key) then
            return board;
        end
    end

    return nil;
end

-- Which row is the viewer's, if any. Recomputed whenever either half of the
-- answer changes: the rows on a commit, the name when the login settles.
local function markOwn(board)
    if (board == nil) then
        return;
    end

    board.you     = nil;
    board.youText = nil;

    if (state.charName == nil) then
        return;
    end

    for _, row in ipairs(board.rows) do
        if (row.name == state.charName) then
            board.you     = row.rank;
            board.youText = string.format('You are #%d on this board.', row.rank);

            return;
        end
    end
end

-- Remembered per character, and only for a board the PLAYER picked: the
-- catalogue's first board is a fallback, not a choice, and writing it back
-- would make everyone's window open on whatever the server happens to ship
-- first.
local function rememberBoard(key)
    config.board = key or '';

    pcall(settings.save);
end

-- Show a board by key, if the catalogue has one. Returns false when it does
-- not, which is what tells the caller to fall back or to say so.
local function selectByKey(key)
    if (key == nil or key == '') then
        return false;
    end

    for _, board in ipairs(state.boards) do
        if (board.key == key) then
            state.selected = key;

            ask('board', key);

            return true;
        end
    end

    return false;
end

--[[
* Open the board a player NAMED. `text` arrives already lowercased.
*
* The KEY the server ships is tried first, then the LABEL the player reads off
* the list -- because nothing on screen says that Cooking's key is `craft:56`,
* and `/lb cooking` finding nothing would be the window refusing the only
* spelling its own list ever showed. Neither spelling reaches the wire: both
* are matched against the catalogue, and the line that goes out carries the
* key the SERVER offered.
--]]
local function showByName(text)
    if (text == nil or text == '') then
        return false;
    end

    if (selectByKey((string.gsub(text, '[^%w:]', '')))) then
        return true;
    end

    for _, board in ipairs(state.boards) do
        if (string.lower(board.label) == text) then
            return selectByKey(board.key);
        end
    end

    return false;
end

--[[
* What `/lb <name>` does when the name is not a board's: put it in the find
* box if that would show something, and refuse if it would not.
*
* THE FIND BOX IS ONLY SET WHEN IT WOULD SHOW SOMETHING. Filtering the list
* down to nothing and then saying "pick one on the left" is the window
* contradicting itself about a list it has just emptied.
*
* Shared by the command handler and by the catalogue's commit, which is where
* a name typed BEFORE the list arrived lands -- the two used to disagree, so
* `/lb cook` filtered or refused depending on how quickly the server answered.
--]]
local function filterOrRefuse(text)
    local matches = 0;

    for _, board in ipairs(state.boards) do
        if (board.match:find(text, 1, true) ~= nil) then
            matches = matches + 1;
        end
    end

    if (matches > 0) then
        state.find[1]   = text;
        state.status    = string.format('Filtered the list to "%s".', text);
        state.statusBad = false;
    else
        state.status    = string.format('No board called "%s". Pick one on the left.', text);
        state.statusBad = true;
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        -- Through the same sanitiser a score goes through, for the same
        -- reason: it is spelled with %d in the sentence below, and `tonumber`
        -- would hand that a NaN for `d|nan|boards`.
        local version = wireScore(parts[2]);

        if (version ~= PROTOCOL) then
            -- ONE warning, which is what the header at the top of this file
            -- promises and what the code did not do: two lines can be in
            -- flight when the refusal lands -- the queue holds `!dwl boards`
            -- and `!dwl board <key>` at once -- and each answer printed the
            -- same sentence again.
            local first = not state.refused;

            state.refused = true;
            state.inbound = nil;

            -- THE REFUSAL IS THE ANSWER TO THE ASK IN FLIGHT, and the ask has
            -- to be retired with it (2026-09-06). Leaving it outstanding let
            -- the answer clock retry a line the server had just said it could
            -- not read, and then latch silent -- which replaced the one
            -- accurate sentence on screen with the one that is definitely
            -- wrong, about a server that had answered immediately. The silent
            -- latch is cleared for the same reason: this server ANSWERS.
            state.requested     = nil;
            state.serverSilent  = false;
            state.pendingBoards = nil;
            state.pendingBoard  = nil;

            if (first) then
                print(chat.header('dwleaderboard'):append(chat.error(string.format(
                    'server protocol %d, addon expects %d. Update dwleaderboard through the launcher.',
                    version, PROTOCOL))));
            end

            return;
        end

        state.inbound = parts[3];

        -- The ask is retired by the envelope that ANSWERS it -- its own verb,
        -- or the `status` envelope the writer wraps a bare refusal in. A
        -- `d|1|boards` arriving because the player typed `!dwl boards` by hand
        -- used to retire a `board` ask in flight, which took its retry with
        -- it. A well-versioned envelope of any verb still clears a silent
        -- latch earned against a server since updated: this one is speaking.
        state.serverSilent = false;

        if (state.requested ~= nil
                and (state.inbound == state.requested.verb or state.inbound == 'status')) then
            state.requested = nil;
        end

        if (state.inbound == 'boards') then
            state.pendingBoards = {};
        elseif (state.inbound == 'board') then
            state.pendingBoard = { key = nil, unit = 'count', rows = {} };
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        state.status    = text;
        state.statusBad = (kind == 'e');

        -- SAID ONCE, NOT ONCE PER ASK. A server that refuses every ask the
        -- same way -- the module absent, the store absent -- used to print
        -- its sentence to the chat log for every single ask. The text itself
        -- is the key, and it is forgotten on the zone line and on any answer
        -- that works, so a refusal that comes BACK is still reported.
        if (kind == 'e' and text ~= '' and text ~= state.lastError) then
            state.lastError = text;

            print(chat.header('dwleaderboard'):append(chat.error(text)));
        end

        return;
    end

    -- Records are routed by the OPEN ENVELOPE'S VERB, not merely by which
    -- staging table happens to be non-nil: an envelope abandoned without its
    -- `z|` leaves its table behind, and a `b|` inside the next `boards`
    -- envelope used to land in it.
    if (kind == 'o' and state.inbound == 'boards' and state.pendingBoards ~= nil) then
        local key = parts[2];

        -- A board with no key is not a board: it can never be asked for, and a
        -- row that cannot be opened is worse than a row that is not there.
        if (key ~= nil and key ~= '' and #state.pendingBoards < MAX_BOARDS) then
            local label = parts[3];

            -- An unlabelled board is listed under its key rather than under
            -- nothing: '##dwl_gil' is an invisible Selectable.
            if (label == nil or label == '') then
                label = key;
            end

            table.insert(state.pendingBoards, {
                key   = key,
                label = label,
                unit  = parts[4] or 'count',
            });
        end

        return;
    end

    if (kind == 'h' and state.inbound == 'board' and state.pendingBoard ~= nil) then
        state.pendingBoard.key  = parts[2] or '';
        state.pendingBoard.unit = parts[3] or 'count';

        return;
    end

    if (kind == 'b' and state.inbound == 'board' and state.pendingBoard ~= nil) then
        if (#state.pendingBoard.rows < MAX_ROWS) then
            local name = parts[2];

            -- A truncated record must still draw a row: imgui.Text(nil) is a
            -- render error, and the pcall around it closes the whole window.
            if (name == nil or name == '') then
                name = '?';
            end

            table.insert(state.pendingBoard.rows, {
                name  = name,
                score = wireScore(parts[3]),
            });
        end

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        if (closed == 'boards' and state.pendingBoards ~= nil) then
            state.boards        = state.pendingBoards;
            state.pendingBoards = nil;
            state.listWidth     = nil;
            state.lastError     = nil;
            state.fetchingFor   = nil;   -- a label may have moved with the list

            dressCatalog(state.boards);

            if (state.statusBad) then
                state.status    = '';
                state.statusBad = false;
            end

            -- Which board to show now that the catalogue is known: the one
            -- `/lb <name>` named, else the one this character was last looking
            -- at, else the first the server ships. A name that is not offered
            -- falls through to the first rather than leaving the window
            -- pointed at nothing.
            local typed = state.wanted;
            local want  = typed or state.selected;

            state.wanted = nil;

            if (not showByName(want)) then
                state.selected = nil;

                if (#state.boards > 0) then
                    state.selected = state.boards[1].key;

                    ask('board', state.selected);
                end

                -- Said AFTER the fallback ask, never before it: `ask` drops a
                -- bad status when it lifts the silent latch, and a sentence
                -- set first would be the one it dropped.
                if (typed ~= nil) then
                    filterOrRefuse(typed);
                end
            end
        elseif (closed == 'board' and state.pendingBoard ~= nil) then
            local board = state.pendingBoard;

            -- Ranks and the text of every cell are fixed HERE, not in the
            -- render loop: a board is a snapshot and nothing about it changes
            -- between two answers.
            board.entry = catalogEntry(board.key);
            board.label = board.entry ~= nil and board.entry.label or board.key;

            dressBoard(board);
            markOwn(board);

            board.at = os.time();

            state.board        = board;
            state.pendingBoard = nil;
            state.status       = '';
            state.statusBad    = false;
            state.lastError    = nil;
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwleaderboard_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        -- Blocked before parsing: a malformed record must not leak into the
        -- chat log as noise.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            local text = 'bad record: ' .. tostring(err);

            -- SAID ONCE, like every other diagnosis in this file. A record
            -- shape this addon throws on arrives once per record, and one
            -- board's answer is sixteen of them -- so the one thing the player
            -- would have read is the same sentence, sixteen times, scrolling
            -- the rest of their log away. Shares the slot with the server's
            -- own refusals: it is the same question ("what did we last
            -- complain about"), and the zone line forgets both.
            if (text ~= state.lastError) then
                state.lastError = text;

                print(chat.header('dwleaderboard'):append(chat.error(text)));
            end
        end

        return;
    end

    -- A zone line invalidates nothing a leaderboard said -- the boards are
    -- server-wide -- but both latches are re-probed: 0x000A is also a login,
    -- and the server on the far side of a map restart may be the updated one.
    if (e.id == 0x000A) then
        state.requested    = nil;
        state.serverSilent = false;
        state.refused      = false;
        state.charCheckAt  = os.clock() + 3.0;

        -- The lazy ask is re-armed by the zone line and by nothing else: it is
        -- also the login packet, so a server that has come back -- or been
        -- restarted with the module it was missing -- is probed exactly once
        -- more. A refusal that has stopped being true is worth printing again.
        state.boardsAsked = false;
        state.lastError   = nil;
    end
end);

--[[
* Rendering.
*
* WHAT A BOARD MEASURES, IN THE OWNER'S OWN WORDS, for the hover. Keyed by the
* board's key so the SERVER can still grow the catalogue without an addon
* release: a board with no entry here falls back to a sentence about its unit,
* and a board with neither still draws -- it just says nothing extra. The
* caveats are the honest ones from the plan document: the char_history boards
* are written on zoning and logout, so they trail the current session, and two
* of the ledgers only started counting the day they shipped.
--]]
local BOARD_TIPS =
{
    jobs     = 'Every job level the character has, added up across all twenty-two jobs.',
    gil      = 'Gil carried on the character. Gil sitting in the mog safe or on an alt is not counted.',
    storage  = 'Slots filled across the mog-house containers -- safe, storage, locker, satchel, sack, case and the wardrobes. Not the inventory, and not the warehouse: that is account-wide, and a board names characters.',
    kills    = 'Enemies defeated, credited to whoever held the claim. Written on zoning and logout, so it trails the current session.',
    streak   = 'The longest run of kills with no knockout in between. Counted from 2026-09-05, when the run started being recorded, and only your own knockout ends one.',
    crafts   = 'Every craft skill added together, spelled as one number to a tenth.',
    fills    = 'Buy orders filled at the market. Counted from the day the ledger shipped -- older fills recorded nobody to credit.',
    sales    = 'Gil taken at the auction house, over every sale that found a buyer.',
    pioneer  = 'Pioneer bounties: the reward for being the first to stock something the market had none of.',
    playtime = 'Time logged in, as the character sheet counts it.',
    deaths   = 'Times knocked out. Written on zoning and logout, so it trails the current session. Yes, it is a leaderboard.',
    battles  = 'Battles fought. Written on zoning and logout, so it trails the current session.',
    spells   = 'Spells cast. Written on zoning and logout, so it trails the current session.',
    ws       = 'Weapon skills used. Written on zoning and logout, so it trails the current session.',
    distance = 'Distance travelled, in the game\'s own units.',
    chats    = 'Lines of chat sent. Written on zoning and logout, so it trails the current session.',
    -- The three player requests of 2026-09-13.
    dig        = 'Chocobo digging skill: the number before the point is the level, the digit after it is the tenth. Raised by digging.',
    driftcoins = 'Drift Coins earned over the account\'s life -- contracts, community settlements and the login stipend, credited to the account\'s most-played character. Coins bought with gil, refunds and GM gifts do not count.',
    driftmarks = 'Driftmarks earned over the account\'s life -- every raid clear, daily, element-day and chain bonus, credited to the account\'s most-played character. Refunds do not count.',
};

-- The fallback, by unit, and the same words the Score column uses.
local UNIT_TIPS =
{
    gil     = 'Scored in gil.',
    tenths  = 'A craft skill: the number before the point is the level, the digit after it is the tenth.',
    seconds = 'Scored in time played, spelled in hours and minutes.',
    clock   = 'A time, and the one kind of score where less is more: the fastest run is rank 1. Spelled minutes and seconds, or hours, minutes and seconds once a run passes the hour.',
    levels  = 'Scored in job levels, added together.',
    units   = 'Scored in the game\'s own distance units.',
    count   = 'Scored as a plain count.',
};

local UNKNOWN_UNIT_TIP =
    'The raw number the server sent: this addon does not know how to spell this unit, which is what lets the server add boards without an addon release.';

local function boardTip(entry)
    if (entry == nil) then
        return nil;
    end

    local tip = BOARD_TIPS[entry.key];

    if (tip == nil and entry.key:sub(1, 6) == 'craft:') then
        tip = string.format('The %s skill, to a tenth of a level.', entry.label);
    end

    return tip or UNIT_TIPS[entry.unit];
end

-- How old the numbers on screen are. os.time() and NOT os.clock(): every
-- throttle in this file is CPU seconds, and this one sentence is about the
-- wall. The two are never compared.
local function agoText(when)
    local secs = os.time() - (when or 0);

    if (secs < 0) then
        secs = 0;
    end

    if (secs < 60) then
        return string.format('%ds ago', secs);
    end

    if (secs < 3600) then
        return string.format('%dm ago', math.floor(secs / 60));
    end

    return string.format('%dh ago', math.floor(secs / 3600));
end

-- The board as text, for the clipboard: built on the click, never per frame.
local function boardClipboard(board)
    local out = T{ };

    out:append(string.format('%s -- DriftwoodXI', board.label));

    for _, row in ipairs(board.rows) do
        out:append(string.format('%2d. %-16s %s', row.rank, row.name, row.text));
    end

    return table.concat(out, '\r\n');
end

local function renderWindow()
    if (imgui.Button('Refresh##dwl_refresh')) then
        -- THE CATALOGUE FIRST when there isn't one. `state.selected` can be a
        -- key restored from the settings file, and a remembered key is not
        -- evidence that the board list ever arrived -- so a Refresh in that
        -- state used to ask for one board's rows and leave the list that
        -- board has to be picked from empty for good.
        if (#state.boards == 0) then
            state.boardsAsked = true;

            ask('boards', nil, true);
        elseif (state.selected ~= nil) then
            ask('board', state.selected, true);
        else
            ask('boards', nil, true);
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Ask the server again for whatever this window is showing. It shares one answer per board for about a minute, so a refresh inside that minute honestly re-reads the same numbers.');
    end

    local board = state.board;
    local shown = board ~= nil and board.key == state.selected;

    imgui.SameLine();

    -- NOT GREYED WHEN THERE IS NOTHING TO COPY. A disabled ImGui item does not
    -- report IsItemHovered(), so a greyed button here would be a control that
    -- refuses the click AND refuses to say why -- which is the opposite of the
    -- rule. It stays live and answers in the status line instead.
    if (imgui.Button('Copy##dwl_copy')) then
        if (shown and #board.rows > 0) then
            imgui.SetClipboardText(boardClipboard(board));

            state.status    = string.format('%s copied to the clipboard.', board.label);
            state.statusBad = false;
        else
            state.status    = 'Nothing to copy yet -- pick a board and let its rows arrive.';
            state.statusBad = true;
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Copy the board on the right to the clipboard: rank, name and score, one player per line.');
    end

    imgui.SameLine();

    local statusTip = nil;

    -- THE REFUSAL IS READ FIRST. It is the accurate diagnosis, and the silent
    -- latch's sentence -- which used to sit above it here -- is the one that
    -- is definitely wrong about a server that answered immediately. Since the
    -- mismatch branch now retires the ask AND clears that latch, the two can
    -- no longer both be true at once: this is the second lock on the same
    -- door, and the order to read them in if anything ever opens it.
    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwleaderboard through the launcher.');

        statusTip = 'The server speaks a leaderboard protocol this addon does not know, so nothing it sends can be read safely. The launcher updates the addon; everything this window shows also works typed as !leaderboard.';
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server.');

        statusTip = 'Two asks went out and neither was answered, so the window stopped asking by itself. Refresh asks again.';
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or state.requested ~= nil) then
        imgui.TextDisabled('asking...');

        statusTip = 'A !dwl line is on the wire. Requests go out one at a time, and are held rather than dropped while the client is zoning.';
    else
        imgui.TextDisabled('Names and scores only. Ties share the rank.');

        statusTip = 'A board says a character name and a score and nothing else -- no account, no login, no last-seen. Deleted characters and GMs are filtered out by the server, not by this window.';
    end

    if (statusTip ~= nil and imgui.IsItemHovered()) then
        imgui.SetTooltip(statusTip);
    end

    imgui.Separator();

    --[[
    * The board list, left; the rows, right. The list is as wide as the longest
    * label the CURRENT catalogue carries -- measured once per catalogue rather
    * than per frame, and clamped at both ends so neither a one-word catalogue
    * nor a very long label decides how much room the table beside it gets.
    --]]
    if (state.listWidth == nil) then
        local widest = (imgui.CalcTextSize('Waiting for the board list...'));

        for _, entry in ipairs(state.boards) do
            local size = (imgui.CalcTextSize(entry.label));

            if (size > widest) then
                widest = size;
            end
        end

        state.listWidth = math.max(170, math.min(300, widest + 34));
    end

    -- ...and then capped again against the room there actually is, every
    -- frame, because the window is resizable and the measurement is not. At
    -- the 520px floor a 300px list would have left the table 34px of rank,
    -- 90px of score and almost nothing for a name.
    local listW = state.listWidth;
    local avail = (imgui.GetContentRegionAvail());

    if (avail ~= nil and avail > 0 and listW > avail * 0.45) then
        listW = math.max(120, avail * 0.45);
    end

    imgui.BeginChild('##dwl_list', { listW, 0 }, ImGuiChildFlags_Borders);

    imgui.SetNextItemWidth(-1);
    imgui.InputTextWithHint('##dwl_find', 'find a board...', state.find, 32);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Narrows the list to boards whose name or key contains what you type. It filters what is already here and sends nothing.');
    end

    local needle  = string.lower(state.find[1] or '');
    local matched = 0;

    for _, entry in ipairs(state.boards) do
        if (needle == '' or entry.match:find(needle, 1, true) ~= nil) then
            matched = matched + 1;

            if (imgui.Selectable(entry.item, state.selected == entry.key)) then
                if (selectByKey(entry.key)) then
                    rememberBoard(entry.key);
                end
            end

            if (imgui.IsItemHovered()) then
                local tip = boardTip(entry);

                if (tip ~= nil) then
                    imgui.SetTooltip(tip);
                end
            end
        end
    end

    if (#state.boards == 0) then
        -- "Waiting" is a lie once the window has STOPPED waiting, which is
        -- what the silent latch means.
        if (state.refused) then
            imgui.TextDisabled('Update the addon to see the boards.');
        elseif (state.serverSilent) then
            imgui.TextDisabled('No board list. Refresh asks again.');
        else
            imgui.TextDisabled('Waiting for the board list...');
        end
    elseif (matched == 0) then
        imgui.TextDisabled('No board matches.');
    end

    imgui.EndChild();

    imgui.SameLine();

    imgui.BeginChild('##dwl_rows', { 0, 0 }, ImGuiChildFlags_Borders);

    if (not shown) then
        --[[
        * A board IS picked while its rows are on the wire, and telling the
        * player to pick one is the one thing this pane must not say then. The
        * three other things it can honestly be -- the protocol refused, the
        * server silent, an ask answered with a refusal and nothing coming --
        * each get their own sentence rather than all reading as "fetching".
        * Both sentences are spelled when the SELECTION changes, not while the
        * wait runs: that wait can be the whole answer clock, twice.
        --]]
        if (state.refused) then
            imgui.TextDisabled('This addon cannot read what this server sends. Update it through the launcher.');
        elseif (state.selected == nil) then
            imgui.TextDisabled('Pick a board on the left.');
        else
            if (state.fetchingFor ~= state.selected) then
                local entry = catalogEntry(state.selected);
                local label = entry ~= nil and entry.label or state.selected;

                state.fetchingFor  = state.selected;
                state.fetchingText = string.format('Fetching %s...', label);
                state.stalledText  = string.format('%s did not arrive. Refresh asks again.', label);
            end

            if (state.requested ~= nil or #queue > 0) then
                imgui.TextDisabled(state.fetchingText);
            else
                imgui.TextDisabled(state.stalledText);
            end
        end
    else
        -- The heading and the freshness line are drawn for an EMPTY board too:
        -- what a board measures and how old the answer is are exactly the two
        -- questions "nobody yet" raises, and they used to be the two things a
        -- player looking at an empty board could not find out.
        imgui.Text(board.label);

        if (imgui.IsItemHovered()) then
            local tip = boardTip(board.entry);

            if (tip ~= nil) then
                imgui.SetTooltip(tip);
            end
        end

        imgui.SameLine();

        -- Re-spelled once a SECOND, not once a frame: the only thing that
        -- moves in it is the clock, and it counts in whole seconds.
        local second = os.time();

        if (board.ageSecond ~= second) then
            board.ageSecond = second;
            board.ageText   = string.format('(%d shown, %s)', #board.rows, agoText(board.at));
        end

        imgui.TextDisabled(board.ageText);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('The server sends only the leaders of a board, and shares one answer across everyone asking for about a minute. Refresh re-asks.');
        end
    end

    -- NO EARLY RETURN HERE, and none anywhere in this function: the two
    -- BeginChild calls above it are open, and an early return is how a Begin
    -- loses its End the next time somebody adds a line under it.
    if (shown and #board.rows == 0) then
        imgui.TextDisabled('Nobody on this board yet. Be first.');
    elseif (shown) then
        -- The hover is tested inside the branch that DREW something: with
        -- neither line drawn, IsItemHovered() would still be about the count
        -- above and would answer for it with the wrong sentence.
        local standing = false;

        if (board.youText ~= nil) then
            imgui.TextColored(theme.colors.ok, board.youText);

            standing = true;
        elseif (state.charName ~= nil) then
            imgui.TextDisabled('You are not on this board yet.');

            standing = true;
        end

        if (standing and imgui.IsItemHovered()) then
            imgui.SetTooltip('Only the leaders are listed, so a place off the bottom of this table does not show. Everything this window shows also works typed as !leaderboard.');
        end

        -- The score column is measured, once per board, from the widest score
        -- it actually has to draw: a fixed 150 clipped "1,234,567 gil" the
        -- moment the window was narrowed, and wasted the room on a board of
        -- two-digit counts.
        if (board.scoreWidth == nil) then
            local widest = (imgui.CalcTextSize('Score'));

            for _, row in ipairs(board.rows) do
                local size = (imgui.CalcTextSize(row.text));

                if (size > widest) then
                    widest = size;
                end
            end

            board.scoreWidth = widest + 18;
        end

        if (imgui.BeginTable('##dwl_table', 3,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                        ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
            -- Name STRETCHES and the two numbers are fixed: narrowing the
            -- window then shortens a name, which is recoverable, instead of
            -- clipping the score, which is the whole point of the board.
            imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 34, 0);
            imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthStretch, 0, 0);
            imgui.TableSetupColumn('Score', ImGuiTableColumnFlags_WidthFixed, board.scoreWidth, 0);
            imgui.TableSetupScrollFreeze(0, 1);

            -- The header row is drawn by hand so each column can say what it
            -- means on hover: TableHeadersRow() draws all three as one item and
            -- leaves nothing for IsItemHovered to be about.
            imgui.TableNextRow(ImGuiTableRowFlags_Headers, 0);

            imgui.TableNextColumn();
            imgui.TableHeader('#');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Standard competition ranking: everyone tied for a place shares its number and the next number skips, so two tied at the top are both 1 and the player below them is 3.');
            end

            imgui.TableNextColumn();
            imgui.TableHeader('Name');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Gold is rank 1, whoever holds it. Green is you, anywhere else on the board. Deleted characters and GMs are never on one at all.');
            end

            imgui.TableNextColumn();
            imgui.TableHeader('Score');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(UNIT_TIPS[board.unit] or UNKNOWN_UNIT_TIP);
            end

            -- Ranks and every cell's text were spelled on the `z|` that
            -- committed these rows; this loop only reads them.
            for _, row in ipairs(board.rows) do
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(row.rankText);

                imgui.TableNextColumn();

                if (row.rank == 1) then
                    imgui.TextColored(theme.colors.warn, row.name);
                elseif (state.charName ~= nil and row.name == state.charName) then
                    imgui.TextColored(theme.colors.ok, row.name);
                else
                    imgui.Text(row.name);
                end

                imgui.TableNextColumn();
                imgui.Text(row.text);
            end

            imgui.EndTable();
        end
    end

    imgui.EndChild();
end

ashita.events.register('d3d_present', 'dwleaderboard_present', function ()
    -- Before the visibility check: a request issued a moment before the
    -- window was closed still has to reach the server.
    pumpQueue();
    checkAnswers();

    -- Who is logged in, for the own-row highlight (the dwparse shape). The
    -- memory manager is asked for through a nil check because this whole
    -- block runs OUTSIDE the render pcall, and a throw here would be sixty
    -- error lines a second rather than one closed window.
    if (state.charCheckAt ~= nil and os.clock() >= state.charCheckAt) then
        local memory = AshitaCore:GetMemoryManager();
        local party  = memory ~= nil and memory:GetParty() or nil;
        local name   = party ~= nil and party:GetMemberName(0) or '';

        if (name ~= nil and name ~= '') then
            state.charName    = name;
            state.charCheckAt = nil;

            -- The name is the other half of the own-row highlight, and it
            -- settles seconds after a board may already have been committed.
            markOwn(state.board);
        else
            state.charCheckAt = os.clock() + 2.0;
        end
    end

    if (not state.open[1]) then
        return;
    end

    -- The board list is asked for LAZILY -- the first frame the window is
    -- actually open -- so a player who never opens it never handshakes. ONCE
    -- per login, and not "whenever the list is empty": a server that answers
    -- the ask with a refusal leaves it empty, and the old condition re-armed
    -- on the next frame (see the header).
    if (not state.boardsAsked and #state.boards == 0 and state.requested == nil
            and not state.serverSilent and not state.refused) then
        state.boardsAsked = true;

        ask('boards');
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 620, 460 }, ImGuiCond_FirstUseEver);

    -- A floor under the size, so the list, the table and the header row stay
    -- usable however far the window is dragged in. Nothing caps the top end.
    imgui.SetNextWindowSizeConstraints({ 520, 320 }, { 99999, 99999 });

    -- NoDocking: the suite-wide flag (fused dw windows survive imgui.ini).
    local visible = imgui.Begin('DriftwoodXI Leaderboard##dwleaderboard', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwleaderboard'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwleaderboard'):append(chat.message('Window closed. Everything it shows also works typed as !leaderboard.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

-- Anything the player types counts against the client's chat rate limit, so
-- a queued line behind a typed one waits its interval instead of racing it.
ashita.events.register('packet_out', 'dwleaderboard_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dwl') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwleaderboard_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed (the suite-wide
    -- /Warehouse lesson).
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/leaderboard' and first ~= '/lb') then
        return;
    end

    e.blocked = true;

    --[[
    * `/lb <board>` opens on one board by name -- either the key the `o|`
    * records carry, which is what the typed tier takes, or the label the
    * player reads off the list. Every remaining word is joined, so
    * `/lb gil on hand` is one name and not four. NOTHING TYPED REACHES THE
    * WIRE: the name is matched against the catalogue and the line that goes
    * out carries the key the SERVER offered. Anything that is not a board's
    * name goes into the find box, which is what a player typing half a name
    * meant. With no argument at all this stays what it was, a toggle.
    --]]
    local wanted = nil;

    if (#args > 1) then
        local words = T{ };

        for index = 2, #args do
            words:append(args[index]);
        end

        wanted = string.lower(table.concat(words, ' '));

        if (wanted == '') then
            wanted = nil;
        end
    end

    if (wanted == nil) then
        state.open[1] = not state.open[1];

        if (state.open[1]) then
            state.reported = false;
        end

        return;
    end

    state.open[1]  = true;
    state.reported = false;

    if (showByName(wanted)) then
        rememberBoard(state.selected);

        return;
    end

    if (#state.boards == 0) then
        -- The catalogue has not arrived yet; its commit applies this.
        state.wanted = wanted;

        return;
    end

    filterOrRefuse(wanted);
end);

ashita.events.register('load', 'dwleaderboard_load', function ()
    state.charCheckAt = os.clock() + 3.0;

    print(chat.header('dwleaderboard'):append(chat.message('/leaderboard (or /lb) opens the boards; /lb <name> opens one of them. Everything it shows also works typed as !leaderboard.')));
end);
