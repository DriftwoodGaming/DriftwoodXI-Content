--[[
* DriftwoodXI -- dwmerits
*
* The merit sheet with this SERVER's numbers: every category's true Combo
* Total (Weapon Skills 70, both job groups 20 per job, Attributes 210,
* Others 20, HP/MP 75), every entry's real ceiling and next cost, and
* raise/lower buttons that reach past the stock menu's caps.
*
* WHY THIS WINDOW EXISTS: the retail client bakes its own category maximums
* into the built-in merit menu and refuses clicks past them -- the server
* stopped enforcing those caps in the 2026-08-30/09-01 expansion, but the
* menu never got the memo and cannot be patched. The menu's counts are
* always right; its maximums and its refusals are retail's, not ours. This
* window is the one that tells the truth and clicks the whole way up.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no merit arithmetic and no category table: names, ceilings,
* costs, totals and maximums all ride the wire (`!dwi`, sender _DWIDATA,
* documentation/dwi_protocol.md), and a raise clicked here reaches exactly
* the xi.dwMerits.edit that `!merits raise hp` typed reaches -- the Mog
* House gate, the ceilings and the wallet are the server's to enforce, and
* this window's greyed buttons are a courtesy, not the authority.
*
* THERE IS EXACTLY ONE NUMBER IN THIS FILE, and it is named as the mirror it
* is: CP_PER_JOB_POINT, because the `j|` record sends the caller's capacity
* points and not the ceiling they count towards, so the Job Points header has
* no denominator without it. The harness pins it against
* src/map/job_points.cpp; a `cpMax` on getJobPointDoorInfo would retire it.
*
* LAZY BY DESIGN: sync fetches the wallet and the six shared category
* summaries; a category's rows arrive when you look at it. The whole
* 296-entry sheet never rides one response (bursts need ceilings).
*
* ONE EDIT IN FLIGHT: raise/lower are writes, so they are never collapsed,
* never retried, and never stacked -- the buttons disarm until the server's
* r| answer lands (or five seconds pass). A lost click costs a click; a
* replayed click would cost merit points.
*
* SINCE 1.1.0 (2026-09-01): a JOB POINTS tab (any job's job points, capacity
* points, every type with its next cost, the gift ladder, and raise buttons
* through the 0x0bf chain -- Mog House, same as the menu) and an ASCENSION
* tab (the limit point bank -- every limit point you ever earned, banked
* beside the retail pool -- convertible to merits at 10,000 each or spent on
* mastery tiers: permanent power that reaches you and every squad member
* you call). Both additive on the same wire, no protocol bump.
*
* TURN IT OFF AND NOTHING IS LOST. `!merits` typed in chat says the same
* numbers in prose, and `!dwi sync` shows exactly what this window is told.
*
* 1.1.3 (2026-09-03): retired spell merits (Dia III and the like -- retail
* moved them onto scrolls) no longer ride the job-group rows unless points
* already sit in one, in which case the row is marked "(retired)" with no
* next cost, so the + button greys and the - button refunds. Spell tiers
* read "III", not "Iii". Switching characters now also drops the previous
* character's job points, bank and mastery sheet, not just its merits. The
* "Next costs" column is wide enough to say so.
*
* 1.2.0 (2026-09-06): LAZY IS NOW TRUE OF ALL FOUR TABS. Opening the window
* used to ask for the wallet, the selected slice, the whole mastery sheet
* AND the played job's job points -- four lines at 1.2s apart, three of them
* for tabs nobody had clicked. Every tab now arms its own read the first
* time it is drawn, which is what the header above always claimed and what
* the Assign tab alone actually did; the same change is what lets a tab
* whose read never came back ASK AGAIN instead of saying "Fetching..."
* forever (it did, after a character switch, until 1.2.0).
*
* Also 1.2.0: a slice is filed under the token the ANSWER names rather than
* the token last asked for; a server note no longer vanishes under "Synced."
* in the same frame; a server whose merit door predates job points latches
* instead of refusing into chat on every open; -5 refunds the way +5 buys;
* the Assign tab has a find box and a "room left" filter; the category and
* job you last looked at are remembered per PC; and every button, badge and
* number says what it is on hover.
*
* 1.2.1 (2026-09-09): A MAP WHOSE KEYS ARE DATA IS A PLAIN TABLE, NEVER `T{ }`
* -- dwgmpanel 1.3.1's rule, applied here. Ashita's sugar gives every T{}
* an `__index` of `table_mt[k] or table[k]`, so an ABSENT key whose NAME is
* one of sugar's sixty-five table methods answers with that FUNCTION rather
* than with nil, and every `== nil` guard above such a read is defeated.
* * `state.rows` is keyed by SLICE TOKEN and is plain now; sheetView's only
* guard is `if (blocks == nil) then return nil end`, so a token named like a
* sugar method would have walked a function with ipairs inside the render
* pcall. No token collides today. `state.cats` is keyed by a number and is
* left as it was.
--]]

addon.name    = 'dwmerits';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.1';
addon.desc    = 'Merit sheet for DriftwoodXI: true totals, raise/lower past the stock menu, job points, and Ascension.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local theme    = require('dwtheme');
local settings = require('settings');

-- The Job Points tooltip catalog (1.1.4, owner request 2026-09-04): one line
-- per job point type id, GENERATED beside this file by
-- tools/dwmerits/gen_jp_catalog.py from sql/job_points.sql and its authored
-- descriptions. A missing or broken copy costs the tooltips, never the tab.
local catalogOk, jpcatalog = pcall(require, 'jpcatalog');

if (not catalogOk or type(jpcatalog) ~= 'table' or type(jpcatalog.byId) ~= 'table') then
    jpcatalog = nil;
end
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

local DATA_SENDER = '_DWIDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

--[[
* THE OLD-DOOR LATCH (1.2.0). Job points, the bank, `convert` and `ascend`
* were added to the wire on 2026-09-01 as ADDITIVE verbs, which is right --
* an old addon ignores records it does not know -- but the other direction
* had nothing holding it: an addon NEWER than the server asks for `jp` and
* `mastery`, and a merit door that predates them answers with the verb list
* it does carry. That refusal used to reach chat as an error and repaint the
* status line, once per tab, on every window open, forever.
*
* So the sentence is latched instead: the two younger tabs stop asking and
* say what is actually wrong. Cleared by the login packet, by Refresh and by
* opening the window on purpose, so a server that updates while the player is
* logged in is asked again the next time they look.
*
* The literal is dwi.lua's own; tools/dwmerits/harness_dwmerits.py holds the
* two equal so a reworded refusal cannot silently stop matching.
--]]
local OLD_DOOR_MARK = 'No merit verb by that name';

--[[
* The marking merit_door.lua puts on a retired spell merit's name (the
* 2026-09-03 round; documentation/dwi_protocol.md says the row rides with
* `next` = 0 and the name suffixed). Matched as a SUFFIX and nothing else --
* a substring test would call any merit whose name merely contains the word
* retired, and the rule this suite keeps is that a scarred line must not
* still pass. Held equal to the server's literal by the harness.
--]]
local RETIRED_MARK = ' (retired)';

--[[
* Capacity points per job point, from src/map/job_points.cpp's own constant
* (`adjustedCapacity >= 30000`). A MIRROR, and named as one: this window owns
* no arithmetic, but the `j|` record carries the caller's capacity points
* without the ceiling they count towards, so the bar has no denominator
* without it. The harness pins this number against the C++ source, and
* getJobPointDoorInfo growing a `cpMax` field would retire it -- see the
* round's report.
--]]
local CP_PER_JOB_POINT = 30000;

--[[
* The selector: which slice of the sheet the window is looking at. The six
* shared tokens and the job list are the protocol's own vocabulary
* (documentation/dwi_protocol.md); labels, totals, ceilings and rows all
* still come off the wire, so this is navigation, not data --
* tools/dwmerits/harness_dwmerits.py holds these tokens equal to the
* server's own category table so the two can never drift.
--]]
local SHARED = T{
    { token = 'hpmp',       label = 'HP / MP' },
    { token = 'attributes', label = 'Attributes' },
    { token = 'combat',     label = 'Combat Skills' },
    { token = 'magic',      label = 'Magic Skills' },
    { token = 'others',     label = 'Others' },
    { token = 'ws',         label = 'Weapon Skills' },
};

local JOBS = T{
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK', 'BST', 'BRD',
    'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU', 'COR', 'PUP', 'DNC', 'SCH',
    'GEO', 'RUN',
};

-- The lowercased job list. Built once because the Job Points tab compares
-- the selected job against the token the wire answered with on every frame,
-- and `job:lower()` in a render loop is one allocation per comparison.
local JOB_TOKENS = T{ };
local JOB_PICK_IDS = T{ };

for i, job in ipairs(JOBS) do
    JOB_TOKENS:append(job:lower());
    JOB_PICK_IDS:append(string.format('%s##dwmerits_jobpick_%d', job, i));
end

-- The combo's flat item list: the six shared slices, then one entry per
-- job (both of its groups arrive in one `job` response). Each entry carries
-- its own Selectable id, built here rather than formatted twenty-eight times
-- on every frame the combo is open.
local PICKS = T{ };

for _, entry in ipairs(SHARED) do
    PICKS:append({ kind = 'cat', token = entry.token, label = entry.label });
end

for _, job in ipairs(JOBS) do
    PICKS:append({ kind = 'job', token = job:lower(), label = job .. ' Job Groups' });
end

for i, entry in ipairs(PICKS) do
    entry.selectId = string.format('%s##dwmerits_pick_%d', entry.label, i);
end

--[[
* Persisted per PC (1.2.0), and deliberately only the NAVIGATION: which slice
* and which job the player was last looking at, and whether the Assign tab's
* room filter was on. Not one merit number is kept -- every number in this
* window is the server's and is re-asked on open, so a settings file that
* went missing or was hand-edited into nonsense costs a combo position and
* nothing else.
*
* TOKENS, NOT INDEXES: the pick combo's order is PICKS' order, and a saved
* index would point at the wrong category the day a slice is inserted. The
* token is the wire's own name for the slice and cannot drift.
--]]
local defaultConfig = T{
    pickToken = 'hpmp',
    jobToken  = 'WAR',
    onlyRoom  = false,
};

local config = defaultConfig;

local okConfig, loadedConfig = pcall(settings.load, defaultConfig);

if (okConfig and loadedConfig ~= nil) then
    config = loadedConfig;
end

-- A file written by an older build, or by hand, must not be able to index
-- past the end of either list: every read below is resolved back to 1.
local function indexOfPick(token)
    for i, entry in ipairs(PICKS) do
        if (entry.token == token) then
            return i;
        end
    end

    return 1;
end

local function indexOfJob(token)
    for i, job in ipairs(JOBS) do
        if (job == token) then
            return i;
        end
    end

    return 1;
end

local function saveConfig()
    pcall(settings.save);
end

local state = T{
    open       = T{ false },

    -- Everything below is replaced wholesale by a response, never merged,
    -- so a stale row cannot survive a refresh (dwtracker's rule).
    charid     = nil,
    wallet     = nil,          -- { points, ceiling, mog }

    -- cats[cat]   = { total, max, token, label }   (from c| records)
    -- rows[token] = ordered { cat-block, ... } for the selected slice; each
    --               block = { cat, entries = { {id,count,ceiling,next,value,name}, ... } }
    --
    -- `rows` IS A PLAIN TABLE, NEVER `T{ }` (1.2.1), and it is dwgmpanel
    -- 1.3.1's rule: a map whose keys are DATA -- here a slice token, `hpmp`
    -- or `ws` or a lowercased job -- must not carry Ashita's sugar
    -- metatable, whose `__index` answers an ABSENT key with `table_mt[k] or
    -- table[k]`. sheetView's only guard is `if (blocks == nil) then return`,
    -- and a token that names a sugar method (`sort`, `count`, `map`, `last`)
    -- would hand it a FUNCTION instead: the guard passes, the render walks a
    -- function with ipairs and the window dies inside its pcall. No token
    -- collides today; the token list is one line from making one that does.
    -- `cats` is keyed by a NUMBER off the wire and cannot collide.
    cats       = T{ },
    rows       = { },

    -- The six shared bars in SHARED's order, rebuilt whenever a c| record
    -- lands rather than searched for six times a frame (1.2.0).
    bars       = T{ },

    pick       = T{ indexOfPick(config.pickToken) },  -- combo index into PICKS
    jobPick    = T{ indexOfJob(config.jobToken) },    -- combo index into JOBS

    -- The Assign tab's client-side view (1.2.0): a find box over the loaded
    -- slice's names and a "room left" filter. Both are the player's own
    -- narrowing of rows already on hand -- no read is sent for either.
    find       = T{ '' },
    onlyRoom   = T{ config.onlyRoom == true },

    -- The view cache: the filtered blocks, and the four things they were
    -- filtered under. modelRev moves on every write to rows/cats, so a stale
    -- view cannot survive an answer. FOUR FIELDS AND NOT ONE FORMATTED KEY:
    -- the key is compared on every frame the Assign tab draws, and building
    -- a string to compare is the allocation the cache exists to avoid.
    modelRev   = 0,
    view       = nil,
    viewToken  = nil,
    viewRev    = -1,
    viewFind   = nil,
    viewRoom   = nil,

    -- Job Points: the fetched job's header, its types and its gift ladder,
    -- replaced wholesale per response (j|/k|/g|).
    jp         = T{ token = nil, header = nil, types = T{ }, gifts = T{ } },

    -- Ascension: the bank (b|) and the mastery sheet (y|), replaced
    -- wholesale per response.
    bank       = nil,
    sheet      = T{ },

    -- "The door answered and there was nothing to show" -- told apart from
    -- "the read is still on the wire" because the tab must say different
    -- things about them. jpEmpty holds the job token that came back headerless.
    jpEmpty    = nil,
    sheetSeen  = false,

    -- Response assembly: records are accepted only between d| and z|, and
    -- cat/job responses build here before replacing the cache, so a
    -- half-arrived slice can never render (dwbags' rule).
    inbound    = nil,
    staging    = nil,
    stageCat   = nil,

    -- Which slice the arriving envelope is about, taken from its own first
    -- c| record rather than from whatever was asked for last (1.2.0).
    stageToken = nil,

    -- True once an m|/e| sentence has arrived inside the open envelope, so
    -- z| leaves it standing instead of painting "Synced." over the one line
    -- that said why nothing came (1.2.0).
    noted      = false,

    -- Which reads are in flight, per tab: the token asked for, or nil for
    -- "this tab may ask". Cleared by forget(), so a Refresh, a zone line and
    -- a character switch all re-arm every tab.
    syncAsked  = false,
    fetching   = nil,
    jpFetching = nil,
    bankAsked  = false,

    -- The one write in flight: { id, verb, at }. Buttons disarm while set.
    pending    = nil,

    -- os.time() of the last envelope that closed cleanly, for the Refresh
    -- tooltip's "asked N seconds ago" (wall seconds, never os.clock()).
    syncedAt   = nil,

    status     = 'Waiting for the first sync.',
    -- 'ok' a confirmation, 'bad' a refusal, 'note' the server saying
    -- something that is neither. A note painted in the confirmation colour
    -- reads as a success, and "No job point types exist for that job" is not
    -- one -- which is exactly how it read until 1.2.0.
    statusTone = 'ok',
    reported   = false,
};

--[[
* Ashita's settings library is CHARACTER-SPECIFIC and swaps the table itself
* on a character switch (settings.lua's process_character_switch), raising
* this callback with the new character's file. So the two combo positions are
* re-resolved from it here -- without that the window opened an alt on the
* main's slice, which is exactly the per-character promise this block exists
* to keep. Registered AFTER `state` for the plain reason that it writes to it.
--]]
pcall(settings.register, 'settings', 'dwmerits_settings_update', function (updated)
    if (updated ~= nil) then
        config = updated;

        state.pick[1]     = indexOfPick(config.pickToken);
        state.jobPick[1]  = indexOfJob(config.jobToken);
        state.onlyRoom[1] = config.onlyRoom == true;
    end
end);

-- The status line's one setter, so a sentence and its colour can never be
-- assigned apart. Tones are 'ok', 'bad' and 'note'; anything else is 'ok'.
local function setStatus(text, tone)
    state.status     = text;
    state.statusTone = tone or 'ok';
end

-- Every write to rows/cats/sheet moves this, and the view cache is keyed on
-- it: a filtered list that outlived its model is the stale-row bug one layer
-- up from the one the wholesale-replace rule already closes.
local function touchModel()
    state.modelRev = state.modelRev + 1;
    state.view     = nil;
    state.viewRev  = -1;
end

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. Reads are deduplicated; WRITES ARE NOT QUEUED HERE AT ALL -- they go
* through sendEdit below, one in flight, never collapsed, never retried.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

--[[
* Drop whatever is still QUEUED for a verb the server has just told us it does
* not carry (1.2.0). A latch that only stops the next ask still lets the line
* already sitting in the queue go out a beat later and be refused a second
* time -- which is one more refusal in chat for something the player never
* did, and the whole reason the latch exists.
--]]
local function unqueue(prefix)
    for i = #queue, 1, -1 do
        if (queue[i]:sub(1, #prefix) == prefix) then
            table.remove(queue, i);
        end
    end
end

local function pumpQueue()
    -- The empty test comes FIRST (1.2.0): canSend() crosses into the memory
    -- manager for the player object on every call, and this runs sixty times
    -- a second for the whole session, almost always over an empty queue.
    -- Nothing else about the order matters -- an empty queue has no line to
    -- hold or to drop.
    if (#queue == 0) then
        return;
    end

    -- Held shut while zoning: a line handed to a zoning client is not
    -- delayed, it is LOST, with "A command error occurred." as its residue
    -- (dwecho.lua's canSend; 2026-08-15).
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking for READS: an unanswered request is asked once more and
* then left alone. A PLAIN TABLE, NOT T{ } (dwbags' shadowed-key lesson).
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

-- True once this server has shown it does not speak dwmerits -- an unknown
-- !command falls through to /say, so retrying against a dead verb is the
-- player publicly chatting "!dwi sync". Cleared by any d| envelope and by
-- the player acting on purpose (window open, refresh).
local serverSilent = false;

--[[
* Has this server EVER opened an envelope? (1.2.0.)
*
* serverSilent used to latch on any read that ran out of tries, and a dropped
* packet on a perfectly healthy server is exactly that: after one hiccup the
* zone-in resync stopped firing for the rest of the session -- so the wallet
* and the Mog House flag went stale on every zone, silently, and the only
* symptom was greyed buttons inside a Mog House.
*
* A server that has answered once is not silent; it is a server that lost a
* line. Only a door that has never spoken is worth latching against, because
* only there does the retry reach /say as public chat.
--]]
local doorSpoke = false;

-- The additive-verb latch (see OLD_DOOR_MARK above): true once this server's
-- merit door has said it carries neither `jp` nor `mastery`. Module-local,
-- set only in the e| branch, read only at the two younger tabs' ask sites.
local doorIsOld = false;

--[[
* Latched by a `d|` whose version this addon cannot read (1.2.0). Every tab's
* self-arm consults it, because a server speaking another record layout
* answers every read the same way -- and the tabs became self-arming in this
* same version, so without this a player on a mismatched build would send a
* fresh line every time they clicked a tab and read "Update dwmerits" again
* for their trouble.
*
* Lifted by the login packet, by Refresh and by opening the window, the way
* the old-door latch is: a server that updates under a logged-in player is
* asked again the next time they look.
--]]
local protocolBad = false;

--[[
* Drop every outstanding ask AND every per-tab fetch latch, so each tab asks
* again the first time it is drawn. One function because the two must move
* together: a latch that outlives its request is a tab that says "Fetching..."
* over a read that gave up (the 1.1.x Job Points tab after a character
* switch), and a request that outlives its latch is the same read twice.
--]]
local function forget()
    requested        = {};
    state.syncAsked  = false;
    state.fetching   = nil;
    state.jpFetching = nil;
    state.bankAsked  = false;

    -- The "answered, and it was empty" marks go with them: a Refresh is the
    -- player asking again, and an empty answer from before is not a reason to
    -- refuse to.
    state.jpEmpty   = nil;
    state.sheetSeen = false;
end

-- Requests are keyed by the whole line ('cat hpmp', 'job war', 'jp war');
-- the envelope names only the verb ('d|1|cat', 'd|1|jp'). Match on the first
-- word, or every argument-carrying read goes unanswered by name, is re-asked
-- once and then reports "No answer from the server" over a server that
-- answered twice (1.1.2, the 2026-09-01 reports).
local function answered(verb)
    for key, asked in pairs(requested) do
        if (type(asked) == 'table' and (key == verb or key:match('^(%S+)') == verb)) then
            asked.answered = true;

            --[[
            * ...and drop the RETRY of it that may still be sitting in the
            * queue (1.2.0). A slow answer is exactly the case where a re-ask
            * has already been issued but not yet pumped, and sending it after
            * the answer landed is a second envelope for data already on
            * screen.
            *
            * Gated on tries > 1 because the match above is by FIRST WORD:
            * a fresh `cat attributes` asked while a `cat hpmp` answer is in
            * flight is marked answered by that answer (the 1.1.2 trade-off,
            * see the comment above), and dropping ITS queued line would lose
            * a read the player just asked for. Only a key that has already
            * been re-asked can have a spare copy to drop.
            --]]
            if (asked.tries > 1) then
                unqueue('!dwi ' .. key);
            end
        end
    end
end

local function ask(verb)
    requested[verb] = { at = os.clock(), answered = false, tries = 1 };

    issue('!dwi ' .. verb);
end

local function checkAnswers()
    -- Nothing outstanding is the common case by a wide margin, and both the
    -- clock read and canSend()'s trip through the memory manager are pure
    -- cost there (1.2.0). next() rather than a count: `requested` is keyed by
    -- command line, so it has no array part to measure.
    if (next(requested) == nil and state.pending == nil) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    -- One clock read for the whole pass. It used to be one per outstanding
    -- ask plus one per retry, sixty times a second.
    local now = os.clock();

    for verb, asked in pairs(requested) do
        if (not asked.answered and (now - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                asked.at    = now;
                asked.tries = asked.tries + 1;

                issue('!dwi ' .. verb);
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;

                -- Only a door that has never answered is latched silent; see
                -- doorSpoke above.
                if (not doorSpoke) then
                    serverSilent = true;
                end

                setStatus(doorSpoke
                    and 'The server did not answer that one. Press Refresh to ask again.'
                    or 'No answer from the server. Is DriftwoodXI up to date?', 'bad');
            end
        end
    end

    -- The write's own clock: no retry, just the buttons back. The next
    -- sync shows whatever really happened.
    if (state.pending ~= nil and (now - state.pending.at) >= ANSWER_TIMEOUT) then
        state.pending   = nil;
        setStatus('No answer to that edit -- nothing retried. Refresh to see where things stand.', 'bad');
    end
end

--[[
* Has a read for this line given up? The tabs' placeholder lines consult it:
* a window that says "Fetching this category from the server..." over a read
* that ran out of tries eight seconds ago is telling the player to keep
* waiting for something that is never coming.
--]]
local function gaveUpOn(verb)
    local asked = requested[verb];

    return asked ~= nil and asked.gaveUp == true;
end

local function currentPick()
    return PICKS[state.pick[1]] or PICKS[1];
end

local function fetchVerbFor(pick)
    if (pick.kind == 'job') then
        return 'job ' .. pick.token;
    end

    return 'cat ' .. pick.token;
end

local function requestSync()
    state.syncAsked = true;

    ask('sync');
end

local function requestPick()
    local pick = currentPick();

    -- The latch is "a read for this slice is out", not "this is where the
    -- answer goes" -- the answer files itself under the token its own c|
    -- record names (see handleRecord's z| branch). Before 1.2.0 this WAS the
    -- filing address, and a combo change between the ask and the z| filed
    -- one slice's rows under the other's name; the comment here claimed the
    -- opposite, which is why it took a read of both halves to see.
    state.fetching = pick.token;

    ask(fetchVerbFor(pick));
end

--[[
* The one write path. Never queued with the reads, never deduplicated,
* never retried: one edit in flight, buttons disarmed until its r| lands.
--]]
local function sendEdit(verb, meritId, count)
    if (state.pending ~= nil) then
        return;
    end

    -- A click handed to a zoning client is not delayed, it is lost -- and a
    -- write is never queued, so there is nothing to hold it in. Say so
    -- (1.2.0): a button that visibly did nothing and said nothing is the one
    -- thing worse than a refusal.
    if (not echo.canSend()) then
        setStatus('Not while the client is zoning -- that click was not sent. Try it again in a moment.', 'bad');

        return;
    end

    state.pending = { id = meritId, verb = verb, at = os.clock() };
    lastSend      = os.clock();

    echo.send(string.format('!dwi %s %d %d', verb, meritId, count));
end

-- The Ascension writes: `convert <n>` and `ascend <key>` -- the same one-in-
-- flight discipline, a different argument shape.
local function sendBankAction(line)
    if (state.pending ~= nil) then
        return;
    end

    if (not echo.canSend()) then
        setStatus('Not while the client is zoning -- that click was not sent. Try it again in a moment.', 'bad');

        return;
    end

    state.pending = { id = 0, verb = 'bank', at = os.clock() };
    lastSend      = os.clock();

    echo.send('!dwi ' .. line);
end

local function requestJob()
    local token = JOB_TOKENS[state.jobPick[1]] or JOB_TOKENS[1];

    state.jpFetching = token;

    ask('jp ' .. token);
end

local function requestMastery()
    state.bankAsked = true;

    ask('mastery');
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* A u| row into a plain entry table.
*
* EVERYTHING THE ROW DRAWS IS BUILT HERE, ONCE (1.2.0). A merit row used to
* cost six string.format calls per frame -- the two number cells, the three
* button ids and the lowercased name the find box compares -- and a job
* group is twenty-six rows, so the sheet was doing better than a hundred and
* fifty formats sixty times a second to draw numbers that only change when an
* answer lands. They are built on the answer instead.
*
* `retired` is the server's own marking (RETIRED_MARK), read as a suffix:
* the merit teaches nothing, the + is greyed by the zero next cost the wire
* already sends, and the row's tooltip must say that rather than quoting a
* per-upgrade value the player will never be paid.
--]]
local function parseEntry(parts)
    local id      = tonumber(parts[2]) or 0;
    local count   = tonumber(parts[3]) or 0;
    local ceiling = tonumber(parts[4]) or 0;
    local cost    = tonumber(parts[5]) or 0;
    local name    = parts[7] or '?';

    return {
        id       = id,
        count    = count,
        ceiling  = ceiling,
        next     = cost,
        value    = tonumber(parts[6]) or 0,
        name     = name,
        retired  = name:sub(-#RETIRED_MARK) == RETIRED_MARK,

        -- Drawn every frame, built once here.
        search   = name:lower(),
        taken    = string.format('%d / %d', count, ceiling),
        cost     = cost > 0 and string.format('%d', cost) or nil,
        lowerId  = string.format('-##dwmerits_l_%d', id),
        lower5Id = string.format('-5##dwmerits_l5_%d', id),
        raiseId  = string.format('+##dwmerits_r_%d', id),
        raise5Id = string.format('+5##dwmerits_r5_%d', id),
    };
end

-- An edit's refreshed u| replaces its row wherever the cache holds it.
local function replaceRow(entry)
    for _, blocks in pairs(state.rows) do
        for _, block in ipairs(blocks) do
            for i, row in ipairs(block.entries) do
                if (row.id == entry.id) then
                    block.entries[i] = entry;

                    return;
                end
            end
        end
    end
end

--[[
* The Overview's bar order, rebuilt when a c| record changes it rather than
* searched for on every frame (1.2.0). overviewBars used to walk the whole
* cats table once per shared token -- and cats grows to fifty entries the
* moment a player browses a few job groups, so it was three hundred string
* comparisons a frame to draw six bars that change only on an answer.
--]]
local function rebuildBars()
    local byToken = { };

    for cat, info in pairs(state.cats) do
        byToken[info.token] = cat;
    end

    local bars = T{ };

    for _, entry in ipairs(SHARED) do
        local cat = byToken[entry.token];

        if (cat ~= nil) then
            bars:append(cat);
        end
    end

    state.bars = bars;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        serverSilent = false;
        doorSpoke    = true;

        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            protocolBad     = true;
            setStatus(string.format('Server protocol %d, addon expects %d. Update dwmerits.', version, PROTOCOL), 'bad');
            state.inbound   = nil;

            -- The envelope IS the answer, whatever version it announced
            -- (dwfame's re-send hazard, closed the same way).
            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            -- And nothing already queued goes out either: every line this
            -- addon sends starts '!dwi ', and a server speaking a layout
            -- this addon cannot read will answer each of them exactly the
            -- same way (1.2.0).
            unqueue('!dwi ');

            state.pending = nil;

            return;
        end

        state.inbound = parts[3];
        state.noted   = false;

        if (state.inbound == 'cat' or state.inbound == 'job') then
            state.staging    = T{ };
            state.stageCat   = nil;
            state.stageToken = nil;
        end

        if (state.inbound == 'jp' or state.inbound == 'jpraise') then
            state.jpStaging = T{ header = nil, types = T{ }, gifts = T{ } };
        end

        if (state.inbound == 'mastery' or state.inbound == 'ascend') then
            state.sheetStaging = T{ };
        end

        answered(state.inbound);

        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            state.pending = nil;
        end

        return;
    end

    -- Notes and refusals are accepted whatever the envelope state: the
    -- sentence saying why something was refused outranks the response it
    -- happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        --[[
        * THE OLD-DOOR LATCH, before anything else this branch does -- and
        * before the chat print, which is the whole point: this refusal is
        * the only thing a server older than the addon can say about `jp`
        * and `mastery`, it arrives once per younger tab per window open,
        * and printing it is telling the player about a mistake they cannot
        * have made. The refusal ENUMERATES the verbs the door does carry,
        * so a door that names `jp` refused something else -- a verb typed
        * by hand -- and the two tabs stay armed.
        --]]
        if (kind == 'e' and string.find(line, OLD_DOOR_MARK, 1, true) ~= nil
                and string.find(line, 'jp', 1, true) == nil) then
            doorIsOld       = true;
            state.pending   = nil;
            setStatus('This server\'s merit door is older than dwmerits: it carries no job points and no Ascension. The other two tabs work.', 'bad');

            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            -- Only the two READS reach the queue; convert and ascend are
            -- writes and go out through sendBankAction, which the latched
            -- tabs can no longer reach because they have no data to draw a
            -- button over.
            unqueue('!dwi jp');
            unqueue('!dwi mastery');

            return;
        end

        setStatus(line:sub(3), kind == 'e' and 'bad' or 'note');

        -- The sentence stands through z| (1.2.0). Every record of an
        -- envelope arrives in the same handful of frames, so a "Synced."
        -- painted at z| over a note raised at m| was a note the player
        -- never saw -- which is exactly what happened to the jp response
        -- for a job with no job point types.
        if (state.inbound ~= nil) then
            state.noted = true;
        end

        if (kind == 'e') then
            -- A refusal RAISED INSIDE an open envelope is that envelope's
            -- answer: without this the ask sat unanswered until its timeout
            -- overwrote the reason with "No answer from the server", and the
            -- buttons stayed disarmed for the pending edit's whole five
            -- seconds over a write the server had already refused.
            if (state.inbound ~= nil) then
                answered(state.inbound);

                state.pending = nil;
            end

            print(chat.header('dwmerits'):append(chat.error(state.status)));

            if (string.find(line, 'not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        -- "Synced." is the DEFAULT answer to a clean close, never an
        -- overwrite: a sentence the server raised inside this envelope is
        -- the one thing it wanted said about it (1.2.0).
        local function synced()
            state.syncedAt = os.time();

            if (not state.noted) then
                setStatus('Synced.', 'ok');
            end
        end

        if (closing == 'cat' or closing == 'job') then
            --[[
            * Commit the staged slice wholesale under the token the ANSWER
            * names -- its own first c| record, with a job group's trailing
            * digit trimmed ('war1' is the wire's name for half of the pick
            * whose token is 'war'). state.fetching is only the fallback,
            * for a slice that somehow carried no c| at all.
            *
            * It used to be state.fetching alone, and that is the ask-time
            * latch: changing the combo between the ask and this line filed
            * the arriving slice under the newly selected token, so the
            * player looked at Attributes and read Weapon Skills. The header
            * comment claimed the opposite. The wire always knew.
            --]]
            local token = state.stageToken or state.fetching;

            if (state.staging ~= nil and #state.staging > 0 and token ~= nil) then
                state.rows[token] = state.staging;

                touchModel();
            end

            state.staging    = nil;
            state.stageCat   = nil;
            state.stageToken = nil;

            synced();
        elseif (closing == 'sync') then
            synced();
        elseif (closing == 'jp' or closing == 'jpraise') then
            if (state.jpStaging ~= nil and state.jpStaging.header ~= nil) then
                local gifts = state.jpStaging.gifts;

                state.jp = T{
                    token  = state.jpStaging.header.token,
                    header = state.jpStaging.header,
                    types  = state.jpStaging.types,
                    gifts  = gifts,
                    -- Counted here, not once a frame: the ladder's length
                    -- only changes when a job's answer replaces it.
                    giftsText = #gifts > 0
                        and string.format('Gifts -- %d rungs, unlocked by total job points spent on this job:', #gifts)
                        or nil,
                };

                state.jpEmpty = nil;
            elseif (closing == 'jp') then
                -- THE DOOR ANSWERED AND CARRIED NO HEADER. That is what a job
                -- with no job point types on this server looks like (the
                -- server sends an m| sentence with it), and it is an ANSWER --
                -- so the tab must say so rather than sit on "Fetching this
                -- job from the server..." over a read that is already home.
                -- Which job is remembered from the ask, because the empty
                -- answer names none.
                state.jpEmpty = state.jpFetching;
            end

            state.jpStaging = nil;

            if (closing == 'jp') then
                synced();
            end
        elseif (closing == 'mastery' or closing == 'ascend') then
            if (state.sheetStaging ~= nil and #state.sheetStaging > 0) then
                state.sheet = state.sheetStaging;
            end

            state.sheetStaging = nil;

            -- The envelope closed, whatever it carried: a store with no
            -- catalog lines is an answer too, and the tab has to be able to
            -- tell it from a read still on the wire.
            if (closing == 'mastery') then
                state.sheetSeen = true;

                synced();
            end
        end

        return;
    end

    -- The bank (b|) and a mastery line (y|): Ascension, additive. The lines
    -- the tab draws are built here rather than sixty times a second.
    if (kind == 'b') then
        local banked   = tonumber(parts[2]) or 0;
        local lifetime = tonumber(parts[3]) or 0;
        local spent    = tonumber(parts[4]) or 0;
        local perMerit = tonumber(parts[5]) or 10000;

        state.bank = {
            banked   = banked,
            lifetime = lifetime,
            spent    = spent,
            perMerit = perMerit,

            bankedText = string.format('Limit points banked: %d', banked),
            ledgerText = string.format('%d earned in all, %d spent. Every limit point you earn banks here, beside the retail bar.', lifetime, spent),
            rateText   = string.format('Merit points cost %d banked limit points each.', perMerit),
        };

        return;
    end

    if (kind == 'y') then
        if (state.sheetStaging ~= nil) then
            local key   = parts[3] or '';
            local tier  = tonumber(parts[4]) or 0;
            local max   = tonumber(parts[5]) or 0;
            local price = tonumber(parts[6]) or 0;

            state.sheetStaging:append({
                id    = tonumber(parts[2]) or 0,
                key   = key,
                tier  = tier,
                max   = max,
                price = price,
                name  = parts[7] or '?',
                desc  = parts[8] or '',

                tierText  = string.format('%d / %d', tier, max),
                priceText = price > 0 and string.format('%d LP', price) or nil,
                buyId     = string.format('Buy##dwmerits_asc_%s', key),
            });
        end

        return;
    end

    -- A bank action's outcome, in words (convert / ascend).
    if (kind == 'a') then
        state.pending   = nil;
        setStatus(parts[3] or '', (tonumber(parts[2]) or 0) == 0 and 'bad' or 'ok');

        return;
    end

    -- Job points: a job header (j|), a type (k|), a gift rung (g|).
    if (kind == 'j') then
        if (state.jpStaging ~= nil) then
            local token = parts[2] or '';
            local jp    = tonumber(parts[3]) or 0;
            local cp    = tonumber(parts[4]) or 0;
            local spent = tonumber(parts[5]) or 0;
            local label = parts[6] or '';

            state.jpStaging.header = {
                token = token,
                jp    = jp,
                cp    = cp,
                spent = spent,
                label = label,

                -- CP_PER_JOB_POINT is the mirror named at the top of this
                -- file: the wire sends the capacity points but not the
                -- ceiling they count towards.
                headerText = string.format('%s: %d job points to spend, %d / %d capacity points, %d spent in all.',
                    label, jp, cp, CP_PER_JOB_POINT, spent),
            };
        end

        return;
    end

    if (kind == 'k') then
        if (state.jpStaging ~= nil) then
            local id    = tonumber(parts[2]) or 0;
            local level = tonumber(parts[3]) or 0;
            local max   = tonumber(parts[4]) or 20;
            local cost  = tonumber(parts[5]) or 0;

            state.jpStaging.types:append({
                id    = id,
                level = level,
                max   = max,
                next  = cost,
                name  = parts[6] or '?',

                levelText = string.format('%d / %d', level, max),
                costText  = cost > 0 and string.format('%d JP', cost) or nil,
                raiseId   = string.format('+##dwmerits_jp_%d', id),
            });
        end

        return;
    end

    if (kind == 'g') then
        if (state.jpStaging ~= nil) then
            local required = tonumber(parts[2]) or 0;
            local mod      = tonumber(parts[3]) or 0;
            local value    = tonumber(parts[4]) or 0;
            -- The gift's own name rides the wire since 1.1.1 (the
            -- job_point_gifts desc column); an older server sends four
            -- fields and the rung reads "mod N" as it did before.
            local name     = (parts[5] ~= nil and parts[5] ~= '') and parts[5] or string.format('mod %d', mod);

            state.jpStaging.gifts:append({
                jp    = required,
                mod   = mod,
                value = value,
                name  = name,

                line  = string.format('  %5d JP  %s %+d', required, name, value),
            });
        end

        return;
    end

    if (kind == 'w') then
        local charid = tonumber(parts[5]);

        -- A different character answering wipes the whole cache: an alt's
        -- merit sheet surviving into this one's window is exactly the quiet
        -- wrongness this project exists to rule out.
        if (state.charid ~= nil and charid ~= nil and charid ~= state.charid) then
            state.cats  = T{ };
            state.rows  = { };
            state.bars  = T{ };
            -- The other tabs are this character's too (1.1.3): an alt's job
            -- points, bank and mastery tiers surviving into this one's
            -- window is the same quiet wrongness, one tab over.
            state.jp    = T{ token = nil, header = nil, types = T{ }, gifts = T{ } };
            state.bank  = nil;
            state.sheet = T{ };

            touchModel();

            --[[
            * AND THE LATCHES WITH THEM (1.2.0). Wiping the data without
            * wiping "a read for this is already out" left every tab saying
            * "Fetching ... from the server" over a request that had been
            * answered -- for the character who just logged out. The Job
            * Points tab never recovered short of a Refresh, because its
            * self-arm is gated on exactly that latch.
            *
            * forget() drops the outstanding asks too, which is right: they
            * belong to the previous character and their answers are already
            * discarded by the branch above.
            --]]
            forget();
        end

        local points  = tonumber(parts[2]) or 0;
        local ceiling = tonumber(parts[3]) or 0;

        state.charid = charid;
        state.wallet = {
            points  = points,
            ceiling = ceiling,
            mog     = (tonumber(parts[4]) or 0) == 1,
            text    = string.format('Merit points: %d / %d', points, ceiling),
        };

        return;
    end

    if (kind == 'c') then
        local cat = tonumber(parts[2]);

        if (cat == nil) then
            return;
        end

        local total = tonumber(parts[3]) or 0;
        local max   = tonumber(parts[4]) or 0;
        local token = parts[5] or '';
        local label = parts[6] or '';
        local fill  = max > 0 and (total / max) or 0;

        if (fill > 1) then fill = 1; end

        state.cats[cat] = {
            total    = total,
            max      = max,
            token    = token,
            label    = label,
            fraction = fill,
            barText  = string.format('%s  --  %d / %d', label, total, max),
        };

        rebuildBars();
        touchModel();

        if (state.staging ~= nil) then
            -- The table's ImGui id rides the block: two blocks of one answer
            -- always carry different category numbers, so the number alone is
            -- unique, and it is built here rather than formatted once per
            -- block on every frame.
            state.staging:append({ cat = cat, entries = T{ }, tableId = string.format('##dwmerits_t_%d', cat) });
            state.stageCat = cat;

            --[[
            * THE ENVELOPE NAMES ITS OWN SLICE. The first c| of a cat/job
            * response is the token the answer is about, and a job group's
            * name carries the group digit the pick's token does not ('war1'
            * and 'war2' are both the 'war' pick). Taken once per envelope,
            * so the SECOND group of a job response cannot re-file it.
            --]]
            if (state.stageToken == nil) then
                if (state.inbound == 'job') then
                    state.stageToken = token:gsub('%d+$', '');
                else
                    state.stageToken = token;
                end
            end
        end

        return;
    end

    if (kind == 'u') then
        local entry = parseEntry(parts);

        if (state.staging ~= nil and state.stageCat ~= nil) then
            state.staging[#state.staging].entries:append(entry);
        else
            -- An edit's refresh: replace the row in place, wherever the
            -- cache holds it.
            replaceRow(entry);
            touchModel();
        end

        return;
    end

    if (kind == 'r') then
        local done = tonumber(parts[2]) or 0;
        local why  = parts[4];

        state.pending = nil;

        if (why ~= nil and why ~= '') then
            setStatus((done > 0 and 'Stopped early: ' or 'Refused: ') .. why, done == 0 and 'bad' or 'note');
        else
            -- Named for the verb its own envelope opened with: a jpraise
            -- spends job points, not merit points, and saying "assigned"
            -- over both was the same sentence for two different currencies
            -- (1.2.0). A zero with no reason is not a success either --
            -- the door always sends one, so a silent zero is a server this
            -- window does not understand, and it is not painted green.
            local noun = 'merit point(s) assigned.';

            if (state.inbound == 'lower') then
                noun = 'merit point(s) refunded.';
            elseif (state.inbound == 'jpraise') then
                noun = 'job point(s) spent.';
            end

            setStatus(string.format('%d %s', done, noun), done == 0 and 'bad' or 'ok');
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWIDATA is
* ours: consumed and blocked before parsing, so a malformed record cannot
* leak as chat noise.
--]]
ashita.events.register('packet_in', 'dwmerits_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwmerits'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

--[[
* The fixed tooltips, as a table so the harness can hold them (dwquest's
* BADGE_TIPS shape). Everything whose text depends on the row it is over --
* why a button is greyed, what a bar's numbers mean for THIS category -- is
* built at its call site instead; a tip that lies about the control under the
* cursor is worse than none.
--]]
local TIPS =
{
    refresh   = 'Ask the server again for everything this window is holding: the wallet, and whichever tabs you have already opened. A tab you have not opened asks for itself when you do.',
    wallet    = 'Merit points you hold, against the ceiling your Limit Point bar fills into. The Max Merit entry, under HP / MP, raises the second number.',
    mogOpen   = 'You are in a Mog House, so raise and lower are live. The server checks this again for every click -- these buttons are a courtesy, never the authority.',
    mogClosed = 'Reading the sheet works anywhere; ASSIGNING asks for your Mog House, exactly as the stock merit menu does. Nothing here can lift that -- the gate is the server\'s.',
    applying  = 'One edit is in flight. Merit points are spent, so a click is never collapsed, never stacked and never retried: the buttons come back when the server answers, or after five seconds.',

    tabOverview  = 'The six shared categories at a glance, against THIS server\'s true Combo Totals -- not the maximums the stock menu bakes in.',
    tabAssign    = 'Every entry of one slice, with its real ceiling, its next cost and the buttons that reach past the stock menu\'s caps.',
    tabJobPoints = 'Any job\'s job points, capacity points and gift ladder, with raise buttons through the client\'s own chain.',
    tabAscension = 'The limit point bank: every limit point you ever earned, banked beside the retail bar, spendable on merit points or on permanent Mastery tiers.',

    pick    = 'Which slice of the sheet to list. The six shared categories, then each job\'s two merit groups -- one response carries both. Rows arrive when you pick, never all 296 at once.',
    find    = 'Narrows the rows already on screen by name. Nothing is asked of the server for it.',
    room    = 'Hide entries that are already at their ceiling, so what is left is what you can still spend on.',
    copy    = 'Copy what this tab is showing to the clipboard, as plain text.',

    jobPick  = 'Whose job points to read. ANY job, not only the one you are on: a squad member is paid YOUR job points judged at THEIR job, so a summoner\'s sheet is worth reading for every job they call.',
    jpHeader = 'Job points to spend, capacity points towards the next one, and the running total spent on this job -- the third number is what unlocks the gift ladder below.',
    gifts    = 'Gifts are free: each rung lands the moment your total SPENT on this job passes its cost. Green rungs are yours already.',

    banked   = 'Limit points held in the bank. Everything you earn past a full merit wallet lands here instead of being lost, and the retail limit bar is untouched by it.',
    convert  = 'Buy merit points out of the bank. Nothing is lost to rounding: what the bank cannot pay for stays banked.',
    mastery  = 'Mastery tiers are permanent, and they reach your whole squad: a member you call is spawned with your stat lines folded in and your mod lines applied (trustutils ApplyTrustMastery). Nothing here is judged at their job -- it is a flat carry of yours.',
};

-- The status line's three voices. `note` is the one 1.2.0 added: an m| record
-- is the server saying something that is neither a confirmation nor a refusal
-- ("No job point types exist for that job on this server"), and it used to be
-- painted in the confirmation green.
local STATUS_COLOURS =
{
    ok   = theme.colors.ok,
    bad  = theme.colors.err,
    note = theme.colors.info,
};

--[[
* Hover the last item drawn and say one sentence about it.
*
* FOR CONSTANT TEXT ONLY. A tip whose sentence has to be BUILT -- the reason a
* button is grey, a price, a rung's remaining cost -- is written as an
* explicit `if (imgui.IsItemHovered()) then ... end` at its call site, so the
* string.format happens on the frame the cursor is over it and not on all
* sixty of every second for all twenty-six rows.
--]]
local function tip(text)
    if (text ~= nil and text ~= '' and imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* A width in pixels for a column that has to hold a known string. Ashita's
* CalcTextSize is a binding call and an older client may not carry it, so the
* fallback is the number this file used before it asked (dwcpx's shape).
*
* MEASURED ONCE PER STRING. The samples are literals and the font does not
* change under a running addon, so a cache turns three binding calls per table
* per frame into three for the session.
--]]
local widthCache = { };

local function textWidth(sample, fallback)
    local cached = widthCache[sample];

    if (cached ~= nil) then
        return cached;
    end

    local value = fallback;

    if (type(imgui.CalcTextSize) == 'function') then
        local ok, width = pcall(imgui.CalcTextSize, sample);

        if (ok and type(width) == 'number' and width > 0) then
            value = width;
        end
    end

    widthCache[sample] = value;

    return value;
end

--[[
* THE ADJUST COLUMN'S WIDTH, measured rather than guessed (1.2.0). It was a
* flat 96, and four of those pixels are the table's own cell padding: the row
* is 22 + 30 + 22 + 30 of button and three 8-pixel gaps, so +5 was clipped by
* two pixels even before -5 joined it. The same arithmetic sizes the Buy
* column on the Ascension tab, which clipped its own 44-pixel button inside 50.
--]]
local BTN_NARROW  = 22;
local BTN_WIDE    = 30;
local BTN_BUY     = 44;
local ADJUST_WIDE = (BTN_NARROW * 2) + (BTN_WIDE * 2) + (8 * 3) + 8;

--[[
* The sizes handed to ImGui, built once. An ImGui size argument is read and
* converted on the call and never retained, so these are safe to share -- and
* a `{ 22, 0 }` written inline is one table allocation per button per row per
* frame, which on a twenty-six row job group at sixty frames a second is six
* thousand throwaway tables a second for four buttons that never move.
--]]
local SZ_NARROW = { BTN_NARROW, 0 };
local SZ_WIDE   = { BTN_WIDE, 0 };
local SZ_BUY    = { BTN_BUY, 0 };
local SZ_BAR    = { -1, 16 };
local SZ_TABLE  = { -1, 0 };
local SZ_FILL   = { -1, -1 };
local SZ_WINDOW = { 560, 520 };
local SZ_MIN    = { 470, 300 };
local SZ_MAX    = { 99999, 99999 };

-- Latched if this Ashita's SetNextWindowSizeConstraints refuses the two-
-- argument spelling; see the call site.
local constraintsBroken = false;

local function canEdit()
    return state.wallet ~= nil and state.wallet.mog and state.pending == nil;
end

-- One category's header bar: label, total against the TRUE maximum. Both the
-- fraction and the caption are built when the c| record lands.
local function categoryBar(cat)
    local info = state.cats[cat];

    if (info == nil) then
        return;
    end

    imgui.ProgressBar(info.fraction, SZ_BAR, info.barText);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(string.format(
            '%s: %d of a Combo Total of %d spent.\nThis is the server\'s maximum. The stock merit menu shows retail\'s and refuses clicks past it.',
            info.label, info.total, info.max));
    end
end

--[[
* CAN this row be raised or lowered -- the cheap test, run for every row of
* every frame. Booleans only: the SENTENCE saying why not is built by
* raiseReason/lowerReason below, and only on the frame the cursor is over the
* button that needs it.
--]]
local function canRaiseRow(row, info)
    return state.wallet ~= nil
        and state.wallet.mog
        and state.pending == nil
        and not row.retired
        and row.count < row.ceiling
        and row.next > 0
        and state.wallet.points >= row.next
        and (info == nil or info.total < info.max);
end

local function canLowerRow(row)
    return state.wallet ~= nil
        and state.wallet.mog
        and state.pending == nil
        and row.count > 0;
end

--[[
* WHY A BUTTON IS GREY, in the window's own words. A greyed control with no
* reason is the one thing this sheet cannot afford: the whole point of it is
* that the stock menu refuses clicks and never says why. Every fact tested
* here is one the SERVER re-checks -- these sentences explain the courtesy,
* they do not make the rule. Called on hover only.
--]]
local function raiseReason(row, info)
    if (state.wallet == nil) then
        return 'Waiting for the wallet. Press Refresh if this does not clear.';
    end

    if (state.pending ~= nil) then
        return TIPS.applying;
    end

    if (not state.wallet.mog) then
        return TIPS.mogClosed;
    end

    if (row.retired) then
        return 'Retired: retail moved this spell onto a scroll and the merit teaches nothing here. Lower it for the refund -- the Scroll is on the Conquest Exchange.';
    end

    if (row.count >= row.ceiling) then
        return string.format('This entry is full at %d.', row.ceiling);
    end

    if (row.next <= 0) then
        return 'The server sends no next cost for this entry, so there is nothing to buy.';
    end

    if (info ~= nil and info.total >= info.max) then
        return string.format('%s is full at %d / %d. Lower something in this category to make room.', info.label, info.total, info.max);
    end

    if (state.wallet.points < row.next) then
        return string.format('The next step costs %d and you hold %d.', row.next, state.wallet.points);
    end

    return string.format('Buy one step for %d merit point(s).', row.next);
end

local function lowerReason(row)
    if (state.wallet == nil) then
        return 'Waiting for the wallet. Press Refresh if this does not clear.';
    end

    if (state.pending ~= nil) then
        return TIPS.applying;
    end

    if (not state.wallet.mog) then
        return TIPS.mogClosed;
    end

    if (row.count <= 0) then
        return 'Nothing is spent here, so there is nothing to give back.';
    end

    return 'Give one step back. Merit points are refunded at what the step cost.';
end

-- The -/-5/+/+5 buttons for one row. Greys itself on every fact already on
-- hand; the server re-checks all of them anyway.
local function editButtons(row, cat)
    local info     = state.cats[cat];
    local canRaise = canRaiseRow(row, info);
    local canLower = canLowerRow(row);

    if (not canLower) then imgui.BeginDisabled(); end

    if (imgui.Button(row.lowerId, SZ_NARROW)) then
        sendEdit('lower', row.id, 1);
    end

    if (not canLower) then imgui.EndDisabled(); end

    -- Hovered OUTSIDE the disabled block on purpose: ImGui does not report a
    -- hover over a disabled item, and "why is this grey" is exactly the
    -- question a greyed button has to answer.
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(lowerReason(row));
    end

    imgui.SameLine();

    if (not canLower) then imgui.BeginDisabled(); end

    if (imgui.Button(row.lower5Id, SZ_WIDE)) then
        sendEdit('lower', row.id, 5);
    end

    if (not canLower) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(canLower
            and 'Give five steps back in one commit. Fewer than five left in the entry refunds what is there and says so.'
            or lowerReason(row));
    end

    imgui.SameLine();

    if (not canRaise) then imgui.BeginDisabled(); end

    if (imgui.Button(row.raiseId, SZ_NARROW)) then
        sendEdit('raise', row.id, 1);
    end

    if (not canRaise) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(raiseReason(row, info));
    end

    imgui.SameLine();

    if (not canRaise) then imgui.BeginDisabled(); end

    if (imgui.Button(row.raise5Id, SZ_WIDE)) then
        sendEdit('raise', row.id, 5);
    end

    if (not canRaise) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(canRaise
            and 'Buy five steps in one commit. The server stops at the ceiling, at the category total or when the wallet runs out, and says where it stopped.'
            or raiseReason(row, info));
    end
end

local function entryRow(row, cat)
    imgui.TableNextRow();
    imgui.TableNextColumn();
    imgui.Text(row.name);

    if (imgui.IsItemHovered()) then
        if (row.retired) then
            imgui.SetTooltip(string.format(
                'Retired (merit id %d). Retail moved this spell onto a scroll, so the merit teaches nothing on this server -- it rides the sheet only because points are still in it. Lower it for the full refund.',
                row.id));
        elseif (row.value > 0) then
            imgui.SetTooltip(string.format('+%d per upgrade (merit id %d)', row.value, row.id));
        else
            imgui.SetTooltip(string.format('Merit id %d.', row.id));
        end
    end

    imgui.TableNextColumn();

    if (row.count >= row.ceiling) then
        imgui.TextColored(theme.colors.ok, row.taken);
    else
        imgui.Text(row.taken);
    end

    tip('Steps bought, against this entry\'s own ceiling. Green is full.');

    imgui.TableNextColumn();

    if (row.cost ~= nil) then
        imgui.Text(row.cost);
        tip('Merit points the NEXT step costs. Steps get dearer as the entry fills.');
    else
        imgui.TextDisabled('--');
        tip(row.retired
            and 'No next cost: this merit is retired and buys nothing.'
            or 'No next cost: this entry is at its ceiling.');
    end

    imgui.TableNextColumn();
    editButtons(row, cat);
end

--[[
* The Assign tab's view: the loaded slice, narrowed by the find box and the
* room filter. CACHED on the model revision and the two controls' values, so
* the lowercasing and the scan happen when one of them changes rather than
* sixty times a second over twenty-six rows.
--]]
local function sheetView(pick)
    local blocks = state.rows[pick.token];

    if (blocks == nil) then
        return nil;
    end

    local needle = state.find[1] or '';
    local room   = state.onlyRoom[1] == true;

    if (state.view ~= nil and state.viewRev == state.modelRev
            and state.viewToken == pick.token
            and state.viewFind == needle
            and state.viewRoom == room) then
        return state.view;
    end

    state.viewToken = pick.token;
    state.viewRev   = state.modelRev;
    state.viewFind  = needle;
    state.viewRoom  = room;

    if (needle == '' and not room) then
        state.view = { blocks = blocks, hidden = 0 };

        return state.view;
    end

    -- Trimmed HERE and not in the key, so the trim runs on a cache miss
    -- rather than on every frame: a leading space is a typo, not a filter,
    -- and it would otherwise match nothing at all.
    local lowered = needle:lower():match('^%s*(.-)%s*$') or '';
    local kept    = T{ };
    local hidden  = 0;

    for _, block in ipairs(blocks) do
        local entries = T{ };

        for _, row in ipairs(block.entries) do
            local show = true;

            if (room and row.count >= row.ceiling) then
                show = false;
            end

            if (show and lowered ~= '' and row.search:find(lowered, 1, true) == nil) then
                show = false;
            end

            if (show) then
                entries:append(row);
            else
                hidden = hidden + 1;
            end
        end

        if (#entries > 0) then
            kept:append({ cat = block.cat, entries = entries, tableId = block.tableId });
        end
    end

    state.view = {
        blocks = kept,
        hidden = hidden,
        -- Built with the view, not on every frame the filter stays on.
        hiddenText = hidden > 0 and string.format('%d row(s) hidden.', hidden) or nil,
        emptyText  = string.format('Nothing in this category matches -- %d row(s) hidden by the find box or the room filter.', hidden),
    };

    return state.view;
end

-- What to say where the rows have not arrived. Never "Fetching..." over a
-- read that ran out of tries (1.2.0).
local function waitingLine(verb, subject)
    if (doorIsOld) then
        return 'This server\'s merit door does not carry ' .. subject .. '.';
    end

    if (gaveUpOn(verb)) then
        return 'No answer for ' .. subject .. '. Press Refresh to ask again.';
    end

    return 'Fetching ' .. subject .. ' from the server...';
end

local function sheetTable(pick)
    local view = sheetView(pick);

    if (view == nil) then
        imgui.TextDisabled(waitingLine(fetchVerbFor(pick), 'this category'));

        -- The tab arms its own read (1.2.0): a slice that was never asked
        -- for, or whose read gave up before Refresh reset the latch, is
        -- asked here rather than only at the doorway.
        if (state.fetching ~= pick.token and not serverSilent and not protocolBad) then
            requestPick();
        end

        return;
    end

    local blocks = view.blocks;

    if (#blocks == 0) then
        imgui.TextDisabled(view.emptyText);

        return;
    end

    for _, block in ipairs(blocks) do
        categoryBar(block.cat);

        if (imgui.BeginTable(block.tableId, 4,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), SZ_TABLE)) then
            imgui.TableSetupColumn('Merit', ImGuiTableColumnFlags_WidthStretch, 0, 0);
            imgui.TableSetupColumn('Taken', ImGuiTableColumnFlags_WidthFixed, textWidth('Taken   ', 70), 0);
            imgui.TableSetupColumn('Next costs', ImGuiTableColumnFlags_WidthFixed, textWidth('Next costs   ', 92), 0);
            imgui.TableSetupColumn('Adjust', ImGuiTableColumnFlags_WidthFixed, ADJUST_WIDE, 0);
            imgui.TableHeadersRow();

            for _, row in ipairs(block.entries) do
                entryRow(row, block.cat);
            end

            imgui.EndTable();
        end

        imgui.Spacing();
    end

    if (view.hiddenText ~= nil) then
        imgui.TextDisabled(view.hiddenText);
        tip('The find box or the room filter is narrowing this list. Clear the box and untick Room left to see everything.');
    end
end

-- The six shared categories as one glance: bars only, from the sync. The
-- order is built when a c| record lands (rebuildBars), not searched for here.
local function overviewBars()
    for _, cat in ipairs(state.bars) do
        categoryBar(cat);
    end
end

--[[
* Copy what a tab shows, as plain text. Built only on the click -- the whole
* point of a clipboard button is that it costs nothing until it is pressed.
--]]
local function copyText(text)
    if (type(imgui.SetClipboardText) ~= 'function') then
        setStatus('This Ashita build carries no clipboard binding.', 'bad');

        return;
    end

    local ok = pcall(imgui.SetClipboardText, text);

    setStatus(ok and 'Copied to the clipboard.' or 'The clipboard refused that.', ok and 'ok' or 'bad');
end

local function overviewText()
    local lines = T{ };

    if (state.wallet ~= nil) then
        lines:append(state.wallet.text);
    end

    for _, cat in ipairs(state.bars) do
        local info = state.cats[cat];

        if (info ~= nil) then
            lines:append(string.format('%s: %d / %d', info.label, info.total, info.max));
        end
    end

    return table.concat(lines, '\n');
end

-- Copies WHAT IS ON SCREEN, filter and all: a Copy button beside a find box
-- that copied the unfiltered list would be copying a different list from the
-- one the player is looking at.
local function sliceText(pick, blocks)
    local lines = T{ };

    lines:append(pick.label);

    if (blocks ~= nil) then
        for _, block in ipairs(blocks) do
            local info = state.cats[block.cat];

            if (info ~= nil) then
                lines:append(string.format('%s: %d / %d', info.label, info.total, info.max));
            end

            for _, row in ipairs(block.entries) do
                lines:append(string.format('  %s: %d / %d%s', row.name, row.count, row.ceiling,
                    row.cost ~= nil and (' (next costs ' .. row.cost .. ')') or ''));
            end
        end
    end

    return table.concat(lines, '\n');
end

--[[
* Job Points tab: pick a job, read its points, raise a type. The raise button
* greys on every fact on hand (ceiling, points to spend, Mog House, one edit in
* flight); the server re-checks all of them through the 0x0bf chain.
--]]
local function jobPointsTab()
    imgui.SetNextItemWidth(120);

    local slot    = state.jobPick[1];
    local current = JOBS[slot] or JOBS[1];
    local token   = JOB_TOKENS[slot] or JOB_TOKENS[1];

    if (imgui.BeginCombo('##dwmerits_jobpick', current)) then
        for i, job in ipairs(JOBS) do
            if (imgui.Selectable(JOB_PICK_IDS[i], state.jobPick[1] == i)) then
                if (state.jobPick[1] ~= i) then
                    state.jobPick[1] = i;
                    config.jobToken  = job;

                    saveConfig();
                    requestJob();
                end
            end
        end

        imgui.EndCombo();
    end

    tip(TIPS.jobPick);

    imgui.SameLine();
    -- Short enough to survive beside a 120-wide combo at the window's own
    -- minimum width; the sentence it used to carry is the combo's tooltip
    -- (1.2.0 -- at 560 the old line ran off the right edge, and the window
    -- passes NoScrollbar, so what runs off is simply gone).
    imgui.TextDisabled('Any job, not only the one you are on.');
    tip(TIPS.jobPick);

    imgui.Separator();

    if (state.jp.header == nil or state.jp.token ~= token) then
        if (state.jpEmpty == token) then
            imgui.TextDisabled('This server lists no job point types for ' .. current .. '. Press Refresh to ask again.');

            return;
        end

        imgui.TextDisabled(waitingLine('jp ' .. token, current .. '\'s job points'));

        if (state.jp.token ~= token and state.jpFetching ~= token
                and not serverSilent and not doorIsOld and not protocolBad) then
            requestJob();
        end

        return;
    end

    local header = state.jp.header;

    imgui.Text(header.headerText);
    tip(TIPS.jpHeader);

    if (not imgui.BeginChild('##dwmerits_jp', SZ_FILL, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (imgui.BeginTable('##dwmerits_jptable', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), SZ_TABLE)) then
        -- Measured, like the Assign tab's: a hard pixel width is a width for
        -- one font size, and Ashita's is the player's to change.
        imgui.TableSetupColumn('Job point', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Level', ImGuiTableColumnFlags_WidthFixed, textWidth('Level   ', 60), 0);
        imgui.TableSetupColumn('Next costs', ImGuiTableColumnFlags_WidthFixed, textWidth('Next costs   ', 92), 0);
        -- Wide enough for the button OR its own header, whichever is bigger:
        -- a fixed column narrower than its label clips the label.
        imgui.TableSetupColumn('Raise', ImGuiTableColumnFlags_WidthFixed,
            math.max(BTN_NARROW + 8, textWidth('Raise   ', 60)), 0);
        imgui.TableHeadersRow();

        for _, row in ipairs(state.jp.types) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row.name);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip((jpcatalog and jpcatalog.byId[row.id]) or 'No description for this job point type yet.');
            end

            imgui.TableNextColumn();

            if (row.level >= row.max) then
                imgui.TextColored(theme.colors.ok, row.levelText);
            else
                imgui.Text(row.levelText);
            end

            -- The ceiling rides the wire (k| max), so the sentence quotes the
            -- record rather than a number this renderer decided on.
            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Levels bought in this type, against its ceiling of %d. Green is full.', row.max));
            end

            imgui.TableNextColumn();

            if (row.costText ~= nil) then
                imgui.Text(row.costText);
                tip('Job points the next level costs. The price is the level you are buying -- level 1 costs 1, level 20 costs 20.');
            else
                imgui.TextDisabled('--');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('No next cost: this type is at its ceiling of %d.', row.max));
                end
            end

            imgui.TableNextColumn();

            local canRaise = canEdit() and row.level < row.max and row.next > 0 and header.jp >= row.next;

            if (not canRaise) then imgui.BeginDisabled(); end

            if (imgui.Button(row.raiseId, SZ_NARROW)) then
                sendEdit('jpraise', row.id, 1);
            end

            if (not canRaise) then imgui.EndDisabled(); end

            -- The greyed reason, in the tab's own words, built on hover only.
            -- The Job Breaker key item is the one condition this window cannot
            -- see -- it lives in the 0x0c0 validator the door holds -- so the
            -- sentence names it rather than pretending the list is complete.
            if (imgui.IsItemHovered()) then
                local reason;

                if (state.wallet == nil) then
                    reason = 'Waiting for the wallet. Press Refresh if this does not clear.';
                elseif (state.pending ~= nil) then
                    reason = TIPS.applying;
                elseif (not state.wallet.mog) then
                    reason = 'Job points are spent in a Mog House, exactly as the client\'s own job point menu asks. Reading works anywhere.';
                elseif (row.level >= row.max) then
                    reason = string.format('This type is full at %d.', row.max);
                elseif (row.next <= 0) then
                    reason = 'The server sends no next cost for this type.';
                elseif (header.jp < row.next) then
                    reason = string.format('The next level costs %d job points and this job holds %d.', row.next, header.jp);
                else
                    reason = string.format('Buy one level for %d job points. Refused without the Job Breaker key item, which the client\'s own menu wants too.', row.next);
                end

                imgui.SetTooltip(reason);
            end
        end

        imgui.EndTable();
    end

    if (state.jp.giftsText ~= nil) then
        imgui.Spacing();
        imgui.TextDisabled(state.jp.giftsText);
        tip(TIPS.gifts);

        for _, gift in ipairs(state.jp.gifts) do
            local unlocked = header.spent >= gift.jp;

            if (unlocked) then
                imgui.TextColored(theme.colors.ok, gift.line);
            else
                imgui.TextDisabled(gift.line);
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(unlocked
                    and string.format('Yours: %d job points spent on this job, and this rung wanted %d.', header.spent, gift.jp)
                    or string.format('Locked: %d more job points spent on this job unlocks it. Gifts cost nothing of their own.', gift.jp - header.spent));
            end
        end
    end

    imgui.EndChild();
end

-- Why the three convert buttons are grey, built on hover only. A module
-- function rather than a closure inside the tab: the tab runs every frame and
-- the closure was one allocation per frame for a sentence almost nobody was
-- reading.
local function convertReason(wallet, bank)
    if (state.pending ~= nil) then
        return TIPS.applying;
    end

    if (wallet == nil) then
        return 'Waiting for the wallet. Press Refresh if this does not clear.';
    end

    if (wallet.points >= wallet.ceiling) then
        return string.format('Your merit wallet is full at %d. Spend some on the Assign tab first -- the bank keeps what it holds.', wallet.ceiling);
    end

    return string.format('A merit point costs %d banked limit points and the bank holds %d.', bank.perMerit, bank.banked);
end

--[[
* Ascension tab: the bank, the merit conversion, the mastery sheet. Every
* number is the store's; the Buy button greys when the store would refuse.
--]]
local function ascensionTab()
    if (state.bank == nil) then
        imgui.TextDisabled(waitingLine('mastery', 'the limit point bank'));

        -- The tab arms its own read (1.2.0). Before that, the bank was
        -- fetched at the doorway whether or not anyone opened this tab --
        -- and if that one read was lost, the tab said "Fetching the bank
        -- from the server..." for the rest of the session.
        if (not state.bankAsked and not serverSilent and not doorIsOld and not protocolBad) then
            requestMastery();
        end

        return;
    end

    local bank = state.bank;

    imgui.Text(bank.bankedText);
    tip(TIPS.banked);

    imgui.PushTextWrapPos(0);
    imgui.TextDisabled(bank.ledgerText);
    imgui.PopTextWrapPos();
    tip('Lifetime is every limit point you have ever earned; spent is what has gone back out as merit points or Mastery tiers.');

    imgui.Separator();
    imgui.Text(bank.rateText);
    tip(TIPS.convert);

    -- THE THREE BUTTONS GET THEIR OWN LINE (1.2.0). They used to follow the
    -- rate sentence on a SameLine, and that row measured about 544 pixels
    -- against a 560-wide window with NoScrollbar -- so "Fill wallet" sat on
    -- the frame's edge at the default size and off it at anything narrower.
    local wallet     = state.wallet;
    local canConvert = state.pending == nil and wallet ~= nil
        and wallet.points < wallet.ceiling and bank.banked >= bank.perMerit;

    if (not canConvert) then imgui.BeginDisabled(); end

    if (imgui.Button('Buy 1 merit##dwmerits_conv1')) then
        sendBankAction('convert 1');
    end

    if (not canConvert) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(canConvert
            and string.format('Spend %d banked limit points on one merit point.', bank.perMerit)
            or convertReason(wallet, bank));
    end

    imgui.SameLine();

    if (not canConvert) then imgui.BeginDisabled(); end

    if (imgui.Button('Buy 5##dwmerits_conv5')) then
        sendBankAction('convert 5');
    end

    if (not canConvert) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(canConvert
            and string.format('Spend up to %d banked limit points on five merit points, in one commit. The server stops early at a full wallet or an empty bank and says where.', bank.perMerit * 5)
            or convertReason(wallet, bank));
    end

    imgui.SameLine();

    if (not canConvert) then imgui.BeginDisabled(); end

    if (imgui.Button('Fill wallet##dwmerits_convall')) then
        sendBankAction('convert 127');
    end

    if (not canConvert) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(canConvert
            and 'Buy merit points until the wallet is full or the bank cannot pay for another. Nothing is lost to rounding -- what the bank cannot spend stays banked.'
            or convertReason(wallet, bank));
    end

    imgui.Separator();
    imgui.PushTextWrapPos(0);
    imgui.TextDisabled('Mastery -- permanent, and every squad member you call is paid your tiers:');
    imgui.PopTextWrapPos();
    tip(TIPS.mastery);

    if (#state.sheet == 0) then
        imgui.TextDisabled(state.sheetSeen
            and 'This server\'s Ascension store lists no mastery tiers. The bank above still buys merit points.'
            or waitingLine('mastery', 'the mastery sheet'));

        return;
    end

    if (not imgui.BeginChild('##dwmerits_mastery', SZ_FILL, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (imgui.BeginTable('##dwmerits_masterytable', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), SZ_TABLE)) then
        imgui.TableSetupColumn('Line', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Tier', ImGuiTableColumnFlags_WidthFixed, textWidth('Tier   ', 60), 0);
        imgui.TableSetupColumn('Next tier costs', ImGuiTableColumnFlags_WidthFixed, textWidth('Next tier costs   ', 110), 0);
        -- 50 held a 44-pixel button and four pixels of cell padding a side,
        -- so the Buy button was clipped by two (1.2.0).
        imgui.TableSetupColumn('Buy', ImGuiTableColumnFlags_WidthFixed, BTN_BUY + 8, 0);
        imgui.TableHeadersRow();

        for _, row in ipairs(state.sheet) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row.name);
            -- Both halves of the cell carry the tip: ImGui hovers the LAST
            -- item drawn, so a tip written once after the description was a
            -- tip the line's own name never had.
            tip(TIPS.mastery);
            imgui.TextDisabled(row.desc);
            tip(TIPS.mastery);

            imgui.TableNextColumn();

            if (row.tier >= row.max) then
                imgui.TextColored(theme.colors.ok, row.tierText);
            else
                imgui.Text(row.tierText);
            end

            tip('Tiers bought, against this line\'s ceiling. Green is complete.');

            imgui.TableNextColumn();

            if (row.priceText ~= nil) then
                imgui.Text(row.priceText);
                tip('Banked limit points the NEXT tier costs. Each tier is dearer than the last.');
            else
                imgui.TextDisabled('complete');
                tip('Every tier of this line is bought.');
            end

            imgui.TableNextColumn();

            local canBuy = state.pending == nil and row.price > 0 and bank.banked >= row.price;

            if (not canBuy) then imgui.BeginDisabled(); end

            if (imgui.Button(row.buyId, SZ_BUY)) then
                sendBankAction('ascend ' .. row.key);
            end

            if (not canBuy) then imgui.EndDisabled(); end

            if (imgui.IsItemHovered()) then
                local why;

                if (state.pending ~= nil) then
                    why = TIPS.applying;
                elseif (row.price <= 0) then
                    why = string.format('%s is already complete at tier %d.', row.name, row.max);
                elseif (bank.banked < row.price) then
                    why = string.format('Tier %d costs %d limit points and the bank holds %d.', row.tier + 1, row.price, bank.banked);
                else
                    why = string.format('Buy tier %d of %s for %d banked limit points.', row.tier + 1, row.name, row.price);
                end

                imgui.SetTooltip(why);
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

--[[
* Refresh: re-ask everything ALREADY ON SCREEN. It used to ask for all four
* reads whatever the player had opened; now the two younger tabs are re-asked
* only if they hold data, and armed by their own render if they do not
* (1.2.0). forget() drops the per-tab latches with the outstanding asks, so a
* tab whose read gave up is asked again by this one click.
--]]
local function refreshAll()
    serverSilent = false;
    doorIsOld    = false;
    protocolBad  = false;

    local hadJob     = state.jp.header ~= nil;
    local hadMastery = state.bank ~= nil;
    local hadRows    = state.rows[currentPick().token] ~= nil;

    forget();
    requestSync();

    -- Only what is HELD is re-asked. A slice, a job or a bank that was never
    -- fetched is not stale, it is absent -- and its own tab arms the read on
    -- the frame it is drawn, so asking here would be the same line twice.
    if (hadRows) then
        requestPick();
    end

    if (hadMastery) then
        requestMastery();
    end

    if (hadJob) then
        requestJob();
    end
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        refreshAll();
    end

    if (imgui.IsItemHovered()) then
        if (state.syncedAt ~= nil) then
            imgui.SetTooltip(string.format('%s\nLast answer %d second(s) ago.', TIPS.refresh, os.time() - state.syncedAt));
        else
            imgui.SetTooltip(TIPS.refresh);
        end
    end

    imgui.SameLine();
    imgui.Text(state.wallet ~= nil and state.wallet.text or 'Merit points: ?');
    tip(TIPS.wallet);
    imgui.SameLine();

    if (state.wallet ~= nil and state.wallet.mog) then
        imgui.TextColored(theme.colors.ok, '[Mog House: assignment open]');
        tip(TIPS.mogOpen);
    else
        imgui.TextDisabled('[Enter your Mog House to assign]');
        tip(TIPS.mogClosed);
    end

    if (state.pending ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled('applying...');
        tip(TIPS.applying);
    end

    if (state.status ~= nil and state.status ~= '') then
        -- WRAPPED (1.2.0). The window passes NoScrollbar and the server's own
        -- sentences run past 120 characters -- the convert receipt names the
        -- points, the wallet, the bank and the retail bar -- so an unwrapped
        -- status line simply lost its second half off the right edge.
        imgui.PushTextWrapPos(0);

        imgui.TextColored(STATUS_COLOURS[state.statusTone] or theme.colors.ok, state.status);

        imgui.PopTextWrapPos();
    end

    imgui.Separator();

    if (imgui.BeginTabBar('##dwmerits_tabs')) then
        if (imgui.BeginTabItem('Overview')) then
            tip(TIPS.tabOverview);

            if (next(state.cats) == nil) then
                imgui.TextDisabled(waitingLine('sync', 'the merit sheet'));

                -- The fourth self-arm, for the fourth tab (1.2.0). The
                -- doorway asks for the wallet, but a character switch wipes
                -- the six bars inside whatever envelope carried the new
                -- charid -- and if that was a `cat` answer rather than a
                -- `sync`, nothing else would ever ask for them again.
                if (not state.syncAsked and not serverSilent and not protocolBad) then
                    requestSync();
                end
            else
                imgui.TextDisabled('The six shared categories, against this server\'s true totals:');
                overviewBars();
                imgui.Spacing();

                if (imgui.Button('Copy##dwmerits_copyoverview')) then
                    copyText(overviewText());
                end

                tip(TIPS.copy);
                imgui.SameLine();
                imgui.TextDisabled('The Assign tab lists every entry -- pick a category or a job\'s groups.');
            end

            imgui.EndTabItem();
        else
            tip(TIPS.tabOverview);
        end

        if (imgui.BeginTabItem('Assign')) then
            tip(TIPS.tabAssign);

            imgui.SetNextItemWidth(220);

            local current = currentPick();

            if (imgui.BeginCombo('##dwmerits_pick', current.label)) then
                for i, pickEntry in ipairs(PICKS) do
                    if (imgui.Selectable(pickEntry.selectId, state.pick[1] == i)) then
                        if (state.pick[1] ~= i) then
                            state.pick[1]    = i;
                            config.pickToken = pickEntry.token;

                            saveConfig();
                            requestPick();
                        end
                    end
                end

                imgui.EndCombo();
            end

            tip(TIPS.pick);

            imgui.SameLine();

            if (imgui.Button('Copy##dwmerits_copyslice')) then
                local view = sheetView(current);

                copyText(sliceText(current, view ~= nil and view.blocks or nil));
            end

            tip(TIPS.copy);

            -- The find box and the room filter, on the row under the combo:
            -- side by side with a 220-wide combo they left no room for the
            -- sentence that used to sit there, and that sentence is the
            -- combo's tooltip now.
            imgui.SetNextItemWidth(180);
            imgui.InputTextWithHint('##dwmerits_find', 'find a merit...', state.find, 48);
            tip(TIPS.find);

            imgui.SameLine();

            if (imgui.Checkbox('Room left##dwmerits_room', state.onlyRoom)) then
                config.onlyRoom = state.onlyRoom[1] == true;

                saveConfig();
            end

            tip(TIPS.room);

            imgui.Separator();

            if (imgui.BeginChild('##dwmerits_sheet', SZ_FILL, ImGuiChildFlags_None)) then
                sheetTable(current);
            end

            imgui.EndChild();
            imgui.EndTabItem();
        else
            tip(TIPS.tabAssign);
        end

        if (imgui.BeginTabItem('Job Points')) then
            tip(TIPS.tabJobPoints);
            jobPointsTab();
            imgui.EndTabItem();
        else
            tip(TIPS.tabJobPoints);
        end

        if (imgui.BeginTabItem('Ascension')) then
            tip(TIPS.tabAscension);
            ascensionTab();
            imgui.EndTabItem();
        else
            tip(TIPS.tabAscension);
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape).
--]]
ashita.events.register('d3d_present', 'dwmerits_present', function ()
    checkAnswers();
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize(SZ_WINDOW, ImGuiCond_FirstUseEver);

    --[[
    * A FLOOR UNDER THE WINDOW (1.2.0). ImGui remembers whatever size the
    * player dragged it to, and there is no size at which this window is
    * still usable once the four tabs no longer fit across the bar: the
    * header strip alone is a Refresh button, the wallet, the Mog House
    * badge and sometimes "applying...", and the Assign tab's own row is a
    * 220-wide combo, a Copy button, a 180-wide find box and a checkbox.
    * 470 is that row plus the window's padding; 300 keeps the tab bar, the
    * status line and a few rows of the sheet on screen at once.
    *
    * PCALL'D AND LATCHED, because no other window in this suite calls it
    * yet and this one is OUTSIDE the render pcall: a player's Ashita is
    * frozen at whatever they installed, and a binding that wants its third
    * (callback) argument would otherwise throw here sixty times a second
    * with no window to close (dwah's tabSelectBroken, same shape). One
    * refusal and the window simply has no minimum, which is 1.1.4.
    --]]
    if (not constraintsBroken) then
        if (not pcall(imgui.SetNextWindowSizeConstraints, SZ_MIN, SZ_MAX)) then
            constraintsBroken = true;
        end
    end

    -- NoDocking: dw windows fused into an unthemed dock once; never again.
    local visible = imgui.Begin('DriftwoodXI Merits##dwmerits', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwmerits'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwmerits'):append(chat.message('Window closed. `!merits` typed by hand says the same numbers.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs: a sheet showing merits as they
* stood before the Mog House visit is the quiet kind of wrong this project
* exists to rule out.
*
* ONLY THE WALLET IS ASKED FOR HERE (1.2.0). It used to be four reads -- the
* wallet, the selected slice, the whole mastery sheet and the played job's
* job points -- 1.2 seconds apart, three of them for tabs the player had not
* clicked. Each tab arms its own read the first time it is drawn, so what
* goes out is what is being looked at; forget() clears the latches, so the
* visible tab asks again on this very frame.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
        serverSilent   = false;
        doorIsOld      = false;
        protocolBad    = false;

        forget();
        requestSync();
    end
end

ashita.events.register('command', 'dwmerits_command', function (e)
    local args  = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwmerits' and first ~= '/merits' and first ~= '/dwi') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        refreshAll();

        return;
    end

    toggleWindow();
end);

--[[
* No zone-in auto-sync, on purpose: unlike fame, merits change only when
* the player changes them, and this window resyncs itself every time it
* opens or edits. What zoning DOES invalidate is the Mog House flag -- so a
* zone line just clears the wallet, and the next open asks fresh.
--]]
ashita.events.register('packet_in', 'dwmerits_zonein', function (e)
    if (e.id == 0x000A) then
        state.wallet  = nil;
        state.pending = nil;

        -- The old-door latch is cleared by the login packet, the way every
        -- unknown-verb latch in this suite is: the server may have been
        -- updated between this login and the last, and a latch that only a
        -- Refresh could lift would outlive the reason for it.
        doorIsOld   = false;
        protocolBad = false;

        forget();

        if (state.open[1] and not serverSilent) then
            -- The wallet and the Mog House flag are what zoning invalidates,
            -- and the slice with them: leaving a Mog House after using the
            -- stock merit menu IS a zone line, so the rows on screen are
            -- exactly the ones most likely to be stale. Only rows that are
            -- HELD are re-asked, because a tab with nothing to show arms its
            -- own read on the frame it is drawn.
            requestSync();

            if (state.rows[currentPick().token] ~= nil) then
                requestPick();
            end
        end
    end
end);

--[[
* Watch what the player sends. Bare `!merits` toggles this window instead
* of going to the server -- the typed verb is a door, not a dead end; any
* `!merits <verb>` line still passes through untouched (that is the escape
* hatch this addon's header promises). Every other outgoing line stamps the
* throttle so a queued query never races something the player typed.
--]]
ashita.events.register('packet_out', 'dwmerits_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!merits' or lower == '!merits ui' or lower == '!merits window' or lower == '!merits gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwi') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwmerits_load', function ()
    print(chat.header('dwmerits'):append(chat.message('/merits or /dwmerits opens the merit sheet -- this server\'s true totals, and assignment past the stock menu\'s caps.')));
end);
