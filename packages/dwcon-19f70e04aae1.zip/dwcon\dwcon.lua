--[[
* DriftwoodXI -- dwcon
*
* Every enemy near you wears its /check answer. A small colored linkpearl bead
* floats beside each mob's name, colored by con difficulty, with its level
* beside it. No more checking a camp one mob at a time to find out which of
* the six identical crabs is the one that kills you.
*
* CON IS SERVER DATA, NOT A CLIENT COMPUTATION. `charutils::CheckMob` walks an
* EXP curve that modules/driftwoodxi/difficulty_curve.lua overrides, so even
* with a mob's level in hand the client cannot reproduce the server's answer.
* And difficulty is PER VIEWER -- it depends on your level, not the mob's --
* so it cannot ride the shared 0x00E entity update either. The server works it
* out and tells this addon, over the per-player `_DWODATA` chat-record channel
* (0x017, blocked here before the chat log ever sees it) that ten other
* Driftwood addons already use.
*
* THE DRIFTWOOD CURVE HAS RETIRED INCREDIBLY EASY PREY (tier 1 is unreachable;
* difficulty_curve.lua sentinels it). Exactly seven tiers occur, plus
* "impossible to gauge" for the mobs the server refuses to gauge at all --
* NMs, Battlefield mobs, CheckAsNm -- which is the same gate the real /check
* applies, so this addon cannot leak a difficulty /check would have withheld.
*
* THE NAMEPLATE RECTANGLE IS NOT EXPOSED TO LUA, so the bead's position is
* re-derived rather than read: the mob's world position is projected through
* the live view and projection matrices (the targetlines worldToScreen
* pattern) with a height offset that puts it where the name floats, and the
* pearl is drawn on `imgui.GetForegroundDrawList()` from `d3d_present`. The
* nameplate's own font colors are untouched -- they still mean NPC / enemy /
* claimed, which is a different question from "can I kill it".
*
* No assets ship with this addon. The pearl is three draw calls: a filled
* circle in the tier color, a rim, and an off-center white specular dot (the
* crosshair precedent).
*
* TURN IT OFF AND NOTHING IS LOST. /check still works, typed, on one mob at a
* time, exactly as it always did. This is faster; it is not required.
--]]

addon.name    = 'dwcon';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.1';
addon.desc    = 'Con pearls: every nearby enemy\'s /check difficulty and level, at a glance.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the `!dwo hello` handshake; installed
-- before any other text_in handler in this file (dwecho.lua). Without it the
-- player reads `Blaster : !dwo hello` in their own log on every zone line.
echo.install();

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load.
*
* This addon is loaded from the launcher's boot script, which runs long before
* the client has a rendering device -- and `d3d.get_device()` at file scope
* makes the whole addon fail to load when it answers nothing (the dwbags
* lesson). Nothing here needs a device until the first pearl is drawn, by
* which point there certainly is one.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; the fourteenth `_DW*DATA` name,
-- and nothing else on the server uses it, so matching it exactly is a safe
-- filter.
local DATA_SENDER = '_DWODATA';

-- Protocol version the server announces in its `d|` record. An unknown one is
-- HARD REFUSED (one warning, then silence) rather than guessed at: a pearl
-- drawn from a record layout this addon does not understand is a lie about how
-- dangerous something is, which is worse than no pearl at all.
local PROTOCOL = 1;

--[[
* The tiers, in EMobDifficulty order.
*
* Tier 1 (Incredibly Easy Prey) is absent ON PURPOSE: the DriftwoodXI
* difficulty curve sentinels it out of reach, so a pearl for it would be a
* legend row no player can ever see. A tier this table does not know is drawn
* as the ungaugeable pearl rather than skipped -- a server that grows an
* eighth tier should be VISIBLE here, not invisible.
*
* Colors are the plan's exact RGB triples. `rim` overrides the default dark
* outline; only Too Weak needs it, because a near-black bead with a black
* outline is a smudge.
--]]
local TIERS = {
    [0] = { short = 'TW', name = 'Too Weak',         r = 45,  g = 45,  b = 45,  rim = { 110, 110, 110 } },
    [2] = { short = 'EP', name = 'Easy Prey',        r = 60,  g = 180, b = 75  },
    [3] = { short = 'DC', name = 'Decent Challenge', r = 240, g = 200, b = 40  },
    [4] = { short = 'EM', name = 'Even Match',       r = 245, g = 130, b = 32  },
    [5] = { short = 'T',  name = 'Tough',            r = 220, g = 50,  b = 47  },
    [6] = { short = 'VT', name = 'Very Tough',       r = 230, g = 60,  b = 230 },
    [7] = { short = 'IT', name = 'Incredibly Tough', r = 120, g = 50,  b = 200 },
};

-- The pearl for a mob the server refuses to gauge (NM / Battlefield /
-- CheckAsNm). Silver, and the level is replaced by a question mark: the server
-- withheld the number, so the addon must not appear to know it.
local UNKNOWN = { short = '??', name = 'Impossible to gauge', r = 200, g = 205, b = 215 };

-- Legend order, and the order the tiers are described in anywhere else.
local TIER_ORDER = { 0, 2, 3, 4, 5, 6, 7 };

--[[
* Drawing constants. Everything a player can move lives in `config`; these are
* proportions of the pearl rather than sizes, so one size slider keeps the bead
* looking like a bead at every setting.
--]]
local SPECULAR_OFFSET = 0.34;   -- of the radius, up and to the left
local SPECULAR_SIZE   = 0.28;   -- of the radius
local RIM_THICKNESS   = 0.18;   -- of the radius, never below 1px
local PEARL_NUDGE     = 2.0;    -- px of air between the bead and the nameplate
local TARGET_SCALE    = 1.40;   -- your current target's bead draws larger
local FADE_START      = 0.55;   -- fraction of the cap where fading begins
local MIN_ALPHA       = 0.30;   -- alpha at the cap itself

--[[
* Persisted presentation state, through Ashita's settings library (the dwport
* shape). Flat scalars only -- the settings serializer takes booleans, numbers
* and strings, and a nested table here would be a silent loss on save.
--]]
local defaultConfig = T{
    pearls      = true,     -- the master switch; /dwcon on|off drives it
    levels      = true,     -- "Lv.34" beside the bead
    tiers       = false,    -- "DC" beside the bead
    nm          = true,     -- draw a bead for mobs the server will not gauge
    pearlSize   = 7.0,      -- radius in pixels at 1.0 scale
    heightUp    = 2.2,      -- world units above the mob's origin
    maxDistance = 30.0,     -- yalms; beyond this nothing is drawn
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

pcall(settings.register, 'settings', 'dwcon_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end
end);

--[[
* ImGui widget holders. Every ImGui input wants a table it can write into, so
* the window edits these and copies back into `config` on the frame the widget
* reports a change. Keeping the two apart is what lets `config` stay flat
* scalars for the serializer.
--]]
local ui = {
    pearls      = T{ config.pearls  ~= false },
    levels      = T{ config.levels  ~= false },
    tiers       = T{ config.tiers   == true  },
    nm          = T{ config.nm      ~= false },
    pearlSize   = T{ config.pearlSize   or 7.0  },
    heightUp    = T{ config.heightUp    or 2.2  },
    maxDistance = T{ config.maxDistance or 30.0 },
};

local function commit()
    config.pearls      = ui.pearls[1];
    config.levels      = ui.levels[1];
    config.tiers       = ui.tiers[1];
    config.nm          = ui.nm[1];
    config.pearlSize   = ui.pearlSize[1];
    config.heightUp    = ui.heightUp[1];
    config.maxDistance = ui.maxDistance[1];

    pcall(settings.save);
end

--[[
* Session state.
*
* `cons` is a PLAIN table keyed by targid -- T{}'s sugar method names would
* collide with nothing here, but pairs() over it is the whole draw loop and a
* plain table keeps that honest.
--]]
local state = {
    cons     = {},          -- [targid] = { gauge = bool, tier = n, level = n }
    inbound  = nil,         -- the verb of the envelope currently open
    synced   = false,       -- a full sync has closed at least once
    refused  = false,       -- an unknown protocol version was seen; stay silent
    warned   = false,       -- a malformed pair has already been reported once
    reported = false,       -- a draw error has already been reported once

    notice    = nil,        -- the last m|/e| sentence, for the config window
    noticeBad = false,

    open     = T{ false },  -- the config window
};

--[[
* Outbound: `!dwo hello`, and nothing else, ever.
*
* One line per 1.2s with duplicate collapse -- the client's chat rate limit
* being what it is, and the zone-in hello racing a login that is still
* settling. `readyAt` holds the queue shut for a moment after a zone line so
* the handshake is not the first thing sent into a half-built zone.
--]]
local SEND_INTERVAL = 1.2;
local ZONE_SETTLE   = 3.0;

local queue   = T{ };
local lastSend = 0;
local readyAt  = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now < readyAt or now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* The handshake. No records are ever sent to a session that has not spoken it
* (the tracker_core ping rule -- a vanilla client never sees a stray record),
* so this is the one line the addon sends blind, exactly as dwtracker's own
* hello is. Re-sent after every zone line because the server's per-char state
* dies with the zone.
--]]
local function hello()
    issue('!dwo hello');
end

--[[
* Record parsing.
*
* Every record is pipe-separated with a single-character kind. Anything this
* addon does not recognise falls off the end of the chain rather than being an
* error: a server newer than the addon must not break it, which is the whole
* reason the `d|` record carries a version at all. Additive record kinds
* therefore never bump PROTOCOL.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* One malformed pair is a warning, not a traceback and not a wall of red. It
* is latched: a server sending one bad pair is sending it every throttle
* period, and sixty lines a second of the same complaint is worse than the bug.
--]]
local function warnBadPair(entry)
    if (state.warned) then
        return;
    end

    state.warned = true;

    print(chat.header('dwcon'):append(chat.warning(
        string.format('ignoring a con record this addon could not read ("%s"). Pearls for other mobs are unaffected.', tostring(entry)))));
end

--[[
* `<targid>:<tier>:<level>` for a gaugeable mob, `<targid>:u` for one the
* server refuses to gauge. Pairs are comma-separated and a `c|` line is packed
* to the wire budget, so one envelope may carry several of these lines; each
* one is merged as it arrives.
--]]
local function applyPairs(packed)
    if (packed == nil or packed == '') then
        return;
    end

    for _, entry in ipairs(split(packed, ',')) do
        if (entry ~= '') then
            local bits   = split(entry, ':');
            local targid = tonumber(bits[1]);

            if (targid == nil) then
                warnBadPair(entry);
            elseif (bits[2] == 'u') then
                state.cons[targid] = { gauge = false };
            else
                local tier  = tonumber(bits[2]);
                local level = tonumber(bits[3]);

                if (tier == nil or level == nil) then
                    warnBadPair(entry);
                else
                    state.cons[targid] = { gauge = true, tier = tier, level = level };
                end
            end
        end
    end
end

local function handleRecord(line)
    -- A refusal is silence. The packets are still blocked (that happens before
    -- this function is reached), so a mismatched server cannot spill records
    -- into the chat log either.
    if (state.refused) then
        return;
    end

    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;
            state.cons    = {};

            print(chat.header('dwcon'):append(chat.error(string.format(
                'server con protocol %d, addon expects %d. Update dwcon through the launcher; no pearls until then.',
                version, PROTOCOL))));

            return;
        end

        state.inbound = parts[3];

        -- A sync replaces the whole table, and the reset runs FIRST: this
        -- function is called under a pcall, and a throw after `inbound` is set
        -- must cost one record rather than leave the old rows in place for the
        -- records behind it to merge into.
        if (state.inbound == 'sync') then
            state.cons = {};
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state, the
    -- way every sibling accepts them. The server DOES emit both ("Con pearls
    -- are not in this build." rides a status envelope; `bye` answers with an
    -- m|) -- and dropped on the floor, with the packet already blocked, the
    -- refusal reached neither the chat log nor the window: the player read
    -- "Waiting for the server's first snapshot..." forever instead.
    if (kind == 'm' or kind == 'e') then
        state.notice    = line:sub(3);
        state.noticeBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwcon'):append(chat.error(state.notice)));
        end

        return;
    end

    -- Records outside an envelope are not ours to act on.
    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        if (state.inbound == 'sync') then
            state.synced = true;
        end

        state.inbound = nil;

        return;
    end

    if (kind == 'c') then
        applyPairs(parts[2]);

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017.
*
* Layout after the 4-byte header: Kind at 0x04, Attr at 0x05, Data at 0x06,
* sName[15] at 0x08, Mes at 0x17. Any line whose sender is _DWODATA is ours.
*
* The addon owns the line WHATEVER happens to be in it, so it is blocked before
* parsing rather than after: a malformed record must not leak into the chat log
* as noise, and a record that throws must not leak either.
--]]
ashita.events.register('packet_in', 'dwcon_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwcon'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* A zone line is a new entity table and a new server-side cache: every targid
* we hold now means a different mob, or nothing. Clear and re-handshake.
*
* The refusal latch is cleared here too. A map restart logs everyone out, so
* the server on the other side of a zone line may well be the updated one.
--]]
ashita.events.register('packet_in', 'dwcon_zonein', function (e)
    if (e.id ~= 0x000A) then
        return;
    end

    state.cons    = {};
    state.inbound = nil;
    state.synced  = false;
    state.refused = false;
    state.warned  = false;
    state.notice  = nil;
    state.noticeBad = false;

    readyAt = os.clock() + ZONE_SETTLE;

    hello();
end);

--[[
* Watch what the player sends, and stamp the throttle from it.
*
* Every sibling with a send queue has this handler and dwcon did not, which
* made it the one addon whose throttle only ever knew about its own sends. The
* client's rate limit is on CHAT, not on any addon, so a hello fired in the
* same beat as a line the player typed is the one the client drops -- and
* dwcon's whole session hangs off that one hello: no reply means no pearls for
* the rest of the zone, with nothing on screen to say why. The zone-in path is
* exactly where this collides, because a player who zones and immediately says
* something is ordinary.
*
* `!dwo` lines are ours and are already stamped by pumpQueue; stamping them
* twice would double the interval on our own traffic.
--]]
ashita.events.register('packet_out', 'dwcon_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower:sub(1, 4) ~= '!dwo') then
        lastSend = os.clock();
    end
end);

--[[
* Colors.
*
* ImGui's ImU32 is packed 0xAABBGGRR (IM_COL32_*_SHIFT in Ashita's imgui.lua).
* This builds it with arithmetic rather than `imgui.col32`, for two reasons:
* that helper takes its arguments in (a, r, g, b) order, which is an easy way
* to ship a blue pearl labelled red; and `bit.lshift(alpha, 24)` answers a
* NEGATIVE 32-bit integer for any alpha over 127, which is a thing to have to
* think about at every call site. Multiplication is unsigned and obvious.
--]]
local function packColor(r, g, b, a)
    return (a * 16777216) + (b * 65536) + (g * 256) + r;
end

local function alphaByte(alpha)
    local value = math.floor(alpha * 255 + 0.5);

    if (value < 0) then
        return 0;
    elseif (value > 255) then
        return 255;
    end

    return value;
end

--[[
* Projection.
*
* v * view * projection, then the perspective divide and the viewport map --
* the targetlines worldToScreen, done one matrix at a time instead of
* pre-multiplying the pair (same answer, sixteen fewer terms to get wrong).
*
* The matrices are D3DMATRIX cdata with _11.._44 fields, and the row-vector
* convention D3D uses puts the transform's column into the sum, which is why
* the x term reads _11/_21/_31/_41 rather than the first row.
*
* Returns nil for anything at or behind the camera plane: w is the view-space
* depth, and dividing by a negative one folds the point back onto the screen
* mirrored, which is how a mob behind you gets a pearl in front of you.
--]]
local function transform(x, y, z, w, m)
    return m._11 * x + m._21 * y + m._31 * z + m._41 * w,
           m._12 * x + m._22 * y + m._32 * z + m._42 * w,
           m._13 * x + m._23 * y + m._33 * z + m._43 * w,
           m._14 * x + m._24 * y + m._34 * z + m._44 * w;
end

local function worldToScreen(wx, wy, wz, view, projection, width, height)
    local vx, vy, vz, vw = transform(wx, wy, wz, 1, view);
    local cx, cy, _, cw  = transform(vx, vy, vz, vw, projection);

    if (cw <= 0.0001) then
        return nil;
    end

    local rhw = 1 / cw;

    return math.floor((cx * rhw + 1) * 0.5 * width),
           math.floor((1 - cy * rhw) * 0.5 * height);
end

--[[
* One bead, on any draw list -- the world's foreground list from d3d_present,
* and the window's own list for the legend, so the legend cannot drift from
* what the game actually draws.
--]]
local function drawPearl(dl, x, y, radius, entry, alpha)
    local a = alphaByte(alpha);

    local rim = entry.rim or { 0, 0, 0 };

    dl:AddCircleFilled({ x, y }, radius, packColor(entry.r, entry.g, entry.b, a), 16);
    dl:AddCircle({ x, y }, radius, packColor(rim[1], rim[2], rim[3], alphaByte(alpha * 0.85)),
        16, math.max(1.0, radius * RIM_THICKNESS));

    -- The specular dot is what makes a flat disc read as a bead.
    dl:AddCircleFilled({ x - radius * SPECULAR_OFFSET, y - radius * SPECULAR_OFFSET },
        math.max(1.0, radius * SPECULAR_SIZE), packColor(255, 255, 255, alphaByte(alpha * 0.80)), 8);
end

--[[
* The label that rides beside a bead: the tier letters and/or the level, both
* optional. An ungaugeable mob's level is a question mark and never a number --
* the server withheld it, and inventing one here would be the addon claiming
* to know something /check refuses to say.
--]]
local function labelFor(con, entry)
    local pieces = {};

    if (config.tiers) then
        pieces[#pieces + 1] = entry.short;
    end

    if (config.levels) then
        pieces[#pieces + 1] = con.gauge and string.format('Lv.%d', con.level) or '?';
    end

    return table.concat(pieces, ' ');
end

--[[
* Draw gating for one targid. Every arm of this is a reason a pearl would be a
* lie: an entity that is not rendered, one the client is hiding, one that is
* not a mob at all, a corpse, or something so far away the bead would be
* shimmer. The cached record is deliberately NOT deleted when a mob fails the
* gate -- the mob may simply have walked behind a wall, and the next server
* sweep is the thing that owns the table's contents.
--]]
local function drawOne(dl, entity, idx, con, view, projection, vp, targetIndex)
    local entry = con.gauge and TIERS[con.tier] or nil;

    if (entry == nil) then
        if (con.gauge) then
            -- GAUGEABLE, but a tier this addon does not know -- a server
            -- that grew an eighth tier. The TIERS comment demands it be
            -- VISIBLE (the ungaugeable checkbox must not hide it: that
            -- setting is about mobs the server refuses to gauge, and this
            -- one it gauged fine), so it wears the unknown pearl and keeps
            -- its real level label.
            entry = UNKNOWN;
        else
            -- Ungaugeable -- the server withheld the gauge -- shown only if
            -- the player asked for those.
            if (not config.nm) then
                return;
            end

            entry = UNKNOWN;
        end
    end

    local flags = entity:GetRenderFlags0(idx);

    if (bit.band(flags, 0x200) ~= 0x200 or bit.band(flags, 0x4000) ~= 0) then
        return;
    end

    if (bit.band(entity:GetSpawnFlags(idx), 0x10) == 0) then
        return;
    end

    if (entity:GetHPPercent(idx) <= 0) then
        return;
    end

    -- GetDistance answers the SQUARED distance (it is the client's own cached
    -- square, not a yalm count). The cap is in yalms, so this is a sqrt and
    -- not a comparison against maxDistance * maxDistance -- the fade below
    -- needs the real distance anyway.
    local distance = math.sqrt(math.max(entity:GetDistance(idx), 0));

    if (distance > config.maxDistance) then
        return;
    end

    -- World space is (X, Z, Y) in Ashita's names: X and Y are the ground
    -- plane, Z is height, and height runs NEGATIVE UPWARDS -- the server's own
    -- eyeline is `pos.y - ENTITY_HEIGHT` (base_entity.cpp), and the client
    -- carries that float unchanged. So the bead is raised by SUBTRACTING.
    local sx, sy = worldToScreen(
        entity:GetLocalPositionX(idx),
        entity:GetLocalPositionZ(idx) - config.heightUp,
        entity:GetLocalPositionY(idx),
        view, projection, vp.Width, vp.Height);

    if (sx == nil) then
        return;
    end

    local radius = config.pearlSize;

    if (idx == targetIndex) then
        radius = radius * TARGET_SCALE;
    end

    -- Fade with distance so a camp full of far-off mobs is a hint rather than
    -- a wall of confetti.
    local alpha = 1.0;
    local ratio = distance / config.maxDistance;

    if (ratio > FADE_START) then
        alpha = 1.0 - ((ratio - FADE_START) / (1.0 - FADE_START)) * (1.0 - MIN_ALPHA);
    end

    -- The bead sits to the LEFT of the nameplate anchor, which is where the
    -- client centres the name; the label sits further left again, so neither
    -- of them lands on top of the name itself.
    local px = sx - radius - PEARL_NUDGE;

    drawPearl(dl, px, sy, radius, entry, alpha);

    local label = labelFor(con, entry);

    if (label ~= '') then
        local width, height = imgui.CalcTextSize(label);
        local tx = px - radius - 4 - (width or 0);
        local ty = sy - (height or 12) * 0.5;

        -- Drawn twice: a black copy one pixel down-right, then the real one.
        -- Vana'diel is full of pale ground and this is one-line legibility.
        dl:AddText({ tx + 1, ty + 1 }, packColor(0, 0, 0, alphaByte(alpha * 0.75)), label);
        dl:AddText({ tx, ty }, packColor(255, 255, 255, alphaByte(alpha)), label);
    end
end

--[[
* The world pass. Everything is re-read per frame on purpose, the viewport
* included: targetlines caches the viewport at load time and is quietly wrong
* for the rest of the session after a resolution change, which is a bug worth
* not inheriting.
--]]
local function drawPearls()
    if (not config.pearls or next(state.cons) == nil) then
        return;
    end

    local dev = device();

    if (dev == nil) then
        return;
    end

    local okViewport, vp = dev:GetViewport();

    if (okViewport ~= 0 or vp == nil) then
        return;
    end

    local okView, view = dev:GetTransform(C.D3DTS_VIEW);
    local okProj, proj = dev:GetTransform(C.D3DTS_PROJECTION);

    if (okView ~= 0 or okProj ~= 0 or view == nil or proj == nil) then
        return;
    end

    local memory = AshitaCore:GetMemoryManager();
    local entity = memory:GetEntity();

    if (entity == nil) then
        return;
    end

    -- The current target, for the larger bead. A target that is not active is
    -- index 0, which no mob ever is.
    local targetIndex = 0;
    local target      = memory:GetTarget();

    if (target ~= nil and target:GetIsActive(0) ~= 0) then
        targetIndex = target:GetTargetIndex(0);
    end

    local dl = imgui.GetForegroundDrawList();

    if (dl == nil) then
        return;
    end

    for targid, con in pairs(state.cons) do
        drawOne(dl, entity, targid, con, view, proj, vp, targetIndex);
    end
end

--[[
* The config window.
--]]
local function legendRow(entry)
    local dl     = imgui.GetWindowDrawList();
    local cx, cy = imgui.GetCursorScreenPos();
    local radius = 6;

    -- The legend draws the REAL pearl through the same function the world pass
    -- uses, so a change to the bead cannot leave the legend describing the
    -- old one.
    drawPearl(dl, cx + radius + 2, cy + 8, radius, entry, 1.0);

    imgui.Dummy({ (radius + 2) * 2, 16 });
    imgui.SameLine();
    imgui.Text(string.format('%-2s  %s', entry.short, entry.name));
end

local function renderWindow()
    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'This server speaks a con protocol this addon does not. Update dwcon through the launcher.');
        imgui.Separator();
    elseif (not state.synced and state.notice ~= nil) then
        -- The server said something instead of a snapshot -- typically "Con
        -- pearls are not in this build." Show that, not a wait that will
        -- never end.
        imgui.TextColored(state.noticeBad and theme.colors.err or theme.colors.warn, state.notice);
        imgui.Separator();
    elseif (not state.synced) then
        imgui.TextColored(theme.colors.warn, 'Waiting for the server\'s first snapshot...');
        imgui.Separator();
    else
        local count = 0;

        for _ in pairs(state.cons) do
            count = count + 1;
        end

        imgui.TextColored(theme.colors.ok, string.format('%d enemies gauged.', count));
        imgui.Separator();
    end

    local changed = false;

    changed = imgui.Checkbox('Draw con pearls', ui.pearls) or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('The master switch. /dwcon on and /dwcon off do the same thing.');
    end

    changed = imgui.Checkbox('Show levels', ui.levels) or changed;
    changed = imgui.Checkbox('Show tier letters', ui.tiers) or changed;
    changed = imgui.Checkbox('Show a pearl for mobs the server will not gauge', ui.nm) or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Notorious monsters, Battlefield mobs and anything else /check refuses to gauge.');
    end

    imgui.Separator();

    imgui.PushItemWidth(220);
    changed = imgui.SliderFloat('Pearl size', ui.pearlSize, 3.0, 16.0, '%.1f px') or changed;
    changed = imgui.SliderFloat('Height above the mob', ui.heightUp, 0.0, 6.0, '%.1f') or changed;
    changed = imgui.SliderFloat('Max draw distance', ui.maxDistance, 5.0, 50.0, '%.0f yalms') or changed;
    imgui.PopItemWidth();

    if (changed) then
        commit();
    end

    imgui.Separator();
    imgui.Text('What the colors mean');

    for _, tier in ipairs(TIER_ORDER) do
        legendRow(TIERS[tier]);
    end

    legendRow(UNKNOWN);

    imgui.TextDisabled('Incredibly Easy Prey does not exist on this server\'s curve.');
end

--[[
* The frame. The queue is pumped first so a handshake goes out whether or not
* anything is being drawn, then the world pass, then the window -- three
* separate pcalls, because a bad frame in one of them must not silence the
* other two. Begin/End and the theme push/pop sit OUTSIDE the window's pcall so
* both stacks stay balanced whatever the render pass does.
--]]
ashita.events.register('d3d_present', 'dwcon_present', function ()
    pumpQueue();

    local okWorld, worldErr = pcall(drawPearls);

    if (not okWorld and not state.reported) then
        state.reported = true;

        print(chat.header('dwcon'):append(chat.error('draw error: ' .. tostring(worldErr))));
        print(chat.header('dwcon'):append(chat.message('Pearls are off for this frame onward. /check still works, typed.')));
    end

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 420, 460 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads.
    local visible = imgui.Begin('DriftwoodXI Con##dwcon', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local okRender, renderErr = pcall(renderWindow);

        if (not okRender) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwcon'):append(chat.error('render error: ' .. tostring(renderErr))));
                print(chat.header('dwcon'):append(chat.message('Window closed. The pearls themselves are unaffected.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* `/dwcon` (and `/con`) opens the window; `/dwcon on|off` is the quick toggle
* for the pearls without opening anything.
--]]
ashita.events.register('command', 'dwcon_command', function (e)
    local args = e.command:args();

    if (#args == 0) then
        return;
    end

    local first = args[1]:lower();

    if (first ~= '/dwcon' and first ~= '/con') then
        return;
    end

    e.blocked = true;

    local verb = (args[2] or ''):lower();

    if (verb == 'on' or verb == 'off') then
        ui.pearls[1] = (verb == 'on');
        commit();

        if (config.pearls) then
            print(chat.header('dwcon'):append(chat.message('Con pearls on.')));
        else
            print(chat.header('dwcon'):append(chat.message('Con pearls off. /dwcon on brings them back.')));
        end

        return;
    end

    state.open[1]  = not state.open[1];
    state.reported = false;

    -- A lost hello has nothing else to retry it (the queue is send-and-
    -- forget, and the next attempt is a zone line away). Opening the
    -- settings window is the natural "why are there no pearls" gesture, so
    -- it earns one more try; issue() collapses duplicates, so this can
    -- never stack.
    if (state.open[1] and not state.synced and not state.refused) then
        hello();
    end
end);

ashita.events.register('load', 'dwcon_load', function ()
    hello();

    print(chat.header('dwcon'):append(chat.message('Con pearls: every nearby enemy wears its /check difficulty. /dwcon opens the settings.')));
end);
