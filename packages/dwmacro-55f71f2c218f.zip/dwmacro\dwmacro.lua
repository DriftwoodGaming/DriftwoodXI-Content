--[[
* DriftwoodXI -- dwmacro
*
* Stops the client losing your macro book and set on a zone line and on a
* fresh login.
*
* WHY THIS IS AN ADDON AND NOT A SERVER PATCH.
*
* The macro palette is not server state, and this was re-checked rather than
* inherited. It is not in the database, it is not in any packet, and the map
* server has never been told about it: the string "macro" does not appear
* anywhere in atom0s's packet reference (XiPackets), which is the complete
* documented protocol, and it appears nowhere in this server's own source
* outside of unrelated C preprocessor macros. The one place the client's own
* saved configuration comes back to it from the server -- `ConfData` in the
* 0x000A login packet, the PS2 `SAVE_CONF` block -- carries chat filters, the
* language flags, anonymity, auto-target and the head-display bit, and nothing
* else; there is no macro field in it to get wrong. `LoginState` on that same
* packet is already the correct `SAVE_LOGIN_STATE_GAME`, so the client is not
* being told a zone line is a fresh login either.
*
* Macro books, their contents, and the book/set you are currently looking at
* all live in the client, in `<PlayOnline>/SquareEnix/FINAL FANTASY XI/USER/
* <charid-in-hex>/`, as `mcr.dat` and `mcr<book>.dat`. There is nothing on the
* server to fix. The only place the behaviour can be corrected is in the
* client, which is what this is.
*
* WHAT THE CLIENT ACTUALLY GETS WRONG.
*
* `FsMacroContainer` is not a copy of your macro books. It holds exactly ONE
* loaded page -- twenty macro records of 380 bytes each, from `this+4` to
* `this+0x1DB4`, which is the arithmetic Ashita's own `macrolib.set` uses to
* write one (`obj + 380 * idx + 4`) -- and then, past the end of them, the
* number of the book that page came out of, at `this+0x1DC0`.
*
* Those twenty records ARE the macro bar. There is no second copy of your
* macro names and lines for the bar to draw from; `FsMacroContainer::getName`
* and `::getLine` read them straight out of the container at that same stride.
*
* On a zone line the client reloads the records -- and reloads them from Book
* 1, Set 1 -- WITHOUT putting Book 1 into the book field. The container is
* left holding book 1's macros while its book field still says book 5. That
* single inconsistency is the whole of "the client forgot":
*
*   - the bar shows Book 1, Set 1, because that is what is loaded;
*   - anything that asks the client which book you are on is told book 5,
*     because that is what the field says;
*   - and `FsMacroContainer::setBook(5)` -- what `/macro book 5` and every
*     addon reaches for -- opens by comparing 5 against the field, finds them
*     equal, and returns without loading anything:
*
*         8B 44 24 04        mov  eax, [esp+4]        ; the requested book
*         56                 push esi
*         8B F1              mov  esi, ecx            ; this
*         8B 8E C0 1D 00 00  mov  ecx, [esi+1DC0h]    ; the current book
*         3B C8              cmp  ecx, eax
*         75 ??              jne  short               ; ... only then does the work
*         8B C1              mov  eax, ecx
*         5E                 pop  esi
*         C2 04 00           ret  4
*
*     so the one call that would put the records back is precisely the one the
*     client refuses to run. Being on the wrong page is what makes you unable
*     to ask for the right one.
*
* HOW IT IS PUT RIGHT.
*
* By making the container consistent again, through the client's own loader:
* ask for a NEIGHBOURING book first so the comparison above fails and the load
* actually happens, then ask for the book that is wanted. Same for the set.
* Four calls, no typing, no packets, nothing the server hears about.
*
* AND -- this is the part every earlier build could not do -- by CHECKING. The
* records are the bar, and the records are readable, so what the player is
* looking at is readable. A fingerprint of those 7,600 bytes is kept beside the
* remembered book and set, taken while the player was sitting on that palette
* and playing normally. After a zone line the live fingerprint is compared
* against it:
*
*   - they match: the client did not forget this time, and nothing is touched.
*   - they differ: the palette is wrong, and it is put back -- and then checked
*     again on the next poll, and put back again if the client's own late
*     rebuild has clobbered it.
*
* So there is no longer a guess about WHEN the client finishes rebuilding. The
* addon watches the whole settling window and acts only when the bar is
* actually wrong, instead of firing blind at fixed times and hoping one of them
* landed after the rebuild. 1.1 stood down because it asked the book FIELD
* whether it was needed and the field lied; the fingerprint is the same
* question asked of the thing the player can see, and it cannot lie, because it
* is read from the same bytes the bar is drawn from.
*
* AND THE WINDOW STILL HAS AN EDGE. Fifteen seconds straddles every rebuild
* anyone here has timed, which is ONE of them (2026-08-07, about six seconds).
* A rebuild landing on the far side of that edge finds the recorder live again
* and would be written down as a choice -- so 2.2 stopped defending it with a
* clock. The first look of every window that finds the bar wrong keeps the
* fingerprint of the page the client fell BACK to, and the recorder refuses
* that fingerprint afterwards under fields naming a different page. That is a
* fact about this zone line rather than a longer guess about the client.
*
* WHY THE TYPED-COMMAND PATH IS STILL HERE.
*
* 1.3 restored by queueing the client's own `/macro book` / `/macro set` text
* commands. That worked, but it buys the wrong thing at a real price: the
* command parser refuses input for several seconds after a zone line -- long
* after the party list is live -- and answers a command it will not take with
* "A command error occurred." and no action. Restoring that way means racing a
* parser, swallowing its error lines out of the player's log, and retrying.
*
* The direct calls have none of that: `FsMacroContainer::setBook` does not care
* whether the client is taking typed input yet, so the repair can land at the
* first frame the container exists. But the typed path is retail-proven in a
* way a direct call is not, so it is kept as a FALLBACK: if two direct repairs
* go by and the fingerprint still refuses to come right, the addon stops
* trusting the direct calls and switches to typed commands for the rest of the
* window, bounce-watcher and all. It is also the channel used when there is no
* remembered fingerprint to check against -- the first zone line on a job it
* has never seen -- because an unverifiable repair should use the mechanism
* with the longer field record.
*
* THE SELECTION IS REMEMBERED PER JOB, not per character. That is the way the
* game already thinks about macro books -- changing job switches your book --
* so keying on the job is what stops the two features fighting: come back as
* BLM and you are put on the book and set you last used as BLM, not on whatever
* WAR was looking at. Per-character separation is free; Ashita's settings
* library already files everything under `<charname>_<serverid>`.
*
* TURN IT OFF AND NOTHING IS LOST. `/macro book <n>` and `/macro set <n>` work
* exactly as they always did. This addon only ever puts back a book and set the
* player had already chosen for that job on that character; it never invents
* one, and with no remembered entry it does nothing at all.
*
* SINCE 2.2.1 (2026-09-09) the bounce watcher refuses a line somebody TYPED.
* It used to block any line containing the mark on any mode, so a player who
* said "A command error occurred." inside the 2.5s window of somebody else's
* typed repair had that line eaten on their client, unread. Same defect class
* as dwnemesis 1.3.1 / dwquest 1.27.1, one window smaller. See
* PLAYER_CHAT_MODES.
--]]

addon.name    = 'dwmacro';
addon.author  = 'DriftwoodXI';
addon.version = '2.2.1';
addon.desc    = 'Stops the client losing your macro book and set when you zone or log back in.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local settings = require('settings');

--[[
* The macro library is a signature scan over the client and it raises rather
* than returning nil when a scan misses. A client build it does not know must
* leave the player with a working game and one line of explanation, not an
* addon that failed to load, so it is required defensively and every use of it
* is behind `macrolib ~= nil`.
--]]
local macrolib = nil;

do
    local ok, lib = pcall(require, 'ffxi.macros');

    if (ok and type(lib) == 'table') then
        macrolib = lib;
    end
end

--[[
* The loaded page: twenty macro records of 380 bytes, starting four bytes into
* the container.
*
* This is not a guess and it is not this addon's arithmetic. Ashita's own
* `macrolib.set` writes a macro at `obj + 380 * idx + 4`, and the client's
* `FsMacroContainer::getName` computes the same address from the same stride
* (`lea edx,[eax+eax*2]; shl edx,5; sub edx,eax; lea ecx,[ecx+edx*4+4]` is
* `idx * 380 + 4`). Everything the macro bar draws lives in this block, which
* is what makes it worth fingerprinting.
--]]
local RECORD_BASE   = 4;
local RECORD_STRIDE = 380;
local RECORD_COUNT  = 20;
local RECORD_END    = RECORD_BASE + (RECORD_STRIDE * RECORD_COUNT);

--[[
* Where the book field lives inside the macro container.
*
* The offset is the four bytes at +9 from the address Ashita matched for
* `setBook` (see the disassembly in the header). Taking it from there rather
* than writing 0x1DC0 down means this and the library can only ever agree:
* they are reading the same matched bytes.
--]]
local BOOK_OFFSET_IMM = 9;

-- A sanity range for that offset. The macro records occupy everything below
-- RECORD_END, so a plausible book offset is a little past that and nowhere
-- near zero. Anything outside this is a bad match, not a client we do not know
-- about, and is refused. The floor is RECORD_END itself (0x1DB4): a matched
-- offset below it would put the "scan above the records" seed loop AND the
-- fingerprint inside the record block -- collapsing both of the guards the
-- seed-scan comment calls independent, on the same bad input.
local BOOK_OFFSET_MIN = RECORD_END;
local BOOK_OFFSET_MAX = 0x4000;

--[[
* How far past the book field to look when measuring the set field.
*
* Above the book field is the only speculative part of the scan, and it is
* speculative in the way that matters -- reading past the end of the allocation
* is a crash, not a failed measurement. A quarter of a kilobyte past the last
* member anyone has ever named is a long way for a sibling field and a short
* way into a heap block this size.
--]]
local SCAN_PAST_BOOK = 0x100;

--[[
* The sets the measurement drives through, as set numbers 0-9.
*
* Four values, so that a byte which merely happens to be 1 when the set is 1 is
* gone by the second probe, and chosen so the two candidate encodings can never
* be confused: as rows these are 2, 18, 8, 0 and as plain sets 1, 9, 4, 0, which
* differ everywhere they can.
*
* THE ORDER NO LONGER CARRIES THE RESTORE, and the comment here used to say it
* did ("the list ends on set 1 ... so a measurement that fails outright leaves
* the palette where the client left it"). Two things make that untrue as
* written: CONFIRM_SET is driven AFTER this list, so the last value the client
* is handed is 6 and not 0; and `measurePageField` reaches its own
* `set_page(restore)` on every path that has moved anything, including the one
* where the probe raises halfway through. Ending on 0 is now a harmless
* coincidence rather than a guarantee -- the guarantee is the restore.
*
* CONFIRM_SET took no part in choosing the candidates, which is the point of it:
* a byte that survived four probes and then also predicted a fifth is the set.
--]]
local PROBE_SETS  = T{ 1, 9, 4, 0 };
local CONFIRM_SET = 6;

local MAX_SET  = 9;

-- BOOKS ARE 0-39. The client ships TWO book-name tables -- mcr.ttl names
-- Book01..Book20 and mcr_2.ttl names Book21..Book40 -- and Ashita's own
-- `set_book` gates on `idx >= 40`. 2.0.1 (2026-08-09) lowered this to 19 on
-- the argument that 39 was "the doubled ROW value"; that doubling belongs to
-- setPage, and Ashita's `set_page` does the doubling itself. The cost was
-- every player keeping macros on books 21-40: readPalette answered nil, the
-- recorder never recorded, the restorer never fired, and this addon was a
-- silent no-op for exactly the players still reporting macro wipes
-- (2026-08-25) -- with nothing repairing the bar, the client's own
-- write-the-loaded-page-to-the-stale-book's-file logout save destroyed
-- their real pages unopposed. 39 was right all along; the harness now pins
-- it against Ashita's 40-book gate.
local MAX_BOOK = 39;

--[[
* Job ids to the three letters the game prints. Only `/dwmacro list` and the
* `forget` lines use it: everything the addon DOES is keyed on the id.
*
* The same table five siblings carry (dwbags, dwcpx, dwah, dwgambits,
* dwgmpanel), in the same order, so a job id reads the same way across the
* suite. Index 0 is the "no job" the memory manager reports while zoning.
--]]
local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

--[[
* The two ways the container could plausibly hold the selection: the row index
* the client's `setPage` is handed, or the set number behind it. Which one it
* actually is gets decided by the measurement rather than by assumption.
--]]
local ENCODINGS = T{
    T{
        name   = 'row',
        encode = function (set) return set * 2; end,
        decode = function (raw)
            if (raw % 2 ~= 0) then
                return nil;
            end

            return math.floor(raw / 2);
        end,
    },
    T{
        name   = 'set',
        encode = function (set) return set; end,
        decode = function (raw) return raw; end,
    },
};

--[[
* How long after a zone line the palette is watched, and how often.
*
* The window is NOT a schedule any more. Nothing fires at a fixed offset inside
* it; the addon looks at the bar every CHECK_INTERVAL and only acts when the
* bar is wrong. What the window's length still has to cover is the client's own
* late rebuild -- observed on 2026-08-07 arriving a good six seconds after the
* party list went live, and refusing typed input for most of that -- because a
* rebuild that lands after the addon has stopped watching is a rebuild that
* wins. Fifteen seconds straddles every one anyone here has seen.
*
* Everything inside the window is also held out of the recorder (see `tick`):
* the client's post-zone default is not a choice the player made, and writing
* it down is how a repair that missed turns into "puts me on Set 1 for ever".
--]]
local RECORD_HOLD    = 15.0;
local CHECK_INTERVAL = 0.5;

--[[
* How long a repair is given to land before the next one is allowed, and how
* many are allowed at all.
*
* A direct call has landed by the time it returns; a typed command takes a
* frame or two to be parsed, so the check that follows one must not be taken
* immediately. Two seconds is far past either.
*
* The ceiling exists for the case the addon cannot distinguish from the outside:
* a player who spends the settling window working the macro menu themselves
* looks exactly like a client that keeps clobbering the palette. Eight repairs
* spread across the window is more coverage than 1.3's three blind passes had,
* and still stops rather than fighting for ever.
--]]
local APPLY_SETTLE = 2.0;
local MAX_APPLIES  = 8;

--[[
* How many unverified direct repairs are allowed before the addon stops
* believing in them and falls back to typed commands for the rest of the
* window. Two: one to be unlucky with, one to be sure.
--]]
local DIRECT_TRIES = 2;

--[[
* How long after a typed repair a "command error" line in the chat log is taken
* to be that repair bouncing off a client that was not ready, rather than the
* player's own typing going wrong. Inside this window the line is swallowed --
* it is this addon's plumbing -- and counted, so `/dwmacro debug` can say the
* repair was rejected instead of leaving "ran and changed nothing" and "never
* landed" looking identical. Only ever armed for the typed fallback; a direct
* repair produces no chat line at all, so the player's own command errors stay
* their own for as long as the fallback is not in use.
--]]
local BOUNCE_WINDOW = 2.5;

--[[
* The whole retail sentence, not the two words it used to be.
*
* This handler BLOCKS the line it matches, so the mark decides what a player
* never sees. `command error` on its own also matches a player saying "I got a
* command error" in party chat, and inside two and a half seconds of a typed
* repair that sentence was eaten. The full sentence cannot be typed by accident.
* Same literal dwecho matches for the same client line (dwecho.lua ERROR_MARK),
* which is the point: one client sentence, one spelling of it.
--]]
local BOUNCE_MARK = 'command error occurred';

--[[
* THE MODES A PLAYER CAN PUT THAT SENTENCE ON (2.2.1, 2026-09-09).
*
* The handler below BLOCKS what it matches, so the mark decides what a player
* never sees -- and until now it decided that on the words alone, on any mode
* at all. "A command error occurred." is a sentence anybody can type: said in
* party chat inside 2.5 seconds of somebody else's typed repair, it was eaten
* on their client with no trace, and the count it bumped made `/dwmacro debug`
* report a repair that bounced when none had. That is the dwnemesis 1.3.1 and
* dwquest 1.27.1 defect at a smaller window, and it gets the same answer: the
* words are scaffolding, the MODE is the signature.
*
* A REFUSAL LIST, not an allow list, and the polarity is deliberate. What this
* handler is trying to swallow is a line the CLIENT wrote locally -- the
* refusal of a command that never reached the server -- and this addon has no
* capture of the mode that line arrives on. An allow list would need that
* number and a wrong one would put the four unexplained error lines per
* bounced repair back in the log, which is the residue this handler exists to
* remove. A refusal list needs only the numbers a player can SPEAK on, and
* those are known: say 9, shout 10, yell 11, tell 12, party 13, linkshell 14
* and 214, unity 212, assist 220 and 222 (chatmon/rules/incoming_chat.lua in
* the shipped Ashita bundle; the same table dwquest.lua names). The client's
* own local line is not another player's say, so no number here can swallow
* it.
*
* SPELLED OUT RATHER THAN A `<= 31` BAND, unlike dwquest's copy: a band takes
* mode 0 and every unnamed number under it with it, and one of those may well
* be where the client writes its own refusal. Only what is KNOWN to carry text
* a person typed is named.
*
* EMOTES ARE 15. `MESSAGE_EMOTION` (Kind 0x08 in
* src/map/packets/c2s/0x0b5_chat_std.h, pushed with the player's raw message
* at 0x0b5_chat_std.cpp:176) is a chat kind a player can send free text on,
* and the shipped Ashita tables never name it. Windower's res/chat.lua does
* (M:\FFXI\Windower\res\chat.lua: `[8] = {en="emote", incoming=15}`), and
* that table agrees with chatmon on every other row -- say 9, shout 10, yell
* 11, tell 12, party 13, linkshell 14, linkshell2 214, unity 212 -- so 15 is
* read, not guessed. (dwquest's `<= 31` band already covers it.)
*
* A plain table, not `T{ }`: it is keyed by numbers and only ever read.
--]]
local PLAYER_CHAT_MODES = {
    [9]   = true, [10]  = true, [11]  = true, [12]  = true, [13]  = true,
    [14]  = true, [15]  = true, [212] = true, [214] = true, [220] = true,
    [222] = true,
};

-- How often the palette is read while playing. Often enough that a set chosen
-- and then immediately zoned away from is caught, rare enough to be free.
local POLL_INTERVAL = 0.5;

--[[
* How long `/dwmacro forget all` stays armed waiting to be typed again.
*
* Forgetting ONE job costs nothing: the player is sitting on the palette while
* they type, so the recorder learns it back within a poll. Forgetting the
* CHARACTER cannot be undone by waiting -- every other job's entry only comes
* back the next time that job is played and zoned on, which for a full set of
* them is weeks. So it is the one verb here that asks twice, in the house's
* staging-then-committing shape (dwbags).
--]]
local FORGET_CONFIRM = 15.0;

-- And how many of those polls in a row have to agree before a new selection is
-- believed. A single read that disagrees with the one beside it is the palette
-- mid-move, not a decision; two costs half a second of lag and cannot be one.
local RECORD_AGREE = 2;

--[[
* Measuring needs a macro container the client has actually finished filling in.
* `inGame()` goes true the moment the player has a party slot, which on a slow
* login -- a server still loading, a zone still streaming in -- is earlier than
* the palette being ready. Probing then drives sets that do not take, no byte
* counts along, and the measurement comes back empty.
*
* So a failure is never final on the strength of one login. MEASURE_RETRIES is
* the budget for a single arming: spend it and the addon goes quiet until the
* next zone line, which re-arms it with a fresh budget and a client that has
* just rebuilt its macro state. Only MEASURE_MAX_ATTEMPTS, across the whole
* session, ends it for good -- because a client that genuinely cannot be read
* should say so once rather than probe the palette for ever.
--]]
local MEASURE_SETTLE         = 2.0;
local MEASURE_RETRIES        = 4;
local MEASURE_RETRY_INTERVAL = 3.0;
local MEASURE_MAX_ATTEMPTS   = 24;

local default_settings = T{
    -- Repairing can be turned off without unloading the addon; the palette is
    -- still remembered while it is off, so turning it back on picks up where
    -- it left off.
    enabled = true,

    -- Keyed by main job id. Each entry is { book = <0-39>, set = <0-9>,
    -- fp = <fingerprint of the twenty records that were loaded there> }, in
    -- the numbering the macro menu shows minus one.
    jobs    = T{ },
};

local config = settings.load(default_settings);

--[[
* The remembered entries, GUARANTEED to be a table.
*
* Everything below indexes `config.jobs` -- the restorer, the recorder, the
* status line -- and a settings file whose `jobs` key is not a table (deleted
* by hand, half-written by a crash, edited to a number) turned every one of
* those into "attempt to index a nil value" sixty times a second. The frame
* pcall caught it, which is worse than it sounds: the addon latched `failed`
* and went silent FOR THE SESSION over a file it could simply have started
* over. The house rule is that a corrupt settings file must never take the
* addon down, and this is the one place that rule was not kept.
*
* It also breaks an aliasing trap in Ashita's own settings library: `merge`
* assigns the DEFAULTS TABLE ITSELF for a key the loaded file is missing
* (libs/sugar/table.lua), so a file with no `jobs` key would leave every
* character writing into one shared table. Replacing it here hands each
* profile its own.
--]]
local jobsWarned = false;

local function jobsTable()
    if (type(config.jobs) ~= 'table') then
        config.jobs = T{ };

        if (not jobsWarned) then
            jobsWarned = true;

            print(chat.header(addon.name):append(chat.error('The remembered macro books could not be read and have been started over. Nothing else is affected; the palette you are on now is learned again within a second.')));
        end
    end

    return config.jobs;
end

--[[
* Builds before 1.1 stored the client's doubled row value under `page`. Nothing
* is thrown away for it: the row halves cleanly into the set it always meant.
* Entries written before 2.0 carry no fingerprint, which is not a migration
* problem -- an entry without one simply cannot be checked until the recorder
* has seen that palette once, and takes the typed fallback in the meantime.
*
* A FUNCTION, NOT A ONE-SHOT BLOCK. Ashita's settings library swaps `config`
* for the new character's table on every profile change through the register
* callback below, and until 2.1.0 the migration ran once at file scope -- so
* the second character logged into in a session kept unmigrated entries, and
* an out-of-range one burned all 8 applies of every zone line on a
* guaranteed applyPalette refusal, taking the book repair down with it.
--]]

--[[
* Is this a number the client could actually be handed as a book or a set?
*
* RANGE IS NOT ENOUGH, which is the house rule for every number that reaches a
* format string or a client call. A settings file is Lua source and Ashita's
* own serializer round-trips `0/0` verbatim (libs/settings.lua names the three
* infinities explicitly), so a NaN in `book` survives a range test -- every
* comparison against it is false -- and reaches `macrolib.set_book`, whose own
* `idx >= 40` gate is false for the same reason. What the client is then handed
* is a NaN cast to uint32_t, which is undefined and indexes whatever it lands
* on. `n ~= math.floor(n)` is true for NaN and for 2.5 alike, so one test
* covers both.
--]]
local function isSelection(n, max)
    return type(n) == 'number' and n == math.floor(n) and n >= 0 and n <= max;
end

local function migrateConfig()
    -- jobsTable() rather than a type test: a `jobs` key that is not a table is
    -- replaced with an empty one here, so nothing below has to keep asking.
    local jobs = jobsTable();

    for job, entry in pairs(jobs) do
        if (type(entry) ~= 'table') then
            -- Not an entry at all. Dropped rather than skipped: everything
            -- below indexes it (`wanted.book`, `known.fp`), and indexing a
            -- number raises inside the frame pcall and silences the addon.
            jobs[job] = nil;
        else
            if (entry.set == nil and type(entry.page) == 'number') then
                entry.set  = math.floor(entry.page / 2);
                entry.page = nil;
            end

            -- A fingerprint is a string or it is nothing. Anything else can
            -- only ever fail to match, so it is cleared rather than kept and
            -- compared: an entry with no fingerprint takes the typed channel
            -- and says so, which is a state the addon already handles.
            if (entry.fp ~= nil and type(entry.fp) ~= 'string') then
                entry.fp = nil;
            end

            -- Entries the client could not be given are DROPPED rather than
            -- clamped: a clamped entry would keep a fingerprint that describes
            -- a palette the entry no longer names, while a dropped one simply
            -- relearns on the next recorder pass. BOTH axes: applyPalette
            -- refuses on either, and an out-of-range `set` (the pre-1.1 page
            -- migration above is unvalidated) burned all 8 applies of a zone
            -- line on a guaranteed refusal. With MAX_BOOK back at the client's
            -- real 39 (2.1.0), this now also RECOVERS the players 2.0.1's
            -- wrong bound refused: a book 20-39 entry is in range again and
            -- simply works, and only genuine garbage is dropped. (The entries
            -- 2.0.x's migration already deleted are gone -- those relearn from
            -- one recorder pass on the right page.)
            if (not isSelection(entry.book, MAX_BOOK) or not isSelection(entry.set, MAX_SET)) then
                jobs[job] = nil;
            end
        end
    end
end

migrateConfig();

local state = T{
    -- What was measured. `bookOffset` is an offset; `page` is a table of
    -- { offset = <byte offset>, enc = <encoding> } and is nil until proven.
    bookOffset = nil,
    page       = nil,

    -- Measurement bookkeeping. `attempts` is the budget for the current arming
    -- and `total` is the session ceiling; `gaveUp` is set only once the ceiling
    -- is reached, and is what makes the failure final and worth saying aloud.
    attempts   = 0,
    total      = 0,
    nextTry    = 0,
    gaveUp     = false,

    -- What the last measurement saw, for `/dwmacro debug`. "Nothing happens" has
    -- several causes and they are not distinguishable from the outside.
    scan       = nil,

    -- Repair bookkeeping. `armed` is set by the zone-in packet and cleared when
    -- the settling window closes; while it is up nothing read from the palette
    -- is recorded, because immediately after a zone the client is sitting on its
    -- own Book 1 / Set 1 default and writing that over the player's real choice
    -- is the one bug this addon must not have.
    armed      = false,
    zonedAt    = 0,
    nextCheck  = 0,

    -- `applies` is how many repairs have gone out this zone, `nextApply` when
    -- the next one is allowed, `appliedFp` the fingerprint the last one left
    -- behind (used to notice a later clobber when there is nothing remembered
    -- to check against), `verified` whether the bar has ever been seen to agree
    -- with what was remembered, and `channel` which mechanism is in use.
    applies    = 0,
    nextApply  = 0,
    appliedFp  = nil,
    verified   = false,
    channel    = 'direct',

    -- What the last zone line actually did, for `/dwmacro debug`. A repair that
    -- ran and did not show up on screen and a repair that never ran look the
    -- same to the player and want completely different answers.
    trail      = nil,

    -- When the last typed repair went out, and how many of its commands the
    -- client has bounced this zone. `sentAt` arms the text_in watcher; a
    -- "command error" line inside BOUNCE_WINDOW of it is ours, not the player's.
    sentAt     = nil,
    bounced    = 0,

    -- The previous poll's reading, for the agreement rule.
    lastSeen   = nil,
    agreed     = 0,

    lastPoll   = 0,

    --[[
    * MAY THE FIELDS AND THE BAR BE WRITTEN DOWN AS A PAIR RIGHT NOW?
    *
    * `record()` reads the selection out of the container FIELDS and the
    * fingerprint out of the RECORDS, and the whole premise of this addon is
    * that after a zone line those two DISAGREE -- the field still says book 5
    * while the bar shows book 1. Writing them down together in that state
    * files book 1's macros under the label "book 5", and the next zone line
    * then finds the bar matching what was remembered and stands down. The
    * feature turns itself off for that job, permanently, in silence.
    *
    * It is not a corner: a job with nothing remembered yet is left alone on
    * purpose (restoreWindow says so), so its FIRST zone line ends with the
    * window closing over exactly that disagreement -- and so does a zone with
    * repairing switched off, and one where the repairs ran out.
    *
    * So the pair is only written once something has PROVED the two agree:
    *   * the restore verified the bar against a remembered fingerprint, or
    *   * the fields have MOVED since the window closed -- which can only
    *     happen through the client's own loader (a /macro command, the macro
    *     menu, the book switch a job change performs), and running the loader
    *     is precisely what makes the records match the field again.
    * Until then the previous entry stands, which is the whole of "turn it
    * back on and it picks up where it left off".
    *
    * `trustBar` starts FALSE (2.2.0). It used to start TRUE on the argument
    * that the disagreement is created by a zone line and nothing else, so an
    * addon loaded mid-session is looking at a container the player has been
    * playing on. That argument holds everywhere except where it matters: a
    * load INSIDE the settling window -- and `/addon load dwmacro` is what the
    * server's own `!addons` list tells players to type -- met exactly the
    * disagreement with the licence already granted. `record()` now earns the
    * licence back on its first poll by recognising the remembered palette,
    * which is the ordinary mid-session load, and holds in the one case where
    * that recognition fails.
    --]]
    trustBar   = false,
    baseline   = nil,   -- the fields as the settling window left them

    --[[
    * The fingerprint of the page the client fell back to on THIS zone line,
    * captured by restoreWindow the first time it found the bar wrong, and
    * refused by the recorder for the rest of the session (see `record`). It is
    * the guard against a macro rebuild arriving after the settling window has
    * closed, which no timer can be lengthened far enough to cover honestly.
    --]]
    clobberFp  = nil,

    -- When `/dwmacro forget all` was armed, or nil. Session state and
    -- deliberately not persisted: a confirmation that survives a relog is not
    -- a confirmation of anything the player still has in mind.
    forgetAllAt = nil,
};

settings.register('settings', 'dwmacro_settings_update', function (s)
    if (s == nil) then
        -- Never fall through to a save here: `config` still holds the
        -- PREVIOUS profile's table, and settings.save() would file character
        -- A's books under character B's name. B's own table arrives when the
        -- library hands a real one (a first login hands the defaults, so the
        -- initial file still gets created through the branch below).
        return;
    end

    config = s;

    -- One warning per profile, not per session: the next character's file is a
    -- different file and can be broken in its own right.
    jobsWarned = false;

    -- The new character's file may predate a migration this build carries --
    -- re-run it, then persist the migrated shape.
    migrateConfig();

    settings.save();
end);

--[[
* Whether the player is actually in the world -- past character select, past
* the zone screen, with a party slot of their own, and NOT mid-zone. Every
* read and write below is gated on this; the macro container exists before
* this is true and holds nothing worth reading.
*
* The zoning check is load-bearing: login status and the party slot both go
* live while the load screen is still up, so a clock started on them alone
* starts several seconds early. `GetIsZoning() == 0` is the same signal the
* stock timers and statustimers addons gate on for "the world is real now".
--]]
local function inGame()
    local player = AshitaCore:GetMemoryManager():GetPlayer();

    if (player == nil or player:GetLoginStatus() ~= 2) then
        return false;
    end

    if (player:GetIsZoning() ~= 0) then
        return false;
    end

    local party = AshitaCore:GetMemoryManager():GetParty();

    if (party == nil or party:GetMemberIsActive(0) == 0) then
        return false;
    end

    return true;
end

local function mainJob()
    local player = AshitaCore:GetMemoryManager():GetPlayer();

    if (player == nil) then
        return 0;
    end

    return player:GetMainJob();
end

--[[
* The live macro container, or 0. This is re-read every time rather than cached
* because it is a pointer through two indirections and the object behind it does
* not survive a zone.
--]]
local function container()
    if (macrolib == nil) then
        return 0;
    end

    local ok, obj = pcall(macrolib.get_fsmacro);

    if (not ok or type(obj) ~= 'number') then
        return 0;
    end

    return obj;
end

--[[
* A fingerprint of the loaded page -- which is to say, of the macro bar.
*
* THIS IS THE ONLY HONEST ANSWER TO "IS THE PLAYER LOOKING AT THE RIGHT
* MACROS", and having it is the whole difference between 2.0 and everything
* before it. The book field says what the client believes; these bytes are what
* it drew. After a zone line the two disagree, and only one of them is the bug.
*
* Two independent rolling hashes rather than one, and returned as a string so
* the settings file holds something legible: a single 32-bit hash over 7,600
* bytes will collide on some pair of pages eventually, and a collision here is
* an addon that declares the bar correct while the player stares at the wrong
* macros. Both would have to collide at once for that.
*
* Cheap enough to run twice a second: `read_array` fetches the block in one
* call and the loop is arithmetic on a LuaJIT number.
--]]
local function fingerprint(obj)
    if (obj == nil or obj == 0) then
        return nil;
    end

    -- Never read past the book field, whatever the client says the layout is.
    local length = RECORD_END - RECORD_BASE;

    if (state.bookOffset ~= nil and state.bookOffset < RECORD_END) then
        length = state.bookOffset - RECORD_BASE;
    end

    if (length <= 0) then
        return nil;
    end

    local ok, bytes = pcall(ashita.memory.read_array, obj + RECORD_BASE, length);

    if (not ok or type(bytes) ~= 'table') then
        return nil;
    end

    local h1 = 0;
    local h2 = 0;

    for index = 1, length do
        local value = bytes[index];

        if (value == nil) then
            return nil;
        end

        h1 = (h1 * 31 + value) % 4294967291;
        h2 = (h2 * 131 + value + index) % 4294967279;
    end

    return ('%d.%d'):fmt(h1, h2);
end

--[[
* The book field's offset, taken out of the bytes Ashita matched for setBook.
--]]
local function findBookOffset()
    if (macrolib == nil or macrolib.ptrs == nil) then
        return nil;
    end

    local ptr = macrolib.ptrs.set_book;

    if (ptr == nil or ptr == 0) then
        return nil;
    end

    local ok, offset = pcall(ashita.memory.read_uint32, ptr + BOOK_OFFSET_IMM);

    if (not ok or type(offset) ~= 'number') then
        return nil;
    end

    if (offset < BOOK_OFFSET_MIN or offset > BOOK_OFFSET_MAX or offset % 4 ~= 0) then
        return nil;
    end

    return offset;
end

--[[
* The probing half of the measurement. Kept separate from the repair so that
* the repair can be guaranteed: this is allowed to fail in the middle, and the
* caller still puts the player's set back.
*
* THE SCAN STARTS ABOVE THE MACRO RECORDS and that is not an optimisation. The
* records change when the page changes -- that is the entire premise of the
* fingerprint above -- so a byte inside them tracks the set just as faithfully
* as the set field does, and a scan that includes them is choosing between
* thousands of bytes that all "count along" rather than looking for a field.
* The set field cannot be inside the loaded page, so it is not looked for
* there.
*
* HOW MUCH ROOM THAT LEAVES, MEASURED RATHER THAN ASSUMED: on the live client
* (2026-08-08, `/dwmacro debug`) the set field came out at 0x1DBC -- four bytes
* below the book field and EIGHT above RECORD_END. It lives in the gap between
* the records and the book, and the gap is eight bytes wide.
*
* WHICH MAKES THIS BOUND THE SECOND OF TWO GUARDS, NOT THE ONLY ONE, and the
* distinction is worth having written down because it was got wrong once. The
* tie-break below picks the candidate nearest the book field, and on that
* layout the nearest record byte is thirteen bytes out against the set field's
* four -- so the tie-break alone would still choose correctly with this bound
* deleted, and this bound alone would still choose correctly with the tie-break
* deleted. Delete BOTH and the measurement picks a macro byte and the addon
* remembers nonsense. They are kept as two because the tie-break's sufficiency
* rests on that eight-byte gap, which is a fact about one client build and not
* a law, while this bound rests on the record stride, which is arithmetic the
* client itself performs.
--]]
local function probePageField(obj, bookOffset, before)
    local size  = bookOffset + SCAN_PAST_BOOK;
    local first = RECORD_END;

    if (first > bookOffset) then
        first = 0;
    end

    -- Probe one, from the full snapshot.
    macrolib.set_page(PROBE_SETS[1]);

    local snapshot = ashita.memory.read_array(obj, size);

    if (type(snapshot) ~= 'table') then
        return nil;
    end

    local candidates = { };

    for offset = first, size - 1 do
        local value = snapshot[offset + 1];

        if (value == nil) then
            break;
        end

        -- The book field is known, and is not the set field.
        if (offset < bookOffset or offset > bookOffset + 3) then
            for index = 1, #ENCODINGS do
                if (value == ENCODINGS[index].encode(PROBE_SETS[1])) then
                    candidates[#candidates + 1] = { offset = offset, enc = ENCODINGS[index] };
                end
            end
        end
    end

    local seeded = #candidates;

    -- The remaining probes, plus the confirming one. A candidate has to predict
    -- every single one of them.
    local rounds = T{ };

    for index = 2, #PROBE_SETS do
        rounds:append(PROBE_SETS[index]);
    end

    rounds:append(CONFIRM_SET);

    for index = 1, #rounds do
        if (#candidates == 0) then
            break;
        end

        macrolib.set_page(rounds[index]);

        local survivors = { };

        for entry = 1, #candidates do
            local candidate = candidates[entry];
            local ok, value = pcall(ashita.memory.read_uint8, obj + candidate.offset);

            if (ok and value == candidate.enc.encode(rounds[index])) then
                survivors[#survivors + 1] = candidate;
            end
        end

        candidates = survivors;
    end

    --[[
    * Nearest the book field wins. Several survivors is not ambiguity to be
    * refused -- all of them track the set, and the offset is only ever read --
    * but the choice still has to be the same one every session, so it is made
    * on distance and then on offset and encoding to break any remaining tie.
    --]]
    table.sort(candidates, function (a, b)
        local da = math.abs(a.offset - bookOffset);
        local db = math.abs(b.offset - bookOffset);

        if (da ~= db) then
            return da < db;
        end

        if (a.offset ~= b.offset) then
            return a.offset < b.offset;
        end

        return a.enc.name < b.enc.name;
    end);

    return {
        seeded    = seeded,
        survivors = #candidates,
        chosen    = candidates[1],
        before    = before,
    };
end

--[[
* Measure the set field, and put the player back on the set they were on.
*
* The restore runs whether the probing succeeded, failed, or raised: the probe
* moves the palette, and a probe that dies halfway through must not leave the
* player looking at somebody else's macros. Where the original set is unknown --
* nothing was found, so there is no byte to read it back out of -- what this job
* was last seen on is the player's own choice rather than the client's default,
* so it is asked first, and 0 is only the answer when there is nothing
* remembered at all -- which is also where the client has just put them.
--]]
local function measurePageField(obj, bookOffset)
    local before = ashita.memory.read_array(obj, bookOffset + SCAN_PAST_BOOK);

    if (type(before) ~= 'table') then
        return nil;
    end

    local ok, result = pcall(probePageField, obj, bookOffset, before);

    local restore = nil;

    if (ok and type(result) == 'table' and result.chosen ~= nil) then
        local original = before[result.chosen.offset + 1];

        if (type(original) == 'number') then
            local decoded = result.chosen.enc.decode(original);

            if (decoded ~= nil and decoded >= 0 and decoded <= MAX_SET) then
                restore = decoded;
            end
        end
    end

    if (restore == nil) then
        local job        = mainJob();
        local remembered = (job ~= 0) and jobsTable()[job] or nil;

        if (remembered ~= nil and isSelection(remembered.set, MAX_SET)) then
            restore = remembered.set;
        else
            restore = 0;
        end
    end

    pcall(macrolib.set_page, restore);

    if (not ok) then
        error(result, 0);
    end

    return result;
end

--[[
* Read the palette FIELDS. Returns nil unless the measurement is done, the
* container is live, and both values are ones the client could actually be
* holding -- a set outside 0-9 means the offset is wrong and the read is thrown
* away rather than remembered.
*
* Note what this is and is not for. It says which book and set the player
* CHOSE, which is what has to be written down. It does NOT say what the client
* is showing them -- after a zone line it happily reports the old selection
* while the bar sits on Book 1 -- so nothing about whether a repair is needed
* is ever decided from it. That is the fingerprint's job.
--]]
local function readPalette()
    if (state.bookOffset == nil or state.page == nil) then
        return nil;
    end

    local obj = container();

    if (obj == 0) then
        return nil;
    end

    local ok, book = pcall(ashita.memory.read_uint32, obj + state.bookOffset);

    if (not ok or type(book) ~= 'number' or book < 0 or book > MAX_BOOK) then
        return nil;
    end

    local okRaw, raw = pcall(ashita.memory.read_uint8, obj + state.page.offset);

    if (not okRaw or type(raw) ~= 'number') then
        return nil;
    end

    local set = state.page.enc.decode(raw);

    if (set == nil or set < 0 or set > MAX_SET) then
        return nil;
    end

    return { book = book, set = set };
end

--[[
* Put the palette back through the client's own loader.
*
* EACH OF THE BOOK AND THE SET GOES THROUGH A NEIGHBOUR FIRST, and that is the
* fix rather than a flourish: `FsMacroContainer::setBook` returns immediately
* when asked for the book its field already claims to hold (the disassembly is
* in the header), and after a zone line that field claims to hold the right
* book while the bar shows Book 1. A no-op is not a repair. The extra
* transition is only ever visible if the player is holding Ctrl or Alt inside
* the settling window, and costs nothing otherwise.
*
* The book goes first and the set second, and that order is not cosmetic: the
* client resets the set whenever the book actually changes, so a set put back
* first would be thrown away by the book change.
*
* Two channels, same four transitions.
*
*   direct  `FsMacroContainer::setBook` / `::setPage`, through Ashita's macro
*           library. Nothing is written to the container; these are the
*           client's own methods, called the way the client calls them. They do
*           not care whether the command parser is up yet, which is why this is
*           the default -- a repair can land at the first frame the container
*           exists instead of waiting out a parser that answers "A command
*           error occurred." for several seconds after a zone line.
*
*   text    the client's own `/macro book <n>` / `/macro set <n>`, queued. The
*           mechanism players and job-change macros have driven for years, kept
*           for when the direct calls cannot be shown to have worked. The
*           commands carry the menu's 1-based numbering, because that is what
*           the client's command parser takes; everything else here is 0-based.
*           A slash command is client-local and reaches no server, so there is
*           no echo to swallow and dwecho stays unnecessary.
*
* The four steps are written out rather than folded into a loop: read as four
* lines it is obvious what happens if one of them is ever removed.
--]]
local function applyPalette(palette, channel)
    if (palette == nil) then
        return false;
    end

    -- The last gate before the client is called. `isSelection` and not a range
    -- test: this is the boundary a NaN would cross into `FsMacroContainer`, and
    -- a range test cannot see one (see isSelection).
    if (not isSelection(palette.book, MAX_BOOK) or not isSelection(palette.set, MAX_SET)) then
        return false;
    end

    local otherBook = (palette.book + 1) % (MAX_BOOK + 1);
    local otherSet  = (palette.set  + 1) % (MAX_SET  + 1);

    if (channel == 'text') then
        local mgr = AshitaCore:GetChatManager();

        if (mgr == nil) then
            return false;
        end

        return pcall(function ()
            mgr:QueueCommand(1, ('/macro book %d'):fmt(otherBook + 1));
            mgr:QueueCommand(1, ('/macro book %d'):fmt(palette.book + 1));
            mgr:QueueCommand(1, ('/macro set %d'):fmt(otherSet + 1));
            mgr:QueueCommand(1, ('/macro set %d'):fmt(palette.set + 1));
        end);
    end

    if (macrolib == nil) then
        return false;
    end

    return pcall(function ()
        macrolib.set_book(otherBook);
        macrolib.set_book(palette.book);
        macrolib.set_page(otherSet);
        macrolib.set_page(palette.set);
    end);
end

--[[
* Human-facing numbering. The client counts books and sets from zero; the macro
* menu counts them from one.
--]]
local function describe(palette)
    if (palette == nil) then
        return 'nothing yet';
    end

    return ('book %d, set %d'):fmt(palette.book + 1, palette.set + 1);
end

--[[
* Measure the palette, spending one budget of attempts per arming and conceding
* only once the session ceiling is reached. Once the measurement is done this is
* a single comparison per frame; once it has given up it is the same.
--]]
local function ensureMeasured()
    if (state.gaveUp or (state.bookOffset ~= nil and state.page ~= nil)) then
        return;
    end

    -- This arming's budget is spent. Wait for the next zone line, which re-arms
    -- with a client that has just rebuilt its macro state.
    if (state.attempts >= MEASURE_RETRIES) then
        return;
    end

    local now = os.clock();

    -- Let the client finish building the palette before touching it, and space
    -- the retries out rather than re-probing every frame.
    if (state.nextTry == 0) then
        state.nextTry = now + MEASURE_SETTLE;
        return;
    end

    if (now < state.nextTry) then
        return;
    end

    -- No container yet is not an attempt, but it must still cost a wait, or a
    -- client that is slow to build one is probed sixty times a second.
    local obj = container();

    if (obj == 0) then
        state.nextTry = now + MEASURE_RETRY_INTERVAL;
        return;
    end

    state.attempts = state.attempts + 1;
    state.total    = state.total + 1;
    state.nextTry  = now + MEASURE_RETRY_INTERVAL;

    -- Whether there is anything left to try after this, ever. Everything below
    -- reports a failure only then; otherwise it goes quiet and waits.
    local final = state.total >= MEASURE_MAX_ATTEMPTS;

    -- Note that this does not throw the book offset away. Nothing keys off it
    -- alone -- every gate below wants both halves -- and keeping it is what lets
    -- `/dwmacro debug` distinguish "the book field was never found" from "the
    -- book field was found and the set field was not", which are the same
    -- silence from the outside and want completely different answers.
    local function giveUp(message)
        state.page = nil;

        if (final) then
            state.gaveUp = true;
            print(chat.header(addon.name):append(chat.error(message)));
            print(chat.header(addon.name):append(chat.message('Your macro palette is untouched; /macro book and /macro set work as normal.')));
        end
    end

    state.bookOffset = findBookOffset();

    if (state.bookOffset == nil) then
        state.scan = { error = 'no book field' };

        giveUp('Could not locate the macro book field in this client. Macro sets will not be remembered.');
        return;
    end

    local ok, result = pcall(measurePageField, obj, state.bookOffset);

    if (not ok or type(result) ~= 'table') then
        state.scan = { error = tostring(result) };

        giveUp('Could not read this client\'s macro palette. Macro sets will not be remembered.');
        return;
    end

    state.scan = { seeded = result.seeded, survivors = result.survivors, chosen = result.chosen };

    if (result.chosen == nil) then
        giveUp('Could not identify the macro set field in this client. Macro sets will not be remembered.');
        return;
    end

    state.page = result.chosen;
end

--[[
* Forget what the last few polls saw. Called whenever the palette is about to be
* moved by something that is not the player -- a zone line, a repair -- so that
* the reading taken before it can never be half of an agreeing pair with the one
* taken after.
--]]
local function forgetSeen()
    state.lastSeen = nil;
    state.agreed   = 0;
end

--[[
* Record the palette against the job currently being played -- both which book
* and set it is, and what the twenty records loaded there look like.
*
* The fingerprint is the half that matters after the next zone line, and it is
* taken HERE, while the player is sitting on their own choice playing normally,
* because that is the only moment the bar is known to be right. It also tracks
* macro edits for free: change a macro and the fingerprint moves within a poll
* or two, so what gets checked after the next zone is what the page actually
* looks like now rather than what it looked like when the set was first picked.
*
* A selection has to read the same RECORD_AGREE polls running before it is
* written down, fingerprint included. The palette is moved by the client and by
* this addon as well as by the player, and a single reading taken while it is in
* motion is not a choice; the settling window keeps the worst of that out (see
* `tick`) and this is the cheap guard against everything else.
--]]
local function record()
    local job = mainJob();

    if (job == 0) then
        forgetSeen();
        return;
    end

    local palette = readPalette();

    if (palette == nil) then
        forgetSeen();
        return;
    end

    local obj   = container();
    local known = jobsTable()[job];
    local fp    = nil;

    --[[
    * THE FIELDS AND THE BAR ARE ONLY WRITTEN DOWN AS A PAIR ONCE SOMETHING HAS
    * SHOWN THEY DESCRIBE THE SAME PAGE (see state.trustBar). Straight after a
    * zone line they need not: that disagreement is the bug this addon exists
    * for, and filing the bar the client left behind under the label the field
    * still carries teaches the NEXT zone line that the wrong page is the right
    * one -- after which the repair never fires for this job again.
    *
    * TWO proofs are accepted here, and the first of them is new in 2.2.0.
    *
    *   * The bar IS the page remembered for this job -- same book, same set,
    *     same fingerprint. Three equalities, and they can only all hold when
    *     the records and the fields describe one page, because the remembered
    *     triple was itself written under proof. This is the same question
    *     restoreWindow asks after a repair, asked without one.
    *
    *   * The fields have MOVED off what the settling window left them on.
    *     Nothing but the client's own loader can move them, and running the
    *     loader is exactly what re-pairs the records with the field.
    *
    * (A third, a verified fingerprint, is stamped in restoreWindow itself.)
    *
    * WHY THE FIRST ONE HAD TO EXIST. `trustBar` used to start TRUE on the
    * argument that an addon loaded mid-session is looking at a container the
    * player has been playing on -- which is true right up until the load
    * happens inside the settling window. `/addon load dwmacro` is what the
    * server's own `!addons` list tells players to type, and a load in the ten
    * seconds after a zone line met exactly the disagreement this licence
    * exists for, with the licence granted. It filed book 1's bar under book
    * 5's label and turned the feature off for that job for good, in silence.
    * Starting FALSE closes that, and the triple above is what keeps the
    * ordinary mid-session load working: the player is sitting on their
    * remembered palette, so the proof lands on the first poll.
    --]]
    if (not state.trustBar) then
        local proved = false;

        if (known ~= nil and known.fp ~= nil
            and known.book == palette.book and known.set == palette.set) then
            fp     = fingerprint(obj);
            proved = (fp ~= nil and fp == known.fp);
        end

        if (not proved) then
            if (state.baseline == nil) then
                state.baseline = { book = palette.book, set = palette.set };
            end

            if (state.baseline.book == palette.book and state.baseline.set == palette.set) then
                forgetSeen();
                return;
            end
        end

        state.trustBar = true;
    end

    if (fp == nil) then
        fp = fingerprint(obj);
    end

    -- A failed read is not an observation. Two consecutive nil reads agree
    -- with each other (nil == nil), reach the write below, and REPLACE a
    -- job's remembered fingerprint with nothing -- silently degrading every
    -- later restore to the unverifiable text channel. Same guard shape as
    -- readPalette's above.
    if (fp == nil) then
        forgetSeen();
        return;
    end

    --[[
    * THE PAGE THE CLIENT FELL BACK TO ON THIS ZONE LINE IS NEVER RECORDED
    * UNDER ANOTHER PAGE'S LABEL (2.2.0).
    *
    * The settling window is fifteen seconds because that straddles every late
    * macro rebuild anyone here has seen -- but "has seen" is one observation
    * (2026-08-07, about six seconds), and a rebuild that lands after the
    * window closes finds the recorder live and trustBar already granted by a
    * verified repair. It would then file the clobbered bar under the fields'
    * label, which is the permanent silent failure this whole file is built to
    * avoid.
    *
    * There is a real signature to test against rather than a longer timer.
    * When the window's FIRST look found the bar wrong, the fingerprint it saw
    * is the page the client falls back to -- and any later reading equal to it
    * is that same fall-back, not a choice. The one honest exception is the
    * player genuinely sitting on the fall-back page, which the container
    * FIELDS say plainly: book 0, set 0. So the refusal is "this bar, under
    * fields that name a different page", which cannot be true of anything the
    * player did.
    *
    * AND IT REFUSES RATHER THAN REPAIRING, deliberately. The signature is two
    * hashes over the loaded page, so the one way it can be wrong is a player
    * whose remembered book holds a byte-identical COPY of book 1, set 1 --
    * which is a thing people do. Refusing to write costs them a silent,
    * self-correcting nothing; repairing would move a palette they had just
    * chosen, in front of them, which is the one behaviour this addon must
    * never have. `/dwmacro remember` is the door for the player who knows the
    * bar is right.
    --]]
    if (state.clobberFp ~= nil and fp == state.clobberFp
        and not (palette.book == 0 and palette.set == 0)) then
        forgetSeen();
        return;
    end

    local seen = state.lastSeen;

    if (seen ~= nil and seen.job == job and seen.book == palette.book
        and seen.set == palette.set and seen.fp == fp) then
        state.agreed = state.agreed + 1;
    else
        state.agreed = 1;
    end

    state.lastSeen = { job = job, book = palette.book, set = palette.set, fp = fp };

    if (state.agreed < RECORD_AGREE) then
        return;
    end

    if (known ~= nil and known.book == palette.book and known.set == palette.set and known.fp == fp) then
        return;
    end

    jobsTable()[job] = T{ book = palette.book, set = palette.set, fp = fp };

    settings.save();
end

--[[
* Arm the watch. Called for the login packet, which the server sends both on a
* real login and on every zone line -- the two cases this addon exists for are
* the same packet.
*
* The clock starts when the player is next seen in the world, not here: the
* packet arrives while the zone screen is still up.
--]]
local function armRestore()
    state.armed     = true;
    state.zonedAt   = 0;
    state.nextCheck = 0;
    state.applies   = 0;
    state.nextApply = 0;
    state.appliedFp = nil;
    state.verified  = false;
    state.channel   = 'direct';
    state.trail     = nil;
    state.sentAt    = nil;
    state.bounced   = 0;

    -- A zone line is the one thing that puts the container fields and the
    -- macro bar out of step, so it is the one thing that withdraws the
    -- recorder's licence to write them down together (see state.trustBar).
    state.trustBar  = false;
    state.baseline  = nil;

    -- The fall-back page is a fact about the zone line that just happened, so
    -- the previous one's signature is dropped with it rather than left to
    -- refuse a reading it has nothing to do with.
    state.clobberFp = nil;

    forgetSeen();

    -- A zone line rebuilds the client's macro state, so if the palette still has
    -- not been measured this is a fresh chance at it -- and a better one than the
    -- frame that just failed. A fresh budget with it: the failure that matters is
    -- a client that cannot be read at all, not a login that was busy.
    if (not state.gaveUp and (state.bookOffset == nil or state.page == nil)) then
        state.attempts = 0;
        state.nextTry  = 0;
    end
end

--[[
* One look at the macro bar, and a repair if it is wrong. Returns whether the
* settling window is still open; while it is, recording is off (see `tick`).
*
* `apply` is the enabled flag, and it silences the repairs WITHOUT shortening
* the window. Turning the feature off does not stop the client losing the
* palette on a zone line, and this addon's promise while it is off is that the
* palette is still remembered so that turning it back on picks up where it left
* off -- which it would not, if the first thing recorded after every zone were
* the client's own Book 1, Set 1.
*
* NOTHING IN HERE FIRES ON A CLOCK. The window is a watch, not a schedule: the
* only thing that makes a repair happen is the bar being wrong, and the only
* thing that makes it stop is the bar being right. That is why the client's
* late rebuild -- six seconds after the party list went live, on the client
* this was diagnosed against -- is no longer something to be straddled by
* guesswork. It clobbers the palette, the next check sees the fingerprint move,
* and it is put back.
--]]
local function restoreWindow(now, apply)
    local since = now - state.zonedAt;

    if (since >= RECORD_HOLD) then
        return false;
    end

    if (not apply or now < state.nextCheck) then
        return true;
    end

    state.nextCheck = now + CHECK_INTERVAL;

    local job = mainJob();

    if (job == 0) then
        return true;
    end

    local wanted = jobsTable()[job];

    -- Nothing remembered for this job is not a failure, it is the first time
    -- this job has been played. Leave the palette completely alone and let the
    -- recorder learn it once the window closes.
    if (wanted == nil or wanted.book == nil or wanted.set == nil) then
        state.trail = { job = job, skipped = 'nothing remembered for this job' };
        return true;
    end

    local obj = container();

    -- No container yet means the client has not built one, which is not the
    -- same as the bar being wrong. Wait; the window is long enough.
    if (obj == 0) then
        return true;
    end

    local fp = fingerprint(obj);

    -- The fingerprint the last repair left behind, sampled once it has had time
    -- to land. It is what stands in for a remembered fingerprint when there is
    -- none: it cannot say whether the bar is RIGHT, but it can say whether
    -- anything has moved it since, which is all that is needed to notice the
    -- client's late rebuild.
    if (state.applies > 0 and state.appliedFp == nil and now >= state.nextApply) then
        state.appliedFp = fp;
    end

    local target = wanted.fp or state.appliedFp;

    if (target ~= nil and fp ~= nil and fp == target) then
        if (wanted.fp ~= nil) then
            state.verified = true;

            -- The bar has been READ and agrees with what was remembered for
            -- this palette, which is the only positive proof this addon can
            -- get that the records and the fields describe the same page --
            -- so the recorder is allowed to write them down as a pair again.
            state.trustBar = true;
        end

        return true;
    end

    --[[
    * The bar is wrong, this is the first look of the window, and there is a
    * remembered fingerprint to have judged it against -- so what is on screen
    * right now is the page the client fell back to, read from the bytes the
    * bar is drawn from. `record()` refuses that fingerprint for the rest of
    * the session under fields that name a different page, which is what stops
    * a rebuild arriving after this window closes from being written down as a
    * choice. `state.applies == 0` is load-bearing: after a repair has gone out
    * the live bar is this addon's work, not the client's fall-back.
    --]]
    if (state.clobberFp == nil and state.applies == 0
        and wanted.fp ~= nil and fp ~= nil and fp ~= wanted.fp) then
        state.clobberFp = fp;
    end

    if (now < state.nextApply or state.applies >= MAX_APPLIES) then
        return true;
    end

    --[[
    * Which mechanism to repair with. Direct calls unless they cannot be
    * checked (no remembered fingerprint) or have been checked and found
    * wanting (DIRECT_TRIES repairs and the bar still has not come right). The
    * fallback is one-way for the rest of the window: a channel that has failed
    * twice is not worth going back to.
    --]]
    if (wanted.fp == nil or (state.applies >= DIRECT_TRIES and not state.verified)) then
        state.channel = 'text';
    end

    -- The watcher and the trail are armed BEFORE the send: the client answers a
    -- rejected command on its own schedule, and an answer that arrives before
    -- the bookkeeping exists would be neither swallowed nor counted. Only the
    -- typed channel can bounce, so only it arms the watcher.
    if (state.channel == 'text') then
        state.sentAt = now;
    end

    state.trail = {
        job     = job,
        wanted  = wanted,
        channel = state.channel,
        before  = (state.trail ~= nil and state.trail.before) or readPalette(),
    };

    state.trail.ok = applyPalette(wanted, state.channel);

    state.applies   = state.applies + 1;
    state.nextApply = now + APPLY_SETTLE;
    state.appliedFp = nil;

    -- The palette has just been moved by this addon, so nothing read across it
    -- is a choice the player made.
    forgetSeen();

    return true;
end

--[[
* Put every clock this addon keeps back to now.
*
* THE CLOCK CAN GO BACKWARDS. On Windows `os.clock()` is milliseconds in a
* 32-bit long, so it wraps to negative after about twenty-four and a half days
* of client uptime -- which the players who leave a client crafting or fishing
* reach. Every timer in here is a difference against it, so a jump backwards
* leaves all of them sitting in the future at once, and each one fails silently
* and differently:
*
*   * `lastPoll` closes the poll gate for ever: nothing is recorded again.
*   * `zonedAt` stops the settling window ever ending: the recorder never
*     restarts and the repair never stops looking.
*   * `sentAt` leaves the bounce watcher armed, swallowing the player's OWN
*     "A command error occurred." lines for the next twenty-five days.
*   * `forgetAllAt` leaves `/dwmacro forget all` confirmed from weeks ago, so
*     the next one commits on a single keystroke.
*
* Noticed rather than prevented, because there is nothing to prevent: one frame
* whose clock is behind the last poll restarts all of them. `zonedAt` and
* `nextTry` keep their zero, which is a sentinel and not a time.
--]]
local function resetClocks(now)
    state.lastPoll    = now;
    state.nextCheck   = now;
    state.nextApply   = now;
    state.sentAt      = nil;
    state.forgetAllAt = nil;

    if (state.zonedAt ~= 0) then
        state.zonedAt = now;
    end

    if (state.nextTry ~= 0) then
        state.nextTry = now;
    end
end

local function tick()
    local now = os.clock();

    if (now < state.lastPoll) then
        resetClocks(now);
    end

    --[[
    * THE STEADY STATE IS ONE CLOCK COMPARISON.
    *
    * Everything below this needs the world to be real, and asking that
    * question is not free: `inGame()` crosses the Lua/client boundary SEVEN
    * times (two memory managers, the player object, its login status, its
    * zoning flag, the party, the slot). At sixty frames a second that is four
    * hundred and twenty crossings every second to answer something the poll
    * below consults twice.
    *
    * So once no settling window is open, the poll clock is asked first --
    * because between polls it is the only thing that can have become true.
    * NOTHING IS SKIPPED BY THIS. Leaving the world still forgets the last
    * reading before anything is paired with it, at most half a second later
    * than it did; the pairing itself has always happened inside `record()`,
    * which only ever runs on a poll frame. And the window is deliberately not
    * covered: while `armed` is up this runs every frame, because `zonedAt`
    * has to start on the FIRST frame the player is in the world.
    --]]
    if (not state.armed and (now - state.lastPoll) < POLL_INTERVAL) then
        return;
    end

    -- Out of the world -- a zone screen, character select -- the palette is not
    -- the player's and the readings either side of the gap are not a pair.
    if (not inGame()) then
        forgetSeen();
        return;
    end

    ensureMeasured();

    --[[
    * The repair runs whether or not the measurement has succeeded. What to put
    * back comes from the settings file, and checking it needs only the record
    * block, whose layout comes from the client's own stride rather than from
    * anything measured. Gating the repair on the measurement meant a client
    * whose set field could not be found lost the book repair too, which needs
    * nothing measured at all, and lost it silently.
    --]]
    if (state.armed) then
        -- The clock starts on the first frame the player is actually in the
        -- world -- inGame() includes the client's own zoning flag, so "in the
        -- world" is the client's word for it, not the party list's.
        if (state.zonedAt == 0) then
            state.zonedAt = now;
        end

        -- Recording stays shut off for the whole window, so the client's
        -- post-zone default is never mistaken for a choice -- whether or not
        -- repairing is the thing putting it right.
        if (restoreWindow(now, config.enabled)) then
            return;
        end

        state.armed = false;

        -- Every repair has landed (or bounced); what the fields say now is the
        -- honest "after" for `/dwmacro debug`.
        if (state.trail ~= nil and state.trail.skipped == nil) then
            state.trail.after = readPalette();
        end
    end

    if ((now - state.lastPoll) < POLL_INTERVAL) then
        return;
    end

    -- STAMPED BEFORE THE MEASUREMENT IS CONSULTED, not after. The gate at the
    -- top of this function rides `lastPoll`, and a client whose set field can
    -- never be found returns below without ever reaching a stamp -- so the gate
    -- would never close for it and every frame would go back to paying for
    -- `inGame()`, which is the one case that most wants the saving.
    state.lastPoll = now;

    -- Recording, unlike repairing, has nothing without the measurement: it
    -- exists to READ what the player picked.
    if (state.bookOffset == nil or state.page == nil) then
        return;
    end

    record();
end

--[[
* Everything above runs once a frame, which is the reason for the pcall: an
* error raised inside `d3d_present` is raised sixty times a second, and the
* addon host answers a long enough run of them by unloading the addon. One bad
* frame costs one line of chat and the feature, not the addon -- and the
* feature going quiet leaves a completely normal macro palette behind.
--]]
local failed   = false;
local failures = 0;

--[[
* How many raised frames the feature survives before it is given up on for the
* session.
*
* Stopping on the first one is right and stays: an error inside `d3d_present`
* is an error sixty times a second. Stopping FOR GOOD was not. Almost
* everything this addon reads is client state that a zone line rebuilds -- the
* macro container, the palette, the party slot -- so a raise out of a half-built
* or half-torn-down one is answered by the very next zone line, and refusing to
* look again cost the player the feature for the rest of the session over a
* frame that had already fixed itself. So a zone line un-stops it, and the
* ceiling is what keeps that from becoming a client probed for ever: the second
* failure is final, and the sentence printed beside it says which of the two
* has just happened.
--]]
local MAX_FAILURES = 2;

ashita.events.register('d3d_present', 'dwmacro_present', function ()
    if (macrolib == nil or failed) then
        return;
    end

    local ok, err = pcall(tick);

    if (not ok) then
        failed   = true;
        failures = failures + 1;

        print(chat.header(addon.name):append(chat.error('Stopped after an error: ' .. tostring(err))));

        if (failures >= MAX_FAILURES) then
            print(chat.header(addon.name):append(chat.message('Your macro palette is untouched; /macro book and /macro set work as normal.')));
        else
            print(chat.header(addon.name):append(chat.message('Your macro palette is untouched. It looks again after the next zone line.')));
        end
    end
end);

--[[
* The login packet. The client's macro state does not survive it, and it is
* sent for a zone line as well as a login, so this one hook covers both cases.
--]]
ashita.events.register('packet_in', 'dwmacro_zonein', function (e)
    if (e.id ~= 0x000A) then
        return;
    end

    -- A zone line rebuilds every piece of client state a raise in `tick` can
    -- have come out of, so it is worth one more look -- a bounded number of
    -- times (see MAX_FAILURES).
    if (failed and failures < MAX_FAILURES) then
        failed = false;

        print(chat.header(addon.name):append(chat.message('Looking at the macro palette again after the zone line.')));
    end

    armRestore();
end);

--[[
* The bounce watcher, for the typed fallback only. A `/macro` command handed to
* a client that is not ready to take input comes back as one "A command error
* occurred." line per command, and nothing happens -- the repair never landed.
* Inside a short window after this addon's own send, that line is this addon's
* plumbing: it is swallowed so the player stops seeing unexplained errors, and
* counted so `/dwmacro debug` can tell a rejected repair from one that ran. No
* control flow hangs off it -- the next check was always going to notice.
*
* `sentAt` is only ever set by the typed channel, so while the direct calls are
* doing the work this handler is one nil-check deep and touches nothing: the
* player's own command errors remain the player's.
--]]
ashita.events.register('text_in', 'dwmacro_text_in', function (e)
    if (state.sentAt == nil or e.blocked) then
        return;
    end

    if (os.clock() - state.sentAt > BOUNCE_WINDOW) then
        state.sentAt = nil;
        return;
    end

    local line = e.message;

    if (type(line) ~= 'string') then
        return;
    end

    --[[
    * WHO WROTE IT, BEFORE WHAT IT SAYS (2.2.1). See PLAYER_CHAT_MODES: a line
    * on a mode a player speaks on is a line somebody typed, whatever sentence
    * it carries, and blocking one is eating another player's chat. Packed
    * mode, so the id is the low byte; ABSENT is not player chat -- the refusal
    * list only ever refuses a number actually present, because a missing mode
    * is what the harness's own client emits and losing the swallow is the
    * failure this handler exists to prevent.
    --]]
    local mode = e.mode_modified or e.mode;

    if (mode ~= nil and PLAYER_CHAT_MODES[bit.band(mode, 0xFF)]) then
        return;
    end

    --[[
    * WHAT ARRIVES HERE IS NOT WHAT THE CLIENT EMITTED. Every other addon on
    * the machine has had this line first, and the marks they leave are TWO
    * bytes wide -- a control byte and an argument byte that is very often an
    * ordinary letter or digit (dwquest's plainText carries the full autopsy).
    * Strip only the control byte and the argument sits in the middle of a
    * word, which is exactly enough to make a substring test miss: the player
    * then reads four unexplained "A command error occurred." lines for every
    * bounced repair, which is the residue this handler exists to remove.
    *
    * So the tags go as PAIRS first -- `\30`/`\31` are the colour tags Ashita's
    * chat library writes, `\127` is the client's end-of-message marker, and
    * `\239` leads the auto-translate brackets, whose argument bytes are a
    * printable quote and parenthesis -- and the blanket pass takes everything
    * else that cannot be drawn, including a tag byte with no argument left.
    --]]
    local clean = line:gsub('[\030\031\127\239].', '');

    clean = clean:gsub('[^\032-\126]', '');

    if (clean:find(BOUNCE_MARK, 1, true) ~= nil) then
        e.blocked     = true;
        state.bounced = state.bounced + 1;

        if (state.trail ~= nil) then
            state.trail.bounced = (state.trail.bounced or 0) + 1;
        end
    end
end);

--[[
* What the measurement saw, and what the last zone line did. This exists because
* every way this addon can fail quietly looks identical from the outside -- no
* set field found, several found and none confirmed, the container never
* readable -- and they want different answers.
--]]
local function printDebug()
    print(chat.header(addon.name):append(chat.message(('macros lib: %s   container: 0x%08X'):fmt(macrolib ~= nil and 'loaded' or 'MISSING', container()))));
    print(chat.header(addon.name):append(chat.message(('book offset: %s   attempts: %d this zone, %d of %d this session'):fmt(
        state.bookOffset ~= nil and ('0x%04X'):fmt(state.bookOffset) or 'unknown',
        state.attempts, state.total, MEASURE_MAX_ATTEMPTS))));

    if (state.page ~= nil) then
        local obj = container();
        local raw = 'unreadable';

        if (obj ~= 0) then
            local ok, value = pcall(ashita.memory.read_uint8, obj + state.page.offset);

            if (ok) then
                raw = tostring(value);
            end
        end

        print(chat.header(addon.name):append(chat.message(('set field: 0x%04X (%+d from book), encoding %s, reads %s'):fmt(
            state.page.offset, state.page.offset - state.bookOffset, state.page.enc.name, raw))));
    else
        print(chat.header(addon.name):append(chat.message('set field: not identified')));
    end

    if (state.scan == nil) then
        print(chat.header(addon.name):append(chat.message('last scan: has not run yet')));
    elseif (state.scan.error ~= nil) then
        print(chat.header(addon.name):append(chat.message('last scan: failed -- ' .. state.scan.error)));
    else
        print(chat.header(addon.name):append(chat.message(('last scan: %d candidate(s) seeded, %d confirmed'):fmt(state.scan.seeded or 0, state.scan.survivors or 0))));
    end

    --[[
    * The bar, as opposed to what the client claims about it. `live` is what the
    * twenty loaded records hash to right now and `remembered` is what they
    * hashed to when the player was last sitting on their own choice; the two
    * agreeing is the addon's whole definition of "the palette is right", so it
    * is the first thing to look at when it is not.
    --]]
    local job        = mainJob();
    local remembered = (job ~= 0) and jobsTable()[job] or nil;

    print(chat.header(addon.name):append(chat.message(('macro bar: live %s, remembered %s%s'):fmt(
        fingerprint(container()) or 'unreadable',
        (remembered ~= nil and remembered.fp) or 'nothing yet',
        state.verified and ' (matched this zone)' or ''))));

    -- Whether the recorder is allowed to write at all, which is a silence with
    -- a cause worth naming: since the zone line the fields and the bar have
    -- not been shown to describe the same page, so what is remembered stands
    -- rather than being replaced by a pair that may not belong together.
    if (not state.trustBar) then
        print(chat.header(addon.name):append(chat.message(
            'recording: HELD -- the bar has not been shown to match the container fields since the zone line. Change book or set once (or let a repair verify) and it resumes.')));
    end

    -- The OTHER silence with a cause worth naming, and it outlives the window:
    -- the page the client fell back to on this zone line is refused by the
    -- recorder for the rest of the session under any other book and set, so a
    -- late rebuild cannot be learned as a choice. Printed with the value so a
    -- "why is this not being written down" question can be answered by
    -- comparing it against the live line above.
    if (state.clobberFp ~= nil) then
        print(chat.header(addon.name):append(chat.message(
            ('fall-back page: %s -- this zone line lost the bar, and that fingerprint is refused as a choice from here on.'):fmt(state.clobberFp))));
    end

    --[[
    * What the last zone line did. A repair that ran and did not show up on
    * screen, a repair that never ran because nothing was remembered, and a zone
    * line the addon never noticed are three different faults that look
    * identical from the player's chair, so all three are named here.
    --]]
    if (state.trail == nil) then
        if (state.armed) then
            print(chat.header(addon.name):append(chat.message('last zone: settling, the bar has not needed putting back yet')));
        else
            print(chat.header(addon.name):append(chat.message('last zone: nothing needed putting back')));
        end
    elseif (state.trail.skipped ~= nil) then
        print(chat.header(addon.name):append(chat.message(('last zone: left alone -- %s'):fmt(state.trail.skipped))));
    else
        --[[
        * The two channels are not described in the same words on purpose. A
        * direct repair calls and is done; a typed one hands four lines to a
        * parser that may refuse them, so a bounce count is a fact worth
        * printing there and noise everywhere else. Saying "queueing ok, 0
        * command(s) bounced" under `setBook/setPage calls` -- which is what
        * 2.0 shipped with, and what the first in-game run printed -- describes
        * a mechanism that was not used.
        --]]
        local typed = state.trail.channel == 'text';
        local ran   = state.trail.ok and 'ok' or 'FAILED';

        print(chat.header(addon.name):append(chat.message(('last zone: put back %s via %s (read %s before, %s after, %s)'):fmt(
            describe(state.trail.wanted),
            typed and '/macro commands' or 'setBook/setPage calls',
            describe(state.trail.before),
            describe(state.trail.after),
            typed and ('typing %s, %d command(s) bounced'):fmt(ran, state.bounced)
                  or ('calling %s'):fmt(ran)))));
        print(chat.header(addon.name):append(chat.message(('%d of %d repair(s) used; the before/after reads are the container fields, which lie after a zone -- the macro bar line above is the one that counts.'):fmt(state.applies, MAX_APPLIES))));
    end
end

--[[
* Every job remembered on this character, packed several to a line.
*
* The status line only ever answers for the job being played, so before 2.2.0
* there was no way to see what `forget` was about to throw away -- or to notice
* that a job had never been learned at all. Twenty-two jobs is twenty-two lines
* of chat log for a question that fits in four, so the entries are packed.
--]]
local function printList()
    local jobs = jobsTable();
    local ids  = { };

    for job, entry in pairs(jobs) do
        if (type(job) == 'number' and type(entry) == 'table'
            and entry.book ~= nil and entry.set ~= nil) then
            ids[#ids + 1] = job;
        end
    end

    if (#ids == 0) then
        print(chat.header(addon.name):append(chat.message('Nothing is remembered on this character yet. Sit on the book and set you want for a job and it is written down within a second.')));
        return;
    end

    table.sort(ids);

    local lines = { };
    local line  = '';

    for index = 1, #ids do
        local entry = jobs[ids[index]];
        local piece = ('%s %d/%d'):fmt(JOB_NAMES[ids[index]] or ('job ' .. tostring(ids[index])), entry.book + 1, entry.set + 1);

        if (line == '') then
            line = piece;
        elseif ((#line + #piece + 3) > 100) then
            lines[#lines + 1] = line;
            line = piece;
        else
            line = line .. '   ' .. piece;
        end
    end

    lines[#lines + 1] = line;

    print(chat.header(addon.name):append(chat.message(('Remembered on this character (%d job(s)), as book/set in the macro menu\'s own numbering:'):fmt(#ids))));

    for index = 1, #lines do
        print(chat.header(addon.name):append(chat.message(lines[index])));
    end
end

--[[
* Take the palette on screen as the truth for this job -- by MAKING it true.
*
* The recorder holds after any zone line it could not verify: the fields and
* the bar have not been shown to describe one page, and writing them down
* together in that state is the permanent silent failure the whole file is
* built around. The way out is to run the client's own loader, because running
* it is what re-pairs the records with the field, and `/dwmacro debug` already
* says so in words ("change book or set once"). This is the same thing without
* leaving the keyboard.
*
* IT PROVES THE LOADER RAN rather than assuming it. The book field is read back
* after the first transition; a client whose direct calls do nothing is exactly
* the client the typed channel exists for, and on that one this says so instead
* of stamping a licence it did not earn.
*
* The fall-back signature is cleared with it: the loader has just re-read the
* page from the book the field names, which is stronger evidence than a
* fingerprint match could be.
--]]
local function rememberNow()
    if (macrolib == nil) then
        print(chat.header(addon.name):append(chat.error('Ashita\'s macro library did not load on this client, so there is no loader to drive.')));
        return;
    end

    -- The palette would be moved and nothing would come of it: the recorder
    -- this hands the licence to is not running.
    if (failed) then
        print(chat.header(addon.name):append(chat.error('Stopped after an error earlier this session, so nothing would be written down. /dwmacro says what to do about that.')));
        return;
    end

    local current = readPalette();

    if (current == nil) then
        print(chat.header(addon.name):append(chat.error('The macro palette has not been read yet, so there is nothing to write down. /dwmacro debug says what the scan saw.')));
        return;
    end

    if (container() == 0) then
        print(chat.header(addon.name):append(chat.error('The client has no macro container right now. Try again once you are standing in the world.')));
        return;
    end

    local other = (current.book + 1) % (MAX_BOOK + 1);

    if (not pcall(macrolib.set_book, other)) then
        print(chat.header(addon.name):append(chat.error('The client refused the macro call; nothing was changed.')));
        return;
    end

    -- The proof, taken between the transition and the way back.
    local moved = readPalette();

    pcall(macrolib.set_book, current.book);
    pcall(macrolib.set_page, (current.set + 1) % (MAX_SET + 1));
    pcall(macrolib.set_page, current.set);

    -- The palette has just been driven by this addon, so no reading taken
    -- across it is a choice the player made.
    forgetSeen();

    if (moved == nil or moved.book ~= other) then
        print(chat.header(addon.name):append(chat.error('The client did not follow the macro call, so nothing has been written down -- your palette is back where it was. A zone line repairs it the other way round.')));
        return;
    end

    state.trustBar  = true;
    state.baseline  = nil;
    state.clobberFp = nil;

    print(chat.header(addon.name):append(chat.message(('Reloaded %s through the client\'s own loader, so the bar and the container fields now describe one page. It is written down within a second.'):fmt(describe(current)))));
end

--[[
* The verbs, named. `/dwmacro` printed a status page for every one of them,
* including the ones it does not have, so a typo looked exactly like a
* success.
--]]
local function printHelp()
    print(chat.header(addon.name):append(chat.message('/dwmacro -- what it measured, and what it remembers for the job you are on.')));
    print(chat.header(addon.name):append(chat.message('/dwmacro on | off -- put the palette back after a zone line, or leave it. Either way it keeps remembering, so turning it back on picks up where it left off.')));
    print(chat.header(addon.name):append(chat.message('/dwmacro list -- every job remembered on this character.')));
    print(chat.header(addon.name):append(chat.message('/dwmacro remember -- take the palette you are looking at as this job\'s, when /dwmacro debug says recording is held.')));
    print(chat.header(addon.name):append(chat.message('/dwmacro forget -- forget the job you are on (it is learned again straight away). /dwmacro forget all -- forget the whole character, and it asks twice.')));
    print(chat.header(addon.name):append(chat.message('/dwmacro debug -- what the palette scan saw, and what the last zone line actually did.')));
end

ashita.events.register('command', 'dwmacro_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/DWMacro`
    -- matched nothing. (Stock Ashita tests with `:any()`, which lowercases
    -- both sides.) `first` is used for the pass-through tests below as well,
    -- so `/MACRO book 5` is still recognised as the CLIENT's command and
    -- handed straight back to it, exactly as `/macro book 5` is.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwmacro' and first ~= '/macro') then
        return;
    end

    local verb = (#args > 1) and args[2]:lower() or 'status';

    --[[
    * /macro IS A RETAIL CLIENT COMMAND, and this addon's whole contract is
    * that `/macro book <n>` and `/macro set <n>` keep working exactly as they
    * always did (see the header). So the alias only claims the verbs dwmacro
    * itself owns and hands anything else straight back to the client --
    * blocking an unknown verb here would eat a client feature this addon has
    * promised not to touch. `debug` is deliberately not on that list; it is a
    * /dwmacro verb only.
    --]]
    if (first == '/macro' and verb ~= 'status' and verb ~= 'on' and verb ~= 'off' and verb ~= 'forget') then
        return;
    end

    -- Bare `/macro` is the client's, too: the status default above quietly
    -- claimed one more token than the list the comment promises. Only bare
    -- `/dwmacro` means "status".
    if (first == '/macro' and #args == 1) then
        return;
    end

    e.blocked = true;

    if (verb == 'on' or verb == 'off') then
        config.enabled = (verb == 'on');
        settings.save();

        print(chat.header(addon.name):append(chat.message('Putting your palette back is now ')):append(chat.success(verb)):append(chat.message('.')));
        return;
    end

    if (verb == 'forget') then
        local scope = (#args > 2) and args[3]:lower() or '';

        if (scope == 'all') then
            local now = os.clock();

            -- Staged, then committed. See FORGET_CONFIRM: this is the one verb
            -- here whose damage cannot be undone by waiting.
            if (state.forgetAllAt == nil or (now - state.forgetAllAt) > FORGET_CONFIRM) then
                state.forgetAllAt = now;

                print(chat.header(addon.name):append(chat.message(('That clears every job remembered on this character, not just the one you are on. Type /dwmacro forget all again within %d seconds to confirm.'):fmt(FORGET_CONFIRM))));
                return;
            end

            state.forgetAllAt = nil;
            config.jobs       = T{ };
            settings.save();
            forgetSeen();

            print(chat.header(addon.name):append(chat.message('Forgot every remembered macro book and set on this character.')));
            return;
        end

        if (scope ~= '') then
            print(chat.header(addon.name):append(chat.error(('Unknown: forget %s. /dwmacro forget clears the job you are on; /dwmacro forget all clears the character.'):fmt(args[3]))));
            return;
        end

        --[[
        * BARE `forget` IS THE JOB YOU ARE ON (2.2.0). It used to wipe the
        * whole character with no confirmation and no undo, on the one word a
        * player reaches for when a single job's entry has gone wrong -- which
        * is the only reason anybody types it. The narrow one is also the safe
        * one: the recorder writes this job down again within a poll or two,
        * because the player is sitting on the palette they want while they
        * type. Everything wider now goes through `forget all`, twice.
        --]]
        local job = mainJob();

        if (job == 0) then
            print(chat.header(addon.name):append(chat.error('There is no job to forget yet -- you are not in the world.')));
            return;
        end

        local jobs = jobsTable();

        if (jobs[job] == nil) then
            print(chat.header(addon.name):append(chat.message(('Nothing was remembered for %s. /dwmacro forget all clears every job on this character.'):fmt(JOB_NAMES[job] or 'this job'))));
            return;
        end

        jobs[job] = nil;
        settings.save();

        -- The recorder is about to write this job down again from the palette
        -- the player is sitting on, and a reading taken before the entry
        -- vanished must not be half of the agreeing pair that does it.
        forgetSeen();

        print(chat.header(addon.name):append(chat.message(('Forgot the macro book and set remembered for %s -- it is learned again from wherever you are sitting now. /dwmacro forget all clears every job.'):fmt(JOB_NAMES[job] or 'this job'))));
        return;
    end

    if (verb == 'list') then
        printList();
        return;
    end

    if (verb == 'remember') then
        rememberNow();
        return;
    end

    if (verb == 'help') then
        printHelp();
        return;
    end

    if (verb == 'debug') then
        printDebug();
        return;
    end

    --[[
    * An unknown verb is NAMED rather than quietly answered with the status
    * page. `/dwmacro` owns everything past its own name -- the `/macro` alias
    * handed the client's verbs back above -- so a typo used to print a status
    * page and look exactly like a verb that had worked.
    --]]
    if (verb ~= 'status') then
        print(chat.header(addon.name):append(chat.error(('Unknown: %s. Try /dwmacro help.'):fmt(args[2]))));
        return;
    end

    -- Status. Says what it measured as well as what it remembers, because
    -- "nothing happens" has two causes and they need different answers.
    if (macrolib == nil) then
        print(chat.header(addon.name):append(chat.error("Ashita's macro library did not load; nothing is being remembered.")));
        return;
    end

    if (failed) then
        print(chat.header(addon.name):append(chat.error('Stopped after an error earlier this session; nothing is being remembered.')));

        if (failures < MAX_FAILURES) then
            print(chat.header(addon.name):append(chat.message('It looks again after the next zone line. /addon reload dwmacro does the same thing sooner.')));
        else
            print(chat.header(addon.name):append(chat.message('It has stopped for this session. Reload with /addon reload dwmacro.')));
        end

        return;
    end

    if (state.bookOffset == nil or state.page == nil) then
        if (state.gaveUp) then
            print(chat.header(addon.name):append(chat.error('Could not read this client\'s macro palette; nothing is being remembered.')));
            print(chat.header(addon.name):append(chat.message('/dwmacro debug says what it saw.')));
        else
            print(chat.header(addon.name):append(chat.message(('Still reading the macro palette (%d attempt(s) so far). It tries again after each zone line.'):fmt(state.total))));
        end

        return;
    end

    local job     = mainJob();
    local current = readPalette();

    print(chat.header(addon.name):append(chat.message('Putting your palette back is ')):append(chat.success(config.enabled and 'on' or 'off')):append(chat.message('. Currently on ' .. describe(current) .. '.')));

    local remembered = (job ~= 0) and jobsTable()[job] or nil;

    -- Named rather than "this job". The palette is remembered per job and a
    -- job change is one of the things that moves it, so a line about "this
    -- job" is ambiguous at exactly the moment the player is most likely to be
    -- asking -- straight after changing one.
    local jobName = (job ~= 0 and JOB_NAMES[job]) or 'this job';

    if (remembered ~= nil and remembered.book ~= nil and remembered.set ~= nil) then
        print(chat.header(addon.name):append(chat.message(('Remembered for %s: %s.'):fmt(jobName, describe(remembered)))));
    else
        print(chat.header(addon.name):append(chat.message(('Nothing remembered for %s yet.'):fmt(jobName))));
    end

    -- The held recorder used to be named only by `/dwmacro debug`, which is a
    -- verb for the person who already suspects something. It is the ordinary
    -- state after any zone line this addon could not verify -- and after a
    -- mid-session load on a job it has never seen -- so the sentence belongs
    -- where the player is already looking, with the one command that ends it.
    if (not state.trustBar) then
        print(chat.header(addon.name):append(chat.message('Not writing anything down yet: since the zone line the macro bar and the container fields have not been shown to describe the same page. Change book or set once, or type /dwmacro remember.')));
    end
end);

ashita.events.register('load', 'dwmacro_load', function ()
    if (macrolib == nil) then
        print(chat.header(addon.name):append(chat.error("Ashita's macro library did not load on this client build; macro sets will not be remembered.")));
        return;
    end

    print(chat.header(addon.name):append(chat.message('Your macro book and set are remembered per job and put back when the client loses them. /dwmacro (or plain /macro) for status, /dwmacro help for the rest.')));
end);

ashita.events.register('unload', 'dwmacro_unload', function ()
    settings.save();
end);
