--[[
* DriftwoodXI -- dwnemesis
*
* Nemesis in a window: two hundred and forty famous notorious
* monsters (the Sky gods, the Sea Jailers, the Zeni monsters, the Salvage
* chariots and the classic zones' remaining names joined the first hundred
* on 2026-09-10), each fought in a
* private arena at its wild level +100 (capped for now), listed by tier with
* the fee per player, your own kills / best time / drops / Mercy meter on
* every row, a marker on each monster whose four-augment drop nobody on the
* server has claimed yet, and an Enter button per row that warps your whole
* party in. On the kill a chest stands up and every real player opens it
* once for their own roll of the monster's real drop table; gear comes with
* one to four random augments and is account-bound.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited
* whole). The roster ships inside it (roster.lua, GENERATED from the server's
* own dumps -- never edit by hand); everything that changes arrives on the
* wire as records, and every button is a real typed command (`!dwd enter 12`
* reaches exactly the dispatch `!nemesis enter 12` reaches). The server gates
* entry, charges the fee and rolls the chest; this window can never do
* anything a player cannot.
*
* TURN IT OFF AND NOTHING IS LOST. `!nemesis` (or `!nem`) does all of it
* typed, and /port or !home leave the arena from inside exactly like the
* button.
*
* SINCE 1.1.0 (2026-09-05) every sentence the server says about a run --
* "You obtain lizard skin. <Mercy 3 of 8>", the chest, the fee, the kill --
* arrives tagged `[Nemesis] ` and this addon moves it out of the battle log
* into the window addon chatter lands in (the dwquest notice shape; see the
* text_in handler at the bottom). Refresh also clears the silent latch, and
* the answer clock no longer ages while the client is zoning -- the two
* halves of "the window went dead after a fight".
*
* SINCE 1.2.0 a find box above the tabs filters every tier and the ledger by
* monster, home zone or signature drop, with an "Unclaimed only" switch --
* a hundred monsters is a list, not a menu.
*
* SINCE 1.3.0 the tab labels carry their counts (a find box across four tabs
* is unreadable without them -- nothing said which tab held the match), the
* signature drop draws the client's own item card on hover, `/nemesis lizzy`
* opens the window on that search, and the row tables reserve the footer's
* height instead of eating it. The bugs behind that release are named at
* their fixes below; the two worth reading first are THE EMPTY BOARD (a
* status envelope carrying a refusal instead of a board used to commit an
* empty one, which reads everywhere as "nine idle arenas") and THE REFUSAL
* THAT DID NOT RETIRE THE ASK (a protocol mismatch left the answer clock
* running, so the accurate "Update dwnemesis" banner was overwritten by "No
* answer from the server" five seconds later).
*
* SINCE 1.3.1 (2026-09-09) the notice reroute is an allow-list on the line's
* MODE: only a server system line (121) whose cleaned text OPENS with the
* tag is moved. A player's "[Nemesis] ..." in say, shout, yell or a linkshell
* used to be stripped of its speaker and re-printed under this header on
* every client in range -- a spoofed server notice. See NOTICE_MODE.
*
* 1.4.1 (2026-09-24): no change of this file's own. The shared dwecho.lua
* beside it now refuses to swallow a "command error occurred" line that
* arrived on a PLAYER's chat mode (say, party, tell...), so another player
* asking about the error is no longer eaten on this client -- and a changed
* byte in this folder is a new number on the content feed.
--]]

addon.name    = 'dwnemesis';
addon.author  = 'DriftwoodXI';
addon.version = '1.4.1';
addon.desc    = 'DriftwoodXI Nemesis: famous NMs at +100 in a private arena, personal chest, augmented drops.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- The roster, generated beside this file. A missing or broken copy renders
-- an honest empty board rather than a crash.
local rosterOk, roster = pcall(require, 'roster');

if (not rosterOk or type(roster) ~= 'table' or type(roster.rows) ~= 'table') then
    roster = { hash = '', rows = {} };
end

--[[
* A GENERATED FILE THAT PARSED IS NOT A GENERATED FILE THAT IS WHOLE, and the
* promise above is "an honest empty board rather than a crash". A row that
* reached this window without its `idx` used to take the window down the
* first frame it was drawn -- a nil table key is an error to WRITE where it is
* merely nil to read, and both the search haystack and the Enter button label
* are remembered per row by idx. Every field the render pass indexes or
* formats is checked once, here, and a row missing one is left out of the
* board rather than allowed to close it.
--]]
do
    local usable = { };

    for _, row in ipairs(roster.rows) do
        if (type(row) == 'table'
                and type(row.idx) == 'number' and row.idx > 0 and row.idx == math.floor(row.idx)
                and type(row.name) == 'string' and row.name ~= ''
                and type(row.sig) == 'string'
                and type(row.tier) == 'number'
                and type(row.level) == 'number'
                and type(row.sigItem) == 'number'
                and type(row.sigRate) == 'number') then
            usable[#usable + 1] = row;
        end
    end

    roster.rows = usable;
end

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line.
local DATA_SENDER = '_DWDDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

--[[
* THE NOTICE TAG. The server cannot choose a chat window (0x017 has no window
* field, and every module prints on SYSTEM_3, which the stock layout files
* with the damage numbers), so nemesis_core.lua prefixes every sentence it
* says to a player with this tag; the text_in handler below blocks the tagged
* line and print()s the sentence, which lands where addon chatter lands --
* Window 2 on the stock setup. KEEP IN SYNC WITH `NOTICE` IN
* modules/driftwoodxi/nemesis_core.lua: harness_dwnemesis.py reads both real
* files and fails when they disagree.
--]]
local NOTICE_TAG = '[Nemesis] ';

--[[
* THE NOTICE MODE (1.3.1, 2026-09-09 -- owner report: "[Nemesis] deez nuts"
* printed under this addon's header on every client in yell range). The
* reroute below used to match the tag ANYWHERE in ANY line, and a line is
* anything text_in sees -- including another player's yell. A player typing
* "[Nemesis] You obtain deez nuts -- 1 augment." had the speaker's name and
* channel thrown away and the rest re-printed as if the server had said it,
* on every client within earshot. The tag is scaffolding, not a signature.
*
* What IS a signature is the line's MODE. The server writes every module
* notice on Kind SYSTEM_3, which the client hands to text_in as mode 121 (low
* byte; customcolors.lua in the shipped Ashita bundle keys on exactly 9 and
* 121, and harness_dwquest.py proves reward lines arrive on 121). A player
* cannot choose that mode: say is 9, shout 10, yell 11, tell 12, party 13,
* linkshells 14 and 214, unity 212, assist 220/222, NPC speech 150/151
* (chatmon/rules/incoming_chat.lua, timestamp.lua). So this is an ALLOW list
* -- one mode, present -- and the tag must open the cleaned line: a system
* line that merely CONTAINS the tag (a server sentence quoting something a
* player typed) is not a notice either. A wrong number here degrades, not
* endangers: the notice falls back to the battle log, where it was before
* 1.1.0. Keep in sync with dwquest.lua's NOTICE_MODE, the same fix.
--]]
local NOTICE_MODE = 121;

--[[
* THE LITERALS THIS ADDON SHARES WITH THE SERVER AND THE WIRE DOES NOT CARRY.
* Each of these is one number or name kept in two files, which is the shape
* the notice tag's own comment above calls out as drifting silently; Part C
* of harness_dwnemesis.py therefore reads BOTH real files and fails when any
* of them disagree with modules/driftwoodxi/nemesis_core.lua. Adding one
* here means adding its check there.
--]]
local TIER_NAMES = { 'Field', 'Dungeon', 'Legend' };
local VENUE_NAMES = { 'Throne Room', 'Chamber of Oracles', 'Sacrificial Chamber' };
local MERCY_STACKS = 8;
local LEVEL_BONUS  = 100;

-- What an arena level is capped at when the board has not arrived, or when a
-- server answered a `t|` line without the ceiling field. It used to be a bare
-- `or 175` beside the arithmetic, which read as a default and was not one:
-- `terms.ceiling` of 0 is a NUMBER, so `terms ~= nil and terms.ceiling or 175`
-- answered 0 and every row on the tab drew "35 -> 0".
local DEFAULT_CEILING = 160; -- the server's LEVEL_CEILING (175 -> 160, 2026-09-12); the wire wins when it speaks

-- The roster ships inside the addon, so its size is known before the board
-- arrives; the tier totals in the tab labels are counted once here rather
-- than walked per frame.
local TIER_TOTAL = { 0, 0, 0 };

for _, row in ipairs(roster.rows) do
    if (row.tier ~= nil and TIER_TOTAL[row.tier] ~= nil) then
        TIER_TOTAL[row.tier] = TIER_TOTAL[row.tier] + 1;
    end
end

--[[
* EVERY NUMBER OFF THE WIRE COMES THROUGH HERE. `tonumber` under LuaJIT --
* which is what Ashita runs, and what Part B of the harness now runs -- answers
* for 'inf', 'nan', '0x10' and '2.5' as readily as for '7', and the drawing
* code downstream is a pile of string.format('%d'). A ledger line carrying
* 'inf' where a best time belongs used to draw the cell as
* "-9223372036854775808:-9223372036854775808", which is what %d does with a
* number it cannot represent. A field that is not a plain integer inside the
* wire's own range is not a number this window can draw, so it reads as the
* record's default and the rest of the record still lands.
--]]
local WIRE_MAX = 2147483647;

local function wireInt(text, default)
    local value = tonumber(text);

    if (value == nil
            or value ~= value                            -- nan
            or value < -WIRE_MAX or value > WIRE_MAX     -- inf, and anything absurd
            or value ~= math.floor(value)) then
        return default or 0;
    end

    return value;
end

local state = T{
    open      = T{ false },

    -- The board, COMMITTED ON z| from pending copies so a half-arrived reply
    -- can never half-fill the window.
    hash      = nil,        -- the server's roster hash
    venues    = nil,        -- { [venue] = { busy1, busy2, busy3 } }
    tiers     = {},         -- { [tier] = { gil, testimonies, lockoutHours, rankCap, ceiling } }
    ledger    = {},         -- { [idx] = { kills, best, drops, mercy, four } }
    unclaimed = {},         -- { [idx] = true }
    syncedAt  = nil,

    -- Moves on every write to the board above and on the zone line that
    -- re-resolves the item names. The filtered row lists and the ledger
    -- totals are cached against it rather than rebuilt sixty times a second
    -- (the dwwarehouse 1.10.0 shape).
    modelRev  = 0,

    pending   = nil,        -- the in-flight status reply

    inbound   = nil,        -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame

    -- The answer clock, per read (the dwfame shape): one retry after five
    -- seconds, then the silent latch.
    requested    = nil,     -- { at, tries }
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until the
    -- zone line re-probes it.
    refused   = false,

    -- A status envelope closed WITHOUT a board (a refusal inside it, or a
    -- reply that ended before its h| and a| arrived). The third latch, and
    -- it exists for the same reason as the other two: the first ask is
    -- automatic and fires from the render loop while `venues` is nil, so a
    -- server that will refuse the ask again would be asked again every 1.2
    -- seconds, forever. A Refresh click lifts it -- a click is the player
    -- asking -- and so does a zone line.
    boardFailed  = false,

    -- Write debounces, PAST the queue's dupe-collapse (the arena's lesson):
    -- the collapse only merges lines still waiting in the queue. nil rather
    -- than 0 on purpose -- os.clock() is process CPU seconds, so a zero
    -- sentinel swallows every click made in the first ENTER_DEBOUNCE of them.
    enterAt   = nil,
    leaveAt   = nil,

    -- The find box (1.2.0): a hundred monsters is a list, not a menu. Matched
    -- against the name, the home zone and the signature drop, case-blind,
    -- on every tier tab and the ledger. `unclaimedOnly` narrows to monsters
    -- whose four-augment drop nobody on the server has claimed.
    find          = T{ '' },
    unclaimedOnly = T{ false },
};

--[[
* THE TOOLTIPS, in one table rather than one literal per call site, so the
* harness can assert them and so two controls that mean the same thing cannot
* drift into two sentences. The suite's rule: say what the control DOES, and
* for a greyed one say why it cannot right now; never repeat the label, never
* tooltip the self-evident. Tips that carry a number are formatted at the call
* site from the pieces below.
--]]
local TIPS = {
    refresh      = 'Ask the server for the board again. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks, and Refresh cannot fix that -- update dwnemesis through the launcher.',
    find         = 'Filters every tier tab and the ledger by monster name, home zone or signature drop.',
    unclaimed    = 'Only monsters whose four-augment drop nobody on the server has claimed yet.',
    clear        = 'Empty the find box and turn the unclaimed switch off.',
    unclaimedN   = 'Monsters no account on the server has ever taken a four-augment drop from. The marker on a row says the same of that row.',
    arenas       = 'Private arenas running right now, out of nine -- three engine areas in each of three venues. Entering takes the emptiest venue.',
    venue        = 'Arenas running in this venue, out of three. All nine busy is the one thing that turns an Enter away before it looks at your party.',
    level        = 'Wild level, then the level it fights at here: wild + 100, capped by the server.',
    sigGear      = 'Table rate at TH 0, before the server\'s drop multiplier. Gear rolls 1-4 augments.',
    sigPlain     = 'Table rate at TH 0, before the server\'s drop multiplier. Drops plain.',
    youNone      = 'You have never fought this one.',
    marker       = 'Nobody on the server has taken a four-augment drop from this one yet.',
    kills        = 'Kills your whole account has taken of this one.',
    best         = 'Your fastest kill of this one, minutes:seconds.',
    drops        = 'Chests of yours that carried a piece of gear. Every piece rolls 1-4 augments.',
    fourCol      = 'Four-augment drops you have taken from this one. One roll in a hundred carries four.',
    mercy        = 'Gear-less chests in a row. At the eighth the next chest is forced to carry gear, and the meter resets.',
    enter        = 'Charges every real player in your party and warps you all in. The server checks everyone first.',
    enterWait    = 'Already asked. The server answers in a moment.',
    enterBoard   = 'The board has not arrived yet, so this addon has nothing to offer a fight from. Refresh, or wait a moment.',
    enterHash    = 'This addon\'s roster is not the server\'s, so a row number here may not name the monster the server would fight. Update dwnemesis before entering.',
    enterRefused = 'This addon is not the version the server speaks. Update dwnemesis through the launcher.',
    leave        = 'Back to the tile you entered from. /port and !home work from inside too.',
    leaveWait    = 'Already asked. The server answers in a moment.',
    copy         = 'Copy every row shown below to the clipboard, one monster per line.',
    ledgerTotals = 'Your whole account across every monster it has fought, whatever the find box is showing.',
};

--[[
* The client's own name for a signature drop, cached by item id (1.3.0). This
* used to be a pcall'd resource-manager lookup per visible row per frame --
* and TWICE over while the find box had text in it, because the search
* haystack was built from the same call. Forty lookups and forty closures a
* frame on the Field tab alone, for a table the client does not change while
* the game is running. All three caches below are keyed off that lookup --
* the drawn name, the lowercase text the find box matches, and the hover
* card's own lines -- and all three are dropped on the ZONE line rather than
* pinned for the session, so an id the resource manager could not answer for
* at login resolves the next time the player zones.
--]]
local nameCache = { };
local haystacks = { };
local cardCache = { };

--[[
* Outbound: `!dwd` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat.
--]]
local SEND_INTERVAL = 1.2;

-- The two write debounces, in seconds of the same clock the queue uses. Each
-- sits PAST the queue's dupe-collapse, which only merges lines still waiting
-- in the queue and so does nothing at all about a click a second apart.
local ENTER_DEBOUNCE = 5.0;
local LEAVE_DEBOUNCE = 3.0;

-- How much text the find box holds. One number for the widget's buffer, the
-- slice `/nemesis <name>` writes into it, and nothing else: they were two
-- numbers to disagree about.
local FIND_MAX = 47;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- `force` is the Refresh button: a click is the player asking, and the
-- silent latch exists to contain AUTOMATIC re-asks (an unknown ! command
-- falls through to public /say on a server without dwd.lua), not to ignore
-- the player. Before 1.1.0 Refresh returned here while the latch was set,
-- which is the whole of "the window stopped answering after a fight" (owner
-- report 2026-09-05): a zone line plus the client's post-zone chat settle
-- window lost both automatic tries, the latch set, and every click after
-- that did nothing. The protocol refusal is NOT lifted by a click -- an
-- addon that is the wrong version stays the wrong version.
local function askStatus(force)
    if (state.refused) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    -- A board the server ANSWERED WITHOUT (see state.boardFailed) latches the
    -- same way a silent server does, and for the same reason: the automatic
    -- first ask fires from the render loop while `venues` is nil, and a
    -- server whose Nemesis half did not load answers every one of them the
    -- same way, forever, at one line per send interval. A click lifts it.
    if (state.boardFailed) then
        if (not force) then
            return;
        end

        state.boardFailed = false;
    end

    -- A CLICK REPLACES THE OLD ANSWER. Lifting a latch without clearing the
    -- sentence that set it left the last refusal red in the header while the
    -- window was actively asking again -- and the header shows a refusal in
    -- preference to "asking...", so the player read a stale complaint about a
    -- request that had already been retried. Only a REFUSAL is dropped; a
    -- note ("Your nemesis awaits.") is still true.
    if (force and state.statusBad) then
        state.status    = '';
        state.statusBad = false;
    end

    state.requested = { at = os.clock(), tries = 1 };

    issue('!dwd status');
end

local function checkAnswers()
    local asked = state.requested;

    if (asked == nil) then
        return;
    end

    -- THE CLOCK DOES NOT AGE WHILE THE CLIENT IS ZONING -- it is RE-STAMPED,
    -- not merely skipped. The ask is issued on the zone-in packet while the
    -- line still sits in the queue behind echo.canSend(); a clock started
    -- then had already expired by the time the line went out, so the retry
    -- fired 1.2 s behind the first send -- both inside the client's chat
    -- settle window, both dropped, and the latch set with the server never
    -- asked (the dwscan/dwfishing "freeze" shape from the 2026-08-15 round).
    if (not echo.canSend()) then
        asked.at = os.clock();

        return;
    end

    if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
        return;
    end

    if (asked.tries >= ANSWER_TRIES) then
        -- NO SENTENCE IS WRITTEN HERE. renderHeader draws the silent latch in
        -- preference to state.status, so the line this used to set was never
        -- read -- and it outlived the latch: the moment Refresh cleared
        -- serverSilent, that unread sentence became the header, red, over a
        -- request that was already back on the wire.
        state.requested    = nil;
        state.serverSilent = true;

        return;
    end

    asked.at    = os.clock();
    asked.tries = asked.tries + 1;

    issue('!dwd status');
end

--[[
* Record parsing (dwd protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], -1);

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            --[[
            * THE REFUSAL RETIRES THE ASK (1.3.0). A mismatched `d|` IS an
            * answer -- the server spoke, in a dialect this addon does not
            * read -- and leaving the answer clock running against it had two
            * costs. Five seconds later checkAnswers re-sent `!dwd status`,
            * against the protocol doc's own promise that an unknown version
            * "refuses once, in chat, and stops asking until a zone line
            * re-probes"; five after that the silent latch set and painted
            * "No answer from the server" over the accurate "Update dwnemesis
            * through the launcher" banner, which points the player at the
            * server when the addon is the problem.
            * The staging copy goes too: it belongs to an envelope that can
            * no longer be trusted to mean what this addon thinks it means.
            --]]
            state.requested    = nil;
            state.pending      = nil;
            state.serverSilent = false;
            state.boardFailed  = false;

            print(chat.header('dwnemesis'):append(chat.error(string.format(
                'server protocol %d, addon expects %d. Update dwnemesis through the launcher.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope proves the server is there (the latch
        -- lifts), but only a STATUS envelope answers the status ask: an
        -- enter or leave answer arriving while a status is outstanding must
        -- not mark it answered, or a lost status is never re-asked and the
        -- board reads "Waiting for the board..." until the next zone line.
        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.inbound == 'status') then
            state.requested = nil;
            state.pending   = { hash = nil, venues = {}, tiers = {}, ledger = {}, unclaimed = {} };

            -- A NEW BOARD CLEARS THE OLD BANNER (1.3.0). Nothing ever did:
            -- a refusal from an `enter` -- "Every arena is occupied. Try
            -- again shortly." -- stayed red in the header for the rest of
            -- the session, over boards that had since been asked for and
            -- answered. Whatever the server wants to say about THIS board
            -- rides inside this envelope as m| or e|, after this line.
            state.status    = '';
            state.statusBad = false;
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        if (kind == 'e') then
            -- A REFUSED WRITE UNLOCKS ITS OWN BUTTON. The Enter debounce is
            -- there to stop a second charge landing behind the first, and a
            -- refusal means nothing was charged -- so making the player sit
            -- out five seconds for a fee they did not pay is the window
            -- punishing them for the server's answer.
            if (state.inbound == 'enter') then
                state.enterAt = nil;
            elseif (state.inbound == 'leave') then
                state.leaveAt = nil;
            end

            --[[
            * A REFUSAL INSIDE AN OPEN ENVELOPE KILLS THAT ANSWER (1.3.0).
            * This is not a rare shape: dwd.lua emits exactly `d|1|status`,
            * `e|Nemesis is not loaded on this build.`, `z|status` when the
            * core did not load, and squad_storage's writer wraps ANY bare
            * fail in the same three lines. Committing that staging copy at
            * z| left `venues` an EMPTY TABLE, which reads everywhere in this
            * file as "the board arrived": the header claimed nine idle
            * arenas on a server with no Nemesis on it, every Enter button
            * went live, and the lazy first ask never fired again because it
            * only fires while `venues` is nil. Dropping the copy here is
            * what makes z| below refuse to commit it.
            --]]
            state.pending = nil;
        end

        -- A NOTE WITH NO SENTENCE IN IT SAYS NOTHING. `out:fail(nil)` writes
        -- a bare `e|`, and blanking the header with it -- or printing an
        -- empty line under this addon's name in the player's chat log -- is
        -- worse than ignoring it. The bookkeeping above still ran: a refusal
        -- with nothing to say is still a refusal.
        if (text == '') then
            return;
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwnemesis'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    local pending = state.pending;

    -- h| -- the server's roster hash.
    if (kind == 'h' and pending ~= nil) then
        pending.hash = parts[2] or '';

        return;
    end

    -- a| -- one venue's three areas, busy flags.
    if (kind == 'a' and pending ~= nil) then
        local venue = wireInt(parts[2]);

        if (venue >= 1 and venue <= 3) then
            pending.venues[venue] = {
                wireInt(parts[3]) ~= 0,
                wireInt(parts[4]) ~= 0,
                wireInt(parts[5]) ~= 0,
            };
        end

        return;
    end

    -- t| -- one tier's terms.
    if (kind == 't' and pending ~= nil) then
        local tier = wireInt(parts[2]);

        if (tier >= 1 and tier <= 3) then
            pending.tiers[tier] = {
                gil          = wireInt(parts[3]),
                testimonies  = wireInt(parts[4]),
                lockoutHours = wireInt(parts[5]),
                rankCap      = wireInt(parts[6]),

                -- A ceiling of zero means "this server did not say", never
                -- "every arena is level zero" -- see DEFAULT_CEILING.
                ceiling      = wireInt(parts[7]),
            };
        end

        return;
    end

    -- l| -- ledger entries, several per line:
    -- idx:kills:best:drops:mercy:four[:lockSeconds]
    --
    -- `lock` was APPENDED in 2026-09-06 and is the seconds left on this
    -- account's Legend lockout for that monster. A server that predates the
    -- field sends six, and the missing seventh reads as zero -- which is
    -- exactly "not locked", so an old server and a new addon agree without
    -- either of them knowing about the other.
    if (kind == 'l' and pending ~= nil) then
        for field = 2, #parts do
            local bits = split(parts[field], ':');
            local idx  = wireInt(bits[1]);

            if (idx > 0) then
                pending.ledger[idx] = {
                    kills = wireInt(bits[2]),
                    best  = wireInt(bits[3]),
                    drops = wireInt(bits[4]),
                    mercy = wireInt(bits[5]),
                    four  = wireInt(bits[6]),
                    lock  = wireInt(bits[7]),
                };
            end
        end

        return;
    end

    -- u| -- the unclaimed set, comma-packed, possibly over several lines.
    if (kind == 'u' and pending ~= nil) then
        for _, piece in ipairs(split(parts[2] or '', ',')) do
            local idx = wireInt(piece);

            if (idx > 0) then
                pending.unclaimed[idx] = true;
            end
        end

        return;
    end

    -- k| -- the enter acknowledgement; the zone line re-probes everything.
    if (kind == 'k') then
        state.status    = 'Your nemesis awaits.';
        state.statusBad = false;

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        if (closed ~= 'status') then
            return;
        end

        --[[
        * ONLY A COMPLETE BOARD COMMITS (1.3.0). `pending` is nil when a
        * refusal killed the envelope (see the e| branch); it is present but
        * hollow when the reply ended before its h| or its a| rows arrived --
        * the client's chat rate-limit drops lines, which is the whole reason
        * this addon carries an answer clock. A HOLLOW BOARD IS WORSE THAN
        * NONE: the hash it does not carry cannot mismatch, so hashMismatch()
        * answers false and every Enter button goes live against a roster the
        * two halves have never agreed on. The latch below is what stops the
        * lazy first ask from re-asking a server that will answer the same way.
        --]]
        local complete = pending ~= nil and pending.hash ~= nil
            and (pending.venues[1] ~= nil or pending.venues[2] ~= nil or pending.venues[3] ~= nil);

        state.pending = nil;

        if (not complete) then
            state.boardFailed = true;

            return;
        end

        state.hash        = pending.hash;
        state.venues      = pending.venues;
        state.tiers       = pending.tiers;
        state.ledger      = pending.ledger;
        state.unclaimed   = pending.unclaimed;
        state.syncedAt    = os.clock();
        state.boardFailed = false;
        state.modelRev    = state.modelRev + 1;

        return;
    end
end

ashita.events.register('packet_in', 'dwnemesis_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwnemesis'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line invalidates the whole picture and re-probes both latches.
    -- A half-arrived envelope dies with the zone too, or its stray tail
    -- would be accepted into a stale pending copy on the far side.
    if (e.id == 0x000A) then
        state.requested    = nil;
        state.serverSilent = false;
        state.refused      = false;
        state.boardFailed  = false;
        state.venues       = nil;
        state.syncedAt     = nil;
        state.inbound      = nil;
        state.pending      = nil;

        -- A RED REFUSAL DOES NOT OUTLIVE THE PLACE IT WAS ABOUT (1.3.0). The
        -- arena that was occupied, the party member who was not in this zone,
        -- the fee that was short: every refusal this window can show names
        -- somewhere the player has just left. A note (m|, or the k| arrival
        -- line) is still true after a zone and stays.
        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end

        -- The signature-drop names resolve out of the client's own tables and
        -- the search haystacks are built from them; re-resolving once per
        -- zone costs a hundred lookups and unpins whatever the resource
        -- manager was able to answer at login.
        nameCache      = { };
        haystacks      = { };
        cardCache      = { };
        state.modelRev = state.modelRev + 1;
    end
end);

--[[
* THE NOTICE REROUTE (see NOTICE_TAG above). A tagged line is blocked out of
* whichever window the client routed it to and re-printed under this addon's
* header, which lands with addon chatter. Skipped when another handler
* already blocked the line (dwecho's echo swallow runs first) or when the
* line was injected by an addon (our own print() re-enters text_in -- and a
* re-printed line no longer carries the tag, but the guard is cheaper than
* the argument). Since 1.3.1 the line must arrive on NOTICE_MODE and the
* tag must open the cleaned line -- plainText strips the decoration (colour
* bytes, a timestamp addon's clock) that the older unanchored match was
* excusing, and the unanchored match is exactly what let a player's yell
* impersonate the server.
--]]
local function plainText(raw)
    -- Two-byte tags and their argument first (Ashita's colour tags, the
    -- client's, the auto-translate brackets), then anything undrawable,
    -- then a leading clock the timestamp addon may have stamped.
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    text = text:gsub('[^\032-\126]', '');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return text;
end

ashita.events.register('text_in', 'dwnemesis_text_in', function (e)
    if (e.blocked or e.injected) then
        return;
    end

    local raw = e.message_modified or e.message;

    if (raw == nil) then
        return;
    end

    -- THE MODE GATE FIRST (see NOTICE_MODE). A missing mode refuses too: the
    -- live client always supplies one, so its absence is not a server line.
    local mode = e.mode_modified or e.mode;
    local low  = mode ~= nil and bit.band(mode, 0xFF) or nil;

    if (low ~= NOTICE_MODE) then
        return;
    end

    -- Left-trimmed so the anchor below is on the text, not on whatever
    -- spacing survived plainText. (gsub returns two values; keep one.)
    local line = (plainText(raw):gsub('^%s+', ''));
    local at   = line:find(NOTICE_TAG, 1, true);

    if (at ~= 1) then
        return;
    end

    -- The trim is on the remainder, not the line: trimming first would eat
    -- the tag's own trailing space and a line that is nothing but a tag
    -- would stop matching.
    local rest = line:sub(at + #NOTICE_TAG):gsub('^%s+', ''):gsub('%s+$', '');

    if (rest == '') then
        return;
    end

    e.blocked = true;

    print(chat.header('dwnemesis'):append(chat.message(rest)));
end);

--[[
* Rendering.
--]]
local function fmtGil(amount)
    local text = tostring(math.floor(amount or 0));
    local out  = '';

    while (#text > 3) do
        out  = ',' .. text:sub(-3) .. out;
        text = text:sub(1, -4);
    end

    return text .. out;
end

--[[
* MEASURED LAYOUT, NOT GUESSED (dwcraft's rule, reached here through dwcpx's
* copy of it). Both helpers read the LIVE font each frame and fall back to a
* conservative constant when a binding does not answer; the asymmetry is
* deliberate, because a fallback that is too big spends a few pixels of list
* and one that is too small hides a control the player needs to click.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

--[[
* WHAT EVERY SCROLLING TABLE HERE MUST LEAVE BELOW ITSELF (1.3.0).
*
* A table carrying ImGuiTableFlags_ScrollY owns a child window, and a child
* window given a ZERO outer height takes the whole remaining content region
* (imgui_tables.cpp hands CalcItemSize the available height as the default for
* exactly that case). Every table in this file passed no outer size at all, so
* each of them ate the rest of the window -- and the separator and the "Leave
* the arena" button drawn after EndTabBar landed BELOW the window's bottom
* edge, at every size the window has ever had. They were reachable only by
* scrolling the window itself, which then scrolled the table's own frozen
* header out of view. A NEGATIVE outer height reads as "available minus this",
* which is the dwcpx footerReserve shape.
--]]
local function footerReserve()
    return -(metric('GetFrameHeightWithSpacing', 26) + 12);
end

-- The client's own name for a signature drop; see nameCache above for why it
-- is remembered rather than asked for per row per frame.
local function itemName(row)
    local cached = nameCache[row.sigItem];

    if (cached ~= nil) then
        return cached;
    end

    local name = row.sig;

    local ok, resolved = pcall(function ()
        local res = AshitaCore:GetResourceManager():GetItemById(row.sigItem);

        return res and res.Name and res.Name[1] or nil;
    end);

    if (ok and resolved ~= nil and resolved ~= '') then
        name = resolved;
    end

    nameCache[row.sigItem] = name;

    return name;
end

-- Item flag bits, from the client's own item data (dwah/dwbags carry the
-- same two).
local FLAG_RARE = 0x8000;
local FLAG_EX   = 0x4000;

--[[
* The client packs an elemental-resistance icon as \239 plus a byte in the
* 0x1F..0x26 band. It is not UTF-8, so it renders as the '?' players reported
* against dwbags; each icon folds to a three-letter tag instead. MIRRORED BY
* HAND from dwah 1.4.0 / dwbags 1.17.0 -- edit one, revisit the others.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function (icon)
        return RESIST_TAGS[icon:byte()] .. ':';
    end));
end

--[[
* The card's own text, remembered per item id (cardCache, declared beside the
* name cache above so the zone line can drop all three together). A hover
* holds for as long as the mouse rests on the cell and the card is rebuilt on
* every one of those frames, so without this a resting mouse cost one
* resource-manager lookup and one description gsub sixty times a second.
--]]
local function cardFor(row)
    local card = cardCache[row.sigItem];

    if (card ~= nil) then
        return card;
    end

    local ok, item = pcall(function ()
        return AshitaCore:GetResourceManager():GetItemById(row.sigItem);
    end);

    card = { };

    if (ok and item ~= nil) then
        local tags = { };

        if (item.Level ~= nil and item.Level > 0) then
            tags[#tags + 1] = string.format('Lv %d', item.Level);
        end

        if (bit.band(item.Flags or 0, FLAG_RARE) ~= 0) then
            tags[#tags + 1] = 'Rare';
        end

        if (bit.band(item.Flags or 0, FLAG_EX) ~= 0) then
            tags[#tags + 1] = 'Ex';
        end

        if (#tags > 0) then
            card.tags = table.concat(tags, '  ');
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            card.desc = cleanDescription(desc);
        end
    else
        card.missing = true;
    end

    cardCache[row.sigItem] = card;

    return card;
end

--[[
* THE SIGNATURE DROP'S HOVER CARD (1.3.0) -- the shape dwtoau's spellCard and
* dwbags'/dwah's itemCard already draw, which is where a player expects to
* find out what a piece of gear actually is. It is also the only thing that
* can hold a drop name at every window size: "Bottle of Ahriman Tears 10%" is
* twenty-seven characters and no column width guarantees them all.
--]]
local function dropCard(row)
    local card = cardFor(row);

    imgui.BeginTooltip();
    imgui.Text(itemName(row));

    if (card.missing) then
        imgui.TextDisabled('(the client\'s own item data has nothing under this id)');
    else
        if (card.tags ~= nil) then
            imgui.TextDisabled(card.tags);
        end

        if (card.desc ~= nil) then
            imgui.Separator();
            imgui.PushTextWrapPos(320.0);
            imgui.Text(card.desc);
            imgui.PopTextWrapPos();
        end
    end

    imgui.Separator();
    imgui.TextDisabled(row.sigGear and TIPS.sigGear or TIPS.sigPlain);
    imgui.EndTooltip();
end

-- One short tip on the item just drawn. Every plain tooltip in this file goes
-- through here so the pattern cannot drift call site by call site.
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local function hashMismatch()
    return state.hash ~= nil and roster.hash ~= '' and state.hash ~= roster.hash;
end

local function busyTotal()
    local busy, total = 0, 0;

    for venue = 1, 3 do
        local areas = state.venues and state.venues[venue] or nil;

        for area = 1, 3 do
            total = total + 1;

            if (areas ~= nil and areas[area]) then
                busy = busy + 1;
            end
        end
    end

    return busy, total;
end

-- The level every arena on a tier is capped at. See DEFAULT_CEILING: a zero
-- here means "this server did not say", never "level zero".
local function ceilingOf(terms)
    local value = terms ~= nil and terms.ceiling or 0;

    if (value <= 0) then
        return DEFAULT_CEILING;
    end

    return value;
end

-- "1:35", or "--" for a monster with no time on the books.
local function bestText(seconds)
    if (seconds == nil or seconds <= 0) then
        return '--';
    end

    return string.format('%d:%02d', math.floor(seconds / 60), seconds % 60);
end

--[[
* THE ACCOUNT SUMMARY, CACHED AGAINST state.modelRev (1.3.0). The ledger
* totals line and the unclaimed count each walked their whole table inside
* the render pass -- up to two hundred iterations sixty times a second, for
* numbers that move only when a board commits or a zone line drops the caches.
--]]
local summaryCache = { rev = -1, kills = 0, drops = 0, four = 0, fought = 0, listed = 0, unclaimed = 0 };

local function summary()
    if (summaryCache.rev == state.modelRev) then
        return summaryCache;
    end

    local kills, drops, four, fought, unclaimed = 0, 0, 0, 0, 0;

    for _, entry in pairs(state.ledger) do
        kills  = kills + entry.kills;
        drops  = drops + entry.drops;
        four   = four + entry.four;
        fought = fought + 1;
    end

    for _ in pairs(state.unclaimed) do
        unclaimed = unclaimed + 1;
    end

    -- `fought` counts the ACCOUNT's rows and `listed` counts the ones this
    -- roster can name. They are the same number except under a hash mismatch,
    -- where the server knows a monster this addon's copy does not: the totals
    -- sentence wants the account's truth, and the Ledger tab's own count has
    -- to match the rows the tab can actually draw or the label reads "3/4"
    -- with nothing filtering.
    local listed = 0;

    for _, row in ipairs(roster.rows) do
        if (state.ledger[row.idx] ~= nil) then
            listed = listed + 1;
        end
    end

    summaryCache = {
        rev       = state.modelRev,
        kills     = kills,
        drops     = drops,
        four      = four,
        fought    = fought,
        listed    = listed,
        unclaimed = unclaimed,
    };

    return summaryCache;
end

-- The lowercase text the find box matches a row against. Built once per row
-- and kept until a zone line re-resolves the item names.
local function haystackFor(row)
    local text = haystacks[row.idx];

    if (text == nil) then
        text = string.lower(row.name .. ' ' .. (row.zoneName or '') .. ' ' .. itemName(row));

        haystacks[row.idx] = text;
    end

    return text;
end

--[[
* THE ROWS ONE TAB DRAWS, FILTERED ONCE PER CHANGE (1.3.0; the dwwarehouse
* 1.10.0 view-cache shape). Before this the filter ran per row per frame, and
* each test allocated a lowercased string.format of the row's three fields --
* which reached the resource manager a SECOND time, on top of the one the
* drawn name already cost. Tier 4 is the Ledger tab: the rows this account
* has fought. The key carries everything the filter reads, so typing in Find
* still narrows on the keystroke; it just stops re-walking an unchanged list
* in between them.
--]]
local viewCache = { };

-- The filter, read ONCE a frame. visibleRows is asked five times in a frame --
-- four tab labels and the active tab's own rows -- and each of those used to
-- lowercase the find text and format a key of its own. refreshView() is
-- called from renderWindow between the find row (which is where the two
-- inputs are read) and the tab bar (which is the first thing that filters);
-- nothing else calls visibleRows, so nothing can see a stale key.
local viewKey    = '';
local viewNeedle = '';
local viewOnly   = false;

local function refreshView()
    viewNeedle = string.lower(state.find[1] or '');
    viewOnly   = state.unclaimedOnly[1] == true;
    viewKey    = string.format('%d|%s|%s', state.modelRev, viewNeedle, tostring(viewOnly));
end

local function visibleRows(tier)
    local slot = viewCache[tier];

    if (slot ~= nil and slot.key == viewKey) then
        return slot.rows;
    end

    local rows = { };

    for _, row in ipairs(roster.rows) do
        local wanted;

        if (tier == 4) then
            wanted = state.ledger[row.idx] ~= nil;
        else
            wanted = row.tier == tier;
        end

        if (wanted
                and (not viewOnly or state.unclaimed[row.idx])
                and (viewNeedle == '' or string.find(haystackFor(row), viewNeedle, 1, true) ~= nil)) then
            rows[#rows + 1] = row;
        end
    end

    viewCache[tier] = { key = viewKey, rows = rows };

    return rows;
end

--[[
* THE FORMATTED CELLS OF ONE ROW, BUILT ON A MODEL CHANGE RATHER THAN PER
* FRAME (1.3.0). Thirty-six rows on the Field tab is a hundred and eight
* string.format calls a frame -- six and a half thousand a second -- for text
* that moves only when a board commits (the ledger, the level ceiling) or a
* zone line re-resolves the item names, both of which move state.modelRev.
* Built lazily, so a tab nobody is looking at formats nothing.
--]]
local cellCache = { rev = -1, rows = { } };

local function cellsFor(row)
    if (cellCache.rev ~= state.modelRev) then
        cellCache = { rev = state.modelRev, rows = { } };
    end

    local cells = cellCache.rows[row.idx];

    if (cells ~= nil) then
        return cells;
    end

    local entry = state.ledger[row.idx];

    cells = {
        level = string.format('%d -> %d', row.level,
            math.min(row.level + LEVEL_BONUS, ceilingOf(state.tiers[row.tier]))),
        drop  = string.format('%s %d%%', itemName(row), math.floor(row.sigRate / 10)),
    };

    if (entry ~= nil) then
        cells.you   = string.format('%dk %dd %s', entry.kills, entry.drops, bestText(entry.best));
        cells.kills = tostring(entry.kills);
        cells.best  = bestText(entry.best);
        cells.drops = tostring(entry.drops);
        cells.mercy = string.format('%d/%d', entry.mercy, MERCY_STACKS);
        cells.fourN = tostring(entry.four);

        if (entry.four > 0) then
            cells.four = string.format('x%d', entry.four);
        end
    end

    cellCache.rows[row.idx] = cells;

    return cells;
end

-- How many rows a tab holds with nothing filtering, for its label.
local function tabTotal(tier)
    if (tier == 4) then
        return summary().listed;
    end

    return TIER_TOTAL[tier] or 0;
end

--[[
* "Field 36" with nothing filtering, "Field 3/36" with something (1.3.0). A
* find box that narrows FOUR tabs at once is unreadable without this: nothing
* on screen said which tab the match landed in, so a search that hit one row
* on the Legend tab looked exactly like a search that hit nothing at all.
*
* The ### is load-bearing. With ## the visible count is part of the tab's
* ImGui id, so the selected tab would be re-created and lose its selection
* every time a number moved -- the reason dwah's Orders tab spells it the
* same way.
--]]
local TAB_IDS = { 'dwd_tab_1', 'dwd_tab_2', 'dwd_tab_3', 'dwd_tab_ledger' };

-- One ImGui id per tier table, built here rather than concatenated per frame.
local ROW_TABLE_IDS = { 'dwd_rows_1', 'dwd_rows_2', 'dwd_rows_3' };

local function tabLabel(name, tier)
    local total = tabTotal(tier);
    local shown = #visibleRows(tier);

    if (shown == total) then
        return string.format('%s %d###%s', name, total, TAB_IDS[tier]);
    end

    return string.format('%s %d/%d###%s', name, shown, total, TAB_IDS[tier]);
end

-- Why an Enter button is not there. A control that is missing or greyed and
-- says nothing about it is the one thing worse than a control that refuses.
local function enterBlocked()
    if (state.refused) then
        return TIPS.enterRefused;
    end

    if (hashMismatch()) then
        return TIPS.enterHash;
    end

    return TIPS.enterBoard;
end

--[[
* WHY A TAB IS EMPTY. It used to say "Nothing on this tier matches the find
* box" for every one of the four ways a tab can empty, and that sentence is
* wrong in three of them: the unclaimed switch with no board yet hides every
* row and the find box is not what did it, a roster.lua that failed to load
* has no rows to match at all (and the player needs to be told that rather
* than left searching an empty window), and a tier where every monster's
* four-augment drop has been claimed is an ANSWER, not a miss.
--]]
local function emptyReason(tier)
    if (#roster.rows == 0) then
        return 'This addon\'s roster file did not load. Reinstall dwnemesis through the launcher.';
    end

    local finding = (state.find[1] or '') ~= '';
    local ledger  = tier == 4;

    if (state.unclaimedOnly[1]) then
        if (state.venues == nil) then
            return 'The unclaimed list arrives with the board. Refresh, or clear the switch.';
        end

        if (finding) then
            if (ledger) then
                return 'Nothing in your ledger is both unclaimed and a match for the find box.';
            end

            return 'Nothing on this tier is both unclaimed and a match for the find box.';
        end

        if (ledger) then
            return 'Nothing in your ledger is unclaimed.';
        end

        return 'Every monster on this tier has had its four-augment drop claimed.';
    end

    if (ledger) then
        return 'Nothing in your ledger matches the find box.';
    end

    return 'Nothing on this tier matches the find box.';
end

-- The Enter button labels, built once per row. Concatenating one per visible
-- row per frame was forty string allocations a frame on the Field tab.
local enterLabels = { };

local function enterLabel(idx)
    local label = enterLabels[idx];

    if (label == nil) then
        label = 'Enter##dwd_enter_' .. idx;

        enterLabels[idx] = label;
    end

    return label;
end

local function refreshTip()
    if (state.refused) then
        return TIPS.refreshStale;
    end

    if (state.syncedAt == nil) then
        return TIPS.refresh;
    end

    return string.format('%s\nThe board on screen arrived about %d second(s) ago.',
        TIPS.refresh, math.max(0, math.floor(os.clock() - state.syncedAt)));
end

local function renderHeader()
    if (imgui.Button('Refresh##dwd_refresh')) then
        askStatus(true);
    end

    -- Built only when it is going to be read: refreshTip formats a sentence
    -- and reads the clock, and tip() would evaluate it every frame.
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(refreshTip());
    end

    imgui.SameLine();

    -- REFUSED OUTRANKS SILENT (1.3.0). A protocol mismatch is the one state
    -- here with an action attached to it, and until the mismatch branch
    -- retired the answer clock the silent latch could set on top of it and
    -- paint "No answer from the server" over the sentence that was true.
    -- The order is belt to that brace.
    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwnemesis through the launcher.');
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server. Refresh to ask again.');
    elseif (hashMismatch()) then
        imgui.TextColored(theme.colors.err, 'This addon\'s roster is not the server\'s. Update dwnemesis before entering.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or state.requested ~= nil) then
        imgui.TextDisabled('asking...');
    else
        imgui.TextDisabled('One monster. One chest. Your roll.');
    end

    if (state.venues ~= nil) then
        local busy, total = busyTotal();

        imgui.Text(string.format('%d of %d arenas running', busy, total));
        tip(TIPS.arenas);

        for venue = 1, 3 do
            local areas = state.venues[venue] or {};
            local count = 0;

            for area = 1, 3 do
                if (areas[area]) then
                    count = count + 1;
                end
            end

            imgui.SameLine();
            imgui.TextColored(count >= 3 and theme.colors.warn or theme.colors.dim,
                string.format('  %s %d/3', VENUE_NAMES[venue], count));
            tip(TIPS.venue);
        end
    elseif (state.boardFailed) then
        -- The latch says exactly what happened, rather than waiting forever
        -- on a board the server has already answered without.
        imgui.TextDisabled('The server answered without a board. Refresh to ask again.');
    else
        imgui.TextDisabled('Waiting for the board...');
    end

    imgui.Separator();
end

local function renderFindRow()
    imgui.PushItemWidth(260);
    imgui.InputTextWithHint('##dwd_find', 'find a monster, zone or drop...', state.find, FIND_MAX + 1);
    imgui.PopItemWidth();

    tip(TIPS.find);

    imgui.SameLine();

    imgui.Checkbox('Unclaimed only##dwd_unclaimed', state.unclaimedOnly);

    tip(TIPS.unclaimed);

    if ((state.find[1] or '') ~= '' or state.unclaimedOnly[1]) then
        imgui.SameLine();

        if (imgui.SmallButton('Clear##dwd_find_clear')) then
            state.find[1]          = '';
            state.unclaimedOnly[1] = false;
        end

        tip(TIPS.clear);
    end

    -- What the "unclaimed" markers add up to, beside the switch that narrows
    -- to them (1.3.0). The marker is what this window is FOR, and the number
    -- behind it could only be had by flipping the switch and counting rows.
    if (state.venues ~= nil and #roster.rows > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d of %d unclaimed', summary().unclaimed, #roster.rows));
        tip(TIPS.unclaimedN);
    end
end

local function renderTierRows(tier)
    local terms   = state.tiers[tier];
    local ceiling = ceilingOf(terms);

    if (terms ~= nil) then
        imgui.TextWrapped(string.format('%s tier -- %s gil and %d different Job Testimon%s per player. Arena level = wild + %d, capped at %d. Augment ranks up to %d.%s',
            TIER_NAMES[tier], fmtGil(terms.gil), terms.testimonies, terms.testimonies == 1 and 'y' or 'ies',
            LEVEL_BONUS, ceiling, terms.rankCap,
            terms.lockoutHours > 0 and string.format(' One fight per monster per account every %d hours.', terms.lockoutHours) or ''));
    else
        imgui.TextDisabled(string.format('%s tier -- terms arrive with the board.', TIER_NAMES[tier]));
    end

    imgui.Separator();

    local canEnter   = state.venues ~= nil and not hashMismatch() and not state.refused;
    local blockedTip = canEnter and '' or enterBlocked();
    local waiting    = state.enterAt ~= nil and (os.clock() - state.enterAt) <= ENTER_DEBOUNCE;
    local rows       = visibleRows(tier);
    local pad        = textWidth('nn', 14);

    -- HOW OLD THE LOCK NUMBERS ARE. `l|`'s lock field is the seconds left at
    -- the moment the board was built, so it has to be aged by however long
    -- the board has been on screen or a lockout that has since run out would
    -- still read as locked. The server is the authority either way -- the
    -- greyed row is a courtesy, and the tooltip says to Refresh.
    local boardAge = state.syncedAt ~= nil and math.max(0, os.clock() - state.syncedAt) or 0;

    if (imgui.BeginTable(ROW_TABLE_IDS[tier], 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        -- The two TEXT columns stretch and the four measured ones are fixed
        -- at the width of their own widest value, so every pixel the window
        -- gains goes to the monster and the drop -- the two that clip. Before
        -- 1.3.0 all six stretched proportionally, which spent a quarter of a
        -- 700-pixel window on "35 -> 135".
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Monster', ImGuiTableColumnFlags_WidthStretch, 3.2);
        imgui.TableSetupColumn('Level', ImGuiTableColumnFlags_WidthFixed, textWidth('195 -> 195', 70) + pad);
        imgui.TableSetupColumn('Signature drop', ImGuiTableColumnFlags_WidthStretch, 3.4);
        imgui.TableSetupColumn('You', ImGuiTableColumnFlags_WidthFixed, textWidth('99k 99d 99:99', 92) + pad);
        imgui.TableSetupColumn('Four', ImGuiTableColumnFlags_WidthFixed, textWidth('unclaimed', 64) + pad);
        imgui.TableSetupColumn('Enter', ImGuiTableColumnFlags_WidthFixed, textWidth('locked', 46) + pad);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            local entry = state.ledger[row.idx];
            local cells = cellsFor(row);

            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.Text(row.name);

            if (imgui.IsItemHovered()) then
                -- THE ROW NUMBER IS THE TYPED DOOR. `!nemesis enter 12` is the
                -- same dispatch this button reaches (see the header), and
                -- nothing in the window said which number a row is -- so a
                -- player who wanted the typed form, or who wanted to report a
                -- row, had to count. It rides the tooltip rather than a
                -- column: worth having, not worth a column's width.
                imgui.SetTooltip(string.format('#%d in the roster -- %s, wild level %d\nTyped: !nemesis enter %d',
                    row.idx, row.zoneName or 'somewhere', row.level, row.idx));
            end

            imgui.TableNextColumn();
            imgui.Text(cells.level);
            tip(TIPS.level);

            imgui.TableNextColumn();
            imgui.Text(cells.drop);

            if (imgui.IsItemHovered()) then
                dropCard(row);
            end

            imgui.TableNextColumn();

            if (entry ~= nil) then
                imgui.Text(cells.you);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('%d kills, %d gear drops, %d four-augment finds, best %s, Mercy %d of %d.\nk is kills, d is gear drops, then your best time.',
                        entry.kills, entry.drops, entry.four, cells.best, entry.mercy, MERCY_STACKS));
                end
            else
                imgui.TextDisabled('--');
                tip(TIPS.youNone);
            end

            imgui.TableNextColumn();

            if (state.unclaimed[row.idx]) then
                imgui.TextColored(theme.colors.warn, 'unclaimed');
                tip(TIPS.marker);
            elseif (cells.four ~= nil) then
                imgui.TextColored(theme.colors.ok, cells.four);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('You have taken %d four-augment drop%s from this one.',
                        entry.four, entry.four == 1 and '' or 's'));
                end
            end

            imgui.TableNextColumn();

            local lockLeft = entry ~= nil and (entry.lock - boardAge) or 0;

            -- WHY canEnter IS TESTED FIRST. A lockout is a fact about a row
            -- number, and the two states that clear canEnter are exactly the
            -- two where a row number may not mean what this addon thinks --
            -- a roster hash that is not the server's, and a protocol the
            -- server does not speak. Saying "locked" there would be attaching
            -- one monster's lockout to another monster's row.
            if (not canEnter) then
                imgui.TextDisabled('--');
                tip(blockedTip);
            elseif (lockLeft > 0) then
                -- A COURTESY, NEVER THE AUTHORITY (the house rule): the server
                -- still decides, and a stale board can still offer a fight it
                -- will refuse. What this stops is the only way a player used
                -- to be able to find out -- pressing Enter on a Legend they
                -- had already fought today and reading the refusal.
                imgui.TextDisabled('locked');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Your account fought %s inside its lockout. The door opens again in about %d hour(s); Refresh for the server\'s own clock.',
                        row.name, math.max(1, math.ceil(lockLeft / 3600))));
                end
            else
                if (imgui.SmallButton(enterLabel(row.idx))) then
                    -- Debounced BEYOND the queue's dupe-collapse (the arena's
                    -- lesson): one enter per ENTER_DEBOUNCE.
                    if (not waiting) then
                        state.enterAt   = os.clock();
                        state.status    = 'Entering...';
                        state.statusBad = false;

                        issue('!dwd enter ' .. row.idx);
                    end
                end

                tip(waiting and TIPS.enterWait or TIPS.enter);
            end
        end

        if (#rows == 0) then
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextDisabled(emptyReason(tier));
        end

        imgui.EndTable();
    end
end

--[[
* COPY (1.3.0). imgui.SetClipboardText is declared in Ashita's own SDK but is
* used by nothing in this suite and by none of Ashita's bundled addons, and a
* player's client is frozen at whatever they installed. So the button is
* HIDDEN rather than greyed when the binding is not a function: a button that
* does nothing when clicked is worse than a button that is not there, and the
* whole tab still works without it.
--]]
local function canCopy()
    return type(imgui.SetClipboardText) == 'function';
end

local function copyLedger(rows)
    local lines = { };

    for _, row in ipairs(rows) do
        local entry = state.ledger[row.idx];

        if (entry ~= nil) then
            lines[#lines + 1] = string.format('%s -- %d kill%s, best %s, %d drop%s, %d four-aug, mercy %d/%d',
                row.name, entry.kills, entry.kills == 1 and '' or 's', bestText(entry.best),
                entry.drops, entry.drops == 1 and '' or 's', entry.four, entry.mercy, MERCY_STACKS);
        end
    end

    if (#lines == 0) then
        return;
    end

    local ok = pcall(imgui.SetClipboardText, table.concat(lines, '\n'));

    state.status    = ok and string.format('%d row(s) copied.', #lines) or 'This client would not take the clipboard.';
    state.statusBad = not ok;
end

local function renderLedger()
    local totals = summary();
    local rows   = visibleRows(4);

    imgui.Text(string.format('%d kills, %d gear drops, %d four-augment finds across %d monsters.',
        totals.kills, totals.drops, totals.four, totals.fought));
    tip(TIPS.ledgerTotals);

    if (canCopy() and #rows > 0) then
        imgui.SameLine();

        if (imgui.SmallButton('Copy##dwd_ledger_copy')) then
            copyLedger(rows);
        end

        tip(TIPS.copy);
    end

    imgui.Separator();

    if (totals.fought == 0) then
        imgui.TextDisabled('Nothing yet. Pick a monster on a tier tab.');

        return;
    end

    if (imgui.BeginTable('dwd_ledger', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad       = textWidth('nn', 14);
        local ledgerAge = state.syncedAt ~= nil and math.max(0, os.clock() - state.syncedAt) or 0;

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Monster', ImGuiTableColumnFlags_WidthStretch, 1.0);
        imgui.TableSetupColumn('Kills', ImGuiTableColumnFlags_WidthFixed, textWidth('Kills', 40) + pad);
        imgui.TableSetupColumn('Best', ImGuiTableColumnFlags_WidthFixed, textWidth('99:99', 46) + pad);
        imgui.TableSetupColumn('Drops', ImGuiTableColumnFlags_WidthFixed, textWidth('Drops', 44) + pad);
        imgui.TableSetupColumn('Four', ImGuiTableColumnFlags_WidthFixed, textWidth('Four', 38) + pad);
        imgui.TableSetupColumn('Mercy', ImGuiTableColumnFlags_WidthFixed, textWidth('Mercy', 48) + pad);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            local cells = cellsFor(row);

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row.name);

            if (imgui.IsItemHovered()) then
                local entry    = state.ledger[row.idx];
                local lockLeft = entry ~= nil and (entry.lock - ledgerAge) or 0;

                if (lockLeft > 0) then
                    imgui.SetTooltip(string.format('%s -- wild level %d, %s tier.\nLocked for about another %d hour(s).',
                        row.zoneName or '?', row.level, TIER_NAMES[row.tier] or '?',
                        math.max(1, math.ceil(lockLeft / 3600))));
                else
                    imgui.SetTooltip(string.format('%s -- wild level %d, %s tier', row.zoneName or '?', row.level,
                        TIER_NAMES[row.tier] or '?'));
                end
            end

            imgui.TableNextColumn();
            imgui.Text(cells.kills);
            tip(TIPS.kills);
            imgui.TableNextColumn();
            imgui.Text(cells.best);
            tip(TIPS.best);
            imgui.TableNextColumn();
            imgui.Text(cells.drops);
            tip(TIPS.drops);
            imgui.TableNextColumn();
            imgui.Text(cells.fourN);
            tip(TIPS.fourCol);
            imgui.TableNextColumn();
            imgui.Text(cells.mercy);
            tip(TIPS.mercy);
        end

        if (#rows == 0) then
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextDisabled(emptyReason(4));
        end

        imgui.EndTable();
    end
end

local function renderWindow()
    renderHeader();
    renderFindRow();

    -- BETWEEN the row that reads the two filter inputs and the tab bar that
    -- is the first thing to use them. See refreshView.
    refreshView();

    if (imgui.BeginTabBar('dwd_tabs')) then
        for tier = 1, 3 do
            if (imgui.BeginTabItem(tabLabel(TIER_NAMES[tier], tier))) then
                renderTierRows(tier);
                imgui.EndTabItem();
            end
        end

        if (imgui.BeginTabItem(tabLabel('Ledger', 4))) then
            renderLedger();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    imgui.Separator();

    local leaving = state.leaveAt ~= nil and (os.clock() - state.leaveAt) <= LEAVE_DEBOUNCE;

    if (imgui.Button('Leave the arena##dwd_leave')) then
        -- DEBOUNCED LIKE ENTER, and for the same reason one interval up: the
        -- queue's dupe-collapse only merges lines still WAITING in it, so a
        -- player clicking a button that appeared to do nothing put one
        -- `!dwd leave` on the wire per send interval and the server answered
        -- every one of them in chat. The status line is the feedback that
        -- was missing and that made the clicking reasonable.
        if (not leaving) then
            state.leaveAt   = os.clock();
            state.status    = 'Leaving the arena...';
            state.statusBad = false;

            issue('!dwd leave');
        end
    end

    tip(leaving and TIPS.leaveWait or TIPS.leave);
end

ashita.events.register('d3d_present', 'dwnemesis_present', function ()
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    -- The board is asked for LAZILY -- the first frame the window is
    -- actually open -- so a player who never opens it never handshakes. Every
    -- latch is consulted here as well as inside askStatus: this test runs
    -- sixty times a second and the call it saves is not free.
    if (state.venues == nil and state.requested == nil
            and not state.serverSilent and not state.refused and not state.boardFailed) then
        askStatus();
    end

    local pushed = theme.push();

    -- 820 x 520 rather than 700 x 480 (1.3.0): six columns, two of which hold
    -- names that run to twenty-seven characters ("Bottle of Ahriman Tears
    -- 10%"). FirstUseEver, so nobody's saved size moves.
    imgui.SetNextWindowSize({ 820, 520 }, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE (1.3.0). Nothing in ImGui stops a window being dragged
    -- to nothing, and this one carries a four-tab bar, a find row, a six
    -- column table and a footer: narrow enough and the header sentence clips
    -- mid-word, short enough and the table is a scrollbar with no rows in it.
    --
    -- 660 IS MEASURED, NOT ROUND. The widest line the window ever draws is
    -- the occupancy row at a full house -- "9 of 9 arenas running" plus the
    -- three venue chips, eighty-seven characters -- and the find row behind
    -- it is a 260-pixel input, a checkbox, Clear and the unclaimed count.
    -- A player whose saved size is under this is clamped up to it once.
    imgui.SetNextWindowSizeConstraints({ 660, 340 }, { 99999, 99999 });

    local visible = imgui.Begin('DriftwoodXI Nemesis##dwnemesis', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwnemesis'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwnemesis'):append(chat.message('Window closed. Everything it shows also works typed as !nemesis.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwnemesis_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:sub(1, 4):lower() ~= '!dwd') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwnemesis_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/nemesis' and first ~= '/dwnemesis') then
        return;
    end

    e.blocked = true;

    --[[
    * `/nemesis lizzy` OPENS THE WINDOW ON THAT SEARCH (1.3.0) rather than
    * toggling it. A hundred monsters is a list you arrive at through the find
    * box, so a player who types a name has already said what they want --
    * and toggling the window SHUT on them because it happened to be open is
    * the wrong answer to the only thing they said. Non-printables are dropped
    * and the text is cut to the input buffer's own size: what goes in here is
    * what the widget hands back on the next frame.
    --]]
    if (#args > 1) then
        local words = { };

        for index = 2, #args do
            words[#words + 1] = args[index];
        end

        local text = (table.concat(words, ' '):gsub('[^\032-\126]', ''));

        -- The switch comes off with it: a player who named a monster wants
        -- to see THAT monster, and leaving a filter on that can hide it is
        -- the same trap as leaving the find box full.
        state.find[1]          = text:sub(1, FIND_MAX);
        state.unclaimedOnly[1] = false;
        state.open[1]          = true;
        state.reported         = false;

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwnemesis_load', function ()
    print(chat.header('dwnemesis'):append(chat.message('/nemesis opens the Nemesis board, /nemesis <name> opens it on that monster. Everything it shows also works typed as !nemesis or !nem.')));
end);
