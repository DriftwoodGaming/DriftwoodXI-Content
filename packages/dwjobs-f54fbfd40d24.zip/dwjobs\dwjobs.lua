--[[
* DriftwoodXI -- dwjobs
*
* The party's jobs in a window: the character you are playing and every
* squad slot beside it, each with a main and support job dropdown -- change
* the whole lineup and click Apply once, or save it as a preset and bring it
* back in one click. Members out as trusts are dismissed and re-called on
* the new jobs by the server; members at home just change.
*
* AND EVERY OTHER CHARACTER ON THE ACCOUNT, under its own heading (2026-09-06).
* The `who` answer has always carried them -- the typed `!jobs` lists them and
* `!jobs set <name>` changes them -- and until this round the window drew only
* the squad slots, which made an alt in no slot the one thing the window could
* not do that the command surface could.
*
* THE LEVELS ON SCREEN ARE THE SERVER'S, NOT char_jobs'. The `c|` record
* carries mlvl and slvl: the played character's are read off the live entity,
* so a level sync or a level restriction is already in them, and slvl has been
* through map.SUBJOB_RATIO. A pick you have NOT applied therefore shows its
* main level and no support level at all, because the ratio is a server
* setting this addon has no way to read and a plausible wrong number is worse
* than none. See mainLevel / subLevelText.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no roster of its own, caches nothing to disk, and has no way to
* change a job the typed command surface could not. Every read is `!dwj who`
* and every write is `!dwj apply|save|use|delete`, which reach exactly the
* same server dispatch `!jobs` reaches -- the only difference is that they
* answer in compact records under the sender name _DWJDATA, which this addon
* parses and blocks before the chat log sees them. Ownership and job unlocks
* are re-checked in the server's C++ and run identically whichever way the
* command arrived; a job a character has not unlocked is not even offered,
* but the server would refuse it regardless.
*
* TYPING `!jobs` ON ITS OWN OPENS THIS WINDOW. The line is intercepted
* before it leaves the client, so the server never sees it; every other
* !jobs command passes through untouched. With the addon off, `!jobs`
* prints everyone's jobs exactly as before.
*
* TURN IT OFF AND NOTHING IS LOST. `!jobs set <char> <main> [sub]`,
* `!jobs save|use|list|delete <name>` all work typed. This is friendlier;
* it is not required.
--]]

addon.name    = 'dwjobs';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.0';
addon.desc    = 'Party job window for DriftwoodXI -- change everyone\'s main and sub jobs by clicking.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. dwbags
-- owns _DWDATA, dwgambits owns _DWGDATA, dwsquad owns _DWSDATA; this addon
-- must never contend for any of them, which is why !dwj exists at all.
local DATA_SENDER = '_DWJDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

local MAX_SLOTS = 5;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

local JOB_COUNT = 22;

-- Character flag bits, as the server packs them.
local CHAR_ONLINE = 1;
local CHAR_LOCKED = 2;
local CHAR_SELF   = 4;

-- The longest a preset name may be, matching the server's cap.
local PRESET_NAME_MAX = 24;

-- The job dropdowns. Wide enough for the widest closed box a row can show,
-- which is a three-letter job, a space and two digits.
local COMBO_WIDTH = 92;

-- Players get addons from the content feed but Ashita itself from whenever
-- they last installed it, so a function this suite has never used before is
-- asked for ONCE here rather than called blind sixty times a second: an
-- unknown imgui field is a nil call and a Lua error per frame. The Copy button
-- is simply not drawn on a client that has no clipboard binding.
local CAN_COPY = type(imgui.SetClipboardText) == 'function';

local state = T{
    open      = T{ false },

    -- Replaced wholesale by a `who` response, never merged, so a stale row
    -- cannot survive a refresh.
    chars     = T{ },

    -- { name, members } in server order. Replaced when a response that
    -- carries `p|` records opens (`who` and `list` both do).
    presets   = T{ },

    -- charid -> { mjob, sjob }: what the player has clicked but not yet
    -- applied. A PLAIN TABLE keyed by charid, not `T{ }` -- unknown keys on a
    -- T{} resolve through its metatable to the sugar methods, which is the
    -- dwbags round-7 bug, paid for once already.
    staged    = { },

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its own
    -- cannot half-fill the UI.
    inbound   = nil,

    -- THE ENVELOPE BEING RECEIVED, STAGED WHOLE. Every record is its own
    -- 0x017 packet, so a `who` answer is fourteen packets and a rendered frame
    -- can land anywhere among them. Wiping `chars` at `d|` and refilling it
    -- record by record therefore drew an EMPTY party -- five "(empty)" rows
    -- and no You -- for as long as the rest of the answer took to arrive, on
    -- every Refresh and after every Apply. Records land here instead and the
    -- whole answer is committed in one assignment at `z|`, which is dwbags'
    -- SECTIONS shape and the suite's rule.
    --
    -- It also fixes the other half: an envelope that never closes (a zone line
    -- mid-answer, a dropped packet) now commits nothing and leaves the ask
    -- outstanding, so needRoster re-asks instead of believing a torn roster.
    pending   = nil,

    -- ONE WRITE IN FLIGHT. Set when a write is queued, cleared by every
    -- terminal state an answer can reach (the `z|who` commit, a refusal, the
    -- protocol gate, the answer clock giving up, a Refresh, a login) -- so it
    -- cannot latch a window shut for ever, which is the failure mode a flag
    -- like this usually ships with.
    --
    -- Without it a second click on Apply, one frame after the first line had
    -- already gone out, queued the SAME line again: the staged picks are not
    -- pruned until the answer lands, so stagedDiffs still had them and issue()
    -- had nothing left in the queue to dedupe against. The second command cost
    -- a throttle window and came back "Nothing to change".
    writing   = false,

    -- How many presets this account may hold, from the server's `n|` record.
    -- 0 means an older server that does not send one, and the counter is then
    -- simply not drawn -- an addon must never invent a number the server owns.
    presetCap = 0,

    -- The last few things said about a change, newest last. An apply that
    -- touches five members sends five `m|` notes and the status line can hold
    -- one, so the four before it used to vanish inside a single frame.
    log       = T{ },

    -- Preset delete asks twice; this is whose first click is pending.
    pendingDelete = nil,

    -- The Save box's buffer. ImGui writes into index 1.
    saveName  = T{ '' },

    status    = 'Loading...',
    statusBad = false,

    -- Whether the sentence on screen is the SERVER's or one of ours. A server
    -- sentence is the only thing telling a player why a change was refused and
    -- must survive the roster that arrives behind it; ours ("Loading...",
    -- "Applying...", the give-up banner) is about a question that has now been
    -- answered, so a completed `who` takes it back down. Without this the
    -- give-up banner sat on screen red for ever, over a window that had been
    -- correct again since the next Refresh.
    statusLocal = true,

    reported  = false,     -- a render error is worth saying once, not per frame

    -- When the last whole `who` landed, so Refresh can say how old the
    -- numbers under it are. The window asks once when it opens, once per
    -- login, and after every write -- so an alt that levelled on another
    -- client, or a `!squad set` typed in another window, is not in them.
    syncedAt  = nil,

    -- THE MODEL REVISION. Bumped by every write to the roster or to the staged
    -- picks, and by nothing else. The render caches below key on it, because
    -- the whole of what this window draws is a pure function of those two
    -- tables and the font -- and it is drawn sixty times a second while a
    -- player reads it, changing perhaps twice a minute.
    rev       = 0,
};

local function bumpModel()
    state.rev = state.rev + 1;
end

-- Bursts need ceilings, and this one grows once per server sentence.
local LOG_MAX = 8;

local function setStatus(text, bad, fromServer)
    state.status      = text;
    state.statusBad   = bad and true or false;
    state.statusLocal = not fromServer;

    -- Only what the server said is worth keeping: "Loading..." and "Applying..."
    -- are this addon narrating itself.
    if (fromServer and text ~= nil and text ~= '') then
        state.log:append({ text = text, bad = bad and true or false });

        while (#state.log > LOG_MAX) do
            table.remove(state.log, 1);
        end
    end
end

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A
* TIME. The client rate-limits outgoing chat, and a !dwj command is a chat
* line; anything over the limit is answered with "A command error occurred"
* before the server ever sees it. So everything queues here and drains at one
* command per SEND_INTERVAL, and duplicates collapse.
--]]
local SEND_INTERVAL = 1.2;

-- A ceiling on a table that grows on events, the rule every other growing
-- table in this suite carries. A BACKSTOP RATHER THAN A WORKING LIMIT, and
-- honestly so: with one write in flight at a time (state.writing) the queue
-- holds at most a write and the roster retry behind it, so nothing a player
-- can do reaches eight. It is here because the alternative to a bound is an
-- unbounded table, and because the shape that fills a queue is a bug in this
-- file rather than a player being fast.
local QUEUE_MAX = 8;

local queue    = T{ };
local lastSend = 0;

-- Declared here rather than with the answer clock below because pumpQueue has
-- to re-stamp it: see the comment there.
local requested = {};

-- Returns whether the line is now on its way -- true for a fresh line AND for
-- one already queued, false only when the ceiling refused it. The write verbs
-- test it: registering the roster as expected for a line that was never taken
-- would leave the window waiting for an answer to a question nobody asked.
local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return true;
        end
    end

    if (#queue >= QUEUE_MAX) then
        return false;
    end

    queue:append(command);

    return true;
end

local function pumpQueue()
    -- The emptiness test FIRST (2026-09-06): this runs sixty times a second
    -- whether the window is open or not, the queue is empty on almost all of
    -- those frames, and echo.canSend() walks the memory manager to the player
    -- object every time it is asked.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));

    -- THE ANSWER CLOCK STARTS WHEN THE QUESTION GOES OUT, not when the button
    -- was clicked. A write registers the roster as expected the moment it is
    -- clicked (expectRoster), and the line behind it waits a throttle window
    -- for every line the player types in the meantime -- so a clock started at
    -- the click aged against a question the server had not been asked yet,
    -- fired a retry, and then said "No answer from the server" about silence
    -- of our own making.
    for _, asked in pairs(requested) do
        if (type(asked) == 'table' and not asked.answered) then
            asked.at = now;
        end
    end
end

--[[
* What has already been asked for, so a window drawn sixty times a second asks
* once. The answer is tracked, not just the question: one lost command must
* not leave the panel stale for ever, and a retry that never terminates is a
* command loop, which is worse than a stale panel. Same shape as dwsquad's.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- The sentence the give-up branch below puts on screen. Named because the
-- commit of a completed answer has to be able to recognise it: it is the
-- addon's own claim about its own clock, and the answer that finally arrives
-- proves it wrong.
local LOST_ANSWER = 'No answer from the server. Press Refresh to ask again.';

local function refresh()
    requested = {};

    -- Whatever was in flight is no longer being waited for: the asks it would
    -- have been answered by are gone.
    state.writing = false;
end

-- An ask is answered whether the server sent the rows or a refusal: the retry
-- exists for a LOST line, not for a line the server took and said no to.
-- Without this an `!dwj who` that dwj.lua answered with its own status
-- envelope ("The squad is not loaded.") was retried twice and then had that
-- accurate sentence replaced by the give-up banner -- the exact shape the
-- suite's protocol gate exists to refuse, arriving by a different door.
local function retireAsks()
    for _, asked in pairs(requested) do
        if (type(asked) == 'table') then
            asked.answered = true;
        end
    end

    state.writing = false;
end

-- A write's response carries the fresh roster, so the roster question is
-- registered as pending without being asked: if the write's answer is lost,
-- needRoster's retry covers it.
local function expectRoster()
    requested['who'] = { at = os.clock(), answered = false, tries = 1 };
    state.writing    = true;
end

local function needRoster()
    local asked = requested['who'];

    if (asked ~= nil) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered) then
            return;
        end

        -- A line of OURS still in the queue is not the server being silent.
        -- The write buttons register the roster as expected at the click and
        -- the line behind them waits a throttle window for every line the
        -- player types, so a clock that ran through that fired a retry and
        -- then a give-up sentence about a question nobody had asked yet.
        -- (pumpQueue re-stamps `at` when a line actually leaves; this is the
        -- half that covers a line which has not left at all.)
        if (#queue > 0) then
            return;
        end

        if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        -- Out of retries and still nothing back. The retry stops here on
        -- purpose -- a command loop is worse than a stale panel -- but a panel
        -- that sits on 'Loading...' for ever without saying why is the worst
        -- available feedback, and the fix is one button away. Said ONCE:
        -- this runs sixty times a second.
        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp  = true;
                state.writing = false;
                setStatus(LOST_ANSWER, true, false);
            end

            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['who'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dwj who');
end

--[[
* Record parsing. Every record is pipe-separated with a single-character
* type. Anything this addon does not recognise is ignored rather than being
* an error: a server newer than the addon must not break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

-- A wire number, refused unless it is a whole one in range. `tonumber` on a
-- LuaJIT build takes 'nan', 'inf' and '2.5' happily, and a chat line has been
-- through every other addon's packet_in handler before it reaches this one --
-- so a scarred field must land as 0 rather than as a fraction that reaches
-- string.format('%d', ...) and comes back as a nine-digit integer nobody sent.
-- (NaN fails `n ~= math.floor(n)`; the range test is what refuses infinity,
-- whose floor is itself.)
local function wholeField(text)
    local n = tonumber(text);

    if (n == nil or n ~= math.floor(n) or n < 0 or n > 4294967295) then
        return 0;
    end

    return n;
end

-- Ceilings over tables filled by the wire. The account cap is 16 characters
-- and the preset cap is 12; these are generous multiples, and their only job
-- is that a server bug or a scarred stream cannot grow a table without bound.
local CHARS_MAX   = 64;
local PRESETS_MAX = 64;

-- Staged entries that now say what the server says are finished business:
-- dropping them here is what clears the yellow highlights the moment an
-- Apply's response lands, with no bookkeeping anywhere else.
local function pruneStaged()
    for charid, pick in pairs(state.staged) do
        local member = state.chars[charid];

        if (member == nil) or (member.mjob == pick.mjob and member.sjob == pick.sjob) then
            state.staged[charid] = nil;
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            setStatus(string.format('Server protocol %s, addon expects %d. Update dwjobs.',
                tostring(parts[2]), PROTOCOL), true, false);

            state.inbound = nil;
            state.pending = nil;

            -- A d| envelope IS the answer, whatever version it announced.
            -- Returning with the ask still outstanding let needRoster re-send
            -- it five seconds later and then replace the one accurate
            -- diagnosis on screen ("Update dwjobs") with the one that is
            -- definitely wrong ("No answer from the server") -- about a server
            -- that had just answered twice. dwfame closed this in its own copy
            -- of the template on 2026-08-15; this copy did not follow.
            --
            -- EVERY pending entry, not parts[3]: a record whose version this
            -- addon cannot parse is exactly the record whose field 3 cannot be
            -- assumed to still be the verb.
            --
            -- Written out here rather than as the retireAsks() call it is a
            -- copy of: harness_dwsuite.py slices THIS branch and looks for the
            -- remedy inside it, and a call it cannot follow reads to that gate
            -- exactly like a branch that returns with the asks outstanding --
            -- which is the failure the gate exists to name.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            state.writing = false;

            return;
        end

        state.inbound = parts[3];

        -- The answer is staged, not applied: `pending` is what the records
        -- behind this one fill, and only `z|` moves it onto the screen. See
        -- state.pending's comment -- a section emptied here and refilled a
        -- packet at a time drew an empty party for as many frames as the rest
        -- of the answer took to arrive.
        --
        -- The reset runs FIRST for the reason it always did: handleRecord is
        -- called under a pcall, and anything that throws after `state.inbound`
        -- is set must cost one record rather than leave the records behind it
        -- appending to the previous answer's staging table.
        state.pending = nil;

        if (state.inbound == 'who') then
            state.pending = { chars = T{ }, presets = T{ }, count = 0, failed = false };
        elseif (state.inbound == 'list') then
            state.pending = { presets = T{ }, count = 0, failed = false };
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- message saying why a change was refused is worth more than the response
    -- it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- Everything after the first pipe, not parts[2]: these carry prose.
        setStatus(line:sub(3), kind == 'e', true);

        -- Errors also go to the chat log: the window may already be closed,
        -- and "nothing happened" is the worst possible feedback.
        if (kind == 'e') then
            print(chat.header('dwjobs'):append(chat.error(state.status)));

            -- An error IS an answer. dwj.lua refuses `!dwj who` in a status
            -- envelope of its own ("The squad is not loaded.") and never opens
            -- a `who` at all, so an ask retired only by `z|who` was re-sent
            -- twice and then had that accurate sentence replaced by the
            -- give-up banner. The retry is for a LOST line.
            retireAsks();

            -- ...and an envelope that failed must not commit whatever partial
            -- rows it managed: the reason is worth more than the rows, and the
            -- rows already on screen are the best truth left.
            if (state.pending ~= nil) then
                state.pending.failed = true;
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        -- A close names the envelope it closes, and the open one is known, so
        -- a `z|` for anything else is a record out of its own stream: it must
        -- not commit a `who` that is still half-arrived, nor retire the ask
        -- that `who` is the answer to.
        if (parts[2] ~= nil and parts[2] ~= '' and parts[2] ~= state.inbound) then
            return;
        end

        local pending = state.pending;

        if (pending ~= nil and not pending.failed) then
            if (state.inbound == 'who') then
                state.chars     = pending.chars;
                state.presets   = pending.presets;
                state.presetCap = pending.cap or 0;

                pruneStaged();
            elseif (state.inbound == 'list') then
                state.presets   = pending.presets;
                state.presetCap = pending.cap or state.presetCap;
            end

            bumpModel();
        end

        if (state.inbound == 'who') then
            -- Retired HERE, not at `d|`: an envelope that never closes -- a
            -- zone line mid-answer, a dropped packet -- left the ask marked
            -- answered and the panel torn, with nothing that would ever ask
            -- again short of the player pressing Refresh.
            local asked = requested['who'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end

            state.writing  = false;
            state.syncedAt = os.clock();

            -- Our own sentence about our own clock is finished business now
            -- that the answer is in; the server's is not (it arrived just
            -- ahead of the roster it caused, and it is the only thing telling
            -- the player why a change was refused).
            if (state.statusLocal) then
                setStatus('', false, false);
            end
        end

        state.pending = nil;
        state.inbound = nil;

        return;
    end

    if (kind == 'c' and state.pending ~= nil and state.inbound == 'who') then
        if (state.pending.count >= CHARS_MAX) then
            return;
        end

        local charid = wholeField(parts[2]);

        -- No character has charid 0, so this is a field that did not survive
        -- the trip -- and TWO of them would share every widget id in their
        -- rows, which is the merged-click bug the id scheme exists to prevent.
        if (charid == 0) then
            return;
        end

        local name = parts[3];

        if (name == nil or name == '') then
            name = '?';
        end

        state.pending.count = state.pending.count + 1;

        state.pending.chars[charid] = T{
            charid   = charid,
            name     = name,
            mjob     = wholeField(parts[4]),
            mlvl     = wholeField(parts[5]),
            sjob     = wholeField(parts[6]),
            slvl     = wholeField(parts[7]),
            flags    = wholeField(parts[8]),
            slot     = wholeField(parts[9]),
            unlocked = wholeField(parts[10]),

            -- Filled by the `j|` record that follows; zeroed here so a lost
            -- one renders as level 0 rather than a Lua error.
            levels   = {},
        };

        return;
    end

    if (kind == 'j' and state.pending ~= nil and state.inbound == 'who') then
        local charid = wholeField(parts[2]);
        local member = state.pending.chars[charid];

        if (member == nil) then
            return;
        end

        local levels = {};
        local jobId  = 1;

        for level in string.gmatch(parts[3] or '', '([^,]*),?') do
            if (jobId > JOB_COUNT) then
                break;
            end

            levels[jobId] = wholeField(level);
            jobId = jobId + 1;
        end

        member.levels = levels;

        return;
    end

    -- `n|<saved>|<cap>` -- how many lineups the account holds and may hold.
    -- ADDITIVE (2026-09-06): a server that does not send it leaves presetCap at
    -- 0 and the window draws no counter, so deployment order does not matter in
    -- either direction and no protocol version moves.
    if (kind == 'n' and state.pending ~= nil
            and (state.inbound == 'who' or state.inbound == 'list')) then
        state.pending.cap = wholeField(parts[3]);

        return;
    end

    if (kind == 'p' and state.pending ~= nil
            and (state.inbound == 'who' or state.inbound == 'list')) then
        if (#state.pending.presets >= PRESETS_MAX) then
            return;
        end

        state.pending.presets:append(T{
            name    = parts[2] or '?',
            members = wholeField(parts[3]),
        });

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Layout after the 4-byte header: sName[15]
* at 0x08, Mes at 0x17. Any line whose sender is _DWJDATA is ours: it is
* consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwjobs_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwjobs'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Helpers over the roster.
--]]

local function isSelf(member)
    return bit.band(member.flags, CHAR_SELF) ~= 0;
end

local function selfMember()
    for _, member in pairs(state.chars) do
        if (isSelf(member)) then
            return member;
        end
    end

    return nil;
end

local function unlockedHas(member, jobId)
    return bit.band(member.unlocked, bit.lshift(1, jobId)) ~= 0;
end

local function levelOf(member, jobId)
    if (jobId == 0) then
        return 0;
    end

    return member.levels[jobId] or 0;
end

-- What this member's pair currently reads as in the window: the staged pick
-- if there is one, the server truth otherwise.
local function effective(member)
    local pick = state.staged[member.charid];

    if (pick ~= nil) then
        return pick.mjob, pick.sjob, true;
    end

    return member.mjob, member.sjob, false;
end

--[[
* THE LEVELS ON SCREEN ARE THE SERVER'S. (2026-09-06.)
*
* The `c|` record carries mlvl and slvl and this addon used to render neither,
* reaching into the `j|` levels instead -- and those are two different numbers:
*
*   * mlvl for the character being played is read off the LIVE entity
*     (squad_jobs.cpp:321), so a level sync or a level restriction is already
*     in it, while char_jobs still says 75;
*   * slvl has been through subLevelFor(), which switches on map.SUBJOB_RATIO
*     -- a server setting the addon has no way to read.
*
* So the window said "BLM75/WHM74" about a character its own `!jobs` described
* as "BLM60/WHM30". These two helpers answer with the server's numbers wherever
* the server has an opinion, and DELIBERATELY DO NOT MIRROR subLevelFor: a
* staged support job has no level until the server writes it, and the honest
* reading of that is no number at all rather than a plausible wrong one.
--]]
local function mainLevel(member, mjob)
    if (mjob == member.mjob) then
        return member.mlvl;
    end

    -- A main the player has staged: that job's own level is the best number
    -- available, and it is the number the player just picked out of the list.
    return levelOf(member, mjob);
end

-- `gap` is what sits between the job and its level: nothing in the compact
-- summary column ("BLM75/WHM37"), a space in a dropdown box ("WHM 37").
local function subLevelText(member, sjob, isStaged, gap)
    if (sjob == 0) then
        return nil;
    end

    if (not isStaged and sjob == member.sjob) then
        return string.format('%s%s%d', JOB_NAMES[sjob] or '?', gap or '', member.slvl);
    end

    return JOB_NAMES[sjob] or '?';
end

local function jobsLabel(member)
    local mjob, sjob, isStaged = effective(member);
    local text = string.format('%s%d', JOB_NAMES[mjob] or '?', mainLevel(member, mjob));
    local sub  = subLevelText(member, sjob, isStaged);

    if (sub ~= nil) then
        text = text .. '/' .. sub;
    end

    return text;
end

-- The changes Apply would send: staged picks that still differ from the
-- server truth, as ready-made wire tokens.
--
-- SORTED BY CHARID, because `pairs` over a table keyed by charid has no order
-- worth relying on and the line is compared as a STRING by issue()'s dedupe.
-- Two clicks that mean the same lineup must produce the same bytes, or the
-- second one is queued as a second command and costs a throttle window to say
-- "Nothing to change".
local diffCache = { rev = -1, diffs = T{ } };

local function stagedDiffs()
    if (diffCache.rev == state.rev) then
        return diffCache.diffs;
    end

    local ids = T{ };

    for charid, pick in pairs(state.staged) do
        local member = state.chars[charid];

        if (member ~= nil and (member.mjob ~= pick.mjob or member.sjob ~= pick.sjob)) then
            ids:append(charid);
        end
    end

    table.sort(ids);

    local diffs = T{ };

    for _, charid in ipairs(ids) do
        local pick = state.staged[charid];

        diffs:append(string.format('%d:%d:%d', charid, pick.mjob, pick.sjob));
    end

    diffCache.rev   = state.rev;
    diffCache.diffs = diffs;

    return diffs;
end

--[[
* Staging. A click never talks to the server: it edits the staged pair for
* that character, and only Apply turns the lot into one !dwj apply line.
--]]
local function stage(member, mjob, sjob)
    bumpModel();

    -- Picking exactly what the server already has is un-staging, not a
    -- change: an entry that matches the truth would paint the row caution
    -- yellow forever, because Apply filters no-ops out (stagedDiffs) and so
    -- never triggers the roster refresh that prunes the entry.
    if (member.mjob == mjob and member.sjob == sjob) then
        state.staged[member.charid] = nil;
        return;
    end

    state.staged[member.charid] = { mjob = mjob, sjob = sjob };
end

local function stageMain(member, jobId)
    local _, sjob = effective(member);

    -- Picking your current support as the new main swaps the two, which is
    -- what that click means ("trade BLM/WHM for WHM/BLM") and is exactly what
    -- the retail Mog House menu does with the same input.
    if (jobId == sjob) then
        local mjob = effective(member);

        stage(member, jobId, mjob);
        return;
    end

    stage(member, jobId, sjob);
end

local function stageSub(member, jobId)
    local mjob = effective(member);

    stage(member, mjob, jobId);
end

--[[
* Writes. Every one is a server command a player could type, queued through
* the throttle, with the roster registered as an expected answer so a lost
* response is re-asked rather than trusted.
--]]
local function applyStaged()
    local diffs = stagedDiffs();

    if (#diffs == 0) then
        setStatus('Nothing to apply.', false, false);
        return;
    end

    if (not issue('!dwj apply ' .. table.concat(diffs, ' '))) then
        setStatus('Too many commands waiting -- try again in a moment.', true, false);
        return;
    end

    expectRoster();


    setStatus('Applying...', false, false);
end

local function usePreset(name)
    if (not issue('!dwj use ' .. name)) then
        setStatus('Too many commands waiting -- try again in a moment.', true, false);
        return;
    end

    -- Picks not yet applied are abandoned by choosing a preset: the preset is
    -- the new statement of intent, and stale yellow rows over its result would
    -- read as the preset having half-worked. AFTER the line is accepted, so a
    -- refused one does not also cost the player the picks it never replaced.
    state.staged = { };
    bumpModel();

    expectRoster();


    setStatus(string.format('Applying "%s"...', name), false, false);
end

local function savePreset(name)
    if (not issue('!dwj save ' .. name)) then
        setStatus('Too many commands waiting -- try again in a moment.', true, false);
        return;
    end

    expectRoster();


    setStatus(string.format('Saving "%s"...', name), false, false);
end

local function deletePreset(name)
    if (not issue('!dwj delete ' .. name)) then
        setStatus('Too many commands waiting -- try again in a moment.', true, false);
        return;
    end

    expectRoster();


    setStatus(string.format('Deleting "%s"...', name), false, false);
end

--[[
* Rendering.
*
* THE TOOLTIPS LIVE IN A TABLE. Every sentence the window explains itself with
* is here rather than spelled inline, so tools/dwjobs/harness_dwjobs.py can
* hold the table against what the window actually draws: a control that grows
* a new meaning cannot keep an old sentence and still pass.
--]]
local TIPS = {
    apply     = 'Send every change marked with a star, as one command. A member out as a trust is dismissed and re-called on the new jobs; a member at home just changes.',
    applyNone = 'Nothing is picked yet. Choose a job in one of the dropdowns and this sends the lot in a single command.',
    revert    = 'Throw away every pick you have not applied. Nothing is sent.',
    refresh   = 'Read the account\'s jobs from the server again.',
    copy      = 'Copy the whole lineup to the clipboard, one line per character.',
    busy      = 'A command is on its way. The buttons that send stay off until the server answers, so one click cannot become two commands.',
    queued    = 'The client rate-limits outgoing chat, so commands leave one at a time. Nothing here is lost -- it is waiting its turn.',
    main      = 'The main job. Only jobs this character has unlocked are offered, and the number beside each is that character\'s own level in it. Picking the current support job here trades the two.',
    sub       = 'The support job. The server caps it against the main job, so a pick you have not applied yet shows no number -- the real one arrives with the change.',
    now       = 'What the server says this character is on. A row you have changed shows your pick instead, marked with a star.',
    out       = 'Out as a trust right now. Applying a change to this member dismisses and re-calls them.',
    online    = 'Logged in on another client. The server refuses a job change for a character with a live session, because that session owns its rows and would write yours back over. Log it out first.',
    empty     = 'No character is registered in this squad slot. Use /squad to put one here.',
    youSlot   = 'This slot holds the character you are playing, which is drawn once as the You row above.',
    others    = 'Characters on this account that hold no squad slot. They cannot be summoned until /squad registers one, but their jobs are yours to change from here.',
    saveName  = 'Letters, digits, spaces and dashes, up to 24 characters. The server refuses anything else.',
    save      = 'Remember what everyone is on RIGHT NOW under this name. It snapshots what the server holds, so apply your changes first.',
    presets   = 'How many lineups this account has saved, and how many it may hold.',
    members   = 'How many characters this lineup remembers. It was whoever held a squad slot the day it was saved.',
    status    = 'The last thing said about a change, by the server or by this window.',
};

local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

-- "a moment", "48 seconds", "6 minutes". Whole numbers only: this feeds a
-- sentence, and "6.3 minutes" is a machine talking.
local function fmtAge(seconds)
    if (seconds < 5) then
        return 'a moment';
    end

    if (seconds < 90) then
        return string.format('%d seconds', seconds);
    end

    local minutes = math.floor(seconds / 60);

    return string.format('%d minute%s', minutes, minutes == 1 and '' or 's');
end

-- One job dropdown. `current` is what it shows; onPick(jobId) stages the
-- choice. The support flavour offers "(none)" and hides the main job; both
-- flavours offer only jobs the character has unlocked, because a locked job
-- is a content gate and the server would refuse it anyway. EVERY WIDGET ID
-- CARRIES THE CHARACTER ID: two Selectables with the same label in one
-- window would merge their click handling.
--
-- `label` is what the CLOSED box reads, and it is passed in rather than
-- derived here because the closed box states the server's truth (see
-- mainLevel / subLevelText) while the LIST states the character's own job
-- levels, which is the right number to pick from.
local function jobCombo(member, comboId, current, excluded, allowNone, tag, label, hint, onPick)
    imgui.PushItemWidth(COMBO_WIDTH);

    if (imgui.BeginCombo(comboId, label)) then
        if (allowNone) then
            if (imgui.Selectable(string.format('(none)##%s_%d_none', tag, member.charid), current == 0)) then
                onPick(0);
            end
        end

        for jobId = 1, JOB_COUNT do
            if (jobId ~= excluded and unlockedHas(member, jobId)) then
                if (imgui.Selectable(string.format('%s %d##%s_%d_%d',
                        JOB_NAMES[jobId], levelOf(member, jobId), tag, member.charid, jobId),
                        jobId == current)) then
                    onPick(jobId);
                end
            end
        end

        imgui.EndCombo();
    else
        -- Only while the list is shut: a tooltip over an open dropdown covers
        -- the very rows it is describing.
        tip(hint);
    end

    imgui.PopItemWidth();
end

-- What a row's name cell says beside the name, and why. Returned rather than
-- drawn so the column can be measured with the tag on it.
local function memberTag(member)
    if (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
        return '[out]', TIPS.out;
    end

    -- A live session owns char_stats in memory, so squad_jobs.cpp refuses the
    -- write outright ("That character is logged in right now."). The flag has
    -- ridden the wire since the window shipped and nothing rendered it, so the
    -- only way to find out was to stage the change and read the red sentence.
    if (not isSelf(member) and bit.band(member.flags, CHAR_ONLINE) ~= 0) then
        return '[logged in]', TIPS.online;
    end

    return nil, nil;
end

-- One party row, from the cached description built by rebuildView(). Nothing
-- here formats a string or measures text: at sixty frames a second over up to
-- twenty rows, that was the whole cost of the panel.
local function memberRow(row)
    local member = row.member;

    imgui.TableNextRow();
    imgui.TableNextColumn();
    imgui.Text(row.label);

    if (row.rowTip ~= nil) then
        tip(row.rowTip);
    end

    imgui.TableNextColumn();

    if (row.staged) then
        -- The theme's caution colour marks "picked but not applied", cleared
        -- the moment the apply's response confirms it.
        imgui.TextColored(theme.colors.warn, member.name);
    else
        imgui.Text(member.name);
    end

    if (row.tag ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(row.tag);
        tip(row.tagTip);
    end

    imgui.TableNextColumn();
    -- The support dropdown never offers the main job, so the swap gesture --
    -- picking the current support AS the main -- lives on the main dropdown,
    -- where stageMain turns it into the BLM/WHM -> WHM/BLM trade it means.
    jobCombo(member, row.mainId, row.mjob, 0, false, 'm', row.mainLabel, TIPS.main,
        function (jobId)
            stageMain(member, jobId);
        end);

    imgui.TableNextColumn();
    jobCombo(member, row.subId, row.sjob, row.mjob, true, 's', row.subLabel, TIPS.sub,
        function (jobId)
            stageSub(member, jobId);
        end);

    imgui.TableNextColumn();

    if (row.staged) then
        imgui.TextColored(theme.colors.warn, row.summary);
    else
        imgui.TextDisabled(row.summary);
    end

    tip(TIPS.now);
end

--[[
* THE VIEW, MEASURED ONCE PER CHANGE. (2026-09-06.)
*
* SIZES ARE MEASURED, NOT TYPED. Every width and height in this panel used to
* be a pixel count that was right once, at one font, on one window size:
*
*   * the name column was 116px, and a fifteen-character name with an " [out]"
*     tag after it is wider than that at the default font -- it overflowed into
*     the main dropdown beside it;
*   * the party panel was 208px tall, which fits six framed rows at the default
*     font and clips the last one at any larger, with no scrollbar to reach it;
*   * and the Save box sat at the bottom of the SAME scroll region as the
*     preset list, so an account near the twelve-preset cap could not scroll to
*     the box that names a new one -- the window is NoScrollbar by design.
*
* CalcTextSize and the two frame-metric calls answer all three at whatever the
* player's font actually is.
*
* AND MEASURED ONCE, because they are not free. Everything below -- who is in
* which slot, what each row's five cells read, how wide the widest name is --
* is a pure function of the roster, the staged picks and the font. All three
* change perhaps twice a minute; the render runs sixty times a second.
* Rebuilding the row list, sorting it, and asking CalcTextSize once per member
* EVERY FRAME is the shape the house rule about hoisting per-frame work exists
* for, and the measured widths above would otherwise have made this window
* more expensive than the one they fixed.
*
* The font is part of the cache key: GetTextLineHeightWithSpacing moves when
* the player scales the interface, and a width measured at the old size would
* sit stale until the next roster answer.
--]]
local view = {
    rev        = -1,
    metric     = -1,
    rows       = T{ },
    presets    = T{ },
    nameWidth  = 0,
    members    = 0,
    subtitle   = '-- you and the five squad slots',
    applyLabel = 'Apply changes',
    applyTip   = '',
};

local function buildRow(label, rowTip, member)
    local mjob, sjob, isStaged = effective(member);
    local tag, tagTip = memberTag(member);
    local summary     = jobsLabel(member);

    if (isStaged) then
        summary = summary .. ' *';
    end

    return {
        kind      = 'member',
        label     = label,
        rowTip    = rowTip,
        member    = member,
        staged    = isStaged,
        mjob      = mjob,
        sjob      = sjob,
        tag       = tag,
        tagTip    = tagTip,
        mainLabel = string.format('%s %d', JOB_NAMES[mjob] or '?', mainLevel(member, mjob)),
        subLabel  = subLevelText(member, sjob, isStaged, ' ') or '(none)',
        summary   = summary,

        -- EVERY WIDGET ID CARRIES THE CHARACTER ID (see jobCombo), and both
        -- were formatted per row per frame until they moved here.
        mainId    = string.format('##dwjobs_m_%d', member.charid),
        subId     = string.format('##dwjobs_s_%d', member.charid),
    };
end

local function rebuildView()
    local me     = selfMember();
    local slots  = T{ };
    local others = T{ };

    for _, member in pairs(state.chars) do
        if (not isSelf(member)) then
            if (member.slot >= 1 and member.slot <= MAX_SLOTS) then
                -- THE CHARACTER BEING PLAYED IS LEFT OUT EVEN WHEN IT HOLDS A
                -- SLOT, and that is reachable: `!squad set` refuses to register
                -- the character you are playing, but nothing stops you
                -- registering an alt and then logging in AS that alt, which the
                -- squad supports on purpose. Its row then answered both
                -- selfMember() and this, so the window drew the same charid
                -- twice -- and both rows built their dropdowns from
                -- `##dwjobs_m_<charid>`, which is ONE ImGui id used twice in one
                -- window. That is the merged-click bug the id scheme exists to
                -- prevent, and the panel says which slot it is in below instead.
                slots[member.slot] = member;
            else
                others:append(member);
            end
        end
    end

    -- By name, so the list does not reshuffle between frames: `pairs` over a
    -- charid-keyed table has no order worth showing a player.
    table.sort(others, function (a, b)
        return a.name < b.name;
    end);

    local rows   = T{ };
    local widest = (imgui.CalcTextSize('Character'));

    local function measure(row)
        local text = row.member.name;

        if (row.tag ~= nil) then
            text = text .. ' ' .. row.tag;
        end

        widest = math.max(widest, (imgui.CalcTextSize(text)));
    end

    if (me ~= nil) then
        local row = buildRow('You', nil, me);

        rows:append(row);
        measure(row);
    end

    for slot = 1, MAX_SLOTS do
        local member = slots[slot];

        if (member ~= nil) then
            local row = buildRow(string.format('%d.', slot), nil, member);

            rows:append(row);
            measure(row);
        elseif (me ~= nil and me.slot == slot) then
            rows:append({ kind = 'you', label = string.format('%d.', slot) });
        else
            rows:append({ kind = 'empty', label = string.format('%d.', slot) });
        end
    end

    -- THE REST OF THE ACCOUNT. The `who` answer has always carried every
    -- character on the account -- the typed `!jobs` lists them all and
    -- `!jobs set <name>` changes them -- and this window drew only the squad
    -- slots, so an alt in no slot was the one thing the window could not do
    -- that the command surface could.
    if (#others > 0) then
        rows:append({ kind = 'heading' });

        for _, member in ipairs(others) do
            local row = buildRow('-', TIPS.others, member);

            rows:append(row);
            measure(row);
        end
    end

    view.rows      = rows;
    view.nameWidth = widest + 16;
    view.members   = 1 + MAX_SLOTS + #others;

    -- The subtitle stopped being true the moment the rest of the account
    -- joined the panel, and an account with nothing outside the squad should
    -- not be told about a section it has not got.
    view.subtitle = #others > 0
        and '-- you, the five squad slots, and the rest of the account'
        or  '-- you and the five squad slots';

    -- The preset rows carry four formatted strings apiece -- two widget ids, a
    -- member count and, until this round, two tooltips built whether anybody
    -- was hovering or not. Twelve presets was sixty string.formats a frame for
    -- a list that changes when somebody clicks Save.
    local presets = T{ };

    for index, preset in ipairs(state.presets) do
        presets:append({
            name    = preset.name,
            useId   = string.format('Use##p_%d', index),
            delId   = string.format('X##pd_%d', index),
            armedId = string.format('Really delete?##pd_%d', index),
            count   = string.format('(%d member%s)', preset.members, preset.members == 1 and '' or 's'),
        });
    end

    view.presets = presets;

    local diffs = stagedDiffs();

    view.applyLabel = #diffs > 0
        and string.format('Apply changes (%d)', #diffs)
        or 'Apply changes';

    view.applyTip = #diffs > 0 and TIPS.apply or TIPS.applyNone;
end

local function currentView()
    local metric = imgui.GetTextLineHeightWithSpacing();

    if (view.rev ~= state.rev or view.metric ~= metric) then
        view.rev    = state.rev;
        view.metric = metric;

        rebuildView();
    end

    return view;
end

local function partyPanelHeight(rows)
    local _, avail = imgui.GetContentRegionAvail();
    local line     = imgui.GetTextLineHeightWithSpacing();
    local row      = imgui.GetFrameHeightWithSpacing();

    -- What it wants: its own title line, a separator, the table's frozen
    -- header row, and one framed row per member -- capped, because an account
    -- with sixteen characters must not push the presets panel off the window.
    local wanted = line * 2 + row * (math.min(rows, 9) + 1) + 8;

    -- What the presets panel below has to keep: a title, a separator, one
    -- preset row and its pinned Save box.
    local floor = line * 2 + row * 3;

    return math.max(row * 3, math.min(wanted, avail - floor));
end

local function partyPanel()
    local model = currentView();

    -- NOTE: the third argument is ImGuiChildFlags, not a bool -- Ashita ships
    -- ImGui 1.90+, and a bool here raises a Lua error on every frame.
    imgui.BeginChild('##dwjobs_party', { 0, partyPanelHeight(model.members) },
        ImGuiChildFlags_Borders);

    imgui.Text('Your party');
    imgui.SameLine();
    imgui.TextDisabled(model.subtitle);
    imgui.Separator();

    if (imgui.BeginTable('##dwjobs_party_table', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY),
            { -1, 0 })) then
        -- WidthFixed throughout, like the other Driftwood addons: only the
        -- flags they already use are proven to exist in this environment's
        -- ImGui bindings, and a nil flag global is a Lua error per frame. The
        -- WIDTHS are measured (see the block comment above).
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, (imgui.CalcTextSize('99.')) + 8, 0);
        imgui.TableSetupColumn('Character', ImGuiTableColumnFlags_WidthFixed, model.nameWidth, 0);
        imgui.TableSetupColumn('Main', ImGuiTableColumnFlags_WidthFixed, COMBO_WIDTH + 24, 0);
        imgui.TableSetupColumn('Support', ImGuiTableColumnFlags_WidthFixed, COMBO_WIDTH + 24, 0);
        imgui.TableSetupColumn('Now', ImGuiTableColumnFlags_WidthFixed, (imgui.CalcTextSize('WAR99/WAR99 *')) + 8, 0);

        -- The header stays put while the rows scroll under it. Two unlabelled
        -- dropdowns side by side told a player nothing about which was which.
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(model.rows) do
            if (row.kind == 'member') then
                memberRow(row);
            else
                imgui.TableNextRow();
                imgui.TableNextColumn();

                if (row.kind == 'heading') then
                    imgui.TableNextColumn();
                    imgui.TextDisabled('Other characters');
                    tip(TIPS.others);
                else
                    imgui.TextDisabled(row.label);
                    imgui.TableNextColumn();

                    if (row.kind == 'you') then
                        -- Registered here, and it is the character you are
                        -- playing: drawn once as "You" above rather than twice
                        -- with the same widget ids. Saying so beats an
                        -- "(empty)" that is a lie.
                        imgui.TextDisabled('(you)');
                        tip(TIPS.youSlot);
                    else
                        imgui.TextDisabled('(empty)');
                        tip(TIPS.empty);
                    end
                end

                imgui.TableNextColumn();
                imgui.TableNextColumn();
                imgui.TableNextColumn();
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

-- The lineup as text, for the clipboard. Names and jobs only: a share of "what
-- is everyone on" is the thing worth pasting into a party chat.
local function lineupText()
    local model = currentView();
    local lines = T{ };

    for _, row in ipairs(model.rows) do
        if (row.kind == 'member') then
            lines:append(string.format('%s %s  %s%s', row.label, row.member.name,
                row.summary, row.tag ~= nil and ('  ' .. row.tag) or ''));
        elseif (row.kind == 'empty') then
            lines:append(string.format('%s (empty)', row.label));
        elseif (row.kind == 'you') then
            lines:append(string.format('%s (you)', row.label));
        end
    end

    return table.concat(lines, '\n');
end

-- Does the typed preset name already exist? See the block in presetsPanel.
local saveMatch = { typed = nil, rev = -1, overwrite = false };

local function presetsPanel()
    local model = currentView();

    imgui.BeginChild('##dwjobs_presets', { 0, 0 }, ImGuiChildFlags_Borders);

    imgui.Text('Presets');
    imgui.SameLine();
    imgui.TextDisabled('-- whole lineups, one click to bring back');

    -- The account's preset cap, when the server told us what it is. An older
    -- server sends no `n|` record and the counter simply does not appear.
    if (state.presetCap > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('(%d of %d)', #state.presets, state.presetCap));
        tip(TIPS.presets);
    end

    imgui.Separator();

    -- The list scrolls inside its own region and the Save row is PINNED below
    -- it: they used to share one scroll region, so the box that names a new
    -- preset went out of reach exactly when an account had the most of them.
    local footer = imgui.GetFrameHeightWithSpacing() + imgui.GetTextLineHeightWithSpacing();

    imgui.BeginChild('##dwjobs_preset_list', { 0, -footer }, ImGuiChildFlags_None);

    if (#state.presets == 0) then
        imgui.TextDisabled('None yet. Set the party up, apply it, then save it here.');
    end

    imgui.BeginDisabled(state.writing);

    for _, preset in ipairs(model.presets) do
        if (imgui.SmallButton(preset.useId)) then
            state.pendingDelete = nil;
            usePreset(preset.name);
        end

        -- Built INSIDE the hover test: a tooltip formatted whether anybody is
        -- hovering or not is a string allocated sixty times a second per row.
        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('Put everyone on their "%s" jobs.', preset.name));
        end

        imgui.SameLine();

        -- Delete asks twice: the first click arms it, the second within the
        -- same window session fires it. A preset is cheap to remake, but an
        -- accidental single click should still not cost one.
        if (state.pendingDelete == preset.name) then
            if (imgui.SmallButton(preset.armedId)) then
                state.pendingDelete = nil;
                deletePreset(preset.name);
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Delete "%s" for good. Click anything else to change your mind.', preset.name));
            end
        else
            if (imgui.SmallButton(preset.delId)) then
                state.pendingDelete = preset.name;
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Delete "%s". Asks once more first.', preset.name));
            end
        end

        imgui.SameLine();
        imgui.Text(preset.name);
        imgui.SameLine();
        imgui.TextDisabled(preset.count);
        tip(TIPS.members);
    end

    imgui.EndDisabled();

    imgui.EndChild();

    imgui.Separator();

    imgui.Text('Save current as');
    imgui.SameLine();
    imgui.PushItemWidth(160);

    -- EnterReturnsTrue: typing a name and pressing Enter is what a text box
    -- with one button beside it means, and reaching for the mouse to finish a
    -- sentence you just typed is the sort of small friction a window like this
    -- exists to remove.
    local entered = imgui.InputText('##dwjobs_savename', state.saveName, PRESET_NAME_MAX + 1,
        ImGuiInputTextFlags_EnterReturnsTrue);

    imgui.PopItemWidth();
    tip(TIPS.saveName);
    imgui.SameLine();

    -- WHAT THE BUTTON WILL DO, in its own label. Re-saving a name overwrites
    -- it (cpp/squad_jobs.cpp: "the cap only guards NEW names"), and a button
    -- that says "Save" while it is about to replace a lineup somebody built is
    -- the sort of quiet the delete confirm exists to avoid.
    --
    -- Answered only when the text or the preset list moves: a :lower() per
    -- preset per frame is a dozen strings a frame for a box somebody typed
    -- into once.
    local typed = tostring(state.saveName[1] or ''):gsub('^%s+', ''):gsub('%s+$', '');

    if (saveMatch.typed ~= typed or saveMatch.rev ~= state.rev) then
        saveMatch.typed     = typed;
        saveMatch.rev       = state.rev;
        saveMatch.overwrite = false;

        if (typed ~= '') then
            local lowered = typed:lower();

            for _, preset in ipairs(state.presets) do
                if (preset.name:lower() == lowered) then
                    saveMatch.overwrite = true;
                    break;
                end
            end
        end
    end

    local overwrite = saveMatch.overwrite;

    imgui.BeginDisabled(state.writing);

    -- Enter counts as the click, but never while a write is in flight: the
    -- button beside it is disabled for that, and a keystroke must not be the
    -- one door that is still open.
    if (imgui.SmallButton(overwrite and 'Overwrite##preset_save' or 'Save##preset_save')
            or (entered and not state.writing)) then
        local name = typed;

        if (name == '') then
            setStatus('A preset needs a name.', true, false);
        elseif (name:find('[^%w %-]') ~= nil) then
            -- cleanName (cpp/squad_jobs.cpp:157) refuses anything but letters,
            -- digits, spaces and dashes, and a pipe would split the `p|` record
            -- the answer comes back in. Said here so it costs no round trip.
            setStatus('A preset name holds letters, digits, spaces and dashes only.', true, false);
        elseif (#stagedDiffs() > 0) then
            -- Saving snapshots the SERVER's lineup, and the window is showing
            -- picks the server has not heard about yet. Saving now would
            -- remember the wrong thing and read as a bug later.
            setStatus('Apply your changes first, then save.', true, false);
        else
            savePreset(name);
        end
    end

    if (imgui.IsItemHovered()) then
        if (overwrite) then
            imgui.SetTooltip(string.format('"%s" already exists. This replaces what it remembers with what everyone is on right now.', typed));
        elseif (state.presetCap > 0 and #state.presets >= state.presetCap) then
            imgui.SetTooltip(string.format('This account already holds its %d saved lineup%s. Delete one first, or type the name of one to replace it.',
                state.presetCap, state.presetCap == 1 and '' or 's'));
        else
            imgui.SetTooltip(TIPS.save);
        end
    end

    imgui.EndDisabled();

    imgui.EndChild();
end

local function renderWindow()
    local model = currentView();

    imgui.BeginDisabled(state.writing);

    if (imgui.Button(model.applyLabel)) then
        state.pendingDelete = nil;
        applyStaged();
    end

    -- ImGui answers IsItemHovered() with false for a disabled item, so this
    -- says nothing while a write is in flight -- which is what the progress
    -- text below is for.
    tip(model.applyTip);

    imgui.EndDisabled();

    imgui.SameLine();

    if (imgui.Button('Revert')) then
        state.staged        = { };
        state.pendingDelete = nil;
        bumpModel();
        setStatus('', false, false);
    end

    tip(TIPS.revert);

    imgui.SameLine();

    if (imgui.Button('Refresh')) then
        state.pendingDelete = nil;
        refresh();
    end

    if (imgui.IsItemHovered()) then
        if (state.syncedAt ~= nil) then
            -- Built inside the hover test: a sentence formatted every frame is
            -- a string allocated sixty times a second for nobody.
            imgui.SetTooltip(string.format(
                '%s These are %s old -- the window reads once when it opens, once per login, and after every change it makes, so a job levelled on another client is not in them yet.',
                TIPS.refresh, fmtAge(math.max(0, math.floor(os.clock() - state.syncedAt)))));
        else
            imgui.SetTooltip(TIPS.refresh);
        end
    end

    imgui.SameLine();

    if (CAN_COPY) then
        if (imgui.Button('Copy')) then
            imgui.SetClipboardText(lineupText());
            setStatus('Lineup copied to the clipboard.', false, false);
        end

        tip(TIPS.copy);

        imgui.SameLine();
    end

    -- A throttled queue has to look like progress rather than like nothing
    -- happening, and it is where the reason the write buttons are off lives:
    -- a disabled control cannot be hovered.
    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
        tip(TIPS.queued);
    elseif (state.writing) then
        imgui.TextDisabled('waiting for the server...');
        tip(TIPS.busy);
    else
        imgui.TextDisabled('');
    end

    -- The message line gets its own row, and errors are red: the reason a
    -- change was refused is the only thing telling a player what to do
    -- instead. The row is drawn EVEN WHEN EMPTY so the panels below it do not
    -- jump a line up and down every time a message comes and goes.
    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end

        -- An apply that changes five members sends five `m|` notes and this
        -- line can hold one, so the four before it used to vanish inside a
        -- frame. They are kept and shown here.
        if (imgui.IsItemHovered() and #state.log > 1) then
            imgui.BeginTooltip();
            imgui.TextDisabled('Recent messages, newest last:');

            for _, entry in ipairs(state.log) do
                if (entry.bad) then
                    imgui.TextColored(theme.colors.err, entry.text);
                else
                    imgui.Text(entry.text);
                end
            end

            imgui.EndTooltip();
        elseif (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.status);
        end
    else
        imgui.TextDisabled(' ');
    end

    imgui.Separator();

    partyPanel();
    presetsPanel();

    needRoster();
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather
* than the addon: an error thrown inside d3d_present is raised sixty times a
* second and the addon host answers a long enough run by unloading the addon.
* Begin and End stay outside the pcall to keep ImGui's window stack balanced;
* the error is reported once and the window closes itself. Everything it does
* is still reachable as !jobs commands, so closing it is a real fallback.
--]]
ashita.events.register('d3d_present', 'dwjobs_present', function ()
    -- Before the visibility check: a click issued a moment before the window
    -- was closed still has to reach the server.
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    imgui.SetNextWindowSize({ 520, 460 }, ImGuiCond_FirstUseEver);

    -- A FLOOR UNDER THE WINDOW. It is flagged NoScrollbar, so anything the
    -- player squeezes off the bottom edge -- the Save box, the preset list --
    -- cannot be scrolled back into reach; the panels below size themselves
    -- from what is left, and below this they have nothing left to size from.
    imgui.SetNextWindowSizeConstraints({ 420, 300 }, { 99999, 99999 });

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Jobs##dwjobs', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwjobs'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwjobs'):append(chat.message('Window closed. Everything it does also works as !jobs commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1] = true;

    -- Reopening is a fresh start for error reporting too: `reported` only
    -- exists to stop one bad frame printing sixty lines a second.
    state.reported      = false;
    state.staged        = { };
    state.pendingDelete = nil;
    state.writing       = false;

    bumpModel();
    setStatus('Loading...', false, false);

    refresh();
end

--[[
* Watch what the player sends.
*
* Bare `!jobs` (and `!jobs ui`) is intercepted and opens this window instead
* of printing the server's listing -- that line is blocked and never leaves
* the client. Every other `!jobs` command passes through and invalidates the
* roster behind it, so `!jobs set` typed by hand keeps the window honest --
* and so do `!squad` commands, because set/clear/call/dismiss all change what
* this window is showing.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped. Stamping
* the player's own line as a send makes the follow-up wait its interval.
--]]
ashita.events.register('packet_out', 'dwjobs_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    -- The same four spellings the slash side takes, plus `toggle`: the server
    -- has no such verb and would answer it with "unknown verb", so a line that
    -- can only mean the window is better served here.
    if (lower == '!jobs' or lower == '!jobs ui' or lower == '!jobs window'
            or lower == '!jobs gui' or lower == '!jobs toggle') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwj') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 5) == '!jobs' or lower:sub(1, 6) == '!squad') then
        refresh();
    end
end);

ashita.events.register('command', 'dwjobs_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Jobs`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwjobs' and first ~= '/jobs') then
        return;
    end

    e.blocked = true;

    -- ARGUMENTS ARE NOT SILENTLY EATEN (2026-09-06). `/jobs use NukerParty`
    -- used to toggle the window and throw the rest away, which reads exactly
    -- like a preset that refused to load -- and it disagreed with the `!jobs`
    -- side, where only the bare line is intercepted and everything else goes
    -- to the server. The verbs live on `!jobs`, so say so rather than guess.
    local second = #args > 1 and args[2]:lower() or '';

    if (second ~= '' and second ~= 'ui' and second ~= 'window' and second ~= 'gui' and second ~= 'toggle') then
        print(chat.header('dwjobs'):append(chat.message(string.format(
            '/jobs takes no arguments -- the verbs live on the server command. Try !jobs %s. /jobs on its own opens the window.',
            second))));

        return;
    end

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

ashita.events.register('load', 'dwjobs_load', function ()
    print(chat.header('dwjobs'):append(chat.message('!jobs (or /jobs) opens the job window. Everything it does also works typed as !jobs commands.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new account view.
ashita.events.register('packet_in', 'dwjobs_zonein', function (e)
    if (e.id == 0x000A) then
        state.chars     = T{ };
        state.presets   = T{ };
        state.staged    = { };
        state.writing   = false;
        state.presetCap = 0;
        state.log       = T{ };
        state.syncedAt  = nil;

        -- Any half-arrived answer belonged to the character that just left:
        -- committing it at a `z|` that lands after the login would paint the
        -- previous character's roster over the new one.
        state.pending   = nil;
        state.inbound   = nil;

        bumpModel();
        setStatus('Loading...', false, false);

        refresh();
    end
end);
