--[[
* DriftwoodXI -- dwreport
*
* Bug reporting without leaving the game. Write what went wrong in the
* window, press Submit, and a report lands in the server owner's inbox with
* your character's real state attached.
*
* WHY THIS IS BETTER THAN A FORUM POST, and the reason the addon exists at
* all: a report that says "the trust healer will not cure me" is a guess
* about what happened. The same report with the server's own view of your
* jobs, your party, your position, your active quest step and the last
* dozen lines of your chat log is EVIDENCE, and evidence can be checked
* against the code before anyone has to reproduce anything. Half of bug
* triage is establishing what the reporter's state actually was; this skips
* that half.
*
* THE DIVISION OF LABOUR IS THE WHOLE DESIGN.
*
*   THE ADDON sends what only the client can know: what you typed, what
*   YOUR client thinks its zone and position are, what your chat log said,
*   which addons you have loaded, what you had targeted.
*
*   THE SERVER stamps everything else at the moment you submit -- jobs,
*   levels, HP, gil, equipment, party and squad, and (when dwtracker's
*   module is loaded) the exact quest and mission step its evaluator places
*   you on. The addon asserts none of that, because the addon cannot know
*   any of it, and a bug report full of confident client-side guesses would
*   be worse than no bug report.
*
* Where the two views disagree -- your client's zone is not the server's --
* the report says so. That disagreement is itself a bug.
*
* MARK THE MOMENT. Opening this window freezes a client-side snapshot right
* then, because you will spend the next minute typing and may well walk
* away, zone, or die while you do. The report carries how long ago the
* snapshot was taken and you can retake it whenever you like. `/dwr mark`
* freezes one without opening anything, for the "that was weird, I will
* write it up in a second" case.
*
* NOTHING IS SENT UNTIL YOU PRESS SUBMIT, the "What is sent" tab lists
* every field verbatim, and the two attachments that carry the most
* personal detail -- your chat log and your addon list -- are checkboxes.
* Turn it off and nothing is lost: `!dwr` typed by hand is the same
* protocol, and there is still a Discord.
--]]

addon.name    = 'dwreport';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.4';
addon.desc    = 'In-game bug reporting with your real game state attached.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line.
-- Fifteen bytes of sName on GP_SERV_COMMAND_CHAT_STD; the seventh name in
-- the suite, and nothing else on the server uses it.
local DATA_SENDER = '_DWRDATA';

local PROTOCOL = 1;

--[[
* Transport limits. These are the SERVER's numbers -- `hello` sends the real
* ones and they replace these -- but the defaults have to be right, because
* the form is drawn (and its character counters drawn with it) before the
* first handshake comes back.
--]]
local limits = {
    title    = 80,
    body     = 900,

    -- `!dwr t 26 [` is eleven characters and `]` is one more, of the 127 a
    -- chat line holds (squad_rule_codes.lua's number, proven in production).
    -- 115 would fit; 110 is that with margin, because an over-length line
    -- is refused by the CLIENT before the server sees it and there is no
    -- way to diagnose that from the other end.
    chunk    = 110,
    chunks   = 26,

    cooldown = 45,
    spool    = true,
};

local function maxDocument()
    return limits.chunk * limits.chunks;
end

--[[
* FNV-1a over the assembled document, 8 hex chars.
*
* MUST MATCH modules/driftwoodxi/report_core.lua's fnv1a exactly (which in
* turn matches dwtracker's). Up to 26 separate chat lines carry one report,
* and a chat line can be dropped; a report silently missing its middle
* third would read perfectly and describe something nobody wrote. The hash
* is what makes that impossible rather than unlikely. The multiply is split
* at 16 bits because hash * 16777619 overflows the 2^53 integer range of a
* double.
--]]
local function fnv1a(text)
    local hash = 2166136261;

    for i = 1, #text do
        hash = bit.bxor(hash, string.byte(text, i)) % 4294967296;

        local lo = hash % 65536;

        hash = (((hash - lo) / 65536) * 16777619 % 65536) * 65536 + lo * 16777619;
        hash = hash % 4294967296;
    end

    return bit.tohex(hash);
end

--[[
* Fallback lists, replaced by the server's on `hello`. They exist so the
* form is usable the very first frame and so a server that answers late
* never shows an empty dropdown.
--]]
local DEFAULT_CATEGORIES = T{
    { key = 'quest',  label = 'Quest or mission'      },
    { key = 'combat', label = 'Combat or battle'      },
    { key = 'squad',  label = 'Squad / alt-trusts'    },
    { key = 'job',    label = 'Job, spell or ability' },
    { key = 'item',   label = 'Item, bags or AH'      },
    { key = 'zone',   label = 'Zone, NPC or map'      },
    { key = 'ui',     label = 'Addon, UI or launcher' },
    { key = 'text',   label = 'Wrong text or typo'    },
    { key = 'econ',   label = 'Gil, EXP or rewards'   },
    { key = 'other',  label = 'Something else'        },
};

local DEFAULT_SEVERITIES = T{
    { key = 'block', label = 'Blocked - I cannot continue' },
    { key = 'major', label = 'Major - badly wrong'         },
    { key = 'minor', label = 'Minor - works, but wrong'    },
    { key = 'look',  label = 'Cosmetic - just looks wrong' },
};

local DEFAULT_FREQUENCIES = T{
    { key = 'always', label = 'Every time'   },
    { key = 'often',  label = 'Most times'   },
    { key = 'some',   label = 'Now and then' },
    { key = 'once',   label = 'Only once'    },
};

--[[
* Chat capture.
*
* A ring of the last CHAT_KEEP lines, kept whether or not the window is
* open -- by the time you decide something was a bug, the lines that
* explain it have already scrolled. Nothing here leaves the client unless
* the Submit that sends it has the attachment box ticked.
*
* Our own records never reach this: they are blocked in packet_in, which
* runs before text_in ever sees them.
--]]
local CHAT_KEEP = 40;
local CHAT_SEND = 10;
local CHAT_WIDE = 110;

local chatRing  = T{ };

local function stripChat(text)
    local out = text;

    -- Auto-translate brackets are two-byte sequences; ask the client to
    -- spell them out rather than shipping the raw bytes.
    local ok, parsed = pcall(function ()
        return AshitaCore:GetChatManager():ParseAutoTranslate(text, true);
    end);

    if (ok and type(parsed) == 'string') then
        out = parsed;
    end

    -- Two-byte tags first, BOTH bytes -- dwquest.lua's plainText is the
    -- reference implementation and this is the same doctrine (PROD_LINUX.md
    -- 10.36). `\030`/`\031` are the colour tags Ashita's chat library writes,
    -- `\127` is the client's end-of-message pair (\127\49), and `\239` leads
    -- the auto-translate brackets for the case where ParseAutoTranslate above
    -- threw. Their ARGUMENT bytes are printable -- a bare `Q`, a trailing `1`
    -- -- so the blanket pass below deletes the tag and leaves the scar.
    out = out:gsub('[\030\031\127\239].', '');

    -- The line-break bytes become a seam SPACE, not nothing: the dat files
    -- break several messages across two lines (`<br>` renders as \007) and
    -- deleting the byte glues the halves together --
    -- "...for the target.(Progress: 2/2)".
    out = out:gsub('[\007\010\013]+', ' ');

    -- Then everything else that cannot be drawn: NUL padding, a tag byte that
    -- had no argument left to take. Everything downstream of here (the wire, a
    -- JSON file, an email) is happier for it.
    out = out:gsub('[^\032-\126]', '');
    out = out:gsub('^%s+', ''):gsub('%s+$', '');

    if (#out > CHAT_WIDE) then
        out = out:sub(1, CHAT_WIDE - 3) .. '...';
    end

    return out;
end

ashita.events.register('text_in', 'dwreport_text_in', function (e)
    -- Never capture our own chatter: the addon printing "Uploading 4/11"
    -- into the log it is about to attach is a feedback loop, and a silly
    -- thing to email someone.
    --
    -- `e.blocked` covers the same ground for a different author. dwecho
    -- swallows the client's echo of our own `!dwr` commands a few handlers
    -- earlier in this same event, and a line the player was never shown has
    -- no business in a report claiming to be what they saw. Any other addon
    -- that blocks a line is excluded for exactly that reason too.
    -- THE DRAWN LINE, NOT THE ARRIVED ONE (2026-08-15). Ashita hands a text_in
    -- handler both: `message` is what came off the wire, `message_modified` is
    -- what the player will actually READ once every handler registered ahead of
    -- this one has rewritten it -- and the bundled timestamp/colour addons load
    -- before the dw* block, so they always have. This addon's whole value is
    -- that the attached log is evidence of what the player saw, which makes it
    -- the last place that should have been capturing the pre-rewrite bytes.
    -- dwquest's parser documents the same rule. Fallback kept for the same
    -- reason dwecho has one: a missing field must not throw inside a chat
    -- handler.
    local raw = e.message_modified or e.message;

    -- Both spellings are tested for our own chatter: a handler ahead of us may
    -- have decorated the line, and either copy naming dwreport is still ours.
    if (e.blocked or raw == nil or raw:find('dwreport', 1, true) ~= nil
            or (e.message ~= nil and e.message:find('dwreport', 1, true) ~= nil)) then
        return;
    end

    local line = stripChat(raw);

    if (line == '') then
        return;
    end

    chatRing:append(line);

    while (#chatRing > CHAT_KEEP) do
        table.remove(chatRing, 1);
    end
end);

--[[
* The client-side snapshot -- "the marked moment".
*
* Every read is pcall'd and every field is optional. This function is
* called at exactly the moments the game is least well: after something
* went wrong, possibly mid-zone, possibly with a stale entity array. A
* snapshot that throws would cost the report the only account of the state
* it was written about, so a field that cannot be read is simply absent.
--]]
local function tryGet(fn, fallback)
    local ok, value = pcall(fn);

    if (not ok or value == nil) then
        return fallback;
    end

    return value;
end

local function selfIndex()
    local party = AshitaCore:GetMemoryManager():GetParty();

    if (party == nil) then
        return nil;
    end

    local index = party:GetMemberTargetIndex(0);

    return (index ~= nil and index > 0) and index or nil;
end

local function loadedAddonNames()
    return tryGet(function ()
        local manager = _G['AddonManager'];

        if (manager == nil) then
            return nil;
        end

        local names = T{ };
        local count = manager:Count();

        -- Ashita's collection getters are zero-based, but "is it" is a
        -- one-line question with a two-line answer that costs nothing to
        -- be right about either way.
        for i = 0, count - 1 do
            local name = manager:Get(i);

            if (name ~= nil and name ~= '') then
                names:append(name);
            end
        end

        if (#names == 0) then
            for i = 1, count do
                local name = manager:Get(i);

                if (name ~= nil and name ~= '') then
                    names:append(name);
                end
            end
        end

        return names;
    end, nil);
end

local function loadedPluginNames()
    return tryGet(function ()
        local manager = AshitaCore:GetPluginManager();

        if (manager == nil) then
            return nil;
        end

        local names = T{ };

        for i = 0, manager:Count() - 1 do
            local plugin = manager:Get(i);

            if (plugin ~= nil) then
                local name = plugin:GetName();

                if (name ~= nil and name ~= '') then
                    names:append(name);
                end
            end
        end

        return names;
    end, nil);
end

-- Frame pacing, sampled continuously so a "the game hitches here" report
-- can carry a number instead of an adjective.
local fps = { last = 0, accum = 0, frames = 0, value = 0 };

local function captureContext()
    local snap = {
        at = os.clock(),
    };

    local party  = AshitaCore:GetMemoryManager():GetParty();
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    local entity = AshitaCore:GetMemoryManager():GetEntity();
    local index  = selfIndex();

    snap.name = tryGet(function () return party:GetMemberName(0); end, nil);

    local zoneId = tryGet(function () return party:GetMemberZone(0); end, nil);

    if (zoneId ~= nil) then
        local zoneName = tryGet(function ()
            return AshitaCore:GetResourceManager():GetString('zones.names', zoneId);
        end, nil);

        -- The id leads, because the server parses it back out to compare
        -- against its own zone. The name is for the human reading it.
        snap.zone = string.format('%i %s', zoneId, zoneName or '?');
    end

    if (index ~= nil) then
        snap.pos = tryGet(function ()
            return string.format('x %.2f  y %.2f  z %.2f  yaw %.2f',
                entity:GetLocalPositionX(index),
                entity:GetLocalPositionY(index),
                entity:GetLocalPositionZ(index),
                entity:GetLocalPositionYaw(index));
        end, nil);

        snap.stance = tryGet(function ()
            return string.format('status %i  anim %i  mount %i',
                entity:GetStatus(index), entity:GetAnimation(index), entity:GetMountId(index));
        end, nil);
    end

    snap.jobs = tryGet(function ()
        local main = party:GetMemberMainJob(0);
        local sub  = party:GetMemberSubJob(0);

        if (sub ~= nil and sub > 0) then
            return string.format('%i/%i at %i/%i',
                main, sub, party:GetMemberMainJobLevel(0), party:GetMemberSubJobLevel(0));
        end

        return string.format('%i at %i', main, party:GetMemberMainJobLevel(0));
    end, nil);

    snap.vitals = tryGet(function ()
        return string.format('HP %i/%i  MP %i/%i  TP %i',
            party:GetMemberHP(0), player:GetHPMax(),
            party:GetMemberMP(0), player:GetMPMax(),
            party:GetMemberTP(0));
    end, nil);

    snap.target = tryGet(function ()
        local target = AshitaCore:GetMemoryManager():GetTarget();

        -- INDEX 0 IS THE MAIN TARGET, and both of these take that index. The
        -- three sibling reads in this file pass it; these two did not, so
        -- under a binder that requires it the whole target section fell into
        -- tryGet's silent degradation and every bug report said "nothing
        -- targeted" -- the one field a targeting bug report is about.
        if (target == nil or target:GetIsActive(0) == 0) then
            return 'nothing targeted';
        end

        local tIndex = target:GetTargetIndex(0);
        local name   = entity:GetName(tIndex);

        return string.format('%s (index %i, %i%% HP, %.1f yalms)',
            (name ~= nil and name ~= '') and name or '?',
            tIndex,
            entity:GetHPPercent(tIndex),
            math.sqrt(entity:GetDistance(tIndex)));
    end, nil);

    snap.buffs = tryGet(function ()
        local names = T{ };

        -- Empty slots read 255; there are 32 of them and a report full of
        -- "255, 255, 255" would be worse than no buff list at all.
        for _, id in pairs(player:GetBuffs()) do
            if (id ~= nil and id > 0 and id ~= 255 and #names < 20) then
                local name = AshitaCore:GetResourceManager():GetString('buffs.names', id);

                names:append((name ~= nil and name ~= '') and name or tostring(id));
            end
        end

        return #names > 0 and names:concat(', ') or 'none';
    end, nil);

    snap.partyList = tryGet(function ()
        local names = T{ };

        for i = 0, 17 do
            if (party:GetMemberIsActive(i) == 1) then
                local name = party:GetMemberName(i);

                if (name ~= nil and name ~= '') then
                    names:append(name);
                end
            end
        end

        return #names > 0 and names:concat(', ') or 'solo';
    end, nil);

    snap.fps = string.format('%.1f', fps.value);

    snap.screen = tryGet(function ()
        return string.format('%ix%i', AshitaCore:GetSystemMetrics(0), AshitaCore:GetSystemMetrics(1));
    end, nil);

    local addons = loadedAddonNames();

    snap.addons   = addons ~= nil and addons:concat(' ') or 'unavailable';
    snap.tracker  = (addons ~= nil and addons:contains('dwtracker')) and 'loaded' or 'not loaded';

    local plugins = loadedPluginNames();

    snap.plugins = plugins ~= nil and plugins:concat(' ') or 'unavailable';

    -- Frozen at the same instant as the rest, for the same reason: the
    -- lines that explain the bug are the ones on screen when it happened,
    -- not the ones on screen when the report was finally written.
    snap.chat = T{ };

    local from = math.max(1, #chatRing - CHAT_SEND + 1);

    for i = from, #chatRing do
        snap.chat:append(chatRing[i]);
    end

    return snap;
end

--[[
* Form state.
*
* The text buffers are the only thing in this addon that is genuinely
* precious -- everything else can be re-derived, and what the player wrote
* cannot. They survive a failed upload, a server refusal, a zone line and
* (via the draft file) a client crash, and are cleared only when the player
* says so.
--]]
local state = T{
    open = T{ false },

    title = T{ '' },
    body  = T{ '' },

    category  = 'other',
    severity  = 'minor',
    frequency = 'always',

    attachChat   = T{ true },
    attachAddons = T{ true },

    categories  = DEFAULT_CATEGORIES,
    severities  = DEFAULT_SEVERITIES,
    frequencies = DEFAULT_FREQUENCIES,

    context = nil,      -- the marked moment, or nil until one is taken

    status    = 'Ready.',
    statusBad = false,

    sent = T{ },        -- refs filed this session, newest first

    cooldown = 0,       -- seconds, from the server's q| record
    cooldownAt = 0,     -- os.clock() when that was true

    reported = false,   -- one render error printed, not sixty a second
};

--[[
* Send throttle. The client rate-limits outgoing chat and a !dwr line is a
* chat line, so everything queues here and drains at one command per
* interval, exact duplicates collapsed (dwbags' lesson, kept verbatim
* through dwtracker).
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

-- The addon's OWN last send, never stamped by the player's chat. The stall
-- detectors key off this: keyed off `lastSend` -- which the packet_out
-- handler pushes forward for every line the player types -- a player asking
-- "did that work?" in chat kept resetting the 12s detector, and a dropped
-- answer sat looking busy until the 180s dead-man timer instead.
local lastOwnSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend    = now;
    lastOwnSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Has this server ever answered a !dwr?
*
* THIS IS A SAFETY GATE, NOT A NICETY, and it is the single most important
* rule in this file. An unknown `!command` on this server falls through to
* ordinary /say chat (0x0b5_chat_std.cpp:121) -- so uploading a report to a
* server that does not speak dwreport would be the player PUBLICLY SAYING
* every line of their bug report, one hundred characters at a time, to
* whoever is standing nearby. Possibly including whatever their chat log
* had in it.
*
* So: no chunk is ever sent until a `hello` has come back in this session,
* proving the verb exists. `hello` itself is the only line we are willing
* to risk leaking, it is eight harmless characters, and it is sent exactly
* once per login unless the player deliberately asks again.
--]]
local serverSpeaks = false;
local helloAsked   = 0;
local helloTries   = 0;

local HELLO_RETRY  = 20.0;
local HELLO_TRIES  = 3;

local function sayHello(force)
    if (serverSpeaks) then
        return;
    end

    local now = os.clock();

    if (not force) then
        -- Bounded, because the failure mode of asking is the failure mode
        -- of every unknown !command here: it becomes /say. Three tries per
        -- login is enough to survive a dropped packet and few enough that a
        -- server without the module never turns this into a chant.
        if (helloTries >= HELLO_TRIES) then
            return;
        end

        if (helloAsked > 0 and (now - helloAsked) < HELLO_RETRY) then
            return;
        end
    end

    helloAsked = now;
    helloTries = helloTries + 1;

    issue('!dwr hello');
end

--[[
* The upload.
*
* One document, split by BYTE COUNT into chunks and reassembled by
* concatenation, so no chunk needs to be a valid anything on its own and a
* boundary can fall anywhere. The server acknowledges with a bitmask of
* what it holds; when the queue has drained we compare, resend exactly what
* is missing, and only then ask it to file.
*
* Rounds rather than per-chunk timers: a chunk waiting its turn in a
* half-minute queue has not been lost, and a per-chunk timeout would spend
* the whole upload racing itself.
--]]
local MAX_ROUNDS     = 3;
local ACK_GRACE      = 3.0;
local ANSWER_TIMEOUT = 12.0;
local UPLOAD_DEAD    = 180.0;

local upload = {
    phase  = 'idle',    -- idle | hello | begin | drain | send | done
    parts  = { },
    n      = 0,
    hash   = '',
    mask   = 0,
    round  = 0,
    at     = 0,
    waited = 0,
    ref    = nil,
};

local function popcount(mask)
    local count = 0;

    for i = 0, 31 do
        if (bit.band(mask, bit.lshift(1, i)) ~= 0) then
            count = count + 1;
        end
    end

    return count;
end

local function uploadActive()
    return upload.phase ~= 'idle' and upload.phase ~= 'done';
end

local function resetUpload()
    upload.phase  = 'idle';
    upload.parts  = { };
    upload.n      = 0;
    upload.mask   = 0;
    upload.round  = 0;
    upload.waited = 0;
end

--[[
* Document encoding. `key=value` records joined by `|`; values escape the
* two characters that could be mistaken for structure plus the newline.
* The server unescapes with the mirror of this and keeps unknown keys, so
* a newer addon can add a field without a server deploy.
--]]
local function esc(value)
    local out = tostring(value or '');

    out = out:gsub('\\', '\\\\');
    out = out:gsub('|', '\\p');
    out = out:gsub('\r', '');
    out = out:gsub('\n', '\\n');

    -- Everything the wire cannot carry becomes a space rather than a
    -- mystery: the outgoing chat buffer is bytes, and a stray control
    -- character in the middle of a report helps nobody.
    out = out:gsub('[^\032-\126\\]', ' ');

    return out;
end

--[[
* Build the document, trimming optional attachments until it fits.
*
* THE ORDER OF SACRIFICE IS DELIBERATE. What the player wrote is never
* trimmed -- it is the report. The plugin list goes first (least often
* decisive), then the addon list, then buffs, then chat lines oldest-first.
* Whatever went is named in the returned list and shown in the window,
* because a report that quietly dropped its own evidence is exactly the
* kind of quiet wrongness this suite exists to rule out.
--]]
local function buildDocument()
    local dropped = T{ };
    local context = state.context;

    local core = T{
        { 'ti', state.title[1] },
        { 'ca', state.category },
        { 'sv', state.severity },
        { 'fr', state.frequency },
    };

    if (context ~= nil) then
        core:append({ 'mk', tostring(math.floor(os.clock() - context.at)) });
    end

    local optional = T{ };

    local function optionalField(key, value, name)
        if (value ~= nil and value ~= '') then
            optional:append({ key = key, value = value, name = name });
        end
    end

    if (context ~= nil) then
        optionalField('cl.zone', context.zone, 'zone');
        optionalField('cl.pos', context.pos, 'position');
        optionalField('cl.vitals', context.vitals, 'vitals');
        optionalField('cl.jobs', context.jobs, 'jobs');
        optionalField('cl.target', context.target, 'target');
        optionalField('cl.stance', context.stance, 'stance');
        optionalField('cl.party', context.partyList, 'party');
        optionalField('cl.fps', context.fps, 'fps');
        optionalField('cl.screen', context.screen, 'screen');
        optionalField('cl.tracker', context.tracker, 'dwtracker');
        optionalField('cl.buffs', context.buffs, 'buffs');

        if (state.attachAddons[1]) then
            optionalField('cl.addons', context.addons, 'addon list');
            optionalField('cl.plugins', context.plugins, 'plugin list');
        end
    end

    local chatLines = T{ };

    if (state.attachChat[1] and context ~= nil and context.chat ~= nil) then
        for _, line in ipairs(context.chat) do
            chatLines:append(line);
        end
    end

    -- Trim priority, least valuable first.
    local sacrifice = T{ 'cl.plugins', 'cl.addons', 'cl.buffs', 'cl.screen', 'cl.fps' };

    local function assemble()
        local records = T{ };

        for _, pair in ipairs(core) do
            records:append(string.format('%s=%s', pair[1], esc(pair[2])));
        end

        for _, field in ipairs(optional) do
            records:append(string.format('%s=%s', field.key, esc(field.value)));
        end

        for _, line in ipairs(chatLines) do
            records:append(string.format('lg=%s', esc(line)));
        end

        -- Last, and deliberately: it is the longest field, and a truncated
        -- document (which cannot happen -- the hash would catch it -- but
        -- which a human may one day read half of in a log) should lose the
        -- description last, not first.
        records:append(string.format('bd=%s', esc(state.body[1])));

        return records:concat('|');
    end

    local function dropField(key)
        for i, field in ipairs(optional) do
            if (field.key == key) then
                dropped:append(field.name);
                table.remove(optional, i);

                return true;
            end
        end

        return false;
    end

    local document = assemble();
    local budget   = maxDocument();

    for _, key in ipairs(sacrifice) do
        if (#document <= budget) then
            break;
        end

        if (dropField(key)) then
            document = assemble();
        end
    end

    while (#document > budget and #chatLines > 0) do
        table.remove(chatLines, 1);

        if (not dropped:contains('older chat lines')) then
            dropped:append('older chat lines');
        end

        document = assemble();
    end

    return document, dropped;
end

--[[
* The assembled length, for the size meter and the "~N seconds" estimate.
*
* Both are drawn every frame and both answer a question that changes at
* typing speed, so assembling two kilobytes sixty times a second to answer
* it would be pure waste. Half a second is far below anything anyone
* notices moving.
--]]
local sizeCache = { at = 0, size = 0 };

local function documentSize()
    local now = os.clock();

    if (now - sizeCache.at > 0.5) then
        sizeCache.at   = now;
        sizeCache.size = #(buildDocument());
    end

    return sizeCache.size;
end

local function beginUpload()
    local document, dropped = buildDocument();

    if (#document > maxDocument()) then
        state.status    = 'That report is too long even after trimming. Please shorten the description.';
        state.statusBad = true;

        return;
    end

    local parts = { };
    local n     = 0;

    for offset = 1, #document, limits.chunk do
        n = n + 1;
        parts[n] = document:sub(offset, offset + limits.chunk - 1);
    end

    upload.parts  = parts;
    upload.n      = n;
    upload.hash   = fnv1a(document);
    upload.mask   = 0;
    upload.round  = 0;
    upload.at     = os.clock();
    upload.waited = 0;
    upload.ref    = nil;
    upload.phase  = 'begin';

    issue(string.format('!dwr begin %i %s', n, upload.hash));

    state.statusBad = false;

    if (#dropped > 0) then
        state.status = string.format('Uploading (%i lines). Trimmed to fit: %s.', n, dropped:concat(', '));
    else
        state.status = string.format('Uploading (%i lines)...', n);
    end
end

-- Queue every chunk the server has not acknowledged.
local function queueMissing()
    upload.round  = upload.round + 1;
    upload.waited = 0;

    local queued = 0;

    for i = 1, upload.n do
        if (bit.band(upload.mask, bit.lshift(1, i - 1)) == 0) then
            issue(string.format('!dwr t %i [%s]', i, upload.parts[i]));
            queued = queued + 1;
        end
    end

    if (queued == 0) then
        upload.phase = 'send';
        issue('!dwr send');

        return;
    end

    upload.phase = 'drain';
end

local function pumpUpload()
    if (not uploadActive()) then
        return;
    end

    local now = os.clock();

    if (now - upload.at > UPLOAD_DEAD) then
        resetUpload();

        state.status    = 'The upload timed out. Your report is still here -- press Submit to try again.';
        state.statusBad = true;

        return;
    end

    -- `begin` and `send` are single questions with single answers, so
    -- silence in either is a stall and not slowness -- and a stall the
    -- player is watching a progress bar through. Neither should be left to
    -- the three-minute dead-man timer, which exists for the case where
    -- something stops the client sending at all.
    if (upload.phase == 'begin' or upload.phase == 'send') then
        if (#queue == 0 and (now - lastOwnSend) > ANSWER_TIMEOUT) then
            resetUpload();

            state.status    = 'The server stopped answering. Your report is still here -- press Submit to try again.';
            state.statusBad = true;
        end

        return;
    end

    if (upload.phase ~= 'drain') then
        return;
    end

    -- Still draining the throttle: not stalled, just slow on purpose.
    if (#queue > 0 or (now - lastOwnSend) < ACK_GRACE) then
        return;
    end

    if (popcount(upload.mask) >= upload.n) then
        upload.phase = 'send';
        issue('!dwr send');

        return;
    end

    if (upload.round >= MAX_ROUNDS) then
        resetUpload();

        state.status    = 'Part of the report kept getting lost. Nothing was sent -- press Submit to try again.';
        state.statusBad = true;

        return;
    end

    state.status = string.format('Resending %i missing line(s)...', upload.n - popcount(upload.mask));

    queueMissing();
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local inResponse = nil;
local pendingSets = nil;

-- Forward declaration: the draft machinery is defined below handleRecord,
-- but the r| (filed) branch must clear a filed draft -- a bare `clearDraft()`
-- here would resolve to a nil GLOBAL, not the local declared later. Assigned
-- its real body beside clearDraft.
local onReportFiled = function () end;

local function handleRecord(message)
    local fields = split(message, '|');
    local kind   = fields[1];

    if (kind == 'd') then
        local version = tonumber(fields[2]);

        -- A protocol this addon does not know is refused outright rather
        -- than half-parsed: dwbags' rule. The one thing that must not
        -- happen is a report the player believes was filed and was not.
        if (version ~= PROTOCOL) then
            inResponse = nil;

            state.status    = 'This server speaks a different dwreport version. Update the addon.';
            state.statusBad = true;

            return;
        end

        inResponse   = fields[3];
        serverSpeaks = true;

        if (inResponse == 'hello') then
            pendingSets = {
                categories  = T{ },
                severities  = T{ },
                frequencies = T{ },
            };
        end

        return;
    end

    if (inResponse == nil) then
        return;
    end

    if (kind == 'z') then
        -- A response that opened for `begin` or `send` and closed without
        -- moving the upload forward is a refusal: a cooldown, a daily
        -- limit, a spool the server cannot write. The player has already
        -- been told why by the `e|` that came with it; what must not happen
        -- is the upload sitting in a phase nothing will ever advance,
        -- looking busy for three minutes until the dead-man timer.
        if ((inResponse == 'begin' and upload.phase == 'begin') or
            (inResponse == 'send' and upload.phase == 'send')) then
            resetUpload();
        end

        if (inResponse == 'hello' and pendingSets ~= nil) then
            if (#pendingSets.categories > 0) then
                state.categories = pendingSets.categories;
            end

            if (#pendingSets.severities > 0) then
                state.severities = pendingSets.severities;
            end

            if (#pendingSets.frequencies > 0) then
                state.frequencies = pendingSets.frequencies;
            end

            pendingSets = nil;
        end

        inResponse = nil;

        return;
    end

    if (kind == 'h') then
        limits.title    = tonumber(fields[3]) or limits.title;
        limits.body     = tonumber(fields[4]) or limits.body;
        limits.chunk    = tonumber(fields[5]) or limits.chunk;
        limits.chunks   = tonumber(fields[6]) or limits.chunks;
        limits.cooldown = tonumber(fields[7]) or limits.cooldown;
        limits.spool    = (tonumber(fields[8]) or 1) == 1;

        return;
    end

    if (kind == 'c' and pendingSets ~= nil) then
        pendingSets.categories:append({ key = fields[2], label = fields[3] });

        return;
    end

    if (kind == 'v' and pendingSets ~= nil) then
        pendingSets.severities:append({ key = fields[2], label = fields[3] });

        return;
    end

    if (kind == 'f' and pendingSets ~= nil) then
        pendingSets.frequencies:append({ key = fields[2], label = fields[3] });

        return;
    end

    if (kind == 'k') then
        upload.mask = tonumber(fields[2], 16) or 0;

        if (upload.phase == 'begin') then
            queueMissing();
        elseif (upload.phase == 'send') then
            -- The server answered `send` with a mask, which means it is
            -- missing something (or threw the parts away over a bad hash).
            -- Either way the fix is another round, not a failure.
            upload.phase = 'drain';
        end

        return;
    end

    if (kind == 'q') then
        state.cooldown   = tonumber(fields[2]) or 0;
        state.cooldownAt = os.clock();

        return;
    end

    if (kind == 'r') then
        local ref = fields[2];

        upload.ref   = ref;
        upload.phase = 'done';

        state.sent:insert(1, { ref = ref, title = state.title[1], at = os.date('%H:%M') });
        state.status    = string.format('Filed as %s. Thank you.', ref);
        state.statusBad = false;

        -- The draft on disk is this report, flushed by the 3s timer while it
        -- was being written. Filed successfully, it must not be restored on
        -- the next login as a ready-to-resubmit form.
        onReportFiled();

        return;
    end

    if (kind == 'g') then
        -- GM listing; printed rather than shown, because it belongs to
        -- whoever typed `!dwr recent` by hand.
        print(chat.header('dwreport'):append(chat.message(string.format('%s  %s  [%s]  %s',
            fields[2] or '?', fields[4] or '?', fields[5] or '?', fields[6] or ''))));

        return;
    end

    -- With the window shut there is nowhere for a status line to be seen,
    -- and `!dwr status` typed by hand is a question that deserves an answer
    -- where it was asked. The window is the louder surface when it is open,
    -- so it keeps the line to itself then.
    local function announce(text, bad)
        state.status    = text;
        state.statusBad = bad;

        if (not state.open[1]) then
            if (bad) then
                print(chat.header('dwreport'):append(chat.error(text)));
            else
                print(chat.header('dwreport'):append(chat.message(text)));
            end
        end
    end

    if (kind == 'm') then
        announce(fields[2] or '', false);

        return;
    end

    if (kind == 'e') then
        announce(fields[2] or 'Refused.', true);

        -- A refusal during an upload ends it. Everything the player wrote
        -- is still in the form; nothing is retried behind their back,
        -- because a server that said no should not be asked again by a
        -- loop they cannot see.
        if (upload.phase ~= 'drain' and upload.phase ~= 'send') then
            resetUpload();
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWRDATA is
* ours: consumed here and blocked so the chat log never sees it -- before
* parsing, so a malformed record cannot leak as noise.
--]]
ashita.events.register('packet_in', 'dwreport_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwreport'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Draft persistence.
*
* This addon is used precisely when things are going wrong, which includes
* the times the client goes down five seconds later. Losing a half-written
* report to the crash it was describing would be a small cruelty, so the
* form is mirrored to a file next to the launcher's theme and read back at
* load. Plain text, no schema, best-effort in both directions: a draft that
* will not load is simply not loaded.
--]]
local DRAFT_PATH = string.format('%s\\config\\dwreport-draft.txt',
    AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

local draftDirty = false;
local draftAt    = 0;

-- Typing is not a reason to touch the disk. The form marks itself dirty and
-- the present loop flushes at most every few seconds.
local function touchDraft()
    draftDirty = true;
end

local function saveDraft()
    draftDirty = false;
    draftAt    = os.clock();

    pcall(function ()
        local file = io.open(DRAFT_PATH, 'wb');

        if (file == nil) then
            return;
        end

        file:write(string.format('%s\n%s\n%s\n%s\n%s',
            state.category, state.severity, state.frequency,
            (state.title[1] or ''):gsub('[\r\n]', ' '),
            state.body[1] or ''));

        file:close();
    end);
end

local function clearDraft()
    pcall(os.remove, DRAFT_PATH);
end

-- The r| handler's half of R1: a successfully filed report must not be
-- restored as a draft on the next login. draftDirty too, or the 3s flush
-- timer re-writes the file right after it is removed.
onReportFiled = function ()
    draftDirty = false;

    clearDraft();
end;

local function loadDraft()
    pcall(function ()
        local file = io.open(DRAFT_PATH, 'rb');

        if (file == nil) then
            return;
        end

        local raw = file:read('*a');
        file:close();

        local lines = split(raw:gsub('\r', ''), '\n');

        if (#lines < 5) then
            return;
        end

        state.category  = lines[1] ~= '' and lines[1] or state.category;
        state.severity  = lines[2] ~= '' and lines[2] or state.severity;
        state.frequency = lines[3] ~= '' and lines[3] or state.frequency;
        state.title[1]  = lines[4] or '';

        -- The body is everything left, newlines intact.
        local rest = T{ };

        for i = 5, #lines do
            rest:append(lines[i]);
        end

        state.body[1] = rest:concat('\n');

        if (state.title[1] ~= '' or state.body[1] ~= '') then
            state.status = 'A draft from last time was restored.';
        end
    end);
end

loadDraft();

--[[
* Rendering
--]]
local function labelFor(list, key, fallback)
    for _, entry in ipairs(list) do
        if (entry.key == key) then
            return entry.label;
        end
    end

    return fallback;
end

local function pickCombo(id, width, current, entries, fallback)
    local chosen = nil;

    imgui.PushItemWidth(width);

    if (imgui.BeginCombo(id, labelFor(entries, current, fallback))) then
        for index, entry in ipairs(entries) do
            if (imgui.Selectable(string.format('%s##%s_%d', entry.label, id, index), entry.key == current)) then
                chosen = entry.key;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    return chosen;
end

local function coloredWrapped(color, text)
    imgui.PushStyleColor(ImGuiCol_Text, color);
    imgui.TextWrapped(text);
    imgui.PopStyleColor();
end

local function cooldownLeft()
    if (state.cooldown <= 0) then
        return 0;
    end

    local left = state.cooldown - (os.clock() - state.cooldownAt);

    return left > 0 and math.ceil(left) or 0;
end

local function contextLine()
    if (state.context == nil) then
        return 'No moment marked yet -- one is taken when you open this window.';
    end

    local age    = math.floor(os.clock() - state.context.at);
    local target = state.context.target;

    return string.format('Marked %s ago%s%s',
        age < 60 and string.format('%i second(s)', age) or string.format('%i minute(s)', math.floor(age / 60)),
        state.context.zone ~= nil and (' in ' .. state.context.zone:gsub('^%d+%s*', '')) or '',
        (target ~= nil and target ~= 'nothing targeted')
            and (', targeting ' .. target:gsub('%s*%(.*$', '')) or '');
end

-- Reasons this report cannot be submitted right now, most blocking first.
local function submitBlockers()
    local reasons = T{ };

    if (not serverSpeaks) then
        reasons:append('The server has not answered yet. Press "Check server" below.');
    elseif (not limits.spool) then
        reasons:append('The server has bug reporting switched off right now.');
    end

    if (#(state.title[1] or '') < 6) then
        reasons:append('Give it a title (at least 6 characters).');
    end

    if (#(state.body[1] or '') < 20) then
        reasons:append('Describe what happened (at least 20 characters).');
    end

    local left = cooldownLeft();

    if (left > 0) then
        reasons:append(string.format('Wait %i more second(s) between reports.', left));
    end

    return reasons;
end

local function reportTab()
    imgui.TextWrapped('Tell us what went wrong. Your character\'s state is attached automatically, so you do not have to describe where you were or what you had on.');
    imgui.Separator();

    local picked = pickCombo('##dwreport_cat', 190, state.category, state.categories, 'Something else');

    if (picked ~= nil) then
        state.category = picked;
        touchDraft();
    end

    imgui.SameLine();
    imgui.Text('What is it about');

    picked = pickCombo('##dwreport_sev', 190, state.severity, state.severities, 'Minor');

    if (picked ~= nil) then
        state.severity = picked;
        touchDraft();
    end

    imgui.SameLine();
    imgui.Text('How bad');

    picked = pickCombo('##dwreport_freq', 190, state.frequency, state.frequencies, 'Every time');

    if (picked ~= nil) then
        state.frequency = picked;
        touchDraft();
    end

    imgui.SameLine();
    imgui.Text('How often');

    imgui.Spacing();
    imgui.Text('Title');
    imgui.PushItemWidth(-1);

    if (imgui.InputText('##dwreport_title', state.title, limits.title + 1)) then
        touchDraft();
    end

    imgui.PopItemWidth();

    imgui.Text('What happened');

    if (imgui.InputTextMultiline('##dwreport_body', state.body, limits.body + 1, { -1, 150 })) then
        touchDraft();
    end

    -- Two meters, because they measure different things and both can bite.
    -- The first is the server's cap on the description; the second is the
    -- transport budget the whole report shares, which the attachments eat
    -- into. Showing the second is what stops "why did it drop my chat log"
    -- from ever being a surprise.
    local used   = documentSize();
    local budget = maxDocument();

    coloredWrapped(used > budget and theme.colors.warn or theme.colors.dim,
        string.format('%i / %i characters   |   report size %i / %i.   What did you do, what did you expect, what happened instead?',
            #(state.body[1] or ''), limits.body, used, budget));

    imgui.Separator();

    coloredWrapped(theme.colors.dim, contextLine());

    if (imgui.Button('Mark this moment again')) then
        state.context       = captureContext();
        state.contextMarked = true;
        state.status        = 'Snapshot retaken.';
        state.statusBad     = false;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Re-reads your zone, position, target, buffs and recent chat right now.\nUse this if you have reproduced the bug since opening this window.');
    end

    imgui.SameLine();
    imgui.Checkbox('Attach recent chat', state.attachChat);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(string.format('The last %i lines of your chat log from the marked moment.\nBy far the most useful thing you can attach.', CHAT_SEND));
    end

    imgui.SameLine();
    imgui.Checkbox('Attach addon list', state.attachAddons);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Which addons and plugins you have loaded.\nWorth leaving on for anything UI-shaped.');
    end

    imgui.Separator();

    if (uploadActive()) then
        local done = popcount(upload.mask);

        imgui.ProgressBar(upload.n > 0 and (done / upload.n) or 0, { -1, 0 },
            string.format('%i / %i', done, upload.n));

        if (imgui.Button('Cancel upload')) then
            issue('!dwr cancel');
            resetUpload();

            state.status    = 'Upload cancelled. Nothing was sent.';
            state.statusBad = false;
        end
    elseif (upload.phase == 'done') then
        coloredWrapped(theme.colors.ok, string.format('Sent. Your reference is %s -- quote it if you talk to staff.', upload.ref or '?'));

        if (imgui.Button('Write another')) then
            state.title[1] = '';
            state.body[1]  = '';
            upload.phase   = 'idle';
            state.context  = captureContext();
            state.contextMarked = false;
            state.status   = 'Ready.';

            clearDraft();
        end
    else
        local blockers = submitBlockers();

        if (#blockers == 0) then
            if (imgui.Button('Submit report', { 140, 0 })) then
                if (state.context == nil) then
                    state.context = captureContext();
                end

                beginUpload();
            end

            imgui.SameLine();
            coloredWrapped(theme.colors.dim, string.format('~%i seconds to send.',
                math.max(2, math.ceil((documentSize() / limits.chunk + 2) * SEND_INTERVAL))));
        else
            imgui.BeginDisabled(true);
            imgui.Button('Submit report', { 140, 0 });
            imgui.EndDisabled();

            imgui.SameLine();
            coloredWrapped(theme.colors.warn, blockers[1]);
        end

        if (not serverSpeaks) then
            if (imgui.Button('Check server')) then
                sayHello(true);
            end
        end
    end

    imgui.Separator();
    coloredWrapped(state.statusBad and theme.colors.err or theme.colors.dim, state.status);
end

local function sentTab()
    if (#state.sent == 0) then
        coloredWrapped(theme.colors.dim, 'Nothing sent this session.');

        return;
    end

    coloredWrapped(theme.colors.dim, 'References for reports filed since you logged in. Quote one to staff and they can find it instantly.');
    imgui.Separator();

    if (imgui.BeginTable('##dwreport_sent', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Reference', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Time', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableSetupColumn('Title', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, entry in ipairs(state.sent) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextColored(theme.colors.hint, entry.ref);
            imgui.TableNextColumn();
            imgui.TextColored(theme.colors.dim, entry.at);
            imgui.TableNextColumn();
            imgui.Text(entry.title);
        end

        imgui.EndTable();
    end
end

--[[
* The transparency tab. It exists because "we also collect some game data"
* is not an acceptable thing to say to somebody, and because a list that
* has to stay true is a list somebody will notice going stale. If you add a
* field to modules/driftwoodxi/report_core.lua, add it here.
--]]
local function collectTab()
    imgui.TextWrapped('A bug report is only worth what can be checked against it, so each one carries your character\'s state at the time. Here is all of it.');
    imgui.Spacing();

    local function group(title, lines)
        imgui.TextColored(theme.colors.hint, title);

        for _, line in ipairs(lines) do
            imgui.TextWrapped('    ' .. line);
        end

        imgui.Spacing();
    end

    group('What you write', {
        'The title, the description, and the three dropdowns.',
    });

    group('From your client, frozen at the marked moment', {
        'Zone and position as your client sees them, and what you had targeted.',
        'HP/MP/TP, jobs and levels, and your status effects.',
        'Your party list, your framerate and your screen size.',
        state.attachChat[1] and string.format('The last %i lines of your chat log -- this box is ticked.', CHAT_SEND)
            or 'Your chat log -- currently NOT attached, the box is unticked.',
        state.attachAddons[1] and 'Your loaded addons and plugins -- this box is ticked.'
            or 'Your addon list -- currently NOT attached, the box is unticked.',
    });

    group('From the server, at the moment you press Submit', {
        'Your character name and id, nation and rank, and playtime.',
        'Jobs, every job you have levelled, HP/MP/TP, gil and equipment.',
        'Your zone, position, instance and battlefield.',
        'Your party and squad, with each member\'s jobs and HP.',
        'Your active quests and missions, and which step the tracker places you on.',
        'The server build and the time, in both Earth and Vana\'diel.',
    });

    group('What is never collected', {
        'Your password, your email, your IP address, or anything about your account.',
        'Your inventory, your other characters, or anyone else\'s data.',
        'Anything at all unless you press Submit.',
    });

    imgui.Separator();
    coloredWrapped(theme.colors.dim, 'Reports go to the server owner as email. There is no automated third party in the path.');
end

local function renderWindow()
    if (imgui.BeginTabBar('##dwreport_tabs')) then
        if (imgui.BeginTabItem('Report')) then
            reportTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Sent')) then
            sentTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('What is sent')) then
            collectTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape, and its
* reasoning, kept verbatim).
--]]
ashita.events.register('d3d_present', 'dwreport_present', function ()
    local now = os.clock();

    if (fps.last > 0) then
        fps.accum  = fps.accum + (now - fps.last);
        fps.frames = fps.frames + 1;

        if (fps.accum >= 1.0) then
            fps.value  = fps.frames / fps.accum;
            fps.accum  = 0;
            fps.frames = 0;
        end
    end

    fps.last = now;

    -- Uploading continues with the window shut: closing it mid-send should
    -- not throw away a report that is halfway to the server.
    pumpUpload();
    pumpQueue();

    if (draftDirty and (now - draftAt) > 3.0) then
        saveDraft();
    end

    if (not state.open[1]) then
        return;
    end

    -- An open window is a deliberate act, so it is the one place the
    -- handshake is allowed to retry on its own -- bounded by HELLO_TRIES,
    -- for the reason sayHello spells out.
    sayHello(false);

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 560, 520 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Bug Report##dwreport', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwreport'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwreport'):append(chat.message('Window closed. Your draft is safe; /dwreport reopens it.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening marks the moment: by the time somebody
* reaches for this window the thing they want to report has already
* happened, and the snapshot should be of then, not of whenever they finish
* typing.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;

        -- "Opening this window freezes a snapshot right then" (the header,
        -- and DWREPORT.md) -- so a plain open RE-captures. The one snapshot
        -- that survives an open is a deliberate mark (`/report mark`, or the
        -- re-mark button): that one exists precisely to outlive the moment.
        -- Gated on `context == nil` alone, the second open of a session
        -- attached a stale snapshot -- wrong zone, wrong target, and a chat
        -- ring frozen at the FIRST open.
        if (state.context == nil or not state.contextMarked) then
            state.context = captureContext();
        end

        sayHello(false);
    end
end

ashita.events.register('command', 'dwreport_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwreport' and args[1] ~= '/report' and args[1] ~= '/dwr' and args[1] ~= '/bug')) then
        return;
    end

    e.blocked = true;

    local verb = #args >= 2 and args[2]:lower() or nil;

    if (verb == 'mark') then
        state.context       = captureContext();
        state.contextMarked = true;
        state.status        = 'Moment marked. Open the window when you are ready to write it up.';
        state.statusBad     = false;

        print(chat.header('dwreport'):append(chat.message('Moment marked -- your state right now is saved for the next report.')));

        return;
    end

    -- The two server verbs somebody will inevitably type with a slash. They
    -- are reads, they answer into chat on their own, and swallowing them as
    -- a report title would be a small daily annoyance for exactly the
    -- people who use them most.
    if (verb == 'recent' or verb == 'status') then
        issue('!dwr ' .. verb);

        return;
    end

    if (verb == 'clear') then
        state.title[1] = '';
        state.body[1]  = '';

        clearDraft();

        print(chat.header('dwreport'):append(chat.message('Draft cleared.')));

        return;
    end

    if (verb ~= nil and verb ~= 'ui' and verb ~= 'window' and verb ~= 'gui') then
        -- Everything after `/report ` becomes the title, so a player can
        -- start one in a single keystroke while it is still fresh.
        local title = e.command:sub(#args[1] + 2);

        state.title[1] = title:sub(1, limits.title);
        state.context  = captureContext();

        if (not state.open[1]) then
            toggleWindow();
        end

        return;
    end

    toggleWindow();
end);

--[[
* Watch what the player sends.
*
* Bare `!dwr` (and its ui/window/gui spellings) is intercepted and opens
* this window instead of going to the server -- dwsquad's pattern, kept
* because the server verb is the name players learn from each other, so it
* has to be a door and not a dead end. Every real verb still passes through
* untouched: that is the escape hatch this addon's header promises, and it
* must keep working.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a chunk fired in the same
* frame as something the player typed is the one that gets dropped -- and
* here that would be a piece of their bug report. Stamping the player's own
* line as a send makes the next queued command wait its interval instead of
* racing it.
--]]
ashita.events.register('packet_out', 'dwreport_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!dwr' or lower == '!dwr ui' or lower == '!dwr window' or lower == '!dwr gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwr') then
        lastSend = os.clock();
    end
end);

--[[
* Login and zone-in (0x000A serves both).
*
* The handshake is re-asked once per login, because whether this server
* speaks dwreport is a per-session fact and the answer gates every upload.
* Nothing else resets: a draft written before a zone line is still the
* draft, and the marked moment is still the moment -- it has a timestamp,
* and the report says how old it is.
--]]
ashita.events.register('packet_in', 'dwreport_zonein', function (e)
    if (e.id ~= 0x000A) then
        return;
    end

    serverSpeaks = false;
    helloAsked   = 0;
    helloTries   = 0;

    -- The cooldown was the OLD session's, and this may not even be the same
    -- character. The server re-asserts it on the next handshake or refusal.
    state.cooldown = 0;

    -- No handshake is sent from here. `hello` is the one line this addon is
    -- willing to risk leaking to /say if the server turns out not to speak
    -- it, so it is spent when the player opens the window -- not on every
    -- zone line of a session in which they were never going to file
    -- anything.
end);

ashita.events.register('load', 'dwreport_load', function ()
    print(chat.header('dwreport'):append(chat.message('/report (or /bug, /dwreport) files a bug report from in-game -- your game state is attached automatically.')));
    print(chat.header('dwreport'):append(chat.message('/report <title> starts one straight away, and /report mark saves your state to write up in a minute.')));
end);

ashita.events.register('unload', 'dwreport_unload', function ()
    if (draftDirty and (state.title[1] ~= '' or state.body[1] ~= '')) then
        saveDraft();
    end
end);
