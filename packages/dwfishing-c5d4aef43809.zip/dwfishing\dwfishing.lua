--[[
* DriftwoodXI -- dwfishing
*
* The whole fishing system in one window: a costed route from 0 to the ceiling,
* every fish this server can give you, the skill it wants, the bait that can
* actually hook it, the rod that will not lose it, every pool it swims in, and
* -- the part no wiki has -- what to catch NEXT, at this box's real rates.
*
* THE ROUTE TAB IS THE ONE THAT ANSWERS THE FIRST QUESTION. Everything else here
* answers something you already knew to ask; the route answers "I have never
* fished, what do I do" as an itinerary -- buy this rod and this bait, stand
* here, and when the number reaches N, move. It is solved in the generator
* against the shop prices, the sale prices, the pool weights and the three rolls
* between hooking a fish and keeping it, it minimises gil and breaks ties on
* casts, and it may never buy what it has not already caught -- so it opens with
* the cheapest rod in the game rather than with the one a rich player would use.
*
* THE NUMBERS HERE ARE NOT THE WIKI'S, AND THAT IS THE POINT. Fishing on
* DriftwoodXI is enabled (stock LandSandBoat ships it OFF) and multiplies
* skill-up chance by five. Both of those live in a gitignored per-box
* settings/map.lua that no wiki, no import and no invariant can see. The
* multiplier arrives on the wire and every percentage below is already scaled
* by it.
*
* EVERYTHING ELSE IS DERIVED, NOT AUTHORED. data/fishdata.lua is generated from
* the same sql/fishing_*.sql dumps the server imports AND from the fishing
* engine's own C++ tuning constants, parsed at generation time
* (tools/dwfishing/gen_fishdata.py). Nobody typed a fish's skill level or a
* bait's affinity into this addon, so nothing here can quietly disagree with
* the server -- and if the dumps move and nobody regenerates, a deploy gate
* refuses rather than shipping a guide that has started lying.
*
* THE THREE RULES THE WHOLE GUIDE TURNS ON, all read off fishingutils.cpp:
*   1. Bait affinity is a HARD gate. GetFishPool intersects the pool with the
*      equipped bait's fishing_bait_affinity rows; no row means that bait can
*      NEVER hook that fish, at any skill, in any weather.
*   2. Being under-skilled is a penalty, not a wall -- a fish up to 100 levels
*      above you still enters the pool. Landing it is the hard part.
*   3. Skill-ups come only from fish ABOVE your level and within 50 of it, and
*      the curve peaks at +11. Items and monsters teach nothing at all.
*   4. That curve is a NUMERATOR, not a percentage: it is rolled against 90,
*      less 10 outside a city and less another (20 - level/3) under 50. On this
*      box the multiplier pushes it past that roll across most of the window, so
*      the skill-up becomes certain and the +11 peak stops being worth chasing.
*   5. Hooking is not catching. Lose, line snap and rod break are rolled before
*      anything reaches the skill-up at all, and reaching more than 7 levels
*      above you is where losing starts.
*
* IT ASKS ONLY WHEN YOU ASK. One handshake on open and one on a zone line.
* There is no tick and no server push: the catalog is local, so the window
* needs the server for four things only -- your skill, your rank cap, where you
* are, and what this box is tuned to.
*
* TURN IT OFF AND NOTHING IS LOST. `!fish` works typed and says where you stand
* and what to catch next; `!fish route` walks the whole plan and `!fish rank`
* names the fish that lifts your cap, all in sentences. This is friendlier; it
* is not required.
--]]

addon.name    = 'dwfishing';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.4';
addon.desc    = 'The fishing guide: a costed 0-110 route, and every fish, bait, rod and spot at this server\'s real rates.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the `!dwh` lines sent below; installed
-- before any other text_in handler in this file (dwecho.lua). Without it the
-- player reads `Blaster : !dwh hello` in their own log on every zone line.
echo.install();

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; the sixteenth `_DW*DATA` name,
-- and nothing else on the server uses it, so matching it exactly is a safe
-- filter.
local DATA_SENDER = '_DWHDATA';

-- Protocol version the server announces in its `d|` record. An unknown one is
-- HARD REFUSED (one message, then silence) rather than guessed at.
local PROTOCOL = 1;

-- Chat is rate-limited by the client, not by this addon. One line per 1.2s and
-- a settle after a zone line, the dwscan cadence.
local SEND_INTERVAL = 1.2;
local ZONE_SETTLE   = 3.0;
local ANSWER_TIMEOUT = 5.0;

-----------------------------------------------------------------------------
-- The catalog
--
-- ONE AUTHORED FILE, TWO CONSUMERS. modules/driftwoodxi/fishing_core.lua loads
-- the identical file and both hash the bytes they actually loaded. A mismatch
-- means the addon and the server would describe different lakes, so the guide
-- REFUSES rather than picking one -- there is no version of that disagreement
-- where the window is safe to read.
-----------------------------------------------------------------------------

-- MUST MATCH modules/driftwoodxi/fishing_core.lua and the Python reference in
-- tools/dwfishing/gen_fishdata.py -- three implementations, one hash. The
-- 16-bit multiply split keeps the arithmetic inside a double's exact-integer
-- range (the dwtracker lesson).
local function fnv1a(text)
    local hash = 2166136261;

    for i = 1, #text do
        hash = bit.bxor(hash, string.byte(text, i)) % 4294967296;

        local lo = hash % 65536;
        hash = (((hash - lo) / 65536) * 16777619 % 65536) * 65536 + lo * 16777619;
        hash = hash % 4294967296;
    end

    return bit.tohex(hash);
end

local catalog = nil;
local catalogError = nil;

local function loadCatalog()
    local path = string.format('%s\\addons\\dwfishing\\data\\fishdata.lua',
        AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

    local file = io.open(path, 'rb');

    if (file == nil) then
        catalogError = 'data/fishdata.lua is missing from this addon install.';
        return;
    end

    local raw = file:read('*a');
    file:close();

    local normalized = raw:gsub('\r', '');
    local chunk, err = loadstring(normalized, 'dwfishing-catalog');

    if (chunk == nil) then
        catalogError = 'data/fishdata.lua will not parse: ' .. tostring(err);
        return;
    end

    local ok, data = pcall(chunk);

    -- Version 2 moved the hour/moon/month tables from macro index to FISH
    -- PATTERN ID and added prices, the rank ladder and the route. A reader
    -- written for 1 would index the new pattern tables without erroring and
    -- quietly draw the wrong curve, so this is a refusal like the hash is.
    if (not ok or type(data) ~= 'table' or data.version ~= 2) then
        catalogError = 'data/fishdata.lua is not a catalog this addon understands.';
        return;
    end

    -- Positional rows -> named records, once, at load. The generator's header
    -- documents every position and the harness locks them.
    local built = {
        hash      = fnv1a(normalized),
        version   = data.version,
        engine    = data.engine,
        baitPower = data.baitPower,
        distMod   = data.distMod,
        levelBias = data.levelBias,
        -- Indexed by the pattern id the FISH ROW carries, not by the macro
        -- index -- see the generator's header. Index 0 exists and is the
        -- engine's default arm, so every id resolves.
        hourP     = data.hourPattern,
        moonP     = data.moonPattern,
        monthP    = data.monthPattern,
        counts    = data.counts,
        fish      = {},
        fishById  = {},
        rods      = {},
        rodById   = {},
        baits     = {},
        baitById  = {},
        spots     = {},
        groups    = data.groups,
        fishSpots = data.fishSpots,
        fishBait  = data.fishBait,
        baitFish  = data.baitFish,
        mobs      = {},
        prices    = data.prices,
        ranks     = data.ranks,
        rankTest  = data.rankTest,
        plans     = data.routePlans,
        planSpots = data.routeSpots,
        levels    = data.routeLevels,
        terms     = data.routeTerms,
        altBand   = data.routeAltBand,
        altPlans  = data.routeAltPlans,
        altLevels = data.routeAltLevels,
    };

    for _, r in ipairs(data.fish) do
        local fish = {
            id = r[1], name = r[2], skill = r[3], size = r[4], water = r[5],
            rarity = r[6], legendary = r[7], item = r[8], minLen = r[9], maxLen = r[10],
            ranking = r[11], difficulty = r[12], delay = r[13], move = r[14],
            hour = r[15], moon = r[16], month = r[17], maxhook = r[18],
            keyitem = r[19], questOnly = r[20], contest = r[21], flags = r[22],
        };

        table.insert(built.fish, fish);
        built.fishById[fish.id] = fish;
    end

    for _, r in ipairs(data.rods) do
        local rod = {
            id = r[1], name = r[2], size = r[3], minRank = r[4], maxRank = r[5],
            legendary = r[6], breakable = r[7], attack = r[8], lgdAttack = r[9],
            recovery = r[10], time = r[11], lgdTime = r[12], smDelay = r[13],
            smMove = r[14], lgDelay = r[15], lgMove = r[16], multiplier = r[17],
            material = r[18], rating = r[19], flags = r[20],
        };

        table.insert(built.rods, rod);
        built.rodById[rod.id] = rod;
    end

    for _, r in ipairs(data.baits) do
        local bait = {
            id = r[1], name = r[2], type = r[3], maxhook = r[4],
            losable = r[5], rankmod = r[6], flags = r[7],
        };

        table.insert(built.baits, bait);
        built.baitById[bait.id] = bait;
    end

    for _, r in ipairs(data.spots) do
        table.insert(built.spots, {
            zone = r[1], area = r[2], group = r[3],
            zoneName = r[4], areaName = r[5], difficulty = r[6],
        });
    end

    for _, r in ipairs(data.mobs) do
        table.insert(built.mobs, {
            id = r[1], name = r[2], zone = r[3], zoneName = r[4], area = r[5],
            level = r[6], nm = r[7], rarity = r[8], reqBait = r[9], altBait = r[10],
            keyitem = r[11], questOnly = r[12], minLen = r[13], maxLen = r[14],
            ranking = r[15], difficulty = r[16],
        });
    end

    catalog = built;
end

loadCatalog();

-----------------------------------------------------------------------------
-- Live state, from the wire
-----------------------------------------------------------------------------
local state = {
    open       = { false },
    spoke      = false,      -- the server has answered at least once
    helloed    = false,
    reported   = false,      -- one render-error line, not sixty a second
    refused    = false,      -- protocol or catalog mismatch: one message, then silence
    building   = nil,
    asked      = nil,
    askedAt    = 0,
    status     = 'Asking the server where you stand...',
    statusBad  = false,

    -- p|
    rawSkill   = nil,
    level      = nil,
    rank       = nil,
    rankCap    = nil,
    zone       = nil,

    -- s|
    multiplier = nil,
    enabled    = nil,
    minLevel   = nil,
    contest    = nil,

    -- g|
    gear       = {},

    -- c|
    serverHash = nil,
};

-- What the ladder tab is showing. Defaults to your live level and follows it
-- until the player drags the slider, at which point it stays where they put it.
local planLevel = { 0 };
local planPinned = false;
local search    = { '' };
local searchMob = { '' };
local searchSpot = { '' };

local queue    = T{};
local lastSend = 0;
local readyAt  = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now < readyAt or now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    local command = table.remove(queue, 1);

    -- THROUGH dwecho, not around it. This addon calls echo.install() at load
    -- and then sent every line with QueueCommand, so the swallower was
    -- installed with nothing ever recorded for it to swallow -- and dwecho
    -- only matches lines it was told about. The player read `Blaster : !fish
    -- route` in their own chat log for every refresh, which is the exact
    -- symptom dwecho.lua's header opens with. `send` records and sends in one
    -- call precisely so the two cannot drift apart.
    echo.send(command);
end

--[[
* The one line this addon is sanctioned to send blind, and it is LATCHED.
*
* An unknown `!command` falls through to ordinary /say, so on a server whose
* dwh.lua is absent -- a launcher release that landed ahead of a server deploy,
* or any non-Driftwood server the boot script loaded this into -- an ungated
* send is the player publicly saying "!dwh hello" to the whole zone. Worse,
* they never see it, because dwecho blocks the local echo of our own lines.
* One line, once per zone, is the smallest thing that can cost anything.
--]]
local function hello()
    if (state.helloed or state.refused) then
        return;
    end

    state.helloed = true;
    state.asked   = 'hello';
    state.askedAt = os.clock();

    issue('!dwh hello');
end

-----------------------------------------------------------------------------
-- Record parsing
--
-- Every record is pipe-separated with a single-character kind. Anything this
-- addon does not recognise falls off the end of the chain rather than being an
-- error: a server newer than the addon must not break it, which is why the
-- `d|` record carries a version at all. Additive kinds never bump PROTOCOL.
-----------------------------------------------------------------------------
local function refuse(message)
    state.refused   = true;
    state.status    = message;
    state.statusBad = true;

    print(chat.header('dwfishing'):append(chat.error(message)));
end

local function handleRecord(line)
    -- Split on '|' by hand rather than with gmatch: a Lua pattern of '([^|]*)'
    -- yields an empty capture between every pair of fields, which silently
    -- shifts every index by one and is exactly the kind of off-by-one that
    -- renders as plausible-but-wrong data rather than as an error.
    local parts  = {};
    local cursor = 1;

    while (true) do
        local pipe = string.find(line, '|', cursor, true);

        if (pipe == nil) then
            table.insert(parts, string.sub(line, cursor));
            break;
        end

        table.insert(parts, string.sub(line, cursor, pipe - 1));
        cursor = pipe + 1;
    end

    local kind = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2] or '');

        if (version ~= PROTOCOL) then
            refuse(string.format(
                'This server speaks fishing protocol %s and this addon speaks %d. Update the addon.',
                tostring(parts[2]), PROTOCOL));

            return;
        end

        state.spoke    = true;
        state.building = { verb = parts[3] };

        -- THE GEAR TABLE IS REPLACED, NOT MERGED INTO. `g|` records are
        -- SPARSE: the server emits a record only for a slot that holds a
        -- fishing piece, so taking one off sends nothing at all and the old
        -- entry sat there forever, marking a slot [worn] over gear the
        -- character was no longer wearing. Cleared on the envelope that
        -- carries them rather than on every envelope -- a `status` envelope
        -- (a bare refusal) has no g| records and must not wipe the table.
        -- `hello` is the only verb that emits them; verbs.state aliases
        -- verbs.hello and the envelope is opened as 'hello', so that name is
        -- the whole set.
        if (parts[3] == 'hello') then
            state.gear = {};
        end

        return;
    end

    if (state.building == nil) then
        return; -- outside an envelope: discarded, per the wire contract
    end

    if (kind == 'z') then
        -- ...UNLESS THIS ENVELOPE IS THE ONE CARRYING THE COMPLAINT. A refusal
        -- is `d|1|status` / `e|<message>` / `z|status` -- squad_storage.lua's
        -- writer wraps a bare fail in its own envelope precisely so the addon,
        -- which discards records outside one, can see it at all. So the close
        -- below was erasing the message three records after it arrived, and
        -- EVERY server refusal this window could receive was invisible: set
        -- for one handler call and blanked before a frame was ever drawn. The
        -- latch this comment used to point at (state.refused) is a different
        -- one -- it belongs to the catalog-mismatch path and never fires here.
        local failed = state.building ~= nil and state.building.failed;

        state.building = nil;
        state.asked    = nil;

        -- A CLOSED ENVELOPE CLEARS A STALE COMPLAINT. The answer-timeout writes
        -- "The server did not answer" and sets statusBad; a later envelope that
        -- arrives and completes is proof that it did. Leaving the old message
        -- up meant one slow reply painted the window red for the rest of the
        -- session, over a guide that was by then perfectly correct.
        if (not failed) then
            state.status    = '';
            state.statusBad = false;
        end

        return;
    end

    if (kind == 'e') then
        state.status    = parts[2] or 'The server refused.';
        state.statusBad = true;

        -- Marked on the envelope so the `z|` that closes it knows not to wipe
        -- what it just delivered. Reset per envelope by the `d|` handler, so a
        -- later clean response still clears the message.
        if (state.building ~= nil) then
            state.building.failed = true;
        end

        return;
    end

    if (kind == 'm') then
        return;
    end

    if (kind == 'c') then
        state.serverHash = parts[2];

        -- THE ONE MISMATCH THAT MUST REFUSE. If the server's catalog is not the
        -- catalog this window is drawing, every spot, bait and skill number
        -- below is about a different server. Stale is not the risk; WRONG is.
        if (catalog ~= nil and parts[2] ~= 'none' and parts[2] ~= catalog.hash) then
            refuse('This addon\'s fishing data does not match the server\'s. Update the addon (or re-run the launcher) -- the guide is hidden rather than shown wrong.');
        end

        return;
    end

    if (kind == 's') then
        state.multiplier = tonumber(parts[2] or '') or 1.0;
        state.enabled    = (tonumber(parts[3] or '') or 0) == 1;
        state.minLevel   = tonumber(parts[4] or '') or 0;
        state.contest    = (tonumber(parts[5] or '') or 0) == 1;

        return;
    end

    if (kind == 'p') then
        state.rawSkill = tonumber(parts[2] or '') or 0;
        state.level    = tonumber(parts[3] or '') or 0;
        state.rank     = tonumber(parts[4] or '') or 0;
        state.rankCap  = tonumber(parts[5] or '') or 0;
        state.zone     = tonumber(parts[6] or '') or 0;

        if (not planPinned) then
            planLevel[1] = state.level;
        end

        return;
    end

    if (kind == 'g') then
        state.gear[parts[2]] = tonumber(parts[3] or '') or 0;

        return;
    end
end

ashita.events.register('packet_in', 'dwfishing_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwfishing'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* A zone line means a new place to stand, which is the one thing on the wire
* that can change without the player doing anything in this window. The
* handshake latch is cleared so the next open re-asks -- and a map restart logs
* everyone out, so the server on the other side may well be the updated one,
* which is why the refusal latch clears too.
--]]
ashita.events.register('packet_in', 'dwfishing_zonein', function (e)
    if (e.id ~= 0x000A) then
        return;
    end

    state.helloed  = false;
    state.refused  = false;
    state.building = nil;
    state.asked    = nil;
    state.status   = '';
    state.statusBad = false;

    readyAt = os.clock() + ZONE_SETTLE;

    if (state.open[1]) then
        hello();
    end
end);

-----------------------------------------------------------------------------
-- Derived views over the catalog
--
-- All of this is arithmetic over the LOCAL catalog and the live multiplier,
-- which is the only number the window is handed. Nothing here re-derives a
-- server decision; it re-reads the same constants the server compiled from.
-----------------------------------------------------------------------------

-- The engine's skill-up NUMERATOR, factorised exactly as the C++ expression
-- separates: a term that depends only on the level difference, plus one that
-- depends only on your level, floored, then scaled by this box's multiplier.
-- nil where the engine returns early -- at or below your level, or beyond the
-- window.
local function skillupNumerator(level, fishSkill)
    if (catalog == nil) then
        return nil;
    end

    local difference = fishSkill - level;

    if (difference < 1 or difference > catalog.engine.skillupWindow) then
        return nil;
    end

    local dist = catalog.distMod[difference] or 0;
    local bias = catalog.levelBias[level + 1] or 0;
    local base = math.max(catalog.engine.skillupFloor, dist + bias);

    return base * (state.multiplier or 1.0);
end

--[[
* THE DENOMINATOR, AND WHY THIS WINDOW USED TO PRINT A NUMBER THAT WAS NOT A
* PERCENTAGE.
*
* `if (xirand::GetRandomNumber(skillRoll) < maxChance)` draws from
* [0, skillRoll), so the chance of a skill-up is maxChance / skillRoll -- and
* skillRoll is never a hundred. It opens at 90, drops 10 anywhere that is not a
* city zone (which is every fishing spot worth standing in) and drops another
* `20 - floor(level / 3)` below level 50. At level 0 the roll is out of SIXTY.
*
* On this box that matters twice over: the early game is a third better than the
* old number claimed, and with the multiplier applied the numerator passes the
* roll outright across most of the window -- the skill-up stops being a chance
* at all, and that is the single most useful thing the window can say.
--]]
local function skillRoll(level)
    if (catalog == nil or catalog.terms == nil) then
        return 100;
    end

    local terms = catalog.terms;
    local roll  = terms.rollBase - terms.rollOutdoor;

    if (level < terms.rollNoviceUnder) then
        roll = roll - (terms.rollNoviceBase - math.floor(level / terms.rollNoviceDiv));
    end

    return math.max(roll, 1);
end

local function skillupChance(level, fishSkill)
    local numerator = skillupNumerator(level, fishSkill);

    if (numerator == nil) then
        return nil;
    end

    return math.min(1.0, numerator / skillRoll(level)) * 100;
end

-- The baits that can hook a fish at all, best power first. An empty list means
-- the fish is unreachable with every bait in the game -- which happens, and the
-- window says so rather than leaving a blank.
local function baitsFor(fishId)
    local out = {};

    if (catalog == nil) then
        return out;
    end

    local flat = catalog.fishBait[fishId];

    if (flat == nil) then
        return out;
    end

    for index = 1, #flat, 2 do
        local bait = catalog.baitById[flat[index]];

        if (bait ~= nil) then
            table.insert(out, { bait = bait, power = flat[index + 1] });
        end
    end

    return out;
end

local function spotsFor(fishId)
    local out = {};

    if (catalog == nil) then
        return out;
    end

    for _, index in ipairs(catalog.fishSpots[fishId] or {}) do
        local spot = catalog.spots[index];

        if (spot ~= nil) then
            table.insert(out, spot);
        end
    end

    return out;
end

local function fishInSpot(spot)
    local out = {};

    if (catalog == nil) then
        return out;
    end

    local flat = catalog.groups[spot.group];

    if (flat == nil) then
        return out;
    end

    -- flat[index + 1] is the GROUP's rarity column, which the engine loads and
    -- never uses (see rarityWord). It is carried here rather than dropped so
    -- the harness can keep asserting the row shape the generator emits.
    for index = 1, #flat, 4 do
        local fish = catalog.fishById[flat[index]];

        if (fish ~= nil) then
            table.insert(out, { fish = fish, groupRarity = flat[index + 1], pool = flat[index + 2] });
        end
    end

    return out;
end

-- The rod the engine will not penalise for this fish. Size mismatch costs 3 or
-- 5 hook points (CalculateHookChance), and a rod whose maxRank sits under the
-- fish's ranking is the one that snaps -- so "best" means matching size and
-- carrying the ranking, cheapest rating first.
local function rodsFor(fish)
    local out = {};

    if (catalog == nil) then
        return out;
    end

    for _, rod in ipairs(catalog.rods) do
        if (rod.size == fish.size and rod.maxRank >= fish.ranking) then
            table.insert(out, rod);
        end
    end

    return out;
end

-- The hours the curve actually peaks at, read off the sampled curve rather than
-- described from memory. Patterns 2, 3 and 4 are not curves at all -- the
-- engine tests the clock directly -- but the generator samples those the same
-- way, so a flat-topped run of hours falls out here as a list rather than
-- needing a special case and a hand-written note to go with it.
local function peakHours(curve)
    local best = -1;

    for index = 1, #curve do
        best = math.max(best, curve[index]);
    end

    local hours = {};

    for index = 1, #curve do
        if (curve[index] >= best - 1e-6) then
            table.insert(hours, index - 1);
        end
    end

    return hours, best;
end

-- Consecutive hours collapse to a range; the clock-test patterns are mostly one
-- or two runs and reading them back as a list of twenty-two hours would be
-- worse than useless.
local function hourList(hours)
    local parts = {};
    local index = 1;

    while (index <= #hours) do
        local last = index;

        while (last < #hours and hours[last + 1] == hours[last] + 1) do
            last = last + 1;
        end

        if (last == index) then
            table.insert(parts, string.format('%02d:00', hours[index]));
        else
            table.insert(parts, string.format('%02d:00-%02d:00', hours[index], hours[last]));
        end

        index = last + 1;
    end

    return table.concat(parts, ', ');
end

local function hourWord(fish)
    if (catalog == nil) then
        return 'any hour';
    end

    local curve = catalog.hourP[fish.hour] or catalog.hourP[0];

    if (curve == nil) then
        return 'any hour';
    end

    local hours = peakHours(curve);

    -- Every hour equally good is the engine's default arm, and "peaks at all of
    -- them" would be noise.
    if (#hours >= #curve) then
        return 'any hour';
    end

    -- Mostly-good is stated as the exception, because "any hour except 05:00
    -- and 17:00" is the sentence, and its complement is twenty-two of them.
    if (#hours * 2 > #curve) then
        local worst = {};

        for index = 1, #curve do
            local hit = false;

            for _, hour in ipairs(hours) do
                hit = hit or (hour == index - 1);
            end

            if (not hit) then
                table.insert(worst, index - 1);
            end
        end

        return 'any hour except ' .. hourList(worst);
    end

    return 'best at ' .. hourList(hours);
end

local MOON_NAMES = {
    'New', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous',
    'Full', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent',
};

local function moonWord(fish)
    if (catalog == nil) then
        return 'any moon';
    end

    -- Moon pattern 5 dispatches to MOONPATTERN_4, not _5, and the moon's own
    -- default arm is 1.0 where the hour's and month's are 0.5. Both of those
    -- are the generator's problem now, and this just reads what it emitted.
    local curve = catalog.moonP[fish.moon] or catalog.moonP[0];

    if (curve == nil) then
        return 'any moon';
    end

    local phases = peakHours(curve);

    if (#phases >= #curve) then
        return 'any moon';
    end

    local parts = {};

    for index = 1, math.min(2, #phases) do
        table.insert(parts, MOON_NAMES[phases[index] + 1] or '?');
    end

    if (#phases > 2) then
        table.insert(parts, string.format('+%d more', #phases - 2));
    end

    return 'best at ' .. table.concat(parts, ' / ') .. ' moon';
end

local SIZE_WORD  = { [0] = 'Small', [1] = 'Large' };
local WATER_WORD = { [0] = 'Any water', [1] = 'Freshwater', [2] = 'Saltwater' };
local BAIT_WORD  = { [0] = 'Bait', [1] = 'Lure', [2] = 'Special' };

--[[
* Rarity is a per-thousand weight the engine multiplies the hook chance by, so
* it is a real number and not a mood. Stated as the multiplier it is.
*
* AND IT IS THE FISH'S OWN RARITY, NOT THE GROUP'S. fishing_group carries a
* rarity column per (group, fish) and this tab used to draw it, but the engine
* does not: LoadFishGroups reads it into the pool map and GetFishPool hands it
* back as `fish.second`, where the catch roll leaves it on a commented-out line
* (`// uint16 baitPower = fish.second; //@TODO`). What CalculateHookChance
* actually multiplies by is `fish->rarity`, straight off fishing_fish. The two
* disagree for 130 of the 1070 group rows, so the old column was quietly wrong
* about roughly one row in eight -- including saying "common" about a Black Sole
* the engine draws at 0.15x.
--]]
local function rarityWord(rarity)
    if (rarity >= 1000) then
        return 'common';
    end

    return string.format('%.1fx rarer', 1000 / math.max(rarity, 1));
end

local function zoneName(spot)
    local resolved = nil;
    local ok, name = pcall(function ()
        return AshitaCore:GetResourceManager():GetString('zones.names', spot.zone);
    end);

    if (ok and name ~= nil and #name > 0) then
        resolved = name;
    end

    -- The catalog's own copy is the raw zone key (Carpenters_Landing); the
    -- client's DAT holds the display name and is preferred, exactly the way
    -- dwscan resolves item names rather than putting them on the wire.
    return resolved or (spot.zoneName or ''):gsub('_', ' ');
end

local function itemName(itemId)
    if (itemId == nil or itemId == 0) then
        return nil;
    end

    local ok, item = pcall(function ()
        return AshitaCore:GetResourceManager():GetItemById(itemId);
    end);

    if (ok and item ~= nil and item.Name ~= nil and #item.Name[1] > 0) then
        return item.Name[1];
    end

    return string.format('item %d', itemId);
end

-- The skill-up ladder for a level: every fish that can teach you something,
-- best first. Items and quest-only rows are excluded because the engine grants
-- no skill for them at all (fishingutils.cpp:2933).
local function ladderFor(level)
    local out = {};

    if (catalog == nil) then
        return out;
    end

    for _, fish in ipairs(catalog.fish) do
        if (fish.item == 0 and fish.questOnly == 0) then
            local numerator = skillupNumerator(level, fish.skill);

            if (numerator ~= nil) then
                table.insert(out, {
                    fish      = fish,
                    numerator = numerator,
                    chance    = math.min(1.0, numerator / skillRoll(level)) * 100,
                    diff      = fish.skill - level,
                    baits     = baitsFor(fish.id),
                    spots     = spotsFor(fish.id),
                });
            end
        end
    end

    -- Ranked on the NUMERATOR, not on the probability. Once the multiplier
    -- pushes maxChance past the roll every row reads 100% and sorting on that
    -- would order the ladder alphabetically, so the engine's own preference is
    -- kept and the saturation is reported instead of sorted on.
    table.sort(out, function (a, b)
        if (a.numerator ~= b.numerator) then
            return a.numerator > b.numerator;
        end

        if (#a.spots ~= #b.spots) then
            return #a.spots > #b.spots;
        end

        return a.fish.name < b.fish.name;
    end);

    return out;
end

local function matches(text, needle)
    if (needle == nil or #needle == 0) then
        return true;
    end

    return string.find(string.lower(text), string.lower(needle), 1, true) ~= nil;
end

-----------------------------------------------------------------------------
-- The route, 0 to the ceiling
--
-- The catalog carries a plan for every level and the plans themselves
-- deduplicated; a SEGMENT is a run of levels that share one. The run boundaries
-- are collapsed HERE rather than in the generator because the rates printed
-- beside them depend on this box's multiplier, which only exists on the wire --
-- the same split the skill-up curve uses, one level up.
--
-- Recomputed only when the multiplier changes, which is once per session.
-----------------------------------------------------------------------------
local route = {
    multiplier = nil, segments = {}, alternates = {},
    casts = 0, gil = 0, earn = 0, kit = 0,
};

local function buildRoute()
    if (catalog == nil or catalog.levels == nil) then
        return;
    end

    local multiplier = state.multiplier or 1.0;

    if (route.multiplier == multiplier) then
        return;
    end

    local segments = {};
    local points   = catalog.terms.pointsPerLevel;
    local totals   = { casts = 0, gil = 0, earn = 0 };

    for level = 0, catalog.engine.maxLevel - 1 do
        local entry = catalog.levels[level + 1];

        if (entry ~= nil) then
            local quads = entry[4];
            local rate  = 0.0;
            local top, topShare = nil, -1;

            for index = 1, #quads, 4 do
                local difference = quads[index + 1];
                local share      = quads[index + 2];
                local amount     = quads[index + 3];
                local dist       = catalog.distMod[difference] or 0;
                local bias       = catalog.levelBias[level + 1] or 0;
                local numerator  = math.max(catalog.engine.skillupFloor, dist + bias) * multiplier;

                rate = rate + share * math.min(1.0, numerator / skillRoll(level)) * amount;

                if (share > topShare) then
                    top, topShare = quads[index], share;
                end
            end

            local casts = (rate > 0) and (points / rate) or 0;
            local last  = segments[#segments];

            totals.casts = totals.casts + casts;
            totals.gil   = totals.gil + casts * entry[2];
            totals.earn  = totals.earn + casts * entry[3];

            if (last ~= nil and last.plan == entry[1]) then
                last.to    = level + 1;
                last.casts = last.casts + casts;
                last.gil   = last.gil + casts * entry[2];
                last.earn  = last.earn + casts * entry[3];
                last.tops[top] = (last.tops[top] or 0) + 1;
            else
                table.insert(segments, {
                    plan  = entry[1],
                    from  = level,
                    to    = level + 1,
                    casts = casts,
                    gil   = casts * entry[2],
                    earn  = casts * entry[3],
                    tops  = { [top] = 1 },
                });
            end
        end
    end

    -- What the route asks you to BUY, each rod and each reusable lure counted
    -- once. Consumable bait is not in here: it is priced per cast inside the
    -- levels, because that is where it is actually spent.
    local owned, kit = {}, 0;

    for _, segment in ipairs(segments) do
        local plan = catalog.plans[segment.plan];

        local buy = { plan[3] };

        if (plan[4] == 1) then
            table.insert(buy, plan[2]);
        end

        for _, id in ipairs(buy) do
            local price = catalog.prices[id];

            if (price ~= nil and not owned[id]) then
                owned[id] = true;
                kit = kit + price[1];
            end
        end

        -- The commonest catch names the segment, which is what a player
        -- remembers a spot by.
        local best, bestCount = nil, -1;

        for id, count in pairs(segment.tops) do
            if (count > bestCount) then
                best, bestCount = id, count;
            end
        end

        segment.top = best;
    end

    -- The alternate openers, costed the same way over the same band. Same
    -- arithmetic as above, so a difference between the two lists can only come
    -- from the catalog and never from two ways of adding it up.
    local alternates = {};

    for index, plan in ipairs(catalog.altPlans or {}) do
        local rows  = (catalog.altLevels or {})[index];
        local entry = { plan = plan, casts = 0, gil = 0, earn = 0, tops = {} };

        for level = catalog.altBand[1], catalog.altBand[2] - 1 do
            local row = rows and rows[level + 1];

            if (row ~= nil) then
                local quads = row[3];
                local rate  = 0.0;
                local top, topShare = nil, -1;

                for at = 1, #quads, 4 do
                    local dist      = catalog.distMod[quads[at + 1]] or 0;
                    local bias      = catalog.levelBias[level + 1] or 0;
                    local numerator = math.max(catalog.engine.skillupFloor, dist + bias) * multiplier;

                    rate = rate + quads[at + 2] * math.min(1.0, numerator / skillRoll(level)) * quads[at + 3];

                    if (quads[at + 2] > topShare) then
                        top, topShare = quads[at], quads[at + 2];
                    end
                end

                local casts = (rate > 0) and (points / rate) or 0;

                entry.casts = entry.casts + casts;
                entry.gil   = entry.gil + casts * row[1];
                entry.earn  = entry.earn + casts * row[2];
                entry.tops[top] = (entry.tops[top] or 0) + 1;
            end
        end

        local best, bestCount = nil, -1;

        for id, count in pairs(entry.tops) do
            if (count > bestCount) then
                best, bestCount = id, count;
            end
        end

        entry.top = best;
        entry.kit = (catalog.prices[plan[3]] and catalog.prices[plan[3]][1] or 0)
            + ((plan[4] == 1 and catalog.prices[plan[2]]) and catalog.prices[plan[2]][1] or 0);

        table.insert(alternates, entry);
    end

    route = {
        multiplier = multiplier,
        segments   = segments,
        alternates = alternates,
        casts      = totals.casts,
        gil        = totals.gil,
        earn       = totals.earn,
        kit        = kit,
    };
end

-- The rank gate a level sits under, and the fish that lifts it.
-- KEYED ON RANK, THE WAY THE SERVER DOES IT (fishing_core.lua, `row[1] ==
-- rank + 1`). This took a SKILL LEVEL and returned the first row whose
-- threshold was above it, which is a different question with a different
-- answer: rank and skill are independent, and the whole point of this panel is
-- the player whose skill has stopped because their RANK caps it. At the cap
-- the two even disagree by a whole rung -- a rank 5 fisherman sits at skill 60,
-- and `60 < row[2]` first succeeds on rank 7's row, so the window named the
-- wrong rank, the wrong test fish, and told them to buy it.
--
-- The `< threshold` form also dropped the top rung entirely: nothing is above
-- 100, so a rank 9 fisherman at the cap was told there was no rung left.
local function rankAt(rank)
    if (catalog == nil or catalog.ranks == nil) then
        return nil;
    end

    for _, row in ipairs(catalog.ranks) do
        if (row[1] == (rank or 0) + 1) then
            return row;
        end
    end

    return nil;
end

-----------------------------------------------------------------------------
-- Rendering
-----------------------------------------------------------------------------
local COL_GOOD = { 0.42, 0.78, 0.42, 1.0 };
local COL_WARN = { 0.95, 0.78, 0.25, 1.0 };
local COL_BAD  = { 0.90, 0.35, 0.32, 1.0 };
local COL_DIM  = { 0.62, 0.62, 0.62, 1.0 };

local function textColored(color, text)
    imgui.TextColored(color, text);
end

-- Route totals run to six figures, and an unbroken run of digits is unreadable
-- at a glance -- which is the only reason anyone looks at them.
local function commaNumber(value)
    local text = string.format('%d', math.floor((value or 0) + 0.5));
    local out  = text:reverse():gsub('(%d%d%d)', '%1,'):reverse();

    return (out:gsub('^,', ''));
end

local function helpMarker(text)
    imgui.SameLine();
    imgui.TextDisabled('(?)');

    if (imgui.IsItemHovered()) then
        imgui.BeginTooltip();
        imgui.PushTextWrapPos(imgui.GetFontSize() * 28.0);
        imgui.TextUnformatted(text);
        imgui.PopTextWrapPos();
        imgui.EndTooltip();
    end
end

-- ITEMS ARE NOT BAIT-GATED, AND SAYING THEY WERE WAS A LIE THE HARNESS CAUGHT.
-- GetFishPool intersects the fish pool with the equipped bait's affinity rows,
-- but GetItemPool does no such thing -- junk is drawn from the area's group on
-- its own weight, whatever is on the hook. Every item row therefore has no
-- affinity row, and rendering that as "no bait in the game hooks this" told
-- players a Rusty Bucket was unobtainable when it is the one thing they cannot
-- avoid catching.
local function baitSummary(baits, limit, isItem)
    if (isItem) then
        return 'any bait (junk ignores affinity)';
    end

    if (#baits == 0) then
        return 'no bait in the game hooks this';
    end

    local parts = {};

    for index = 1, math.min(limit or 3, #baits) do
        local entry = baits[index];

        table.insert(parts, string.format('%s (p%d)', entry.bait.name, entry.power));
    end

    return table.concat(parts, ', ');
end

local function spotSummary(spots, limit)
    if (#spots == 0) then
        return 'no pool holds it';
    end

    local parts = {};

    for index = 1, math.min(limit or 2, #spots) do
        local spot = spots[index];

        table.insert(parts, string.format('%s - %s', zoneName(spot), spot.areaName));
    end

    if (#spots > (limit or 2)) then
        table.insert(parts, string.format('+%d more', #spots - (limit or 2)));
    end

    return table.concat(parts, ', ');
end

-----------------------------------------------------------------------------
-- Tab: Route -- the whole thing, 0 to the ceiling
--
-- THIS IS THE TAB THE OTHER SIX WERE MISSING. Everything else here answers a
-- question you already knew to ask; this one answers "I have never fished, what
-- do I do", and it answers it as an itinerary: buy this, stand here, and when
-- the number reaches N, move. The optimisation is the generator's (it minimises
-- gil and breaks ties on casts, and it may never buy what the route has not
-- already caught) -- everything below draws its result at this box's rate.
-----------------------------------------------------------------------------
local function itemLine(id)
    local price = catalog and catalog.prices[id];

    if (price == nil) then
        return 'not sold by any shop in the catalog';
    end

    return string.format('%d gil from %s in %s%s',
        price[1], price[3], price[2],
        (price[5] <= 1) and ' (reusable -- you buy it once)' or ' each');
end

local function gearName(index, id)
    local entry = index[id];

    return (entry ~= nil) and entry.name or itemName(id);
end

local function segmentAt(level)
    for _, segment in ipairs(route.segments) do
        if (level >= segment.from and level < segment.to) then
            return segment;
        end
    end

    return nil;
end

local function tabRoute()
    if (catalog == nil or catalog.levels == nil) then
        return;
    end

    buildRoute();

    if (#route.segments == 0) then
        textColored(COL_BAD, 'This catalog carries no route.');

        return;
    end

    if (state.level == nil) then
        textColored(COL_DIM, 'Waiting for the server to say where you stand -- the plan below is the whole route.');
    end

    local level = state.level or 0;
    local here  = segmentAt(level);

    -- ---- where you are, right now -------------------------------------
    if (state.level ~= nil) then
        imgui.Text(string.format('Fishing skill %.1f', (state.rawSkill or 0) / 10));
        imgui.SameLine();
        textColored(COL_DIM, string.format('| rank %d, capped at %d | %d of %d done',
            state.rank or 0, state.rankCap or 0, level, catalog.engine.maxLevel));

        if (level >= (state.rankCap or 0)) then
            local gate = rankAt(state.rank or 0);

            textColored(COL_BAD, 'You are AT your rank cap. Nothing you catch will move the number.');

            if (gate ~= nil and catalog.rankTest ~= nil) then
                local fish = catalog.fishById[gate[3]];

                -- gate[2] is the skill the test is TAKEN at, which for the next
                -- rung is the cap you are stuck at right now -- so printing it
                -- as the new cap said "that lifts you to Craftsman, cap 60" to
                -- somebody already capped at 60. The cap a rung grants is one
                -- step above the skill it is tested at.
                textColored(COL_WARN, string.format('Catch a %s and trade it to %s in %s -- that lifts you to %s, cap %d.',
                    (fish ~= nil) and fish.name or itemName(gate[3]),
                    catalog.rankTest.npc, catalog.rankTest.zone, gate[4],
                    gate[2] + catalog.rankTest.capStep));
                imgui.SameLine();
                helpMarker('Nothing in the game states the cap or the reason, which is why this ' ..
                    'is the commonest way a fisherman gets stuck: the number simply stops moving ' ..
                    'and no message explains it.');

                -- Not a tooltip. A player who is stuck is the one person who
                -- most needs to know they do not have to grind to the exact cap
                -- first, and a fact you have to hover to find is a fact most
                -- people never read.
                textColored(COL_DIM, string.format(
                    '   The guild lets you test from skill %d, not only at %d.%s',
                    gate[2] - catalog.rankTest.tolerance, gate[2],
                    (gate[1] == catalog.rankTest.lastRank and catalog.rankTest.expertKey)
                        and ' That last rung also wants the guild key item and the quest behind it.' or ''));

                if (catalog.prices[gate[3]] ~= nil) then
                    textColored(COL_DIM, string.format('   (or just buy one: %s)', itemLine(gate[3])));
                end
            end
        elseif (here ~= nil) then
            local plan = catalog.plans[here.plan];
            local spot = catalog.spots[plan[1]];

            textColored(COL_GOOD, string.format('Right now: %s - %s, %s + %s.',
                zoneName(spot), spot.areaName,
                gearName(catalog.rodById, plan[3]), gearName(catalog.baitById, plan[2])));
            imgui.Text(string.format('   Rod: %s', itemLine(plan[3])));
            imgui.Text(string.format('   Bait: %s', itemLine(plan[2])));

            if (here.top ~= nil and catalog.fishById[here.top] ~= nil) then
                imgui.Text(string.format('   Most of your skill here comes from %s.',
                    catalog.fishById[here.top].name));
            end

            textColored(COL_DIM, string.format('   Stay until %d, about %d more casts.',
                here.to, math.max(0, math.floor(here.casts * (here.to - level) / math.max(1, here.to - here.from)))));
        end

        imgui.Separator();
    end

    -- ---- the whole plan -----------------------------------------------
    imgui.Text(string.format('%d moves, about %s casts, %s gil of rods and bait.',
        #route.segments, commaNumber(route.casts), commaNumber(route.kit + route.gil)));
    imgui.SameLine();
    helpMarker('Chosen by gil first and casts second -- cheapest, as asked -- and it may never ' ..
        'buy what it has not already caught, so it opens with the cheapest rod in the game and ' ..
        'upgrades once the fishing has paid for it. Casts are whole casts, hooked or not, at ' ..
        'this server\'s skill-up rate, averaged over every hour, moon and month.');

    if (route.earn > route.kit + route.gil) then
        textColored(COL_GOOD, string.format(
            'What you land on the way is worth about %s gil, so the route pays for itself many times over.',
            commaNumber(route.earn)));
    end

    if (imgui.BeginTable('##dwfishing_route', 7,
        bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY,
                ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Skill', ImGuiTableColumnFlags_WidthStretch, 0.55);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 2.0);
        imgui.TableSetupColumn('Rod', ImGuiTableColumnFlags_WidthStretch, 1.3);
        imgui.TableSetupColumn('Bait', ImGuiTableColumnFlags_WidthStretch, 1.1);
        imgui.TableSetupColumn('Mostly', ImGuiTableColumnFlags_WidthStretch, 1.1);
        imgui.TableSetupColumn('Casts', ImGuiTableColumnFlags_WidthStretch, 0.6);
        imgui.TableSetupColumn('Gil', ImGuiTableColumnFlags_WidthStretch, 0.7);
        imgui.TableHeadersRow();

        local carried = {};

        for _, segment in ipairs(route.segments) do
            local plan = catalog.plans[segment.plan];
            local spot = catalog.spots[plan[1]];
            local mine = (segment == here);

            imgui.TableNextRow();

            imgui.TableNextColumn();
            if (mine) then
                textColored(COL_GOOD, string.format('%d-%d', segment.from, segment.to));
            else
                imgui.Text(string.format('%d-%d', segment.from, segment.to));
            end

            imgui.TableNextColumn();
            imgui.Text(string.format('%s - %s', zoneName(spot), spot.areaName));

            -- A rank test falls inside this stretch: say so where the player is
            -- looking, because arriving at the cap with no idea why is the
            -- failure this whole feature exists to prevent.
            for _, row in ipairs(catalog.ranks or {}) do
                if (row[2] > segment.from and row[2] <= segment.to) then
                    local fish = catalog.fishById[row[3]];

                    textColored(COL_WARN, string.format('at %d: guild test -- trade a %s', row[2],
                        (fish ~= nil) and fish.name or itemName(row[3])));
                end
            end

            imgui.TableNextColumn();
            local rodText = gearName(catalog.rodById, plan[3]);

            if (carried.rod ~= plan[3]) then
                textColored(COL_WARN, rodText);
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Buy here: ' .. itemLine(plan[3]));
                end
                carried.rod = plan[3];
            else
                textColored(COL_DIM, rodText);
            end

            -- A rod that snaps is a rod you have to walk back for, and no table
            -- here knows what that is worth -- so it is stated, not priced.
            if (plan[5] > 0.005) then
                textColored(COL_BAD, string.format('snaps ~1 cast in %d', math.floor(1 / plan[5])));
            end

            imgui.TableNextColumn();
            local baitText = gearName(catalog.baitById, plan[2]);

            if (carried.bait ~= plan[2]) then
                textColored(COL_WARN, baitText);
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Buy here: ' .. itemLine(plan[2]));
                end
                carried.bait = plan[2];
            else
                textColored(COL_DIM, baitText);
            end

            imgui.TableNextColumn();
            if (segment.top ~= nil and catalog.fishById[segment.top] ~= nil) then
                imgui.Text(catalog.fishById[segment.top].name);
            end

            imgui.TableNextColumn();
            imgui.Text(commaNumber(segment.casts));

            imgui.TableNextColumn();
            imgui.Text(commaNumber(segment.gil));
        end

        imgui.EndTable();
    end

    -- ---- somewhere else to start -------------------------------------
    --
    -- THE OPENING IS THE ONE PICK THE OPTIMISER IS LEAST QUALIFIED TO MAKE. It
    -- ranks every water in the game and knows nothing about which of them you
    -- can walk to, and the character least likely to own an airship pass or an
    -- expansion is the one at skill 0. So the first stretch is offered as a
    -- CHOICE: the best plan in each of several other places, over the same
    -- levels, costed the same way. Every one of them is a real answer -- pick
    -- the one you can get to.
    if (#route.alternates > 0 and catalog.altBand ~= nil) then
        imgui.Separator();

        -- Unfolded where it matters. A player still inside the band is the one
        -- this list exists for and should not have to go looking for it; past
        -- it, it is history and folds away.
        local inBand = (state.level == nil) or (state.level < catalog.altBand[2]);
        local title  = string.format('Cannot reach the first two? Other places to fish %d-%d',
            catalog.altBand[1], catalog.altBand[2]);

        if (inBand) then
            textColored(COL_WARN, title);
        end

        if (inBand or imgui.CollapsingHeader(title .. '###dwfishing_alts')) then
            imgui.TextWrapped(string.format(
                'The same %d levels, somewhere else, costed the same way. The route above is the ' ..
                'cheapest this server\'s own numbers allow; these are what it looks like if you ' ..
                'start where you already are.', catalog.altBand[2] - catalog.altBand[1]));

            if (imgui.BeginTable('##dwfishing_route_alts', 6,
                bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg,
                        ImGuiTableFlags_SizingStretchProp))) then
                imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 2.0);
                imgui.TableSetupColumn('Rod', ImGuiTableColumnFlags_WidthStretch, 1.3);
                imgui.TableSetupColumn('Bait', ImGuiTableColumnFlags_WidthStretch, 1.1);
                imgui.TableSetupColumn('Mostly', ImGuiTableColumnFlags_WidthStretch, 1.1);
                imgui.TableSetupColumn('Casts', ImGuiTableColumnFlags_WidthStretch, 0.6);
                imgui.TableSetupColumn('Gil', ImGuiTableColumnFlags_WidthStretch, 0.7);
                imgui.TableHeadersRow();

                for _, entry in ipairs(route.alternates) do
                    local spot = catalog.spots[entry.plan[1]];

                    imgui.TableNextRow();

                    imgui.TableNextColumn();
                    imgui.Text(string.format('%s - %s', zoneName(spot), spot.areaName));

                    imgui.TableNextColumn();
                    imgui.Text(gearName(catalog.rodById, entry.plan[3]));
                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('Buy here: ' .. itemLine(entry.plan[3]));
                    end

                    imgui.TableNextColumn();
                    imgui.Text(gearName(catalog.baitById, entry.plan[2]));
                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('Buy here: ' .. itemLine(entry.plan[2]));
                    end

                    imgui.TableNextColumn();
                    if (entry.top ~= nil and catalog.fishById[entry.top] ~= nil) then
                        imgui.Text(catalog.fishById[entry.top].name);
                    end

                    imgui.TableNextColumn();
                    imgui.Text(commaNumber(entry.casts));

                    imgui.TableNextColumn();
                    imgui.Text(commaNumber(entry.kit + entry.gil));
                end

                imgui.EndTable();
            end

            textColored(COL_DIM, string.format(
                'After %d the route above is the same wherever you started.', catalog.altBand[2]));
        end
    end

    imgui.Separator();
    imgui.TextWrapped(
        'THIS ROUTE DOES NOT KNOW WHAT YOU CAN REACH. Nothing in the server\'s data records zone ' ..
        'access, so a stretch may name water that needs travel, an expansion or a quest you do not ' ..
        'have. It also plans only with bait you can BUY -- several of the best baits are crafted or ' ..
        'fished, and the Fish tab lists every bait that hooks a given fish, not just the bought ones. ' ..
        'Weather, fishing gear, pool depletion and how well you play the reel-in are not modelled.');
end

-----------------------------------------------------------------------------
-- Tab: Next -- the 0..110 ladder
-----------------------------------------------------------------------------
local function tabNext()
    if (state.level == nil) then
        imgui.TextWrapped('Waiting for the server to say where you stand...');

        return;
    end

    imgui.Text(string.format('Fishing skill %.1f', (state.rawSkill or 0) / 10));
    imgui.SameLine();
    textColored(COL_DIM, string.format('| rank %d, capped at %d', state.rank or 0, state.rankCap or 0));

    -- THE THING NOTHING ELSE IN THE GAME TELLS YOU. Rank hard-caps skill at
    -- (rank + 1) * 10; at the cap no catch of any kind moves the number, and
    -- the game reports neither the cap nor the reason.
    if ((state.level or 0) >= (state.rankCap or 0)) then
        textColored(COL_BAD, 'You are AT your rank cap. No catch will raise your skill.');
        imgui.SameLine();
        helpMarker('Fishing skill is hard-capped by your guild RANK at (rank + 1) x 10 ' ..
            '(fishingutils.cpp, FishingSkillup). Take the Fishermen\'s Guild rank test to lift it. ' ..
            'Nothing in the game states this cap, which is why you can fish for a week without moving.');
    end

    if (state.enabled == false) then
        textColored(COL_BAD, 'Fishing is DISABLED on this server right now.');
    end

    if (state.multiplier ~= nil) then
        local word = (state.multiplier == 1.0)
            and 'This server uses the stock skill-up rate (x1).'
            or string.format('This server multiplies fishing skill-ups by %g (stock is x1).', state.multiplier);

        textColored(state.multiplier > 1.0 and COL_GOOD or COL_DIM, word);
    end

    imgui.Separator();

    imgui.PushItemWidth(220);
    if (imgui.SliderInt('Plan for level', planLevel, 0, catalog and catalog.engine.maxLevel or 110)) then
        planPinned = true;
    end
    imgui.PopItemWidth();

    imgui.SameLine();

    if (imgui.Button('Follow my skill')) then
        planPinned   = false;
        planLevel[1] = state.level or 0;
    end

    helpMarker('The curve peaks at exactly +' .. tostring(catalog and catalog.engine.skillupPeak or 11) ..
        ' levels above you -- not at the hardest thing you can land. A catch AT or BELOW your ' ..
        'level teaches nothing at all, and neither do items or monsters, however big.\n\n' ..
        'Per catch is a REAL probability: the engine rolls the curve against ' ..
        string.format('%d', skillRoll(planLevel[1])) .. ' at this level, not against 100. ' ..
        'Rows are ordered by the engine\'s own preference, so when the whole column reads 100% ' ..
        'they are still listed best-first.');

    local level  = planLevel[1];
    local ladder = ladderFor(level);

    -- THE THING THE MULTIPLIER ACTUALLY DOES, SAID OUT LOUD. maxChance is rolled
    -- against skillRoll, and once the multiplier pushes it past that the
    -- skill-up stops being a chance at all -- so the +11 peak stops mattering
    -- and what is left is how fast you can land ANYTHING in the window. A player
    -- chasing the peak on this box is optimising a term that has saturated.
    if (#ladder > 0 and ladder[1].chance >= 100) then
        local saturated = 0;

        for _, entry in ipairs(ladder) do
            saturated = saturated + ((entry.chance >= 100) and 1 or 0);
        end

        textColored(COL_GOOD, string.format(
            '%d of these %d are a CERTAIN skill-up here -- this server\'s multiplier has saturated the curve.',
            saturated, #ladder));
        imgui.SameLine();
        helpMarker('When every target in the window is certain, the peak at +' ..
            tostring(catalog.engine.skillupPeak) .. ' buys you nothing. What is left is how ' ..
            'quickly you can land anything above your level at all -- which is what the Route ' ..
            'tab optimises, and why it does not simply send you at the biggest fish you can hook.');
    end

    if (#ladder == 0) then
        textColored(COL_DIM, 'Nothing in the catalog sits inside the skill-up window for this level.');

        return;
    end

    if (imgui.BeginTable('##dwfishing_ladder', 5,
        bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY,
                ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Fish', ImGuiTableColumnFlags_WidthStretch, 1.4);
        imgui.TableSetupColumn('Skill', ImGuiTableColumnFlags_WidthStretch, 0.6);
        imgui.TableSetupColumn('Per catch', ImGuiTableColumnFlags_WidthStretch, 0.8);
        imgui.TableSetupColumn('Bait that works', ImGuiTableColumnFlags_WidthStretch, 2.0);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 2.2);
        imgui.TableHeadersRow();

        for _, entry in ipairs(ladder) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.Text(entry.fish.name);

            if (entry.fish.legendary == 1) then
                imgui.SameLine();
                textColored(COL_WARN, '*');
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Legendary fish: rods treat it differently (bonus attack and time on a legendary rod).');
                end
            end

            imgui.TableNextColumn();
            imgui.Text(string.format('%d (+%d)', entry.fish.skill, entry.diff));

            imgui.TableNextColumn();
            local color = COL_DIM;

            if (entry.diff >= (catalog.engine.skillupPeak - 2) and entry.diff <= (catalog.engine.skillupPeak + 2)) then
                color = COL_GOOD;
            end

            textColored(color, string.format('%.0f%%', entry.chance));

            imgui.TableNextColumn();
            if (#entry.baits == 0) then
                textColored(COL_BAD, 'no bait hooks this');
            else
                imgui.Text(baitSummary(entry.baits, 3));
            end

            imgui.TableNextColumn();
            if (#entry.spots == 0) then
                textColored(COL_BAD, 'no pool holds it');
            else
                imgui.Text(spotSummary(entry.spots, 2));
            end
        end

        imgui.EndTable();
    end
end

-----------------------------------------------------------------------------
-- Tab: Fish
-----------------------------------------------------------------------------
local function tabFish()
    if (catalog == nil) then
        return;
    end

    imgui.PushItemWidth(260);
    imgui.InputText('Search fish', search, 64);
    imgui.PopItemWidth();
    helpMarker('Every fish this server can actually give you. Fish the engine refuses to load ' ..
        '(disabled, or ranking 99+) are not in this list, because they are not in the game.');

    imgui.SameLine();
    textColored(COL_DIM, string.format('%d fish', catalog.counts.fish));

    if (imgui.BeginTable('##dwfishing_fish', 6,
        bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY,
                ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Fish', ImGuiTableColumnFlags_WidthStretch, 1.3);
        imgui.TableSetupColumn('Skill', ImGuiTableColumnFlags_WidthStretch, 0.5);
        imgui.TableSetupColumn('Size / water', ImGuiTableColumnFlags_WidthStretch, 0.9);
        imgui.TableSetupColumn('Bait', ImGuiTableColumnFlags_WidthStretch, 1.8);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 1.8);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthStretch, 1.1);
        imgui.TableHeadersRow();

        for _, fish in ipairs(catalog.fish) do
            if (matches(fish.name, search[1])) then
                imgui.TableNextRow();

                imgui.TableNextColumn();
                imgui.Text(fish.name);

                if (fish.item == 1) then
                    imgui.SameLine();
                    textColored(COL_DIM, '[junk]');
                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('An item, not a fish. It teaches no skill at all, however often you hook it.');
                    end
                end

                imgui.TableNextColumn();
                imgui.Text(tostring(fish.skill));

                imgui.TableNextColumn();
                imgui.Text(string.format('%s, %s', SIZE_WORD[fish.size] or '?', WATER_WORD[fish.water] or '?'));

                imgui.TableNextColumn();
                imgui.Text(baitSummary(baitsFor(fish.id), 2, fish.item == 1));

                imgui.TableNextColumn();
                imgui.Text(spotSummary(spotsFor(fish.id), 2));

                imgui.TableNextColumn();
                imgui.Text(string.format('%s; %s', hourWord(fish), moonWord(fish)));
            end
        end

        imgui.EndTable();
    end
end

-----------------------------------------------------------------------------
-- Tab: Spots
-----------------------------------------------------------------------------
local function tabSpots()
    if (catalog == nil) then
        return;
    end

    imgui.PushItemWidth(260);
    imgui.InputText('Search spots', searchSpot, 64);
    imgui.PopItemWidth();

    imgui.SameLine();

    if (imgui.Button('Where I am')) then
        -- Filter to the current zone by writing its name into the search
        -- box, so the filter is visible and editable rather than a hidden
        -- mode. Clearing the box (the old behaviour) listed all ~200 areas,
        -- which is the opposite of what this label promises.
        if (state.zone ~= nil) then
            searchSpot[1] = zoneName({ zone = state.zone });
        else
            searchSpot[1] = '';
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Show only the fishing areas in the zone you are standing in.');
    end

    imgui.SameLine();
    textColored(COL_DIM, string.format('%d fishing areas', catalog.counts.spots));

    for _, spot in ipairs(catalog.spots) do
        local label = string.format('%s - %s', zoneName(spot), spot.areaName);
        local here  = (state.zone ~= nil and spot.zone == state.zone);

        if (matches(label, searchSpot[1]) or (here and #searchSpot[1] == 0)) then
            local holding = fishInSpot(spot);
            local lowest, highest = nil, nil;

            for _, entry in ipairs(holding) do
                if (entry.fish.item == 0) then
                    lowest  = (lowest == nil or entry.fish.skill < lowest) and entry.fish.skill or lowest;
                    highest = (highest == nil or entry.fish.skill > highest) and entry.fish.skill or highest;
                end
            end

            local header = string.format('%s%s  [skill %s-%s, %d catchable]###spot%d_%d',
                here and '> ' or '', label,
                tostring(lowest or '-'), tostring(highest or '-'), #holding, spot.zone, spot.area);

            if (imgui.CollapsingHeader(header)) then
                if (here) then
                    textColored(COL_GOOD, 'You are in this zone.');
                end

                if (imgui.BeginTable(string.format('##spotfish%d_%d', spot.zone, spot.area), 4,
                    bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
                    imgui.TableSetupColumn('Catch', ImGuiTableColumnFlags_WidthStretch, 1.3);
                    imgui.TableSetupColumn('Skill', ImGuiTableColumnFlags_WidthStretch, 0.5);
                    imgui.TableSetupColumn('Rarity', ImGuiTableColumnFlags_WidthStretch, 0.7);
                    imgui.TableSetupColumn('Bait', ImGuiTableColumnFlags_WidthStretch, 2.0);
                    imgui.TableHeadersRow();

                    for _, entry in ipairs(holding) do
                        imgui.TableNextRow();

                        imgui.TableNextColumn();
                        imgui.Text(entry.fish.name);

                        if (entry.fish.item == 1) then
                            imgui.SameLine();
                            textColored(COL_DIM, '[junk]');
                        end

                        imgui.TableNextColumn();
                        imgui.Text(tostring(entry.fish.skill));

                        imgui.TableNextColumn();
                        imgui.Text(rarityWord(entry.fish.rarity));

                        imgui.TableNextColumn();
                        imgui.Text(baitSummary(baitsFor(entry.fish.id), 2, entry.fish.item == 1));
                    end

                    imgui.EndTable();
                end
            end
        end
    end
end

-----------------------------------------------------------------------------
-- Tab: Gear
-----------------------------------------------------------------------------
-- The gear the ENGINE recognises, with what each piece actually does. Read off
-- GetFishingGear and CalculateLuckyTiming: anything not on this list does
-- nothing for fishing whatever its name or description suggests.
local GEAR_NOTES = {
    { id = 25608, slot = 'head',  note = 'Tlahtlamah Glasses -- recognised by the engine' },
    { id = 11499, slot = 'head',  note = 'Trainee\'s Spectacles -- recognised by the engine' },
    { id = 10925, slot = 'neck',  note = 'Fisher\'s Torque -- recognised by the engine' },
    { id = 13808, slot = 'body',  note = 'Fisherman\'s Tunica -- +0.5 lucky timing' },
    { id = 13809, slot = 'body',  note = 'Angler\'s Tunica -- +1 lucky timing' },
    { id = 14400, slot = 'body',  note = 'Fisherman\'s Apron -- +3 lucky timing, and moves 25% of the junk pool to "nothing"' },
    { id = 11337, slot = 'body',  note = 'Fisherman\'s Smock -- +3 lucky timing, and moves 25% of the junk pool to "nothing"' },
    { id = 14070, slot = 'hands', note = 'Fisherman\'s Gloves -- +0.5 lucky timing' },
    { id = 14071, slot = 'hands', note = 'Angler\'s Gloves -- +1 lucky timing' },
    { id = 11768, slot = 'waist', note = 'Fisher\'s Rope -- one second off the wait for a bite' },
    { id = 14292, slot = 'legs',  note = 'Fisherman\'s Hose -- +0.5 lucky timing' },
    { id = 14293, slot = 'legs',  note = 'Angler\'s Hose -- +1 lucky timing' },
    { id = 14171, slot = 'feet',  note = 'Fisherman\'s Boots -- +0.5 lucky timing' },
    { id = 14172, slot = 'feet',  note = 'Angler\'s Boots -- +1 lucky timing' },
    { id = 14195, slot = 'feet',  note = 'Waders -- +2 lucky timing' },
};

local function tabGear()
    if (catalog == nil) then
        return;
    end

    -- The rod and bait slots arrive on every g| sweep and are the answer to
    -- "why can I not fish" -- an id of 0 means the slot is empty (the
    -- protocol doc calls this out). Say it before the reference tables.
    if (state.gear['rod'] ~= nil or state.gear['bait'] ~= nil) then
        local rodId  = state.gear['rod'] or 0;
        local baitId = state.gear['bait'] or 0;

        imgui.Text('Equipped:');
        imgui.SameLine();

        if (rodId ~= 0) then
            imgui.Text(itemName(rodId) or string.format('rod %d', rodId));
        else
            textColored(COL_WARN, 'no rod');
        end

        imgui.SameLine();
        imgui.TextDisabled('/');
        imgui.SameLine();

        if (baitId ~= 0) then
            imgui.Text(itemName(baitId) or string.format('bait %d', baitId));
        else
            textColored(COL_WARN, 'no bait');
        end

        if ((rodId == 0 or baitId == 0)) then
            imgui.SameLine();
            imgui.TextDisabled('-- both are required before a cast does anything.');
        end

        imgui.Separator();
    end

    if (imgui.CollapsingHeader('Rods###dwfishing_rods')) then
        helpMarker('A rod whose size does not match the fish costs you hook chance ' ..
            '(3 points for a small fish on a big rod, 5 for a big fish on a small one), and a rod ' ..
            'whose max rank sits under the fish\'s ranking is the one that snaps.');

        if (imgui.BeginTable('##dwfishing_rodtable', 6,
            bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
            imgui.TableSetupColumn('Rod', ImGuiTableColumnFlags_WidthStretch, 1.4);
            imgui.TableSetupColumn('For', ImGuiTableColumnFlags_WidthStretch, 0.6);
            imgui.TableSetupColumn('Rank band', ImGuiTableColumnFlags_WidthStretch, 0.8);
            imgui.TableSetupColumn('Attack', ImGuiTableColumnFlags_WidthStretch, 0.6);
            imgui.TableSetupColumn('Time', ImGuiTableColumnFlags_WidthStretch, 0.6);
            imgui.TableSetupColumn('Notes', ImGuiTableColumnFlags_WidthStretch, 1.4);
            imgui.TableHeadersRow();

            for _, rod in ipairs(catalog.rods) do
                imgui.TableNextRow();

                imgui.TableNextColumn();
                imgui.Text(rod.name);

                imgui.TableNextColumn();
                imgui.Text(SIZE_WORD[rod.size] or '?');

                imgui.TableNextColumn();
                imgui.Text(string.format('%d - %d', rod.minRank, rod.maxRank));

                imgui.TableNextColumn();
                imgui.Text(tostring(rod.attack));

                imgui.TableNextColumn();
                imgui.Text(tostring(rod.time));

                imgui.TableNextColumn();
                local notes = {};

                if (rod.legendary == 1) then
                    table.insert(notes, 'legendary (no size penalty)');
                end

                if (rod.breakable == 0) then
                    table.insert(notes, 'unbreakable');
                end

                imgui.Text(#notes > 0 and table.concat(notes, ', ') or '');
            end

            imgui.EndTable();
        end
    end

    if (imgui.CollapsingHeader('Bait and lures###dwfishing_baits')) then
        helpMarker('Bait affinity is a HARD gate: a bait can only ever hook fish it has an ' ..
            'affinity row for. Power 3 is worth +80 hook chance for bait and +75 for a lure, ' ..
            'power 1 only +35 / +30 -- so the right bait matters more than anything else you carry.');

        if (imgui.BeginTable('##dwfishing_baittable', 5,
            bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
            imgui.TableSetupColumn('Bait', ImGuiTableColumnFlags_WidthStretch, 1.4);
            imgui.TableSetupColumn('Type', ImGuiTableColumnFlags_WidthStretch, 0.6);
            imgui.TableSetupColumn('Hooks', ImGuiTableColumnFlags_WidthStretch, 0.6);
            imgui.TableSetupColumn('Lost on use', ImGuiTableColumnFlags_WidthStretch, 0.7);
            imgui.TableSetupColumn('Fish it can hook', ImGuiTableColumnFlags_WidthStretch, 2.2);
            imgui.TableHeadersRow();

            for _, bait in ipairs(catalog.baits) do
                local flat  = catalog.baitFish[bait.id];
                local count = flat and (#flat / 2) or 0;

                imgui.TableNextRow();

                imgui.TableNextColumn();
                imgui.Text(bait.name);

                imgui.TableNextColumn();
                imgui.Text(BAIT_WORD[bait.type] or '?');

                imgui.TableNextColumn();
                imgui.Text(tostring(bait.maxhook));

                imgui.TableNextColumn();
                imgui.Text(bait.losable == 1 and 'yes' or 'no');

                imgui.TableNextColumn();
                if (count == 0) then
                    textColored(COL_DIM, 'nothing in the catalog');
                else
                    imgui.Text(string.format('%d kinds', count));
                end
            end

            imgui.EndTable();
        end
    end

    if (imgui.CollapsingHeader('Gear the engine actually reads###dwfishing_gear')) then
        imgui.TextWrapped('GetFishingGear checks seven slots against a fixed list of item ids. ' ..
            'Anything not below does nothing for fishing, whatever its description says.');
        imgui.Separator();

        for _, entry in ipairs(GEAR_NOTES) do
            local worn = (state.gear[entry.slot] == entry.id);

            if (worn) then
                textColored(COL_GOOD, '[worn] ' .. entry.note);
            else
                textColored(COL_DIM, entry.note);
            end
        end

        imgui.Separator();
        imgui.TextWrapped('Pelican Ring grants an extra skill-up roll per catch. ' ..
            'Lu Shang\'s Rod is PENALISED below skill 50 -- the engine adds 20 to the skill-up ' ..
            'roll, making it harder, so it is not the beginner rod its reputation suggests.');
    end
end

-----------------------------------------------------------------------------
-- Tab: Monsters
-----------------------------------------------------------------------------
local function tabMobs()
    if (catalog == nil) then
        return;
    end

    imgui.TextWrapped('Things that are not fish. These hook like a catch and then fight you; ' ..
        'they teach no fishing skill at all. Many require a specific bait and will not appear on anything else.');
    imgui.Separator();

    -- This tab's own search box: it used to filter on the Fish tab's, so a
    -- leftover fish name over there emptied this table with nothing on
    -- screen to say why.
    imgui.PushItemWidth(260);
    imgui.InputText('Search monsters', searchMob, 64);
    imgui.PopItemWidth();

    if (imgui.BeginTable('##dwfishing_mobs', 5,
        bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY,
                ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Monster', ImGuiTableColumnFlags_WidthStretch, 1.3);
        imgui.TableSetupColumn('Zone', ImGuiTableColumnFlags_WidthStretch, 1.4);
        imgui.TableSetupColumn('Level', ImGuiTableColumnFlags_WidthStretch, 0.5);
        imgui.TableSetupColumn('NM', ImGuiTableColumnFlags_WidthStretch, 0.4);
        imgui.TableSetupColumn('Bait it needs', ImGuiTableColumnFlags_WidthStretch, 1.6);
        imgui.TableHeadersRow();

        for _, mob in ipairs(catalog.mobs) do
            if (matches(mob.name, searchMob[1]) or matches(mob.zoneName, searchMob[1])) then
                imgui.TableNextRow();

                imgui.TableNextColumn();
                imgui.Text((mob.name or ''):gsub('_', ' '));

                imgui.TableNextColumn();
                imgui.Text((mob.zoneName or ''):gsub('_', ' '));

                imgui.TableNextColumn();
                imgui.Text(tostring(mob.level));

                imgui.TableNextColumn();
                imgui.Text(mob.nm == 1 and 'yes' or '');

                imgui.TableNextColumn();
                if (mob.reqBait == 0) then
                    textColored(COL_DIM, 'any');
                else
                    local names = { itemName(mob.reqBait) };

                    if (mob.altBait > 0) then
                        table.insert(names, itemName(mob.altBait));
                    end

                    imgui.Text(table.concat(names, ' or '));
                end
            end
        end

        imgui.EndTable();
    end
end

-----------------------------------------------------------------------------
-- Tab: Basics
--
-- The rules of the system, stated once, from the engine rather than from
-- folklore. This is the tab a new fisherman reads first.
-----------------------------------------------------------------------------
local function tabBasics()
    if (catalog == nil) then
        return;
    end

    local engine = catalog.engine;

    imgui.TextWrapped('Everything below is read out of this server\'s own fishing code, not a wiki.');
    imgui.Separator();

    if (imgui.CollapsingHeader('How skill-ups actually work###dwfishing_basics_skill')) then
        imgui.BulletText(string.format(
            'A catch AT or BELOW your level teaches nothing. Nothing at all.'));
        imgui.BulletText(string.format(
            'A catch more than %d levels above you also teaches nothing.', engine.skillupWindow));
        imgui.BulletText(string.format(
            'The curve PEAKS at exactly +%d levels above you -- not at the hardest fish you can land.',
            engine.skillupPeak));
        imgui.BulletText('Items and monsters teach nothing, however large.');
        imgui.BulletText(string.format(
            'Your rank hard-caps your skill at (rank + 1) x %d. At the cap, nothing moves it but the guild test.',
            math.floor(engine.rankStep / 10)));
        imgui.BulletText(string.format(
            'The curve is rolled against %d at your level, not against 100 -- it starts at %d, ' ..
            'drops %d anywhere that is not a city, and drops more again below level %d.',
            skillRoll(state.level or 0), catalog.terms.rollBase, catalog.terms.rollOutdoor,
            catalog.terms.rollNoviceUnder));
        imgui.BulletText('HOOKING IS NOT CATCHING. A lost catch, a snapped line and a broken rod all ' ..
            'teach nothing, and reaching more than 7 levels above you is where losing starts.');

        if (state.multiplier ~= nil and state.multiplier ~= 1.0) then
            imgui.BulletText(string.format(
                'This server multiplies the whole curve by %g -- which on most of the window pushes it ' ..
                'past the roll entirely, so the skill-up becomes certain and the +%d peak stops mattering.',
                state.multiplier, engine.skillupPeak));
        end
    end

    if (imgui.CollapsingHeader('How a bite is decided###dwfishing_basics_hook')) then
        imgui.BulletText('Bait affinity is a hard gate: no affinity row, no bite, ever.');
        imgui.BulletText(string.format(
            'Bait power is the biggest term: power 3 is worth +%d (bait) or +%d (lure); power 1 only +%d / +%d.',
            catalog.baitPower[3][2], catalog.baitPower[3][1],
            catalog.baitPower[1][2], catalog.baitPower[1][1]));
        imgui.BulletText(string.format(
            'Being under-skilled costs %.2f hook points per level -- a penalty, never a wall. A fish up to %d levels above you still bites.',
            engine.hookUnderSlope, engine.poolSkillWindow));
        imgui.BulletText(string.format(
            'Being over-skilled costs too: %.2f points per level once you are more than %d above it.',
            engine.hookOverSlope, engine.hookOverGrace));
        imgui.BulletText(string.format(
            'The wrong size rod costs %d points (small fish, big rod) or %d (big fish, small rod). Legendary rods pay neither.',
            engine.rodTooBig, engine.rodTooSmall));
        imgui.BulletText(string.format(
            'The result is clamped to %d-%d, so nothing is ever hopeless and nothing is ever certain.',
            engine.hookClampLow, engine.hookClampHigh));
    end

    if (imgui.CollapsingHeader('Time, moon and tide###dwfishing_basics_time')) then
        imgui.BulletText('Every fish carries an hour, moon and month preference, and they are multiplied together.');
        imgui.BulletText('The moon contributes three times as much as the month, and the hour twice as much.');
        imgui.BulletText('The wait for a bite is 13 seconds, minus 4 on a New or Full moon, minus 1 at 05:00 or 17:00, minus 1 with Fisher\'s Rope. It never drops below 7.');
        imgui.BulletText('The Fish tab states each fish\'s best hour and moon.');
    end

    if (imgui.CollapsingHeader('What this window will not do###dwfishing_basics_limits')) then
        imgui.TextWrapped(
            'It does not tell you which fishing AREA of a zone you are standing in -- the server ' ..
            'resolves that from your exact position and there is no binding to ask it, so the Spots ' ..
            'tab lists every area in the zone and marks the zone you are in. It does not model the ' ..
            'reel-in minigame, which is decided live from your rod, the fish and your skill. And it ' ..
            'states rarity as the weight the engine multiplies by, never as a "drop rate", because ' ..
            'the pool is a weighted draw and not a roll per fish.');
    end
end

-----------------------------------------------------------------------------
-- Window
-----------------------------------------------------------------------------
local TABS = {
    { label = 'Route',    draw = tabRoute  },
    { label = 'Next',     draw = tabNext   },
    { label = 'Fish',     draw = tabFish   },
    { label = 'Spots',    draw = tabSpots  },
    { label = 'Gear',     draw = tabGear   },
    { label = 'Monsters', draw = tabMobs   },
    { label = 'Basics',   draw = tabBasics },
};

local function renderWindow()
    if (catalog == nil) then
        textColored(COL_BAD, catalogError or 'The fishing catalog failed to load.');
        imgui.TextWrapped('Re-run the launcher to repair this addon\'s data file.');

        return;
    end

    if (state.refused) then
        textColored(COL_BAD, state.status);

        return;
    end

    if (state.statusBad and #tostring(state.status) > 0) then
        textColored(COL_BAD, state.status);
    elseif (not state.spoke) then
        textColored(COL_DIM, 'Asking the server where you stand...');
    end

    if (imgui.BeginTabBar('##dwfishing_tabs')) then
        for index, tab in ipairs(TABS) do
            if (imgui.BeginTabItem(string.format('%s##dwfishing_tab_%d', tab.label, index))) then
                tab.draw();
                imgui.EndTabItem();
            end
        end

        imgui.EndTabBar();
    end
end

local function openWindow()
    state.open[1] = true;

    -- Reopening is a fresh start for error reporting too: `reported` only
    -- exists to stop one bad frame printing sixty lines a second.
    state.reported = false;

    -- And a fresh try for the handshake: the answer timeout clears
    -- state.asked but a latched `helloed` would make this call a no-op, so
    -- one lost line (the client's own rate limiter is enough) would leave
    -- the window dead until the next zone. dwtracker and dwfame clear their
    -- equivalent latch on open for the same reason.
    if (not state.spoke) then
        state.helloed = false;
    end

    hello();
end

ashita.events.register('d3d_present', 'dwfishing_present', function ()
    pumpQueue();

    -- One retry, then stop and say so. A retry that never terminates is a
    -- command loop, and this one is a chat line per attempt.
    if (state.asked ~= nil) then
        -- While a send is held (zone-in) the hello cannot go out, so measure the
        -- give-up from when a line can actually be sent rather than from the
        -- queued ask -- there is no retry here to re-stamp it. (dwecho canSend;
        -- 2026-08-15.)
        if (not echo.canSend()) then
            state.askedAt = os.clock();
        elseif (os.clock() - state.askedAt > ANSWER_TIMEOUT) then
            state.asked     = nil;
            state.status    = 'The server did not answer. Is the fishing module loaded?';
            state.statusBad = true;
        end
    end

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 900, 560 }, ImGuiCond_FirstUseEver);

    -- The suite's flag set, which this window shipped without. NoSavedSettings
    -- was the odd one out and it contradicted the line above: FirstUseEver
    -- means "unless ImGui has a saved size", so telling ImGui never to save
    -- made the size and POSITION reset to the default on every single reload,
    -- and the player re-placed the window every session. NoDocking was missed
    -- by the 2026-08-02 sweep that added it to every other window because this
    -- addon did not exist yet.
    local visible = imgui.Begin('DriftwoodXI Fishing##dwfishing', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        -- pcall'd like every sibling window (dwcraft's block states the
        -- reason): an error raised inside d3d_present fires sixty times a
        -- second and the host answers by unloading the addon -- and a throw
        -- past Begin would skip imgui.End() and theme.pop(), unbalancing
        -- both stacks by one per frame.
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwfishing'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwfishing'):append(chat.message('Window closed. Everything it shows also works as !fish commands.')));
            end
        end
    end

    imgui.End();

    theme.pop(pushed);
end);

ashita.events.register('command', 'dwfishing_command', function (e)
    local args = e.command:args();

    if (#args == 0) then
        return;
    end

    local first = args[1]:lower();

    if (first ~= '/dwfishing' and first ~= '/dwfish' and first ~= '/fishing') then
        return;
    end

    e.blocked = true;

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

--[[
* A bare `!fish` typed by hand opens the window instead, the way `!scan` and
* `!port` do -- and any other outgoing chat line stamps the throttle, because
* the client's rate limit is on chat and not on this addon.
--]]
ashita.events.register('packet_out', 'dwfishing_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!fish' or lower == '!fish ui' or lower == '!fish window' or lower == '!fish gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwh') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwfishing_load', function ()
    print(chat.header('dwfishing'):append(chat.message(
        '/dwfishing opens the fishing guide -- the Route tab is the whole 0-110 plan, and the rest is every fish, bait, rod and spot. !fish route does it typed.')));
end);
