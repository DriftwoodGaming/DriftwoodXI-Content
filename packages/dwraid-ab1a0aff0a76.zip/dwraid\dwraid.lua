--[[
* DriftwoodXI -- dwraid
*
* The raid board as a window -- your driftmark purse, the trials across
* every venue the server serves, the tiers and what they pay, how many
* arenas are running, and the buttons that take you there. No orb, no
* travel: pick a fight, press Enter, and the server gates your whole party
* where you stand and moves everyone. Leave puts you back on the exact tile
* you left.
*
* THIS PARAGRAPH USED TO SAY TWO THINGS THAT STOPPED BEING TRUE, and both
* were corrected on 2026-09-06 rather than left as folklore. It said "the
* Horlais Peak trials", which was right for one venue out of the nine the
* server now runs (three arenas each), and it said entry worked from
* "cities and safe zones only, the server's rule" -- a rule the owner
* REVERSED on 2026-08-23. Entry is allowed from any map that saveReturn can
* describe well enough to put the party back; raid_core.lua's own comment
* names the three families that still refuse (live instances, Dynamis, the
* vessel zones) and says why each one fails differently. Nothing about
* venue counts or entry rules is decided here in any case -- the roster and
* the refusals both ride the wire -- which is exactly why a wrong sentence
* here could sit for weeks without failing anything.
*
* AND A TRIAL IS NOT PINNED TO ITS VENUE (1.15.0, the server's overflow
* round): a shrine whose three arenas are taken now sends its own trials to
* the next shrine with room, so the occupancy block names WHERE each run is,
* which shrines are full, and how much room the open trial has anywhere. The
* one refusal left is a board with no free arena at all -- and that sentence,
* like every other, is the server's.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no opinion about your purse, the tiers, or which arenas are
* busy. The server answers `!dwx status` in compact records under the
* sender name _DWXDATA, which this addon parses and blocks before the chat
* log sees them; the payouts and the arena state ride the wire. Every
* button is a `!dwx` verb a player could type -- the server re-checks
* everything, so this window can do nothing a typed command cannot
* (the dwq.lua rule, inherited whole).
*
* TURN IT OFF AND NOTHING IS LOST. `!raid` typed in chat is the same
* answers in prose, and `!raid enter` is the same warp.
*
* WHAT THE WINDOW ADDS ON TOP OF THE WIRE (1.4.0): the fight roster hangs
* under element tabs (the f| tail names each fight's element; only elements
* that hold a fight get a tab, so the row grows with the roster), and every
* shop row draws its item's icon and a hover card -- name, iLvl, jobs,
* slots and the item's own description -- read from the client's OWN
* resources by the item id the s| tail carries. Nothing item-shaped rides
* the wire beyond that one number, and nobody has to alt-tab to a wiki to
* learn what a shelf row is.
*
* AND WHAT 1.11.0 ADDS: a find box over the shelf (with a Clear, a count and
* a clipboard copy of what it kept), a price the purse cannot reach drawn in
* the error ink -- a courtesy, never a gate, because the server owns every
* refusal -- a `!raid marks` reply read rather than discarded, and a hover
* sentence on every control whose meaning was not written on its face.
* Everything the window draws more than once is now worked out when the
* answer commits rather than sixty times a second: the shelf, the element
* strip, the occupancy block, the purse, the ledger and both Confirm labels.
*
* AND WHAT 1.12.0 ADDS: an order for the shelf -- Shelf, Name or Price, kept
* per PC beside the text size, because "what can my purse reach" has no
* answer in a list ordered by an index this window does not draw -- a
* sentence on every column header (four tables, eight labels that say nothing
* on their face, all of them previously drawn through the one-call header row
* that leaves nothing for a hover to be about), and a hover on each trial
* saying how many of its first-of-the-day bonuses are still unclaimed, which
* used to cost a click on every element tab and every fight button to work
* out.
*
* AND ONE BEHAVIOUR CHANGED RATHER THAN GREW: the trial and the shelf you
* had chosen now SURVIVE a zone line. Everything server-derived still resets
* there -- a login may be a different character -- but a selection is not
* server-derived, and entering the arena, leaving it and the return warp are
* all zone lines, so a wipe on the Manticore used to come back pointing at
* the Colossus. Both commits already validate the selection against the
* answer that just landed, which is what makes keeping it safe.
--]]

addon.name    = 'dwraid';
addon.author  = 'DriftwoodXI';
addon.version = '1.15.0';
addon.desc    = 'Raid board for DriftwoodXI: the trials, the tiers, your driftmarks.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local d3d   = require('d3d8');
local ffi   = require('ffi');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

local settings = require('settings');

local C = ffi.C;

--[[
* Persisted presentation state, through Ashita's settings library (the dwcon
* shape). Flat scalars only -- the settings serializer takes booleans, numbers
* and strings, and a nested table here would be a silent loss on save (1.7.0,
* the text-size round).
--]]
local defaultConfig = T{
    textScale = 1.0,        -- 1.0 = the client's own font size
    shopSort  = 'shelf',    -- 'shelf' (the server's own order), 'name' or 'price'
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

-- Forward declaration: the settings callback below has to put the reloaded
-- scale back into the slider's own widget table, and that table is declared a
-- few lines further down where the rest of the UI state lives.
local uiTextScale;

pcall(settings.register, 'settings', 'dwraid_settings_update', function (s)
    if (s ~= nil) then
        config = s;

        -- AND THE WIDGET HAS TO FOLLOW IT (2026-09-06). ImGui sliders own
        -- their value: the table below is what the player drags, and it was
        -- filled once at load and never again. A settings file reloaded under
        -- the addon -- which is exactly what this callback is for -- left the
        -- slider showing the OLD percent, and the next nudge wrote that stale
        -- number straight back over the file that had just changed.
        if (uiTextScale ~= nil) then
            local sc = tonumber(config.textScale) or 1.0;

            if (sc < 0.8) then sc = 0.8; end
            if (sc > 1.6) then sc = 1.6; end

            uiTextScale[1] = sc * 100;
        end
    end
end);

-- The scale, read through one clamp so a hand-edited config file cannot
-- push the window into an unreadable or unclickable size.
local function scaleOf()
    local sc = tonumber(config.textScale) or 1.0;

    if (sc < 0.8) then sc = 0.8; end
    if (sc > 1.6) then sc = 1.6; end

    return sc;
end

-- A pixel measure at the current scale, for the handful of literals ImGui's
-- own font scaling does not touch (column widths, icon sizes, wrap points).
local function px(n)
    return math.floor(n * scaleOf() + 0.5);
end

--[[
* The shelf's sort order (1.12.0), read through one whitelist for the same
* reason the scale is read through one clamp: this string reaches a table
* lookup and a comparator, and a hand-edited config file (or one written by a
* newer version of this addon and then opened by an older one) must not be
* able to hand either of them a word they have no branch for. Anything
* unrecognised reads as the server's own order, which is what every shipped
* version before this one drew.
--]]
local SORT_ORDERS = { shelf = true, name = true, price = true };

local function sortMode()
    local mode = config.shopSort;

    if (type(mode) ~= 'string' or not SORT_ORDERS[mode]) then
        return 'shelf';
    end

    return mode;
end

-- ImGui widget holder for the slider (a table it can write into); slider
-- speaks percent, config stores the scale itself. Declared above so the
-- settings-reload callback can put a reloaded value back into it.
uiTextScale = T{ scaleOf() * 100 };

--[[
* The D3D device, fetched on first use rather than at load: this addon is
* loaded from the launcher's boot script, long before the client has a
* rendering device, and a file-scope d3d.get_device() would make the whole
* addon fail to load (dwbags' lesson, kept verbatim). Nothing here needs a
* device until the first shop icon is drawn.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server
-- uses it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWXDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout -- never for an additive record.
local PROTOCOL = 1;

-- The forge's page word. It is NOT a p| page index -- the tab is offered by
-- the elite shelf's own gate -- so state.pageSel holds this string where it
-- otherwise holds a number. Declared here rather than beside the render
-- because the z| commit has to test for it too, and until 1.11.0 that site
-- carried its own copy of the word.
local REFORGE_PAGE = 'reforge';

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged,
    -- so a stale row cannot survive a refresh (dwtracker's rule).
    purse     = nil,          -- { balance, earned, spent }
    purseText = nil,          -- the two purse lines, formatted once when g| lands
    arena     = nil,          -- { full, tier, minutes, fight, busy, capacity -- the tail pair nil on an older server }
    runs      = T{ },         -- { fight, tier, minutes }, one per live run -- empty on a pre-multi-arena server
    venues    = T{ },         -- [index] = { label, busy, capacity } from v| -- empty on a pre-overflow server,
                              -- which is what makes the run lines fall back to the venue-less shape
    board     = nil,          -- the occupancy block as drawn: { color, line, runs = { text } }
    fights    = T{ },         -- [index] = { word, label, element } -- empty on a pre-fight-roster server; element nil on a pre-element server
    fightSel  = 1,            -- which fight the Enter buttons ask for
    elemSel   = nil,          -- which element tab is open; nil renders the roster flat (a pre-element server)
    taken     = T{ },         -- [fight index] = tier bitmask: the dailies this ACCOUNT
                              -- already collected today. Empty on a server that sends no
                              -- k|, which reads as "nothing known to be taken" and renders
                              -- every bonus claimable -- the shipped behaviour, unchanged.
    tiers     = T{ },         -- [index] = { label, base, daily }
    -- THE VARIETY ROUND (1.14.0), all replaced wholesale on commit like the rest:
    day       = nil,          -- { word, pct, pctText, day } from w| -- nil on an older server or when the engine has no clock
    ladder    = T{ },         -- [rung] = percent of base, from n| -- empty on an older server
    repeats   = T{ },         -- [fight][tier] = { count, pay } from j| -- how often this ACCOUNT was paid today and what the next base is
    chain     = nil,          -- { links, pct, pctText, seconds, mask, window } from c| -- nil on an older server
    today     = nil,          -- the day line and the chain line as drawn, formatted once at commit
    nextPay   = T{ },         -- [fight][tier] = { text, tip }: the "A clear" cell when it is not the base
    ledger    = T{ },         -- { delta, age, reason }, newest first
    shop      = T{ },         -- [shelf index] = { label, price, page, itemid } -- indices are sparse; itemid nil on an older server
    pages     = T{ },         -- [index] = { word, label } -- empty on a pre-pages server
    pageSel   = 1,            -- which shop page the shelf table shows; REFORGE_PAGE for the forge (1.8.0)
    quote     = nil,          -- { index, price, until } -- the live quote, if any

    -- The Relic Reforge section (1.8.0, ILVL109_PLAN's owed addon work).
    -- `reforge` is what the bag can convert -- e| records, nil until the tab
    -- first asks; `reforgeQuote` is the forge's own live quote (y|). The
    -- server holds ONE quote slot for the shelf and the forge together, so
    -- each of q| and y| clears the other side's quote here.
    reforge      = nil,       -- [n] = { relic, give, price }
    reforgeAt    = nil,       -- when the forge was last asked, for the retry offer
    reforgeQuote = nil,       -- { relic, give, price, deadline }

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its
    -- own cannot half-fill the UI.
    inbound   = nil,
    building  = nil,          -- the next tiers/ledger, committed on z|
    status    = 'Waiting for the first sync.',
    statusBad = false,
    protoBad  = false,        -- the last d| announced a version this addon cannot read
    syncedAt  = nil,          -- when the board last committed, for the Refresh hover
    reported  = false,        -- a render error is worth saying once, not per frame

    -- The shelf find box (1.11.0). A table because that is what ImGui writes
    -- into; the filtered view below is rebuilt only when this, the page or
    -- the model moves.
    find      = T{ '' },

    -- A zone-in sync is deferred: 0x000A arrives while the client is still
    -- on the load screen, and a chat line sent there is a chat line lost.
    syncAt    = nil,
    syncSlot  = nil,
};

--[[
* MODEL REVISIONS (1.11.0). Three faces of this window used to be rebuilt
* from scratch sixty times a second for a model the wire changes a handful of
* times a session: the element tab strip (two walks of the roster and two
* fresh tables a frame), the shelf (a walk of the whole 219-slot index space
* with a string.format for the price and another for the button id on every
* visible row) and the forge's item names (a resource-manager lookup per row
* per frame, twice over -- dwah's name cache exists for exactly that).
*
* Each cache is keyed on the revision of the model it reads, bumped where
* that model is REPLACED -- never merged, so a bump cannot be missed by a
* partial write. The view is what changes shape; the wire is not.
--]]
local rosterRev = 0;
local shopRev   = 0;

--[[
* Item icons, from the client's own resources -- dwbags' iconOf/drawIcon,
* kept verbatim, reasoning and all: cached because the shop is dozens of
* rows redrawn every frame and D3DXCreateTextureFromFileInMemoryEx is not
* free; gc_safe_release hands back a texture that releases itself when Lua
* collects it, which is what keeps this from leaking across a reload.
--]]
local icons = T{ };

--[[
* AND THE NUMBER IMGUI ACTUALLY WANTS, MEMOISED BESIDE IT (1.12.0).
* imgui.Image takes a texture handle as a plain number, and the way to get
* one from the cached texture is `tonumber(ffi.cast('uint32_t', texture))` --
* which drawIcon was doing once per visible row on EVERY FRAME. A cast
* allocates a cdata object, so a full armour shelf spent forty of them a
* frame -- twenty-four hundred a second of garbage -- re-deriving an address
* that cannot move while the texture is alive. Filled where the texture is
* created and dropped with it, so the two tables can never disagree.
--]]
local iconHandles = { };

local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    -- The one cast this texture will ever need. Guarded rather than trusted:
    -- a handle that came back as anything but a number would reach
    -- imgui.Image as a nil and take the render pcall down sixty times a
    -- second, and drawing the Dummy square instead costs nothing but an icon.
    local handle = tonumber(ffi.cast('uint32_t', icons[itemId]));

    if (type(handle) == 'number') then
        iconHandles[itemId] = handle;
    else
        icons[itemId]       = false;
        iconHandles[itemId] = nil;

        return nil;
    end

    return icons[itemId];
end

-- ImGui wants a size as a table and drawIcon runs once per visible row every
-- frame, so the square was allocated forty times a frame on a full shelf for
-- two numbers that move only when the text-size slider does. Memoised by the
-- pixel size itself; the binding reads the table and does not keep it.
local iconSizes = { };

local function sizeVec(size)
    local vec = iconSizes[size];

    if (vec == nil) then
        vec = { size, size };
        iconSizes[size] = vec;
    end

    return vec;
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);
    local handle  = texture ~= nil and texture ~= false and iconHandles[itemId] or nil;

    if (handle ~= nil) then
        imgui.Image(handle, sizeVec(size));
    else
        imgui.Dummy(sizeVec(size));
    end

    imgui.SameLine();
end

--[[
* The hover card's vocabulary: client DAT bitmasks decoded to the words a
* player reads. The job order is the server's own (dwbags' table); the
* flag bits are the same ones sql/item_basic.sql spells @FLAG_RARE and
* @FLAG_EX. All of it is presentation -- the server re-checks everything
* that matters (the Rare pre-pay refusal lives in raid_core.lua).
--]]
local FLAG_EX   = 0x4000;
local FLAG_RARE = 0x8000;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

local SLOT_LABELS = {
    [0]  = 'Main',  [1]  = 'Sub',   [2]  = 'Ranged', [3]  = 'Ammo',
    [4]  = 'Head',  [5]  = 'Body',  [6]  = 'Hands',  [7]  = 'Legs',
    [8]  = 'Feet',  [9]  = 'Neck',  [10] = 'Waist',  [11] = 'Ear',
    [12] = 'Ear',   [13] = 'Ring',  [14] = 'Ring',   [15] = 'Back',
};

local function jobsText(mask)
    local names = T{ };

    for jobId = 1, #JOB_NAMES do
        if (bit.band(mask, bit.lshift(1, jobId)) ~= 0) then
            names:append(JOB_NAMES[jobId]);
        end
    end

    if (#names == 0) then
        return nil;
    end

    if (#names >= #JOB_NAMES) then
        return 'All jobs';
    end

    return table.concat(names, ' ');
end

local function slotsText(mask)
    local names = T{ };
    local seen  = { };

    for slot = 0, 15 do
        if (bit.band(mask, bit.lshift(1, slot)) ~= 0) then
            local label = SLOT_LABELS[slot];

            if (not seen[label]) then
                seen[label] = true;
                names:append(label);
            end
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, '/');
end

--[[
* The hover card itself: everything a purchase decision needs -- name,
* iLvl, level, Rare/Ex, slots, jobs and the item's own description text --
* read from the client's resources by the id the s| tail carries. The
* point is that nobody should have to alt-tab to a wiki to learn what a
* shelf row is. An older server sends no id; the card then shows only what
* the wire said (label and price), which is exactly what that server means.
--]]
--[[
* The eight elemental-resist icons in the client's item descriptions are
* FFXI-private Shift-JIS pairs -- 0xEF then 0x1F..0x26, in wheel order
* fire ice wind earth lightning water light dark (read straight out of
* ROM/118/107.DAT: item 6272 carries fire as EF 1F, item 4488 dark as
* EF 26, and the JP DAT spells the same slots 耐火/耐風/耐土). ImGui wants
* UTF-8, so the raw pair renders as the '?' players reported. Each icon
* (and the '+' that usually follows it) folds to a three-letter tag:
* '<fire>+20' reads FiR:20, '<dark>-10' reads DkR:-10. Mirrored BY HAND
* from dwbags 1.17.0 -- edit one, revisit the others.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function(b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

-- The client's own name for an item id (the dwbags shape). The shelf never
-- needs this -- its labels ride the s| records -- but the forge's b| records
-- carry only ids, and the ids are the point: names resolve from the DATs the
-- player is actually running.
--
-- CACHED SINCE 1.11.0, and the reason is the same one dwah wrote its name
-- cache for: the forge drew two names per row and each one was a fresh
-- GetResourceManager():GetItemById(), so a bag holding a dozen convertible
-- pieces asked the resource manager twenty-four times a frame -- fourteen
-- hundred times a second -- for a table the client does not change while the
-- game is running. Cleared on the zone line rather than pinned for the
-- session, so an id the manager could not answer for at login resolves the
-- next time the player zones.
local nameCache = { };

local function itemName(itemId)
    local key = itemId or 0;

    if (nameCache[key] ~= nil) then
        return nameCache[key];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(key);
    local name = nil;

    if (item ~= nil and item.Name ~= nil and item.Name[1] ~= nil and #item.Name[1] > 0) then
        name = item.Name[1];
    else
        name = string.format('item %d', key);
    end

    nameCache[key] = name;

    return name;
end

local function itemTooltip(row)
    imgui.BeginTooltip();

    -- A tooltip is its own window, so the slider's per-window font scale does
    -- not reach it -- re-applied here so the card reads at the size the rest
    -- of the window does (guarded per the dwtheme skew rule; 1.7.0).
    if (type(imgui.SetWindowFontScale) == 'function' and scaleOf() ~= 1.0) then
        imgui.SetWindowFontScale(scaleOf());
    end

    local item = nil;

    if (row.itemid ~= nil and row.itemid ~= 0) then
        item = AshitaCore:GetResourceManager():GetItemById(row.itemid);

        drawIcon(row.itemid, px(32));
    end

    imgui.Text(row.label);

    if (item ~= nil) then
        local tags = T{ };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags:append(string.format('iLvl %d', item.ItemLevel));
        end

        if (item.Level ~= nil and item.Level > 0) then
            tags:append(string.format('Lv.%d', item.Level));
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_RARE) ~= 0) then
            tags:append('Rare');
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_EX) ~= 0) then
            tags:append('Ex');
        end

        if (#tags > 0) then
            imgui.TextColored(theme.colors.info, table.concat(tags, '  '));
        end

        local slots = item.Slots ~= nil and slotsText(item.Slots) or nil;
        local jobs  = item.Jobs ~= nil and jobsText(item.Jobs) or nil;

        if (slots ~= nil and jobs ~= nil) then
            imgui.TextDisabled(slots .. '  --  ' .. jobs);
        elseif (slots ~= nil or jobs ~= nil) then
            imgui.TextDisabled(slots or jobs);
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            -- A fixed wrap width, not one derived from imgui state: the
            -- card must render the same whatever window it floats over.
            -- px() rather than a literal since 1.7.0, so the card's shape
            -- survives the text-size slider -- still constant per frame.
            imgui.PushTextWrapPos(px(320));
            imgui.Text(cleanDescription(desc));
            imgui.PopTextWrapPos();
        end
    end

    imgui.Separator();

    -- The shelf's number IS the item's price; the forge's is a fee paid on
    -- top of a piece the player already owns, and the card used to say
    -- "2250 driftmarks" under a relic that is not for sale (1.11.0).
    --
    -- Every card built in this file carries its own sentence since 1.12.0 --
    -- the shelf's at the s| record, the forge's at dressReforge -- so this
    -- reads one field rather than formatting a wire number inside a render
    -- pass. The empty fallback is the belt: a card added later without a
    -- sentence should draw a blank line, not raise inside the pcall and take
    -- the whole window down with it.
    imgui.TextColored(theme.colors.hint, row.priceLine or '');

    imgui.EndTooltip();
end

--[[
* The elemental wheel, in its canonical order, each with the tint its tab
* wears while selected. ONLY ELEMENTS THAT HOLD A FIGHT GET A TAB -- today
* that is Water and Earth, and a new element's tab appears by itself the
* day its first boss ships, because the roster (and each fight's element)
* rides the wire. An element word this addon does not know still gets a
* tab, at the end, under its own name -- a newer server must never file a
* fight where no tab can show it.
--]]
local ELEMENTS = {
    { word = 'fire',      label = 'Fire',      color = { 0.96, 0.48, 0.38, 1.0 } },
    { word = 'ice',       label = 'Ice',       color = { 0.62, 0.86, 0.96, 1.0 } },
    { word = 'wind',      label = 'Wind',      color = { 0.55, 0.90, 0.60, 1.0 } },
    { word = 'earth',     label = 'Earth',     color = { 0.87, 0.72, 0.45, 1.0 } },
    { word = 'lightning', label = 'Lightning', color = { 0.80, 0.62, 0.95, 1.0 } },
    { word = 'water',     label = 'Water',     color = { 0.50, 0.70, 0.95, 1.0 } },
    { word = 'light',     label = 'Light',     color = { 0.95, 0.93, 0.80, 1.0 } },
    { word = 'dark',      label = 'Dark',      color = { 0.68, 0.62, 0.78, 1.0 } },
};

-- The same eight by word, for the day line (1.14.0): the w| record names
-- today's element by the vocabulary f| already uses.
local ELEMENT_BY_WORD = { };

for _, entry in ipairs(ELEMENTS) do
    ELEMENT_BY_WORD[entry.word] = entry;
end

--[[
* THE TOOLTIPS, in one table rather than one literal per call site (1.11.0,
* the dwnemesis shape), so the harness can assert them and so two controls
* that mean the same thing cannot drift into two sentences. The suite's rule:
* say what the control DOES, and for a greyed one say why it cannot right
* now; never repeat the label, never tooltip the self-evident. Tips carrying
* a number are formatted at the call site from the pieces below.
*
* The two story-lock sentences are the OWNER'S OWN WORDS from the CoP round
* and are not to be reworded here.
--]]
local TIPS = {
    scale        = 'Scales this window only, and remembers what you pick.',
    refresh      = 'Ask the server for the board again. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks, and Refresh cannot fix that -- update dwraid through the launcher.',
    leave        = 'Out of the arena and back to the tile you entered from. The server says so politely if you are not in one.',
    queued       = 'Lines waiting on the client\'s own chat limit. One goes out every 1.2 seconds.',
    purse        = 'Driftmarks your whole ACCOUNT holds -- every character on it shares one purse.',
    purseFlow    = 'Everything this account has ever earned and ever spent, since the first clear.',
    -- ACCURATE ABOUT THE GATE, not merely about the number (1.11.0) -- and
    -- REWRITTEN IN 1.15.0, because the gate moved under it. It used to say a
    -- full venue refused its own trials, which was the server's rule until
    -- the venue-overflow round (raid_core's pickVenue): a full shrine now
    -- seats the party at the next free one and only a board with no free
    -- arena anywhere refuses. A tooltip describing the old gate is worse than
    -- none -- it teaches a player to wait for a shrine that was never in
    -- their way.
    arenas       = 'Arenas running a trial right now, across every venue. A venue fills at three, and a full one simply sends its trials to the next free shrine -- only a board with no free arena at all turns an Enter away.',
    arenasIdle   = 'No arena anywhere is running a trial, so nothing you press now will be turned away for a full house.',
    run          = 'A trial somebody is in right now, where it is being fought and how long it has been going. Fifteen minutes is the cap.',
    venueFull    = 'These shrines have all three arenas busy. Their own trials still start -- the server seats them at the next shrine with room, and tells you which.',
    fightCapacity = 'How many parties are fighting the open trial right now, anywhere, and how many arenas across every venue are still free for it. A trial is not limited to its own shrine.',
    element      = 'Show the trials that fight under this element.',
    fight        = 'Pick this trial. The tier rows below then pay, grey and enter for it.',
    -- The open trial is drawn as text rather than as a button and earned its
    -- own sentence in 1.12.0 -- telling a player to pick the thing they have
    -- already picked is the kind of tooltip that teaches people not to hover.
    fightOpen    = 'The trial the tier rows below describe: what they pay, what is spent, and where Enter takes you.',
    base         = 'What one clear of this tier pays, every time.',
    daily        = 'A bonus on top of the clear, once a day for this trial at this tier. It turns over at Japanese midnight.',
    dailySpent   = 'Already claimed today. The clear still pays its base.',
    -- THE VARIETY ROUND (1.14.0): the day bonus, the chain, and what a repeat
    -- clear pays. Every number in these comes off the wire (w|, c|, j|, n|);
    -- the sentences only say what the numbers are for.
    dayBonus     = 'The Vana\'diel day changes every 57.6 minutes and walks all eight elements. Trials fighting under the day\'s element pay this much extra on the clear and on its first-of-the-day bonus alike.',
    chainOn      = 'Clears of DIFFERENT trials back to back build a chain, and each new trial pays a little more on top, up to the cap. Clearing a trial already in the chain resets it; letting the clock run out ends it.',
    chainOff     = 'Clear two different trials close together and the second pays extra. Keep changing trials and the bonus keeps climbing.',
    nextPay      = 'This account has already been paid %d time(s) for this trial at this tier today, so the next clear pays %d of the base %d. Repeats pay %s of base until Japanese midnight; the first-of-the-day bonus is untouched.',
    locked       = 'Complete COP to unlock this difficulty.',
    enter        = 'Gathers your whole party from where you stand and warps everyone in. The server checks everyone first and says why if it refuses.',
    page         = 'Show this shelf. A page only appears once the server has opened it to this character.',
    forgeTab     = 'Armor (iLvl 109): a Dynamis relic, AF +1 or Empyrean +2 armor piece plus\n'
                .. 'driftmarks becomes its reforged iLvl 109 piece. The piece is consumed.',
    find         = 'Narrows this shelf by item name. The Buy numbers do not move.',
    clearFind    = 'Empty the find box and show the whole shelf again.',
    sort         = 'Reorder this shelf. Shelf is the server\'s own order and the one the typed !raid shop numbers; Price cheapest first is the fastest way to see what your purse reaches. Remembered for next time.',
    copy         = 'Copy the rows shown below to the clipboard, one item and price to a line.',
    buy          = 'Ask the server what this costs. Nothing is bought until you press Confirm.',
    dear         = 'More than your purse holds today. Buy still quotes it; the refusal comes at Confirm, from the server, with the number you are short.',
    confirm      = 'Buys it now at the price quoted. The countdown is the server\'s own window on that quote.',
    expired      = 'That quote ran out. Press Buy again for a fresh one -- nothing was charged.',
    reforge      = 'Ask the forge what this conversion costs. Nothing is consumed until you press Confirm.',
    forgeConfirm = 'Pays the fee and converts now. The piece you hold is destroyed in the exchange.',
    forgeRetry   = 'Ask the forge for your bag again. The first request did not come back -- nothing was lost, and nothing was charged.',
    forgeLook    = 'Read your bag again. Pick up a relic, an AF +1 or an Empyrean +2 piece and this list fills without leaving the tab.',
    ledgerWhen   = 'How long ago the server recorded the movement, measured at the last sync.',

    -- THE COLUMN HEADERS (1.12.0). Four tables in this window carried eight
    -- labels between them that say nothing on their face -- "A clear",
    -- "First of the day", "Fee", "When" -- and every one of them was drawn
    -- through TableHeadersRow(), which submits the whole row as ONE item and
    -- so leaves nothing for IsItemHovered to be about. The header is where a
    -- reader looks first and it was the one part of the window that could not
    -- answer. (dwleaderboard's note, four addons over.)
    colTier      = 'The difficulty rungs THIS trial offers. A trial that stops short simply does not draw the rungs above it, because a rung a fight does not have is not a locked door.',
    colReason    = 'What the server recorded the movement for -- a clear, a first-of-the-day bonus, a purchase, or a refund when something could not be delivered.',
    colChange    = 'Driftmarks in or out. Green is earned, red is spent, and the sign is the direction.',
    colItem      = 'Hover any row for the client\'s own card: level, jobs, slots and the item\'s description, read from your DATs rather than from the wire.',
    colPrice     = 'What this shelf asks, in driftmarks. Drawn in the error ink when it is more than your purse holds.',
    colHeld      = 'A piece your bag holds right now that the forge will take. A piece you are wearing is refused -- take it off first.',
    colBecomes   = 'The iLvl 109 piece the forge hands back in its place.',
    colFee       = 'Driftmarks the conversion costs on top of the piece. A fee, not a price: nothing in this table is for sale.',

    -- The four empty states. Each one is a sentence about the WIRE, and none
    -- of them said which way to push.
    noPurse      = 'The purse rides in with every sync. If this stays empty, press Refresh.',
    noTiers      = 'The tier ladder rides in with every sync. If this stays empty, press Refresh -- or update dwraid if the status line says to.',
    noShop       = 'The shelf is a second answer from the server and it can be lost on its own. Press Refresh to ask again.',
    noLedger     = 'Nothing has moved on this account\'s purse yet. A clear is the first thing that will.',
};

-- One tooltip on the item just drawn (the dwnemesis helper, kept verbatim).
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* WHAT THIS ASHITA HAS (1.12.0, the dwfishing shape). The custom header row
* below needs three calls and a constant, and a player's install is frozen at
* whatever they first put on disk while this file arrives through the content
* feed -- so an install without them must fall back to the one-call header,
* which draws every label and only loses the sentences. Detected once at load,
* behind a pcall of its own: `imgui` resolves unknown names through a
* metatable onto the GuiManager userdata, and a missing key there is not
* guaranteed to be a quiet nil.
--]]
local function guiHas(name)
    local ok, value = pcall(function ()
        return imgui[name];
    end);

    return ok and type(value) == 'function';
end

local CAN_HEADER_TIPS = guiHas('TableHeader') and guiHas('TableNextRow')
    and guiHas('TableNextColumn') and ImGuiTableRowFlags_Headers ~= nil;

--[[
* AND WHETHER IT CAN TELL A DRAG FROM ITS END (1.12.0). The text-size slider
* saved the config on every frame its value moved, and settings.save WRITES A
* FILE -- so dragging the handle once from 80% to 160% rewrote the settings
* file dozens of times in a second, for a number the player was still
* choosing. dwah's own comment states the rule this file was breaking:
* "called on a change, never per frame: settings.save writes a file."
*
* IsItemActive rather than IsItemDeactivatedAfterEdit, and deliberately:
* both would do, but this one DEGRADES SAFELY. The write below is gated on
* "the handle is not being held", so an install where this call is missing
* answers false, the gate opens on the very next frame, and the behaviour is
* exactly the one that shipped -- a preference saved a little too eagerly.
* The other call is gated the other way round, and an install where it never
* fired would silently stop saving the preference at all, which is the one
* failure a capability guard must not be able to produce.
--]]
local CAN_ITEM_ACTIVE = guiHas('IsItemActive');

--[[
* AND WHETHER IT CAN BE GIVEN A SIZE FLOOR (1.12.0). The floor added in
* 1.11.0 was called unguarded, and it is one of the handful of calls this
* addon makes OUTSIDE the render pcall -- where a raise is not a lost frame
* but the addon host unloading dwraid, so the whole window disappears and
* `/raid` stops answering. Every other capability in this file is already
* guarded this way; this one was the exception, on the newest call it makes.
* Without it, a window with no floor -- exactly what shipped for a year.
* (dwfishing states the same reasoning on the same call.)
--]]
local CAN_CONSTRAIN = guiHas('SetNextWindowSizeConstraints');

-- Set when the slider moves, cleared by the write. File-scope because the
-- drag spans frames and the render function does not.
local scaleUnsaved = false;

--[[
* Every table in this window wears the same flags and fills the region it is
* given, so both are spelled once and HOISTED OUT OF THE RENDER (1.12.0): a
* bit.bor and a fresh { -1, 0 } per table per frame is four of each a frame
* for two values that cannot change. The shared size table is safe for the
* same reason the memoised icon square is -- the binding reads it and does
* not keep it.
--]]
local TABLE_FLAGS = bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit);
local TABLE_SIZE  = { -1, 0 };

--[[
* A table's whole head: its columns declared, then a header row drawn by hand
* so each one can say what it means on hover.
*
* THE COLUMN LIST IS ONE LIST (1.12.0). The labels used to be spelled twice
* per table -- once in TableSetupColumn, once in the tooltip table beside it
* -- which is the two-file drift bug at one file's scale, and it had a worse
* failure than a stale word: a tooltip list that fell one entry short of the
* table's column count would walk TableNextColumn off the end of the row and
* fold the header into two. Declared from the same array, the two cannot
* disagree and the column COUNT is `#columns` rather than a literal.
*
* `width` nil means a stretch column; a number is a px()-scaled fixed one, so
* the widths follow the text-size slider rather than fighting it.
*
* All or nothing on the hover half: without the calls CAN_HEADER_TIPS tests,
* the stock one-call row, which is exactly what this window drew until 1.12.0.
--]]
local function tableHead(columns)
    for _, column in ipairs(columns) do
        if (column.width == nil) then
            imgui.TableSetupColumn(column.label, ImGuiTableColumnFlags_WidthStretch, 0, 0);
        else
            imgui.TableSetupColumn(column.label, ImGuiTableColumnFlags_WidthFixed,
                px(column.width), 0);
        end
    end

    if (not CAN_HEADER_TIPS) then
        imgui.TableHeadersRow();

        return;
    end

    imgui.TableNextRow(ImGuiTableRowFlags_Headers, 0);

    for _, column in ipairs(columns) do
        imgui.TableNextColumn();
        imgui.TableHeader(column.label);

        if (column.tip ~= nil) then
            tip(column.tip);
        end
    end
end

local function elementOf(fight)
    if (fight == nil or fight.element == nil or fight.element == '') then
        return nil;
    end

    return fight.element;
end

-- The highest index a record table holds, asked of the table itself. The
-- fight loops once counted to a literal 9 and the five CoP trials arrived
-- as indices 9-13: the server served them, the f| handler stored them, and
-- the window drew four of the five nowhere at all. Every indexed list the
-- server can grow (fights, tiers, shop pages) reads its ceiling here now.
local function maxIndexOf(records)
    local ceiling = 0;

    for index in pairs(records) do
        if (type(index) == 'number' and index > ceiling) then
            ceiling = index;
        end
    end

    return ceiling;
end

local function rosterCeiling()
    return maxIndexOf(state.fights);
end

-- The tabs to draw: wheel order first, unknown words after, each exactly
-- once. Empty when no fight carries an element (a pre-element server) --
-- the roster then renders flat, which is what that server means.
--
-- CACHED ON THE ROSTER REVISION SINCE 1.11.0: this walked the roster twice
-- and allocated two tables (plus a gsub for every element word this addon
-- does not know) on EVERY FRAME, for an answer the wire changes once a zone.
local elemCache    = nil;
local elemCacheRev = -1;

local function buildElements()
    local seen    = { };
    local out     = T{ };
    local ceiling = rosterCeiling();

    for index = 1, ceiling do
        local element = elementOf(state.fights[index]);

        if (element ~= nil) then
            seen[element] = true;
        end
    end

    -- Each tab carries the two strings it draws with. They used to be built
    -- in the render -- the bracketed form TWICE for the open tab, since the
    -- wrap measure needs it before the text does -- which is three string
    -- allocations a tab a frame for labels the wire changes once a zone.
    local function tab(word, label, color)
        -- Today's element wears its bonus on the tab (1.14.0), so the
        -- reason to open it is visible before it is opened.
        if (state.day ~= nil and state.day.word == word) then
            label = label .. ' ' .. state.day.pctText;
        end

        return {
            word     = word,
            label    = label,
            color    = color,
            bracket  = '[ ' .. label .. ' ]',
            buttonId = string.format('%s##dwraid_elem_%s', label, word),
        };
    end

    for _, entry in ipairs(ELEMENTS) do
        if (seen[entry.word]) then
            out:append(tab(entry.word, entry.label, entry.color));
            seen[entry.word] = nil;
        end
    end

    for index = 1, ceiling do
        local element = elementOf(state.fights[index]);

        if (element ~= nil and seen[element]) then
            out:append(tab(element, (element:gsub('^%l', string.upper)), nil));
            seen[element] = nil;
        end
    end

    return out;
end

local function presentElements()
    if (elemCache == nil or elemCacheRev ~= rosterRev) then
        elemCache    = buildElements();
        elemCacheRev = rosterRev;
    end

    return elemCache;
end

-- The lowest-indexed fight on an element (or the lowest of all for nil),
-- for tab clicks and for a selection whose fight vanished in a refresh.
local function firstFightOf(element)
    for index = 1, rosterCeiling() do
        local fight = state.fights[index];

        if (fight ~= nil and (element == nil or elementOf(fight) == element)) then
            return index;
        end
    end

    return 1;
end

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. The client rate-limits outgoing chat and a !dwx command is a chat
* line; everything queues here and drains at one command per interval, with
* duplicates collapsed (dwbags' lesson, kept verbatim).
--]]
local SEND_INTERVAL = 1.2;

--[[
* AND A CEILING ON IT (1.11.0). Duplicate collapsing bounds the queue against
* one button pressed twice; it does nothing about twenty DIFFERENT buttons.
* Every Buy row is its own line, so a hand skidding down the shelf could
* enqueue a minute of chat -- lines the player has long stopped wanting,
* arriving one every 1.2 seconds, each one overwriting the last quote. Eight
* is about ten seconds of backlog: past that the press is refused OUT LOUD
* rather than swallowed, because a button that does nothing and says nothing
* is the failure this window exists to rule out.
--]]
local QUEUE_MAX = 8;

local queue    = T{ };
local lastSend = 0;

-- AND IT ANSWERS WHETHER THE LINE IS GOING OUT (2026-09-06). A refused press
-- is not the same event as an accepted one and the answer clock below has to
-- be able to tell them apart -- see ask().
local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            -- Already on its way: the duplicate is collapsed, not refused,
            -- and the line the caller wanted still reaches the server.
            return true;
        end
    end

    if (#queue >= QUEUE_MAX) then
        state.status    = 'Too many requests already waiting. Give the last ones a moment.';
        state.statusBad = true;

        return false;
    end

    queue:append(command);

    return true;
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST, and that ordering is the whole point
    -- (2026-09-06): this runs on every rendered frame for the life of the
    -- session and the queue is empty in almost all of them, while
    -- echo.canSend() is three calls across the C++ boundary
    -- (GetMemoryManager, GetPlayer, GetIsZoning). Asking it first spent a
    -- hundred and eighty of those a second to decide to do nothing.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking: a command can be lost on the way out, so an unanswered
* request is asked once more and then left alone. A PLAIN TABLE, NOT T{ }:
* keyed by verb names, and sugar-table method names shadowing a key cost
* dwbags a round once already.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

--[[
* True once this server has shown it does not speak dwraid -- either its
* own refusal arrived ("The raid is not loaded.") or a request went
* unanswered twice. An unknown !command on this server falls through to
* ordinary /say chat, so every auto-sync against a dead verb is the player
* PUBLICLY SAYING "!dwx status". While set, zone-in auto-syncs stop.
* Cleared by anything that proves the server speaks (a d| envelope) and by
* the player acting on purpose (window open, refresh).
--]]
local serverSilent = false;

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

--[[
* When the server last opened ANY envelope. A verb that goes unanswered while
* the server is plainly answering other things is one lost line -- the
* outgoing `!` eaten by the client's own chat limit is the usual way -- and
* not a server that does not speak dwraid. Telling those two apart matters
* because the second one latches `serverSilent`, which stops every zone-in
* sync this addon makes; doing that over a shelf that did not arrive would
* silence the whole window for the session (1.11.0).
--]]
local lastEnvelopeAt = nil;

local function ask(verb)
    -- A CLOCK ONLY STARTS ON A LINE THAT IS ACTUALLY GOING OUT (2026-09-06).
    -- This used to register the ask first and issue second, so a request the
    -- queue REFUSED -- the 1.11.0 ceiling, reached by a hand skidding down the
    -- shelf -- still armed the answer clock for a line that had never left the
    -- addon. Five seconds later it "timed out", was re-asked into the same
    -- full queue, timed out again, and then latched `serverSilent`: the window
    -- accused a perfectly healthy server of not answering and stopped every
    -- zone-in sync it makes for the rest of the session, over its own back
    -- pressure. The player has already been told out loud that the queue is
    -- full, which is the whole reason the ceiling says so rather than
    -- swallowing the press.
    if (not issue('!dwx ' .. verb)) then
        return;
    end

    -- `firstAt` never moves; `at` is the retry clock. The two were one field,
    -- which made "has the server said anything since I first asked?"
    -- unanswerable.
    local now = os.clock();

    requested[verb] = { at = now, firstAt = now, answered = false, tries = 1 };
end

-- Re-ask an unanswered verb once; give up loudly after that. Called every
-- frame, window open or not.
local function checkAnswers()
    -- NOTHING OUTSTANDING IS THE COMMON CASE BY A WIDE MARGIN, and the walk
    -- that proves it is two hash lookups against echo.canSend()'s three calls
    -- across the C++ boundary -- which this asked on every rendered frame of
    -- the session, window open or shut (2026-09-06, the same ordering fix
    -- pumpQueue above took).
    local waiting = false;

    for _, asked in pairs(requested) do
        if (not asked.answered and not asked.gaveUp) then
            waiting = true;
            break;
        end
    end

    if (not waiting) then
        return;
    end

    -- A held send (zone-in) leaves the line queued; aging the answer clock
    -- against it would be a false timeout, and after ANSWER_TRIES a false
    -- "No answer from the server." (dwecho canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    for verb, asked in pairs(requested) do
        if (not asked.answered and (os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                -- A RETRY THE QUEUE REFUSED IS NOT A RETRY (2026-09-06), the
                -- same fact ask() above was taught: burning the last try on a
                -- line that never left the addon is how a full queue talked
                -- this window into "No answer from the server". Leaving the
                -- clock where it stands asks again on the next frame that has
                -- room instead.
                if (issue('!dwx ' .. verb)) then
                    asked.at    = os.clock();
                    asked.tries = asked.tries + 1;
                end
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;

                if (lastEnvelopeAt ~= nil and lastEnvelopeAt >= (asked.firstAt or 0)) then
                    -- The server HAS answered since this was asked, so the
                    -- diagnosis is about one line, not about the server. Say
                    -- which one, and leave the auto-syncs alone.
                    state.status = string.format(
                        'The server did not answer "%s". Press Refresh to ask again.', verb);
                else
                    serverSilent = true;

                    state.status = 'No answer from the server. Is DriftwoodXI up to date?';
                end

                state.statusBad = true;
            end
        end
    end
end

local function requestStatus()
    ask('status');
    ask('shop');
end

--[[
* THE `marks` LATCH (1.11.0), and why a five-line panel earns one.
*
* A purchase changes exactly two things -- the purse and the ledger -- and
* the confirm envelope carries only the first. So the movement a player just
* made was missing from "Recent movements" until they zoned or pressed
* Refresh, in the one window built to show it to them. `marks` is the verb
* for precisely those two things, and it is the smallest envelope that has
* them both.
*
* But this addon had never asked for it, and the addon and the server halves
* ship on different cadences -- so a client that reaches a server predating
* the verb must neither print a refusal the player can do nothing about nor
* keep asking. The dwbags shape, kept whole: a module-local latch set on the
* doorway's own literal, the request site gated on it, the latch cleared on
* the login packet so a server updated under the player is tried again.
* Deployment order does not matter in either direction.
--]]
local marksUnsupported = false;

local function refreshLedger()
    if (marksUnsupported) then
        return;
    end

    issue('!dwx marks');
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* A WHOLE, FINITE NUMBER OFF THE WIRE, or the fallback (2026-09-06, review).
*
* LuaJIT's tonumber accepts 'nan', 'inf' and '2.5', and `or 0` catches none
* of them. Every number this reads is either formatted with %d -- which on
* LuaJIT does not raise but spells a NaN as -9223372036854775808 -- or, since
* 1.12.0, handed to the shelf's Price comparator, and a NaN there answers
* false both ways against every neighbour: not a strict weak ordering, which
* is the one input LuaJIT's sort may raise "invalid order function" on, inside
* the render pcall, on every frame the shelf is drawn. The server's own
* emitters use %i and cannot produce one; this is the belt.
--]]
local function wholeNumber(text, fallback)
    local value = tonumber(text);

    if (value == nil or value ~= value or value == math.huge or value == -math.huge) then
        return fallback;
    end

    return math.floor(value);
end

--[[
* Seconds since an os.clock() stamp, and INFINITE when the clock has gone
* backwards: on Windows os.clock() wraps negative after about 24.8 days of
* client uptime, and a stamp from before the wrap is ahead of every reading
* after it, which would hold a gate shut for the rest of the session. A gate
* that finds its stamp in the future treats the wait as over.
--]]
local function elapsed(stamp)
    if (stamp == nil) then
        return math.huge;
    end

    local now = os.clock();

    if (now < stamp) then
        return math.huge;
    end

    return now - stamp;
end

--[[
* WHAT THE ANSWER LOOKS LIKE ONCE, RATHER THAN SIXTY TIMES A SECOND (1.11.0).
*
* Everything below turns a committed answer into the strings the render pass
* draws, at the moment the answer commits. The occupancy block alone was up
* to thirteen string.formats and thirteen concatenations a frame, for a board
* the wire moves once a zone; the purse was two more; the ledger three per
* row. None of it depends on anything that changes between frames, which is
* the whole test for whether work belongs in the render pass at all.
--]]
local function runLabel(run)
    local tier  = state.tiers[run.tier];
    local fight = state.fights[run.fight];
    local label = tier ~= nil and tier.label or 'unknown tier';

    if (fight ~= nil) then
        label = fight.label .. ' ' .. label;
    end

    return label;
end

-- The occupancy block: an older server's one-arena sentence, or the
-- multi-arena count with a line per live run. Built from `arena` and `runs`
-- TOGETHER, which is why both now commit together.
local function buildBoard()
    local arena = state.arena;

    if (arena == nil) then
        return nil;
    end

    local board = { runs = T{ } };

    if (arena.busy ~= nil and arena.capacity ~= nil) then
        if (arena.busy == 0) then
            board.color = theme.colors.ok;
            board.line  = string.format('All %d arenas are idle.', arena.capacity);
            board.idle  = true;
        else
            board.color = arena.busy >= arena.capacity and theme.colors.hint or theme.colors.ok;
            board.line  = string.format('%d of %d arenas busy.', arena.busy, arena.capacity);

            -- EACH RUN NAMED BY ITS SHRINE (1.15.0), from the v| directory
            -- that arrived with it. Before the overflow round every trial ran
            -- at its own venue, so a run line that named only the trial named
            -- the place too; now it does not, and "why am I at Balga's Dais"
            -- is a question this block exists to answer. A server that sends
            -- no v| leaves the venue nil and the line renders exactly as it
            -- shipped.
            for _, run in ipairs(state.runs) do
                local venue = state.venues[run.venue];

                if (venue ~= nil) then
                    board.runs:append(string.format('  %s %d: %s, %d minute(s) in.',
                        venue.label, run.area, runLabel(run), run.minutes));
                else
                    board.runs:append(string.format('  %s, %d minute(s) in.',
                        runLabel(run), run.minutes));
                end
            end

            -- ...and the shrines that are FULL, which is the other half of
            -- the same answer: a full venue is where the overflow comes from.
            local full = T{ };

            for _, venue in ipairs(state.venues) do
                if (venue.capacity > 0 and venue.busy >= venue.capacity) then
                    full:append(venue.label);
                end
            end

            if (#full > 0) then
                board.full = string.format('Full: %s -- their trials run at the next free shrine.',
                    table.concat(full, ', '));
            end
        end

        return board;
    end

    -- The shipped one-arena lines, driven by the fields an older server sends.
    if (arena.full) then
        board.color = theme.colors.hint;
        board.line  = string.format('The arena is occupied (%s, %d minute(s) in).',
            runLabel({ tier = arena.tier, fight = arena.fight }), arena.minutes);
    else
        board.color = theme.colors.ok;
        board.line  = 'The arena is idle.';
        board.idle  = true;
    end

    return board;
end

--[[
* THE VARIETY ROUND'S TWO LINES AND ITS CELLS (1.14.0), built once at commit
* like the board above: the day line in its element's own tint, the chain
* line, and -- per (fight, tier) the account has already been paid for today
* -- the number the "A clear" column shows in place of the base. The number
* is the server's (j| carries it); this file never does the ladder
* arithmetic, it draws what it was told.
--]]
local function buildToday()
    local day   = state.day;
    local chain = state.chain;

    if (day == nil and chain == nil) then
        return nil;
    end

    local today = { };

    if (day ~= nil) then
        local entry = ELEMENT_BY_WORD[day.word];

        today.dayLine  = string.format('%s: %s trials pay %s on every clear today.',
            day.day, entry ~= nil and entry.label:lower() or day.word, day.pctText);
        today.dayColor = entry ~= nil and entry.color or theme.colors.ok;
    end

    if (chain ~= nil) then
        if (chain.links == 0) then
            today.chainLine  = string.format('No variety chain running: clear two different trials within %d minutes of each other to start one.',
                math.max(1, math.floor(chain.window / 60)));
            today.chainColor = theme.colors.hint;
            today.chainTip   = TIPS.chainOff;
        else
            today.chainLine  = string.format('Variety chain: %d trial(s). The next new trial pays %s, for another %d minute(s).',
                chain.links, chain.pctText, math.ceil(chain.seconds / 60));
            today.chainColor = theme.colors.ok;
            today.chainTip   = TIPS.chainOn;
        end
    end

    return today;
end

-- The ladder as one phrase for the next-pay tip: "75%, then 50%, then 25%".
-- Empty on a server that sends no n|.
local function ladderText()
    local parts = T{ };

    for rung = 2, maxIndexOf(state.ladder) do
        if (state.ladder[rung] ~= nil) then
            parts:append(string.format('%d%%', state.ladder[rung]));
        end
    end

    if (#parts == 0) then
        return 'less';
    end

    return table.concat(parts, ', then ');
end

local function buildNextPay()
    local out    = T{ };
    local ladder = ladderText();

    for fightIndex, byTier in pairs(state.repeats) do
        out[fightIndex] = T{ };

        for tierIndex, row in pairs(byTier) do
            local tier = state.tiers[tierIndex];

            out[fightIndex][tierIndex] = {
                text = string.format('%d', row.pay),
                tip  = string.format(TIPS.nextPay, row.count, row.pay, tier ~= nil and tier.base or 0, ladder),
            };
        end
    end

    return out;
end

-- The ledger rows as drawn. `age` is a snapshot the server took, so the
-- "when" is as fixed as the delta is -- formatting it per frame was work for
-- an answer that cannot change until the next sync.
local function dressLedger(rows)
    for _, row in ipairs(rows) do
        row.deltaText = string.format('%+d', row.delta);

        if (row.age < 60) then
            row.whenText = 'just now';
        elseif (row.age < 3600) then
            row.whenText = string.format('%dm ago', math.floor(row.age / 60));
        elseif (row.age < 86400) then
            row.whenText = string.format('%dh ago', math.floor(row.age / 3600));
        else
            row.whenText = string.format('%dd ago', math.floor(row.age / 86400));
        end
    end

    return rows;
end

--[[
* The forge rows, named, priced and SORTED (1.11.0). raid_core walks its
* REFORGE table with pairs(), so the b| records arrive in the server's hash
* order -- a different order every time the bag is read. The addon drew them
* in arrival order, which meant the row under the player's cursor changed
* identity between one visit to the tab and the next. Ordering a list for a
* reader is a renderer's job, so it is done here; the wire is left alone.
--]]
local function dressReforge(rows)
    for _, row in ipairs(rows) do
        row.relicName = itemName(row.relic);
        row.giveName  = itemName(row.give);
        row.priceText = string.format('%d', row.price);
        row.priceLine = string.format('Forge fee: %d driftmarks', row.price);
        row.relicCard = { itemid = row.relic, label = row.relicName,
                          price = row.price, priceLine = row.priceLine };
        row.giveCard  = { itemid = row.give, label = row.giveName,
                          price = row.price, priceLine = row.priceLine };
    end

    -- A strict weak ordering, tie-broken on the id: two pieces can share a
    -- name (the DATs do repeat), and a comparator that answers false both
    -- ways for equal keys is the one LuaJIT raises "invalid order function"
    -- on when the list grows past its insertion-sort threshold.
    table.sort(rows, function (a, b)
        if (a.relicName ~= b.relicName) then
            return a.relicName < b.relicName;
        end

        return a.relic < b.relic;
    end);

    for index, row in ipairs(rows) do
        row.buttonId = string.format('Reforge##dwraid_reforge_%d', index);
    end

    return rows;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        -- An envelope is the server speaking dwraid, whatever it carries.
        serverSilent   = false;
        lastEnvelopeAt = os.clock();

        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwraid through the launcher.', version, PROTOCOL);
            state.statusBad = true;
            state.protoBad  = true;
            state.inbound   = nil;
            state.building  = nil;

            -- A d| envelope IS the answer, whatever version it announced.
            -- Returning with the ask still outstanding let checkAnswers
            -- re-send it and then replace the one accurate diagnosis on screen
            -- ("Update dwraid") with "No answer from the server. Is
            -- DriftwoodXI up to date?" -- about a server that had just
            -- answered twice (the fix dwfame made on 2026-08-15).
            --
            -- A blanket retire is right HERE and in exactly one other place
            -- (the "raid is not loaded" refusal below), and those two share
            -- the property that earns it: each is a server saying it will not
            -- answer ANY of this addon's questions until something outside
            -- the addon changes. A readable envelope never has that property,
            -- however it was raised -- which is why the retire that used to
            -- sit under every early refusal is gone (see the z| handler).
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.protoBad = false;
        state.inbound  = parts[3];

        -- A response replaces its own section outright: the lists build in
        -- `building` and commit on z|, so a reply cut off mid-flight can
        -- never leave the window half of one answer and half of another.
        --
        -- AND AN ENVELOPE THIS ADDON DOES NOT STAGE CLEARS THE TABLE RATHER
        -- THAN INHERITING IT (2026-09-06). `buy`, `confirm`, `marks` and
        -- anything a newer server adds fell through every arm and left
        -- whatever the previous envelope had staged in place -- so a shop
        -- reply that never got its
        -- z| (a lost line is the whole reason this file commits on close)
        -- handed its shop staging to the very next `!raid marks` a player
        -- typed, and the l| handler indexed a ledger list that shop staging
        -- does not have. Every movement row printed "bad record:" into the
        -- chat log, once each, for a reply that was perfectly well formed.
        if (state.inbound == 'status') then
            -- `filled` separates a real status reply from the shared writer's
            -- wrapper around an EARLY refusal. A refusal raised before any verb
            -- opened an envelope ships as a bare d|1|status ... z|status with
            -- one e| inside it, so a status-shaped close arrives carrying no
            -- tiers at all -- see the z| handler.
            state.building = { tiers = T{ }, fights = T{ }, ledger = T{ }, runs = T{ }, venues = T{ }, taken = T{ }, ladder = T{ }, repeats = T{ }, filled = false };
        elseif (state.inbound == 'shop') then
            state.building = { shop = T{ }, pages = T{ } };
        elseif (state.inbound == 'reforge') then
            -- One envelope name, two replies: the bare list (b| rows) and
            -- the quote (one y|, no rows). `sawQuote` keeps the quote reply
            -- from committing its empty row list over the one on screen.
            state.building = { reforge = T{ }, sawQuote = false };
        elseif (state.inbound == 'marks') then
            -- `!raid marks` is the typed door this window is the face of, and
            -- its envelope carries the purse and the last five movements.
            -- Read since 1.11.0 -- by a player who types it, and by this
            -- addon after a purchase, which is the one thing that changes a
            -- movement without changing a zone.
            --
            -- `sawPurse` is the status branch's `filled` latch in this
            -- envelope's own terms: verbMarks emits its g| BEFORE it can
            -- refuse, so an envelope carrying no purse is a refusal, and
            -- committing its empty row list would blank a good movements
            -- panel with the answer to a question that failed.
            state.building = { ledger = T{ }, sawPurse = false };
        else
            state.building = nil;
        end

        --[[
        * A `d|1|status` IS NOT PROOF THAT A STATUS REPLY IS ARRIVING
        * (2026-09-06). The shared writer auto-wraps EVERY early refusal --
        * every sentence `enter`, `leave`, `buy`, `confirm` and `reforge`
        * raise before their own verb opens an envelope, which is most of the
        * sentences this window ever shows -- as d|1|status ... e| ...
        * z|status (squad_storage.lua's `wrapped`). So a player who pressed
        * Refresh and then Enter, and whose Enter was refused, had their
        * outstanding `status` ask marked answered by the refusal, and a
        * status reply genuinely lost on the way back was never re-asked and
        * never diagnosed: the board sat on last zone's numbers under a green
        * "Synced." for the rest of the session.
        *
        * `status` is therefore confirmed at its CLOSE, and only when the
        * envelope carried the tier list -- `filled`, the same latch that
        * decides whether to commit it, because it answers the same question.
        * Every other verb opens its own envelope and cannot be a wrapper, so
        * its `d|` still answers for it.
        --]]
        if (state.inbound ~= 'status') then
            answered(state.inbound);
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- sentence saying why something was refused is worth more than the
    -- response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- THE LATCH COMES BEFORE THE STATUS LINE AND BEFORE THE PRINT. A
        -- refusal about a verb the player never typed -- one this addon
        -- asked for on its own, at a server too old to know it -- is not a
        -- sentence to put in their chat log or on their status line. Latch,
        -- and say nothing.
        if (kind == 'e' and string.find(line, 'unknown verb "marks"', 1, true) ~= nil) then
            marksUnsupported = true;

            return;
        end

        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwraid'):append(chat.error(state.status)));

            -- The command exists but raid_core.lua is not loaded (dwx.lua's
            -- own refusal). Asking again cannot help until a map restart --
            -- detect once and go quiet.
            if (string.find(line, 'The raid is not loaded', 1, true) ~= nil) then
                serverSilent = true;

                -- AND THIS ONE REFUSAL DOES ANSWER EVERYTHING (2026-09-06),
                -- which is why the blanket retire in the z| handler could be
                -- taken out from under every other refusal and put here. A
                -- server whose doorway says the core is not loaded will not
                -- answer status, shop or anything else until a map restart --
                -- so there is no ask left worth a retry, and the sentence
                -- already on the status line is a better diagnosis than the
                -- "No answer from the server" the answer clock would put over
                -- it five seconds from now.
                for _, asked in pairs(requested) do
                    if (type(asked) == 'table') then
                        asked.answered = true;
                    end
                end
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'status' and state.building ~= nil) then
            -- ONLY COMMIT AN ENVELOPE THAT CARRIED THE LIST. An early refusal
            -- -- one raised before its verb opened an envelope, which is every
            -- refusal `enter` and `leave` produce -- is auto-wrapped by the
            -- shared writer as d|1|status ... z|status. Committing that blanked
            -- the tier table and the ledger the window had, and then overwrote
            -- the server's own sentence with a green 'Synced.', so the player
            -- was told the sync worked and shown an empty board instead of
            -- being told why they could not enter.
            if (state.building.filled) then
                -- The status ask is answered HERE, by an envelope that
                -- actually carried the board -- see the d| handler.
                answered('status');

                state.tiers    = state.building.tiers;
                state.fights   = state.building.fights or T{ };
                state.ledger   = dressLedger(state.building.ledger);
                state.runs     = state.building.runs or T{ };
                -- The venue directory commits with the runs it names, for
                -- the same reason the arena count does (see below): a frame
                -- drawn between the two would label this venue's runs with
                -- the last board's names.
                state.venues   = state.building.venues or T{ };
                state.taken    = state.building.taken or T{ };

                -- The variety round's four (1.14.0): assigned outright, nil
                -- included, for the reason the arena count is -- a status
                -- reply that carried none of them has said the server knows
                -- nothing of them, and an older server's board must draw
                -- exactly as it did before.
                state.day      = state.building.day;
                state.ladder   = state.building.ladder or T{ };
                state.repeats  = state.building.repeats or T{ };
                state.chain    = state.building.chain;
                state.today    = buildToday();
                state.nextPay  = buildNextPay();

                -- THE ARENA COUNT COMMITS WITH THE RUNS IT COUNTS (2026-09-06).
                -- a| used to land straight on state.arena the instant it
                -- arrived while its r| rows waited for this close -- and every
                -- record is its own 0x017 packet, so a frame drawn between
                -- them showed the NEW count above the OLD runs. One answer,
                -- one commit, the rule every other list here already obeyed.
                -- Assigned outright, nil included: a status reply that said
                -- nothing about the arenas has said the window knows nothing
                -- about them, which is the whole point of replacing a section
                -- rather than merging into it.
                state.arena = state.building.arena;

                rosterRev = rosterRev + 1;

                -- The selection survives a refresh unless its fight is gone
                -- (a server rollback, or a pre-fight-roster server that
                -- sends no f| at all). The element tab follows whatever
                -- fight survived; a roster without element words leaves it
                -- nil and the tab row unrendered.
                if (state.fights[state.fightSel] == nil) then
                    state.fightSel = firstFightOf(nil);
                end

                state.elemSel = elementOf(state.fights[state.fightSel]);
                state.board   = buildBoard();

                state.syncedAt  = os.clock();
                state.status    = 'Synced.';
                state.statusBad = false;
            else
                --[[
                * AND AN ENVELOPE THAT CARRIED NO LIST ANSWERS NOTHING AT ALL
                * (narrowed again 2026-09-06, and this is the end of the
                * narrowing).
                *
                * This branch is the writer's auto-wrap around an EARLY
                * refusal, and the blanket retire that stood here has now been
                * wrong in two places for one reason: it read one verb's
                * refusal as a reply to every question outstanding. On the `d|`
                * line it silently answered the `shop` ask riding beside a
                * genuine status reply. Here it silently answered BOTH asks
                * whenever any Enter, Leave, Buy, Confirm or Reforge was
                * refused -- which is the ordinary way this window is used, and
                * most of the sentences it ever shows. Either way a reply lost
                * on the wire was never re-asked and never diagnosed, and a
                * board sitting on last zone's numbers under a green "Synced."
                * is exactly the quiet kind of wrong this project exists to
                * rule out.
                *
                * Nothing is retired here, and nothing needs to be. The only
                * request this addon makes that a wrapper is ever the whole
                * answer to is one aimed at a server with no raid core at all
                * -- and that server says so, in the sentence the e| branch
                * above latches on, where the fact is actually known.
                --]]
            end

            state.building = nil;
        elseif (closing == 'marks' and state.building ~= nil) then
            -- The purse is already in from g|; this is its movement list --
            -- committed only when that g| actually arrived, for the reason
            -- the d| branch gives.
            if (state.building.sawPurse) then
                state.ledger = dressLedger(state.building.ledger);
            end

            state.building = nil;
        elseif (closing == 'shop' and state.building ~= nil) then
            state.shop     = state.building.shop;
            state.pages    = state.building.pages or T{ };
            state.building = nil;
            shopRev        = shopRev + 1;

            -- The selection survives a refresh unless its page is gone (a
            -- server rollback, or a pre-pages server that sends no p| at
            -- all -- the shelf then renders as the flat list it used to be).
            -- The forge tab is not a p| page, so it is judged by its own
            -- gate at render time rather than by this table.
            if (state.pageSel ~= REFORGE_PAGE and state.pages[state.pageSel] == nil) then
                state.pageSel = 1;
            end
        elseif (closing == 'reforge' and state.building ~= nil) then
            -- The quote reply reuses this envelope and carries no rows;
            -- committing it would blank the list under the player's cursor.
            if (not state.building.sawQuote) then
                state.reforge = dressReforge(state.building.reforge);
            end

            state.building = nil;
        end

        return;
    end

    if (kind == 'g') then
        state.purse = {
            balance = wholeNumber(parts[2], 0),
            earned  = wholeNumber(parts[3], 0),
            spent   = wholeNumber(parts[4], 0),
        };

        -- An envelope that got as far as the purse got past every refusal
        -- its verb can raise before opening one (see the marks branch).
        if (state.building ~= nil) then
            state.building.sawPurse = true;
        end

        -- Both purse lines, formatted here rather than twice a frame.
        state.purseText = {
            balance = string.format('%d driftmarks', state.purse.balance),
            detail  = string.format('(%d earned, %d spent, account-wide)',
                state.purse.earned, state.purse.spent),
        };

        return;
    end

    if (kind == 'a' and state.building ~= nil and state.building.runs ~= nil) then
        local arena = {
            -- Field 2's shipped MEANING is "entry would be refused right now"
            -- -- with more arenas than one that is EVERY slot full, not any
            -- slot used (raid_core's own comment). Named for what it says
            -- rather than `running`, which is what it was called and is not
            -- what it means.
            full    = (tonumber(parts[2]) or 0) ~= 0,
            tier    = tonumber(parts[3]) or 0,
            minutes = tonumber(parts[4]) or 0,
            -- Appended at the tail 2026-08-11; absent from an older server,
            -- and 0 means "unknown fight" wherever it is read.
            fight   = tonumber(parts[5]) or 0,
            -- Appended at the tail 2026-08-18 (the multi-arena pass): how
            -- many arenas hold a run, out of how many exist. nil -- not 0 --
            -- on an older server, so the renderer can tell "idle" from
            -- "server predates arenas" and fall back to the shipped line.
            busy     = tonumber(parts[6]),
            capacity = tonumber(parts[7]),
        };

        -- Appended at the tail 2026-08-27 (the Promyvion tier): whether this
        -- ACCOUNT has finished Chains of Promathia. nil -- not false -- on an
        -- older server, and only false (a server that SAID no) greys the
        -- rung; nil draws it plain and lets the server's own refusal sentence
        -- speak.
        --
        -- WRITTEN AS A BRANCH, NOT AS `a and b or nil` (fixed 2026-09-06).
        -- The ternary idiom collapses whenever the middle term is false --
        -- `true and false or nil` is nil -- so a server answering 0 produced
        -- byte-for-byte the same value as a server too old to answer at all,
        -- and the whole story-locked face of the Promyvion rung was dead the
        -- day it shipped: an account mid-CoP got a live Enter button and
        -- learned the truth from the server's refusal instead.
        if (parts[8] ~= nil) then
            arena.copDone = (tonumber(parts[8]) or 0) ~= 0;
        end

        state.building.arena = arena;

        return;
    end

    -- v| -- one venue (additive, 2026-09-10, the venue-overflow round):
    -- index, arenas busy, arenas total, label. This is what finally lets the
    -- board say WHERE a run is -- r| has carried a venue index since the
    -- multi-arena pass and this window had no table to look it up in, which
    -- was cosmetic while a trial only ever ran at its own shrine and stopped
    -- being cosmetic the day a full shrine started sending its trials next
    -- door. Keyed by index and built aside like every other list here.
    if (kind == 'v' and state.building ~= nil and state.building.venues ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            state.building.venues[index] = {
                busy     = tonumber(parts[3]) or 0,
                capacity = tonumber(parts[4]) or 0,
                label    = parts[5] or '?',
            };
        end

        return;
    end

    -- r| -- one live run (additive, 2026-08-18): venue, area, fight index,
    -- tier index, minutes in. Builds with the status lists and commits on
    -- z|, so a mid-flight reply can never show half an occupancy board.
    if (kind == 'r' and state.building ~= nil and state.building.runs ~= nil) then
        state.building.runs:append({
            venue   = tonumber(parts[2]) or 0,
            area    = tonumber(parts[3]) or 0,
            fight   = tonumber(parts[4]) or 0,
            tier    = tonumber(parts[5]) or 0,
            minutes = tonumber(parts[6]) or 0,
        });

        return;
    end

    -- f| -- the fight roster (additive, 2026-08-11). The WORD is what the
    -- enter verb wants on the wire; the label is what people read. A server
    -- that never sends f| leaves the roster empty, and the Enter buttons
    -- fall back to the tier-only verb that server understands.
    if (kind == 'f' and state.building ~= nil and state.building.fights ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            -- The element rides the tail (additive, 2026-08-18); absent or
            -- empty on an older server, and nil means "no element tabs"
            -- wherever it is read.
            local element = parts[5];

            if (element == '') then
                element = nil;
            end

            local label = parts[4] or '?';

            -- The live pair, read once here so the render loop never does
            -- arithmetic or allocates a string per frame (this window's
            -- standing rule).
            local running = tonumber(parts[7]);
            local free    = tonumber(parts[8]);
            local capText = nil;

            if (running ~= nil and free ~= nil) then
                capText = string.format('%s: %d running, %d arena(s) free.', label, running, free);
            end

            state.building.fights[index] = {
                word    = parts[3] or '?',
                label   = label,
                element = element,
                -- The two strings the picker draws with, built once here for
                -- the same reason the element tabs' are.
                bracket  = '[ ' .. label .. ' ]',
                buttonId = string.format('%s##dwraid_fight_%d', label, index),
                -- The tier ceiling rides one further back (additive,
                -- 2026-08-27): rungs past it are not drawn for this fight.
                -- nil on an older server = draw the whole ladder, as ever.
                maxTier = tonumber(parts[6]),
                -- The live pair (additive, 2026-09-10, the venue-overflow
                -- round): how many copies of this trial are up anywhere, and
                -- how many arenas it could be seated in right now. nil -- not
                -- 0 -- on an older server, so the capacity line is simply not
                -- drawn there rather than claiming a board with no room.
                running = running,
                free    = free,
                capText = capText,
            };
        end

        return;
    end

    -- Gated on its OWN list, not merely on "some envelope is building" (the
    -- rule every sibling handler here already followed; t| and l| were the
    -- two that did not, and a staging table of the wrong shape made them
    -- throw -- see the d| handler's note, 2026-09-06).
    if (kind == 't' and state.building ~= nil and state.building.tiers ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            local label = parts[3] or '?';
            local base  = wholeNumber(parts[4], 0);
            local daily = wholeNumber(parts[5], 0);

            -- THE WORD THE ENTER VERB PARSES, FROM THE WIRE WHERE IT EXISTS
            -- (tail field appended 2026-09-06). It used to be derived here as
            -- label:lower(), which is a guess about the server's vocabulary
            -- that happens to be right for all five rungs it has today -- and
            -- would silently send an unparseable verb the day a tier was
            -- labelled "Very Hard". f| has carried a fight's word since
            -- 2026-08-11 for exactly this reason. Absent or empty means an
            -- older server, where the derivation is the only answer there is
            -- and is the answer that server's own parser expects.
            local word = parts[6];

            if (word == nil or word == '') then
                word = label:lower();
            end

            state.building.tiers[index] = {
                label = label,
                base  = base,
                daily = daily,
                -- Drawn every frame, so worked out once here: the two pay
                -- numbers, the button's own id, and the enter word.
                baseText  = string.format('%d', base),
                dailyText = string.format('+%d', daily),
                enterId   = string.format('Enter##dwraid_enter_%d', index),
                word      = word,
            };

            -- A genuine status reply always carries every tier (raid_core's
            -- verbStatus emits t| twice before it closes). One tier is enough
            -- to prove this envelope was an answer rather than a wrapper.
            state.building.filled = true;
        end

        return;
    end

    -- k| -- the dailies this ACCOUNT has already collected today (additive,
    -- 2026-08-27): fight index, then a bitmask of tier indices. It builds
    -- with the rest of the status lists and commits on z|, so a mid-flight
    -- reply can never grey out a row on half an answer. A server that never
    -- sends k| leaves the set empty and every bonus renders claimable --
    -- which is exactly what that server is able to prove.
    if (kind == 'k' and state.building ~= nil and state.building.taken ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            state.building.taken[index] = tonumber(parts[3]) or 0;
        end

        return;
    end

    -- THE VARIETY ROUND'S FOUR (all additive, 2026-09-09 / 1.14.0). Each
    -- builds with the status lists and commits on z|, gated on a list of its
    -- own where it has one and on the tier table -- the status envelope's
    -- witness -- where it does not.
    --
    -- w| -- today's Vana'diel element, its bonus and the day's name.
    if (kind == 'w' and state.building ~= nil and state.building.tiers ~= nil) then
        local word = parts[2];
        local pct  = wholeNumber(parts[3], 0);

        if (word ~= nil and word ~= '' and pct > 0) then
            state.building.day = {
                word    = word,
                pct     = pct,
                pctText = string.format('+%d%%', pct),
                day     = (parts[4] ~= nil and parts[4] ~= '') and parts[4] or (word:gsub('^%l', string.upper) .. ' day'),
            };
        end

        return;
    end

    -- n| -- the repeat ladder, one rung per record.
    if (kind == 'n' and state.building ~= nil and state.building.ladder ~= nil) then
        local rung = tonumber(parts[2]);

        if (rung ~= nil) then
            state.building.ladder[rung] = wholeNumber(parts[3], 100);
        end

        return;
    end

    -- j| -- how many times this ACCOUNT has been paid for (fight, tier)
    -- today, and what the next clear's base will be. The number is the
    -- server's; a missing tail (a shape this file does not know) draws
    -- nothing rather than a guess.
    if (kind == 'j' and state.building ~= nil and state.building.repeats ~= nil) then
        local fight = tonumber(parts[2]);
        local tier  = tonumber(parts[3]);
        local pay   = tonumber(parts[5]);

        if (fight ~= nil and tier ~= nil and pay ~= nil) then
            state.building.repeats[fight] = state.building.repeats[fight] or T{ };
            state.building.repeats[fight][tier] = {
                count = wholeNumber(parts[4], 0),
                pay   = math.floor(pay),
            };
        end

        return;
    end

    -- c| -- the live variety chain.
    if (kind == 'c' and state.building ~= nil and state.building.tiers ~= nil) then
        local pct = wholeNumber(parts[3], 0);

        state.building.chain = {
            links   = wholeNumber(parts[2], 0),
            pct     = pct,
            pctText = string.format('+%d%%', pct),
            seconds = wholeNumber(parts[4], 0),
            mask    = wholeNumber(parts[5], 0),
            window  = wholeNumber(parts[6], 0),
        };

        return;
    end

    if (kind == 'l' and state.building ~= nil and state.building.ledger ~= nil) then
        state.building.ledger:append({
            delta  = wholeNumber(parts[2], 0),
            age    = wholeNumber(parts[3], 0),
            reason = parts[4] or '',
        });

        return;
    end

    -- p| -- the shop page directory (additive, 2026-08-18). A server that
    -- never sends p| leaves the directory empty and the shelf renders flat,
    -- which is exactly what that server's s| records describe.
    if (kind == 'p' and state.building ~= nil and state.building.pages ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            local label = parts[4] or '?';

            state.building.pages[index] = {
                word  = parts[3] or '?',
                label = label,
                -- The tab's own strings, built once rather than per frame.
                bracket  = '[ ' .. label .. ' ]',
                buttonId = string.format('%s##dwraid_page_%d', label, index),
            };
        end

        return;
    end

    if (kind == 's' and state.building ~= nil and state.building.shop ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            local label = parts[3] or '?';
            local price = wholeNumber(parts[4], 0);

            state.building.shop[index] = {
                label = label,
                price = price,
                -- Appended at the tail 2026-08-18; absent from an older
                -- server, and 0 means "no page" wherever it is read.
                page  = tonumber(parts[5]) or 0,
                -- The item id, appended the same day: what the icon and
                -- the hover card are drawn from. nil -- not 0 -- on an
                -- older server, so the renderer knows there is no card.
                itemid = tonumber(parts[6]),
                -- Everything the shelf draws or matches, worked out once
                -- here: the row's own index (the Buy verb's argument, which
                -- is sparse and never renumbers), the price as drawn, the
                -- button's ImGui id, and the lowercased haystack the find
                -- box searches.
                index     = index,
                priceText = string.format('%d', price),
                -- The card's own price sentence. Built here since 1.12.0 for
                -- the reason the forge's has been: itemTooltip formatted it
                -- on every frame the cursor rested on a row, and it is the
                -- same eleven characters for as long as the shelf stands.
                priceLine = string.format('%d driftmarks', price),
                buttonId  = string.format('Buy##dwraid_buy_%d', index),
                search    = label:lower(),
            };
        end

        return;
    end

    -- The live quote rides outside the list-building rule: it is one value,
    -- it names its own window, and the Confirm button exists only while it
    -- is fresh (the server holds the same 60 s rule; this is presentation).
    -- The server holds ONE quote slot for the shelf and the forge together,
    -- so a shelf quote retires any forge quote on screen and vice versa --
    -- otherwise a stale Confirm button would settle the OTHER purchase.
    if (kind == 'q') then
        local index = tonumber(parts[2]) or 0;
        local price = wholeNumber(parts[3], 0);
        local row   = state.shop[index];

        state.quote = {
            index    = index,
            price    = price,
            deadline = os.clock() + (tonumber(parts[4]) or 60),
            -- The button's whole label, built here: it names one shelf row at
            -- one price and neither moves while the quote lives, so building
            -- it per frame was a string.format for an answer already known.
            buttonLabel = string.format('Confirm: %s for %d##dwraid_confirm',
                row ~= nil and row.label or '?', price),
        };

        state.reforgeQuote = nil;

        return;
    end

    -- A convertible relic in the bag (1.8.0, the forge list). Only accepted
    -- while the reforge envelope is building, the same rule every list obeys.
    if (kind == 'b' and state.building ~= nil and state.building.reforge ~= nil) then
        state.building.reforge:append({
            relic = tonumber(parts[2]) or 0,
            give  = tonumber(parts[3]) or 0,
            price = tonumber(parts[4]) or 0,
        });

        return;
    end

    -- The forge quote (1.8.0). One value with its own window, the q| shape;
    -- also marks the building envelope as a quote reply so the z| commit
    -- does not blank the row list with the quote's empty one.
    if (kind == 'y') then
        local give  = tonumber(parts[3]) or 0;
        local price = wholeNumber(parts[4], 0);

        state.reforgeQuote = {
            relic    = tonumber(parts[2]) or 0,
            give     = give,
            price    = price,
            deadline = os.clock() + (tonumber(parts[5]) or 60),
            buttonLabel = string.format(
                'Confirm: %s for %d -- the piece is consumed##dwraid_reforge_confirm',
                itemName(give), price),
        };

        state.quote = nil;

        if (state.building ~= nil) then
            state.building.sawQuote = true;
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWXDATA is
* ours: consumed here and blocked so the chat log never sees it -- before
* parsing, so a malformed record cannot leak as noise.
--]]
ashita.events.register('packet_in', 'dwraid_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwraid'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

local function purseBlock()
    if (state.purseText == nil) then
        imgui.TextDisabled('No purse data yet. Refresh, or wait for the first sync.');
        tip(TIPS.noPurse);

        return;
    end

    imgui.TextColored(theme.colors.hint, state.purseText.balance);
    tip(TIPS.purse);
    imgui.SameLine();
    imgui.TextDisabled(state.purseText.detail);
    tip(TIPS.purseFlow);
end

-- The occupancy block, drawn from what buildBoard() worked out when the
-- answer committed. Nothing here is computed per frame any more.
local function arenaBlock()
    local board = state.board;

    if (board == nil) then
        return;
    end

    imgui.TextColored(board.color, board.line);
    tip(board.idle and TIPS.arenasIdle or TIPS.arenas);

    for _, line in ipairs(board.runs) do
        imgui.TextDisabled(line);
        tip(TIPS.run);
    end

    -- The full shrines and, for the trial the picker has open, what room is
    -- left to it (1.15.0). Both were worked out at commit; this draws them.
    if (board.full ~= nil) then
        imgui.TextDisabled(board.full);
        tip(TIPS.venueFull);
    end

    local fight = state.fights[state.fightSel];

    if (fight ~= nil and fight.capText ~= nil) then
        imgui.TextDisabled(fight.capText);
        tip(TIPS.fightCapacity);
    end
end

-- The day line and the chain line (1.14.0), from what buildToday() worked
-- out at commit. Nothing on an older server.
local function todayBlock()
    local today = state.today;

    if (today == nil) then
        return;
    end

    if (today.dayLine ~= nil) then
        imgui.TextColored(today.dayColor, today.dayLine);
        tip(TIPS.dayBonus);
    end

    if (today.chainLine ~= nil) then
        imgui.TextColored(today.chainColor, today.chainLine);
        tip(today.chainTip);
    end
end

--[[
* A SameLine that keeps the next button on this row only if it fits the
* window (1.7.0): the three button rows below (elements, fights, shop pages)
* used to march off the right edge the moment the labels outgrew the window
* -- which is exactly what raising the text size does. Measured each frame
* against the live window width, so wrapping follows a resize as it happens.
* CalcTextSize answers in the CURRENT window's font scale, so the measure
* follows the slider for free. On an older Ashita whose imgui.lua lacks the
* measuring calls this degrades to the old unconditional SameLine -- the
* dwtheme skew rule.
--]]
-- The three measures under ONE pcall rather than three (1.11.0): this runs
-- once per button on three button rows, so the old shape paid three pcalls a
-- button a frame for a measurement that either works for all three or for
-- none of them. CalcTextSize answers a pair and only its width is wanted,
-- which is what a non-final call position gives for free.
local function measureRow(label)
    return imgui.CalcTextSize(label), imgui.GetCursorPosX(), imgui.GetWindowWidth();
end

local function sameLineIfFits(label)
    imgui.SameLine();

    -- Every measure is validated as a NUMBER, not just as a function: a
    -- skewed install (or a stub) can answer a callable that returns nil, and
    -- nil arithmetic inside the render pcall closes the whole window.
    local ok, width, curX, winW = pcall(measureRow, label);

    if (not ok or type(width) ~= 'number'
            or type(curX) ~= 'number'
            or type(winW) ~= 'number') then
        return;
    end

    -- Text plus the button's own frame padding, against the window's right
    -- edge less its window padding.
    if (curX + width + px(16) > winW - px(12)) then
        imgui.NewLine();
    end
end

--[[
* The element tabs: one per element that holds a fight, wheel order, the
* open one drawn as text in its element's tint (the fight picker's shape,
* one level up). Picking a tab moves the fight selection onto that
* element's first fight, so the Enter buttons below always ask for a fight
* the open tab is showing. On a pre-element server this renders nothing
* and the fight row below shows the whole roster, exactly as it used to.
--]]
local function elementsBlock()
    local elements = presentElements();

    if (#elements == 0) then
        return;
    end

    imgui.TextDisabled('Element:');

    for _, entry in ipairs(elements) do
        if (entry.word == state.elemSel) then
            sameLineIfFits(entry.bracket);
            imgui.TextColored(entry.color or theme.colors.ok, entry.bracket);
        else
            sameLineIfFits(entry.label);

            if (imgui.Button(entry.buttonId)) then
                state.elemSel  = entry.word;
                state.fightSel = firstFightOf(entry.word);
            end

            tip(TIPS.element);
        end
    end
end

--[[
* WHAT IS STILL OWED ON A TRIAL TODAY (1.12.0), as one sentence on the hover.
*
* The k| masks are per (fight, tier) and the tier table can only ever show
* ONE fight's -- the selected one -- so "which trial still has bonuses on it"
* was a question that cost a click on every element tab and every fight
* button to answer, in the one window built to answer it. The typed door
* rolls the same fact up across the whole roster in prose; this is the
* window's half of that, and it reads off state the wire already sent.
*
* Formatted on hover and nowhere else: a sentence nobody is looking at is not
* worth a string.format sixty times a second, which is the rule the rest of
* this file was moved onto in 1.11.0.
*
* A server that sends no k| leaves every mask at zero and this reads "all
* four still unclaimed" -- exactly what its daily column already draws in the
* claimable ink, and exactly what a server with no such binding can honestly
* say.
--]]
local function dailiesLeftText(index)
    local fight = state.fights[index];

    if (fight == nil) then
        return nil;
    end

    local rungs = maxIndexOf(state.tiers);

    if (rungs == 0) then
        return nil;
    end

    local ceiling = fight.maxTier or rungs;
    local mask    = state.taken[index] or 0;
    local left    = 0;
    local total   = 0;

    for rung = 1, rungs do
        if (state.tiers[rung] ~= nil and rung <= ceiling) then
            total = total + 1;

            if (bit.band(mask, bit.lshift(1, rung - 1)) == 0) then
                left = left + 1;
            end
        end
    end

    if (total == 0) then
        return nil;
    end

    if (left == 0) then
        return 'Every first-of-the-day bonus on this trial is spent until Japanese midnight.';
    end

    return string.format('%d of its %d first-of-the-day bonuses are still unclaimed.', left, total);
end

-- What the variety round says about one trial on hover (1.14.0): whether it
-- fights under today's element, and whether clearing it next builds or
-- resets the chain. Formatted on hover only, like the sentence beside it.
local function varietyText(index)
    local fight = state.fights[index];

    if (fight == nil) then
        return nil;
    end

    local parts = T{ };

    if (state.day ~= nil and elementOf(fight) == state.day.word) then
        parts:append(string.format('It fights under today\'s element: %s on every clear.', state.day.pctText));
    end

    if (state.chain ~= nil and state.chain.links > 0) then
        if (index >= 1 and index <= 31 and bit.band(state.chain.mask, bit.lshift(1, index - 1)) ~= 0) then
            parts:append('It is in your variety chain: clearing it again resets the chain.');
        else
            parts:append(string.format('Not in your chain yet: clearing it next pays %s on top.', state.chain.pctText));
        end
    end

    if (#parts == 0) then
        return nil;
    end

    return table.concat(parts, ' ');
end

local function fightTip(index, open)
    if (not imgui.IsItemHovered()) then
        return;
    end

    local text = open and TIPS.fightOpen or TIPS.fight;
    local owed = dailiesLeftText(index);

    if (owed ~= nil) then
        text = text .. ' ' .. owed;
    end

    local extra = varietyText(index);

    if (extra ~= nil) then
        text = text .. ' ' .. extra;
    end

    imgui.SetTooltip(text);
end

--[[
* The fight picker: one button per fight ON THE OPEN ELEMENT TAB, the
* selected one drawn as text -- the tiersBlock Enter buttons ask for
* whichever fight is selected here. With no element data (a pre-element or
* pre-fight-roster server) the filter is off and every fight renders, and
* with no roster at all this block renders nothing and Enter falls back to
* the tier-only verb.
--]]
local function fightsBlock()
    if (next(state.fights) == nil) then
        return;
    end

    imgui.TextDisabled('Fight:');

    for index = 1, rosterCeiling() do
        local fight = state.fights[index];

        if (fight ~= nil and (state.elemSel == nil or elementOf(fight) == state.elemSel)) then
            if (index == state.fightSel) then
                sameLineIfFits(fight.bracket);
                imgui.TextColored(theme.colors.ok, fight.bracket);

                -- THE OPEN TRIAL EARNS THE SENTENCE TOO (1.12.0). It is drawn
                -- as text rather than as a button, and until now that meant
                -- the one trial a player is actually looking at was the one
                -- they could not hover for what it still owes them. Its lead
                -- sentence differs: telling somebody to pick what they have
                -- already picked teaches them not to hover.
                fightTip(index, true);
            else
                sameLineIfFits(fight.label);

                if (imgui.Button(fight.buttonId)) then
                    state.fightSel = index;
                end

                fightTip(index, false);
            end
        end
    end
end

--[[
* One tier as a row: label, payouts, and the Enter button that is the whole
* point of the window. The button only SENDS the verb -- the server gates
* the party, and its refusal sentence lands in the status line above.
--]]
-- The nameless fourth column still gets a header cell so the row is the full
-- width of the table; its buttons carry their own sentences.
local TIER_COLUMNS = {
    { label = 'Tier',             tip = TIPS.colTier,  width = 90 },
    { label = 'A clear',          tip = TIPS.base,     width = 90 },
    { label = 'First of the day', tip = TIPS.daily },
    { label = '',                                      width = 70 },
};

local function tiersBlock()
    if (next(state.tiers) == nil) then
        imgui.TextDisabled('No tier data yet.');
        tip(TIPS.noTiers);

        return;
    end

    -- Fixed widths ride px(): ImGui's font scale moves the glyphs but not a
    -- hand-set column, and an unscaled column truncates exactly the way the
    -- dwcraft measuring comment warns about. They live in TIER_COLUMNS above,
    -- beside the label and the sentence each column carries.
    if (imgui.BeginTable('##dwraid_tiers', #TIER_COLUMNS, TABLE_FLAGS, TABLE_SIZE)) then
        tableHead(TIER_COLUMNS);

        -- The selected fight's ceiling (2026-08-27): rungs past it are not
        -- drawn at all -- a rung a fight does not offer is not a locked
        -- door, it is not a door. nil (an older server) draws the whole
        -- ladder, and the enter verb's own sentence covers the rest.
        local fightSel = state.fights[state.fightSel];
        local ceiling  = fightSel ~= nil and fightSel.maxTier or nil;

        for index = 1, maxIndexOf(state.tiers) do
            local tier = state.tiers[index];

            if (tier ~= nil and (ceiling == nil or index <= ceiling)) then
                -- The Promyvion rung is STORY-LOCKED until the account has
                -- finished CoP (the owner's design): drawn greyed, with the
                -- owner's own hover words, and its Enter withheld -- the
                -- server refuses the same press with the same fact.
                --
                -- `== 5`, not `>= 5` (narrowed 2026-09-06). Rung five is the
                -- one rung anybody decided this about, and withholding a
                -- button the server WOULD have accepted is the one direction
                -- this window is never allowed to be wrong in -- a greyed
                -- control here is a courtesy, never the authority. A sixth
                -- rung, if one ever ships, draws plain and earns the server's
                -- own sentence until somebody adds it here on purpose.
                local storyLocked = index == 5 and state.arena ~= nil
                    and state.arena.copDone == false;

                imgui.TableNextRow();
                imgui.TableNextColumn();

                if (storyLocked) then
                    imgui.TextColored(theme.colors.inert, tier.label);
                    tip(TIPS.locked);
                else
                    imgui.Text(tier.label);
                end

                imgui.TableNextColumn();

                -- WHAT THE NEXT CLEAR ACTUALLY PAYS (1.14.0): once this
                -- account has been paid for the selected fight at this rung
                -- today, the server's j| says what the next base is and the
                -- cell shows that number in the hint ink instead of the base.
                -- Nothing on an older server, or before the first clear.
                local nextPay = state.nextPay[state.fightSel] ~= nil and state.nextPay[state.fightSel][index] or nil;

                if (nextPay ~= nil) then
                    imgui.TextColored(theme.colors.hint, nextPay.text);
                    tip(nextPay.tip);
                else
                    imgui.Text(tier.baseText);
                    tip(TIPS.base);
                end

                imgui.TableNextColumn();

                -- GREY WHEN THIS ACCOUNT ALREADY TOOK IT TODAY. The daily is
                -- keyed per (fight, tier) server-side, so the mask read here
                -- is the SELECTED fight's -- these rows describe that fight,
                -- which is why fightsBlock() runs one line above tiersBlock()
                -- in the render pass. Nothing is hidden and nothing is
                -- disabled: Enter still enters, because the clear itself
                -- still pays its base. Only the bonus is spent.
                local takenMask = state.taken[state.fightSel] or 0;
                local claimed   = bit.band(takenMask, bit.lshift(1, index - 1)) ~= 0;

                imgui.TextColored(claimed and theme.colors.inert or theme.colors.ok,
                    tier.dailyText);
                tip(claimed and TIPS.dailySpent or TIPS.daily);

                imgui.TableNextColumn();

                -- A story-locked rung gets the greyed word where its button
                -- would be -- withholding the click, not hiding the row, so
                -- the rung is something to aim at rather than a secret.
                if (storyLocked) then
                    imgui.TextColored(theme.colors.inert, 'Locked');
                    tip(TIPS.locked);
                else
                    if (imgui.Button(tier.enterId)) then
                        -- The fight rides the verb by its WORD (the f| record's
                        -- second field): labels hold spaces, and a lowercased
                        -- two-word label would be refused by the parser. No
                        -- roster (an older server) means no fight word, which is
                        -- exactly the verb that server understands.
                        local fight = state.fights[state.fightSel];

                        state.status    = string.format('Asking for the %s trial...',
                            fight ~= nil and (fight.label .. ' ' .. tier.label) or tier.label);
                        state.statusBad = false;

                        if (fight ~= nil) then
                            issue(string.format('!dwx enter %s %s', fight.word, tier.word));
                        else
                            issue(string.format('!dwx enter %s', tier.word));
                        end
                    end

                    tip(TIPS.enter);
                end
            end
        end

        imgui.EndTable();
    end
end

--[[
* The movements, as a table rather than three SameLine'd texts (1.11.0). The
* reason field is free text the server clips at 48 characters, and at 160%
* text size a 48-character reason plus its age ran straight past the right
* edge of a default-sized window with no way to read the end of it. A stretch
* column wraps the table to the window instead, the way every other table in
* this file already does.
--]]
local LEDGER_COLUMNS = {
    { label = 'Change', tip = TIPS.colChange,  width = 60 },
    { label = 'Reason', tip = TIPS.colReason },
    { label = 'When',   tip = TIPS.ledgerWhen, width = 72 },
};

local function ledgerBlock()
    if (#state.ledger == 0) then
        imgui.TextDisabled('No driftmark movements yet. The trial pays the first ones.');
        tip(TIPS.noLedger);

        return;
    end

    if (imgui.BeginTable('##dwraid_ledger', #LEDGER_COLUMNS, TABLE_FLAGS, TABLE_SIZE)) then
        tableHead(LEDGER_COLUMNS);

        for _, row in ipairs(state.ledger) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextColored(row.delta >= 0 and theme.colors.ok or theme.colors.err,
                row.deltaText);
            imgui.TableNextColumn();
            imgui.TextDisabled(row.reason);
            imgui.TableNextColumn();
            imgui.TextDisabled(row.whenText);
            tip(TIPS.ledgerWhen);
        end

        imgui.EndTable();
    end
end

-- A section header: a breath, the title in the dim ink, a rule under it --
-- the same shape every section of the window wears.
local function sectionHeader(text)
    imgui.Spacing();
    imgui.TextColored(theme.colors.dim, text);
    imgui.Separator();
end

--[[
* The shop: shelf rows with a Buy button each, and a Confirm button that
* exists only while a quote is fresh. Buy asks the server for a quote;
* nothing purchases on one click -- the deliberate second press is the
* dwquest storefront's rule, kept whole.
--]]
--[[
* The page picker: one button per shop page, the selected one drawn as text
* (the fightsBlock shape, kept whole). On a server that sent no p| records
* (pre-pages build) this renders nothing and the shelf below shows every
* row it received -- exactly the flat list that server means.
--]]
-- The forge tab is offered exactly when the elite (iLvl 109) shelf page is
-- -- the two sit behind the same server gate (cap 109 AND the CoP story),
-- and the p| directory carrying `elite` IS the server saying that gate
-- passed for this character. An older server, or an account mid-story,
-- serves no elite page and the tab never draws. (REFORGE_PAGE itself is
-- declared with the protocol constants at the top of the file.)

-- Asked twice a frame by the two blocks below, for an answer the page
-- directory only changes when it is replaced -- so it is worked out on the
-- shop revision and read from there (1.11.0).
local forgeOffered    = false;
local forgeOfferedRev = -1;

local function reforgeOffered()
    if (forgeOfferedRev ~= shopRev) then
        forgeOffered    = false;
        forgeOfferedRev = shopRev;

        for _, page in pairs(state.pages) do
            if (page.word == 'elite') then
                forgeOffered = true;
                break;
            end
        end
    end

    return forgeOffered;
end

local function shopPagesBlock()
    if (next(state.pages) == nil) then
        return;
    end

    imgui.TextDisabled('Page:');

    for index = 1, maxIndexOf(state.pages) do
        local page = state.pages[index];

        if (page ~= nil) then
            if (index == state.pageSel) then
                sameLineIfFits(page.bracket);
                imgui.TextColored(theme.colors.ok, page.bracket);
            else
                sameLineIfFits(page.label);

                if (imgui.Button(page.buttonId)) then
                    state.pageSel = index;
                end

                tip(TIPS.page);
            end
        end
    end

    -- The Relic Reforge tab (1.8.0) -- the iLvl-109 ARMOR surface, which is
    -- a trade-in rather than a shelf (ILVL109_PLAN decision 2), drawn at
    -- the end of the page strip it belongs beside.
    if (reforgeOffered()) then
        if (state.pageSel == REFORGE_PAGE) then
            sameLineIfFits('[ Relic Reforge ]');
            imgui.TextColored(theme.colors.ok, '[ Relic Reforge ]');
        else
            sameLineIfFits('Relic Reforge');

            if (imgui.Button('Relic Reforge##dwraid_page_reforge')) then
                state.pageSel = REFORGE_PAGE;

                -- The list is the bag's live contents, so every visit
                -- re-asks rather than trusting a stale copy.
                state.reforge   = nil;
                state.reforgeAt = os.clock();

                issue('!dwx reforge');
            end
        end

        tip(TIPS.forgeTab);
    end
end

--[[
* A QUOTE THAT RAN OUT SAYS SO (1.11.0). Both Confirm buttons simply vanished
* at their deadline, leaving nothing where the press had been -- so a player
* who looked away for a minute came back to a window that had quietly
* forgotten the purchase it had just offered them. The line stands for a
* short grace and then the quote is dropped, because an explanation that
* never leaves is its own kind of noise.
--]]
local QUOTE_GRACE = 20;

local function expiredNote(left)
    if (left <= -QUOTE_GRACE) then
        return false;
    end

    imgui.PushTextWrapPos(0);
    imgui.TextColored(theme.colors.warn,
        'That quote expired. Ask again for a fresh one -- nothing was charged.');
    imgui.PopTextWrapPos();
    tip(TIPS.expired);

    return true;
end

--[[
* The Relic Reforge section (1.8.0 -- ILVL109_PLAN's owed addon work, built
* on the b|/y| records the server has emitted since the flip). One row per
* convertible relic in the bag: the relic, what it becomes, the price, and a
* Reforge button that asks for the quote -- the deliberate second press is
* the shelf's own Confirm rule, kept whole, and the confirm verb is the
* shelf's too (one quote slot server-side; q| and y| retire each other).
--]]
local FORGE_COLUMNS = {
    { label = 'Piece held', tip = TIPS.colHeld },
    { label = 'Becomes',    tip = TIPS.colBecomes },
    { label = 'Fee',        tip = TIPS.colFee,    width = 70 },
    { label = '',                                 width = 80 },
};

local function reforgeBlock()
    -- Three families since 1.10.0 (2026-09-03): the Outfitter's AF +1 and
    -- Empyrean +2 pieces list beside the Dynamis relics off the same b|
    -- records -- the server decides what the bag can forge; this window
    -- only says so.
    --
    -- WRAPPED, NOT CLIPPED (1.11.0): this sentence and the empty-bag one
    -- below both run past a hundred characters, and a default-width window
    -- at any text size cut them off mid-word -- which is the one thing an
    -- explanation must not do.
    imgui.PushTextWrapPos(0);
    imgui.TextDisabled('A Dynamis relic, AF +1 or Empyrean +2 armor piece + driftmarks becomes the iLvl 109 piece. The piece is consumed.');
    imgui.PopTextWrapPos();

    if (state.reforge == nil) then
        --[[
        * AND THE TAB ASKS FOR ITSELF WHEN NOBODY HAS ASKED FOR IT (1.12.0).
        * Every request for this list used to hang off the tab CLICK, so a
        * view that arrived at the forge any other way sat on "Reading your
        * bag..." for good -- with no Try again either, because that offer is
        * measured from a request that was never made. The zone-in is exactly
        * such a way in since this version: the page selection now survives a
        * zone line (entering the arena, leaving it and the return warp are
        * all zone lines), and the wipe that follows leaves the forge open
        * with nothing asked. Asking here makes the tab correct however the
        * window came to be on it, and it cannot loop: the request stamps its
        * own clock, and the clock is what says a request is outstanding.
        --]]
        --
        -- AND IT WAITS ITS TURN (2026-09-06, review). A zone-in schedules the
        -- sync behind the ZONE_ORDER stagger precisely so this addon's first
        -- line after a load screen does not land on the same instant as every
        -- sibling's; an ask queued from the first rendered frame after 0x000A
        -- went out the moment the client would take chat -- slot zero's
        -- instant, ahead of the addon's own sync -- which is the collision the
        -- stagger exists to prevent. `syncAt` is nil whenever no zone-in sync
        -- is pending, so a fresh load and a tab click behave as before. And
        -- the silence latch is honoured for the same reason the sync honours
        -- it: this ask is automatic, and an unknown `!` command on a server
        -- without dwx.lua is public /say.
        if (state.reforgeAt == nil and state.syncAt == nil and not serverSilent) then
            state.reforgeAt = os.clock();

            issue('!dwx reforge');
        end

        imgui.TextDisabled('Reading your bag...');

        --[[
        * A LOST LINE HERE HAD NO WAY BACK (1.11.0). The tab that asks the
        * forge is drawn as plain text the moment it is open, so a request
        * that never came home left "Reading your bag..." on screen with no
        * control on the window that would ask again -- the only recovery was
        * to click a different shelf page and then this tab a second time,
        * which is not a thing anybody would guess. The offer waits a few
        * seconds so a normal round trip never grows a button.
        --]]
        if (state.reforgeAt ~= nil and elapsed(state.reforgeAt) > 6.0) then
            imgui.SameLine();

            if (imgui.SmallButton('Try again##dwraid_reforge_retry')) then
                state.reforgeAt = os.clock();

                issue('!dwx reforge');
            end

            tip(TIPS.forgeRetry);
        end

        return;
    end

    if (#state.reforge == 0) then
        --[[
        * AND THE EMPTY ANSWER GETS A WAY BACK TOO (1.12.0). "Open this tab
        * again" was the only recovery here, and it is the same instruction
        * 1.11.0 decided nobody would guess when it added Try again one branch
        * up -- the difference is only that the server ANSWERED this time. A
        * player who reads this, goes to their mog house for the piece and
        * comes back is looking at a list that will not change until they
        * click away and click back. The button is on its own line rather than
        * SameLine'd, because the sentence above it wraps.
        --]]
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled('Nothing in your bags reforges right now. Hold a Dynamis relic, AF +1 or Empyrean +2 armor piece, then look again.');
        imgui.PopTextWrapPos();

        if (imgui.SmallButton('Look again##dwraid_reforge_recheck')) then
            state.reforge   = nil;
            state.reforgeAt = os.clock();

            issue('!dwx reforge');
        end

        tip(TIPS.forgeLook);

        return;
    end

    if (imgui.BeginTable('##dwraid_reforge', #FORGE_COLUMNS, TABLE_FLAGS, TABLE_SIZE)) then
        tableHead(FORGE_COLUMNS);

        for _, row in ipairs(state.reforge) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            drawIcon(row.relic, px(20));

            local relicHovered = imgui.IsItemHovered();

            imgui.Text(row.relicName);

            if (imgui.IsItemHovered() or relicHovered) then
                itemTooltip(row.relicCard);
            end

            imgui.TableNextColumn();

            drawIcon(row.give, px(20));

            local giveHovered = imgui.IsItemHovered();

            imgui.Text(row.giveName);

            if (imgui.IsItemHovered() or giveHovered) then
                itemTooltip(row.giveCard);
            end

            imgui.TableNextColumn();
            imgui.Text(row.priceText);
            imgui.TableNextColumn();

            if (imgui.Button(row.buttonId)) then
                state.status    = string.format('Asking for a quote on %s...', row.giveName);
                state.statusBad = false;

                issue(string.format('!dwx reforge %d', row.relic));
            end

            tip(TIPS.reforge);
        end

        imgui.EndTable();
    end

    if (state.reforgeQuote ~= nil) then
        local left = state.reforgeQuote.deadline - os.clock();

        if (left > 0) then
            if (imgui.Button(state.reforgeQuote.buttonLabel)) then
                state.reforgeQuote = nil;

                issue('!dwx confirm');

                -- The relic is gone the moment the confirm settles; re-ask so
                -- the list never offers a conversion the bag can no longer pay.
                state.reforgeAt = os.clock();

                issue('!dwx reforge');

                -- And the fee it cost belongs in the movements beside it.
                refreshLedger();
            end

            tip(TIPS.forgeConfirm);

            imgui.SameLine();
            imgui.TextDisabled(string.format('%ds left on the quote', math.floor(left)));
        elseif (not expiredNote(left)) then
            state.reforgeQuote = nil;
        end
    end
end

--[[
* THE SHELF VIEW (1.11.0), the dwah pattern applied here.
*
* What the shelf draws is a filter of the model, and the model moves once a
* sync. The old walk ran the whole 219-slot index space and, for every row it
* kept, allocated a string.format for the price and another for the button id
* -- eighty allocations a frame on the armor page alone. Worse, the find box
* below would have added a :lower() and a :find() per row per frame on top of
* it, which is exactly the shape dwah's view cache exists to refuse.
*
* Keyed on the shop revision, the page, the find term and (since 1.12.0) the
* order: rebuilt when the wire replaces the shelf, when the player picks a
* tab, when a letter is typed or when the order changes, and read straight
* out otherwise.
--]]
-- THE KEY IS COMPARED FIELD BY FIELD, NOT FORMATTED (1.12.0). The cache is
-- read on every frame and the old shape built a fresh
-- `string.format('%d|%s|%s', ...)` -- plus the tostring inside it -- purely
-- to decide that nothing had moved. Two allocations a frame to avoid work is
-- not avoiding work; four scalar comparisons allocate nothing at all.
local shopView     = T{ };
local shopViewRev  = -1;
local shopViewPage = nil;
local shopViewTerm = nil;
local shopViewSort = nil;
local shopTotal    = 0;
local shopCountText = '';

-- The typed text, lowercased and trimmed. Memoised on the raw buffer: this
-- runs once a frame and the three allocations it makes are three more than an
-- unchanged box needs.
local findRaw  = nil;
local findTerm = '';

local function findText()
    local text = state.find[1] or '';

    if (findRaw ~= text) then
        findRaw  = text;
        findTerm = text:lower():gsub('^%s+', ''):gsub('%s+$', '');
    end

    return findTerm;
end

--[[
* The three orders the shelf can be read in (1.12.0). `shelf` is the
* server's own -- the order every shipped version before this one drew, and
* the order the typed door numbers -- and it is what an unrecognised config
* word falls back to. Each comparator is a STRICT WEAK ORDERING tie-broken
* on the shelf index, which is unique and never renumbers: a comparator that
* answers false both ways for two equal keys is the one LuaJIT raises
* "invalid order function" on once a list outgrows its insertion sort.
--]]
local SORT_FUNCS = {
    name = function (a, b)
        if (a.search ~= b.search) then
            return a.search < b.search;
        end

        return a.index < b.index;
    end,
    price = function (a, b)
        if (a.price ~= b.price) then
            return a.price < b.price;
        end

        return a.index < b.index;
    end,
};

local function buildShopView(paged, term, order)
    local out   = T{ };
    local total = 0;

    -- Shelf indices are sparse and forever (the server's rule), so the walk
    -- cannot use #shop -- but it no longer uses a hand-maintained literal
    -- either (1.12.0). The ceiling was 99, then 199 when the bracket pages
    -- landed at 100, then 219 when the materials page landed at 200 (it was
    -- labelled "Magian Materials" until the server renamed it 2026-09-07 --
    -- a label, so nothing here moved), and each
    -- of those moves was a line in this file that had to be remembered on the
    -- day a page shipped. maxIndexOf asks the table what it actually holds,
    -- so the ninth page renders the hour it opens with no addon edit -- and a
    -- shelf whose top bracket is still dark walks fewer slots than the
    -- literal did, not more.
    for index = 1, maxIndexOf(state.shop) do
        local row = state.shop[index];

        if (row ~= nil and ((not paged) or row.page == state.pageSel)) then
            total = total + 1;

            if (term == '' or row.search:find(term, 1, true) ~= nil) then
                out:append(row);
            end
        end
    end

    local sorter = SORT_FUNCS[order];

    if (sorter ~= nil) then
        table.sort(out, sorter);
    end

    shopTotal = total;

    -- The count beside the find box, built here rather than per frame: it can
    -- only change when this view is rebuilt, which is the whole definition of
    -- the cache it lives in.
    shopCountText = string.format('%d of %d rows', #out, total);

    return out;
end

local function shelfRows(paged)
    local term  = findText();
    local order = sortMode();

    if (shopViewRev ~= shopRev or shopViewPage ~= state.pageSel
            or shopViewTerm ~= term or shopViewSort ~= order) then
        shopViewRev  = shopRev;
        shopViewPage = state.pageSel;
        shopViewTerm = term;
        shopViewSort = order;
        shopView     = buildShopView(paged, term, order);
    end

    return shopView, term;
end

-- The find row is drawn in two halves around the view build, because the
-- widget writes the player's typing into its buffer as it draws: filtering
-- before it runs would answer for the text as it stood last frame, and the
-- count beside the box would disagree with the table under it (the dwtoau
-- ordering, kept).
local function shelfFindBox()
    imgui.PushItemWidth(px(200));
    imgui.InputTextWithHint('##dwraid_shop_find', 'find an item...', state.find, 40);
    imgui.PopItemWidth();
    tip(TIPS.find);
end

-- Everything that has to know what the filter kept: a Clear while the box
-- holds anything, a copy of what is on screen, and the count that says
-- whether a search which found nothing found nothing or simply narrowed hard.
local function shelfFindExtras(shown, term)
    if (term ~= '') then
        sameLineIfFits('Clear');

        if (imgui.SmallButton('Clear##dwraid_shop_clear')) then
            state.find[1] = '';
        end

        tip(TIPS.clearFind);
    end

    -- Guarded per the dwtheme skew rule: an Ashita generation without the
    -- clipboard call must not grow a button that throws inside the render
    -- pcall and closes the window.
    if (type(imgui.SetClipboardText) == 'function' and #shown > 0) then
        sameLineIfFits('Copy');

        if (imgui.SmallButton('Copy##dwraid_shop_copy')) then
            local lines = T{ };

            for _, row in ipairs(shown) do
                lines:append(string.format('%s -- %d driftmarks', row.label, row.price));
            end

            pcall(imgui.SetClipboardText, table.concat(lines, '\n'));
        end

        tip(TIPS.copy);
    end

    if (term ~= '') then
        sameLineIfFits(shopCountText);
        imgui.TextDisabled(shopCountText);
    end
end

--[[
* THE SHELF'S ORDER (1.12.0), in the bracket-button idiom the element, fight
* and page strips already wear, so a third row of the same shape reads as the
* same control rather than as a new one.
*
* Why it is worth a control at all: the shelf runs to forty rows on a page,
* prices run from twenty driftmarks to a few thousand, and the one
* question a purse asks -- "what can I afford right now" -- has no answer in
* a list ordered by an index the window does not even draw. Ascending price
* IS that answer. The order is remembered per PC beside the text size, which
* is the other thing about this window a player sets once.
*
* It is presentation and nothing else: Buy still carries the row's own shelf
* index, which the server owns and which never renumbers, so a sorted window
* and a typed `!raid buy 20` mean exactly the same row.
--]]
-- The two strings each tab draws with are constants of this file, so they are
-- spelled once here rather than being rebuilt per button per frame -- the
-- same rule the element, fight and page strips were moved onto in 1.11.0.
local SORT_TABS = {
    { word = 'shelf', label = 'Shelf',
      bracket = '[ Shelf ]', buttonId = 'Shelf##dwraid_sort_shelf' },
    { word = 'name',  label = 'Name',
      bracket = '[ Name ]',  buttonId = 'Name##dwraid_sort_name' },
    { word = 'price', label = 'Price',
      bracket = '[ Price ]', buttonId = 'Price##dwraid_sort_price' },
};

local function shelfSortBlock()
    local order = sortMode();

    imgui.TextDisabled('Order:');

    for _, entry in ipairs(SORT_TABS) do
        if (entry.word == order) then
            sameLineIfFits(entry.bracket);
            imgui.TextColored(theme.colors.ok, entry.bracket);
        else
            sameLineIfFits(entry.label);

            if (imgui.Button(entry.buttonId)) then
                config.shopSort = entry.word;

                pcall(settings.save);
            end

            tip(TIPS.sort);
        end
    end
end

local SHOP_COLUMNS = {
    { label = 'Item',  tip = TIPS.colItem },
    { label = 'Price', tip = TIPS.colPrice, width = 70 },
    { label = '',                           width = 60 },
};

local function shopBlock()
    if (next(state.shop) == nil) then
        imgui.TextDisabled('No shop data yet.');
        tip(TIPS.noShop);

        return;
    end

    shopPagesBlock();

    -- The forge face replaces the shelf while its tab is open -- it is a
    -- view of the BAG, not of the s| directory the table below renders.
    if (state.pageSel == REFORGE_PAGE) then
        if (not reforgeOffered()) then
            -- A refresh took the elite page away (a rollback, a story
            -- regression): fall back to the first shelf rather than
            -- stranding the view on a tab that no longer draws.
            state.pageSel = 1;
        else
            reforgeBlock();

            return;
        end
    end

    -- Paged when the server sent a directory, flat when it did not.
    local paged = next(state.pages) ~= nil;

    shelfSortBlock();
    shelfFindBox();

    local shown, term = shelfRows(paged);

    shelfFindExtras(shown, term);

    -- A purse the shelf can be measured against. THE SERVER STILL OWNS THE
    -- REFUSAL -- this is a courtesy, so a player reads the wall before they
    -- press it rather than after. A branch, not `a and b or nil`: a balance
    -- of zero is a real balance, and the idiom only happens to survive it
    -- because zero is truthy in Lua.
    local balance = nil;

    if (state.purse ~= nil) then
        balance = state.purse.balance;
    end

    if (imgui.BeginTable('##dwraid_shop', #SHOP_COLUMNS, TABLE_FLAGS, TABLE_SIZE)) then
        tableHead(SHOP_COLUMNS);

        for _, row in ipairs(shown) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            -- The icon, then the label -- and the hover card on either.
            -- drawIcon leaves the cursor on the same line, and
            -- IsItemHovered reads the LAST item, so the icon's hover is
            -- taken before the label is drawn.
            drawIcon(row.itemid, px(20));

            local hovered = imgui.IsItemHovered();

            imgui.Text(row.label);

            if (imgui.IsItemHovered() or hovered) then
                itemTooltip(row);
            end

            imgui.TableNextColumn();

            if (balance ~= nil and row.price > balance) then
                imgui.TextColored(theme.colors.err, row.priceText);
                tip(TIPS.dear);
            else
                imgui.Text(row.priceText);
            end

            imgui.TableNextColumn();

            if (imgui.Button(row.buttonId)) then
                state.status    = string.format('Asking for a quote on %s...', row.label);
                state.statusBad = false;

                issue(string.format('!dwx buy %d', row.index));
            end

            tip(TIPS.buy);
        end

        imgui.EndTable();
    end

    if (#shown == 0 and term ~= '') then
        imgui.TextDisabled('Nothing on this shelf matches. Clear the find box, or try another page.');
    end

    if (state.quote ~= nil) then
        local left = state.quote.deadline - os.clock();

        if (left > 0) then
            if (imgui.Button(state.quote.buttonLabel)) then
                state.quote = nil;

                issue('!dwx confirm');

                -- The purse rides back on the confirm envelope; the movement
                -- does not. Ask for the one envelope that carries both.
                refreshLedger();
            end

            tip(TIPS.confirm);

            imgui.SameLine();
            imgui.TextDisabled(string.format('%ds left on the quote', math.floor(left)));
        elseif (not expiredNote(left)) then
            state.quote = nil;
        end
    end
end

local function renderWindow()
    -- The text-size slider (1.7.0, the mockup's top row). Percent in the
    -- widget, a scale in the config; the scale takes effect the frame it
    -- moves, and the FILE is written once the handle is let go rather than on
    -- every frame of the drag (1.12.0 -- see CAN_ITEM_ACTIVE).
    imgui.TextDisabled('Text size:');
    imgui.SameLine();
    imgui.PushItemWidth(px(140));

    if (imgui.SliderFloat('##dwraid_textscale', uiTextScale, 80, 160, '%.0f%%')) then
        -- The scale itself takes effect this frame; only the file write
        -- waits for the handle to be let go (see CAN_ITEM_ACTIVE).
        config.textScale = (tonumber(uiTextScale[1]) or 100) / 100;
        scaleUnsaved     = true;
    end

    -- Both calls read the item just submitted, so this stays on the line
    -- after the slider and before anything else is drawn.
    if (scaleUnsaved and not (CAN_ITEM_ACTIVE and imgui.IsItemActive())) then
        scaleUnsaved = false;

        pcall(settings.save);
    end

    tip(TIPS.scale);

    imgui.PopItemWidth();

    if (imgui.Button('Refresh')) then
        serverSilent = false;

        forget();
        requestStatus();
    end

    --[[
    * The Refresh hover carries its own clock (1.11.0, the dwnemesis shape).
    * The arena count is the part of this board that goes stale fastest -- a
    * run starts or ends without anything on screen moving -- and "how old is
    * what I am looking at" had no answer anywhere in the window.
    *
    * And a Refresh that CANNOT help says so instead: after a version
    * mismatch the server is answering perfectly well and this addon still
    * cannot read it, so pressing again is the one thing that will not fix
    * anything.
    --]]
    if (imgui.IsItemHovered()) then
        if (state.protoBad) then
            imgui.SetTooltip(TIPS.refreshStale);
        elseif (state.syncedAt == nil) then
            imgui.SetTooltip(TIPS.refresh);
        else
            imgui.SetTooltip(string.format('%s Last answer %d second(s) ago.',
                TIPS.refresh, math.max(0, math.floor(os.clock() - state.syncedAt))));
        end
    end

    sameLineIfFits('Leave the arena');

    if (imgui.Button('Leave the arena')) then
        state.status    = 'Asking to leave...';
        state.statusBad = false;

        issue('!dwx leave');
    end

    tip(TIPS.leave);

    if (#queue > 0) then
        sameLineIfFits('99 queued...');
        imgui.TextDisabled(string.format('%d queued...', #queue));
        tip(TIPS.queued);
    end

    -- WRAPPED, NOT CLIPPED (1.11.0). The status line is whatever sentence the
    -- server last said, and its longest refusals run past eighty characters
    -- -- "That shelf opens when Chains of Promathia is behind you. Finish the
    -- story first." does not fit a default-width window at any text size, and
    -- a refusal cut off before its reason is worse than no refusal at all.
    if (state.status ~= nil and state.status ~= '') then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok,
            state.status);
        imgui.PopTextWrapPos();
    end

    imgui.Separator();

    purseBlock();
    arenaBlock();
    todayBlock();

    sectionHeader('The trials -- gather your party anywhere and go.');

    elementsBlock();
    fightsBlock();
    tiersBlock();

    sectionHeader('The Driftmark shop -- hover an item for its card.');

    shopBlock();

    sectionHeader('Recent movements');

    ledgerBlock();
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape, and its
* reasoning, kept verbatim).
--]]
ashita.events.register('d3d_present', 'dwraid_present', function ()
    -- Before the visibility check: a sync requested by a zone-in still has
    -- to reach the server with the window shut.
    if (state.syncAt ~= nil and os.clock() >= state.syncAt) then
        -- A typed line handed to a client that is still zoning is not
        -- delayed, it is LOST. The client's own zoning flag is the fact;
        -- wait it out (dwfame's lesson, kept verbatim).
        --
        -- THE MEMORY MANAGER IS ASKED FOR, NOT ASSUMED (2026-09-06). This
        -- runs OUTSIDE the render pcall -- it has to, a sync scheduled by a
        -- zone-in still has to reach the server with the window shut -- so a
        -- nil here is not a lost frame, it is the addon host unloading
        -- dwraid. And a nil player now WAITS rather than firing: no player
        -- means not in the world, and a chat line sent there is a chat line
        -- lost, which is the same fact the zoning flag states.
        local memory = AshitaCore:GetMemoryManager();
        local player = memory ~= nil and memory:GetPlayer() or nil;

        if (player == nil or player:GetIsZoning() ~= 0) then
            state.syncAt   = os.clock() + 1.0;
            state.syncSlot = nil;
        elseif (state.syncSlot == nil) then
            -- Zoning done. Every sibling clears its zoning flag on the SAME
            -- frame, so hold this addon's stagger slot before firing or the
            -- zone-in syncs collide at the client's chat throttle and all but
            -- one come back "A command error occurred." (dwecho.lua's ZONE_ORDER
            -- is the shared slot order; 2026-08-14).
            state.syncSlot = os.clock() + echo.zoneSlot('dwraid') * echo.SEND_INTERVAL;
            state.syncAt   = state.syncSlot;
        else
            state.syncAt   = nil;
            state.syncSlot = nil;

            -- THE SILENCE LATCH IS RE-READ AT THE MOMENT OF FIRING, not only
            -- at the moment of scheduling (2026-09-06). Between the two there
            -- are eight seconds in which the server can prove it does not
            -- speak dwraid -- the player types `!raid` and gets "The raid is
            -- not loaded", or an outstanding ask gives up -- and the sync
            -- scheduled before that proof went out anyway. On a server
            -- without dwx.lua an unknown `!` command IS public /say, so the
            -- one thing this latch exists to prevent is the player saying
            -- "!dwx status" out loud to whoever is standing nearby.
            if (not serverSilent) then
                forget();
                requestStatus();
            end
        end
    end

    -- Answer tracking runs whether or not the window is open: it is exactly
    -- the window-closed zone-in auto-syncs that must stop when the server
    -- has gone silent (an unknown !command here is /say chat).
    checkAnswers();

    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    -- AND THE FIRST-USE SIZE RIDES px() TOO (1.12.0). Every other measurement
    -- in this window is scaled -- the four tier columns, the shop columns, the
    -- wrap points, the icons, the size floor below -- and this one literal was
    -- not, so a player who had settled on 140% text got their first window at
    -- the 100% box: 250 pixels of px()-scaled fixed columns in the tier table
    -- alone became 400, and "First of the day" was clipped in its own header
    -- before a single row drew. It is FirstUseEver, so this only ever decides
    -- the box a player is handed before they size it themselves -- which is
    -- exactly the moment it should be the right one.
    imgui.SetNextWindowSize({ px(540), px(580) }, ImGuiCond_FirstUseEver);

    -- A FLOOR UNDER THE DRAG (1.11.0). Nothing stopped a player from pulling
    -- this window down to a title bar: the tier table's four columns are
    -- sized in px() and the page strip wraps against the window width, so
    -- below about four hundred pixels the Enter column is the first thing off
    -- the edge and there is no scroll that reaches it sideways. The floor
    -- rides px() too, so it follows the text-size slider rather than fighting
    -- it. Declared in Ashita's SDK and already used by dwnemesis.
    if (CAN_CONSTRAIN) then
        imgui.SetNextWindowSizeConstraints({ px(420), px(240) }, { 99999, 99999 });
    end

    -- NoDocking: dragging one Driftwood window onto another used to fuse
    -- them into a single unthemed dock that imgui.ini kept across reloads.
    -- The scrollbar came back in 1.4.0: the tier headers, the shop headers
    -- and the hover-card shelf grew the content taller than the old fixed
    -- fit, and clipping the ledger with no way to reach it is worse than a
    -- scrollbar (the window resizes; the bar is for people who shrink it).
    local visible = imgui.Begin('DriftwoodXI Raid##dwraid', state.open, ImGuiWindowFlags_NoDocking);

    -- The whole window follows the slider through ImGui's own per-window
    -- font scale, applied after Begin (it belongs to the current window) and
    -- reset before End so the scale cannot leak into another window sharing
    -- this ImGui state. Guarded per the dwtheme skew rule: Ashita installs
    -- differ across generations, and a missing function must degrade to the
    -- stock size rather than close the window through the render pcall.
    local scaled = visible and scaleOf() ~= 1.0 and type(imgui.SetWindowFontScale) == 'function';

    if (scaled) then
        imgui.SetWindowFontScale(scaleOf());
    end

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwraid'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwraid'):append(chat.message('Window closed. `!raid` typed by hand says the same things.')));
            end
        end
    end

    if (scaled) then
        imgui.SetWindowFontScale(1.0);
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs: a window showing the purse
* as it stood two clears ago is the quiet kind of wrong this project exists
* to rule out, and a sync costs one chat line.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting, and for the
        -- silent-server detection: opening the window is the deliberate
        -- act that earns one more try.
        state.reported = false;
        serverSilent   = false;

        forget();
        requestStatus();
    end
end

--[[
* THE SLASH DOOR, and what it does with words it was not expecting.
*
* Until 1.11.0 anything after `/raid` that was not `refresh` fell through to a
* plain toggle -- so `/raid enter tidebound savage`, which is a perfectly
* reasonable thing to type, silently opened or CLOSED the window and said
* nothing about the fact that the server verbs live behind `!`. Two changes,
* both borrowed from dwnemesis' own reasoning: a player who typed something
* has said what they want, so the window OPENS rather than toggling, and the
* one line that would have saved them is printed. `/raid find <text>` opens
* the board on a shelf search, which is the only argument this addon can
* honestly answer itself.
--]]
local function openWindow()
    if (not state.open[1]) then
        toggleWindow();
    end
end

ashita.events.register('command', 'dwraid_command', function (e)
    local args = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwraid' and first ~= '/raid' and first ~= '/dwx') then
        return;
    end

    e.blocked = true;

    if (#args < 2) then
        toggleWindow();

        return;
    end

    local verb = args[2]:lower();

    if (verb == 'refresh' or verb == 'sync') then
        serverSilent = false;

        forget();
        requestStatus();

        return;
    end

    if (verb == 'find' or verb == 'search') then
        local words = { };

        for index = 3, #args do
            words[#words + 1] = args[index];
        end

        -- Non-printables dropped and the text cut to the input buffer's own
        -- size: what goes in here is what the widget hands back next frame.
        state.find[1] = (table.concat(words, ' '):gsub('[^\032-\126]', '')):sub(1, 39);

        -- The forge tab draws no shelf, so a search typed while it is open
        -- has to come back to one. Written as a branch rather than
        -- `a and b or c`: that idiom silently collapses whenever its middle
        -- term can be false or nil, which is exactly how the Promyvion story
        -- lock came to be dead from the day it shipped -- and a reader should
        -- not have to work out whether this one is safe.
        if (state.pageSel == REFORGE_PAGE) then
            state.pageSel = 1;
        end

        openWindow();

        return;
    end

    openWindow();

    print(chat.header('dwraid'):append(chat.message(
        '/raid opens the board; /raid refresh re-syncs; /raid find <text> searches the shelf. '
        .. 'The server verbs are typed with an exclamation mark -- !raid enter tidebound savage, !raid leave, !raid shop.')));
end);

--[[
* Sync on login and zone-in (0x000A serves both) -- and for this addon the
* zone-in IS the payoff moment: entering the arena, leaving it, and the
* return warp are all zone changes, so the window refreshes itself exactly
* when the purse and the arena state just changed. Everything server-derived
* resets first -- a login may be a different character.
--]]
ashita.events.register('packet_in', 'dwraid_zonein', function (e)
    if (e.id == 0x000A) then
        state.purse     = nil;
        state.purseText = nil;
        state.arena     = nil;
        -- runs, taken and board were the three server-derived tables this
        -- wipe missed (2026-09-06). Nothing rendered them while the rest of
        -- the board was empty, so the omission never showed -- but the block
        -- above this handler promises that EVERYTHING server-derived resets,
        -- because a login may be a different character, and a promise the
        -- code does not keep is the next bug's hiding place.
        state.runs      = T{ };
        state.venues    = T{ }; -- the v| directory (1.15.0), server-derived like the runs it names
        state.taken     = T{ };
        state.board     = nil;
        state.fights    = T{ };
        --[[
        * THE SELECTION IS NOT SERVER-DERIVED AND NO LONGER RESETS WITH IT
        * (1.12.0). `fightSel` and `pageSel` are what the player pointed at,
        * and this file already has a rule about them -- the status and shop
        * commits both keep the selection "unless its fight is gone" / "unless
        * its page is gone", validated against the answer that just landed.
        * The zone-in wipe broke that rule for the one moment it matters most:
        * entering the arena, leaving it and the return warp are ALL zone
        * changes, so a player who wiped on the Howlmane Manticore came back
        * to the Tidebound Colossus, and one who was spending marks on the
        * Elite shelf came back to Supplies -- every time.
        *
        * Nothing stale can show through: both tables are emptied on this line,
        * so every block that could read the selection renders its empty state
        * until the commit re-validates it, and a login as a different
        * character is exactly the commit that does the validating.
        *
        * The element tab is the one selection that DOES clear, because it is
        * not a choice this addon stores -- it is re-derived from the selected
        * fight every time the roster commits.
        --]]
        state.elemSel   = nil;
        state.tiers     = T{ };
        state.ledger    = T{ };
        state.day       = nil;
        state.ladder    = T{ };
        state.repeats   = T{ };
        state.chain     = nil;
        state.today     = nil;
        state.nextPay   = T{ };
        state.shop         = T{ };
        state.pages        = T{ };
        -- The find box does clear: a search is a momentary act on a shelf,
        -- not a place in the window the player chose to be.
        state.find[1]      = '';
        state.quote        = nil;
        state.reforge      = nil;
        state.reforgeAt    = nil;
        state.reforgeQuote = nil;
        state.building     = nil;
        state.inbound      = nil;
        state.protoBad     = false;
        state.syncedAt     = nil;
        state.status       = 'Syncing...';
        state.statusBad    = false;

        -- The additive-verb latch is a fact about the SERVER, and 0x000A is
        -- the only moment this addon learns it may be talking to a different
        -- one (dwbags' rule): a server updated under the player earns a fresh
        -- try rather than being written off for the session.
        marksUnsupported   = false;

        -- Every view cache reads one of the tables just emptied, so each one
        -- is invalidated by the same line that empties it.
        rosterRev = rosterRev + 1;
        shopRev   = shopRev + 1;

        -- The item-name cache goes with the zone rather than living for the
        -- session (dwnemesis' rule): an id the resource manager could not
        -- answer for at login resolves the next time the player zones.
        nameCache = { };

        -- And the icon cache drops its FAILURES only. A loaded texture is
        -- expensive and never changes, but a `false` here means "the resource
        -- manager did not answer for this id THIS TIME" -- pinning that for
        -- the session left a row drawn during a load screen with no icon
        -- until the addon was reloaded. Assigning nil to the key currently
        -- being visited is the one table mutation pairs() allows.
        for id, texture in pairs(icons) do
            if (texture == false) then
                icons[id] = nil;
            end
        end

        forget();

        -- AND THE STAGGER SLOT IS RE-ARMED WITH IT (2026-09-06). syncSlot is
        -- the latch that says "the ZONE_ORDER wait has already been served";
        -- it was cleared when a sync fired but not when a NEW zone line
        -- arrived, so a second zone within the eight seconds the first one
        -- waits -- a player stepping back across a zone line, or the raid's
        -- own entry warp landing on top of an ordinary zone change -- found
        -- the latch still set and fired the moment its four seconds were up,
        -- with no stagger at all. That is slot zero's instant, shared with
        -- every sibling addon that zoned at the same time, and the client's
        -- chat throttle answers all but one of them with "A command error
        -- occurred." -- which is the exact failure ZONE_ORDER exists to
        -- prevent (dwecho.lua, 2026-08-14).
        state.syncSlot = nil;

        -- No auto-sync against a server that has shown it does not speak
        -- dwraid: an unknown !command falls through to /say here, so each
        -- retry would be the player chatting "!dwx status" at whoever is
        -- nearby. Opening the window retries deliberately.
        if (not serverSilent) then
            state.syncAt = os.clock() + 4.0;
        else
            state.status = 'Raid board paused (no answer from the server). Open the window to retry.';
        end
    end
end);

--[[
* Watch what the player sends.
*
* Bare `!raid` (and the ui/window/gui spellings of `!dwx`) toggles this
* window instead of going to the server -- the server verb is the name
* players learn, so it has to be a door and not a dead end. `!raid enter`
* and every argumented form still pass through untouched; that is the
* escape hatch this addon's header promises.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped
* (dwbags' lesson, kept verbatim).
--]]
ashita.events.register('packet_out', 'dwraid_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!raid' or lower == '!dwx' or
        lower == '!dwx ui' or lower == '!dwx window' or lower == '!dwx gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwx') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwraid_load', function ()
    print(chat.header('dwraid'):append(chat.message('/raid, /dwraid or !raid opens the raid board.')));
end);
