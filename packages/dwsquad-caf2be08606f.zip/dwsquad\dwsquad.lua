--[[
* DriftwoodXI -- dwsquad
*
* Your squad in a window: every character on the account listed by name, job
* and level, with the five squad slots beside them -- add and remove members
* by clicking instead of remembering names and typing !squad set.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no roster of its own, caches nothing to disk, and has no way to
* change a squad the typed command surface could not. Every read is `!dws who`
* and every write is `!dws set|clear`, which reach exactly the same server
* functions `!squad set|clear` reach -- the only difference is that they
* answer in compact records under the sender name _DWSDATA, which this addon
* parses and blocks before the chat log sees them. The Call and Dismiss
* buttons send the literal `!squad call` and `!squad dismiss` a player would
* type, because their output is narrative and belongs in the chat log.
*
* That constraint is deliberate and it is the reason a UI could be shipped at
* all: a bug in here cannot register a character the server would have
* refused, because it is not doing anything the typed command does not do.
* The ownership check lives in the server's C++ and runs identically
* whichever way the command arrived.
*
* TYPING `!squad` ON ITS OWN NOW OPENS THIS WINDOW. The line is intercepted
* before it leaves the client, so the server never sees it; every other
* !squad command passes through untouched. With the addon off, `!squad`
* prints its usage text exactly as before.
*
* TURN IT OFF AND NOTHING IS LOST. `!squad set <slot> <name>`, `!squad clear
* <slot>`, `!squad list`, `!squad call` and `!squad dismiss` all work typed.
* This is friendlier; it is not required.
--]]

addon.name    = 'dwsquad';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.1';
addon.desc    = 'Squad roster window for DriftwoodXI -- add and remove members by clicking.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. dwbags
-- owns _DWDATA and dwgambits owns _DWGDATA; this addon must never contend for
-- either, which is why !dws exists at all.
local DATA_SENDER = '_DWSDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

local MAX_SLOTS = 5;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Character flag bits, as the server packs them.
local CHAR_ONLINE = 1;
local CHAR_LOCKED = 2;
local CHAR_SELF   = 4;

local state = T{
    open      = T{ false },

    -- Replaced wholesale by a `who` response, never merged, so a stale row
    -- cannot survive a refresh.
    chars     = T{ },

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its own
    -- cannot half-fill the UI.
    inbound   = nil,
    status    = 'Loading...',
    statusBad = false,
    reported  = false,     -- a render error is worth saying once, not per frame
};

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A
* TIME. The client rate-limits outgoing chat, and a !dws command is a chat
* line; anything over the limit is answered with "A command error occurred"
* before the server ever sees it. So everything queues here and drains at one
* command per SEND_INTERVAL, and duplicates collapse.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a window drawn sixty times a second asks
* once. THE ANSWER IS TRACKED, NOT JUST THE QUESTION: a command issued in the
* same instant as something the player typed can be eaten by the client's
* chat throttle, and one lost command must not leave the panel stale for
* ever. An unanswered request is asked once more after ANSWER_TIMEOUT and
* then left alone -- a retry that never terminates is a command loop, which
* is worse than a stale panel.
*
* A PLAIN TABLE, NOT `T{ }`: this table is keyed by verb names, and a `T{ }`
* resolves unknown keys through its metatable to the sugar table methods --
* which is exactly the dwbags round-7 bug, paid for once already.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

local function refresh()
    requested = {};
end

-- A write's response carries the fresh roster, so the roster question is
-- registered as pending without being asked: if the write's answer is lost,
-- needRoster's retry covers it.
local function expectRoster()
    requested['who'] = { at = os.clock(), answered = false, tries = 1 };
end

local function needRoster()
    local asked = requested['who'];

    if (asked ~= nil) then
        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['who'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dws who');
end

--[[
* Record parsing. Every record is pipe-separated with a single-character
* type. Anything this addon does not recognise is ignored rather than being
* an error: a server newer than the addon must not break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwsquad.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright, and the reset runs
        -- FIRST: handleRecord is called under a pcall, and anything that
        -- throws after `state.inbound` is set must cost one record, not leave
        -- old rows for the records behind it to append to.
        if (state.inbound == 'who') then
            state.chars = T{ };

            local asked = requested['who'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- message saying why a change was refused is worth more than the response
    -- it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- Everything after the first pipe, not parts[2]: these carry prose.
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        -- Errors also go to the chat log: the window may already be closed,
        -- and "nothing happened" is the worst possible feedback.
        if (kind == 'e') then
            print(chat.header('dwsquad'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        -- The roster arriving is the moment "Loading..." stops being true.
        if (state.inbound == 'who' and state.status == 'Loading...') then
            state.status = '';
        end

        state.inbound = nil;

        return;
    end

    if (kind == 'c' and state.inbound == 'who') then
        local charid = tonumber(parts[2]) or 0;

        -- Fields 9 and 10 are bag used/size, which this window has no use
        -- for; field 11 is the squad slot, which is its whole subject.
        state.chars[charid] = T{
            charid = charid,
            name   = parts[3],
            mjob   = tonumber(parts[4]) or 0,
            mlvl   = tonumber(parts[5]) or 0,
            sjob   = tonumber(parts[6]) or 0,
            slvl   = tonumber(parts[7]) or 0,
            flags  = tonumber(parts[8]) or 0,
            slot   = tonumber(parts[11]) or 0,
        };

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Layout after the 4-byte header: sName[15]
* at 0x08, Mes at 0x17. Any line whose sender is _DWSDATA is ours: it is
* consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwsquad_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwsquad'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Helpers over the roster.
--]]

-- Characters in charid order, which is creation order and is stable.
local function orderedChars()
    local ordered = T{ };

    for _, member in pairs(state.chars) do
        ordered:append(member);
    end

    table.sort(ordered, function (a, b) return a.charid < b.charid; end);

    return ordered;
end

local function jobsOf(member)
    local text = string.format('%s%d', JOB_NAMES[member.mjob] or '?', member.mlvl);

    if (member.sjob ~= 0 and member.slvl ~= 0) then
        text = text .. string.format('/%s%d', JOB_NAMES[member.sjob] or '?', member.slvl);
    end

    return text;
end

local function isSelf(member)
    return bit.band(member.flags, CHAR_SELF) ~= 0;
end

local function tagOf(member)
    if (isSelf(member)) then
        return '(you)';
    elseif (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
        return '[summoned]';
    elseif (bit.band(member.flags, CHAR_ONLINE) ~= 0) then
        return '[logged in]';
    end

    return '';
end

-- [slot] = member, from the flat character list.
local function slotView()
    local slots = T{ };

    for _, member in pairs(state.chars) do
        if (member.slot >= 1 and member.slot <= MAX_SLOTS) then
            slots[member.slot] = member;
        end
    end

    return slots;
end

local function firstEmptySlot()
    local slots = slotView();

    for slot = 1, MAX_SLOTS do
        if (slots[slot] == nil) then
            return slot;
        end
    end

    return nil;
end

--[[
* Writes. Every one is the same server command a player could type, queued
* through the throttle, with the roster registered as an expected answer so a
* lost response is re-asked rather than trusted.
--]]
local function assign(slot, member)
    issue(string.format('!dws set %d %s', slot, member.name));
    expectRoster();

    state.status    = string.format('Adding %s to slot %d...', member.name, slot);
    state.statusBad = false;
end

local function unassign(slot, member)
    issue(string.format('!dws clear %d', slot));
    expectRoster();

    state.status    = string.format('Removing %s from slot %d...', member.name, slot);
    state.statusBad = false;
end

--[[
* Rendering.
--]]

-- The dropdown a click on an empty slot opens: every character that is
-- neither the one being played nor already in a slot. EVERY WIDGET ID
-- CARRIES THE CHARACTER ID, because two Selectables with the same label in
-- one combo would merge their click handling.
local function emptySlotCombo(slot)
    imgui.PushItemWidth(-1);

    if (imgui.BeginCombo(string.format('##dwsquad_add_%d', slot), '(empty -- click to add)')) then
        local offered = 0;

        for _, member in ipairs(orderedChars()) do
            if (not isSelf(member) and member.slot == 0) then
                offered = offered + 1;

                if (imgui.Selectable(string.format('%s  %s##add_%d_%d',
                        member.name, jobsOf(member), slot, member.charid))) then
                    assign(slot, member);
                end
            end
        end

        if (offered == 0) then
            imgui.TextDisabled('Every other character is already in the squad.');
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
end

local function squadPanel()
    -- NOTE: the third argument is ImGuiChildFlags, not a bool -- Ashita ships
    -- ImGui 1.90+, and a bool here raises a Lua error on every frame.
    imgui.BeginChild('##dwsquad_slots', { 300, 0 }, ImGuiChildFlags_Borders);

    imgui.Text('Your squad');
    imgui.SameLine();
    imgui.TextDisabled('-- summoned as trusts by !squad call');
    imgui.Separator();

    local slots = slotView();

    if (imgui.BeginTable('##dwsquad_slot_table', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        -- WidthFixed throughout, like dwbags and dwgambits: only the flags
        -- those two already use are proven to exist in this environment's
        -- ImGui bindings, and a nil flag global is a Lua error per frame.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 18, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 190, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 62, 0);

        for slot = 1, MAX_SLOTS do
            local member = slots[slot];

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(string.format('%d.', slot));

            imgui.TableNextColumn();

            if (member ~= nil) then
                imgui.Text(member.name);
                imgui.SameLine();
                imgui.TextDisabled(jobsOf(member));

                local tag = tagOf(member);

                if (tag ~= '') then
                    imgui.SameLine();
                    imgui.TextDisabled(tag);
                end
            else
                emptySlotCombo(slot);
            end

            imgui.TableNextColumn();

            if (member ~= nil) then
                if (imgui.SmallButton(string.format('Remove##slot_%d', slot))) then
                    unassign(slot, member);
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Un-register %s from slot %d', member.name, slot));
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

local function charactersPanel()
    imgui.BeginChild('##dwsquad_chars', { 0, 0 }, ImGuiChildFlags_Borders);

    imgui.Text('Your characters');
    imgui.SameLine();
    imgui.TextDisabled('-- everyone on this account');
    imgui.Separator();

    local empty = firstEmptySlot();

    if (imgui.BeginTable('##dwsquad_char_table', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY), { -1, -1 })) then
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 76, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 62, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, member in ipairs(orderedChars()) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(member.name);

            imgui.TableNextColumn();
            imgui.TextDisabled(jobsOf(member));

            imgui.TableNextColumn();

            if (member.slot > 0) then
                imgui.TextDisabled(string.format('slot %d', member.slot));
            else
                imgui.TextDisabled(tagOf(member));
            end

            imgui.TableNextColumn();

            if (isSelf(member)) then
                -- The character being played cannot be its own trust; the
                -- server refuses it, so the button is not offered.
                imgui.TextDisabled('');
            elseif (member.slot > 0) then
                if (imgui.SmallButton(string.format('Remove##c_%d', member.charid))) then
                    unassign(member.slot, member);
                end
            elseif (empty ~= nil) then
                if (imgui.SmallButton(string.format('Add##c_%d', member.charid))) then
                    assign(empty, member);
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Add %s to slot %d', member.name, empty));
                end
            else
                imgui.TextDisabled('full');
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

local function renderWindow()
    if (imgui.Button('Call squad')) then
        -- The literal typed command: its narrative -- who answered, who was
        -- refused and why -- belongs in the chat log. The outgoing watcher
        -- below sees the line and refreshes the roster behind it.
        issue('!squad call');

        state.status    = 'Calling the squad...';
        state.statusBad = false;
    end

    imgui.SameLine();

    if (imgui.Button('Dismiss')) then
        issue('!squad dismiss');

        state.status    = 'Dismissing...';
        state.statusBad = false;
    end

    imgui.SameLine();

    if (imgui.Button('Refresh')) then
        refresh();
    end

    imgui.SameLine();

    -- A throttled queue has to look like progress rather than like nothing
    -- happening.
    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    else
        imgui.TextDisabled('');
    end

    -- The message line gets its own row, and errors are red: the reason a
    -- change was refused is the only thing telling a player what to do
    -- instead.
    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Separator();

    squadPanel();
    imgui.SameLine();
    charactersPanel();

    needRoster();
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather
* than the addon: an error thrown inside d3d_present is raised sixty times a
* second and the addon host answers a long enough run by unloading the addon.
* Begin and End stay outside the pcall to keep ImGui's window stack balanced;
* the error is reported once and the window closes itself. Everything it does
* is still reachable as !squad commands, so closing it is a real fallback.
--]]
ashita.events.register('d3d_present', 'dwsquad_present', function ()
    -- Before the visibility check: a click issued a moment before the window
    -- was closed still has to reach the server.
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    imgui.SetNextWindowSize({ 660, 320 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Squad##dwsquad', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwsquad'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwsquad'):append(chat.message('Window closed. Everything it does also works as !squad commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1] = true;

    -- Reopening is a fresh start for error reporting too: `reported` only
    -- exists to stop one bad frame printing sixty lines a second.
    state.reported  = false;
    state.status    = 'Loading...';
    state.statusBad = false;

    refresh();
end

--[[
* Watch what the player sends.
*
* Bare `!squad` (and `!squad ui`) is intercepted and opens this window
* instead of printing the server's usage text -- that line is blocked and
* never leaves the client. Every other `!squad` command passes through and
* invalidates the roster behind it, so `!squad set` typed by hand keeps the
* window honest.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped. Stamping
* the player's own line as a send makes the follow-up wait its interval.
--]]
ashita.events.register('packet_out', 'dwsquad_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!squad' or lower == '!squad ui' or lower == '!squad window' or lower == '!squad gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dws') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 6) == '!squad') then
        refresh();
    end
end);

ashita.events.register('command', 'dwsquad_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwsquad' and args[1] ~= '/squad')) then
        return;
    end

    e.blocked = true;

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

ashita.events.register('load', 'dwsquad_load', function ()
    print(chat.header('dwsquad'):append(chat.message('!squad (or /squad) opens the squad window. Everything it does also works typed as !squad commands.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new account view.
ashita.events.register('packet_in', 'dwsquad_zonein', function (e)
    if (e.id == 0x000A) then
        state.chars     = T{ };
        state.status    = 'Loading...';
        state.statusBad = false;

        refresh();
    end
end);
