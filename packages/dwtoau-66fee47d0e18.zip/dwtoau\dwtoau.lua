--[[
* DriftwoodXI -- dwtoau
*
* The ToAU job kit: the three Treasures of Aht Urhgan jobs need a hand a
* squad alt-trust cannot give itself. A BLUE MAGE casts only what it has
* SET; a PUPPETMASTER fights with the automaton it BUILT; a CORSAIR's rolls
* are pressed by hand when the moment calls for them. A logged-in character
* does all three from the client's own menus; a squad member is never logged
* in. This window is the door the master uses instead.
*
*   Blue Mage tab     pick a squad blue mage, tick spells from everything
*                     the account knows (level, set points and kind on every
*                     row), watch the slot and point budget, Apply. Two
*                     hundred rows read in the server's order, by name, by
*                     level or BY SET POINTS -- the last being the question
*                     no filter box can answer ("what still fits in the four
*                     I have left").
*   Puppetmaster tab  frame, head, twelve attachment slots, the per-element
*                     capacity bars, everything the account has unlocked --
*                     in the server's order, by name, or by the total element
*                     capacity a part spends; Apply writes the build,
*                     Deactivate puts an active automaton away so it can be
*                     re-equipped.
*   Corsair tab       every corsair out, the rolls it can press as buttons,
*                     its Double-Up window while one is open, and the rolls
*                     sitting on you right now with their numbers and clocks.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no budget arithmetic and no unlock table: slots, points, levels,
* capacities and unlocks all ride the wire (`!dwk`, sender _DWKDATA,
* documentation/dwk_protocol.md), and an Apply clicked here reaches exactly
* the xi.dwToau.writeBlue / writeAutomaton that `!toau blu Yakapo set
* head_butt` typed reaches -- the account check, the online rule, the
* budget, the level gate, the unlocks and the capacity are the server's to
* enforce (cpp/squad_toau.cpp), and this window's greyed buttons are a
* courtesy, not the authority. Names are the client's own: spells and
* attachments are drawn from the resource manager by id, so the wire carries
* numbers and the window says words.
*
* EDITS ARE LOCAL UNTIL APPLY, and Apply sends the WHOLE list -- a lost line
* costs a click, never a slot. An unsaved working copy also SURVIVES A
* REFRESH: a zone line re-reads both per-character records, because `out` and
* `active` are zone facts and a stale `active` greys Apply with nothing to
* say why -- and that answer no longer throws away what the player has been
* building. Only Apply and Revert move a working copy the player has touched.
* ONE WRITE IN FLIGHT: Apply, Deactivate and a roll press disarm the buttons
* until THAT WRITE'S OWN w| lands (or five seconds pass); writes are never
* collapsed, never retried, and a late answer to a write already given up on
* frees nothing -- one intent is never two writes.
*
* THE EXPANSION GATE. ENABLE_TOAU is still 0 on this server, so no character
* can BE a blue mage, a puppetmaster or a corsair -- and every empty picker
* used to blame the player for it ("a character not on BLU is set from /jobs
* first"), which is the wrong sentence about the right emptiness. The sync
* envelope carries `g|<0/1>`, the server's own setting, and the window says
* the true one instead. ADDITIVE: a server that predates the record never
* sends it, and ABSENT IS NOT THE SAME AS OFF, so nothing is claimed until a
* server says so.
*
* EVERY ROW OF CONTROLS MEASURES ITSELF. Both control rows and both preset
* rows were laid out in hard pixels and did not fit the window they were
* drawn in -- the Blue Mage row came to about 760 against a default width of
* 720 and a floor of 700 -- and this window carries NoScrollbar, so the last
* button on each was simply gone. Widths come from CalcTextSize in the font
* the client is really drawing with and from GetContentRegionAvail, with a
* floor under each so a bar or a combo cannot shrink past its own text.
*
* TURN IT OFF AND NOTHING IS LOST. `!toau` typed in chat does the same jobs
* in prose, and `!dwk sync` shows exactly what this window is told.
*
* PRESETS (1.2.0, owner request 2026-09-04) are the one thing this file keeps
* between sessions, and they are kept ON THIS PC: named blue magic sets and
* automaton builds in one file for the whole account
* (config\addons\dwtoau\presets.lua under the Ashita install), because a
* preset is a shopping list for ANY squad member, not a fact about one. The
* server never sees a preset -- Load fills the working copy exactly as
* clicking each row would, Load & Apply then presses Apply, and everything a
* preset asks for that the character cannot have (a spell the account never
* learned, one above its level, a part nobody unlocked, more than the budget
* holds) is skipped and SAID, never sent. The window's greyed buttons stay a
* courtesy: the server re-checks the whole list on the way in, as always.
* Hovering an automaton part draws the client's own description card for it,
* the way the Blue Mage tab's rows do for a spell.
*
* 1.3.1 (2026-09-09): A MAP WHOSE KEYS ARE DATA IS A PLAIN TABLE, NEVER `T{ }`
* -- dwgmpanel 1.3.1's rule, applied here. Ashita's sugar gives every T{}
* an `__index` of `table_mt[k] or table[k]`, so an ABSENT key whose NAME is
* one of sugar's sixty-five table methods answers with that FUNCTION rather
* than with nil, and every `== nil` guard above such a read is defeated.
* * `KINDS` maps a wire kind letter to its label and both readers are
* `KINDS[row.kind] or row.kind`, so its absent-key answer IS the fallback: a
* kind naming a sugar method would have been a FUNCTION rather than nil, kept
* by the `or`, and handed to imgui.Text inside the render pcall. Defensive
* rather than a fix for a live bug -- the `k|` parser's `(%a)` holds the kind
* to one byte and no sugar method is one byte long -- and both halves of that
* are gated now, so widening the field cannot quietly re-open it.
--]]

addon.name    = 'dwtoau';
addon.author  = 'DriftwoodXI';
addon.version = '1.3.1';
addon.desc    = 'ToAU job kit for DriftwoodXI squads: set a blue mage\'s spells, build a puppetmaster\'s automaton, press a corsair\'s rolls.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

local DATA_SENDER = '_DWKDATA';

-- The sender field of a 0x017 is a fifteen-byte zero-padded name, so the name
-- PLUS its terminator identifies it exactly. Held as one constant because the
-- test below runs for EVERY chat packet the client receives, ours or not
-- (2026-09-06): it used to cut all fifteen bytes out and run a gsub over them
-- first, which is two throwaway strings per line of anybody's chat.
local SENDER_MATCH = DATA_SENDER .. '\0';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

-- Job ids as the engine numbers them (xi.job). Navigation, not data: the
-- wire says which job each character is on; these only pick the tab's rows.
local JOB_BLU = 16;
local JOB_COR = 17;
local JOB_PUP = 18;

local BLUE_SLOTS       = 20;
local ATTACHMENT_SLOTS = 12;

-- Element order of every capacity/cost list on the wire: the maneuver
-- order (fire, ice, wind, earth, thunder, water, light, dark).
local ELEMENTS = T{ 'Fire', 'Ice', 'Wind', 'Earth', 'Thunder', 'Water', 'Light', 'Dark' };

-- Item ids of the automaton parts: the client's resource manager names
-- them (puppetutils' own 0x2000 / 0x2100 bases).
local PART_BASE       = 0x2000;
local ATTACHMENT_BASE = 0x2100;

-- Kind letters the wire puts on a blue spell (cpp/squad_toau.cpp blueKind).
--
-- A PLAIN TABLE, NEVER `T{ }` (1.3.1), by dwgmpanel 1.3.1's rule: the key is
-- DATA off the wire and both readers are `KINDS[row.kind] or row.kind` -- the
-- absent-key answer IS the fallback. Ashita's sugar answers an absent key
-- with `table_mt[k] or table[k]`, so a kind naming one of its sixty-five
-- methods would come back a FUNCTION, the `or` would keep it, and imgui.Text
-- would be handed a function inside the render pcall.
--
-- No such kind can reach here TODAY, and that is a fact about the wire
-- reader rather than about this table: the `k|` parser matches
-- `^(%d+):(%d+):(%d+):(%a)$`, so a kind is exactly one alpha byte and no
-- sugar method is one byte long. Both halves are gated in
-- tools/dwtoau/harness_dwtoau.py -- the day the kind field widens, this
-- table is already the right shape instead of being the next thing to
-- learn about sugar.
local KINDS = {
    p = 'Physical',
    m = 'Magical',
    d = 'Debuff',
    h = 'Healing',
    b = 'Buff',
};

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged,
    -- so a stale row cannot survive a refresh (dwtracker's rule).
    chars     = T{ },        -- c| rows, in wire order
    charById  = T{ },

    -- Blue Mage tab: the picked character, the server's last answer, and the
    -- working copy that Apply sends.
    bluPick   = nil,         -- charid
    blu       = nil,         -- { header, set = {ids}, known = {rows}, byId }
    bluWork   = T{ },        -- ordered ids
    -- Bumped by EVERY write to bluWork. The two things the render pass
    -- recomputed for every row of every frame -- "is this spell in the set"
    -- and the trait totals -- are memoised against it (2026-09-06).
    bluRev    = 0,
    -- Bumped whenever the KNOWN list is replaced (a commit, or a pick that
    -- drops it): the filtered view below is memoised against it.
    bluModelRev = 0,
    bluDirty  = false,
    bluFilter = T{ '' },
    bluKind   = T{ 1 },      -- 1 = all, then KINDS in KIND_ORDER
    bluSort   = T{ 1 },      -- BLU_SORTS below; 1 is the server's own order
    bluPreset     = nil,     -- the picked preset's name
    bluPresetName = T{ '' }, -- the name box (InputText writes into a table)

    -- Puppetmaster tab.
    pupPick   = nil,
    pup       = nil,         -- { header, attachments, capacity, frames, heads, unlocked, unlockedById }
    pupWork   = nil,         -- { frame, head, attachments = {12} }
    -- The Puppetmaster tab's halves of the same two revisions the Blue Mage
    -- tab keeps: the working build's, and the unlocked list's (2026-09-06).
    pupRev      = 0,
    pupModelRev = 0,
    pupDirty  = false,
    pupFilter = T{ '' },
    pupSort   = T{ 1 },      -- PUP_SORTS below; 1 is the server's own order
    pupPreset     = nil,
    pupPresetName = T{ '' },

    -- Corsair tab: members out with their rolls, the double-up windows,
    -- the rolls on the player; each stamped with the clock it arrived on.
    cor       = T{ members = T{ }, windows = T{ }, active = T{ }, count = 0, at = 0 },
    corAsked  = 0,

    -- Bumped whenever the roster is replaced: the pickers' row order is
    -- memoised against it (2026-09-06).
    charsRev  = 0,

    -- Response assembly: records are accepted only between d| and z|.
    inbound    = nil,
    inboundId  = nil,
    staging    = nil,
    -- Set when an e| lands INSIDE an open envelope: that envelope is
    -- condemned and its z| commits nothing (2026-09-06, see handleRecord).
    inboundBad = false,

    -- Whether this server has Treasures of Aht Urhgan open, from the sync
    -- envelope's g| record. nil means the server never said (an older
    -- server, before the record existed) -- which is not the same as "off",
    -- so nothing is claimed until it does.
    toauOpen  = nil,

    -- The one write in flight: { verb, charid, at }. Buttons disarm while set.
    pending   = nil,

    status    = 'Waiting for the first sync.',
    statusBad = false,
    reported  = false,
};

local KIND_ORDER = T{ 'p', 'm', 'd', 'h', 'b' };

--[[
* The orders the two long lists can be read in (2026-09-06, this round's one
* feature).
*
* Two hundred known spells and two hundred and thirty unlocked attachments are
* a lot of rows to answer "what still fits in the four set points I have left"
* or "what fits in the two fire capacity I have left" in -- and neither filter
* box can answer either question at all, because both are about a NUMBER on
* the row rather than its name.
*
* THE SERVER'S OWN ORDER STAYS FIRST AND STAYS THE DEFAULT: it is what this
* window has always drawn, and a list that silently reorders itself the day an
* addon updates is its own small bug. Nothing is persisted; opening the window
* is opening it on the order the wire sent.
*
* Every comparator ends on the id. A comparator that is not a strict weak
* ordering is what LuaJIT raises "invalid order function" on, and two rows
* with the same level or the same cost is the ordinary case here rather than
* the exotic one.
--]]
local BLU_SORTS = T{ 'Server order', 'By name', 'By level', 'By points' };
local PUP_SORTS = T{ 'Server order', 'By name', 'By cost' };

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. Reads are deduplicated; WRITES ARE NOT QUEUED HERE AT ALL -- they go
* through sendWrite below, one in flight, never collapsed, never retried.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

--[[
* Answer tracking for READS, declared HERE rather than with the rest of the
* answer machinery below: pumpQueue stamps an ask's clock the moment its
* line actually leaves, and a local declared after the function that reads it
* is the global nil instead. A PLAIN TABLE, NOT T{ } (dwbags' shadowed-key
* lesson).
--]]
local requested = {};

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- The empty queue is the common case and this runs every frame: the
    -- zoning read below costs a memory-manager call, so the cheap test goes
    -- first (2026-09-06).
    if (#queue == 0) then
        return;
    end

    -- Held shut while zoning: a line handed to a zoning client is not
    -- delayed, it is LOST (dwecho.lua's canSend).
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    local command = table.remove(queue, 1);

    --[[
        THE ANSWER CLOCK STARTS HERE, not when the ask was filed (2026-09-06).

        A Refresh files four reads at once and this queue lets one out every
        1.2 seconds, so the fourth line sat here for 3.6 of its own five-second
        timeout and the server had 1.4 seconds to answer it before checkAnswers
        called it lost and asked AGAIN -- a second line for a read that was
        never late, on every Refresh, and the retry counter spent on nothing.
        The keys are the line minus the '!dwk ' this function is holding.
    --]]
    local asked = requested[command:sub(6)];

    if (asked ~= nil) then
        asked.at = now;
    end

    echo.send(command);
end

--[[
* An unanswered request is asked once more and then left alone. The table
* itself is declared with the send queue above.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- True once this server has shown it does not speak dwtoau -- an unknown
-- !command falls through to /say, so retrying against a dead verb is the
-- player publicly chatting "!dwk sync". Cleared by any d| envelope this
-- addon can read and by the player acting on purpose (window open, refresh).
local serverSilent = false;

--[[
* Latched when the server announces a protocol this addon cannot read.
*
* Marking the pending asks answered stops the RETRY, which is what the suite
* gate asks for, and it was the whole of the old remedy -- but the Corsair
* tab has a second asking path that no retry counter runs through: it
* re-asks `cor` every eight seconds for as long as the tab is showing, gated
* only on serverSilent, which the mismatch `d|` had just cleared. So a
* player on the wrong version watched "Update dwtoau" and "Server protocol N"
* alternate forever, one doomed line every eight seconds, for the whole
* session (2026-09-06). The latch stops the asking itself; only the player
* acting on purpose -- Refresh, or opening the window again after updating --
* lifts it.
--]]
local protocolBad = false;

local function forget()
    requested = {};
end

-- Requests are keyed by the whole line ('blu 1234'); the envelope names the
-- verb and, for the per-character verbs, the charid.
local function answered(verb, charid)
    for key, asked in pairs(requested) do
        if (type(asked) == 'table') then
            local first, rest = key:match('^(%S+)%s*(.*)$');

            if (first == verb and (charid == nil or rest == '' or rest == tostring(charid))) then
                asked.answered = true;
            end
        end
    end
end

local function ask(verb)
    -- A server speaking a layout this addon cannot read answers every ask
    -- the same way; asking again is a line spent to be told so twice.
    if (protocolBad) then
        return;
    end

    -- `at` stays NIL until pumpQueue actually sends the line: an ask still
    -- waiting on the throttle has not been asked, and the five seconds it is
    -- given are five seconds of the SERVER's silence, not of this addon's
    -- own queue (2026-09-06).
    requested[verb] = { at = nil, answered = false, tries = 1 };

    issue('!dwk ' .. verb);
end

local function checkAnswers()
    -- Nothing outstanding is the common case by far, and this runs every
    -- frame: the two live reads below (the zoning flag, the clock) are only
    -- worth taking when there is something to time (2026-09-06).
    if (state.pending == nil and next(requested) == nil) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    for verb, asked in pairs(requested) do
        if (asked.answered) then
            -- An answered ask is finished business. Left in the table it was
            -- walked every frame for the life of the window and grew by one
            -- entry for every character the player picked; deleting the key
            -- being visited is what `next` allows (2026-09-06).
            requested[verb] = nil;
        elseif (asked.at ~= nil and (os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                -- Nil again, and stamped when the retry's own line leaves.
                asked.at    = nil;
                asked.tries = asked.tries + 1;

                issue('!dwk ' .. verb);
            else
                -- Given up on, and then DELETED (2026-09-06): the entry's
                -- only job was to stop the retry, and nothing re-asks unless
                -- ask() writes it again -- which resets it anyway. Left in
                -- place it kept this function past its early return for the
                -- life of the window, so the zoning flag was read every
                -- frame forever after one silent server.
                requested[verb] = nil;
                serverSilent    = true;

                state.status    = 'No answer from the server. Is DriftwoodXI up to date?';
                state.statusBad = true;
            end
        end
    end

    -- The write's own clock: no retry, just the buttons back. The next
    -- sync shows whatever really happened.
    if (state.pending ~= nil and (os.clock() - state.pending.at) >= ANSWER_TIMEOUT) then
        state.pending   = nil;
        state.status    = 'No answer to that write -- nothing retried. Refresh to see where things stand.';
        state.statusBad = true;
    end
end

local function requestSync()
    ask('sync');
end

local function requestBlue()
    if (state.bluPick ~= nil) then
        ask('blu ' .. tostring(state.bluPick));
    end
end

local function requestPup()
    if (state.pupPick ~= nil) then
        ask('pup ' .. tostring(state.pupPick));
    end
end

local function requestCor()
    state.corAsked = os.clock();

    ask('cor');
end

--[[
* The one write path. Never queued with the reads, never deduplicated,
* never retried: one write in flight, buttons disarmed until its w| lands.
--]]
local function sendWrite(verb, charid, line)
    if (state.pending ~= nil) then
        return false;
    end

    if (not echo.canSend()) then
        -- THE CLICK THAT VANISHED (2026-09-06). A line handed to a zoning
        -- client is not delayed, it is LOST -- and writes are never queued
        -- and never retried, so there is nothing this window can honestly do
        -- but refuse the press. It used to refuse it in silence: the button
        -- came back up, nothing went out, and no sentence anywhere said why.
        state.status    = 'Not sent: the client is still zoning. Press it again in a moment -- writes are never queued and never retried.';
        state.statusBad = true;

        return false;
    end

    state.pending = { verb = verb, charid = charid, at = os.clock() };
    lastSend      = os.clock();

    echo.send('!dwk ' .. line);

    return true;
end

--[[
* Names from the client's own resources. The wire carries ids; a name the
* client cannot draw falls back to a number so a row is never blank.
--]]
local spellNames = {};
local itemNames  = {};

local function spellName(id)
    if (spellNames[id] ~= nil) then
        return spellNames[id];
    end

    local name  = nil;
    local spell = AshitaCore:GetResourceManager():GetSpellById(id);

    -- Typed, not merely non-nil (2026-09-06): the SDK table's shape is the
    -- client's business, and `#` on something that is not a string is an
    -- error inside the render pcall -- which is the whole window. The
    -- description readers below have always been this careful.
    if (spell ~= nil and spell.Name ~= nil and type(spell.Name[1]) == 'string' and #spell.Name[1] > 0) then
        name = spell.Name[1];
    end

    spellNames[id] = name or string.format('spell #%d', id);

    return spellNames[id];
end

--[[
* Lowered names for the two filter boxes, cached by the name itself.
*
* Both list tables ran `name:lower():find(filter)` over EVERY row on EVERY
* frame -- two hundred throwaway strings sixty times a second for a box most
* players leave empty, and the lowering never changes because the names it
* lowers are themselves cached by id. Keyed on the string so one table
* serves spells and attachments, and bounded by the number of distinct names
* the client can draw (2026-09-06).
--]]
local loweredNames = {};

local function lowered(name)
    local lower = loweredNames[name];

    if (lower == nil) then
        lower = name:lower();
        loweredNames[name] = lower;
    end

    return lower;
end

--[[
* Row text that is decided the moment a record is parsed, built once instead
* of once a frame.
*
* The two list tables are the hot loops in this window. Two hundred known
* spells and two hundred and thirty unlocked attachments, each row formatting
* its own button id and calling tostring on its own two numbers, sixty times a
* second -- around fifty thousand throwaway strings a second for a window
* standing perfectly still (2026-09-06). None of it can change: a spell's id
* is its id and its level is its level.
*
* Keyed by the number, so both tables are bounded by the ids, levels and point
* costs the wire can carry rather than by how long the window has been open.
--]]
local function labelCache(format)
    local cache = {};

    return function (key)
        local text = cache[key];

        if (text == nil) then
            text = string.format(format, key);
            cache[key] = text;
        end

        return text;
    end
end

local blueSetLabel   = labelCache('Set##dwtoau_blu_a_%d');
local blueUnsetLabel = labelCache('Unset##dwtoau_blu_u_%d');
local blueDropLabel  = labelCache('x##dwtoau_blu_rm_%d');
local pupOnLabel     = labelCache('On##dwtoau_pup_a_%d');
local pupOffLabel    = labelCache('Off##dwtoau_pup_u_%d');
local pupDropLabel   = labelCache('x##dwtoau_pup_rm_%d');
local pupEmptyLabel  = labelCache('%2d  --');

local numTexts = {};

local function numText(value)
    local text = numTexts[value];

    if (text == nil) then
        text = tostring(value);
        numTexts[value] = text;
    end

    return text;
end

local function itemName(itemId, fallback)
    if (itemNames[itemId] ~= nil) then
        return itemNames[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    local name = nil;

    if (item ~= nil and item.Name ~= nil and type(item.Name[1]) == 'string' and #item.Name[1] > 0) then
        name = item.Name[1];
    end

    itemNames[itemId] = name or fallback or string.format('item #%d', itemId);

    return itemNames[itemId];
end

--[[
* The blue magic catalog -- bluecatalog.lua beside this file, GENERATED by
* tools/dwtoau/gen_blue_catalog.py from the server's blue magic dumps and
* gated by PLANS/Check-BlueCatalog.ps1 plus the dwtoau harness. It is what
* the hover cards (owner request 2026-09-03) read for the two things the
* client's own Set Spells card shows that neither the wire nor the resource
* manager carries: the stat bonuses a spell grants while set and the job
* trait it counts toward. The description and the MP cost come from the
* client's resources; the level and the blue magic points ride the k| record.
* Missing catalog = cards without the trait and stat lines, plus a line
* saying so; nothing else degrades (the dwquest augcatalog rule).
--]]
local haveCatalog, bluecatalog = pcall(require, 'bluecatalog');

if (not haveCatalog or type(bluecatalog) ~= 'table'
        or type(bluecatalog.spells) ~= 'table' or type(bluecatalog.traits) ~= 'table') then
    haveCatalog = false;
    bluecatalog = { spells = { }, traits = { } };
end

-- The client's own words for a spell: the description text and the mana cost,
-- read once per id. Guarded like every resource read here -- the SDK table's
-- shape is the client's business, and a card missing a line beats a window
-- that throws on hover.
local spellInfos = {};

local function spellInfo(id)
    if (spellInfos[id] ~= nil) then
        return spellInfos[id];
    end

    local info = { desc = nil, mp = nil };

    pcall(function()
        local spell = AshitaCore:GetResourceManager():GetSpellById(id);

        if (spell ~= nil) then
            if (spell.Description ~= nil and spell.Description[1] ~= nil and #spell.Description[1] > 0) then
                info.desc = spell.Description[1];
            end

            if (type(spell.ManaCost) == 'number') then
                info.mp = spell.ManaCost;
            end
        end
    end);

    spellInfos[id] = info;

    return info;
end

-- The tier table a catalog category names, or nil (category 0, or a
-- category the server defines no tier for).
local function traitTiers(category)
    if (category == nil or category == 0) then
        return nil;
    end

    local tiers = bluecatalog.traits[category];

    if (type(tiers) ~= 'table' or #tiers == 0) then
        return nil;
    end

    return tiers;
end

-- "2/4/6" -- the points each tier needs, the server's own thresholds.
local function tierLadder(tiers)
    local steps = T{ };

    for _, tier in ipairs(tiers) do
        steps:append(tostring(tier[2]) .. (tier.jp and '*' or ''));
    end

    return table.concat(steps, '/');
end

--[[
* The hover card (owner request 2026-09-03): what the client's own Set Spells
* menu shows for a blue spell -- the description, the stat bonuses it grants
* while set, the job trait it counts toward, its level, MP cost and blue
* magic point cost -- so a player building a squad blue mage's set can see
* which spells feed which trait. The numbers are the SERVER's: the trait
* weight is what blueutils::CalculateTraits sums and the tier ladder is
* what it compares against, which is why the catalog carries them rather
* than retail's.
--]]
local function spellCard(row, why)
    local info  = spellInfo(row.id);
    local entry = bluecatalog.spells[row.id];

    imgui.BeginTooltip();
    imgui.Text(string.format('%s  (%s)', spellName(row.id), KINDS[row.kind] or row.kind));

    if (info.desc ~= nil) then
        imgui.TextWrapped(info.desc);
    end

    if (entry ~= nil) then
        if (#entry.m > 0) then
            imgui.Text(table.concat(entry.m, '  '));
        end

        local tiers = traitTiers(entry.t);

        if (tiers ~= nil) then
            imgui.Text(string.format('Job Trait: %s (+%d pt, tiers at %s)', tiers[1][3], entry.w, tierLadder(tiers)));

            if (#tiers > 1 and tiers[#tiers][3] ~= tiers[1][3]) then
                imgui.TextDisabled(string.format('becomes %s at the top tier', tiers[#tiers][3]));
            end
        elseif (entry.t ~= 0) then
            imgui.TextDisabled('Job Trait: none this server defines');
        end
    elseif (not haveCatalog) then
        imgui.TextDisabled('(bluecatalog.lua missing: no trait or stat lines)');
    end

    imgui.Text(string.format('Lv.%d  MP cost %s  Blue Magic Points %d',
        row.level, info.mp ~= nil and tostring(info.mp) or '?', row.points));

    -- The row's own Set button is greyed when the character cannot hold this
    -- spell, and a greyed button draws no tooltip of its own -- so the
    -- reason rides the card the name always draws (2026-09-06).
    if (why ~= nil) then
        imgui.TextDisabled(why);
    end

    imgui.EndTooltip();
end

--[[
* The set's trait progress: points per category over the working set, so a
* player sees "Lizard Killer 1/2" while choosing, not after applying. Same
* catalog, same server thresholds; a tier marked * needs job points the
* summoner may not have.
--]]
local function traitProgress(setIds)
    local points = { };
    local order  = T{ };

    for _, id in ipairs(setIds) do
        local entry = bluecatalog.spells[id];

        if (entry ~= nil and traitTiers(entry.t) ~= nil) then
            if (points[entry.t] == nil) then
                points[entry.t] = 0;
                order:append(entry.t);
            end

            points[entry.t] = points[entry.t] + entry.w;
        end
    end

    table.sort(order);

    local lines = T{ };

    for _, category in ipairs(order) do
        local tiers   = traitTiers(category);
        local have    = points[category];
        local reached = nil;
        local nextUp  = nil;

        for _, tier in ipairs(tiers) do
            if (have >= tier[2]) then
                reached = tier;
            elseif (nextUp == nil) then
                nextUp = tier;
            end
        end

        lines:append({
            text = string.format('%s: %d pt%s%s', reached ~= nil and reached[3] or tiers[1][3], have,
                reached ~= nil and string.format(' -- tier %d%s', reached[1], reached.jp and ' (job points)' or '') or '',
                nextUp ~= nil and string.format(', next tier at %d', nextUp[2]) or ''),
            reached = reached ~= nil,
        });
    end

    return lines;
end

--[[
* `harlequin_frame` -> `Harlequin Frame`: the wire's raw names, for the parts
* the client's resources might not name.
*
* Cached by the raw name (2026-09-06): the frame and head pickers call this
* on every frame to build the fallback name they hand itemName, and every
* call allocated a table, a string per word and a concat for an answer that
* is a property of the word.
--]]
local prettyNames = {};

local function prettify(raw)
    local key   = tostring(raw or '');
    local ready = prettyNames[key];

    if (ready ~= nil) then
        return ready;
    end

    local words = T{ };

    for word in string.gmatch(key, '[^_]+') do
        words:append(word:sub(1, 1):upper() .. word:sub(2));
    end

    ready = table.concat(words, ' ');
    prettyNames[key] = ready;

    return ready;
end

--[[
* THE FALLBACK WAS BUILT EAGERLY (2026-09-06). itemName only USES its
* fallback when the client cannot name the item -- which is almost never --
* but the argument was a string.format, so it was built for every one of two
* hundred and thirty unlocked rows on every frame regardless. It was the
* single most expensive line left on the Puppetmaster tab, and the counter in
* the harness is what found it.
--]]
local attachmentFallback = labelCache('attachment #%d');

local function attachmentName(id)
    return itemName(ATTACHMENT_BASE + id, attachmentFallback(id));
end

-- The client's own words for an item -- its description text -- read once
-- per id and guarded like every resource read here.
local itemInfos = {};

local function itemInfo(itemId)
    if (itemInfos[itemId] ~= nil) then
        return itemInfos[itemId];
    end

    local info = { desc = nil };

    pcall(function()
        local item = AshitaCore:GetResourceManager():GetItemById(itemId);

        if (item ~= nil and item.Description ~= nil and type(item.Description[1]) == 'string' and #item.Description[1] > 0) then
            info.desc = item.Description[1];
        end
    end);

    itemInfos[itemId] = info;

    return info;
end

-- The cost line of an attachment row, in full element names ('Fire 1,
-- Wind 2') or the short form the table uses ('Fir 1 Win 2').
local function attachmentCosts(row, short)
    local costs = T{ };

    for element = 1, 8 do
        if ((row.elements[element] or 0) > 0) then
            costs:append(string.format('%s %d', short and ELEMENTS[element]:sub(1, 3) or ELEMENTS[element], row.elements[element]));
        end
    end

    return costs;
end

--[[
* The attachment hover card (owner request 2026-09-04): what the client's own
* automaton menu says a part does -- the item's description from the client's
* resources -- with the element capacity it costs from the wire, and the slot
* it sits in when it is equipped. A part the client has no words for still
* draws its costs; the missing line is named, not blank.
--]]
local function attachmentCard(row, slot, why)
    local info  = itemInfo(ATTACHMENT_BASE + row.id);
    local costs = attachmentCosts(row, false);

    imgui.BeginTooltip();
    imgui.Text(attachmentName(row.id));

    if (info.desc ~= nil) then
        imgui.TextWrapped(info.desc);
    else
        imgui.TextDisabled('(no description in the client\'s item data)');
    end

    imgui.Text(#costs > 0 and ('Costs: ' .. table.concat(costs, ', ')) or 'Costs: nothing');

    if (slot ~= nil) then
        imgui.TextDisabled(string.format('equipped in slot %d', slot));
    end

    -- The row's own On button is greyed when the build cannot take the part,
    -- and a greyed button draws no tooltip at all -- so the reason rides the
    -- card the name always draws (2026-09-06, the Blue Mage tab's rule).
    if (why ~= nil) then
        imgui.TextDisabled(why);
    end

    imgui.EndTooltip();
end

--[[
* The frame and head hover card (2026-09-06). The header of this file has
* promised since 1.2.0 that "hovering an automaton part draws the client's
* own description card for it" -- and a frame and a head are automaton parts
* -- but only the twelve attachment slots ever drew one. These are items too
* (`0x2000 + id`, the wire's own base), and what the frame and the head add
* to each element is the arithmetic the capacity bars are made of, so the
* card says it rather than leaving the player to subtract two bars.
--]]
local function partCard(row, kind, equipped, note)
    local info  = itemInfo(PART_BASE + row.id);
    local gives = T{ };

    for element = 1, 8 do
        if ((row.elements[element] or 0) > 0) then
            gives:append(string.format('%s %d', ELEMENTS[element], row.elements[element]));
        end
    end

    imgui.BeginTooltip();
    imgui.Text(itemName(PART_BASE + row.id, prettify(row.name)));

    if (info.desc ~= nil) then
        imgui.TextWrapped(info.desc);
    else
        imgui.TextDisabled('(no description in the client\'s item data)');
    end

    imgui.Text(#gives > 0 and ('Capacity it grants: ' .. table.concat(gives, ', ')) or 'Capacity it grants: none');

    if (not row.unlocked) then
        imgui.TextDisabled(string.format('Nobody on your account has unlocked this %s yet.', kind));
    elseif (equipped) then
        imgui.TextDisabled(string.format('The %s this automaton is built on.', kind));
    end

    if (note ~= nil) then
        imgui.TextDisabled(note);
    end

    imgui.EndTooltip();
end

--[[
* Presets (owner request 2026-09-04): named blue magic sets and automaton
* builds, kept in ONE file for the whole account on this PC --
* config\addons\dwtoau\presets.lua under the Ashita install, beside where
* Ashita's own settings library keeps every addon's files. One file rather
* than the per-character settings library because a preset is a list any
* squad member may be handed, and the character you happen to be playing
* when you save it is not part of it.
*
* The file is Lua the way Ashita's settings are Lua -- a table returned --
* read with loadstring under pcall and validated field by field, so a
* hand-edited or damaged file costs a sentence in the window, never the
* addon. Names are kept to printable ASCII and 24 characters; ids are
* numbers or they are dropped. Re-read every time the window opens, so an
* edit made with the window closed is seen.
--]]
local PRESET_FILE     = string.format('%s\\config\\addons\\dwtoau\\presets.lua', AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));
local PRESET_DIR      = PRESET_FILE:gsub('[\\/][^\\/]+$', '');
local PRESET_NAME_MAX = 24;

local presets     = T{ blu = T{ }, pup = T{ } };
local presetsNote = nil;   -- a sentence about the last file trouble, or nil

local function cleanPresetName(raw)
    local name = tostring(raw or ''):gsub('[^%w %-_%.\']', ''):gsub('^%s+', ''):gsub('%s+$', '');

    return name:sub(1, PRESET_NAME_MAX);
end

local function presetIndex(list, name)
    if (name == nil) then
        return nil;
    end

    local lower = name:lower();

    for index, entry in ipairs(list) do
        if (entry.name:lower() == lower) then
            return index;
        end
    end

    return nil;
end

local function presetByName(list, name)
    local index = presetIndex(list, name);

    return index ~= nil and list[index] or nil;
end

local function sortPresets()
    local byName = function (a, b)
        return a.name:lower() < b.name:lower();
    end

    table.sort(presets.blu, byName);
    table.sort(presets.pup, byName);
end

--[[
* A list of whole non-negative ids, `count` long when a count is given
* (missing entries read as 0, the empty slot), else as long as the input.
*
* THE CEILING IS NOT DECORATION (2026-09-06). LuaJIT's tonumber accepts
* 'inf', '1e400' and 'nan' -- a hand-edited or half-written presets file can
* hold any of them -- and math.floor keeps infinity infinite. Nothing that
* far out ever reached the wire (a spell or a part is looked up by id and an
* id nobody knows is skipped and counted), but the very next Save rewrote the
* whole file through string.format('%d', ...), and what %d does with a number
* that has no integer representation is the runtime's choice: the client's
* LuaJIT 2.1 writes -9223372036854775808 for an infinity or a NaN (a file the
* next load reads back as "no part", silently), and Lua 5.4 -- what the
* offline harness runs -- RAISES, inside the render pcall, so the window
* closed with "render error" and the player's own file was the cause. Either
* way the file was the wrong file. Every id this window can hold fits in
* sixteen bits; anything else reads as the empty slot. (Checked 2026-09-06
* against lupa's LuaJIT 2.1 on this box.)
--]]
local PRESET_ID_MAX = 0xFFFF;

local function wholeNumbers(list, count)
    local out = T{ };

    if (type(list) ~= 'table') then
        list = { };
    end

    for index = 1, (count or #list) do
        local value = tonumber(list[index]) or 0;

        -- value ~= value is the NaN test; the two infinities are named.
        if (value ~= value or value == math.huge or value == -math.huge) then
            value = 0;
        else
            value = math.floor(value);
        end

        out:append((value > 0 and value <= PRESET_ID_MAX) and value or 0);
    end

    return out;
end

--[[
* One whole id in the range wholeNumbers keeps, for the two SINGLE-value
* fields a preset carries.
*
* THEY WENT ROUND THE CEILING (2026-09-06). wholeNumbers guards the id LISTS
* and nothing guarded the automaton preset's frame and head, which were read
* with a bare math.floor(tonumber(...)): math.floor keeps an infinity
* infinite and a NaN a NaN, and savePresets writes both through
* string.format('%d', ...) -- which on Lua 5.4 RAISES on a number with no
* integer representation, outside the pcall that guards the file write and
* therefore inside the render pcall (a hand-edited presets file closed the
* window and called it a render error), and on the client's LuaJIT writes a
* huge negative that the next load reads as "no part" without a word. Zero is
* the honest reading: loadPupPreset already treats a frame or head nobody has
* as "keep the one that is equipped".
--]]
local function wholeNumber(value)
    return wholeNumbers({ value }, 1)[1];
end

local function numberList(list)
    local parts = T{ };

    for _, value in ipairs(list) do
        parts:append(string.format('%d', value));
    end

    return table.concat(parts, ', ');
end

local function loadPresets()
    presets = T{ blu = T{ }, pup = T{ } };

    local ok, err = pcall(function()
        local file = io.open(PRESET_FILE, 'rb');

        if (file == nil) then
            return;
        end

        local raw = file:read('*a');

        file:close();

        local chunk, why = loadstring(raw, '@dwtoau/presets.lua');

        if (chunk == nil) then
            error(why);
        end

        local data = chunk();

        if (type(data) ~= 'table') then
            error('the file did not return a table');
        end

        for _, entry in ipairs(type(data.blu) == 'table' and data.blu or { }) do
            local name = cleanPresetName(type(entry) == 'table' and entry.name or nil);

            if (name ~= '' and presetIndex(presets.blu, name) == nil) then
                local ids = T{ };

                for _, id in ipairs(wholeNumbers(entry.ids)) do
                    if (id > 0) then
                        ids:append(id);
                    end
                end

                presets.blu:append({ name = name, ids = ids });
            end
        end

        for _, entry in ipairs(type(data.pup) == 'table' and data.pup or { }) do
            local name = cleanPresetName(type(entry) == 'table' and entry.name or nil);

            if (name ~= '' and presetIndex(presets.pup, name) == nil) then
                presets.pup:append({
                    name        = name,
                    frame       = wholeNumber(entry.frame),
                    head        = wholeNumber(entry.head),
                    attachments = wholeNumbers(entry.attachments, ATTACHMENT_SLOTS),
                });
            end
        end
    end);

    if (ok) then
        presetsNote = nil;
    else
        presetsNote = 'Could not read the presets file: ' .. tostring(err);
    end

    sortPresets();
end

local function savePresets()
    sortPresets();

    local lines = T{ };

    lines:append('-- dwtoau presets: named blue magic sets (spell ids) and automaton builds');
    lines:append('-- (frame, head, twelve attachment ids). Written by the addon; edit with the');
    lines:append('-- window closed, and the next open reads it back.');
    lines:append('return {');
    lines:append('    blu = {');

    for _, entry in ipairs(presets.blu) do
        lines:append(string.format('        { name = %q, ids = { %s } },', entry.name, numberList(entry.ids)));
    end

    lines:append('    },');
    lines:append('    pup = {');

    for _, entry in ipairs(presets.pup) do
        lines:append(string.format('        { name = %q, frame = %d, head = %d, attachments = { %s } },',
            entry.name, entry.frame, entry.head, numberList(entry.attachments)));
    end

    lines:append('    },');
    lines:append('}');

    local ok, err = pcall(function()
        if (not ashita.fs.exists(PRESET_DIR)) then
            ashita.fs.create_dir(PRESET_DIR);
        end

        local file = io.open(PRESET_FILE, 'wb');

        if (file == nil) then
            error('cannot open ' .. PRESET_FILE .. ' for writing');
        end

        file:write(table.concat(lines, '\n') .. '\n');
        file:close();
    end);

    if (ok) then
        presetsNote = nil;
    else
        presetsNote = 'Could not write the presets file: ' .. tostring(err);
    end

    return ok;
end

-- Store an entry under its name (overwriting a same-named one) and write.
local function putPreset(list, entry)
    local index = presetIndex(list, entry.name);

    if (index ~= nil) then
        list[index] = entry;
    else
        list:append(entry);
    end

    return savePresets();
end

local function dropPreset(list, name)
    local index = presetIndex(list, name);

    if (index == nil) then
        return false;
    end

    table.remove(list, index);

    return savePresets();
end

-- "skipped 3 (1 not known, 2 over the budget)" from a table of counted
-- reasons, in the order given; '' when nothing was skipped.
local function skippedText(reasons)
    local total = 0;
    local parts = T{ };

    for _, reason in ipairs(reasons) do
        if (reason[1] > 0) then
            total = total + reason[1];
            parts:append(string.format('%d %s', reason[1], reason[2]));
        end
    end

    if (total == 0) then
        return '';
    end

    return string.format(' -- skipped %d (%s)', total, table.concat(parts, ', '));
end

local function sameList(a, b)
    if (#a ~= #b) then
        return false;
    end

    for index = 1, #a do
        if (a[index] ~= b[index]) then
            return false;
        end
    end

    return true;
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* EVERY NUMBER OFF THE WIRE IS A WHOLE NUMBER, OR IT IS ZERO.
*
* WHY THIS IS ONE RULE AND NOT A PATCH. Nearly every number this window reads
* off a record reaches `string.format('%d', ...)` somewhere -- a spell id and
* a frame when a preset is saved, a charid in the picker's own Selectable id
* and in both write lines, a level in the header, a capacity in a bar's
* overlay, a roll's total on the board -- and a number with no integer
* representation is answered two ways, neither of them acceptable. The
* client's LuaJIT 2.1 does not raise: %d TRUNCATES 2.5 to 2, so a fractional
* charid became a `!dwk bluset` aimed at a different character, and a NaN or
* an infinity became -9223372036854775808 on the wire. Lua 5.4 -- what the
* offline harness runs -- RAISES instead: inside the render pcall that closes
* the whole window and blames a render error; inside the packet handler it is
* a record silently dropped with a red line in the log. The presets file
* taught this addon the lesson earlier the same day (2026-09-06), and auditing
* every %d site afterwards found the wire could do it in a dozen more places,
* so the answer is a filter every numeric field goes through rather than a
* guard on the handful somebody remembered. (The LuaJIT half was checked on
* 2026-09-06 against lupa's LuaJIT 2.1 on this box.)
*
* Our server writes all of them with %i. The reason to do this anyway is that
* a 0x017 has been through every other addon on the client before this
* handler sees it, and at least one third-party addon in this suite's world
* rewrites packets.
*
* NOT the presets file's wholeNumbers, and the difference is deliberate: that
* one FLOORS a fraction, which is the right reading of a file a player edited
* by hand and the wrong one for a record. A number the server did not send is
* not a number, and rounding 2.5 into spell 2 puts a row in this window that
* nothing on the account has ever known.
--]]
local function wireNumbers(text, count)
    local out   = T{ };
    local index = 0;

    for piece in string.gmatch(tostring(text or ''), '[^,]+') do
        local value = tonumber(piece);

        index = index + 1;

        -- value ~= value is the NaN test; math.floor keeps an infinity
        -- infinite, so the ceiling is not decoration either.
        if (value == nil or value ~= value or value ~= math.floor(value)
                or value < 0 or value > PRESET_ID_MAX) then
            value = 0;
        end

        out[index] = value;
    end

    for slot = index + 1, (count or 0) do
        out[slot] = 0;
    end

    return out;
end

-- One number off the wire, or 0 for anything that is not one.
local function wireNumber(text)
    return wireNumbers(text)[1] or 0;
end

local function charOf(charid)
    return state.charById[charid];
end

local function onJob(row, jobId)
    return row ~= nil and (row.mjob == jobId or row.sjob == jobId);
end

-- The per-character staging for blu/bluset and pup/pupset responses.
local function newBlueStaging()
    return T{ header = nil, set = T{ }, known = T{ } };
end

local function newPupStaging()
    return T{ header = nil, attachments = T{ }, capacity = T{ }, frames = T{ }, heads = T{ }, unlocked = T{ } };
end

local function newCorStaging()
    return T{ members = T{ }, windows = T{ }, active = T{ } };
end

-- Commit a blue response: the cache and the working copy both reset to
-- what the server said (a write's own refresh rides its envelope).
local function commitBlue(staging)
    if (staging == nil or staging.header == nil) then
        return;
    end

    local byId = T{ };

    for _, row in ipairs(staging.known) do
        byId[row.id] = row;
    end

    state.blu         = T{
        header = staging.header,
        set    = staging.set,
        known  = staging.known,
        byId   = byId,
    };
    state.bluModelRev = state.bluModelRev + 1;

    --[[
        AN UNSAVED SET SURVIVES A REFRESH (2026-09-06). The header of this
        file has promised since the first version that the working copies are
        kept across a zone line -- and since the zone-in handler started
        re-asking the two per-character reads, which it must because `out` and
        `active` are zone facts, every zone line ran this function and threw
        the player's unapplied edits away without a word. Refresh did the
        same, and so did the answer to the `blu` the Corsair tab's own poll
        provoked. A working copy the player has CHANGED is theirs until they
        Apply or Revert; only a clean one takes the server's answer. The
        revision is not bumped in that case because the working set did not
        move -- the memos keyed on it are still right.
    ]]
    if (state.bluDirty) then
        state.bluDirty = not sameList(state.bluWork, staging.set);
    else
        state.bluWork = T{ };
        state.bluRev  = state.bluRev + 1;

        for _, id in ipairs(staging.set) do
            state.bluWork:append(id);
        end
    end
end

-- The working build the server's answer describes. Revert's answer too, so
-- the two cannot drift (2026-09-06 -- Revert used to rebuild a whole fake
-- staging table and run it through commitPup, which also bumped the model
-- revision and threw away the filtered view for nothing).
local function pupWorkFrom(header, attachments)
    local work = T{ frame = header.frame, head = header.head, attachments = T{ } };

    for slot = 1, ATTACHMENT_SLOTS do
        work.attachments[slot] = attachments[slot] or 0;
    end

    return work;
end

local function commitPup(staging)
    if (staging == nil or staging.header == nil) then
        return;
    end

    local unlockedById = T{ };

    for _, row in ipairs(staging.unlocked) do
        unlockedById[row.id] = row;
    end

    state.pup         = T{
        header       = staging.header,
        attachments  = staging.attachments,
        capacity     = staging.capacity,
        frames       = staging.frames,
        heads        = staging.heads,
        unlocked     = staging.unlocked,
        unlockedById = unlockedById,
    };
    state.pupModelRev = state.pupModelRev + 1;

    -- An unsaved build survives a refresh, the Blue Mage tab's rule and for
    -- the same reason: the zone-in re-read exists to move `active` and `out`,
    -- not to discard twelve slots the player has been filling.
    if (state.pupDirty and state.pupWork ~= nil) then
        state.pupDirty = not (state.pupWork.frame == staging.header.frame
            and state.pupWork.head == staging.header.head
            and sameList(state.pupWork.attachments, staging.attachments));
    else
        state.pupWork  = pupWorkFrom(staging.header, staging.attachments);
        state.pupRev   = state.pupRev + 1;
        state.pupDirty = false;
    end
end

local function commitCor(staging)
    if (staging == nil) then
        return;
    end

    -- members is keyed by charid, so #members is meaningless; the count is
    -- taken once here rather than by a pairs() walk every frame, and the
    -- tab needs it to tell "no corsair is out" from "the corsairs answered
    -- but the character list has not" (2026-09-06).
    local count = 0;

    for _ in pairs(staging.members) do
        count = count + 1;
    end

    state.cor = T{
        members = staging.members,
        windows = staging.windows,
        active  = staging.active,
        count   = count,
        at      = os.clock(),
    };
end

--[[
* EVERY LINE THIS ADDON PRINTS GOES THROUGH ONE CEILING (2026-09-06).
*
* A refusal is PRINTED as well as shown, because one that lands while the
* window is closed would otherwise be silent -- but the Corsair tab re-asks
* the server every eight seconds for as long as it is showing, so a roster
* that has started failing answered every one of those asks with the same
* sentence and put a red line in the player's log every eight seconds for the
* rest of the session. The bad-record diagnostic below has exactly the same
* shape for exactly the same reason.
*
* The status line still says it every time; the LOG hears a given sentence
* again only after a minute, which is a ceiling on a burst rather than a mute.
* Keyed by the sentence, and emptied rather than pruned once it holds more
* distinct ones than a real session produces -- a table that grows on events
* needs a bound, and this one is fed by the server.
--]]
local QUIET_WINDOW = 60.0;
local QUIET_MAX    = 64;

local lastSaid  = {};
local saidCount = 0;

local function sayOnce(text, colour)
    local now  = os.clock();
    local when = lastSaid[text];

    if (when ~= nil and (now - when) < QUIET_WINDOW) then
        return;
    end

    if (when == nil) then
        if (saidCount >= QUIET_MAX) then
            lastSaid  = {};
            saidCount = 0;
        end

        saidCount = saidCount + 1;
    end

    lastSaid[text] = now;

    print(chat.header('dwtoau'):append(colour(text)));
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireNumber(parts[2]);

        if (version ~= PROTOCOL) then
            state.status     = string.format('Server protocol %d, addon expects %d. Update dwtoau.', version, PROTOCOL);
            state.statusBad  = true;
            state.inbound    = nil;
            state.inboundBad = false;
            state.staging    = nil;

            -- The envelope IS the answer, whatever version it announced.
            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            -- ...and NOTHING ASKS AGAIN until the player says so: the
            -- Corsair tab's eight-second poll is not a retry and no retry
            -- counter reaches it. THE QUEUE IS PARKED with it (dwah's
            -- shape): a line already waiting on the throttle is as doomed as
            -- one asked after the mismatch, and it holds nothing but reads --
            -- writes never enter this queue at all.
            protocolBad   = true;
            queue         = T{ };
            state.pending = nil;

            return;
        end

        -- Only an envelope this addon can actually read says the server is
        -- listening: a mismatch used to clear the silence latch too.
        serverSilent = false;
        protocolBad  = false;

        state.inbound    = parts[3];
        state.inboundId  = tonumber(parts[4]);
        state.inboundBad = false;

        if (state.inbound == 'sync') then
            state.staging = T{ chars = T{ } };
        elseif (state.inbound == 'blu' or state.inbound == 'bluset') then
            state.staging = newBlueStaging();
        elseif (state.inbound == 'pup' or state.inbound == 'pupset' or state.inbound == 'pupoff') then
            state.staging = newPupStaging();
        elseif (state.inbound == 'cor') then
            state.staging = newCorStaging();
        else
            state.staging = nil;
        end

        answered(state.inbound, state.inboundId);

        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            state.pending = nil;
        end

        return;
    end

    -- Notes and refusals are accepted whatever the envelope state: the
    -- sentence saying why something was refused outranks the response it
    -- happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            sayOnce(state.status, chat.error);

            if (string.find(line, 'not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end

            -- A refusal INSIDE an open envelope CONDEMNS that envelope
            -- (2026-09-06). toau_kit.lua's emitSync and emitCorsairs both
            -- raise their roster failure with the envelope already open, so
            -- the records that follow are nothing at all -- and the old z|
            -- handling then committed that nothing AND wrote a green
            -- 'Synced.' over the sentence saying why. A player whose roster
            -- read failed watched the character list empty itself, both
            -- builder tabs lose their pickers, and the window call it a
            -- success. The z| below now commits nothing for a condemned
            -- envelope and leaves the refusal standing.
            state.inboundBad = true;

            -- A refusal that came instead of a write's outcome frees the
            -- buttons -- but ONLY when it is that write's own refusal. The
            -- Corsair tab re-asks `cor` every eight seconds, so a roster
            -- that has started failing raised an e| straight through a
            -- bluset still in flight, re-armed Apply while the server was
            -- still deciding, and invited a second write for one intent.
            -- Every write's refusal arrives either in its own envelope
            -- (w|0, not e|) or wrapped as a bare `status` one. THE CHARACTER
            -- COUNTS AS WELL AS THE VERB (2026-09-06, the second half of the
            -- w| rule): a write for one alt that timed out, and then a second
            -- write for ANOTHER alt, and then the first one's late refusal --
            -- same verb, different character -- freed the second one while
            -- the server was still deciding about it.
            if (state.pending ~= nil and (state.inbound == nil or state.inbound == 'status'
                    or (state.inbound == state.pending.verb
                        and (state.inboundId == nil or state.inboundId == state.pending.charid)))) then
                state.pending = nil;
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing   = state.inbound;
        local staging   = state.staging;
        local condemned = state.inboundBad;

        state.inbound    = nil;
        state.inboundId  = nil;
        state.staging    = nil;
        state.inboundBad = false;

        -- A condemned envelope commits nothing and says nothing: the e| that
        -- condemned it already said why, and that sentence is the answer.
        if (condemned) then
            return;
        end

        if (closing == 'sync' and staging ~= nil) then
            state.chars    = staging.chars;
            state.charById = T{ };
            state.charsRev = state.charsRev + 1;

            for _, row in ipairs(state.chars) do
                state.charById[row.charid] = row;
            end

            -- A pick the roster no longer carries is dropped with its data
            -- (2026-09-06). The combo fell back to "Pick a character..." on
            -- its own, but the tab below went on drawing the old character's
            -- set with a live Apply aimed at a charid this account no longer
            -- has -- and only the server's refusal would have said so.
            if (state.bluPick ~= nil and state.charById[state.bluPick] == nil) then
                state.bluPick     = nil;
                state.blu         = nil;
                state.bluWork     = T{ };
                state.bluRev      = state.bluRev + 1;
                state.bluModelRev = state.bluModelRev + 1;
                state.bluDirty    = false;
            end

            if (state.pupPick ~= nil and state.charById[state.pupPick] == nil) then
                state.pupPick     = nil;
                state.pup         = nil;
                state.pupWork     = nil;
                state.pupRev      = state.pupRev + 1;
                state.pupModelRev = state.pupModelRev + 1;
                state.pupDirty    = false;
            end

            -- nil when the server never sent g| (an older server): unknown
            -- is not the same as off, and only a server that said so is
            -- quoted (2026-09-06).
            state.toauOpen = staging.toau;

            state.status    = 'Synced.';
            state.statusBad = false;
        elseif ((closing == 'blu' or closing == 'bluset') and staging ~= nil) then
            -- Commit under the character the envelope NAMED, so a pick
            -- change mid-flight can never file one alt's set under another.
            if (staging.header ~= nil and staging.header.charid == state.bluPick) then
                commitBlue(staging);
            end

            if (closing == 'blu') then
                state.status    = 'Synced.';
                state.statusBad = false;
            end
        elseif ((closing == 'pup' or closing == 'pupset') and staging ~= nil) then
            if (staging.header ~= nil and staging.header.charid == state.pupPick) then
                commitPup(staging);
            end

            if (closing == 'pup') then
                state.status    = 'Synced.';
                state.statusBad = false;
            end
        elseif (closing == 'pupoff') then
            -- The automaton is gone; the next pup read says so.
            requestPup();
        elseif (closing == 'cor' and staging ~= nil) then
            commitCor(staging);
        elseif (closing == 'roll') then
            requestCor();
        end

        return;
    end

    local staging = state.staging;

    -- A write's outcome, in words.
    if (kind == 'w') then
        local ok = wireNumber(parts[2]) ~= 0;

        --[[
            ONLY THIS WRITE'S OWN OUTCOME FREES THIS WRITE (2026-09-06). The
            e| path learned that rule this morning and w| had the same hole in
            it. A write nobody answers for five seconds is given up on and the
            buttons come back, so the player presses the next thing -- and
            then the SLOW answer to the first one lands and clears the second
            write's latch while the server is still deciding about it. One
            intent, two writes, which is the single thing this window promises
            never to do (a replayed roll is a SECOND roll). The envelope names
            the verb and the character it belongs to, so a w| for anything but
            the write in flight is read for its sentence and nothing more.
        ]]
        if (state.pending ~= nil and state.inbound == state.pending.verb
                and (state.inboundId == nil or state.inboundId == state.pending.charid)) then
            state.pending = nil;
        end

        state.statusBad = not ok;

        -- A w| with no sentence left the status EMPTY, so the buttons came
        -- back with no word about what had just happened to the character
        -- (2026-09-06). The record's own ok flag is enough to say something.
        if (parts[5] ~= nil and parts[5] ~= '') then
            state.status = parts[5];
        else
            state.status = ok and 'The server took that write.' or 'The server refused that write and said nothing about why.';
        end

        return;
    end

    if (kind == 'c' and staging ~= nil and staging.chars ~= nil) then
        local flags = wireNumber(parts[12]);

        -- The charid is a %d in three places (the picker's Selectable id, the
        -- two write lines) as well as a table key, so it takes the wire's own
        -- whole-id filter like every other id here (2026-09-06).
        staging.chars:append({
            charid = wireNumber(parts[2]),
            name   = parts[3] or '?',
            slot   = wireNumber(parts[4]),
            mjob   = wireNumber(parts[5]),
            mlvl   = wireNumber(parts[6]),
            sjob   = wireNumber(parts[7]),
            slvl   = wireNumber(parts[8]),
            blu    = wireNumber(parts[9]),
            pup    = wireNumber(parts[10]),
            cor    = wireNumber(parts[11]),
            online = bit.band(flags, 1) ~= 0,
            out    = bit.band(flags, 2) ~= 0,
            self   = bit.band(flags, 4) ~= 0,
            active = bit.band(flags, 8) ~= 0,
            tag    = parts[13] or '',
        });

        return;
    end

    -- Whether the expansion these three jobs belong to is open on this
    -- server at all (2026-09-06, toau_kit.lua's emitSync). ADDITIVE: a
    -- server that predates the record simply never sends it, and the window
    -- claims nothing rather than guessing from three zeroed job levels.
    if (kind == 'g' and staging ~= nil and staging.chars ~= nil) then
        staging.toau = wireNumber(parts[2]) == 1;

        return;
    end

    -- Blue magic: header, the set, the known list (packed).
    if (kind == 'b' and staging ~= nil and staging.known ~= nil) then
        staging.header = {
            charid     = wireNumber(parts[2]),
            name       = parts[3] or '?',
            job        = wireNumber(parts[4]),
            level      = wireNumber(parts[5]),
            slots      = wireNumber(parts[6]),
            points     = wireNumber(parts[7]),
            used       = wireNumber(parts[8]),
            usedPoints = wireNumber(parts[9]),
            out        = wireNumber(parts[10]) == 1,
        };

        return;
    end

    if (kind == 's' and staging ~= nil and staging.set ~= nil) then
        for _, id in ipairs(wireNumbers(parts[2])) do
            if (id > 0) then
                staging.set:append(id);
            end
        end

        return;
    end

    if (kind == 'k' and staging ~= nil and staging.known ~= nil) then
        for entry in string.gmatch(parts[2] or '', '[^,]+') do
            local id, level, points, kindLetter = entry:match('^(%d+):(%d+):(%d+):(%a)$');

            if (id ~= nil) then
                staging.known:append({
                    id     = tonumber(id),
                    level  = tonumber(level),
                    points = tonumber(points),
                    kind   = kindLetter,
                });
            end
        end

        return;
    end

    -- Automaton: header, equipped, capacity, frames, heads, unlocked (packed).
    if (kind == 'p' and staging ~= nil and staging.frames ~= nil) then
        -- The two the working build carries into %d; zero is not a part, so a
        -- record that does not name one falls back to the harlequin the way it
        -- always did.
        local frame = wireNumber(parts[6]);
        local head  = wireNumber(parts[7]);

        staging.header = {
            charid  = wireNumber(parts[2]),
            name    = parts[3] or '?',
            job     = wireNumber(parts[4]),
            level   = wireNumber(parts[5]),
            frame   = frame > 0 and frame or 0x20,
            head    = head > 0 and head or 0x01,
            active  = wireNumber(parts[8]) == 1,
            out     = wireNumber(parts[9]) == 1,
            petname = parts[10] or '',
        };

        return;
    end

    -- The equipped list is l| (loadout): e| is the family's refusal record.
    -- Twelve whole ids; anything else is the empty slot.
    if (kind == 'l' and staging ~= nil and staging.attachments ~= nil) then
        staging.attachments = wireNumbers(parts[2], ATTACHMENT_SLOTS);

        return;
    end

    -- Parsed and kept for completeness; the bars are drawn from the frame
    -- and head nibbles instead, which is the same arithmetic against the
    -- WORKING build rather than the equipped one.
    if (kind == 'q' and staging ~= nil and staging.capacity ~= nil) then
        staging.capacity = wireNumbers(parts[2], 8);

        return;
    end

    if ((kind == 'f' or kind == 'h') and staging ~= nil and staging.frames ~= nil) then
        local row = {
            id       = wireNumber(parts[2]),
            unlocked = wireNumber(parts[3]) == 1,
            name     = parts[4] or '',
            elements = wireNumbers(parts[5], 8),
        };

        if (kind == 'f') then
            staging.frames:append(row);
        else
            staging.heads:append(row);
        end

        return;
    end

    if (kind == 'a' and staging ~= nil and staging.unlocked ~= nil) then
        for entry in string.gmatch(parts[2] or '', '[^,]+') do
            local id, hex = entry:match('^(%d+):(%x+)$');

            if (id ~= nil) then
                local slots    = tonumber(hex, 16) or 0;
                local elements = T{ };

                for element = 1, 8 do
                    elements[element] = bit.band(bit.rshift(slots, (element - 1) * 4), 0xF);
                end

                -- The total capacity a part spends, summed here rather than
                -- per row per sort: it is what 'By cost' orders on, and it
                -- cannot change once the record is parsed (2026-09-06).
                local cost = 0;

                for element = 1, 8 do
                    cost = cost + elements[element];
                end

                --[[
                    The Cost column's own text, decided HERE (2026-09-06).
                    The table rebuilt it -- a table, up to eight
                    string.formats and a concat -- for every one of two
                    hundred rows on every frame, so it was cached by
                    attachment id; and a cache keyed by an id outlives the
                    MODEL that filled it, so a second `a|` describing the same
                    id differently drew the first one's numbers for the rest
                    of the session. It belongs on the row, which the next
                    answer replaces whole.
                --]]
                local costs = attachmentCosts({ elements = elements }, true);

                staging.unlocked:append({
                    id       = tonumber(id),
                    slots    = slots,
                    elements = elements,
                    cost     = cost,
                    costText = #costs > 0 and table.concat(costs, ' ') or '-',
                });
            end
        end

        return;
    end

    -- Corsairs: a roll a member can press, a double-up window, a roll on
    -- the player.
    if (kind == 'r' and staging ~= nil and staging.members ~= nil) then
        local charid = wireNumber(parts[2]);

        if (staging.members[charid] == nil) then
            staging.members[charid] = T{ rolls = T{ }, tricks = T{ } };
        end

        local row = { id = wireNumber(parts[3]), name = prettify(parts[4] or ''), raw = parts[4] or '' };

        -- The button's own label, decided here rather than formatted for
        -- every roll of every member on every frame (2026-09-06, the rule
        -- `roll.bust` already followed).
        if ((parts[5] or 'r') == 'r') then
            row.button = string.format('%s##dwtoau_roll_%d_%d', row.name, charid, row.id);

            staging.members[charid].rolls:append(row);
        else
            row.button = string.format('%s##dwtoau_trick_%d_%d', row.name, charid, row.id);

            staging.members[charid].tricks:append(row);
        end

        return;
    end

    if (kind == 'u' and staging ~= nil and staging.windows ~= nil) then
        staging.windows[wireNumber(parts[2])] = {
            effect    = wireNumber(parts[3]),
            total     = wireNumber(parts[4]),
            remaining = wireNumber(parts[5]),
        };

        return;
    end

    if (kind == 'o' and staging ~= nil and staging.active ~= nil) then
        local name = parts[3] or '?';

        staging.active:append({
            effect    = wireNumber(parts[2]),
            name      = name,
            -- Decided ONCE, here: the render pass used to lower and search
            -- the name of every active roll on every frame (2026-09-06).
            bust      = name:lower():find('bust', 1, true) ~= nil,
            total     = wireNumber(parts[4]),
            remaining = wireNumber(parts[5]),
            caster    = parts[6] or '',
        });

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWKDATA is
* ours: consumed and blocked before parsing, so a malformed record cannot
* leak as chat noise.
--]]
ashita.events.register('packet_in', 'dwtoau_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    if (e.data_modified:sub(0x09, 0x08 + #SENDER_MATCH) ~= SENDER_MATCH) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        -- Through the same ceiling as a refusal: a record shape this addon
        -- cannot read arrives once per ask, and the Corsair tab asks every
        -- eight seconds (2026-09-06).
        sayOnce('bad record: ' .. tostring(err), chat.error);
    end
end);

--[[
* Rendering
--]]

--[[
* Hover text, in ONE table (dwbags' TIPS shape) so the harness can hold the
* window to the sentences it promises and a wording change is one edit. A
* control whose meaning depends on the state -- a greyed Apply, a Set the
* budget cannot hold -- builds its sentence at the call site instead, INSIDE
* the IsItemHovered guard, so the string.format is not paid sixty times a
* second for a control nobody is pointing at.
--]]
local TIPS = {
    refresh     = 'Ask the server for all of it again: the roster, the picked character\'s blue magic and automaton, and the corsairs out.',

    tabBlue     = 'Set a squad blue mage\'s spells. A blue mage casts only what is SET, and a squad member cannot set its own.',
    tabPup      = 'Build a squad puppetmaster\'s automaton: frame, head and twelve attachments, inside the element capacity.',
    tabCor      = 'Press a squad corsair\'s rolls, and read the ones sitting on you with their clocks.',

    pickBlue    = 'Which squad blue mage to set. The characters ON the job come first; the rest are greyed and each says whether it has BLU at all -- /jobs switches one that does.',
    pickPup     = 'Which squad puppetmaster to build for. The characters ON the job come first; the rest are greyed and each says whether it has PUP at all -- /jobs switches one that does.',

    slotBar     = 'Spell slots the working set uses. The server sets the count from the character\'s BLU level plus the summoner\'s Assimilation merits.',
    pointBar    = 'Blue magic set points the working set spends. Every spell costs some; the ceiling is the character\'s BLU level plus the summoner\'s blue magic job points.',
    capacityBar = 'Element capacity: the frame and the head grant it, the equipped attachments spend it. Over capacity, the server refuses the build.',

    revertBlue  = 'Put the working set back to what the server last said. Nothing is sent.',
    revertPup   = 'Put the working build back to what the server last said. Nothing is sent.',

    bluFilter   = 'Type part of a spell\'s name to narrow the list. Names are the client\'s own.',
    bluKind     = 'Show only one kind of blue magic: physical, magical, debuff, healing or buff.',
    bluSort     = 'What order to read the list in. By points answers "what still fits in the set points I have left"; the server\'s own order is what the wire sent, and is the default.',
    bluKnown    = 'Every blue spell anyone on your account has learned -- blue magic is account-wide, so one character\'s learning arms them all.',
    bluClear    = 'Take every spell out of the working set. Nothing is sent until Apply.',
    traitBlock  = 'What the WORKING set earns, trait by trait, off the generated catalog beside this addon: the server\'s own weights and tier thresholds, never retail\'s. A tier marked "job points" needs the summoner\'s blue magic job points as well as the set points.',
    bluCopy     = 'Copy the working set\'s spell names to the clipboard, in slot order.',

    pupFilter   = 'Type part of an attachment\'s name to narrow the list.',
    pupSort     = 'What order to read the list in. By cost is the total element capacity a part spends, which answers "what still fits"; the server\'s own order is the default.',
    pupUnlocked = 'Every automaton part anyone on your account has unlocked -- an attachment used by one character equips them all.',
    pupFrame    = 'The automaton\'s frame. It decides the body, and half of the element capacity.',
    pupHead     = 'The automaton\'s head. It decides the behaviour, and the other half of the element capacity.',
    pupClear    = 'Empty all twelve attachment slots. Nothing is sent until Apply.',
    pupCopy     = 'Copy the frame, the head and the twelve slots to the clipboard.',

    presetPick  = 'A saved list, kept ON THIS PC for the whole account -- the server never sees one.',
    presetLoad  = 'Fill the working copy from this preset -- nothing is sent until Apply. Anything this character cannot have is skipped and counted.',
    presetName  = 'A name for the preset, up to 24 characters. Saving over a name replaces it.',
    presetDrop  = 'Delete this preset from the file on this PC. Nothing on the server changes.',

    status      = 'The last word from the server, or from this window. Green is what happened; red is a refusal, or something this window could not do.',

    bluOut      = 'This member is standing in your party right now, so a set written here is armed ON THE SPOT -- no dismiss, no re-call. A gambit rule naming a spell you take out simply idles.',
    pupOut      = 'This member is standing in your party right now. A build lands on the next Activate, and the squad\'s pet keep does that on its own tick -- roughly half a minute.',
    pupOff      = 'Put the automaton away so the build can be written: an ACTIVE automaton refuses the write, retail\'s own rule. At full HP the Activate timer is handed back, and the squad brings the new build out on its own.',
    pupEmpty    = 'An empty slot. On, in the list to the right, fills the first empty slot; the twelve keep their order, so a preset comes back in the shape it was saved in.',

    corWindow   = 'The member\'s Double-Up window: the roll\'s total so far, and how long is left to press Double-Up or Snake Eye.',
    corActive   = 'Rolls and busts on YOU right now, with the number rolled and the time left. Eleven is the lucky total; a bust is the penalty for going over.',
    corTrick    = 'A card trick rather than a roll: Double-Up, Snake Eye, Fold, Random Deal, Wild Card, Crooked Cards.',
};

-- The one sentence for the setting the three jobs hang off, said wherever
-- the window would otherwise blame the player for the server's own gate.
local TOAU_CLOSED = 'Treasures of Aht Urhgan is not open on this server yet: no character can be a blue mage, puppetmaster or corsair until it is.';

--[[
* MEASUREMENT (2026-09-06, the dwah/dwcpx shape).
*
* Both control rows and both preset rows were laid out in hard pixels, and the
* Blue Mage one came to roughly 760 of them -- two 220-pixel bars, Apply,
* Revert, the marker, Clear and Copy on one SameLine chain -- against a window
* whose default width is 720 and whose floor is 700. So the last control on
* the row was simply off the right edge, and this window carries NoScrollbar,
* so nothing on screen said there was a button out there at all. Worse, the
* overflow is font-dependent: a player running Ashita at a larger font loses
* more of the row, and no fixed set of numbers can be right for both.
*
* CalcTextSize answers in the font the client is actually drawing with.
* Guarded because it is a call an older generation may not carry, and memoised
* by the string because these labels never change; dropped on zone-in with
* nothing else, the way dwah drops its own, in case the font moved.
--]]
local textWidths = {};

local function textWidth(sample, fallback)
    local cached = textWidths[sample];

    if (cached ~= nil) then
        return cached;
    end

    local width = fallback;

    if (type(imgui.CalcTextSize) == 'function') then
        local ok, measured = pcall(imgui.CalcTextSize, sample);

        if (ok and type(measured) == 'number' and measured > 0) then
            width = measured;
        end
    end

    textWidths[sample] = width;

    return width;
end

-- The width left on the line the cursor is on, or a sane guess for a
-- generation that does not answer. 704 is the default window minus its own
-- padding, which is what every row here used to assume without saying so.
local function regionWidth()
    if (type(imgui.GetContentRegionAvail) ~= 'function') then
        return 704;
    end

    local ok, width = pcall(imgui.GetContentRegionAvail);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return 704;
end

-- ImGui's default style, which this suite's theme does not move (dwtheme
-- pushes colours, never sizes): eight pixels between items on a line, four
-- of frame padding each side of a button's label.
local ITEM_SPACING = 8;
local FRAME_PAD    = 8;

-- The plain tip. Constant text only -- a formatted one is built inside its
-- own IsItemHovered so it is not allocated every frame.
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

-- Hoisted out of jobLabel (2026-09-06): the table was allocated on every
-- call, and a call is one per picker per frame plus one per roster row for
-- every frame a popup is open.
local JOB_NAMES = { [JOB_BLU] = 'BLU', [JOB_COR] = 'COR', [JOB_PUP] = 'PUP' };

local function jobLabel(row)
    -- Cached ON THE ROW, which is a fresh table for every sync, so the cache
    -- cannot outlive the roster it describes.
    if (row.jobText ~= nil) then
        return row.jobText;
    end

    local main = JOB_NAMES[row.mjob] or string.format('job %d', row.mjob);

    if (row.sjob == 0 or row.slvl == 0) then
        row.jobText = string.format('%s%d', main, row.mlvl);
    else
        local sub = JOB_NAMES[row.sjob] or string.format('job %d', row.sjob);

        row.jobText = string.format('%s%d/%s%d', main, row.mlvl, sub, row.slvl);
    end

    return row.jobText;
end

-- The level the character HOLDS in the tab's job, whether or not it is on
-- it. The wire has carried blu/pup/cor since the first version (`c|`
-- columns nine to eleven) and the picker never said them, so a greyed row
-- read "not on this job" whether the character had the job at 75 or had
-- never touched it -- which of the two is the only thing that decides
-- whether /jobs is worth typing (2026-09-06).
local function heldLevel(row, jobId)
    if (jobId == JOB_BLU) then
        return row.blu or 0;
    elseif (jobId == JOB_PUP) then
        return row.pup or 0;
    end

    return row.cor or 0;
end

--[[
* The picker's row order: characters ON the tab's job first, then the rest.
*
* The comment over this combo has said "characters ON the job first" since the
* first version and the loop simply walked the wire order (2026-09-06), so on
* an account with a dozen characters the one or two that can actually be
* picked sat wherever the roster happened to put them, with greyed rows above
* and below. Two passes rather than a sort: table.sort is not stable, and the
* order INSIDE each half is the roster's own and worth keeping. Memoised on
* the roster's revision because an open popup rebuilds this every frame.
--]]
local pickerRows    = { };
local pickerRowsRev = -1;

local function pickerView(jobId)
    if (pickerRowsRev ~= state.charsRev) then
        pickerRows    = { };
        pickerRowsRev = state.charsRev;
    end

    local rows = pickerRows[jobId];

    if (rows == nil) then
        rows = T{ };

        for _, row in ipairs(state.chars) do
            if (onJob(row, jobId) and not row.self) then
                rows:append(row);
            end
        end

        for _, row in ipairs(state.chars) do
            if (not (onJob(row, jobId) and not row.self)) then
                rows:append(row);
            end
        end

        pickerRows[jobId] = rows;
    end

    return rows;
end

-- The character combo shared by the two builder tabs: characters ON the
-- job first, the rest greyed with the reason.
local function characterPicker(id, jobId, picked, onPick, tipText)
    local current = picked ~= nil and charOf(picked) or nil;
    local label   = current ~= nil and string.format('%s (%s)', current.name, jobLabel(current)) or 'Pick a character...';

    imgui.SetNextItemWidth(240);

    local open = imgui.BeginCombo('##dwtoau_pick_' .. id, label);

    tip(tipText);

    if (open) then
        if (#state.chars == 0) then
            imgui.TextDisabled('No characters yet -- Refresh asks the server for the roster.');
        end

        for _, row in ipairs(pickerView(jobId)) do
            local eligible = onJob(row, jobId) and not row.self;

            -- Cached ON THE ROW, beside its job label and for the same
            -- reason: the popup rebuilt this whole sentence for every roster
            -- row on every frame it was open, and none of it moves until the
            -- roster does. Two entries per row, one per picker, because the
            -- reason a row is greyed is a fact about the tab's job
            -- (2026-09-06).
            if (row.pickLabels == nil) then
                row.pickLabels = { };
            end

            local label = row.pickLabels[id];

            if (label == nil) then
                local held = heldLevel(row, jobId);
                local why  = '';

                if (row.self) then
                    why = '  (you -- use the game menu)';
                elseif (not eligible) then
                    why = held > 0
                        and string.format('  (has the job at %d -- /jobs switches it)', held)
                        or '  (has never had this job)';
                end

                label = string.format('%s  %s%s##dwtoau_pick_%s_%d', row.name, jobLabel(row), why, id, row.charid);
                row.pickLabels[id] = label;
            end

            if (not eligible) then imgui.BeginDisabled(); end

            if (imgui.Selectable(label, picked == row.charid)) then
                onPick(row.charid);
            end

            if (not eligible) then imgui.EndDisabled(); end
        end

        imgui.EndCombo();
    end
end

local function statusLine()
    if (state.pending ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled('applying...');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('One write is on its way to the server. This window keeps exactly ONE in flight -- a replayed roll is a second roll -- and the buttons come back when the answer lands, or after five seconds.');
        end
    end

    if (state.status ~= nil and state.status ~= '') then
        -- WRAPPED (2026-09-06): the server's refusals are whole sentences and
        -- the longest of them run well past the window's width, where an
        -- unwrapped TextColored simply ran off the right edge and the half
        -- that said what to do about it was never on screen.
        imgui.PushTextWrapPos(0);

        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end

        tip(TIPS.status);

        imgui.PopTextWrapPos();
    end

    -- The one thing that is nobody's mistake (2026-09-06): the three jobs do
    -- not exist on this server yet, and every empty picker below is that and
    -- not the player. Said only when the server itself said so.
    if (state.toauOpen == false) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(theme.colors.warn, TOAU_CLOSED);
        imgui.PopTextWrapPos();
    end
end

--[[
* Blue Mage tab.
--]]
local function bluePointsUsed()
    local points = 0;

    for _, id in ipairs(state.bluWork) do
        local row = state.blu and state.blu.byId[id] or nil;

        points = points + (row and row.points or 0);
    end

    return points;
end

-- Why Apply is not pressable, in one sentence, or what it will do when it
-- is. Called only from inside an IsItemHovered guard, so its string.format
-- is paid when a player is actually pointing at the marker.
local function blueApplyWhy(header, slots, used)
    if (state.pending ~= nil) then
        return 'Apply is off: one write is in flight and this window keeps exactly one. It comes back when the server answers, or after five seconds.';
    end

    if (slots > header.slots) then
        return string.format('Apply is off: %d spells set against %d slots. Take some out.', slots, header.slots);
    end

    if (used > header.points) then
        return string.format('Apply is off: %d set points spent of %d. Take something out.', used, header.points);
    end

    if (not state.bluDirty) then
        return 'Apply is off: the working set already matches what the server holds. Nothing to send.';
    end

    return 'Apply sends the WHOLE set in one line -- a lost line costs a click, never a slot. The server re-checks all of it on the way in.';
end

--[[
* "Is this spell in the working set", as a lookup rather than a walk.
*
* The known table asks it once per row per frame -- two hundred rows against
* a twenty-entry list is four thousand comparisons every frame for an answer
* that changes only when the player clicks something. Rebuilt on the working
* set's own revision (2026-09-06).
--]]
local blueHeld    = {};
local blueHeldRev = -1;

local function blueHeldMap()
    if (blueHeldRev ~= state.bluRev) then
        blueHeld    = {};
        blueHeldRev = state.bluRev;

        for _, id in ipairs(state.bluWork) do
            blueHeld[id] = true;
        end
    end

    return blueHeld;
end

local function blueHas(id)
    return blueHeldMap()[id] == true;
end

local function blueRemove(id)
    for index, existing in ipairs(state.bluWork) do
        if (existing == id) then
            table.remove(state.bluWork, index);

            state.bluRev   = state.bluRev + 1;
            state.bluDirty = true;

            return;
        end
    end
end

local function blueAdd(id)
    if (blueHas(id)) then
        return;
    end

    state.bluWork:append(id);

    state.bluRev   = state.bluRev + 1;
    state.bluDirty = true;
end

--[[
* The trait totals for the working set, memoised on the set's own revision.
*
* traitProgress walks the set, allocates a table per category, sorts and
* formats a sentence for each. It ran on EVERY frame for a result that moves
* only when the player clicks a spell (2026-09-06).
--]]
local traitLines   = T{ };
local traitLineRev = -1;

local function blueTraitProgress()
    if (traitLineRev ~= state.bluRev) then
        traitLines   = traitProgress(state.bluWork);
        traitLineRev = state.bluRev;
    end

    return traitLines;
end

--[[
* The filtered known list, rebuilt only when the model, the filter box or
* the kind picker changes (dwah's view-cache rule).
*
* Before this the render pass lowered and searched every one of the two
* hundred known names on every frame -- two hundred throwaway strings and
* two hundred `find`s, sixty times a second, for a filter box most players
* leave empty and a list that only moves when the server answers.
--]]
local blueRows      = T{ };
local blueRowsRev   = -1;
local blueRowsText  = nil;
local blueRowsKind  = -1;
local blueRowsSort  = -1;

-- The comparator for a BLU_SORTS choice, or nil for the server's own order.
-- Sorted into the VIEW, never the model: the wire's order is still the wire's.
local function blueSorter(mode)
    if (mode == 2) then
        return function (a, b)
            local left, right = lowered(spellName(a.id)), lowered(spellName(b.id));

            if (left ~= right) then
                return left < right;
            end

            return a.id < b.id;
        end;
    elseif (mode == 3) then
        return function (a, b)
            if (a.level ~= b.level) then
                return a.level < b.level;
            end

            return a.id < b.id;
        end;
    elseif (mode == 4) then
        return function (a, b)
            if (a.points ~= b.points) then
                return a.points < b.points;
            end

            return a.id < b.id;
        end;
    end

    return nil;
end

local function blueView()
    if (blueRowsRev == state.bluModelRev and blueRowsText == state.bluFilter[1]
            and blueRowsKind == state.bluKind[1] and blueRowsSort == state.bluSort[1]) then
        return blueRows;
    end

    blueRowsRev  = state.bluModelRev;
    blueRowsText = state.bluFilter[1];
    blueRowsKind = state.bluKind[1];
    blueRowsSort = state.bluSort[1];
    blueRows     = T{ };

    -- Not through lowered(): that table is for names, and every prefix a
    -- player types through the box would take a permanent seat in it.
    local needle = blueRowsText:lower();
    local wanted = blueRowsKind > 1 and KIND_ORDER[blueRowsKind - 1] or nil;
    local known  = state.blu ~= nil and state.blu.known or T{ };

    for _, row in ipairs(known) do
        if ((needle == '' or lowered(spellName(row.id)):find(needle, 1, true) ~= nil)
                and (wanted == nil or row.kind == wanted)) then
            blueRows:append(row);
        end
    end

    local sorter = blueSorter(blueRowsSort);

    if (sorter ~= nil) then
        table.sort(blueRows, sorter);
    end

    return blueRows;
end

-- Why a Set button is greyed, said on the row's own hover card: the button
-- itself is disabled and ImGui reports no hover for those at all.
local function blueSetWhy(row, header, tooHigh, slots, used)
    if (blueHas(row.id)) then
        return 'In the set. Unset takes it out again -- nothing is sent until Apply.';
    end

    if (tooHigh) then
        return string.format('Cannot be set: it needs BLU%d and this character is BLU%d.', row.level, header.level);
    end

    if (slots >= header.slots) then
        return string.format('Cannot be set: all %d slots are full. Take one out first.', header.slots);
    end

    if (used + row.points > header.points) then
        return string.format('Cannot be set: it costs %d set points and only %d are left.',
            row.points, math.max(0, header.points - used));
    end

    return nil;
end

-- Returns whether the line actually left, so Load & Apply can say which of
-- the two things happened rather than claiming the second one either way.
local function applyBlue()
    if (state.bluPick == nil) then
        return false;
    end

    local ids = T{ };

    for _, id in ipairs(state.bluWork) do
        ids:append(tostring(id));
    end

    return sendWrite('bluset', state.bluPick, string.format('bluset %d %s', state.bluPick, #ids > 0 and table.concat(ids, ',') or '0'));
end

--[[
* Blue magic presets. Save keeps the WORKING set as it stands in the left
* panel (applied or not) under a name; Load rebuilds the working set from a
* preset against what THIS character can have -- a spell the account does
* not know, one above the character's level, or one the slot and point
* budget cannot hold is skipped and counted -- and Load & Apply presses
* Apply when nothing had to be skipped. The set is filled in preset order,
* so a preset's first spells are the ones that survive a tighter budget.
--]]
local function saveBluePreset(raw)
    local name = cleanPresetName(raw);

    if (name == '') then
        state.status    = 'Give the preset a name first.';
        state.statusBad = true;

        return;
    end

    if (#state.bluWork == 0) then
        state.status    = 'Nothing to save -- the set is empty.';
        state.statusBad = true;

        return;
    end

    local ids = T{ };

    for _, id in ipairs(state.bluWork) do
        ids:append(id);
    end

    if (putPreset(presets.blu, { name = name, ids = ids })) then
        state.bluPreset = name;
        state.status    = string.format('Saved preset "%s": %d spell(s). Presets live on this PC, for every character on the account.', name, #ids);
        state.statusBad = false;
    else
        state.status    = presetsNote or 'Could not save the preset.';
        state.statusBad = true;
    end
end

local function loadBluePreset(entry)
    local header  = state.blu.header;
    local work    = T{ };
    local used    = 0;
    local unknown = 0;
    local tooHigh = 0;
    local over    = 0;

    for _, id in ipairs(entry.ids) do
        local row  = state.blu.byId[id];
        local held = false;

        for _, existing in ipairs(work) do
            if (existing == id) then
                held = true;
            end
        end

        if (held) then
            -- A preset naming a spell twice is one spell.
        elseif (row == nil) then
            unknown = unknown + 1;
        elseif (row.level > header.level) then
            tooHigh = tooHigh + 1;
        elseif (#work >= header.slots or used + row.points > header.points) then
            over = over + 1;
        else
            work:append(id);
            used = used + row.points;
        end
    end

    state.bluWork  = work;
    state.bluRev   = state.bluRev + 1;
    state.bluDirty = not sameList(work, state.blu.set);

    local skipped = skippedText({
        { unknown, 'not known to the account' },
        { tooHigh, string.format('above BLU%d', header.level) },
        { over,    'over the slot or point budget' },
    });

    state.status    = string.format('Loaded "%s": %d spell(s)%s.', entry.name, #work, skipped);
    state.statusBad = false;

    return skipped == '';
end

--[[
* The three preset buttons grey together when no preset is picked, and a
* greyed button cannot draw a tooltip at all (dwbags' rule), so the label
* that opens the row carries the reason for all three. It is a TextDisabled
* and therefore never itself disabled.
--]]
--[[
* How wide the preset row's two boxes may be. Seven controls on one line -- a
* label, the preset combo, Load, Load & Apply, Delete, the name box and Save
* -- measured about 680 pixels in the default font, which is inside the
* window's 700 floor by a margin that a larger font eats whole. The five
* label-sized controls are measured; the combo and the name box divide what
* is left in the 170:130 proportion they were drawn in, and neither goes below
* the width its own hint text needs.
--]]
local function presetRowWidths(saveLabel)
    local fixed = textWidth('Presets:', 55)
        + textWidth('Load', 30) + FRAME_PAD
        + textWidth('Load & Apply', 84) + FRAME_PAD
        + textWidth('Delete', 42) + FRAME_PAD
        + textWidth(saveLabel, 62) + FRAME_PAD
        + 6 * ITEM_SPACING;

    local room  = regionWidth() - fixed;
    local combo = math.max(110, math.min(170, math.floor(room * 170 / 300)));

    return combo, math.max(90, math.min(130, math.floor(room - combo)));
end

local function presetsWhy(list, picked)
    if (picked ~= nil) then
        return 'Load, Load & Apply and Delete act on the preset named in the box beside this. Presets live on this PC, for every character on the account -- the server never sees one.';
    end

    if (#list == 0) then
        return 'No presets saved yet. Build a set, type a name in the box on the right and Save -- the file is on this PC and covers the whole account.';
    end

    return 'Load, Load & Apply and Delete are greyed because no preset is picked. Choose one from the list beside this.';
end

local function bluePresetRow()
    local picked            = presetByName(presets.blu, state.bluPreset);
    local comboWidth, nameWidth = presetRowWidths('Save set');

    imgui.TextDisabled('Presets:');

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(presetsWhy(presets.blu, picked));
    end

    imgui.SameLine();
    imgui.SetNextItemWidth(comboWidth);

    local label = picked ~= nil and picked.name or (#presets.blu > 0 and 'pick a preset...' or 'none saved yet');

    local openPreset = imgui.BeginCombo('##dwtoau_blu_preset', label);

    tip(TIPS.presetPick);

    if (openPreset) then
        for _, entry in ipairs(presets.blu) do
            if (imgui.Selectable(string.format('%s  (%d)##dwtoau_blu_preset_%s', entry.name, #entry.ids, entry.name), picked ~= nil and picked.name == entry.name)) then
                state.bluPreset         = entry.name;
                state.bluPresetName[1]  = entry.name;
            end
        end

        imgui.EndCombo();
    end

    imgui.SameLine();

    if (picked == nil) then imgui.BeginDisabled(); end

    if (imgui.SmallButton('Load##dwtoau_blu_preset_load')) then
        loadBluePreset(picked);
    end

    tip(TIPS.presetLoad);

    imgui.SameLine();

    if (imgui.SmallButton('Load & Apply##dwtoau_blu_preset_apply')) then
        local whole  = loadBluePreset(picked);
        local header = state.blu.header;

        if (not state.bluDirty) then
            state.status = state.status .. ' Already set on this character.';
        elseif (not whole) then
            state.status = state.status .. ' Not applied: look the set over, then Apply.';
        elseif (state.pending ~= nil) then
            state.status = state.status .. ' Not applied: another write is still in flight.';
        elseif (#state.bluWork <= header.slots and bluePointsUsed() <= header.points) then
            local loaded = state.status;

            if (applyBlue()) then
                state.status = loaded .. ' Applying...';
            else
                state.status    = loaded .. ' Not applied: the client is still zoning -- press Apply in a moment.';
                state.statusBad = true;
            end
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Load the preset and Apply it in one click -- applied only when nothing had to be skipped.');
    end

    imgui.SameLine();

    if (imgui.SmallButton('Delete##dwtoau_blu_preset_delete')) then
        local name = picked.name;

        if (dropPreset(presets.blu, name)) then
            state.bluPreset = nil;
            state.status    = string.format('Deleted preset "%s".', name);
            state.statusBad = false;
        else
            -- The entry is out of memory either way; it is the FILE that
            -- refused, so the next window open reads the preset back and the
            -- player has to be told that rather than watching it return
            -- (2026-09-06).
            state.status    = string.format('"%s" is out of the window but still in the file: %s', name,
                presetsNote or 'the presets file could not be written.');
            state.statusBad = true;
        end
    end

    tip(TIPS.presetDrop);

    if (picked == nil) then imgui.EndDisabled(); end

    imgui.SameLine();
    imgui.SetNextItemWidth(nameWidth);
    imgui.InputTextWithHint('##dwtoau_blu_preset_name', 'preset name', state.bluPresetName, PRESET_NAME_MAX + 1);

    local canSave = #state.bluWork > 0 and cleanPresetName(state.bluPresetName[1]) ~= '';

    -- The name box is never disabled, so it carries the reason Save is
    -- (dwbags' rule again).
    if (imgui.IsItemHovered()) then
        if (#state.bluWork == 0) then
            imgui.SetTooltip('Save is off: the working set is empty, and an empty preset is a name with nothing behind it.');
        elseif (not canSave) then
            imgui.SetTooltip('Save is off until this box holds a name -- letters, digits, spaces, - _ . and \', up to 24 characters.');
        else
            imgui.SetTooltip(TIPS.presetName);
        end
    end

    imgui.SameLine();

    if (not canSave) then imgui.BeginDisabled(); end

    if (imgui.SmallButton('Save set##dwtoau_blu_preset_save')) then
        saveBluePreset(state.bluPresetName[1]);
    end

    if (not canSave) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Save the set as it stands on the left (applied or not) under this name. The same name overwrites.');
    end

    if (presetsNote ~= nil) then
        imgui.TextColored(theme.colors.warn, presetsNote);
    end
end

local function blueTab()
    characterPicker('blu', JOB_BLU, state.bluPick, function (charid)
        if (state.bluPick ~= charid) then
            state.bluPick     = charid;
            state.blu         = nil;
            state.bluWork     = T{ };
            state.bluRev      = state.bluRev + 1;
            state.bluModelRev = state.bluModelRev + 1;
            state.bluDirty    = false;

            requestBlue();
        end
    end, TIPS.pickBlue);

    imgui.SameLine();

    -- WRAPPED (2026-09-06): the picker beside it is 240 pixels and this
    -- sentence is another four hundred, so at the window's own floor the two
    -- are within a pixel of the right edge -- and a player running a larger
    -- font simply loses the end of it. It is the only thing on the row that
    -- can wrap harmlessly.
    imgui.PushTextWrapPos(0);
    imgui.TextDisabled('Spells anyone on your account has learned are known to every squad member.');
    imgui.PopTextWrapPos();

    if (state.bluPick == nil) then
        if (state.toauOpen == false) then
            imgui.TextDisabled('Nothing to pick: no character can be on BLU while the expansion is closed.');
        else
            imgui.TextDisabled('Pick a squad blue mage. A character not on BLU is set from /jobs first.');
        end

        return;
    end

    if (state.blu == nil) then
        imgui.TextDisabled('Fetching the blue magic list from the server...');

        return;
    end

    local header = state.blu.header;
    local used   = bluePointsUsed();
    local slots  = #state.bluWork;

    imgui.Text(string.format('%s -- BLU%d (%s job)', header.name, header.level, header.job == 1 and 'main' or (header.job == 2 and 'support' or 'not set')));

    -- The SameLine belongs INSIDE the branch. Outside it (2026-09-06) a
    -- character that was NOT out left the cursor parked on the name's line
    -- with nothing following, so the two budget bars, Apply and Revert all
    -- drew on the header row -- one layout for a member standing in the
    -- party and a different one for a member at home.
    if (header.out) then
        imgui.SameLine();
        imgui.TextColored(theme.colors.info, '[out in your party: an Apply re-arms it on the spot]');
        tip(TIPS.bluOut);
    end

    local slotFraction  = header.slots > 0 and (slots / header.slots) or 0;
    local pointFraction = header.points > 0 and (used / header.points) or 0;

    --[[
        THE ROW MEASURES ITSELF (2026-09-06). The fixed half -- Apply, Revert,
        the marker, Clear and Copy -- is measured in the live font, and the two
        bars take half of what is left each. The 140-pixel floor is deliberate:
        below it a bar cannot draw 'Set points  12 / 45' at all, and a row that
        overflows a window the player can widen beats two illegible bars.
    ]]
    -- Apply and Revert are FIXED width on purpose -- their labels never
    -- change, and a row whose buttons move is a row that jumps -- but the
    -- number is measured rather than typed, so a larger font widens them
    -- instead of clipping them, and the arithmetic below uses the same one.
    local buttonWidth = math.max(70, textWidth('Revert', 42) + FRAME_PAD + 10);
    local fixed = 2 * buttonWidth
        + math.max(textWidth('unsaved', 55), textWidth('in sync', 55))
        + textWidth('Clear', 34) + FRAME_PAD
        + textWidth('Copy', 32) + FRAME_PAD
        + 6 * ITEM_SPACING;
    local barWidth = math.max(140, math.min(220, math.floor((regionWidth() - fixed) / 2)));

    imgui.ProgressBar(math.min(slotFraction, 1), { barWidth, 16 }, string.format('Slots  %d / %d', slots, header.slots));
    tip(TIPS.slotBar);
    imgui.SameLine();
    imgui.ProgressBar(math.min(pointFraction, 1), { barWidth, 16 }, string.format('Set points  %d / %d', used, header.points));
    tip(TIPS.pointBar);
    imgui.SameLine();

    local canApply = state.pending == nil and state.bluDirty and slots <= header.slots and used <= header.points;

    if (not canApply) then imgui.BeginDisabled(); end

    if (imgui.Button('Apply##dwtoau_blu_apply', { buttonWidth, 0 })) then
        applyBlue();
    end

    if (not canApply) then imgui.EndDisabled(); end

    imgui.SameLine();

    --[[
        THE CONDITION IS CAPTURED FIRST, and that is the whole point
        (2026-09-06). Revert is pressable only while the working set is
        DIRTY, so BeginDisabled is skipped -- and the press then sets
        `state.bluDirty` false, so the closing test read TRUE and called
        EndDisabled with nothing open. ImGui asserts on that in a debug build
        and, in the release build the players run, decrements its disabled
        stack past zero and pops a style var that was never pushed: every
        control drawn after it in that frame is judged against a corrupted
        stack. Every other Begin/EndDisabled pair in this file already tests
        a local decided before the button; these two tested live state the
        button itself moves.
    ]]
    local canRevert = state.bluDirty;

    if (not canRevert) then imgui.BeginDisabled(); end

    if (imgui.Button('Revert##dwtoau_blu_revert', { buttonWidth, 0 })) then
        state.bluWork = T{ };
        state.bluRev  = state.bluRev + 1;

        for _, id in ipairs(state.blu.set) do
            state.bluWork:append(id);
        end

        state.bluDirty = false;
    end

    tip(TIPS.revertBlue);

    if (not canRevert) then imgui.EndDisabled(); end

    -- THE REASON APPLY IS GREY LIVES ON THIS MARKER, not on Apply (dwbags'
    -- rule, 2026-09-06): ImGui reports no hover at all for a disabled item
    -- unless the test is asked to allow it, and that flag is the newest
    -- generation API this suite does not use -- so a SetTooltip written on
    -- the greyed button would be dead code wearing the courtesy's name. The
    -- marker is never disabled, and it is beside the button it explains.
    imgui.SameLine();

    if (state.bluDirty) then
        imgui.TextColored(theme.colors.warn, 'unsaved');
    else
        imgui.TextDisabled('in sync');
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(blueApplyWhy(header, slots, used));
    end

    imgui.SameLine();

    if (imgui.SmallButton('Clear##dwtoau_blu_clear')) then
        if (#state.bluWork > 0) then
            state.bluWork  = T{ };
            state.bluRev   = state.bluRev + 1;
            state.bluDirty = not sameList(state.bluWork, state.blu.set);
        end
    end

    tip(TIPS.bluClear);
    imgui.SameLine();

    if (imgui.SmallButton('Copy##dwtoau_blu_copy')) then
        local names = T{ };

        for _, id in ipairs(state.bluWork) do
            names:append(spellName(id));
        end

        -- pcall'd: an Ashita generation without the clipboard call must
        -- not throw inside the render pcall and take the window down with
        -- it, and it must not be told it copied something either.
        local copied = pcall(imgui.SetClipboardText,
            string.format('%s -- BLU%d set (%d/%d slots, %d/%d points): %s',
                header.name, header.level, slots, header.slots, used, header.points,
                #names > 0 and table.concat(names, ', ') or 'nothing set'));

        state.status    = copied
            and string.format('Copied %d spell name(s) to the clipboard.', #names)
            or 'This Ashita build has no clipboard call -- nothing was copied.';
        state.statusBad = not copied;
    end

    tip(TIPS.bluCopy);

    bluePresetRow();

    if (slots > header.slots or used > header.points) then
        imgui.TextColored(theme.colors.err, 'Over budget -- the server would refuse this set. Remove something.');
    end

    imgui.Separator();

    --[[
        Left: the set. Right: everything known, filtered.

        The left panel takes about a THIRD of the window rather than a fixed
        250 pixels (2026-09-06). At the window's own 700-pixel floor a fixed
        250 left the known list 426 to fit a filter box, a kind picker, a sort
        picker and a count into -- seven pixels less than their own floors
        need -- so the last picker's edge was clipped at exactly the width the
        addon itself allows a player to choose. It is still bounded at both
        ends: below 210 the set's own rows clip, and above 260 it is taking
        room the two-hundred-row list wants.
    ]]
    local setWidth = math.max(210, math.min(260, math.floor(regionWidth() * 0.34)));

    if (imgui.BeginChild('##dwtoau_blu_set', { setWidth, -1 }, ImGuiChildFlags_None)) then
        imgui.TextDisabled(string.format('Set (%d):', slots));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('The spells this character will cast, in the order the server holds them. A blue mage casts only what is SET.');
        end

        if (#state.bluWork == 0) then
            imgui.TextDisabled('Nothing set. Add spells from the right.');
        end

        for _, id in ipairs(state.bluWork) do
            local row = state.blu.byId[id];

            if (imgui.SmallButton(blueDropLabel(id))) then
                blueRemove(id);
            end

            tip('Take this spell out of the set. Nothing is sent until Apply.');

            imgui.SameLine();
            imgui.Text(string.format('%s  (%d)', spellName(id), row and row.points or 0));

            if (imgui.IsItemHovered() and row ~= nil) then
                spellCard(row, 'In the set, costing the set points in brackets.');
            end
        end

        -- What the working set earns, trait by trait (the catalog's numbers).
        local progress = blueTraitProgress();

        if (#progress > 0) then
            imgui.Separator();
            imgui.TextDisabled('Job traits from this set:');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.traitBlock);
            end

            -- WRAPPED (2026-09-06): a trait line is a whole sentence --
            -- 'Plantoid Killer: 8 pt -- tier 3 (job points), next tier at 12'
            -- -- and this panel is 250 pixels wide, so the half that says what
            -- is still owed was clipped off the right of the panel every time.
            imgui.PushTextWrapPos(0);

            for _, line in ipairs(progress) do
                if (line.reached) then
                    imgui.TextColored(theme.colors.ok, line.text);
                else
                    imgui.TextDisabled(line.text);
                end
            end

            imgui.PopTextWrapPos();
        elseif (#state.bluWork > 0 and not haveCatalog) then
            imgui.Separator();
            imgui.TextDisabled('(bluecatalog.lua missing: trait progress unavailable)');
        end
    end

    imgui.EndChild();
    imgui.SameLine();

    if (imgui.BeginChild('##dwtoau_blu_known', { -1, -1 }, ImGuiChildFlags_None)) then
        -- The filtered rows, built once per change rather than once per
        -- frame; the count then says how much the filter is hiding, and the
        -- row is measured around it rather than laid out in hard pixels
        -- (2026-09-06: the sort picker joined this row, and three boxes plus
        -- a count do not fit the panel the way two did).
        local rows      = blueView();
        local countText = (#rows == #state.blu.known)
            and string.format('%d known', #state.blu.known)
            or string.format('%d of %d known', #rows, #state.blu.known);

        local boxes  = math.max(290, regionWidth() - textWidth('888 of 888 known', 108) - 3 * ITEM_SPACING);
        local filterWidth = math.max(100, math.floor(boxes * 0.38));
        local kindWidth   = math.max(90, math.floor(boxes * 0.28));
        local sortWidth   = math.max(100, boxes - filterWidth - kindWidth);

        imgui.SetNextItemWidth(filterWidth);
        imgui.InputTextWithHint('##dwtoau_blu_filter', 'filter...', state.bluFilter, 48);
        tip(TIPS.bluFilter);
        imgui.SameLine();
        imgui.SetNextItemWidth(kindWidth);

        local kindLabel = state.bluKind[1] == 1 and 'All kinds' or KINDS[KIND_ORDER[state.bluKind[1] - 1]];
        local openKind  = imgui.BeginCombo('##dwtoau_blu_kind', kindLabel);

        tip(TIPS.bluKind);

        if (openKind) then
            if (imgui.Selectable('All kinds##dwtoau_blu_kind_0', state.bluKind[1] == 1)) then
                state.bluKind[1] = 1;
            end

            for i, letter in ipairs(KIND_ORDER) do
                if (imgui.Selectable(string.format('%s##dwtoau_blu_kind_%d', KINDS[letter], i), state.bluKind[1] == i + 1)) then
                    state.bluKind[1] = i + 1;
                end
            end

            imgui.EndCombo();
        end

        imgui.SameLine();
        imgui.SetNextItemWidth(sortWidth);

        local openSort = imgui.BeginCombo('##dwtoau_blu_sort', BLU_SORTS[state.bluSort[1]] or BLU_SORTS[1]);

        tip(TIPS.bluSort);

        if (openSort) then
            for i, name in ipairs(BLU_SORTS) do
                if (imgui.Selectable(string.format('%s##dwtoau_blu_sort_%d', name, i), state.bluSort[1] == i)) then
                    state.bluSort[1] = i;
                end
            end

            imgui.EndCombo();
        end

        imgui.SameLine();
        imgui.TextDisabled(countText);
        tip(TIPS.bluKnown);

        -- ScrollY with the header row frozen (2026-09-06): the table used to
        -- scroll with the child around it, so 'Spell / Lv / Pts / Kind / Set'
        -- left the top of the panel on the first wheel click and the columns
        -- went unlabelled for the rest of a two-hundred-row list.
        if (imgui.BeginTable('##dwtoau_blu_table', 5,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
            -- Measured rather than guessed, for the Cost column's reason: a
            -- FIXED column neither wraps nor scrolls, so anything past its
            -- width is cut off. 'Physical' against 64 pixels and an 'Unset'
            -- button against 44 were both inside a pixel or two of clipping
            -- in the default font, and a player running a larger one lost
            -- them (2026-09-06).
            imgui.TableSetupColumn('Spell', ImGuiTableColumnFlags_WidthStretch, 0, 0);
            imgui.TableSetupColumn('Lv', ImGuiTableColumnFlags_WidthFixed,
                math.max(34, textWidth('99', 16) + 18), 0);
            imgui.TableSetupColumn('Pts', ImGuiTableColumnFlags_WidthFixed,
                math.max(34, textWidth('Pts', 22) + 12), 0);
            imgui.TableSetupColumn('Kind', ImGuiTableColumnFlags_WidthFixed,
                math.max(64, textWidth('Physical', 56) + 12), 0);
            imgui.TableSetupColumn('Set', ImGuiTableColumnFlags_WidthFixed,
                math.max(44, textWidth('Unset', 36) + FRAME_PAD + 6), 0);
            imgui.TableSetupScrollFreeze(0, 1);
            imgui.TableHeadersRow();

            for _, row in ipairs(rows) do
                imgui.TableNextRow();
                imgui.TableNextColumn();

                local tooHigh = row.level > header.level;
                local name    = spellName(row.id);

                if (tooHigh) then
                    imgui.TextDisabled(name);
                else
                    imgui.Text(name);
                end

                -- The hover card on the name (owner request 2026-09-03):
                -- description, stat bonuses, job trait, level, MP, points --
                -- and, since 2026-09-06, why the Set beside it is greyed.
                if (imgui.IsItemHovered()) then
                    spellCard(row, blueSetWhy(row, header, tooHigh, slots, used));
                end

                imgui.TableNextColumn();
                imgui.Text(numText(row.level));
                imgui.TableNextColumn();
                imgui.Text(numText(row.points));
                imgui.TableNextColumn();
                imgui.Text(KINDS[row.kind] or row.kind);
                imgui.TableNextColumn();

                if (blueHas(row.id)) then
                    if (imgui.SmallButton(blueUnsetLabel(row.id))) then
                        blueRemove(row.id);
                    end
                else
                    local canAdd = not tooHigh and slots < header.slots and used + row.points <= header.points;

                    if (not canAdd) then imgui.BeginDisabled(); end

                    if (imgui.SmallButton(blueSetLabel(row.id))) then
                        blueAdd(row.id);
                    end

                    if (not canAdd) then imgui.EndDisabled(); end
                end
            end

            imgui.EndTable();
        end
    end

    imgui.EndChild();
end

--[[
* Puppetmaster tab.
--]]
local function partRow(list, id)
    for _, row in ipairs(list) do
        if (row.id == id) then
            return row;
        end
    end

    return nil;
end

-- The working build's capacity (frame + head nibbles) and load (the
-- attachments' nibbles), per element.
local function pupBudget()
    local capacity = T{ };
    local load     = T{ };

    local frame = partRow(state.pup.frames, state.pupWork.frame);
    local head  = partRow(state.pup.heads, state.pupWork.head);

    for element = 1, 8 do
        capacity[element] = ((frame and frame.elements[element]) or 0) + ((head and head.elements[element]) or 0);
        load[element]     = 0;
    end

    for slot = 1, ATTACHMENT_SLOTS do
        local id = state.pupWork.attachments[slot];

        if (id ~= 0) then
            local row = state.pup.unlockedById[id];

            if (row ~= nil) then
                for element = 1, 8 do
                    load[element] = load[element] + (row.elements[element] or 0);
                end
            end
        end
    end

    return capacity, load;
end

--[[
* The working build's capacity and load, and whether a part still fits, both
* memoised on the build's own revision (2026-09-06).
*
* pupBudget walks twelve slots and eight elements and allocates two tables; it
* ran once a frame. pupFits ran for EVERY one of ~230 unlocked rows on every
* frame -- eight comparisons apiece, near two thousand of them a frame -- for
* an answer that moves only when the player changes the frame, the head or a
* slot. The MODEL revision is in the key as well as the working one, because
* the element numbers themselves ride the `f|`/`h|`/`a|` records.
--]]
local pupCapacity    = nil;
local pupLoad        = nil;
local pupBudgetRev   = -1;
local pupBudgetModel = -1;

local pupFitsMap   = {};
local pupFitsRev   = -1;
local pupFitsModel = -1;

--[[
* Which slot an attachment sits in, as a lookup rather than a twelve-slot
* walk per row per frame. Rebuilt on the working build's own revision, the
* Blue Mage tab's rule (2026-09-06).
--]]
local pupSlotOf  = {};
local pupSlotRev = -1;

local function pupSlotMap()
    if (pupSlotRev ~= state.pupRev) then
        pupSlotOf  = {};
        pupSlotRev = state.pupRev;

        for slot = 1, ATTACHMENT_SLOTS do
            -- The working copy is dropped whole when the pick changes, and a
            -- revision bump can land in that gap.
            local id = state.pupWork ~= nil and state.pupWork.attachments[slot] or 0;

            if (id ~= 0 and pupSlotOf[id] == nil) then
                pupSlotOf[id] = slot;
            end
        end
    end

    return pupSlotOf;
end

local function pupHas(id)
    return pupSlotMap()[id];
end

local function pupFits(row, capacity, load)
    for element = 1, 8 do
        if (load[element] + (row.elements[element] or 0) > capacity[element]) then
            return false;
        end
    end

    return true;
end

local function pupBudgetCached()
    if (pupCapacity == nil or pupBudgetRev ~= state.pupRev or pupBudgetModel ~= state.pupModelRev) then
        pupCapacity, pupLoad = pupBudget();
        pupBudgetRev         = state.pupRev;
        pupBudgetModel       = state.pupModelRev;
    end

    return pupCapacity, pupLoad;
end

--[[
* A MEMO DERIVES WHAT IT IS KEYED ON (2026-09-06, found reviewing this
* round's own perf pass). This took the frame's capacity and load as
* arguments and filed the answer under the build's revision -- and an On or
* an Off clicked INSIDE the table's own loop bumps that revision mid-frame,
* so every row drawn after the clicked one was filed under the NEW revision
* with the OLD numbers, and stayed wrong for as long as nothing else moved.
* Both halves now come from the same memo, so they cannot disagree.
--]]
local function pupFitsCached(row)
    if (pupFitsRev ~= state.pupRev or pupFitsModel ~= state.pupModelRev) then
        pupFitsMap   = {};
        pupFitsRev   = state.pupRev;
        pupFitsModel = state.pupModelRev;
    end

    local fits = pupFitsMap[row.id];

    if (fits == nil) then
        local capacity, load = pupBudgetCached();

        fits = pupFits(row, capacity, load);
        pupFitsMap[row.id] = fits;
    end

    return fits;
end

local function pupOverloaded(capacity, load)
    for element = 1, 8 do
        if (load[element] > capacity[element]) then
            return true;
        end
    end

    return false;
end

local function pupFreeSlot()
    for slot = 1, ATTACHMENT_SLOTS do
        if (state.pupWork.attachments[slot] == 0) then
            return slot;
        end
    end

    return nil;
end

--[[
* How wide the Cost column has to be, measured from the widest cost THIS
* account actually holds and recomputed only when the model changes.
*
* It was 110 pixels, guessed. An attachment that spends three elements reads
* 'Fir 2 Ice 1 Win 1' -- seventeen characters, half again as wide as the
* guess -- and a fixed column does not scroll or wrap, so the end of it was
* simply cut off, on the one column of that table a player is reading the
* capacity bars against (2026-09-06).
--]]
local costColumn    = 110;
local costColumnRev = -1;

local function costColumnWidth()
    if (costColumnRev ~= state.pupModelRev) then
        costColumnRev = state.pupModelRev;
        costColumn    = textWidth('Cost', 30);

        for _, row in ipairs(state.pup ~= nil and state.pup.unlocked or T{ }) do
            local width = textWidth(row.costText or '-', 0);

            if (width > costColumn) then
                costColumn = width;
            end
        end

        -- A ceiling as well as a floor: a column wide enough to push the
        -- name column off the panel is its own kind of clipped.
        costColumn = math.min(math.max(costColumn + 12, 60), 220);
    end

    return costColumn;
end

--[[
* The filtered unlocked list, rebuilt only when the model or the filter box
* changes -- the Blue Mage tab's view cache, for the same reason: the old
* loop lowered and searched every unlocked name on every frame.
--]]
local pupRows      = T{ };
local pupRowsRev   = -1;
local pupRowsText  = nil;
local pupRowsSort  = -1;

-- PUP_SORTS' comparators, the Blue Mage tab's rule: view only, id last.
local function pupSorter(mode)
    if (mode == 2) then
        return function (a, b)
            local left, right = lowered(attachmentName(a.id)), lowered(attachmentName(b.id));

            if (left ~= right) then
                return left < right;
            end

            return a.id < b.id;
        end;
    elseif (mode == 3) then
        return function (a, b)
            if ((a.cost or 0) ~= (b.cost or 0)) then
                return (a.cost or 0) < (b.cost or 0);
            end

            return a.id < b.id;
        end;
    end

    return nil;
end

local function pupView()
    if (pupRowsRev == state.pupModelRev and pupRowsText == state.pupFilter[1]
            and pupRowsSort == state.pupSort[1]) then
        return pupRows;
    end

    pupRowsRev  = state.pupModelRev;
    pupRowsText = state.pupFilter[1];
    pupRowsSort = state.pupSort[1];
    pupRows     = T{ };

    local needle   = pupRowsText:lower();
    local unlocked = state.pup ~= nil and state.pup.unlocked or T{ };

    for _, row in ipairs(unlocked) do
        if (needle == '' or lowered(attachmentName(row.id)):find(needle, 1, true) ~= nil) then
            pupRows:append(row);
        end
    end

    local sorter = pupSorter(pupRowsSort);

    if (sorter ~= nil) then
        table.sort(pupRows, sorter);
    end

    return pupRows;
end

-- Why Apply is not pressable, said on a marker that is never disabled.
local function pupApplyWhy(header, overloaded)
    if (state.pending ~= nil) then
        return 'Apply is off: one write is in flight and this window keeps exactly one. It comes back when the server answers, or after five seconds.';
    end

    if (header.active) then
        return 'Apply is off: the automaton is ACTIVE. Retail\'s own rule -- Deactivate puts it away, and the squad brings the new build back out on its own.';
    end

    if (overloaded) then
        return 'Apply is off: the build is over the element capacity. Change the frame or the head, or take a part off.';
    end

    if (not state.pupDirty) then
        return 'Apply is off: the working build already matches what the server holds. Nothing to send.';
    end

    return 'Apply sends the frame, the head and all twelve slots in one line. The server re-checks the whole build on the way in.';
end

-- Why an On button is greyed, said on the row's own hover card.
local function pupEquipWhy(row, slot, free, capacity, load)
    if (slot ~= nil) then
        return 'Equipped. Off takes it out again -- nothing is sent until Apply.';
    end

    if (free == nil) then
        return 'Cannot be equipped: all twelve slots are full. Take one out first.';
    end

    if (not pupFits(row, capacity, load)) then
        local short = T{ };

        for element = 1, 8 do
            local over = load[element] + (row.elements[element] or 0) - capacity[element];

            if (over > 0) then
                short:append(string.format('%s %d', ELEMENTS[element], over));
            end
        end

        if (#short == 0) then
            return 'Cannot be equipped: the build is over the element capacity. Change the frame or head, or take a part off.';
        end

        return string.format('Cannot be equipped: over capacity by %s. Change the frame or head, or take a part off.', table.concat(short, ', '));
    end

    return nil;
end

local function applyPup()
    if (state.pupPick == nil or state.pupWork == nil) then
        return false;
    end

    local ids = T{ };

    for slot = 1, ATTACHMENT_SLOTS do
        ids:append(tostring(state.pupWork.attachments[slot] or 0));
    end

    return sendWrite('pupset', state.pupPick, string.format('pupset %d %d %d %s', state.pupPick, state.pupWork.frame, state.pupWork.head, table.concat(ids, ',')));
end

local function partPicker(id, list, picked, onPick, tipText, kind, width)
    local current = partRow(list, picked);
    local label   = current ~= nil and itemName(PART_BASE + current.id, prettify(current.name)) or '?';

    imgui.SetNextItemWidth(width);

    local open = imgui.BeginCombo('##dwtoau_pup_' .. id, label);

    -- The card on the PREVIEW, which is never disabled: it is the part the
    -- automaton is actually built on, and it is the half of the capacity
    -- bars a player is most often trying to account for.
    if (imgui.IsItemHovered()) then
        if (current ~= nil) then
            partCard(current, kind, true, tipText);
        else
            imgui.SetTooltip(tipText);
        end
    end

    if (open) then
        for _, row in ipairs(list) do
            local name = itemName(PART_BASE + row.id, prettify(row.name));

            if (not row.unlocked) then imgui.BeginDisabled(); end

            if (imgui.Selectable(string.format('%s%s##dwtoau_pup_%s_%d', name, row.unlocked and '' or '  (not unlocked)', id, row.id), picked == row.id)) then
                onPick(row.id);
            end

            -- Only the rows a player can actually pick draw a card: a locked
            -- row is disabled and ImGui reports no hover for those at all,
            -- so its own label carries the reason instead.
            if (row.unlocked and imgui.IsItemHovered()) then
                partCard(row, kind, picked == row.id, nil);
            end

            if (not row.unlocked) then imgui.EndDisabled(); end
        end

        imgui.EndCombo();
    end
end

--[[
* Automaton presets: frame, head and the twelve slots, saved from the
* working build and loaded back against what THIS account has unlocked --
* a locked frame or head keeps the current one, a part nobody unlocked or
* one the capacity cannot hold is skipped and counted, and slots keep their
* positions so a saved build comes back in the shape it was saved in.
--]]
local function savePupPreset(raw)
    local name = cleanPresetName(raw);

    if (name == '') then
        state.status    = 'Give the preset a name first.';
        state.statusBad = true;

        return;
    end

    local attachments = T{ };
    local count       = 0;

    for slot = 1, ATTACHMENT_SLOTS do
        attachments[slot] = state.pupWork.attachments[slot] or 0;

        if (attachments[slot] ~= 0) then
            count = count + 1;
        end
    end

    if (putPreset(presets.pup, { name = name, frame = state.pupWork.frame, head = state.pupWork.head, attachments = attachments })) then
        state.pupPreset = name;
        state.status    = string.format('Saved preset "%s": %s, %s, %d attachment(s). Presets live on this PC, for every character on the account.',
            name, itemName(PART_BASE + state.pupWork.frame, 'frame'), itemName(PART_BASE + state.pupWork.head, 'head'), count);
        state.statusBad = false;
    else
        state.status    = presetsNote or 'Could not save the preset.';
        state.statusBad = true;
    end
end

local function loadPupPreset(entry)
    local lockedParts = 0;
    local unknown     = 0;
    local over        = 0;
    local kept        = 0;

    local work = T{ frame = state.pupWork.frame, head = state.pupWork.head, attachments = T{ } };

    for slot = 1, ATTACHMENT_SLOTS do
        work.attachments[slot] = 0;
    end

    local frame = partRow(state.pup.frames, entry.frame);
    local head  = partRow(state.pup.heads, entry.head);

    if (frame ~= nil and frame.unlocked) then
        work.frame = entry.frame;
    else
        lockedParts = lockedParts + 1;
    end

    if (head ~= nil and head.unlocked) then
        work.head = entry.head;
    else
        lockedParts = lockedParts + 1;
    end

    -- The budget helpers read state.pupWork, so the working copy is swapped
    -- in first and the slots filled against it, one part at a time.
    state.pupWork = work;
    state.pupRev  = state.pupRev + 1;

    for slot = 1, ATTACHMENT_SLOTS do
        local id = entry.attachments[slot] or 0;

        if (id ~= 0) then
            local row = state.pup.unlockedById[id];

            if (row == nil) then
                unknown = unknown + 1;
            elseif (pupHas(id) ~= nil) then
                -- A build naming a part twice is one part.
            else
                local capacity, load = pupBudget();

                if (pupFits(row, capacity, load)) then
                    work.attachments[slot] = id;

                    -- The slot map pupHas reads is keyed on this revision and
                    -- this loop asks it between fills: without the bump the
                    -- second mention of one part would read as absent and be
                    -- equipped twice (2026-09-06, found the day the map
                    -- replaced the twelve-slot walk).
                    state.pupRev = state.pupRev + 1;
                    kept         = kept + 1;
                else
                    over = over + 1;
                end
            end
        end
    end

    state.pupDirty = not (work.frame == state.pup.header.frame and work.head == state.pup.header.head
        and sameList(work.attachments, state.pup.attachments));

    local skipped = skippedText({
        { lockedParts, 'frame or head not unlocked' },
        { unknown,     'not unlocked on the account' },
        { over,        'over the element capacity' },
    });

    state.status    = string.format('Loaded "%s": %s, %s, %d attachment(s)%s.', entry.name,
        itemName(PART_BASE + work.frame, 'frame'), itemName(PART_BASE + work.head, 'head'), kept, skipped);
    state.statusBad = false;

    return skipped == '';
end

local function pupPresetRow()
    local picked            = presetByName(presets.pup, state.pupPreset);
    local header            = state.pup.header;
    local comboWidth, nameWidth = presetRowWidths('Save build');

    imgui.TextDisabled('Presets:');

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(presetsWhy(presets.pup, picked));
    end

    imgui.SameLine();
    imgui.SetNextItemWidth(comboWidth);

    local label = picked ~= nil and picked.name or (#presets.pup > 0 and 'pick a preset...' or 'none saved yet');

    local openPreset = imgui.BeginCombo('##dwtoau_pup_preset', label);

    tip(TIPS.presetPick);

    if (openPreset) then
        for _, entry in ipairs(presets.pup) do
            -- The count the blue row has always carried (2026-09-06): a
            -- preset's name says nothing about how much of a build is in it,
            -- and 'Twin (2)' against 'Twin (11)' is the whole difference
            -- between a two-part opener and a finished automaton.
            local filled = 0;

            for slot = 1, ATTACHMENT_SLOTS do
                if ((entry.attachments[slot] or 0) ~= 0) then
                    filled = filled + 1;
                end
            end

            if (imgui.Selectable(string.format('%s  (%d)##dwtoau_pup_preset_%s', entry.name, filled, entry.name), picked ~= nil and picked.name == entry.name)) then
                state.pupPreset        = entry.name;
                state.pupPresetName[1] = entry.name;
            end
        end

        imgui.EndCombo();
    end

    imgui.SameLine();

    if (picked == nil) then imgui.BeginDisabled(); end

    if (imgui.SmallButton('Load##dwtoau_pup_preset_load')) then
        loadPupPreset(picked);
    end

    tip(TIPS.presetLoad);

    imgui.SameLine();

    if (imgui.SmallButton('Load & Apply##dwtoau_pup_preset_apply')) then
        local whole = loadPupPreset(picked);
        local capacity, load = pupBudgetCached();

        if (not state.pupDirty) then
            state.status = state.status .. ' Already equipped on this character.';
        elseif (not whole) then
            state.status = state.status .. ' Not applied: look the build over, then Apply.';
        elseif (header.active) then
            state.status = state.status .. ' Not applied: the automaton is active -- Deactivate first.';
        elseif (state.pending ~= nil) then
            state.status = state.status .. ' Not applied: another write is still in flight.';
        elseif (not pupOverloaded(capacity, load)) then
            local loaded = state.status;

            if (applyPup()) then
                state.status = loaded .. ' Applying...';
            else
                state.status    = loaded .. ' Not applied: the client is still zoning -- press Apply in a moment.';
                state.statusBad = true;
            end
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Load the preset and Apply it in one click -- applied only when nothing had to be skipped and the automaton is not active.');
    end

    imgui.SameLine();

    if (imgui.SmallButton('Delete##dwtoau_pup_preset_delete')) then
        local name = picked.name;

        if (dropPreset(presets.pup, name)) then
            state.pupPreset = nil;
            state.status    = string.format('Deleted preset "%s".', name);
            state.statusBad = false;
        else
            state.status    = string.format('"%s" is out of the window but still in the file: %s', name,
                presetsNote or 'the presets file could not be written.');
            state.statusBad = true;
        end
    end

    tip(TIPS.presetDrop);

    if (picked == nil) then imgui.EndDisabled(); end

    imgui.SameLine();
    imgui.SetNextItemWidth(nameWidth);
    imgui.InputTextWithHint('##dwtoau_pup_preset_name', 'preset name', state.pupPresetName, PRESET_NAME_MAX + 1);

    local canSave = cleanPresetName(state.pupPresetName[1]) ~= '';

    -- The name box is never disabled, so it carries the reason Save is.
    if (imgui.IsItemHovered()) then
        if (not canSave) then
            imgui.SetTooltip('Save is off until this box holds a name -- letters, digits, spaces, - _ . and \', up to 24 characters.');
        else
            imgui.SetTooltip(TIPS.presetName);
        end
    end

    imgui.SameLine();

    if (not canSave) then imgui.BeginDisabled(); end

    if (imgui.SmallButton('Save build##dwtoau_pup_preset_save')) then
        savePupPreset(state.pupPresetName[1]);
    end

    if (not canSave) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Save the frame, head and slots as they stand (applied or not) under this name. The same name overwrites.');
    end

    if (presetsNote ~= nil) then
        imgui.TextColored(theme.colors.warn, presetsNote);
    end
end

local function pupTab()
    characterPicker('pup', JOB_PUP, state.pupPick, function (charid)
        if (state.pupPick ~= charid) then
            state.pupPick     = charid;
            state.pup         = nil;
            state.pupWork     = nil;
            state.pupRev      = state.pupRev + 1;
            state.pupModelRev = state.pupModelRev + 1;
            state.pupDirty    = false;

            requestPup();
        end
    end, TIPS.pickPup);

    imgui.SameLine();
    imgui.PushTextWrapPos(0);
    imgui.TextDisabled('Parts anyone on your account has unlocked equip every squad member.');
    imgui.PopTextWrapPos();

    if (state.pupPick == nil) then
        if (state.toauOpen == false) then
            imgui.TextDisabled('Nothing to pick: no character can be on PUP while the expansion is closed.');
        else
            imgui.TextDisabled('Pick a squad puppetmaster. A character not on PUP is set from /jobs first.');
        end

        return;
    end

    if (state.pup == nil or state.pupWork == nil) then
        imgui.TextDisabled('Fetching the automaton from the server...');

        return;
    end

    local header = state.pup.header;

    imgui.Text(string.format('%s -- PUP%d%s', header.name, header.level, header.petname ~= '' and ('  --  ' .. header.petname) or ''));

    -- Inside the branch, for the reason the Blue Mage tab's header carries:
    -- an automaton that is neither active nor out left the cursor on the
    -- name's line and the frame and head pickers drew beside it.
    if (header.active) then
        imgui.SameLine();
        imgui.TextColored(theme.colors.warn, '[automaton ACTIVE -- deactivate to equip]');

        -- The tag is never disabled, so it carries the reason Deactivate can
        -- be greyed (dwbags' rule).
        if (imgui.IsItemHovered()) then
            if (state.pending ~= nil) then
                imgui.SetTooltip('Deactivate is off while a write is in flight; this window keeps exactly one.');
            else
                imgui.SetTooltip('An ACTIVE automaton refuses the write -- retail\'s own rule. Deactivate puts it away (Activate is refunded at full HP) and the squad\'s pet keep brings the new build back out on its own tick.');
            end
        end

        imgui.SameLine();

        local canOff = state.pending == nil;

        if (not canOff) then imgui.BeginDisabled(); end

        if (imgui.Button('Deactivate##dwtoau_pup_off',
                { math.max(90, textWidth('Deactivate', 68) + FRAME_PAD + 10), 0 })) then
            sendWrite('pupoff', state.pupPick, string.format('pupoff %d', state.pupPick));
        end

        -- The ACTIVE tag beside it carries the reason this button is GREY
        -- (a disabled item reports no hover); this one is what it does when
        -- it is not (2026-09-06).
        tip(TIPS.pupOff);

        if (not canOff) then imgui.EndDisabled(); end
    elseif (header.out) then
        imgui.SameLine();
        imgui.TextColored(theme.colors.info, '[out in your party: the squad activates the new build on its own]');
        tip(TIPS.pupOut);
    end

    -- The Blue Mage tab's rule, on the row that had the same problem: two
    -- 190-pixel pickers, Apply, Revert, the marker, Clear and Copy came to
    -- more than the window is wide, so Copy was off the right edge. 130 is
    -- the floor because a narrower combo cannot show 'Sharpshot Z-500 Frame'.
    local buttonWidth = math.max(70, textWidth('Revert', 42) + FRAME_PAD + 10);
    local fixed = 2 * buttonWidth
        + math.max(textWidth('unsaved', 55), textWidth('in sync', 55))
        + textWidth('Clear', 34) + FRAME_PAD
        + textWidth('Copy', 32) + FRAME_PAD
        + 6 * ITEM_SPACING;
    local pickWidth = math.max(130, math.min(190, math.floor((regionWidth() - fixed) / 2)));

    partPicker('frame', state.pup.frames, state.pupWork.frame, function (id)
        state.pupWork.frame = id;
        state.pupRev        = state.pupRev + 1;
        state.pupDirty      = true;
    end, TIPS.pupFrame, 'frame', pickWidth);

    imgui.SameLine();

    partPicker('head', state.pup.heads, state.pupWork.head, function (id)
        state.pupWork.head = id;
        state.pupRev       = state.pupRev + 1;
        state.pupDirty     = true;
    end, TIPS.pupHead, 'head', pickWidth);

    local capacity, load = pupBudgetCached();
    local overloaded     = pupOverloaded(capacity, load);

    imgui.SameLine();

    local canApply = state.pending == nil and state.pupDirty and not overloaded and not header.active;

    if (not canApply) then imgui.BeginDisabled(); end

    if (imgui.Button('Apply##dwtoau_pup_apply', { buttonWidth, 0 })) then
        applyPup();
    end

    if (not canApply) then imgui.EndDisabled(); end

    imgui.SameLine();

    -- Captured for the reason the Blue Mage tab's Revert is: the press this
    -- guards is what makes the closing test disagree with the opening one.
    local canRevert = state.pupDirty;

    if (not canRevert) then imgui.BeginDisabled(); end

    if (imgui.Button('Revert##dwtoau_pup_revert', { buttonWidth, 0 })) then
        state.pupWork  = pupWorkFrom(state.pup.header, state.pup.attachments);
        state.pupRev   = state.pupRev + 1;
        state.pupDirty = false;
    end

    tip(TIPS.revertPup);

    if (not canRevert) then imgui.EndDisabled(); end

    -- The reason Apply is grey rides this marker, not Apply itself: the Blue
    -- Mage tab's rule, and for the same ImGui fact.
    imgui.SameLine();

    if (state.pupDirty) then
        imgui.TextColored(theme.colors.warn, 'unsaved');
    else
        imgui.TextDisabled('in sync');
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(pupApplyWhy(header, overloaded));
    end

    imgui.SameLine();

    if (imgui.SmallButton('Clear##dwtoau_pup_clear')) then
        for slot = 1, ATTACHMENT_SLOTS do
            state.pupWork.attachments[slot] = 0;
        end

        state.pupRev   = state.pupRev + 1;
        state.pupDirty = not (state.pupWork.frame == header.frame and state.pupWork.head == header.head
            and sameList(state.pupWork.attachments, state.pup.attachments));
    end

    tip(TIPS.pupClear);
    imgui.SameLine();

    if (imgui.SmallButton('Copy##dwtoau_pup_copy')) then
        local parts = T{ };

        for slot = 1, ATTACHMENT_SLOTS do
            local id = state.pupWork.attachments[slot];

            if (id ~= 0) then
                parts:append(string.format('%d %s', slot, attachmentName(id)));
            end
        end

        local copied = pcall(imgui.SetClipboardText,
            string.format('%s -- PUP%d automaton: %s frame, %s head; %s',
                header.name, header.level,
                itemName(PART_BASE + state.pupWork.frame, 'frame'), itemName(PART_BASE + state.pupWork.head, 'head'),
                #parts > 0 and table.concat(parts, ', ') or 'no attachments'));

        state.status    = copied
            and string.format('Copied the build (%d attachment(s)) to the clipboard.', #parts)
            or 'This Ashita build has no clipboard call -- nothing was copied.';
        state.statusBad = not copied;
    end

    tip(TIPS.pupCopy);

    pupPresetRow();

    --[[
        The eight capacity bars, two rows of four. The width is a quarter of
        the line, floored at what the widest overlay needs: 'Thunder 88/88'
        measured 91 pixels against a bar of 118 in the default font, which is
        comfortable -- and clipped in a larger one, on the numbers this whole
        tab is about (2026-09-06).
    ]]
    local capWidth = math.max(textWidth('Thunder 88/88', 100) + 12,
        math.min(150, math.floor((regionWidth() - 3 * ITEM_SPACING) / 4)));

    for element = 1, 8 do
        local fraction = capacity[element] > 0 and (load[element] / capacity[element]) or (load[element] > 0 and 1 or 0);

        imgui.ProgressBar(math.min(fraction, 1), { capWidth, 14 }, string.format('%s %d/%d', ELEMENTS[element], load[element], capacity[element]));
        tip(TIPS.capacityBar);

        if (element % 4 ~= 0) then
            imgui.SameLine();
        end
    end

    if (overloaded) then
        imgui.TextColored(theme.colors.err, 'Over capacity -- the server would refuse this build. Change the frame or head, or remove a part.');
    end

    imgui.Separator();

    -- The Blue Mage tab's rule, for the same reason: the unlocked list's own
    -- row has a filter box, a sort picker and a count to fit.
    local slotsWidth = math.max(210, math.min(260, math.floor(regionWidth() * 0.34)));

    if (imgui.BeginChild('##dwtoau_pup_slots', { slotsWidth, -1 }, ImGuiChildFlags_None)) then
        imgui.TextDisabled('Attachments (12 slots):');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('The twelve slots the automaton fights with. Slot order is kept exactly as it stands here -- a preset comes back in the shape it was saved in.');
        end

        for slot = 1, ATTACHMENT_SLOTS do
            local id = state.pupWork.attachments[slot];

            if (id == 0) then
                imgui.TextDisabled(pupEmptyLabel(slot));
                tip(TIPS.pupEmpty);
            else
                if (imgui.SmallButton(pupDropLabel(slot))) then
                    state.pupWork.attachments[slot] = 0;
                    state.pupRev   = state.pupRev + 1;
                    state.pupDirty = true;
                end

                tip('Take this part out of the slot. Nothing is sent until Apply.');

                imgui.SameLine();
                imgui.Text(string.format('%2d  %s', slot, attachmentName(id)));

                local row = state.pup.unlockedById[id];

                -- The hover card (owner request 2026-09-04): what the part
                -- does, in the client's own words, and what it costs.
                if (imgui.IsItemHovered() and row ~= nil) then
                    attachmentCard(row, slot);
                end
            end
        end
    end

    imgui.EndChild();
    imgui.SameLine();

    if (imgui.BeginChild('##dwtoau_pup_unlocked', { -1, -1 }, ImGuiChildFlags_None)) then
        local rows = pupView();
        local free = pupFreeSlot();

        -- 'unlocked' rather than 'unlocked on the account' (2026-09-06): the
        -- longer label plus a filter box and a sort picker is more than this
        -- panel is wide, and the tooltip on it has always said whose account
        -- it means.
        local countText = (#rows == #state.pup.unlocked)
            and string.format('%d unlocked', #state.pup.unlocked)
            or string.format('%d of %d unlocked', #rows, #state.pup.unlocked);

        local boxes  = math.max(200, regionWidth() - textWidth('888 of 888 unlocked', 133) - 3 * ITEM_SPACING);
        local filterWidth = math.max(100, math.floor(boxes * 0.5));
        local sortWidth   = math.max(100, boxes - filterWidth);

        imgui.SetNextItemWidth(filterWidth);
        imgui.InputTextWithHint('##dwtoau_pup_filter', 'filter...', state.pupFilter, 48);
        tip(TIPS.pupFilter);
        imgui.SameLine();
        imgui.SetNextItemWidth(sortWidth);

        local openSort = imgui.BeginCombo('##dwtoau_pup_sort', PUP_SORTS[state.pupSort[1]] or PUP_SORTS[1]);

        tip(TIPS.pupSort);

        if (openSort) then
            for i, name in ipairs(PUP_SORTS) do
                if (imgui.Selectable(string.format('%s##dwtoau_pup_sort_%d', name, i), state.pupSort[1] == i)) then
                    state.pupSort[1] = i;
                end
            end

            imgui.EndCombo();
        end

        imgui.SameLine();
        imgui.TextDisabled(countText);
        tip(TIPS.pupUnlocked);

        -- ScrollY with the header frozen, the Blue Mage tab's rule: the
        -- column names used to scroll away on the first wheel click.
        if (imgui.BeginTable('##dwtoau_pup_table', 3,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
            imgui.TableSetupColumn('Attachment', ImGuiTableColumnFlags_WidthStretch, 0, 0);
            imgui.TableSetupColumn('Cost', ImGuiTableColumnFlags_WidthFixed, costColumnWidth(), 0);
            imgui.TableSetupColumn('Equip', ImGuiTableColumnFlags_WidthFixed,
                math.max(54, textWidth('Equip', 36) + FRAME_PAD + 6), 0);
            imgui.TableSetupScrollFreeze(0, 1);
            imgui.TableHeadersRow();

            for _, row in ipairs(rows) do
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(attachmentName(row.id));

                local held = pupHas(row.id);

                if (imgui.IsItemHovered()) then
                    attachmentCard(row, held, pupEquipWhy(row, held, free, capacity, load));
                end

                imgui.TableNextColumn();
                imgui.Text(row.costText or '-');
                imgui.TableNextColumn();

                if (held ~= nil) then
                    if (imgui.SmallButton(pupOffLabel(row.id))) then
                        state.pupWork.attachments[held] = 0;
                        state.pupRev   = state.pupRev + 1;
                        state.pupDirty = true;
                    end
                else
                    local canAdd = free ~= nil and pupFitsCached(row);

                    if (not canAdd) then imgui.BeginDisabled(); end

                    if (imgui.SmallButton(pupOnLabel(row.id))) then
                        state.pupWork.attachments[free] = row.id;
                        state.pupRev   = state.pupRev + 1;
                        state.pupDirty = true;
                    end

                    if (not canAdd) then imgui.EndDisabled(); end
                end
            end

            imgui.EndTable();
        end
    end

    imgui.EndChild();
end

--[[
* The roll hover card (2026-09-06): what the client's own ability menu says a
* phantom roll or card trick does.
*
* Job abilities live in the client's ability data at `serverId + 512` -- the
* same offset dwparse and dwgambits un-apply -- and the `r|` record carries
* the SERVER's job-ability id. That offset is an assumption about the client,
* not a fact off the wire, so it is CHECKED rather than trusted: the client's
* name for the id must be the name the wire sent for the same id, or the card
* draws no description at all. A card that confidently describes the wrong
* ability is worse than a card with one line missing.
--]]
local ABILITY_CLIENT_OFFSET = 512;

local abilityInfos = {};

local function normalName(text)
    return (tostring(text or ''):lower():gsub('[^%w]', ''));
end

local function abilityInfo(serverId, wireName)
    if (abilityInfos[serverId] ~= nil) then
        return abilityInfos[serverId];
    end

    local info = { name = nil, desc = nil, skew = false };

    pcall(function ()
        local ability = AshitaCore:GetResourceManager():GetAbilityById(serverId + ABILITY_CLIENT_OFFSET);

        if (ability ~= nil) then
            if (ability.Name ~= nil and type(ability.Name[1]) == 'string' and #ability.Name[1] > 0) then
                info.name = ability.Name[1];
            end

            if (ability.Description ~= nil and type(ability.Description[1]) == 'string' and #ability.Description[1] > 0) then
                info.desc = ability.Description[1];
            end
        end
    end);

    if (info.name ~= nil and wireName ~= nil and wireName ~= ''
            and normalName(info.name) ~= normalName(wireName)) then
        info.name = nil;
        info.desc = nil;
        info.skew = true;
    end

    abilityInfos[serverId] = info;

    return info;
end

local function rollCard(roll, isTrick)
    local info = abilityInfo(roll.id, roll.raw);

    imgui.BeginTooltip();
    imgui.Text(info.name or roll.name);

    if (info.desc ~= nil) then
        imgui.TextWrapped(info.desc);
    elseif (info.skew) then
        imgui.TextDisabled('(the client names a different ability at this id -- no description drawn)');
    else
        imgui.TextDisabled('(no description in the client\'s ability data)');
    end

    if (isTrick) then
        imgui.TextDisabled(TIPS.corTrick);
    end

    imgui.EndTooltip();
end

--[[
* Corsair tab: every corsair out, its rolls as buttons, the rolls on you.
* Re-asked every few seconds while the tab is showing -- a roll has a
* clock, and the numbers on it move.
--]]
local COR_REFRESH = 8.0;

-- Iterated in place of the roster when the member child is culled, so the
-- skip costs no table (2026-09-06).
local NO_ROWS = T{ };

-- `now` is passed in rather than read here: this is called once per open
-- Double-Up window and once per roll on the player, and os.clock() is a call
-- into the C runtime for an answer that cannot move inside one frame
-- (2026-09-06).
local function secondsLeft(remaining, now)
    return math.max(remaining - math.floor(now - state.cor.at), 0);
end

--[[
* The Corsair tab is the one tab with no scroll region of its own, and the
* window carries NoScrollbar (2026-09-06). Six corsairs out, twenty rolls
* apiece and the rolls ON YOU -- the half with the clocks running, the whole
* reason to look -- were simply below the bottom edge with no scrollbar to
* say so. The members now scroll in their own child and the board sits under
* it, always on screen; the footer is measured from what it will draw rather
* than guessed.
--]]
local function corFooterHeight()
    local line = 20;

    if (type(imgui.GetTextLineHeightWithSpacing) == 'function') then
        local measured = imgui.GetTextLineHeightWithSpacing();

        if (type(measured) == 'number' and measured > 0) then
            line = measured;
        end
    end

    -- The heading, plus a row per roll on the player (or the one line that
    -- says there are none), plus the separator above it -- and a ceiling,
    -- because a footer that grows without one eventually IS the tab.
    return line * (1 + math.min(math.max(1, #state.cor.active), 8)) + line;
end

local function corTab()
    local now = os.clock();

    if (now - state.corAsked >= COR_REFRESH and not serverSilent) then
        requestCor();
    end

    local any    = false;
    local shown  = 0;
    local frozen = state.pending ~= nil;

    -- The body only when the child is really being drawn, which is the shape
    -- the other two tabs' children already use: ImGui culls a clipped child's
    -- contents anyway, and six corsairs' worth of roll buttons is real work
    -- to submit into a region nobody can see. EndChild ALWAYS, whatever
    -- BeginChild answered (2026-09-06).
    local inChild = imgui.BeginChild('##dwtoau_cor_members', { -1, -corFooterHeight() }, ImGuiChildFlags_None);

    for _, row in ipairs(inChild and state.chars or NO_ROWS) do
        local member = state.cor.members[row.charid];

        if (member ~= nil) then
            any   = true;
            shown = shown + 1;

            imgui.Text(string.format('%s  (!%s)', row.name, row.tag));

            -- The member's own line is never disabled, so it carries the
            -- reason the roll buttons under it can be (dwbags' rule): a
            -- greyed button reports no hover for a tooltip to hang on.
            if (imgui.IsItemHovered()) then
                if (frozen) then
                    imgui.SetTooltip('The rolls are held while a write is in flight -- this window keeps exactly one, and a replayed press is a SECOND roll. They come back when the server answers, or after five seconds.');
                else
                    imgui.SetTooltip(string.format('%s answers to !%s. A press goes through the squad\'s own action tier -- recast, cost, target and refusal are all its.', row.name, row.tag ~= '' and row.tag or 'cor'));
                end
            end

            local window = state.cor.windows[row.charid];

            if (window ~= nil) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.info, string.format('Double-Up open: %d, %ds left', window.total, secondsLeft(window.remaining, now)));
                tip(TIPS.corWindow);
            end

            local canPress = not frozen;

            if (not canPress) then imgui.BeginDisabled(); end

            --[[
                THE GRID IS MEASURED, NOT COUNTED (2026-09-06). The buttons
                were 130 pixels four to a row: "Companion's Roll" is 112 of
                them in the default font and more than 130 in a larger one, so
                the name on the button a player is about to press was the
                thing that clipped. The width is the widest roll this member
                actually has, and how many fit on a line follows from it --
                which also means a wide window gets six to a row instead of
                four. Cached on the member, which the next `cor` answer
                replaces whole.
            ]]
            if (member.width == nil) then
                local widest = textWidth('Corsair\'s Roll', 98);

                for _, roll in ipairs(member.rolls) do
                    local measured = textWidth(roll.name, 0);

                    if (measured > widest) then
                        widest = measured;
                    end
                end

                member.width = math.max(130, widest + FRAME_PAD + 10);
            end

            local perRow = math.max(2, math.floor((regionWidth() + ITEM_SPACING) / (member.width + ITEM_SPACING)));
            local column = 0;

            for _, roll in ipairs(member.rolls) do
                if (column > 0) then
                    imgui.SameLine();
                end

                if (imgui.Button(roll.button, { member.width, 0 })) then
                    sendWrite('roll', row.charid, string.format('roll %d %d', row.charid, roll.id));
                end

                -- The client's own words for the roll, checked against the
                -- name the wire sent for the same id (2026-09-06).
                if (canPress and imgui.IsItemHovered()) then
                    rollCard(roll);
                end

                column = (column + 1) % perRow;
            end

            if (#member.rolls == 0) then
                imgui.TextDisabled('  no rolls learned yet');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Every roll but Phantom Roll is LEARNED from a die item, and a squad corsair rolls what its own character has learned. !addallrolls teaches them all.');
                end
            end

            if (#member.tricks > 0) then
                -- The card tricks are SmallButtons of their own widths; the
                -- longest of them ('Crooked Cards') decides how many fit.
                local trickWidth = textWidth('Crooked Cards', 91) + FRAME_PAD + 8;
                local trickRow   = math.max(2, math.floor((regionWidth() + ITEM_SPACING) / (trickWidth + ITEM_SPACING)));

                column = 0;

                for _, trick in ipairs(member.tricks) do
                    if (column > 0) then
                        imgui.SameLine();
                    end

                    if (imgui.SmallButton(trick.button)) then
                        sendWrite('roll', row.charid, string.format('roll %d %d', row.charid, trick.id));
                    end

                    if (canPress and imgui.IsItemHovered()) then
                        rollCard(trick, true);
                    end

                    column = (column + 1) % trickRow;
                end
            end

            if (not canPress) then imgui.EndDisabled(); end

            imgui.Separator();
        end
    end

    -- The empty state must say WHICH nothing this is (2026-09-06). It used to
    -- claim "no corsair is out" whatever the reason, so a roster read that
    -- had not arrived -- or an expansion that is not open at all -- read as
    -- an empty squad, and Refresh was the last thing a player would try.
    if (inChild and not any) then
        if (state.toauOpen == false) then
            imgui.TextDisabled('No corsair can exist while the expansion is closed.');
        elseif (state.cor.count > shown) then
            imgui.TextDisabled(string.format('%d corsair(s) answered, but the character list has not arrived yet -- press Refresh.', state.cor.count));
        else
            imgui.TextDisabled('No corsair is out in your squad. Call one from /squad, then look here.');
        end

        imgui.Separator();
    elseif (inChild and state.cor.count > shown) then
        imgui.TextDisabled(string.format('(%d more corsair(s) answered than the character list knows -- press Refresh.)', state.cor.count - shown));
        imgui.Separator();
    end

    imgui.EndChild();
    imgui.Separator();

    imgui.TextDisabled('On you right now:');
    tip(TIPS.corActive);

    if (#state.cor.active == 0) then
        imgui.TextDisabled('  no rolls');
    end

    for _, roll in ipairs(state.cor.active) do
        local left = secondsLeft(roll.remaining, now);

        -- A BUST HAS NO NUMBER (2026-09-06): its sub-power is zero, and the
        -- board read 'Bust 0' where the typed door has always printed the
        -- penalty without one. A zero that is not a roll total looks like a
        -- roll of nothing.
        local line = roll.bust
            and string.format('  %s  --  %d:%02d left%s', roll.name, math.floor(left / 60), left % 60,
                roll.caster ~= '' and ('  (' .. roll.caster .. ')') or '')
            or string.format('  %s %d  --  %d:%02d left%s', roll.name, roll.total, math.floor(left / 60), left % 60,
                roll.caster ~= '' and ('  (' .. roll.caster .. ')') or '');

        -- roll.bust is decided once, when the record is parsed: the test used
        -- to lower and search the name on every frame for every row.
        if (roll.bust) then
            imgui.TextColored(theme.colors.err, line);
        elseif (roll.total == 11) then
            imgui.TextColored(theme.colors.ok, line);
        else
            imgui.Text(line);
        end
    end
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        serverSilent = false;
        protocolBad  = false;

        forget();
        requestSync();
        requestBlue();
        requestPup();
        requestCor();
    end

    tip(TIPS.refresh);

    imgui.SameLine();
    imgui.TextDisabled('The ToAU job kit: what a squad member cannot set for itself.');

    statusLine();
    imgui.Separator();

    --[[
        The hover test sits BETWEEN BeginTabItem and the body, never inside
        the `if`: ImGui submits the tab as an item inside BeginTabItem, so
        IsItemHovered reads the TAB there whether it opened or not, and the
        first widget the body draws would take the "last item" away
        (dwbags' shape).
    --]]
    if (imgui.BeginTabBar('##dwtoau_tabs')) then
        local onBlue = imgui.BeginTabItem('Blue Mage');

        tip(TIPS.tabBlue);

        if (onBlue) then
            blueTab();
            imgui.EndTabItem();
        end

        local onPup = imgui.BeginTabItem('Puppetmaster');

        tip(TIPS.tabPup);

        if (onPup) then
            pupTab();
            imgui.EndTabItem();
        end

        local onCor = imgui.BeginTabItem('Corsair');

        tip(TIPS.tabCor);

        if (onCor) then
            corTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape).
--]]
ashita.events.register('d3d_present', 'dwtoau_present', function ()
    checkAnswers();
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 720, 540 }, ImGuiCond_FirstUseEver);

    -- A FLOOR UNDER THE WIDTH AND THE HEIGHT (2026-09-06). Both preset rows
    -- are one line of seven controls -- a label, a 170px combo, Load, Load &
    -- Apply, Delete, a 130px name box and Save -- which measures around 680
    -- pixels before the window's own padding, and the Blue Mage header's two
    -- 220px bars plus Apply, Revert, the marker, Clear and Copy comes to the
    -- same. Dragged narrower than that the rows wrapped into each other and
    -- the tab bar's own labels started clipping; nothing stopped a player
    -- doing it, and ImGui remembers the size they left behind.
    imgui.SetNextWindowSizeConstraints({ 700, 380 }, { 99999, 99999 });

    -- NoDocking: dw windows fused into an unthemed dock once; never again.
    local visible = imgui.Begin('DriftwoodXI ToAU Job Kit##dwtoau', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwtoau'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwtoau'):append(chat.message('Window closed. `!toau` typed by hand does the same jobs.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs: a set as it stood before the
* last Apply is the quiet kind of wrong this project exists to rule out.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
        serverSilent   = false;
        protocolBad    = false;

        -- The presets file is re-read on every open: an edit made with the
        -- window closed is seen, and a preset saved by the other PC's copy
        -- of this addon needs no restart.
        loadPresets();

        forget();
        requestSync();
        requestBlue();
        requestPup();
        requestCor();
    end
end

ashita.events.register('command', 'dwtoau_command', function (e)
    local args  = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwtoau' and first ~= '/toau' and first ~= '/dwk') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        serverSilent = false;
        protocolBad  = false;

        forget();
        requestSync();
        requestBlue();
        requestPup();
        requestCor();

        return;
    end

    toggleWindow();
end);

--[[
* Zoning invalidates who is out and what is active; the working copies are
* kept (an unsaved set survives a zone line), the pending write is not.
*
* THE TWO PER-CHARACTER READS GO WITH THEM (2026-09-06). `out` on the blue
* header and `active`/`out` on the automaton header are all zone-dependent,
* and a stale `active` is not cosmetic: it is the flag that greys Apply on
* the Puppetmaster tab, so a player who zoned after dismissing an automaton
* found the build locked with no way forward but Refresh. Only asked when the
* window is OPEN and a character is picked -- the window starts closed and
* ImGui does not restore it, so this cannot fire on a login -- and the queue
* still lets one line out per throttle window, held shut until the client
* stops zoning.
--]]
ashita.events.register('packet_in', 'dwtoau_zonein', function (e)
    if (e.id == 0x000A) then
        state.pending = nil;

        -- The measured label widths go with the zone line (dwah's rule): they
        -- are answers in a font that a settings change between zones can move.
        textWidths = {};

        forget();

        if (state.open[1] and not serverSilent) then
            requestSync();
            requestBlue();
            requestPup();
            requestCor();
        end
    end
end);

--[[
* Watch what the player sends. Bare `!toau` toggles this window instead of
* going to the server -- the typed verb is a door, not a dead end; any
* `!toau <verb>` line still passes through untouched. Every other outgoing
* line stamps the throttle so a queued query never races something the
* player typed.
--]]
ashita.events.register('packet_out', 'dwtoau_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!toau' or lower == '!toau ui' or lower == '!toau window' or lower == '!toau gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwk') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwtoau_load', function ()
    print(chat.header('dwtoau'):append(chat.message('/toau or /dwtoau opens the ToAU job kit -- set a squad blue mage\'s spells, build a puppetmaster\'s automaton, press a corsair\'s rolls.')));
end);
