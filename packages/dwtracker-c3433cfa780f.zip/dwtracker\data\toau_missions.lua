-- dwtracker data -- Treasures of Aht Urhgan missions (2026-09-21, the day
-- the expansion opened). Names from the enum (scripts/globals/missions.lua,
-- xi.mission.id.toau); steps HAND-AUTHORED from scripts/missions/toau/*.lua
-- as ground truth, plus the battlefield and instance files those scripts
-- hand off to (scripts/battlefields/**, scripts/zones/**/instances/**).
-- Pure data: numeric ids and display strings only, no xi.*, no functions
-- (DWTRACKER_FORMAT.md decisions T2/§3-4). Loaded byte-identically by the
-- server module and the dwtracker addon; both hash these bytes, so an edit
-- that reaches only one side makes the addon refuse step rendering for
-- this area until the copies agree again. tools/dwtracker_lint.py must
-- pass before any edit here ships.
--
-- FIVE THINGS ABOUT THE ToAU LOG THAT SHAPE EVERY ENTRY BELOW:
--
-- 1. missionStatus IS ONE WORD PER LOG, NOT PER MISSION. Every script here
--    reads player:getMissionStatus(4), and Mission:complete writes it back
--    to 0 on completion (interaction/mission.lua:67, every log but CoP).
--    So a threshold here is only ever about the mission that is CURRENT,
--    which is exactly the entry the evaluator is running -- but see 2.
--
-- 2. FOUR OF THE THRESHOLDS ARE WRITTEN FROM OUTSIDE THE MISSION SCRIPT.
--    31's status 1 comes from the Periqia instance, 42's and 44's status 2
--    from the two Nyzul Isle instances, and 15's status 2 from the Ashu
--    Talif instance. They are real writes on log 4 and the atoms read them
--    the same way; the linter's "value some script of that log writes or
--    compares" test passes because the mission scripts compare them.
--
-- 3. THE `Option` CHARVAR IS A DIALOGUE TOGGLE, NOT PROGRESS. Missions 8,
--    9, 11, 25 and 33 flip it 0/1 (or 0/2) purely to alternate Naja's
--    lines, so it is monotone in none of them and is read in no entry.
--    `Timer` is a Vana'diel day stamp, likewise not progress. Missions
--    whose only gate is "a day has passed and you have zoned" carry ONE
--    honest step rather than a bright step no atom can place.
--
-- 4. SEVERAL MISSIONS HAVE NO READABLE MIDPOINT AT ALL -- their whole
--    state is "walk here and watch" -- and those are single-step entries.
--    A delivery whose only marker is the ABSENCE of a key item (mission 2)
--    is the same case: there is no negation atom, and inventing one would
--    be the forbidden bright-but-wrong step.
--
-- 5. THE LOG DOES NOT END ON A COMPLETION. 48 Eternal Mercenary calls no
--    mission:complete anywhere (48_Eternal_Mercenary.lua) -- it is where
--    the line stops, and its step says so rather than promising a finish.
--
-- WHAT IS NOT AVAILABLE ON THIS SERVER, and is said so in the step text
-- wherever a mission would otherwise send a player at it: Besieged,
-- Einherjar, Salvage, ZNM, Pankration and the Chocobo Circuit. Only some
-- Assaults run (ten have scripts; the Commissions Agency refuses the rest
-- and refunds the tag), and mission 31's Periqia instance is one of the
-- ones that does. Every Aht Urhgan open field is raised to roughly level
-- 120-150 here, and the towns are safe.
--
-- NYZUL ISLE, and the distinction that matters for missions 42 and 44:
-- `NYZUL_ENABLED` is FALSE on this server and was deliberately left that
-- way on 2026-09-21 (PLANS/TOAU_RAISE_PLAN.md, "Nyzul read end to end" --
-- one boss floor in three is a dead run over a mob_groups row with
-- poolid 0). But that flag has exactly ONE reader, Sorrowful_Sage.lua,
-- the vendor who sells the ASSAULT orders. Everything downstream is live
-- and ungated, including the Alzadaal Runic Seal these two missions
-- register their instances through -- so 42 and 44 are playable while the
-- Nyzul Isle Uncharted Area Survey assault is not, and the steps below
-- say only what those two missions actually need.
return {
    kind = 'missions',
    log = 4,
    area = 'toau_missions',
    label = "Treasures of Aht Urhgan",
    entries = {
        [0] = { -- LAND_OF_SACRED_SERPENTS (M1)
            name = "Land of Sacred Serpents",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    -- The section check is `currentMission == 0 and
                    -- ENABLE_TOAU == 1 and hasKeyItem(BOARDING_PERMIT)`, and
                    -- the log sits on mission 0 from character creation
                    -- (char_entity.cpp:179), so the permit IS the gate.
                    text = "Get the Boarding Permit from Faursel in Lower Jeuno -- his quest is The Road to Aht Urhgan, already in your Jeuno log. Nothing in Aht Urhgan answers you without it.",
                    pos  = "Lower Jeuno, Faursel (!pos 38 3.1 -45.2)",
                    done = { ki = 781 }, -- BOARDING_PERMIT
                },
                {
                    text = "Take the Mhaura boat to Aht Urhgan Whitegate, then walk up onto the second Salaheem's Sentinels platform. The cutscene there is the whole mission.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                },
            },
        },
        [1] = { -- IMMORTAL_SENTRIES (M2)
            name = "Immortal Sentries",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    -- One step on purpose: progress here is the ABSENCE of
                    -- the Supplies Package, and no atom can say "not".
                    text = "Hand your Supplies Package to any Immortal -- Meyaada, Daswil, Nahshib, Nareema or Waudeen -- then report back to Naja Salaheem. It pays 150 Imperial Standing.",
                    pos  = "Arrapago Reef (!pos 22 -8 573) / Bhaflau Thickets (!pos -209 -13 -780) / Caedarva Mire (!pos -274 -9 -64)",
                },
            },
        },
        [2] = { -- PRESIDENT_SALAHEEM (M3)
            name = "President Salaheem",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Naja Salaheem and sit through the mog locker sales pitch.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Leave Whitegate and come back, then talk to Naja again for the cutscene that ends this.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [3] = { -- KNIGHT_OF_GOLD (M4)
            name = "Knight of Gold",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Hear Naja out, then find Cacaroon out on the Whitegate waterfront and agree to run his errand.",
                    pos  = "Aht Urhgan Whitegate, Cacaroon (!pos -72 0 -82)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Pay Cacaroon: trade him 1000 gil, or one Imperial Bronze Piece.",
                    pos  = "Aht Urhgan Whitegate, Cacaroon (!pos -72 0 -82)",
                    done = { missionStatus = { 4, gte = 2 } },
                },
                {
                    text = "Walk up to Walahra Temple for the next scene.",
                    pos  = "Aht Urhgan Whitegate, Walahra Temple (!pos 79 0 41)",
                    done = { missionStatus = { 4, gte = 3 } },
                },
                {
                    text = "Go down to the Shaharat Teahouse. The scene there ends the mission and leaves you Raillefal's Letter.",
                    pos  = "Aht Urhgan Whitegate, Shaharat Teahouse (!pos 79 -6 -130)",
                },
            },
        },
        [4] = { -- CONFESSIONS_OF_ROYALTY (M5)
            name = "Confessions of Royalty",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    -- The only var here is `Option`, set to 1 solely on the
                    -- Guilerme detour, so it cannot order the normal path.
                    text = "Carry Raillefal's Letter to Halver inside Chateau d'Oraguille. Locked out of the Chateau? Speak to Guilerme in Northern San d'Oria and he walks you in for the scene.",
                    pos  = "Chateau d'Oraguille, Halver (!pos 2 0.1 0.1)",
                },
            },
        },
        [5] = { -- EASTERLY_WINDS (M6)
            name = "Easterly Winds",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Halver sends you to Jeuno. Walk up to the palace entrance in Ru'Lude Gardens for the cutscene; keep a free inventory slot and it pays 10 Imperial Bronze Pieces.",
                    pos  = "Ru'Lude Gardens, palace entrance (!pos 0 3 59)",
                },
            },
        },
        [6] = { -- WESTERLY_WINDS (M7)
            name = "Westerly Winds",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Back in Whitegate, go down to the Shaharat Teahouse. Raillefal's Note and an Imperial Silver Piece are handed over there -- with no free slot nothing happens at all.",
                    pos  = "Aht Urhgan Whitegate, Shaharat Teahouse (!pos 79 -6 -130)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Take the note to Naja Salaheem.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [7] = { -- A_MERCENARY_LIFE (M8)
            name = "A Mercenary Life",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Naja Salaheem, then leave Whitegate and come back and step onto the second Salaheem's Sentinels platform. The scene there ends it.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                },
            },
        },
        [8] = { -- UNDERSEA_SCOUTING (M9)
            name = "Undersea Scouting",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Naja sends you under the sea. Work through the Alzadaal Undersea Ruins to the great door on map 7 and walk up to it.",
                    pos  = "Alzadaal Undersea Ruins (!pos 440 0 -580)",
                },
            },
        },
        [9] = { -- ASTRAL_WAVES (M10)
            name = "Astral Waves",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Report to Naja Salaheem. The conversation is the whole mission and leaves you the Astral Compass.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [10] = { -- IMPERIAL_SCHEMES (M11)
            name = "Imperial Schemes",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Naja, then let a Vana'diel day pass and zone out and back before stepping onto the first Salaheem's Sentinels platform.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 34 -6.6 -55)",
                },
            },
        },
        [11] = { -- ROYAL_PUPPETEER (M12)
            name = "Royal Puppeteer",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Sail to Nashmau and ask Pyopyoroon about the puppet.",
                    pos  = "Nashmau, Pyopyoroon (!pos 22 0 25)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Bring Pyopyoroon a Vial of Jody's Acid and trade it to him.",
                    pos  = "Nashmau, Pyopyoroon (!pos 22 0 25)",
                },
            },
        },
        [12] = { -- LOST_KINGDOM (M13)
            name = "Lost Kingdom",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Naja hands you the Vial of Spectral Scent. Take it to Jazaraat's Headstone out in Caedarva Mire and use it there.",
                    pos  = "Caedarva Mire, Jazaraat's Headstone (!pos -389 6 -570)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Touch the headstone again to call Jazaraat up, and kill it. Caedarva Mire runs around level 120-150 here, so bring a party or a squad.",
                    pos  = "Caedarva Mire, Jazaraat's Headstone (!pos -389 6 -570)",
                    done = { missionStatus = { 4, gte = 2 } },
                },
                {
                    text = "Touch the headstone once more for the scene that ends the mission and leaves you the Ephramadian Gold Coin.",
                    pos  = "Caedarva Mire, Jazaraat's Headstone (!pos -389 6 -570)",
                },
            },
        },
        [13] = { -- THE_DOLPHIN_CREST (M14)
            name = "The Dolphin Crest",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Naja Salaheem. The briefing is the whole mission.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [14] = { -- THE_BLACK_COFFIN (M15)
            name = "The Black Coffin",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Carry the Ephramadian Gold Coin to the cutter beached on the Arrapago Reef shore. Walking up to it starts the scene.",
                    pos  = "Arrapago Reef, the cutter (!pos -458 -2 -406)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Examine the cutter to board the Ashu Talif, and win the fight aboard -- Gessho first, then the captain's crew. A party or squad may come; the coin is spent on entry.",
                    pos  = "Arrapago Reef, the cutter (!pos -464.5 -2 -394.5)",
                    done = { missionStatus = { 4, gte = 2 } },
                },
                {
                    text = "Leave the ship. The scene back on the Arrapago shore drops you straight into Nashmau.",
                    pos  = "Arrapago Reef (!pos -456 -3 -405)",
                    done = { missionStatus = { 4, gte = 3 } },
                },
                {
                    text = "The cutscene as you land in Nashmau finishes the mission.",
                    pos  = "Nashmau",
                },
            },
        },
        [15] = { -- GHOSTS_OF_THE_PAST (M16)
            name = "Ghosts of the Past",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Naja Salaheem and sit through her wardrobe questions. Any answer you give ends the mission.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [16] = { -- GUESTS_OF_THE_EMPIRE (M17)
            name = "Guests of the Empire",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Naja inspects your clothes. Wear a body piece the palace allows with hands, legs and feet all covered, and she passes you first time; otherwise she plays dress-up instead.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Change into palace-approved gear and go back to Naja until she approves of you.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                    done = { missionStatus = { 4, gte = 2 } },
                },
                {
                    text = "Unequip your weapon and shield, keep the approved gear on, and speak to the Imperial Whitegate guard.",
                    pos  = "Aht Urhgan Whitegate, Imperial Whitegate (!pos 152 -2 0)",
                },
            },
        },
        [17] = { -- PASSING_GLORY (M18)
            name = "Passing Glory",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Let a Vana'diel day pass, zone out and back, then step onto the second Salaheem's Sentinels platform for the scene.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                },
            },
        },
        [18] = { -- SWEETS_FOR_THE_SOUL (M19)
            name = "Sweets for the Soul",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Naja sends you out for sweets. Walk down to the Shaharat Teahouse for the scene.",
                    pos  = "Aht Urhgan Whitegate, Shaharat Teahouse (!pos 79 -6 -130)",
                },
            },
        },
        [19] = { -- TEAHOUSE_TUMULT (M20)
            name = "Teahouse Tumult",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Get into the Aydeewa Subterrane, off Wajaom Woodlands. The scene fires as you arrive.",
                    pos  = "Aydeewa Subterrane",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Go to the far end of the Subterrane and examine the spot there.",
                    pos  = "Aydeewa Subterrane (!pos -298 36 -38)",
                },
            },
        },
        [20] = { -- FINDERS_KEEPERS (M21)
            name = "Finders Keepers",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Step onto the second Salaheem's Sentinels platform. The scene there is the whole mission.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                },
            },
        },
        [21] = { -- SHIELD_OF_DIPLOMACY (M22)
            name = "Shield of Diplomacy",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Make your way into the Navukgo Execution Chamber, off Caedarva Mire. The scene fires as you arrive.",
                    pos  = "Navukgo Execution Chamber",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Examine the Decorative Bronze Gate for the second scene.",
                    pos  = "Navukgo Execution Chamber (!pos -600 8 -100)",
                    done = { missionStatus = { 4, gte = 2 } },
                },
                {
                    text = "Enter through the gate and win the fight. Up to six, trusts and squad allowed, 30 minutes, level capped at 99.",
                    pos  = "Navukgo Execution Chamber (!pos -600 8 -100)",
                },
            },
        },
        [22] = { -- SOCIAL_GRACES (M23)
            name = "Social Graces",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Step onto the second Salaheem's Sentinels platform for the scene.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                },
            },
        },
        [23] = { -- FOILED_AMBITION (M24)
            name = "Foiled Ambition",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "A Vana'diel day has to pass and you have to zone; then step onto the second Salaheem's Sentinels platform. Five Imperial Gold Pieces come out of it.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                },
            },
        },
        [24] = { -- PLAYING_THE_PART (M25)
            name = "Playing the Part",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Let a Vana'diel day pass, zone out and back, then talk to Naja Salaheem.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [25] = { -- SEAL_OF_THE_SERPENT (M26)
            name = "Seal of the Serpent",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Put your weapon and shield away -- both hands empty -- then speak to the Imperial Whitegate guard.",
                    pos  = "Aht Urhgan Whitegate, Imperial Whitegate (!pos 152 -2 0)",
                },
            },
        },
        [26] = { -- MISPLACED_NOBILITY (M27)
            name = "Misplaced Nobility",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Go back into the Aydeewa Subterrane and examine the same spot at the far end.",
                    pos  = "Aydeewa Subterrane (!pos -298 36 -38)",
                },
            },
        },
        [27] = { -- BASTION_OF_KNOWLEDGE (M28)
            name = "Bastion of Knowledge",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Walk up to Walahra Temple for the scene.",
                    pos  = "Aht Urhgan Whitegate, Walahra Temple (!pos 79 0 41)",
                },
            },
        },
        [28] = { -- PUPPET_IN_PERIL (M29)
            name = "Puppet in Peril",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Get into the Jade Sepulcher, off Aydeewa Subterrane, and examine the Ornamental Door.",
                    pos  = "Jade Sepulcher (!pos 300 -2.5 -200)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Go through the door and win the fight. Up to six, trusts and squad allowed, 30 minutes, level capped at 99.",
                    pos  = "Jade Sepulcher (!pos 300 -2.5 -200)",
                },
            },
        },
        [29] = { -- PREVALENCE_OF_PIRATES (M30)
            name = "Prevalence of Pirates",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Zone into Arrapago Reef. The scene fires however you arrive, survival guide included.",
                    pos  = "Arrapago Reef",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Walk to the cutter on the shore for the second scene. It ends with the Periqia Assault Area Entry Permit in your hands.",
                    pos  = "Arrapago Reef, the cutter (!pos -458 -2 -406)",
                },
            },
        },
        [30] = { -- SHADES_OF_VENGEANCE (M31)
            name = "Shades of Vengeance",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    -- Status 1 is written by the Periqia instance, not by
                    -- this mission's script (Periqia/instances/
                    -- shades_of_vengeance.lua:69).
                    text = "Spend the Periqia Assault Area Entry Permit: touch the Runic Seal in Caedarva Mire and clear the run behind it. Nashib re-issues the permit a Vana'diel day after a loss.",
                    pos  = "Caedarva Mire, Runic Seal (!pos -354 -3 -20)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Come back out into Caedarva Mire; the scene as you arrive ends the mission.",
                    pos  = "Caedarva Mire",
                },
            },
        },
        [31] = { -- IN_THE_BLOOD (M32)
            name = "In the Blood",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Report to Naja Salaheem. The conversation is the whole mission and pays an Imperial Gold Piece.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [32] = { -- SENTINELS_HONOR (M33)
            name = "Sentinels' Honor",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Let a Vana'diel day pass, zone out and back, then talk to Naja Salaheem. Her line cycles until the day is up, which is how you can tell you are early.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [33] = { -- TESTING_THE_WATERS (M34)
            name = "Testing the Waters",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    -- The coin was consumed entering the Ashu Talif back on
                    -- mission 15; Lost Kingdom's completed-section hands it
                    -- back (13_Lost_Kingdom.lua:100). The anyOf keeps the
                    -- consumable from un-doing this step once you are past it.
                    text = "You need the Ephramadian Gold Coin again -- mission 15 spent it. Touch Jazaraat's Headstone in Caedarva Mire and it is handed straight back.",
                    pos  = "Caedarva Mire, Jazaraat's Headstone (!pos -389 6 -570)",
                    done = {
                        anyOf = {
                            { ki = 786 }, -- EPHRAMADIAN_GOLD_COIN
                            { missionStatus = { 4, gte = 1 } },
                        },
                    },
                },
                {
                    text = "Walk to the cutter on the Arrapago Reef shore with the coin on you and answer the question you are asked. A wrong answer makes you leave the zone and come back to try again.",
                    pos  = "Arrapago Reef, the cutter (!pos -458 -2 -406)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "The right answer sets you down in Talacca Cove. The cutscene as you land ends the mission and takes the coin.",
                    pos  = "Talacca Cove (!pos -89 -7.3 -109)",
                },
            },
        },
        [34] = { -- LEGACY_OF_THE_LOST (M35)
            name = "Legacy of the Lost",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Back in Talacca Cove -- it has ordinary zone lines from Caedarva Mire and Arrapago Reef -- touch the Rock Slab and beat Gessho. Up to six, trusts and squad allowed, 30 minutes.",
                    pos  = "Talacca Cove, Rock Slab (!pos -100 -9.4 -87)",
                },
            },
        },
        [35] = { -- GAZE_OF_THE_SABOTEUR (M36)
            name = "Gaze of the Saboteur",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Get into the Hazhalm Testing Grounds, under Mount Zhayolm. The scene fires as you arrive.",
                    pos  = "Hazhalm Testing Grounds",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Work down to the Entry Gate and examine it. The Percipient Eye is spent there and the mission ends with Luminian Dagger in hand.",
                    pos  = "Hazhalm Testing Grounds, Entry Gate (!pos 486 -228 -20)",
                },
            },
        },
        [36] = { -- PATH_OF_BLOOD (M37)
            name = "Path of Blood",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Step onto the second Salaheem's Sentinels platform. The scene force-zones you when it ends -- that is meant to happen.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "Zone back into Aht Urhgan Whitegate for the second scene.",
                    pos  = "Aht Urhgan Whitegate",
                },
            },
        },
        [37] = { -- STIRRINGS_OF_WAR (M38)
            name = "Stirrings of War",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Let a Vana'diel day pass and zone, then go down to the Shaharat Teahouse for the scene. It leaves you the Allied Council Summons.",
                    pos  = "Aht Urhgan Whitegate, Shaharat Teahouse (!pos 79 -6 -130)",
                },
            },
        },
        [38] = { -- ALLIED_RUMBLINGS (M39)
            name = "Allied Rumblings",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Travel to Jeuno and walk up to the palace entrance in Ru'Lude Gardens.",
                    pos  = "Ru'Lude Gardens, palace entrance (!pos 0 3 59)",
                },
            },
        },
        [39] = { -- UNRAVELING_REASON (M40)
            name = "Unraveling Reason",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Let a Vana'diel day pass and zone, then ask Pherimociel in Ru'Lude Gardens about the ship and accept the ride. Asking early costs you a zone before you can ask again.",
                    pos  = "Ru'Lude Gardens, Pherimociel (!pos -32 1 68)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    text = "You are set down in Wajaom Woodlands. Zone out and back in for the next scene.",
                    pos  = "Wajaom Woodlands (!pos -200 -10 80)",
                    done = { missionStatus = { 4, gte = 2 } },
                },
                {
                    text = "Zone into Wajaom Woodlands again for the third scene.",
                    pos  = "Wajaom Woodlands (!pos -200 -10 80)",
                    done = { missionStatus = { 4, gte = 3 } },
                },
                {
                    text = "One more zone into Wajaom Woodlands ends the mission.",
                    pos  = "Wajaom Woodlands (!pos -200 -10 80)",
                },
            },
        },
        [40] = { -- LIGHT_OF_JUDGMENT (M41)
            name = "Light of Judgement",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Rodin-Comidin in Whitegate and take the Nyzul Isle Route from him. That is the whole mission.",
                    pos  = "Aht Urhgan Whitegate, Rodin-Comidin (!pos 17.2 -6 51.2)",
                },
            },
        },
        [41] = { -- PATH_OF_DARKNESS (M42)
            name = "Path of Darkness",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Go down to Alzadaal Undersea Ruins and examine the lamp there for the briefing.",
                    pos  = "Alzadaal Undersea Ruins, lamp (!pos 207 -1.5 20)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    -- Status 2 is written by the Nyzul instance, not by this
                    -- script (Nyzul_Isle/instances/path_of_darkness.lua:113).
                    text = "With the Nyzul Isle Route on you, touch the Runic Seal nearby and clear the Nyzul run. Rodin-Comidin re-issues the route if you lost it; the seal takes it on entry.",
                    pos  = "Alzadaal Undersea Ruins, Runic Seal (!pos 123.5 -2.5 20)",
                    done = { missionStatus = { 4, gte = 2 } },
                },
                {
                    text = "Come back into Alzadaal Undersea Ruins; the scene as you arrive ends the mission.",
                    pos  = "Alzadaal Undersea Ruins",
                },
            },
        },
        [42] = { -- FANGS_OF_THE_LION (M43)
            name = "Fangs of the Lion",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Step onto the second Salaheem's Sentinels platform. The scene there ends the mission and leaves you the Mythril Mirror.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                },
            },
        },
        [43] = { -- NASHMEIRAS_PLEA (M44)
            name = "Nashmeira's Plea",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Go down to Alzadaal Undersea Ruins and examine the lamp for the briefing. Naja hands the Mythril Mirror back if you no longer have it.",
                    pos  = "Alzadaal Undersea Ruins, lamp (!pos 207 -1.5 20)",
                    done = { missionStatus = { 4, gte = 1 } },
                },
                {
                    -- Status 2 from Nyzul_Isle/instances/nashmeiras_plea.lua:82.
                    text = "Touch the Runic Seal nearby with the Mythril Mirror on you and clear the Nyzul run. The mirror is taken on entry.",
                    pos  = "Alzadaal Undersea Ruins, Runic Seal (!pos 123.5 -2.5 20)",
                    done = { missionStatus = { 4, gte = 2 } },
                },
                {
                    text = "Come back into Alzadaal Undersea Ruins; the scene as you arrive ends the mission.",
                    pos  = "Alzadaal Undersea Ruins",
                },
            },
        },
        [44] = { -- RAGNAROK (M45)
            name = "Ragnarok",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Step onto the second Salaheem's Sentinels platform for the scene.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                },
            },
        },
        [45] = { -- IMPERIAL_CORONATION (M46)
            name = "Imperial Coronation",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Empty both hands, wear palace-approved gear with hands, legs and feet covered, and speak to the Imperial Whitegate guard. Choose one ring: Balrahn's, Ulthalam's or Jalzahn's.",
                    pos  = "Aht Urhgan Whitegate, Imperial Whitegate (!pos 152 -2 0)",
                },
            },
        },
        [46] = { -- THE_EMPRESS_CROWNED (M47)
            name = "The Empress Crowned",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Step onto the second Salaheem's Sentinels platform. The scene ends the mission with the Glory Crown and the Eternal Mercenary title.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6.5 -56)",
                },
            },
        },
        [47] = { -- ETERNAL_MERCENARY (M48)
            name = "Eternal Mercenary",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "The line stops here. Naja Salaheem has a last word for you, but nothing completes this entry -- it stays on your log as the end of the Aht Urhgan story.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
    },
}
