-- dwtracker data -- Aht Urhgan quests (quest log 6), authored 2026-09-21,
-- the day Treasures of Aht Urhgan opened. Names from the scripts' own
-- header comments and the enum (scripts/globals/quests.lua,
-- xi.quest.id.ahtUrhgan); steps HAND-AUTHORED from
-- scripts/quests/ahtUrhgan/*.lua as ground truth, plus the battlefield and
-- instance files those scripts hand off to.
-- Pure data: numeric ids and display strings only, no xi.*, no functions
-- (DWTRACKER_FORMAT.md decisions T2/§3-4). Loaded byte-identically by the
-- server module and the dwtracker addon; both hash these bytes, so an edit
-- that reaches only one side makes the addon refuse step rendering for
-- this area until the copies agree again. tools/dwtracker_lint.py must
-- pass before any edit here ships.
--
-- FIVE THINGS ABOUT THIS LOG THAT SHAPE THE ENTRIES BELOW:
--
-- 1. 52 OF THE 72 IDS HAVE A FRAMEWORK SCRIPT and carry steps. The other
--    20 are authored NAME ONLY, and the reason is recorded on each: some
--    are unimplemented (the Voidwatch ops, the Assault-quest ids, the
--    later SoA-era rows), and two -- The Wayward Automaton (27) and
--    Operation Teatime (28), Puppetmaster AF1 and AF2 -- are real and
--    playable but live in LEGACY ZONE NPC SCRIPTS with no (log, id) of
--    their own, which the linter's source cross-check cannot reach. They
--    are named so the journal and dwreport can say what they are.
--
-- 2. THE `Prog` CHARVAR IS THE SPINE. Most of these quests advance a
--    single `Prog` counter through the section checks, and the steps are
--    that ladder. Where a quest instead uses `Prog` as a BIT MASK
--    (Arts and Crafts) or resets it mid-run, or where its only marker is
--    a day stamp (`Timer`, `Wait`, `Stage = VanadielUniqueDay()`) or a
--    dialogue toggle, the entry carries FEWER, HONEST steps rather than a
--    ladder no atom can place -- FORMAT §6.8.1, and the one forbidden
--    outcome is a bright step that is wrong.
--
-- 3. THE FIELDS ARE +60 LEVELS HERE. Every Aht Urhgan open-field zone runs
--    roughly level 120-150; Aht Urhgan Whitegate, Al Zahbi and Nashmau are
--    safe. Steps that send a player out of town say so.
--
-- 4. WHAT IS NOT AVAILABLE, said in the step text wherever a quest would
--    otherwise send a player at it: Besieged, Einherjar, Salvage, ZNM,
--    Pankration and the Chocobo Circuit. Only ten Assaults have scripts;
--    the Commissions Agency refuses the rest and refunds the tag, which
--    is what makes the nine Promotion quests (90-98) a long earth-time
--    grind -- each one needs 25 AssaultPromotion points, zeroed on every
--    promotion, and the only faucet is an Assault clear.
--
-- 5. NYZUL ISLE IS A SPLIT CASE, and quests 74 and 75 depend on the half
--    that works. `NYZUL_ENABLED` is FALSE here and was deliberately left
--    that way on 2026-09-21 (PLANS/TOAU_RAISE_PLAN.md, "Nyzul read end to
--    end"), but that flag has exactly ONE reader -- Sorrowful_Sage.lua,
--    the vendor for the Uncharted Area Survey ASSAULT. The Alzadaal Runic
--    Seal and instance 7702, which is where Waking the Colossus and
--    Divine Interference actually fight Alexander, are live and ungated.
--
-- The Road to Aht Urhgan -- the quest that opens the expansion -- is NOT
-- here: it is Jeuno 91 and already lives in jeuno_quests.lua, gated on the
-- same flag. Cross-referenced, never duplicated.
return {
    kind = 'quests',
    log = 6,
    area = 'ahturhgan_quests',
    label = "Aht Urhgan",
    entries = {
        [0] = { -- KEEPING_NOTES
            name = "Keeping Notes",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Ahkk Jharcham in Aht Urhgan Whitegate to take the job.",
                    pos  = "Aht Urhgan Whitegate, Ahkk Jharcham (!pos 0.1 -1 -76)",
                    done = { status = 1 },
                },
                {
                    text = "Get one Sheet of Parchment and one Jar of Black Ink. Both are ordinary shop and auction house goods.",
                    done = { allOf = { { item = 917 }, { item = 929 } } },
                },
                {
                    text = "Trade the Sheet of Parchment and the Jar of Black Ink together to Ahkk Jharcham.",
                    pos  = "Aht Urhgan Whitegate, Ahkk Jharcham (!pos 0.1 -1 -76)",
                },
            },
        },
        [1] = { -- ARTS_AND_CRAFTS
            name = "Arts and Crafts",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Hadahda in Aht Urhgan Whitegate and agree to help with his survey.",
                    pos  = "Aht Urhgan Whitegate, Hadahda (!pos -112 -7 -66)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to all seven townsfolk, in any order: Mhasbaf, Mathlouq, Zabahf, Ekhu Pesshyadha, Qutiba, Balakaf and Matifa. Then go back to Hadahda, who hands you a Bowl of Sutlac.",
                    pos  = "Aht Urhgan Whitegate, Mhasbaf (!pos 54 -7 11) / Mathlouq (!pos -93 -7 129) / Balakaf (!pos 25 -7 126)",
                    done = { var = 'Stage', eq = 1 },
                },
                {
                    text = "Trade the Bowl of Sutlac back to Hadahda.",
                    pos  = "Aht Urhgan Whitegate, Hadahda (!pos -112 -7 -66)",
                },
            },
        },
        [2] = { -- OLDUUM
            name = "Olduum",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Dkhaaya in Aht Urhgan Whitegate. He lends you his research journal and asks for a relic out of the Aydeewa dig.",
                    pos  = "Aht Urhgan Whitegate, Dkhaaya (!pos -73 -1 -6)",
                    done = { status = 1 },
                },
                {
                    text = "Trade a Pickaxe to the Excavation Site in Aydeewa Subterrane. Only about half the digs turn up a relic, so bring a stack. That zone is raised here to roughly level 126-140.",
                    pos  = "Aydeewa Subterrane, Excavation Site (!pos 390 1 349)",
                    done = { anyOf = { { ki = 768 }, { ki = 769 }, { ki = 770 } } },
                },
                {
                    text = "Take the relic back to Dkhaaya for a Lightning Band. Trading that ring to the Leypoint in Wajaom Woodlands turns it into an Olduum Ring.",
                    pos  = "Aht Urhgan Whitegate, Dkhaaya (!pos -73 -1 -6) / Wajaom Woodlands, Leypoint (!pos -200 -8.5 80)",
                },
            },
        },
        [3] = { -- GOT_IT_ALL
            name = "Got It All",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Tehf Kimasnahya in Aht Urhgan Whitegate to take the errand.",
                    pos  = "Aht Urhgan Whitegate, Tehf Kimasnahya (!pos -89.897 -1 6.199)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Speak to Ekhu Pesshyadha.",
                    pos  = "Aht Urhgan Whitegate, Ekhu Pesshyadha (!pos -13.043 0.999 103.423)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Speak to Zabahf.",
                    pos  = "Aht Urhgan Whitegate, Zabahf (!pos -90.070 -1 10.140)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Go back to Ekhu Pesshyadha, who hands you the Vial of Luminous Water.",
                    pos  = "Aht Urhgan Whitegate, Ekhu Pesshyadha (!pos -13.043 0.999 103.423)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Take the Vial of Luminous Water to Tehf Kimasnahya and agree to hand it over.",
                    pos  = "Aht Urhgan Whitegate, Tehf Kimasnahya (!pos -89.897 -1 6.199)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Walk to the marked spot in Aht Urhgan Whitegate to set off the next cutscene.",
                    pos  = "Aht Urhgan Whitegate, cutscene spot (!pos 59 0 -67)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Report back to Tehf Kimasnahya.",
                    pos  = "Aht Urhgan Whitegate, Tehf Kimasnahya (!pos -89.897 -1 6.199)",
                    done = { var = 'Prog', gte = 7 },
                },
                {
                    text = "Zone out and back, then return to Tehf Kimasnahya after the next Japan-time midnight to finish.",
                    pos  = "Aht Urhgan Whitegate, Tehf Kimasnahya (!pos -89.897 -1 6.199)",
                },
            },
        },
        [4] = { -- GET_THE_PICTURE
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "Get the Picture",
            gated = 'ENABLE_TOAU',
        },
        [5] = { -- AN_EMPTY_VESSEL
            name = "An Empty Vessel",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Waoud in Aht Urhgan Whitegate and take his divination; answering all ten questions correctly starts the quest, once per Vana'diel day. The DWQuest Special shelf sells this unlock for 100 Drift Coins.",
                    pos  = "Aht Urhgan Whitegate, Waoud (!pos 65 -6 -78)",
                    done = { status = 1 },
                },
                {
                    text = "Zone once, then speak to Waoud again on a later Vana'diel day. He names one of three offerings: a Siren's Tear, a Pinch of Valkurm Sunsand or a Dangruf Stone.",
                    pos  = "Aht Urhgan Whitegate, Waoud (!pos 65 -6 -78)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Bring the offering he named and trade it to Waoud. He hands it straight back, so keep it on you.",
                    pos  = "Aht Urhgan Whitegate, Waoud (!pos 65 -6 -78)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Carry that offering into Aydeewa Subterrane and walk into the marked chamber. Accept Waoud's offer in the cutscene; refusing cancels the quest. The zone runs about level 126-140 here.",
                    pos  = "Aydeewa Subterrane, marked chamber (!pos 380 0 340)",
                },
            },
        },
        [6] = { -- LUCK_OF_THE_DRAW
            name = "Luck of the Draw",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Ratihb in Aht Urhgan Whitegate. The quest runs through Arrapago Reef, level 128-149 here. The DWQuest Special shelf sells the Corsair unlock for 100 Drift Coins.",
                    pos  = "Aht Urhgan Whitegate, Ratihb (!pos 75.225 -6 -137.203)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Speak to Mafwahb, over on the east side of Aht Urhgan Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Mafwahb (!pos 149.11 -2 -2.7127)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Make your way to Arrapago Reef and examine the boat at H-10. Bring a squad or a capped main; the zone is level 128-149 here.",
                    pos  = "Arrapago Reef, boat at H-10 (!pos 468.767 -12.292 111.817)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Carry on into Talacca Cove and examine the ??? there to receive the Forgotten Hexagun. Talacca Cove runs about level 120-145.",
                    pos  = "Talacca Cove, ??? (!pos -62.239 -7.9619 -137.1251)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the rock slab in Talacca Cove to finish and unlock Corsair.",
                    pos  = "Talacca Cove, Rock Slab (!pos -99 -7 -91)",
                },
            },
        },
        [7] = { -- NO_STRINGS_ATTACHED
            name = "No Strings Attached",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Shamarhaan in Bastok Markets, then Iruki-Waraki in Aht Urhgan Whitegate. The quest runs through Arrapago Reef, level 128-149 here. The DWQuest Special shelf sells this unlock for 100 Drift Coins.",
                    pos  = "Bastok Markets, Shamarhaan (!pos -285 -13 -84) / Aht Urhgan Whitegate, Iruki-Waraki (!pos 101 -7 -29)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Ghatsad in Aht Urhgan Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Ghatsad (!pos 34.325 -7.804 57.511)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Search the pile of discarded materials in Arrapago Reef for an Antique Automaton. Bring a squad or a capped main; the zone is level 128-149 here.",
                    pos  = "Arrapago Reef, pile of discarded materials (!pos 457.128 -8.249 60.795)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Bring the Antique Automaton back to Ghatsad.",
                    pos  = "Aht Urhgan Whitegate, Ghatsad (!pos 34.325 -7.804 57.511)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Speak to Ghatsad again on a later Vana'diel day.",
                    pos  = "Aht Urhgan Whitegate, Ghatsad (!pos 34.325 -7.804 57.511)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Return to Iruki-Waraki to name your automaton and unlock Puppetmaster.",
                    pos  = "Aht Urhgan Whitegate, Iruki-Waraki (!pos 101.329 -6.999 -29.042)",
                },
            },
        },
        [8] = { -- FINDING_FAULTS
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "Finding Faults",
            gated = 'ENABLE_TOAU',
        },
        [9] = { -- GIVE_PEACE_A_CHANCE
            name = "Give Peace a Chance",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Mishhar in Aht Urhgan Whitegate to take the job.",
                    pos  = "Aht Urhgan Whitegate, Mishhar (!pos -12 -6 29)",
                    done = { status = 1 },
                },
                {
                    text = "At night only, examine the ??? in Wajaom Woodlands. By day it does nothing. The zone is raised here to roughly level 120-150.",
                    pos  = "Wajaom Woodlands, ??? (!pos 416 -24 220)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Report back to Mishhar.",
                    pos  = "Aht Urhgan Whitegate, Mishhar (!pos -12 -6 29)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the ??? in Mamook. That zone is raised here to roughly level 130-145.",
                    pos  = "Mamook, ??? (!pos 347 -12 -256)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Return to Mishhar to finish.",
                    pos  = "Aht Urhgan Whitegate, Mishhar (!pos -12 -6 29)",
                },
            },
        },
        [10] = { -- THE_ART_OF_WAR
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "The Art of War",
            gated = 'ENABLE_TOAU',
        },
        [12] = { -- A_TASTE_OF_HONEY
            name = "A Taste of Honey",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Finish Vanishing Act first, then speak to Qutiba in Aht Urhgan Whitegate. He puts you off until the wait Vanishing Act left behind has run out.",
                    pos  = "Aht Urhgan Whitegate, Qutiba (!pos 92 -7.5 -130)",
                    done = { status = 1 },
                },
                {
                    text = "Gather three Pots of White Honey from the Pephredo Hives in Wajaom Woodlands. Each hive gives one pot per Japan-time day, so work three different hives. That zone runs about level 120-150 here.",
                    pos  = "Wajaom Woodlands, Pephredo Hive (!pos 240 -18 93) / Pephredo Hive (!pos -198 -22 -414)",
                    done = { item = 5562, qty = 3 },
                },
                {
                    text = "Trade all three Pots of White Honey to Qutiba in one trade.",
                    pos  = "Aht Urhgan Whitegate, Qutiba (!pos 92 -7.5 -130)",
                },
            },
        },
        [13] = { -- SUCH_SWEET_SORROW
            name = "Such Sweet Sorrow",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Dabhuh in Aht Urhgan Whitegate. The cutscene carries you out to Caedarva Mire and straight back; the quest is only logged once you land back in Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Dabhuh (!pos 97.939 0 -91.530)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Merrow Scale. Merrows and Nixes in Arrapago Reef drop it, but that zone is level 128-149 here, so the auction house is the cheaper road.",
                    done = { item = 2146 },
                },
                {
                    text = "Trade the Merrow Scale to Dabhuh.",
                    pos  = "Aht Urhgan Whitegate, Dabhuh (!pos 97.939 0 -91.530)",
                },
            },
        },
        [14] = { -- FEAR_OF_THE_DARK_II
            name = "Fear of the Dark II",
            gated = 'ENABLE_TOAU',
            repeatable = true,
            steps = {
                {
                    text = "Talk to Suldiran in Al Zahbi and take his standing order for imp wings.",
                    pos  = "Al Zahbi, Suldiran (!pos 42 -7 -43)",
                    done = { status = 1 },
                },
                {
                    text = "Trade Suldiran two Imp Wings. He pays 200 gil, and he keeps buying pairs at the same price after the quest is finished.",
                    pos  = "Al Zahbi, Suldiran (!pos 42 -7 -43)",
                },
            },
        },
        [15] = { -- COOK_A_ROON
            name = "Cook-a-roon",
            gated = 'ENABLE_TOAU',
            repeatable = true,
            steps = {
                {
                    text = "Talk to Ququroon in Nashmau and take his order for Aht Urhgan seafood.",
                    pos  = "Nashmau, Ququroon (!pos -2 -1 67)",
                    done = { status = 1 },
                },
                {
                    text = "Trade Ququroon one each of Ahtapot, Istakoz, Istavrit, Istiridye and Mercanbaligi. He takes all five, and only about half the time does a Bowl of Nashmau Stew come back. He keeps trading afterwards.",
                    pos  = "Nashmau, Ququroon (!pos -2 -1 67)",
                },
            },
        },
        [16] = { -- THE_DIE_IS_CAST
            name = "The Die is Cast",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Ratihb at the Shaharat Teahouse in Aht Urhgan Whitegate to take the job.",
                    pos  = "Aht Urhgan Whitegate, Ratihb (!pos 75 -6 -137)",
                    done = { status = 1 },
                },
                {
                    text = "Ask Ekhu Pesshyadha about the dice.",
                    pos  = "Aht Urhgan Whitegate, Ekhu Pesshyadha (!pos -13 1 103)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Sail to Nashmau and talk to Jijiroon.",
                    pos  = "Nashmau, Jijiroon (!pos 16 0 -33)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the ??? in Arrapago Reef. That field runs level 128-149 here, so do not walk it alone.",
                    pos  = "Arrapago Reef, ??? (!pos 311 -4 170)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the ??? again to call up Bukki, and kill it.",
                    pos  = "Arrapago Reef, ??? (!pos 311 -4 170)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the ??? once more to collect the Bag of Gold Pieces.",
                    pos  = "Arrapago Reef, ??? (!pos 311 -4 170)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Carry the gold back to Ratihb for the Random Ring.",
                    pos  = "Aht Urhgan Whitegate, Ratihb (!pos 75 -6 -137)",
                },
            },
        },
        [17] = { -- TWO_HORN_THE_SAVAGE
            name = "Two Horn the Savage",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Milazahn in Aht Urhgan Whitegate and agree to hunt the beast.",
                    pos  = "Aht Urhgan Whitegate, Milazahn (!pos -58 0 2)",
                    done = { status = 1 },
                },
                {
                    text = "Trade exactly 1000 gil to Cacaroon for what he knows.",
                    pos  = "Aht Urhgan Whitegate, Cacaroon (!pos -71 0 -86)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the Viscous Liquid in Mamook. Mamook is open field here, roughly level 120-150, so bring a party.",
                    pos  = "Mamook, Viscous Liquid (!pos -262 5 -141)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the Viscous Liquid again to call up the Mamool Ja, and kill it. Zoning out does not undo this.",
                    pos  = "Mamook, Viscous Liquid (!pos -262 5 -141)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Viscous Liquid a third time to take the proof.",
                    pos  = "Mamook, Viscous Liquid (!pos -262 5 -141)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Report back to Milazahn for an Imperial Mythril Piece.",
                    pos  = "Aht Urhgan Whitegate, Milazahn (!pos -58 0 2)",
                },
            },
        },
        [18] = { -- TOTOROONS_TREASURE_HUNT
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "Totoroon's Treasure Hunt",
            gated = 'ENABLE_TOAU',
        },
        [19] = { -- WHAT_FRIENDS_ARE_FOR
            name = "What Friends Are For",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Walk into Aydeewa Subterrane and watch the cutscene that opens this. Aydeewa is open field, roughly level 120-150 here.",
                    pos  = "Aydeewa Subterrane, cutscene spot (!pos -389 13 -445)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Talk to Tsetseroon in Nashmau to take the quest.",
                    pos  = "Nashmau, Tsetseroon (!pos -13 -6 69)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Trade Tsetseroon one Chunk of Tin Ore and one Cobalt Jellyfish. He gives you the Pot of Tsetseroon's Stew.",
                    pos  = "Nashmau, Tsetseroon (!pos -13 -6 69)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Carry the stew to the ??? in Aydeewa Subterrane and hand it over. Say yes to the offer there and you get the Map of Aydeewa Subterrane on the spot.",
                    pos  = "Aydeewa Subterrane, ??? (!pos -406 7 -440)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Return to Tsetseroon. He gives the Aydeewa map, or an Imperial Bronze Piece if you already hold it.",
                    pos  = "Nashmau, Tsetseroon (!pos -13 -6 69)",
                },
            },
        },
        [20] = { -- ROCK_BOTTOM
            name = "Rock Bottom",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Examine the ??? in Mount Zhayolm to start. Mount Zhayolm is open field, roughly level 120-150 here.",
                    pos  = "Mount Zhayolm, ??? (!pos 838 -14 232)",
                    done = { status = 1 },
                },
                {
                    text = "Trade a Pickaxe to the same ???.",
                    pos  = "Mount Zhayolm, ??? (!pos 838 -14 232)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Leave Mount Zhayolm and zone back in, then trade a Mythril Pick to the ??? (the HQ pick works too). You get the Map of Mount Zhayolm, or 2000 gil if you already hold it.",
                    pos  = "Mount Zhayolm, ??? (!pos 838 -14 232)",
                },
            },
        },
        [21] = { -- BEGINNINGS
            name = "Beginnings",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Blue Mage AF1: main job BLU at level 40 or higher, An Empty Vessel finished and the ToAU mission Immortal Sentries cleared. Ask Waoud for a divination; he reads once per Vana'diel day.",
                    pos  = "Aht Urhgan Whitegate, Waoud (!pos 65 -6 -78)",
                    done = { status = 1 },
                },
                {
                    text = "Collect all five serpent Brands. Nahshib (!pos -274 -9 -64) and Nareema (!pos 518 -25 -467) stand in Caedarva Mire, Waudeen (!pos 674 -24 368) in Mount Zhayolm. All these fields run level 120-150.",
                    pos  = "Bhaflau Thickets, Daswil (!pos -209 -13 -780) / Arrapago Reef, Meyaada (!pos 22 -8 573)",
                    done = { allOf = {
                        { ki = 829 },
                        { ki = 830 },
                        { ki = 831 },
                        { ki = 832 },
                        { ki = 833 },
                    } },
                },
                {
                    text = "Go back to Waoud holding all five Brands. He hands over the Immortal's Scimitar.",
                    pos  = "Aht Urhgan Whitegate, Waoud (!pos 65 -6 -78)",
                },
            },
        },
        [22] = { -- OMENS
            name = "Omens",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Blue Mage AF2: main job BLU at level 50 or higher with Beginnings finished. Zone once after Beginnings, then talk to Waoud.",
                    pos  = "Aht Urhgan Whitegate, Waoud (!pos 65 -6 -78)",
                    done = { status = 1 },
                },
                {
                    text = "Clear the Omens battlefield. Enter Navukgo Execution Chamber and touch the Decorative Bronze Gate: up to 18 players, 30 minutes. It only opens before you report back, so go now.",
                    pos  = "Navukgo Execution Chamber, Decorative Bronze Gate (!pos -600 8 -100)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Tell Waoud what you saw and take the Sealed Immortal Envelope.",
                    pos  = "Aht Urhgan Whitegate, Waoud (!pos 65 -6 -78)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Carry the envelope to Lathuya.",
                    pos  = "Aht Urhgan Whitegate, Lathuya (!pos -95 -6 32)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the spot Lathuya names in Aydeewa Subterrane. That field runs level 120-150 here.",
                    pos  = "Aydeewa Subterrane, ??? (!pos 342 37 -25)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Report back to Lathuya for the Magus Charuqs.",
                    pos  = "Aht Urhgan Whitegate, Lathuya (!pos -95 -6 32)",
                },
            },
        },
        [23] = { -- TRANSFORMATIONS
            name = "Transformations",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Blue Mage AF3: main job BLU at level 50 or higher with Omens finished, and zone once first. Pay Waoud 1000 gil for a divination, then touch the Imperial Whitegate gate to begin.",
                    pos  = "Aht Urhgan Whitegate, Waoud (!pos 65 -6 -78) / Aht Urhgan Whitegate, Imperial Whitegate (!pos 152 -2 0)",
                    done = { status = 1 },
                },
                {
                    text = "Take the gate down to Alzadaal Undersea Ruins and walk onto the first marked spot for a cutscene.",
                    pos  = "Alzadaal Undersea Ruins, first spot (!pos 60 0 776)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Cross to the second marked spot for the next cutscene.",
                    pos  = "Alzadaal Undersea Ruins, second spot (!pos 140 0 -580)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the ??? to call up the Nepionic Soulflayer, and kill it.",
                    pos  = "Alzadaal Undersea Ruins, ??? (!pos -530 0 650)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the ??? again for the Magus Keffiyeh.",
                    pos  = "Alzadaal Undersea Ruins, ??? (!pos -530 0 650)",
                },
            },
        },
        [24] = { -- EQUIPPED_FOR_ALL_OCCASIONS
            name = "Equipped for All Occasions",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Corsair AF1: main job COR at level 40 or higher. Examine the wrecked boat at H-10 in Arrapago Reef. That field runs level 128-149 here, so get there with help.",
                    pos  = "Arrapago Reef, boat at H-10 (!pos 469 -12 112)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the iron door in Maze of Shakhrami to call up the Lost Soul, and kill it.",
                    pos  = "Maze of Shakhrami, iron door (!pos 248 18 -142)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the iron door again to take the Wheel Lock Trigger.",
                    pos  = "Maze of Shakhrami, iron door (!pos 248 18 -142)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Carry the trigger back to the boat at H-10 in Arrapago Reef.",
                    pos  = "Arrapago Reef, boat at H-10 (!pos 469 -12 112)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Finish Luck of the Draw and talk to Ratihb there for its closing cutscene. Until that has played he will not hear this report at all.",
                    pos  = "Aht Urhgan Whitegate, Ratihb (!pos 75 -6 -137)",
                    done = { allOf = {
                        { var = 'Prog', gte = 4 },
                        { var = 'Stage', eq = 1 },
                    } },
                },
                {
                    text = "Report to Ratihb for the Trump Gun.",
                    pos  = "Aht Urhgan Whitegate, Ratihb (!pos 75 -6 -137)",
                },
            },
        },
        [25] = { -- NAVIGATING_THE_UNFRIENDLY_SEAS
            name = "Navigating the Unfriendly Seas",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Corsair AF2: main job COR at level 50 or higher with Equipped for All Occasions finished. Examine the boat at H-10 in Arrapago Reef, a level 128-149 field.",
                    pos  = "Arrapago Reef, boat at H-10 (!pos 469 -12 112)",
                    done = { status = 1 },
                },
                {
                    text = "Fish up a Hydrogauge. It only bites while this quest is open, and only in Aht Urhgan Whitegate, Al Zahbi, Nashmau or on the Silver Sea ferries. Show it to Leleroon, who hands it straight back.",
                    pos  = "Nashmau, Leleroon (!pos -15 0 25)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Trade the Hydrogauge to the leypoint in Wajaom Woodlands. That field runs level 120-150 here.",
                    pos  = "Wajaom Woodlands, Leypoint (!pos -200 -9 80)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Wait about a minute at the leypoint, then examine it again to take the reading.",
                    pos  = "Wajaom Woodlands, Leypoint (!pos -200 -9 80)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Bring the reading back to the boat at H-10 in Arrapago Reef for the Corsair's Culottes.",
                    pos  = "Arrapago Reef, boat at H-10 (!pos 469 -12 112)",
                },
            },
        },
        [26] = { -- AGAINST_ALL_ODDS
            name = "Against All Odds",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Corsair AF3: main job COR at level 50 or higher with Navigating the Unfriendly Seas finished. Walk into the Shaharat Teahouse; the cutscene there hands you the Life Float.",
                    pos  = "Aht Urhgan Whitegate, Shaharat Teahouse (!pos 75 -6 -130)",
                    done = { status = 1 },
                },
                {
                    text = "Go to the ship moored off Arrapago Reef and walk up to the Cutter for the next cutscene. That field runs level 128-149 here.",
                    pos  = "Arrapago Reef, Cutter (!pos -462 -2 -394)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Board the Ashu Talif with the Life Float and kill Gowam and Yazquhl inside. Boarding consumes the float; Ratihb will issue a replacement, but only once per day.",
                    pos  = "Arrapago Reef, Cutter (!pos -462 -2 -394) / Aht Urhgan Whitegate, Ratihb (!pos 75 -6 -137)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Leaving the Ashu Talif closes the quest. If the cutscene did not play, talk to the Cutter again for the Corsair's Tricorne.",
                    pos  = "Arrapago Reef, Cutter (!pos -462 -2 -394)",
                },
            },
        },
        [27] = { -- THE_WAYWARD_AUTOMATON
            -- Name only: PUP AF1; playable, but legacy NPC scripts (Iruki-Waraki, Caedarva qm9, Dnegan) with no (log, id).
            name = "The Wayward Automaton",
            gated = 'ENABLE_TOAU',
        },
        [28] = { -- OPERATION_TEATIME
            -- Name only: PUP AF2; playable, but legacy NPC scripts (Iruki-Waraki, Caedarva qm10) with no (log, id).
            name = "Operation Teatime",
            gated = 'ENABLE_TOAU',
        },
        [29] = { -- PUPPETMASTER_BLUES
            name = "Puppetmaster Blues",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Puppetmaster AF3: main job PUP at level 50 or higher with Operation Teatime (PUP AF2) finished. AF2 is the old NPC chain and does complete, but if Dnegan in Nashmau ignores you during it, relog and retry.",
                    pos  = "Aht Urhgan Whitegate, Iruki-Waraki (!pos 101 -7 -29)",
                    done = { status = 1 },
                },
                {
                    text = "Talk to Shamarhaan in Bastok Markets to get Valkeng's Memory Chip.",
                    pos  = "Bastok Markets, Shamarhaan (!pos -285 -13 -85)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the ??? in Mount Zhayolm for the Toggle Switch, then clear Puppetmaster Blues at the Rock Slab in Talacca Cove: up to six players, 30 minutes, both key items on you.",
                    pos  = "Mount Zhayolm, ??? (!pos 761 -15 2) / Talacca Cove, Rock Slab (!pos -100 -9 -87)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Report what happened to Shamarhaan in Bastok Markets.",
                    pos  = "Bastok Markets, Shamarhaan (!pos -285 -13 -85)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Report back to Iruki-Waraki in Aht Urhgan Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Iruki-Waraki (!pos 101 -7 -29)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Talk to Sajhra in Nashmau.",
                    pos  = "Nashmau, Sajhra (!pos 15 0 -61)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Return to Iruki-Waraki for the Puppetry Taj.",
                    pos  = "Aht Urhgan Whitegate, Iruki-Waraki (!pos 101 -7 -29)",
                },
            },
        },
        [30] = { -- MOMENT_OF_TRUTH
            name = "Moment of Truth",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Finish Give Peace a Chance first, then speak to Mishhar in Aht Urhgan Whitegate to take the quest.",
                    pos  = "Aht Urhgan Whitegate, Mishhar (!pos -12 -6 29)",
                    done = { status = 1 },
                },
                {
                    text = "Walk into the Shaharat Teahouse in Aht Urhgan Whitegate for a cutscene.",
                    pos  = "Aht Urhgan Whitegate, Shaharat Teahouse (!pos 80 -6 -130)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Report back to Mishhar.",
                    pos  = "Aht Urhgan Whitegate, Mishhar (!pos -12 -6 29)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the ??? in Mamook for a cutscene. Mamook is an open field zone and is raised 60 levels here, so expect monsters around 120-150.",
                    pos  = "Mamook, ??? (!pos 217 -26 -95)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Enter Jade Sepulcher from Bhaflau Thickets and examine the Ornamental Door for a cutscene. Both zones are raised 60 levels.",
                    pos  = "Bhaflau Thickets, zone line (!pos -100 -15 -477) / Jade Sepulcher, Ornamental Door (!pos 300 -3 -200)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Enter the battlefield at the Ornamental Door and defeat Shadowhand Kajeel Ja, level 125 here. Up to 6 players, 30 minutes; a party or up to five squad members may come.",
                    pos  = "Jade Sepulcher, Ornamental Door (!pos 300 -3 -200)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Return to Mishhar for a potion chosen for your main job.",
                    pos  = "Aht Urhgan Whitegate, Mishhar (!pos -12 -6 29)",
                },
            },
        },
        [31] = { -- THREE_MEN_AND_A_CLOSET
            name = "Three Men and a Closet",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Finish Got It All first, then speak to Kubhe Ijyuhla in Aht Urhgan Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Kubhe Ijyuhla (!pos 23 0 22)",
                    done = { status = 1 },
                },
                {
                    text = "Arrive in Wajaom Woodlands straight from Aht Urhgan Whitegate for the cutscene. Warp with the Survival Guide or /port; walking out through Al Zahbi does not fire it.",
                    pos  = "Aht Urhgan Whitegate, Survival Guide (!pos 134 0 17) / Wajaom Woodlands, Survival Guide (!pos -839 -20 98)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Return to Kubhe Ijyuhla in Aht Urhgan Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Kubhe Ijyuhla (!pos 23 0 22)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Speak to Ratihb at the Shaharat Teahouse.",
                    pos  = "Aht Urhgan Whitegate, Ratihb (!pos 75 -6 -137)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Speak to Tehf Kimasnahya and agree to help him when he asks.",
                    pos  = "Aht Urhgan Whitegate, Tehf Kimasnahya (!pos -90 0 6)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Report to Kubhe Ijyuhla for an Imperial Bronze Piece.",
                    pos  = "Aht Urhgan Whitegate, Kubhe Ijyuhla (!pos 23 0 22)",
                },
            },
        },
        [32] = { -- FIVE_SECONDS_OF_FAME
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "Five Seconds of Fame",
            gated = 'ENABLE_TOAU',
        },
        [40] = { -- THE_BEAST_WITHIN
            name = "The Beast Within",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "As a Blue Mage of level 66 or higher who has finished Transformations, speak to Waoud and accept. His 1000 gil divination is optional and changes nothing.",
                    pos  = "Aht Urhgan Whitegate, Waoud (!pos 65 -6 -78)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Blue Mage's Testimony from Mamool Ja in Wajaom Woodlands or Mamook, about 10 percent. Trade it to the Imperial Whitegate to be sent to Jade Sepulcher; the trade does not take it.",
                    pos  = "Aht Urhgan Whitegate, Imperial Whitegate (!pos 154 -4 0)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Enter the battlefield at the Ornamental Door still holding the testimony and defeat Raubahn, level 130 here. Solo, no subjob, no squad, 10 minutes. You get the title and a warp scroll.",
                    pos  = "Jade Sepulcher, Ornamental Door (!pos 300 -3 -200)",
                },
            },
        },
        [41] = { -- BREAKING_THE_BONDS_OF_FATE
            name = "Breaking the Bonds of Fate",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "As a Corsair of level 66 or higher who has finished Against All Odds, examine the ??? on the boat in Arrapago Reef. The reef is a field zone raised 60 levels, roughly 120-150.",
                    pos  = "Arrapago Reef, ??? on the boat (!pos 469 -12 112)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Corsair's Testimony from Lamia and Merrow in Arrapago Reef or Caedarva Mire, about 10 percent, then trade it to the same ??? to be sent to Talacca Cove. The trade does not take it.",
                    pos  = "Arrapago Reef, ??? on the boat (!pos 469 -12 112)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Enter the battlefield at the Rock Slab still holding the testimony and defeat Qultada, level 130 here. Solo, no subjob, no squad, 10 minutes. You get the title and a warp scroll.",
                    pos  = "Talacca Cove, Rock Slab (!pos -100 -9 -87)",
                },
            },
        },
        [43] = { -- SAGA_OF_THE_SKYSERPENT
            name = "Saga of the Skyserpent",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Speak to Fari-Wari at the Shaharat Teahouse in Aht Urhgan Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the ??? in Halvung to receive the Lilac Ribbon. Halvung is reached from Mount Zhayolm, Wajaom Woodlands or Bhaflau Thickets and is raised 60 levels, roughly 120-150.",
                    pos  = "Halvung, ??? (!pos -12 8 -185)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Return to Fari-Wari. He sends you to Wajaom Woodlands for a cutscene and warps you back on his own.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Speak to Fari-Wari once more for an Imperial Gold Piece and 1000 imperial standing.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                },
            },
        },
        [44] = { -- ODE_TO_THE_SERPENTS
            name = "Ode to the Serpents",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "With Saga of the Skyserpent finished, speak to Fari-Wari to take this quest and receive Biyaada's Letter.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                    done = { status = 1 },
                },
                {
                    text = "Leave this quest open and finish both When the Bow Breaks and Fist of the People. Gaweesh and Talhaal only offer them while Ode to the Serpents is still accepted.",
                    pos  = "Al Zahbi, Gaweesh (!pos -64 -7 38) / Al Zahbi, Talhaal (!pos -36 -6 107)",
                    done = { allOf = { { completedQuest = { 6, 45 } }, { completedQuest = { 6, 46 } } } },
                },
                {
                    text = "Return to Fari-Wari for an Imperial Gold Piece.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                },
            },
        },
        [45] = { -- WHEN_THE_BOW_BREAKS
            name = "When the Bow Breaks",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "While Ode to the Serpents is accepted but not yet finished, speak to Gaweesh in Al Zahbi.",
                    pos  = "Al Zahbi, Gaweesh (!pos -64 -7 38)",
                    done = { status = 1 },
                },
                {
                    text = "Kill Aht Urhgan Attercops in Wajaom Woodlands or Bhaflau Thickets for a Frayed Arrow, about 5 percent. Both are field zones raised 60 levels, roughly 120-150.",
                    pos  = "Wajaom Woodlands, Al Zahbi zone line (!pos 614 -27 356)",
                    done = { item = 2462 },
                },
                {
                    text = "Trade the Frayed Arrow to the Giwahb Watchtower in Wajaom Woodlands for the title and 500 imperial standing.",
                    pos  = "Wajaom Woodlands, Giwahb Watchtower (!pos -339 -37 655)",
                },
            },
        },
        [46] = { -- FIST_OF_THE_PEOPLE
            name = "Fist of the People",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "While Ode to the Serpents is accepted but not yet finished, speak to Talhaal in Al Zahbi.",
                    pos  = "Al Zahbi, Talhaal (!pos -36 -6 107)",
                    done = { status = 1 },
                },
                {
                    text = "Report to Fari-Wari at the Shaharat Teahouse in Aht Urhgan Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Kill Wajaom Tigers in Wajaom Woodlands or Bhaflau Thickets for a Rusty Medal, about 5 percent, then trade it to the Leypoint. Both are field zones raised 60 levels, roughly 120-150.",
                    pos  = "Wajaom Woodlands, Leypoint (!pos -200 -10 80)",
                },
            },
        },
        [47] = { -- SOOTHING_WATERS
            name = "Soothing Waters",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "With Ode to the Serpents finished, speak to Fari-Wari and accept.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Eunheem in Aht Urhgan Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Eunheem (!pos -56 0 -3)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Speak to Nadeey in Aht Urhgan Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Nadeey (!pos 80 0 55)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Speak to Mihli Aliapoh in Al Zahbi.",
                    pos  = "Al Zahbi, Mihli Aliapoh (!pos -23 -6 79)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Kill Aydeewa Diremites in Aydeewa Subterrane for a Tuft of Colorful Hair, about 10 percent, then trade it to the ??? there. The zone is raised 60 levels, roughly 120-150.",
                    pos  = "Aydeewa Subterrane, ??? (!pos 352 2 377)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Report to Fari-Wari for an Imperial Gold Piece and 500 imperial standing.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                },
            },
        },
        [48] = { -- EMBERS_OF_HIS_PAST
            name = "Embers of His Past",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "With Soothing Waters finished, speak to Fari-Wari. He warps you through two cutscenes in Wajaom Woodlands and returns you to Aht Urhgan Whitegate on his own.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Sprightly Footsteps in Mount Zhayolm between 18:00 and 06:00 game time. The zone is raised 60 levels, roughly 120-150.",
                    pos  = "Mount Zhayolm, Sprightly Footsteps (!pos 822 -18 176)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Still at night, examine the Withered Petals in Mount Zhayolm.",
                    pos  = "Mount Zhayolm, Withered Petals (!pos 857 -15 249)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Get a Hydrangea from Hilltroll Warriors or Red Mages in Mount Zhayolm, about 10 percent, and trade it to Fari-Wari. Two more cutscenes play in Wajaom Woodlands; you keep the flower.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                    done = { var = 'Prog', gte = 8 },
                },
                {
                    text = "Between 18:00 and 06:00, trade the Hydrangea to the Withered Petals in Mount Zhayolm.",
                    pos  = "Mount Zhayolm, Withered Petals (!pos 857 -15 249)",
                    done = { var = 'Prog', gte = 9 },
                },
                {
                    text = "Report to Fari-Wari for an Imperial Gold Piece and 500 imperial standing, then zone out and back and speak to him again for a Mercenary Camp Entry Slip.",
                    pos  = "Aht Urhgan Whitegate, Fari-Wari (!pos 80 -6 -137)",
                },
            },
        },
        [60] = { -- THE_PRANKSTER
            name = "The Prankster",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Ahaadah in Aht Urhgan Whitegate and take his errand.",
                    pos  = "Aht Urhgan Whitegate, Ahaadah (!pos -70 -6 105)",
                    done = { status = 1 },
                },
                {
                    text = "Walk to the first spot Ahaadah described, on the upper level of Whitegate, and watch the scene.",
                    pos  = "Aht Urhgan Whitegate (!pos 23 1 -99)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Walk to the second spot, down near the Shaharat Teahouse, for the next scene.",
                    pos  = "Aht Urhgan Whitegate (!pos 27 -6 -125)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Take the Ironbound Gate out to Bhaflau Thickets, check the ??? to pop the Plague Chigoe and kill it. Field zones here are raised about 60 levels, so it fights at roughly 120.",
                    pos  = "Aht Urhgan Whitegate, Ironbound Gate (!pos -43.2 0 56) / Bhaflau Thickets (!pos 460 -15 256)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Check the ??? again to finish and receive the Map of Caedarva Mire.",
                    pos  = "Bhaflau Thickets, ??? (!pos 460 -15 256)",
                },
            },
        },
        [61] = { -- DELIVERING_THE_GOODS
            name = "Delivering the Goods",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Fochacha in Aht Urhgan Whitegate to take the delivery job.",
                    pos  = "Aht Urhgan Whitegate, Fochacha (!pos 3 -1 -11)",
                    done = { status = 1 },
                },
                {
                    text = "Hand the goods to Qutiba or Ulamaal at the Shaharat Teahouse.",
                    pos  = "Aht Urhgan Whitegate, Qutiba (!pos 92 -7.5 -130) / Ulamaal (!pos 93 -7.5 -128)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Report back to Fochacha for three Imperial Bronze Pieces.",
                    pos  = "Aht Urhgan Whitegate, Fochacha (!pos 3 -1 -11)",
                },
            },
        },
        [62] = { -- VANISHING_ACT
            name = "Vanishing Act",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Qutiba or Ulamaal to take the job. It needs Delivering the Goods finished, and they will not start it until you have zoned and the next game day has begun.",
                    pos  = "Aht Urhgan Whitegate, Qutiba (!pos 92 -7.5 -130) / Ulamaal (!pos 93 -7.5 -128)",
                    done = { status = 1 },
                },
                {
                    text = "Ask Fochacha what the missing ingredient is.",
                    pos  = "Aht Urhgan Whitegate, Fochacha (!pos 3 -1 -11)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Walk to the west end of Whitegate for the scene that sends you out of the city.",
                    pos  = "Aht Urhgan Whitegate (!pos -80 -6 129)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Trade a Sickle to a Harvesting Point in Wajaom Woodlands to get the Rainbow Berry. That field zone is raised about 60 levels here, so travel carefully.",
                    pos  = "Wajaom Woodlands, Harvesting Point (!pos 170 -28 70) / (!pos 240 -16 82)",
                    done = { allOf = { { var = 'Prog', gte = 2 }, { ki = 776 } } },
                },
                {
                    text = "Bring the berry back to Qutiba or Ulamaal for an Imperial Silver Piece.",
                    pos  = "Aht Urhgan Whitegate, Qutiba (!pos 92 -7.5 -130) / Ulamaal (!pos 93 -7.5 -128)",
                },
            },
        },
        [63] = { -- STRIKING_A_BALANCE
            name = "Striking a Balance",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Saliyahf in Aht Urhgan Whitegate to take the job.",
                    pos  = "Aht Urhgan Whitegate, Saliyahf (!pos -60 0 65)",
                    done = { status = 1 },
                },
                {
                    text = "Go and hear Wazyih out.",
                    pos  = "Aht Urhgan Whitegate, Wazyih (!pos -94 -6 -93)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Walk to the spot Wazyih pointed out, in the northwest of Whitegate, for the scene.",
                    pos  = "Aht Urhgan Whitegate (!pos -101 0 -14)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Tell Wazyih what you saw.",
                    pos  = "Aht Urhgan Whitegate, Wazyih (!pos -94 -6 -93)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Find the wandering carrier in Al Zahbi holding Munahda's Package. BLOCKED: that NPC is missing from this server's data, so the quest cannot be carried past this point.",
                    pos  = "Al Zahbi (!pos 53 0 60) / Al Zahbi (!pos 18 0 -30)",
                },
            },
        },
        [64] = { -- NOT_MEANT_TO_BE
            name = "Not Meant to Be",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Fhe Maksojha in Nashmau and take the job.",
                    pos  = "Nashmau, Fhe Maksojha (!pos 19 -7 71)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Check the ??? in Caedarva Mire. That field zone is raised about 60 levels here, so the trip out is dangerous below the cap.",
                    pos  = "Caedarva Mire, ??? (!pos 457 -7 -271)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Go back to Fhe Maksojha in Nashmau with what you found.",
                    pos  = "Nashmau, Fhe Maksojha (!pos 19 -7 71)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Return to the ??? to pop Lamia No.27 and Moshdahn, and kill both. They sit near the top of the raised band, around level 140.",
                    pos  = "Caedarva Mire, ??? (!pos 457 -7 -271)",
                    done = { allOf = { { var = 'Prog', gte = 3 }, { var = 'Stage', gte = 3 } } },
                },
                {
                    text = "Check the ??? once more now that both are dead.",
                    pos  = "Caedarva Mire, ??? (!pos 457 -7 -271)",
                    done = { allOf = { { var = 'Prog', gte = 4 }, { var = 'Stage', gte = 3 } } },
                },
                {
                    text = "Report to Fhe Maksojha for three Imperial Gold Pieces.",
                    pos  = "Nashmau, Fhe Maksojha (!pos 19 -7 71)",
                },
            },
        },
        [65] = { -- LED_ASTRAY
            name = "Led Astray",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Mhasbaf in Aht Urhgan Whitegate to take the job.",
                    pos  = "Aht Urhgan Whitegate, Mhasbaf (!pos 54.7 -7 11.4)",
                    done = { status = 1 },
                },
                {
                    text = "Walk east to the spot Mhasbaf named and watch the scene.",
                    pos  = "Aht Urhgan Whitegate (!pos 71 0 9)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Ask Tohka Telposkha about the boy.",
                    pos  = "Aht Urhgan Whitegate, Tohka Telposkha (!pos 22.1 0 22.8)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Ask both Rubahah and Cacaroon. You need to hear from each of them before the trail moves on.",
                    pos  = "Aht Urhgan Whitegate, Rubahah (!pos -96.7 0 -14.7) / Cacaroon (!pos -72 0 -82.3)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Walk to the last spot in Whitegate to be handed the Letter from Bernahn.",
                    pos  = "Aht Urhgan Whitegate (!pos 12 2 -94)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Take the letter to Tataroon in Nashmau for an Imperial Silver Piece.",
                    pos  = "Nashmau, Tataroon (!pos -25.2 0 -39)",
                },
            },
        },
        [66] = { -- RAT_RACE
            name = "Rat Race",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Kakkaroon in Nashmau and take the job.",
                    pos  = "Nashmau, Kakkaroon (!pos 13.2 0 -25.3)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Ask Nadee Periyaha in Aht Urhgan Whitegate about the rats.",
                    pos  = "Aht Urhgan Whitegate, Nadee Periyaha (!pos -10.8 0 -1.2)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Trade an Imperial Bronze Piece to Cacaroon in Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Cacaroon (!pos -72 0 -82.3)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Talk to Ququroon in Nashmau and hear what he wants.",
                    pos  = "Nashmau, Ququroon (!pos -2.4 -1 66.8)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Trade Ahtapot, Istakoz, Istavrit, Istiridye and Mercanbaligi to Ququroon in one trade. All five are fished in Aht Urhgan waters.",
                    pos  = "Nashmau, Ququroon (!pos -2.4 -1 66.8)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Trade the Bowl of Nashmau Stew to Kyokyoroon.",
                    pos  = "Nashmau, Kyokyoroon (!pos 18 -6 10.5)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Report to Kakkaroon for the pay: Imperial Gold, Mythril and Silver Pieces.",
                    pos  = "Nashmau, Kakkaroon (!pos 13.2 0 -25.3)",
                },
            },
        },
        [67] = { -- THE_PRINCE_AND_THE_HOPPER
            name = "The Prince and the Hopper",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Talk to Maudaal in Aht Urhgan Whitegate and agree to help.",
                    pos  = "Aht Urhgan Whitegate, Maudaal (!pos -147.2 1.8 -3.1)",
                    done = { status = 1 },
                },
                {
                    text = "Leave by the southern Ironbound Gate into Wajaom Woodlands. The scene fires as you land at the northeastern tower, and that gate is the only route that puts you on the trigger.",
                    pos  = "Aht Urhgan Whitegate, Ironbound Gate (!pos -43.2 0 -56) / Wajaom Woodlands (!pos 690 -18.5 220)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the Toad's Footprint in eastern Mamook. You are then shuttled through two scenes in Wajaom Woodlands and back. Both field zones run about 60 levels above retail.",
                    pos  = "Mamook, Toad's Footprint (!pos 216.1 -23.8 -102.5)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the other Toad's Footprint, in western Mamook.",
                    pos  = "Mamook, Toad's Footprint (!pos -42.9 6 -100.3)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Examine it again to pop Poroggo Casanova and its five escorts, then kill the Casanova. Bring help: it fights near level 120.",
                    pos  = "Mamook, Toad's Footprint (!pos -42.9 6 -100.3)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Examine the footprint once more for the closing scene.",
                    pos  = "Mamook, Toad's Footprint (!pos -42.9 6 -100.3)",
                    done = { var = 'Prog', gte = 7 },
                },
                {
                    text = "Report to Maudaal in Whitegate for Chanoix's Gorget.",
                    pos  = "Aht Urhgan Whitegate, Maudaal (!pos -147.2 1.8 -3.1)",
                },
            },
        },
        [68] = { -- VW_OP_050_AHT_URGAN_ASSAULT
            -- Name only: Voidwatch; not on this server.
            name = "VW Op. 050: Aht Urhgan Assault",
            gated = 'ENABLE_TOAU',
        },
        [69] = { -- VW_OP_068_SUBTERRAINEAN_SKIRMISH
            -- Name only: Voidwatch; not on this server.
            name = "VW Op. 068: Subterranean Skirmish",
            gated = 'ENABLE_TOAU',
        },
        [70] = { -- AN_IMPERIAL_HEIST
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "An Imperial Heist",
            gated = 'ENABLE_TOAU',
        },
        [71] = { -- DUTIES_TASKS_AND_DEEDS
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "Duties, Tasks, and Deeds",
            gated = 'ENABLE_TOAU',
        },
        [72] = { -- FORGING_A_NEW_MYTH
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "Forging a New Myth",
            gated = 'ENABLE_TOAU',
        },
        [73] = { -- COMING_FULL_CIRCLE
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "Coming Full Circle",
            gated = 'ENABLE_TOAU',
        },
        [74] = { -- WAKING_THE_COLOSSUS
            name = "Waking the Colossus",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Needs the ToAU mission The Eternal Mercenary as your current mission. Step into Salaheem's Sentinels for the scene, then ask the Imperial Whitegate for the job and take the Imperial Missive.",
                    pos  = "Aht Urhgan Whitegate, Salaheem's Sentinels (!pos 35 -6 -45) / Imperial Whitegate (!pos 152.8 -2.2 0.1)",
                    done = { status = 1 },
                },
                {
                    text = "Carry the missive to the Audience Chamber door in Ru'Lude Gardens.",
                    pos  = "Ru'Lude Gardens, Audience Chamber (!pos 0 -5 66)",
                    -- Widened to the same anyOf shape as step 3 so that step
                    -- 3 provably implies it: holding any of the approval key
                    -- items is itself proof this door has been opened, and
                    -- the Prog branch is the survivor that keeps the
                    -- consumables from un-doing the step.
                    done = {
                        anyOf = {
                            { ki = 1244 },
                            { ki = 1245 },
                            { ki = 1247 },
                            { var = 'Prog', gte = 2 },
                        },
                    },
                },
                {
                    text = "Collect approval from Halver in Chateau d'Oraguille, Iron Eater in the Metalworks and Kupipi in Heavens Tower, then go back to the Audience Chamber door for Jeuno's letter.",
                    pos  = "Chateau d'Oraguille (!pos 2.4 0 0) / Metalworks (!pos 91 -19 1) / Heavens Tower (!pos 2 0 30)",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 2 }, { ki = 1244 } } }, { allOf = { { var = 'Prog', gte = 2 }, { ki = 1245 } } }, { allOf = { { var = 'Prog', gte = 2 }, { ki = 1247 } } }, { var = 'Prog', gte = 3 } } },
                },
                {
                    text = "Show the four letters to the Imperial Whitegate to swap them for Megomak's present.",
                    pos  = "Aht Urhgan Whitegate, Imperial Whitegate (!pos 152.8 -2.2 0.1)",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 2 }, { ki = 1245 } } }, { allOf = { { var = 'Prog', gte = 2 }, { ki = 1247 } } }, { var = 'Prog', gte = 3 } } },
                },
                {
                    text = "Take the present to the Acid-eaten Door in Mount Zhayolm and trade it for Megomak's shopping list. That field zone is raised about 60 levels here.",
                    pos  = "Mount Zhayolm, Acid-eaten Door (!pos 271.9 -32 -88)",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 2 }, { ki = 1247 } } }, { var = 'Prog', gte = 3 } } },
                },
                {
                    text = "Trade three Slabs of Plumbago to the same door for the Lightning Cell.",
                    pos  = "Mount Zhayolm, Acid-eaten Door (!pos 271.9 -32 -88)",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 2 }, { ki = 1247 }, { ki = 1246 } } }, { var = 'Prog', gte = 3 } } },
                },
                {
                    text = "Take the Lightning Cell to the Blank Lamp in Alzadaal Undersea Ruins.",
                    pos  = "Alzadaal Undersea Ruins, Blank Lamp (!pos 209.4 0 20)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Touch the Runic Seal to register the Nyzul Isle instance and beat Alexander inside the 15 minute limit. The cell is spent on entry, so a wipe means another three Slabs of Plumbago.",
                    pos  = "Alzadaal Undersea Ruins, Runic Seal (!pos 125 -2 20)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "You are dropped back into Alzadaal with the Whisper of Radiance. Report to the Imperial Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Imperial Whitegate (!pos 152.8 -2.2 0.1)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Claim your reward from Naja Salaheem: Colossus's Mantle, Earring or Torque, 10000 gil, or the Alexander spell.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [75] = { -- DIVINE_INTERFERENCE
            name = "Divine Interference",
            gated = 'ENABLE_TOAU',
            repeatable = true,
            steps = {
                {
                    text = "Needs Waking the Colossus finished with The Eternal Mercenary still your current ToAU mission, and it does not open until the next Japanese midnight. Ask the Imperial Whitegate for the job.",
                    pos  = "Aht Urhgan Whitegate, Imperial Whitegate (!pos 152.8 -2.2 0.1)",
                    done = { status = 1 },
                },
                {
                    text = "Report to the Acid-eaten Door in Mount Zhayolm. That field zone is raised about 60 levels here.",
                    pos  = "Mount Zhayolm, Acid-eaten Door (!pos 271.9 -32 -88)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Trade three Slabs of Plumbago to the door for a Lightning Cell.",
                    pos  = "Mount Zhayolm, Acid-eaten Door (!pos 271.9 -32 -88)",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 2 }, { ki = 1246 } } }, { var = 'Prog', gte = 3 } } },
                },
                {
                    text = "Take the cell to the Blank Lamp in Alzadaal Undersea Ruins.",
                    pos  = "Alzadaal Undersea Ruins, Blank Lamp (!pos 209.4 0 20)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Touch the Runic Seal to register the Nyzul Isle instance and beat Alexander inside the 15 minute limit. The cell is spent on entry.",
                    pos  = "Alzadaal Undersea Ruins, Runic Seal (!pos 125 -2 20)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "You return to Alzadaal with the Whisper of Radiance. Claim your reward from Naja Salaheem; the job can be taken again after the next Japanese midnight.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 22.7 -8.8 -45.6)",
                },
            },
        },
        [76] = { -- THE_RIDER_COMETH
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "The Rider Cometh",
            gated = 'ENABLE_TOAU',
        },
        [77] = { -- UNWAVERING_RESOLVE
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "Unwavering Resolve",
            gated = 'ENABLE_TOAU',
        },
        [78] = { -- A_STYGIAN_PACT
            -- Name only: no script in scripts/quests/ahtUrhgan/.
            name = "A Stygian Pact",
            gated = 'ENABLE_TOAU',
        },
        [90] = { -- PROMOTION_PRIVATE_FIRST_CLASS
            name = "Promotion: Private First Class",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Bank 25 Assault promotion points, then talk to Naja Salaheem. Points come only from clearing an Assault: 5 for your first clear of one, 1 after that. Ten Assaults are built here; the agency refuses the rest.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                    done = { status = 1 },
                },
                {
                    text = "Trade an Imp Wing to Naja Salaheem. Heraldic Imps in Caedarva Mire and Arrapago Reef drop them; both are open fields, raised to roughly level 120-150 here.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                },
            },
        },
        [91] = { -- PROMOTION_SUPERIOR_PRIVATE
            name = "Promotion: Superior Private",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Your promotion points were zeroed by the last promotion, so bank 25 more, then talk to Naja Salaheem. Imperial Army ID Tags restock one per earth day and cap at three, so this is the slow part.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                    done = { status = 1 },
                },
                {
                    text = "Examine a Warhorse Hoofprint out in the fields for the Dark Rider Hoofprint. These zones sit around level 120-150. Skip Mount Zhayolm: its three hoofprints are unplaced on this server.",
                    pos  = "Wajaom Woodlands (!pos -621 -10 -69) / Bhaflau Thickets (!pos 460 -15 256) / Caedarva Mire (!pos 413 -21 -114)",
                    done = { ki = 789 },
                },
                {
                    text = "Carry the Dark Rider Hoofprint back to Naja Salaheem.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                },
            },
        },
        [92] = { -- PROMOTION_LANCE_CORPORAL
            name = "Promotion: Lance Corporal",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Bank another 25 Assault promotion points, then talk to Abquhbah in Whitegate to take the mythralline survey.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { status = 1 },
                },
                {
                    text = "Talk to Nafiwaa on the north side of Whitegate. He hands you five empty test tubes.",
                    pos  = "Aht Urhgan Whitegate, Nafiwaa (!pos -74 -6 126)",
                    done = { var = 'Stage', gte = 1 },
                },
                {
                    text = "Fill all five tubes: four Mythralline Wellsprings stand in Wajaom Woodlands and one in Bhaflau Thickets. Take the full set back to Nafiwaa and mix. Both fields run around level 120-150.",
                    pos  = "Wajaom Woodlands, wellsprings (!pos -92 -15 -339) (!pos 181 -23 268) / Bhaflau Thickets (!pos 181 -15 373)",
                    done = { var = 'Stage', gte = 3 },
                },
                {
                    text = "Wait one Vana'diel day, then walk into Abquhbah's corner of Whitegate to be promoted. A denser mix pays better; a worthless mix pays nothing and leaves you stuck, so remix before you hand it in.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                },
            },
        },
        [93] = { -- PROMOTION_CORPORAL
            name = "Promotion: Corporal",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Bank another 25 Assault promotion points, then talk to Naja Salaheem. She hands you a Quartz Transmitter.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                    done = { status = 1 },
                },
                {
                    text = "Plant the transmitter at any Warhorse Hoofprint. Wajaom Woodlands, Bhaflau Thickets and Caedarva Mire all have real ones; Mount Zhayolm's are unplaced here. Expect level 120-150 out there.",
                    pos  = "Wajaom Woodlands (!pos -621 -10 -69) / Bhaflau Thickets (!pos 460 -15 256) / Caedarva Mire (!pos 413 -21 -114)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Report back to Naja Salaheem.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                },
            },
        },
        [94] = { -- PROMOTION_SERGEANT
            name = "Promotion: Sergeant",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Bank another 25 Assault promotion points, then talk to Naja Salaheem and accept the job.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                    done = { status = 1 },
                },
                {
                    text = "Walk to the west end of Aht Urhgan Whitegate for a scene.",
                    pos  = "Aht Urhgan Whitegate, west end (!pos -80 0 0)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Sail to Nashmau and walk into the dock area. If no scene plays, or the one that plays leads nowhere, come back on a later Vana'diel day and walk in again.",
                    pos  = "Nashmau, dock area (!pos 0 0 -40)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Trade a Bowl of Sutlac to Totoroon in Nashmau. No shop here stocks it: it is a Cooking 40 synth on a fire crystal, so buy one off the auction house or make it.",
                    pos  = "Nashmau, Totoroon (!pos -13 0 -24)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the ??? in southern Caedarva Mire. The zone is raised to roughly level 120-150.",
                    pos  = "Caedarva Mire, ??? (!pos 195 2 -616)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Report back to Naja Salaheem.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                },
            },
        },
        [95] = { -- PROMOTION_SERGEANT_MAJOR
            name = "Promotion: Sergeant Major",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Bank another 25 Assault promotion points, then talk to Naja Salaheem. She sets three mercenary tests, and you get one attempt per Vana'diel day at whichever one you are on.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                    done = { status = 1 },
                },
                {
                    text = "Pass Naja's first test. Fail it and nothing is lost except the day; come back tomorrow and try again.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                    done = { var = 'Stage', gte = 1 },
                },
                {
                    text = "Pass the second test, again one attempt per Vana'diel day.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                    done = { var = 'Stage', gte = 3 },
                },
                {
                    text = "Pass the third test, again one attempt per Vana'diel day.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                    done = { var = 'Stage', gte = 5 },
                },
                {
                    text = "Let one more Vana'diel day pass, then talk to Naja Salaheem for the promotion.",
                    pos  = "Aht Urhgan Whitegate, Naja Salaheem (!pos 26 -8 -45.5)",
                },
            },
        },
        [96] = { -- PROMOTION_CHIEF_SERGEANT
            name = "Promotion: Chief Sergeant",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Bank another 25 Assault promotion points, then talk to Abquhbah in Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35 -6 -58)",
                    done = { status = 1 },
                },
                {
                    text = "Talk to Hagakoff, east along the canal from Abquhbah.",
                    pos  = "Aht Urhgan Whitegate, Hagakoff (!pos 82 0 -74)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Go back to Abquhbah with what Hagakoff told you.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35 -6 -58)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Talk to Hagakoff once more to get the growing instructions.",
                    pos  = "Aht Urhgan Whitegate, Hagakoff (!pos 82 0 -74)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "In Aydeewa Subterrane, examine a Mushroom Patch for a Scourshroom, plant it at a second patch, zone out, then return and pick the crop. Hand the mushrooms to Abquhbah. The zone is raised.",
                    pos  = "Aydeewa Subterrane, patches (!pos 123 37 6) (!pos -208 9 143) / Aht Urhgan Whitegate, Abquhbah (!pos 35 -6 -58)",
                    done = { allOf = { { var = 'Prog', gte = 3 }, { var = 'Stage', gte = 1 } } },
                },
                {
                    text = "Keep growing and handing in mushrooms until Abquhbah has enough and promotes you. Picking between 4:00 and 6:00 Vana'diel time can double a patch, and a patch pays out only once.",
                    pos  = "Aydeewa Subterrane, patches (!pos 117 37 -46) (!pos -221 9 141) / Aht Urhgan Whitegate, Abquhbah (!pos 35 -6 -58)",
                },
            },
        },
        [97] = { -- PROMOTION_SECOND_LIEUTENANT
            name = "Promotion: Second Lieutenant",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Bank another 25 Assault promotion points, then talk to Abquhbah, or simply walk into his corner of Whitegate.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { status = 1 },
                },
                {
                    text = "Trade 3 Imperial Gold Pieces to Abquhbah for the Officer Academy Manual. Nothing on this server sells imperial coins: they come only from Aht Urhgan quest and mission rewards, or the auction house.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Trade 2 Imperial Mythril Pieces to Abquhbah and sit the first academy exam. A failed exam eats the coins, so bank spares before you start.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Trade 2 more Imperial Mythril Pieces for the second exam.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Trade Abquhbah one piece of beastman gear: Mamool Ja Collar or Helm, Troll Pauldron or Vambrace, Lamian Armlet or Kaman, Qutrub Gorget, Macuahuitl, Jadagna, Januwiyah or Tariqah. All drop in the raised fields.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Trade 2 last Imperial Mythril Pieces for the final exam. Pass it and you make Second Lieutenant.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                },
            },
        },
        [98] = { -- PROMOTION_FIRST_LIEUTENANT
            name = "Promotion: First Lieutenant",
            gated = 'ENABLE_TOAU',
            steps = {
                {
                    text = "Bank another 25 Assault promotion points, then walk into Abquhbah's corner of Aht Urhgan Whitegate. There is no NPC to talk to for this one: the opening scene fires on the spot.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { status = 1 },
                },
                {
                    text = "Trade 5 Imperial Gold Pieces to Abquhbah as tuition, then come back on a later Vana'diel day and win his counterespionage game. One attempt per day, and a loss costs nothing but the day.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Win Abquhbah's cipher game, one attempt per Vana'diel day.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Win Abquhbah's rock-paper-scissors game, one attempt per Vana'diel day.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Talk to Abquhbah between 15:00 and 16:59 Vana'diel time to set up the graduation. Outside that window he only repeats himself.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Zone out and back, then talk to Abquhbah again between 15:00 and 16:59 Vana'diel time to graduate as First Lieutenant.",
                    pos  = "Aht Urhgan Whitegate, Abquhbah (!pos 35.5 -6.6 -58)",
                },
            },
        },
        [99] = { -- PROMOTION_CAPTAIN
            -- Name only: no script; the rank chain stops at First Lieutenant here.
            name = "Promotion: Captain",
            gated = 'ENABLE_TOAU',
        },
        [101] = { -- SCOUTING_THE_ASHU_TALIF
            -- Name only: Assault quest id; the Assault itself is not implemented.
            name = "Scouting the Ashu Talif",
            gated = 'ENABLE_TOAU',
        },
        [102] = { -- ROYAL_PAINTER_ESCORT
            -- Name only: Assault quest id; the Assault itself is not implemented.
            name = "Royal Painter Escort",
            gated = 'ENABLE_TOAU',
        },
        [103] = { -- TARGETING_THE_CAPTAIN
            -- Name only: Assault quest id; the Assault itself is not implemented.
            name = "Targeting the Captain",
            gated = 'ENABLE_TOAU',
        },
    },
}
