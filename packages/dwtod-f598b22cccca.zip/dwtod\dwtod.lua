--[[
* DriftwoodXI -- dwtod
*
* Time of death, in a window. Every timer-pop notorious monster on this
* server in one searchable list: whether it is up or dead, how long it has
* been dead, how long until it comes back, the window it comes back inside,
* and -- a click on the row -- its level band, its spawn spot, its family,
* whether it aggroes and links, and its four best drops at THIS server's
* rates. Pin the ones you camp and they stay at the top of the list, per
* character.
*
* THE ONE NON-NEGOTIABLE: THE SERVER IS THE ONLY SOURCE OF STATE. On retail a
* camper's TOD is hearsay typed into a spreadsheet; here the server is
* standing next to the monster. It knows whether the entity is alive, it
* holds the respawn clock, and it wrote the time of death down when the thing
* died. So this window is a RENDERER (the dwbags rule, inherited whole): it
* asks, it draws what came back, and the ONE number it derives is the tick of
* a clock the server handed it -- "dead for" counted up from the server's own
* `tod` against the server's own `serverEpoch`, and "respawn in" counted down
* from the server's own `remain`, both aged by how long the answer has been on
* screen. THE CLIENT'S CLOCK IS ONLY EVER USED FOR THAT DELTA: a machine whose
* clock is minutes out still draws the right countdown, because the base is
* the server's. When a countdown reaches zero the window does not decide the
* monster is up -- it asks once more and shows whatever the server says.
*
* THE CATALOG SHIPS INSIDE THE ADDON (catalog.lua, GENERATED from the server's
* own dumps -- never edit by hand). Names, zones, level bands, spawn spots,
* families, respawn windows and drop rates are its rows; the wire carries only
* the four things that MOVE (state, tod, remain, hp) plus the claimer. Both
* copies carry a hash and the server echoes its own in `h|`, so an addon whose
* catalog is not the server's says so on the header and keeps drawing rather
* than pretending the row numbers still line up.
*
* WHAT IS NOT HERE, and the footer says it in one line: lottery pops and
* forced/event pops. They have no clock of their own -- a lottery NM takes a
* placeholder's slot when a roll goes its way -- so there is no countdown to
* draw and inventing one is exactly the lie dwscan 1.5.0 was filed against.
*
* IT TAKES NO ZONE-IN SLOT AND SAYS NOTHING WHILE IT IS SHUT. Every ask fires
* from the render loop, the first frame the window is actually shown in a zone
* (the dwunleashed decision; see dwecho.lua's ZONE_ORDER, which this addon is
* deliberately absent from). A zone line RE-ARMS that first ask rather than
* sending one, so a player who never opens the window never handshakes and the
* login burst is exactly as long as it was before this addon existed. While
* the window is open it asks for the rows on screen once a minute, one line at
* a time, and never at all once a latch is set; a countdown that runs out
* brings that ask forward ONCE per row, and no automatic ask of any kind
* follows another inside STATE_FLOOR.
*
* TURN IT OFF AND NOTHING IS LOST. `!tod` lists the current zone typed and
* `!tod <text>` answers up to eight matches as sentences.
*
* Over `!dwto` (`documentation/dwto_protocol.md`).
--]]

addon.name    = 'dwtod';
addon.author  = 'DriftwoodXI';
-- 1.0.2 (2026-09-24): dwecho.lua only -- the shared command-error swallow no
-- longer eats another player's chat line that happens to quote the error.
addon.version = '1.0.2';
addon.desc    = 'DriftwoodXI Time of Death: every timer-pop NM, up or dead, with the server\'s own respawn clock.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

--[[
* The catalog, generated beside this file. A missing or broken copy renders
* ONE honest sentence rather than a crash -- the window still opens, the
* header still works, and the player is told what to do about it.
--]]
local catalogOk, catalog = pcall(require, 'catalog');

if (not catalogOk or type(catalog) ~= 'table' or type(catalog.rows) ~= 'table') then
    catalog = { hash = '', rows = { } };
end

if (type(catalog.hash) ~= 'string') then
    catalog.hash = '';
end

--[[
* A GENERATED FILE THAT PARSED IS NOT A GENERATED FILE THAT IS WHOLE (the
* dwnemesis lesson, and the promise above is "one honest sentence rather than
* a crash"). A row that reached this window without its `idx` would take the
* window down the first frame it was drawn -- a nil table key is an error to
* WRITE where it is merely nil to read, and both the search haystack and the
* pin button's label are remembered per row by idx. Every field the render
* pass indexes or formats is checked once, here, and a row missing one is left
* out of the list rather than allowed to close it. The optional shapes
* (`mobs`, `drops`) are REPAIRED rather than refused: a row with no drop table
* is a real row on this server, and forty-seven of them exist.
--]]
do
    local usable = { };

    for _, row in ipairs(catalog.rows) do
        if (type(row) == 'table'
                and type(row.idx) == 'number' and row.idx > 0 and row.idx == math.floor(row.idx)
                and type(row.key) == 'string' and row.key ~= ''
                and type(row.name) == 'string' and row.name ~= ''
                and type(row.zone) == 'number'
                and type(row.zoneName) == 'string'
                and type(row.lvlLo) == 'number' and type(row.lvlHi) == 'number'
                and type(row.base) == 'number'
                and type(row.winLo) == 'number' and type(row.winHi) == 'number'
                and type(row.x) == 'number' and type(row.y) == 'number' and type(row.z) == 'number'
                and type(row.family) == 'string'
                and type(row.aggro) == 'number' and type(row.links) == 'number') then
            if (type(row.drops) ~= 'table') then
                row.drops = { };
            end

            if (type(row.mobs) ~= 'table') then
                row.mobs = { };
            end

            usable[#usable + 1] = row;
        end
    end

    catalog.rows = usable;
end

-- idx -> row, built once: every wire record names a row by its index and the
-- list is walked by index on every committed answer.
local byIdx = { };

for _, row in ipairs(catalog.rows) do
    byIdx[row.idx] = row;
end

-- Swallows the client's local echo of the `!dwto` lines sent below; installed
-- before any other handler in this file (dwecho.lua). Without it the player
-- reads `Blaster : !dwto zone` in their own log on every window open.
echo.install();

-- The sender name the server stamps on every machine-readable line.
local DATA_SENDER = '_DWTODATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

-- The wire's own "the server did not say" values, spelled once. `remain` -1
-- is "up, or unknown" and is NEVER a countdown; `hpp` -1 is "not up".
local NO_REMAIN = -1;
local NO_HPP    = -1;

-- `n|`'s state field.
local ST_UNKNOWN = 0;
local ST_UP      = 1;
local ST_DEAD    = 2;

--[[
* EVERY NUMBER OFF THE WIRE COMES THROUGH HERE (the dwnemesis shape). LuaJIT
* -- which is what Ashita runs -- answers `tonumber` for 'inf', 'nan', '0x10'
* and '2.5' as readily as for '7', and everything downstream is a pile of
* string.format('%d'). A field that is not a plain integer inside the wire's
* own range is not a number this window can draw, so it reads as the record's
* default and the rest of the record still lands.
--]]
local WIRE_MAX = 2147483647;

local function wireInt(text, default)
    local value = tonumber(text);

    if (value == nil
            or value ~= value                            -- nan
            or value < -WIRE_MAX or value > WIRE_MAX     -- inf, and anything absurd
            or value ~= math.floor(value)) then
        return default or 0;
    end

    return value;
end

--[[
* Persisted presentation state, through Ashita's settings library (the
* dwunleashed shape). TWO flat scalars: the pinned keys and the last search.
* Nothing the server said is ever written to disk -- a cached time of death is
* a time of death that can be wrong, and the whole point of this window is
* that it does not guess.
*
* THE PINS ARE A COMMA-JOINED STRING AND NOT A TABLE, on purpose: the settings
* serialiser takes booleans, numbers and strings, and a nested table here is a
* silent loss on save (dwscan's note, one file over). A key is a lower-snake
* word from the catalog, so a comma can never appear inside one.
*
* THE DEFAULTS ARE A SUGAR TABLE, and that `T` is load-bearing rather than
* decorative: settings.lua calls `defaults:copy(true)` (:180) and
* `settings:merge(defaults)` (:338), both sugar-table methods, so a plain
* table raises 'attempt to call a nil value'. The pcall below hides it at
* load; the library's own UNGUARDED packet_in handler re-loads on the
* zone-enter packet (:538) and Ashita answers a raise inside an event callback
* by UNLOADING THE ADDON -- so a missing `T` works at the desk and then the
* window disappears on the player's next zone line.
--]]
local defaultConfig = T{
    pins = '',
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

-- The pinned set, keyed by catalog key. Rebuilt from the string on every way
-- a config arrives (load, and the library's character-switch callback).
local pins = { };

local function readPins(cfg)
    pins = { };

    local packed = type(cfg) == 'table' and cfg.pins or '';

    if (type(packed) ~= 'string') then
        return;
    end

    for key in string.gmatch(packed, '([^,]+)') do
        -- Only a key this catalog knows: a pin left over from an older
        -- catalog would otherwise be written back out forever and count
        -- against the ask budget for a row that cannot be drawn.
        if (key ~= '') then
            pins[key] = true;
        end
    end
end

readPins(config);

local function savePins()
    local keys = { };

    for key in pairs(pins) do
        keys[#keys + 1] = key;
    end

    -- Sorted so the file does not churn on every save for no reason.
    table.sort(keys);

    config.pins = table.concat(keys, ',');

    pcall(settings.save);
end

-- The settings profile changes when the CHARACTER does, and the library hands
-- the new one over here. A watchlist is per character by design: the pins are
-- what THIS character is camping.
pcall(settings.register, 'settings', 'dwtod_settings_update', function (s)
    if (type(s) ~= 'table') then
        return;
    end

    config = s;

    readPins(config);
end);

--[[
* Outbound: `!dwto` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat.
--]]
local SEND_INTERVAL = 1.2;

-- The answer clock, per read (the dwfame shape): one retry after five
-- seconds, then the silent latch. An unknown `!` command falls through to
-- PUBLIC /say on a server without dwto.lua, and the latch is what contains
-- that to two lines rather than one every send interval, forever.
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

--[[
* HOW OFTEN AN OPEN WINDOW RE-ASKS FOR LIVE STATE, and it is a minute rather
* than a tick (dwscan's argument, T5 in DWTOD_PLAN.md). Nothing on this wire
* moves faster than a player can read it: an NM that comes up is up for as
* long as it takes somebody to kill it, and a countdown ticks on the client
* off a number the server already gave. One chat line a minute, never a burst,
* and not one while the window is shut.
--]]
local STATE_POLL = 60.0;

--[[
* THE FLOOR UNDER EVERY AUTOMATIC STATE ASK, whatever asked for it. The poll
* above is one reason to ask and the expiry re-ask below is the other, and
* each carries a latch of its own -- which is exactly how 1.0.0 shipped a
* loop: the expiry latch was cleared by every answer, so a row the server
* kept calling "due now" (`remain` 0 is a permanent answer for a mob with no
* pending respawn -- Alexander, 2026-09-22) was re-asked on every round trip,
* one `!dwto state` line every two seconds for as long as the window stayed
* open. The per-row latch is fixed where it lives; THIS is the belt and
* braces, so that no future latch bug can be worth more than one line per
* floor. A Refresh click and a zone line are the player asking and are not
* held by it -- but the floor does run from them, so the first automatic ask
* after a click waits its turn like any other.
--]]
local STATE_FLOOR = 12.0;

--[[
* THE TWO LINES THIS ADDON EVER SENDS, SPELLED OUT IN FULL.
*
* Written as whole literals rather than built with `'!dwto ' .. verb`, and the
* reason is a gate rather than taste: harness_dwsuite.py discovers every verb
* every addon sends by reading its `'!dwX <verb>'` literals and proving some
* module under modules/driftwoodxi spells that word. A concatenated verb is
* invisible to that scan -- so the addon would be exempt from the one check
* that catches an addon newer than its server sending a verb the doorway has
* never heard of, whose refusal is a PUBLIC line in chat on every window open.
--]]
local ZONE_LINE  = '!dwto zone';
local STATE_LINE = '!dwto state %s';

--[[
* HOW MANY ROWS ONE POLL COVERS, AND HOW MANY INDICES FIT ON A LINE.
*
* ASK_CHUNK is the PROTOCOL's ceiling (DWTOD_PLAN.md T6: up to forty indices
* per `state` ask). ASK_LINE_MAX is the one that actually binds, and it is the
* CLIENT's: an `!` command is a chat line, and the client keeps only the first
* 120 bytes of a line it is handed. MEASURED, not read off a struct: 1.0.0
* budgeted 120 for the INDEX LIST alone, so its first ask against the real
* catalog was 129 bytes with the `!dwto state ` in front, and the owner's
* screenshot of 2026-09-22 shows it arriving as exactly its first 120 --
* `...,152,153,149,` with the dangling comma, three rows never asked about.
* The cut costs twice: a tail cut mid-number is a question about a row
* nobody asked about, answered as though it were the whole question; and the
* client's local echo of a cut line no longer ENDS WITH the line dwecho
* recorded, so dwecho's suffix match misses and `<name> : !dwto state ...`
* is printed in the player's own log on every ask. So the budget is the
* WHOLE LINE, prefix included, four bytes under the measured cut, and a
* chunk closes at whichever ceiling comes first.
*
* ASK_MAX is how many rows one poll asks about at all: three lines at the
* sizes this catalog reaches (115, 116 and 19 bytes on the real catalog's
* first sixty rows by name -- two, before the budget counted the prefix). The
* alternative -- a cleared search box over
* five hundred catalog rows -- is a dozen chat lines a minute for rows nobody
* is looking at. When the list on screen is longer than this, the window SAYS
* so rather than quietly drawing "Unknown" down the rest of the page.
--]]
local ASK_CHUNK    = 40;
local ASK_LINE_MAX = 116;
local ASK_MAX      = 60;

-- How much text the search box holds. One number for the widget's buffer and
-- for the slice `/tod <text>` writes into it: they were two numbers to
-- disagree about.
local FIND_MAX = 47;

local state = T{
    open = T{ false },

    -- The live picture, keyed by catalog idx and MERGED rather than replaced:
    -- a `state` answer covers the rows that were asked for and a `zone` answer
    -- covers the zone, so neither is ever the whole truth and neither may
    -- throw the other's rows away.
    live = { },

    -- The server's hash, as of the last committed answer. nil until one lands.
    hash = nil,

    -- Bumped on every committed answer and on every filter change; the view
    -- cache keys on it rather than re-filtering five hundred rows a frame.
    modelRev = 0,

    pending   = nil,     -- the in-flight envelope's staging copy
    inbound   = nil,     -- the verb of the envelope currently open

    status    = '',
    statusBad = false,
    reported  = false,   -- a render error is worth saying once, not per frame

    -- The answer clock, keyed by verb: { [verb] = { at, tries } }. Keyed
    -- rather than single because the two reads are independent -- a `zone`
    -- answer arriving while a `state` is outstanding must not mark the state
    -- answered, or a lost poll is never re-asked.
    requested    = T{ },
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until a zone
    -- line re-probes it. A click does NOT lift this one -- an addon that is
    -- the wrong version stays the wrong version.
    refused = false,

    -- An envelope closed WITHOUT its header (a refusal inside it, or a reply
    -- that ended before its `h|` arrived). The third latch, and it exists for
    -- the same reason as the other two: a server whose TOD half did not load
    -- answers every ask the same way, forever. A Refresh click lifts it -- a
    -- click is the player asking -- and so does a zone line.
    answerFailed = false,

    -- The lazy zone ask has fired in THIS zone. Not "the live table is empty":
    -- a server that answers with a refusal leaves it empty forever, and
    -- re-arming on emptiness asks once per throttle window for as long as the
    -- window stays open (the dwleaderboard lesson).
    zoneAsked  = false,
    statePolled = nil,

    -- The filters. Read by the render pass, consumed by the view cache.
    find     = T{ '' },
    thisZone = T{ false },
    watched  = T{ false },

    -- The row whose detail pane is open, by idx. One at a time: two open
    -- panes in a scrolling table is a list you cannot read.
    expanded = nil,

    -- The filtered list and the zone it was filtered for, rebuilt only when
    -- something it depends on moves.
    view     = { },
    viewKey  = '',
    zoneNow  = 0,

    -- True when the list on screen is longer than one poll can cover.
    overAsk  = false,
};

--[[
* THE TOOLTIPS, in one table rather than one literal per call site, so the
* harness can assert them and so two controls that mean the same thing cannot
* drift into two sentences. The house rule: say what the control DOES, and for
* a greyed one say why it cannot right now; never repeat the label, never
* tooltip the self-evident.
--]]
local TIPS = {
    refresh      = 'Ask the server again, now. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks, and Refresh cannot fix that -- update dwtod through the launcher.',
    find         = 'Filters by monster name, zone, family or drop name.',
    thisZone     = 'Only the timer-pop monsters of the zone you are standing in.',
    watched      = 'Only the rows you have pinned. Pins are kept per character.',
    clear        = 'Empty the search box and turn both switches off.',
    row          = 'Click for the level band, the spawn spot, the family and this server\'s drop rates.',
    status       = 'What the server said when it last answered about this row. Unknown means the server has not been asked, or could not read the zone.',
    deadFor      = 'Counted up from the time of death the server recorded, aged by how long its answer has been on screen.',
    respawnIn    = 'Counted down from the seconds the server said were left. At zero this window asks once more rather than deciding for itself.',
    window       = 'How long after a death it comes back. A range is a rolled window; a single figure is a fixed timer.',
    pin          = 'Keep this row at the top of the list and ask the server about it even when it is filtered out. Kept per character.',
    unpin        = 'Stop watching this row.',
    overAsk      = 'The server answers up to this many rows per poll. Narrow the search, or pin what you are watching.',
    drops        = 'This server\'s own rates, not the wiki\'s -- the drop multiplier is already in these numbers.',
    spawn        = 'The first spawn point of the group, in the zone\'s own coordinates.',
};

--[[
* Record parsing (dwto protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST. This runs on every rendered frame for
    -- the life of the session and the queue is empty in almost all of them,
    -- while echo.canSend() is three calls across the C++ boundary
    -- (GetMemoryManager, GetPlayer, GetIsZoning). Asking it first spends a
    -- hundred and eighty of those a second to decide to do nothing.
    if (#queue == 0) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

-- Is anything outstanding? Deliberately NOT a render helper: the suite's
-- `d|`-wipe gate judges a name by whether some imgui-drawing function reads
-- it, and the ask table is bookkeeping rather than a pane.
local function asking()
    return next(state.requested) ~= nil;
end

local function latched()
    return state.refused or state.serverSilent or state.answerFailed;
end

-- `force` is the Refresh button: a click is the player asking, and the silent
-- latch exists to contain AUTOMATIC re-asks, not to ignore the player. The
-- PROTOCOL refusal is not lifted by a click.
local function permitted(force)
    if (state.refused) then
        return false;
    end

    if (state.serverSilent) then
        if (not force) then
            return false;
        end

        state.serverSilent = false;
    end

    if (state.answerFailed) then
        if (not force) then
            return false;
        end

        state.answerFailed = false;
    end

    -- A CLICK REPLACES THE OLD ANSWER. Lifting a latch without clearing the
    -- sentence that set it leaves the last refusal red in the header while the
    -- window is actively asking again. Only a REFUSAL is dropped; a note is
    -- still true.
    if (force and state.statusBad) then
        state.status    = '';
        state.statusBad = false;
    end

    return true;
end

local function askZone(force)
    if (not permitted(force)) then
        return;
    end

    state.requested['zone'] = { at = os.clock(), tries = 1 };

    issue(ZONE_LINE);
end

--[[
* THE STATE ASK, as whole chat lines. Built rather than remembered, because
* the queue's duplicate collapse matches on the whole string and two polls
* that ask about the same rows SHOULD collapse into one.
--]]
local function stateLines(indices)
    local lines = { };
    local chunk = { };

    -- The whole line is measured, so the prefix is the width of an empty
    -- ask: `!dwto state ` and nothing after it.
    local prefix = #string.format(STATE_LINE, '');
    local width  = prefix;

    local function flush()
        if (#chunk == 0) then
            return;
        end

        lines[#lines + 1] = string.format(STATE_LINE, table.concat(chunk, ','));
        chunk = { };
        width = prefix;
    end

    for _, idx in ipairs(indices) do
        local text = tostring(idx);

        -- The piece, plus the comma in front of it when it is not the first.
        -- Both ceilings are tested before the piece goes in, never after: a
        -- line that is already too long has already been sent.
        local cost = #text + ((#chunk > 0) and 1 or 0);

        if (#chunk > 0 and (#chunk >= ASK_CHUNK or (width + cost) > ASK_LINE_MAX)) then
            flush();

            cost = #text;
        end

        chunk[#chunk + 1] = text;
        width = width + cost;
    end

    flush();

    return lines;
end

-- The last state ask's own indices, kept so a retry re-sends the same
-- question rather than whatever happens to be on screen a heartbeat later.
local lastAsked = { };

local function askState(indices, force)
    if (#indices == 0) then
        return;
    end

    if (not permitted(force)) then
        return;
    end

    state.requested['state'] = { at = os.clock(), tries = 1 };
    state.statePolled        = os.clock();
    lastAsked                = indices;

    for _, line in ipairs(stateLines(indices)) do
        issue(line);
    end
end

local function reissueState()
    for _, line in ipairs(stateLines(lastAsked)) do
        issue(line);
    end
end

local function checkAnswers()
    for verb, asked in pairs(state.requested) do
        -- THE CLOCK DOES NOT AGE WHILE THE CLIENT IS ZONING -- it is
        -- RE-STAMPED, not merely skipped. A line still sitting in the queue
        -- behind echo.canSend() had already burned its timeout by the time it
        -- went out, so the retry fired 1.2 s behind the first send: both
        -- inside the client's chat settle window, both dropped, and the latch
        -- set with the server never asked.
        if (not echo.canSend()) then
            asked.at = os.clock();
        elseif ((os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries >= ANSWER_TRIES) then
                -- NO SENTENCE IS WRITTEN HERE: the header draws the silent
                -- latch in preference to state.status, so a line set here is
                -- never read and outlives the latch that hid it.
                state.requested[verb] = nil;
                state.serverSilent    = true;
            else
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                if (verb == 'zone') then
                    issue(ZONE_LINE);
                else
                    reissueState();
                end
            end
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], -1);

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            --[[
            * THE REFUSAL RETIRES THE ASKS. A mismatched `d|` IS an answer --
            * the server spoke, in a dialect this addon does not read -- and
            * leaving the clock running against it costs twice: five seconds
            * later the retry goes out against the protocol document's own
            * promise to stop asking, and five after that the silent latch
            * paints "No answer from the server" over the accurate "Update
            * dwtod" banner, which points the player at the server when the
            * addon is the problem.
            * The staging copy goes too: it belongs to an envelope that can no
            * longer be trusted to mean what this addon thinks it means.
            --]]
            state.requested    = T{ };
            state.pending      = nil;
            state.serverSilent = false;
            state.answerFailed = false;

            print(chat.header('dwtod'):append(chat.error(string.format(
                'Server protocol %d, addon expects %d. Update dwtod through the launcher.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope proves the server is there (the silent
        -- latch lifts), but only the envelope for a given verb answers that
        -- verb's ask.
        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.inbound == 'zone' or state.inbound == 'state') then
            state.requested[state.inbound] = nil;
            state.pending = { verb = state.inbound, hash = nil, epoch = 0, count = 0, rows = { } };

            -- A NEW ANSWER CLEARS THE OLD BANNER. Whatever the server wants to
            -- say about THIS answer rides inside this envelope as m| or e|,
            -- after this line.
            state.status    = '';
            state.statusBad = false;
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        if (kind == 'e') then
            --[[
            * A REFUSAL INSIDE AN OPEN ENVELOPE KILLS THAT ANSWER. This is not
            * a rare shape: a machine doorway emits exactly `d|1|zone`,
            * `e|Time of death is not loaded on this build.`, `z|zone` when the
            * core did not load, and the shared writer wraps ANY bare fail in
            * the same three lines. Committing that staging copy at z| would
            * publish an answer with no rows in it, which reads everywhere in
            * this file as "the server says nothing here is on a timer".
            --]]
            state.pending = nil;
        end

        -- A NOTE WITH NO SENTENCE IN IT SAYS NOTHING. `out:fail(nil)` writes a
        -- bare `e|`, and blanking the header with it is worse than ignoring
        -- it. The bookkeeping above still ran: a refusal with nothing to say
        -- is still a refusal.
        if (text == '') then
            return;
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwtod'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    local pending = state.pending;

    -- h| -- the catalog hash the SERVER holds, its own clock, and how many
    -- n| rows are on their way.
    if (kind == 'h' and pending ~= nil) then
        pending.hash  = parts[2] or '';
        pending.epoch = wireInt(parts[3]);
        pending.count = wireInt(parts[4]);

        return;
    end

    -- n| -- one row's live state. `claim` is the LAST field, so a name with a
    -- pipe in it cannot exist and a missing one reads as '-'.
    if (kind == 'n' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx > 0) then
            pending.rows[idx] = {
                st     = wireInt(parts[3]),
                tod    = wireInt(parts[4]),
                remain = wireInt(parts[5], NO_REMAIN),
                hpp    = wireInt(parts[6], NO_HPP),
                claim  = parts[7] or '-',
            };
        end

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        if (closed ~= 'zone' and closed ~= 'state') then
            return;
        end

        --[[
        * ONLY AN ANSWER WITH ITS HEADER COMMITS. `pending` is nil when a
        * refusal killed the envelope; it is present but hollow when the reply
        * ended before its `h|` arrived -- the client's chat rate limit drops
        * lines, which is the whole reason this addon carries an answer clock.
        * A HOLLOW ANSWER IS WORSE THAN NONE: without the hash there is nothing
        * for the mismatch banner to catch, and without the epoch every "dead
        * for" on screen would be counted from zero -- which draws as a monster
        * that died in 1970.
        *
        * AN ANSWER WITH A HEADER AND NO ROWS DOES COMMIT: a `zone` ask in a
        * zone with no timer pops in it is a real answer, and the list says so
        * in its own words.
        --]]
        local complete = pending ~= nil and pending.hash ~= nil;

        state.pending = nil;

        if (not complete) then
            state.answerFailed = true;

            return;
        end

        local at = os.clock();

        state.hash = pending.hash;

        -- MERGED, NEVER REPLACED (see state.live). Each row remembers the
        -- epoch of the answer it came in and the client clock at the moment it
        -- landed: those two together are the whole of the tick.
        --
        -- THE EXPIRY LATCH SURVIVES AN ANSWER THAT SAYS NOTHING NEW. 1.0.0
        -- cleared it on every answer, and a row the server keeps calling "due
        -- now" -- remain 0, which is a PERMANENT answer for a mob with no
        -- pending respawn, or one in a zone whose clock is not running -- was
        -- then re-asked on every round trip, forever. The latch is lifted only
        -- by news: a fresh countdown (remain above zero), a change of state,
        -- or a different time of death. Anything else is the same "due now"
        -- the window already asked about once, and the sixty-second poll is
        -- how it hears the monster stand up.
        for idx, row in pairs(pending.rows) do
            local before = state.live[idx];

            state.live[idx] = {
                st      = row.st,
                tod     = row.tod,
                remain  = row.remain,
                hpp     = row.hpp,
                claim   = row.claim,
                epoch   = pending.epoch,
                at      = at,
                reasked = before ~= nil and before.reasked == true
                    and before.st == row.st and before.tod == row.tod
                    and row.remain <= 0,
            };
        end

        state.answerFailed = false;
        state.modelRev     = state.modelRev + 1;

        return;
    end
end

ashita.events.register('packet_in', 'dwtod_packet_in', function (e)
    if (e.id == 0x0017) then
        local data = e.data_modified or e.data;

        if (data == nil) then
            return;
        end

        local sender = data:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = data:sub(0x18, e.size):gsub('%z.*$', '');

        -- BLOCKED BEFORE IT IS PARSED (the dwbags rule). A record that throws
        -- inside handleRecord must still not reach the chat log: the player's
        -- window would fill with `n|12|2|1758...` for as long as the bug lived,
        -- and a parse error is exactly when that is most likely.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwtod'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    --[[
    * A zone line re-probes every latch and RE-ARMS the lazy ask rather than
    * sending one. That is what keeps this addon out of dwecho's ZONE_ORDER
    * entirely: a closed window adds nothing to the login burst.
    *
    * The live picture is NOT thrown away. A time of death is a fact about a
    * monster and not about where the player is standing -- the countdown a
    * player was watching in Jeuno is the same countdown after they zone into
    * the field, and the next poll refreshes it anyway. What does go is any
    * half-arrived envelope, or its stray tail would be accepted into a stale
    * staging copy on the far side.
    --]]
    if (e.id == 0x000A) then
        state.requested    = T{ };
        state.serverSilent = false;
        state.refused      = false;
        state.answerFailed = false;
        state.inbound      = nil;
        state.pending      = nil;
        state.zoneAsked    = false;
        state.statePolled  = nil;

        -- A RED REFUSAL DOES NOT OUTLIVE THE PLACE IT WAS ABOUT. A note is
        -- still true after a zone and stays.
        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end

        -- The "This zone" filter is about a zone the player has just left.
        state.modelRev = state.modelRev + 1;
    end
end);

--[[
* Rendering.
*
* MEASURED LAYOUT, NOT GUESSED (dwcraft's rule, reached here through
* dwnemesis's copy of it). Both helpers read the LIVE font each frame and fall
* back to a conservative constant when a binding does not answer; the asymmetry
* is deliberate, because a fallback that is too big spends a few pixels of list
* and one that is too small hides a control the player needs to click.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

-- What a scrolling table must leave below itself: a table carrying ScrollY
-- owns a child window, and a child window given a ZERO outer height takes the
-- whole remaining content region -- so anything drawn after it lands below the
-- window's bottom edge. A NEGATIVE outer height reads as "available minus
-- this" (the dwnemesis footerReserve shape).
local function footerReserve()
    return -(metric('GetFrameHeightWithSpacing', 26) + 12);
end

-- One short tip on the item just drawn. Every plain tooltip in this file goes
-- through here so the pattern cannot drift call site by call site.
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* "2h 05m 31s", "5m 02s", "41s". Never negative: a clock that has passed is a
* clock that has passed, and "-3s" is the window arguing with the server.
--]]
local function duration(seconds)
    if (seconds == nil or seconds < 0) then
        seconds = 0;
    end

    seconds = math.floor(seconds);

    local hours   = math.floor(seconds / 3600);
    local minutes = math.floor((seconds % 3600) / 60);

    if (hours > 0) then
        return string.format('%dh %02dm %02ds', hours, minutes, seconds % 60);
    end

    if (minutes > 0) then
        return string.format('%dm %02ds', minutes, seconds % 60);
    end

    return string.format('%ds', seconds);
end

-- A respawn window's own length, in the coarsest unit that is still exact:
-- "1h", "21h", "2.5h", "15m".
local function span(seconds)
    if (seconds == nil or seconds <= 0) then
        return '?';
    end

    if (seconds % 3600 == 0) then
        return string.format('%dh', math.floor(seconds / 3600));
    end

    if (seconds >= 3600) then
        return string.format('%.1fh', seconds / 3600);
    end

    if (seconds % 60 == 0) then
        return string.format('%dm', math.floor(seconds / 60));
    end

    return string.format('%ds', seconds);
end

--[[
* The Window column. "1h" for a fixed timer; "21-24h" for a rolled one -- the
* unit is dropped off the low end when both ends carry the same one, because
* "21h-24h" is two units for one fact and this column is four characters wide
* on a narrow window.
--]]
local function windowText(row)
    if (row.winLo > 0 and row.winHi > 0) then
        local lo = span(row.winLo);
        local hi = span(row.winHi);
        local unit = string.match(hi, '%a+$');

        if (unit ~= nil and #lo > #unit and lo:sub(-#unit) == unit) then
            lo = lo:sub(1, #lo - #unit);
        end

        return lo .. '-' .. hi;
    end

    return span(row.base);
end

-- The longest a row can plausibly be dead before its own tod stops meaning
-- anything (T8): a tod older than this is not drawn as "dead for", because the
-- row is either up -- in which case the tod is stale by definition -- or its
-- countdown is what matters.
local function staleAfter(row)
    local longest = row.winHi > 0 and row.winHi or row.base;

    -- Four times the window, floored at a day: a server restart re-rolls the
    -- short clocks, and a tod that survived one is still worth showing.
    return math.max(86400, longest * 4);
end

-- Seconds this answer has been on screen. THE CLIENT'S CLOCK IS ONLY EVER
-- USED FOR THIS DELTA.
local function aged(live)
    if (live == nil or live.at == nil) then
        return 0;
    end

    return math.max(0, math.floor(os.clock() - live.at));
end

local function deadFor(row, live)
    if (live == nil or live.st ~= ST_DEAD or live.tod <= 0 or live.epoch <= 0) then
        return nil;
    end

    local seconds = (live.epoch - live.tod) + aged(live);

    if (seconds < 0 or seconds > staleAfter(row)) then
        return nil;
    end

    return seconds;
end

local function respawnIn(live)
    if (live == nil or live.st ~= ST_DEAD or live.remain == nil or live.remain < 0) then
        return nil;
    end

    return live.remain - aged(live);
end

--[[
* The search haystack, lowercased once per row and kept for the life of the
* session: the catalog does not change while the game is running, and a filter
* that rebuilt four strings per row per keystroke over five hundred rows is
* the dwnemesis 1.3.0 bug with a bigger list behind it.
--]]
local haystacks = { };

local function haystackFor(row)
    local text = haystacks[row.idx];

    if (text == nil) then
        local drops = { };

        for _, drop in ipairs(row.drops) do
            if (type(drop) == 'table' and type(drop.name) == 'string') then
                drops[#drops + 1] = drop.name;
            end
        end

        text = string.lower(string.format('%s %s %s %s',
            row.name, row.zoneName, row.family, table.concat(drops, ' ')));

        haystacks[row.idx] = text;
    end

    return text;
end

-- The zone the player is standing in, for the "This zone" switch. pcall'd
-- because this is asked from d3d_present, OUTSIDE the render pcall: a manager
-- that does not answer AT ALL is otherwise a Lua error sixty times a second
-- with no window on screen to explain it (the dwscan note).
local function readZone()
    local memory = AshitaCore:GetMemoryManager();

    if (memory == nil) then
        return 0;
    end

    local party = memory:GetParty();

    if (party == nil) then
        return 0;
    end

    return party:GetMemberZone(0) or 0;
end

local function currentZone()
    local ok, id = pcall(readZone);

    if (ok and type(id) == 'number' and id > 0) then
        return id;
    end

    return 0;
end

--[[
* THE ROWS ON SCREEN, FILTERED ONCE PER CHANGE (the dwwarehouse view-cache
* shape). The key carries everything the filter reads, so typing in the search
* box still narrows on the keystroke; it just stops re-walking five hundred
* rows in between them. Pinned rows sort to the top -- the watchlist is what
* the window is for -- then by name, so the order never moves under a click.
--]]
local function refreshView()
    state.zoneNow = currentZone();

    local needle = string.lower(state.find[1] or '');
    local key    = string.format('%d|%s|%s|%s|%d|%d',
        state.modelRev, needle, tostring(state.thisZone[1] == true),
        tostring(state.watched[1] == true), state.zoneNow, #catalog.rows);

    if (key == state.viewKey) then
        return;
    end

    state.viewKey = key;

    local rows = { };

    for _, row in ipairs(catalog.rows) do
        local wanted = true;

        if (state.watched[1] == true and not pins[row.key]) then
            wanted = false;
        end

        if (wanted and state.thisZone[1] == true and row.zone ~= state.zoneNow) then
            wanted = false;
        end

        if (wanted and needle ~= '' and string.find(haystackFor(row), needle, 1, true) == nil) then
            wanted = false;
        end

        if (wanted) then
            rows[#rows + 1] = row;
        end
    end

    table.sort(rows, function (a, b)
        local pa = pins[a.key] and 1 or 0;
        local pb = pins[b.key] and 1 or 0;

        if (pa ~= pb) then
            return pa > pb;
        end

        if (a.name ~= b.name) then
            return a.name < b.name;
        end

        return a.idx < b.idx;
    end);

    state.view    = rows;
    state.overAsk = false;
end

--[[
* THE INDICES ONE POLL ASKS ABOUT: the pinned rows first -- they are asked
* about whether or not they are on screen, which is the whole point of a pin --
* then the rows on screen, deduplicated, capped at ASK_MAX. The cap is
* REPORTED (state.overAsk) rather than swallowed: a list that silently draws
* "Unknown" down the page is the window pretending it asked.
--]]
local function askSet()
    local seen    = { };
    local indices = { };

    local function take(row)
        if (row == nil or seen[row.idx] or #indices >= ASK_MAX) then
            return;
        end

        seen[row.idx]      = true;
        indices[#indices + 1] = row.idx;
    end

    for _, row in ipairs(catalog.rows) do
        if (pins[row.key]) then
            take(row);
        end
    end

    for _, row in ipairs(state.view) do
        take(row);
    end

    state.overAsk = #indices >= ASK_MAX;

    return indices;
end

--[[
* A COUNTDOWN THAT REACHES ZERO ASKS ONCE, AND THE WINDOW DECIDES NOTHING.
* `remain` running out does not mean the monster is up: it means the server's
* own clock said it would be due about now, and the only way to learn whether
* it actually stood up is to ask. Latched per row (`reasked`), and the latch
* is lifted ONLY by an answer that changes something about the row (see the
* commit in handleRecord) -- so a server that keeps saying "due now" is asked
* once, not once a frame and not once a round trip. The sixty-second poll
* still covers the row, which is how the window hears it stand up.
--]]
local function expiredRows(indices)
    local out = { };

    for _, idx in ipairs(indices) do
        local live = state.live[idx];

        if (live ~= nil and not live.reasked and live.st == ST_DEAD
                and live.remain >= 0 and (live.remain - aged(live)) <= 0) then
            out[#out + 1] = live;
        end
    end

    return out;
end

-- Seconds since the last state ask, automatic or clicked. math.huge when
-- there has not been one in this zone, and when the clock reads EARLIER than
-- the stamp: os.clock() wraps after ~24.8 days of client uptime (dwecho's
-- elapsed()), and a stamp in the future would otherwise hold every ask shut.
local function sincePoll()
    if (state.statePolled == nil) then
        return math.huge;
    end

    local since = os.clock() - state.statePolled;

    if (since < 0) then
        return math.huge;
    end

    return since;
end

local function pumpAsks()
    if (latched()) then
        return;
    end

    -- The zone ask, once per zone, the first frame the window is shown in it.
    if (not state.zoneAsked and not asking()) then
        state.zoneAsked = true;

        askZone();

        return;
    end

    if (state.requested['state'] ~= nil) then
        return;
    end

    local indices = askSet();

    if (#indices == 0) then
        return;
    end

    -- THE FLOOR (STATE_FLOOR): no automatic ask of either kind inside it. It
    -- is tested BEFORE the expiry latches are set, so a row that runs out
    -- while the floor is holding is asked about when it lifts rather than
    -- latched and forgotten.
    local since = sincePoll();

    if (since < STATE_FLOOR) then
        return;
    end

    local expired = expiredRows(indices);

    if (#expired > 0) then
        -- The re-ask is the ordinary poll, brought forward. ONLY THE ROWS
        -- THAT ACTUALLY RAN OUT ARE LATCHED: latching the whole ask set would
        -- spend one row's expiry on every other row's, and the next countdown
        -- to reach zero would never ask at all.
        for _, live in ipairs(expired) do
            live.reasked = true;
        end

        askState(indices);

        return;
    end

    if (since >= STATE_POLL) then
        askState(indices);
    end
end

local function hashMismatch()
    return state.hash ~= nil and state.hash ~= '' and catalog.hash ~= ''
        and state.hash ~= catalog.hash;
end

local function refreshTip()
    if (state.refused) then
        return TIPS.refreshStale;
    end

    if (state.statePolled == nil) then
        return TIPS.refresh;
    end

    return string.format('%s\nThe rows on screen were last asked about %d second(s) ago.',
        TIPS.refresh, math.max(0, math.floor(os.clock() - state.statePolled)));
end

local function renderHeader()
    if (imgui.Button('Refresh##dwtod_refresh')) then
        -- A click is the player asking: it lifts both liftable latches, clears
        -- a stale refusal, and re-asks the zone AND the rows on screen.
        askZone(true);

        askState(askSet(), true);
    end

    -- Built only when it is going to be read: refreshTip formats a sentence
    -- and reads the clock, and tip() would evaluate it every frame.
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(refreshTip());
    end

    imgui.SameLine();

    -- REFUSED OUTRANKS SILENT. A protocol mismatch is the one state here with
    -- an action attached to it, and the mismatch branch retires the answer
    -- clock precisely so the silent latch cannot paint over the sentence that
    -- is true.
    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwtod through the launcher.');
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server. Refresh to ask again.');
    elseif (state.answerFailed) then
        imgui.TextColored(theme.colors.err, 'The server answered without a header. Refresh to ask again.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or asking()) then
        imgui.TextDisabled('asking...');
    else
        imgui.TextDisabled('The server is standing next to every one of them.');
    end

    -- THE HASH BANNER IS PERSISTENT AND THE WINDOW KEEPS DRAWING. A catalog
    -- that is not the server's still names most of the same monsters; what it
    -- cannot promise is that row 214 here is row 214 there. So the rows stay
    -- on screen and the sentence stays above them, rather than the window
    -- blanking itself over a mismatch the player can fix in a minute.
    if (hashMismatch()) then
        imgui.TextColored(theme.colors.warn,
            'This addon\'s catalog differs from the server\'s -- update dwtod through the launcher.');
    end

    imgui.Separator();
end

local function renderFilters()
    imgui.PushItemWidth(240);
    imgui.InputTextWithHint('##dwtod_find', 'search name, zone, family or drop...', state.find, FIND_MAX + 1);
    imgui.PopItemWidth();
    tip(TIPS.find);

    imgui.SameLine();
    imgui.Checkbox('This zone##dwtod_thiszone', state.thisZone);
    tip(TIPS.thisZone);

    imgui.SameLine();
    imgui.Checkbox('Watched##dwtod_watched', state.watched);
    tip(TIPS.watched);

    if ((state.find[1] or '') ~= '' or state.thisZone[1] or state.watched[1]) then
        imgui.SameLine();

        if (imgui.SmallButton('Clear##dwtod_clear')) then
            state.find[1]     = '';
            state.thisZone[1] = false;
            state.watched[1]  = false;
        end

        tip(TIPS.clear);
    end

    if (state.overAsk) then
        imgui.TextDisabled(string.format(
            'Live state is asked for %d rows at a time -- narrow the search, or pin what you are watching.',
            ASK_MAX));
        tip(TIPS.overAsk);
    end
end

-- One ImGui id per row, built once rather than concatenated per visible row
-- per frame.
local rowLabels = { };
local pinLabels = { };

local function rowLabel(row)
    local label = rowLabels[row.idx];

    if (label == nil) then
        label = string.format('%s##dwtod_row_%d', row.name, row.idx);

        rowLabels[row.idx] = label;
    end

    return label;
end

local function pinLabel(row, pinned)
    local slot = pinLabels[row.idx];

    if (slot == nil) then
        slot = {
            on  = string.format('Unpin##dwtod_pin_%d', row.idx),
            off = string.format('Pin##dwtod_pin_%d', row.idx),
        };

        pinLabels[row.idx] = slot;
    end

    return pinned and slot.on or slot.off;
end

local function togglePin(row)
    if (pins[row.key]) then
        pins[row.key] = nil;
    else
        pins[row.key] = true;
    end

    savePins();

    -- The pinned rows sort to the top, so the list itself has moved.
    state.modelRev = state.modelRev + 1;
end

--[[
* WHY THE LIST IS EMPTY, and it is four different sentences because it is four
* different facts. "Nothing matches the search" is wrong in three of them: a
* catalog that did not load has no rows to match at all, an empty watchlist is
* an invitation rather than a miss, and a zone with no timer pops in it is an
* ANSWER.
--]]
local function emptyReason()
    if (#catalog.rows == 0) then
        return 'This addon\'s catalog file did not load. Reinstall dwtod through the launcher.';
    end

    local finding = (state.find[1] or '') ~= '';

    if (state.watched[1] and not finding and not state.thisZone[1]) then
        return 'Nothing pinned yet. Open a row and press Pin.';
    end

    if (state.thisZone[1] and not finding and not state.watched[1]) then
        return 'Nothing in this zone is on a respawn timer.';
    end

    return 'Nothing matches the search.';
end

local function statusCell(live)
    if (live == nil or live.st == ST_UNKNOWN) then
        imgui.TextColored(theme.colors.dim, 'Unknown');
        tip(TIPS.status);

        return;
    end

    if (live.st == ST_DEAD) then
        imgui.TextColored(theme.colors.warn, 'Dead');
        tip(TIPS.status);

        return;
    end

    local text = 'Up';

    if (live.hpp >= 0) then
        text = string.format('Up %d%%', live.hpp);
    end

    if (live.claim ~= nil and live.claim ~= '' and live.claim ~= '-') then
        text = string.format('%s -- claimed by %s', text, live.claim);
    end

    imgui.TextColored(theme.colors.ok, text);
    tip(TIPS.status);
end

--[[
* The detail pane: everything the catalog knows about one row, drawn under it
* rather than in a second window. Every figure here is GENERATED from the
* server's own dumps -- the drop percentages are this server's, multiplier
* already applied (dwscan's rule, and its numbers are not the wiki's either).
--]]
local function renderDetail(row)
    imgui.Text(string.format('Level %d-%d   %s   %s, %s',
        row.lvlLo, row.lvlHi,
        row.family ~= '' and row.family or 'family unknown',
        row.aggro ~= 0 and 'aggressive' or 'passive',
        row.links ~= 0 and 'links' or 'does not link'));

    imgui.Text(string.format('Spawns at %.1f, %.1f, %.1f', row.x, row.y, row.z));
    tip(TIPS.spawn);

    if (row.winLo > 0 and row.winHi > 0) then
        imgui.Text(string.format('Timer pop: it comes back between %s and %s after it dies.',
            span(row.winLo), span(row.winHi)));
    else
        imgui.Text(string.format('Timer pop: it comes back %s after it dies.', span(row.base)));
    end

    if (#row.drops == 0) then
        imgui.TextDisabled('It drops nothing on this server.');

        return;
    end

    local shown = { };

    for index, drop in ipairs(row.drops) do
        if (index > 4) then
            break;
        end

        if (type(drop) == 'table' and type(drop.name) == 'string') then
            shown[#shown + 1] = string.format('%s %.1f%%', drop.name, tonumber(drop.pct) or 0);
        end
    end

    imgui.Text('Drops: ' .. table.concat(shown, '   '));
    tip(TIPS.drops);
end

local function renderRows()
    local rows = state.view;
    local pad  = textWidth('nn', 14);

    if (imgui.BeginTable('dwtod_rows', 8,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('Zone', ImGuiTableColumnFlags_WidthStretch, 2.6);
        imgui.TableSetupColumn('Lv', ImGuiTableColumnFlags_WidthFixed, textWidth('99-99', 44) + pad);
        imgui.TableSetupColumn('Status', ImGuiTableColumnFlags_WidthStretch, 2.4);
        imgui.TableSetupColumn('Dead for', ImGuiTableColumnFlags_WidthFixed, textWidth('99h 59m 59s', 92) + pad);
        imgui.TableSetupColumn('Respawn in', ImGuiTableColumnFlags_WidthFixed, textWidth('99h 59m 59s', 92) + pad);
        imgui.TableSetupColumn('Window', ImGuiTableColumnFlags_WidthFixed, textWidth('21-24h', 58) + pad);
        imgui.TableSetupColumn('Pin', ImGuiTableColumnFlags_WidthFixed, textWidth('Unpin', 48) + pad);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            local live   = state.live[row.idx];
            local pinned = pins[row.key] == true;

            imgui.TableNextRow();

            imgui.TableNextColumn();

            if (imgui.Selectable(rowLabel(row), state.expanded == row.idx)) then
                state.expanded = (state.expanded == row.idx) and nil or row.idx;
            end

            tip(TIPS.row);

            imgui.TableNextColumn();
            imgui.Text(row.zoneName ~= '' and row.zoneName or string.format('zone %d', row.zone));

            imgui.TableNextColumn();
            imgui.Text(string.format('%d-%d', row.lvlLo, row.lvlHi));

            imgui.TableNextColumn();
            statusCell(live);

            imgui.TableNextColumn();

            local dead = deadFor(row, live);

            if (dead ~= nil) then
                imgui.Text(duration(dead));
                tip(TIPS.deadFor);
            else
                imgui.TextDisabled('--');
            end

            imgui.TableNextColumn();

            local left = respawnIn(live);

            if (left == nil) then
                imgui.TextDisabled('--');
            elseif (left <= 0) then
                -- NOT "up": the window does not decide that. The re-ask is
                -- already on its way (see expiredRow).
                imgui.TextColored(theme.colors.warn, 'due now');
                tip(TIPS.respawnIn);
            else
                imgui.Text(duration(left));
                tip(TIPS.respawnIn);
            end

            imgui.TableNextColumn();
            imgui.Text(windowText(row));
            tip(TIPS.window);

            imgui.TableNextColumn();

            if (imgui.SmallButton(pinLabel(row, pinned))) then
                togglePin(row);
            end

            tip(pinned and TIPS.unpin or TIPS.pin);

            -- The detail pane, under the row it belongs to (the dwunleashed
            -- callouts shape): a second row that spans from the Zone column
            -- so the Name column still reads as a list.
            if (state.expanded == row.idx) then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.TableNextColumn();
                renderDetail(row);
            end
        end

        if (#rows == 0) then
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextDisabled(emptyReason());
        end

        imgui.EndTable();
    end
end

local function renderWindow()
    renderHeader();

    if (#catalog.rows == 0) then
        -- ONE LINE, AND THE WINDOW STILL OPENS. A catalog that did not load is
        -- not a reason to throw: the player needs to be told what happened and
        -- what to do, and everything this window shows also works typed.
        imgui.TextColored(theme.colors.err,
            'This addon\'s catalog file did not load. Reinstall dwtod through the launcher.');

        return;
    end

    renderFilters();
    renderRows();

    -- THE FOOTER, and it is the honest half of what this window is. The
    -- catalog holds timer pops only, because they are the only ones with a
    -- clock to draw (DWTOD_PLAN.md T1).
    imgui.TextDisabled('Lottery and forced pops have no clock and are not listed.');
end

ashita.events.register('d3d_present', 'dwtod_present', function ()
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    -- THE VIEW IS REBUILT BEFORE THE ASKS AND NOT INSIDE THE DRAW, because the
    -- ask set is built from it: the rows on screen are exactly the rows worth
    -- asking about. It is one frame behind the search box, which is what the
    -- widget can promise -- the buffer is written during the draw.
    refreshView();
    pumpAsks();

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 880, 520 }, ImGuiCond_FirstUseEver);

    --[[
    * A MINIMUM SIZE. Nothing in ImGui stops a window being dragged to nothing,
    * and this one carries a filter row, an eight-column table and a footer.
    *
    * 700 IS MEASURED, NOT ROUND, and it is measured off the columns: the five
    * FIXED ones are "99-99", "99h 59m 59s" twice, "21-24h" and the Unpin
    * button -- thirty-eight characters and five cell paddings, about three
    * hundred and thirty pixels at the stock font -- and the three stretch
    * columns need a name, a zone name and "Up 100% -- claimed by Someone"
    * beside them. The filter row behind it is a 240-pixel input, two
    * checkboxes and Clear. A player whose saved size is under this is clamped
    * up to it once.
    --]]
    imgui.SetNextWindowSizeConstraints({ 700, 320 }, { 99999, 99999 });

    local visible = imgui.Begin('DriftwoodXI Time of Death##dwtod', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwtod'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwtod'):append(chat.message('Window closed. Everything it shows also works typed as !tod.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwtod_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    -- THE THROTTLE IS STAMPED BY WHAT THE PLAYER SENDS, NOT ONLY BY US. The
    -- limit it exists to respect is the CLIENT's, on chat, and that counts the
    -- player's own typing -- so an addon that stamps only from its own pump
    -- believes the channel is idle when it is not and fires into the same beat
    -- as a line the player typed. The client then drops one of them.
    if (message:sub(1, 5):lower() ~= '!dwto') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwtod_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, and a player
    -- who capitalises is not making a mistake.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/tod' and first ~= '/dwtod') then
        return;
    end

    e.blocked = true;

    --[[
    * `/tod lizzy` OPENS THE WINDOW ON THAT SEARCH rather than toggling it (the
    * dwnemesis 1.3.0 shape). Five hundred monsters is a list you arrive at
    * through the search box, so a player who types a name has already said
    * what they want -- and toggling the window SHUT on them because it
    * happened to be open is the wrong answer to the only thing they said. The
    * switches come off with it: a player who named a monster wants to see THAT
    * monster, and leaving a filter on that can hide it is the same trap as
    * leaving the search box full.
    --]]
    if (#args > 1) then
        local words = { };

        for index = 2, #args do
            words[#words + 1] = args[index];
        end

        local text = (table.concat(words, ' '):gsub('[^\032-\126]', ''));

        state.find[1]     = text:sub(1, FIND_MAX);
        state.thisZone[1] = false;
        state.watched[1]  = false;
        state.open[1]     = true;
        state.reported    = false;

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwtod_load', function ()
    print(chat.header('dwtod'):append(chat.message('/tod opens the Time of Death window, /tod <name> opens it on that search. Everything it shows also works typed as !tod.')));
end);
