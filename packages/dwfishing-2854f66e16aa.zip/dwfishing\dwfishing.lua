--[[
* DriftwoodXI -- dwfishing
*
* The whole fishing system in one window: a costed route from 0 to the ceiling,
* every fish this server can give you, the skill it wants, the bait that can
* actually hook it, the rod that will not lose it, every pool it swims in, and
* -- the part no wiki has -- what to catch NEXT, at this box's real rates.
*
* THE ROUTE TAB IS THE ONE THAT ANSWERS THE FIRST QUESTION. Everything else here
* answers something you already knew to ask; the route answers "I have never
* fished, what do I do" as an itinerary -- buy this rod and this bait, stand
* here, and when the number reaches N, move. It is solved in the generator
* against the shop prices, the sale prices, the pool weights and the three rolls
* between hooking a fish and keeping it, it minimises gil and breaks ties on
* casts, and it may never buy what it has not already caught -- so it opens with
* the cheapest rod in the game rather than with the one a rich player would use.
*
* THE NUMBERS HERE ARE NOT THE WIKI'S, AND THAT IS THE POINT. Fishing on
* DriftwoodXI is enabled (stock LandSandBoat ships it OFF) and multiplies
* skill-up chance by five. Both of those live in a gitignored per-box
* settings/map.lua that no wiki, no import and no invariant can see. The
* multiplier arrives on the wire and every percentage below is already scaled
* by it.
*
* EVERYTHING ELSE IS DERIVED, NOT AUTHORED. data/fishdata.lua is generated from
* the same sql/fishing_*.sql dumps the server imports AND from the fishing
* engine's own C++ tuning constants, parsed at generation time
* (tools/dwfishing/gen_fishdata.py). Nobody typed a fish's skill level or a
* bait's affinity into this addon, so nothing here can quietly disagree with
* the server -- and if the dumps move and nobody regenerates, a deploy gate
* refuses rather than shipping a guide that has started lying.
*
* THE FIVE RULES THE WHOLE GUIDE TURNS ON, all read off fishingutils.cpp (it
* said THREE and listed five: the fourth and fifth were added with the
* denominator work and the count was not):
*   1. Bait affinity is a HARD gate. GetFishPool intersects the pool with the
*      equipped bait's fishing_bait_affinity rows; no row means that bait can
*      NEVER hook that fish, at any skill, in any weather.
*   2. Being under-skilled is a penalty, not a wall -- a fish up to 100 levels
*      above you still enters the pool. Landing it is the hard part.
*   3. Skill-ups come only from fish ABOVE your level and within 50 of it, and
*      the curve peaks at +11. Items and monsters teach nothing at all.
*   4. That curve is a NUMERATOR, not a percentage: it is rolled against 90,
*      less 10 outside a city and less another (20 - level/3) under 50. On this
*      box the multiplier pushes it past that roll across most of the window, so
*      the skill-up becomes certain and the +11 peak stops being worth chasing.
*   5. Hooking is not catching. Lose, line snap and rod break are rolled before
*      anything reaches the skill-up at all, and reaching more than 7 levels
*      above you is where losing starts.
*
* IT ASKS ONLY WHEN YOU ASK. One handshake on open, one on a zone line, and
* one on the Refresh button. There is no tick and no server push: the catalog
* is local, so the window needs the server for four things only -- your skill,
* your rank cap, where you are, and what this box is tuned to. Those four are
* also the only things in the window that can be STALE, which is why the top
* row says how old they are and offers to ask again. (The open handshake was a
* promise this file made and the code stopped keeping the moment the first one
* succeeded; 1.2.0 fixed it.)
*
* THE CATALOG IS RESOLVED ONCE, NOT SIXTY TIMES A SECOND. Everything derived
* from it -- which baits hook a fish, which pools hold it, the rods that will
* not lose it, its best hour and moon, an area's skill band, a monster's bait,
* the whole route's cells -- is arithmetic over a file that is loaded once and
* never written to, so it is computed on first sight and kept. The wire's four
* facts are the only inputs that move, and the two things that depend on them
* (the ladder and the route) are keyed on exactly those. Before 1.2.0 this
* window rebuilt all of it, plus several hundred resource-manager reads, on
* every rendered frame.
*
* TURN IT OFF AND NOTHING IS LOST. `!fish` works typed and says where you stand
* and what to catch next; `!fish route` walks the whole plan and `!fish rank`
* names the fish that lifts your cap, all in sentences. This is friendlier; it
* is not required.
--]]

addon.name    = 'dwfishing';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.1';
addon.desc    = 'The fishing guide: a costed 0-110 route, and every fish, bait, rod and spot at this server\'s real rates.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the `!dwh` lines sent below; installed
-- before any other text_in handler in this file (dwecho.lua). Without it the
-- player reads `Blaster : !dwh hello` in their own log on every zone line.
echo.install();

--[[
* IS THIS CALL IN THE PLAYER'S ASHITA?
*
* Addons update through the content feed; the client's Ashita is whatever the
* player installed and does not move with them. All four calls below are
* declared in the Ashita this window was written against (addons/libs/
* annotations/SDK/IGuiManager.lua) and all four are calls no other addon in
* this suite makes yet -- so an older install is exactly where they would be
* missing. One of them, the size floor, is made OUTSIDE the render pcall,
* where a raise is not a closed window but an addon the host unloads.
*
* Detected once at load, behind a pcall of its own: `imgui` resolves unknown
* names through a metatable onto the GuiManager userdata, and a missing key
* there is not guaranteed to be a quiet nil.
--]]
local function guiHas(name)
    local ok, value = pcall(function ()
        return imgui[name];
    end);

    return ok and type(value) == 'function';
end

-- Per-column header tooltips need imgui's custom-header shape; without it the
-- one-call header row still draws every label, just without the sentences.
local CAN_HEADER_TIPS = guiHas('TableHeader') and guiHas('TableSetColumnIndex')
    and ImGuiTableRowFlags_Headers ~= nil;

-- The size floor and the clipboard are both all-or-nothing: no floor, or no
-- Copy button at all rather than one that does nothing.
local CAN_CONSTRAIN = guiHas('SetNextWindowSizeConstraints');
local CAN_CLIPBOARD = guiHas('SetClipboardText');

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; the sixteenth `_DW*DATA` name,
-- and nothing else on the server uses it, so matching it exactly is a safe
-- filter.
local DATA_SENDER = '_DWHDATA';

-- Protocol version the server announces in its `d|` record. An unknown one is
-- HARD REFUSED (one message, then silence) rather than guessed at.
local PROTOCOL = 1;

-- Chat is rate-limited by the client, not by this addon. One line per 1.2s and
-- a settle after a zone line, the dwscan cadence.
local SEND_INTERVAL = 1.2;
local ZONE_SETTLE   = 3.0;
local ANSWER_TIMEOUT = 5.0;

-----------------------------------------------------------------------------
-- The catalog
--
-- ONE AUTHORED FILE, TWO CONSUMERS. modules/driftwoodxi/fishing_core.lua loads
-- the identical file and both hash the bytes they actually loaded. A mismatch
-- means the addon and the server would describe different lakes, so the guide
-- REFUSES rather than picking one -- there is no version of that disagreement
-- where the window is safe to read.
-----------------------------------------------------------------------------

-- MUST MATCH modules/driftwoodxi/fishing_core.lua and the Python reference in
-- tools/dwfishing/gen_fishdata.py -- three implementations, one hash. The
-- 16-bit multiply split keeps the arithmetic inside a double's exact-integer
-- range (the dwtracker lesson).
local function fnv1a(text)
    local hash = 2166136261;

    for i = 1, #text do
        hash = bit.bxor(hash, string.byte(text, i)) % 4294967296;

        local lo = hash % 65536;
        hash = (((hash - lo) / 65536) * 16777619 % 65536) * 65536 + lo * 16777619;
        hash = hash % 4294967296;
    end

    return bit.tohex(hash);
end

local catalog = nil;
local catalogError = nil;

local function loadCatalog()
    local path = string.format('%s\\addons\\dwfishing\\data\\fishdata.lua',
        AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

    local file = io.open(path, 'rb');

    if (file == nil) then
        catalogError = 'data/fishdata.lua is missing from this addon install.';
        return;
    end

    local raw = file:read('*a');
    file:close();

    local normalized = raw:gsub('\r', '');
    local chunk, err = loadstring(normalized, 'dwfishing-catalog');

    if (chunk == nil) then
        catalogError = 'data/fishdata.lua will not parse: ' .. tostring(err);
        return;
    end

    local ok, data = pcall(chunk);

    -- Version 2 moved the hour/moon/month tables from macro index to FISH
    -- PATTERN ID and added prices, the rank ladder and the route. A reader
    -- written for 1 would index the new pattern tables without erroring and
    -- quietly draw the wrong curve, so this is a refusal like the hash is.
    if (not ok or type(data) ~= 'table' or data.version ~= 2) then
        catalogError = 'data/fishdata.lua is not a catalog this addon understands.';
        return;
    end

    -- Positional rows -> named records, once, at load. The generator's header
    -- documents every position and the harness locks them.
    local built = {
        hash      = fnv1a(normalized),
        version   = data.version,
        engine    = data.engine,
        baitPower = data.baitPower,
        distMod   = data.distMod,
        levelBias = data.levelBias,
        -- Indexed by the pattern id the FISH ROW carries, not by the macro
        -- index -- see the generator's header. Index 0 exists and is the
        -- engine's default arm, so every id resolves.
        hourP     = data.hourPattern,
        moonP     = data.moonPattern,
        monthP    = data.monthPattern,
        counts    = data.counts,
        fish      = {},
        fishById  = {},
        rods      = {},
        rodById   = {},
        baits     = {},
        baitById  = {},
        spots     = {},
        groups    = data.groups,
        fishSpots = data.fishSpots,
        fishBait  = data.fishBait,
        baitFish  = data.baitFish,
        mobs      = {},
        prices    = data.prices,
        ranks     = data.ranks,
        rankTest  = data.rankTest,
        plans     = data.routePlans,
        planSpots = data.routeSpots,
        levels    = data.routeLevels,
        terms     = data.routeTerms,
        altBand   = data.routeAltBand,
        altPlans  = data.routeAltPlans,
        altLevels = data.routeAltLevels,
    };

    for _, r in ipairs(data.fish) do
        local fish = {
            id = r[1], name = r[2], skill = r[3], size = r[4], water = r[5],
            rarity = r[6], legendary = r[7], item = r[8], minLen = r[9], maxLen = r[10],
            ranking = r[11], difficulty = r[12], delay = r[13], move = r[14],
            hour = r[15], moon = r[16], month = r[17], maxhook = r[18],
            keyitem = r[19], questOnly = r[20], contest = r[21], flags = r[22],
        };

        table.insert(built.fish, fish);
        built.fishById[fish.id] = fish;
    end

    for _, r in ipairs(data.rods) do
        local rod = {
            id = r[1], name = r[2], size = r[3], minRank = r[4], maxRank = r[5],
            legendary = r[6], breakable = r[7], attack = r[8], lgdAttack = r[9],
            recovery = r[10], time = r[11], lgdTime = r[12], smDelay = r[13],
            smMove = r[14], lgDelay = r[15], lgMove = r[16], multiplier = r[17],
            material = r[18], rating = r[19], flags = r[20],
        };

        table.insert(built.rods, rod);
        built.rodById[rod.id] = rod;
    end

    for _, r in ipairs(data.baits) do
        local bait = {
            id = r[1], name = r[2], type = r[3], maxhook = r[4],
            losable = r[5], rankmod = r[6], flags = r[7],
        };

        table.insert(built.baits, bait);
        built.baitById[bait.id] = bait;
    end

    -- The catalog's own name for every zone it knows water or a hooked monster
    -- in, keyed by zone id. The client's DAT is still preferred where it
    -- answers -- but it can answer nothing (a string this install does not
    -- carry), and the empty name that used to fall out of that is what made
    -- "Where I am" list all 166 areas instead of one zone's.
    built.zoneNames = {};

    for _, r in ipairs(data.spots) do
        table.insert(built.spots, {
            zone = r[1], area = r[2], group = r[3],
            zoneName = r[4], areaName = r[5], difficulty = r[6],
        });

        built.zoneNames[r[1]] = (r[4] or ''):gsub('_', ' ');
    end

    for _, r in ipairs(data.mobs) do
        table.insert(built.mobs, {
            id = r[1], name = r[2], zone = r[3], zoneName = r[4], area = r[5],
            level = r[6], nm = r[7], rarity = r[8], reqBait = r[9], altBait = r[10],
            keyitem = r[11], questOnly = r[12], minLen = r[13], maxLen = r[14],
            ranking = r[15], difficulty = r[16],
        });

        -- A monster's zone need not hold a fishing spot, so these fill gaps the
        -- spot rows leave. Spots win where both know a zone: they are the
        -- rows the guide's own tables are built from.
        if (built.zoneNames[r[3]] == nil) then
            built.zoneNames[r[3]] = (r[4] or ''):gsub('_', ' ');
        end
    end

    catalog = built;
end

loadCatalog();

-----------------------------------------------------------------------------
-- What this window remembers between sessions
--
-- Per PC, in config\addons\dwfishing\ under the Ashita install, through the
-- same settings library every sibling uses. Two scalars only: the tab you were
-- last on and whether you had junk folded away. Nothing here is data -- the
-- catalog is the data and it ships with the addon -- so a missing or corrupt
-- file costs a preference and nothing else, and the load is pcall'd like
-- dwcon's and dwscan's so it can never take the window down.
--
-- T{ }, NOT { } -- AND THE PCALL IS NOT THE SAFETY NET IT LOOKS LIKE
-- (1.2.1, 2026-09-06). Ashita's settings library calls `defaults:copy(true)`
-- (settings.lua:180) and `settings:merge(defaults)` (:338), and both live on
-- the sugar-table metatable, so a PLAIN defaults table is "attempt to call a
-- nil value" the first time the library reaches for either. The load below is
-- pcall'd, so that raise is silent -- but the library ALSO re-loads every
-- cached block from inside its own packet_in handler on the zone-enter packet
-- (:538 -> process_character_switch :286 -> load_settings :180), and THAT call
-- is not pcall'd by anyone. Ashita answers a raise in an event callback by
-- UNLOADING THE ADDON, so 1.2.0 shipped a window that vanished on the first
-- zone line with a settings.lua traceback in its place. Every sibling
-- (dwcon, dwscan, dwquest, dwcpx, ...) has always used T{ }; only this one
-- did not. harness_dwsuite now refuses a bare `{` here suite-wide.
-----------------------------------------------------------------------------
local defaultConfig = T{
    tab      = 1,
    hideJunk = false,
};

-- A table of its own rather than `config = defaultConfig`: aliased, a window
-- write would land in the constants, and settings.load merges those constants
-- over what is on disk. It only matters on the path where the load below
-- fails -- which is precisely the path nothing else covers. (dwscan's header
-- states the same rule.)
local config = defaultConfig:copy(true);

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

-- Ashita hands the whole table back on a profile change, so `config` is
-- re-pointed rather than merged into.
pcall(settings.register, 'settings', 'dwfishing_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end
end);

local function saveConfig()
    pcall(settings.save);
end

-----------------------------------------------------------------------------
-- Live state, from the wire
-----------------------------------------------------------------------------
local state = {
    open       = { false },
    spoke      = false,      -- the server has answered at least once
    helloed    = false,
    reported   = false,      -- one render-error line, not sixty a second
    refused    = false,      -- protocol or catalog mismatch: one message, then silence
    building   = nil,
    asked      = nil,
    askedAt    = 0,
    status     = 'Asking the server where you stand...',
    statusBad  = false,

    -- When the last envelope closed cleanly. The window says how old its
    -- answer is because everything the wire carries -- skill, rank cap, zone,
    -- what is on the rod -- changes while the window is shut, and a guide that
    -- looks live and is an hour old is worse than one that says so.
    syncedAt   = nil,

    -- Set by openWindow so the first frame of a reopened window lands on the
    -- tab the player left, and cleared the moment it has.
    wantTab    = nil,

    -- p|
    rawSkill   = nil,
    level      = nil,
    rank       = nil,
    rankCap    = nil,
    zone       = nil,

    -- s|
    multiplier = nil,
    enabled    = nil,
    minLevel   = nil,
    contest    = nil,

    -- g|
    gear       = {},

    -- c|
    serverHash = nil,
};

-- What the ladder tab is showing. Defaults to your live level and follows it
-- until the player drags the slider, at which point it stays where they put it.
local planLevel = { 0 };
local planPinned = false;

-- The tables ImGui writes into. Kept apart from `config` so the saved file
-- stays flat scalars (dwcon's header states the rule) and allocated once, not
-- once per frame.
local ui = { hideJunk = { false } };
local search    = { '' };
local searchMob = { '' };
local searchSpot = { '' };

local queue    = T{};
local lastSend = 0;
local readyAt  = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST, and that ordering is the whole point:
    -- this runs on every rendered frame for the life of the session, and the
    -- queue is empty in almost all of them. `echo.canSend()` is three calls
    -- across the C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning), so
    -- asking it first spent a hundred and eighty of those a second to decide
    -- whether to do nothing. (2026-09-06.)
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now < readyAt or now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    local command = table.remove(queue, 1);

    -- THROUGH dwecho, not around it. This addon calls echo.install() at load
    -- and then sent every line with QueueCommand, so the swallower was
    -- installed with nothing ever recorded for it to swallow -- and dwecho
    -- only matches lines it was told about. The player read `Blaster : !fish
    -- route` in their own chat log for every refresh, which is the exact
    -- symptom dwecho.lua's header opens with. `send` records and sends in one
    -- call precisely so the two cannot drift apart.
    echo.send(command);

    -- THE ANSWER CLOCK STARTS HERE, NOT WHERE THE ASK WAS ARMED (2026-09-06).
    -- A zone line holds this queue shut for ZONE_SETTLE while the give-up ran
    -- from the moment `hello` queued the line, so the window spent the settle
    -- ageing a line it had not sent -- leaving barely two of ANSWER_TIMEOUT's
    -- five seconds for a map server that is answering a login burst. The one
    -- line this addon ever sends is the ask, so stamping on the send is
    -- stamping on the ask.
    if (state.asked ~= nil) then
        state.askedAt = os.clock();
    end
end

--[[
* The one line this addon is sanctioned to send blind, and it is LATCHED.
*
* An unknown `!command` falls through to ordinary /say, so on a server whose
* dwh.lua is absent -- a launcher release that landed ahead of a server deploy,
* or any non-Driftwood server the boot script loaded this into -- an ungated
* send is the player publicly saying "!dwh hello" to the whole zone. Worse,
* they never see it, because dwecho blocks the local echo of our own lines.
* One line per zone line, per window open and per Refresh press -- each of
* them something the player did -- is the smallest thing that can cost
* anything, and the latch is what keeps a frame loop from ever adding to it.
--]]
local function hello()
    if (state.helloed or state.refused) then
        return;
    end

    state.helloed = true;
    state.asked   = 'hello';
    state.askedAt = os.clock();

    issue('!dwh hello');
end

-----------------------------------------------------------------------------
-- Record parsing
--
-- Every record is pipe-separated with a single-character kind. Anything this
-- addon does not recognise falls off the end of the chain rather than being an
-- error: a server newer than the addon must not break it, which is why the
-- `d|` record carries a version at all. Additive kinds never bump PROTOCOL.
-----------------------------------------------------------------------------
--[[
* A REFUSAL RETIRES THE ASK AND ABANDONS THE ENVELOPE (2026-09-06).
*
* Both were live bugs, and each hid a different half of the one message that
* matters most -- the only sentence this window can say that tells a player
* what to DO about it.
*
*   * The pending ask was left outstanding, so ANSWER_TIMEOUT later the answer
*     clock overwrote "Update the addon" with "The server did not answer",
*     about a server that had just answered twice. That is the suite rule
*     harness_dwsuite's protocol gate exists for.
*   * The catalog-hash refusal arrives as the FIRST record of an ordinary
*     hello (`c|` precedes `s|`, `p|` and `g|`), so the `z|` that closed the
*     envelope three records later found no `failed` mark and blanked the
*     status -- while `state.refused` stayed latched. The window then drew its
*     refusal branch, which draws state.status: a blank red line over an empty
*     window, with nothing on screen to say where the guide had gone.
*
* Clearing `building` is what closes both: every remaining record of this
* envelope, `z|` included, now falls off the "outside an envelope" guard, which
* is the correct reading of a refused answer -- there is nothing in the rest of
* it this window is willing to draw.
--]]
local function refuse(message)
    state.refused   = true;
    state.status    = message;
    state.statusBad = true;
    state.asked     = nil;
    state.building  = nil;

    print(chat.header('dwfishing'):append(chat.error(message)));
end

--[[
* A WIRE FIELD THAT REACHES string.format('%d') HAS TO BE AN INTEGER.
*
* LuaJIT raises on `string.format('%d', 43.5)` rather than truncating, and a
* raise inside d3d_present is answered by the render pcall CLOSING THE WINDOW
* -- over a guide that is ninety-nine per cent local catalog data with nothing
* to do with the malformed field. The emitters all use `%i`, so this is not
* about the server as it stands: it is about the line that arrives garbled, a
* future emitter, and the third-party addons that rewrite our chat packets
* before we see them. NaN and the infinities are rejected first, because
* `nan < 0` and `nan > 0` are both false and math.floor(nan) is still nan.
--]]
local function wholeNumber(text, fallback)
    local value = tonumber(text or '');

    if (value == nil or value ~= value or value < -2147483648 or value > 2147483647) then
        return fallback;
    end

    return math.floor(value);
end

local function handleRecord(line)
    -- Split on '|' by hand rather than with gmatch: a Lua pattern of '([^|]*)'
    -- yields an empty capture between every pair of fields, which silently
    -- shifts every index by one and is exactly the kind of off-by-one that
    -- renders as plausible-but-wrong data rather than as an error.
    local parts  = {};
    local cursor = 1;

    while (true) do
        local pipe = string.find(line, '|', cursor, true);

        if (pipe == nil) then
            table.insert(parts, string.sub(line, cursor));
            break;
        end

        table.insert(parts, string.sub(line, cursor, pipe - 1));
        cursor = pipe + 1;
    end

    local kind = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2] or '');

        if (version ~= PROTOCOL) then
            refuse(string.format(
                'This server speaks fishing protocol %s and this addon speaks %d. Update the addon.',
                tostring(parts[2]), PROTOCOL));

            return;
        end

        state.spoke    = true;
        state.building = { verb = parts[3] };

        -- THE GEAR TABLE IS REPLACED, NOT MERGED INTO. `g|` records are
        -- SPARSE: the server emits a record only for a slot that holds a
        -- fishing piece, so taking one off sends nothing at all and the old
        -- entry sat there forever, marking a slot [worn] over gear the
        -- character was no longer wearing. Cleared on the envelope that
        -- carries them rather than on every envelope -- a `status` envelope
        -- (a bare refusal) has no g| records and must not wipe the table.
        -- `hello` is the only verb that emits them; verbs.state aliases
        -- verbs.hello and the envelope is opened as 'hello', so that name is
        -- the whole set.
        --
        -- STAGED, NOT WIPED IN PLACE (2026-09-06). This used to reset
        -- `state.gear` here and let the g| records refill it, and every record
        -- is its own 0x017 packet with the render running between them -- so
        -- the Gear tab drew every worn mark gone for a frame or two on each
        -- hello, and a hello the server refused mid-envelope left it that way
        -- for good. The new set builds on the envelope and the close swaps it
        -- in whole; a failed envelope drops it and the old set stands.
        if (parts[3] == 'hello') then
            state.building.gear = {};
        end

        return;
    end

    if (state.building == nil) then
        return; -- outside an envelope: discarded, per the wire contract
    end

    if (kind == 'z') then
        -- ...UNLESS THIS ENVELOPE IS THE ONE CARRYING THE COMPLAINT. A refusal
        -- is `d|1|status` / `e|<message>` / `z|status` -- squad_storage.lua's
        -- writer wraps a bare fail in its own envelope precisely so the addon,
        -- which discards records outside one, can see it at all. So the close
        -- below was erasing the message three records after it arrived, and
        -- EVERY server refusal this window could receive was invisible: set
        -- for one handler call and blanked before a frame was ever drawn. The
        -- latch this comment used to point at (state.refused) is a different
        -- one -- it belongs to the catalog-mismatch path and never fires here.
        local failed = state.building ~= nil and state.building.failed;
        local staged = state.building ~= nil and state.building.gear or nil;

        state.building = nil;
        state.asked    = nil;

        -- A CLOSED ENVELOPE CLEARS A STALE COMPLAINT. The answer-timeout writes
        -- "The server did not answer" and sets statusBad; a later envelope that
        -- arrives and completes is proof that it did. Leaving the old message
        -- up meant one slow reply painted the window red for the rest of the
        -- session, over a guide that was by then perfectly correct.
        if (not failed) then
            state.status    = '';
            state.statusBad = false;
            state.syncedAt  = os.clock();

            -- The staged gear becomes the table in one assignment (the d|
            -- branch, 2026-09-06); a refused hello never reaches this line.
            if (staged ~= nil) then
                state.gear = staged;
            end
        end

        return;
    end

    if (kind == 'e') then
        state.status    = parts[2] or 'The server refused.';
        state.statusBad = true;

        -- Marked on the envelope so the `z|` that closes it knows not to wipe
        -- what it just delivered. Reset per envelope by the `d|` handler, so a
        -- later clean response still clears the message.
        if (state.building ~= nil) then
            state.building.failed = true;
        end

        return;
    end

    if (kind == 'm') then
        return;
    end

    if (kind == 'c') then
        state.serverHash = parts[2];

        -- THE ONE MISMATCH THAT MUST REFUSE. If the server's catalog is not the
        -- catalog this window is drawing, every spot, bait and skill number
        -- below is about a different server. Stale is not the risk; WRONG is.
        if (catalog ~= nil and parts[2] ~= 'none' and parts[2] ~= catalog.hash) then
            refuse('This addon\'s fishing data does not match the server\'s. Update the addon (or re-run the launcher) -- the guide is hidden rather than shown wrong.');
        end

        return;
    end

    if (kind == 's') then
        -- A MULTIPLIER THAT IS NOT A REAL NUMBER POISONS TWO CACHES AS WELL AS
        -- THE ARITHMETIC. LuaJIT's tonumber accepts 'nan' and 'inf', nan is not
        -- equal to itself, and both the ladder and the route are kept on a
        -- `cache.multiplier == multiplier` test -- so a nan would rebuild the
        -- whole ladder and the whole route on EVERY FRAME while every
        -- percentage in the window read nan. Refused back to the stock rate,
        -- which is what the addon assumes before the server has spoken anyway.
        local multiplier = tonumber(parts[2] or '');

        state.multiplier = (multiplier ~= nil and multiplier == multiplier
            and multiplier > 0 and multiplier < 1000) and multiplier or 1.0;
        state.enabled    = (tonumber(parts[3] or '') or 0) == 1;
        state.minLevel   = wholeNumber(parts[4], 0);
        state.contest    = (tonumber(parts[5] or '') or 0) == 1;

        return;
    end

    if (kind == 'p') then
        state.rawSkill = wholeNumber(parts[2], 0);
        state.level    = wholeNumber(parts[3], 0);
        state.rank     = wholeNumber(parts[4], 0);
        state.rankCap  = wholeNumber(parts[5], 0);
        state.zone     = wholeNumber(parts[6], 0);

        if (not planPinned) then
            planLevel[1] = state.level;
        end

        return;
    end

    if (kind == 'g') then
        -- Into the envelope's staged set while a hello is open (see the d|
        -- branch); a g| outside one is a record this envelope did not stage.
        (state.building.gear or state.gear)[parts[2]] = wholeNumber(parts[3], 0);

        return;
    end
end

ashita.events.register('packet_in', 'dwfishing_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwfishing'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* A zone line means a new place to stand, which is the one thing on the wire
* that can change without the player doing anything in this window. The
* handshake latch is cleared so the next open re-asks -- and a map restart logs
* everyone out, so the server on the other side may well be the updated one,
* which is why the refusal latch clears too.
--]]
ashita.events.register('packet_in', 'dwfishing_zonein', function (e)
    if (e.id ~= 0x000A) then
        return;
    end

    state.helloed  = false;
    state.refused  = false;
    state.building = nil;
    state.asked    = nil;
    state.status   = '';
    state.statusBad = false;

    -- THE ZONE IS THE ONE FACT THE ZONE LINE INVALIDATES, and it used to
    -- survive it: for the whole gap between the load screen and the answer the
    -- Spots tab marked the zone the player had just LEFT with "You are in this
    -- zone", which is the only claim on that tab about right now. Skill, rank
    -- and the cap are not cleared -- zoning does not move them, and blanking
    -- them would flash the whole guide back to "waiting" on every door.
    state.zone     = nil;
    state.syncedAt = nil;

    readyAt = os.clock() + ZONE_SETTLE;

    if (state.open[1]) then
        hello();
    end
end);

-----------------------------------------------------------------------------
-- Derived views over the catalog
--
-- All of this is arithmetic over the LOCAL catalog and the live multiplier,
-- which is the only number the window is handed. Nothing here re-derives a
-- server decision; it re-reads the same constants the server compiled from.
-----------------------------------------------------------------------------

-- The engine's skill-up NUMERATOR, factorised exactly as the C++ expression
-- separates: a term that depends only on the level difference, plus one that
-- depends only on your level, floored, then scaled by this box's multiplier.
-- nil where the engine returns early -- at or below your level, or beyond the
-- window.
--
-- TAKEN AS A DIFFERENCE, because that is the form the route needs and the
-- ladder can reach. This same expression was written out three times in this
-- file (here, and twice inside buildRoute), and a formula that is mirrored
-- rather than called is a formula that drifts -- the alt-trust rule, one tier
-- down. The multiplier is a parameter for the same reason: the route costs
-- itself at a multiplier it is handed, not at the one in `state`.
local function numeratorAt(level, difference, multiplier)
    if (catalog == nil) then
        return nil;
    end

    if (difference < 1 or difference > catalog.engine.skillupWindow) then
        return nil;
    end

    local dist = catalog.distMod[difference] or 0;
    local bias = catalog.levelBias[level + 1] or 0;

    return math.max(catalog.engine.skillupFloor, dist + bias) * (multiplier or 1.0);
end

local function skillupNumerator(level, fishSkill)
    return numeratorAt(level, fishSkill - level, state.multiplier or 1.0);
end

--[[
* THE DENOMINATOR, AND WHY THIS WINDOW USED TO PRINT A NUMBER THAT WAS NOT A
* PERCENTAGE.
*
* `if (xirand::GetRandomNumber(skillRoll) < maxChance)` draws from
* [0, skillRoll), so the chance of a skill-up is maxChance / skillRoll -- and
* skillRoll is never a hundred. It opens at 90, drops 10 anywhere that is not a
* city zone (which is every fishing spot worth standing in) and drops another
* `20 - floor(level / 3)` below level 50. At level 0 the roll is out of SIXTY.
*
* On this box that matters twice over: the early game is a third better than the
* old number claimed, and with the multiplier applied the numerator passes the
* roll outright across most of the window -- the skill-up stops being a chance
* at all, and that is the single most useful thing the window can say.
--]]
local function skillRoll(level)
    if (catalog == nil or catalog.terms == nil) then
        return 100;
    end

    local terms = catalog.terms;
    local roll  = terms.rollBase - terms.rollOutdoor;

    if (level < terms.rollNoviceUnder) then
        roll = roll - (terms.rollNoviceBase - math.floor(level / terms.rollNoviceDiv));
    end

    return math.max(roll, 1);
end

-- The numerator over that roll, clamped at certainty. One copy, so the ladder
-- and the route cannot come to disagree about what a percentage is.
local function chanceFrom(numerator, level)
    if (numerator == nil) then
        return nil;
    end

    return math.min(1.0, numerator / skillRoll(level)) * 100;
end

-- The baits that can hook a fish at all, best power first. An empty list means
-- the fish is unreachable with every bait in the game -- which happens, and the
-- window says so rather than leaving a blank.
local function baitsFor(fishId)
    local out = {};

    if (catalog == nil) then
        return out;
    end

    local flat = catalog.fishBait[fishId];

    if (flat == nil) then
        return out;
    end

    for index = 1, #flat, 2 do
        local bait = catalog.baitById[flat[index]];

        if (bait ~= nil) then
            table.insert(out, { bait = bait, power = flat[index + 1] });
        end
    end

    return out;
end

local function spotsFor(fishId)
    local out = {};

    if (catalog == nil) then
        return out;
    end

    for _, index in ipairs(catalog.fishSpots[fishId] or {}) do
        local spot = catalog.spots[index];

        if (spot ~= nil) then
            table.insert(out, spot);
        end
    end

    return out;
end

local function fishInSpot(spot)
    local out = {};

    if (catalog == nil) then
        return out;
    end

    local flat = catalog.groups[spot.group];

    if (flat == nil) then
        return out;
    end

    -- flat[index + 1] is the GROUP's rarity column, which the engine loads and
    -- never uses (see rarityWord). It is carried here rather than dropped so
    -- the harness can keep asserting the row shape the generator emits.
    for index = 1, #flat, 4 do
        local fish = catalog.fishById[flat[index]];

        if (fish ~= nil) then
            table.insert(out, { fish = fish, groupRarity = flat[index + 1], pool = flat[index + 2] });
        end
    end

    return out;
end

-- The rod the engine will not penalise for this fish. Size mismatch costs 3 or
-- 5 hook points (CalculateHookChance), and a rod whose maxRank sits under the
-- fish's ranking is the one that snaps -- so "best" means matching size and
-- carrying the ranking, cheapest rating first.
local function rodsFor(fish)
    local out = {};

    if (catalog == nil) then
        return out;
    end

    for _, rod in ipairs(catalog.rods) do
        if (rod.size == fish.size and rod.maxRank >= fish.ranking) then
            table.insert(out, rod);
        end
    end

    return out;
end

-- The hours the curve actually peaks at, read off the sampled curve rather than
-- described from memory. Patterns 2, 3 and 4 are not curves at all -- the
-- engine tests the clock directly -- but the generator samples those the same
-- way, so a flat-topped run of hours falls out here as a list rather than
-- needing a special case and a hand-written note to go with it.
local function peakHours(curve)
    local best = -1;

    for index = 1, #curve do
        best = math.max(best, curve[index]);
    end

    local hours = {};

    for index = 1, #curve do
        if (curve[index] >= best - 1e-6) then
            table.insert(hours, index - 1);
        end
    end

    return hours, best;
end

-- Consecutive hours collapse to a range; the clock-test patterns are mostly one
-- or two runs and reading them back as a list of twenty-two hours would be
-- worse than useless.
local function hourList(hours)
    local parts = {};
    local index = 1;

    while (index <= #hours) do
        local last = index;

        while (last < #hours and hours[last + 1] == hours[last] + 1) do
            last = last + 1;
        end

        if (last == index) then
            table.insert(parts, string.format('%02d:00', hours[index]));
        else
            table.insert(parts, string.format('%02d:00-%02d:00', hours[index], hours[last]));
        end

        index = last + 1;
    end

    return table.concat(parts, ', ');
end

local function hourWord(fish)
    if (catalog == nil) then
        return 'any hour';
    end

    local curve = catalog.hourP[fish.hour] or catalog.hourP[0];

    if (curve == nil) then
        return 'any hour';
    end

    local hours = peakHours(curve);

    -- Every hour equally good is the engine's default arm, and "peaks at all of
    -- them" would be noise.
    if (#hours >= #curve) then
        return 'any hour';
    end

    -- Mostly-good is stated as the exception, because "any hour except 05:00
    -- and 17:00" is the sentence, and its complement is twenty-two of them.
    if (#hours * 2 > #curve) then
        local worst = {};

        for index = 1, #curve do
            local hit = false;

            for _, hour in ipairs(hours) do
                hit = hit or (hour == index - 1);
            end

            if (not hit) then
                table.insert(worst, index - 1);
            end
        end

        return 'any hour except ' .. hourList(worst);
    end

    return 'best at ' .. hourList(hours);
end

local MOON_NAMES = {
    'New', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous',
    'Full', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent',
};

local function moonWord(fish)
    if (catalog == nil) then
        return 'any moon';
    end

    -- Moon pattern 5 dispatches to MOONPATTERN_4, not _5, and the moon's own
    -- default arm is 1.0 where the hour's and month's are 0.5. Both of those
    -- are the generator's problem now, and this just reads what it emitted.
    local curve = catalog.moonP[fish.moon] or catalog.moonP[0];

    if (curve == nil) then
        return 'any moon';
    end

    local phases = peakHours(curve);

    if (#phases >= #curve) then
        return 'any moon';
    end

    local parts = {};

    for index = 1, math.min(2, #phases) do
        table.insert(parts, MOON_NAMES[phases[index] + 1] or '?');
    end

    if (#phases > 2) then
        table.insert(parts, string.format('+%d more', #phases - 2));
    end

    return 'best at ' .. table.concat(parts, ' / ') .. ' moon';
end

--[[
* THE THIRD CLOCK, WHICH NOTHING DREW.
*
* Every fish carries an hour, a moon AND a month pattern; the engine multiplies
* all three together (GetMonthlyTidalInfluence, fishingutils.cpp:236). The
* catalog has sampled the month curves since the first release and no tab has
* ever rendered one -- a table nobody draws is a table nobody can check.
*
* It is on the hover card rather than in the "When" column because it is the
* weakest of the three (the Basics tab: the moon contributes three times as
* much as the month) and because a month is not something a player can steer
* the way they can wait four hours. nil where every month is equal, which is
* the engine's default arm and would be a line saying nothing.
*
* The engine reads `get_month() - 1`, so the curve is 0-based and a displayed
* month is the sampled index plus one.
--]]
local function monthWord(fish)
    if (catalog == nil) then
        return nil;
    end

    local curve = catalog.monthP[fish.month] or catalog.monthP[0];

    if (curve == nil) then
        return nil;
    end

    local best = peakHours(curve);

    if (#best >= #curve) then
        return nil;
    end

    local parts = {};

    for index = 1, math.min(4, #best) do
        table.insert(parts, tostring(best[index] + 1));
    end

    if (#best > 4) then
        table.insert(parts, string.format('+%d more', #best - 4));
    end

    return 'best in month ' .. table.concat(parts, ', ');
end

local SIZE_WORD  = { [0] = 'Small', [1] = 'Large' };
local WATER_WORD = { [0] = 'Any water', [1] = 'Freshwater', [2] = 'Saltwater' };
local BAIT_WORD  = { [0] = 'Bait', [1] = 'Lure', [2] = 'Special' };

--[[
* Rarity is a per-thousand weight the engine multiplies the hook chance by, so
* it is a real number and not a mood. Stated as the multiplier it is.
*
* AND IT IS THE FISH'S OWN RARITY, NOT THE GROUP'S. fishing_group carries a
* rarity column per (group, fish) and this tab used to draw it, but the engine
* does not: LoadFishGroups reads it into the pool map and GetFishPool hands it
* back as `fish.second`, where the catch roll leaves it on a commented-out line
* (`// uint16 baitPower = fish.second; //@TODO`). What CalculateHookChance
* actually multiplies by is `fish->rarity`, straight off fishing_fish. The two
* disagree for 130 of the 1070 group rows, so the old column was quietly wrong
* about roughly one row in eight -- including saying "common" about a Black Sole
* the engine draws at 0.15x.
--]]
local function rarityWord(rarity)
    if (rarity >= 1000) then
        return 'common';
    end

    return string.format('%.1fx rarer', 1000 / math.max(rarity, 1));
end

--[[
* THE CLIENT'S OWN NAMES, ASKED FOR ONCE EACH.
*
* Every one of these is a DAT read behind a pcall, and this window was asking
* for the same handful of them once per ROW per FRAME: the Fish tab alone
* resolved up to two zone names for each of 128 rows, the Monsters tab up to
* two item names for each of 259, sixty times a second, for names that cannot
* change while the client is running. Cached by id INCLUDING the miss -- a
* zone this install carries no string for must not be re-asked sixty times a
* second either. (2026-09-06.)
--]]
local zoneNameCache = {};
local itemNameCache = {};

local function zoneName(spot)
    local id     = spot.zone;
    local cached = zoneNameCache[id];

    if (cached ~= nil) then
        return cached;
    end

    local resolved = nil;
    local ok, name = pcall(function ()
        return AshitaCore:GetResourceManager():GetString('zones.names', id);
    end);

    if (ok and type(name) == 'string' and #name > 0) then
        resolved = name;
    end

    -- The catalog's own copy is the raw zone key (Carpenters_Landing); the
    -- client's DAT holds the display name and is preferred, exactly the way
    -- dwscan resolves item names rather than putting them on the wire. The
    -- catalog's index is the FALLBACK rather than the empty string it used to
    -- be: an empty name is what made "Where I am" write an empty filter and
    -- list every fishing area in the game.
    resolved = resolved
        or (catalog ~= nil and catalog.zoneNames[id])
        or string.format('zone %s', tostring(id));

    zoneNameCache[id] = resolved;

    return resolved;
end

local function itemName(itemId)
    if (itemId == nil or itemId == 0) then
        return nil;
    end

    local cached = itemNameCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local resolved = nil;
    local ok, item = pcall(function ()
        return AshitaCore:GetResourceManager():GetItemById(itemId);
    end);

    -- `type(...) == 'string'` and not `#item.Name[1]`: the length operator is
    -- outside the pcall above, so an item whose Name table is present and
    -- whose first entry is not would raise here rather than fall back.
    if (ok and item ~= nil and item.Name ~= nil and type(item.Name[1]) == 'string' and #item.Name[1] > 0) then
        resolved = item.Name[1];
    end

    resolved = resolved or string.format('item %d', itemId);
    itemNameCache[itemId] = resolved;

    return resolved;
end

-- The client's own description of an item, for the hover cards. Read once per
-- id and guarded the way dwtoau's is; a nil answer is cached as a miss so a
-- fish the install has no description for is not re-read every frame the
-- mouse rests on it.
local itemDescCache = {};

local function itemDesc(itemId)
    if (itemId == nil or itemId == 0) then
        return nil;
    end

    local cached = itemDescCache[itemId];

    if (cached ~= nil) then
        return cached.text;
    end

    local entry = { text = nil };

    pcall(function ()
        local item = AshitaCore:GetResourceManager():GetItemById(itemId);

        if (item ~= nil and item.Description ~= nil and type(item.Description[1]) == 'string'
            and #item.Description[1] > 0) then
            entry.text = item.Description[1];
        end
    end);

    itemDescCache[itemId] = entry;

    return entry.text;
end

-- ITEMS ARE NOT BAIT-GATED, AND SAYING THEY WERE WAS A LIE THE HARNESS CAUGHT.
-- GetFishPool intersects the fish pool with the equipped bait's affinity rows,
-- but GetItemPool does no such thing -- junk is drawn from the area's group on
-- its own weight, whatever is on the hook. Every item row therefore has no
-- affinity row, and rendering that as "no bait in the game hooks this" told
-- players a Rusty Bucket was unobtainable when it is the one thing they cannot
-- avoid catching.
local function baitSummary(baits, limit, isItem)
    if (isItem) then
        return 'any bait (junk ignores affinity)';
    end

    if (#baits == 0) then
        return 'no bait in the game hooks this';
    end

    local parts = {};

    for index = 1, math.min(limit or 3, #baits) do
        local entry = baits[index];

        table.insert(parts, string.format('%s (p%d)', entry.bait.name, entry.power));
    end

    return table.concat(parts, ', ');
end

local function spotSummary(spots, limit)
    if (#spots == 0) then
        return 'no pool holds it';
    end

    local parts = {};

    for index = 1, math.min(limit or 2, #spots) do
        local spot = spots[index];

        table.insert(parts, string.format('%s - %s', zoneName(spot), spot.areaName));
    end

    if (#spots > (limit or 2)) then
        table.insert(parts, string.format('+%d more', #spots - (limit or 2)));
    end

    return table.concat(parts, ', ');
end

--[[
* EVERYTHING ABOUT A FISH THAT CANNOT CHANGE, RESOLVED ONCE.
*
* Which baits hook it, which pools hold it, the two sentences about its clock,
* and the rods that will not lose it. None of it depends on the player, the
* wire or the multiplier -- it is all arithmetic over a catalog that is loaded
* once and never written to -- and the Fish tab was recomputing all of it for
* 128 rows sixty times a second: two table builds, a scan of a 24-point curve
* for its peak, a run-length pass over the hours, and up to two DAT zone reads,
* per row, per frame. (2026-09-06.)
--]]
local fishViews = {};

-- Whether a catch at this skill would teach you anything AT ALL, which is the
-- question the Skill column silently begged: the engine's window is above your
-- level and within fifty of it, and every number in these tables is outside it
-- for most players most of the time. nil while the server has not said where
-- you stand -- a colour that means "yes" must not appear before the answer.
local function teachesNow(fishSkill)
    if (state.level == nil) then
        return nil;
    end

    return numeratorAt(state.level, fishSkill - state.level, 1.0) ~= nil;
end

local function fishView(fish)
    local view = fishViews[fish.id];

    if (view ~= nil) then
        return view;
    end

    local baits = baitsFor(fish.id);
    local spots = spotsFor(fish.id);
    local junk  = (fish.item == 1);

    -- THE RODS THAT WILL NOT LOSE IT -- the line the README row and this
    -- file's own opening paragraph both promise, and which nothing drew.
    -- `rodsFor` has been in this file since the addon shipped with no caller
    -- at all. Cheapest rating first, which is the order the catalog emits
    -- them in.
    local rods  = rodsFor(fish);
    local names = {};

    for index = 1, math.min(4, #rods) do
        table.insert(names, rods[index].name);
    end

    if (#rods > 4) then
        table.insert(names, string.format('+%d more', #rods - 4));
    end

    view = {
        baits   = baits,
        spots   = spots,
        rods    = rods,
        rodText = (#rods > 0) and table.concat(names, ', ')
            or 'nothing in the game both matches its size and carries its ranking',
        bait2   = baitSummary(baits, 2, junk),
        bait3   = baitSummary(baits, 3, junk),
        bait6   = baitSummary(baits, 6, junk),
        where2  = spotSummary(spots, 2),
        where4  = spotSummary(spots, 4),
        when    = string.format('%s; %s', hourWord(fish), moonWord(fish)),
        month   = monthWord(fish),
        sizeWater = string.format('%s, %s', SIZE_WORD[fish.size] or '?', WATER_WORD[fish.water] or '?'),
        skill   = tostring(fish.skill),
        rarity  = rarityWord(fish.rarity),
        needle  = string.lower(fish.name),
    };

    fishViews[fish.id] = view;

    return view;
end

-- The skill-up ladder for a level: every fish that can teach you something,
-- best first. Items and quest-only rows are excluded because the engine grants
-- no skill for them at all (fishingutils.cpp:2933).
--
-- CACHED ON THE TWO THINGS IT DEPENDS ON. It walks all 128 fish, resolves
-- every bait and pool row behind each one and sorts what is left -- and it ran
-- on every frame for a table that only moves when the player drags the slider
-- or the server names a different multiplier.
local ladderCache = { level = nil, multiplier = nil, rows = {} };

local function ladderFor(level)
    local multiplier = state.multiplier or 1.0;

    if (ladderCache.level == level and ladderCache.multiplier == multiplier) then
        return ladderCache.rows;
    end

    local out = {};

    if (catalog == nil) then
        return out;
    end

    for _, fish in ipairs(catalog.fish) do
        if (fish.item == 0 and fish.questOnly == 0) then
            local numerator = skillupNumerator(level, fish.skill);

            if (numerator ~= nil) then
                local view = fishView(fish);

                local chance = chanceFrom(numerator, level);

                table.insert(out, {
                    fish       = fish,
                    view       = view,
                    numerator  = numerator,
                    chance     = chance,
                    diff       = fish.skill - level,
                    skillText  = string.format('%d (+%d)', fish.skill, fish.skill - level),
                    chanceText = string.format('%.0f%%', chance),
                    baits      = view.baits,
                    spots      = view.spots,
                });
            end
        end
    end

    -- Ranked on the NUMERATOR, not on the probability. Once the multiplier
    -- pushes maxChance past the roll every row reads 100% and sorting on that
    -- would order the ladder alphabetically, so the engine's own preference is
    -- kept and the saturation is reported instead of sorted on.
    table.sort(out, function (a, b)
        if (a.numerator ~= b.numerator) then
            return a.numerator > b.numerator;
        end

        if (#a.spots ~= #b.spots) then
            return #a.spots > #b.spots;
        end

        return a.fish.name < b.fish.name;
    end);

    -- Counted here rather than on every frame: the Next tab's headline needs
    -- how many of these are certain, and that is a property of the ladder.
    out.certain = 0;

    for _, entry in ipairs(out) do
        if (entry.chance >= 100) then
            out.certain = out.certain + 1;
        end
    end

    ladderCache.level      = level;
    ladderCache.multiplier = multiplier;
    ladderCache.rows       = out;

    return out;
end

-----------------------------------------------------------------------------
-- Names and numbers the route and the tables both quote
--
-- Above the route rather than beside the tabs, because the route now formats
-- its own rows once at build time instead of on every frame, and a `local
-- function` declared further down the file is not visible to code compiled
-- above it -- it would resolve to a nil global at call time.
-----------------------------------------------------------------------------
-- Route totals run to six figures, and an unbroken run of digits is unreadable
-- at a glance -- which is the only reason anyone looks at them.
local function commaNumber(value)
    local text = string.format('%d', math.floor((value or 0) + 0.5));
    local out  = text:reverse():gsub('(%d%d%d)', '%1,'):reverse();

    return (out:gsub('^,', ''));
end

local function itemLine(id)
    local price = catalog and catalog.prices[id];

    if (price == nil) then
        return 'not sold by any shop in the catalog';
    end

    return string.format('%d gil from %s in %s%s',
        price[1], price[3], price[2],
        (price[5] <= 1) and ' (reusable -- you buy it once)' or ' each');
end

local function gearName(index, id)
    local entry = index[id];

    return (entry ~= nil) and entry.name or itemName(id);
end

-----------------------------------------------------------------------------
-- The route, 0 to the ceiling
--
-- The catalog carries a plan for every level and the plans themselves
-- deduplicated; a SEGMENT is a run of levels that share one. The run boundaries
-- are collapsed HERE rather than in the generator because the rates printed
-- beside them depend on this box's multiplier, which only exists on the wire --
-- the same split the skill-up curve uses, one level up.
--
-- Recomputed only when the multiplier changes, which is once per session.
-----------------------------------------------------------------------------
local route = {
    multiplier = nil, segments = {}, alternates = {}, castsFrom = {},
    casts = 0, gil = 0, earn = 0, kit = 0,
};

local function buildRoute()
    if (catalog == nil or catalog.levels == nil) then
        return;
    end

    local multiplier = state.multiplier or 1.0;

    if (route.multiplier == multiplier) then
        return;
    end

    local segments   = {};
    local points     = catalog.terms.pointsPerLevel;
    local totals     = { casts = 0, gil = 0, earn = 0 };
    local levelCasts = {};

    for level = 0, catalog.engine.maxLevel - 1 do
        local entry = catalog.levels[level + 1];

        if (entry ~= nil) then
            local quads = entry[4];
            local rate  = 0.0;
            local top, topShare = nil, -1;

            for index = 1, #quads, 4 do
                local difference = quads[index + 1];
                local share      = quads[index + 2];
                local amount     = quads[index + 3];

                -- `or 0` is a guard, not a case: the generator refuses to emit
                -- a level whose differences fall outside the skill-up window,
                -- and the harness asserts that every one of them is inside it.
                local numerator  = numeratorAt(level, difference, multiplier) or 0;

                rate = rate + share * math.min(1.0, numerator / skillRoll(level)) * amount;

                if (share > topShare) then
                    top, topShare = quads[index], share;
                end
            end

            local casts = (rate > 0) and (points / rate) or 0;
            local last  = segments[#segments];

            levelCasts[level] = casts;
            totals.casts = totals.casts + casts;
            totals.gil   = totals.gil + casts * entry[2];
            totals.earn  = totals.earn + casts * entry[3];

            if (last ~= nil and last.plan == entry[1]) then
                last.to    = level + 1;
                last.casts = last.casts + casts;
                last.gil   = last.gil + casts * entry[2];
                last.earn  = last.earn + casts * entry[3];

                -- `top` is nil only for a level with no hookable target at
                -- all, which the generator does not emit and the harness
                -- forbids -- but a nil table KEY is a raise, not a blank cell,
                -- and this one would take the whole Route tab down.
                if (top ~= nil) then
                    last.tops[top] = (last.tops[top] or 0) + 1;
                end
            else
                table.insert(segments, {
                    plan  = entry[1],
                    from  = level,
                    to    = level + 1,
                    casts = casts,
                    gil   = casts * entry[2],
                    earn  = casts * entry[3],
                    tops  = (top ~= nil) and { [top] = 1 } or {},
                });
            end
        end
    end

    --[[
    * WHAT IS LEFT OF THE STRETCH YOU ARE STANDING IN, EXACTLY.
    *
    * "Stay until 55, about N more casts" used to pro-rata the stretch's total
    * across its levels -- casts * (to - you) / (to - from) -- and the casts a
    * level costs are not flat across a stretch: the skill-up curve moves under
    * you as you climb it, so the early levels of a run are cheaper than the
    * late ones and the interpolation was wrong at both ends and in the middle.
    * The catalog carries the per-level cost and this walk has just computed it,
    * so the suffix sum is free and the number is the real one. (2026-09-06.)
    --]]
    local castsFrom = {};

    for _, segment in ipairs(segments) do
        local running = 0;

        for level = segment.to - 1, segment.from, -1 do
            running = running + (levelCasts[level] or 0);
            castsFrom[level] = running;
        end
    end

    -- ...and what is left AFTER this stretch, so the window can answer the
    -- other half of the same question: not "how long until I move" but "how
    -- far is the whole climb from where I am standing". The route's headline
    -- total is measured from zero, which is the one level the player reading
    -- it is not on.
    local trailing = 0;

    for index = #segments, 1, -1 do
        segments[index].afterCasts = trailing;
        trailing = trailing + segments[index].casts;
    end

    -- What the route asks you to BUY, each rod and each reusable lure counted
    -- once. Consumable bait is not in here: it is priced per cast inside the
    -- levels, because that is where it is actually spent.
    local owned, kit = {}, 0;

    for _, segment in ipairs(segments) do
        local plan = catalog.plans[segment.plan];

        local buy = { plan[3] };

        if (plan[4] == 1) then
            table.insert(buy, plan[2]);
        end

        for _, id in ipairs(buy) do
            local price = catalog.prices[id];

            if (price ~= nil and not owned[id]) then
                owned[id] = true;
                kit = kit + price[1];
            end
        end

        -- The commonest catch names the segment, which is what a player
        -- remembers a spot by.
        local best, bestCount = nil, -1;

        for id, count in pairs(segment.tops) do
            if (count > bestCount) then
                best, bestCount = id, count;
            end
        end

        segment.top = best;

        -- EVERY CELL OF THIS ROW, FORMATTED HERE RATHER THAN ON EVERY FRAME.
        -- The route is rebuilt only when the multiplier changes -- once per
        -- session -- and the tab was re-running two comma-grouping passes (a
        -- reverse, a gsub and another reverse each), three string.formats and
        -- a scan of the whole rank ladder per row, sixty times a second, over
        -- numbers that had not moved. (2026-09-06.)
        local spot = catalog.spots[plan[1]];

        segment.range    = string.format('%d-%d', segment.from, segment.to);
        segment.where    = string.format('%s - %s', zoneName(spot), spot.areaName);
        segment.rodId    = plan[3];
        segment.baitId   = plan[2];
        segment.rodText  = gearName(catalog.rodById, plan[3]);
        segment.baitText = gearName(catalog.baitById, plan[2]);
        segment.rodBuy   = 'Buy here: ' .. itemLine(plan[3]);
        segment.baitBuy  = 'Buy here: ' .. itemLine(plan[2]);
        segment.rodLine  = string.format('   Rod: %s', itemLine(plan[3]));
        segment.baitLine = string.format('   Bait: %s', itemLine(plan[2]));
        segment.castText = commaNumber(segment.casts);
        segment.gilText  = commaNumber(segment.gil);
        segment.topName  = (best ~= nil and catalog.fishById[best] ~= nil)
            and catalog.fishById[best].name or nil;
        segment.snaps    = (plan[5] > 0.005)
            and string.format('snaps ~1 cast in %d', math.floor(1 / plan[5])) or nil;

        -- A rank test falling inside this stretch is said where the player is
        -- looking, because arriving at the cap with no idea why is the failure
        -- this whole feature exists to prevent.
        segment.tests = {};

        for _, row in ipairs(catalog.ranks or {}) do
            if (row[2] > segment.from and row[2] <= segment.to) then
                local fish = catalog.fishById[row[3]];

                table.insert(segment.tests, string.format('at %d: guild test -- trade a %s', row[2],
                    (fish ~= nil) and fish.name or itemName(row[3])));
            end
        end
    end

    -- The alternate openers, costed the same way over the same band. Same
    -- arithmetic as above, so a difference between the two lists can only come
    -- from the catalog and never from two ways of adding it up.
    local alternates = {};

    for index, plan in ipairs(catalog.altPlans or {}) do
        local rows  = (catalog.altLevels or {})[index];
        local entry = { plan = plan, casts = 0, gil = 0, earn = 0, tops = {} };

        for level = catalog.altBand[1], catalog.altBand[2] - 1 do
            local row = rows and rows[level + 1];

            if (row ~= nil) then
                local quads = row[3];
                local rate  = 0.0;
                local top, topShare = nil, -1;

                for at = 1, #quads, 4 do
                    local numerator = numeratorAt(level, quads[at + 1], multiplier) or 0;

                    rate = rate + quads[at + 2] * math.min(1.0, numerator / skillRoll(level)) * quads[at + 3];

                    if (quads[at + 2] > topShare) then
                        top, topShare = quads[at], quads[at + 2];
                    end
                end

                local casts = (rate > 0) and (points / rate) or 0;

                entry.casts = entry.casts + casts;
                entry.gil   = entry.gil + casts * row[1];
                entry.earn  = entry.earn + casts * row[2];

                if (top ~= nil) then
                    entry.tops[top] = (entry.tops[top] or 0) + 1;
                end
            end
        end

        local best, bestCount = nil, -1;

        for id, count in pairs(entry.tops) do
            if (count > bestCount) then
                best, bestCount = id, count;
            end
        end

        entry.top = best;
        entry.kit = (catalog.prices[plan[3]] and catalog.prices[plan[3]][1] or 0)
            + ((plan[4] == 1 and catalog.prices[plan[2]]) and catalog.prices[plan[2]][1] or 0);

        -- The row, formatted once, for the reason the segments above are.
        local spot = catalog.spots[plan[1]];

        entry.where    = string.format('%s - %s', zoneName(spot), spot.areaName);
        entry.rodText  = gearName(catalog.rodById, plan[3]);
        entry.baitText = gearName(catalog.baitById, plan[2]);
        entry.rodBuy   = 'Buy here: ' .. itemLine(plan[3]);
        entry.baitBuy  = 'Buy here: ' .. itemLine(plan[2]);
        entry.castText = commaNumber(entry.casts);
        entry.gilText  = commaNumber(entry.kit + entry.gil);
        entry.topName  = (best ~= nil and catalog.fishById[best] ~= nil)
            and catalog.fishById[best].name or nil;

        table.insert(alternates, entry);
    end

    route = {
        multiplier = multiplier,
        segments   = segments,
        alternates = alternates,
        castsFrom  = castsFrom,
        casts      = totals.casts,
        gil        = totals.gil,
        earn       = totals.earn,
        kit        = kit,

        -- The two sentences above the table, for the reason every cell in it
        -- is precomputed: they are the same three numbers until the server
        -- names a different multiplier.
        summary    = string.format('%d moves, about %s casts, %s gil of rods and bait.',
            #segments, commaNumber(totals.casts), commaNumber(kit + totals.gil)),
        payback    = (totals.earn > kit + totals.gil) and string.format(
            'What you land on the way is worth about %s gil, so the route pays for itself many times over.',
            commaNumber(totals.earn)) or nil,
    };
end

-- The rank gate a level sits under, and the fish that lifts it.
-- KEYED ON RANK, THE WAY THE SERVER DOES IT (fishing_core.lua, `row[1] ==
-- rank + 1`). This took a SKILL LEVEL and returned the first row whose
-- threshold was above it, which is a different question with a different
-- answer: rank and skill are independent, and the whole point of this panel is
-- the player whose skill has stopped because their RANK caps it. At the cap
-- the two even disagree by a whole rung -- a rank 5 fisherman sits at skill 60,
-- and `60 < row[2]` first succeeds on rank 7's row, so the window named the
-- wrong rank, the wrong test fish, and told them to buy it.
--
-- The `< threshold` form also dropped the top rung entirely: nothing is above
-- 100, so a rank 9 fisherman at the cap was told there was no rung left.
local function rankAt(rank)
    if (catalog == nil or catalog.ranks == nil) then
        return nil;
    end

    for _, row in ipairs(catalog.ranks) do
        if (row[1] == (rank or 0) + 1) then
            return row;
        end
    end

    return nil;
end

-----------------------------------------------------------------------------
-- Rendering
-----------------------------------------------------------------------------
--[[
* THE LAUNCHER'S PALETTE, NOT THIS FILE'S OWN.
*
* These were four hard-coded RGBA literals -- the one Driftwood window that
* painted itself instead of wearing the theme, so on Shoreline (the light one)
* its greens and greys were chosen against a dark ground that was not there.
* dwtheme builds its palette at require time and thereafter rewrites the
* CONTENTS of these tables in place, never their identity (its own header says
* so), which is exactly why a reference taken here follows a theme change the
* player makes mid-session. Every sibling window does it this way.
* (2026-09-06.)
--]]
local COL_GOOD = theme.colors.ok;
local COL_WARN = theme.colors.warn;
local COL_BAD  = theme.colors.err;
local COL_DIM  = theme.colors.dim;

local function textColored(color, text)
    imgui.TextColored(color, text);
end

local function helpMarker(text)
    imgui.SameLine();
    imgui.TextDisabled('(?)');

    if (imgui.IsItemHovered()) then
        imgui.BeginTooltip();
        imgui.PushTextWrapPos(imgui.GetFontSize() * 28.0);
        imgui.TextUnformatted(text);
        imgui.PopTextWrapPos();
        imgui.EndTooltip();
    end
end

--[[
* THE ONE-LINE TIPS, AS DATA.
*
* Kept in a table rather than inline so the harness can assert that a control
* still explains itself after somebody moves it, and so the wording of the
* whole window can be read in one place. `helpMarker` takes long paragraphs and
* is used where a sentence needs room; these are the short ones that hang off a
* control.
*
* NO LITERAL PER-CENT SIGNS IN ANY OF THEM. ImGui's own SetTooltip is a
* printf-style call and what Ashita's binding does with a stray `%` is not
* something this file has any way to test -- no addon in the suite has ever
* passed one, so there is no precedent either. Text and TextColored are known
* safe (the ladder has drawn "100%" through them since the first release), so
* where a percentage has to appear it does, and where a tooltip has to say one
* it says it in words.
--]]
local TIPS = {
    refresh    = 'Ask the server again for your skill, your rank cap, where you are standing '
              .. 'and what is on your rod. Everything else in this window is local and never goes stale.',
    refreshWait = 'Already asking. One chat line goes out at a time, and the answer usually '
              .. 'lands within a second or two.',
    copyRoute  = 'Copy the whole plan to the clipboard as plain text -- one line per stretch, '
              .. 'with where to stand, what to hold and how many casts.',
    follow     = 'Snap the plan back to your real skill and let it follow you again. '
              .. 'Dragging the slider pins it where you put it.',
    followOff  = 'The plan is already following your skill. Drag the slider to pin it somewhere else.',
    slider     = 'Plan for any level, not only the one you are on -- what to catch next at 30, '
              .. 'or what the last stretch will want. It follows your skill until you drag it.',
    searchFish = 'Type any part of a name. Sorted by the skill each one wants, lowest first.',
    searchSpot = 'Type a zone or an area name. Your own zone is listed first while the box is empty.',
    searchMob  = 'Type any part of a monster or zone name.',
    hideJunk   = 'Fold away the items -- buckets, kelp, logs. They teach no skill at all, '
              .. 'and there are enough of them to bury the fish.',
    whereIAm   = 'Show only the fishing areas in the zone you are standing in.',
    whereIAmWait = 'The server has not said where you are yet. It answers on a zone line and '
              .. 'whenever this window is opened.',
    mobHere    = 'This one can be hooked in the zone you are standing in right now.',
    yourBait   = 'The bait on your line has an affinity row for this one, so it can hook it at all. '
              .. 'Junk ignores affinity and is drawn on whatever you are holding.',
    junkBadge  = 'An item, not a fish. It teaches no skill at all, however often you hook it.',
    legendary  = 'Legendary fish: rods treat it differently (bonus attack and time on a legendary rod).',
    rarity     = 'The weight the engine multiplies this catch\'s hook chance by, stated against a '
              .. 'common fish. It is a weighted draw from the pool, never a roll per fish.',
    equipped   = 'The rod rides the ranged slot and the bait rides the ammo slot -- the only two '
              .. 'the fishing engine reads. Either one empty and a cast does nothing.',
    snaps      = 'This stretch plans with a rod that can break. Losing it costs a walk back to a '
              .. 'shop, which no cast count here prices.',
    guildTest  = 'A guild rank test falls inside this stretch. Your skill stops dead at the cap '
              .. 'until you take it, and nothing in the game says so.',
    teachesYes = 'Green because this one is inside your skill-up window right now: above your '
              .. 'level and within fifty of it. Landing it teaches you something.',
    teachesNo  = 'Not green: this one is at or below your level, or more than fifty above it, so '
              .. 'landing it teaches nothing at all. It may still be worth catching.',
    synced     = 'How long ago the server last told this window where you stand. The catalog below '
              .. 'is local and always current; only these four facts age.',
};

--[[
* The long-form help behind each `(?)`, as data.
*
* Every one of these is three to five string concatenations, and Lua builds a
* concatenation when it is EVALUATED, not when it is written -- so each of them
* was allocating a few hundred bytes sixty times a second whether or not
* anybody was hovering the marker it belongs to. Constant text belongs in a
* constant. (The Next tab's roll help is the one that genuinely varies; it has
* its own per-level cache below.)
--]]
local HELP = {
    rankCap = 'Nothing in the game states the cap or the reason, which is why this '
        .. 'is the commonest way a fisherman gets stuck: the number simply stops moving '
        .. 'and no message explains it.',
    plan = 'Chosen by gil first and casts second -- cheapest, as asked -- and it may never '
        .. 'buy what it has not already caught, so it opens with the cheapest rod in the game and '
        .. 'upgrades once the fishing has paid for it. Casts are whole casts, hooked or not, at '
        .. 'this server\'s skill-up rate, averaged over every hour, moon and month.',
    hardCap = 'Fishing skill is hard-capped by your guild RANK at (rank + 1) x 10 '
        .. '(fishingutils.cpp, FishingSkillup). Take the Fishermen\'s Guild rank test to lift it. '
        .. 'Nothing in the game states this cap, which is why you can fish for a week without moving.',
    fishList = 'Every fish this server can actually give you. Fish the engine refuses to load '
        .. '(disabled, or ranking 99+) are not in this list, because they are not in the game.',
    rods = 'A rod whose size does not match the fish costs you hook chance '
        .. '(3 points for a small fish on a big rod, 5 for a big fish on a small one), and a rod '
        .. 'whose max rank sits under the fish\'s ranking is the one that snaps.',
    baits = 'Bait affinity is a HARD gate: a bait can only ever hook fish it has an '
        .. 'affinity row for. Power 3 is worth +80 hook chance for bait and +75 for a lure, '
        .. 'power 1 only +35 / +30 -- so the right bait matters more than anything else you carry.',
};

-- The saturation note names the peak, which comes off the catalog, so it is
-- built on first sight rather than written as a literal.
local saturationHelp = nil;

local function saturationText()
    if (saturationHelp == nil) then
        saturationHelp = 'When every target in the window is certain, the peak at +'
            .. tostring(catalog and catalog.engine.skillupPeak or 11) .. ' buys you nothing. What is '
            .. 'left is how quickly you can land anything above your level at all -- which is what '
            .. 'the Route tab optimises, and why it does not simply send you at the biggest fish '
            .. 'you can hook.';
    end

    return saturationHelp;
end

-- The Next tab's long help, which quotes the ROLL for the level being planned
-- and so cannot be a constant. Built once per level: it is nearly four hundred
-- characters of concatenation and it was rebuilt sixty times a second whether
-- or not anybody was hovering it.
local ladderHelpCache = {};

local function ladderHelp(level)
    local text = ladderHelpCache[level];

    if (text == nil) then
        text = 'The curve peaks at exactly +' .. tostring(catalog and catalog.engine.skillupPeak or 11) ..
            ' levels above you -- not at the hardest thing you can land. A catch AT or BELOW your ' ..
            'level teaches nothing at all, and neither do items or monsters, however big.\n\n' ..
            'Per catch is a REAL probability: the engine rolls the curve against ' ..
            string.format('%d', skillRoll(level)) .. ' at this level, not against 100. ' ..
            'Rows are ordered by the engine\'s own preference, so when the whole column reads 100% ' ..
            'they are still listed best-first.';

        ladderHelpCache[level] = text;
    end

    return text;
end

--[[
* A HEADER ROW SUBMITTED COLUMN BY COLUMN, so each column can carry the
* sentence its one-word label cannot.
*
* This is imgui's own custom-header shape -- TableNextRow with the Headers row
* flag, then TableHeader per column -- and it draws exactly what the one-call
* TableHeadersRow it replaces drew. What that call could not do was leave
* anywhere to hang a tooltip, and this window is almost entirely tables whose
* headers are one word each: "Mostly", "For", "Rank band", "Hooks", "Lost on
* use" and "Per catch" all mean something precise here and nothing obvious
* anywhere else.
*
* The columns are module data rather than eight inline runs of
* TableSetupColumn, so the weights and the wording live in one place, nothing
* is rebuilt sixty times a second, and the harness can read them.
--]]
local function setupColumns(columns)
    for _, column in ipairs(columns) do
        imgui.TableSetupColumn(column.label, ImGuiTableColumnFlags_WidthStretch, column.weight);
    end
end

local function headerRow(columns)
    -- The one-call row on an install that has no TableHeader: the same labels,
    -- without the sentences behind them.
    if (not CAN_HEADER_TIPS) then
        imgui.TableHeadersRow();

        return;
    end

    imgui.TableNextRow(ImGuiTableRowFlags_Headers);

    for index, column in ipairs(columns) do
        imgui.TableSetColumnIndex(index - 1);
        imgui.TableHeader(column.label);

        if (column.tip ~= nil and imgui.IsItemHovered()) then
            imgui.SetTooltip(column.tip);
        end
    end
end

local ROUTE_COLUMNS = {
    { label = 'Skill',  weight = 0.55, tip = 'The skill band this stretch covers. Move on when your skill reaches the second number.' },
    { label = 'Where',  weight = 2.0,  tip = 'The zone and the fishing area to stand in. The area matters: each one draws from its own pool.' },
    { label = 'Rod',    weight = 1.3,  tip = 'Highlighted on the stretch where you buy it, dim while you are still carrying it.' },
    { label = 'Bait',   weight = 1.1,  tip = 'Highlighted on the stretch where you buy it. Most bait is eaten one per cast; a lure is bought once.' },
    { label = 'Mostly', weight = 1.1,  tip = 'The catch that supplies most of the skill here -- what this stretch will feel like.' },
    { label = 'Casts',  weight = 0.6,  tip = 'Whole casts, hooked or not, at this server\'s own skill-up rate, averaged over every hour, moon and month.' },
    { label = 'Gil',    weight = 0.7,  tip = 'What the bait for this stretch costs. Rods are counted once, in the total above the table.' },
};

local ALT_COLUMNS = {
    { label = 'Where',  weight = 2.0,  tip = 'Somewhere else to fish the opening band, for a character who cannot reach the first two.' },
    { label = 'Rod',    weight = 1.3,  tip = 'The rod this opening wants, and where to buy it.' },
    { label = 'Bait',   weight = 1.1,  tip = 'The bait this opening wants, and where to buy it.' },
    { label = 'Mostly', weight = 1.1,  tip = 'The catch that supplies most of the skill in this opening.' },
    { label = 'Casts',  weight = 0.6,  tip = 'Casts to cross the whole band from here, at this server\'s rate.' },
    { label = 'Gil',    weight = 0.7,  tip = 'The kit and the bait together, for the whole band.' },
};

local LADDER_COLUMNS = {
    { label = 'Fish',            weight = 1.4, tip = 'Hover a row for its description, the rods that carry it and every pool it swims in.' },
    { label = 'Skill',           weight = 0.6, tip = 'The skill the fish wants, and how far above you it is. The curve peaks at eleven above.' },
    { label = 'Per catch',       weight = 0.8, tip = 'The real chance of a skill-up per catch LANDED, already scaled by this server\'s multiplier. Losing the fish teaches nothing.' },
    { label = 'Bait that works', weight = 2.0, tip = 'Every bait with an affinity row for it, best first. Anything not listed can never hook it.' },
    { label = 'Where',           weight = 2.2, tip = 'The fishing areas whose pool holds it.' },
};

local FISH_COLUMNS = {
    { label = 'Fish',         weight = 1.3, tip = 'Hover a row for its description, the rods that carry it and every pool it swims in.' },
    { label = 'Skill',        weight = 0.5, tip = 'The skill the fish wants. Being under it is a penalty on the bite, never a wall. Green means it is inside your skill-up window right now.' },
    { label = 'Size / water', weight = 0.9, tip = 'A rod of the wrong size costs hook chance; the water decides which pools can hold it.' },
    { label = 'Bait',         weight = 1.8, tip = 'The strongest baits with an affinity row for it. Affinity is a hard gate.' },
    { label = 'Where',        weight = 1.8, tip = 'The fishing areas whose pool holds it.' },
    { label = 'When',         weight = 1.1, tip = 'The hours and moons the engine weights highest for it. Both are multipliers on the bite, not switches.' },
};

local SPOTFISH_COLUMNS = {
    { label = 'Catch',  weight = 1.3, tip = 'Everything this area\'s pool can give you, junk included, ordered by the skill it wants.' },
    { label = 'Skill',  weight = 0.5, tip = 'The skill it wants. A fish up to a hundred above you still enters the pool. Green means it would teach you something right now.' },
    { label = 'Rarity', weight = 0.7, tip = 'The weight the engine multiplies its hook chance by, against a common fish.' },
    { label = 'Bait',   weight = 2.0, tip = 'The strongest baits with an affinity row for it.' },
};

local ROD_COLUMNS = {
    { label = 'Rod',        weight = 1.4, tip = 'Every rod the engine loads.' },
    { label = 'For',        weight = 0.6, tip = 'The fish size this rod is built for. The wrong size costs three hook points for a small fish, five for a large one.' },
    { label = 'Rank band',  weight = 0.8, tip = 'The fish rankings this rod handles. A rod whose top rank sits under the fish is the one that snaps.' },
    { label = 'Attack',     weight = 0.6, tip = 'How hard it pulls in the reel-in. Higher lands a fighting fish sooner.' },
    { label = 'Time',       weight = 0.6, tip = 'How long it can keep the fight going before the line gives.' },
    { label = 'Notes',      weight = 1.4, tip = 'Legendary rods pay no size penalty; an unbreakable rod cannot snap on you.' },
};

local BAIT_COLUMNS = {
    { label = 'Bait',             weight = 1.4, tip = 'Every bait and lure the engine loads.' },
    { label = 'Type',             weight = 0.6, tip = 'Bait is eaten as you fish; a lure is kept. Special is neither.' },
    { label = 'Hooks',            weight = 0.6, tip = 'How many catches it can hold at once -- the engine\'s max hook count for this bait.' },
    { label = 'Lost on use',      weight = 0.7, tip = 'Whether the engine can take it off your line on a failed catch.' },
    { label = 'Fish it can hook', weight = 2.2, tip = 'How many catches it has an affinity row for. Hover the number for the list.' },
};

--[[
* THE HOVER CARD FOR A FISH: the client's own words about it, and the four
* things the client does not know -- what can hook it, what will not lose it,
* where it swims and when it bites.
*
* THE RODS ARE THE PART THAT WAS OWED. `rodsFor` has been in this file since
* the addon shipped and nothing has ever called it, so "the rods that will not
* lose it" -- which is what the README row promises, and what this file's own
* opening paragraph promises -- was the one claim the window drew nowhere. A
* rod whose top rank sits under the fish's ranking is the rod that snaps, and
* no other tab says which those are for a given fish. (2026-09-06.)
--]]
local function fishCard(fish)
    local view = fishView(fish);

    imgui.BeginTooltip();
    imgui.PushTextWrapPos(imgui.GetFontSize() * 30.0);

    imgui.Text(fish.name);
    textColored(COL_DIM, string.format('skill %d, %s, %s',
        fish.skill, view.sizeWater, view.rarity));

    local desc = itemDesc(fish.id);

    if (desc ~= nil) then
        imgui.TextWrapped(desc);
    end

    imgui.Separator();
    imgui.Text('Bait: ' .. view.bait6);
    imgui.Text('Rods that will not lose it: ' .. view.rodText);
    imgui.Text('Where: ' .. view.where4);
    imgui.Text('When: ' .. view.when);

    if (view.month ~= nil) then
        imgui.Text('Month: ' .. view.month);
    end

    imgui.PopTextWrapPos();
    imgui.EndTooltip();
end

-- The rod and bait reference rows, formatted once. Twenty and thirty-nine
-- rows of numbers that never move; they were re-formatted on every frame the
-- section was open.
local rodViews = {};

local function rodView(rod)
    local view = rodViews[rod.id];

    if (view ~= nil) then
        return view;
    end

    local notes = {};

    if (rod.legendary == 1) then
        table.insert(notes, 'legendary (no size penalty)');
    end

    if (rod.breakable == 0) then
        table.insert(notes, 'unbreakable');
    end

    view = {
        size   = SIZE_WORD[rod.size] or '?',
        band   = string.format('%d - %d', rod.minRank, rod.maxRank),
        attack = tostring(rod.attack),
        time   = tostring(rod.time),
        notes  = (#notes > 0) and table.concat(notes, ', ') or '',
    };

    rodViews[rod.id] = view;

    return view;
end

local baitViews = {};

local function baitView(bait)
    local view = baitViews[bait.id];

    if (view ~= nil) then
        return view;
    end

    -- math.floor, not a bare division: an odd affinity list would make this a
    -- fraction, and string.format('%d') RAISES on one rather than truncating.
    local flat  = (catalog ~= nil) and catalog.baitFish[bait.id] or nil;
    local count = (flat ~= nil) and math.floor(#flat / 2) or 0;

    view = {
        kind    = BAIT_WORD[bait.type] or '?',
        hooks   = tostring(bait.maxhook),
        losable = (bait.losable == 1) and 'yes' or 'no',
        count   = count,
        kinds   = string.format('%d kinds', count),
    };

    baitViews[bait.id] = view;

    return view;
end

-- The client's own card for an item this window names -- a rod, a bait, a
-- piece of fishing gear. The description is the client's DAT text; the note
-- under it is ours (where a shop sells it, what the engine does with it).
local function itemCard(itemId, title, note)
    imgui.BeginTooltip();
    imgui.PushTextWrapPos(imgui.GetFontSize() * 30.0);

    imgui.Text(title or itemName(itemId) or '');

    local desc = itemDesc(itemId);

    if (desc ~= nil) then
        imgui.TextWrapped(desc);
    else
        imgui.TextDisabled('(no description in the client\'s item data)');
    end

    if (note ~= nil) then
        imgui.Separator();
        imgui.TextWrapped(note);
    end

    imgui.PopTextWrapPos();
    imgui.EndTooltip();
end

-- The same card for a bait: how many catches it can hook, and which. The
-- catalog has carried `baitFish` since the first release and the Gear tab drew
-- only the COUNT, so the one question a bait row raises -- "hook what?" -- had
-- no answer anywhere in the window. Built on demand and kept, because it is a
-- fixed list of names.
local baitFishText = {};

local function baitCard(bait)
    local text = baitFishText[bait.id];

    if (text == nil) then
        local flat  = (catalog ~= nil) and catalog.baitFish[bait.id] or nil;
        local names = {};

        for index = 1, (flat ~= nil) and #flat or 0, 2 do
            local fish = catalog.fishById[flat[index]];

            if (fish ~= nil and #names < 14) then
                table.insert(names, string.format('%s (p%d)', fish.name, flat[index + 1]));
            end
        end

        local total = (flat ~= nil) and math.floor(#flat / 2) or 0;

        if (total > #names) then
            table.insert(names, string.format('and %d more', total - #names));
        end

        text = (#names > 0) and table.concat(names, ', ')
            or 'nothing in this catalog has an affinity row for it';
        baitFishText[bait.id] = text;
    end

    imgui.BeginTooltip();
    imgui.PushTextWrapPos(imgui.GetFontSize() * 30.0);
    imgui.Text(bait.name);

    local desc = itemDesc(bait.id);

    if (desc ~= nil) then
        imgui.TextWrapped(desc);
    end

    imgui.Separator();
    imgui.TextWrapped('Hooks: ' .. text);
    imgui.PopTextWrapPos();
    imgui.EndTooltip();
end

local MOB_COLUMNS = {
    { label = 'Monster',       weight = 1.3, tip = 'Hooks like a catch and then fights you. None of them teach any fishing skill.' },
    { label = 'Zone',          weight = 1.4, tip = 'Where it can be hooked. Green is the zone you are standing in.' },
    { label = 'Level',         weight = 0.5, tip = 'The level it fights at once it is on the shore with you.' },
    { label = 'NM',            weight = 0.4, tip = 'A notorious monster: one at a time, and worth being ready for.' },
    { label = 'Bait it needs', weight = 1.6, tip = 'Many of these appear on one bait only and on nothing else, however long you fish.' },
};

-----------------------------------------------------------------------------
-- Tab: Route -- the whole thing, 0 to the ceiling
--
-- THIS IS THE TAB THE OTHER SIX WERE MISSING. Everything else here answers a
-- question you already knew to ask; this one answers "I have never fished, what
-- do I do", and it answers it as an itinerary: buy this, stand here, and when
-- the number reaches N, move. The optimisation is the generator's (it minimises
-- gil and breaks ties on casts, and it may never buy what the route has not
-- already caught) -- everything below draws its result at this box's rate.
-----------------------------------------------------------------------------
local function segmentAt(level)
    for _, segment in ipairs(route.segments) do
        if (level >= segment.from and level < segment.to) then
            return segment;
        end
    end

    return nil;
end

--[[
* The whole plan as plain text, for the clipboard. Built on demand -- nobody
* presses this every frame -- and out of the same precomputed cells the table
* draws, so the copy cannot say something the window does not.
--]]
local function routeText()
    local lines = {
        string.format('DriftwoodXI fishing route -- %d moves, about %s casts, %s gil of rods and bait.',
            #route.segments, commaNumber(route.casts), commaNumber(route.kit + route.gil)),
    };

    for _, segment in ipairs(route.segments) do
        table.insert(lines, string.format('%s  %s  --  %s + %s  (about %s casts)',
            segment.range, segment.where, segment.rodText, segment.baitText, segment.castText));

        for _, test in ipairs(segment.tests) do
            table.insert(lines, '        ' .. test);
        end
    end

    table.insert(lines, 'It does not know what you can reach: some water needs travel, an expansion or a quest.');

    return table.concat(lines, '\n');
end

-- The alternate openers' three fixed sentences. They quote the band's own two
-- numbers and nothing else, so they are built on first sight and kept -- all
-- three were being rebuilt every frame, folded or not.
local altWordCache = nil;

local function altWords()
    if (altWordCache ~= nil) then
        return altWordCache;
    end

    local title = string.format('Cannot reach the first two? Other places to fish %d-%d',
        catalog.altBand[1], catalog.altBand[2]);

    altWordCache = {
        title  = title,
        header = title .. '###dwfishing_alts',
        blurb  = string.format(
            'The same %d levels, somewhere else, costed the same way. The route above is the ' ..
            'cheapest this server\'s own numbers allow; these are what it looks like if you ' ..
            'start where you already are.', catalog.altBand[2] - catalog.altBand[1]),
        after  = string.format('After %d the route above is the same wherever you started.',
            catalog.altBand[2]),
    };

    return altWordCache;
end

local function tabRoute()
    if (catalog == nil or catalog.levels == nil) then
        return;
    end

    buildRoute();

    if (#route.segments == 0) then
        textColored(COL_BAD, 'This catalog carries no route.');

        return;
    end

    if (state.level == nil) then
        textColored(COL_DIM, 'Waiting for the server to say where you stand -- the plan below is the whole route.');
    end

    local level = state.level or 0;
    local here  = segmentAt(level);

    -- ---- where you are, right now -------------------------------------
    if (state.level ~= nil) then
        imgui.Text(string.format('Fishing skill %.1f', (state.rawSkill or 0) / 10));
        imgui.SameLine();
        textColored(COL_DIM, string.format('| rank %d, capped at %d | %d of %d done',
            state.rank or 0, state.rankCap or 0, level, catalog.engine.maxLevel));

        if (level >= (state.rankCap or 0)) then
            local gate = rankAt(state.rank or 0);

            -- THE TOP OF THE LADDER IS NOT THE SAME NEWS AS BEING STUCK ON IT.
            -- A fisherman at the ceiling has no rung left to take, and the red
            -- "nothing you catch will move the number" with no follow-up read
            -- as a fault report about the one state that is a finished job.
            -- The typed tier has always said this ("You are at the top of the
            -- guild ladder"); the window said nothing at all.
            if (gate == nil) then
                textColored(COL_GOOD, string.format(
                    'You are at the top of the guild ladder, at this server\'s fishing ceiling of %d. Nothing lifts it further.',
                    catalog.engine.maxLevel));
            else
                textColored(COL_BAD, 'You are AT your rank cap. Nothing you catch will move the number.');
            end

            if (gate ~= nil and catalog.rankTest ~= nil) then
                local fish = catalog.fishById[gate[3]];

                -- gate[2] is the skill the test is TAKEN at, which for the next
                -- rung is the cap you are stuck at right now -- so printing it
                -- as the new cap said "that lifts you to Craftsman, cap 60" to
                -- somebody already capped at 60. The cap a rung grants is one
                -- step above the skill it is tested at.
                textColored(COL_WARN, string.format('Catch a %s and trade it to %s in %s -- that lifts you to %s, cap %d.',
                    (fish ~= nil) and fish.name or itemName(gate[3]),
                    catalog.rankTest.npc, catalog.rankTest.zone, gate[4],
                    gate[2] + catalog.rankTest.capStep));
                imgui.SameLine();
                helpMarker(HELP.rankCap);

                -- Not a tooltip. A player who is stuck is the one person who
                -- most needs to know they do not have to grind to the exact cap
                -- first, and a fact you have to hover to find is a fact most
                -- people never read.
                textColored(COL_DIM, string.format(
                    '   The guild lets you test from skill %d, not only at %d.%s',
                    gate[2] - catalog.rankTest.tolerance, gate[2],
                    (gate[1] == catalog.rankTest.lastRank and catalog.rankTest.expertKey)
                        and ' That last rung also wants the guild key item and the quest behind it.' or ''));

                if (catalog.prices[gate[3]] ~= nil) then
                    textColored(COL_DIM, string.format('   (or just buy one: %s)', itemLine(gate[3])));
                end
            end
        elseif (here ~= nil) then
            textColored(COL_GOOD, string.format('Right now: %s, %s + %s.',
                here.where, here.rodText, here.baitText));
            imgui.Text(here.rodLine);
            imgui.Text(here.baitLine);

            if (here.topName ~= nil) then
                imgui.Text(string.format('   Most of your skill here comes from %s.', here.topName));
            end

            textColored(COL_DIM, string.format('   Stay until %d, about %d more casts.',
                here.to, math.max(0, math.floor((route.castsFrom[level] or 0) + 0.5))));
            textColored(COL_DIM, string.format('   About %s casts from here to %d, all told.',
                commaNumber((route.castsFrom[level] or 0) + (here.afterCasts or 0)),
                catalog.engine.maxLevel));
        end

        imgui.Separator();
    end

    -- ---- the whole plan -----------------------------------------------
    imgui.Text(route.summary);
    imgui.SameLine();
    helpMarker(HELP.plan);

    -- On the SUMMARY's line, not the payback sentence's. A SameLine here after
    -- the payback line would hang the button off the end of a sentence that
    -- runs most of the window's width, and at the 620px floor that is a button
    -- past the right edge.
    if (CAN_CLIPBOARD) then
        imgui.SameLine();

        if (imgui.SmallButton('Copy##dwfishing_route_copy')) then
            imgui.SetClipboardText(routeText());
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.copyRoute);
        end
    end

    if (route.payback ~= nil) then
        textColored(COL_GOOD, route.payback);
    end

    -- NO ScrollY ON THIS TABLE, AND THAT IS THE FIX RATHER THAN AN OVERSIGHT.
    -- A scrolling table with no outer size takes ALL the remaining height of
    -- whatever it is drawn in (imgui's CalcItemSize against a zero outer_size),
    -- so these eight rows were followed by a wall of empty table -- and the
    -- alternate openers under it, and the whole disclaimer under those, were
    -- laid out past the bottom edge of a window whose flags say NoScrollbar.
    -- The tab body is the scroll region now (renderWindow's child, dwquest's
    -- shape) and this table draws at its own height inside it. (2026-09-06.)
    if (imgui.BeginTable('##dwfishing_route', #ROUTE_COLUMNS,
        bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg,
                ImGuiTableFlags_SizingStretchProp))) then
        setupColumns(ROUTE_COLUMNS);
        headerRow(ROUTE_COLUMNS);

        local carried = {};

        for _, segment in ipairs(route.segments) do
            local mine = (segment == here);

            imgui.TableNextRow();

            imgui.TableNextColumn();
            if (mine) then
                textColored(COL_GOOD, segment.range);
            else
                imgui.Text(segment.range);
            end

            imgui.TableNextColumn();
            imgui.Text(segment.where);

            -- A rank test falls inside this stretch: say so where the player is
            -- looking, because arriving at the cap with no idea why is the
            -- failure this whole feature exists to prevent.
            for _, test in ipairs(segment.tests) do
                textColored(COL_WARN, test);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.guildTest);
                end
            end

            imgui.TableNextColumn();
            if (carried.rod ~= segment.rodId) then
                textColored(COL_WARN, segment.rodText);
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(segment.rodBuy);
                end
                carried.rod = segment.rodId;
            else
                textColored(COL_DIM, segment.rodText);
            end

            -- A rod that snaps is a rod you have to walk back for, and no table
            -- here knows what that is worth -- so it is stated, not priced.
            if (segment.snaps ~= nil) then
                textColored(COL_BAD, segment.snaps);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.snaps);
                end
            end

            imgui.TableNextColumn();
            if (carried.bait ~= segment.baitId) then
                textColored(COL_WARN, segment.baitText);
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(segment.baitBuy);
                end
                carried.bait = segment.baitId;
            else
                textColored(COL_DIM, segment.baitText);
            end

            imgui.TableNextColumn();
            if (segment.topName ~= nil) then
                imgui.Text(segment.topName);
            end

            imgui.TableNextColumn();
            imgui.Text(segment.castText);

            imgui.TableNextColumn();
            imgui.Text(segment.gilText);
        end

        imgui.EndTable();
    end

    -- ---- somewhere else to start -------------------------------------
    --
    -- THE OPENING IS THE ONE PICK THE OPTIMISER IS LEAST QUALIFIED TO MAKE. It
    -- ranks every water in the game and knows nothing about which of them you
    -- can walk to, and the character least likely to own an airship pass or an
    -- expansion is the one at skill 0. So the first stretch is offered as a
    -- CHOICE: the best plan in each of several other places, over the same
    -- levels, costed the same way. Every one of them is a real answer -- pick
    -- the one you can get to.
    if (#route.alternates > 0 and catalog.altBand ~= nil) then
        imgui.Separator();

        -- Unfolded where it matters. A player still inside the band is the one
        -- this list exists for and should not have to go looking for it; past
        -- it, it is history and folds away.
        local inBand = (state.level == nil) or (state.level < catalog.altBand[2]);
        local words  = altWords();

        if (inBand) then
            textColored(COL_WARN, words.title);
        end

        if (inBand or imgui.CollapsingHeader(words.header)) then
            imgui.TextWrapped(words.blurb);

            if (imgui.BeginTable('##dwfishing_route_alts', #ALT_COLUMNS,
                bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg,
                        ImGuiTableFlags_SizingStretchProp))) then
                setupColumns(ALT_COLUMNS);
                headerRow(ALT_COLUMNS);

                for _, entry in ipairs(route.alternates) do
                    imgui.TableNextRow();

                    imgui.TableNextColumn();
                    imgui.Text(entry.where);

                    imgui.TableNextColumn();
                    imgui.Text(entry.rodText);
                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(entry.rodBuy);
                    end

                    imgui.TableNextColumn();
                    imgui.Text(entry.baitText);
                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(entry.baitBuy);
                    end

                    imgui.TableNextColumn();
                    if (entry.topName ~= nil) then
                        imgui.Text(entry.topName);
                    end

                    imgui.TableNextColumn();
                    imgui.Text(entry.castText);

                    imgui.TableNextColumn();
                    imgui.Text(entry.gilText);
                end

                imgui.EndTable();
            end

            textColored(COL_DIM, words.after);
        end
    end

    imgui.Separator();
    imgui.TextWrapped(
        'THIS ROUTE DOES NOT KNOW WHAT YOU CAN REACH. Nothing in the server\'s data records zone ' ..
        'access, so a stretch may name water that needs travel, an expansion or a quest you do not ' ..
        'have. It also plans only with bait you can BUY -- several of the best baits are crafted or ' ..
        'fished, and the Fish tab lists every bait that hooks a given fish, not just the bought ones. ' ..
        'Weather, fishing gear, pool depletion and how well you play the reel-in are not modelled.');
end

-----------------------------------------------------------------------------
-- Tab: Next -- the 0..110 ladder
-----------------------------------------------------------------------------
local function tabNext()
    if (state.level == nil) then
        imgui.TextWrapped('Waiting for the server to say where you stand...');

        return;
    end

    imgui.Text(string.format('Fishing skill %.1f', (state.rawSkill or 0) / 10));
    imgui.SameLine();
    textColored(COL_DIM, string.format('| rank %d, capped at %d', state.rank or 0, state.rankCap or 0));

    -- THE THING NOTHING ELSE IN THE GAME TELLS YOU. Rank hard-caps skill at
    -- (rank + 1) * 10; at the cap no catch of any kind moves the number, and
    -- the game reports neither the cap nor the reason.
    if ((state.level or 0) >= (state.rankCap or 0)) then
        -- The ceiling and the cap are the same test and different news, the
        -- distinction the Route tab draws one tab over: there is no rung above
        -- the last one, so telling a finished fisherman to go and take the
        -- guild test is sending them to an NPC with nothing to say.
        if (rankAt(state.rank or 0) == nil) then
            textColored(COL_GOOD, 'You are at the top of the guild ladder. Nothing raises the cap further.');
        else
            textColored(COL_BAD, 'You are AT your rank cap. No catch will raise your skill.');
            imgui.SameLine();
            helpMarker(HELP.hardCap);
        end
    end

    if (state.multiplier ~= nil) then
        local word = (state.multiplier == 1.0)
            and 'This server uses the stock skill-up rate (x1).'
            or string.format('This server multiplies fishing skill-ups by %g (stock is x1).', state.multiplier);

        textColored(state.multiplier > 1.0 and COL_GOOD or COL_DIM, word);
    end

    imgui.Separator();

    imgui.PushItemWidth(220);
    if (imgui.SliderInt('Plan for level', planLevel, 0, catalog and catalog.engine.maxLevel or 110)) then
        planPinned = true;
    end
    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.slider);
    end

    imgui.SameLine();

    -- Left enabled even while it would do nothing: pressing it when the plan is
    -- already following is idempotent, and a disabled item reports no hover at
    -- all, which would take the sentence that explains it away with it.
    if (imgui.Button('Follow my skill')) then
        planPinned   = false;
        planLevel[1] = state.level or 0;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(planPinned and TIPS.follow or TIPS.followOff);
    end

    -- Built once per level rather than once per frame: this string is nearly
    -- four hundred characters of concatenation and it was rebuilt sixty times
    -- a second whether or not anybody was hovering it.
    helpMarker(ladderHelp(planLevel[1]));

    local level  = planLevel[1];
    local ladder = ladderFor(level);

    -- THE THING THE MULTIPLIER ACTUALLY DOES, SAID OUT LOUD. maxChance is rolled
    -- against skillRoll, and once the multiplier pushes it past that the
    -- skill-up stops being a chance at all -- so the +11 peak stops mattering
    -- and what is left is how fast you can land ANYTHING in the window. A player
    -- chasing the peak on this box is optimising a term that has saturated.
    if (#ladder > 0 and ladder[1].chance >= 100) then
        textColored(COL_GOOD, string.format(
            '%d of these %d are a CERTAIN skill-up here -- this server\'s multiplier has saturated the curve.',
            ladder.certain or 0, #ladder));
        imgui.SameLine();
        helpMarker(saturationText());
    end

    if (#ladder == 0) then
        textColored(COL_DIM, 'Nothing in the catalog sits inside the skill-up window for this level.');

        return;
    end

    if (imgui.BeginTable('##dwfishing_ladder', #LADDER_COLUMNS,
        bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY,
                ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupScrollFreeze(0, 1);
        setupColumns(LADDER_COLUMNS);
        headerRow(LADDER_COLUMNS);

        for _, entry in ipairs(ladder) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.Text(entry.fish.name);

            if (imgui.IsItemHovered()) then
                fishCard(entry.fish);
            end

            if (entry.fish.legendary == 1) then
                imgui.SameLine();
                textColored(COL_WARN, '*');
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.legendary);
                end
            end

            imgui.TableNextColumn();
            imgui.Text(entry.skillText);

            imgui.TableNextColumn();
            local color = COL_DIM;

            if (entry.diff >= (catalog.engine.skillupPeak - 2) and entry.diff <= (catalog.engine.skillupPeak + 2)) then
                color = COL_GOOD;
            end

            textColored(color, entry.chanceText);

            imgui.TableNextColumn();
            if (#entry.baits == 0) then
                textColored(COL_BAD, 'no bait hooks this');
            else
                imgui.Text(entry.view.bait3);
            end

            imgui.TableNextColumn();
            if (#entry.spots == 0) then
                textColored(COL_BAD, 'no pool holds it');
            else
                imgui.Text(entry.view.where2);
            end
        end

        imgui.EndTable();
    end
end

-----------------------------------------------------------------------------
-- Tab: Fish
-----------------------------------------------------------------------------
--[[
* THE FISH LIST, FILTERED AND SORTED ONCE PER KEYSTROKE.
*
* Rebuilding it every frame was two lower() allocations per row per frame for a
* list of 128 that changes when somebody types. And it is SORTED BY SKILL now,
* lowest first: the catalog's own order is by fish id, which puts a wall of
* buckets, kelp and logs at the top of a guide whose entire subject is skill,
* and means nothing to anybody.
--]]
-- The cache key is the two fields themselves rather than a string built from
-- them: this is called on every frame and the hit path must not allocate to
-- decide it has nothing to do.
local fishRows = { search = nil, junk = nil, rows = {}, count = '' };

local function fishList()
    local typed  = search[1] or '';
    local noJunk = (config.hideJunk == true);

    if (fishRows.search == typed and fishRows.junk == noJunk) then
        return fishRows.rows;
    end

    local needle = string.lower(typed);
    local rows   = {};

    for _, fish in ipairs(catalog.fish) do
        local junk = (fish.item == 1);

        if ((not junk or not noJunk)
            and (#needle == 0 or string.find(fishView(fish).needle, needle, 1, true) ~= nil)) then
            table.insert(rows, fish);
        end
    end

    table.sort(rows, function (a, b)
        if (a.skill ~= b.skill) then
            return a.skill < b.skill;
        end

        -- Names are unique in the catalog, so this is a strict order: a
        -- comparator that can call two different rows equal both ways is the
        -- one LuaJIT answers with "invalid order function".
        return a.name < b.name;
    end);

    fishRows.search = typed;
    fishRows.junk   = noJunk;
    fishRows.rows   = rows;
    fishRows.count  = string.format('%d of %d', #rows, catalog.counts.fish);

    return rows;
end

local function tabFish()
    if (catalog == nil) then
        return;
    end

    imgui.PushItemWidth(260);
    imgui.InputText('Search fish', search, 64);
    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.searchFish);
    end

    helpMarker(HELP.fishList);

    imgui.SameLine();

    -- Junk outnumbers the fish in whole stretches of the catalog and is
    -- unavoidable rather than interesting, so it folds away -- and the choice
    -- is remembered, because somebody who does not want to see buckets today
    -- does not want to see them tomorrow either.
    --
    -- The widget's table is a module local, not a fresh one per frame: ImGui
    -- writes into it, and dwcon's header explains why the two are kept apart
    -- (config stays flat scalars for the serializer). Re-seeded each frame so
    -- a profile change through the settings callback still reaches the box.
    ui.hideJunk[1] = (config.hideJunk == true);

    if (imgui.Checkbox('Hide junk', ui.hideJunk)) then
        config.hideJunk = ui.hideJunk[1];
        saveConfig();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.hideJunk);
    end

    imgui.SameLine();

    local rows = fishList();

    textColored(COL_DIM, fishRows.count);

    if (#rows == 0) then
        textColored(COL_DIM, 'Nothing in the catalog matches that.');

        return;
    end

    if (imgui.BeginTable('##dwfishing_fish', #FISH_COLUMNS,
        bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY,
                ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupScrollFreeze(0, 1);
        setupColumns(FISH_COLUMNS);
        headerRow(FISH_COLUMNS);

        for _, fish in ipairs(rows) do
            local view = fishView(fish);

            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.Text(fish.name);

            if (imgui.IsItemHovered()) then
                fishCard(fish);
            end

            if (fish.item == 1) then
                imgui.SameLine();
                textColored(COL_DIM, '[junk]');
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.junkBadge);
                end
            elseif (fish.legendary == 1) then
                imgui.SameLine();
                textColored(COL_WARN, '*');
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.legendary);
                end
            end

            imgui.TableNextColumn();
            local teaches = teachesNow(fish.skill);

            if (teaches == true) then
                textColored(COL_GOOD, view.skill);
            else
                imgui.Text(view.skill);
            end

            if (teaches ~= nil and imgui.IsItemHovered()) then
                imgui.SetTooltip(teaches and TIPS.teachesYes or TIPS.teachesNo);
            end

            imgui.TableNextColumn();
            imgui.Text(view.sizeWater);

            imgui.TableNextColumn();
            imgui.Text(view.bait2);

            imgui.TableNextColumn();
            imgui.Text(view.where2);

            imgui.TableNextColumn();
            imgui.Text(view.when);
        end

        imgui.EndTable();
    end
end

-----------------------------------------------------------------------------
-- Tab: Spots
-----------------------------------------------------------------------------
--[[
* EVERY AREA'S OWN SUMMARY, RESOLVED ONCE.
*
* The header of a folded area still has to say what is in it, so this ran for
* all 166 of them on every frame whether or not one was open: a table build per
* area (1070 rows of catalog between them), a scan for the skill band, a DAT
* zone lookup and two string.formats. None of it depends on anything but the
* catalog. (2026-09-06.)
--]]
local spotViews = {};

local function spotView(spot)
    local view = spotViews[spot];

    if (view ~= nil) then
        return view;
    end

    local holding = fishInSpot(spot);
    local lowest, highest, fish, junk = nil, nil, 0, 0;

    for _, entry in ipairs(holding) do
        if (entry.fish.item == 0) then
            fish    = fish + 1;
            lowest  = (lowest == nil or entry.fish.skill < lowest) and entry.fish.skill or lowest;
            highest = (highest == nil or entry.fish.skill > highest) and entry.fish.skill or highest;
        else
            junk = junk + 1;
        end
    end

    -- BY THE SKILL THEY WANT, like the Fish tab. The group's own order is the
    -- order the rows happened to be dumped in, and this is a table a player
    -- reads to find the thing they can catch NEXT.
    table.sort(holding, function (a, b)
        if (a.fish.skill ~= b.fish.skill) then
            return a.fish.skill < b.fish.skill;
        end

        return a.fish.name < b.fish.name;
    end);

    local label = string.format('%s - %s', zoneName(spot), spot.areaName);

    view = {
        holding = holding,
        label   = label,
        needle  = string.lower(label),
        tableId = string.format('##spotfish%d_%d', spot.zone, spot.area),
        -- The ### id keeps the fold state stable while the visible half of the
        -- label gains and loses its "you are here" marker.
        --
        -- The count used to be `#holding`, which counts the junk as catchable
        -- while the skill band beside it deliberately does not -- so an area
        -- reading "skill 4-33, 9 catchable" held six fish and three buckets.
        header  = string.format('%s  [skill %s-%s, %d fish%s]###spot%d_%d',
            label, tostring(lowest or '-'), tostring(highest or '-'), fish,
            (junk > 0) and string.format(' + %d junk', junk) or '',
            spot.zone, spot.area),
    };

    spotViews[spot] = view;

    return view;
end

--[[
* WHAT THE BAIT ON YOUR LINE CAN HOOK, AS A LOOKUP.
*
* Bait affinity is the hard gate this whole guide turns on, and the equipped
* bait rides the `g|` sweep -- so the one question an area's list really raises
* ("with what I am holding, right now?") was answerable all along and the
* window never answered it. It is not the missing AREA question the plan doc
* parks as undoable: which of the zone's fish this bait can hook at all is a
* property of the bait and the catalog, and neither of those needs the server's
* position resolver.
*
* Keyed on the equipped id, so changing bait invalidates it by itself.
--]]
local baitReachCache = { id = nil, set = nil };

local function baitReach()
    local id = state.gear['bait'];

    if (catalog == nil or id == nil or id == 0) then
        return nil;
    end

    if (baitReachCache.id == id) then
        return baitReachCache.set;
    end

    local flat = catalog.baitFish[id];
    local set  = nil;

    -- nil for a bait the engine does not load as bait at all, which is the
    -- same answer as "hooks nothing here": no marker either way.
    if (flat ~= nil) then
        set = {};

        for index = 1, #flat, 2 do
            set[flat[index]] = true;
        end
    end

    baitReachCache.id  = id;
    baitReachCache.set = set;

    return set;
end

local spotRows = { search = nil, zone = nil, rows = {}, count = '' };

local function spotList()
    local typed = searchSpot[1] or '';

    if (spotRows.search == typed and spotRows.zone == state.zone) then
        return spotRows.rows;
    end

    local needle = string.lower(typed);
    local mine   = {};
    local rest   = {};

    for _, spot in ipairs(catalog.spots) do
        if (#needle == 0 or string.find(spotView(spot).needle, needle, 1, true) ~= nil) then
            -- YOUR OWN ZONE FIRST. The catalog's order is by zone id, so the
            -- one area a player opened this tab to look at could be a hundred
            -- and forty rows down a list that marks it with a '>' nobody has
            -- scrolled far enough to see. The filter still decides what is in
            -- the list; this only decides what is at the top of it.
            table.insert((state.zone ~= nil and spot.zone == state.zone) and mine or rest, spot);
        end
    end

    local rows = mine;

    for _, spot in ipairs(rest) do
        table.insert(rows, spot);
    end

    spotRows.search = typed;
    spotRows.zone   = state.zone;
    spotRows.rows   = rows;
    spotRows.count  = string.format('%d of %d fishing areas', #rows, catalog.counts.spots);

    return rows;
end

local function tabSpots()
    if (catalog == nil) then
        return;
    end

    imgui.PushItemWidth(260);
    imgui.InputText('Search spots', searchSpot, 64);
    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.searchSpot);
    end

    imgui.SameLine();

    -- A GREYED WORD RATHER THAN A DISABLED BUTTON, the dwcpx rule: ImGui
    -- reports no hover over a disabled item without a HoveredFlags this suite
    -- does not use, so a greyed button could not carry the sentence that says
    -- why it is greyed. The label is the same width either way, so the row
    -- does not move when the answer lands.
    if (state.zone == nil) then
        imgui.TextDisabled('Where I am');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.whereIAmWait);
        end
    else
        if (imgui.Button('Where I am')) then
            -- Filter to the current zone by writing its name into the search
            -- box, so the filter is visible and editable rather than a hidden
            -- mode. Clearing the box (the old behaviour) listed all 166 areas,
            -- which is the opposite of what this label promises -- and that is
            -- exactly what it did whenever the client could not name the zone,
            -- because the name came only from the DAT. zoneName falls back to
            -- the catalog's own index now.
            searchSpot[1] = zoneName({ zone = state.zone });
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.whereIAm);
        end
    end

    imgui.SameLine();

    local rows = spotList();

    textColored(COL_DIM, spotRows.count);

    if (#rows == 0) then
        textColored(COL_DIM, 'No fishing area matches that.');

        return;
    end

    -- Said once, above the list, so the marker on the rows below does not need
    -- a hover to be understood.
    local reach = baitReach();

    if (reach ~= nil) then
        textColored(COL_DIM, string.format('On your line: %s. Everything it can hook is marked.',
            itemName(state.gear['bait']) or 'bait'));
    end

    for _, spot in ipairs(rows) do
        local view = spotView(spot);
        local here = (state.zone ~= nil and spot.zone == state.zone);

        if (imgui.CollapsingHeader(here and ('> ' .. view.header) or view.header)) then
            if (here) then
                textColored(COL_GOOD, 'You are in this zone.');
            end

            if (imgui.BeginTable(view.tableId, #SPOTFISH_COLUMNS,
                bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
                setupColumns(SPOTFISH_COLUMNS);
                headerRow(SPOTFISH_COLUMNS);

                for _, entry in ipairs(view.holding) do
                    local fish = entry.fish;
                    local card = fishView(fish);

                    imgui.TableNextRow();

                    imgui.TableNextColumn();
                    imgui.Text(fish.name);

                    if (imgui.IsItemHovered()) then
                        fishCard(fish);
                    end

                    if (fish.item == 1) then
                        imgui.SameLine();
                        textColored(COL_DIM, '[junk]');

                        if (imgui.IsItemHovered()) then
                            imgui.SetTooltip(TIPS.junkBadge);
                        end
                    end

                    if (reach ~= nil and reach[fish.id]) then
                        imgui.SameLine();
                        textColored(COL_GOOD, '[yours]');

                        if (imgui.IsItemHovered()) then
                            imgui.SetTooltip(TIPS.yourBait);
                        end
                    end

                    imgui.TableNextColumn();
                    local teaches = teachesNow(fish.skill);

                    if (teaches == true) then
                        textColored(COL_GOOD, card.skill);
                    else
                        imgui.Text(card.skill);
                    end

                    if (teaches ~= nil and imgui.IsItemHovered()) then
                        imgui.SetTooltip(teaches and TIPS.teachesYes or TIPS.teachesNo);
                    end

                    imgui.TableNextColumn();
                    imgui.Text(card.rarity);

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(TIPS.rarity);
                    end

                    imgui.TableNextColumn();
                    imgui.Text(card.bait2);
                end

                imgui.EndTable();
            end
        end
    end
end

-----------------------------------------------------------------------------
-- Tab: Gear
-----------------------------------------------------------------------------
-- The gear the ENGINE recognises, with what each piece actually does. Read off
-- GetFishingGear and CalculateLuckyTiming: anything not on this list does
-- nothing for fishing whatever its name or description suggests.
local GEAR_NOTES = {
    { id = 25608, slot = 'head',  note = 'Tlahtlamah Glasses -- recognised by the engine' },
    { id = 11499, slot = 'head',  note = 'Trainee\'s Spectacles -- recognised by the engine' },
    { id = 10925, slot = 'neck',  note = 'Fisher\'s Torque -- recognised by the engine' },
    { id = 13808, slot = 'body',  note = 'Fisherman\'s Tunica -- +0.5 lucky timing' },
    { id = 13809, slot = 'body',  note = 'Angler\'s Tunica -- +1 lucky timing' },
    { id = 14400, slot = 'body',  note = 'Fisherman\'s Apron -- +3 lucky timing, and moves 25% of the junk pool to "nothing"' },
    { id = 11337, slot = 'body',  note = 'Fisherman\'s Smock -- +3 lucky timing, and moves 25% of the junk pool to "nothing"' },
    { id = 14070, slot = 'hands', note = 'Fisherman\'s Gloves -- +0.5 lucky timing' },
    { id = 14071, slot = 'hands', note = 'Angler\'s Gloves -- +1 lucky timing' },
    { id = 11768, slot = 'waist', note = 'Fisher\'s Rope -- one second off the wait for a bite' },
    { id = 14292, slot = 'legs',  note = 'Fisherman\'s Hose -- +0.5 lucky timing' },
    { id = 14293, slot = 'legs',  note = 'Angler\'s Hose -- +1 lucky timing' },
    { id = 14171, slot = 'feet',  note = 'Fisherman\'s Boots -- +0.5 lucky timing' },
    { id = 14172, slot = 'feet',  note = 'Angler\'s Boots -- +1 lucky timing' },
    { id = 14195, slot = 'feet',  note = 'Waders -- +2 lucky timing' },
};

-- The seven slots the `g|` sweep reports, in the order fishing_core emits
-- them, and the ids GetFishingGear actually reads. Both are derived from
-- GEAR_NOTES so the three cannot drift apart.
local GEAR_SLOTS = { 'head', 'neck', 'body', 'hands', 'waist', 'legs', 'feet' };
local RECOGNISED_GEAR = {};

for _, entry in ipairs(GEAR_NOTES) do
    RECOGNISED_GEAR[entry.id] = true;
end

local function tabGear()
    if (catalog == nil) then
        return;
    end

    -- The rod and bait slots arrive on every g| sweep and are the answer to
    -- "why can I not fish" -- an id of 0 means the slot is empty (the
    -- protocol doc calls this out). Say it before the reference tables.
    if (state.gear['rod'] ~= nil or state.gear['bait'] ~= nil) then
        local rodId  = state.gear['rod'] or 0;
        local baitId = state.gear['bait'] or 0;

        imgui.Text('Equipped:');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.equipped);
        end

        imgui.SameLine();

        if (rodId ~= 0) then
            imgui.Text(itemName(rodId) or string.format('rod %d', rodId));

            if (imgui.IsItemHovered()) then
                itemCard(rodId, itemName(rodId), nil);
            end
        else
            textColored(COL_WARN, 'no rod');
        end

        imgui.SameLine();
        imgui.TextDisabled('/');
        imgui.SameLine();

        if (baitId ~= 0) then
            imgui.Text(itemName(baitId) or string.format('bait %d', baitId));

            if (imgui.IsItemHovered()) then
                local bait = catalog.baitById[baitId];

                if (bait ~= nil) then
                    baitCard(bait);
                else
                    itemCard(baitId, itemName(baitId),
                        'The fishing engine does not load this as bait, so nothing will bite on it.');
                end
            end
        else
            textColored(COL_WARN, 'no bait');
        end

        if ((rodId == 0 or baitId == 0)) then
            imgui.SameLine();
            imgui.TextDisabled('-- both are required before a cast does anything.');
        end

        imgui.Separator();
    end

    if (imgui.CollapsingHeader('Rods###dwfishing_rods')) then
        helpMarker(HELP.rods);

        if (imgui.BeginTable('##dwfishing_rodtable', #ROD_COLUMNS,
            bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
            setupColumns(ROD_COLUMNS);
            headerRow(ROD_COLUMNS);

            for _, rod in ipairs(catalog.rods) do
                local view = rodView(rod);

                imgui.TableNextRow();

                imgui.TableNextColumn();
                imgui.Text(rod.name);

                if (imgui.IsItemHovered()) then
                    itemCard(rod.id, rod.name, itemLine(rod.id));
                end

                imgui.TableNextColumn();
                imgui.Text(view.size);

                imgui.TableNextColumn();
                imgui.Text(view.band);

                imgui.TableNextColumn();
                imgui.Text(view.attack);

                imgui.TableNextColumn();
                imgui.Text(view.time);

                imgui.TableNextColumn();
                imgui.Text(view.notes);
            end

            imgui.EndTable();
        end
    end

    if (imgui.CollapsingHeader('Bait and lures###dwfishing_baits')) then
        helpMarker(HELP.baits);

        if (imgui.BeginTable('##dwfishing_baittable', #BAIT_COLUMNS,
            bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
            setupColumns(BAIT_COLUMNS);
            headerRow(BAIT_COLUMNS);

            for _, bait in ipairs(catalog.baits) do
                local view = baitView(bait);

                imgui.TableNextRow();

                imgui.TableNextColumn();
                imgui.Text(bait.name);

                if (imgui.IsItemHovered()) then
                    baitCard(bait);
                end

                imgui.TableNextColumn();
                imgui.Text(view.kind);

                imgui.TableNextColumn();
                imgui.Text(view.hooks);

                imgui.TableNextColumn();
                imgui.Text(view.losable);

                imgui.TableNextColumn();
                if (view.count == 0) then
                    textColored(COL_DIM, 'nothing in the catalog');
                else
                    imgui.Text(view.kinds);

                    -- The catalog has carried the whole affinity list since the
                    -- first release and this cell drew only the count, so the
                    -- one question a bait row raises had no answer anywhere in
                    -- the window.
                    if (imgui.IsItemHovered()) then
                        baitCard(bait);
                    end
                end
            end

            imgui.EndTable();
        end
    end

    if (imgui.CollapsingHeader('Gear the engine actually reads###dwfishing_gear')) then
        imgui.TextWrapped('GetFishingGear checks seven slots against a fixed list of item ids. ' ..
            'Anything not below does nothing for fishing, whatever its description says.');
        imgui.Separator();

        for _, entry in ipairs(GEAR_NOTES) do
            local worn = (state.gear[entry.slot] == entry.id);

            if (worn) then
                textColored(COL_GOOD, '[worn] ' .. entry.note);
            else
                textColored(COL_DIM, entry.note);
            end

            -- The client's own words for the piece, and which slot it goes in
            -- -- neither of which the one-line note has room for.
            if (imgui.IsItemHovered()) then
                itemCard(entry.id, itemName(entry.id),
                    string.format('%s slot.%s', entry.slot,
                        worn and ' You are wearing it.' or ''));
            end
        end

        --[[
        * AND WHAT YOU ARE ACTUALLY WEARING IN THOSE SLOTS.
        *
        * The `g|` sweep reports every one of the seven slots that holds
        * anything, not only the pieces on the list above -- and this window
        * used every one of those records for a single exact-id comparison and
        * then dropped it. So a player wearing a Fisherman's Ring, or any of
        * the several pieces whose description mentions fishing and whose id
        * GetFishingGear does not read, was told nothing at all: the list above
        * simply did not mention it, which reads as "not in the game" rather
        * than as "does nothing". The wire already carried the answer.
        --]]
        local ignored = {};

        for _, slot in ipairs(GEAR_SLOTS) do
            local worn = state.gear[slot];

            if (worn ~= nil and worn ~= 0 and not RECOGNISED_GEAR[worn]) then
                table.insert(ignored, string.format('%s: %s', slot, itemName(worn) or '?'));
            end
        end

        if (#ignored > 0) then
            imgui.Separator();
            textColored(COL_WARN, 'You are wearing, in those same slots, gear the engine does not read:');

            for _, line in ipairs(ignored) do
                textColored(COL_DIM, '   ' .. line);
            end
        end

        imgui.Separator();
        imgui.TextWrapped('Pelican Ring grants an extra skill-up roll per catch. ' ..
            'Lu Shang\'s Rod is PENALISED below skill 50 -- the engine adds 20 to the skill-up ' ..
            'roll, making it harder, so it is not the beginner rod its reputation suggests.');
    end
end

-----------------------------------------------------------------------------
-- Tab: Monsters
-----------------------------------------------------------------------------
--[[
* One monster row, resolved once.
*
* This tab resolved up to two item names per row for 259 rows on every frame --
* five hundred DAT reads behind five hundred pcalls, sixty times a second, for
* a table nothing writes to. It also printed the catalog's raw zone KEY where
* every other tab prints the client's own display name, so the same zone read
* differently depending on which tab you were looking at.
--]]
local mobViews = {};

local function mobView(mob)
    local view = mobViews[mob];

    if (view ~= nil) then
        return view;
    end

    local bait = nil;

    if (mob.reqBait ~= 0) then
        local names = { itemName(mob.reqBait) };

        if ((mob.altBait or 0) > 0) then
            table.insert(names, itemName(mob.altBait));
        end

        bait = table.concat(names, ' or ');
    end

    local name = (mob.name or ''):gsub('_', ' ');
    local zone = zoneName(mob);

    view = {
        name   = name,
        zone   = zone,
        level  = tostring(mob.level),
        nm     = (mob.nm == 1) and 'yes' or '',
        bait   = bait,
        needle = string.lower(name .. ' ' .. zone),
    };

    mobViews[mob] = view;

    return view;
end

--[[
* ONE ROW PER MONSTER PER ZONE, NOT PER AREA.
*
* fishing_mob is keyed by (zone, AREA), so a monster that can be hooked in
* three of a zone's waters is three rows -- and this tab does not show the
* area, because the server resolves it from your exact position and exposes no
* binding for it (the plan doc parks that as undoable). So thirty-one of the
* 259 rows arrived as visually identical duplicates: the same name, the same
* zone, the same level, the same NM flag and the same bait, twice or three
* times in a row. Not one displayed field differs between any pair of them.
*
* Built once; the catalog does not change while the client is running.
--]]
local mobMaster = nil;

local function mobAll()
    if (mobMaster ~= nil) then
        return mobMaster;
    end

    mobMaster = {};

    if (catalog == nil) then
        return mobMaster;
    end

    local seen = {};

    for _, mob in ipairs(catalog.mobs) do
        local key = string.format('%s|%d', mob.name or '', mob.zone or 0);

        if (not seen[key]) then
            seen[key] = true;
            table.insert(mobMaster, mob);
        end
    end

    return mobMaster;
end

local mobRows = { search = nil, zone = nil, rows = {}, count = '' };

local function mobList()
    local typed = searchMob[1] or '';

    if (mobRows.search == typed and mobRows.zone == state.zone) then
        return mobRows.rows;
    end

    local needle = string.lower(typed);
    local mine   = {};
    local rest   = {};

    for _, mob in ipairs(mobAll()) do
        if (#needle == 0 or string.find(mobView(mob).needle, needle, 1, true) ~= nil) then
            -- The ones you can hook where you are standing, first, the way the
            -- Spots tab lists your own zone first.
            table.insert((state.zone ~= nil and mob.zone == state.zone) and mine or rest, mob);
        end
    end

    local rows = mine;

    for _, mob in ipairs(rest) do
        table.insert(rows, mob);
    end

    mobRows.search = typed;
    mobRows.zone   = state.zone;
    mobRows.rows   = rows;
    mobRows.count  = string.format('%d of %d', #rows, #mobAll());

    return rows;
end

local function tabMobs()
    if (catalog == nil) then
        return;
    end

    imgui.TextWrapped('Things that are not fish. These hook like a catch and then fight you; ' ..
        'they teach no fishing skill at all. Many require a specific bait and will not appear on anything else.');
    imgui.Separator();

    -- This tab's own search box: it used to filter on the Fish tab's, so a
    -- leftover fish name over there emptied this table with nothing on
    -- screen to say why.
    imgui.PushItemWidth(260);
    imgui.InputText('Search monsters', searchMob, 64);
    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.searchMob);
    end

    imgui.SameLine();

    local rows = mobList();

    textColored(COL_DIM, mobRows.count);

    if (#rows == 0) then
        textColored(COL_DIM, 'No monster matches that.');

        return;
    end

    if (imgui.BeginTable('##dwfishing_mobs', #MOB_COLUMNS,
        bit.bor(ImGuiTableFlags_Borders, ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY,
                ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupScrollFreeze(0, 1);
        setupColumns(MOB_COLUMNS);
        headerRow(MOB_COLUMNS);

        for _, mob in ipairs(rows) do
            local view = mobView(mob);

            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.Text(view.name);

            imgui.TableNextColumn();

            -- The ones in the zone you are standing in, marked. Several of
            -- these are notorious monsters that will kill the fisherman who
            -- hooked them, and "can this happen to me HERE" is the only
            -- question this table is urgent about.
            if (state.zone ~= nil and mob.zone == state.zone) then
                textColored(COL_GOOD, view.zone);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.mobHere);
                end
            else
                imgui.Text(view.zone);
            end

            imgui.TableNextColumn();
            imgui.Text(view.level);

            imgui.TableNextColumn();
            imgui.Text(view.nm);

            imgui.TableNextColumn();
            if (view.bait == nil) then
                textColored(COL_DIM, 'any');
            else
                imgui.Text(view.bait);
            end
        end

        imgui.EndTable();
    end
end

-----------------------------------------------------------------------------
-- Tab: Basics
--
-- The rules of the system, stated once, from the engine rather than from
-- folklore. This is the tab a new fisherman reads first.
-----------------------------------------------------------------------------
--[[
* The Basics tab's bullets, built once instead of on every frame.
*
* Fifteen string.formats and two long concatenations for a page of text that
* changes only when the server names a different multiplier or the player's
* level crosses the novice line. The two lists are separate because one of them
* is genuinely constant and the other is not.
--]]
local basicsFixed = nil;
local basicsLive  = { level = nil, multiplier = nil, lines = {} };

local function basicsHookLines()
    if (basicsFixed ~= nil) then
        return basicsFixed;
    end

    local engine = catalog.engine;

    basicsFixed = {
        'Bait affinity is a hard gate: no affinity row, no bite, ever.',
        string.format(
            'Bait power is the biggest term: power 3 is worth +%d (bait) or +%d (lure); power 1 only +%d / +%d.',
            catalog.baitPower[3][2], catalog.baitPower[3][1],
            catalog.baitPower[1][2], catalog.baitPower[1][1]),
        string.format(
            'Being under-skilled costs %.2f hook points per level -- a penalty, never a wall. A fish up to %d levels above you still bites.',
            engine.hookUnderSlope, engine.poolSkillWindow),
        string.format(
            'Being over-skilled costs too: %.2f points per level once you are more than %d above it.',
            engine.hookOverSlope, engine.hookOverGrace),
        string.format(
            'The wrong size rod costs %d points (small fish, big rod) or %d (big fish, small rod). Legendary rods pay neither.',
            engine.rodTooBig, engine.rodTooSmall),
        string.format(
            'The result is clamped to %d-%d, so nothing is ever hopeless and nothing is ever certain.',
            engine.hookClampLow, engine.hookClampHigh),
    };

    return basicsFixed;
end

local function basicsSkillLines()
    local level = state.level or 0;

    if (basicsLive.level == level and basicsLive.multiplier == state.multiplier) then
        return basicsLive.lines;
    end

    local engine = catalog.engine;
    local lines  = {
        'A catch AT or BELOW your level teaches nothing. Nothing at all.',
        string.format('A catch more than %d levels above you also teaches nothing.', engine.skillupWindow),
        string.format(
            'The curve PEAKS at exactly +%d levels above you -- not at the hardest fish you can land.',
            engine.skillupPeak),
        'Items and monsters teach nothing, however large.',
        string.format(
            'Your rank hard-caps your skill at (rank + 1) x %d. At the cap, nothing moves it but the guild test.',
            math.floor(engine.rankStep / 10)),
        string.format(
            'The curve is rolled against %d at your level, not against 100 -- it starts at %d, ' ..
            'drops %d anywhere that is not a city, and drops more again below level %d.',
            skillRoll(level), catalog.terms.rollBase, catalog.terms.rollOutdoor,
            catalog.terms.rollNoviceUnder),
        'HOOKING IS NOT CATCHING. A lost catch, a snapped line and a broken rod all '
            .. 'teach nothing, and reaching more than 7 levels above you is where losing starts.',
    };

    if (state.multiplier ~= nil and state.multiplier ~= 1.0) then
        table.insert(lines, string.format(
            'This server multiplies the whole curve by %g -- which on most of the window pushes it ' ..
            'past the roll entirely, so the skill-up becomes certain and the +%d peak stops mattering.',
            state.multiplier, engine.skillupPeak));
    end

    basicsLive.level      = level;
    basicsLive.multiplier = state.multiplier;
    basicsLive.lines      = lines;

    return lines;
end

local function tabBasics()
    if (catalog == nil) then
        return;
    end

    imgui.TextWrapped('Everything below is read out of this server\'s own fishing code, not a wiki.');
    imgui.Separator();

    if (imgui.CollapsingHeader('How skill-ups actually work###dwfishing_basics_skill')) then
        for _, line in ipairs(basicsSkillLines()) do
            imgui.BulletText(line);
        end
    end

    if (imgui.CollapsingHeader('How a bite is decided###dwfishing_basics_hook')) then
        for _, line in ipairs(basicsHookLines()) do
            imgui.BulletText(line);
        end
    end

    if (imgui.CollapsingHeader('Time, moon and tide###dwfishing_basics_time')) then
        imgui.BulletText('Every fish carries an hour, moon and month preference, and they are multiplied together.');
        imgui.BulletText('The moon contributes three times as much as the month, and the hour twice as much.');
        imgui.BulletText('The wait for a bite is 13 seconds, minus 4 on a New or Full moon, minus 1 at 05:00 or 17:00, minus 1 with Fisher\'s Rope. It never drops below 7.');
        imgui.BulletText('The Fish tab states each fish\'s best hour and moon in the When column, and '
            .. 'hovering one adds the month -- the third of the three, and the weakest.');
    end

    -- WHICH CATALOG, AND WHOSE. The hash rides `c|` and the addon refuses the
    -- guide when it does not match, so when it DOES match the player has no
    -- way to see that the check happened at all -- and "is my addon current"
    -- is the first question anybody asks a guide that disagrees with them.
    if (imgui.CollapsingHeader('What this window is reading###dwfishing_basics_data')) then
        -- The monster count is the DEDUPLICATED one the Monsters tab lists,
        -- not the catalog's row count: fishing_mob is keyed by area and this
        -- window cannot show areas, so the two would disagree by thirty-one
        -- rows and the player could see both numbers.
        imgui.BulletText(string.format('%d fish, %d rods, %d baits, %d fishing areas, %d hookable monsters.',
            catalog.counts.fish, catalog.counts.rods, catalog.counts.baits,
            catalog.counts.spots, #mobAll()));
        imgui.BulletText(string.format('Catalog %s, version %d, generated from this server\'s own dumps.',
            tostring(catalog.hash), catalog.version));

        -- THE TWO SETTINGS THIS WINDOW WAS PARSING AND THROWING AWAY. `s|` has
        -- carried both since the first release and nothing drew either, which
        -- is the opposite of the plan's F10: a per-box setting becomes
        -- ADVERTISED the moment the window states it, and these two are
        -- invisible to every import and invariant the repo has.
        if (state.minLevel ~= nil) then
            imgui.BulletText(string.format('Fishing needs main job level %d on this box (map.FISHING_MIN_LEVEL).',
                state.minLevel));
        end

        if (state.contest ~= nil) then
            imgui.BulletText(state.contest
                and 'The guild\'s fishing contest in Selbina progresses on its own here.'
                or 'The guild\'s fishing contest does not progress on its own here.');
        end

        if (state.serverHash ~= nil) then
            if (state.serverHash == catalog.hash) then
                textColored(COL_GOOD, '   The server confirms it loaded the same file.');
            elseif (state.serverHash == 'none') then
                textColored(COL_WARN, '   The server could not load its own copy, so nothing was compared.');
            else
                textColored(COL_BAD, string.format('   The server loaded %s instead.', tostring(state.serverHash)));
            end
        else
            textColored(COL_DIM, '   The server has not sent its copy of the hash yet.');
        end
    end

    if (imgui.CollapsingHeader('What this window will not do###dwfishing_basics_limits')) then
        imgui.TextWrapped(
            'It does not tell you which fishing AREA of a zone you are standing in -- the server ' ..
            'resolves that from your exact position and there is no binding to ask it, so the Spots ' ..
            'tab lists every area in the zone and marks the zone you are in. It does not model the ' ..
            'reel-in minigame, which is decided live from your rod, the fish and your skill. And it ' ..
            'states rarity as the weight the engine multiplies by, never as a "drop rate", because ' ..
            'the pool is a weighted draw and not a roll per fish.');
    end
end

-----------------------------------------------------------------------------
-- Window
-----------------------------------------------------------------------------
local TABS = {
    { label = 'Route',    draw = tabRoute  },
    { label = 'Next',     draw = tabNext   },
    { label = 'Fish',     draw = tabFish   },
    { label = 'Spots',    draw = tabSpots  },
    { label = 'Gear',     draw = tabGear   },
    { label = 'Monsters', draw = tabMobs   },
    { label = 'Basics',   draw = tabBasics },
};

-- The two ids every tab needs, built once. Fourteen string.formats a frame for
-- seven labels that never change is not a lot, but it is nothing at all here.
for index, tab in ipairs(TABS) do
    tab.id     = string.format('%s##dwfishing_tab_%d', tab.label, index);
    tab.bodyId = string.format('##dwfishing_body_%d', index);
end

-- "12s ago" / "4m ago", in the units a player thinks in. os.clock is what the
-- whole file measures with (on Windows it is wall time since the process
-- started, which is why the throttle can use it), so this does not mix two
-- clocks to say one thing.
local syncedLine = { at = nil, text = '' };

local function agoWord(seconds)
    if (seconds < 90) then
        return string.format('%ds', math.max(0, math.floor(seconds)));
    end

    return string.format('%dm', math.floor(seconds / 60));
end

local function renderWindow()
    if (catalog == nil) then
        textColored(COL_BAD, catalogError or 'The fishing catalog failed to load.');
        imgui.TextWrapped('Re-run the launcher to repair this addon\'s data file.');

        return;
    end

    if (state.refused) then
        textColored(COL_BAD, state.status);

        return;
    end

    --[[
    * THE TOP ROW: how to ask again, and how old the answer is.
    *
    * Four facts on this window come off the wire -- your skill, your rank cap,
    * where you are standing and what is on your rod -- and every one of them
    * moves while the window is shut. Everything else is the local catalog and
    * cannot go stale at all. So the age is stated rather than implied, and the
    * button that fixes it is beside the sentence that reports it.
    --]]
    local asking = (state.asked ~= nil);

    -- NOT WRAPPED IN BeginDisabled, deliberately: ImGui answers IsItemHovered()
    -- with false for a disabled item unless you pass a HoveredFlags this suite
    -- does not use, so a greyed button's tooltip never appears -- and the
    -- tooltip is the only thing that would say WHY it was greyed (dwcpx's
    -- block states the same rule). The click is what is gated instead, and the
    -- hover says which of the two states you are in.
    if (imgui.SmallButton('Refresh##dwfishing_refresh')) then
        -- A second ask while one is still in flight is a second chat line for
        -- an answer already on its way.
        if (not asking) then
            state.helloed = false;
            hello();
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(asking and TIPS.refreshWait or TIPS.refresh);
    end

    imgui.SameLine();

    if (state.statusBad and #tostring(state.status) > 0) then
        textColored(COL_BAD, state.status);
    elseif (not state.spoke) then
        textColored(COL_DIM, 'Asking the server where you stand...');
    elseif (state.syncedAt ~= nil) then
        -- Formatted once a second rather than sixty times: the only thing that
        -- moves in it is a whole number of seconds.
        local age = math.max(0, math.floor(os.clock() - state.syncedAt));

        if (syncedLine.at ~= age) then
            syncedLine.at   = age;
            syncedLine.text = string.format('Your skill, rank and zone as of %s ago.', agoWord(age));
        end

        textColored(COL_DIM, syncedLine.text);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.synced);
        end
    else
        textColored(COL_DIM, 'The catalog below is local; only your own four facts come from the server.');
    end

    -- FISHING BEING OFF IS NOT A FACT ABOUT ONE TAB. It lived on the Next tab
    -- only, so a player reading the Route tab was handed a costed itinerary for
    -- an activity this box has switched off, with nothing to say so. It is the
    -- first thing anything here should say.
    if (state.enabled == false) then
        textColored(COL_BAD, 'Fishing is DISABLED on this server right now -- nothing below can be caught.');
    end

    if (imgui.BeginTabBar('##dwfishing_tabs')) then
        for index, tab in ipairs(TABS) do
            -- The tab the player left, restored on the frame after an open and
            -- then never forced again -- otherwise the flag would fight every
            -- click for the rest of the session.
            local flags = (state.wantTab == index) and ImGuiTabItemFlags_SetSelected
                or ImGuiTabItemFlags_None;

            if (imgui.BeginTabItem(tab.id, nil, flags)) then
                -- SetSelected takes effect on the NEXT frame (imgui consumes
                -- NextSelectedTabId at BeginTabBar), so the flag is re-asserted
                -- until the wanted tab is the one actually drawing -- and the
                -- remembered index is not overwritten in the meantime, which
                -- would otherwise save the tab the window opened on top of the
                -- tab the player left.
                if (state.wantTab == index) then
                    state.wantTab = nil;
                end

                if (state.wantTab == nil and config.tab ~= index) then
                    config.tab = index;
                    saveConfig();
                end

                -- EVERY TAB DRAWS INTO A CHILD THAT FILLS IT, so its content
                -- scrolls with a bar of its own. The window's flags say
                -- NoScrollbar (the suite's set), so anything a tab lays out
                -- past the bottom edge is content the player cannot see and has
                -- no sign exists -- which is where the Route tab's alternate
                -- openers and its whole disclaimer had gone. dwquest's shape.
                if (imgui.BeginChild(tab.bodyId, { -1, -1 }, ImGuiChildFlags_None)) then
                    tab.draw();
                end

                imgui.EndChild();
                imgui.EndTabItem();
            end
        end

        imgui.EndTabBar();
    end
end

local function openWindow()
    state.open[1] = true;

    -- Reopening is a fresh start for error reporting too: `reported` only
    -- exists to stop one bad frame printing sixty lines a second.
    state.reported = false;

    -- AND A FRESH HANDSHAKE, EVERY TIME, NOT ONLY WHEN THE FIRST ONE FAILED.
    --
    -- This used to clear the latch only `if (not state.spoke)`, which fixed
    -- the lost-line case (the client's own rate limiter is enough to eat one)
    -- and left the ordinary one broken: once a hello had been answered,
    -- reopening the window in the same zone re-asked NOTHING. The header
    -- promises "one handshake on open and one on a zone line", and fishing is
    -- the one activity that moves the number this whole window is about -- so
    -- the guide a player reopened after an hour at the water still quoted the
    -- skill, the rank cap, the zone and the rod they had an hour earlier, with
    -- no indication it was stale. dwquest re-syncs on every open for exactly
    -- this reason; the queue's own dedup and the 1.2s throttle bound the cost
    -- to one chat line per open. (2026-09-06.)
    state.helloed = false;

    -- Open on the tab it was closed on. Cleared by the frame that honours it.
    state.wantTab = (type(config.tab) == 'number'
        and config.tab >= 1 and config.tab <= #TABS) and math.floor(config.tab) or nil;

    hello();
end

ashita.events.register('d3d_present', 'dwfishing_present', function ()
    pumpQueue();

    -- One ask, then stop and say so. There is no automatic retry at all: a
    -- retry that never terminates is a command loop, and this one would be a
    -- chat line per attempt. Refresh, a zone line and reopening the window are
    -- the three ways to ask again, and all three are the player's own doing.
    if (state.asked ~= nil) then
        -- While a send is held the hello cannot go out, so the give-up is
        -- measured from when the line can actually leave rather than from when
        -- it was queued: pumpQueue stamps askedAt on the send, and this branch
        -- holds the clock still for as long as the client refuses chat at all.
        -- (dwecho canSend; 2026-08-15. The send-side stamp is 2026-09-06.)
        if (not echo.canSend()) then
            state.askedAt = os.clock();
        elseif (os.clock() - state.askedAt > ANSWER_TIMEOUT) then
            state.asked     = nil;
            state.status    = 'The server did not answer. Is the fishing module loaded?';
            state.statusBad = true;
        end
    end

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 900, 560 }, ImGuiCond_FirstUseEver);

    -- A FLOOR UNDER THE DRAG HANDLE. The widest table here is seven stretch
    -- columns of zone names, rod names and bait names; dragged much under this
    -- they stop being readable one at a time rather than all at once, and the
    -- window remembers the size it was left at -- so one bad drag is permanent
    -- until the player finds the corner again. 620 x 380 keeps the tab bar, a
    -- header row and several rows of every table. No window in this suite had
    -- one before. (2026-09-06.)
    if (CAN_CONSTRAIN) then
        imgui.SetNextWindowSizeConstraints({ 620, 380 }, { 99999, 99999 });
    end

    -- The suite's flag set, which this window shipped without. NoSavedSettings
    -- was the odd one out and it contradicted the line above: FirstUseEver
    -- means "unless ImGui has a saved size", so telling ImGui never to save
    -- made the size and POSITION reset to the default on every single reload,
    -- and the player re-placed the window every session. NoDocking was missed
    -- by the 2026-08-02 sweep that added it to every other window because this
    -- addon did not exist yet.
    local visible = imgui.Begin('DriftwoodXI Fishing##dwfishing', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        -- pcall'd like every sibling window (dwcraft's block states the
        -- reason): an error raised inside d3d_present fires sixty times a
        -- second and the host answers by unloading the addon -- and a throw
        -- past Begin would skip imgui.End() and theme.pop(), unbalancing
        -- both stacks by one per frame.
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwfishing'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwfishing'):append(chat.message('Window closed. Everything it shows also works as !fish commands.')));
            end
        end
    end

    imgui.End();

    theme.pop(pushed);
end);

ashita.events.register('command', 'dwfishing_command', function (e)
    local args = e.command:args();

    if (#args == 0) then
        return;
    end

    local first = args[1]:lower();

    if (first ~= '/dwfishing' and first ~= '/dwfish' and first ~= '/fishing') then
        return;
    end

    e.blocked = true;

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

--[[
* A bare `!fish` typed by hand opens the window instead, the way `!scan` and
* `!port` do -- and any other outgoing chat line stamps the throttle, because
* the client's rate limit is on chat and not on this addon.
--]]
ashita.events.register('packet_out', 'dwfishing_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!fish' or lower == '!fish ui' or lower == '!fish window' or lower == '!fish gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwh') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwfishing_load', function ()
    print(chat.header('dwfishing'):append(chat.message(
        '/dwfishing opens the fishing guide -- the Route tab is the whole 0-110 plan, and the rest is every fish, bait, rod and spot. !fish route does it typed.')));
end);
