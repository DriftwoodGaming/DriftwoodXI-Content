--[[
* DriftwoodXI -- dwspoils
*
* Augmented gear off ordinary kills, in a window. Every monster that pays you
* experience has a small chance of handing you a piece of equipment carrying
* one to four random augments, levelled to the monster that died, straight
* into your bags -- no treasure pool, no lot, no trade. This window draws what
* your ACCOUNT has been handed: the last thirty, newest first, with the item's
* own icon and card, WHICH AUGMENTS it rolled, the monster and its level, the
* zone, how long ago, and where it landed when that was not your inventory. A
* second tab holds the server's last thirty FOUR-augment awards, which are the
* ones the world hears about, and those name their four as well.
*
* 1.1.0 (2026-09-21) IS WHEN IT STARTED NAMING THEM. Both tabs used to say how
* MANY augments a piece carried and nothing about which -- the hover card's
* last line was a bare "4 augment(s) on this piece" -- so the one fact the
* whole feature exists to produce was the one fact this window did not draw.
* The names are decoded here, from the ids the server already sent: the same
* GENERATED augcatalog.lua dwquest, dwbags, dwah and dwwarehouse carry, and
* the same rank arithmetic, so a piece reads the same in every window on the
* server. The Hall of Four's `w|` record grew an `augs` field for it, appended
* last, which is why an older copy of this addon keeps working unchanged.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited whole
* through dwunleashed). It carries no item table, no rate table and no clock
* of its own: everything it draws arrived on the wire as records, and the only
* two lines it ever sends are `!dwsp mine` and `!dwsp hall`, which reach
* exactly the dispatch `!spoils` and `!spoils hall` reach. It has no button
* that spends anything, moves your character or touches a roll. It cannot: the
* wire has no verb for any of that.
*
* TURN IT OFF AND NOTHING IS LOST. `!spoils` says all of it typed, and the
* `[Spoils] ` lines the server prints on every award arrive whether this is
* loaded or not.
*
* IT SAYS NOTHING ABOUT THE ODDS beyond "a small chance" (owner, 2026-09-20):
* not the rate, not the split, and nothing at all about how a dry run is
* treated. None of that is on this wire -- there is no field a future version
* of this window could read it out of by accident -- and the quiet is the
* feature.
*
* IT TAKES NO ZONE-IN SLOT. The first ask is LAZY -- the first frame the
* window is actually shown in a zone -- so a player who never opens it never
* handshakes and the login burst is exactly as long as it was before this
* addon existed (the dwparse decision; see dwecho.lua's ZONE_ORDER, which this
* addon is deliberately absent from). While the window is open it re-asks the
* tab on screen every sixty seconds, on Refresh, and once a couple of seconds
* after it sees one of the server's own `[Spoils] You obtain` lines go by --
* which is the only moment the list is KNOWN to have changed.
*
* Over `!dwsp` (`documentation/dwsp_protocol.md`); the offline guard is
* tools/dwspoils/harness_dwspoils.py.
--]]

addon.name    = 'dwspoils';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.1';
addon.desc    = 'DriftwoodXI Spoils: the augmented gear ordinary kills have handed your account, and the server\'s four-augment hall.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

local C = ffi.C;

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. The FIRST
-- two-letter door: dwa.lua through dwz.lua are all doors already, so `dwsp`
-- and `_DWSPDATA` are where the registry in dww.lua's header goes next.
local DATA_SENDER = '_DWSPDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

--[[
* THE TAG THE SERVER PREFIXES EVERY SPOILS SENTENCE WITH. This addon does NOT
* block or reroute those lines -- they are ordinary system chat and the player
* is meant to read them where the rest of the game's sentences land. It reads
* them only as a NUDGE: an award has just happened, so the list on screen is
* stale, and a re-ask a couple of seconds later collects it.
*
* THE THREE SENTENCES, AND WHY TWO OF THEM ARE MATCHED AND THE THIRD IS NOT
* (2026-09-20, independent review). spoils_core.lua says exactly three things
* under this tag:
*
*   1. the award -- `You obtain <item> with N augments from <mob>.`
*   2. the LOST award -- `<A Mob> yielded <item> with N augments, but nothing
*      on your account could hold it and it was lost.`
*   3. the world line, to EVERYBODY -- `<Name> obtained <item> with four
*      augments from DWSpoils when slaying <mob>!`
*
* The first cut matched `[Spoils] You obtain` and got both halves wrong. It
* missed (2) -- which is the row most worth drawing promptly, because a lost
* award is the one the player will want to see booked -- and it matched (3)
* for a character named `You`, whose every four-augment award would have made
* every open window on the server re-ask at once.
*
* So: the award is matched WITH ITS TRAILING SPACE, which is what separates
* `You obtain ` from the world line's `You obtained `; and the lost line is
* matched on its own unmistakable tail, because its FIRST word is the mob's
* name and there is no fixed prefix to anchor on. The world line contains
* neither and can never nudge anything.
*
* ALL THREE LITERALS ARE THE SERVER'S OWN. Part C of
* tools/dwspoils/harness_dwspoils.py parses the tag and both format strings
* out of modules/driftwoodxi/spoils_core.lua and the three constants below
* out of this file, and fails when they stop agreeing -- so rewording either
* side turns the harness red instead of silently costing the nudge.
--]]
local NOTICE_TAG  = '[Spoils] ';
local NUDGE_AWARD = '[Spoils] You obtain ';
local NUDGE_LOST  = 'nothing on your account could hold it and it was lost.';

--[[
* THE MODE GATE (dwnemesis 1.3.1's lesson, inherited whole). A line is
* anything text_in sees, INCLUDING another player's yell -- so a player typing
* "[Spoils] You obtain deez nuts" would otherwise make every client in earshot
* re-ask the server. The server writes every module notice on SYSTEM_3, which
* the client hands to text_in as mode 121 (low byte); a player cannot choose
* that mode. An allow list of one, and a wrong number here merely costs the
* nudge -- the sixty-second poll still collects the award.
--]]
local NOTICE_MODE = 121;

--[[
* EVERY NUMBER OFF THE WIRE COMES THROUGH HERE (the dwnemesis shape). LuaJIT
* -- which is what Ashita runs -- answers `tonumber` for 'inf', 'nan', '0x10'
* and '2.5' as readily as for '7', and everything downstream is a pile of
* string.format('%d'). A field that is not a plain integer inside the wire's
* own range is not a number this window can draw, so it reads as the record's
* default and the rest of the record still lands.
--]]
local WIRE_MAX = 2147483647;

local function wireInt(text, default)
    local value = tonumber(text);

    if (value == nil
            or value ~= value                            -- nan
            or value < -WIRE_MAX or value > WIRE_MAX     -- inf, and anything absurd
            or value ~= math.floor(value)) then
        return default or 0;
    end

    return value;
end

--[[
* AUGMENT NAMES -- augcatalog.lua beside this file, the same GENERATED catalog
* dwquest, dwbags, dwah and dwwarehouse carry (tools/dwquest/
* gen_augment_catalog.py writes dwquest's; every other copy is byte-identical
* to it, which PLANS/Check-QuestAugments.ps1 and Part C of
* tools/dwspoils/harness_dwspoils.py both assert).
*
* WHY A COPY RATHER THAN A WIRE FIELD. The words are two to forty bytes each
* and a record is 130; four augments in prose would not fit in the row they
* belong to, let alone beside the item, the monster, the zone and the landing.
* So the server sends what it sends everywhere else -- `id:value` pairs -- and
* every window on the server turns them into the same sentence out of the same
* generated table. A second table here would be a second answer.
*
* pcall'd because a half-synced addon folder is a real deployment state: with
* no catalog the rows and the card still list their augments, as the raw ids
* they are, and nothing else about the window changes.
--]]
local haveAugCatalog, augcatalog = pcall(require, 'augcatalog');

if (not haveAugCatalog or type(augcatalog) ~= 'table' or type(augcatalog.augments) ~= 'table') then
    augcatalog = { augments = { } };
end

--[[
* ONE AUGMENT'S MAGNITUDE AT A GIVEN RANK -- dwbags' `augmentWords` character
* for character, which is dwquest's. `rank` is the HUMAN rank: the stored
* five-bit exdata value plus one, and the wire's `augs` field carries the
* STORED number (spoils_augments.lua writes `rank - 1`), so every call site
* below adds the one.
*
* A substitutable entry has its digit runs recomputed for this rank -- term k
* applies to the k-th digit run, a bare number n means n + stored, a pair
* { b, s } means b + stored * s. The generator emits a term ONLY where it
* verified that against the engine's own formula (item_equipment.cpp
* SetAugmentMod: the stored value is ADDED once, never multiplied), so this
* never invents a magnitude.
--]]
local function augmentWords(augid, rank)
    local entry = augcatalog.augments[augid];

    if (entry == nil) then
        return string.format('augment %d', augid);
    end

    local label  = entry.l;
    local stored = rank - 1;

    if (entry.m == nil) then
        return label;
    end

    if (stored > 0) then
        local k = 0;

        label = string.gsub(label, '%d+', function (digits)
            k = k + 1;

            local term = entry.m[k];

            if (term == nil) then
                return digits;
            end

            if (type(term) == 'table') then
                return tostring(term[1] + stored * term[2]);
            end

            return tostring(term + stored);
        end);
    end

    return label;
end

--[[
* One augment as this window names it: the magnitude AT THIS RANK, and the
* rank itself whenever it is not 1. dwbags' `augmentText`, and the rank is
* stated ALONGSIDE the magnitude for the reason that file records at length
* (owner report, 2026-09-11): a card that printed a bare `Mag. Evasion +7`
* beside a reference showing the catalog's rank-1 `+3` read as the window
* hiding eight points. +7 IS what rank 5 grants.
--]]
local function augmentText(augid, rank)
    if (augcatalog.augments[augid] == nil) then
        return string.format('augment %d rank %d', augid, rank);
    end

    local label = augmentWords(augid, rank);

    if (rank > 1) then
        return string.format('%s (rank %d)', label, rank);
    end

    return label;
end

--[[
* THE WIRE'S `augs` FIELD, DECODED ONCE, AT PARSE TIME -- never per frame.
* Thirty rows times four augments is 120 string.gsub calls, and a row is
* redrawn sixty times a second for as long as the window is open; composing
* these in the render pass would be seven thousand substitutions a second to
* produce text that cannot change until the next answer arrives (the dwcpx
* per-frame-cost rule).
*
* Answers a LIST (one entry per augment, for the card) and a single compact
* LINE (for the row), or nil and nil when there is nothing to say -- which is
* what an old ledger row with no `augs`, an old server that does not send the
* Hall's field yet, and an empty string all look like. Every caller draws the
* count sentence it drew before when it gets nil, so nothing regresses.
*
* THE TWO DIFFER BY THE RANK AND BY NOTHING ELSE. The card is a reference and
* says `HP+6 (rank 6)`; the row is a glance and says `HP+6`, which is also
* exactly what the server's own `[Spoils] It carries ...` chat line and its
* map-log line say. The MAGNITUDE is the same figure in all four places --
* that is the part a player compares against their own bag -- and the rank
* appears only where there is room to explain it.
--]]
local function decodeAugs(text)
    if (type(text) ~= 'string' or text == '') then
        return nil, nil;
    end

    local list  = { };
    local short = { };

    for id, stored in string.gmatch(text, '(%d+):(%d+)') do
        local rank = tonumber(stored) + 1;

        list[#list + 1]  = augmentText(tonumber(id), rank);
        short[#short + 1] = augmentWords(tonumber(id), rank);
    end

    if (#list == 0) then
        return nil, nil;
    end

    return list, table.concat(short, ', ');
end

--[[
* Persisted presentation state, through Ashita's settings library (the
* dwunleashed shape). ONE flat scalar: which tab this character was last
* looking at. Nothing the server said is ever written to disk -- a cached
* ledger is a ledger that can be wrong, and this one is cheap to ask for
* again. The window's own size and position are ImGui's business, through the
* FirstUseEver sizing below and its ini file.
*
* THE DEFAULTS ARE A SUGAR TABLE, and that `T` is load-bearing rather than
* decorative: settings.lua calls `defaults:copy(true)` (:180) and
* `settings:merge(defaults)` (:338), both sugar-table methods, so a plain
* table raises 'attempt to call a nil value'. The pcall below hides it at
* load; the library's own UNGUARDED packet_in handler re-loads on the
* zone-enter packet (:538) and Ashita answers a raise inside an event callback
* by UNLOADING THE ADDON -- so a missing `T` works at the desk and then the
* window disappears on the player's next zone line.
--]]
local defaultConfig = T{
    tab = 'mine',
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

local TABS = { 'mine', 'hall' };

local function rememberedTab(cfg)
    if (type(cfg) ~= 'table' or type(cfg.tab) ~= 'string') then
        return 'mine';
    end

    for _, key in ipairs(TABS) do
        if (cfg.tab == key) then
            return key;
        end
    end

    return 'mine';
end

--[[
* Outbound: `!dwsp` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat.
--]]
local SEND_INTERVAL = 1.2;

-- The answer clock, per read (the dwfame shape): one retry after five
-- seconds, then the silent latch. An unknown `!` command falls through to
-- PUBLIC /say on a server without dwsp.lua, and the latch is what contains
-- that to two lines rather than one every send interval, forever.
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- How often an OPEN window re-asks the tab on screen. A ledger only moves
-- when something is awarded, and an award announces itself in chat (see
-- NUDGE_PREFIX), so sixty seconds is the backstop rather than the mechanism.
local POLL_INTERVAL = 60.0;

-- How long after an award line to collect it. The server writes the ledger
-- row and the chat line in the same breath, but the row has to be readable
-- by the time the answer is built, and a couple of seconds costs the player
-- nothing they can perceive.
local NUDGE_DELAY = 2.0;

--[[
* THE TWO LINES THIS ADDON EVER SENDS, SPELLED OUT IN FULL.
*
* Written as whole literals rather than built with `'!dwsp ' .. verb`, and the
* reason is a gate rather than taste: harness_dwsuite.py discovers every verb
* every addon sends by reading its `'!dwX <verb>'` literals and proves some
* module under modules/driftwoodxi spells that word. A concatenated verb is
* invisible to that scan -- so the addon would be exempt from the one check
* that catches an addon newer than its server sending a verb the doorway has
* never heard of, whose refusal is a PUBLIC line in chat on every window open.
--]]
local LINES = {
    mine = '!dwsp mine',
    hall = '!dwsp hall',
};

--[[
* WHERE AN AWARD LANDED, by the wire's own code. The window says nothing at
* all for code 0: an item in your inventory is where an item goes, and a
* column that says "Inventory" thirty times is a column that hides the four
* rows worth reading.
--]]
local LANDED_WORD = {
    [0] = '',
    [1] = 'Mog Satchel',
    [2] = 'Mog Sack',
    [3] = 'Mog Case',
    [4] = 'another character',
    [5] = 'delivery box',
    [9] = 'lost',
};

local state = T{
    open = T{ false },

    -- The header counts and the two lists, COMMITTED ON z| from pending
    -- copies so a half-arrived reply can never half-fill the window.
    counts   = nil,      -- the c| record, as one table
    countsAt = nil,      -- os.clock() when it committed, so `now` can be aged
    rows     = nil,      -- the r| rows, newest first
    rowsAt   = nil,
    hall     = nil,      -- the w| rows, newest first
    hallAt   = nil,

    pendingCounts = nil,
    pendingRows   = nil,
    pendingHall   = nil,

    inbound   = nil,     -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,   -- a render error is worth saying once, not per frame

    -- The answer clock, keyed by verb: { [verb] = { at, tries } }. Keyed
    -- rather than single because the two reads are independent -- a hall
    -- answer arriving while a mine is outstanding must not mark the mine
    -- answered, or a lost list is never re-asked.
    requested    = T{ },
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until a zone
    -- line re-probes it. A click does NOT lift this one -- an addon that is
    -- the wrong version stays the wrong version.
    refused = false,

    -- The lazy hello has fired in THIS zone. Not "the rows are nil": a server
    -- that answers the ask with a refusal leaves them nil forever, and
    -- re-arming on emptiness asks once per throttle window for as long as the
    -- window stays open (the dwleaderboard lesson).
    helloSent = false,
    polledAt  = T{ },    -- per verb, so switching tabs does not reset the other
    nudgeAt   = nil,     -- os.clock() at which an award line should be collected

    -- Which tab is drawn, restored from the settings file; `wantTab` is a tab
    -- the player named on the command line and is spent the frame it is taken
    -- (the dwparse shape: SetSelected left standing fights the player's own
    -- clicks every other frame).
    tab     = rememberedTab(config),
    wantTab = nil,
};

-- The settings profile changes when the CHARACTER does, and the library hands
-- the new one over here.
pcall(settings.register, 'settings', 'dwspoils_settings_update', function (s)
    if (type(s) ~= 'table') then
        return;
    end

    config    = s;
    state.tab = rememberedTab(config);
end);

local function saveConfig()
    config.tab = state.tab;

    pcall(settings.save);
end

--[[
* THE TOOLTIPS, in one table rather than one literal per call site, so two
* controls that mean the same thing cannot drift into two sentences. The
* house rule: say what the control DOES, and for a greyed one say why it
* cannot right now; never repeat the label, never tooltip the self-evident.
--]]
local TIPS = {
    refresh      = 'Ask the server again, now. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks, and Refresh cannot fix that -- update dwspoils through the launcher.',
    lifetime     = 'Every piece of augmented gear ordinary kills have handed this ACCOUNT, since the ledger began.',
    fours        = 'How many of them carried four augments. Those are the ones the whole server hears about.',
    pips         = 'One pip per augment on the piece. Four pips are drawn in gold.',
    augs         = 'What the piece rolled, at the rank it rolled -- the same numbers your own bag shows. Hover the item for the full card.',
    monster      = 'What died for it, and the level it was. NM marks a notorious monster.',
    zone         = 'Where you were standing.',
    when         = 'How long ago, measured from the SERVER\'s own clock -- a machine whose clock is out still reads right.',
    landed       = 'Where the piece ended up. Nothing here means it went straight into your inventory.',
    rows         = 'The last thirty pieces this account was handed, newest first.',
    hallRows     = 'The last thirty four-augment awards on the server, newest first.',
    first        = 'Nobody on the server had ever been handed a four-augment copy of this item before.',
};

--[[
* Record parsing (dwsp protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST. This runs on every rendered frame for
    -- the life of the session and the queue is empty in almost all of them,
    -- while echo.canSend() is three calls across the C++ boundary
    -- (GetMemoryManager, GetPlayer, GetIsZoning). Asking it first spends a
    -- hundred and eighty of those a second to decide to do nothing.
    if (#queue == 0) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

-- Is anything outstanding? Deliberately NOT a render helper: the suite's
-- `d|`-wipe gate judges a name by whether some imgui-drawing function reads
-- it, and the ask table is bookkeeping rather than a pane.
local function asking()
    return next(state.requested) ~= nil;
end

local function latched()
    return state.refused or state.serverSilent;
end

-- `force` is the Refresh button: a click is the player asking, and the silent
-- latch exists to contain AUTOMATIC re-asks, not to ignore the player. The
-- PROTOCOL refusal is not lifted by a click.
local function ask(verb, force)
    if (state.refused) then
        return;
    end

    if (LINES[verb] == nil) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    -- ONE OUTSTANDING ASK AT A TIME. Two reads in flight is two lines in the
    -- client's chat throttle for a window that can only show one tab, and the
    -- answers arrive interleaved on a wire whose envelopes are not nested.
    if (not force and asking()) then
        return;
    end

    -- A CLICK REPLACES THE OLD ANSWER. Lifting a latch without clearing the
    -- sentence that set it leaves the last refusal red in the header while the
    -- window is actively asking again. Only a REFUSAL is dropped; a note is
    -- still true.
    if (force and state.statusBad) then
        state.status    = '';
        state.statusBad = false;
    end

    state.requested[verb] = { at = os.clock(), tries = 1 };
    state.polledAt[verb]  = os.clock();

    issue(LINES[verb]);
end

local function checkAnswers()
    for verb, asked in pairs(state.requested) do
        -- THE CLOCK DOES NOT AGE WHILE THE CLIENT IS ZONING -- it is
        -- RE-STAMPED, not merely skipped. A line still sitting in the queue
        -- behind echo.canSend() had already burned its timeout by the time it
        -- went out, so the retry fired 1.2 s behind the first send: both
        -- inside the client's chat settle window, both dropped, and the latch
        -- set with the server never asked.
        if (not echo.canSend()) then
            asked.at = os.clock();
        elseif ((os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries >= ANSWER_TRIES) then
                -- NO SENTENCE IS WRITTEN HERE: the header draws the silent
                -- latch in preference to state.status, so a line set here is
                -- never read and outlives the latch that hid it.
                state.requested[verb] = nil;
                state.serverSilent    = true;
            else
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue(LINES[verb]);
            end
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], -1);

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            --[[
            * THE REFUSAL RETIRES THE ASKS. A mismatched `d|` IS an answer --
            * the server spoke, in a dialect this addon does not read -- and
            * leaving the clock running against it costs twice: five seconds
            * later the retry goes out against the protocol document's own
            * promise to stop asking, and five after that the silent latch
            * paints "No answer from the server" over the accurate "Update
            * dwspoils" banner, which points the player at the server when the
            * addon is the problem.
            * The staging copies go too: they belong to an envelope that can no
            * longer be trusted to mean what this addon thinks it means.
            *
            * AND SO DOES THE QUEUE (2026-09-20, independent review). Retiring
            * the answer clock stops this addon ASKING again; it does not
            * unsend a line that is already sitting in the pump behind the
            * client's throttle. That line went out a beat later, the server
            * answered it in the same dialect, and the player read a second
            * identical red sentence about a version they cannot fix from
            * here -- a refusal that has to be said twice reads like a fault
            * rather than an instruction. Drained in place rather than
            * reassigned: `queue` is an upvalue the render pass reads for its
            * "asking..." line.
            --]]
            state.requested     = T{ };
            state.pendingCounts = nil;
            state.pendingRows   = nil;
            state.pendingHall   = nil;
            state.serverSilent  = false;

            for index = #queue, 1, -1 do
                table.remove(queue, index);
            end

            print(chat.header('dwspoils'):append(chat.error(string.format(
                'Server protocol %d, addon expects %d. Update dwspoils.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope proves the server is there (the silent
        -- latch lifts), but only the MATCHING verb retires its own ask.
        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.inbound == 'mine' or state.inbound == 'hall') then
            state.requested[state.inbound] = nil;
            state.pendingCounts            = { seen = false, lifetime = 0, fours = 0, now = 0 };

            -- A NEW ANSWER CLEARS THE OLD BANNER. Whatever the server wants to
            -- say about THIS answer rides inside this envelope as m| or e|,
            -- after this line.
            state.status    = '';
            state.statusBad = false;
        end

        if (state.inbound == 'mine') then
            state.pendingRows = T{ };
        elseif (state.inbound == 'hall') then
            state.pendingHall = T{ };
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        if (kind == 'e') then
            --[[
            * A REFUSAL INSIDE AN OPEN ENVELOPE KILLS THAT ANSWER. This is not
            * a rare shape: a door emits exactly `d|1|mine`, `e|Spoils is not
            * loaded on this build.`, `z|mine` when the core did not load, and
            * squad_storage's writer wraps ANY bare fail in the same three
            * lines. Committing that staging copy at z| would leave the tab
            * drawing "Nothing yet" -- a confident false sentence about a
            * server that answered nothing at all.
            --]]
            state.pendingCounts = nil;
            state.pendingRows   = nil;
            state.pendingHall   = nil;
        end

        -- A NOTE WITH NO SENTENCE IN IT SAYS NOTHING. `out:fail(nil)` writes a
        -- bare `e|`, and blanking the header with it is worse than ignoring
        -- it. The bookkeeping above still ran: a refusal with nothing to say
        -- is still a refusal.
        if (text == '') then
            return;
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwspoils'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    -- c| -- the account's lifetime counts and the SERVER's clock. Sent on both
    -- verbs, because both tabs draw the header line.
    if (kind == 'c' and state.pendingCounts ~= nil) then
        state.pendingCounts.seen     = true;
        state.pendingCounts.lifetime = wireInt(parts[2]);
        state.pendingCounts.fours    = wireInt(parts[3]);
        state.pendingCounts.now      = wireInt(parts[4]);

        return;
    end

    -- r| -- one award on this account, newest first.
    if (kind == 'r' and state.pendingRows ~= nil) then
        local augs           = parts[10] or '';
        local augList, augLine = decodeAugs(augs);

        state.pendingRows:append({
            id       = wireInt(parts[2]),
            at       = wireInt(parts[3]),
            itemId   = wireInt(parts[4]),
            augCount = wireInt(parts[5]),
            mobLvl   = wireInt(parts[6]),
            zoneId   = wireInt(parts[7]),
            nm       = wireInt(parts[8]) ~= 0,
            landed   = wireInt(parts[9]),
            augs     = augs,
            augList  = augList,
            augLine  = augLine,
            mobName  = parts[11] or '',
            taker    = parts[12] or '',
        });

        return;
    end

    --[[
    * w| -- one four-augment award anywhere on the server, newest first.
    *
    * THE TENTH FIELD IS NEW AND IT IS OPTIONAL (dwspoils 1.1.0 / server
    * 2026-09-21). It was APPENDED to the record rather than inserted, so this
    * branch reads it exactly the way client discipline 2 says an added field
    * is read: `parts[10]` is nil against a server that has not been updated,
    * decodeAugs answers nil twice, and the Hall draws what it drew in 1.0.0.
    * The protocol version did not move and must not -- a bump is a HARD
    * refusal on this side and would brick every installed copy over a field
    * they would otherwise have skipped.
    --]]
    if (kind == 'w' and state.pendingHall ~= nil) then
        local augs           = parts[10] or '';
        local augList, augLine = decodeAugs(augs);

        state.pendingHall:append({
            id       = wireInt(parts[2]),
            at       = wireInt(parts[3]),
            itemId   = wireInt(parts[4]),
            mobLvl   = wireInt(parts[5]),
            zoneId   = wireInt(parts[6]),
            first    = wireInt(parts[7]) ~= 0,
            charName = parts[8] or '',
            mobName  = parts[9] or '',
            augs     = augs,
            augList  = augList,
            augLine  = augLine,
        });

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        --[[
        * ONLY A COMPLETE ANSWER COMMITS. The staging copies are nil when a
        * refusal killed the envelope; the counts are present but hollow when
        * the reply ended before its `c|` arrived -- the client's chat rate
        * limit drops lines, which is the whole reason this addon carries an
        * answer clock. An EMPTY LIST is a legitimate answer and commits: a
        * player who has been handed nothing yet is told so in the tab's own
        * words.
        --]]
        local counts = state.pendingCounts;

        state.pendingCounts = nil;

        if (counts ~= nil and counts.seen) then
            state.counts   = counts;
            state.countsAt = os.clock();
        end

        if (closed == 'mine') then
            if (state.pendingRows ~= nil) then
                state.rows   = state.pendingRows;
                state.rowsAt = os.clock();
            end

            state.pendingRows = nil;
        elseif (closed == 'hall') then
            if (state.pendingHall ~= nil) then
                state.hall   = state.pendingHall;
                state.hallAt = os.clock();
            end

            state.pendingHall = nil;
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwspoils_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        -- BLOCKED BEFORE IT IS PARSED (the dwbags rule), and ONLY for this
        -- sender. The server's own `[Spoils] ` sentences carry no sender name
        -- of ours and are left exactly where the game put them. A record that
        -- throws inside handleRecord must still not reach the chat log: the
        -- player's window would fill with `r|12|178...|` for as long as the
        -- bug lived, and a parse error is exactly when that is most likely.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwspoils'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line invalidates the whole picture and re-probes every latch. The
    -- lazy hello re-arms with it: a player who zoned is exactly the one whose
    -- window has been shut for a while. A half-arrived envelope dies with the
    -- zone too, or its stray tail would be accepted into a stale pending copy
    -- on the far side.
    if (e.id == 0x000A) then
        state.requested     = T{ };
        state.serverSilent  = false;
        state.refused       = false;
        state.inbound       = nil;
        state.pendingCounts = nil;
        state.pendingRows   = nil;
        state.pendingHall   = nil;
        state.helloSent     = false;
        state.polledAt      = T{ };
        state.nudgeAt       = nil;

        -- A RED REFUSAL DOES NOT OUTLIVE THE PLACE IT WAS ABOUT. A note is
        -- still true after a zone and stays.
        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end
    end
end);

--[[
* The client's own item data, asked ONCE PER ID (the dwcpx shape, which is
* dwbags' by way of dwquest). The item DAT is static from load, so an id that
* answers nil now answers nil forever and a negative result caches as safely
* as a positive one. `false` is "the client does not know this id"; nil is
* "not asked yet".
--]]
local resources = { };

local function resourceOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    local hit = resources[itemId];

    if (hit ~= nil) then
        return hit ~= false and hit or nil;
    end

    local ok, item = pcall(function ()
        return AshitaCore:GetResourceManager():GetItemById(itemId);
    end);

    if (not ok or item == nil) then
        resources[itemId] = false;

        return nil;
    end

    resources[itemId] = item;

    return item;
end

local function itemName(itemId)
    local item = resourceOf(itemId);

    if (item == nil or item.Name == nil or item.Name[1] == nil or item.Name[1] == '') then
        return string.format('item %d', itemId or 0);
    end

    return item.Name[1];
end

local function zoneName(zoneId)
    if (zoneId == nil or zoneId <= 0) then
        return '';
    end

    local ok, name = pcall(function ()
        return AshitaCore:GetResourceManager():GetString('zones.names', zoneId);
    end);

    if (ok and type(name) == 'string' and name ~= '') then
        return name;
    end

    return string.format('zone %d', zoneId);
end

--[[
* The D3D device, fetched on first use rather than at load: this addon can be
* loaded from the launcher's boot script, long before the client has a
* rendering device, and a file-scope d3d.get_device() would make the whole
* addon fail to load (dwbags' lesson, kept verbatim through dwcpx).
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        local ok, dev = pcall(d3d.get_device);

        if (ok) then
            d3d8dev = dev;
        end
    end

    return d3d8dev;
end

--[[
* Item icons, from the client's own resources -- dwbags' iconOf/drawIcon by
* way of dwcpx, kept verbatim, reasoning and all: cached because the rows are
* redrawn every frame and D3DXCreateTextureFromFileInMemoryEx is not free;
* gc_safe_release hands back a texture that releases itself when Lua collects
* it, which is what keeps this from leaking across a reload.
--]]
local icons     = T{ };
local iconCount = 0;

local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = resourceOf(itemId);

    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;

        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;

        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));
    iconCount     = iconCount + 1;

    return icons[itemId];
end

--[[
* THE CEILING ON THE ICON CACHE (dwcpx 1.4.0's rule). Every entry is a live
* D3DPOOL_MANAGED texture and the key is an item id -- sixty-five thousand of
* them. FFXI is a 32-bit process that runs out of ADDRESSES long before it
* runs out of memory. Sixty rows can only ever hold sixty ids, so this is a
* brace rather than a working limit; it costs one comparison a frame.
*
* Dropped WHOLE rather than evicted one at a time (gc_safe_release owns the
* release, so letting go of the last reference IS the free), and dropped at
* the TOP OF A FRAME, never from inside iconOf: ImGui keeps the raw texture
* pointer in its draw list until Ashita renders that list at the end of the
* present hook.
--]]
local ICON_MAX = 256;

local function sweepIcons()
    if (iconCount < ICON_MAX) then
        return;
    end

    icons     = T{ };
    iconCount = 0;

    collectgarbage('collect');
end

--[[
* Rendering.
*
* MEASURED LAYOUT, NOT GUESSED (dwcraft's rule, reached here through
* dwunleashed). Both helpers read the LIVE font each frame and fall back to a
* conservative constant when a binding does not answer; the asymmetry is
* deliberate, because a fallback that is too big spends a few pixels of list
* and one that is too small hides a control the player needs to click.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

-- What a scrolling table must leave below itself: a table carrying ScrollY
-- owns a child window, and a child window given a ZERO outer height takes the
-- whole remaining content region -- so anything drawn after it lands below the
-- window's bottom edge. A NEGATIVE outer height reads as "available minus
-- this" (the dwnemesis footerReserve shape).
local function footerReserve()
    return -(metric('GetFrameHeightWithSpacing', 26) + 12);
end

-- One short tip on the item just drawn. Every plain tooltip in this file goes
-- through here so the pattern cannot drift call site by call site.
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

-- The server's clock at the moment the counts were built, advanced by however
-- long they have been on screen. THE CLIENT'S CLOCK IS ONLY EVER USED FOR THE
-- DELTA: a machine whose clock is minutes out still draws the right age,
-- because the base is the server's own `now`.
local function serverNow()
    if (state.counts == nil) then
        return 0;
    end

    local aged = state.countsAt ~= nil and math.max(0, os.clock() - state.countsAt) or 0;

    return state.counts.now + math.floor(aged);
end

-- "12 Sep 21:14"-ish is not available without a date library the client does
-- not ship, so a row is aged instead: how long ago, in the server's own clock.
local function ago(at)
    local now = serverNow();

    if (at <= 0 or now <= 0 or now < at) then
        return 'just now';
    end

    local seconds = now - at;

    if (seconds < 60) then
        return 'just now';
    end

    if (seconds < 3600) then
        return string.format('%dm ago', math.floor(seconds / 60));
    end

    if (seconds < 86400) then
        return string.format('%dh ago', math.floor(seconds / 3600));
    end

    return string.format('%dd ago', math.floor(seconds / 86400));
end

-- The augment pips. Four are GOLD, because four is the count the whole server
-- is told about; one to three are the theme's ordinary accent. Drawn as text
-- rather than as shapes so they scale with whatever font the player runs.
local function pips(count)
    local n = math.max(0, math.min(4, count or 0));

    if (n == 0) then
        imgui.TextDisabled('-');
        tip(TIPS.pips);

        return;
    end

    imgui.TextColored(n >= 4 and theme.colors.warn or theme.colors.hint, string.rep('*', n));
    tip(TIPS.pips);
end

--[[
* THE ITEM'S OWN CARD (the dwnemesis dropCard shape). The client already
* carries every word of this; a window that re-typed it would be a second
* source of truth for something the player can check in their own bag.
--]]
local FLAG_RARE = 0x8000;
local FLAG_EX   = 0x4000;

--[[
* The client packs an elemental-resistance icon as \239 plus a byte in the
* 0x1F..0x26 band. It is not UTF-8, so it renders as the '?' players reported
* against dwbags; each icon folds to a three-letter tag instead. MIRRORED BY
* HAND from dwnemesis 1.3.0 / dwah 1.4.0 / dwbags 1.17.0 -- edit one, revisit
* the others.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function (icon)
        return RESIST_TAGS[icon:byte()] .. ':';
    end));
end

local cardCache = { };

local function cardFor(itemId)
    local card = cardCache[itemId];

    if (card ~= nil) then
        return card;
    end

    local item = resourceOf(itemId);

    card = { };

    if (item ~= nil) then
        local tags = { };

        if (item.Level ~= nil and item.Level > 0) then
            tags[#tags + 1] = string.format('Lv %d', item.Level);
        end

        if (bit.band(item.Flags or 0, FLAG_RARE) ~= 0) then
            tags[#tags + 1] = 'Rare';
        end

        if (bit.band(item.Flags or 0, FLAG_EX) ~= 0) then
            tags[#tags + 1] = 'Ex';
        end

        if (#tags > 0) then
            card.tags = table.concat(tags, '  ');
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            card.desc = cleanDescription(desc);
        end
    else
        card.missing = true;
    end

    cardCache[itemId] = card;

    return card;
end

--[[
* `augList` is the decoded list this row carried, or nil; `augCount` is the
* wire's own count, which is all an old row (or an old server's Hall record)
* can offer. The card names every augment when it can and falls back to the
* count sentence when it cannot -- the 1.0.0 behaviour, kept exactly, because
* there are rows on prod written before the server sent any of this.
--]]
local function itemCard(itemId, augList, augCount, augs)
    local card = cardFor(itemId);

    imgui.BeginTooltip();
    imgui.Text(itemName(itemId));

    if (card.missing) then
        imgui.TextDisabled('(the client\'s own item data has nothing under this id)');
    else
        if (card.tags ~= nil) then
            imgui.TextDisabled(card.tags);
        end

        if (card.desc ~= nil) then
            imgui.Separator();
            imgui.PushTextWrapPos(320.0);
            imgui.Text(card.desc);
            imgui.PopTextWrapPos();
        end
    end

    imgui.Separator();

    --[[
    * WHICH AUGMENTS, NOT HOW MANY (1.1.0, the owner's ask). This line used to
    * end at "4 augment(s) on this piece." with the raw `1:5,2:9,25:3` under
    * it, on the reasoning that the catalog which turns one into a sentence is
    * DWQuest's and a second copy here would be a second thing to keep right.
    * The second half of that was true and is now handled the way dwbags, dwah
    * and dwwarehouse handle it -- a byte-identical copy of the SAME generated
    * file, gated -- and the first half meant the window drew everything about
    * a piece except the part the player opened it for.
    *
    * The raw pairs stay, dimmed, at the foot: they are what the server's own
    * log line and the `dw_spoils_ledger.augs` column spell, so a player
    * reporting something odd and the owner grepping for it are looking at the
    * same fourteen characters.
    --]]
    if (augList ~= nil) then
        imgui.TextDisabled(string.format('%d augment(s) on this piece:', #augList));

        for _, words in ipairs(augList) do
            imgui.TextColored(theme.colors.hint, '  ' .. words);
        end
    else
        imgui.TextDisabled(string.format('%d augment(s) on this piece.', augCount or 0));
    end

    if (augs ~= nil and augs ~= '') then
        imgui.TextDisabled(augs);
    end

    imgui.EndTooltip();
end

-- The icon cell. A row whose id the client cannot draw gets the same gap, so
-- the column never jumps between rows.
local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end
end

local function refreshTip()
    if (state.refused) then
        return TIPS.refreshStale;
    end

    local at = state.tab == 'hall' and state.hallAt or state.rowsAt;

    if (at == nil) then
        return TIPS.refresh;
    end

    return string.format('%s\nWhat is on screen arrived about %d second(s) ago.',
        TIPS.refresh, math.max(0, math.floor(os.clock() - at)));
end

local function renderHeader()
    if (imgui.Button('Refresh##dwsp_refresh')) then
        -- A click is the player asking: it lifts the liftable latch, clears a
        -- stale refusal, and re-asks whichever tab is on screen.
        ask(state.tab, true);
    end

    -- Built only when it is going to be read: refreshTip formats a sentence
    -- and reads the clock, and tip() would evaluate it every frame.
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(refreshTip());
    end

    imgui.SameLine();

    -- REFUSED OUTRANKS SILENT. A protocol mismatch is the one state here with
    -- an action attached to it, and the mismatch branch retires the answer
    -- clock precisely so the silent latch cannot paint over the sentence that
    -- is true.
    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwspoils through the launcher.');
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server. Refresh to ask again.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or asking()) then
        imgui.TextDisabled('asking...');
    elseif (state.counts ~= nil) then
        imgui.Text(string.format('%d award(s) on this account', state.counts.lifetime));
        tip(TIPS.lifetime);

        imgui.SameLine();

        imgui.TextColored(theme.colors.warn, string.format('   %d with four augments',
            state.counts.fours));
        tip(TIPS.fours);
    else
        imgui.TextDisabled('Anything that pays you experience can pay you gear.');
    end

    imgui.Separator();
end

local function renderMine()
    local rows = state.rows;

    if (rows == nil) then
        imgui.TextDisabled('Waiting for the server...');

        return;
    end

    if (#rows == 0) then
        -- THE ONE SENTENCE, and it says nothing about the odds beyond "a small
        -- chance" (owner, 2026-09-20). There is no rate on this wire and there
        -- is nothing here for a future version to read one out of.
        imgui.TextWrapped('Nothing yet. Every monster that pays you experience has a small '
            .. 'chance to hand you a piece of augmented gear, levelled to whatever died -- '
            .. 'straight into your bags, no lot and no trade.');

        return;
    end

    imgui.Text(string.format('Your last %d:', #rows));
    tip(TIPS.rows);
    imgui.Separator();

    if (imgui.BeginTable('dwsp_mine', 7,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad  = textWidth('nn', 14);
        local size = metric('GetTextLineHeight', 14) + 4;

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('##dwsp_icon', ImGuiTableColumnFlags_WidthFixed, size + pad);
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('Augs', ImGuiTableColumnFlags_WidthFixed, textWidth('Augs', 40) + pad);
        imgui.TableSetupColumn('Monster', ImGuiTableColumnFlags_WidthStretch, 2.6);
        imgui.TableSetupColumn('Zone', ImGuiTableColumnFlags_WidthStretch, 2.2);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, textWidth('999d ago', 66) + pad);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 1.8);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            drawIcon(row.itemId, size);

            imgui.TableNextColumn();
            imgui.Text(itemName(row.itemId));

            if (imgui.IsItemHovered()) then
                itemCard(row.itemId, row.augList, row.augCount, row.augs);
            end

            -- THE SECOND LINE, under the item, dimmed: what it rolled. Built
            -- once when the record arrived (decodeAugs), so this is one Text
            -- call and no formatting. A row the server sent no augments for
            -- simply does not get one, and the table's rows stay the height
            -- they were.
            if (row.augLine ~= nil) then
                imgui.TextDisabled(row.augLine);
                tip(TIPS.augs);
            end

            imgui.TableNextColumn();
            pips(row.augCount);

            imgui.TableNextColumn();

            if (row.nm) then
                imgui.TextColored(theme.colors.hint, string.format('%s (NM %d)',
                    row.mobName ~= '' and row.mobName or 'something', row.mobLvl));
            else
                imgui.Text(string.format('%s (%d)',
                    row.mobName ~= '' and row.mobName or 'something', row.mobLvl));
            end

            tip(TIPS.monster);

            imgui.TableNextColumn();
            imgui.Text(zoneName(row.zoneId));
            tip(TIPS.zone);

            imgui.TableNextColumn();
            imgui.Text(ago(row.at));
            tip(TIPS.when);

            imgui.TableNextColumn();

            local word = LANDED_WORD[row.landed];

            if (row.landed == 9) then
                imgui.TextColored(theme.colors.err, 'lost');
                tip(TIPS.landed);
            elseif (row.landed == 4) then
                imgui.TextDisabled(row.taker ~= '' and row.taker or 'another character');
                tip(TIPS.landed);
            elseif (word ~= nil and word ~= '') then
                imgui.TextDisabled(word);
                tip(TIPS.landed);
            else
                imgui.TextDisabled('');
            end
        end

        imgui.EndTable();
    end
end

local function renderHall()
    local rows = state.hall;

    if (rows == nil) then
        imgui.TextDisabled('Waiting for the server...');

        return;
    end

    if (#rows == 0) then
        imgui.TextWrapped('Nothing yet. A piece handed over with four augments is announced to '
            .. 'the whole server, and every one of them lands here.');

        return;
    end

    imgui.Text(string.format('The last %d on the server:', #rows));
    tip(TIPS.hallRows);
    imgui.Separator();

    if (imgui.BeginTable('dwsp_hall', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad  = textWidth('nn', 14);
        local size = metric('GetTextLineHeight', 14) + 4;

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, textWidth('999d ago', 66) + pad);
        imgui.TableSetupColumn('Who', ImGuiTableColumnFlags_WidthStretch, 1.8);
        imgui.TableSetupColumn('##dwsp_hall_icon', ImGuiTableColumnFlags_WidthFixed, size + pad);
        imgui.TableSetupColumn('What', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('Off', ImGuiTableColumnFlags_WidthStretch, 2.6);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 2.2);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.Text(ago(row.at));
            tip(TIPS.when);

            imgui.TableNextColumn();
            imgui.Text(row.charName ~= '' and row.charName or 'someone');

            imgui.TableNextColumn();
            drawIcon(row.itemId, size);

            imgui.TableNextColumn();

            if (row.first) then
                imgui.TextColored(theme.colors.warn, itemName(row.itemId));
            else
                imgui.Text(itemName(row.itemId));
            end

            if (imgui.IsItemHovered()) then
                itemCard(row.itemId, row.augList, 4, row.augs);
            end

            if (row.first) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.warn, '(first)');
                tip(TIPS.first);
            end

            -- The four, under the name. This is the tab's whole point: a Hall
            -- row is four augments BY DEFINITION, so the count was never the
            -- interesting number and which four always was.
            if (row.augLine ~= nil) then
                imgui.TextDisabled(row.augLine);
                tip(TIPS.augs);
            end

            imgui.TableNextColumn();
            imgui.Text(string.format('%s (%d)',
                row.mobName ~= '' and row.mobName or 'something', row.mobLvl));
            tip(TIPS.monster);

            imgui.TableNextColumn();
            imgui.Text(zoneName(row.zoneId));
            tip(TIPS.zone);
        end

        imgui.EndTable();
    end
end

--[[
* One tab. The remembered choice is written back only when the PLAYER moves,
* never when a `wantTab` from the command line takes the window somewhere for
* one frame -- and SetSelected is spent the frame it lands, because leaving it
* standing fights the player's own clicks on every other frame (the dwparse
* note).
--]]
local function tabItem(key, label, body)
    local flags = ImGuiTabItemFlags_None;

    if (state.wantTab == key) then
        flags = ImGuiTabItemFlags_SetSelected;
    end

    if (imgui.BeginTabItem(label, nil, flags)) then
        if (state.wantTab == key) then
            state.wantTab = nil;
        end

        if (state.wantTab == nil and state.tab ~= key) then
            state.tab = key;

            saveConfig();
        end

        body();
        imgui.EndTabItem();
    end
end

local function renderWindow()
    renderHeader();

    if (imgui.BeginTabBar('dwsp_tabs')) then
        tabItem('mine', string.format('My Spoils %d###dwsp_tab_mine',
            state.rows ~= nil and #state.rows or 0), renderMine);
        tabItem('hall', string.format('Hall of Four %d###dwsp_tab_hall',
            state.hall ~= nil and #state.hall or 0), renderHall);

        imgui.EndTabBar();
    end
end

ashita.events.register('d3d_present', 'dwspoils_present', function ()
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    sweepIcons();

    -- THE FIRST ASK IS LAZY AND IT IS ASKED HERE, the first frame the window
    -- is actually shown in this zone -- never on the zone line, never at load.
    -- That is what keeps this addon out of dwecho's ZONE_ORDER entirely: it
    -- adds nothing to the login burst, because a closed window says nothing.
    -- Every latch is consulted here as well as inside ask(): this test runs
    -- sixty times a second and the call it saves is not free.
    --
    -- IT ASKS FOR `wantTab` WHEN THERE IS ONE, and that is not a nicety.
    -- `/spoils hall` from a CLOSED window sets wantTab and opens the window,
    -- but wantTab is only consumed inside the render pass -- so a hello that
    -- read state.tab asked for the remembered tab, waited out an answer, and
    -- only then asked for the one the player actually named: two lines and a
    -- couple of seconds of "Waiting for the server..." on the tab in front of
    -- them (2026-09-20, independent review).
    if (not state.helloSent and not latched() and not asking()) then
        state.helloSent = true;

        ask(state.wantTab or state.tab);
    elseif (not latched() and not asking()) then
        local verb = state.tab;

        -- THE NUDGE. An award line has just gone by, so the list on screen is
        -- known stale; collect it once, a couple of seconds later.
        if (state.nudgeAt ~= nil and os.clock() >= state.nudgeAt) then
            state.nudgeAt = nil;

            ask(verb);
        else
            -- The poll, per verb, so opening the other tab asks for it at once
            -- rather than inheriting a clock that has just been stamped.
            local at = state.polledAt[verb];

            if (at == nil or (os.clock() - at) >= POLL_INTERVAL) then
                ask(verb);
            end
        end
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 700, 430 }, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE. Nothing in ImGui stops a window being dragged to
    -- nothing, and this one carries a two-tab bar and a seven-column table.
    -- 560 IS MEASURED, NOT ROUND: the seven columns' own minimum widths plus
    -- the padding between them, at the stock font.
    imgui.SetNextWindowSizeConstraints({ 560, 300 }, { 99999, 99999 });

    local visible = imgui.Begin('DriftwoodXI Spoils##dwspoils', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwspoils'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwspoils'):append(chat.message('Window closed. Everything it shows also works typed as !spoils.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwspoils_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    -- THE THROTTLE IS STAMPED BY WHAT THE PLAYER SENDS, NOT ONLY BY US. The
    -- limit it exists to respect is the CLIENT's, on chat, and that counts the
    -- player's own typing -- so an addon that stamps only from its own pump
    -- believes the channel is idle when it is not and fires into the same beat
    -- as a line the player typed. The client then drops one of them.
    if (message:sub(1, 5):lower() ~= '!dwsp') then
        lastSend = os.clock();
    end
end);

--[[
* THE AWARD NUDGE. The server's own `[Spoils] ` sentences are ordinary system
* chat and this handler LEAVES THEM ALONE -- it never blocks, never reroutes
* and never re-prints one. It reads a single fact off them: an award has just
* happened, so whatever is on screen is stale. The mode gate comes first (see
* NOTICE_MODE) and the tag must OPEN the cleaned line, or a player's yell
* would be able to drive this window's traffic.
--]]
local function plainText(raw)
    -- Two-byte tags and their argument first (Ashita's colour tags, the
    -- client's, the auto-translate brackets), then anything undrawable, then a
    -- leading clock the timestamp addon may have stamped.
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    text = text:gsub('[^\032-\126]', '');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return text;
end

ashita.events.register('text_in', 'dwspoils_text_in', function (e)
    if (e.blocked or e.injected) then
        return;
    end

    -- A closed window asks for nothing, so there is nothing to make stale.
    if (not state.open[1]) then
        return;
    end

    local raw = e.message_modified or e.message;

    if (raw == nil) then
        return;
    end

    -- THE MODE GATE FIRST. A missing mode refuses too: the live client always
    -- supplies one, so its absence is not a server line.
    local mode = e.mode_modified or e.mode;
    local low  = mode ~= nil and bit.band(mode, 0xFF) or nil;

    if (low ~= NOTICE_MODE) then
        return;
    end

    local line = (plainText(raw):gsub('^%s+', ''));

    -- THE TAG MUST OPEN THE LINE for either shape: a system sentence that
    -- merely CONTAINS the tag (one quoting something a player typed) is not a
    -- notice either.
    if (line:find(NOTICE_TAG, 1, true) ~= 1) then
        return;
    end

    local award = line:find(NUDGE_AWARD, 1, true) == 1;
    local lost  = line:find(NUDGE_LOST, 1, true) ~= nil;

    if (not award and not lost) then
        return;
    end

    -- Already pending: one nudge per settling window, not one per line. A
    -- party wiping a camp can produce two awards inside the delay.
    if (state.nudgeAt == nil) then
        state.nudgeAt = os.clock() + NUDGE_DELAY;
    end
end);

ashita.events.register('command', 'dwspoils_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, and a player
    -- who capitalises is not making a mistake.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/spoils' and first ~= '/dwspoils') then
        return;
    end

    e.blocked = true;

    -- `/spoils hall` OPENS the window on that tab rather than toggling it: a
    -- player who named a tab has already said what they want, and toggling the
    -- window shut on them because it happened to be open is the wrong answer
    -- to the only thing they said.
    if (#args > 1) then
        local word = args[2]:lower();

        if (word == 'hall' or word == 'mine') then
            state.wantTab  = word;
            state.open[1]  = true;
            state.reported = false;

            return;
        end

        print(chat.header('dwspoils'):append(chat.message('/spoils opens the window; /spoils hall opens it on the Hall of Four.')));

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwspoils_load', function ()
    print(chat.header('dwspoils'):append(chat.message('/spoils opens the Spoils window, /spoils hall opens it on the Hall of Four. Everything it shows also works typed as !spoils.')));
end);
