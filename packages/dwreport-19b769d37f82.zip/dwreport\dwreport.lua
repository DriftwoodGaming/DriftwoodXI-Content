--[[
* DriftwoodXI -- dwreport
*
* Bug reporting without leaving the game. Write what went wrong in the
* window, press Submit, and a report lands in the server owner's inbox with
* your character's real state attached.
*
* WHY THIS IS BETTER THAN A FORUM POST, and the reason the addon exists at
* all: a report that says "the trust healer will not cure me" is a guess
* about what happened. The same report with the server's own view of your
* jobs, your party, your position, your active quest step and the last
* dozen lines of your chat log is EVIDENCE, and evidence can be checked
* against the code before anyone has to reproduce anything. Half of bug
* triage is establishing what the reporter's state actually was; this skips
* that half.
*
* THE DIVISION OF LABOUR IS THE WHOLE DESIGN.
*
*   THE ADDON sends what only the client can know: what you typed, what
*   YOUR client thinks its zone and position are, what your chat log said,
*   which addons you have loaded, what you had targeted.
*
*   THE SERVER stamps everything else at the moment you submit -- jobs,
*   levels, HP, gil, equipment, party and squad, and (when dwtracker's
*   module is loaded) the exact quest and mission step its evaluator places
*   you on. The addon asserts none of that, because the addon cannot know
*   any of it, and a bug report full of confident client-side guesses would
*   be worse than no bug report.
*
* Where the two views disagree -- your client's zone is not the server's --
* the report says so. That disagreement is itself a bug.
*
* MARK THE MOMENT. Opening this window freezes a client-side snapshot right
* then, because you will spend the next minute typing and may well walk
* away, zone, or die while you do. The report carries how long ago the
* snapshot was taken and you can retake it whenever you like. `/dwr mark`
* freezes one without opening anything, for the "that was weird, I will
* write it up in a second" case.
*
* NOTHING OF YOURS IS SENT UNTIL YOU PRESS SUBMIT. The one line this addon
* sends on its own is the eight-character `!dwr hello` handshake, which
* carries nothing about you and exists so that no part of your report is
* ever sent to a server that would turn it into public /say (see
* `serverSpeaks` below, which is the most important rule in this file).
* This paragraph used to say "nothing is sent", and a file whose whole
* argument is that a bug report should not contain confident claims that
* are not exactly true should not open with one (1.1.0).
*
* The "What is sent" tab lists every field verbatim, and the two
* attachments that carry the most personal detail -- your chat log and your
* addon list -- are checkboxes whose setting is remembered. Turn one off and
* nothing is lost: "Copy report" puts the whole thing on your clipboard,
* `!dwr` typed by hand is the same protocol, and there is still a Discord.
--]]

addon.name    = 'dwreport';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.0';
addon.desc    = 'In-game bug reporting with your real game state attached.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line.
-- Fifteen bytes of sName on GP_SERV_COMMAND_CHAT_STD; the seventh name in
-- the suite, and nothing else on the server uses it.
local DATA_SENDER = '_DWRDATA';

local PROTOCOL = 1;

--[[
* Transport limits. These are the SERVER's numbers -- `hello` sends the real
* ones and they replace these -- but the defaults have to be right, because
* the form is drawn (and its character counters drawn with it) before the
* first handshake comes back.
--]]
local limits = {
    title    = 80,
    body     = 900,

    -- The payload of one `!dwr t` line. Fallback only -- the server's `h|`
    -- overrides it, so what actually ships is report_core.lua's CHUNK_MAX.
    -- 90, not 110: a two-digit-index line at 110 (`!dwr t 10 [...]`, 122
    -- chars) did not survive this command's send path -- the trailing `]`
    -- was lost, the server called it "Malformed chunk", and the report kept
    -- getting lost. 90 keeps the line at 102 and the local echo under the
    -- 128-byte chat buffer so dwecho still swallows it (see report_core.lua).
    chunk    = 90,
    chunks   = 26,

    cooldown = 45,
    spool    = true,
};

-- The smallest description box worth typing a bug report into: four lines
-- at the default font. Below the window's own minimum size it is never
-- reached; above it, it is what stops a very short window from collapsing the
-- box to nothing rather than trimming the footer.
local BODY_FLOOR = 72;

-- The widest payload a `!dwr t` line can carry and still arrive whole. Not a
-- preference: `!dwr t 26 [` is eleven characters and `]` is one, so this puts
-- the widest line at 102 -- and 122 was measured losing its trailing `]` in
-- the field. The server's `h|` may declare LESS and is followed; it may not
-- declare more (see the `h|` branch).
local CHUNK_CEILING = 90;

local function maxDocument()
    return limits.chunk * limits.chunks;
end

--[[
* FNV-1a over the assembled document, 8 hex chars.
*
* MUST MATCH modules/driftwoodxi/report_core.lua's fnv1a exactly (which in
* turn matches dwtracker's). Up to 26 separate chat lines carry one report,
* and a chat line can be dropped; a report silently missing its middle
* third would read perfectly and describe something nobody wrote. The hash
* is what makes that impossible rather than unlikely. The multiply is split
* at 16 bits because hash * 16777619 overflows the 2^53 integer range of a
* double.
--]]
local function fnv1a(text)
    local hash = 2166136261;

    for i = 1, #text do
        hash = bit.bxor(hash, string.byte(text, i)) % 4294967296;

        local lo = hash % 65536;

        hash = (((hash - lo) / 65536) * 16777619 % 65536) * 65536 + lo * 16777619;
        hash = hash % 4294967296;
    end

    return bit.tohex(hash);
end

--[[
* Fallback lists, replaced by the server's on `hello`. They exist so the
* form is usable the very first frame and so a server that answers late
* never shows an empty dropdown.
--]]
local DEFAULT_CATEGORIES = T{
    { key = 'quest',  label = 'Quest or mission'      },
    { key = 'combat', label = 'Combat or battle'      },
    { key = 'squad',  label = 'Squad / alt-trusts'    },
    { key = 'job',    label = 'Job, spell or ability' },
    { key = 'item',   label = 'Item, bags or AH'      },
    { key = 'zone',   label = 'Zone, NPC or map'      },
    { key = 'ui',     label = 'Addon, UI or launcher' },
    { key = 'text',   label = 'Wrong text or typo'    },
    { key = 'econ',   label = 'Gil, EXP or rewards'   },
    { key = 'other',  label = 'Something else'        },
};

local DEFAULT_SEVERITIES = T{
    { key = 'block', label = 'Blocked - I cannot continue' },
    { key = 'major', label = 'Major - badly wrong'         },
    { key = 'minor', label = 'Minor - works, but wrong'    },
    { key = 'look',  label = 'Cosmetic - just looks wrong' },
};

local DEFAULT_FREQUENCIES = T{
    { key = 'always', label = 'Every time'   },
    { key = 'often',  label = 'Most times'   },
    { key = 'some',   label = 'Now and then' },
    { key = 'once',   label = 'Only once'    },
};

--[[
* Chat capture.
*
* A ring of the last CHAT_KEEP lines, kept whether or not the window is
* open -- by the time you decide something was a bug, the lines that
* explain it have already scrolled. Nothing here leaves the client unless
* the Submit that sends it has the attachment box ticked.
*
* Our own records never reach this: they are blocked in packet_in, which
* runs before text_in ever sees them.
--]]
local CHAT_KEEP = 40;
local CHAT_SEND = 10;
local CHAT_WIDE = 110;

-- The two sentences that name CHAT_SEND, cut once at load. Both were
-- string.format calls in the render pass -- one on every frame the "What is
-- sent" tab was open -- to interpolate a constant into a fixed sentence.
local CHAT_ATTACH_CARD = string.format(
    'The last %i lines of your chat log, frozen at the marked moment.', CHAT_SEND);
local CHAT_ATTACH_ON = string.format(
    'The last %i lines of your chat log -- this box is ticked.', CHAT_SEND);

-- The Sent tab's receipt drawer. Well past the server's twenty-a-day per
-- character, and a ceiling rather than none because the list is per session
-- and a session can span several characters.
local SENT_KEEP = 60;

local chatRing  = T{ };

local function stripChat(text)
    local out = text;

    -- Auto-translate brackets are two-byte sequences; ask the client to
    -- spell them out rather than shipping the raw bytes.
    local ok, parsed = pcall(function ()
        return AshitaCore:GetChatManager():ParseAutoTranslate(text, true);
    end);

    if (ok and type(parsed) == 'string') then
        out = parsed;
    end

    -- Two-byte tags first, BOTH bytes -- dwquest.lua's plainText is the
    -- reference implementation and this is the same doctrine (PROD_LINUX.md
    -- 10.36). `\030`/`\031` are the colour tags Ashita's chat library writes,
    -- `\127` is the client's end-of-message pair (\127\49), and `\239` leads
    -- the auto-translate brackets for the case where ParseAutoTranslate above
    -- threw. Their ARGUMENT bytes are printable -- a bare `Q`, a trailing `1`
    -- -- so the blanket pass below deletes the tag and leaves the scar.
    out = out:gsub('[\030\031\127\239].', '');

    -- The line-break bytes become a seam SPACE, not nothing: the dat files
    -- break several messages across two lines (`<br>` renders as \007) and
    -- deleting the byte glues the halves together --
    -- "...for the target.(Progress: 2/2)".
    out = out:gsub('[\007\010\013]+', ' ');

    -- Then everything else that cannot be drawn: NUL padding, a tag byte that
    -- had no argument left to take. Everything downstream of here (the wire, a
    -- JSON file, an email) is happier for it.
    out = out:gsub('[^\032-\126]', '');
    out = out:gsub('^%s+', ''):gsub('%s+$', '');

    if (#out > CHAT_WIDE) then
        out = out:sub(1, CHAT_WIDE - 3) .. '...';
    end

    return out;
end

ashita.events.register('text_in', 'dwreport_text_in', function (e)
    -- Never capture our own chatter: the addon printing "Uploading 4/11"
    -- into the log it is about to attach is a feedback loop, and a silly
    -- thing to email someone.
    --
    -- `e.blocked` covers the same ground for a different author. dwecho
    -- swallows the client's echo of our own `!dwr` commands a few handlers
    -- earlier in this same event, and a line the player was never shown has
    -- no business in a report claiming to be what they saw. Any other addon
    -- that blocks a line is excluded for exactly that reason too.
    -- THE DRAWN LINE, NOT THE ARRIVED ONE (2026-08-15). Ashita hands a text_in
    -- handler both: `message` is what came off the wire, `message_modified` is
    -- what the player will actually READ once every handler registered ahead of
    -- this one has rewritten it -- and the bundled timestamp/colour addons load
    -- before the dw* block, so they always have. This addon's whole value is
    -- that the attached log is evidence of what the player saw, which makes it
    -- the last place that should have been capturing the pre-rewrite bytes.
    -- dwquest's parser documents the same rule. Fallback kept for the same
    -- reason dwecho has one: a missing field must not throw inside a chat
    -- handler.
    local raw = e.message_modified or e.message;

    -- Both spellings are tested for our own chatter: a handler ahead of us may
    -- have decorated the line, and either copy naming dwreport is still ours.
    if (e.blocked or raw == nil or raw:find('dwreport', 1, true) ~= nil
            or (e.message ~= nil and e.message:find('dwreport', 1, true) ~= nil)) then
        return;
    end

    local line = stripChat(raw);

    if (line == '') then
        return;
    end

    chatRing:append(line);

    while (#chatRing > CHAT_KEEP) do
        table.remove(chatRing, 1);
    end
end);

--[[
* The client-side snapshot -- "the marked moment".
*
* Every read is pcall'd and every field is optional. This function is
* called at exactly the moments the game is least well: after something
* went wrong, possibly mid-zone, possibly with a stale entity array. A
* snapshot that throws would cost the report the only account of the state
* it was written about, so a field that cannot be read is simply absent.
--]]
local function tryGet(fn, fallback)
    local ok, value = pcall(fn);

    if (not ok or value == nil) then
        return fallback;
    end

    return value;
end

--[[
* The memory manager, and the three views the snapshot reads.
*
* WRAPPED FROM 1.1.0, and this is the header's own promise finally kept: it
* says "every read is pcall'd and every field is optional", and every read
* below this point was -- but the four that FETCH the managers were not, and
* they are the ones most likely to answer nil. captureContext is called from
* the command handler, from packet_out and from the render pass, and only the
* last of those has a pcall over it, so `/report mark` at a moment when the
* party view is not there yet was an unhandled error rather than a snapshot
* with fewer fields in it.
--]]
local function memoryView(getter)
    return tryGet(function ()
        local memory = AshitaCore:GetMemoryManager();

        if (memory == nil) then
            return nil;
        end

        return memory[getter](memory);
    end, nil);
end

local function selfIndex()
    local party = memoryView('GetParty');

    if (party == nil) then
        return nil;
    end

    local index = tryGet(function () return party:GetMemberTargetIndex(0); end, nil);

    return (index ~= nil and index > 0) and index or nil;
end

--[[
* Who this client is playing right now, or nil if it cannot be told.
*
* Used for one question only: does a snapshot the player deliberately marked
* still belong to the character they are about to file it as? A read that
* fails answers "cannot tell", which is treated as "leave the mark alone" --
* the mark is the player's, and a snapshot is only ever thrown away here on
* positive evidence that it describes somebody else.
--]]
local function currentName()
    local party = memoryView('GetParty');

    if (party == nil) then
        return nil;
    end

    return tryGet(function () return party:GetMemberName(0); end, nil);
end

local function loadedAddonNames()
    return tryGet(function ()
        local manager = _G['AddonManager'];

        if (manager == nil) then
            return nil;
        end

        local names = T{ };
        local count = manager:Count();

        -- Ashita's collection getters are zero-based, but "is it" is a
        -- one-line question with a two-line answer that costs nothing to
        -- be right about either way.
        for i = 0, count - 1 do
            local name = manager:Get(i);

            if (name ~= nil and name ~= '') then
                names:append(name);
            end
        end

        if (#names == 0) then
            for i = 1, count do
                local name = manager:Get(i);

                if (name ~= nil and name ~= '') then
                    names:append(name);
                end
            end
        end

        return names;
    end, nil);
end

local function loadedPluginNames()
    return tryGet(function ()
        local manager = AshitaCore:GetPluginManager();

        if (manager == nil) then
            return nil;
        end

        local names = T{ };

        for i = 0, manager:Count() - 1 do
            local plugin = manager:Get(i);

            if (plugin ~= nil) then
                local name = plugin:GetName();

                if (name ~= nil and name ~= '') then
                    names:append(name);
                end
            end
        end

        return names;
    end, nil);
end

-- Frame pacing, sampled continuously so a "the game hitches here" report
-- can carry a number instead of an adjective.
local fps = { last = 0, accum = 0, frames = 0, value = 0 };

local function captureContext()
    local snap = {
        at = os.clock(),
    };

    local party  = memoryView('GetParty');
    local player = memoryView('GetPlayer');
    local entity = memoryView('GetEntity');
    local index  = selfIndex();

    snap.name = tryGet(function () return party:GetMemberName(0); end, nil);

    local zoneId = tryGet(function () return party:GetMemberZone(0); end, nil);

    if (zoneId ~= nil) then
        --[[
        * WRAPPED LIKE EVERY SIBLING FIELD, and floored before the `%i`.
        *
        * CORRECTED 1.1.0, because the reason first written here was wrong and
        * a wrong reason is worse than none: `%i` does NOT raise on a
        * fractional number under LuaJIT -- `string.format('%i', 2.5)` answers
        * '2' on the engine Ashita runs, and only Lua 5.3+ (which is the MAP
        * SERVER's engine, not this one) refuses it. The floor is therefore
        * tidiness, not a guard.
        *
        * The guard is the pcall, and the hazard it is really for is the line
        * below it: `AshitaCore:GetResourceManager()` can answer nil during a
        * zone, and indexing nil raises for certain. `GetMemberZone` answering
        * something that is not a number at all does the same to `%i`. This
        * was the one snapshot line whose reads sat outside tryGet, and
        * captureContext is called from the command handler and from
        * packet_out, neither of which has a pcall over it -- so every other
        * field here degrades to absent and this one took the addon with it.
        --]]
        snap.zone = tryGet(function ()
            local zoneName = tryGet(function ()
                return AshitaCore:GetResourceManager():GetString('zones.names', zoneId);
            end, nil);

            -- The id leads, because the server parses it back out to compare
            -- against its own zone. The name is for the human reading it.
            return string.format('%i %s', math.floor(zoneId), zoneName or '?');
        end, nil);
    end

    if (index ~= nil) then
        snap.pos = tryGet(function ()
            return string.format('x %.2f  y %.2f  z %.2f  yaw %.2f',
                entity:GetLocalPositionX(index),
                entity:GetLocalPositionY(index),
                entity:GetLocalPositionZ(index),
                entity:GetLocalPositionYaw(index));
        end, nil);

        snap.stance = tryGet(function ()
            return string.format('status %i  anim %i  mount %i',
                entity:GetStatus(index), entity:GetAnimation(index), entity:GetMountId(index));
        end, nil);
    end

    snap.jobs = tryGet(function ()
        local main = party:GetMemberMainJob(0);
        local sub  = party:GetMemberSubJob(0);

        if (sub ~= nil and sub > 0) then
            return string.format('%i/%i at %i/%i',
                main, sub, party:GetMemberMainJobLevel(0), party:GetMemberSubJobLevel(0));
        end

        return string.format('%i at %i', main, party:GetMemberMainJobLevel(0));
    end, nil);

    snap.vitals = tryGet(function ()
        return string.format('HP %i/%i  MP %i/%i  TP %i',
            party:GetMemberHP(0), player:GetHPMax(),
            party:GetMemberMP(0), player:GetMPMax(),
            party:GetMemberTP(0));
    end, nil);

    snap.target = tryGet(function ()
        local target = memoryView('GetTarget');

        -- INDEX 0 IS THE MAIN TARGET, and both of these take that index. The
        -- three sibling reads in this file pass it; these two did not, so
        -- under a binder that requires it the whole target section fell into
        -- tryGet's silent degradation and every bug report said "nothing
        -- targeted" -- the one field a targeting bug report is about.
        if (target == nil or target:GetIsActive(0) == 0) then
            return 'nothing targeted';
        end

        local tIndex = target:GetTargetIndex(0);
        local name   = entity:GetName(tIndex);

        return string.format('%s (index %i, %i%% HP, %.1f yalms)',
            (name ~= nil and name ~= '') and name or '?',
            tIndex,
            entity:GetHPPercent(tIndex),
            math.sqrt(entity:GetDistance(tIndex)));
    end, nil);

    snap.buffs = tryGet(function ()
        local names = T{ };

        -- Empty slots read 255; there are 32 of them and a report full of
        -- "255, 255, 255" would be worse than no buff list at all.
        for _, id in pairs(player:GetBuffs()) do
            if (id ~= nil and id > 0 and id ~= 255 and #names < 20) then
                local name = AshitaCore:GetResourceManager():GetString('buffs.names', id);

                names:append((name ~= nil and name ~= '') and name or tostring(id));
            end
        end

        return #names > 0 and names:concat(', ') or 'none';
    end, nil);

    snap.partyList = tryGet(function ()
        local names = T{ };

        for i = 0, 17 do
            if (party:GetMemberIsActive(i) == 1) then
                local name = party:GetMemberName(i);

                if (name ~= nil and name ~= '') then
                    names:append(name);
                end
            end
        end

        return #names > 0 and names:concat(', ') or 'solo';
    end, nil);

    snap.fps = string.format('%.1f', fps.value);

    snap.screen = tryGet(function ()
        return string.format('%ix%i', AshitaCore:GetSystemMetrics(0), AshitaCore:GetSystemMetrics(1));
    end, nil);

    local addons = loadedAddonNames();

    snap.addons = (addons ~= nil and #addons > 0) and addons:concat(' ') or 'unavailable';

    -- THREE ANSWERS, NOT TWO (1.1.0). "not loaded" is an assertion about the
    -- player's install, and it was being made on the strength of a read that
    -- had failed -- exactly the confident client-side guess this addon's
    -- header says would be worse than no bug report. A list we could not read
    -- says so.
    if (addons == nil or #addons == 0) then
        snap.tracker = 'unknown (addon list unreadable)';
    else
        snap.tracker = addons:contains('dwtracker') and 'loaded' or 'not loaded';
    end

    local plugins = loadedPluginNames();

    snap.plugins = (plugins ~= nil and #plugins > 0) and plugins:concat(' ') or 'unavailable';

    -- Frozen at the same instant as the rest, for the same reason: the
    -- lines that explain the bug are the ones on screen when it happened,
    -- not the ones on screen when the report was finally written.
    snap.chat = T{ };

    local from = math.max(1, #chatRing - CHAT_SEND + 1);

    for i = from, #chatRing do
        snap.chat:append(chatRing[i]);
    end

    -- Cut once, here, for the window's one-line summary of the snapshot. Both
    -- were gsubs inside contextLine, which is drawn sixty times a second and
    -- was re-answering a question that cannot change until the next snapshot
    -- replaces this one.
    if (snap.zone ~= nil) then
        snap.zoneShort = (snap.zone:gsub('^%d+%s*', ''));
    end

    if (snap.target ~= nil and snap.target ~= 'nothing targeted') then
        snap.targetShort = (snap.target:gsub('%s*%(.*$', ''));
    end

    return snap;
end

--[[
* Form state.
*
* The text buffers are the only thing in this addon that is genuinely
* precious -- everything else can be re-derived, and what the player wrote
* cannot. They survive a failed upload, a server refusal, a zone line and
* (via the draft file) a client crash, and are cleared only when the player
* says so.
--]]
local state = T{
    open = T{ false },

    title = T{ '' },
    body  = T{ '' },

    category  = 'other',
    severity  = 'minor',
    frequency = 'always',

    attachChat   = T{ true },
    attachAddons = T{ true },

    categories  = DEFAULT_CATEGORIES,
    severities  = DEFAULT_SEVERITIES,
    frequencies = DEFAULT_FREQUENCIES,

    context = nil,      -- the marked moment, or nil until one is taken

    -- True when that snapshot was taken DELIBERATELY (`/report mark`, the
    -- re-mark button, or a one-keystroke `/report <title>`) rather than by
    -- opening the window. Declared here from 1.1.0 because three separate
    -- code paths read it and it had never been named in one place; a
    -- deliberate mark is the only snapshot allowed to survive a window open,
    -- and it is spent when the report it was taken for is filed.
    contextMarked = false,

    status    = 'Ready.',
    statusBad = false,

    sent = T{ },        -- refs filed this session, newest first

    cooldown = 0,       -- seconds, from the server's q| record
    cooldownAt = 0,     -- os.clock() when that was true

    reported = false,   -- one render error printed, not sixty a second
};

--[[
* Say something to the player, wherever they are looking.
*
* With the window shut there is nowhere for a status line to be seen, and
* `!dwr status` typed by hand is a question that deserves an answer where it
* was asked. The window is the louder surface when it is open, so it keeps
* the line to itself then.
*
* A FILE LOCAL, not a closure inside handleRecord (1.1.0): it was rebuilt on
* every record, and a `hello` answer alone is a dozen of them.
--]]
local function announce(text, bad)
    state.status    = text;
    state.statusBad = bad;

    if (not state.open[1]) then
        if (bad) then
            print(chat.header('dwreport'):append(chat.error(text)));
        else
            print(chat.header('dwreport'):append(chat.message(text)));
        end
    end
end

--[[
* Send throttle. The client rate-limits outgoing chat and a !dwr line is a
* chat line, so everything queues here and drains at one command per
* interval, exact duplicates collapsed (dwbags' lesson, kept verbatim
* through dwtracker).
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

-- The addon's OWN last send, never stamped by the player's chat. The stall
-- detectors key off this: keyed off `lastSend` -- which the packet_out
-- handler pushes forward for every line the player types -- a player asking
-- "did that work?" in chat kept resetting the 12s detector, and a dropped
-- answer sat looking busy until the 180s dead-man timer instead.
local lastOwnSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

--[[
* The handshake, and only the handshake, jumps the queue.
*
* pumpQueue holds the HEAD of the queue while `serverSpeaks` is false, so a
* `!dwr hello` appended at the back of a queue full of held chunks can never
* be reached -- the line that would lift the hold sits behind the hold. It is
* also the honest ordering: every other line in this queue is waiting on the
* answer to this one.
*
* Nothing else may use this. Reordering `begin` ahead of a `t`, or a `t` ahead
* of another, is how a report arrives as somebody else's.
--]]
local function issueFirst(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:insert(1, command);
end

--[[
* Has this server ever answered a !dwr?
*
* THIS IS A SAFETY GATE, NOT A NICETY, and it is the single most important
* rule in this file. An unknown `!command` on this server falls through to
* ordinary /say chat (0x0b5_chat_std.cpp:121) -- so uploading a report to a
* server that does not speak dwreport would be the player PUBLICLY SAYING
* every line of their bug report, one hundred characters at a time, to
* whoever is standing nearby. Possibly including whatever their chat log
* had in it.
*
* So: no chunk is ever sent until a `hello` has come back in this session,
* proving the verb exists. `hello` itself is the only line we are willing
* to risk leaking, it is eight harmless characters, and it is spent only on a
* deliberate act: opening the window, pressing "Check server", typing a server
* verb, or having an upload in flight when a login line retires the proof
* under it (1.1.0). Three tries per login, whichever of those asked.
*
* THIS BLOCK SITS ABOVE pumpQueue, and must (1.1.0): pumpQueue reads
* `serverSpeaks` to hold a queued chunk whose proof expired under it, and a
* local referenced before its declaration resolves to a nil GLOBAL instead --
* which reads as "the server has never answered" on every frame and holds the
* queue shut for the life of the session. `sayHello` itself still lives below,
* because it needs `issueFirst`.
--]]
local serverSpeaks = false;
local helloAsked   = 0;
local helloTries   = 0;

--[[
* True once a `d|` arrived carrying a version this addon cannot read.
*
* It is a SEPARATE latch from `serverSpeaks` on purpose: this server does speak
* dwreport -- it answered -- and it is not going to answer any differently to
* being asked again, so the handshake must stand down rather than spend its
* three tries on doomed lines and leave the form saying "The server has not
* answered yet", which is the one thing that is definitely untrue. Cleared on
* the login line with the rest of the per-session facts: a map restart logs
* everyone out, so the server on the other side may well be the updated one.
--]]
local protocolBad  = false;

local HELLO_RETRY  = 20.0;
local HELLO_TRIES  = 3;

local function pumpQueue()
    -- THE EMPTY TEST FIRST (1.1.0). `canSend` is two calls into Ashita's
    -- memory manager, and this runs on every frame of every session whether
    -- or not this addon has anything to say -- which, for a bug reporter, is
    -- almost always. Asking "is there anything to send" before "may I send"
    -- costs a length read and answers the same question.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    --[[
    * THE SAFETY GATE IS A QUEUE RULE TOO (1.1.0), and this is the same rule
    * `serverSpeaks` states below -- applied at the moment a line LEAVES
    * rather than only at the moment it was queued.
    *
    * A report is twenty-odd lines draining over half a minute at this
    * throttle, and 0x000A serves a relog exactly as it serves a zone line, so
    * a map restart inside that window retires the handshake with the chunks
    * still sitting here. If that restart was a deploy that no longer carries
    * dwr.lua, every remaining `!dwr t` becomes ordinary public /say carrying a
    * piece of the player's report and, if they ticked the box, their chat log
    * -- which is precisely the catastrophe the gate exists to make
    * impossible, reached by the one route it was not watching. Worse, the
    * drain's resend rounds put the WHOLE report through that route three
    * times over.
    *
    * Held, not dropped: the upload's own clocks end it if the handshake never
    * comes back, and `resetUpload` drops these lines when they do.
    * `!dwr hello` is the one line this addon is willing to risk, and it is
    * the line that lifts the hold.
    --]]
    if (not serverSpeaks and queue[1] ~= '!dwr hello') then
        return;
    end

    lastSend    = now;
    lastOwnSend = now;

    echo.send(table.remove(queue, 1));
end


local function sayHello(force)
    if (serverSpeaks) then
        return;
    end

    -- A server that answered with a version this addon cannot read will answer
    -- the retry the same way. `force` does not override this one: the "Check
    -- server" button exists for a server that has said NOTHING, and this one
    -- has spoken.
    if (protocolBad) then
        return;
    end

    local now = os.clock();

    if (not force) then
        -- Bounded, because the failure mode of asking is the failure mode
        -- of every unknown !command here: it becomes /say. Three tries per
        -- login is enough to survive a dropped packet and few enough that a
        -- server without the module never turns this into a chant.
        if (helloTries >= HELLO_TRIES) then
            return;
        end

        if (helloAsked > 0 and (now - helloAsked) < HELLO_RETRY) then
            return;
        end
    end

    helloAsked = now;
    helloTries = helloTries + 1;

    issueFirst('!dwr hello');
end

--[[
* The upload.
*
* One document, split by BYTE COUNT into chunks and reassembled by
* concatenation, so no chunk needs to be a valid anything on its own and a
* boundary can fall anywhere. The server acknowledges with a bitmask of
* what it holds; when the queue has drained we compare, resend exactly what
* is missing, and only then ask it to file.
*
* Rounds rather than per-chunk timers: a chunk waiting its turn in a
* half-minute queue has not been lost, and a per-chunk timeout would spend
* the whole upload racing itself.
--]]
local MAX_ROUNDS     = 3;
local ACK_GRACE      = 3.0;
local ANSWER_TIMEOUT = 12.0;
local UPLOAD_DEAD    = 180.0;

local upload = {
    phase  = 'idle',    -- idle | hello | begin | drain | send | done
    parts  = { },
    n      = 0,
    hash   = '',
    mask   = 0,
    round  = 0,
    at     = 0,
    ref    = nil,

    -- When the client last stopped being able to send at all (a zone screen,
    -- character select). Zero means it can. See pumpUpload's hold.
    held   = 0,
};

--[[
* How many of THIS upload's chunks the server has acknowledged.
*
* Counted over `upload.n` bits and not all thirty-two (1.1.0): the mask is a
* number off a wire this addon does not control, and every use of the count
* is a comparison against `upload.n` -- the progress bar's numerator, and the
* test that decides the drain is finished. A mask with a bit set above the
* chunk count therefore both draws "28 / 11" and can end the drain before
* every chunk has actually landed, which is the one thing the acknowledgement
* exists to prevent. Bits this upload never claimed are not information about
* it.
--]]
local function received(mask, width)
    local count = 0;

    for i = 0, math.min((width or 32), 32) - 1 do
        if (bit.band(mask, bit.lshift(1, i)) ~= 0) then
            count = count + 1;
        end
    end

    return count;
end

local function uploadActive()
    return upload.phase ~= 'idle' and upload.phase ~= 'done';
end

--[[
* Drop this upload's own lines from the send queue.
*
* The queue drains at one line per SEND_INTERVAL, so an upload that ENDS --
* cancelled, refused, timed out, or answered by a server speaking a protocol
* this addon cannot read -- still has most of its `!dwr t` lines waiting their
* turn, and every one of them goes out over the following half minute at a
* server that has already said no. Under Cancel it is worse than untidy: the
* window says "Nothing was sent" while the report uploads itself behind the
* sentence.
*
* `!dwr hello` is deliberately spared. It is the handshake, not the upload,
* and it is the one line this addon is willing to risk.
--]]
local function dropUploadLines()
    for i = #queue, 1, -1 do
        local line = queue[i];

        if (line == '!dwr send' or line:sub(1, 11) == '!dwr begin '
                or line:sub(1, 7) == '!dwr t ') then
            table.remove(queue, i);
        end
    end
end

local function resetUpload()
    dropUploadLines();

    upload.phase  = 'idle';
    upload.parts  = { };
    upload.n      = 0;
    upload.mask   = 0;
    upload.round  = 0;
    upload.held   = 0;
end

--[[
* Document encoding. `key=value` records joined by `|`; values escape the
* two characters that could be mistaken for structure plus the newline.
* The server unescapes with the mirror of this and keeps unknown keys, so
* a newer addon can add a field without a server deploy.
--]]
local function esc(value)
    local out = tostring(value or '');

    out = out:gsub('\\', '\\\\');
    out = out:gsub('|', '\\p');
    out = out:gsub('\r', '');
    out = out:gsub('\n', '\\n');

    -- Everything the wire cannot carry becomes a space rather than a
    -- mystery: the outgoing chat buffer is bytes, and a stray control
    -- character in the middle of a report helps nobody.
    out = out:gsub('[^\032-\126\\]', ' ');

    return out;
end

--[[
* Trim priority, least valuable first.
*
* A FILE CONSTANT (1.1.0) rather than a table rebuilt inside buildDocument,
* which `documentSize` calls twice a second for the size meter -- and, more
* usefully, so the "What is sent" tab's sentence about the order and the order
* itself can be held against each other by the harness. A promise about what
* gets sacrificed that has drifted from the code doing the sacrificing is
* worse than no promise.
--]]
local SACRIFICE = T{ 'cl.plugins', 'cl.addons', 'cl.buffs', 'cl.screen', 'cl.fps' };

--[[
* Build the document, trimming optional attachments until it fits.
*
* THE ORDER OF SACRIFICE IS DELIBERATE. What the player wrote is never
* trimmed -- it is the report. The plugin list goes first (least often
* decisive), then the addon list, then buffs, then chat lines oldest-first.
* Whatever went is named in the returned list and shown in the window,
* because a report that quietly dropped its own evidence is exactly the
* kind of quiet wrongness this suite exists to rule out.
--]]
local function buildDocument()
    local dropped = T{ };
    local context = state.context;

    local core = T{
        { 'ti', state.title[1] },
        { 'ca', state.category },
        { 'sv', state.severity },
        { 'fr', state.frequency },
    };

    if (context ~= nil) then
        core:append({ 'mk', tostring(math.floor(os.clock() - context.at)) });
    end

    local optional = T{ };

    local function optionalField(key, value, name)
        if (value ~= nil and value ~= '') then
            optional:append({ key = key, value = value, name = name });
        end
    end

    if (context ~= nil) then
        -- FIRST, AND NEVER SACRIFICED (1.1.0): fifteen bytes that say whose
        -- client the rest of this section came off. A mark can outlive a
        -- character switch, and when it does the server's own zone
        -- cross-check reports `!! MISMATCH ... possible desync` at a reader
        -- who has no way to tell that the two halves are simply about two
        -- different characters. report_core renders every `cl.*` key it is
        -- given, so this needs no server deploy to appear.
        optionalField('cl.name', context.name, 'character name');
        optionalField('cl.zone', context.zone, 'zone');
        optionalField('cl.pos', context.pos, 'position');
        optionalField('cl.vitals', context.vitals, 'vitals');
        optionalField('cl.jobs', context.jobs, 'jobs');
        optionalField('cl.target', context.target, 'target');
        optionalField('cl.stance', context.stance, 'stance');
        optionalField('cl.party', context.partyList, 'party');
        optionalField('cl.fps', context.fps, 'fps');
        optionalField('cl.screen', context.screen, 'screen');
        optionalField('cl.tracker', context.tracker, 'dwtracker');
        optionalField('cl.buffs', context.buffs, 'buffs');

        if (state.attachAddons[1]) then
            optionalField('cl.addons', context.addons, 'addon list');
            optionalField('cl.plugins', context.plugins, 'plugin list');
        end
    end

    local chatLines = T{ };

    if (state.attachChat[1] and context ~= nil and context.chat ~= nil) then
        for _, line in ipairs(context.chat) do
            chatLines:append(line);
        end
    end

    -- CONCATENATED, NOT FORMATTED. `assemble` runs over every record in the
    -- document and is called again for each attachment the trimmer drops --
    -- and `documentSize` calls it twice a second for the size meter while the
    -- window is open. `a .. '=' .. b` is the same string for a third of the
    -- work; there is no formatting here, only joining.
    local function assemble()
        local records = T{ };

        for _, pair in ipairs(core) do
            records:append(pair[1] .. '=' .. esc(pair[2]));
        end

        for _, field in ipairs(optional) do
            records:append(field.key .. '=' .. esc(field.value));
        end

        for _, line in ipairs(chatLines) do
            records:append('lg=' .. esc(line));
        end

        -- Last, and deliberately: it is the longest field, and a truncated
        -- document (which cannot happen -- the hash would catch it -- but
        -- which a human may one day read half of in a log) should lose the
        -- description last, not first.
        records:append('bd=' .. esc(state.body[1]));

        return records:concat('|');
    end

    local function dropField(key)
        for i, field in ipairs(optional) do
            if (field.key == key) then
                dropped:append(field.name);
                table.remove(optional, i);

                return true;
            end
        end

        return false;
    end

    local document = assemble();
    local budget   = maxDocument();

    for _, key in ipairs(SACRIFICE) do
        if (#document <= budget) then
            break;
        end

        if (dropField(key)) then
            document = assemble();
        end
    end

    while (#document > budget and #chatLines > 0) do
        table.remove(chatLines, 1);

        if (not dropped:contains('older chat lines')) then
            dropped:append('older chat lines');
        end

        document = assemble();
    end

    return document, dropped;
end

--[[
* The assembled length, for the size meter and the "~N seconds" estimate.
*
* Both are drawn every frame and both answer a question that changes at
* typing speed, so assembling two kilobytes sixty times a second to answer
* it would be pure waste. Half a second is far below anything anyone
* notices moving.
--]]
local sizeCache = { at = 0, size = 0 };

local function documentSize()
    local now = os.clock();

    if (now - sizeCache.at > 0.5) then
        sizeCache.at   = now;
        sizeCache.size = #(buildDocument());
    end

    return sizeCache.size;
end

-- Typing moves the meter within half a second and nobody notices; TICKING AN
-- ATTACHMENT BOX moves it by hundreds of characters at once, and half a
-- second of the old figure beside a box the player just changed reads as the
-- box having done nothing. The cache is dropped on the events that are not
-- typing speed.
local function invalidateSize()
    sizeCache.at = 0;
end

local function beginUpload()
    local document, dropped = buildDocument();

    if (#document > maxDocument()) then
        state.status    = 'That report is too long even after trimming. Please shorten the description.';
        state.statusBad = true;

        return;
    end

    local parts = { };
    local n     = 0;

    for offset = 1, #document, limits.chunk do
        n = n + 1;
        parts[n] = document:sub(offset, offset + limits.chunk - 1);
    end

    upload.parts  = parts;
    upload.n      = n;
    upload.hash   = fnv1a(document);
    upload.mask   = 0;
    upload.round  = 0;
    upload.at     = os.clock();
    upload.ref    = nil;
    upload.phase  = 'begin';

    issue(string.format('!dwr begin %i %s', n, upload.hash));

    state.statusBad = false;

    if (#dropped > 0) then
        state.status = string.format('Uploading (%i lines). Trimmed to fit: %s.', n, dropped:concat(', '));
    else
        state.status = string.format('Uploading (%i lines)...', n);
    end
end

-- Queue every chunk the server has not acknowledged.
local function queueMissing()
    upload.round  = upload.round + 1;

    local queued = 0;

    for i = 1, upload.n do
        if (bit.band(upload.mask, bit.lshift(1, i - 1)) == 0) then
            issue(string.format('!dwr t %i [%s]', i, upload.parts[i]));
            queued = queued + 1;
        end
    end

    if (queued == 0) then
        upload.phase = 'send';
        issue('!dwr send');

        return;
    end

    upload.phase = 'drain';
end

local function pumpUpload()
    if (not uploadActive()) then
        return;
    end

    local now = os.clock();

    --[[
    * A LOAD SCREEN IS NOT A STALL (1.1.0).
    *
    * Both clocks below measure silence from the server, and neither can mean
    * anything while the client is on a zone screen: the queue is held shut
    * there (`pumpQueue`, and dwecho's canSend), nothing can leave, and
    * nothing can arrive. A zone that took longer than the twelve-second
    * answer clock therefore spent that clock on the load screen and told the
    * player "the server stopped answering" about a question it had not yet
    * been given the chance to answer -- throwing away an upload that was
    * fine, on the one client event most likely to happen mid-report.
    *
    * The anchors are pushed forward rather than the pump returning early,
    * because both clocks are absolute times: skipping the frame would let
    * the whole load screen count the moment it ended. Held, not dropped --
    * the same doctrine the queue itself follows.
    *
    * AND THE HOLD IS BOUNDED FROM ITS OWN ANCHOR, because pushing forward the
    * clock that watches you is an extend-on-activity window and one of those
    * without a ceiling never closes. `canSend` is also false when there is no
    * memory manager to ask -- at character select, after a disconnect -- so a
    * client that never comes back would otherwise leave the upload looking
    * busy for the rest of the session, with the Cancel button as the only
    * door out of it.
    --]]
    if (not echo.canSend()) then
        if (upload.held == 0) then
            upload.held = now;
        elseif (now - upload.held > UPLOAD_DEAD) then
            resetUpload();

            announce('The client never finished loading, so nothing was sent. Your report is still here -- press Submit to try again.', true);

            return;
        end

        upload.at   = now;
        lastOwnSend = now;

        return;
    end

    upload.held = 0;

    --[[
    * AN UPLOAD IN FLIGHT SPENDS THE HANDSHAKE (1.1.0).
    *
    * A login line retires `serverSpeaks`, and from this version pumpQueue
    * then holds every chunk until the verb is proven again -- so something
    * has to do the proving, or a report that was three lines from filed when
    * the map restarted sits in the queue until the dead-man timer. An upload
    * the player pressed Submit on is exactly as deliberate an act as an open
    * window, which is the only other place this ask is allowed.
    *
    * Bounded by HELLO_TRIES like every other ask. If the answer never comes,
    * the clocks below end the upload and `resetUpload` drops its lines --
    * which is the right outcome, because a server that will not answer
    * `hello` is a server no chunk may be sent to.
    --]]
    if (not serverSpeaks) then
        sayHello(false);
    end

    if (now - upload.at > UPLOAD_DEAD) then
        resetUpload();

        -- ANNOUNCED, NOT JUST SHOWN (1.1.0). The upload deliberately carries
        -- on with the window shut, so all three of these endings could happen
        -- where nobody was looking -- and a player who closed the window over
        -- a progress bar and was never told otherwise has every reason to
        -- believe their report was filed. The success path already reaches
        -- them (the server's own `m|` goes through announce); the failures
        -- did not.
        announce('The upload timed out. Your report is still here -- press Submit to try again.', true);

        return;
    end

    -- `begin` and `send` are single questions with single answers, so
    -- silence in either is a stall and not slowness -- and a stall the
    -- player is watching a progress bar through. Neither should be left to
    -- the three-minute dead-man timer, which exists for the case where
    -- something stops the client sending at all.
    if (upload.phase == 'begin' or upload.phase == 'send') then
        if (#queue == 0 and (now - lastOwnSend) > ANSWER_TIMEOUT) then
            resetUpload();

            announce('The server stopped answering. Your report is still here -- press Submit to try again.', true);
        end

        return;
    end

    if (upload.phase ~= 'drain') then
        return;
    end

    -- Still draining the throttle: not stalled, just slow on purpose.
    if (#queue > 0 or (now - lastOwnSend) < ACK_GRACE) then
        return;
    end

    if (received(upload.mask, upload.n) >= upload.n) then
        upload.phase = 'send';
        issue('!dwr send');

        return;
    end

    if (upload.round >= MAX_ROUNDS) then
        resetUpload();

        announce('Part of the report kept getting lost. Nothing was sent -- press Submit to try again.', true);

        return;
    end

    state.status = string.format('Resending %i missing line(s)...', upload.n - received(upload.mask, upload.n));

    queueMissing();
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* One number off the wire, or the addon's own if it is not one.
*
* A FILE LOCAL FROM 1.1.0, and not for tidiness: it was declared inside the
* `h|` branch, so it was the `h|` numbers alone that were bounded and `q|` --
* the other number this addon does arithmetic with -- was taken raw. LuaJIT's
* `tonumber` answers for 'nan', 'inf' and '1e300', and a cooldown of 1e300
* greys the Submit button with "Wait -9223372036854775808 more second(s)"
* until the next login, off one garbled chat line. Integrality is part of the
* test because `n ~= math.floor(n)` is true for NaN, which every plain
* magnitude comparison lets through.
--]]
local function bounded(value, low, high, fallback)
    value = tonumber(value);

    if (value == nil or value ~= math.floor(value) or value < low or value > high) then
        return fallback;
    end

    return value;
end

--[[
* A key that is really in a list, or the list's first key.
*
* The three dropdowns are the SERVER's lists, replaced whole on every
* handshake, while the selection is the player's and survives a draft file.
* A selection the incoming list does not carry drew the combo's fallback
* label -- "Something else" -- over a `ca=` the report still sent, so the
* window named one category and the mail arrived under another. Snapping the
* selection onto the list keeps the label and the wire the same fact.
--]]
--[[
* One dropdown entry off a `c|`, `v|` or `f|` record -- or nothing.
*
* BOTH FIELDS OR NEITHER (1.1.0). These records ride a fixed-width packet
* field and can therefore arrive short, and both halves of one are
* load-bearing: a nil LABEL is handed straight to `imgui.BeginCombo`, whose
* binding is a native call taking a string -- nil is not one, and a bad
* argument raised inside the render pass closes a window with a half-written
* bug report in it. A nil KEY is quieter
* and no better: the entry draws but can never be selected, because picking
* it assigns nil and `pickCombo` reads nil as "nothing was picked". A record
* that cannot be used is refused where it arrives rather than halfway down a
* frame.
*
* A FILE LOCAL rather than a closure inside handleRecord: a `hello` answer is
* a dozen of these records and the rest of this file learned that lesson from
* `announce`.
--]]
local function namedEntry(fields)
    local key   = fields[2];
    local label = fields[3];

    if (key == nil or key == '' or label == nil or label == '') then
        return nil;
    end

    return { key = key, label = label };
end

local function snapKey(list, current)
    for _, entry in ipairs(list) do
        if (entry.key == current) then
            return current;
        end
    end

    return (list[1] ~= nil) and list[1].key or current;
end

local inResponse = nil;
local pendingSets = nil;

-- Never reused, never renumbered: the ImGui id of a Sent row's Copy button is
-- minted once when the row is made. See the `r|` branch.
local sentSeq = 0;

-- Forward declaration: the draft machinery is defined below handleRecord,
-- but the r| (filed) branch must clear a filed draft -- a bare `clearDraft()`
-- here would resolve to a nil GLOBAL, not the local declared later. Assigned
-- its real body beside clearDraft.
local onReportFiled = function () end;

local function handleRecord(message)
    local fields = split(message, '|');
    local kind   = fields[1];

    if (kind == 'd') then
        local version = tonumber(fields[2]);

        -- A protocol this addon does not know is refused outright rather
        -- than half-parsed: dwbags' rule. The one thing that must not
        -- happen is a report the player believes was filed and was not.
        if (version ~= PROTOCOL) then
            inResponse  = nil;
            protocolBad = true;

            -- AND THE PENDING ASK IS RETIRED (1.1.0). An upload left sitting
            -- in `begin` or `send` is timed out by the answer clock twelve
            -- seconds later, and its sentence -- "The server stopped
            -- answering" -- then replaces the one accurate diagnosis on
            -- screen, about a server that had just answered. That is the
            -- exact failure harness_dwsuite.py's mismatch-branch gate exists
            -- to refuse, and this file was carrying it. resetUpload also
            -- drops the chunk lines still queued behind it: they carry the
            -- player's report to a server that cannot file it.
            resetUpload();

            state.status    = 'This server speaks a different dwreport version. Update the addon.';
            state.statusBad = true;

            return;
        end

        inResponse   = fields[3];
        serverSpeaks = true;

        if (inResponse == 'hello') then
            pendingSets = {
                categories  = T{ },
                severities  = T{ },
                frequencies = T{ },
            };
        end

        return;
    end

    if (inResponse == nil) then
        return;
    end

    if (kind == 'z') then
        -- A response that opened for `begin` or `send` and closed without
        -- moving the upload forward is a refusal: a cooldown, a daily
        -- limit, a spool the server cannot write. The player has already
        -- been told why by the `e|` that came with it; what must not happen
        -- is the upload sitting in a phase nothing will ever advance,
        -- looking busy for three minutes until the dead-man timer.
        if ((inResponse == 'begin' and upload.phase == 'begin') or
            (inResponse == 'send' and upload.phase == 'send')) then
            resetUpload();
        end

        if (inResponse == 'hello' and pendingSets ~= nil) then
            -- COMMITTED WHOLE, AND THE SELECTION MOVED WITH THEM (1.1.0). A
            -- list that no longer carries the selected key left the combo
            -- drawing its fallback over a key the report still sent.
            if (#pendingSets.categories > 0) then
                state.categories = pendingSets.categories;
                state.category   = snapKey(state.categories, state.category);
            end

            if (#pendingSets.severities > 0) then
                state.severities = pendingSets.severities;
                state.severity   = snapKey(state.severities, state.severity);
            end

            if (#pendingSets.frequencies > 0) then
                state.frequencies = pendingSets.frequencies;
                state.frequency   = snapKey(state.frequencies, state.frequency);
            end

            pendingSets = nil;
        end

        inResponse = nil;

        return;
    end

    if (kind == 'h') then
        --[[
        * THE TWO TRANSPORT NUMBERS ARE CLAMPED, and this is not defensiveness
        * for its own sake -- both are used as ARITHMETIC and neither had a
        * bound.
        *
        *   `chunk` is the STEP of `beginUpload`'s numeric for. A zero step is
        *   a Lua error ("'for' step is zero") raised from inside the render
        *   pass, which closes the window over the player's half-written
        *   report; a negative one silently produces a nought-chunk upload.
        *
        *   `chunks` indexes a 32-BIT MASK -- `bit.lshift(1, i - 1)` in
        *   queueMissing and `received`'s bit loop. report_core.lua's own
        *   comment says MAX_CHUNKS is 26 "and not 32" for exactly that
        *   reason, so the ceiling is a fact both halves know and only one of
        *   them was enforcing. Past 32 the shift wraps: chunk 33 acknowledges
        *   chunk 1, the received count can never reach it, and the upload burns
        *   its rounds and reports "part of the report kept getting lost".
        *
        * A server value outside the range is refused rather than taken, so
        * what stands is this addon's own working default. `bounded` is a file
        * local (declared above handleRecord) because `q|` needs it too.
        --]]
        limits.title    = bounded(fields[3], 1, 4096, limits.title);
        limits.body     = bounded(fields[4], 1, 65536, limits.body);

        --[[
        * AND THE CHUNK IS CAPPED AT WHAT THE LINE CAN CARRY (1.1.0).
        *
        * The `bounded` call alone accepted anything up to 150, which is a
        * declaration this client cannot deliver: `!dwr t 26 [` is eleven
        * characters and `]` is one more, so a 150-byte payload is a
        * 162-character line, and the send path was proven in the field to
        * lose the trailing `]` somewhere past 102 (DWREPORT.md, "Why the
        * chunk is 90 bytes"). Every chunk would then come back "Malformed
        * chunk" and the player would be told their report kept getting lost.
        *
        * Splitting SMALLER than the server allows is always safe -- the
        * server only ever checks that a payload is not too LONG -- so the
        * declaration is capped rather than followed. Raising the ceiling is
        * a coordinated change with report_core.lua's CHUNK_MAX and the
        * command's send path, not something a server can announce.
        --]]
        limits.chunk    = math.min(bounded(fields[5], 1, 150, limits.chunk), CHUNK_CEILING);
        limits.chunks   = bounded(fields[6], 1, 32, limits.chunks);
        -- Bounded with its siblings from 1.1.0: it stopped being a number the
        -- addon merely stored the moment the r| branch below began ARMING the
        -- local countdown from it, and `nan` reaches this from a `tonumber`
        -- on LuaJIT.
        limits.cooldown = bounded(fields[7], 0, 86400, limits.cooldown);
        limits.spool    = (tonumber(fields[8]) or 1) == 1;

        return;
    end

    if (kind == 'c' and pendingSets ~= nil) then
        local entry = namedEntry(fields);

        if (entry ~= nil) then
            pendingSets.categories:append(entry);
        end

        return;
    end

    if (kind == 'v' and pendingSets ~= nil) then
        local entry = namedEntry(fields);

        if (entry ~= nil) then
            pendingSets.severities:append(entry);
        end

        return;
    end

    if (kind == 'f' and pendingSets ~= nil) then
        local entry = namedEntry(fields);

        if (entry ~= nil) then
            pendingSets.frequencies:append(entry);
        end

        return;
    end

    if (kind == 'k') then
        --[[
        * AN ACKNOWLEDGEMENT IS ONLY EVER AN ANSWER TO A QUESTION THIS UPLOAD
        * ASKED, and until 1.1.0 this branch took any `k|` from any envelope
        * in any phase. Two things went wrong with that, both of them rare and
        * both of them expensive:
        *
        *   A mask arriving with no upload running -- a `t` ack still in
        *   flight when the previous attempt timed out -- called queueMissing
        *   against the NEW upload's `begin`, queueing chunks the new draft
        *   had not been declared for and burning one of its three rounds.
        *
        *   A `chunk` ack arriving after `!dwr send` had already gone out
        *   knocked the phase back to `drain`; the drain then finished a
        *   second time and sent `!dwr send` again. The first send files the
        *   report and clears the server's draft, so the second is refused
        *   with "No upload in progress" -- and that refusal overwrites the
        *   "Filed as DW-..." receipt the player is reading.
        *
        * So the envelope has to match the phase: the drain is started only by
        * the answer to our `begin`, and only the answer to our `send` may
        * restart it. Mid-drain, every `chunk` ack is ours and welcome.
        --]]
        if (not uploadActive()) then
            return;
        end

        if (upload.phase == 'begin' and inResponse ~= 'begin') then
            return;
        end

        if (upload.phase == 'send' and inResponse ~= 'send') then
            return;
        end

        -- `fields[2] or ''`: the two-argument tonumber demands a string and
        -- RAISES on nil, so a truncated `k` record (no second field at all)
        -- threw out of here into the packet handler's pcall and printed
        -- "bad record" at the player for a line they never sent.
        upload.mask = tonumber(fields[2] or '', 16) or 0;

        if (upload.phase == 'begin') then
            queueMissing();
        elseif (upload.phase == 'send') then
            -- The server answered `send` with a mask, which means it is
            -- missing something (or threw the parts away over a bad hash).
            -- Either way the fix is another round, not a failure.
            upload.phase = 'drain';
        end

        return;
    end

    if (kind == 'q') then
        -- BOUNDED LIKE ITS SIBLINGS (1.1.0). This was the one number this
        -- addon does arithmetic with that had no bound at all: `1e300` off a
        -- garbled line greys the Submit button with "Wait
        -- -9223372036854775808 more second(s)" until the next login, and a
        -- negative one is a countdown that has already run out. A figure the
        -- addon cannot use means "no cooldown known", which is what it
        -- believed a second earlier.
        state.cooldown   = bounded(fields[2], 0, 86400, 0);
        state.cooldownAt = os.clock();

        return;
    end

    if (kind == 'r') then
        -- A REFERENCE IS A STRING OR IT IS NOT A REFERENCE (1.1.0). These
        -- records ride a fixed-width packet field, so one can arrive short --
        -- and a nil ref reached `imgui.TextColored` on the Sent tab, a native
        -- call that takes a string and is handed something that is not one,
        -- closing the window over the receipt for a report that HAD been
        -- filed. The report is still
        -- filed; what is missing is the name for it, and saying so is the
        -- honest answer.
        local ref = fields[2];

        if (ref == nil or ref == '') then
            ref = '(no reference)';
        end

        upload.ref   = ref;
        upload.phase = 'done';

        --[[
        * THE ROW CARRIES ITS OWN BUTTON ID (1.1.0), for two reasons.
        *
        * It was `string.format('Copy##dwreport_copy_%i', index)` inside the
        * row loop -- one fresh string per row, sixty times a second, for a
        * label that never changes. With the drawer near its ceiling that is
        * sixty allocations a frame to draw a list nobody is typing into.
        *
        * And the INDEX was the wrong thing to key on anyway: rows are
        * inserted at the front, so filing a report renumbered every button
        * below it and ImGui saw the whole column as new widgets.
        --]]
        sentSeq = sentSeq + 1;

        state.sent:insert(1, {
            ref    = ref,
            title  = state.title[1],
            at     = os.date('%H:%M'),
            copyId = string.format('Copy##dwreport_copy_%i', sentSeq),
        });

        -- BOUNDED, like every other table in this suite that grows on an
        -- event. The server's daily limit is twenty per character and this
        -- list is per SESSION, so a player who works through several
        -- characters in one sitting is the case it needs a ceiling for; the
        -- files on the server are the record, this is the receipt drawer.
        while (#state.sent > SENT_KEEP) do
            table.remove(state.sent);
        end

        --[[
        * ARM THE COOLDOWN LOCALLY (1.1.0).
        *
        * The server charges it the moment it files, and the addon only ever
        * learned the number by being REFUSED: press Submit again straight
        * away and the whole `begin` round trip happened just to come back
        * with "Please wait 43 more second(s)", which reads as a failure
        * rather than as a rule.
        *
        * THE SERVER STILL OWNS THE RULE. This is the courtesy the house
        * doctrine allows a greyed button to be -- the countdown comes from
        * the handshake's own figure, and a `q|` from the server overwrites it
        * the moment the two disagree.
        --]]
        if (limits.cooldown > 0) then
            state.cooldown   = limits.cooldown;
            state.cooldownAt = os.clock();
        end

        state.status    = string.format('Filed as %s. Thank you.', ref);
        state.statusBad = false;

        -- The draft on disk is this report, flushed by the 3s timer while it
        -- was being written. Filed successfully, it must not be restored on
        -- the next login as a ready-to-resubmit form.
        onReportFiled();

        return;
    end

    if (kind == 'g') then
        -- GM listing; printed rather than shown, because it belongs to
        -- whoever typed `!dwr recent` by hand.
        print(chat.header('dwreport'):append(chat.message(string.format('%s  %s  [%s]  %s',
            fields[2] or '?', fields[4] or '?', fields[5] or '?', fields[6] or ''))));

        return;
    end

    if (kind == 'm') then
        announce(fields[2] or '', false);

        return;
    end

    if (kind == 'e') then
        announce(fields[2] or 'Refused.', true);

        --[[
        * A refusal during an upload ends it. Everything the player wrote is
        * still in the form; nothing is retried behind their back, because a
        * server that said no should not be asked again by a loop they cannot
        * see.
        *
        * THE PHASES ARE NAMED, not excluded (1.1.0). `begin` and `send` are
        * single questions with single answers, so an `e|` in either is the
        * answer and the upload is over. `drain` is not: its refusals are
        * per-chunk ("Malformed chunk"), and the right answer to those is the
        * resend round the drain is already going to do. `done` is not either
        * -- an unrelated refusal arriving after a successful file used to
        * wipe the receipt panel and put the Submit form back with the report
        * still in it.
        *
        * The old test excluded `send` as well, and report_core raises most of
        * its send-time refusals through `out:fail` with NOTHING open, so they
        * arrive as a bare `status` envelope whose `z|` does not match the
        * phase either. "Daily report limit reached." therefore left the
        * upload sitting in `send` until the answer clock replaced it with
        * "The server stopped answering" -- the accurate sentence overwritten
        * by the wrong one, twelve seconds later, every time.
        --]]
        if (upload.phase == 'begin' or upload.phase == 'send') then
            resetUpload();
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWRDATA is
* ours: consumed here and blocked so the chat log never sees it -- before
* parsing, so a malformed record cannot leak as noise.
--]]
ashita.events.register('packet_in', 'dwreport_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwreport'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Draft persistence.
*
* This addon is used precisely when things are going wrong, which includes
* the times the client goes down five seconds later. Losing a half-written
* report to the crash it was describing would be a small cruelty, so the
* form is mirrored to a file next to the launcher's theme and read back at
* load. Plain text, no schema, best-effort in both directions: a draft that
* will not load is simply not loaded.
--]]
local DRAFT_PATH = string.format('%s\\config\\dwreport-draft.txt',
    AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

local draftDirty = false;
local draftAt    = 0;

-- Typing is not a reason to touch the disk. The form marks itself dirty and
-- the present loop flushes at most every few seconds.
local function touchDraft()
    draftDirty = true;
end

local function saveDraft()
    draftDirty = false;
    draftAt    = os.clock();

    -- AN EMPTIED FORM IS NOT A DRAFT (1.1.0). The flush used to write the
    -- empty strings out like any other state, so a player who typed something,
    -- thought better of it and cleared the boxes had the old text handed back
    -- on their next login -- from the file the flush had already replaced with
    -- an empty one, or from the file that survived because the flush never ran.
    -- Either way the file goes rather than being written.
    if ((state.title[1] or '') == '' and (state.body[1] or '') == '') then
        pcall(os.remove, DRAFT_PATH);

        return;
    end

    pcall(function ()
        local file = io.open(DRAFT_PATH, 'wb');

        if (file == nil) then
            return;
        end

        file:write(string.format('%s\n%s\n%s\n%s\n%s',
            state.category, state.severity, state.frequency,
            (state.title[1] or ''):gsub('[\r\n]', ' '),
            state.body[1] or ''));

        file:close();
    end);
end

--[[
* Throw the draft away and mean it.
*
* CLEARING THE DIRTY FLAG IS HALF THE JOB, and until 1.1.0 only the filed-
* report path did it. `/report clear` and "Write another" both removed the
* file and left `draftDirty` standing, so the three-second flush wrote a
* fresh (empty) draft back over the top of the deletion a moment later --
* which is not a data loss but is a file the player asked to be gone,
* sitting there.
--]]
local function clearDraft()
    draftDirty = false;

    pcall(os.remove, DRAFT_PATH);
end

-- The r| handler's half of R1: a successfully filed report must not be
-- restored as a draft on the next login.
onReportFiled = function ()
    clearDraft();

    -- AND THE MARK IS SPENT WITH IT (1.1.0). A `/report mark` snapshot is
    -- deliberately allowed to outlive the moment it was taken -- that is the
    -- whole point of the verb -- but it must not outlive the report it was
    -- taken FOR. It did: after filing, closing the window and reopening it an
    -- hour later re-attached the hour-old snapshot, because `toggleWindow`
    -- refuses to re-capture over a deliberate mark and nothing ever cleared
    -- the flag. "Write another" had its own copy of this line; the door the
    -- player actually uses did not.
    state.contextMarked = false;
end;

local function loadDraft()
    pcall(function ()
        local file = io.open(DRAFT_PATH, 'rb');

        if (file == nil) then
            return;
        end

        local raw = file:read('*a');
        file:close();

        local lines = split(raw:gsub('\r', ''), '\n');

        if (#lines < 5) then
            return;
        end

        state.category  = lines[1] ~= '' and lines[1] or state.category;
        state.severity  = lines[2] ~= '' and lines[2] or state.severity;
        state.frequency = lines[3] ~= '' and lines[3] or state.frequency;
        state.title[1]  = lines[4] or '';

        -- The body is everything left, newlines intact.
        local rest = T{ };

        for i = 5, #lines do
            rest:append(lines[i]);
        end

        state.body[1] = rest:concat('\n');

        if (state.title[1] ~= '' or state.body[1] ~= '') then
            state.status = 'A draft from last time was restored.';
        end
    end);
end

--[[
* The two consent boxes, remembered.
*
* A SEPARATE FILE FROM THE DRAFT, and deliberately: the draft is DELETED the
* moment the form is empty (that is its own fix), and a player's decision that
* their chat log is nobody's business must not be thrown away with the report
* they made it for. Ticking a box is a choice about every future report, not
* about this one.
*
* It was being thrown away: both boxes came back ticked on every load, so a
* player who unticked "Attach recent chat" for privacy had it silently
* re-ticked the next time they logged in, and the next report carried the log
* they had said no to. The header calls these the two attachments that carry
* the most personal detail; a choice about those has to stick.
*
* `key=value` lines rather than positions, so a key this version does not know
* is ignored and one it does not find keeps its default -- which is what makes
* the file safe to read from an older or newer addon, and safe to be missing
* or half-written after a crash.
--]]
local PREFS_PATH = string.format('%s\\config\\dwreport-prefs.txt',
    AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

local function savePrefs()
    pcall(function ()
        local file = io.open(PREFS_PATH, 'wb');

        if (file == nil) then
            return;
        end

        file:write(string.format('chat=%i\naddons=%i\n',
            state.attachChat[1] and 1 or 0,
            state.attachAddons[1] and 1 or 0));

        file:close();
    end);
end

local function loadPrefs()
    pcall(function ()
        local file = io.open(PREFS_PATH, 'rb');

        if (file == nil) then
            return;
        end

        local raw = file:read('*a');
        file:close();

        if (type(raw) ~= 'string') then
            return;
        end

        local chatValue = raw:match('chat=(%d)');
        local addonValue = raw:match('addons=(%d)');

        if (chatValue ~= nil) then
            state.attachChat[1] = chatValue == '1';
        end

        if (addonValue ~= nil) then
            state.attachAddons[1] = addonValue == '1';
        end
    end);
end

loadDraft();
loadPrefs();

--[[
* Rendering
--]]
local function labelFor(list, key, fallback)
    for _, entry in ipairs(list) do
        if (entry.key == key) then
            return entry.label;
        end
    end

    return fallback;
end

--[[
* One hovered sentence, in the suite's shape.
*
* `IsItemHovered` + `SetTooltip` and nothing newer: the player's ImGui is
* whatever shipped with the Ashita they first installed, while this file
* reaches them through the content feed, so the newest-generation spellings
* (SetItemTooltip, BeginItemTooltip, the HoveredFlags family) are not
* available to write against.
--]]
-- How wide a hover card is allowed to get before its text wraps. Both cards
-- in this file draw lines that come off the client -- a chat line to
-- CHAT_WIDE, and the whole addon list on one line -- and a tooltip is a window
-- ImGui sizes to its widest line.
local CARD_WRAP = 460;

local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* One hovered sentence that did not come from this file.
*
* `SetTooltip` cannot wrap -- it is a whole tooltip in one call -- so the
* sentences in TIPS carry their own line breaks and are drawn with it. Text
* the PLAYER wrote, or that came off the wire, has no line breaks in it and no
* bound on its length (`limits.title` is a server-declared number), and a
* tooltip is a window ImGui sizes to its widest line. Those get a card.
--]]
local function tipWrapped(text)
    if (imgui.IsItemHovered()) then
        imgui.BeginTooltip();
        imgui.PushTextWrapPos(CARD_WRAP);
        imgui.TextWrapped(text);
        imgui.PopTextWrapPos();
        imgui.EndTooltip();
    end
end

--[[
* Live font metrics, with a conservative constant when a binding does not
* expose the call. dwcpx's helper, and its asymmetry: a fallback that is too
* big spends a few pixels of the description box, one that is too small hides
* the Submit button -- and this window carries NoScrollbar, so anything past
* the bottom edge is simply gone rather than scrolled to.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

--[[
* Does the player's ImGui have this call at all?
*
* dwfishing's helper, for dwah's lesson: an annotation is not proof. This
* addon reaches players through the content feed and runs on whatever Ashita
* build they installed first, and a nil global called inside the render pass
* is an error sixty times a second until the host unloads the addon -- which
* here would close a window with a half-written bug report in it.
--]]
local function guiHas(name)
    local ok, value = pcall(function ()
        return imgui[name];
    end);

    return ok and type(value) == 'function';
end

-- Both are all-or-nothing: no size floor rather than a broken one, and no
-- Copy button rather than one that does nothing when it is pressed.
local CAN_CONSTRAIN = guiHas('SetNextWindowSizeConstraints');
local CAN_CLIPBOARD = guiHas('SetClipboardText');

-- Latched if the call is there and refuses anyway (dwah proved that both
-- happen): asked once, then never again for the life of the session.
local constraintsBroken = false;

-- How wide a sample renders at the live font, for a column that must not clip
-- what it is sized to hold.
local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

-- GetContentRegionAvail answers WIDTH then HEIGHT (Ashita's IGuiManager
-- annotation, and LootScope reads the pair). The height is the one this file
-- needs and the one a single-value read would silently miss.
local function availHeight(fallback)
    if (type(imgui.GetContentRegionAvail) ~= 'function') then
        return fallback;
    end

    local ok, _, height = pcall(imgui.GetContentRegionAvail);

    if (ok and type(height) == 'number' and height > 0) then
        return height;
    end

    return fallback;
end

local function pickCombo(id, width, current, entries, fallback, hint)
    local chosen = nil;

    imgui.PushItemWidth(width);

    local open = imgui.BeginCombo(id, labelFor(entries, current, fallback));

    -- BEFORE the popup body, not after EndCombo: with the list open, the
    -- "last item" ImGui would answer IsItemHovered for is whatever the popup
    -- drew last, so a tooltip hung off the end of this function belongs to a
    -- Selectable rather than to the combo the player is pointing at.
    if (hint ~= nil) then
        tip(hint);
    end

    if (open) then
        for index, entry in ipairs(entries) do
            if (imgui.Selectable(string.format('%s##%s_%d', entry.label, id, index), entry.key == current)) then
                chosen = entry.key;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    return chosen;
end

local function coloredWrapped(color, text)
    imgui.PushStyleColor(ImGuiCol_Text, color);
    imgui.TextWrapped(text);
    imgui.PopStyleColor();
end

local function cooldownLeft()
    if (state.cooldown <= 0) then
        return 0;
    end

    local left = state.cooldown - (os.clock() - state.cooldownAt);

    return left > 0 and math.ceil(left) or 0;
end

--[[
* The snapshot's one-line summary, re-cut only when it can have changed.
*
* This sentence is drawn every frame and can change once a SECOND -- and only
* when the second it names rolls over, or when a new snapshot replaces the one
* it describes. Both are in the key, so the string is built about once a
* second instead of sixty times. (`zoneShort` and `targetShort` were the same
* argument one level down: they were two gsubs per frame over strings that
* cannot change at all until the next snapshot, and are now cut once in
* captureContext.)
--]]
local contextCache = { context = nil, age = -1, text = '' };

local function contextLine()
    if (state.context == nil) then
        return 'No moment marked yet -- one is taken when you open this window.';
    end

    local age = math.floor(os.clock() - state.context.at);

    if (contextCache.context ~= state.context or contextCache.age ~= age) then
        contextCache.context = state.context;
        contextCache.age     = age;
        contextCache.text    = string.format('Marked %s ago%s%s',
            age < 60 and string.format('%i second(s)', age) or string.format('%i minute(s)', math.floor(age / 60)),
            state.context.zoneShort ~= nil and (' in ' .. state.context.zoneShort) or '',
            state.context.targetShort ~= nil and (', targeting ' .. state.context.targetShort) or '');
    end

    return contextCache.text;
end

--[[
* The two-part size meter, re-cut only when one of its four numbers moves.
*
* The longest formatted string in the render pass, drawn every frame, and its
* inputs change at typing speed at the very fastest -- the report size behind
* it is a half-second cache of its own. Keyed on all four so a change to any
* of them shows immediately and a frame that changed nothing costs nothing.
--]]
local meterCache = { body = -1, used = -1, limit = -1, budget = -1, text = '' };

local function meterLine(bodyLen, used, budget)
    if (meterCache.body ~= bodyLen or meterCache.used ~= used
            or meterCache.limit ~= limits.body or meterCache.budget ~= budget) then
        meterCache.body   = bodyLen;
        meterCache.used   = used;
        meterCache.limit  = limits.body;
        meterCache.budget = budget;
        meterCache.text   = string.format(
            '%i / %i characters   |   report size %i / %i.   What did you do, what did you expect, what happened instead?',
            bodyLen, limits.body, used, budget);
    end

    return meterCache.text;
end

--[[
* The title box's own counter, re-cut only when it moves.
*
* Same reasoning as meterLine one function up: drawn every frame, changes at
* typing speed at the very fastest, and the server's declared limit changes
* about once a session.
--]]
local titleCache = { len = -1, limit = -1, text = '' };

local function titleMeter(len)
    if (titleCache.len ~= len or titleCache.limit ~= limits.title) then
        titleCache.len   = len;
        titleCache.limit = limits.title;
        titleCache.text  = string.format('(%i / %i)', len, limits.title);
    end

    return titleCache.text;
end

--[[
* The hover sentences, as a table.
*
* One place so the harness can hold them, and so the window's explanations
* stay in the addon's voice rather than each growing its own. Every control
* whose meaning is not its label is here; the self-evident ones deliberately
* are not.
--]]
local TIPS = {
    category  = 'Which part of the game this is about. It decides who reads it\nfirst -- a quest report and a combat report go to different eyes.',
    severity  = 'How badly this is hurting you right now.\n"Blocked" means you cannot continue at all; use it when that is true\nand it will be believed.',
    frequency = 'How reliably it happens. "Every time" is the most valuable\nanswer there is -- it means somebody can reproduce it in a minute.',
    title     = 'One line, the way you would say it out loud.\nIt becomes the subject of the mail, so "trusts will not heal in\nDynamis" beats "bug".',
    body      = 'What you did, what you expected, and what happened instead --\nin that order. Everything about your character is attached for you,\nso you never have to describe where you were or what you had on.',
    meter     = 'Left: how much of the description allowance you have used.\nRight: the whole report against the transport budget, which the\nattachments below share. Go over it and the attachments are trimmed\nin a fixed order and the window names what went -- what you wrote is\nnever trimmed.',
    context   = 'The client-side snapshot this report will carry, and how long\nago it was frozen. The server stamps everything else at the moment\nyou press Submit.',
    progress  = 'Chunks the server has acknowledged. The report goes up one\nchat line at a time because the client rate-limits chat; anything\nlost on the way is resent automatically.',
    cancel    = 'Stops the upload and drops the lines still waiting to go out.\nNothing is filed and nothing you wrote is lost.',
    another   = 'Clears the title and description for a new report and marks\nthe moment again. The reference above stays on the Sent tab.',
    submit    = 'Sends the report. Nothing has left your machine before this.',
    check     = 'Asks the server whether it speaks dwreport at all.\nUntil it answers, no part of your report is sent -- an unknown\ncommand on this server becomes ordinary /say.',
    copy      = 'Copies the reference to your clipboard.',
    copyReport = 'Copies everything this report would carry -- what you wrote and\nyour marked snapshot -- to your clipboard as plain text, so you can\npaste it into Discord. Nothing is filed by copying. The two\nattachment boxes above decide what goes, exactly as they do on Submit.',
    sentTab   = 'References for the reports you have filed since logging in.',
    sentEmpty = 'Only what you have filed since you logged in shows here.\nEvery report you have ever filed is on the server; this is a receipt\ndrawer, not the record.',
    liveValues = 'The client half of the report, exactly as it will be sent, off\nthe marked snapshot. The server half cannot be shown here because this\naddon does not know it -- the server stamps it when you press Submit.',
    collectTab = 'Every field this report carries, named in full.',
    reportTab = 'Write the report here.',
};

--[[
* The whole report as plain text, for the clipboard.
*
* THE ESCAPE HATCH THE HEADER PROMISES, MADE PRESSABLE (1.1.0). "Turn it off
* and nothing is lost: `!dwr` typed by hand is the same protocol, and there is
* still a Discord" -- but a player whose server does not speak dwreport, or
* speaks a version this addon cannot, had no way to get what they had written
* OUT of the window except by retyping it. That is the one moment this addon
* is most needed and was least useful.
*
* It obeys the two checkboxes exactly as the wire does: a player who unticked
* the chat log did not consent to it reaching their clipboard on the way to a
* Discord channel either.
*
* Forward-declared because the button that calls it is drawn in reportTab and
* the snapshot field list it walks is COLLECT_LIVE, which belongs beside the
* tab that documents it. The file already does this for `onReportFiled`.
--]]
local reportText = function () return ''; end;

--[[
* Put it on the clipboard, and say which "it" went.
*
* One door for the button and the `/report copy` command, so the two cannot
* drift and the sentence the player reads is the same wherever they pressed.
* The empty-form case is NOT refused: a player who wants to paste their state
* somewhere without writing a report first is doing something reasonable, and
* the copy says for itself that it carries no description. What it must never
* do is claim a report was copied when there was no report.
--]]
local function copyReport()
    if (not CAN_CLIPBOARD) then
        state.status    = 'This Ashita build has no clipboard call for addons to use.';
        state.statusBad = true;

        return false;
    end

    if (not pcall(imgui.SetClipboardText, reportText())) then
        state.status    = 'The clipboard refused that.';
        state.statusBad = true;

        return false;
    end

    local written = (state.title[1] or '') ~= '' or (state.body[1] or '') ~= '';

    state.status = written
        and 'The whole report is on your clipboard. Nothing was filed.'
        or 'Your marked state is on your clipboard -- there is nothing written yet.';
    state.statusBad = false;

    return true;
end

--[[
* What the description box must leave below itself.
*
* Everything drawn under it in reportTab, charged for at the live font: the
* two-line size meter, the context sentence, the button-and-checkbox row, the
* Submit row, the status sentence (which is a whole refusal off the wire and
* wraps), and the three separators with the window's bottom padding.
--]]
local function footerReserve()
    local line  = metric('GetTextLineHeightWithSpacing', 17);
    local frame = metric('GetFrameHeightWithSpacing', 23);

    -- Five text lines and two button rows, which is the Submit branch -- the
    -- tallest of the three. The size meter wraps to two lines at any width
    -- this window can be dragged to; the context sentence is one; the status
    -- is a whole refusal off the wire and is charged for two. The constant is
    -- the three separators and the window's own bottom padding.
    local reserve = line * 5 + frame * 2 + 32;

    -- "Check server" and "Copy report" share a row of their own below the
    -- Submit row: the first is drawn only while the server has said nothing
    -- at all, the second whenever the player's ImGui has a clipboard call.
    -- One row is charged for whenever either of them can be drawn.
    if (CAN_CLIPBOARD or (not serverSpeaks and not protocolBad)) then
        reserve = reserve + frame;
    end

    return reserve;
end

-- Reasons this report cannot be submitted right now, most blocking first.
local function submitBlockers()
    local reasons = T{ };

    if (protocolBad) then
        -- Named apart from silence, because they want opposite answers: this
        -- server DID answer, and pressing "Check server" would only ask it to
        -- say the same thing again.
        reasons:append('This server speaks a dwreport version this addon does not. Update through the launcher.');
    elseif (not serverSpeaks) then
        reasons:append('The server has not answered yet. Press "Check server" below.');
    elseif (not limits.spool) then
        reasons:append('The server has bug reporting switched off right now.');
    end

    if (#(state.title[1] or '') < 6) then
        reasons:append('Give it a title (at least 6 characters).');
    end

    if (#(state.body[1] or '') < 20) then
        reasons:append('Describe what happened (at least 20 characters).');
    end

    local left = cooldownLeft();

    if (left > 0) then
        reasons:append(string.format('Wait %i more second(s) between reports.', left));
    end

    return reasons;
end

local function reportTab()
    imgui.TextWrapped('Tell us what went wrong. Your character\'s state is attached automatically, so you do not have to describe where you were or what you had on.');
    imgui.Separator();

    local picked = pickCombo('##dwreport_cat', 190, state.category, state.categories,
        'Something else', TIPS.category);

    if (picked ~= nil) then
        state.category = picked;
        touchDraft();
    end

    imgui.SameLine();
    imgui.Text('What is it about');

    picked = pickCombo('##dwreport_sev', 190, state.severity, state.severities,
        'Minor', TIPS.severity);

    if (picked ~= nil) then
        state.severity = picked;
        touchDraft();
    end

    imgui.SameLine();
    imgui.Text('How bad');

    picked = pickCombo('##dwreport_freq', 190, state.frequency, state.frequencies,
        'Every time', TIPS.frequency);

    if (picked ~= nil) then
        state.frequency = picked;
        touchDraft();
    end

    imgui.SameLine();
    imgui.Text('How often');

    imgui.Spacing();
    imgui.Text('Title');

    --[[
    * AND HOW MUCH OF IT IS LEFT (1.1.0). The description box has a two-part
    * meter under it; the title box had no number anywhere. `InputText` simply
    * stops accepting keystrokes at the buffer size, so a player writing a
    * long title hit an invisible wall with nothing on screen to explain it --
    * and the title is the one field that becomes the subject line, so it is
    * the one they are most likely to labour over. Warn-coloured at the wall,
    * because that is the moment the number is the answer to a question.
    --]]
    local titleLen = #(state.title[1] or '');

    imgui.SameLine();
    imgui.TextColored(titleLen >= limits.title and theme.colors.warn or theme.colors.dim,
        titleMeter(titleLen));

    imgui.PushItemWidth(-1);

    if (imgui.InputText('##dwreport_title', state.title, limits.title + 1)) then
        touchDraft();
    end

    tip(TIPS.title);
    imgui.PopItemWidth();

    imgui.Text('What happened');

    --[[
    * THE DESCRIPTION BOX GROWS WITH THE WINDOW (1.1.0).
    *
    * It was a hard 150 pixels tall, which made the window's height do nothing
    * useful in either direction: dragged taller, the box a player is spending
    * a minute typing into stayed the same size and the extra space went to
    * nothing; dragged shorter, the meter, the Submit button and the status
    * line went off the bottom edge -- and this window passes NoScrollbar, so
    * off the bottom edge means gone rather than scrolled to.
    *
    * Sized from what is actually left instead, minus what is drawn below it,
    * with a floor so it is always a box you can see a sentence in. The window
    * also has a minimum size now (see the present handler), so the floor is
    * the belt to that pair of braces rather than the only guard.
    --]]
    local bodyHeight = math.max(BODY_FLOOR, availHeight(246) - footerReserve());

    if (imgui.InputTextMultiline('##dwreport_body', state.body, limits.body + 1, { -1, bodyHeight })) then
        touchDraft();
    end

    tip(TIPS.body);

    -- Two meters, because they measure different things and both can bite.
    -- The first is the server's cap on the description; the second is the
    -- transport budget the whole report shares, which the attachments eat
    -- into. Showing the second is what stops "why did it drop my chat log"
    -- from ever being a surprise.
    local used   = documentSize();
    local budget = maxDocument();

    coloredWrapped(used > budget and theme.colors.warn or theme.colors.dim,
        meterLine(#(state.body[1] or ''), used, budget));

    tip(TIPS.meter);

    imgui.Separator();

    coloredWrapped(theme.colors.dim, contextLine());
    tip(TIPS.context);

    --[[
    * 'Mark again', not 'Mark this moment again' (1.1.0). This button shares a
    * row with the two consent checkboxes and nothing on that row wraps, so
    * the row's width is the width the whole window has to be able to reach:
    * at the twenty-two characters it used to carry, the row came to more than
    * the minimum size the window itself invited the player to drag to, and
    * "Attach addon list" was clipped off the right edge at a size the window
    * said was allowed. The checkbox labels are the ones that had to stay
    * spelled out -- they are the consent surface -- and the sentence directly
    * above this button already says what was marked and when.
    --]]
    if (imgui.Button('Mark again')) then
        state.context       = captureContext();
        state.contextMarked = true;
        state.status        = 'Snapshot retaken.';
        state.statusBad     = false;
    end

    -- The noun the shortened label had to drop lives here instead.
    tip('Marks the moment again: re-reads your zone, position, target,\nbuffs and recent chat as they are right now. Use this if you have\nreproduced the bug since opening this window.');

    imgui.SameLine();

    if (imgui.Checkbox('Attach recent chat', state.attachChat)) then
        -- Ticking it changes what the report will carry, and the size meter
        -- reads a half-second cache -- so the meter would have gone on
        -- showing the old figure for up to half a second after the box moved.
        invalidateSize();

        -- And the choice outlives this report: see savePrefs.
        savePrefs();
    end

    --[[
    * THE HOVER CARD IS THE POINT, not decoration (1.1.0). This checkbox is
    * the single most personal thing the addon can attach and the one field
    * the transparency tab could only describe in the abstract ("the last ten
    * lines"). Hovering it now shows the exact lines that will go, from the
    * marked moment -- so "what am I about to send" is answered by showing it
    * rather than by promising.
    --]]
    if (imgui.IsItemHovered()) then
        imgui.BeginTooltip();

        -- A TOOLTIP IS A WINDOW SIZED TO ITS WIDEST LINE, and every line in
        -- this one comes off the client: stripChat lets a chat line run to
        -- CHAT_WIDE, which at the client's font is a card most of a screen
        -- wide for a hover. Wrapped at a readable measure instead; popped on
        -- the way out, because a wrap position left pushed applies to
        -- everything drawn after it.
        imgui.PushTextWrapPos(CARD_WRAP);

        imgui.TextColored(theme.colors.hint, CHAT_ATTACH_CARD);
        imgui.TextColored(theme.colors.dim, 'By far the most useful thing you can attach.');
        imgui.Separator();

        local lines = state.context ~= nil and state.context.chat or nil;

        if (lines == nil or #lines == 0) then
            imgui.TextColored(theme.colors.inert, '(nothing in the log yet)');
        else
            for _, line in ipairs(lines) do
                imgui.TextWrapped(line);
            end
        end

        imgui.PopTextWrapPos();
        imgui.EndTooltip();
    end

    imgui.SameLine();

    if (imgui.Checkbox('Attach addon list', state.attachAddons)) then
        invalidateSize();
        savePrefs();
    end

    if (imgui.IsItemHovered()) then
        imgui.BeginTooltip();

        -- The widest line this addon ever draws: every addon the player has
        -- loaded, joined by spaces. Unwrapped it is a card wider than the
        -- screen on a heavily modded install.
        imgui.PushTextWrapPos(CARD_WRAP);

        imgui.TextColored(theme.colors.hint, 'Which addons and plugins you have loaded.');
        imgui.TextColored(theme.colors.dim, 'Worth leaving on for anything UI-shaped.');
        imgui.Separator();
        imgui.TextWrapped(state.context ~= nil and (state.context.addons or 'unavailable') or 'unavailable');
        imgui.PopTextWrapPos();
        imgui.EndTooltip();
    end

    imgui.Separator();

    if (uploadActive()) then
        local done = received(upload.mask, upload.n);

        imgui.ProgressBar(upload.n > 0 and (done / upload.n) or 0, { -1, 0 },
            string.format('%i / %i', done, upload.n));

        tip(TIPS.progress);

        if (imgui.Button('Cancel upload')) then
            -- RESET FIRST, THEN ASK. resetUpload drops the chunk lines still
            -- queued behind this one; issuing the cancel before it would put
            -- the cancel in the queue BEHIND twenty `!dwr t` lines, which then
            -- uploaded the whole report over the next half minute underneath
            -- a sentence saying nothing had been sent.
            resetUpload();
            issue('!dwr cancel');

            state.status    = 'Upload cancelled -- nothing was filed. Everything you wrote is still here.';
            state.statusBad = false;
        end

        tip(TIPS.cancel);
    elseif (upload.phase == 'done') then
        coloredWrapped(theme.colors.ok, string.format('Sent. Your reference is %s -- quote it if you talk to staff.', upload.ref or '?'));

        if (CAN_CLIPBOARD and upload.ref ~= nil) then
            if (imgui.Button('Copy reference')) then
                if (pcall(imgui.SetClipboardText, upload.ref)) then
                    state.status    = string.format('%s copied to the clipboard.', upload.ref);
                    state.statusBad = false;
                end
            end

            tip(TIPS.copy);
            imgui.SameLine();
        end

        if (imgui.Button('Write another')) then
            state.title[1] = '';
            state.body[1]  = '';
            upload.phase   = 'idle';
            state.context  = captureContext();
            state.contextMarked = false;
            state.status   = 'Ready.';

            invalidateSize();
            clearDraft();
        end

        tip(TIPS.another);
    else
        local blockers = submitBlockers();

        if (#blockers == 0) then
            if (imgui.Button('Submit report', { 140, 0 })) then
                if (state.context == nil) then
                    state.context = captureContext();
                end

                beginUpload();
            end

            tip(TIPS.submit);

            imgui.SameLine();
            coloredWrapped(theme.colors.dim, string.format('~%i seconds to send.',
                math.max(2, math.ceil((documentSize() / limits.chunk + 2) * SEND_INTERVAL))));

            tip('The report goes up one chat line at a time, because the client\nrate-limits outgoing chat. You can close this window while it sends.');
        else
            imgui.BeginDisabled(true);
            imgui.Button('Submit report', { 140, 0 });
            imgui.EndDisabled();

            imgui.SameLine();
            coloredWrapped(theme.colors.warn, blockers[1]);

            -- THE SENTENCE, NOT THE BUTTON. ImGui does not report a hover over
            -- a disabled item without the newest HoveredFlags spelling, which
            -- the player's Ashita may not have -- so the reason beside the
            -- button is what carries the rest of the reasons.
            if (#blockers > 1 and imgui.IsItemHovered()) then
                imgui.BeginTooltip();
                imgui.PushTextWrapPos(CARD_WRAP);
                imgui.TextColored(theme.colors.hint, 'Before this can be sent:');

                for _, reason in ipairs(blockers) do
                    imgui.TextWrapped('  ' .. reason);
                end

                imgui.PopTextWrapPos();
                imgui.EndTooltip();
            elseif (#blockers == 1) then
                tip('Submit is greyed until this is settled. Nothing has left your\nmachine, and nothing you wrote is at risk.');
            end
        end

        -- NOT DRAWN AGAINST A PROTOCOL MISMATCH. `sayHello` stands down on
        -- that latch, so the button would be a control that does nothing --
        -- and the blocker sentence above already says what the fix is (update
        -- the addon), which pressing this cannot bring any closer.
        local secondRow = false;

        if (not serverSpeaks and not protocolBad) then
            if (imgui.Button('Check server')) then
                sayHello(true);
            end

            tip(TIPS.check);

            secondRow = true;
        end

        --[[
        * THE WAY OUT WHEN THERE IS NO WAY THROUGH (1.1.0).
        *
        * Every reason Submit is greyed above is a reason the player still has
        * something worth saying and nowhere to put it -- most sharply the two
        * that are about the SERVER rather than about them: it has not
        * answered, or it speaks a version this addon cannot. The header
        * already promises "there is still a Discord"; this is that promise
        * with a button on it. Shares the row with "Check server" so the
        * footer is the same height whichever of them is drawn.
        --]]
        if (CAN_CLIPBOARD) then
            if (secondRow) then
                imgui.SameLine();
            end

            if (imgui.Button('Copy report')) then
                copyReport();
            end

            tip(TIPS.copyReport);
        end
    end

    imgui.Separator();
    coloredWrapped(state.statusBad and theme.colors.err or theme.colors.dim, state.status);
end

local function sentTab()
    if (#state.sent == 0) then
        coloredWrapped(theme.colors.dim, 'Nothing sent this session.');

        -- The one thing an empty drawer could be read as saying that is not
        -- true: that reports filed earlier have gone somewhere.
        tip(TIPS.sentEmpty);

        return;
    end

    coloredWrapped(theme.colors.dim, 'References for reports filed since you logged in. Quote one to staff and they can find it instantly.');
    imgui.Separator();

    if (imgui.BeginTable('##dwreport_sent', CAN_CLIPBOARD and 4 or 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        -- The reference column is sized from the text rather than from a
        -- guess: a reference is `DW-` plus a base36 second plus a two-digit
        -- counter, which is eleven characters today and grows a twelfth in
        -- 2038. 110 pixels happened to fit it and would not have said so.
        imgui.TableSetupColumn('Reference', ImGuiTableColumnFlags_WidthFixed,
            math.max(96, textWidth('DW-XXXXXXXXXX', 96) + 12), 0);
        imgui.TableSetupColumn('Time', ImGuiTableColumnFlags_WidthFixed,
            math.max(52, textWidth('00:00', 44) + 12), 0);
        imgui.TableSetupColumn('Title', ImGuiTableColumnFlags_WidthStretch, 0, 0);

        if (CAN_CLIPBOARD) then
            imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed,
                math.max(44, textWidth('Copy', 32) + 20), 0);
        end

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, entry in ipairs(state.sent) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextColored(theme.colors.hint, entry.ref);
            imgui.TableNextColumn();
            imgui.TextColored(theme.colors.dim, entry.at);
            imgui.TableNextColumn();
            imgui.Text(entry.title);

            -- The full title, which the stretch column clips when the window
            -- is narrow and the player wrote a real sentence. A CARD, not a
            -- plain tip: this is the player's own text at whatever length the
            -- server's `h|` allowed, and it would otherwise be one unwrapped
            -- line.
            tipWrapped(entry.title);

            if (CAN_CLIPBOARD) then
                imgui.TableNextColumn();

                -- Minted with the row (see the `r|` branch), not formatted
                -- afresh sixty times a second.
                if (imgui.Button(entry.copyId or 'Copy##dwreport_copy_x')) then
                    if (pcall(imgui.SetClipboardText, entry.ref)) then
                        state.status    = string.format('%s copied to the clipboard.', entry.ref);
                        state.statusBad = false;
                    end
                end

                tip(TIPS.copy);
            end
        end

        imgui.EndTable();
    end
end

--[[
* The transparency tab. It exists because "we also collect some game data"
* is not an acceptable thing to say to somebody, and because a list that
* has to stay true is a list somebody will notice going stale. If you add a
* field to modules/driftwoodxi/report_core.lua, add it here.
--]]
--[[
* The four fixed lists, hoisted out of the render (1.1.0). They are constants
* -- the same eleven sentences every frame -- and they were being rebuilt as
* four fresh Lua tables sixty times a second while this tab was on screen.
* Only the two attachment lines depend on anything, and they stay inside.
--]]
local COLLECT_WRITE = T{
    'The title, the description, and the three dropdowns.',
};

local COLLECT_CLIENT = T{
    -- The character name is here from 1.1.0 because the report carries it
    -- (`cl.name`), and this list is a promise rather than a summary: a field
    -- that is sent and not named here is the list going quietly stale, which
    -- DWREPORT.md calls worse than no list at all.
    'Which character you are on, your zone and position as your client sees them, and what you had targeted.',
    'HP/MP/TP, jobs and levels, and your status effects.',
    'Your party list, your framerate and your screen size.',
};

local COLLECT_SERVER = T{
    'Your character name and id, nation and rank, and playtime.',
    'Jobs, every job you have levelled, HP/MP/TP, gil and equipment.',
    'Your zone, position, instance and battlefield.',
    'Your party and squad, with each member\'s jobs and HP.',
    'Your active quests and missions, and which step the tracker places you on.',
    'The server build and the time, in both Earth and Vana\'diel.',
};

local COLLECT_NEVER = T{
    'Your password, your email, your IP address, or anything about your account.',
    'Your inventory, your other characters, or anyone else\'s data.',
    'Anything at all unless you press Submit.',
};

-- The client half of the report, as label and snapshot field, in the order it
-- is written to the document. The two attachment-gated fields and the chat
-- log are drawn beneath it and only while their boxes are ticked, which is
-- the point of drawing any of it.
local COLLECT_LIVE = T{
    { 'Character',      'name'      },
    { 'Zone',           'zone'      },
    { 'Position',       'pos'       },
    { 'Vitals',         'vitals'    },
    { 'Jobs',           'jobs'      },
    { 'Target',         'target'    },
    { 'Stance',         'stance'    },
    { 'Party',          'partyList' },
    { 'Status effects', 'buffs'     },
    { 'Framerate',      'fps'       },
    { 'Screen',         'screen'    },
    { 'dwtracker',      'tracker'   },
};

--[[
* The forward-declared clipboard renderer, now that COLLECT_LIVE exists.
*
* Deliberately NOT the wire document: `ti=...|bd=...|cl.zone=...` is a thing a
* parser reads, and what a player pastes into Discord is read by a person.
* Same fields, same order, same two consent boxes -- one is escaped for a
* transport and the other is not.
--]]
reportText = function ()
    local out = T{ };

    out:append('DriftwoodXI bug report -- copied from the game. Nothing was filed by copying this.');
    out:append('');
    out:append('Title:     ' .. (state.title[1] or ''));
    out:append('About:     ' .. labelFor(state.categories, state.category, state.category));
    out:append('How bad:   ' .. labelFor(state.severities, state.severity, state.severity));
    out:append('How often: ' .. labelFor(state.frequencies, state.frequency, state.frequency));
    out:append('');
    out:append(state.body[1] or '');

    local context = state.context;

    if (context ~= nil) then
        out:append('');
        out:append(contextLine());

        for _, row in ipairs(COLLECT_LIVE) do
            local value = context[row[2]];

            if (value ~= nil and value ~= '') then
                out:append('  ' .. row[1] .. ': ' .. tostring(value));
            end
        end

        if (state.attachAddons[1]) then
            out:append('  Addons: ' .. tostring(context.addons or 'unavailable'));
            out:append('  Plugins: ' .. tostring(context.plugins or 'unavailable'));
        end

        if (state.attachChat[1] and context.chat ~= nil and #context.chat > 0) then
            out:append('  Chat log:');

            for _, line in ipairs(context.chat) do
                out:append('    ' .. line);
            end
        end
    end

    return out:concat('\n');
end;

local function collectGroup(title, lines)
    imgui.TextColored(theme.colors.hint, title);

    for _, line in ipairs(lines) do
        imgui.TextWrapped('    ' .. line);
    end

    imgui.Spacing();
end

--[[
* THIS TAB IS LONGER THAN THE WINDOW, SO IT SCROLLS ITSELF (1.1.0).
*
* Four lists of sentences, then a table with a row for every client-side field
* the report carries plus every attached chat line: past fifty lines at the
* default font, against a window whose whole point is to be the size of a
* form. The window carries NoScrollbar and manages no scroll region of its
* own, so everything past the bottom edge was not below the fold -- it was
* GONE, with nothing on screen to say there had been more. What was gone
* included the live values (the strongest half of the promise this tab makes)
* and the closing sentence about where reports actually go.
*
* A child region is the fix rather than dropping NoScrollbar: the report tab
* is measured to fit exactly and must not grow a scrollbar it never needs,
* and a child scrolls on the wheel wherever the pointer is inside it.
* EndChild is unconditional, as the house requires -- BeginChild's return
* value says whether the region is visible, not whether it was opened.
--]]
local function collectTab()
    imgui.BeginChild('##dwreport_collect_body', { -1, -1 }, ImGuiChildFlags_None);

    imgui.TextWrapped('A bug report is only worth what can be checked against it, so each one carries your character\'s state at the time. Here is all of it.');
    imgui.Spacing();

    local group = collectGroup;

    group('What you write', COLLECT_WRITE);

    imgui.TextColored(theme.colors.hint, 'From your client, frozen at the marked moment');

    for _, line in ipairs(COLLECT_CLIENT) do
        imgui.TextWrapped('    ' .. line);
    end

    imgui.TextWrapped('    ' .. (state.attachChat[1]
        and CHAT_ATTACH_ON
        or 'Your chat log -- currently NOT attached, the box is unticked.'));
    imgui.TextWrapped('    ' .. (state.attachAddons[1]
        and 'Your loaded addons and plugins -- this box is ticked.'
        or 'Your addon list -- currently NOT attached, the box is unticked.'));

    imgui.Spacing();

    group('From the server, at the moment you press Submit', COLLECT_SERVER);

    group('What is never collected', COLLECT_NEVER);

    --[[
    * AND WHAT THAT MEANS RIGHT NOW (1.1.0).
    *
    * The four lists above are a description, and a description is exactly
    * what this tab exists NOT to be: DWREPORT.md calls the tab "a promise",
    * and the strongest form of the promise is the values themselves. Every
    * client-side field the report will carry, as it will carry it, off the
    * marked snapshot -- so "what am I about to send" is answered by showing
    * it rather than by naming it.
    *
    * The server half cannot be shown here and is not pretended at: the addon
    * does not know it, which is the whole division of labour this addon is
    * built on.
    --]]
    imgui.Separator();
    imgui.TextColored(theme.colors.hint, 'And right now, from your client, that is exactly:');
    tip(TIPS.liveValues);

    --[[
    * AND WHAT WILL NOT FIT (1.1.0). This tab is a promise, and a promise that
    * lists a field which is about to be sacrificed is a promise being broken
    * quietly. Over the transport budget the trimmer drops attachments in a
    * fixed order, and the only sign of that used to be the size meter turning
    * warn-coloured on the OTHER tab plus a sentence after Submit naming what
    * had already gone.
    *
    * The order is named rather than the outcome computed: working out exactly
    * which fields survive means running the trimmer, and the trimmer
    * assembles the whole document -- which is the one thing this render is
    * not going to do sixty times a second. `documentSize` is the half-second
    * cache the meter already reads.
    --]]
    if (documentSize() > maxDocument()) then
        coloredWrapped(theme.colors.warn,
            'This report is over the transport budget, so some of the list above will be trimmed to fit -- plugins first, then the addon list, then your status effects, screen and framerate, then chat lines oldest first. What you wrote is never trimmed, and the window names what went.');
    end

    if (state.context == nil) then
        coloredWrapped(theme.colors.inert, '    No moment is marked yet -- one is taken when you open this window.');
    elseif (imgui.BeginTable('##dwreport_live', 2,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH,
                    ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Field', ImGuiTableColumnFlags_WidthFixed,
            math.max(96, textWidth('Status effects', 96) + 16), 0);
        imgui.TableSetupColumn('Value', ImGuiTableColumnFlags_WidthStretch, 0, 0);

        for _, row in ipairs(COLLECT_LIVE) do
            local value = state.context[row[2]];

            if (value ~= nil and value ~= '') then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.TextColored(theme.colors.dim, row[1]);
                imgui.TableNextColumn();
                imgui.TextWrapped(tostring(value));
            end
        end

        if (state.attachAddons[1]) then
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextColored(theme.colors.dim, 'Addons');
            imgui.TableNextColumn();
            imgui.TextWrapped(tostring(state.context.addons or 'unavailable'));

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextColored(theme.colors.dim, 'Plugins');
            imgui.TableNextColumn();
            imgui.TextWrapped(tostring(state.context.plugins or 'unavailable'));
        end

        if (state.attachChat[1] and state.context.chat ~= nil) then
            for index, line in ipairs(state.context.chat) do
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.TextColored(theme.colors.dim, index == 1 and 'Chat log' or '');
                imgui.TableNextColumn();
                imgui.TextWrapped(line);
            end
        end

        imgui.EndTable();
    end

    imgui.Separator();
    coloredWrapped(theme.colors.dim, 'Reports go to the server owner as email. There is no automated third party in the path.');

    imgui.EndChild();
end

local sentLabelCache = { count = -1, label = 'Sent###dwreport_tab_sent' };

local function renderWindow()
    if (imgui.BeginTabBar('##dwreport_tabs')) then
        if (imgui.BeginTabItem('Report###dwreport_tab_report')) then
            tip(TIPS.reportTab);
            reportTab();
            imgui.EndTabItem();
        else
            tip(TIPS.reportTab);
        end

        -- THE COUNT IS IN THE LABEL, with a `###` id behind it so the tab does
        -- not lose its selection the moment that count changes (dwah's shape).
        -- A player who filed a report and then closed the window has no other
        -- way to see that anything was filed at all. Cut when the count moves
        -- rather than every frame: it moves a handful of times a session.
        if (sentLabelCache.count ~= #state.sent) then
            sentLabelCache.count = #state.sent;
            sentLabelCache.label = #state.sent > 0
                and string.format('Sent (%i)###dwreport_tab_sent', #state.sent)
                or 'Sent###dwreport_tab_sent';
        end

        if (imgui.BeginTabItem(sentLabelCache.label)) then
            tip(TIPS.sentTab);
            sentTab();
            imgui.EndTabItem();
        else
            tip(TIPS.sentTab);
        end

        if (imgui.BeginTabItem('What is sent###dwreport_tab_collect')) then
            tip(TIPS.collectTab);
            collectTab();
            imgui.EndTabItem();
        else
            tip(TIPS.collectTab);
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape, and its
* reasoning, kept verbatim).
--]]
ashita.events.register('d3d_present', 'dwreport_present', function ()
    local now = os.clock();

    if (fps.last > 0) then
        fps.accum  = fps.accum + (now - fps.last);
        fps.frames = fps.frames + 1;

        if (fps.accum >= 1.0) then
            fps.value  = fps.frames / fps.accum;
            fps.accum  = 0;
            fps.frames = 0;
        end
    end

    fps.last = now;

    -- Uploading continues with the window shut: closing it mid-send should
    -- not throw away a report that is halfway to the server.
    pumpUpload();
    pumpQueue();

    if (draftDirty and (now - draftAt) > 3.0) then
        saveDraft();
    end

    if (not state.open[1]) then
        return;
    end

    -- An open window is a deliberate act, so it is one of the two places the
    -- handshake is allowed to retry on its own -- bounded by HELLO_TRIES, for
    -- the reason sayHello spells out. The other is an upload already in
    -- flight (pumpUpload), which is at least as deliberate and whose queue is
    -- held shut until the proof comes back.
    sayHello(false);

    local pushed = theme.push();

    --[[
    * A MINIMUM SIZE (1.1.0). Nothing in this window scrolls -- it passes
    * NoScrollbar and manages no scroll region of its own -- so a player who
    * dragged the corner in lost the Submit button, then the status line, then
    * the description box itself, with no way to tell that anything was below
    * the edge. The floor is what the report tab actually needs: the three
    * dropdown rows at 190 apiece plus their labels across, and the title row,
    * a description box worth typing into and the whole footer down.
    *
    * Probed under pcall once, dwah's shape and for its reason: an annotation
    * is not proof, and this addon reaches players on whatever Ashita they
    * installed first. Refused, the latch closes and the window is what it
    * always was.
    --]]
    if (CAN_CONSTRAIN and not constraintsBroken) then
        --[[
        * RAISED FROM 470x470 (1.1.0), because 470x470 was not a size the
        * report tab could actually be drawn at and the floor's whole job is
        * to be one.
        *
        * Height: the description box clamps at BODY_FLOOR and the footer is
        * charged for by footerReserve, so below their sum plus the chrome
        * above the box -- the tab bar, the three dropdown rows, the title row
        * and its labels -- the footer is past the bottom edge of a window
        * carrying NoScrollbar, which is gone rather than scrolled to. That
        * sum is a little over 540 at the client's font, and the floor was
        * seventy pixels under it.
        *
        * Width: the row carrying the re-mark button and the two consent
        * checkboxes does not wrap, and it did not fit 470 either.
        --]]
        if (not pcall(imgui.SetNextWindowSizeConstraints, { 520, 560 }, { 99999, 99999 })) then
            constraintsBroken = true;
        end
    end

    --[[
    * 620x620, AND THE FIRST-RUN SIZE HAS TO CLEAR THE FLOOR BY MORE THAN A
    * PIXEL (1.1.0).
    *
    * 560x520 was short of what this tab draws and 560x560 was barely level
    * with it: the rows above the description box come to about 265 pixels
    * once the tab bar and the title bar are counted, the box will not go
    * below BODY_FLOOR, and the footer wants footerReserve -- which is past
    * 540 before the box has a single line of slack in it. A default that
    * lands ON the minimum is a window nobody can make smaller and which shows
    * a four-line description box; 620 is the same layout with room in it and
    * sixty pixels of drag to give back.
    *
    * FirstUseEver, so nobody who has already sized this window notices.
    --]]
    imgui.SetNextWindowSize({ 620, 620 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Bug Report##dwreport', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwreport'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwreport'):append(chat.message('Window closed. Your draft is safe; /dwreport reopens it.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening marks the moment: by the time somebody
* reaches for this window the thing they want to report has already
* happened, and the snapshot should be of then, not of whenever they finish
* typing.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;

        -- "Opening this window freezes a snapshot right then" (the header,
        -- and DWREPORT.md) -- so a plain open RE-captures. The one snapshot
        -- that survives an open is a deliberate mark (`/report mark`, or the
        -- re-mark button): that one exists precisely to outlive the moment.
        -- Gated on `context == nil` alone, the second open of a session
        -- attached a stale snapshot -- wrong zone, wrong target, and a chat
        -- ring frozen at the FIRST open.
        --[[
        * AND A MARK BELONGS TO THE CHARACTER IT WAS TAKEN ON (1.1.0). The
        * one snapshot allowed to outlive its moment is a deliberate mark --
        * but a mark taken as one character and submitted as another
        * describes the wrong client entirely, and the server's zone
        * cross-check then reports `!! MISMATCH ... possible desync` at a
        * reader with no way to see that the two halves are about two
        * different people. A name we cannot read is not evidence of
        * anything, so the mark stands.
        --]]
        local name = currentName();

        if (state.context == nil or not state.contextMarked
                or (name ~= nil and state.context.name ~= nil and state.context.name ~= name)) then
            state.context = captureContext();
        end

        sayHello(false);
    end
end

ashita.events.register('command', 'dwreport_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Report`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.) The
    -- title slice below reads `#args[1]`, a LENGTH, so it is unaffected.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwreport' and first ~= '/report' and first ~= '/dwr' and first ~= '/bug') then
        return;
    end

    e.blocked = true;

    --[[
    * A VERB IS A WORD ON ITS OWN (1.1.0).
    *
    * `/report mark` marks the moment. `/report mark this quest as broken` is
    * a TITLE that happens to begin with the word mark -- the one-keystroke
    * door the header promises -- and it was being swallowed by the verb it
    * collided with, leaving the player looking at a chat line about a
    * snapshot and no report started. Same for `clear`, `status` and `recent`,
    * and it is what makes the two verbs added in this version safe to add at
    * all: `/report cancel` cancels, `/report cancel button does nothing` is a
    * report about the Cancel button.
    --]]
    local verb = (#args == 2) and args[2]:lower() or nil;

    if (verb == 'help') then
        print(chat.header('dwreport'):append(chat.message('/report            open the window (also /bug, /dwreport, /dwr)')));
        print(chat.header('dwreport'):append(chat.message('/report <title>    start one with the title already filled in')));
        print(chat.header('dwreport'):append(chat.message('/report mark       freeze your state now, write it up later')));
        print(chat.header('dwreport'):append(chat.message('/report clear      throw the saved draft away')));
        print(chat.header('dwreport'):append(chat.message('/report cancel     stop an upload that is running')));
        print(chat.header('dwreport'):append(chat.message('/report copy       put the whole report on your clipboard')));
        print(chat.header('dwreport'):append(chat.message('/report status     cooldown, and how many you have left today')));

        return;
    end

    --[[
    * The same door as the "Copy report" button, for the case the button is
    * hardest to reach: a player whose window will not open, or who is reading
    * the sentence in chat rather than in the window. Refused rather than
    * silently doing nothing when the player's ImGui has no clipboard call --
    * a command that answers nothing is worse than one that says why.
    --]]
    if (verb == 'copy') then
        if (copyReport()) then
            print(chat.header('dwreport'):append(chat.message(state.status)));
        else
            print(chat.header('dwreport'):append(chat.error(state.status)));
        end

        return;
    end

    if (verb == 'cancel') then
        if (not uploadActive()) then
            print(chat.header('dwreport'):append(chat.message('Nothing is uploading right now.')));

            return;
        end

        -- Reset first, then ask: resetUpload drops the chunk lines still
        -- queued, so the cancel is not stuck behind the report it cancels.
        resetUpload();
        issue('!dwr cancel');

        state.status    = 'Upload cancelled -- nothing was filed. Everything you wrote is still here.';
        state.statusBad = false;

        print(chat.header('dwreport'):append(chat.message('Upload cancelled -- nothing was filed. Your report is still in the window.')));

        return;
    end

    if (verb == 'mark') then
        state.context       = captureContext();
        state.contextMarked = true;
        state.status        = 'Moment marked. Open the window when you are ready to write it up.';
        state.statusBad     = false;

        print(chat.header('dwreport'):append(chat.message('Moment marked -- your state right now is saved for the next report.')));

        return;
    end

    -- The two server verbs somebody will inevitably type with a slash. They
    -- are reads, they answer into chat on their own, and swallowing them as
    -- a report title would be a small daily annoyance for exactly the
    -- people who use them most.
    if (verb == 'recent' or verb == 'status') then
        -- BEHIND THE SAME GATE AS THE UPLOAD (1.0.9, the 2026-08-09 review's
        -- fourth backlog item): an unknown ! command is public /say here, and
        -- these two were the one door in this file that sent without the
        -- server having proven it speaks dwreport. Until it has, the typed
        -- verb costs a hello (the eight harmless characters) and a sentence.
        if (not serverSpeaks) then
            sayHello(true);
            print(chat.header('dwreport'):append(chat.message(
                'The server has not answered dwreport yet -- asked it now. Try /report ' .. verb .. ' again in a moment.')));

            return;
        end

        issue('!dwr ' .. verb);

        return;
    end

    if (verb == 'clear') then
        state.title[1] = '';
        state.body[1]  = '';

        invalidateSize();
        clearDraft();

        print(chat.header('dwreport'):append(chat.message('Draft cleared.')));

        return;
    end

    if (#args >= 2 and verb ~= 'ui' and verb ~= 'window' and verb ~= 'gui') then
        -- Everything after `/report ` becomes the title, so a player can
        -- start one in a single keystroke while it is still fresh.
        --
        -- TRIMMED, because the slice is taken by LENGTH from the command word
        -- and `:args()` collapses runs of whitespace that the raw line still
        -- has: `/report   the ferry` handed the form a title beginning with
        -- two spaces, which then counted towards the six-character floor and
        -- shipped in the subject line of the mail.
        local title = e.command:sub(#args[1] + 2):gsub('^%s+', ''):gsub('%s+$', '');

        if (title == '') then
            toggleWindow();

            return;
        end

        state.title[1] = title:sub(1, limits.title);
        invalidateSize();

        -- Marked here and nowhere else: a plain open re-captures anyway, and
        -- capturing twice for one keystroke read the entity array twice at
        -- the moment the game is least well.
        state.context       = captureContext();
        state.contextMarked = true;

        -- What the player typed is the precious half (the header says so), so
        -- the draft is armed for the flush timer the moment there is one --
        -- rather than only once they type into the box themselves.
        touchDraft();

        if (not state.open[1]) then
            toggleWindow();
        end

        return;
    end

    toggleWindow();
end);

--[[
* Watch what the player sends.
*
* Bare `!dwr` (and its ui/window/gui spellings) is intercepted and opens
* this window instead of going to the server -- dwsquad's pattern, kept
* because the server verb is the name players learn from each other, so it
* has to be a door and not a dead end. Every real verb still passes through
* untouched: that is the escape hatch this addon's header promises, and it
* must keep working.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a chunk fired in the same
* frame as something the player typed is the one that gets dropped -- and
* here that would be a piece of their bug report. Stamping the player's own
* line as a send makes the next queued command wait its interval instead of
* racing it.
--]]
ashita.events.register('packet_out', 'dwreport_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!dwr' or lower == '!dwr ui' or lower == '!dwr window' or lower == '!dwr gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwr') then
        lastSend = os.clock();
    end
end);

--[[
* Login and zone-in (0x000A serves both).
*
* The handshake is re-asked once per login, because whether this server
* speaks dwreport is a per-session fact and the answer gates every upload.
* Nothing else resets: a draft written before a zone line is still the
* draft, and the marked moment is still the moment -- it has a timestamp,
* and the report says how old it is.
--]]
ashita.events.register('packet_in', 'dwreport_zonein', function (e)
    if (e.id ~= 0x000A) then
        return;
    end

    serverSpeaks = false;
    helloAsked   = 0;
    helloTries   = 0;

    -- A map restart logs everyone out, so the server on the other side of this
    -- packet may well be the updated one -- the same reasoning dwscan and
    -- dwfishing state in their own zone handlers. A mismatch that is still
    -- real re-announces itself on the next `d|`.
    protocolBad  = false;

    -- The cooldown was the OLD session's, and this may not even be the same
    -- character. The server re-asserts it on the next handshake or refusal.
    state.cooldown = 0;

    --[[
    * AND THE ENVELOPE READER IS CLOSED (1.1.0).
    *
    * `inResponse` is opened by a `d|` and closed by the matching `z|`, and
    * the one thing that can happen between them is exactly what this packet
    * means: the map went away. A reader left open across a login accepted
    * the NEXT session's first records into the previous session's envelope --
    * and a `pendingSets` left half-filled would have committed a category
    * list assembled from two different handshakes.
    --]]
    inResponse  = nil;
    pendingSets = nil;

    -- No handshake is sent from here. `hello` is the one line this addon is
    -- willing to risk leaking to /say if the server turns out not to speak
    -- it, so it is spent when the player opens the window -- not on every
    -- zone line of a session in which they were never going to file
    -- anything.
end);

ashita.events.register('load', 'dwreport_load', function ()
    print(chat.header('dwreport'):append(chat.message('/report (or /bug, /dwreport) files a bug report from in-game -- your game state is attached automatically.')));
    print(chat.header('dwreport'):append(chat.message('/report <title> starts one straight away, and /report mark saves your state to write up in a minute.')));
end);

ashita.events.register('unload', 'dwreport_unload', function ()
    -- saveDraft decides for itself whether there is anything to keep, so an
    -- unload that catches an emptied form now REMOVES the file rather than
    -- leaving the last flush's copy of text the player deleted.
    if (draftDirty) then
        saveDraft();
    end
end);
