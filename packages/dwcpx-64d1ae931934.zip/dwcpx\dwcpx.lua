--[[
* DriftwoodXI -- dwcpx
*
* The Conquest Point Exchange in a window: every gate guard's conquest-point
* shelf -- all three nations, every rank, plus the allied sundries -- and
* every regular merchant's gil counter in Vana'diel, browsable and buyable
* from anywhere. `/cpx` opens it; there is no guard to walk to, because the
* window IS the counter.
*
* Nation tabs page by rank the way the guards' menus do, so what comes from
* where is still legible -- but nothing GATES on it: any nation's gear at any
* rank, bought with your own conquest points, no trading partner required.
* The merchant tabs (Weapons / Armor / Scrolls / Goods) fold every zone shop
* and the 24/8 guild counters into the sections the auction house would file
* them under, priced in gil OR conquest points -- which is most of the reason
* to keep signet on and keep slaying.
*
* Every row draws the client's own item icon and a hover card: name, level,
* jobs, slots, Rare/Ex, stack size, both prices, how many you already carry,
* and the item's real description. A search box on the Search tab asks the
* SERVER (!dwv find), so it sees every shelf at once, fetched or not.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It ships no stock and no arithmetic. Every tab, every dropdown, every row
* and every price arrives as _DWVDATA records answering `!dwv` reads
* (documentation/dwv_protocol.md); the tabs themselves are server records, so
* a new shelf needs no addon update. A click issues a line a player could
* type (`!dwv buy 104609 gil 12`), and THE CLIENT NEVER SENDS A PRICE -- it
* sends a shelf number. The Confirm button exists only while a quote is
* armed, a quote is armed only by a `t|` record, and the click that sends
* `confirm` disarms it in the same statement -- so one quote can buy at most
* one thing, and a window that never asked can buy nothing at all. Funds,
* bag space, the item-level ceiling and the Rare re-buy are all re-checked
* server-side at confirm time.
*
* TYPING `!cpx` ON ITS OWN OPENS THIS WINDOW. The line is intercepted before
* it leaves the client; every other !cpx command passes through.
*
* TURN IT OFF AND NOTHING IS LOST. `!cpx list sandoria rank3`, `!cpx list
* weapons sword`, `!cpx find bronze`, `!cpx buy <number> [cp|gil] [qty]` and
* `!cpx confirm` all work typed. This is friendlier; it is not required.
*
* ANSWERS BUILD ASIDE AND COMMIT WHOLE (1.3.0). This wire's family documents
* the rule -- "lists build aside and commit on z|, so a half-arrived reply
* can never half-fill the window" -- and this addon did not follow it. The
* tab bar and its section dropdowns were WIPED at a hello answer's `d|` and
* refilled one record at a time, and records ride one per chat packet, so
* every Refresh, every zone line and every typed `!cpx` drew a tab bar that
* was empty and then growing for several frames -- and ImGui, handed a tab
* bar without the tab it was showing, picks another one. The player was
* thrown off the shelf they were reading, every time. Directories, find
* results and list pages now stage and replace in a single frame.
*
* AND THE ROWS ARE A TABLE, AND THE TABLE IS BUILT ONCE PER ANSWER (1.3.0).
* The shelf was a chain of SameLine calls, so every price and every button
* sat at whatever x the item name happened to end at and one long name
* pushed its own Buy button off the window; and all of it -- the name
* lookup, the price strings, the weapon line, the filter's lowercase, the
* Fits-me test -- was recomputed for every row sixty times a second. The
* item column stretches, the three beside it are measured, and the whole
* filtered-sorted-prepared view is cached against the model revision, the
* filter, the sort and the job it answers for.
--]]

addon.name    = 'dwcpx';
addon.author  = 'DriftwoodXI';
addon.version = '1.3.0';
addon.desc    = 'The Conquest Point Exchange for DriftwoodXI -- every nation\'s CP shelf and every merchant\'s counter, from anywhere, for conquest points or gil.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local theme    = require('dwtheme');
local echo     = require('dwecho');
local settings = require('settings');

local C = ffi.C;

echo.install();

local PROTOCOL    = 1;
local DATA_SENDER = '_DWVDATA';

--[[
* Settings, per PC: the shared quantity the Buy buttons quote for stackables,
* the row order, whether the Fits-me filter is on, and which section each tab
* was left on. Everything else is server state, re-asked on open.
*
* KEYS ARE ADDED, NEVER REPURPOSED -- a settings file written by an older
* dwcpx must still load, and the library fills a missing key from the
* defaults below, so an old file gains the new fields at their defaults.
--]]
local SORT_KEYS = { 'shelf', 'name', 'price', 'level' };

local defaultConfig = T{
    qty      = T{ 1 },
    sort     = 'shelf',
    fits     = false,
    -- A PLAIN table, not T{}: the keys are server-chosen tab names and T{}'s
    -- sugar method names would shadow any that collided (the dwm_protocol
    -- rule about verb-keyed tables).
    sections = { },
};

local config = defaultConfig;

--[[
* A settings file in a shape this window cannot use must never be the reason
* the window dies (the house rule for persisted state), and these fields do
* not merely misbehave on the wrong type:
*
*   * `config.qty` is handed to imgui.InputInt, which wants a TABLE it can
*     write back into. A file where `qty` came back a number raises inside
*     the binding every frame the pane draws -- which reads to the player as
*     a shelf that will not render at all.
*   * `config.qty[1]` reaches string.format('%d', n). The client's LuaJIT
*     truncates a fraction there and the Lua the offline harness runs raises
*     on it, so a hand-edited `qty = 2.5` is a silently wrong purchase on one
*     and a red gate on the other. Neither is a thing to keep.
*   * `sort` names a comparator and `sections` is indexed by tab key: a
*     string where a table belongs, or a sort nobody wrote, would be read
*     every frame.
*
* Checked once on load and once on every settings-library update, quietly
* repaired, and said in chat only when something actually had to be replaced.
--]]
local function sanitiseConfig()
    local repaired = false;

    if (type(config) ~= 'table') then
        config   = T{ };
        repaired = true;
    end

    local qty = type(config.qty) == 'table' and config.qty[1] or nil;

    -- `qty ~= qty` is the NaN test: tonumber accepts 'nan', and every
    -- comparison against it is false, so the range test alone lets it past.
    if (type(qty) ~= 'number' or qty ~= qty or qty < 1 or qty > 99 or qty ~= math.floor(qty)) then
        repaired   = repaired or config.qty ~= nil;
        config.qty = T{ 1 };
    end

    local knownSort = false;

    for _, key in ipairs(SORT_KEYS) do
        if (config.sort == key) then
            knownSort = true;
        end
    end

    if (not knownSort) then
        repaired    = repaired or config.sort ~= nil;
        config.sort = 'shelf';
    end

    if (type(config.fits) ~= 'boolean') then
        config.fits = false;
    end

    if (type(config.sections) ~= 'table') then
        repaired        = repaired or config.sections ~= nil;
        config.sections = { };
    end

    return repaired;
end

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

local configRepaired = sanitiseConfig();

pcall(settings.register, 'settings', 'dwcpx_settings_update', function (s)
    if (s ~= nil) then
        config = s;

        sanitiseConfig();
    end
end);

--[[
* The D3D device, fetched on first use rather than at load: this addon is
* loaded from the launcher's boot script, long before the client has a
* rendering device, and a file-scope d3d.get_device() would make the whole
* addon fail to load (dwbags' lesson, kept verbatim via dwquest).
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        local ok, dev = pcall(d3d.get_device);

        if (ok) then
            d3d8dev = dev;
        end
    end

    return d3d8dev;
end

--[[
* THE ITEM RESOURCE, ASKED ONCE PER ID (1.3.0). The client's item DAT is
* static from load, so an id that answers nil now answers nil forever and a
* negative result caches as safely as a positive one. Before this, a shelf
* row asked the resource manager THREE times every frame -- once for the
* name, once for the icon, once for the inline damage/delay -- and a shop
* section holds hundreds of rows, so the count was in the thousands per
* frame for data that cannot change. `false` is the cached "the client does
* not know this id"; nil means "not asked yet".
--]]
local resources = { };

local function resourceOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    local hit = resources[itemId];

    if (hit ~= nil) then
        return hit ~= false and hit or nil;
    end

    local ok, item = pcall(function ()
        return AshitaCore:GetResourceManager():GetItemById(itemId);
    end);

    if (not ok or item == nil) then
        resources[itemId] = false;

        return nil;
    end

    resources[itemId] = item;

    return item;
end

--[[
* Item icons, from the client's own resources -- dwbags' iconOf/drawIcon by
* way of dwquest, kept verbatim, reasoning and all: cached because the shelf
* is rows redrawn every frame and D3DXCreateTextureFromFileInMemoryEx is not
* free; gc_safe_release hands back a texture that releases itself when Lua
* collects it, which is what keeps this from leaking across a reload.
--]]
local icons = T{ };

local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = resourceOf(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* The hover card's vocabulary -- dwbags' by way of dwquest, kept verbatim:
* client DAT bitmasks decoded to the words a player reads. All of it is
* presentation; the server re-checks everything that matters at confirm time.
--]]
local FLAG_EX   = 0x4000;
local FLAG_RARE = 0x8000;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

local SLOT_LABELS = {
    [0]  = 'Main',  [1]  = 'Sub',   [2]  = 'Ranged', [3]  = 'Ammo',
    [4]  = 'Head',  [5]  = 'Body',  [6]  = 'Hands',  [7]  = 'Legs',
    [8]  = 'Feet',  [9]  = 'Neck',  [10] = 'Waist',  [11] = 'Ear',
    [12] = 'Ear',   [13] = 'Ring',  [14] = 'Ring',   [15] = 'Back',
};

local function jobsText(mask)
    local names = T{ };

    for jobId = 1, #JOB_NAMES do
        if (bit.band(mask, bit.lshift(1, jobId)) ~= 0) then
            names:append(JOB_NAMES[jobId]);
        end
    end

    if (#names == 0) then
        return nil;
    end

    if (#names >= #JOB_NAMES) then
        return 'All jobs';
    end

    return table.concat(names, ' ');
end

local function slotsText(mask)
    local names = T{ };
    local seen  = { };

    for slot = 0, 15 do
        if (bit.band(mask, bit.lshift(1, slot)) ~= 0) then
            local label = SLOT_LABELS[slot];

            if (not seen[label]) then
                seen[label] = true;
                names:append(label);
            end
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, '/');
end

--[[
* The eight elemental-resist icons in the client's item descriptions are
* FFXI-private Shift-JIS pairs -- 0xEF then 0x1F..0x26, in wheel order
* fire ice wind earth lightning water light dark. ImGui wants UTF-8, so the
* raw pair renders as the '?' players reported. Each icon (and the '+' that
* usually follows it) folds to a three-letter tag. Mirrored BY HAND from
* dwbags 1.17.0 -- edit one, revisit the others.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function(b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

-- The row's display name: the client resource's (with its apostrophes) when
-- the client knows the id, the wire label when it does not. Reads the cached
-- resource, so a shelf of six hundred rows costs six hundred lookups once
-- rather than six hundred every frame.
local function itemName(itemId, fallback)
    local item = resourceOf(itemId);

    if (item ~= nil and item.Name ~= nil and item.Name[1] ~= nil and #item.Name[1] > 0) then
        return item.Name[1];
    end

    return fallback;
end

--[[
* How many of an item this CHARACTER is carrying, counted from the client's
* own containers. Display only (the server re-checks everything at confirm),
* cached for a second because the card redraws every frame, and pcall'd
* because a hover card must never be the reason the window closes.
--]]
-- Every container a bought item can end up counted in, minus 3 (Temporary,
-- which is event stock and not something you own). 13..16 are wardrobes 5
-- through 8 (item_container.h LOC_WARDROBE5..8) and were MISSING until
-- 1.3.0, so "You are carrying 2." read 0 for anyone whose spare set lives in
-- the later wardrobes. A container the client does not have answers a
-- maximum of zero and costs the loop nothing.
local OWNED_CONTAINERS = { 0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };

local ownedCache = { at = 0, counts = { } };

local function ownedCount(itemId)
    local now = os.clock();

    if (now - ownedCache.at > 1.0) then
        ownedCache = { at = now, counts = { } };

        local ok = pcall(function ()
            local inventory = AshitaCore:GetMemoryManager():GetInventory();

            for _, containerId in ipairs(OWNED_CONTAINERS) do
                local max = inventory:GetContainerCountMax(containerId);

                for slot = 1, max do
                    local entry = inventory:GetContainerItem(containerId, slot);

                    if (entry ~= nil and entry.Id > 0 and entry.Id < 65535 and entry.Count > 0) then
                        ownedCache.counts[entry.Id] = (ownedCache.counts[entry.Id] or 0) + entry.Count;
                    end
                end
            end
        end);

        if (not ok) then
            ownedCache.counts = { };
        end
    end

    return ownedCache.counts[itemId] or 0;
end

--[[
* State. Everything here is a rendering of server records; the only numbers
* that move locally are countdowns.
--]]
local state = {
    open        = { false, },
    now         = os.clock(),
    reported    = false,
    status      = '',
    statusBad   = false,
    serverSpoke = false,
    synced      = false,
    inbound     = nil,

    purse       = nil,      -- { cp, gil, rank, nation } from g|
    tabs        = { },      -- j| order: { key, label, kind }
    drops       = { },      -- [tabkey] = { { key, label, count }, ... }
    selected    = { },      -- [tabkey] = selected drop key
    lists       = { },      -- [tab/drop] = { rows, page, pages, total, synced }
    quote       = nil,      -- t| arms it; nothing else can
    find        = { text = { '' }, results = { }, synced = false, asked = false },

    filter      = { '' },   -- client-side row filter, shared across tabs
    fitsMe      = { config.fits == true },
    fitsBroken  = false,

    -- Bumped by every answer that REPLACES rows the panes draw from. The
    -- view cache below keys on it, which is the whole reason a shelf of two
    -- hundred and fifty rows is filtered and sorted once per answer rather
    -- than once per frame.
    modelRev    = 0,
};

local NATION_NAMES = { [0] = 'San d\'Oria', [1] = 'Bastok', [2] = 'Windurst' };

local function listKey(tabKey, dropKey)
    return tabKey .. '/' .. dropKey;
end

--[[
* Sending: one command per interval, reads deduplicated, WRITES NEVER
* COLLAPSED AND NEVER RETRIED (the dwmerc rule). A lost `buy` re-sent could
* re-quote after the player moved on; a lost `confirm` re-sent is the double
* purchase the whole two-step exists to prevent. Writes drain first.
--]]
local SEND_INTERVAL = 1.2;

local readQueue    = { };
local writeQueue   = { };
local lastSend     = 0;
local writePending = nil;

local WRITE_TIMEOUT = 10.0;

local function issueRead(command)
    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

local function beginWrite(what, label, command)
    writePending = { what = what, label = label, at = os.clock() };
    table.insert(writeQueue, command);
end

local function pumpQueue(now)
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and both queues are empty in
    -- almost all of them, while echo.canSend() is three calls across the C++
    -- boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it first
    -- spent a hundred and eighty of those a second to decide to do nothing.
    -- An empty queue has no line to hold or to drop, so the order is free.
    if (#writeQueue == 0 and #readQueue == 0) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#writeQueue > 0) then
        lastSend = now;
        echo.send(table.remove(writeQueue, 1));

        -- THE ANSWER CLOCK STARTS WHEN THE LINE LEAVES, NOT WHEN IT WAS
        -- QUEUED (1.3.0). `beginWrite` stamped the click, and the click can
        -- be a second and a half ahead of the send (the 1.2s throttle) or
        -- an entire load screen ahead of it (canSend holds the queue shut
        -- while the client is zoning) -- so a write could time out with
        -- "No answer from the server" while it was still sitting in the
        -- queue, unsent, and then go out anyway a moment later.
        if (writePending ~= nil) then
            writePending.at = now;
        end

        return;
    end

    if (#readQueue > 0) then
        lastSend = now;
        echo.send(table.remove(readQueue, 1));
    end
end

--[[
* Ask-once-retry-once (the dwquest discipline): one ask, one retry on a 5s
* silence, then stop and say so -- a retry that never terminates is a command
* loop, and on a server without this module an unknown ! command falls
* through to public /say.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = { };

local function refresh()
    requested = { };
end

local function askOnce(key, command, now)
    local asked = requested[key];

    if (asked ~= nil) then
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or (now - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp = true;

                if (not state.serverSpoke) then
                    state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
                    state.statusBad = true;
                end
            end

            return;
        end

        asked.at    = now;
        asked.tries = asked.tries + 1;
    else
        requested[key] = { at = now, answered = false, tries = 1 };
    end

    issueRead(command);
end

local function needHello(now)
    askOnce('hello', '!dwv hello', now);
end

--[[
* The visible tab/drop's rows, page by page: the h| header says how many
* pages there are, and the next page is asked only after the last answered.
*
* WITH A CEILING ON THE CHASE (1.3.0). The page count is a wire field, and a
* page fetched is a command sent and forty rows kept -- so an answer claiming
* a page count it does not have would have this addon asking, and growing a
* row table, until the server ran out of pages to refuse. The biggest real
* section in the catalog is 258 rows (seven pages of forty), so fifty is a
* ceiling no shelf can reach and a malformed header cannot pass.
--]]
local MAX_PAGES = 50;

local function needList(tabKey, dropKey, now)
    local key  = listKey(tabKey, dropKey);
    local list = state.lists[key];

    if (list ~= nil and list.synced) then
        if (list.pages ~= nil and list.page ~= nil
                and list.page < list.pages and list.page < MAX_PAGES) then
            askOnce(string.format('list:%s:%d', key, list.page + 1),
                string.format('!dwv list %s %s %d', tabKey, dropKey, list.page + 1), now);
        end

        return;
    end

    askOnce(string.format('list:%s:1', key),
        string.format('!dwv list %s %s 1', tabKey, dropKey), now);
end

--[[
* THE SEARCH IS A READ LIKE THE OTHERS (1.3.0). It used to be asked exactly
* once, from the click, and never revisited -- so `askOnce`'s retry and its
* give-up could not fire for it at all, and an answer the client dropped
* (which is what the zoning gate and the chat rate limit both produce) left
* the pane on 'Searching...' for the rest of the session with nothing on any
* clock to change it. Re-armed from the render loop while the answer is
* outstanding, which gives it the same one retry every other read gets and
* the same terminal give-up after it.
--]]
local function needFind(now)
    if (state.find.asked and not state.find.synced and state.find.command ~= nil) then
        askOnce('find', state.find.command, now);
    end
end

--[[
* Record intake. A reader accepts records only between d| and z|; the
* version handshake is a HARD refusal (this window must never render prices
* off a wire it half-understands), and every reset runs FIRST because the
* handler runs under a pcall.
--]]
--[[
* AN EMPTY FIELD IS STILL A FIELD (1.3.0), and this is the suite's own
* splitter -- the `[^sep]*` form with a separator appended, which twenty-two
* sibling addons carry verbatim. dwcpx was the odd one out: it matched runs
* of ONE OR MORE non-separator characters, which SKIPS an empty field. Every
* record on this wire is read by position, so a single empty field silently
* pulled every field after it one place to the left -- a row whose gil was
* empty read its level as its price, its stack size as its level and its
* NAME as its stack size, then drew itself with no name and a Gil button
* quoting a price nothing on the shelf charges. The server formats every
* number, so it cannot emit an empty one today; a truncated packet or
* another addon rewriting this 0x017 stream can, and a parser that reads by
* position must not answer a short record with a plausible wrong one.
--]]
local function split(line, sep)
    local parts = { };

    for piece in string.gmatch((line or '') .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts[#parts + 1] = piece;
    end

    return parts;
end

--[[
* Every number on this wire is an integer by contract (the server formats
* each of them with %i), and several of them are handed straight back to
* string.format('%d') for a label or a command. A fraction there truncates
* silently on the client's LuaJIT and RAISES on the Lua the offline harness
* runs; an infinity or a NaN raises on both. A record that arrived malformed
* -- truncated, or rewritten by another addon on the same 0x017 stream --
* must not be able to reach either outcome, so this reader refuses anything
* outside the range a 32-bit wire field can mean -- which is also what rules
* out the infinities and the values too large to have an integer form -- and
* floors what it accepts. `value ~= value` is the NaN test, and it comes
* first: tonumber accepts 'nan' and every comparison against the result is
* false, so a range test alone lets one through.
--]]
local WIRE_MIN = -2147483648;
local WIRE_MAX = 4294967295;

local function num(text, fallback)
    local value = tonumber(text);

    if (value == nil or value ~= value or value < WIRE_MIN or value > WIRE_MAX) then
        return fallback;
    end

    return math.floor(value);
end

-- Which list fetch the f| records now arriving belong to: named by the h|
-- header, cleared with the envelope.
local currentList = nil;

--[[
* ANSWERS BUILD ASIDE AND COMMIT WHOLE (1.3.0) -- the family rule this wire
* documented (dwa/dwe/dwl/dwx: "lists build aside and commit on z|") and did
* not follow.
*
* The tab bar and its section dropdowns used to be WIPED at the hello
* answer's `d|` and refilled one `j|`/`k|` record at a time. Records ride
* one per chat packet and a full directory is dozens of them, so for the
* several frames between the wipe and the last record the window drew a tab
* bar that was first empty and then growing -- ImGui drops a tab that is not
* submitted this frame and picks another, so every Refresh, every zone line
* and every typed `!cpx` threw the player off the tab they were reading and
* onto whichever one happened to be first. The same wipe made the `j|`
* records of a hello answered TWICE (the five-second retry) stack a second
* set of tabs on top of the first.
*
* So both directories and the find results now build in a staging table and
* replace the live one in a single frame at `z|`. A record that arrives
* outside its verb's envelope still writes to the live table, exactly as it
* always did (dwbags' rule).
--]]
local arriving  = nil;
local listStage = nil;

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = num(parts[2], 0);

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwcpx.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- Nothing half-built survives a wire this addon cannot read.
            arriving    = nil;
            listStage   = nil;
            currentList = nil;

            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.serverSpoke = true;
        state.inbound     = parts[3];

        arriving  = nil;
        listStage = nil;

        if (state.inbound == 'hello') then
            arriving = { verb = 'hello', tabs = { }, drops = { } };

            local asked = requested['hello'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'find') then
            arriving          = { verb = 'find', results = { } };
            state.find.synced = false;
        end

        -- `list` is deliberately not reset here: the rows belong to whichever
        -- tab/drop the h| header names, and the header does the staging.

        return;
    end

    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwcpx'):append(chat.error(state.status)));
        end

        local endsWrite = state.inbound == 'buy' or state.inbound == 'confirm'
            or (state.inbound == 'status' and writePending ~= nil);

        -- A REFUSED CONFIRM IS A REFUSAL, NOT A RETRY PROMPT: every reason it
        -- can fail is fixed by a fresh quote and none by re-sending the word.
        if (kind == 'e' and (state.inbound == 'confirm'
                or (state.inbound == 'status' and writePending ~= nil
                    and writePending.what == 'confirm'))) then
            state.quote = nil;
        end

        if (endsWrite) then
            writePending = nil;
        end

        -- A REFUSAL THE SERVER WRAPPED ITSELF ANSWERS EVERY OUTSTANDING ASK
        -- (1.3.0). `d|1|status` is the envelope dwv.lua puts around a refusal
        -- raised before a verb opened one -- today that is "the Conquest Point
        -- Exchange is not loaded on this server" and nothing else, and it is
        -- the answer to whatever was asked. Left outstanding, the ask retried
        -- five seconds later, the server refused identically, and the player
        -- read the same red sentence in chat twice for one click. Retiring
        -- them is the mismatch branch's own remedy, applied to the other
        -- answer that will never change on a retry.
        if (kind == 'e' and state.inbound == 'status') then
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'hello') then
            -- THE COMMIT: the staged directory replaces the live one in a
            -- single frame, so the tab bar is never empty between two
            -- answers and the tab the player is reading survives a refresh.
            if (arriving ~= nil and arriving.verb == 'hello') then
                state.tabs     = arriving.tabs;
                state.drops    = arriving.drops;
                state.modelRev = state.modelRev + 1;
            end

            state.synced = true;

            if (state.status == 'Loading...') then
                state.status = '';
            end
        elseif (closing == 'list') then
            if (listStage ~= nil) then
                state.lists[listStage.key] = {
                    rows   = listStage.rows,
                    starts = listStage.starts,
                    page   = listStage.page,
                    pages  = listStage.pages,
                    total  = listStage.total,
                    synced = true,
                };

                state.modelRev = state.modelRev + 1;

                local asked = requested[string.format('list:%s:%d',
                    listStage.key, listStage.page)];

                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            elseif (currentList ~= nil) then
                -- A `list` envelope that carried no header names no list;
                -- the ask for its first page is retired anyway so the
                -- five-second retry does not repeat a question the server
                -- has already declined to answer with rows.
                local asked = requested[string.format('list:%s:1', currentList)];

                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            currentList = nil;
            listStage   = nil;
        elseif (closing == 'find') then
            if (arriving ~= nil and arriving.verb == 'find') then
                state.find.results = arriving.results;
                state.modelRev     = state.modelRev + 1;
            end

            state.find.synced = true;

            local asked = requested['find'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (closing == 'buy' or closing == 'confirm') then
            writePending = nil;

            if (closing == 'confirm') then
                -- Armed or not, this quote is spent; the g| that came with
                -- the answer already moved the purse on screen.
                state.quote = nil;
                -- The counts a purchase changes are re-read lazily.
                ownedCache.at = 0;

                -- AND THE QUOTE'S OWN SENTENCE GOES WITH IT (1.3.0). The
                -- buy answer left "<item> for 1,200 CP. !cpx confirm within
                -- 60 seconds." in the status line, and a confirm that
                -- SUCCEEDS carries only g| records -- so the instruction to
                -- confirm a quote that no longer exists stayed on screen
                -- after the purchase. A refusal is left alone: it set
                -- statusBad, and the reason a purchase failed is the one
                -- sentence worth keeping.
                if (not state.statusBad) then
                    state.status = '';
                end
            end
        end

        arriving = nil;

        return;
    end

    if (kind == 'g') then
        state.purse = {
            cp     = num(parts[2], 0),
            gil    = num(parts[3], 0),
            rank   = num(parts[4], 0),
            nation = num(parts[5], 0),
        };

        return;
    end

    if (kind == 'j') then
        local tabs = (arriving ~= nil and arriving.tabs) or state.tabs;

        table.insert(tabs, {
            key   = parts[3] or '',
            label = parts[4] or '',
            kind  = parts[5] or 'cp',
        });

        return;
    end

    if (kind == 'k') then
        local tabKey = parts[2] or '';
        local drops  = (arriving ~= nil and arriving.drops) or state.drops;

        if (drops[tabKey] == nil) then
            drops[tabKey] = { };
        end

        table.insert(drops[tabKey], {
            key   = parts[3] or '',
            label = parts[4] or '',
            count = num(parts[5], 0),
        });

        return;
    end

    if (kind == 'h') then
        local tabKey  = parts[2] or '';
        local dropKey = parts[3] or '';
        local page    = num(parts[4], 1);

        currentList = listKey(tabKey, dropKey);

        local live   = state.lists[currentList];
        local rows   = { };
        local starts = { };

        -- Pages after the first EXTEND what is already on screen, so the
        -- staged rows begin as a copy of the live ones. `starts` remembers
        -- where each page's rows began: a page answered TWICE (the ask
        -- retried, then both answers arriving) has to replace its own rows
        -- rather than append a second copy of them, which is what the old
        -- append-in-place did -- forty duplicate rows in the middle of a
        -- shop shelf, with the shelf number of each one still correct so
        -- nothing else ever complained.
        if (page > 1 and live ~= nil) then
            for key, at in pairs(live.starts or { }) do
                starts[key] = at;
            end

            local from = math.min(starts[page] or #live.rows, #live.rows);

            for n = 1, from do
                rows[n] = live.rows[n];
            end
        end

        starts[page] = #rows;

        listStage = {
            key    = currentList,
            rows   = rows,
            starts = starts,
            page   = page,
            pages  = num(parts[5], 1),
            total  = num(parts[6], 0),
        };

        return;
    end

    if (kind == 'f') then
        local rows = nil;

        if (listStage ~= nil and listStage.key == currentList) then
            rows = listStage.rows;
        elseif (currentList ~= nil and state.lists[currentList] ~= nil) then
            rows = state.lists[currentList].rows;
        end

        if (rows == nil) then
            return;
        end

        table.insert(rows, {
            index  = num(parts[2], 0),
            itemid = num(parts[3], 0),
            cp     = num(parts[4], 0),
            gil    = num(parts[5], 0),
            level  = num(parts[6], 0),
            stack  = num(parts[7], 1),
            label  = parts[8] or '',
            -- Additive tail (1.2.0): 0 teaches nothing, 1 already known,
            -- 2 not yet known. An old server sends eight fields; 0 it is.
            known  = num(parts[9], 0),
        });

        return;
    end

    if (kind == 'r') then
        table.insert((arriving ~= nil and arriving.results) or state.find.results, {
            index  = num(parts[2], 0),
            itemid = num(parts[3], 0),
            cp     = num(parts[4], 0),
            gil    = num(parts[5], 0),
            level  = num(parts[6], 0),
            stack  = num(parts[7], 1),
            tab    = parts[8] or '',
            label  = parts[9] or '',
            -- Additive tail (1.2.0), same meaning as the f| rows'.
            known  = num(parts[10], 0),
        });

        return;
    end

    if (kind == 't') then
        state.quote = {
            index    = num(parts[2], 0),
            qty      = num(parts[3], 1),
            currency = parts[4] or 'gil',
            total    = num(parts[5], 0),
            holds    = num(parts[6], 60),
            label    = parts[7] or '',
            at       = os.clock(),
        };

        writePending = nil;

        return;
    end
end

ashita.events.register('packet_in', 'dwcpx_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwcpx'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Reads over the synced state.
--]]
local function ticked(base, at, now)
    if (base == nil or at == nil) then
        return nil;
    end

    local left = base - (now - at);

    return left > 0 and left or 0;
end

--[[
* MEASURED LAYOUT, NOT GUESSED -- dwcraft's rule, adopted here by the bug it
* warns about (2026-08-30 player report, screenshot): the row lists reserved
* a hand-tuned 32 pixels for everything below them, and everything below
* them is a separator, the quote sentence, the Confirm/Cancel row and the
* status line. Four things in thirty-two pixels, so Confirm and Cancel were
* drawn off the bottom edge of the window and could not be clicked -- the
* player could see the price and not agree to it.
*
* Both helpers read the LIVE font each frame and fall back to a conservative
* constant when a binding does not expose the call. The asymmetry is
* deliberate: a fallback that is too big spends a few pixels of list, one
* that is too small hides the buttons again.
*
* Hoisted above the panes in 1.3.0: the column widths of the row table are
* measured the same way, and the measurement has to be defined before the
* view cache that stores it.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

-- Thousands separators, in ONE pass over the digits (1.3.0). The old loop
-- prepended a character at a time -- a fresh string per digit, twice per row
-- per frame on a six-hundred-row shelf -- for a value that only ever changes
-- when the wire says so.
local function fmtNumber(value)
    local text = tostring(math.floor(value));
    local head = #text % 3;
    local out  = { };

    if (head > 0) then
        out[1] = text:sub(1, head);
    end

    for i = head + 1, #text, 3 do
        out[#out + 1] = text:sub(i, i + 2);
    end

    return table.concat(out, ',');
end

--[[
* Who the Fits-me filter is filtering FOR. Read once per view build rather
* than once per row: it used to be a memory-manager call and a resource
* lookup for every row on screen, every frame. Returns nil when the client
* cannot say, which the filter reads as "everything fits" -- the filter is
* display sugar and the server owns every real gate.
--]]
local function mainJob()
    if (state.fitsBroken) then
        return nil, 0;
    end

    local ok, job, level = pcall(function ()
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (player == nil) then
            return nil, nil;
        end

        return player:GetMainJob(), player:GetMainJobLevel();
    end);

    if (not ok) then
        state.fitsBroken = true;

        return nil, 0;
    end

    if (job == nil or job == 0) then
        return nil, 0;
    end

    return job, level or 0;
end

-- Can that job wear this, at that level? Display-only sugar for the
-- "Fits me" filter; guarded, and latched off on the first error.
local function fitsMe(itemId, job, level)
    if (state.fitsBroken or job == nil) then
        return true;
    end

    local ok, fits = pcall(function ()
        local item = resourceOf(itemId);

        if (item == nil) then
            return true;
        end

        local jobs = item.Jobs;

        if (jobs == nil or jobs == 0) then
            return true; -- not equipment: everything fits
        end

        if (bit.band(jobs, bit.lshift(1, job)) == 0) then
            return false;
        end

        return item.Level == nil or item.Level <= level;
    end);

    if (not ok) then
        state.fitsBroken = true;

        return true;
    end

    return fits;
end

--[[
* The hover card: the client's own item knowledge plus this shelf's prices.
--]]
-- The combat skill a weapon trains, by the client's skill id (the same ids
-- the shelf's weapon sections are folded from in gen_cpx_catalog.py).
local WEAPON_SKILLS =
{
    [1] = 'Hand-to-Hand', [2] = 'Dagger', [3] = 'Sword', [4] = 'Great Sword',
    [5] = 'Axe', [6] = 'Great Axe', [7] = 'Scythe', [8] = 'Polearm',
    [9] = 'Katana', [10] = 'Great Katana', [11] = 'Club', [12] = 'Staff',
    [25] = 'Archery', [26] = 'Marksmanship', [27] = 'Throwing',
};

-- "DMG 12  Delay 240  DPS 3.00  Sword", or nil for anything that is not a
-- weapon with a delay. Damage per second is the plain retail arithmetic
-- (damage x 60 / delay), rounded to two places.
local function weaponLine(item)
    local damage = item.Damage or 0;
    local delay  = item.Delay or 0;

    if (damage <= 0 or delay <= 0) then
        return nil;
    end

    local skill = WEAPON_SKILLS[item.Skill or 0];

    return string.format('DMG %d   Delay %d   DPS %.2f%s', damage, delay, damage * 60 / delay,
        skill ~= nil and ('   ' .. skill) or '');
end

--[[
* The card's body, and the reason it is its own function (1.3.0): every line
* it draws reads a field off a client resource, and the card is drawn from
* inside the row table -- so a resource this client happens to disagree with
* would have thrown between BeginTooltip and EndTooltip AND between
* BeginTable and EndTable, which is a corrupt ImGui frame rather than a
* missing card. The body is pcall'd by the wrapper below; the pairs that
* must balance are outside it, and so is the description's wrap-position
* push, which is why this returns the description rather than drawing it.
--]]
local function cardBody(row, tabLabel)
    local item = nil;

    if (row.itemid ~= nil and row.itemid ~= 0) then
        item = resourceOf(row.itemid);

        drawIcon(row.itemid, 32);
    end

    imgui.Text(itemName(row.itemid, row.label));

    if (item ~= nil) then
        local tags = T{ };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags:append(string.format('iLvl %d', item.ItemLevel));
        end

        if (item.Level ~= nil and item.Level > 0) then
            tags:append(string.format('Lv.%d', item.Level));
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_RARE) ~= 0) then
            tags:append('Rare');
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_EX) ~= 0) then
            tags:append('Ex');
        end

        if (row.stack ~= nil and row.stack > 1) then
            tags:append(string.format('Stack %d', row.stack));
        end

        if (#tags > 0) then
            imgui.TextColored(theme.colors.info, table.concat(tags, '  '));
        end

        local slots = item.Slots ~= nil and slotsText(item.Slots) or nil;
        local jobs  = item.Jobs ~= nil and jobsText(item.Jobs) or nil;

        if (slots ~= nil and jobs ~= nil) then
            imgui.TextDisabled(slots .. '  --  ' .. jobs);
        elseif (slots ~= nil or jobs ~= nil) then
            imgui.TextDisabled(slots or jobs);
        end

        -- THE WEAPON LINE (1.2.1): damage, delay, the damage per second they
        -- make together, and the skill the weapon trains -- the four numbers a
        -- weapons shelf is shopped by, read off the client's own item resource
        -- (the same source the row's name comes from). Nothing here is
        -- computed on the server; a row that is not a weapon draws no line.
        local weapon = weaponLine(item);

        if (weapon ~= nil) then
            imgui.TextColored(theme.colors.info, weapon);
        end
    end

    -- The prices, colored by whether the purse on screen covers them.
    local purse = state.purse;

    if (row.gil ~= nil and row.gil > 0) then
        imgui.TextColored(
            (purse ~= nil and purse.gil >= row.gil) and theme.colors.ok or theme.colors.err,
            string.format('%s gil', fmtNumber(row.gil)));
        imgui.SameLine();
        imgui.TextDisabled('or');
        imgui.SameLine();
    end

    imgui.TextColored(
        (purse ~= nil and purse.cp >= (row.cp or 0)) and theme.colors.ok or theme.colors.err,
        string.format('%s CP', fmtNumber(row.cp or 0)));

    if (tabLabel ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled('-- ' .. tabLabel);
    end

    local owned = ownedCount(row.itemid);

    if (owned > 0) then
        imgui.TextDisabled(string.format('You are carrying %d.', owned));
    end

    -- The known-spell line (1.2.0): the server's answer for scroll-taught
    -- magic and the dice, riding each row's additive tail. Warn color when
    -- the book already holds it -- the whole point is stopping a duplicate
    -- buy while flicking through hundreds of scrolls.
    if (row.known == 1) then
        imgui.TextColored(theme.colors.warn or theme.colors.info, 'Already known.');
    elseif (row.known == 2) then
        imgui.TextColored(theme.colors.ok, 'Not yet learned.');
    end

    -- THE TYPED LINE FOR THIS ROW (1.3.0). Every shelf number is forever and
    -- the whole window is a renderer over commands a player could type, but
    -- nothing on screen ever said what this row's number was -- so the typed
    -- door was only discoverable by using it. The card names it as the line
    -- itself, which is also the line to paste into a macro.
    if (row.index ~= nil and row.index > 0) then
        imgui.TextDisabled(string.format('!cpx buy %d', row.index));
    end

    if (item ~= nil) then
        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            return cleanDescription(desc);
        end
    end

    return nil;
end

local function itemCard(row, tabLabel)
    imgui.BeginTooltip();

    local ok, desc = pcall(cardBody, row, tabLabel);

    if (not ok) then
        imgui.TextDisabled('This card could not be read from the client\'s own item data.');
        desc = nil;
    end

    if (desc ~= nil) then
        imgui.Separator();
        -- A fixed wrap width, not one derived from imgui state: the
        -- card must render the same whatever window it floats over.
        imgui.PushTextWrapPos(320.0);
        imgui.Text(desc);
        imgui.PopTextWrapPos();
    end

    imgui.EndTooltip();
end

--[[
* WHAT EVERY CONTROL MEANS, ON HOVER (1.3.0). Kept as a table rather than as
* string literals at the call sites so the harness can read them, and so a
* sentence that has to change changes in one place. Nothing self-evident is
* in here: a tip that only repeats its own label is noise a player learns to
* stop reading.
--]]
local TIPS = {
    purse    = 'Your conquest points and your gil, and the rank you hold in your own nation.\nThe Exchange asks for no rank and no nation -- the tabs are organisation, not a gate.',
    refresh  = 'Re-read your purse and every fetched shelf from the server.\nThe rows on screen stay until their replacement arrives.',
    section  = 'Which part of this shelf to show. The number beside each name is how many rows it stocks.',
    filter   = 'Narrows the rows already fetched, by name.\nThe Search tab asks the server about every shelf at once, fetched or not.',
    fits     = 'Only rows your current main job could equip at its level.\nGoods and scrolls always show.',
    qty      = 'How many a Buy click quotes, for stackable rows.\nSingle items always quote one.',
    sort     = 'The order the rows are listed in. Shelf order is the server\'s own -- the order a gate guard\'s menu uses.',
    find     = 'Three letters or more, then Enter. The server looks at every shelf, fetched or not, and answers up to thirty rows.',
    findGo   = 'Ask the server to search every shelf. Enter in the box does the same.',
    count    = 'How many rows are drawn, out of how many this view holds.\nOnly the first few hundred are handed to the window at once -- narrow it with the filter to see the rest.',
    buyGil   = 'Price this row in gil. A click only QUOTES it: nothing is spent until you press Confirm.',
    buyCp    = 'Price this row in conquest points. A click only QUOTES it: nothing is spent until you press Confirm.',
    buyOnly  = 'Price this row in conquest points -- conquest gear is not sold for gil.\nA click only QUOTES it: nothing is spent until you press Confirm.',
    buyBusy  = 'A line is already on its way to the server. The buttons come back when it answers.',
    buyQuote = 'A price is already quoted below. Confirm it or cancel it first -- one quote buys at most one thing.',
    confirm  = 'Buy it. The server re-checks your purse, your bag space, the item-level ceiling and the Rare re-buy before anything moves.',
    cancel   = 'Drop the quote. Nothing was spent, and the server\'s copy of it ages out on its own.',
    quoted   = 'The price the server is holding for you, and how long it holds it.\nThe countdown is the client\'s copy; the server\'s clock is the one that decides.',
    tabCp    = 'A gate guard\'s conquest-point shelf, paged by rank the way their menus are.\nAny nation, any rank: the rank is organisation here, not a gate.',
    tabShop  = 'A merchant shelf: every counter in Vana\'diel that sells this kind of thing, priced in gil OR conquest points.',
    tabFind  = 'Search every shelf at once -- including the ones this session never opened.',
    known    = 'Your own book already holds what this teaches, so a second one teaches nothing.\nThe server answers this per row, for the character you are on.',
    shelf    = 'The shelf this row lives on. Its own tab lists the rest of that section.',
};

--[[
* Actions. Every one is a line a player could type.
--]]
local function quoteBuy(row, currency)
    local qty = 1;

    if (row.stack ~= nil and row.stack > 1) then
        -- FLOORED, NOT JUST CLAMPED (1.3.0). This number reaches
        -- string.format('%d', qty) and it is the one number here the player
        -- can put a fraction into: a settings file carrying `qty = 2.5`
        -- silently bought two on the client and raised on the Lua the
        -- offline harness runs. The loader repairs the file; this is the
        -- guard where the value is CONSUMED, which is the half that has to
        -- hold whatever the file said.
        qty = math.floor(math.max(1, math.min(tonumber(config.qty[1]) or 1, row.stack)));
    end

    beginWrite('buy', row.label,
        string.format('!dwv buy %d %s %d', row.index, currency, qty));
end

--[[
* THE VIEW CACHE (1.3.0) -- the reason a 1,400-row Exchange can be a window.
*
* What a pane draws is not the wire rows: it is the wire rows filtered by
* the find box, filtered again by Fits-me, sorted, and capped -- and every
* row of it needs its display name, its price strings and its weapon line,
* none of which the wire carries. All of that used to happen INSIDE the
* render, THREE resource-manager lookups per row per frame (one for the
* filter's name, one for the row's, one for the damage and delay) plus two
* comma-inserting string builds, a string.lower and a button-id format --
* and with Fits-me on, a fourth lookup and a memory-manager call as well.
* The largest section in the catalog is Materials at 258 rows, so that is
* better than forty-five thousand resource lookups a second for data that
* cannot change without an answer arriving.
*
* It is all computed once here instead, into a prepared list, and thrown
* away only when something it depends on changes: the model revision (which
* every commit bumps), the filter text, the Fits-me flag and the job it
* answers for, the sort order, and which list is on screen. A frame that
* changes none of those does no work at all beyond drawing.
*
* THE CAP IS A DRAW CAP, NOT A SEARCH CAP: the filter and the sort see every
* row, and only what is handed to ImGui is bounded (the house's 300).
--]]
local DRAW_ROWS = 300;

local view = {
    key      = nil,
    rows     = { },
    total    = 0,
    matched  = 0,
    hasLevel = false,
    levelW   = 0,
    priceW   = 0,
    buyW     = 0,
};

-- Which tab a row lives on, in the words the server chose for its label. The
-- find records name the tab by KEY, and a key is a wire token ('goods'), not
-- a sentence -- so the label the tab bar shows is what the row should say.
local function tabLabelOf(tabKey)
    if (tabKey == nil or tabKey == '') then
        return nil;
    end

    for _, tab in ipairs(state.tabs) do
        if (tab.key == tabKey) then
            return tab.label;
        end
    end

    return tabKey;
end

-- One wire row, dressed for drawing. Everything here is derived from data
-- that cannot change without an answer, which is what makes it cacheable.
local function prepareRow(row, prefix)
    local name = itemName(row.itemid, row.label);
    local item = resourceOf(row.itemid);

    local weapon    = nil;
    local weaponTip = nil;

    if (item ~= nil and (item.Damage or 0) > 0 and (item.Delay or 0) > 0) then
        weapon    = string.format('D%d/%d', item.Damage, item.Delay);
        weaponTip = weaponLine(item);
    end

    return {
        row       = row,
        name      = name,
        lower     = string.lower(name),
        level     = (row.level ~= nil and row.level > 1) and string.format('Lv.%d', row.level) or nil,
        weapon    = weapon,
        weaponTip = weaponTip,
        -- THE KNOWN TAG (1.3.0). The `known` tail has been on the wire since
        -- 1.2.0 and only the hover card read it, so the answer to "have I
        -- learned this one" cost a hover -- on a scrolls shelf of a hundred
        -- and forty rows, which is exactly the shelf the field was added for.
        -- Only the ALREADY KNOWN are marked: on a shelf of teachers, the
        -- unmarked rows are the ones worth buying.
        known     = row.known == 1,
        -- Where a find hit lives. Shelf rows carry no tab of their own --
        -- the tab they are drawn under is the answer.
        shelf     = tabLabelOf(row.tab),
        gilText   = (row.gil ~= nil and row.gil > 0) and (fmtNumber(row.gil) .. 'g') or nil,
        cpText    = fmtNumber(row.cp or 0) .. 'cp',
        -- THE BUTTON LABELS, BUILT ONCE. An ImGui id is part of the label
        -- string, so the row used to concatenate two or three of them every
        -- frame -- five hundred string allocations a frame on a full shelf,
        -- for ids that cannot change while the row exists. The shelf number
        -- is forever and unique across every shelf, which is what makes the
        -- id stable: a re-sort must never hand ImGui the same id for a
        -- different row.
        gilId     = string.format('Gil##dwcpx_buy_g_%s_%d', prefix, row.index or 0),
        cpId      = string.format('CP##dwcpx_buy_c_%s_%d', prefix, row.index or 0),
        buyId     = string.format('Buy##dwcpx_buy_%s_%d', prefix, row.index or 0),
    };
end

--[[
* The comparators. Every one falls back to the shelf number, which is unique
* per row -- a comparator that can answer "neither is less" for two DIFFERENT
* rows is not a strict weak ordering, and table.sort raises "invalid order
* function for sorting" when it catches one.
--]]
local SORT_LABELS = {
    shelf = 'Shelf order',
    name  = 'Name',
    price = 'Cheapest',
    level = 'Level',
};

local function sortPrepared(rows, mode)
    if (mode == 'name') then
        table.sort(rows, function (a, b)
            if (a.lower ~= b.lower) then
                return a.lower < b.lower;
            end

            return (a.row.index or 0) < (b.row.index or 0);
        end);
    elseif (mode == 'price') then
        table.sort(rows, function (a, b)
            local ac = a.row.cp or 0;
            local bc = b.row.cp or 0;

            if (ac ~= bc) then
                return ac < bc;
            end

            return (a.row.index or 0) < (b.row.index or 0);
        end);
    elseif (mode == 'level') then
        table.sort(rows, function (a, b)
            local al = a.row.level or 0;
            local bl = b.row.level or 0;

            if (al ~= bl) then
                return al < bl;
            end

            return (a.row.index or 0) < (b.row.index or 0);
        end);
    end
end

--[[
* The prepared, filtered, sorted, capped view of one row source. `filtered`
* says whether the client-side filter and the Fits-me checkbox apply -- the
* Search tab's rows are already the answer to a question the player asked,
* so a second filter over them would hide hits the server just found.
--]]
local function viewFor(sourceKey, rows, prefix, filtered)
    local job, level = nil, 0;

    if (filtered and state.fitsMe[1]) then
        job, level = mainJob();
    end

    local filterText = filtered and string.lower(state.filter[1] or '') or '';

    local key = table.concat({
        sourceKey,
        tostring(state.modelRev),
        filterText,
        state.fitsMe[1] and '1' or '0',
        tostring(job),
        tostring(level),
        tostring(config.sort),
        tostring(#rows),
    }, '\31');

    if (view.key == key) then
        return view;
    end

    local prepared = { };

    for _, row in ipairs(rows) do
        local entry   = prepareRow(row, prefix);
        local visible = true;

        if (#filterText > 0 and string.find(entry.lower, filterText, 1, true) == nil) then
            visible = false;
        end

        if (visible and job ~= nil and not fitsMe(row.itemid, job, level)) then
            visible = false;
        end

        if (visible) then
            prepared[#prepared + 1] = entry;
        end
    end

    sortPrepared(prepared, config.sort);

    local matched = #prepared;

    for n = #prepared, DRAW_ROWS + 1, -1 do
        prepared[n] = nil;
    end

    -- The column widths, measured from the WIDEST STRING THIS VIEW ACTUALLY
    -- HOLDS rather than from a sample nobody checked. Only the longest
    -- candidate is handed to CalcTextSize (digits are the same width in this
    -- font, so longest-by-characters is the widest), which keeps a rebuild
    -- to a handful of measurements instead of one per row.
    local hasLevel  = false;
    local anyGil    = false;
    local widePrice = '';

    for _, entry in ipairs(prepared) do
        if (entry.level ~= nil) then
            hasLevel = true;
        end

        if (entry.gilText ~= nil) then
            anyGil = true;
        end

        local price = (entry.gilText ~= nil and (entry.gilText .. ' / ') or '') .. entry.cpText;

        if (#price > #widePrice) then
            widePrice = price;
        end
    end

    view = {
        key      = key,
        rows     = prepared,
        total    = #rows,
        matched  = matched,
        hasLevel = hasLevel,
        levelW   = hasLevel and (textWidth('Lv.99', 36) + 8) or 1,
        priceW   = textWidth(widePrice ~= '' and widePrice or '999,999cp', 110) + 8,
        -- The buy cell holds either both small buttons or one, and the two
        -- greyed words that stand in for them while a write or a quote is
        -- outstanding -- so it is measured from whichever is widest.
        buyW     = math.max(
            anyGil and (textWidth('Gil', 24) + textWidth('CP', 18) + 34) or (textWidth('Buy', 26) + 18),
            textWidth('quoted', 44) + 8),
    };

    return view;
end

--[[
* One shelf row, as table cells: the item (icon, name, and a weapon's
* damage/delay inline), its level where the view has any, its prices, and
* the Buy buttons.
*
* IT USED TO BE A CHAIN OF SameLine CALLS (1.3.0 changed it). That chain put
* every price and every button at whatever x the name happened to end at, so
* a shelf read as a ragged staircase and one long item name pushed its own
* Buy button off the right edge of the window. The item column now STRETCHES
* and the columns beside it are measured from their own widest content, so
* the prices line up down the shelf and the buttons stay reachable however
* long a name runs. The level column is drawn only where some row on screen
* has a level worth showing.
*
* The hover card rides the icon and the name (drawIcon leaves the cursor on
* the same line, and IsItemHovered reads the LAST item, so the icon's hover
* is taken first).
--]]
local function shelfRow(entry, hasLevel)
    local row = entry.row;

    imgui.TableNextRow();
    imgui.TableNextColumn();

    drawIcon(row.itemid, 20);

    local hoveredIcon = imgui.IsItemHovered();

    imgui.Text(entry.name);

    if (imgui.IsItemHovered() or hoveredIcon) then
        -- The card names the shelf in the words the tab bar uses, not in the
        -- wire's own key: 'Goods' rather than 'goods'.
        itemCard(row, entry.shelf);
    end

    -- A weapon row wears its damage and delay inline (1.2.1), so the shelf can
    -- be read across without hovering every sword.
    if (entry.weapon ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(entry.weapon);

        if (imgui.IsItemHovered() and entry.weaponTip ~= nil) then
            imgui.SetTooltip(entry.weaponTip);
        end
    end

    if (entry.known) then
        imgui.SameLine();
        imgui.TextColored(theme.colors.warn or theme.colors.info, 'known');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.known);
        end
    end

    if (entry.shelf ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(entry.shelf);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.shelf);
        end
    end

    if (hasLevel) then
        imgui.TableNextColumn();

        if (entry.level ~= nil) then
            imgui.TextDisabled(entry.level);
        end
    end

    imgui.TableNextColumn();

    local purse = state.purse;

    if (entry.gilText ~= nil) then
        imgui.TextColored(
            (purse ~= nil and purse.gil >= row.gil) and theme.colors.ok or theme.colors.err,
            entry.gilText);
        imgui.SameLine();
        imgui.TextDisabled('/');
        imgui.SameLine();
    end

    imgui.TextColored(
        (purse ~= nil and purse.cp >= row.cp) and theme.colors.ok or theme.colors.err,
        entry.cpText);

    imgui.TableNextColumn();

    -- WHY THERE IS NO BUTTON HERE, SAID OUT LOUD (1.3.0). The buttons still
    -- disappear while a write is in flight or a quote is armed -- that part
    -- is the two-step's own discipline -- but an empty cell reads as "this
    -- row cannot be bought at all". A greyed word in their place keeps the
    -- column steady and carries the reason on hover.
    --
    -- Deliberately a TextDisabled and not a BeginDisabled button: ImGui does
    -- not report a hover over a disabled item without a HoveredFlags this
    -- suite does not use, so a greyed button's tooltip would never appear.
    if (writePending ~= nil) then
        imgui.TextDisabled('busy');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.buyBusy);
        end
    elseif (state.quote ~= nil) then
        imgui.TextDisabled('quoted');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.buyQuote);
        end
    elseif (entry.gilText ~= nil) then
        if (imgui.SmallButton(entry.gilId)) then
            quoteBuy(row, 'gil');
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.buyGil);
        end

        imgui.SameLine();

        if (imgui.SmallButton(entry.cpId)) then
            quoteBuy(row, 'cp');
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.buyCp);
        end
    else
        if (imgui.SmallButton(entry.buyId)) then
            quoteBuy(row, 'cp');
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.buyOnly);
        end
    end
end

--[[
* The armed quote, and the ONLY place Confirm exists. Local teardown on
* Cancel: the server's quote ages out on its own clock, and nothing un-asks
* a price.
--]]
local function quoteStrip()
    if (state.quote == nil) then
        return;
    end

    imgui.Separator();

    local left = ticked(state.quote.holds, state.quote.at, state.now);

    if (left ~= nil and left <= 0) then
        state.quote = nil;

        return;
    end

    -- FLOORED BEFORE IT IS FORMATTED: `left` is a countdown in fractional
    -- seconds, and %d on a fraction is a truncation on the client's LuaJIT
    -- but a RAISE on the Lua the offline harness runs -- so the one number
    -- here that is not already an integer off the wire is made one.
    imgui.TextColored(theme.colors.hint, string.format('%s%s -- %s %s   (%ds to confirm)',
        state.quote.label,
        state.quote.qty > 1 and string.format(' x%d', state.quote.qty) or '',
        fmtNumber(state.quote.total),
        state.quote.currency == 'gil' and 'gil' or 'CP',
        math.floor(left or 0)));

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.quoted);
    end

    if (writePending ~= nil) then
        imgui.TextDisabled('buying...');
    else
        if (imgui.SmallButton('Confirm##dwcpx_confirm')) then
            state.quote = nil;
            beginWrite('confirm', 'confirm', '!dwv confirm');
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.confirm);
        end

        imgui.SameLine();

        if (imgui.SmallButton('Cancel##dwcpx_cancel')) then
            state.quote = nil;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.cancel);
        end
    end
end

--[[
* How many lines the status sentence will take once it wraps (1.3.0). It was
* drawn on one unwrapped line and charged for one, and the sentences it
* draws are whole refusals off the wire -- up to the protocol's 130-byte
* budget -- so the end of "You need 12,000 conquest points and have 4,310.
* Nothing was charged." simply ran off the right edge of the window. It
* wraps now, and the footer is charged for what the wrap will cost.
*
* Capped at three lines: a wire sentence cannot need more, and a reserve
* that grows without bound would eat the shelf it is making room beneath.
--]]
local function statusLines()
    if (state.status == nil or state.status == '') then
        return 0;
    end

    local avail = metric('GetWindowWidth', 680) - 24;
    local width = textWidth(state.status, 0);

    if (avail <= 0 or width <= 0) then
        return 1;
    end

    return math.min(3, math.max(1, math.ceil(width / avail)));
end

-- What the row lists must leave for the footer. Only the strip that will
-- actually be drawn is charged for, so an idle window spends nothing on a
-- quote it is not showing.
local function footerReserve()
    local line = metric('GetTextLineHeightWithSpacing', 20);

    -- The separator quoteStrip draws, plus the window's own bottom padding.
    local reserve = 12;

    if (state.quote ~= nil) then
        -- The quote sentence, then either 'buying...' or Confirm/Cancel.
        reserve = reserve + line + metric('GetFrameHeightWithSpacing', 26);
    end

    reserve = reserve + line * statusLines();

    return -math.ceil(reserve);
end

--[[
* The Qty stepper, drawn by every pane that can Buy. ONE function rather
* than one copy per tab: the Search tab shipped without it (2026-08-30
* report -- a player who searched for Millioncorn could only ever buy one),
* and two copies would have been two chances to drift apart again.
*
* InputInt spends its item width on the number field AND both step buttons.
* At the old 70 the buttons took nearly all of it and a two-digit quantity
* was clipped to its first digit: 10 read as 1, 20 as 2. The width below is
* the space three digits actually need plus the two buttons' own.
--]]
local function qtyControl()
    imgui.SetNextItemWidth(textWidth('0000', 34)
        + metric('GetFrameHeight', 22) * 2
        + 16);

    if (imgui.InputInt('Qty##dwcpx_qty', config.qty)) then
        -- Floored as well as clamped: the value reaches string.format('%d'),
        -- where a fraction is a silent truncation on one Lua and a raise on
        -- another, and a stepper is not the only thing that can put a number
        -- in this table (a hand-edited settings file is the other, and it is
        -- repaired on load for the same reason).
        local qty = tonumber(config.qty[1]) or 1;

        if (qty ~= qty or qty < 1) then
            qty = 1;
        elseif (qty > 99) then
            qty = 99;
        end

        config.qty[1] = math.floor(qty);

        pcall(settings.save);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.qty);
    end
end

--[[
* The row order, drawn by every pane that lists rows. Persisted per PC: a
* player who prefers the cheapest first should not have to say so again on
* every login, and the setting costs one word in the settings file.
--]]
local function sortControl()
    imgui.SetNextItemWidth(textWidth('Shelf order', 78) + metric('GetFrameHeight', 22) + 12);

    -- The hover test goes between Begin and the body: BeginCombo submits the
    -- combo button whether or not the popup opened, so this reads the button
    -- either way, and EndCombo would have left a different last item.
    local openCombo = imgui.BeginCombo('##dwcpx_sort', SORT_LABELS[config.sort] or SORT_LABELS.shelf);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.sort);
    end

    if (openCombo) then
        for _, key in ipairs(SORT_KEYS) do
            if (imgui.Selectable(string.format('%s##dwcpx_sort_%s', SORT_LABELS[key], key), key == config.sort)) then
                config.sort = key;

                pcall(settings.save);
            end
        end

        imgui.EndCombo();
    end
end

-- How much of the view is on screen. It doubles as the draw cap's own
-- explanation: a section the cap is trimming says so rather than looking
-- like a section that is simply short.
local function countLabel(shown)
    local text;

    if (shown.matched > #shown.rows) then
        text = string.format('%d of %d shown', #shown.rows, shown.matched);
    elseif (shown.matched < shown.total) then
        text = string.format('%d of %d rows', shown.matched, shown.total);
    else
        text = string.format('%d rows', shown.total);
    end

    imgui.TextDisabled(text);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.count);
    end
end

--[[
* One tab's pane: the dropdown the server sent, the client-side filter, and
* the fetched rows. The fetch itself is armed by the render (lazy: a tab
* nobody looks at is never fetched).
--]]
local wantedList = nil;

local function shelfPane(tab)
    local drops = state.drops[tab.key] or { };

    if (#drops == 0) then
        imgui.TextDisabled('Nothing is stocked here.');

        return;
    end

    -- The selected section: whichever one this session or this PC was last
    -- left on, and the first stocked one when that names nothing.
    --
    -- RESOLVED AGAINST THE LIVE DIRECTORY EVERY FRAME (1.3.0), not once when
    -- the tab was first drawn: a remembered section the server has since
    -- renamed, emptied or stopped sending used to be kept anyway -- the
    -- dropdown read 'Pick a section...' and the list read behind it asked
    -- for a shelf that is not there, so the pane sat on 'Fetching the
    -- shelf...' for the rest of the session with nothing able to change it.
    local current = nil;
    local wanted  = state.selected[tab.key] or config.sections[tab.key];

    for _, drop in ipairs(drops) do
        if (drop.key == wanted) then
            current = drop;
        end
    end

    if (current == nil) then
        for _, drop in ipairs(drops) do
            if (current == nil and drop.count > 0) then
                current = drop;
            end
        end

        current = current or drops[1];
    end

    local selectedKey = current.key;

    state.selected[tab.key] = selectedKey;

    local widest = 'Pick a section...';

    for _, drop in ipairs(drops) do
        if (#drop.label > #widest) then
            widest = drop.label;
        end
    end

    -- MEASURED, NOT 170 PIXELS. Section names run from 'Rank 1' to
    -- 'Meals & Drinks' and carry their stock count in brackets, and the
    -- fixed width clipped the longer ones to a name the player then had to
    -- open the dropdown to read.
    imgui.SetNextItemWidth(textWidth(widest .. ' (9999)', 170) + metric('GetFrameHeight', 22) + 12);

    local openDrop = imgui.BeginCombo('##dwcpx_drop_' .. tab.key,
        string.format('%s (%d)', current.label, current.count));

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.section);
    end

    if (openDrop) then
        for _, drop in ipairs(drops) do
            if (imgui.Selectable(string.format('%s (%d)##dwcpx_drop_%s_%s',
                    drop.label, drop.count, tab.key, drop.key), drop.key == selectedKey)) then
                state.selected[tab.key]  = drop.key;
                config.sections[tab.key] = drop.key;

                pcall(settings.save);
            end
        end

        imgui.EndCombo();
    end

    imgui.SameLine();
    imgui.SetNextItemWidth(140);
    imgui.InputTextWithHint('##dwcpx_filter', 'filter...', state.filter, 48);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.filter);
    end

    imgui.SameLine();

    if (imgui.Checkbox('Fits me##dwcpx_fits', state.fitsMe)) then
        config.fits = state.fitsMe[1] == true;

        pcall(settings.save);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.fits);
    end

    -- THE SECOND CONTROL LINE (1.3.0). Five controls on one line ran past
    -- the right edge of the window at anything narrower than the default
    -- size, and the last of them -- Qty -- is the one a player reaches for
    -- most. Two short lines fit any width the size constraint allows.
    sortControl();

    imgui.SameLine();
    qtyControl();

    selectedKey = state.selected[tab.key];
    wantedList  = { tab = tab.key, drop = selectedKey };

    local key   = listKey(tab.key, selectedKey);
    local list  = state.lists[key];
    local rows  = (list ~= nil and list.rows) or { };
    local shown = viewFor(key, rows, tab.key, true);

    if (list ~= nil) then
        imgui.SameLine();
        countLabel(shown);
    end

    imgui.Separator();

    if (not imgui.BeginChild('##dwcpx_rows_' .. tab.key, { -1, footerReserve() }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (list == nil or (#list.rows == 0 and not list.synced)) then
        imgui.TextDisabled('Fetching the shelf...');
        imgui.EndChild();

        return;
    end

    if (#shown.rows == 0) then
        imgui.TextDisabled(list.total == 0 and 'Nothing is stocked in this section.'
            or 'Nothing here matches the filter.');
    elseif (imgui.BeginTable('##dwcpx_rowtable_' .. tab.key, shown.hasLevel and 4 or 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthStretch, 1.0, 0);

        if (shown.hasLevel) then
            imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, shown.levelW, 0);
        end

        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, shown.priceW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, shown.buyW, 0);

        for _, entry in ipairs(shown.rows) do
            shelfRow(entry, shown.hasLevel);
        end

        imgui.EndTable();
    end

    if (list.pages ~= nil and list.page ~= nil and list.page < list.pages) then
        imgui.TextDisabled(list.page >= MAX_PAGES
            and string.format('This section says it has %d pages; %d is as far as the window will fetch.',
                list.pages, MAX_PAGES)
            or string.format('Fetching more... (%d of %d pages)', list.page, list.pages));
    end

    imgui.EndChild();
end

--[[
* The Search pane: the server-side find, so it sees shelves this session
* never fetched. Results name the tab they live on.
--]]
local function searchPane()
    imgui.SetNextItemWidth(220);

    local enterPressed = imgui.InputTextWithHint('##dwcpx_find', 'search every shelf...',
        state.find.text, 48, ImGuiInputTextFlags_EnterReturnsTrue);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.find);
    end

    imgui.SameLine();

    local clicked = imgui.SmallButton('Search##dwcpx_find_go');

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.findGo);
    end

    -- The same Qty the shelves carry. A search result is a shelf row (the
    -- find record carries its stack size, and Buy here goes through the same
    -- quoteBuy), so the control was the only thing missing -- without it a
    -- player who found Millioncorn by name could buy exactly one at a time.
    -- On its own line since 1.3.0, so the two panes read the same way.
    sortControl();

    imgui.SameLine();
    qtyControl();

    local shown = viewFor('find', state.find.results, 'find', false);

    if (state.find.asked and state.find.synced) then
        imgui.SameLine();
        countLabel(shown);
    end

    if ((enterPressed or clicked) and #(state.find.text[1] or '') >= 3) then
        state.find.results  = { };
        state.find.synced   = false;
        state.find.asked    = true;
        state.find.command  = '!dwv find ' .. state.find.text[1];
        requested['find']   = nil;
        state.modelRev      = state.modelRev + 1;

        askOnce('find', state.find.command, state.now);
    end

    imgui.Separator();

    if (not imgui.BeginChild('##dwcpx_find_rows', { -1, footerReserve() }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    local asked = requested['find'];

    if (not state.find.asked) then
        imgui.TextDisabled('Three letters or more, then Search. Every shelf is looked at, fetched or not.');
    elseif (not state.find.synced and type(asked) == 'table' and asked.gaveUp) then
        -- A SEARCH THAT WAS NEVER ANSWERED SAYS SO (1.3.0). It used to sit
        -- on 'Searching...' for the rest of the session: the ask gave up
        -- after its one retry and nothing told the pane, so the one state
        -- the player could not recover from looked exactly like the one
        -- that resolves itself in a second.
        imgui.TextDisabled('The server did not answer that search. Press Search to ask again.');
    elseif (not state.find.synced) then
        imgui.TextDisabled('Searching...');
    elseif (#shown.rows == 0) then
        imgui.TextDisabled('Nothing on any shelf matches that.');
    elseif (imgui.BeginTable('##dwcpx_rowtable_find', shown.hasLevel and 4 or 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthStretch, 1.0, 0);

        if (shown.hasLevel) then
            imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, shown.levelW, 0);
        end

        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, shown.priceW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, shown.buyW, 0);

        for _, entry in ipairs(shown.rows) do
            shelfRow(entry, shown.hasLevel);
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

--[[
* The window.
--]]
local function renderWindow()
    -- The purse header: what you hold, where you rank.
    if (state.purse ~= nil) then
        imgui.TextColored(theme.colors.badge, fmtNumber(state.purse.cp) .. ' CP');
        imgui.SameLine();
        imgui.TextDisabled('|');
        imgui.SameLine();
        imgui.TextColored(theme.colors.badge, fmtNumber(state.purse.gil) .. ' gil');
        imgui.SameLine();
        imgui.TextDisabled(string.format('Rank %d, %s', state.purse.rank,
            NATION_NAMES[state.purse.nation] or 'Vana\'diel'));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.purse);
        end
    else
        imgui.TextDisabled('Reading your purse...');
    end

    -- MEASURED, NOT 70 PIXELS: the button's own width plus the window's
    -- padding, so it sits against the right edge at any window size instead
    -- of overlapping the purse line on a narrow one.
    --
    -- And right-aligned ONLY where there is room for it. SameLine takes an
    -- absolute x and will move the cursor BACKWARDS if given one, so at the
    -- window's minimum width the old fixed offset drew the button on top of
    -- the rank sentence. Where the purse line already reaches past the
    -- right-hand slot, the button simply follows it.
    local rightAt = metric('GetWindowWidth', 680)
        - textWidth('Refresh', 48) - metric('GetFrameHeight', 22) - 8;

    imgui.SameLine();

    if (rightAt > metric('GetCursorPosX', 0)) then
        imgui.SameLine(rightAt);
    end

    if (imgui.SmallButton('Refresh##dwcpx_refresh')) then
        -- THE ROWS ON SCREEN STAY UNTIL THEIR REPLACEMENT COMMITS (1.3.0).
        -- This used to throw every fetched shelf away, so a Refresh blanked
        -- the list the player was reading into 'Fetching the shelf...' and
        -- scrolled it back to the top. Marking them unsynced re-asks page
        -- one of each, and the z| commit swaps the rows in one frame.
        for _, list in pairs(state.lists) do
            list.synced = false;
        end

        refresh();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.refresh);
    end

    wantedList = nil;

    if (imgui.BeginTabBar('##dwcpx_tabs')) then
        for _, tab in ipairs(state.tabs) do
            local openTab = imgui.BeginTabItem(string.format('%s##dwcpx_tab_%s', tab.label, tab.key));

            -- The hover test goes here rather than inside the branch: a tab
            -- is submitted whether or not it is the selected one, so this is
            -- the only place an UNselected tab can explain itself.
            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(tab.kind == 'shop' and TIPS.tabShop or TIPS.tabCp);
            end

            if (openTab) then
                local ok, err = pcall(shelfPane, tab);

                if (not ok) then
                    imgui.TextDisabled('This shelf failed to draw: ' .. tostring(err));
                end

                imgui.EndTabItem();
            end
        end

        local openFind = imgui.BeginTabItem('Search##dwcpx_tab_find');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabFind);
        end

        if (openFind) then
            local ok, err = pcall(searchPane);

            if (not ok) then
                imgui.TextDisabled('The search failed to draw: ' .. tostring(err));
            end

            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    quoteStrip();

    if (state.status ~= '' and state.status ~= nil) then
        -- WRAPPED, and the footer above was charged for the wrap: a refusal
        -- off the wire is a whole sentence and used to run off the right
        -- edge of the window with no way to read the end of it.
        imgui.PushTextWrapPos(0.0);
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.hint, state.status);
        imgui.PopTextWrapPos();
    end
end

ashita.events.register('d3d_present', 'dwcpx_present', function ()
    state.now = os.clock();

    if (writePending ~= nil and (state.now - writePending.at) > WRITE_TIMEOUT) then
        writePending = nil;

        -- AND THE LINE ITSELF IS DROPPED IF IT NEVER LEFT (1.3.0). At most
        -- one write is ever in flight (both buttons that make one are gone
        -- while it is), so a queue that still holds something at the moment
        -- the clock runs out is holding a line that was never sent -- and a
        -- window that has just told the player nothing was re-sent must not
        -- then send it a minute later when the road reopens.
        writeQueue = { };

        state.status    = 'No answer from the server. Nothing was re-sent -- Refresh shows where you stand.';
        state.statusBad = true;
    end

    pumpQueue(state.now);

    if (not state.open[1]) then
        return;
    end

    -- The reads, armed by what is on screen (lazy: a session that never
    -- opens the window never handshakes).
    needHello(state.now);

    if (state.synced and wantedList ~= nil) then
        needList(wantedList.tab, wantedList.drop, state.now);
    end

    needFind(state.now);

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 680, 540 }, ImGuiCond_FirstUseEver);

    -- A FLOOR UNDER THE SIZE (1.3.0). FirstUseEver means imgui.ini wins, and
    -- imgui.ini remembers whatever the window was last dragged to -- including
    -- a size with no room for the tab bar's own scroll arrows, where the
    -- section dropdown, the Qty box and the footer's Confirm button are all
    -- off the edge and the window cannot be used to get back. The minimum is
    -- measured rather than picked: the two control lines, the tab bar, a few
    -- rows and the footer.
    -- The width is the first control line's own: the widest section name in
    -- its dropdown, the 140-pixel filter box, the Fits-me checkbox and the
    -- spacing between them. The height is the two control lines, the tab
    -- bar, the purse line, a separator and the footer.
    imgui.SetNextWindowSizeConstraints(
        { textWidth('Meals & Drinks (9999)', 170) + textWidth('Fits me', 50) + 260,
          metric('GetFrameHeightWithSpacing', 26) * 6 + metric('GetTextLineHeightWithSpacing', 20) * 4 },
        { 99999, 99999 });

    -- NoDocking: dragging one Driftwood window onto another used to fuse
    -- them into a single unthemed dock that imgui.ini kept across reloads.
    local visible = imgui.Begin('DriftwoodXI Conquest Point Exchange##dwcpx', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwcpx'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwcpx'):append(chat.message('Window closed. Everything it does also works as !cpx commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle.
--]]
local function openWindow()
    state.open[1]   = true;
    state.reported  = false;
    state.status    = state.synced and '' or 'Loading...';
    state.statusBad = false;

    refresh();
end

local function toggleWindow()
    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end

--[[
* Watch what the player sends. Bare `!cpx` (and ui/window/gui) toggles the
* window and never leaves the client; every other !cpx line passes through
* and marks our state stale, because a typed buy changes the purse under
* the window. Any other outgoing line stamps the throttle -- the client's
* rate limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwcpx_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!cpx' or lower == '!cpx ui' or lower == '!cpx window' or lower == '!cpx gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwv') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 4) == '!cpx') then
        refresh();
    end
end);

ashita.events.register('command', 'dwcpx_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Cpx`
    -- matched nothing and fell through to the game as an unknown command.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwcpx' and first ~= '/cpx') then
        return;
    end

    e.blocked = true;

    toggleWindow();
end);

ashita.events.register('load', 'dwcpx_load', function ()
    print(chat.header('dwcpx'):append(chat.message('/cpx opens the Conquest Point Exchange: every nation\'s CP shelf and every merchant\'s counter, from anywhere. Everything it does also works typed as !cpx commands.')));

    -- SAID ONCE, AND ONLY WHEN SOMETHING WAS ACTUALLY REPLACED: a settings
    -- file the loader had to repair is a preference the player will notice
    -- has moved, and silence about that reads as the window losing settings
    -- at random.
    if (configRepaired) then
        print(chat.header('dwcpx'):append(chat.message('Your saved dwcpx settings could not be read and were reset to their defaults.')));
    end
end);

--[[
* A login is a new character; a zone line is a new session as far as the
* server's answers are concerned. Reset, and re-ask only once the server has
* spoken this session (an automatic line against a dead verb is the player
* saying it in public).
--]]
ashita.events.register('packet_in', 'dwcpx_zonein', function (e)
    if (e.id == 0x000A) then
        state.synced    = false;
        state.tabs      = { };
        state.drops     = { };
        state.lists     = { };
        state.purse     = nil;
        state.status    = 'Loading...';
        state.statusBad = false;

        -- The staging tables belong to whatever envelope was open across the
        -- zone line, and that envelope is not coming back.
        arriving    = nil;
        listStage   = nil;
        currentList = nil;

        -- The search results were answered for a session that has ended.
        -- The text the player typed is kept -- it is theirs -- but the rows
        -- are dropped and the pane goes back to inviting a fresh search
        -- rather than showing an answer nobody asked twice for.
        state.find.results = { };
        state.find.synced  = false;
        state.find.asked   = false;
        state.find.command = nil;

        state.modelRev = state.modelRev + 1;

        -- A write cannot survive the zone line it was in flight across, and
        -- NEITHER CAN A QUOTE: it was priced against a purse and a bag this
        -- window can no longer vouch for.
        writePending = nil;
        state.quote  = nil;

        -- AND NEITHER CAN A WRITE THAT NEVER LEFT (1.3.0). The queue is held
        -- shut while the client is zoning -- which is the whole point of
        -- canSend -- so a Confirm clicked a beat before the zone line was
        -- still sitting in it, unsent, when this handler declared the quote
        -- dead. It then went out on the far side of the load screen, against
        -- a quote the server holds for a full minute, and bought the thing
        -- this window had already told the player it had dropped. Both
        -- queues are emptied: the reads are re-armed by refresh() below.
        readQueue  = { };
        writeQueue = { };

        ownedCache.at = 0;

        if (state.serverSpoke and state.open[1]) then
            refresh();
        end
    end
end);
