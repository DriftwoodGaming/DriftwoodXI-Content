--[[
* DriftwoodXI -- dwmacro
*
* Remembers which macro book and set you were on, and puts you back on it
* after a zone line and after a fresh login.
*
* WHY THIS IS AN ADDON AND NOT A SERVER PATCH.
*
* The macro palette is not server state. It is not in the database, it is not
* in any packet, and the map server has never been told about it: the string
* "macro" does not appear anywhere in atom0s's packet reference (XiPackets),
* which is the complete documented protocol, and it appears nowhere in this
* server's own source outside of unrelated C preprocessor macros. Macro books,
* their contents, and the book/set you are currently looking at all live in the
* client, in `<PlayOnline>/SquareEnix/FINAL FANTASY XI/USER/<charid-in-hex>/`,
* as `mcr.dat` and `mcr<book><set>.dat`.
*
* Losing the selection on a zone line is a retail client bug -- it was reported
* on Square Enix's own bug forum with exactly the symptom seen here, "macro
* books reset to Book 1, Page 1 when zoning, accept the change back, and reset
* again on the next zone". There is nothing on the server to fix. The only
* place the behaviour can be corrected is in the client, which is what this is.
*
* HOW IT KNOWS WHERE YOU WERE.
*
* Ashita ships `libs/ffxi/macros.lua`, which locates the client's
* `FsMacroContainer` and its `setBook` / `setPage` methods by signature scan.
* Two things are read out of that:
*
*   - The current book. `FsMacroContainer::setBook` opens by comparing its
*     argument against the container's book field, so the field's offset is an
*     immediate inside the very signature Ashita matched. It is read out of the
*     matched bytes rather than hardcoded, which means it cannot drift out of
*     step with the library: if the signature stops matching, the library fails
*     first and this addon reports itself inert.
*
*   - The current set. There is no such shortcut -- `setPage` does not expose
*     the field as an immediate, and Ashita's SDK headers describe no layout for
*     the container -- so the offset is measured instead of guessed. Once per
*     arming the container is snapshotted, the page is driven to four known
*     values, and every byte that counted along with it is a candidate. A fifth
*     value that took no part in choosing the candidates is then used to confirm
*     them, and the original set is put back, so the palette ends where it
*     started. If nothing survives, the addon says so and stays out of the way.
*
* WHAT THE MEASUREMENT ASSUMES, AND WHAT IT DELIBERATELY DOES NOT.
*
* It does not assume a width. The set is small enough to fit in a byte whatever
* the client declares the field as, and on a little-endian machine the low byte
* of a dword field is the field for values this size, so the scan walks bytes.
* An earlier version walked 4-byte-aligned dwords and so could only ever see a
* field that was both dword-wide and dword-aligned.
*
* It does not assume an encoding. The client's `setPage` takes a row index --
* a "set" on screen is two rows of ten macros, Ctrl and Alt, so set 3 is 4 --
* and Ashita's `set_page` doubles for you. Whether the container then stores
* that doubled row or the plain set number is not documented anywhere, so both
* are tried and whichever one actually counted is remembered. Everything above
* the read is in plain set numbers, 0-9.
*
* It does not treat more than one answer as no answer. The offset is only ever
* READ; the measurement's probes drive the client's own `setPage`, and the
* restore queues the client's own `/macro` commands -- the field is never
* written. So a second byte that tracks the set just as faithfully is not a
* hazard to be refused, it is a second correct answer, and the one nearest the
* book field is taken.
*
* WHY THE RESTORE NEVER ASKS FIRST.
*
* The field above is a fine way to learn what the player chose. It is a useless
* way to learn what the client is showing them, and 1.1 confused the two: it
* read the palette on the way in, found it already agreed with what it
* remembered, and stood down having done nothing -- every zone line, for every
* player. The field keeps the old selection across a zone line while the macro
* bar drops to Book 1, Set 1, so "already correct" was exactly the reading taken
* when the player was sitting on the wrong set.
*
* So the restore is unconditional. It does not ask whether it is needed, it does
* not require the palette to read at all, and it does not even require the set
* field to have been measured -- what to put back comes from the settings file,
* not from a read. What the read is still good for is saying afterwards what
* happened, which is what `/dwmacro debug` prints.
*
* HOW THE RESTORE MOVES THE BAR, AND WHY 1.3 CHANGED THE MECHANISM.
*
* 1.2 restored by calling `FsMacroContainer::setBook` / `setPage` directly. The
* field followed -- the addon could read its own write back -- but whether the
* macro bar the player is looking at followed was the one claim no offline
* harness could test, and the field answered it on 2026-08-07: zone after zone,
* the player still sat on Book 1, Set 1. A direct call into the container moves
* the state this addon can see and, evidently, not the state the player can.
*
* So the restore now speaks to the client the way the player does: it queues
* the client's own `/macro book <n>` and `/macro set <n>` text commands. That
* path is the one mechanism with retail-proven effect on the visible bar -- it
* is exactly what a player types to put themselves back, and what job-change
* macros have driven for years. It also fails LOUDLY instead of silently: a
* text command the client is handed before it is ready to take input comes
* back as "A command error occurred." in the log, so a restore that ran too
* early is a fact on the record rather than a guess. The addon watches for
* that bounce within a couple of seconds of its own send, swallows the line
* (it is this addon's noise, not the player's), notes it for `/dwmacro debug`,
* and lets a later pass answer it -- the passes were always retries.
*
* Each of the book and the set still goes through a neighbouring value first,
* because the command lands in the same `setBook` that returns immediately when
* asked for the book the field already claims to hold (see the disassembly at
* applyPalette), and after a zone line that field claims to hold the right
* book while the bar shows Book 1. A no-op is not a restore. The two extra
* transitions are only ever visible if the player is holding Ctrl or Alt
* inside the restore window, and cost nothing otherwise.
*
* THE SELECTION IS REMEMBERED PER JOB, not per character. That is the way the
* game already thinks about macro books -- changing job switches your book --
* so keying on the job is what stops the two features fighting: come back as
* BLM and you are put on the book and set you last used as BLM, not on whatever
* WAR was looking at. Per-character separation is free; Ashita's settings
* library already files everything under `<charname>_<serverid>`.
*
* TURN IT OFF AND NOTHING IS LOST. `/macro book <n>` and `/macro set <n>` work
* exactly as they always did. This addon only ever puts back a book and set the
* player had already chosen for that job on that character; it never invents
* one, and with no remembered entry it does nothing at all.
--]]

addon.name    = 'dwmacro';
addon.author  = 'DriftwoodXI';
addon.version = '1.3';
addon.desc    = 'Remembers your macro book and set across zoning and logging back in.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local settings = require('settings');

--[[
* The macro library is a signature scan over the client and it raises rather
* than returning nil when a scan misses. A client build it does not know must
* leave the player with a working game and one line of explanation, not an
* addon that failed to load, so it is required defensively and every use of it
* is behind `macrolib ~= nil`.
--]]
local macrolib = nil;

do
    local ok, lib = pcall(require, 'ffxi.macros');

    if (ok and type(lib) == 'table') then
        macrolib = lib;
    end
end

--[[
* Where the book field lives inside the macro container.
*
* `FsMacroContainer::setBook` begins:
*
*     8B 44 24 04        mov  eax, [esp+4]        ; the requested book
*     56                 push esi
*     8B F1              mov  esi, ecx            ; this
*     8B 8E C0 1D 00 00  mov  ecx, [esi+1DC0h]    ; the current book
*     3B C8              cmp  ecx, eax
*
* so the offset is the four bytes at +9 from the address Ashita matched. Taking
* it from there rather than writing 0x1DC0 down means this and the library can
* only ever agree: they are reading the same matched bytes.
--]]
local BOOK_OFFSET_IMM = 9;

-- A sanity range for that offset. The macro records themselves occupy the
-- first ~7.6KB of the container, so a plausible book offset is a little past
-- that and nowhere near zero. Anything outside this is a bad match, not a
-- client we do not know about, and is refused.
local BOOK_OFFSET_MIN = 0x1000;
local BOOK_OFFSET_MAX = 0x4000;

--[[
* How far past the book field to look when measuring the set field.
*
* Everything below the book field is macro record data the client is known to
* have allocated, so scanning down to zero costs nothing but time. Above it is
* the only speculative part, and it is speculative in the way that matters --
* reading past the end of the allocation is a crash, not a failed measurement.
* A quarter of a kilobyte past the last member anyone has ever named is a long
* way for a sibling field and a short way into a heap block this size.
--]]
local SCAN_PAST_BOOK = 0x100;

--[[
* The sets the measurement drives through, as set numbers 0-9.
*
* Four values, so that a byte which merely happens to be 1 when the set is 1 is
* gone by the second probe, and chosen so the two candidate encodings can never
* be confused: as rows these are 2, 18, 8, 0 and as plain sets 1, 9, 4, 0, which
* differ everywhere they can. The list ends on set 1 because that is where the
* client has just put the player when this runs, so a measurement that fails
* outright leaves the palette exactly where the client left it.
*
* CONFIRM_SET took no part in choosing the candidates, which is the point of it:
* a byte that survived four probes and then also predicted a fifth is the set.
--]]
local PROBE_SETS  = T{ 1, 9, 4, 0 };
local CONFIRM_SET = 6;

local MAX_SET  = 9;
local MAX_BOOK = 39;

--[[
* The two ways the container could plausibly hold the selection: the row index
* the client's `setPage` is handed, or the set number behind it. Which one it
* actually is gets decided by the measurement rather than by assumption.
--]]
local ENCODINGS = T{
    T{
        name   = 'row',
        encode = function (set) return set * 2; end,
        decode = function (raw)
            if (raw % 2 ~= 0) then
                return nil;
            end

            return math.floor(raw / 2);
        end,
    },
    T{
        name   = 'set',
        encode = function (set) return set; end,
        decode = function (raw) return raw; end,
    },
};

--[[
* When the palette is put back after a zone line, counted in seconds from the
* first frame the player is actually in the world -- and "in the world" means
* the client's own zoning flag has cleared, not merely that a party slot has
* filled in. That distinction is where 1.2's schedule died: login status and
* the party list go live while the load screen is still up, so passes clocked
* from there (1.2 used 1, 3 and 6 seconds) could all fire before the client
* had finished rebuilding its macro state, and the rebuild then threw every
* one of them away. The proof is in the log the player was already looking
* at: a typed line handed to the client ~6 seconds after the area line still
* bounced with "A command error occurred." -- the client was not taking input
* yet, at a moment 1.2 believed its work was long done.
*
* THE RESTORE IS NEVER GATED ON A READ, and that is the whole of the 1.1 bug.
* 1.1 read the palette first and stood down when it already agreed with what it
* remembered -- which it always did, because the field the addon reads keeps the
* old selection across a zone line while the macro bar the player is looking at
* drops to Book 1, Set 1. The addon saw "already correct", did nothing, and the
* player sat on Set 1: the exact symptom it exists to fix. A read of the field
* the restore itself writes can confirm the write landed; it can never confirm
* what the client is showing, so it is not allowed to decide whether to write.
*
* More than one pass because the client rebuilds its macro state some time
* after it stops calling itself "zoning" and the exact moment is not ours to
* know -- a restore that arrives first is simply overwritten by it, and one the
* client bounces (see the text_in watcher) never landed at all. Three passes
* over twelve seconds straddle every rebuild anyone has observed; a player who
* picks a set inside that window is put back at most twice and can simply pick
* again, which is a far smaller cost than a feature that does not work at all.
--]]
local RESTORE_PASSES = T{ 2.0, 6.0, 12.0 };

--[[
* How long after a zone line the palette stops being read as a choice.
*
* Everything in the settling window -- the client's own reset, and every pass
* above -- is the client and this addon moving the palette, not the player. It
* must never be recorded: remembering the client's post-zone default is how a
* restore that missed turns into "puts me on Set 1 for ever". Must be past the
* last pass, with room for it to land.
--]]
local RECORD_HOLD = 15.0;

--[[
* How long after a restore pass a "command error" line in the chat log is taken
* to be that pass bouncing off a client that was not ready, rather than the
* player's own typing going wrong. Inside this window the line is swallowed --
* it is this addon's plumbing -- and counted, so `/dwmacro debug` can say the
* pass was rejected instead of leaving "ran and changed nothing" and "never
* landed" looking identical. Generous next to the one frame the client takes
* to answer, short enough that the player's own errors stay their own.
--]]
local BOUNCE_WINDOW = 2.5;

-- How often the palette is read while playing. Often enough that a set chosen
-- and then immediately zoned away from is caught, rare enough to be free.
local POLL_INTERVAL = 0.5;

-- And how many of those polls in a row have to agree before a new selection is
-- believed. A single read that disagrees with the one beside it is the palette
-- mid-move, not a decision; two costs half a second of lag and cannot be one.
local RECORD_AGREE = 2;

--[[
* Measuring needs a macro container the client has actually finished filling in.
* `inGame()` goes true the moment the player has a party slot, which on a slow
* login -- a server still loading, a zone still streaming in -- is earlier than
* the palette being ready. Probing then drives sets that do not take, no byte
* counts along, and the measurement comes back empty.
*
* So a failure is never final on the strength of one login. MEASURE_RETRIES is
* the budget for a single arming: spend it and the addon goes quiet until the
* next zone line, which re-arms it with a fresh budget and a client that has
* just rebuilt its macro state. Only MEASURE_MAX_ATTEMPTS, across the whole
* session, ends it for good -- because a client that genuinely cannot be read
* should say so once rather than probe the palette for ever.
*
* The earlier build spent a single four-attempt budget in the first fourteen
* seconds of the session and never took another, so one unlucky login meant
* "macro sets will not be remembered" until the game was restarted.
--]]
local MEASURE_SETTLE         = 2.0;
local MEASURE_RETRIES        = 4;
local MEASURE_RETRY_INTERVAL = 3.0;
local MEASURE_MAX_ATTEMPTS   = 24;

local default_settings = T{
    -- Restoring can be turned off without unloading the addon; the palette is
    -- still remembered while it is off, so turning it back on picks up where
    -- it left off.
    enabled = true,

    -- Keyed by main job id. Each entry is { book = <0-39>, set = <0-9> }, in
    -- the numbering the macro menu shows minus one.
    jobs    = T{ },
};

local config = settings.load(default_settings);

--[[
* Builds before 1.1 stored the client's doubled row value under `page`. Nothing
* is thrown away for it: the row halves cleanly into the set it always meant.
--]]
do
    if (type(config.jobs) == 'table') then
        for _, entry in pairs(config.jobs) do
            if (type(entry) == 'table' and entry.set == nil and type(entry.page) == 'number') then
                entry.set  = math.floor(entry.page / 2);
                entry.page = nil;
            end
        end
    end
end

local state = T{
    -- What was measured. `bookOffset` is an offset; `page` is a table of
    -- { offset = <byte offset>, enc = <encoding> } and is nil until proven.
    bookOffset = nil,
    page       = nil,

    -- Measurement bookkeeping. `attempts` is the budget for the current arming
    -- and `total` is the session ceiling; `gaveUp` is set only once the ceiling
    -- is reached, and is what makes the failure final and worth saying aloud.
    attempts   = 0,
    total      = 0,
    nextTry    = 0,
    gaveUp     = false,

    -- What the last measurement saw, for `/dwmacro debug`. "Nothing happens" has
    -- several causes and they are not distinguishable from the outside.
    scan       = nil,

    -- Restore bookkeeping. `armed` is set by the zone-in packet and cleared when
    -- the settling window closes; while it is up nothing read from the palette
    -- is recorded, because immediately after a zone the client is sitting on its
    -- own Book 1 / Set 1 default and writing that over the player's real choice
    -- is the one bug this addon must not have.
    armed      = false,
    zonedAt    = 0,
    pass       = 0,

    -- What the last zone line actually did, for `/dwmacro debug`. A restore that
    -- runs and does not show up on screen and a restore that never ran look the
    -- same to the player and want completely different answers.
    trail      = nil,

    -- When the last restore pass queued its commands, and how many of them the
    -- client has bounced this zone. `sentAt` arms the text_in watcher; a
    -- "command error" line inside BOUNCE_WINDOW of it is ours, not the player's.
    sentAt     = nil,
    bounced    = 0,

    -- The previous poll's reading, for the agreement rule.
    lastSeen   = nil,
    agreed     = 0,

    lastPoll   = 0,
};

settings.register('settings', 'dwmacro_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end

    settings.save();
end);

--[[
* Whether the player is actually in the world -- past character select, past
* the zone screen, with a party slot of their own, and NOT mid-zone. Every
* read and write below is gated on this; the macro container exists before
* this is true and holds nothing worth reading.
*
* The zoning check is load-bearing and is what 1.2 lacked: login status and
* the party slot both go live while the load screen is still up, so a clock
* started on them alone starts several seconds early -- early enough that
* every restore pass could land before the client rebuilt its macro state,
* and be erased by the rebuild. `GetIsZoning() == 0` is the same signal the
* stock timers and statustimers addons gate on for "the world is real now".
--]]
local function inGame()
    local player = AshitaCore:GetMemoryManager():GetPlayer();

    if (player == nil or player:GetLoginStatus() ~= 2) then
        return false;
    end

    if (player:GetIsZoning() ~= 0) then
        return false;
    end

    local party = AshitaCore:GetMemoryManager():GetParty();

    if (party == nil or party:GetMemberIsActive(0) == 0) then
        return false;
    end

    return true;
end

local function mainJob()
    local player = AshitaCore:GetMemoryManager():GetPlayer();

    if (player == nil) then
        return 0;
    end

    return player:GetMainJob();
end

--[[
* The live macro container, or 0. This is re-read every time rather than cached
* because it is a pointer through two indirections and the object behind it does
* not survive a zone.
--]]
local function container()
    if (macrolib == nil) then
        return 0;
    end

    local ok, obj = pcall(macrolib.get_fsmacro);

    if (not ok or type(obj) ~= 'number') then
        return 0;
    end

    return obj;
end

--[[
* The book field's offset, taken out of the bytes Ashita matched for setBook.
--]]
local function findBookOffset()
    if (macrolib == nil or macrolib.ptrs == nil) then
        return nil;
    end

    local ptr = macrolib.ptrs.set_book;

    if (ptr == nil or ptr == 0) then
        return nil;
    end

    local ok, offset = pcall(ashita.memory.read_uint32, ptr + BOOK_OFFSET_IMM);

    if (not ok or type(offset) ~= 'number') then
        return nil;
    end

    if (offset < BOOK_OFFSET_MIN or offset > BOOK_OFFSET_MAX or offset % 4 ~= 0) then
        return nil;
    end

    return offset;
end

--[[
* The probing half of the measurement. Kept separate from the restore so that
* the restore can be guaranteed: this is allowed to fail in the middle, and the
* caller still puts the player's set back.
*
* The first probe is the expensive one -- a whole snapshot of the container,
* compared byte for byte -- and it is the only one, because the handful of bytes
* that survive it are then read individually. Every later probe costs a few
* reads rather than eight thousand.
--]]
local function probePageField(obj, bookOffset, before)
    local size = bookOffset + SCAN_PAST_BOOK;

    -- Probe one, from the full snapshot.
    macrolib.set_page(PROBE_SETS[1]);

    local first = ashita.memory.read_array(obj, size);

    if (type(first) ~= 'table') then
        return nil;
    end

    local candidates = { };

    for offset = 0, size - 1 do
        local value = first[offset + 1];

        if (value == nil) then
            break;
        end

        -- The book field is known, and is not the set field.
        if (offset < bookOffset or offset > bookOffset + 3) then
            for index = 1, #ENCODINGS do
                if (value == ENCODINGS[index].encode(PROBE_SETS[1])) then
                    candidates[#candidates + 1] = { offset = offset, enc = ENCODINGS[index] };
                end
            end
        end
    end

    local seeded = #candidates;

    -- The remaining probes, plus the confirming one. A candidate has to predict
    -- every single one of them.
    local rounds = T{ };

    for index = 2, #PROBE_SETS do
        rounds:append(PROBE_SETS[index]);
    end

    rounds:append(CONFIRM_SET);

    for index = 1, #rounds do
        if (#candidates == 0) then
            break;
        end

        macrolib.set_page(rounds[index]);

        local survivors = { };

        for entry = 1, #candidates do
            local candidate = candidates[entry];
            local ok, value = pcall(ashita.memory.read_uint8, obj + candidate.offset);

            if (ok and value == candidate.enc.encode(rounds[index])) then
                survivors[#survivors + 1] = candidate;
            end
        end

        candidates = survivors;
    end

    --[[
    * Nearest the book field wins. Several survivors is not ambiguity to be
    * refused -- all of them track the set, and the offset is only ever read --
    * but the choice still has to be the same one every session, so it is made
    * on distance and then on offset and encoding to break any remaining tie.
    --]]
    table.sort(candidates, function (a, b)
        local da = math.abs(a.offset - bookOffset);
        local db = math.abs(b.offset - bookOffset);

        if (da ~= db) then
            return da < db;
        end

        if (a.offset ~= b.offset) then
            return a.offset < b.offset;
        end

        return a.enc.name < b.enc.name;
    end);

    return {
        seeded    = seeded,
        survivors = #candidates,
        chosen    = candidates[1],
        before    = before,
    };
end

--[[
* Measure the set field, and put the player back on the set they were on.
*
* The restore runs whether the probing succeeded, failed, or raised: the probe
* moves the palette, and a probe that dies halfway through must not leave the
* player looking at somebody else's macros. Where the original set is unknown --
* nothing was found, so there is no byte to read it back out of -- set 1 is the
* honest fallback, and is where the last probe already left things.
--]]
local function measurePageField(obj, bookOffset)
    local before = ashita.memory.read_array(obj, bookOffset + SCAN_PAST_BOOK);

    if (type(before) ~= 'table') then
        return nil;
    end

    local ok, result = pcall(probePageField, obj, bookOffset, before);

    local restore = nil;

    if (ok and type(result) == 'table' and result.chosen ~= nil) then
        local original = before[result.chosen.offset + 1];

        if (type(original) == 'number') then
            local decoded = result.chosen.enc.decode(original);

            if (decoded ~= nil and decoded >= 0 and decoded <= MAX_SET) then
                restore = decoded;
            end
        end
    end

    --[[
    * The snapshot taken before any probing is the honest answer, but it can only
    * be decoded through a candidate that survived -- so when nothing survived
    * there is no byte to read the original out of. Falling straight to set 0
    * there is what made a failed measurement indistinguishable from the bug this
    * addon exists to fix: it put the player on Set 1 and left them there. What
    * this job was last seen on is the player's own choice rather than the
    * client's default, so it is asked first, and 0 is only the answer when there
    * is nothing remembered at all -- which is also where the client has just put
    * them.
    --]]
    if (restore == nil) then
        local job       = mainJob();
        local remembered = (job ~= 0) and config.jobs[job] or nil;

        if (remembered ~= nil and type(remembered.set) == 'number'
            and remembered.set >= 0 and remembered.set <= MAX_SET) then
            restore = remembered.set;
        else
            restore = 0;
        end
    end

    pcall(macrolib.set_page, restore);

    if (not ok) then
        error(result, 0);
    end

    return result;
end

--[[
* Read the palette. Returns nil unless the measurement is done, the container is
* live, and both values are ones the client could actually be holding -- a set
* outside 0-9 means the offset is wrong and the read is thrown away rather than
* remembered.
--]]
local function readPalette()
    if (state.bookOffset == nil or state.page == nil) then
        return nil;
    end

    local obj = container();

    if (obj == 0) then
        return nil;
    end

    local ok, book = pcall(ashita.memory.read_uint32, obj + state.bookOffset);

    if (not ok or type(book) ~= 'number' or book < 0 or book > MAX_BOOK) then
        return nil;
    end

    local okRaw, raw = pcall(ashita.memory.read_uint8, obj + state.page.offset);

    if (not okRaw or type(raw) ~= 'number') then
        return nil;
    end

    local set = state.page.enc.decode(raw);

    if (set == nil or set < 0 or set > MAX_SET) then
        return nil;
    end

    return { book = book, set = set };
end

--[[
* Put the palette back, by queueing the client's own text commands -- the same
* `/macro book` and `/macro set` a player would type, which is the one path
* with retail-proven effect on the bar the player is actually looking at (1.2
* called `FsMacroContainer::setBook` directly; the field followed, the bar did
* not -- see the header). The book goes first and the set second, and that
* order is not cosmetic: the client resets the set whenever the book actually
* changes, so a set restored first would be thrown away by the book change.
*
* EACH ONE IS SET TWICE, through a neighbouring value and then to the value that
* is wanted, and that is the fix rather than a flourish. The command lands in
* `FsMacroContainer::setBook`, which opens by comparing its argument against
* the book it has stored and returning if they are equal --
*
*     8B 44 24 04        mov  eax, [esp+4]        ; the requested book
*     56                 push esi
*     8B F1              mov  esi, ecx            ; this
*     8B 8E C0 1D 00 00  mov  ecx, [esi+1DC0h]    ; the current book
*     3B C8              cmp  ecx, eax
*     75 ??              jne  short               ; ... only then does the work
*     8B C1              mov  eax, ecx
*     5E                 pop  esi
*     C2 04 00           ret  4
*
* -- so asking for the book the field already claims to hold is not a restore,
* it is a no-op, and after a zone line that field claims to hold the book the
* player was on while the macro bar shows Book 1. A transition the client has
* to make cannot be skipped. The extra hop is only ever drawn if the player is
* holding Ctrl or Alt inside the restore window.
*
* The four sends are written out rather than folded into a loop: read as four
* lines it is obvious what happens if one of them is ever removed.
*
* The commands carry the menu's 1-based numbering, because that is what the
* client's command parser takes; everything else in this addon is 0-based.
* Nothing here ever writes the fields the measurement found; those are
* read-only to this addon, and nothing here reaches the server -- a slash
* command is client-local and produces no chat line, so there is no echo to
* swallow and dwecho stays unnecessary.
--]]
local function applyPalette(palette)
    if (palette == nil) then
        return false;
    end

    if (palette.book < 0 or palette.book > MAX_BOOK or palette.set < 0 or palette.set > MAX_SET) then
        return false;
    end

    local mgr = AshitaCore:GetChatManager();

    if (mgr == nil) then
        return false;
    end

    local otherBook = (palette.book + 1) % (MAX_BOOK + 1);
    local otherSet  = (palette.set  + 1) % (MAX_SET  + 1);

    local ok = pcall(function ()
        mgr:QueueCommand(1, ('/macro book %d'):fmt(otherBook + 1));
        mgr:QueueCommand(1, ('/macro book %d'):fmt(palette.book + 1));
        mgr:QueueCommand(1, ('/macro set %d'):fmt(otherSet + 1));
        mgr:QueueCommand(1, ('/macro set %d'):fmt(palette.set + 1));
    end);

    return ok;
end

--[[
* Human-facing numbering. The client counts books and sets from zero; the macro
* menu counts them from one.
--]]
local function describe(palette)
    if (palette == nil) then
        return 'nothing yet';
    end

    return ('book %d, set %d'):fmt(palette.book + 1, palette.set + 1);
end

--[[
* Measure the palette, spending one budget of attempts per arming and conceding
* only once the session ceiling is reached. Once the measurement is done this is
* a single comparison per frame; once it has given up it is the same.
--]]
local function ensureMeasured()
    if (state.gaveUp or (state.bookOffset ~= nil and state.page ~= nil)) then
        return;
    end

    -- This arming's budget is spent. Wait for the next zone line, which re-arms
    -- with a client that has just rebuilt its macro state.
    if (state.attempts >= MEASURE_RETRIES) then
        return;
    end

    local now = os.clock();

    -- Let the client finish building the palette before touching it, and space
    -- the retries out rather than re-probing every frame.
    if (state.nextTry == 0) then
        state.nextTry = now + MEASURE_SETTLE;
        return;
    end

    if (now < state.nextTry) then
        return;
    end

    -- No container yet is not an attempt, but it must still cost a wait, or a
    -- client that is slow to build one is probed sixty times a second.
    local obj = container();

    if (obj == 0) then
        state.nextTry = now + MEASURE_RETRY_INTERVAL;
        return;
    end

    state.attempts = state.attempts + 1;
    state.total    = state.total + 1;
    state.nextTry  = now + MEASURE_RETRY_INTERVAL;

    -- Whether there is anything left to try after this, ever. Everything below
    -- reports a failure only then; otherwise it goes quiet and waits.
    local final = state.total >= MEASURE_MAX_ATTEMPTS;

    -- Note that this does not throw the book offset away. Nothing keys off it
    -- alone -- every gate below wants both halves -- and keeping it is what lets
    -- `/dwmacro debug` distinguish "the book field was never found" from "the
    -- book field was found and the set field was not", which are the same
    -- silence from the outside and want completely different answers.
    local function giveUp(message)
        state.page = nil;

        if (final) then
            state.gaveUp = true;
            print(chat.header(addon.name):append(chat.error(message)));
            print(chat.header(addon.name):append(chat.message('Your macro palette is untouched; /macro book and /macro set work as normal.')));
        end
    end

    state.bookOffset = findBookOffset();

    if (state.bookOffset == nil) then
        state.scan = { error = 'no book field' };

        giveUp('Could not locate the macro book field in this client. Macro sets will not be remembered.');
        return;
    end

    local ok, result = pcall(measurePageField, obj, state.bookOffset);

    if (not ok or type(result) ~= 'table') then
        state.scan = { error = tostring(result) };

        giveUp('Could not read this client\'s macro palette. Macro sets will not be remembered.');
        return;
    end

    state.scan = { seeded = result.seeded, survivors = result.survivors, chosen = result.chosen };

    if (result.chosen == nil) then
        giveUp('Could not identify the macro set field in this client. Macro sets will not be remembered.');
        return;
    end

    state.page = result.chosen;
end

--[[
* Forget what the last few polls saw. Called whenever the palette is about to be
* moved by something that is not the player -- a zone line, a restore pass -- so
* that the reading taken before it can never be half of an agreeing pair with
* the one taken after.
--]]
local function forgetSeen()
    state.lastSeen = nil;
    state.agreed   = 0;
end

--[[
* Record the palette against the job currently being played.
*
* A selection has to read the same RECORD_AGREE polls running before it is
* written down. The palette is moved by the client and by this addon as well as
* by the player, and a single reading taken while it is in motion is not a
* choice; the settling window keeps the worst of that out (see `tick`) and this
* is the cheap guard against everything else.
--]]
local function record()
    local job = mainJob();

    if (job == 0) then
        forgetSeen();
        return;
    end

    local palette = readPalette();

    if (palette == nil) then
        forgetSeen();
        return;
    end

    local seen = state.lastSeen;

    if (seen ~= nil and seen.job == job and seen.book == palette.book and seen.set == palette.set) then
        state.agreed = state.agreed + 1;
    else
        state.agreed = 1;
    end

    state.lastSeen = { job = job, book = palette.book, set = palette.set };

    if (state.agreed < RECORD_AGREE) then
        return;
    end

    local known = config.jobs[job];

    if (known ~= nil and known.book == palette.book and known.set == palette.set) then
        return;
    end

    config.jobs[job] = T{ book = palette.book, set = palette.set };

    settings.save();
end

--[[
* Arm a restore. Called for the login packet, which the server sends both on a
* real login and on every zone line -- the two cases this addon exists for are
* the same packet.
*
* The clock starts when the player is next seen in the world, not here: the
* packet arrives while the zone screen is still up, and the delay that matters
* is the one after the client has finished rebuilding.
--]]
local function armRestore()
    state.armed   = true;
    state.zonedAt = 0;
    state.pass    = 0;
    state.trail   = nil;
    state.sentAt  = nil;
    state.bounced = 0;

    forgetSeen();

    -- A zone line rebuilds the client's macro state, so if the palette still has
    -- not been measured this is a fresh chance at it -- and a better one than the
    -- frame that just failed. A fresh budget with it: the failure that matters is
    -- a client that cannot be read at all, not a login that was busy.
    if (not state.gaveUp and (state.bookOffset == nil or state.page == nil)) then
        state.attempts = 0;
        state.nextTry  = 0;
    end
end

--[[
* One restore pass: put the player back on the book and set this job was last
* seen on, whatever the palette currently claims.
*
* Nothing here asks permission from a read. The reading is taken and kept, but
* only so `/dwmacro debug` can say what the pass walked into -- it decides
* nothing, because the field it comes from is the same one the restore moves
* and it agrees with a stale selection just as readily as with a live one.
* The "after" reading is NOT taken here: the commands this queues have not
* run yet on this frame, so a read now would only ever show "before" again.
* It is taken when the settling window closes, once every pass has landed.
--]]
local function restorePass()
    local job = mainJob();

    if (job == 0) then
        return;
    end

    local wanted = config.jobs[job];

    -- Nothing remembered for this job is not a failure, it is the first time
    -- this job has been played. Leave the palette completely alone and let the
    -- poller learn it once the window closes.
    if (wanted == nil or wanted.book == nil or wanted.set == nil) then
        state.trail = { pass = state.pass, job = job, skipped = 'nothing remembered for this job' };
        return;
    end

    local before = (state.trail ~= nil and state.trail.before) or readPalette();

    -- The watcher and the trail are armed BEFORE the send: the client answers
    -- a rejected command on its own schedule, and an answer that arrives
    -- before the bookkeeping exists would be neither swallowed nor counted.
    state.sentAt = os.clock();

    state.trail = {
        pass   = state.pass,
        job    = job,
        wanted = wanted,
        before = before,
    };

    state.trail.ok = applyPalette(wanted);

    -- The palette has just been moved by this addon, so nothing read across it
    -- is a choice the player made.
    forgetSeen();
end

--[[
* Run whatever the settling window owes at this moment, and say whether it is
* still open. While it is, recording is off (see `tick`).
*
* `apply` is the enabled flag, and it silences the passes WITHOUT shortening the
* window. Turning restoring off does not stop the client resetting the palette
* on a zone line, and this addon's promise while it is off is that the palette
* is still remembered so that turning it back on picks up where it left off --
* which it would not, if the first thing recorded after every zone were the
* client's own Book 1, Set 1.
--]]
local function restoreWindow(now, apply)
    local since = now - state.zonedAt;

    if (since >= RECORD_HOLD) then
        return false;
    end

    -- One pass per frame at most: two restores inside a single frame would be
    -- the second one undoing nothing and costing four more calls into the
    -- client for it.
    if (apply and state.pass < #RESTORE_PASSES and since >= RESTORE_PASSES[state.pass + 1]) then
        state.pass = state.pass + 1;
        restorePass();
    end

    return true;
end

local function tick()
    -- Out of the world -- a zone screen, character select -- the palette is not
    -- the player's and the readings either side of the gap are not a pair.
    if (not inGame()) then
        forgetSeen();
        return;
    end

    ensureMeasured();

    local now = os.clock();

    --[[
    * The restore runs whether or not the measurement has succeeded -- that
    * ordering is deliberate and was 1.2's third bug. What to put back comes
    * from the settings file and goes out as text commands; neither needs an
    * offset. Gating the restore on the measurement meant a client whose set
    * field could not be found lost the book restore too, which needs nothing
    * measured at all, and lost it silently.
    --]]
    if (state.armed) then
        -- The clock starts on the first frame the player is actually in the
        -- world -- inGame() now includes the client's own zoning flag, so
        -- "in the world" is the client's word for it, not the party list's.
        if (state.zonedAt == 0) then
            state.zonedAt = now;
        end

        -- Recording stays shut off for the whole window, so the client's
        -- post-zone default is never mistaken for a choice -- whether or not
        -- restoring is the thing putting it right.
        if (restoreWindow(now, config.enabled)) then
            return;
        end

        state.armed = false;

        -- Every pass has landed (or bounced); what the field says now is the
        -- honest "after" for `/dwmacro debug`.
        if (state.trail ~= nil and state.trail.skipped == nil) then
            state.trail.after = readPalette();
        end
    end

    -- Recording, unlike restoring, has nothing without the measurement: it
    -- exists to READ what the player picked.
    if (state.bookOffset == nil or state.page == nil) then
        return;
    end

    if (now - state.lastPoll < POLL_INTERVAL) then
        return;
    end

    state.lastPoll = now;

    record();
end

--[[
* Everything above runs once a frame, which is the reason for the pcall: an
* error raised inside `d3d_present` is raised sixty times a second, and the
* addon host answers a long enough run of them by unloading the addon. One bad
* frame costs one line of chat and the feature, not the addon -- and the
* feature going quiet leaves a completely normal macro palette behind.
--]]
local failed = false;

ashita.events.register('d3d_present', 'dwmacro_present', function ()
    if (macrolib == nil or failed) then
        return;
    end

    local ok, err = pcall(tick);

    if (not ok) then
        failed = true;

        print(chat.header(addon.name):append(chat.error('Stopped after an error: ' .. tostring(err))));
        print(chat.header(addon.name):append(chat.message('Your macro palette is untouched; /macro book and /macro set work as normal.')));
    end
end);

--[[
* The login packet. The client's macro state does not survive it, and it is
* sent for a zone line as well as a login, so this one hook covers both cases.
--]]
ashita.events.register('packet_in', 'dwmacro_zonein', function (e)
    if (e.id == 0x000A) then
        armRestore();
    end
end);

--[[
* The bounce watcher. A `/macro` command handed to a client that is not ready
* to take input comes back as one "A command error occurred." line per
* command, and nothing happens -- the restore never landed. Inside a short
* window after this addon's own send, that line is this addon's plumbing: it
* is swallowed so the player stops seeing unexplained errors on every zone,
* and counted so `/dwmacro debug` can tell a rejected pass from one that ran.
* No control flow hangs off it -- the later passes were always the retry.
*
* Outside the window the handler is one nil-check deep and touches nothing:
* the player's own command errors remain the player's.
--]]
ashita.events.register('text_in', 'dwmacro_text_in', function (e)
    if (state.sentAt == nil or e.blocked) then
        return;
    end

    if (os.clock() - state.sentAt > BOUNCE_WINDOW) then
        state.sentAt = nil;
        return;
    end

    local line = e.message;

    if (type(line) ~= 'string') then
        return;
    end

    if (line:find('command error', 1, true) ~= nil) then
        e.blocked     = true;
        state.bounced = state.bounced + 1;

        if (state.trail ~= nil) then
            state.trail.bounced = (state.trail.bounced or 0) + 1;
        end
    end
end);

--[[
* What the measurement saw. This exists because every way this addon can fail
* quietly looks identical from the outside -- no set field found, several found
* and none confirmed, the container never readable -- and they want different
* answers.
--]]
local function printDebug()
    print(chat.header(addon.name):append(chat.message(('macros lib: %s   container: 0x%08X'):fmt(macrolib ~= nil and 'loaded' or 'MISSING', container()))));
    print(chat.header(addon.name):append(chat.message(('book offset: %s   attempts: %d this zone, %d of %d this session'):fmt(
        state.bookOffset ~= nil and ('0x%04X'):fmt(state.bookOffset) or 'unknown',
        state.attempts, state.total, MEASURE_MAX_ATTEMPTS))));

    if (state.page ~= nil) then
        local obj = container();
        local raw = 'unreadable';

        if (obj ~= 0) then
            local ok, value = pcall(ashita.memory.read_uint8, obj + state.page.offset);

            if (ok) then
                raw = tostring(value);
            end
        end

        print(chat.header(addon.name):append(chat.message(('set field: 0x%04X (%+d from book), encoding %s, reads %s'):fmt(
            state.page.offset, state.page.offset - state.bookOffset, state.page.enc.name, raw))));
    else
        print(chat.header(addon.name):append(chat.message('set field: not identified')));
    end

    if (state.scan == nil) then
        print(chat.header(addon.name):append(chat.message('last scan: has not run yet')));
    elseif (state.scan.error ~= nil) then
        print(chat.header(addon.name):append(chat.message('last scan: failed -- ' .. state.scan.error)));
    else
        print(chat.header(addon.name):append(chat.message(('last scan: %d candidate(s) seeded, %d confirmed'):fmt(state.scan.seeded or 0, state.scan.survivors or 0))));
    end

    --[[
    * What the last zone line did. A restore that ran and did not show up on
    * screen, a restore that never ran because nothing was remembered, and a
    * zone line the addon never noticed are three different faults that look
    * identical from the player's chair, so all three are named here.
    --]]
    if (state.trail == nil) then
        if (state.armed) then
            print(chat.header(addon.name):append(chat.message('last zone: settling, no pass has run yet')));
        else
            print(chat.header(addon.name):append(chat.message('last zone: no restore pass has run this session')));
        end
    elseif (state.trail.skipped ~= nil) then
        print(chat.header(addon.name):append(chat.message(('last zone: pass %d skipped -- %s'):fmt(state.trail.pass, state.trail.skipped))));
    else
        print(chat.header(addon.name):append(chat.message(('last zone: pass %d put back %s via /macro commands (read %s before, %s after, queueing %s, %d command(s) bounced)'):fmt(
            state.trail.pass,
            describe(state.trail.wanted),
            describe(state.trail.before),
            describe(state.trail.after),
            state.trail.ok and 'ok' or 'FAILED',
            state.bounced))));
        print(chat.header(addon.name):append(chat.message(('%d of %d pass(es) run; the reads are the container field, not the macro bar. A bounce means the client rejected a pass ("A command error occurred") and a later pass retried it.'):fmt(state.pass, #RESTORE_PASSES))));
    end
end

ashita.events.register('command', 'dwmacro_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwmacro' and args[1] ~= '/macro')) then
        return;
    end

    local verb = (#args > 1) and args[2]:lower() or 'status';

    --[[
    * /macro IS A RETAIL CLIENT COMMAND, and this addon's whole contract is
    * that `/macro book <n>` and `/macro set <n>` keep working exactly as they
    * always did (see the header). So the alias only claims the verbs dwmacro
    * itself owns and hands anything else straight back to the client --
    * blocking an unknown verb here would eat a client feature this addon has
    * promised not to touch. `debug` is deliberately not on that list; it is a
    * /dwmacro verb only.
    --]]
    if (args[1] == '/macro' and verb ~= 'status' and verb ~= 'on' and verb ~= 'off' and verb ~= 'forget') then
        return;
    end

    e.blocked = true;

    if (verb == 'on' or verb == 'off') then
        config.enabled = (verb == 'on');
        settings.save();

        print(chat.header(addon.name):append(chat.message('Restoring is now ')):append(chat.success(verb)):append(chat.message('.')));
        return;
    end

    if (verb == 'forget') then
        config.jobs = T{ };
        settings.save();

        print(chat.header(addon.name):append(chat.message('Forgot every remembered macro book and set.')));
        return;
    end

    if (verb == 'debug') then
        printDebug();
        return;
    end

    -- Status. Says what it measured as well as what it remembers, because
    -- "nothing happens" has two causes and they need different answers.
    if (macrolib == nil) then
        print(chat.header(addon.name):append(chat.error("Ashita's macro library did not load; nothing is being remembered.")));
        return;
    end

    if (failed) then
        print(chat.header(addon.name):append(chat.error('Stopped after an error earlier this session; nothing is being remembered. Reload with /addon reload dwmacro.')));
        return;
    end

    if (state.bookOffset == nil or state.page == nil) then
        if (state.gaveUp) then
            print(chat.header(addon.name):append(chat.error('Could not read this client\'s macro palette; nothing is being remembered.')));
            print(chat.header(addon.name):append(chat.message('/dwmacro debug says what it saw.')));
        else
            print(chat.header(addon.name):append(chat.message(('Still reading the macro palette (%d attempt(s) so far). It tries again after each zone line.'):fmt(state.total))));
        end

        return;
    end

    local job     = mainJob();
    local current = readPalette();

    print(chat.header(addon.name):append(chat.message('Restoring is ')):append(chat.success(config.enabled and 'on' or 'off')):append(chat.message('. Currently on ' .. describe(current) .. '.')));

    local remembered = (job ~= 0) and config.jobs[job] or nil;

    if (remembered ~= nil and remembered.book ~= nil and remembered.set ~= nil) then
        print(chat.header(addon.name):append(chat.message('Remembered for this job: ' .. describe(remembered) .. '.')));
    else
        print(chat.header(addon.name):append(chat.message('Nothing remembered for this job yet.')));
    end
end);

ashita.events.register('load', 'dwmacro_load', function ()
    if (macrolib == nil) then
        print(chat.header(addon.name):append(chat.error("Ashita's macro library did not load on this client build; macro sets will not be remembered.")));
        return;
    end

    print(chat.header(addon.name):append(chat.message('Your macro book and set are remembered per job and put back after zoning. /dwmacro (or plain /macro) for status.')));
end);

ashita.events.register('unload', 'dwmacro_unload', function ()
    settings.save();
end);
