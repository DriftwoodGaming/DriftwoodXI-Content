--[[
* DriftwoodXI -- dwquest
*
* The Drift Board in a window: the daily and weekly contracts offered to your
* level band, the ones you have signed with their counters moving as you
* fight, what each pays, how long is left, and your Drift Coins. Accept and
* abandon are buttons. `/quests` opens it from anywhere -- there is no NPC to
* walk to, because the window IS the quest giver.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It ships no pool, no prices, no progress and no arithmetic. Every contract,
* every count, every reward and every countdown arrives as _DWUDATA records
* answering `!dwu hello` (documentation/dwu_protocol.md), and the server
* re-resolves the contract from its own rotation whichever way the command
* arrived. A click issues a line a player could type (`!dwu accept d1`), and
* THE CLIENT NEVER SENDS A QUEST DEFINITION -- it sends a slot name. There is
* no record on this wire that could tell the server what a contract needs,
* pays, or is worth, so a bug in this window cannot mint a coin.
*
* THE ONE NUMBER THAT MOVES LOCALLY IS A CLOCK. The board header and every
* contract carry countdowns that were exact when the server built the record;
* the window ticks them down between syncs and re-asks when the rotation one
* reaches zero (dwu_protocol.md, `y|`). Nothing else here is computed --
* not a price, not a payout, not a progress count.
*
* TYPING `!drift` ON ITS OWN OPENS THIS WINDOW. The line is intercepted before
* it leaves the client; every other !drift command passes through.
*
* TURN IT OFF AND NOTHING IS LOST. `!drift`, `!drift accept d1`,
* `!drift abandon a1`, `!drift balance` all work typed. This is friendlier;
* it is not required.
--]]

addon.name    = 'dwquest';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.0';
addon.desc    = 'The Drift Board for DriftwoodXI -- daily and weekly contracts, live progress, Drift Coins.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. Nine
-- other addons own nine other names; this addon must never contend for any of
-- them, which is why `!dwu` exists at all -- the obvious `!dwq` belongs to
-- alt storage (DWQUEST_PLAN.md F1).
local DATA_SENDER = '_DWUDATA';

-- Bumped only for a breaking change to the record layout.
local PROTOCOL = 1;

--[[
* State.
*
* Everything server-derived is replaced wholesale by a `board` envelope and
* never merged, so a contract that expired between syncs cannot survive as a
* stale card. A `ping` is the deliberate exception: it carries only the rows
* that moved, so it merges (dwu_protocol.md, "The ping").
*
* `actives` and `offerByKey` are PLAIN tables, not T{ }: they are keyed by
* quest keys and slot names, and T{ }'s sugar method names shadow string keys
* -- the collision that cost dwbags a round.
--]]
local state = T{
    open        = T{ false },

    -- The y| header. clockAt is the os.clock() at which the two countdowns
    -- were true, which is the only thing that makes ticking them down honest.
    poolVersion = nil,
    day         = nil,
    band        = nil,
    secsToDay   = nil,
    secsToWeek  = nil,
    clockAt     = nil,
    rollAsked   = false,

    offers      = { },     -- o| records, in wire order
    actives     = { },     -- [qkey] = a| record
    activeOrder = { },     -- qkeys, in the order the server listed them

    balance     = nil,     -- g|; nil means the server did not say

    synced      = false,   -- gates the panel: no cards until the first z|board

    -- True once a d| has arrived this session. Auto-syncs (zone-in) stay off
    -- until then: an unknown !command falls through to /say, and an automatic
    -- line against a dead verb is the player saying it in public.
    serverSpoke = false,

    inbound     = nil,     -- the verb whose envelope is currently open

    status      = 'Loading...',
    statusBad   = false,
    reported    = false,   -- a render error is worth saying once, not per frame

    toast       = nil,
    toastAt     = nil,

    now         = 0,       -- os.clock(), read once per frame (see present)
};

--[[
* Sending: one command per interval, reads deduplicated, WRITES NEVER
* COLLAPSED AND NEVER RETRIED (the dwmerc rule, dwu_protocol.md client
* discipline 4). A lost `accept` that was re-sent could arrive after a
* rotation, which is a contract the player did not click on. Both verbs are
* idempotent server-side; that is not a licence to re-send them.
*
* Writes drain first: an accept stuck behind two queued board reads spends
* three seconds looking broken.
--]]
local SEND_INTERVAL = 1.2;

local readQueue  = { };
local writeQueue = { };
local lastSend   = 0;

local function issueRead(command)
    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

local function issueWrite(command)
    table.insert(writeQueue, command);
end

local function pumpQueue(now)
    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#writeQueue > 0) then
        lastSend = now;
        echo.send(table.remove(writeQueue, 1));

        return;
    end

    if (#readQueue > 0) then
        lastSend = now;
        echo.send(table.remove(readQueue, 1));
    end
end

--[[
* Answer tracking for the board read: ask once, retry once on a 5s silence,
* then stop and say so -- a retry that never terminates is a command loop.
*
* `hello` and `board` are tracked under ONE key because the server answers
* both with a `board` envelope (quest_core.lua's dispatch): keying on the verb
* we sent would leave a `hello` waiting forever for a `z|hello` that the
* protocol does not have.
*
* A PLAIN TABLE, not T{ }, for the reason above.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = { };

-- `hello` is the verb that arms the post-kill ping for the session, and it is
-- the one verb only the addon sends. It goes out when the arming might not be
-- in place: window open, and after a zone line. An in-session re-read is
-- `board`, which is the same records without re-arming.
local wantVerb = 'hello';

local function refresh(verb)
    requested = { };
    wantVerb  = verb or 'board';
end

local function needBoard(now)
    local asked = requested['board'];

    if (asked ~= nil) then
        if (asked.answered or (now - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp = true;

                if (not state.serverSpoke) then
                    state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
                    state.statusBad = true;
                end
            end

            return;
        end

        asked.at    = now;
        asked.tries = asked.tries + 1;
    else
        requested['board'] = { at = now, answered = false, tries = 1 };
    end

    issueRead('!dwu ' .. wantVerb);
end

--[[
* A write in flight. Nothing here moves money and the store re-checks the
* account on both verbs, but a button clicked twice while the first click is
* still queued is a second line on the wire for a decision the player made
* once -- so the card says what it is doing instead of accepting the click.
--]]
local WRITE_TIMEOUT = 10.0;

local writePending = nil;

local function beginWrite(what, label, command)
    writePending = { what = what, label = label, at = os.clock() };

    issueWrite(command);
end

--[[
* Record parsing.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function num(text, fallback)
    return tonumber(text or '') or fallback;
end

local TOAST_SECONDS = 8.0;

local function toast(text)
    state.toast   = text;
    state.toastAt = os.clock();
end

--[[
* One a| record -- an accepted contract. It carries its own name and reward
* rather than pointing back at an o|, because a contract inside its grace
* period is not on today's board and this window still has to draw it
* (dwu_protocol.md, `a|`).
*
* KEYED ON qkey, NEVER ON handle: handles are a typed-tier label that
* renumbers between syncs, and a model keyed on one abandons the wrong
* contract exactly once (client discipline 3).
--]]
local function handleContract(parts)
    local qkey = parts[3];

    if (qkey == nil or qkey == '') then
        return;
    end

    local row = {
        handle   = parts[2],
        qkey     = qkey,
        kind     = parts[4],
        period   = parts[5],
        name     = parts[6],
        progress = num(parts[7], 0),
        needed   = num(parts[8], 0),
        reward   = num(parts[9], 0),
        secsLeft = num(parts[10], 0),
        state    = parts[11],
        at       = os.clock(),
    };

    local prev = state.actives[qkey];

    -- The toast fires off the PING only. A board sync is the window catching
    -- up with kills it already celebrated, and re-celebrating them on every
    -- zone line would make the toast mean nothing.
    if (state.inbound == 'ping') then
        if (row.state == 'done' and (prev == nil or prev.state ~= 'done')) then
            toast(string.format('Contract complete: %s   +%d DC', row.name, row.reward));
        elseif (prev == nil or row.progress > prev.progress) then
            toast(string.format('%s   %d / %d', row.name, row.progress, row.needed));

            -- THE WINDOW BEING SHUT MUST NOT COST THE PLAYER THE COUNTER.
            -- quest_core stops printing the per-kill progress line the moment a
            -- session is armed, because the window animates it instead -- so an
            -- armed session with the window closed would see nothing at all,
            -- which is strictly worse than not having this addon. Same sentence
            -- the server prints for everybody else; payouts are announced by the
            -- server to both tiers and are not repeated here.
            if (not state.open[1]) then
                print(chat.header('dwquest'):append(chat.message(
                    string.format('%s: %d/%d', row.name, row.progress, row.needed))));
            end
        end
    end

    if (prev == nil) then
        table.insert(state.activeOrder, qkey);
    end

    state.actives[qkey] = row;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = num(parts[2], 0);

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwquest.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.serverSpoke = true;
        state.inbound     = parts[3];

        -- A board replaces its whole section, and the reset runs FIRST: this
        -- runs under a pcall, and a throw after inbound is set must cost one
        -- record rather than leave old rows for the ones behind it. A ping is
        -- deliberately not reset -- it carries only what moved.
        if (state.inbound == 'board') then
            state.offers      = { };
            state.actives     = { };
            state.activeOrder = { };

            local asked = requested['board'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        end

        return;
    end

    -- Status lines are accepted whatever the envelope state: the sentence
    -- saying why something was refused is worth more than the response it
    -- happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwquest'):append(chat.error(state.status)));
        end

        -- A write that has answered is a write that is no longer in flight,
        -- whichever way it went. Nothing is re-sent either way.
        if (state.inbound == 'accept' or state.inbound == 'abandon') then
            writePending = nil;
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'board') then
            state.synced = true;

            if (state.status == 'Loading...') then
                state.status = '';
            end
        elseif (closing == 'accept' or closing == 'abandon') then
            writePending = nil;

            -- The write answered with a sentence, not with rows: the board it
            -- produced has to be read back before the cards are true. A read,
            -- so it is retried; the write itself never is.
            refresh('board');
        end

        return;
    end

    if (kind == 'y') then
        state.poolVersion = num(parts[2], nil);
        state.day         = num(parts[3], nil);
        state.band        = num(parts[5], nil);
        state.secsToDay   = num(parts[6], 0);
        state.secsToWeek  = num(parts[7], 0);
        state.clockAt     = os.clock();
        state.rollAsked   = false;

        return;
    end

    if (kind == 'o') then
        table.insert(state.offers, {
            slot   = parts[2],
            kind   = parts[3],
            qkey   = parts[4],
            name   = parts[5],
            needed = num(parts[6], 0),
            reward = num(parts[7], 0),
            state  = parts[8],
        });

        return;
    end

    if (kind == 'a') then
        handleContract(parts);

        return;
    end

    if (kind == 'g') then
        state.balance = num(parts[2], nil);

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWUDATA is ours -- consumed and blocked before parsing so a
* malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwquest_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwquest'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Reads over the synced state.
--]]

-- A countdown the server sent, aged by the wall clock since it arrived. Never
-- below zero: `secsLeft` is documented as never negative, and a bar counting
-- backwards past its own expiry is a number nobody can act on.
local function ticked(base, at, now)
    if (base == nil or at == nil) then
        return nil;
    end

    local left = base - (now - at);

    return left > 0 and left or 0;
end

local function fmtClock(secs)
    if (secs == nil) then
        return '--';
    end

    secs = math.floor(secs);

    if (secs <= 0) then
        return 'now';
    end

    if (secs >= 3600) then
        return string.format('%dh %02dm', math.floor(secs / 3600), math.floor((secs % 3600) / 60));
    end

    if (secs >= 60) then
        return string.format('%dm %02ds', math.floor(secs / 60), secs % 60);
    end

    return string.format('%ds', secs);
end

-- The rotation rolled while the window was open: the offers on screen belong
-- to the period that just ended. Asked ONCE per header -- y| clears the flag.
local function checkRotation(now)
    if (state.rollAsked or not state.synced or state.clockAt == nil) then
        return;
    end

    local day  = ticked(state.secsToDay, state.clockAt, now);
    local week = ticked(state.secsToWeek, state.clockAt, now);

    if ((day ~= nil and day <= 0) or (week ~= nil and week <= 0)) then
        state.rollAsked = true;

        refresh('board');
    end
end

--[[
* Actions. Every one is a line a player could type.
*
* Abandon names the QUEST KEY, not the handle: the server takes either, and
* the key cannot be renumbered out from under a click (client discipline 3).
--]]
local function acceptSlot(offer)
    beginWrite('accept', offer.name, string.format('!dwu accept %s', offer.slot));

    state.status    = string.format('Signing %s...', offer.name);
    state.statusBad = false;
end

local function abandonContract(row)
    beginWrite('abandon', row.name, string.format('!dwu abandon %s', row.qkey));

    state.status    = string.format('Tearing up %s...', row.name);
    state.statusBad = false;
end

--[[
* Rendering.
--]]

-- The period label comes off the slot handle, which IS the period: `d1`/`d2`
-- are the dailies and `w1`/`w2` the weeklies, fixed by the protocol
-- (dwu_protocol.md, `o|`). Reading a documented handle is not arithmetic over
-- server data -- there is no other number here the window invents.
local function periodLabel(slotOrPeriod)
    return tostring(slotOrPeriod or ''):sub(1, 1) == 'w' and 'Weekly' or 'Daily';
end

local function objectiveText(kind, needed, name)
    if (kind == 'fam') then
        return string.format('Slay %d of the %s family', needed, name);
    end

    return string.format('Slay %d creatures in %s', needed, name);
end

local function badge(text)
    imgui.TextColored(theme.colors.badge, string.format('[%s]', text));
    imgui.SameLine();
end

local function progressRow(row)
    local fraction = 0;

    if (row.needed > 0) then
        fraction = row.progress / row.needed;

        if (fraction < 0) then fraction = 0; end
        if (fraction > 1) then fraction = 1; end
    end

    imgui.ProgressBar(fraction, { -1, 16 }, string.format('%d / %d', row.progress, row.needed));
end

-- One card: the badge line, the bar, then reward, countdown and the one
-- button the card's state allows. Everything on it came off the wire.
local function contractCard(id, period, kind, title, reward, signed)
    badge(period);
    badge(kind == 'fam' and 'family' or 'zone');
    imgui.Text(title);

    if (signed ~= nil) then
        progressRow(signed);
    else
        imgui.ProgressBar(0, { -1, 16 }, 'Not signed');
    end

    imgui.TextDisabled(string.format('%d DC', reward));

    if (signed ~= nil) then
        imgui.SameLine();

        if (signed.state == 'done') then
            imgui.TextColored(theme.colors.ok, 'paid');
        else
            local left = ticked(signed.secsLeft, signed.at, state.now);

            if (left ~= nil and left <= 0) then
                imgui.TextDisabled('expired');
            else
                imgui.TextDisabled(string.format('%s left', fmtClock(left)));
            end
        end
    end

    imgui.SameLine();

    if (writePending ~= nil) then
        imgui.TextDisabled(string.format('%s...',
            writePending.what == 'abandon' and 'Tearing up' or 'Signing'));
    elseif (signed == nil) then
        if (imgui.SmallButton(string.format('Accept##dwquest_accept_%s', id))) then
            return 'accept';
        end
    elseif (signed.state ~= 'done') then
        if (imgui.SmallButton(string.format('Abandon##dwquest_abandon_%s', id))) then
            return 'abandon';
        end
    else
        imgui.TextDisabled('done');
    end

    imgui.Separator();

    return nil;
end

local function boardPanel()
    if (not imgui.BeginChild('##dwquest_board', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    local offered = { };

    for _, offer in ipairs(state.offers) do
        offered[offer.qkey] = true;

        local signed = state.actives[offer.qkey];
        local click  = contractCard(offer.slot, periodLabel(offer.slot), offer.kind,
            objectiveText(offer.kind, offer.needed, offer.name), offer.reward, signed);

        if (click == 'accept') then
            acceptSlot(offer);
        elseif (click == 'abandon' and signed ~= nil) then
            abandonContract(signed);
        end
    end

    if (#state.offers == 0) then
        imgui.TextDisabled('No contracts offered. The board is not loaded on this server build.');
    end

    -- Contracts inside their grace period: signed under an earlier rotation,
    -- still completable, and NOT on today's board -- which is the whole reason
    -- the a| record carries its own name and reward.
    local extra = { };

    for _, qkey in ipairs(state.activeOrder) do
        if (not offered[qkey] and state.actives[qkey] ~= nil) then
            table.insert(extra, state.actives[qkey]);
        end
    end

    if (#extra > 0) then
        imgui.TextDisabled('Still yours, from an earlier board:');

        for _, row in ipairs(extra) do
            local click = contractCard(row.qkey, periodLabel(row.period), row.kind,
                objectiveText(row.kind, row.needed, row.name), row.reward, row);

            if (click == 'abandon') then
                abandonContract(row);
            end
        end
    end

    imgui.EndChild();
end

local function headerRow()
    -- Refresh re-says `hello`, not `board`. It is the player's deliberate
    -- "make this right" click, and the one thing a plain re-read could not fix
    -- is a lost arming -- a map that restarted under the session drops the
    -- local var the ping rides on, and every following board read would come
    -- back correct and silent forever after. Re-arming is a no-op when it was
    -- never lost.
    if (imgui.Button('Refresh##dwquest_refresh')) then
        refresh('hello');
    end

    imgui.SameLine();

    if (state.balance ~= nil) then
        imgui.TextColored(theme.colors.ok, string.format('%d DC', state.balance));
    else
        imgui.TextDisabled('-- DC');
    end

    local queued = #readQueue + #writeQueue;

    if (queued > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d queued...', queued));
    end

    if (state.day ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('day %d  band %d  pool v%d',
            state.day, state.band or 0, state.poolVersion or 0));
    end

    if (state.clockAt ~= nil) then
        imgui.TextDisabled(string.format('New dailies in %s   New weeklies in %s',
            fmtClock(ticked(state.secsToDay, state.clockAt, state.now)),
            fmtClock(ticked(state.secsToWeek, state.clockAt, state.now))));
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    if (state.toast ~= nil and state.toastAt ~= nil and (state.now - state.toastAt) <= TOAST_SECONDS) then
        imgui.TextColored(theme.colors.hint, state.toast);
    end

    imgui.Separator();
end

local function renderWindow()
    headerRow();

    if (state.synced) then
        boardPanel();
    else
        imgui.TextDisabled('Waiting for the board...');
    end

    -- Inside the pcall, and last: the sync is the one thing here that can
    -- queue a line, and a throw in it must cost the window rather than the
    -- present handler that draws every other addon after us.
    checkRotation(state.now);
    needBoard(state.now);
end

--[[
* The render pass: pcall'd body, Begin/End and theme push/pop outside it so
* both stacks stay balanced; an error closes the window once, loudly, and the
* typed commands remain as the fallback.
--]]
ashita.events.register('d3d_present', 'dwquest_present', function ()
    -- Read once per frame. Two reads of the clock inside one frame would let
    -- a countdown and the bar beside it disagree, and the offline harness's
    -- clock strides deliberately to make that visible.
    state.now = os.clock();

    -- A write that was never answered must not hold the card hostage. Nothing
    -- was charged, nothing is re-sent: Refresh shows where the contract
    -- actually stands.
    if (writePending ~= nil and (state.now - writePending.at) > WRITE_TIMEOUT) then
        writePending    = nil;
        state.status    = 'No answer from the server. Nothing was re-sent -- Refresh shows where you stand.';
        state.statusBad = true;
    end

    pumpQueue(state.now);

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 560, 520 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Drift Board##dwquest', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwquest'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwquest'):append(chat.message('Window closed. Everything it does also works as !drift commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening asks `hello`, which is both the board read and
* the handshake that arms the post-kill ping for the session -- the one verb
* only the addon sends (dwu_protocol.md).
--]]
local function openWindow()
    state.open[1]   = true;
    state.reported  = false;
    state.status    = state.synced and '' or 'Loading...';
    state.statusBad = false;

    refresh('hello');
end

local function toggleWindow()
    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end

--[[
* Watch what the player sends. Bare `!drift` (and ui/window/gui) toggles the
* window and never leaves the client; every other !drift line passes through
* and marks our state stale, because a typed accept changes the board under
* the window. Any other outgoing line stamps the throttle -- the client's rate
* limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwquest_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!drift' or lower == '!drift ui' or lower == '!drift window' or lower == '!drift gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwu') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 6) == '!drift') then
        refresh('board');
    end
end);

ashita.events.register('command', 'dwquest_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwquest' and args[1] ~= '/quests')) then
        return;
    end

    e.blocked = true;

    toggleWindow();
end);

ashita.events.register('load', 'dwquest_load', function ()
    print(chat.header('dwquest'):append(chat.message('/quests opens the Drift Board. Everything it does also works typed as !drift commands.')));
end);

--[[
* A login is a new character and a new account view; a zone line is a good
* moment to catch up on kills the ping may have missed. Re-sync either way --
* but only once the server has spoken this session (an automatic line against
* a dead verb is the player saying it in public).
*
* The re-ask is `hello`, not `board`: the ping arming is a local var on the
* character the server was talking to, and this is exactly the event after
* which it may no longer be there.
--]]
ashita.events.register('packet_in', 'dwquest_zonein', function (e)
    if (e.id == 0x000A) then
        state.synced      = false;
        state.offers      = { };
        state.actives     = { };
        state.activeOrder = { };
        state.balance     = nil;
        state.clockAt     = nil;
        state.status      = 'Loading...';
        state.statusBad   = false;

        -- A write cannot survive the zone line it was in flight across: the
        -- answer, if there was one, went to a session that is gone.
        writePending = nil;

        if (state.serverSpoke) then
            refresh('hello');
        end
    end
end);
