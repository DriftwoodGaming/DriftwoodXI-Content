--[[
* DriftwoodXI -- dwleaderboard
*
* The server's bragging boards in a window: most total job levels, most gil,
* most kills, the most enemies defeated without a death, the fullest
* mog-house storage, the highest of every craft and all crafts combined, who
* fills the market's buy orders, playtime, deaths, distance walked -- names
* and scores, ranked, with everyone tied for first sharing rank 1.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited
* whole). It holds no data of its own: the board list arrives from the server
* (`o|` records -- boards grow server-side without an addon release, the
* vocabulary rule) and every board's rows arrive ranked. Every read is
* `!dwl boards` or `!dwl board <key>`, which are the same server functions
* `!leaderboard` reaches typed. The server enforces the privacy line -- names
* and scores only, no deleted characters, no GMs -- and this window can never
* be told more than the typed tier says.
*
* RANKS ARE ASSIGNED HERE, ON PURPOSE. Rows arrive sorted; standard
* competition ranking (tied scores share the rank, the next rank skips) is
* presentation, and the one thing the player asked of it -- "persons tied for
* first all get their name listed" -- is exactly what sorted rows plus shared
* ranks give. The server never spells a rank, so the two tiers cannot
* disagree about one.
*
* SCORES ARE RAW INTEGERS ON THE WIRE; the `unit` word in the h|/o| records
* says how to spell one (gil commas, craft tenths, playtime hours). A unit
* this addon does not know renders as the raw number -- a server newer than
* the addon must not break it.
*
* TURN IT OFF AND NOTHING IS LOST. `!leaderboard` does all of it typed.
--]]

addon.name    = 'dwleaderboard';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.2';
addon.desc    = 'The DriftwoodXI leaderboards: job levels, gil, kills, no-death streaks, storage, crafts, market deeds.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line.
local DATA_SENDER = '_DWLDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

local state = T{
    open      = T{ false },

    -- The board catalogue, in the server's shipping order, and the rows of
    -- the one board on screen. Both COMMIT ON z| from a pending copy, so a
    -- half-arrived reply can never half-fill the window.
    boards    = {},         -- { { key, label, unit }, ... }
    board     = nil,        -- { key, unit, rows = { { name, score } } }
    selected  = nil,        -- the key the player is looking at

    pendingBoards = nil,
    pendingBoard  = nil,

    inbound   = nil,        -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame

    -- The answer clock, per verb (the dwfame shape): one retry after five
    -- seconds, then the silent latch -- an unknown ! command falls through to
    -- PUBLIC /say on a server without dwl.lua, and the latch contains that.
    requested    = nil,     -- { verb, key, at, tries }
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until the
    -- zone line re-probes it (a map restart is also a login).
    refused   = false,

    -- Who is logged in, so their own row draws highlighted.
    charName  = nil,
    charCheckAt = nil,
};

--[[
* Outbound: `!dwl` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat and
* answers a burst with "A command error occurred" before the server sees it.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    -- Queries collapse: asking twice for the same board is never useful and
    -- there are no writes on this wire at all.
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- Held, not dropped, while the client is zoning (dwecho's canSend).
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local function commandFor(verb, key)
    if (verb == 'board') then
        return string.format('!dwl board %s', key);
    end

    return '!dwl boards';
end

-- `force` is the Refresh button: a click is the player asking, and the
-- silent latch exists to contain AUTOMATIC re-asks, not to ignore the
-- player (the dwnemesis 1.1.0 finding: a Refresh gated on the latch is a
-- window that never recovers without a zone line). The protocol refusal is
-- not lifted by a click.
local function ask(verb, key, force)
    if (state.refused) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    state.requested = { verb = verb, key = key, at = os.clock(), tries = 1 };

    issue(commandFor(verb, key));
end

-- The retry pass, from the render loop. The clock never ages while the
-- client is zoning: a held queue is not an unanswered server.
local function checkAnswers()
    local asked = state.requested;

    if (asked == nil) then
        return;
    end

    -- Re-stamped, not skipped, while the client is zoning: a clock started
    -- when the line was queued behind echo.canSend() has already expired
    -- when the line finally goes out, and the retry then fires into the
    -- same post-zone settle window that drops the first send.
    if (not echo.canSend()) then
        asked.at = os.clock();

        return;
    end

    if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
        return;
    end

    if (asked.tries >= ANSWER_TRIES) then
        state.requested    = nil;
        state.serverSilent = true;
        state.status       = 'No answer from the server. Is DriftwoodXI up to date?';
        state.statusBad    = true;

        return;
    end

    asked.at    = os.clock();
    asked.tries = asked.tries + 1;

    issue(commandFor(asked.verb, asked.key));
end

--[[
* Record parsing. Records are accepted only between a `d|` and its `z|`;
* anything unrecognised falls off the chain rather than being an error, which
* is what lets the server grow record kinds without breaking this addon.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            print(chat.header('dwleaderboard'):append(chat.error(string.format(
                'server protocol %d, addon expects %d. Update dwleaderboard through the launcher.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope answers the outstanding ask and clears
        -- a silent latch earned against a server since updated.
        state.requested    = nil;
        state.serverSilent = false;

        state.inbound = parts[3];

        if (state.inbound == 'boards') then
            state.pendingBoards = {};
        elseif (state.inbound == 'board') then
            state.pendingBoard = { key = nil, unit = 'count', rows = {} };
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwleaderboard'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'o' and state.pendingBoards ~= nil) then
        table.insert(state.pendingBoards, {
            key   = parts[2],
            label = parts[3],
            unit  = parts[4] or 'count',
        });

        return;
    end

    if (kind == 'h' and state.pendingBoard ~= nil) then
        state.pendingBoard.key  = parts[2];
        state.pendingBoard.unit = parts[3] or 'count';

        return;
    end

    if (kind == 'b' and state.pendingBoard ~= nil) then
        table.insert(state.pendingBoard.rows, {
            name  = parts[2],
            score = tonumber(parts[3]) or 0,
        });

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        if (closed == 'boards' and state.pendingBoards ~= nil) then
            state.boards        = state.pendingBoards;
            state.pendingBoards = nil;

            if (state.selected == nil and #state.boards > 0) then
                state.selected = state.boards[1].key;

                ask('board', state.selected);
            end
        elseif (closed == 'board' and state.pendingBoard ~= nil) then
            state.board        = state.pendingBoard;
            state.pendingBoard = nil;
            state.status       = '';
            state.statusBad    = false;
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwleaderboard_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        -- Blocked before parsing: a malformed record must not leak into the
        -- chat log as noise.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwleaderboard'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line invalidates nothing a leaderboard said -- the boards are
    -- server-wide -- but both latches are re-probed: 0x000A is also a login,
    -- and the server on the far side of a map restart may be the updated one.
    if (e.id == 0x000A) then
        state.requested    = nil;
        state.serverSilent = false;
        state.refused      = false;
        state.charCheckAt  = os.clock() + 3.0;
    end
end);

--[[
* Rendering.
--]]
local function comma(n)
    local s    = tostring(math.floor(n));
    local left = s;
    local out  = '';

    while (#left > 3) do
        out  = ',' .. left:sub(-3) .. out;
        left = left:sub(1, -4);
    end

    return left .. out;
end

-- A score, spelled by its unit. An unknown unit is the raw number: a server
-- newer than this addon must not break it.
local function scoreText(unit, score)
    if (unit == 'tenths') then
        return string.format('%d.%d', math.floor(score / 10), score % 10);
    end

    if (unit == 'seconds') then
        return string.format('%dh %02dm', math.floor(score / 3600), math.floor(score / 60) % 60);
    end

    if (unit == 'gil') then
        return comma(score) .. ' gil';
    end

    return comma(score);
end

local function boardLabel(key)
    for _, board in ipairs(state.boards) do
        if (board.key == key) then
            return board.label;
        end
    end

    return key or '';
end

local function renderWindow()
    if (imgui.Button('Refresh##dwl_refresh')) then
        if (state.selected ~= nil) then
            ask('board', state.selected, true);
        else
            ask('boards', nil, true);
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Ask the server again. Boards refresh themselves about once a minute.');
    end

    imgui.SameLine();

    if (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server.');
    elseif (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwleaderboard through the launcher.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or state.requested ~= nil) then
        imgui.TextDisabled('asking...');
    else
        imgui.TextDisabled('Names and scores only. Ties share the rank.');
    end

    imgui.Separator();

    -- The board list, left; the rows, right.
    imgui.BeginChild('##dwl_list', { 190, 0 }, ImGuiChildFlags_Borders);

    for _, board in ipairs(state.boards) do
        if (imgui.Selectable(string.format('%s##dwl_%s', board.label, board.key), state.selected == board.key)) then
            state.selected = board.key;

            ask('board', board.key);
        end
    end

    if (#state.boards == 0) then
        imgui.TextDisabled('Waiting for the board list...');
    end

    imgui.EndChild();

    imgui.SameLine();

    imgui.BeginChild('##dwl_rows', { 0, 0 }, ImGuiChildFlags_Borders);

    local board = state.board;

    if (board == nil or board.key ~= state.selected) then
        imgui.TextDisabled('Pick a board on the left.');
    elseif (#board.rows == 0) then
        imgui.Text(boardLabel(board.key));
        imgui.TextDisabled('Nobody on this board yet. Be first.');
    else
        imgui.Text(boardLabel(board.key));

        if (imgui.BeginTable('##dwl_table', 3,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                        ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
            imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 30, 0);
            imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthFixed, 170, 0);
            imgui.TableSetupColumn('Score', ImGuiTableColumnFlags_WidthFixed, 150, 0);
            imgui.TableSetupScrollFreeze(0, 1);
            imgui.TableHeadersRow();

            -- Standard competition ranking: tied scores share the rank, the
            -- next rank skips -- so everyone tied for first is named at 1.
            local rank = 0;
            local last = nil;

            for index, row in ipairs(board.rows) do
                if (last == nil or row.score < last) then
                    rank = index;
                    last = row.score;
                end

                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(tostring(rank));

                imgui.TableNextColumn();

                if (rank == 1) then
                    imgui.TextColored(theme.colors.warn, row.name);
                elseif (state.charName ~= nil and row.name == state.charName) then
                    imgui.TextColored(theme.colors.ok, row.name);
                else
                    imgui.Text(row.name);
                end

                imgui.TableNextColumn();
                imgui.Text(scoreText(board.unit, row.score));
            end

            imgui.EndTable();
        end
    end

    imgui.EndChild();
end

ashita.events.register('d3d_present', 'dwleaderboard_present', function ()
    -- Before the visibility check: a request issued a moment before the
    -- window was closed still has to reach the server.
    pumpQueue();
    checkAnswers();

    -- Who is logged in, for the own-row highlight (the dwparse shape).
    if (state.charCheckAt ~= nil and os.clock() >= state.charCheckAt) then
        local party = AshitaCore:GetMemoryManager():GetParty();
        local name  = party ~= nil and party:GetMemberName(0) or '';

        if (name ~= nil and name ~= '') then
            state.charName    = name;
            state.charCheckAt = nil;
        else
            state.charCheckAt = os.clock() + 2.0;
        end
    end

    if (not state.open[1]) then
        return;
    end

    -- The board list is asked for LAZILY -- the first frame the window is
    -- actually open -- so a player who never opens it never handshakes.
    if (#state.boards == 0 and state.requested == nil
            and not state.serverSilent and not state.refused) then
        ask('boards');
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 620, 460 }, ImGuiCond_FirstUseEver);

    -- NoDocking: the suite-wide flag (fused dw windows survive imgui.ini).
    local visible = imgui.Begin('DriftwoodXI Leaderboard##dwleaderboard', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwleaderboard'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwleaderboard'):append(chat.message('Window closed. Everything it shows also works typed as !leaderboard.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

-- Anything the player types counts against the client's chat rate limit, so
-- a queued line behind a typed one waits its interval instead of racing it.
ashita.events.register('packet_out', 'dwleaderboard_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dwl') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwleaderboard_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed (the suite-wide
    -- /Warehouse lesson).
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/leaderboard' and first ~= '/lb') then
        return;
    end

    e.blocked = true;

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwleaderboard_load', function ()
    state.charCheckAt = os.clock() + 3.0;

    print(chat.header('dwleaderboard'):append(chat.message('/leaderboard (or /lb) opens the boards. Everything it shows also works typed as !leaderboard.')));
end);
