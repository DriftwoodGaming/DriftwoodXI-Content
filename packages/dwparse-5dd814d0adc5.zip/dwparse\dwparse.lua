--[[
* DriftwoodXI -- dwparse
*
* A damage and healing parser for the party on screen: every action the server
* announces, broken down per actor, with the numbers a player tunes a setup by
* -- DPS, accuracy, crit rate, max hit, healing output -- and an Export button
* that speaks the result into chat for the rest of the party.
*
* THIS ADDON ONLY LISTENS. It decodes GP_SERV_COMMAND_BATTLE2 (0x0028), the
* packet the client itself renders the combat log from, and never blocks,
* rewrites or sends anything on its own account -- the one thing it transmits
* is the Export text, which goes out as ordinary typed chat through the same
* throttled queue dwbags uses. Turn it off and the game is exactly as it was.
*
* THE WIRE FORMAT IS THE SERVER'S OWN. The bit layout below mirrors
* GP_SERV_COMMAND_BATTLE2::pack in src/map/packets/s2c/0x028_battle2.cpp and
* the message ids come from src/map/enums/msg_basic.h -- this addon runs
* against DriftwoodXI and nothing else, so the server source is ground truth
* and no guessing against retail captures was involved. If the pack order ever
* changes, change it here in the same commit.
*
* ROWS ARE KEYED BY NAME, NOT BY ENTITY ID, and that is the feature. A squad
* member dismissed and re-called comes back as a brand new entity with a brand
* new id; a zone line renumbers everybody. The name survives both, so the
* parse does too: it accumulates until the Reset button (or /parse reset)
* clears it, across zones and across recalls. Pets ride under their own name
* tagged with their owner's -- "Carbuncle (Ayla)" -- so a summoner's output
* reads as two honest rows rather than one muddled one.
*
* WHAT COUNTS AS WHAT. Damage is anything the server said dealt points of
* damage, skillchains included (they arrive as an additional-effect block on
* the closing weaponskill and are credited to its actor). Drains count as
* damage only -- the self-heal half is not added to healing, so the Healing
* tab stays an honest measure of restorative output. Healing is what the
* server said was recovered; overcure is invisible on the wire (the server
* already reports the capped number), so what you see is HP that landed.
*
* WHO IS TRACKED. By default only the party and its pets earn rows -- on this
* server that means you, your squad, and anything you summon. Untick "Party
* only" and every actor in range is tracked, mobs included. The Taken tab is
* always about party members, whoever was hitting them.
--]]

addon.name    = 'dwparse';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.2';
addon.desc    = 'Damage and healing parser for DriftwoodXI. /parse or /dwparse.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

--[[
* Message ids, from the server's msg_basic.h. Only the ones that carry (or
* deny) an amount matter to a parser; anything not listed is ignored, which is
* also what keeps a server newer than the addon from breaking it -- an unknown
* message is simply not counted rather than being an error.
--]]

-- Main-result damage: the value field is points dealt by the actor.
local DMG = {
    [1]   = true,   -- melee hit
    [67]  = true,   -- melee critical
    [77]  = true,   -- Sange
    [157] = true,   -- Barrage
    [352] = true,   -- ranged hit
    [353] = true,   -- ranged critical
    [576] = true,   -- ranged, squarely
    [577] = true,   -- ranged, strikes true
    [185] = true,   -- skill damage (weaponskills, mob TP moves)
    [187] = true,   -- skill HP drain
    [110] = true,   -- ability damage
    [317] = true,   -- ability damage (Swipe/Lunge family)
    [197] = true,   -- ability damage, resisted
    [2]   = true,   -- magic damage
    [252] = true,   -- magic burst
    [227] = true,   -- magic HP drain
    [274] = true,   -- magic burst HP drain
    [264] = true,   -- <target> takes damage (AoE secondary lines)
};

local CRIT = { [67] = true, [353] = true };

-- The swing happened and connected with nothing: misses, dodges, evades.
local MISS = {
    [15]  = true,   -- melee miss
    [30]  = true,   -- anticipates
    [32]  = true,   -- dodges
    [282] = true,   -- evades
    [354] = true,   -- ranged miss
    [188] = true,   -- skill misses
    [158] = true,   -- ability misses
    [324] = true,   -- ability misses (named target)
};

-- The action landed but was refused: full resists and "no effect". Counted as
-- attempts so a resisted nuke drags the average the way it dragged the fight.
local RESIST = {
    [85]  = true,   -- resists the spell
    [284] = true,   -- resists the effects
    [655] = true,   -- completely resists
    [75]  = true,   -- magic no effect
    [189] = true,   -- skill no effect
    [323] = true,   -- ability no effect
    [355] = true,   -- ranged no effect
};

-- Absorbed by shadows: not a miss (the aim was true) and not damage. Its own
-- count, because eating shadows is exactly what some setups are for.
local SHADOW = { [31] = true };

-- Main-result countering: the TARGET dealt this damage to the actor, so the
-- attribution is inverted relative to every other damage message.
local COUNTER = { [33] = true };

-- Main-result HP healing: the value is HP recovered by the target.
local HEAL = {
    [7]   = true,   -- magic recovers HP (cures)
    [24]  = true,   -- recovers HP (AoE cure secondary lines)
    [102] = true,   -- ability recovers HP
    [103] = true,   -- skill recovers HP (waltzes, chakra family)
    [238] = true,   -- skill recovers HP, AoE
    [263] = true,   -- recovers HP
    [306] = true,   -- item recovers HP
    [318] = true,   -- item recovers HP
    [367] = true,   -- recovers HP
    [587] = true,   -- regains HP
    [382] = true,   -- ranged attack absorbed as HP
};

-- Main-result MP restoration -- a sideline stat, but the one a Ballad or
-- Evoker's setup is judged by.
local HEAL_MP = {
    [224] = true,   -- skill recovers MP
    [225] = true,   -- skill MP drain
    [276] = true,   -- recovers MP
    [366] = true,   -- MP drained
    [588] = true,   -- regains MP
};

-- Additional-effect block: en-spells, drains, and skillchains. Skillchain
-- damage is message 287 + chain id (action.cpp recordSkillchain), so 288-303
-- name the chain that closed.
local PROC_DMG = { [163] = true, [229] = true, [161] = true };
local PROC_HEAL = { [384] = true };
local PROC_MP = { [162] = true };

local SC_NAMES = {
    [288] = 'Light',         [289] = 'Darkness',      [290] = 'Gravitation',
    [291] = 'Fragmentation', [292] = 'Distortion',    [293] = 'Fusion',
    [294] = 'Compression',   [295] = 'Liquefaction',  [296] = 'Induration',
    [297] = 'Reverberation', [298] = 'Transfixion',   [299] = 'Scission',
    [300] = 'Detonation',    [301] = 'Impaction',     [302] = 'Radiance',
    [303] = 'Umbra',
};

-- Reaction block: the target's spikes, counters and retaliations, dealt back
-- onto the actor.
local REACT_DMG = { [44] = true, [132] = true, [33] = true, [536] = true };

--[[
* Parse state. Everything cumulative lives in `parse` and only reset() ever
* replaces it -- deliberately NOT touched by the zone-in packet, which is the
* whole reason this addon exists over /p "what did that hit for?".
*
* `actors` is a PLAIN table keyed by display name. Not T{}: sugar tables
* resolve unknown keys through their method table, and a row keyed by a name
* the player chose must never collide with a method (the dwbags `find` lesson,
* learned so this addon does not have to learn it again).
--]]
local function freshActor(name)
    return {
        name    = name,
        dmg     = { total = 0, max = 0, maxLabel = '' },
        heal    = { total = 0, max = 0, maxLabel = '', mp = 0 },
        taken   = { total = 0, hits = 0, max = 0, maxLabel = '', evades = 0, shadows = 0, healed = 0 },
        actions = {},   -- [label] = { count, landed, total, max, crits, misses, resists, shadows }
        heals   = {},   -- [label] = { count, total, max }
        sources = {},   -- [attacker] = { count, total, max }  (Taken tab detail)
        recent  = {},   -- ring of { t, amount } for the sliding-window DPS
        recentSum = 0,
    };
end

local function freshParse()
    return {
        actors    = {},
        startedAt = nil,    -- os.clock() of the first combat event
        lastAt    = nil,    -- os.clock() of the most recent one
    };
end

local parse = freshParse();

-- The sliding window the "Recent" column reads: long enough to smooth a slow
-- weaponskill cycle, short enough to answer "what am I doing right now".
local RECENT_WINDOW = 30.0;

local state = T{
    open      = T{ false },
    paused    = T{ false },
    partyOnly = T{ true },
    tab       = 'dmg',      -- which tab is on screen; Export exports it
    channel   = 1,          -- index into CHANNELS
    selected  = nil,        -- actor name whose breakdown is open
    status    = 'Parsing. Fight something.',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame
    charName  = nil,        -- who is logged in; a new name resets the parse
    charCheckAt = nil,
};

local CHANNELS = {
    { label = 'Party',     prefix = '/p '    },
    { label = 'Say',       prefix = '/say '  },
    { label = 'Linkshell', prefix = '/l '    },
    { label = 'Echo',      prefix = '/echo ' },
};

--[[
* Outgoing chat, one line per interval -- the same queue-and-pump dwbags runs,
* for the same reason: the client rate-limits outgoing chat and answers a
* burst with "A command error occurred" before the server ever sees it. An
* export is up to nine lines and they all have to arrive.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Who earns a row: the party and its pets.
*
* Rebuilt at most once a second rather than per packet -- a melee round from a
* full squad is a stream of 0x0028s and the answer does not change inside a
* second. Keyed by server id, valued with the display name the row should
* carry; a pet's name is tagged with its owner so "Carbuncle" from two
* different summoners stays two rows.
--]]
local trackedCache = { at = 0, ids = {} };

local function trackedSet()
    local now = os.clock();

    if (now - trackedCache.at < 1.0) then
        return trackedCache.ids;
    end

    local ids    = {};
    local party  = AshitaCore:GetMemoryManager():GetParty();
    local entity = AshitaCore:GetMemoryManager():GetEntity();

    if (party ~= nil) then
        for i = 0, 17 do
            if (party:GetMemberIsActive(i) == 1) then
                local sid  = party:GetMemberServerId(i);
                local name = party:GetMemberName(i);

                if (sid ~= nil and sid ~= 0 and name ~= nil and name ~= '') then
                    ids[sid] = name;

                    -- The member's pet, read out of the entity array. Wrapped
                    -- because an index can go stale between the party list and
                    -- the entity read on a zone line.
                    local ok, petIdx = pcall(function ()
                        return entity:GetPetTargetIndex(party:GetMemberTargetIndex(i));
                    end);

                    if (ok and petIdx ~= nil and petIdx > 0) then
                        local petSid  = entity:GetServerId(petIdx);
                        local petName = entity:GetName(petIdx);

                        if (petSid ~= nil and petSid ~= 0 and petName ~= nil and petName ~= '') then
                            ids[petSid] = string.format('%s (%s)', petName, name);
                        end
                    end
                end
            end
        end
    end

    trackedCache.at  = now;
    trackedCache.ids = ids;

    return ids;
end

--[[
* A name for any entity id, party or not -- what the "Party only" untick and
* the Taken tab's attacker column run on.
*
* Dynamic entities (mobs, trusts, pets; id >= 0x1000000) carry their targid
* OFFSET BY 0x100 -- zone_entities.cpp builds the id as
* `0x01000000 | zone << 12 | (targid + 0x0100)` -- so the low twelve bits are
* NOT the index and have to be un-offset the way the server itself does it
* (zoneutils.cpp GetEntity). This comment used to say they "encode their own
* index", and the code below believed it. The lookup is still direct and NEVER
* cached: a dismissed trust's index is reused by the next spawn under the same
* id, and the current occupant's name is the correct answer at event time.
* Player-range ids carry no index, so those are found by scan and cached,
* verified before reuse.
--]]
local playerIdCache = {};

local function entityName(sid)
    if (sid == nil or sid == 0) then
        return nil;
    end

    local entity = AshitaCore:GetMemoryManager():GetEntity();

    if (sid >= 0x1000000) then
        local idx = sid % 0x1000;

        -- Un-offset exactly as zoneutils.cpp does. Dynamic targids start at
        -- 0x700, so the stored value lands in [0x800, 0x9FF] and static ids
        -- stop below 0x700 -- the ranges cannot overlap, so the test is
        -- unambiguous. The upper bound covers the zone's overflow escape
        -- (targid = 0x900), which would otherwise index one past the end of
        -- the client's 0x900-entry array.
        if (idx >= 0x800) then
            idx = idx - 0x100;
        end

        if (idx <= 0x8FF and entity:GetServerId(idx) == sid) then
            local name = entity:GetName(idx);

            return (name ~= nil and name ~= '') and name or nil;
        end

        return nil;
    end

    local cached = playerIdCache[sid];

    if (cached ~= nil and entity:GetServerId(cached) == sid) then
        local name = entity:GetName(cached);

        return (name ~= nil and name ~= '') and name or nil;
    end

    for idx = 0x400, 0x8FF do
        if (entity:GetServerId(idx) == sid) then
            playerIdCache[sid] = idx;

            local name = entity:GetName(idx);

            return (name ~= nil and name ~= '') and name or nil;
        end
    end

    return nil;
end

--[[
* Resource names for the breakdown labels. Job abilities arrive under their
* small id and live at id + 512 in the client's ability DAT; weaponskills use
* their raw id. Mob and pet TP moves have no client-side name table worth
* trusting, so they fall through to a numbered label rather than a wrong one.
--]]
local function abilityName(id, offset)
    local ability = AshitaCore:GetResourceManager():GetAbilityById(id + offset);

    if (ability ~= nil and ability.Name[1] ~= nil and ability.Name[1]:len() > 0) then
        return ability.Name[1];
    end

    return nil;
end

local function actionLabel(category, param)
    if (category == 1) then
        return 'Melee';
    elseif (category == 2) then
        return 'Ranged';
    elseif (category == 3) then
        return abilityName(param, 0) or string.format('Weaponskill #%d', param);
    elseif (category == 4) then
        local spell = AshitaCore:GetResourceManager():GetSpellById(param);

        if (spell ~= nil and spell.Name[1] ~= nil and spell.Name[1]:len() > 0) then
            return spell.Name[1];
        end

        return string.format('Spell #%d', param);
    elseif (category == 5) then
        local item = AshitaCore:GetResourceManager():GetItemById(param);

        if (item ~= nil and item.Name[1] ~= nil and item.Name[1]:len() > 0) then
            return item.Name[1];
        end

        return string.format('Item #%d', param);
    elseif (category == 6 or category == 14 or category == 15) then
        return abilityName(param, 512) or abilityName(param, 0) or string.format('Ability #%d', param);
    elseif (category == 11 or category == 13) then
        return abilityName(param, 512) or string.format('TP move #%d', param);
    end

    return string.format('Action #%d', param);
end

--[[
* Accumulation. Rows appear on first credit; the clock starts on the first
* combat event and advances on every one after it, so DPS is measured over
* time actually spent fighting rather than time spent running back.
--]]
local function actorRow(name)
    local row = parse.actors[name];

    if (row == nil) then
        row = freshActor(name);
        parse.actors[name] = row;
    end

    return row;
end

local function touchClock()
    local now = os.clock();

    if (parse.startedAt == nil) then
        parse.startedAt = now;
    end

    parse.lastAt = now;
end

local function pruneRecent(row, now)
    local list = row.recent;

    while (#list > 0 and now - list[1].t > RECENT_WINDOW) do
        row.recentSum = row.recentSum - list[1].amount;
        table.remove(list, 1);
    end
end

local function bucket(map, label)
    local b = map[label];

    if (b == nil) then
        b = { count = 0, landed = 0, total = 0, max = 0, crits = 0, misses = 0, resists = 0, shadows = 0 };
        map[label] = b;
    end

    return b;
end

local function creditDamage(name, label, amount, isCrit)
    local row = actorRow(name);
    local now = os.clock();

    row.dmg.total = row.dmg.total + amount;

    if (amount > row.dmg.max) then
        row.dmg.max      = amount;
        row.dmg.maxLabel = label;
    end

    local b = bucket(row.actions, label);

    b.count  = b.count + 1;
    b.landed = b.landed + 1;
    b.total  = b.total + amount;

    if (amount > b.max) then
        b.max = amount;
    end

    if (isCrit) then
        b.crits = b.crits + 1;
    end

    pruneRecent(row, now);
    table.insert(row.recent, { t = now, amount = amount });
    row.recentSum = row.recentSum + amount;

    touchClock();
end

local function creditAttempt(name, label, kind)
    local row = actorRow(name);
    local b   = bucket(row.actions, label);

    b.count = b.count + 1;
    b[kind] = b[kind] + 1;

    touchClock();
end

local function creditHeal(name, label, amount)
    local row = actorRow(name);

    row.heal.total = row.heal.total + amount;

    if (amount > row.heal.max) then
        row.heal.max      = amount;
        row.heal.maxLabel = label;
    end

    local b = row.heals[label];

    if (b == nil) then
        b = { count = 0, total = 0, max = 0 };
        row.heals[label] = b;
    end

    b.count = b.count + 1;
    b.total = b.total + amount;

    if (amount > b.max) then
        b.max = amount;
    end

    touchClock();
end

local function creditMP(name, amount)
    local row = actorRow(name);

    row.heal.mp = row.heal.mp + amount;

    touchClock();
end

local function creditTaken(name, attacker, amount)
    local row = actorRow(name);

    row.taken.total = row.taken.total + amount;
    row.taken.hits  = row.taken.hits + 1;

    if (amount > row.taken.max) then
        row.taken.max      = amount;
        row.taken.maxLabel = attacker or '?';
    end

    if (attacker ~= nil) then
        local b = row.sources[attacker];

        if (b == nil) then
            b = { count = 0, total = 0, max = 0 };
            row.sources[attacker] = b;
        end

        b.count = b.count + 1;
        b.total = b.total + amount;

        if (amount > b.max) then
            b.max = amount;
        end
    end

    touchClock();
end

--[[
* The bit reader, matching the server's unpackBitsBE: bytes assembled
* little-endian from the byte the offset lands in, shifted down by the
* in-byte remainder, masked to length. Pure arithmetic rather than the bit
* library, because a 32-bit field at a 7-bit offset spans 39 bits and LuaJIT's
* bit ops truncate at 32; doubles carry 53 cleanly.
--]]
local function readBits(data, bitOffset, length)
    local byteStart = math.floor(bitOffset / 8);
    local shift     = bitOffset % 8;
    local nBytes    = math.floor((shift + length + 7) / 8);
    local value     = 0;

    for i = nBytes, 1, -1 do
        value = value * 256 + (data:byte(byteStart + i) or 0);
    end

    return math.floor(value / (2 ^ shift)) % (2 ^ length);
end

--[[
* GP_SERV_COMMAND_BATTLE2, field for field in the server's pack() order.
* Categories that only announce a start (7-10, 12) carry no amounts and are
* skipped before any bit is read.
--]]
local function parseActionPacket(data)
    local pos = 40;     -- skip the 4-byte header and WorkSize

    local function read(length)
        local value = readBits(data, pos, length);

        pos = pos + length;

        return value;
    end

    local act = {};

    act.actor    = read(32);
    local trgSum = read(6);
    read(4);                    -- res_sum, always 0
    act.category = read(4);
    act.param    = read(32);
    read(32);                   -- recast / action info
    act.targets  = {};

    if (act.category == 7 or act.category == 8 or act.category == 9
            or act.category == 10 or act.category == 12 or act.category == 0) then
        return nil;
    end

    for t = 1, math.min(trgSum, 15) do
        local target = { id = read(32), results = {} };
        local resSum = read(4);

        for r = 1, math.min(resSum, 8) do
            local res = {};

            res.miss = read(3);
            read(2);            -- kind
            read(12);           -- animation
            read(5);            -- info
            read(5);            -- hit distortion + knockback
            res.value   = read(17);
            res.message = read(10);
            read(31);           -- modifier

            if (read(1) == 1) then
                read(6);        -- proc kind
                read(4);        -- proc info
                res.procValue   = read(17);
                res.procMessage = read(10);
            end

            if (read(1) == 1) then
                read(6);        -- react kind
                read(4);        -- react info
                res.reactValue   = read(14);
                res.reactMessage = read(10);
            end

            target.results[#target.results + 1] = res;
        end

        act.targets[#act.targets + 1] = target;
    end

    return act;
end

--[[
* One decoded action against the tallies.
*
* Attribution runs per result: the actor's side needs the actor to be worth a
* row (party, or anyone when "Party only" is off, and nameless actors out of
* range are dropped rather than invented); the target's side only ever cares
* whether the target is a party member. Both halves of one result can count --
* a mob's TP move is the mob's damage dealt and the tank's damage taken.
--]]
local function handleAction(act)
    local tracked   = trackedSet();
    local actorName = tracked[act.actor];

    if (actorName == nil and not state.partyOnly[1]) then
        actorName = entityName(act.actor);
    end

    local label = actionLabel(act.category, act.param);

    for _, target in ipairs(act.targets) do
        local targetName = tracked[target.id];

        for _, res in ipairs(target.results) do
            local msg = res.message;

            if (COUNTER[msg]) then
                -- The target countered: their damage, dealt to the actor.
                local counterer = tracked[target.id]
                    or ((not state.partyOnly[1]) and entityName(target.id) or nil);

                if (counterer ~= nil) then
                    creditDamage(counterer, 'Counter', res.value, false);
                end

                if (actorName ~= nil and tracked[act.actor] ~= nil) then
                    creditTaken(actorName, targetName or entityName(target.id), res.value);
                end
            elseif (DMG[msg]) then
                if (actorName ~= nil) then
                    creditDamage(actorName, label, res.value, CRIT[msg] == true);
                end

                if (targetName ~= nil) then
                    creditTaken(targetName, actorName or entityName(act.actor), res.value);
                end
            elseif (MISS[msg]) then
                if (actorName ~= nil) then
                    creditAttempt(actorName, label, 'misses');
                end

                if (targetName ~= nil) then
                    actorRow(targetName).taken.evades = actorRow(targetName).taken.evades + 1;
                    touchClock();
                end
            elseif (RESIST[msg]) then
                if (actorName ~= nil) then
                    creditAttempt(actorName, label, 'resists');
                end
            elseif (SHADOW[msg]) then
                if (actorName ~= nil) then
                    creditAttempt(actorName, label, 'shadows');
                end

                if (targetName ~= nil) then
                    actorRow(targetName).taken.shadows = actorRow(targetName).taken.shadows + 1;
                    touchClock();
                end
            elseif (HEAL[msg]) then
                if (actorName ~= nil) then
                    creditHeal(actorName, label, res.value);
                end

                if (targetName ~= nil) then
                    actorRow(targetName).taken.healed = actorRow(targetName).taken.healed + res.value;

                    -- Like every other target-side counter: without this, a
                    -- cure from an untracked healer (Party only on) creates
                    -- rows while the combat clock still reads "waiting".
                    touchClock();
                end
            elseif (HEAL_MP[msg]) then
                if (actorName ~= nil) then
                    creditMP(actorName, res.value);
                end
            end

            -- Additional effects: en-spells, drains, and the skillchain the
            -- weaponskill closed, all credited to the weaponskill's actor.
            if (res.procMessage ~= nil and res.procMessage ~= 0 and actorName ~= nil) then
                local pm = res.procMessage;

                if (SC_NAMES[pm] ~= nil) then
                    creditDamage(actorName, 'Skillchain: ' .. SC_NAMES[pm], res.procValue, false);
                elseif (pm > 384 and pm <= 400 and SC_NAMES[pm - 384 + 287] ~= nil) then
                    -- 384 + effect is a skillchain ABSORBED by the target
                    -- (action.cpp emits it when the chain damage goes
                    -- negative), exactly parallel to 287 + effect for the
                    -- damage case: an undead eating a Light chain heals for
                    -- it, and dropping the row reported nothing at all.
                    creditHeal(actorName, 'Skillchain: ' .. SC_NAMES[pm - 384 + 287], res.procValue);
                elseif (PROC_DMG[pm]) then
                    creditDamage(actorName, 'Add. effect', res.procValue, false);
                elseif (PROC_HEAL[pm]) then
                    creditHeal(actorName, 'Add. effect', res.procValue);
                elseif (PROC_MP[pm]) then
                    creditMP(actorName, res.procValue);
                end
            end

            -- Reactions: the target's spikes or retaliation, dealt back onto
            -- the actor -- the one block where roles swap.
            if (res.reactMessage ~= nil and REACT_DMG[res.reactMessage]) then
                local spiker = tracked[target.id]
                    or ((not state.partyOnly[1]) and entityName(target.id) or nil);

                if (spiker ~= nil) then
                    creditDamage(spiker, 'Spikes', res.reactValue, false);
                end

                if (tracked[act.actor] ~= nil) then
                    creditTaken(tracked[act.actor], targetName or entityName(target.id), res.reactValue);
                end
            end
        end
    end
end

ashita.events.register('packet_in', 'dwparse_packet_in', function (e)
    if (e.id == 0x0028) then
        if (state.paused[1]) then
            return;
        end

        -- Decoding is pcall'd per packet: one malformed action must cost that
        -- action, not the addon. Nothing is ever blocked from here.
        local ok, act = pcall(parseActionPacket, e.data);

        if (ok and act ~= nil) then
            pcall(handleAction, act);
        end

        return;
    end

    -- A zone line deliberately clears NOTHING -- surviving it is the point.
    -- But a login can be a different character, whose parse this is not, so
    -- the name is checked once the party list has had a moment to fill in.
    if (e.id == 0x000A) then
        trackedCache.at = 0;
        playerIdCache   = {};

        state.charCheckAt = os.clock() + 3.0;
    end
end);

--[[
* Formatting.
--]]
local function comma(n)
    local s    = tostring(math.floor(n));
    local left = s;
    local out  = '';

    while (#left > 3) do
        out  = ',' .. left:sub(-3) .. out;
        left = left:sub(1, -4);
    end

    return left .. out;
end

local function clockText(seconds)
    seconds = math.max(math.floor(seconds), 0);

    if (seconds >= 3600) then
        return string.format('%d:%02d:%02d', math.floor(seconds / 3600), math.floor(seconds / 60) % 60, seconds % 60);
    end

    return string.format('%02d:%02d', math.floor(seconds / 60), seconds % 60);
end

-- Combat time: first event to last event, never less than a second so an
-- opening round does not divide by nothing.
local function combatSeconds()
    if (parse.startedAt == nil) then
        return 0;
    end

    return math.max(parse.lastAt - parse.startedAt, 1);
end

local function dps(total)
    local seconds = combatSeconds();

    if (seconds == 0) then
        return 0;
    end

    return total / seconds;
end

local function recentDps(row)
    pruneRecent(row, os.clock());

    if (row.recentSum <= 0) then
        return 0;
    end

    local span = RECENT_WINDOW;

    if (parse.startedAt ~= nil) then
        span = math.min(span, math.max(os.clock() - parse.startedAt, 1));
    end

    return row.recentSum / span;
end

-- Melee + ranged accuracy, the number the Accuracy column shows. Shadows
-- count as connected -- the swing was true, the mob just had Utsusemi up.
local function accuracy(row)
    local attempts = 0;
    local landed   = 0;

    for _, key in ipairs({ 'Melee', 'Ranged' }) do
        local b = row.actions[key];

        if (b ~= nil) then
            attempts = attempts + b.count;
            landed   = landed + b.landed + b.shadows;
        end
    end

    if (attempts == 0) then
        return nil;
    end

    return 100 * landed / attempts;
end

--[[
* `metric` decides who APPEARS; `sortKey` decides the order. They are the same
* thing for every caller but one, so sortKey defaults to metric and nothing
* else changes.
*
* The exception is the Taken tab. metricTaken deliberately counts evades,
* shadows and HP healed so a tank who avoided everything still shows up --
* which is right for INCLUSION and wrong for RANK, because that tab prints
* row.taken.total and nothing else. A row that took 200 damage and evaded
* forty swings outranked one that took 2,000, and the list read as though the
* numbers beside it were out of order.
--]]
local function sortedBy(metric, sortKey)
    sortKey = sortKey or metric;

    local rows = {};

    for _, row in pairs(parse.actors) do
        if (metric(row) > 0) then
            rows[#rows + 1] = row;
        end
    end

    table.sort(rows, function (a, b)
        local am, bm = sortKey(a), sortKey(b);

        if (am == bm) then
            return a.name < b.name;
        end

        return am > bm;
    end);

    return rows;
end

local metricDmg   = function (row) return row.dmg.total; end
local metricHeal  = function (row) return row.heal.total + row.heal.mp; end
local metricTaken = function (row) return row.taken.total + row.taken.evades + row.taken.shadows + row.taken.healed; end

-- The Taken tab's RANKING key: the one number that tab actually prints.
local metricTakenDmg = function (row) return row.taken.total; end

local function grandTotal(rows, metric)
    local total = 0;

    for _, row in ipairs(rows) do
        total = total + metric(row);
    end

    return total;
end

--[[
* Export: the current tab, spoken into the chosen channel one throttled line
* at a time. Short lines on purpose -- chat has a byte budget and a nine-line
* wall of numbers is already pushing hospitality.
--]]
local function exportTab()
    local prefix = CHANNELS[state.channel].prefix;
    local lines  = T{ };

    if (state.tab == 'heal') then
        local rows  = sortedBy(metricHeal);
        local total = grandTotal(rows, function (r) return r.heal.total; end);

        lines:append(string.format('Healing %s: %s HP total', clockText(combatSeconds()), comma(total)));

        for rank = 1, math.min(#rows, 8) do
            local row = rows[rank];
            local pct = total > 0 and (100 * row.heal.total / total) or 0;

            lines:append(string.format('%d. %s %s (%.1f%%) max %s%s',
                rank, row.name, comma(row.heal.total), pct, comma(row.heal.max),
                row.heal.mp > 0 and string.format(', %s MP', comma(row.heal.mp)) or ''));
        end
    elseif (state.tab == 'taken') then
        local rows = sortedBy(metricTaken, metricTakenDmg);

        lines:append(string.format('Damage taken %s:', clockText(combatSeconds())));

        for rank = 1, math.min(#rows, 8) do
            local row = rows[rank];

            lines:append(string.format('%d. %s %s over %d hits, max %s (%s)',
                rank, row.name, comma(row.taken.total), row.taken.hits,
                comma(row.taken.max), row.taken.maxLabel));
        end
    else
        local rows  = sortedBy(metricDmg);
        local total = grandTotal(rows, metricDmg);

        lines:append(string.format('Parse %s: %s damage total', clockText(combatSeconds()), comma(total)));

        for rank = 1, math.min(#rows, 8) do
            local row = rows[rank];
            local pct = total > 0 and (100 * row.dmg.total / total) or 0;

            lines:append(string.format('%d. %s %s (%.1f%%) %s DPS, max %s',
                rank, row.name, comma(row.dmg.total), pct,
                comma(dps(row.dmg.total)), comma(row.dmg.max)));
        end
    end

    if (#lines <= 1) then
        state.status    = 'Nothing to export yet.';
        state.statusBad = true;

        return;
    end

    for _, line in ipairs(lines) do
        issue(prefix .. line);
    end

    state.status    = string.format('Exporting %d lines to %s...', #lines, CHANNELS[state.channel].label);
    state.statusBad = false;
end

local function resetParse(reason)
    parse           = freshParse();
    state.selected  = nil;
    state.status    = reason or 'Parse cleared.';
    state.statusBad = false;
end

--[[
* Rendering. The shell -- theme push/pop and Begin/End outside a pcall'd
* body, one reported error, window closes itself -- is the dwbags shell,
* because it is the shape that survives a bad frame.
--]]
local function drawShareBar(fraction, pct)
    -- 22 tall rather than 14: the overlay percentage is drawn at the font's
    -- full line height, so a shorter bar clipped it top and bottom.
    imgui.ProgressBar(fraction, { 96, 22 }, string.format('%.1f%%', pct));
end

local function detailPane()
    local row = state.selected ~= nil and parse.actors[state.selected] or nil;

    if (row == nil) then
        imgui.TextDisabled('Click a name for its breakdown.');

        return;
    end

    if (state.tab == 'heal') then
        imgui.Text(string.format('%s - %s HP healed', row.name, comma(row.heal.total)));

        if (row.heal.mp > 0) then
            imgui.SameLine();
            imgui.TextDisabled(string.format('  %s MP restored', comma(row.heal.mp)));
        end

        if (imgui.BeginTable('##dwparse_healdetail', 5,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                        ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
            imgui.TableSetupColumn('Action', ImGuiTableColumnFlags_WidthFixed, 180, 0);
            imgui.TableSetupColumn('Casts', ImGuiTableColumnFlags_WidthFixed, 60, 0);
            imgui.TableSetupColumn('Total', ImGuiTableColumnFlags_WidthFixed, 90, 0);
            imgui.TableSetupColumn('Avg', ImGuiTableColumnFlags_WidthFixed, 70, 0);
            imgui.TableSetupColumn('Max', ImGuiTableColumnFlags_WidthFixed, 70, 0);
            imgui.TableSetupScrollFreeze(0, 1);
            imgui.TableHeadersRow();

            local labels = {};

            for label in pairs(row.heals) do
                labels[#labels + 1] = label;
            end

            table.sort(labels, function (a, b) return row.heals[a].total > row.heals[b].total; end);

            for _, label in ipairs(labels) do
                local b = row.heals[label];

                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(label);
                imgui.TableNextColumn();
                imgui.Text(tostring(b.count));
                imgui.TableNextColumn();
                imgui.Text(comma(b.total));
                imgui.TableNextColumn();
                imgui.Text(comma(b.total / math.max(b.count, 1)));
                imgui.TableNextColumn();
                imgui.Text(comma(b.max));
            end

            imgui.EndTable();
        end

        return;
    end

    if (state.tab == 'taken') then
        imgui.Text(string.format('%s - %s taken over %d hits', row.name, comma(row.taken.total), row.taken.hits));
        imgui.SameLine();
        imgui.TextDisabled(string.format('  evaded %d, shadows %d, healed for %s',
            row.taken.evades, row.taken.shadows, comma(row.taken.healed)));

        if (imgui.BeginTable('##dwparse_takendetail', 5,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                        ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
            imgui.TableSetupColumn('From', ImGuiTableColumnFlags_WidthFixed, 180, 0);
            imgui.TableSetupColumn('Hits', ImGuiTableColumnFlags_WidthFixed, 60, 0);
            imgui.TableSetupColumn('Total', ImGuiTableColumnFlags_WidthFixed, 90, 0);
            imgui.TableSetupColumn('Avg', ImGuiTableColumnFlags_WidthFixed, 70, 0);
            imgui.TableSetupColumn('Max', ImGuiTableColumnFlags_WidthFixed, 70, 0);
            imgui.TableSetupScrollFreeze(0, 1);
            imgui.TableHeadersRow();

            local labels = {};

            for label in pairs(row.sources) do
                labels[#labels + 1] = label;
            end

            table.sort(labels, function (a, b) return row.sources[a].total > row.sources[b].total; end);

            for _, label in ipairs(labels) do
                local b = row.sources[label];

                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(label);
                imgui.TableNextColumn();
                imgui.Text(tostring(b.count));
                imgui.TableNextColumn();
                imgui.Text(comma(b.total));
                imgui.TableNextColumn();
                imgui.Text(comma(b.total / math.max(b.count, 1)));
                imgui.TableNextColumn();
                imgui.Text(comma(b.max));
            end

            imgui.EndTable();
        end

        return;
    end

    imgui.Text(string.format('%s - %s damage', row.name, comma(row.dmg.total)));
    imgui.SameLine();
    imgui.TextDisabled(string.format('  max %s (%s)', comma(row.dmg.max), row.dmg.maxLabel));

    if (imgui.BeginTable('##dwparse_dmgdetail', 7,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Action', ImGuiTableColumnFlags_WidthFixed, 180, 0);
        imgui.TableSetupColumn('Tries', ImGuiTableColumnFlags_WidthFixed, 52, 0);
        imgui.TableSetupColumn('Hits', ImGuiTableColumnFlags_WidthFixed, 52, 0);
        imgui.TableSetupColumn('Total', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        imgui.TableSetupColumn('Avg', ImGuiTableColumnFlags_WidthFixed, 70, 0);
        imgui.TableSetupColumn('Max', ImGuiTableColumnFlags_WidthFixed, 70, 0);
        imgui.TableSetupColumn('Notes', ImGuiTableColumnFlags_WidthFixed, 130, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        local labels = {};

        for label in pairs(row.actions) do
            labels[#labels + 1] = label;
        end

        table.sort(labels, function (a, b) return row.actions[a].total > row.actions[b].total; end);

        for _, label in ipairs(labels) do
            local b     = row.actions[label];
            local notes = T{ };

            if (b.crits > 0) then
                notes:append(string.format('%.0f%% crit', 100 * b.crits / math.max(b.landed, 1)));
            end

            if (b.shadows > 0) then
                notes:append(string.format('%d shadowed', b.shadows));
            end

            if (b.resists > 0) then
                notes:append(string.format('%d resisted', b.resists));
            end

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(label);
            imgui.TableNextColumn();
            imgui.Text(tostring(b.count));
            imgui.TableNextColumn();
            imgui.Text(tostring(b.landed));
            imgui.TableNextColumn();
            imgui.Text(comma(b.total));
            imgui.TableNextColumn();
            imgui.Text(comma(b.total / math.max(b.landed, 1)));
            imgui.TableNextColumn();
            imgui.Text(comma(b.max));
            imgui.TableNextColumn();
            imgui.Text(notes:concat(', '));
        end

        imgui.EndTable();
    end
end

local function nameCell(row)
    if (imgui.Selectable(row.name .. '##sel_' .. row.name, state.selected == row.name)) then
        state.selected = (state.selected == row.name) and nil or row.name;
    end
end

local function damageTab()
    local rows  = sortedBy(metricDmg);
    local total = grandTotal(rows, metricDmg);
    local top   = #rows > 0 and rows[1].dmg.total or 0;

    if (imgui.BeginTable('##dwparse_dmg', 8,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -160 })) then
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 24, 0);
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthFixed, 150, 0);
        imgui.TableSetupColumn('Damage', ImGuiTableColumnFlags_WidthFixed, 84, 0);
        imgui.TableSetupColumn('DPS', ImGuiTableColumnFlags_WidthFixed, 62, 0);
        imgui.TableSetupColumn('30s', ImGuiTableColumnFlags_WidthFixed, 62, 0);
        imgui.TableSetupColumn('Share', ImGuiTableColumnFlags_WidthFixed, 104, 0);
        imgui.TableSetupColumn('Acc', ImGuiTableColumnFlags_WidthFixed, 52, 0);
        imgui.TableSetupColumn('Max', ImGuiTableColumnFlags_WidthFixed, 76, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for rank, row in ipairs(rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(tostring(rank));

            imgui.TableNextColumn();
            nameCell(row);

            imgui.TableNextColumn();
            imgui.Text(comma(row.dmg.total));

            imgui.TableNextColumn();
            imgui.Text(comma(dps(row.dmg.total)));

            imgui.TableNextColumn();
            local recent = recentDps(row);

            if (recent > 0) then
                imgui.Text(comma(recent));
            else
                imgui.TextDisabled('-');
            end

            imgui.TableNextColumn();
            drawShareBar(top > 0 and (row.dmg.total / top) or 0,
                total > 0 and (100 * row.dmg.total / total) or 0);

            imgui.TableNextColumn();
            local acc = accuracy(row);

            if (acc ~= nil) then
                imgui.Text(string.format('%.0f%%', acc));
            else
                imgui.TextDisabled('-');
            end

            imgui.TableNextColumn();
            imgui.Text(comma(row.dmg.max));

            if (imgui.IsItemHovered() and row.dmg.maxLabel ~= '') then
                imgui.SetTooltip(row.dmg.maxLabel);
            end
        end

        imgui.EndTable();
    end

    imgui.BeginChild('##dwparse_dmgdetailpane', { 0, 0 }, ImGuiChildFlags_Borders);
    detailPane();
    imgui.EndChild();
end

local function healingTab()
    local rows  = sortedBy(metricHeal);
    local total = grandTotal(rows, function (r) return r.heal.total; end);

    -- The LARGEST heal.total, not the first row's: rows are ordered by
    -- HP + MP restored, so an MP restorer with zero cures can sit first --
    -- and a `top` of its 0 (clamped to 1) drew every healer below it as a
    -- full-width bar with a mismatched percentage beside it.
    local top = 1;

    for _, row in ipairs(rows) do
        if (row.heal.total > top) then
            top = row.heal.total;
        end
    end

    if (imgui.BeginTable('##dwparse_heal', 7,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -160 })) then
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 24, 0);
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthFixed, 150, 0);
        imgui.TableSetupColumn('Healing', ImGuiTableColumnFlags_WidthFixed, 84, 0);
        imgui.TableSetupColumn('HPS', ImGuiTableColumnFlags_WidthFixed, 62, 0);
        imgui.TableSetupColumn('Share', ImGuiTableColumnFlags_WidthFixed, 104, 0);
        imgui.TableSetupColumn('MP', ImGuiTableColumnFlags_WidthFixed, 76, 0);
        imgui.TableSetupColumn('Max', ImGuiTableColumnFlags_WidthFixed, 76, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for rank, row in ipairs(rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(tostring(rank));

            imgui.TableNextColumn();
            nameCell(row);

            imgui.TableNextColumn();
            imgui.Text(comma(row.heal.total));

            imgui.TableNextColumn();
            imgui.Text(comma(dps(row.heal.total)));

            imgui.TableNextColumn();
            drawShareBar(row.heal.total / top, total > 0 and (100 * row.heal.total / total) or 0);

            imgui.TableNextColumn();

            if (row.heal.mp > 0) then
                imgui.Text(comma(row.heal.mp));
            else
                imgui.TextDisabled('-');
            end

            imgui.TableNextColumn();
            imgui.Text(comma(row.heal.max));

            if (imgui.IsItemHovered() and row.heal.maxLabel ~= '') then
                imgui.SetTooltip(row.heal.maxLabel);
            end
        end

        imgui.EndTable();
    end

    imgui.BeginChild('##dwparse_healdetailpane', { 0, 0 }, ImGuiChildFlags_Borders);
    detailPane();
    imgui.EndChild();
end

local function takenTab()
    -- Ranked by the number the table prints (the export already does this;
    -- the on-screen table was the copy the fix missed): metricTaken decides
    -- who appears, metricTakenDmg decides the order.
    local rows = sortedBy(metricTaken, metricTakenDmg);

    if (imgui.BeginTable('##dwparse_taken', 7,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -160 })) then
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthFixed, 150, 0);
        imgui.TableSetupColumn('Taken', ImGuiTableColumnFlags_WidthFixed, 84, 0);
        imgui.TableSetupColumn('Hits', ImGuiTableColumnFlags_WidthFixed, 52, 0);
        imgui.TableSetupColumn('Avg', ImGuiTableColumnFlags_WidthFixed, 70, 0);
        imgui.TableSetupColumn('Max', ImGuiTableColumnFlags_WidthFixed, 76, 0);
        imgui.TableSetupColumn('Evade/Shadow', ImGuiTableColumnFlags_WidthFixed, 96, 0);
        imgui.TableSetupColumn('Healed for', ImGuiTableColumnFlags_WidthFixed, 84, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            nameCell(row);

            imgui.TableNextColumn();
            imgui.Text(comma(row.taken.total));

            imgui.TableNextColumn();
            imgui.Text(tostring(row.taken.hits));

            imgui.TableNextColumn();
            imgui.Text(comma(row.taken.total / math.max(row.taken.hits, 1)));

            imgui.TableNextColumn();
            imgui.Text(comma(row.taken.max));

            if (imgui.IsItemHovered() and row.taken.maxLabel ~= '') then
                imgui.SetTooltip('From ' .. row.taken.maxLabel);
            end

            imgui.TableNextColumn();
            imgui.Text(string.format('%d / %d', row.taken.evades, row.taken.shadows));

            imgui.TableNextColumn();
            imgui.Text(comma(row.taken.healed));
        end

        imgui.EndTable();
    end

    imgui.BeginChild('##dwparse_takendetailpane', { 0, 0 }, ImGuiChildFlags_Borders);
    detailPane();
    imgui.EndChild();
end

local function renderWindow()
    if (imgui.Button('Reset')) then
        resetParse();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Clear the parse back to zero. Zoning and squad recalls never clear it; only this does.');
    end

    imgui.SameLine();
    imgui.Checkbox('Pause', state.paused);

    imgui.SameLine();
    imgui.Checkbox('Party only', state.partyOnly);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Track only the party and its pets. Untick to track every actor in range, mobs included.\nRows already earned stay either way.');
    end

    imgui.SameLine();
    imgui.PushItemWidth(90);

    if (imgui.BeginCombo('##dwparse_channel', CHANNELS[state.channel].label)) then
        for index, channel in ipairs(CHANNELS) do
            if (imgui.Selectable(channel.label, state.channel == index)) then
                state.channel = index;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.Button('Export')) then
        exportTab();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Speak the tab on screen into the chosen channel, one line at a time.');
    end

    imgui.SameLine();

    if (parse.startedAt ~= nil) then
        imgui.TextDisabled(string.format('%s combat%s%s',
            clockText(combatSeconds()),
            state.paused[1] and '  [paused]' or '',
            #queue > 0 and string.format('  %d queued...', #queue) or ''));
    else
        imgui.TextDisabled(state.paused[1] and '[paused]' or 'waiting for combat');
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Separator();

    if (imgui.BeginTabBar('##dwparse_tabs')) then
        if (imgui.BeginTabItem('Damage')) then
            state.tab = 'dmg';
            damageTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Healing')) then
            state.tab = 'heal';
            healingTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Taken')) then
            state.tab = 'taken';
            takenTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

ashita.events.register('d3d_present', 'dwparse_present', function ()
    -- Before the visibility check: an export issued a moment before the
    -- window was closed still has to reach the party.
    pumpQueue();

    -- The character check armed by the last zone-in: a different name on
    -- party slot 0 means a different account view, and their parse should
    -- not inherit this one.
    if (state.charCheckAt ~= nil and os.clock() >= state.charCheckAt) then
        local party = AshitaCore:GetMemoryManager():GetParty();
        local name  = party ~= nil and party:GetMemberName(0) or '';

        if (name ~= nil and name ~= '') then
            if (state.charName ~= nil and name ~= state.charName) then
                resetParse('New character - parse cleared.');
            end

            state.charName    = name;
            state.charCheckAt = nil;
        else
            state.charCheckAt = os.clock() + 2.0;
        end
    end

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 660, 480 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Parse##dwparse', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwparse'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwparse'):append(chat.message('Window closed. The parse itself is intact; /parse reopens it.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

-- Anything the player types counts against the client's chat rate limit, so
-- an export queued behind a typed line waits its interval instead of racing
-- it and being the one that gets dropped.
ashita.events.register('packet_out', 'dwparse_packet_out', function (e)
    if (e.id == 0x00B5) then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwparse_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwparse' and args[1] ~= '/parse' and args[1] ~= '/dwp')) then
        return;
    end

    e.blocked = true;

    local verb = (#args > 1) and args[2]:lower() or '';

    if (verb == 'reset' or verb == 'clear') then
        resetParse();
        print(chat.header('dwparse'):append(chat.message('Parse cleared.')));

        return;
    end

    if (verb == 'pause') then
        state.paused[1] = not state.paused[1];
        print(chat.header('dwparse'):append(chat.message('Parsing is now ')):append(chat.success(state.paused[1] and 'paused' or 'running')):append(chat.message('.')));

        return;
    end

    if (verb == 'export') then
        if (#args > 2) then
            local wanted = args[3]:lower();

            for index, channel in ipairs(CHANNELS) do
                if (channel.label:lower():sub(1, #wanted) == wanted) then
                    state.channel = index;
                end
            end
        end

        exportTab();

        return;
    end

    if (verb == 'help') then
        print(chat.header('dwparse'):append(chat.message('/parse toggles the window. Subcommands: reset, pause, export [party|say|linkshell|echo].')));

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too.
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwparse_load', function ()
    state.charCheckAt = os.clock() + 3.0;

    print(chat.header('dwparse'):append(chat.message('/parse (or /dwparse) opens the parser. It keeps counting across zones and squad recalls; Reset starts it over.')));
end);
