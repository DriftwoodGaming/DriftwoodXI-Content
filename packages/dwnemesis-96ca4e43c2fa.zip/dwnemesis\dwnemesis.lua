--[[
* DriftwoodXI -- dwnemesis
*
* Nemesis in a window: a hundred famous notorious monsters, each fought in a
* private arena at its wild level +100 (capped for now), listed by tier with
* the fee per player, your own kills / best time / drops / Mercy meter on
* every row, a marker on each monster whose four-augment drop nobody on the
* server has claimed yet, and an Enter button per row that warps your whole
* party in. On the kill a chest stands up and every real player opens it
* once for their own roll of the monster's real drop table; gear comes with
* one to four random augments and is account-bound.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited
* whole). The roster ships inside it (roster.lua, GENERATED from the server's
* own dumps -- never edit by hand); everything that changes arrives on the
* wire as records, and every button is a real typed command (`!dwd enter 12`
* reaches exactly the dispatch `!nemesis enter 12` reaches). The server gates
* entry, charges the fee and rolls the chest; this window can never do
* anything a player cannot.
*
* TURN IT OFF AND NOTHING IS LOST. `!nemesis` (or `!nem`) does all of it
* typed, and /port or !home leave the arena from inside exactly like the
* button.
--]]

addon.name    = 'dwnemesis';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.0';
addon.desc    = 'DriftwoodXI Nemesis: famous NMs at +100 in a private arena, personal chest, augmented drops.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- The roster, generated beside this file. A missing or broken copy renders
-- an honest empty board rather than a crash.
local rosterOk, roster = pcall(require, 'roster');

if (not rosterOk or type(roster) ~= 'table' or type(roster.rows) ~= 'table') then
    roster = { hash = '', rows = {} };
end

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line.
local DATA_SENDER = '_DWDDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

local TIER_NAMES = { 'Field', 'Dungeon', 'Legend' };
local VENUE_NAMES = { 'Throne Room', 'Chamber of Oracles', 'Sacrificial Chamber' };
local MERCY_STACKS = 8;

local state = T{
    open      = T{ false },
    tab       = 1,          -- 1..3 the tiers, 4 the ledger

    -- The board, COMMITTED ON z| from pending copies so a half-arrived reply
    -- can never half-fill the window.
    hash      = nil,        -- the server's roster hash
    venues    = nil,        -- { [venue] = { busy1, busy2, busy3 } }
    tiers     = {},         -- { [tier] = { gil, testimonies, lockoutHours, rankCap, ceiling } }
    ledger    = {},         -- { [idx] = { kills, best, drops, mercy, four } }
    unclaimed = {},         -- { [idx] = true }
    syncedAt  = nil,

    pending   = nil,        -- the in-flight status reply

    inbound   = nil,        -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame

    -- The answer clock, per read (the dwfame shape): one retry after five
    -- seconds, then the silent latch.
    requested    = nil,     -- { at, tries }
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until the
    -- zone line re-probes it.
    refused   = false,

    enterAt   = 0,
};

--[[
* Outbound: `!dwd` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local function askStatus()
    if (state.refused or state.serverSilent) then
        return;
    end

    state.requested = { at = os.clock(), tries = 1 };

    issue('!dwd status');
end

local function checkAnswers()
    local asked = state.requested;

    if (asked == nil or not echo.canSend()) then
        return;
    end

    if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
        return;
    end

    if (asked.tries >= ANSWER_TRIES) then
        state.requested    = nil;
        state.serverSilent = true;
        state.status       = 'No answer from the server. Is DriftwoodXI up to date?';
        state.statusBad    = true;

        return;
    end

    asked.at    = os.clock();
    asked.tries = asked.tries + 1;

    issue('!dwd status');
end

--[[
* Record parsing (dwd protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            print(chat.header('dwnemesis'):append(chat.error(string.format(
                'server protocol %d, addon expects %d. Update dwnemesis through the launcher.',
                version, PROTOCOL))));

            return;
        end

        state.requested    = nil;
        state.serverSilent = false;

        state.inbound = parts[3];

        if (state.inbound == 'status') then
            state.pending = { hash = nil, venues = {}, tiers = {}, ledger = {}, unclaimed = {} };
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwnemesis'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    local pending = state.pending;

    -- h| -- the server's roster hash.
    if (kind == 'h' and pending ~= nil) then
        pending.hash = parts[2] or '';

        return;
    end

    -- a| -- one venue's three areas, busy flags.
    if (kind == 'a' and pending ~= nil) then
        local venue = tonumber(parts[2]) or 0;

        if (venue >= 1 and venue <= 3) then
            pending.venues[venue] = {
                (tonumber(parts[3]) or 0) ~= 0,
                (tonumber(parts[4]) or 0) ~= 0,
                (tonumber(parts[5]) or 0) ~= 0,
            };
        end

        return;
    end

    -- t| -- one tier's terms.
    if (kind == 't' and pending ~= nil) then
        local tier = tonumber(parts[2]) or 0;

        if (tier >= 1 and tier <= 3) then
            pending.tiers[tier] = {
                gil          = tonumber(parts[3]) or 0,
                testimonies  = tonumber(parts[4]) or 0,
                lockoutHours = tonumber(parts[5]) or 0,
                rankCap      = tonumber(parts[6]) or 0,
                ceiling      = tonumber(parts[7]) or 0,
            };
        end

        return;
    end

    -- l| -- ledger entries, several per line: idx:kills:best:drops:mercy:four
    if (kind == 'l' and pending ~= nil) then
        for field = 2, #parts do
            local bits = split(parts[field], ':');
            local idx  = tonumber(bits[1]) or 0;

            if (idx > 0) then
                pending.ledger[idx] = {
                    kills = tonumber(bits[2]) or 0,
                    best  = tonumber(bits[3]) or 0,
                    drops = tonumber(bits[4]) or 0,
                    mercy = tonumber(bits[5]) or 0,
                    four  = tonumber(bits[6]) or 0,
                };
            end
        end

        return;
    end

    -- u| -- the unclaimed set, comma-packed, possibly over several lines.
    if (kind == 'u' and pending ~= nil) then
        for _, piece in ipairs(split(parts[2] or '', ',')) do
            local idx = tonumber(piece) or 0;

            if (idx > 0) then
                pending.unclaimed[idx] = true;
            end
        end

        return;
    end

    -- k| -- the enter acknowledgement; the zone line re-probes everything.
    if (kind == 'k') then
        state.status    = 'Your nemesis awaits.';
        state.statusBad = false;

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        if (closed == 'status' and pending ~= nil) then
            state.hash      = pending.hash;
            state.venues    = pending.venues;
            state.tiers     = pending.tiers;
            state.ledger    = pending.ledger;
            state.unclaimed = pending.unclaimed;
            state.syncedAt  = os.clock();
            state.pending   = nil;
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwnemesis_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwnemesis'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line invalidates the whole picture and re-probes both latches.
    if (e.id == 0x000A) then
        state.requested    = nil;
        state.serverSilent = false;
        state.refused      = false;
        state.venues       = nil;
        state.syncedAt     = nil;
    end
end);

--[[
* Rendering.
--]]
local function fmtGil(amount)
    local text = tostring(math.floor(amount or 0));
    local out  = '';

    while (#text > 3) do
        out  = ',' .. text:sub(-3) .. out;
        text = text:sub(1, -4);
    end

    return text .. out;
end

local function itemName(row)
    local ok, name = pcall(function()
        local res = AshitaCore:GetResourceManager():GetItemById(row.sigItem);

        return res and res.Name and res.Name[1] or nil;
    end);

    if (ok and name ~= nil and name ~= '') then
        return name;
    end

    return row.sig;
end

local function hashMismatch()
    return state.hash ~= nil and roster.hash ~= '' and state.hash ~= roster.hash;
end

local function busyTotal()
    local busy, total = 0, 0;

    for venue = 1, 3 do
        local areas = state.venues and state.venues[venue] or nil;

        for area = 1, 3 do
            total = total + 1;

            if (areas ~= nil and areas[area]) then
                busy = busy + 1;
            end
        end
    end

    return busy, total;
end

local function renderHeader()
    if (imgui.Button('Refresh##dwd_refresh')) then
        askStatus();
    end

    imgui.SameLine();

    if (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server.');
    elseif (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwnemesis through the launcher.');
    elseif (hashMismatch()) then
        imgui.TextColored(theme.colors.err, 'This addon\'s roster is not the server\'s. Update dwnemesis before entering.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or state.requested ~= nil) then
        imgui.TextDisabled('asking...');
    else
        imgui.TextDisabled('One monster. One chest. Your roll.');
    end

    if (state.venues ~= nil) then
        local busy, total = busyTotal();

        imgui.Text(string.format('%d of %d arenas running', busy, total));

        for venue = 1, 3 do
            local areas = state.venues[venue] or {};
            local count = 0;

            for area = 1, 3 do
                if (areas[area]) then
                    count = count + 1;
                end
            end

            imgui.SameLine();
            imgui.TextColored(count >= 3 and theme.colors.warn or theme.colors.dim,
                string.format('  %s %d/3', VENUE_NAMES[venue], count));
        end
    else
        imgui.TextDisabled('Waiting for the board...');
    end

    imgui.Separator();
end

local function renderTierRows(tier)
    local terms = state.tiers[tier];

    if (terms ~= nil) then
        imgui.TextWrapped(string.format('%s tier -- %s gil and %d different Job Testimon%s per player. Arena level = wild + 100, capped at %d. Augment ranks up to %d.%s',
            TIER_NAMES[tier], fmtGil(terms.gil), terms.testimonies, terms.testimonies == 1 and 'y' or 'ies',
            terms.ceiling, terms.rankCap,
            terms.lockoutHours > 0 and string.format(' One fight per monster per account every %d hours.', terms.lockoutHours) or ''));
    else
        imgui.TextDisabled(string.format('%s tier -- terms arrive with the board.', TIER_NAMES[tier]));
    end

    imgui.Separator();

    local canEnter = state.venues ~= nil and not hashMismatch() and not state.refused;

    if (imgui.BeginTable('dwd_rows_' .. tier, 6, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Monster', ImGuiTableColumnFlags_None, 3.2);
        imgui.TableSetupColumn('Level', ImGuiTableColumnFlags_None, 1.4);
        imgui.TableSetupColumn('Signature drop', ImGuiTableColumnFlags_None, 3.0);
        imgui.TableSetupColumn('You', ImGuiTableColumnFlags_None, 2.4);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_None, 1.2);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_None, 1.0);
        imgui.TableHeadersRow();

        for _, row in ipairs(roster.rows) do
            if (row.tier == tier) then
                local entry   = state.ledger[row.idx];
                local ceiling = terms ~= nil and terms.ceiling or 175;

                imgui.TableNextRow();

                imgui.TableNextColumn();
                imgui.Text(row.name);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('%s -- wild level %d', row.zoneName, row.level));
                end

                imgui.TableNextColumn();
                imgui.Text(string.format('%d -> %d', row.level, math.min(row.level + 100, ceiling)));

                imgui.TableNextColumn();
                imgui.Text(string.format('%s %d%%', itemName(row), math.floor(row.sigRate / 10)));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(row.sigGear
                        and 'Table rate at TH 0, before the server\'s drop multiplier. Gear rolls 1-4 augments.'
                        or 'Table rate at TH 0, before the server\'s drop multiplier. Drops plain.');
                end

                imgui.TableNextColumn();

                if (entry ~= nil) then
                    imgui.Text(string.format('%dk %dd %s', entry.kills, entry.drops,
                        entry.best > 0 and string.format('%d:%02d', math.floor(entry.best / 60), entry.best % 60) or '--'));

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(string.format('%d kills, %d gear drops, %d four-augment finds, best %ds, Mercy %d of %d.',
                            entry.kills, entry.drops, entry.four, entry.best, entry.mercy, MERCY_STACKS));
                    end
                else
                    imgui.TextDisabled('--');
                end

                imgui.TableNextColumn();

                if (state.unclaimed[row.idx]) then
                    imgui.TextColored(theme.colors.warn, 'unclaimed');

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('Nobody on the server has taken a four-augment drop from this one yet.');
                    end
                elseif (entry ~= nil and entry.four > 0) then
                    imgui.TextColored(theme.colors.ok, string.format('x%d', entry.four));
                end

                imgui.TableNextColumn();

                if (canEnter) then
                    if (imgui.SmallButton('Enter##dwd_enter_' .. row.idx)) then
                        -- Debounced BEYOND the queue's dupe-collapse (the
                        -- arena's lesson): one enter per five seconds.
                        if (os.clock() - (state.enterAt or 0) > 5.0) then
                            state.enterAt = os.clock();

                            issue('!dwd enter ' .. row.idx);

                            state.status    = 'Entering...';
                            state.statusBad = false;
                        end
                    end

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('Charges every real player in your party and warps you all in. The server checks everyone first.');
                    end
                else
                    imgui.TextDisabled('--');
                end
            end
        end

        imgui.EndTable();
    end
end

local function renderLedger()
    local kills, drops, four, fought = 0, 0, 0, 0;

    for _, entry in pairs(state.ledger) do
        kills  = kills + entry.kills;
        drops  = drops + entry.drops;
        four   = four + entry.four;
        fought = fought + 1;
    end

    imgui.Text(string.format('%d kills, %d gear drops, %d four-augment finds across %d monsters.', kills, drops, four, fought));
    imgui.Separator();

    if (fought == 0) then
        imgui.TextDisabled('Nothing yet. Pick a monster on a tier tab.');

        return;
    end

    if (imgui.BeginTable('dwd_ledger', 6, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Monster', ImGuiTableColumnFlags_None, 3.0);
        imgui.TableSetupColumn('Kills', ImGuiTableColumnFlags_None, 1.0);
        imgui.TableSetupColumn('Best', ImGuiTableColumnFlags_None, 1.2);
        imgui.TableSetupColumn('Drops', ImGuiTableColumnFlags_None, 1.0);
        imgui.TableSetupColumn('Four', ImGuiTableColumnFlags_None, 1.0);
        imgui.TableSetupColumn('Mercy', ImGuiTableColumnFlags_None, 1.2);
        imgui.TableHeadersRow();

        for _, row in ipairs(roster.rows) do
            local entry = state.ledger[row.idx];

            if (entry ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(row.name);
                imgui.TableNextColumn();
                imgui.Text(tostring(entry.kills));
                imgui.TableNextColumn();
                imgui.Text(entry.best > 0 and string.format('%d:%02d', math.floor(entry.best / 60), entry.best % 60) or '--');
                imgui.TableNextColumn();
                imgui.Text(tostring(entry.drops));
                imgui.TableNextColumn();
                imgui.Text(tostring(entry.four));
                imgui.TableNextColumn();
                imgui.Text(string.format('%d/%d', entry.mercy, MERCY_STACKS));
            end
        end

        imgui.EndTable();
    end
end

local function renderWindow()
    renderHeader();

    if (imgui.BeginTabBar('dwd_tabs')) then
        for tier = 1, 3 do
            if (imgui.BeginTabItem(TIER_NAMES[tier] .. '##dwd_tab_' .. tier)) then
                state.tab = tier;
                renderTierRows(tier);
                imgui.EndTabItem();
            end
        end

        if (imgui.BeginTabItem('Ledger##dwd_tab_ledger')) then
            state.tab = 4;
            renderLedger();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    imgui.Separator();

    if (imgui.Button('Leave the arena##dwd_leave')) then
        issue('!dwd leave');
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Back to the tile you entered from. /port and !home work from inside too.');
    end
end

ashita.events.register('d3d_present', 'dwnemesis_present', function ()
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    -- The board is asked for LAZILY -- the first frame the window is
    -- actually open -- so a player who never opens it never handshakes.
    if (state.venues == nil and state.requested == nil
            and not state.serverSilent and not state.refused) then
        askStatus();
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 700, 480 }, ImGuiCond_FirstUseEver);

    local visible = imgui.Begin('DriftwoodXI Nemesis##dwnemesis', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwnemesis'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwnemesis'):append(chat.message('Window closed. Everything it shows also works typed as !nemesis.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwnemesis_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dwd') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwnemesis_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/nemesis' and first ~= '/dwnemesis') then
        return;
    end

    e.blocked = true;

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwnemesis_load', function ()
    print(chat.header('dwnemesis'):append(chat.message('/nemesis opens the Nemesis board. Everything it shows also works typed as !nemesis or !nem.')));
end);
