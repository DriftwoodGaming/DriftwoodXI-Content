--[[
* DriftwoodXI -- dwecho
*
* Swallows the client's local echo of the `!` commands a Driftwood addon
* sends, so the chat log stops showing the plumbing.
*
* WHAT THE PLAYER WAS SEEING. Lines like these, unprompted, for something
* they never typed -- two of them on every login before dwtracker was fixed
* on 2026-07-30, and a couple more every time somebody opened a window:
*
*     Blaster : !dwt hello
*     Blaster : !dwq bags 1
*
* It reads like a bug. On a login it is the first thing a new character sees.
*
* IT IS NOT A FAILED COMMAND, which is exactly what it looks like. That was
* checked properly rather than assumed: a `!` command the server does not
* recognise leaves TWO traces -- a `cmdhandler::call: Function does not
* exist` error in the map log AND a SAY row in the audit_chat table. Real
* leaks have that pair (`!gambits` and `!mercdebug` from earlier sessions do).
* The addon lines have neither, because the server took the commands and
* answered them. Nothing was ever broadcast.
*
* WHERE IT ACTUALLY COMES FROM. `QueueCommand(1, ...)` is CommandMode::Typed,
* "forward the command as if a player typed it" (Ashita.h, CommandMode). It
* has to be that: a `!` command IS a chat line -- that is the only way one
* reaches an LSB server -- so the suite sends them the way a player would.
* The client then renders the line locally, the way it renders anything you
* type. The server consumes the command instead of broadcasting it, so that
* local copy is never replaced or matched by a real say. One orphan line per
* command, and nothing upstream is wrong.
*
* THE MATCH IS DELIBERATELY NARROW, because the cost of a false positive is
* eating a player's chat. A line is swallowed only if it ENDS with a command
* string this addon put on the wire within the last few seconds, and each
* send is consumed by at most one line. The echo renders as `<name> : !dwq
* bags 1`, so the suffix test is exact against the part we control, and a
* passing mention ("!dwq bags 1 is broken") never matches. Worst case, a
* player types one of our commands by hand at the same moment and loses a
* duplicate echo of their own typing.
*
* USAGE -- two lines of setup, then send through here instead of the chat
* manager:
*
*     local echo = require('dwecho');
*     echo.install();
*
*     echo.send(command);   -- was AshitaCore:GetChatManager():QueueCommand(1, command)
*
* `send` is the whole point of the shape: recording and sending cannot drift
* apart if they are the same call. An addon that sends around it just keeps
* its echo, which is the old behaviour and harmless.
*
* A COPY PER ADDON FOLDER, exactly like dwtheme.lua, because an addon folder
* is the unit of distribution. `dwbags/dwecho.lua` is the master -- edit
* there and re-copy to the others. Each addon runs in its own Lua state, so
* each copy keeps its own table and its own handler; they never see each
* other's commands, which is what makes the narrow match safe.
*
* dwmacro does not carry this file. It is the one addon that never talks to
* the server -- no commands, no echo.
--]]

local echo = { };

-- Generous next to a 1.2s send interval and short enough that a stale entry
-- cannot sit around waiting to eat an unrelated line.
local WINDOW = 3.0;

-- command string -> os.clock() when it went out. A plain table: the keys are
-- arbitrary command text, and T{}'s sugar method names would shadow them.
local sent = { };

local installed = false;

--[[
* Put a command on the wire and remember it long enough to recognise its echo.
--]]
function echo.send(command)
    if (type(command) ~= 'string' or command == '') then
        return;
    end

    sent[command] = os.clock();

    AshitaCore:GetChatManager():QueueCommand(1, command);
end

--[[
* Register the one text_in handler. Idempotent -- calling it twice would
* otherwise register two handlers that both try to block the same line.
*
* Handlers that read the chat log for their own purposes (dwreport's report
* buffer) must skip lines where `e.blocked` is already set: a line the player
* never saw does not belong in a bug report either.
--]]
function echo.install()
    if (installed) then
        return;
    end

    installed = true;

    ashita.events.register('text_in', 'dwecho_text_in', function (e)
        if (e.blocked or e.message == nil) then
            return;
        end

        local line = e.message:gsub('[^\032-\126]', '');

        line = line:gsub('%s+$', '');

        if (line == '') then
            return;
        end

        local now = os.clock();

        -- Clearing the current key inside pairs() is the one table mutation
        -- Lua guarantees is safe, so the expiry sweep rides along with the
        -- search instead of needing a pass of its own.
        for command, at in pairs(sent) do
            if (now - at > WINDOW) then
                sent[command] = nil;
            elseif (#line >= #command and line:sub(-#command) == command) then
                sent[command] = nil;
                e.blocked = true;

                return;
            end
        end
    end);
end

return echo;
