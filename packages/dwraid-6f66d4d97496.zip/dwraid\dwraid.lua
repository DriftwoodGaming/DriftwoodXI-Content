--[[
* DriftwoodXI -- dwraid
*
* The raid board: the Trial of the Tidebound as a window -- your driftmark
* purse, the two tiers and what they pay, whether the arena is free, and
* the buttons that take you there. No orb, no travel: Enter gates your
* whole party where you stand (cities and safe zones only, the server's
* rule) and the server moves everyone. Leave puts you back on the exact
* tile you left.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no opinion about your purse, the tiers, or whether the arena is
* busy. The server answers `!dwx status` in compact records under the
* sender name _DWXDATA, which this addon parses and blocks before the chat
* log sees them; the payouts and the arena state ride the wire. Every
* button is a `!dwx` verb a player could type -- the server re-checks
* everything, so this window can do nothing a typed command cannot
* (the dwq.lua rule, inherited whole).
*
* TURN IT OFF AND NOTHING IS LOST. `!raid` typed in chat is the same
* answers in prose, and `!raid enter` is the same warp.
--]]

addon.name    = 'dwraid';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.0';
addon.desc    = 'Raid board for DriftwoodXI: the trial, the tiers, your driftmarks.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server
-- uses it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWXDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout -- never for an additive record.
local PROTOCOL = 1;

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged,
    -- so a stale row cannot survive a refresh (dwtracker's rule).
    purse     = nil,          -- { balance, earned, spent }
    arena     = nil,          -- { running, tier, minutes }
    tiers     = T{ },         -- [index] = { label, base, daily }
    ledger    = T{ },         -- { delta, age, reason }, newest first
    shop      = T{ },         -- [index] = { label, price }
    quote     = nil,          -- { index, price, until } -- the live quote, if any

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its
    -- own cannot half-fill the UI.
    inbound   = nil,
    building  = nil,          -- the next tiers/ledger, committed on z|
    status    = 'Waiting for the first sync.',
    statusBad = false,
    reported  = false,        -- a render error is worth saying once, not per frame

    -- A zone-in sync is deferred: 0x000A arrives while the client is still
    -- on the load screen, and a chat line sent there is a chat line lost.
    syncAt    = nil,
};

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. The client rate-limits outgoing chat and a !dwx command is a chat
* line; everything queues here and drains at one command per interval, with
* duplicates collapsed (dwbags' lesson, kept verbatim).
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking: a command can be lost on the way out, so an unanswered
* request is asked once more and then left alone. A PLAIN TABLE, NOT T{ }:
* keyed by verb names, and sugar-table method names shadowing a key cost
* dwbags a round once already.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

--[[
* True once this server has shown it does not speak dwraid -- either its
* own refusal arrived ("The raid is not loaded.") or a request went
* unanswered twice. An unknown !command on this server falls through to
* ordinary /say chat, so every auto-sync against a dead verb is the player
* PUBLICLY SAYING "!dwx status". While set, zone-in auto-syncs stop.
* Cleared by anything that proves the server speaks (a d| envelope) and by
* the player acting on purpose (window open, refresh).
--]]
local serverSilent = false;

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

local function ask(verb)
    requested[verb] = { at = os.clock(), answered = false, tries = 1 };

    issue('!dwx ' .. verb);
end

-- Re-ask an unanswered verb once; give up loudly after that. Called every
-- frame, window open or not.
local function checkAnswers()
    for verb, asked in pairs(requested) do
        if (not asked.answered and (os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue('!dwx ' .. verb);
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;
                serverSilent = true;

                state.status    = 'No answer from the server. Is DriftwoodXI up to date?';
                state.statusBad = true;
            end
        end
    end
end

local function requestStatus()
    ask('status');
    ask('shop');
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        -- An envelope is the server speaking dwraid, whatever it carries.
        serverSilent = false;

        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwraid through the launcher.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright: the lists build in
        -- `building` and commit on z|, so a reply cut off mid-flight can
        -- never leave the window half of one answer and half of another.
        if (state.inbound == 'status') then
            state.building = { tiers = T{ }, ledger = T{ } };
        elseif (state.inbound == 'shop') then
            state.building = { shop = T{ } };
        end

        answered(state.inbound);

        -- A refusal raised before a verb opened its own envelope arrives
        -- wrapped in `d|1|status` (the writer's shape). That IS the answer
        -- to whatever was asked: left unanswered, checkAnswers re-sends the
        -- verb and then replaces the server's precise sentence with a "no
        -- answer" diagnosis that is simply untrue.
        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- sentence saying why something was refused is worth more than the
    -- response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwraid'):append(chat.error(state.status)));

            -- The command exists but raid_core.lua is not loaded (dwx.lua's
            -- own refusal). Asking again cannot help until a map restart --
            -- detect once and go quiet.
            if (string.find(line, 'The raid is not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'status' and state.building ~= nil) then
            state.tiers    = state.building.tiers;
            state.ledger   = state.building.ledger;
            state.building = nil;

            state.status    = 'Synced.';
            state.statusBad = false;
        elseif (closing == 'shop' and state.building ~= nil) then
            state.shop     = state.building.shop;
            state.building = nil;
        end

        return;
    end

    if (kind == 'g') then
        state.purse = {
            balance = tonumber(parts[2]) or 0,
            earned  = tonumber(parts[3]) or 0,
            spent   = tonumber(parts[4]) or 0,
        };

        return;
    end

    if (kind == 'a') then
        state.arena = {
            running = (tonumber(parts[2]) or 0) ~= 0,
            tier    = tonumber(parts[3]) or 0,
            minutes = tonumber(parts[4]) or 0,
        };

        return;
    end

    if (kind == 't' and state.building ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            state.building.tiers[index] = {
                label = parts[3] or '?',
                base  = tonumber(parts[4]) or 0,
                daily = tonumber(parts[5]) or 0,
            };
        end

        return;
    end

    if (kind == 'l' and state.building ~= nil) then
        state.building.ledger:append({
            delta  = tonumber(parts[2]) or 0,
            age    = tonumber(parts[3]) or 0,
            reason = parts[4] or '',
        });

        return;
    end

    if (kind == 's' and state.building ~= nil and state.building.shop ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            state.building.shop[index] = {
                label = parts[3] or '?',
                price = tonumber(parts[4]) or 0,
            };
        end

        return;
    end

    -- The live quote rides outside the list-building rule: it is one value,
    -- it names its own window, and the Confirm button exists only while it
    -- is fresh (the server holds the same 60 s rule; this is presentation).
    if (kind == 'q') then
        state.quote = {
            index    = tonumber(parts[2]) or 0,
            price    = tonumber(parts[3]) or 0,
            deadline = os.clock() + (tonumber(parts[4]) or 60),
        };

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWXDATA is
* ours: consumed here and blocked so the chat log never sees it -- before
* parsing, so a malformed record cannot leak as noise.
--]]
ashita.events.register('packet_in', 'dwraid_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwraid'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

local function agoText(age)
    if (age < 3600) then
        return string.format('%dm ago', math.floor(age / 60));
    elseif (age < 86400) then
        return string.format('%dh ago', math.floor(age / 3600));
    end

    return string.format('%dd ago', math.floor(age / 86400));
end

local function purseBlock()
    if (state.purse == nil) then
        imgui.TextDisabled('No purse data yet. Refresh, or wait for the first sync.');

        return;
    end

    imgui.Text(string.format('%d driftmarks', state.purse.balance));
    imgui.SameLine();
    imgui.TextDisabled(string.format('(%d earned, %d spent, account-wide)', state.purse.earned, state.purse.spent));
end

local function arenaBlock()
    if (state.arena == nil) then
        return;
    end

    if (state.arena.running) then
        local tier  = state.tiers[state.arena.tier];
        local label = tier ~= nil and tier.label or 'unknown tier';

        imgui.TextColored(theme.colors.hint,
            string.format('The arena is occupied (%s, %d minute(s) in).', label, state.arena.minutes));
    else
        imgui.TextColored(theme.colors.ok, 'The arena is idle.');
    end
end

--[[
* One tier as a row: label, payouts, and the Enter button that is the whole
* point of the window. The button only SENDS the verb -- the server gates
* the party, and its refusal sentence lands in the status line above.
--]]
local function tiersBlock()
    if (next(state.tiers) == nil) then
        imgui.TextDisabled('No tier data yet.');

        return;
    end

    if (imgui.BeginTable('##dwraid_tiers', 3, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Tier', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        imgui.TableSetupColumn('Pays', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Go', ImGuiTableColumnFlags_WidthFixed, 70, 0);

        for index = 1, 9 do
            local tier = state.tiers[index];

            if (tier ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(tier.label);
                imgui.TableNextColumn();
                imgui.Text(string.format('%d a clear, +%d first of the day', tier.base, tier.daily));
                imgui.TableNextColumn();

                if (imgui.Button(string.format('Enter##dwraid_enter_%d', index))) then
                    state.status    = string.format('Asking for the %s trial...', tier.label);
                    state.statusBad = false;

                    issue(string.format('!dwx enter %s', tier.label:lower()));
                end
            end
        end

        imgui.EndTable();
    end
end

local function ledgerBlock()
    if (#state.ledger == 0) then
        imgui.TextDisabled('No driftmark movements yet. The trial pays the first ones.');

        return;
    end

    for _, row in ipairs(state.ledger) do
        imgui.TextDisabled(string.format('%+d  %s  (%s)', row.delta, row.reason, agoText(row.age)));
    end
end

--[[
* The shop: shelf rows with a Buy button each, and a Confirm button that
* exists only while a quote is fresh. Buy asks the server for a quote;
* nothing purchases on one click -- the deliberate second press is the
* dwquest storefront's rule, kept whole.
--]]
local function shopBlock()
    if (next(state.shop) == nil) then
        imgui.TextDisabled('No shop data yet.');

        return;
    end

    if (imgui.BeginTable('##dwraid_shop', 3, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Price', ImGuiTableColumnFlags_WidthFixed, 70, 0);
        imgui.TableSetupColumn('Go', ImGuiTableColumnFlags_WidthFixed, 60, 0);

        for index = 1, 30 do
            local row = state.shop[index];

            if (row ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(row.label);
                imgui.TableNextColumn();
                imgui.Text(string.format('%d', row.price));
                imgui.TableNextColumn();

                if (imgui.Button(string.format('Buy##dwraid_buy_%d', index))) then
                    state.status    = string.format('Asking for a quote on %s...', row.label);
                    state.statusBad = false;

                    issue(string.format('!dwx buy %d', index));
                end
            end
        end

        imgui.EndTable();
    end

    if (state.quote ~= nil and os.clock() < state.quote.deadline) then
        local quoted = state.shop[state.quote.index];

        if (imgui.Button(string.format('Confirm: %s for %d##dwraid_confirm',
                quoted ~= nil and quoted.label or '?', state.quote.price))) then
            state.quote = nil;

            issue('!dwx confirm');
        end
    end
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        serverSilent = false;

        forget();
        requestStatus();
    end

    imgui.SameLine();

    if (imgui.Button('Leave the arena')) then
        state.status    = 'Asking to leave...';
        state.statusBad = false;

        issue('!dwx leave');
    end

    imgui.SameLine();

    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    else
        imgui.TextDisabled('');
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Separator();

    purseBlock();
    arenaBlock();

    imgui.Separator();
    imgui.TextDisabled('The Trial of the Tidebound -- gather your party in a city and go.');

    tiersBlock();

    imgui.Separator();
    imgui.TextDisabled('The Driftmark shop');

    shopBlock();

    imgui.Separator();
    imgui.TextDisabled('Recent movements');

    ledgerBlock();
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape, and its
* reasoning, kept verbatim).
--]]
ashita.events.register('d3d_present', 'dwraid_present', function ()
    -- Before the visibility check: a sync requested by a zone-in still has
    -- to reach the server with the window shut.
    if (state.syncAt ~= nil and os.clock() >= state.syncAt) then
        -- A typed line handed to a client that is still zoning is not
        -- delayed, it is LOST. The client's own zoning flag is the fact;
        -- wait it out (dwfame's lesson, kept verbatim).
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (player ~= nil and player:GetIsZoning() ~= 0) then
            state.syncAt = os.clock() + 1.0;
        else
            state.syncAt = nil;

            forget();
            requestStatus();
        end
    end

    -- Answer tracking runs whether or not the window is open: it is exactly
    -- the window-closed zone-in auto-syncs that must stop when the server
    -- has gone silent (an unknown !command here is /say chat).
    checkAnswers();

    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 480, 420 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse
    -- them into a single unthemed dock that imgui.ini kept across reloads.
    local visible = imgui.Begin('DriftwoodXI Raid##dwraid', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwraid'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwraid'):append(chat.message('Window closed. `!raid` typed by hand says the same things.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs: a window showing the purse
* as it stood two clears ago is the quiet kind of wrong this project exists
* to rule out, and a sync costs one chat line.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting, and for the
        -- silent-server detection: opening the window is the deliberate
        -- act that earns one more try.
        state.reported = false;
        serverSilent   = false;

        forget();
        requestStatus();
    end
end

ashita.events.register('command', 'dwraid_command', function (e)
    local args = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwraid' and first ~= '/raid' and first ~= '/dwx') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        serverSilent = false;

        forget();
        requestStatus();

        return;
    end

    toggleWindow();
end);

--[[
* Sync on login and zone-in (0x000A serves both) -- and for this addon the
* zone-in IS the payoff moment: entering the arena, leaving it, and the
* return warp are all zone changes, so the window refreshes itself exactly
* when the purse and the arena state just changed. Everything server-derived
* resets first -- a login may be a different character.
--]]
ashita.events.register('packet_in', 'dwraid_zonein', function (e)
    if (e.id == 0x000A) then
        state.purse     = nil;
        state.arena     = nil;
        state.tiers     = T{ };
        state.ledger    = T{ };
        state.shop      = T{ };
        state.quote     = nil;
        state.building  = nil;
        state.inbound   = nil;
        state.status    = 'Syncing...';
        state.statusBad = false;

        forget();

        -- No auto-sync against a server that has shown it does not speak
        -- dwraid: an unknown !command falls through to /say here, so each
        -- retry would be the player chatting "!dwx status" at whoever is
        -- nearby. Opening the window retries deliberately.
        if (not serverSilent) then
            state.syncAt = os.clock() + 4.0;
        else
            state.status = 'Raid board paused (no answer from the server). Open the window to retry.';
        end
    end
end);

--[[
* Watch what the player sends.
*
* Bare `!raid` (and the ui/window/gui spellings of `!dwx`) toggles this
* window instead of going to the server -- the server verb is the name
* players learn, so it has to be a door and not a dead end. `!raid enter`
* and every argumented form still pass through untouched; that is the
* escape hatch this addon's header promises.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped
* (dwbags' lesson, kept verbatim).
--]]
ashita.events.register('packet_out', 'dwraid_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!raid' or lower == '!dwx' or
        lower == '!dwx ui' or lower == '!dwx window' or lower == '!dwx gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwx') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwraid_load', function ()
    print(chat.header('dwraid'):append(chat.message('/raid, /dwraid or !raid opens the raid board.')));
end);
