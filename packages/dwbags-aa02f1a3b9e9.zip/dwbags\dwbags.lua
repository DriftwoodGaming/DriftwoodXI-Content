--[[
* DriftwoodXI -- dwbags
*
* Every bag on your account, from whichever character you are logged in on.
* Search across all of them, move items between them, and see what each of your
* squad members will be wearing the next time you call them.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no item data of its own, caches nothing to disk, and has no way to
* move an item that the typed command surface does not already have. Every read
* is `!dwq <verb>` and every write is `!dwq send|fetch|equip|use`, which are
* the same server-side functions `!squad send|fetch|equip|use` reach -- the
* only difference is that they answer in compact records under the sender name
* _DWDATA, which this addon parses and blocks before the chat log sees them.
*
* That constraint is deliberate and it is the reason a UI could be shipped at
* all: a bug in here cannot move an item the server would have refused, because
* it is not doing anything the typed command does not do. The ownership check,
* the transaction and the Rare/Ex rules all live in the server's C++ and run
* identically whichever way the command arrived.
*
* WHY THE SERVER DOES NOT SEND ITEM NAMES. It does not need to: this addon is
* inside the client, and the client already has the name, the icon, the level,
* the job mask and the flags of every item in its own DAT resources. Sending
* them would be paying twice, and it is what keeps a packed record inside the
* 150-byte chat buffer the whole protocol has to fit through.
*
* TURN IT OFF AND NOTHING IS LOST. `!squad who`, `!squad bag`, `!squad find`,
* `!squad send`, `!squad fetch`, `!squad gear`, `!squad equip` and `!squad menu`
* all work typed, and `!squad menu` gives you the same operations as
* client-rendered dialogs. This is faster; it is not required.
*
* UPGRADE MARKERS (1.8) render the `h|` records `!dwq hints` answers: a mark
* on any gear slot where something in another of your characters' bags beats
* what this one wears, with the fetch/send recipe one click away. The click
* issues the same typed lines a player would -- never retried -- and a server
* too old to know the verb is detected once and never asked again, so
* deployment order cannot matter.
*
* THE STORAGE TAB (1.9) renders the `y|` and `p|` records `!dwq bagpref`
* answers: which bag each kind of item is put away in when it arrives, a
* wardrobe layout in one click, and the `!dwq tidy` that applies it to what a
* character already holds. Gear now defaults into the mog wardrobes, which are
* the only containers that can hold nothing else -- so it stops competing with
* everything else for the four bags a player actually carries.
*
* The seventeen `p|` rows are per EQUIP SLOT and the groups this draws --
* Weapons, Off-hand, Armour, Trinkets, Jewellery -- are assembled here, from
* those rows. That is on purpose: a group is a way of talking about a layout,
* not a thing the server stores, and a layout whose groups cut across these
* (the owner's own does) has to stay drawable rather than being rounded off to
* the nearest lie. A group whose slots disagree says so and offers the slots.
*
* PLACED FURNITURE (1.9.3) renders item flag bit 16: furniture standing in a
* Mog House layout shows a greyed 'placed' tag where Send/Fetch would be, the
* way a worn item shows 'worn'. The server refuses the transfer either way --
* this only says why BEFORE the click, and what to do about it. A server too
* old to send the bit simply never sets it, and the row keeps its buttons.
*
* THE STACK BUTTON (1.10) is one click over the `!dwq stack` verb: every item
* split across more than one part-stack -- three fire crystals here, four in
* the satchel, two in the safe -- is combined into as few stacks as it can
* be, into the inventory when there is room. Which rows may merge is decided
* entirely in the server's C++ (worn, bazaared, signed and augmented copies
* stay put), so this button, like every other, cannot move anything the typed
* command would not. A server too old to know the verb is detected once off
* its own unknown-verb sentence and the button is not drawn, so deployment
* order cannot matter.
*
* SEND FROM AN ALT (1.11) is the Gear tab's Get-button recipe put on every alt
* row: a Send button beside Fetch that queues the same two typed lines a
* player would send -- fetch into your own inventory, then send on to whoever
* the header's "Send to" names -- one per interval, in order, NEVER retried.
* The item passes through your inventory because that is the only route the
* typed commands have; there is no alt-to-alt verb on the server, and growing
* one for a button would be the moment this addon stopped being a renderer.
* If the fetch is refused the send then refuses on its own terms -- two red
* sentences is noisy, but nothing moves that the typed pair would not have
* moved. The button is not drawn when "Send to" names the character the row
* belongs to (that transfer is a no-op with extra steps) or when it names
* nobody.
*
* QUICKER AUTO-REFRESH (1.11.1). After a transfer click, the visible tab's
* re-ask now enters the throttled queue BEFORE the `who`/`find` refresh
* instead of after it, so the rows on screen update one send interval after
* the action's last line rather than up to three. The commands and the 1.2s
* throttle are unchanged -- only the order moved; see refetchVisible.
--]]

addon.name    = 'dwbags';
addon.author  = 'DriftwoodXI';
addon.version = '1.11.1';
addon.desc    = 'Account-wide bag browser, item transfer and squad gearing for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local d3d   = require('d3d8');
local ffi   = require('ffi');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load.
*
* This addon is loaded from the launcher's boot script, which runs long before
* the client has a rendering device -- and `d3d.get_device()` at file scope
* makes the whole addon fail to load when it answers nothing. That is the
* difference between `/addon load dwbags` working by hand and the same line in
* driftwood-default.txt appearing to do nothing at all. Nothing here needs a
* device until the first icon is drawn, by which point there certainly is one.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server uses
-- it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

-- Equip slot ids, in the order a player reads them.
local SLOT_NAMES = {
    [0]  = 'main',  [1]  = 'sub',   [2]  = 'ranged', [3]  = 'ammo',
    [4]  = 'head',  [5]  = 'body',  [6]  = 'hands',  [7]  = 'legs',
    [8]  = 'feet',  [9]  = 'neck',  [10] = 'waist',  [11] = 'ear1',
    [12] = 'ear2',  [13] = 'ring1', [14] = 'ring2',  [15] = 'back',
};

-- Container ids, matching CONTAINER_ID in the server's item_container.h.
local LOC_NAMES = {
    [0]  = 'Inventory', [1]  = 'Mog Safe',  [2]  = 'Storage',   [3]  = 'Temp',
    [4]  = 'Locker',    [5]  = 'Satchel',   [6]  = 'Sack',      [7]  = 'Case',
    [8]  = 'Wardrobe',  [9]  = 'Mog Safe 2',[10] = 'Wardrobe 2',[11] = 'Wardrobe 3',
    [12] = 'Wardrobe 4',[13] = 'Wardrobe 5',[14] = 'Wardrobe 6',[15] = 'Wardrobe 7',
    [16] = 'Wardrobe 8',[17] = 'Recycle Bin',
};

--[[
* Bag routing (`p|` and `y|`).
*
* A class is one destination the server stores: class 0 is "not equipment" and
* class N is equip slot N - 1. `loc` is a container id, or ANY_WARDROBE for
* "any of them, filling in order".
--]]
local ANY_WARDROBE = 254;

local function classOfSlot(slot)
    return slot + 1;
end

-- The groups the tab draws. Assembled here rather than sent, because a group is
-- a way of TALKING about a layout and the server stores slots -- see the header.
local BAG_GROUPS = {
    { name = 'weapons',   label = 'Weapons',           slots = { 0 } },
    { name = 'offhand',   label = 'Off-hand & ranged', slots = { 1, 2, 3 } },
    { name = 'armour',    label = 'Armour',            slots = { 4, 5, 6, 7, 8 } },
    { name = 'trinkets',  label = 'Trinkets',          slots = { 9, 10, 15 } },
    { name = 'jewellery', label = 'Jewellery',         slots = { 11, 12, 13, 14 } },
    { name = 'items',     label = 'Everything else',   slots = { }, other = true },
};

-- Destination names exactly as `!dwq bagpref` parses them, in the order a
-- player reads them. `wardrobes` is the pseudo-target.
local BAG_DESTINATIONS = {
    { name = 'wardrobes', loc = ANY_WARDROBE, label = 'Any wardrobe' },
    { name = 'wardrobe',  loc = 8,  label = 'Wardrobe' },
    { name = 'wardrobe2', loc = 10, label = 'Wardrobe 2' },
    { name = 'wardrobe3', loc = 11, label = 'Wardrobe 3' },
    { name = 'wardrobe4', loc = 12, label = 'Wardrobe 4' },
    { name = 'wardrobe5', loc = 13, label = 'Wardrobe 5' },
    { name = 'wardrobe6', loc = 14, label = 'Wardrobe 6' },
    { name = 'wardrobe7', loc = 15, label = 'Wardrobe 7' },
    { name = 'wardrobe8', loc = 16, label = 'Wardrobe 8' },
    { name = 'inventory', loc = 0,  label = 'Inventory' },
    { name = 'satchel',   loc = 5,  label = 'Satchel' },
    { name = 'sack',      loc = 6,  label = 'Sack' },
    { name = 'case',      loc = 7,  label = 'Case' },
    { name = 'safe',      loc = 1,  label = 'Mog Safe' },
    { name = 'safe2',     loc = 9,  label = 'Mog Safe 2' },
    { name = 'locker',    loc = 4,  label = 'Locker' },
};

-- Layout ids, matching kLayout* in the server's alt_storage.cpp.
local BAG_LAYOUTS = {
    { id = 0, name = 'category', label = 'By category',
      blurb = 'Weapons, off-hand, armour, trinkets and jewellery each get a wardrobe.' },
    { id = 1, name = 'slot',     label = 'By slot',
      blurb = 'Main / head+neck+ears / body+hands+rings / back+waist+legs+feet / sub+ranged+ammo.' },
    { id = 2, name = 'simple',   label = 'Any wardrobe',
      blurb = 'All gear into the wardrobes, filling them in order.' },
    { id = 3, name = 'off',      label = 'No wardrobes',
      blurb = 'Everything into inventory, satchel, sack and case, as it was before.' },
};

-- Wardrobe container ids are 8 and 10..16 -- 9 is the second mog safe, sitting
-- in the middle of the run.
local function isWardrobeLoc(loc)
    return loc == ANY_WARDROBE or loc == 8 or (loc >= 10 and loc <= 16);
end

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Item flag bits, as the server packs them.
local ITEM_EQUIPPED  = 1;
local ITEM_AUGMENTED = 2;
local ITEM_BAZAARED  = 4;
local ITEM_PLACED    = 16;  -- furniture standing in a Mog House layout

-- Client DAT item flags, the same bits the server's item_basic carries. Read
-- from the client's own resources (like names and icons are), so the wire
-- format did not have to change to grow a Use button. The server re-checks
-- usability on `!dwq use` regardless -- this only decides whether the button
-- is worth drawing.
local FLAG_SCROLL = 0x0080;
local FLAG_CANUSE = 0x0200;

local function datFlagsOf(itemId)
    local item = AshitaCore:GetResourceManager():GetItemById(itemId);

    return item ~= nil and item.Flags or 0;
end

-- Character flag bits.
local CHAR_ONLINE = 1;
local CHAR_LOCKED = 2;
local CHAR_SELF   = 4;

-- The upgrade-marker colour, distinct from the pin's amber and the error red.
-- All of these live in dwtheme and follow the launcher's Appearance theme.
local COLOR_HINT = theme.colors.hint;

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged, so a
    -- stale row cannot survive a refresh.
    chars     = T{ },
    selected  = nil,        -- charid
    bags      = T{ },       -- [loc] = { size, used, items = {} }
    gear      = T{ },       -- [equipslot] = record
    options   = T{ },       -- [equipslot] = { record, ... }
    hints     = T{ },       -- [equipslot] = the best upgrade found account-wide
    box       = T{ },
    finds     = T{ },
    findQuery = '',

    -- Bag routing. `prefs` is [class] = { loc, isdefault, free } and `layout` is
    -- the named layout id, or 255 for one the player has edited by hand.
    prefs     = T{ },
    layout    = 255,

    -- The verb whose response is currently arriving. Records are only accepted
    -- between a `d|` and its `z|`, so a line that arrives on its own -- a
    -- response to something typed by hand, say -- cannot half-fill the UI.
    inbound   = nil,
    status    = 'Press Refresh.',
    statusBad = false,      -- draw the banner as an error rather than a note
    tab       = 1,
    reported  = false,      -- a render error is worth saying once, not per frame

    search    = T{ '' },
    sendQty   = T{ 1 },
    sendAll   = T{ true },  -- move the whole stack unless told otherwise
    sendTo    = nil,        -- charid a Send goes to; see the header combo
};

local icons = T{ };

--[[
* The item icon out of the client's own resources.
*
* Cached because a bag is eighty rows redrawn every frame and
* D3DXCreateTextureFromFileInMemoryEx is not free. gc_safe_release hands back a
* texture that releases itself when Lua collects it, which is what keeps this
* from leaking across a reload.
--]]
local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

local function itemName(itemId)
    local item = AshitaCore:GetResourceManager():GetItemById(itemId);

    if (item == nil or item.Name[1] == nil or item.Name[1]:len() == 0) then
        return string.format('item %d', itemId);
    end

    return item.Name[1];
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A TIME.
*
* THE CLIENT RATE-LIMITS OUTGOING CHAT, AND A !dwq COMMAND IS A CHAT LINE.
* Firing four of them in a single frame -- which is what a naive "refresh
* everything" does -- gets the first one sent and the rest answered with
* "A command error occurred" by the client, before the server ever sees them.
* The symptom is maddening precisely because it is not deterministic: whichever
* command happens to go first works, so the character list fills in while the
* gear panel stays empty and Send silently does nothing.
*
* So everything queues here and drains at one command per SEND_INTERVAL.
* Duplicates collapse, because asking twice for the same thing is never useful
* and the queue is the one place that can know.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

--[[
* Drains one queued command. Called every frame from d3d_present, including
* while the window is shut: a Send issued just before closing it still has to
* reach the server.
--]]
local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a tab drawn sixty times a second asks
* once. Keyed by verb, holding the charid the answer is about, when it was
* asked, whether it was answered and how many times it has been sent.
*
* THE ANSWER IS TRACKED, NOT JUST THE QUESTION, because a command can be lost on
* the way out. The client rate-limits outgoing chat and answers anything over
* the limit with "A command error occurred" before the server ever sees it, and
* a !dwq command is a chat line like any other -- so a query issued in the same
* instant as something the player typed can simply evaporate. That used to leave
* the panel showing pre-command data until the player clicked to another
* character and back, which is the worst shape a bug can have: the number is
* wrong and nothing on screen says so. It is exactly how the In transit tab went
* on listing an item that `!squad call` had already delivered.
*
* So an unanswered request is asked once more, and then left alone -- a retry
* that never terminates would be a command loop, which is worse than a stale
* panel.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

--[[
* A PLAIN TABLE, NOT `T{ }`, AND THIS ONE COST A ROUND.
*
* This table is keyed by VERB -- 'bag', 'gear', 'box', 'find' -- and a `T{ }`
* resolves unknown keys through its metatable to the sugar table methods
* (`libs/sugar/table.lua:372`). So `requested['find']` did not answer nil, it
* answered `table_mt.find`, **a function**, and writing a field to it threw.
*
* The blast radius was much wider than the error line, because the throw
* happened after `state.inbound` had been set and before the section reset that
* follows it: every `find` response then appended to the previous one instead of
* replacing it, which is what made the results list appear to duplicate itself
* on every search. A table indexed by names the caller chooses must not be one
* that already has names of its own.
--]]
local requested = {};

-- True once the server has said it has no hints verb -- one from before
-- UPGRADE_HINTS_PLAN.md Phase 2. Detected off the dispatch's own unknown-verb
-- sentence (frozen on any server old enough to say it) and reset on every
-- login line, so a server upgraded underneath a running client gets asked
-- again rather than never.
local hintsUnsupported = false;

-- The same detection for `bagpref` and `tidy`, and for the same reason: a
-- server from before bag routing answers them with its unknown-verb sentence,
-- and the honest response to that is to draw the tab as unavailable rather than
-- to ask again every time it is opened. Reset on login with the hints flag.
local prefsUnsupported = false;

-- And again for `stack`, so the Stack button simply is not drawn against a
-- server from before the combiner existed. Reset on login with the others.
local stackUnsupported = false;

local function forget()
    requested = {};
end

-- Called from the `d|` record: whatever response is arriving answers the
-- outstanding question for that verb.
local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

--[[
* Ask for one verb about one character, at most once -- twice if the first one
* was never answered.
*
* Called from the tab that needs it rather than all at once on selection: the
* Bags tab does not need the gear list and the Gear tab does not need the
* delivery box, and with a throttled queue every command not sent is a second
* the player is not waiting.
--]]
local function need(verb, charid)
    local member = state.chars[charid];

    if (member == nil) then
        return;
    end

    local asked = requested[verb];

    if (asked ~= nil and asked.charid == charid) then
        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested[verb] = T{ charid = charid, at = os.clock(), answered = false, tries = 1 };
    end

    issue(string.format('!dwq %s %s', verb, member.name));
end

local function refreshChars()
    issue('!dwq who');
end

--[[
* Record parsing.
*
* Every record is pipe-separated with a single-character type. Anything this
* addon does not recognise is ignored rather than being an error: a server
* newer than the addon must not break it, which is the whole reason the `d|`
* record carries a protocol version.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

-- `<slot>:<itemid>:<qty>:<flags>,...`
local function parsePacked(charid, loc, packed)
    local rows = T{ };

    for _, entry in ipairs(split(packed, ',')) do
        local bits = split(entry, ':');

        if (#bits >= 4) then
            rows:append(T{
                charid = charid,
                loc    = loc,
                slot   = tonumber(bits[1]) or 0,
                itemid = tonumber(bits[2]) or 0,
                qty    = tonumber(bits[3]) or 0,
                flags  = tonumber(bits[4]) or 0,
            });
        end
    end

    return rows;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            -- statusBad too, or the loudest message this addon can produce is
            -- drawn in whatever colour the LAST message happened to leave
            -- behind -- so "update dwbags" reads as an ordinary note, and if
            -- the previous line was a success it reads as a green one.
            -- dwwarehouse sets both here; this copy of the template did not.
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwbags.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        --[[
            A STALE ENVELOPE IS DROPPED WHOLE, BEFORE THE RESET BELOW.

            Selecting a different character fires a fresh read, but a reply
            already in flight for the PREVIOUS one still arrives -- and the
            reset below is keyed on the verb, not on whose data it is. The
            per-record filters further down correctly ignored the foreign
            rows, which is precisely what made this visible: the section was
            cleared and then nothing refilled it, so the panel of the
            character on screen went blank until the next read landed.

            The server stamps every per-character read envelope with the
            charid (squad_storage.lua open()): bag, gear, box, bagpref and
            hints. It is absent for who/find/send/fetch/use/status and from
            any older server, and those keep exactly today's behaviour.
            Status lines are unaffected: the m|/e| branch sits above the
            `state.inbound == nil` guard, so a refusal riding a foreign
            envelope still reaches the status bar.
        --]]
        local envChar = tonumber(parts[4]);

        if (envChar ~= nil and state.selected ~= nil and envChar ~= state.selected) then
            state.inbound = nil;

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright. THIS RUNS BEFORE
        -- ANYTHING ELSE THE `d|` RECORD DOES, because handleRecord is called
        -- under a pcall: anything that throws above this line leaves the old
        -- rows in place and the records behind it append to them, which turns a
        -- one-line bug into a duplicated list.
        if (state.inbound == 'who') then
            state.chars = T{ };
        elseif (state.inbound == 'bag') then
            state.bags = T{ };
        elseif (state.inbound == 'gear') then
            state.gear = T{ };
            state.options = T{ };
        elseif (state.inbound == 'box') then
            state.box = T{ };
        elseif (state.inbound == 'find') then
            state.finds = T{ };
        elseif (state.inbound == 'hints') then
            state.hints = T{ };
        elseif (state.inbound == 'bagpref') then
            state.prefs  = T{ };

            -- Reset with the rows, not left behind: a response whose `y|` was
            -- dropped would otherwise go on claiming the layout the last one
            -- named, which is the one thing on this tab that reads as fact
            -- rather than as a control.
            state.layout = 255;
        end

        answered(state.inbound);

        return;
    end

    -- Status and error lines are accepted whatever the envelope state.
    --
    -- They are the one thing a player must never lose, and they were being lost
    -- twice over: the server emitted them outside any `d|` (so this guard threw
    -- them away), and a dropped `d|` would have swallowed them regardless. The
    -- server now wraps them properly; this is the belt to that pair of braces,
    -- because the message saying why a transfer was refused is worth more than
    -- the response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- The one refusal that is not worth a red banner: a server from
        -- before the hint tier answering `!dwq hints` with its unknown-verb
        -- sentence. That means upgrade markers do not exist here yet, so the
        -- addon stops asking and draws nothing -- deployment order must not
        -- matter in either direction (UPGRADE_HINTS_PLAN.md Phase 3).
        if (kind == 'e' and not hintsUnsupported
                and string.find(line, 'unknown verb "hints"', 1, true) ~= nil) then
            hintsUnsupported = true;

            return;
        end

        -- Same again for bag routing, on a server from before it existed.
        if (kind == 'e' and not prefsUnsupported
                and (string.find(line, 'unknown verb "bagpref"', 1, true) ~= nil
                     or string.find(line, 'unknown verb "tidy"', 1, true) ~= nil)) then
            prefsUnsupported = true;

            return;
        end

        -- And again for the stack combiner. The stale-binary spelling is
        -- matched as well as the stale-Lua one: a map whose squad_storage.lua
        -- knows the verb but whose binary predates DwBagStack answers with a
        -- sentence of its own, and both mean the same thing to this button.
        if (kind == 'e' and not stackUnsupported
                and (string.find(line, 'unknown verb "stack"', 1, true) ~= nil
                     or string.find(line, 'does not have bag stacking', 1, true) ~= nil)) then
            stackUnsupported = true;

            return;
        end

        -- Everything after the first pipe, not parts[2]: these carry prose and
        -- an item name may contain anything.
        state.status  = line:sub(3);
        state.statusBad = (kind == 'e');

        -- Also to the chat log: the window may not be open, and "nothing
        -- happened" is the worst possible feedback for a refused transfer.
        if (kind == 'e') then
            print(chat.header('dwbags'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        state.inbound = nil;

        return;
    end

    if (kind == 'c') then
        local charid = tonumber(parts[2]) or 0;

        state.chars[charid] = T{
            charid = charid,
            name   = parts[3],
            mjob   = tonumber(parts[4]) or 0,
            mlvl   = tonumber(parts[5]) or 0,
            sjob   = tonumber(parts[6]) or 0,
            slvl   = tonumber(parts[7]) or 0,
            flags  = tonumber(parts[8]) or 0,
            used   = tonumber(parts[9]) or 0,
            size   = tonumber(parts[10]) or 0,
            slot   = tonumber(parts[11]) or 0,
            order  = charid,
        };

        -- Default the selection to the character being played, and the Send
        -- target to the first character that is not them, so the window is
        -- usable on the frame it opens rather than after two clicks.
        if (state.selected == nil and bit.band(state.chars[charid].flags, CHAR_SELF) ~= 0) then
            state.selected = charid;
        end

        if (state.sendTo == nil and bit.band(state.chars[charid].flags, CHAR_SELF) == 0) then
            state.sendTo = charid;
        end

        return;
    end

    -- THE PER-CHARACTER RECORDS ARE FILTERED AGAINST THE SELECTION. Click
    -- character A, then B inside the queue's 1.2s interval, and A's response
    -- arrives while B is selected -- without this check A's bags filled B's
    -- panel for a second or two before B's response corrected it. Records for
    -- anybody but the character on screen are simply not ours to render; the
    -- request for the right one is already in the queue.
    if (kind == 'n') then
        local charid = tonumber(parts[2]) or 0;
        local loc    = tonumber(parts[3]) or 0;

        if (charid ~= state.selected) then
            return;
        end

        state.bags[loc] = state.bags[loc] or T{ items = T{ } };
        state.bags[loc].used = tonumber(parts[4]) or 0;
        state.bags[loc].size = tonumber(parts[5]) or 0;

        return;
    end

    if (kind == 'i') then
        local charid = tonumber(parts[2]) or 0;
        local loc    = tonumber(parts[3]) or 0;

        if (charid ~= state.selected) then
            return;
        end

        state.bags[loc] = state.bags[loc] or T{ items = T{ }, used = 0, size = 0 };

        for _, row in ipairs(parsePacked(charid, loc, parts[4])) do
            state.bags[loc].items:append(row);
        end

        return;
    end

    if (kind == 'f') then
        local charid = tonumber(parts[2]) or 0;
        local loc    = tonumber(parts[3]) or 0;

        for _, row in ipairs(parsePacked(charid, loc, parts[4])) do
            state.finds:append(row);
        end

        return;
    end

    if (kind == 'g') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if ((tonumber(parts[2]) or 0) ~= state.selected) then
            return;
        end

        local slot = tonumber(parts[3]) or 0;

        state.gear[slot] = T{
            slot   = slot,
            itemid = tonumber(parts[4]) or 0,
            loc    = tonumber(parts[5]) or 0,
            score  = tonumber(parts[7]) or 0,
            pinned = (tonumber(parts[8]) or 0) ~= 0,
        };

        return;
    end

    if (kind == 'k') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if ((tonumber(parts[2]) or 0) ~= state.selected) then
            return;
        end

        local slot = tonumber(parts[3]) or 0;

        state.options[slot] = state.options[slot] or T{ };
        state.options[slot]:append(T{
            slot   = slot,
            itemid = tonumber(parts[4]) or 0,
            loc    = tonumber(parts[5]) or 0,
            score  = tonumber(parts[7]) or 0,
        });

        -- Sorted HERE rather than at draw time, and with a tiebreak.
        --
        -- Lua's table.sort is not stable, so two items on an equal score can
        -- swap places on every sort. Sorting inside the render pass therefore
        -- re-ordered the column sixty times a second and the names appeared to
        -- alternate -- which is the flicker that made the Gear tab unreadable.
        -- Item id breaks the tie so that "equal score" still has one true order.
        table.sort(state.options[slot], function (a, b)
            if (a.score == b.score) then
                return a.itemid < b.itemid;
            end

            return a.score > b.score;
        end);

        return;
    end

    if (kind == 'h') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if ((tonumber(parts[2]) or 0) ~= state.selected) then
            return;
        end

        local slot = tonumber(parts[3]) or 0;

        -- One upgrade per slot: records arrive biggest-improvement first, so
        -- the first to land for a slot is the one worth drawing.
        if (state.hints[slot] == nil) then
            state.hints[slot] = T{
                slot       = slot,
                itemid     = tonumber(parts[4]) or 0,
                fromcharid = tonumber(parts[5]) or 0,
                loc        = tonumber(parts[6]) or 0,
                bagslot    = tonumber(parts[7]) or 0,
                score      = tonumber(parts[8]) or 0,
                worn       = tonumber(parts[9]) or 0,
            };
        end

        return;
    end

    if (kind == 'y') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if ((tonumber(parts[2]) or 0) ~= state.selected) then
            return;
        end

        state.layout = tonumber(parts[3]) or 255;

        return;
    end

    if (kind == 'p') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if ((tonumber(parts[2]) or 0) ~= state.selected) then
            return;
        end

        -- `<class>:<loc>:<isdefault>:<free>,...`
        for _, entry in ipairs(split(parts[3], ',')) do
            local bits = split(entry, ':');

            if (#bits >= 4) then
                state.prefs[tonumber(bits[1]) or 0] = T{
                    loc       = tonumber(bits[2]) or 0,
                    isdefault = (tonumber(bits[3]) or 0) ~= 0,
                    free      = tonumber(bits[4]) or 0,
                };
            end
        end

        return;
    end

    if (kind == 'x') then
        local charid = tonumber(parts[2]) or 0;

        -- Foreign rows are dropped the way every other per-character record
        -- drops them: an older server's box envelope carries no charid stamp,
        -- so a stale reply would otherwise fill this section with the
        -- previously selected character's deliveries.
        if (state.selected ~= nil and charid ~= state.selected) then
            return;
        end

        state.box:append(T{
            charid = charid,
            itemid = tonumber(parts[3]) or 0,
            qty    = tonumber(parts[4]) or 0,
            sender = parts[5],
        });

        return;
    end

end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017.
*
* Layout after the 4-byte header: Kind at 0x04, Attr at 0x05, Data at 0x06,
* sName[15] at 0x08, Mes at 0x17. Any line whose sender is _DWDATA is ours: it
* is consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwbags_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwbags'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

-- Characters in charid order, which is creation order and is stable.
local function orderedChars()
    local ordered = T{ };

    for _, member in pairs(state.chars) do
        ordered:append(member);
    end

    table.sort(ordered, function (a, b) return a.order < b.order; end);

    return ordered;
end

local function charList()
    -- NOTE: the third argument is ImGuiChildFlags, not a bool. Ashita ships an
    -- ImGui new enough to have made that change (1.90), and passing `true` here
    -- raises a Lua error on every single frame -- which the addon host answers
    -- by unloading the addon after enough of them.
    imgui.BeginChild('##dwbags_chars', { 190, 0 }, ImGuiChildFlags_Borders);

    for _, member in ipairs(orderedChars()) do
        local tag = '';

        if (bit.band(member.flags, CHAR_SELF) ~= 0) then
            tag = ' (you)';
        elseif (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
            tag = ' [out]';
        elseif (bit.band(member.flags, CHAR_ONLINE) ~= 0) then
            tag = ' [on]';
        end

        local label = string.format('%s%s', member.name, tag);

        if (imgui.Selectable(label, state.selected == member.charid)) then
            state.selected = member.charid;

            -- Nothing is fetched here: whichever tab is on screen asks for its
            -- own data on the next frame, so switching characters costs one
            -- command rather than three.
            forget();

            state.bags    = T{ };
            state.gear    = T{ };
            state.options = T{ };
            state.hints   = T{ };
            state.box     = T{ };
            state.prefs   = T{ };
            state.layout  = 255;
        end

        imgui.TextDisabled(string.format('  %s%d  %d/%d',
            JOB_NAMES[member.mjob] or '?', member.mlvl, member.used, member.size));
    end

    imgui.EndChild();
end

local function selectedName()
    local member = state.selected ~= nil and state.chars[state.selected] or nil;

    return member ~= nil and member.name or nil;
end

local function isSelf(charid)
    local member = state.chars[charid];

    return member ~= nil and bit.band(member.flags, CHAR_SELF) ~= 0;
end

--[[
* Re-ask for whatever is on screen after a transfer.
*
* forget() covers the per-character verbs, but a Find result set is not keyed by
* character and so was left showing pre-transfer quantities -- the owner sent
* the same stack twice because it still read x7 after the first send. A find is
* re-issued only when one is actually on screen.
--]]
--[[
* THE WHO AND FIND RE-ASKS ARE DEFERRED TWO PUMPED FRAMES, NOT QUEUED HERE
* (1.11.1). The queue drains one line per SEND_INTERVAL, so a command's
* position in it is latency the player watches. Queueing `who` from inside the
* click put it ahead of the visible tab's own re-ask -- which only lands on the
* NEXT frame, when the tab's need() runs and finds forget() has cleared it --
* so the rows being stared at refreshed LAST, up to two intervals behind the
* left pane's counts. Two frames, not one, because the click itself happens
* mid-render, after this frame's need() has already run: the first counted
* frame is the one where the visible tab re-asks, the second is where the
* flush lands behind it. Same commands, same throttle, new order.
--]]
local refetchWait = 0;

local function refetchVisible()
    forget();

    refetchWait = 2;
end

local function pumpRefetch()
    if (refetchWait == 0) then
        return;
    end

    refetchWait = refetchWait - 1;

    if (refetchWait > 0) then
        return;
    end

    -- Find results before `who`: when a find is on screen it is content the
    -- player searched for, and the Find tab has no need() of its own to have
    -- jumped the queue with.
    if (state.findQuery ~= '' and state.findQuery ~= nil) then
        issue(string.format('!dwq find %s', state.findQuery));
    end

    -- The character list's used/size counts came from `who` and change with
    -- every transfer, and nothing else ever re-asks for them -- so without this
    -- the left pane read 79/80 long after the bag stopped being that full.
    refreshChars();
end

--[[
* How many of this row to move: the whole stack by default, or the spin box.
*
* THE FLOOR IS 1 AND IT IS APPLIED HERE AS WELL AS AT THE WIDGET. `InputInt`
* takes any integer it is given, including negative ones, and a negative
* quantity has no meaning in either direction -- it is not "move backwards", it
* is a number that lands in a `uint32` on the server as four billion. The widget
* clamps what the player can see and this clamps what the command can carry, so
* the two would both have to fail for a nonsense number to be sent.
--]]
local function moveCount(row)
    local held = math.max(row.qty, 1);

    if (state.sendAll[1]) then
        return held;
    end

    local wanted = math.floor(tonumber(state.sendQty[1]) or 1);

    return math.max(math.min(wanted, held), 1);
end

--[[
* The row action: pull an item out of another character's bag, or push one of
* your own across. Both go through the same server command a player would type.
*
* EVERY WIDGET ID CARRIES THE CHARACTER ID. Two characters holding the same item
* in the same container slot -- which is the normal outcome of sending one thing
* to two alts, since the collect drops it in the first free cell of each -- gave
* two buttons the identical `##loc_slot` suffix, and ImGui answered with a
* "conflicting ID" diagnostic and merged their click handling.
--]]
--[[
* The Use button, beside Send/Fetch on any row the client's own item flags say
* is usable. The server decides what a use MEANS -- a scroll teaches the spell
* to the whole account, food sticks to that character across calls, a potion or
* an ether lands on them while they are OUT, and anything else is refused with
* a sentence in the status line -- so this only decides that the button is
* worth drawing.
*
* For your own rows only scrolls get it, and only in the inventory: your own
* food works better through the game's ordinary item menu, and the server
* refuses it here with exactly that advice.
*
* THE TOOLTIP FOLLOWS THE CHARACTER, NOT THE ITEM, because that is the half the
* player cannot see for themselves. Whether an ether does anything turns on
* whether that character is standing in the world right now -- a member is
* rebuilt at full HP and MP at every call -- and the roster already knows,
* through the same CHAR_LOCKED bit that puts [out] beside their name. The
* server refuses either way with a sentence; saying it BEFORE the click is what
* stops the click.
--]]
local function useButton(row, id, name)
    if (imgui.SmallButton(string.format('Use##u%s', id))) then
        issue(string.format('!dwq use %s %d', name, row.itemid));

        refetchVisible();
    end

    if (imgui.IsItemHovered()) then
        local member = state.chars[row.charid];
        local out    = member ~= nil and bit.band(member.flags, CHAR_LOCKED) ~= 0;

        imgui.SetTooltip(string.format(
            'Use as %s. A scroll teaches the spell to your WHOLE account;\n'
            .. 'food stays on them across calls until it wears off.\n'
            .. 'Potions, ethers and remedies land on them %s.',
            name,
            out and 'right now -- they are out' or 'only while they are out'));
    end

    imgui.SameLine();
end

local function transferButton(row)
    local name = state.chars[row.charid] ~= nil and state.chars[row.charid].name or nil;

    if (name == nil) then
        return;
    end

    if (bit.band(row.flags, ITEM_EQUIPPED) ~= 0) then
        imgui.TextDisabled('worn');

        return;
    end

    -- Furniture standing in the Mog House layout. The server refuses the
    -- transfer regardless (and says so in the red status line); this tag says
    -- why BEFORE the click, the way 'worn' does, with the fix in the tooltip.
    if (bit.band(row.flags, ITEM_PLACED) ~= 0) then
        imgui.TextDisabled('placed');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Placed in the Mog House. Remove it from the layout\n'
                .. '(Mog House menu, on that character) to send or fetch it.');
        end

        return;
    end

    -- Priced in a bazaar. Same treatment as 'placed': the server refuses the
    -- transfer (alt_storage.cpp), so say why before the click instead of after.
    if (bit.band(row.flags, ITEM_BAZAARED) ~= 0) then
        imgui.TextDisabled('priced');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Priced in a bazaar. Clear the price\n'
                .. '(on that character) to send or fetch it.');
        end

        return;
    end

    local id       = string.format('%d_%d_%d', row.charid, row.loc, row.slot);
    local datFlags = datFlagsOf(row.itemid);

    if (isSelf(row.charid)) then
        if (bit.band(datFlags, FLAG_SCROLL) ~= 0 and row.loc == 0) then
            useButton(row, id, name);
        end

        -- Push, to whoever the header's "Send to" names. That is deliberately
        -- not the left-hand selection: the left pane answers "whose bags am I
        -- looking at", and conflating the two left every row of your own bag
        -- showing a hint instead of a button.
        local target = state.sendTo ~= nil and state.chars[state.sendTo] or nil;

        if (target == nil) then
            imgui.TextDisabled('no target');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Choose a character in "Send to" at the top of the window.');
            end

            return;
        end

        if (imgui.SmallButton(string.format('Send##s%s', id))) then
            issue(string.format('!dwq send %s %d %d', target.name, row.itemid, moveCount(row)));

            refetchVisible();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('Send %d to %s', moveCount(row), target.name));
        end

        return;
    end

    if (bit.band(datFlags, FLAG_CANUSE) ~= 0) then
        useButton(row, id, name);
    end

    if (imgui.SmallButton(string.format('Fetch##f%s', id))) then
        issue(string.format('!dwq fetch %s %d %d', name, row.itemid, moveCount(row)));

        refetchVisible();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(string.format('Take %d from %s', moveCount(row), name));
    end

    -- Send, from an alt's row straight to whoever the header's "Send to"
    -- names: the Get-button recipe (see the header, 1.11). Two typed lines,
    -- fetch then send, queued in order and never retried -- the item rides
    -- through your inventory because that is the only route the typed
    -- commands have. Not drawn when the target IS this row's character (a
    -- round trip to nowhere), and not drawn with no target at all -- Fetch
    -- stands alone then, exactly as it did before this button existed.
    local target = state.sendTo ~= nil and state.chars[state.sendTo] or nil;

    if (target ~= nil and target.charid ~= row.charid) then
        imgui.SameLine();

        if (imgui.SmallButton(string.format('Send##s%s', id))) then
            -- One count for both lines: they describe one movement, and
            -- reading the spin box twice would let a mid-queue edit send a
            -- different number than was fetched.
            local count = moveCount(row);

            issue(string.format('!dwq fetch %s %d %d', name, row.itemid, count));
            issue(string.format('!dwq send %s %d %d', target.name, row.itemid, count));

            refetchVisible();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Send %d to %s -- fetched from %s into your inventory first,\n'
                .. 'then sent on. Needs a free slot in your bags on the way.',
                moveCount(row), target.name, name));
        end
    end
end

local function itemRow(row)
    imgui.TableNextRow();
    imgui.TableNextColumn();

    drawIcon(row.itemid, 20);

    local name = itemName(row.itemid);

    if (bit.band(row.flags, ITEM_AUGMENTED) ~= 0) then
        name = name .. ' +';
    end

    imgui.Text(name);

    imgui.TableNextColumn();
    imgui.Text(row.qty > 1 and string.format('x%d', row.qty) or '');

    imgui.TableNextColumn();
    imgui.Text(LOC_NAMES[row.loc] or tostring(row.loc));

    imgui.TableNextColumn();
    transferButton(row);
end

local function bagsTab()
    local name = selectedName();

    if (name == nil) then
        imgui.Text('Pick a character.');

        return;
    end

    need('bag', state.selected);

    -- One click over `!dwq stack`: works for the character being played AND
    -- for any alt (the server has a live path and an offline path). Which
    -- rows may merge is the server's decision alone -- see the header.
    if (not stackUnsupported) then
        if (imgui.SmallButton('Stack all##dwbags_stack')) then
            issue(string.format('!dwq stack %s', name));

            refetchVisible();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Combine every item %s holds in more than one part-stack into as few\n'
                .. 'stacks as possible, into the inventory when there is room. Worn,\n'
                .. 'bazaared, signed and augmented copies stay where they are.', name));
        end

        imgui.SameLine();
        imgui.TextDisabled('Combines split stacks across every bag.');
    end

    if (imgui.BeginTable('##dwbags_items', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthFixed, 250, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 40, 0);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        -- Wide enough for Use + Fetch + Send side by side.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 165, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        local locs = T{ };

        for loc, _ in pairs(state.bags) do
            locs:append(loc);
        end

        table.sort(locs);

        for _, loc in ipairs(locs) do
            for _, row in ipairs(state.bags[loc].items) do
                itemRow(row);
            end
        end

        imgui.EndTable();
    end
end

--[[
* The upgrade sentence, assembled from the h| record's ids through the client's
* own resources -- names never ride this wire (the dwbags rule). The worn
* piece's name comes from the g| record already on screen for the same slot.
--]]
local function upgradeTooltip(hint)
    local donor     = state.chars[hint.fromcharid];
    local donorName = donor ~= nil and donor.name or 'another character';
    local where     = LOC_NAMES[hint.loc] or tostring(hint.loc);
    local worn      = state.gear[hint.slot];
    local against   = worn ~= nil
        and string.format('the worn %s scores %d', itemName(worn.itemid), hint.worn)
        or 'the slot is empty';

    if (isSelf(hint.fromcharid)) then
        return string.format('Your %s (%s) scores %d here; %s.\nClick to send it over.',
            itemName(hint.itemid), where, hint.score, against);
    end

    return string.format('%s\'s %s (%s) scores %d here; %s.\nClick to fetch it and send it over.',
        donorName, itemName(hint.itemid), where, hint.score, against);
end

local function gearTab()
    local name = selectedName();

    if (name == nil) then
        imgui.Text('Pick a character.');

        return;
    end

    need('gear', state.selected);

    -- The gear scan deliberately refuses the character being played -- a real
    -- player's gear is their own business -- so their tab is never asked.
    if (not hintsUnsupported and not isSelf(state.selected)) then
        need('hints', state.selected);
    end

    imgui.TextDisabled('Gearing is automatic. Click an alternative to pin it; Auto undoes the pin.');

    -- SizingFixedFit with explicit widths, not StretchProp: the "Instead" cells
    -- hold a variable stack of buttons whose width depends on item names, so a
    -- stretched column feeds its own width back into its content measurement and
    -- oscillates by a pixel or two every frame as the scrollbar comes and goes.
    -- Fixed columns cannot enter that loop.
    if (imgui.BeginTable('##dwbags_gear', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Slot', ImGuiTableColumnFlags_WidthFixed, 55, 0);
        imgui.TableSetupColumn('Wearing', ImGuiTableColumnFlags_WidthFixed, 190, 0);
        imgui.TableSetupColumn('Instead', ImGuiTableColumnFlags_WidthFixed, 190, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for slot = 0, 15 do
            local worn    = state.gear[slot];
            local options = state.options[slot];
            local hint    = state.hints[slot];

            if (worn ~= nil or (options ~= nil and #options > 0) or hint ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(SLOT_NAMES[slot]);

                if (hint ~= nil) then
                    imgui.SameLine();
                    imgui.TextColored(COLOR_HINT, '+');

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(upgradeTooltip(hint));
                    end
                end

                imgui.TableNextColumn();

                if (worn ~= nil) then
                    drawIcon(worn.itemid, 20);
                    imgui.Text(itemName(worn.itemid));

                    if (worn.pinned) then
                        imgui.SameLine();
                        imgui.TextColored(theme.colors.pin, '[pin]');
                    end
                else
                    imgui.TextDisabled('empty');
                end

                imgui.TableNextColumn();

                if (options ~= nil) then
                    for index = 1, math.min(#options, 4) do
                        local option = options[index];

                        if (imgui.SmallButton(string.format('%s##pin_%d_%d',
                                itemName(option.itemid), slot, index))) then
                            issue(string.format('!dwq equip %s %s %d', name, SLOT_NAMES[slot], option.itemid));

                            requested['gear'] = nil;
                        end
                    end
                end

                -- The upgrade recipe, one click away (UPGRADE_HINTS_PLAN.md
                -- Phase 3): the same typed lines a player would send -- fetch
                -- into your own inventory, then send to this character --
                -- queued one per interval, in order, NEVER retried. If the
                -- fetch is refused the send then refuses on its own terms;
                -- two red sentences is noisy, but nothing moves that the
                -- typed commands would not have moved.
                if (hint ~= nil) then
                    local donor = state.chars[hint.fromcharid];

                    if (donor ~= nil) then
                        if (imgui.SmallButton(string.format('Get %s##up_%d', itemName(hint.itemid), slot))) then
                            if (bit.band(donor.flags, CHAR_SELF) == 0) then
                                issue(string.format('!dwq fetch %s %d 1', donor.name, hint.itemid));
                            end

                            issue(string.format('!dwq send %s %d 1', name, hint.itemid));

                            refetchVisible();
                        end

                        if (imgui.IsItemHovered()) then
                            imgui.SetTooltip(upgradeTooltip(hint));
                        end
                    end
                end

                if (worn ~= nil and worn.pinned) then
                    if (imgui.SmallButton(string.format('Auto##auto_%d', slot))) then
                        issue(string.format('!dwq equip %s %s auto', name, SLOT_NAMES[slot]));

                        requested['gear'] = nil;
                    end
                end
            end
        end

        imgui.EndTable();
    end
end

local function findTab()
    imgui.PushItemWidth(240);

    if (imgui.InputText('##dwbags_search', state.search, 64,
            ImGuiInputTextFlags_EnterReturnsTrue)) then
        if (#state.search[1] >= 2) then
            state.findQuery = state.search[1];
            issue(string.format('!dwq find %s', state.search[1]));
        end
    end

    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.Button('Search')) then
        if (#state.search[1] >= 2) then
            state.findQuery = state.search[1];
            issue(string.format('!dwq find %s', state.search[1]));
        end
    end

    imgui.SameLine();
    imgui.TextDisabled('Every container on every character on your account.');

    if (imgui.BeginTable('##dwbags_finds', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthFixed, 230, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 40, 0);
        imgui.TableSetupColumn('Who', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        -- Wide enough for Use + Fetch + Send side by side.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 165, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(state.finds) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);
            imgui.Text(itemName(row.itemid));

            imgui.TableNextColumn();
            imgui.Text(row.qty > 1 and string.format('x%d', row.qty) or '');

            imgui.TableNextColumn();
            imgui.Text(state.chars[row.charid] ~= nil and state.chars[row.charid].name or '?');

            imgui.TableNextColumn();
            imgui.Text(LOC_NAMES[row.loc] or tostring(row.loc));

            imgui.TableNextColumn();
            transferButton(row);
        end

        imgui.EndTable();
    end
end

--[[
* What one group reads as: the destination its slots agree on, or nil when they
* do not.
*
* A GROUP THAT DISAGREES MUST SAY SO RATHER THAN PICK A WINNER. The server
* stores one destination per slot precisely so a layout can cut across these
* groups -- the owner's own puts head, neck and both earrings together, which is
* three of them -- and a renderer that showed the first slot's answer as the
* group's would be quietly wrong for exactly the layouts the storage exists to
* support.
--]]
local function groupDestination(group)
    if (group.other) then
        return state.prefs[0];
    end

    local agreed = nil;

    for _, slot in ipairs(group.slots) do
        local row = state.prefs[classOfSlot(slot)];

        if (row == nil) then
            return nil;
        end

        if (agreed == nil) then
            agreed = row;
        elseif (agreed.loc ~= row.loc) then
            return nil;
        end
    end

    return agreed;
end

local function destinationLabel(loc)
    for _, dest in ipairs(BAG_DESTINATIONS) do
        if (dest.loc == loc) then
            return dest.label;
        end
    end

    return LOC_NAMES[loc] or tostring(loc);
end

--[[
* Set every slot in a group to one destination.
*
* One command per slot, queued and throttled like everything else -- the server
* has no group verb because a group is not a thing it stores. Armour is five
* commands at 1.2s apiece, which is slow enough to be worth the queue counter
* the header already draws and is why the layout buttons exist: those are one
* command for all seventeen.
--]]
local function setGroup(name, group, destName)
    if (group.other) then
        issue(string.format('!dwq bagpref %s items %s', name, destName));
    else
        for _, slot in ipairs(group.slots) do
            issue(string.format('!dwq bagpref %s %s %s', name, SLOT_NAMES[slot], destName));
        end
    end

    requested['bagpref'] = nil;
end

local function prefsTab()
    local name = selectedName();

    if (name == nil) then
        imgui.Text('Pick a character.');

        return;
    end

    if (prefsUnsupported) then
        imgui.TextColored(theme.colors.err, 'This server does not have bag routing yet.');
        imgui.TextDisabled('Everything else in this window still works.');

        return;
    end

    need('bagpref', state.selected);

    imgui.TextDisabled('Where an item lands in ' .. name .. '\'s bags when you send it, or when they collect a');
    imgui.TextDisabled('delivery. Gear defaults into the wardrobes -- they hold nothing else, so it keeps');
    imgui.TextDisabled('the four bags they actually carry free for everything else.');

    imgui.Separator();

    -- The layout row: seventeen slots in one command.
    --
    -- NONE OF THESE IS DISABLED WHEN IT IS THE CURRENT ONE. Re-applying the
    -- layout you are already on is the fastest way back from a hand-edit, and
    -- disabling the button would hide the one control that does it. Which one
    -- is current is said in words on the line below instead, where it cannot be
    -- mistaken for a disabled control.
    imgui.Text('Layout:');

    for _, layout in ipairs(BAG_LAYOUTS) do
        imgui.SameLine();

        if (imgui.SmallButton(string.format('%s##layout_%d', layout.label, layout.id))) then
            issue(string.format('!dwq bagpref %s layout %s', name, layout.name));

            requested['bagpref'] = nil;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(layout.blurb);
        end
    end

    local current = nil;

    for _, layout in ipairs(BAG_LAYOUTS) do
        if (state.layout == layout.id) then
            current = layout;
        end
    end

    if (current ~= nil) then
        imgui.TextColored(theme.colors.ok, string.format('Currently: %s -- %s', current.label, current.blurb));
    else
        imgui.TextDisabled('Currently: a layout of your own. Any button above replaces it.');
    end

    if (imgui.BeginTable('##dwbags_prefs', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -80 })) then
        imgui.TableSetupColumn('Group', ImGuiTableColumnFlags_WidthFixed, 140, 0);
        imgui.TableSetupColumn('Goes to', ImGuiTableColumnFlags_WidthFixed, 190, 0);
        imgui.TableSetupColumn('Free', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, group in ipairs(BAG_GROUPS) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(group.label);

            local dest = groupDestination(group);

            imgui.TableNextColumn();
            imgui.PushItemWidth(180);

            local shown = dest ~= nil and destinationLabel(dest.loc) or 'Mixed';

            if (imgui.BeginCombo(string.format('##dest_%s', group.name), shown)) then
                for _, option in ipairs(BAG_DESTINATIONS) do
                    -- A wardrobe holds nothing but equipment, so it is not
                    -- offered for the group that is not equipment. The server
                    -- refuses it too; this only keeps it off the list.
                    if (not (group.other and isWardrobeLoc(option.loc))) then
                        if (imgui.Selectable(option.label, dest ~= nil and dest.loc == option.loc)) then
                            setGroup(name, group, option.name);
                        end
                    end
                end

                if (imgui.Selectable('Default', dest ~= nil and dest.isdefault)) then
                    setGroup(name, group, 'auto');
                end

                imgui.EndCombo();
            end

            imgui.PopItemWidth();

            if (dest == nil) then
                -- Split across containers: name the slots, because that is the
                -- only honest rendering and it is also how you fix it.
                local parts = T{ };

                for _, slot in ipairs(group.slots) do
                    local row = state.prefs[classOfSlot(slot)];

                    if (row ~= nil) then
                        parts:append(string.format('%s %s', SLOT_NAMES[slot], destinationLabel(row.loc)));
                    end
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Split across bags:\n' .. table.concat(parts, '\n')
                        .. '\nChoosing one here puts the whole group in it.');
                end
            elseif (not dest.isdefault) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.pin, '*');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Changed from the default.');
                end
            end

            imgui.TableNextColumn();

            if (dest ~= nil) then
                imgui.Text(tostring(dest.free));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Free cells there right now. Full is not a problem -- an item that\n'
                        .. 'does not fit falls through to the spare wardrobes, then to the\n'
                        .. 'ordinary bags, and only then to the delivery box.');
                end
            else
                imgui.TextDisabled('-');
            end
        end

        imgui.EndTable();
    end

    imgui.Separator();

    -- Tidy. Its own row at the bottom, because it is the one control here that
    -- moves items rather than recording a preference.
    if (isSelf(state.selected)) then
        imgui.TextDisabled('Sort this character\'s own bags in the game\'s own menu -- this only sorts alts.');
    else
        if (imgui.Button('Tidy bags now')) then
            issue(string.format('!dwq tidy %s', name));

            refetchVisible();
            requested['bagpref'] = nil;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Re-file everything %s is already holding to match the layout above.\n'
                .. 'Sorts the wardrobes, inventory, satchel, sack and case; leaves the mog\n'
                .. 'safe, locker and storage alone. Never moves what they are wearing.\n'
                .. 'They must not be logged in.', name));
        end

        imgui.SameLine();
        imgui.TextDisabled('Applies the layout to what they already have.');
    end
end

local function boxTab()
    if (state.selected ~= nil) then
        need('box', state.selected);
    end

    -- A send lands in the alt's bags outright now, so this tab is the exception
    -- shelf rather than the route: it holds what could not be written straight
    -- in -- a character who was logged in, a character whose bags were full --
    -- along with real deliveries and auction house payouts. All of it is
    -- collected the next time that character is called.
    imgui.TextDisabled('Waiting to be collected. Sends normally land in the bag at once; these could not,');
    imgui.TextDisabled('so they arrive the next time you call that character.');

    if (#state.box == 0) then
        imgui.Text('Nothing waiting.');

        return;
    end

    if (imgui.BeginTable('##dwbags_box', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthFixed, 250, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 40, 0);
        imgui.TableSetupColumn('For', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('From', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(state.box) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);
            imgui.Text(itemName(row.itemid));

            imgui.TableNextColumn();
            imgui.Text(row.qty > 1 and string.format('x%d', row.qty) or '');

            imgui.TableNextColumn();
            imgui.Text(state.chars[row.charid] ~= nil and state.chars[row.charid].name or '?');

            imgui.TableNextColumn();
            imgui.Text(row.sender or '');
        end

        imgui.EndTable();
    end
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        refreshChars();
        forget();
    end

    imgui.SameLine();

    -- A throttled queue has to look like progress rather than like nothing
    -- happening, which is exactly how the unthrottled version failed.
    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    else
        imgui.TextDisabled('');
    end

    -- THE MESSAGE LINE GETS ITS OWN ROW, AND ERRORS ARE RED.
    --
    -- Every refusal is a rule with a reason -- Rare/Ex, worn, logged in, bag
    -- full -- and that reason is the only thing telling a player what to do
    -- instead. It used to share a line with the queue counter, in the same grey
    -- as everything else, which in a busy chat log made it read as decoration.
    -- It is now hard to miss and persists until something replaces it.
    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    -- The transfer controls live here rather than in a tab, because they apply
    -- to every tab that has a Send or Fetch button on it and the owner hit the
    -- gap immediately: the Find tab had rows to move and no way to say how many.
    imgui.Text('Send to:');
    imgui.SameLine();
    imgui.PushItemWidth(140);

    local targetName = (state.sendTo ~= nil and state.chars[state.sendTo] ~= nil)
        and state.chars[state.sendTo].name or '(pick one)';

    if (imgui.BeginCombo('##dwbags_target', targetName)) then
        for _, member in ipairs(orderedChars()) do
            if (bit.band(member.flags, CHAR_SELF) == 0) then
                if (imgui.Selectable(member.name, state.sendTo == member.charid)) then
                    state.sendTo = member.charid;
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    imgui.SameLine();
    imgui.Checkbox('Whole stack', state.sendAll);

    if (not state.sendAll[1]) then
        imgui.SameLine();
        imgui.PushItemWidth(90);
        imgui.InputInt('##dwbags_qty', state.sendQty, 1, 10);
        imgui.PopItemWidth();

        -- ImGui's InputInt has no lower bound of its own -- the minus button and
        -- the keyboard will both take it below zero and leave it there -- so the
        -- bound is applied to the buffer every frame. Done here rather than only
        -- inside moveCount so the player never sees a number the window would
        -- not act on.
        if ((tonumber(state.sendQty[1]) or 1) < 1) then
            state.sendQty[1] = 1;
        end
    end

    imgui.Separator();

    charList();

    imgui.SameLine();

    imgui.BeginChild('##dwbags_right', { 0, 0 }, ImGuiChildFlags_None);

    if (imgui.BeginTabBar('##dwbags_tabs')) then
        if (imgui.BeginTabItem('Bags')) then
            bagsTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Gear')) then
            gearTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Find')) then
            findTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('In transit')) then
            boxTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Storage')) then
            prefsTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    imgui.EndChild();
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather than
* the addon.
*
* An error thrown inside a d3d_present handler is raised on EVERY frame -- sixty
* times a second -- and the addon host answers a long enough run of them by
* unloading the addon. The failure mode is therefore "the console fills with the
* same line and the window disappears", which tells a player nothing and loses
* the one copy of the message worth reading.
*
* So: Begin and End stay outside the pcall, which is what keeps ImGui's window
* stack balanced whatever happens in between; the error is reported once; and
* the window closes itself. Everything the window does is still reachable as
* !squad commands, so closing it is a real fallback rather than a dead end.
--]]
ashita.events.register('d3d_present', 'dwbags_present', function ()
    -- Before the visibility check: a Send issued a moment before the window was
    -- closed still has to reach the server -- and a refetch armed by a click
    -- that then closed the window still has to flush its who/find.
    pumpQueue();
    pumpRefetch();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    -- 860, not the old 780: the action column grew a Send button (1.11), and
    -- the Find tab's five columns plus the character list no longer fit the
    -- old width. FirstUseEver means a player who has already sized the window
    -- keeps their size; this is only the fresh install's opening shape.
    imgui.SetNextWindowSize({ 860, 460 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Bags##dwbags', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwbags'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwbags'):append(chat.message('Window closed. Everything it does also works as !squad commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Watch what the player sends, so the window keeps up with commands typed
* outside it.
*
* `!squad call` collects everything waiting in the delivery box, which empties
* the In transit tab -- and the window had no way of knowing, so it went on
* showing items that had already arrived. The same goes for a dismiss, or a send
* or fetch typed by hand. Matching our own outgoing chat is exact and costs
* nothing: 0x00B5 is Kind at 0x04, a pad byte, then the message at 0x06.
*
* Only `!squad` is matched for invalidation, not `!dwq`: the addon's own
* commands already know what they invalidated.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE, though. The
* client's rate limit is on chat, not on this addon, so a query fired in the
* same frame as something the player typed is the one that gets dropped -- and
* the invalidation above is precisely what fires a query in that frame. Stamping
* the player's own line as a send makes the follow-up wait its interval instead
* of racing it.
--]]
ashita.events.register('packet_out', 'dwbags_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dwq') then
        lastSend = os.clock();
    end

    if (message:lower():sub(1, 6) == '!squad') then
        forget();

        if (state.findQuery ~= nil and state.findQuery ~= '') then
            issue(string.format('!dwq find %s', state.findQuery));
        end
    end
end);

ashita.events.register('command', 'dwbags_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwbags' and args[1] ~= '/bags')) then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        refreshChars();
        forget();

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported` only
        -- exists to stop one bad frame printing sixty lines a second, not to
        -- silence a different error a week later in the same session.
        state.reported = false;

        refreshChars();
        forget();
    end
end);

ashita.events.register('load', 'dwbags_load', function ()
    print(chat.header('dwbags'):append(chat.message('/dwbags opens the account bag browser. Everything it does also works typed as !squad.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new account view.
ashita.events.register('packet_in', 'dwbags_zonein', function (e)
    if (e.id == 0x000A) then
        state.chars    = T{ };
        state.selected = nil;
        state.bags     = T{ };
        state.gear     = T{ };
        state.options  = T{ };
        state.hints    = T{ };
        state.box      = T{ };
        state.finds    = T{ };
        state.prefs    = T{ };
        state.layout   = 255;
        state.sendTo   = nil;
        state.findQuery = '';
        state.statusBad = false;

        -- An open window re-fetches on its own, the way dwsquad and dwjobs
        -- do in this same handler; a closed one waits for the open transition
        -- (which calls refreshChars) rather than spending a chat line nobody
        -- is looking at.
        if (state.open[1]) then
            state.status = 'Loading...';

            refreshChars();
            forget();
        else
            state.status = 'Press Refresh.';
        end

        -- Asked again on the other side: the server may have grown the hints
        -- verb since the last look (a map restart logs everyone out).
        hintsUnsupported = false;
        prefsUnsupported = false;
        stackUnsupported = false;
    end
end);
