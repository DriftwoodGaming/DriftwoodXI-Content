--[[
* DriftwoodXI -- dwwarehouse
*
* One account-wide pool of storage, from whichever character you are logged in
* on. Search it, take things out of it, put things into it, and pull a named
* bundle of materials in one click.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It is a sibling of dwbags (`addons/dwbags/dwbags.lua:8-21`) and inherits that
* rule unchanged. It holds no item data of its own, caches nothing to disk
* except the player's own kit names, and has no way to move an item that the
* typed command surface does not already have. Every read is `!dww
* who|page|crystals` and every write is `!dww put|take|trash|stack|stashall|
* pull|pin|unpin|buy|sell|cluster|storecrystals|takecrystals`, which are the
* same server-side functions `!warehouse` reaches -- the only difference is
* that they answer in compact records under the sender name _DWWDATA, which
* this addon parses and blocks before the chat log sees them.
*
* THE CRYSTALS TAB (1.12.0, server 2026-09-05). A crafter's shelf silts up with
* crystals, and the tab is the two ways out that create nothing: Cluster asks
* the server to turn every twelve crystals of an element into a cluster and
* stack the clusters (the exchange an Ephemeral Moogle makes when you deposit
* crystals and draw clusters), and Store Crystals moves the shelf's crystals
* and clusters into THE MOOGLES' OWN LEDGER -- the per-character tally every
* Ephemeral Moogle reads -- so any moogle can hand them back, and so can the
* tab's Retrieve. The `c|` record carries that ledger, and a server that never
* sends one gets no crystal button drawn at all, the Sell button's rule.
*
* THE MARKET LANE (1.9.0, server 2026-09-01). A Sell button on every shelf row
* lists it on the DWAH market straight from the warehouse -- no bag slot, no
* second window. The server's `sell` verb hands the row to the market store's
* OWN listing gate (the one the /dwah Sell tab and the Jeuno counter run), so
* nothing sells from here that could not sell from a bag; the fee is charged
* when it sells, exactly as any other listing. The `s|` record carries the
* account's market standing, and a server that never sends one gets no Sell
* button drawn at all -- the honest rendering of a server without the lane.
*
* WHY THAT MATTERS HERE MORE THAN ANYWHERE. The warehouse is the one container
* whose capacity the server owns outright, so a client that could invent a row
* would be inventing storage. Every rule -- the Rare re-check on the way out,
* the deposit refusals, the capacity ceiling -- lives in the server's C++ and
* runs identically whichever way the command arrived. Nothing below is trusted
* by anything.
*
* THERE IS NO BOUND LANE ANY MORE (2026-08-08). An EX, augmented or NoDelivery
* item used to be stored FOR ITS DEPOSITOR: the row carried that charid and no
* other character on the account could take it back out. The warehouse exists
* to move gear around an account, so that rule was working against the feature
* it lived in, and it is gone -- every row belongs to the account and any
* character on it may withdraw any row. What this addon lost with it: the two
* wire flag bits below, and the disabled Take button they drew.
*
* WHY THE SERVER DOES NOT SEND ITEM NAMES. Same answer as dwbags: this addon is
* inside the client, and the client already has the name, the icon and the type
* of every item in its own DAT resources. Sending them would be paying twice,
* and it is what keeps a packed `w|` record inside the chat buffer the whole
* protocol has to fit through.
*
* THE MODEL IS PAGED, NOT PUSHED. A thousand rows do not fit in one chat line,
* so a full sync is `page 0..N` walked on this addon's own 1.2s pump with a
* progressive render behind it. After that, deltas keep it current: every
* mutation answers with the `w|`/`r|` rows it changed plus a `k|` carrying the
* account's generation counter. A generation this addon did not cause -- a
* second client on the same account moving something -- is a gap, and a gap
* repages rather than guessing.
*
* THE DEPOSIT TAB READS CLIENT MEMORY, WHICH IS THE ONE PLACE IT CAN. Nothing
* on the wire says what is in your own inventory right now; the client knows,
* and `!dww put` names the slot AND the item id precisely so the server can
* refuse a claim that has gone stale ("bag changed"). A wrong read here costs a
* refusal sentence, never a wrong item.
*
* KITS ARE LOCAL AND ALWAYS WILL BE. A kit is a name for a list of item ids and
* quantities; pulling one emits ordinary `!dww pull` lines. The server never
* hears the name and stores nothing about it. They live in Ashita's settings
* library, which already files everything under `<charname>_<serverid>`, so
* per-character separation is free (the dwmacro precedent,
* `addons/dwmacro/dwmacro.lua:85-90`).
*
* WHAT 1.13.0 CHANGED, and why any of it is in a header. It is ONE release and
* it came out of two passes over this file, so it is written as two lists; the
* comments below carry the same one number, because one number is what players
* receive. Most of it is facts about the WIRE rather than about the window,
* which is where this addon's bugs live.
*
* THE FIRST PASS:
*
*   - Every number off the wire now comes through `intOf`. Almost all of them
*     reach `string.format('%d', ...)` eventually, and a number with no
*     integer representation is answered by the client's LuaJIT with silent
*     truncation (2.5 sends a `!dww take` aimed at row 2) or a huge negative
*     (a NaN), and by Lua 5.4 -- the offline harness -- with a throw the
*     render pcall answers by closing the window. The server clamps on the
*     way out for the same reason (a thrown ! command broadcasts in /say);
*     this is the same discipline on the way in.
*   - `history` (1.11.0) is an ADDITIVE verb that shipped with no unsupported
*     latch, which is the one thing every additive verb in this suite owes.
*     An older core answered every hover of the Sell strip's History button
*     with a red banner and a red chat line, twenty seconds apart, for ever.
*   - An envelope whose `z|` never arrived hung the window for the session:
*     `inbound` stayed open, and because the `d|` had already stamped the page
*     ask ANSWERED, the sweep sat on "loading" with both self-repair paths
*     disarmed behind `syncing`. There is a watchdog now (dwah 1.6.0's).
*   - A protocol mismatch, and a sweep that gave up, each left half of that
*     same state behind -- `syncing` true in one, `sweepGen` unspent in the
*     other. Both stand fully down now.
*   - The one line this addon sent without going through the queue (the
*     History click) went through neither the send throttle nor the zoning
*     hold. Every line goes through `issue()`.
*   - And the queue itself has a ceiling. It drains at one line per 1.2s and
*     nothing bounded it, so a mouse run down three hundred Take buttons was
*     six minutes of a window that answers every click by doing nothing.
*
* THE SECOND PASS, with fresh eyes on the same file. Its theme is that four
* separate pieces of state could each be left holding a half-truth that every
* freshness check in this window then agreed with:
*
*   - A `q|` was acted on WHOEVER asked for it. `d|` stamps the outstanding
*     `page` ask answered without saying which page it is about, so a stale
*     answer -- a sweep restarted while an older `!dww page 7` was still on
*     the wire, or a page re-asked and then answered twice -- moved the walk
*     to wherever it landed. When that page is the LAST one the walk is
*     declared finished on a model holding one page of twelve, with `syncing`
*     false and `syncGen` equal to `gen`: a silently short list nothing in
*     this addon can notice. A page answer that does not match the ask now
*     drives nothing and puts the real ask back on the clock, and startSync
*     drops any page line still waiting in the queue.
*   - The pin list was emptied at `d|` and refilled behind it, the one
*     section of this window still breaking the commit-at-`z|` rule. An
*     envelope cut short -- the watchdog's own case -- left the character
*     with no pins drawn at all while the server went on honouring every one
*     of them. Staged and committed whole.
*   - `!dww who` had no answer clock, and it is the ONLY envelope that
*     carries the pins, the market standing that draws the Sell buttons, the
*     crystal ledger that draws the Crystals tab and the purchase count. One
*     lost `who` therefore rendered a full-featured server as a bare one, for
*     the rest of the login, with nothing on screen to say so.
*   - `os.date` is another `string.format('%d', ...)`: localtime has no
*     answer for a stamp out of range (Lua 5.4 raises, the client's LuaJIT
*     hands back nil and the sale line reads 'nil'), and ZERO is out of
*     range everywhere west of Greenwich -- zero being the intOf fallback for
*     a field the protocol documents as silently truncatable. One malformed
*     sale row drew a non-date for half the player base and not the other.
*
* And two things the first pass got HALF right, which is the part worth
* writing down because both read as finished: the greyed page arrows' "why"
* tooltips were dead code (ImGui reports no hover at all for an item inside a
* disabled scope, so the sentence is never shown), and the window's new floor
* was set at 620 wide when the header strip it exists to protect needs closer
* to 800 -- so the last category chips and half the market line could still
* be dragged off the screen. Measuring beats choosing.
*
* AND THE PASS AFTER THAT MEASURED THE REST OF THE LAYOUT, which is where the
* remaining bugs were hiding in plain sight. Three rows in this window added
* up past the width the window OPENS at, and ImGui clips a SameLine rather
* than wrapping it -- so the control at the end of each was simply not on
* screen at the default size, with a tooltip nobody could reach:
*
*   - the header's second row (Find, six chips, the sort combo, 'Whole stack'
*     and the quantity box that appears when it is unticked -- about 910 in
*     an 840-wide window), which is now two rows;
*   - the sell strip (an icon, the item name, a price box, the net, and four
*     buttons -- about 830), whose buttons now take a row of their own;
*   - the Deposit tab's first row, which carried the first sentence of its
*     own tooltip in forty-six characters and now carries the number that
*     decides whether Stash All will finish.
*
* The same pass gave the status line the one thing it never had: an END. Every
* sentence stayed until another replaced it, so a green 'Copied 12 row(s)' and
* a red refusal were both still under the header an hour later -- and red is
* the strongest thing this header can say. Events fade after half a minute of
* WALL time; the four conditions (a protocol mismatch, the row-count repair, a
* sweep that gave up, an account being written from elsewhere) stay until
* something answers them, and each says which kind it is on hover.
*
* THE SELECTION, THE BATCH AND THE VENDOR (1.15.0, server 2026-09-14). The
* owner's report was one sentence long and named the whole problem: "im
* avoiding purging my wh because its 1 by 1". A thousand-slot shelf whose only
* Trash button takes one row is a shelf nobody tidies.
*
*   - Every shelf row now has a TICK, and the strip above the table carries
*     Select all / None / Invert (over the FILTERED view, which is what the
*     player is looking at), Select same item, and the two batch buttons.
*   - 'Trash Selected (N)' and 'Vendor Selected (N)' each ask ONCE for the
*     whole set, with the count and what the pile is worth in the sentence,
*     and then send `!dww trashmany` / `!dww vendormany` lines -- the
*     selection chopped into lines that fit the server's 130-byte budget, the
*     way a long kit already becomes several `!dww pull` lines. The server
*     answers every row: the ones that moved ride the ordinary `r|` delta,
*     and anything it refused comes back as its own sentence naming the item.
*   - VENDOR is the shop counter without the walk: the server sells the row at
*     the item template's own base price -- the number a shopkeeper quotes --
*     and pays the gil straight into the pouch. The `v|` record carries those
*     prices per item id so every row can show what it is worth, and the `g|`
*     record carries the gil in hand and the ceiling it may not pass. No `g|`,
*     no Vendor button: the Sell button's rule, one lane over.
*   - And the shelf grew what the selection needs to be usable: a Value column
*     and a Value sort, a 'Sellable only' filter for when Vendor is the
*     intent, and a readout of what is ticked. Every batch control that
*     cannot be pressed is greyed and says why on hover.
*
* TURN IT OFF AND NOTHING IS LOST. `!warehouse` does all of it typed.
--]]

addon.name    = 'dwwarehouse';
addon.author  = 'DriftwoodXI';
addon.version = '1.17.1';
addon.desc    = 'Account-wide virtual storage for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this file,
-- so a blocked line is already flagged by the time they see it.
echo.install();

local C = ffi.C;

--[[
* Whether this player's Ashita has the two calls 1.13.0 wants but the suite
* cannot assume.
*
* ASKED ONCE, AT LOAD, AND NEVER AGAIN. An addon updates through the content
* feed while the client stays at whatever build the player first installed,
* so a function named in Ashita's own SDK annotations can still be missing on
* the machine this file is running on -- and calling a nil is a Lua error
* sixty times a second until the host unloads the addon. The controls that
* need them simply do not draw where they are absent, which is the honest
* rendering and not a degraded one (dwfishing.lua:125-126, dwgambits' guard).
--]]
local CAN_CLIPBOARD = (type(imgui.SetClipboardText) == 'function');
local CAN_CONSTRAIN = (type(imgui.SetNextWindowSizeConstraints) == 'function');

--[[
* The D3D device, fetched on first use rather than at load.
*
* This addon is loaded from the launcher's boot script, which runs long before
* the client has a rendering device -- and `d3d.get_device()` at file scope
* makes the whole addon fail to load when it answers nothing. Nothing here
* needs a device until the first icon is drawn, by which point there certainly
* is one. (dwbags.lua:107-116.)
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server uses
-- it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWWDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

--[[
* `w|` flag bits, as the server packs them (DWWAREHOUSE_PLAN.md, wire section).
*
* BITS 8 AND 16 ARE NOT DEFINED HERE AND THAT IS THE POINT. They were
* BOUND_OTHER and BOUND_MINE, two halves of one fact: which side of a bound
* row's lane this character was on. The lane is retired (see the header) and
* the server sets neither bit, so a constant for them here would be a name for
* something that never arrives -- and the next reader would have to disprove it
* before trusting the Take button. They are not re-used for anything else, so
* an addon of any age against a server of any age reads a row the same way.
--]]
local WH_RARE        = 1;
local WH_EX          = 2;
local WH_AUGMENTED   = 4;

-- The client's own inventory, which is the only container `put` reads from.
-- Slot 0 is gil and is deliberately skipped: currency is a deposit refusal on
-- the server (R3) and a row for it would only ever be a button that fails.
local INVENTORY_CONTAINER = 0;
local INVENTORY_SLOTS     = 80;

--[[
* Category chips, keyed on the client DAT item type (Ashita's
* `plugins/sdk/ffxi/enums.h` ItemType).
*
* THESE ARE A FILTER, NOT A TAXONOMY, and the DAT does not have the categories
* a player has in their head. There is no "food" type -- food and medicine are
* both UsableItem -- so the Food chip shows both, which is the honest rendering
* of what the client actually knows. Nothing on the server turns on any of
* this; it narrows a list and that is all.
*
* Each chip carries its own `hint` (1.13.0): the paragraph above is the
* answer to "why does Food show medicine", and it was written in a comment
* nobody browsing a warehouse can read. The chips are the one set of controls
* here whose labels are this addon's OPINION rather than a fact, so they are
* exactly the ones that owe an explanation on hover.
--]]
local CATEGORIES = {
    { name = 'All',       all   = true,
      hint  = 'Every stored row, unfiltered.' },
    { name = 'Weapons',   types = { [4] = true },
      hint  = 'Anything the client files as a weapon, including ranged and ammo.' },
    { name = 'Armor',     types = { [5] = true },
      hint  = 'Anything the client files as armour, including accessories.' },
    { name = 'Materials', types = { [1] = true, [3] = true, [8] = true },
      hint  = 'Crafting materials, crystals and general items -- the three\n'
          .. 'client types a synth draws from.' },
    { name = 'Food',      types = { [7] = true },
      hint  = 'Food AND medicine: the client has one "usable item" type for\n'
          .. 'both, so a chip that showed only food would be inventing one.' },
    { name = 'Other',     other = true,
      hint  = 'Everything none of the other chips covers -- keys, furnishings,\n'
          .. 'anything the client types in a way this window does not name.' },
};

--[[
* Both forms of each chip's widget id, built once at load (1.13.0).
*
* The header formatted six of them EVERY FRAME, for two strings per chip that
* can never differ: a chip's label only ever picks up or loses its brackets.
* Three hundred and sixty short-lived strings a second for a row of six
* buttons -- the same hoist the 1.13.0 pass made for the shelf rows
* (rowLabels) and the bag slots (idsForSlot) and did not reach here.
--]]
for index, category in ipairs(CATEGORIES) do
    category.idPlain  = string.format('%s##dww_cat_%d', category.name, index);
    category.idPicked = string.format('[%s]##dww_cat_%d', category.name, index);
end

local SORTS = {
    { name = 'Name' },
    { name = 'Qty' },
    -- No timestamp rides the wire. `id` is AUTO_INCREMENT on the warehouse
    -- table, so a bigger row id IS a later deposit -- newest-first is rowid
    -- descending and needs nothing added to the protocol to be true.
    { name = 'Newest' },
    -- Both local (1.9.0): the DAT's item type and the equip level, read from
    -- the client's own resources like the name is. Level puts the highest
    -- gear first, which is how a shelf of spares is actually browsed.
    { name = 'Type' },
    { name = 'Level' },
    -- Server-said (1.15.0): the `v|` record's shop price times the quantity on
    -- the row, biggest first -- "what is this shelf worth, and what should I
    -- be selling" answered without typing anything. A row the server priced at
    -- nothing sorts to the bottom, which is where an unsellable row belongs
    -- when the question is about money. An older server sends no prices at
    -- all and every row is worth nothing, so the sort quietly falls back to
    -- the name order underneath it rather than shuffling.
    { name = 'Value' },
};

-- The market's own price ceiling (market_core.lua MAX_PRICE): a price the
-- strip would send past it is refused there, so it is not offered here.
local MAX_PRICE = 999999999;

--[[
* The eight elements of the Crystals tab (1.12.0), in the server's order --
* xi.element FIRE..DARK, which is also the order the `c|` record packs its
* counts and the order every Ephemeral Moogle's ledger is read. The item ids
* are the client's own (crystals 4096..4103, clusters 4104..4111, both
* contiguous); the word is what the server's verbs take. Display names still
* come from the DATs at draw time, like every other row's.
--]]
local ELEMENTS = {
    { name = 'Fire',      word = 'fire',      crystal = 4096, cluster = 4104 },
    { name = 'Ice',       word = 'ice',       crystal = 4097, cluster = 4105 },
    { name = 'Wind',      word = 'wind',      crystal = 4098, cluster = 4106 },
    { name = 'Earth',     word = 'earth',     crystal = 4099, cluster = 4107 },
    { name = 'Lightning', word = 'lightning', crystal = 4100, cluster = 4108 },
    { name = 'Water',     word = 'water',     crystal = 4101, cluster = 4109 },
    { name = 'Light',     word = 'light',     crystal = 4102, cluster = 4110 },
    { name = 'Dark',      word = 'dark',      crystal = 4103, cluster = 4111 },
};

-- The four widget ids each element's row needs, built once at load for the
-- CATEGORIES reason above (1.13.0): eight rows formatted four ids each every
-- frame the tab was open, for thirty-two strings that never differ.
for index, element in ipairs(ELEMENTS) do
    element.idStore    = string.format('Store##dww_cstore_%d', index);
    element.idQty      = string.format('##dww_ctake_%d', index);
    element.idRetrieve = string.format('Retrieve##dww_ctake_%d', index);
    element.idAll      = string.format('all##dww_ctakeall_%d', index);
end

-- A cluster is twelve crystals, on the server and at every moogle.
local CLUSTER_UNITS = 12;

--[[
* The hover text, as a table rather than as sixty string literals scattered
* through the render pass (1.13.0, the dwquest BADGE_TIPS shape).
*
* WHAT EARNS ONE. A control whose label does not already say what it does, a
* number with a unit, an abbreviation, a tab whose name is a word this server
* invented, and every control that is greyed or missing -- where the tip has
* to say WHY it cannot be pressed, because a button that is simply absent is
* the one thing a player cannot ask a question about. What does NOT earn one:
* anything whose label is already the whole sentence ('Cancel', 'Never mind',
* the category chips' own words are not enough -- those DO earn one, because
* 'Materials' and 'Other' are this addon's opinion about the client's item
* types and not the player's).
*
* The tips that quote a live number are NOT here -- they are built where the
* number is, because a tip that says '%d' is a tip nobody reads twice.
--]]
local TIPS = {
    tabWarehouse = 'Everything stored on the shelf, for the whole account.\n'
        .. 'Take it back, throw it away, or list it on the market from here.',
    tabDeposit   = 'What your own bags are holding right now, read from the client.\n'
        .. 'Put things in one at a time, tick several, or stash the lot.',
    tabCrystals  = 'The crafter\'s way out of a shelf full of crystals: make clusters,\n'
        .. 'or move them into the Ephemeral Moogles\' own ledger and back.',
    tabKits      = 'Named lists of items you pull out together -- a recipe\'s materials\n'
        .. 'in one click. Kits are yours, kept on this PC, never on the server.',

    capacity     = 'Slots used out of the slots your account owns.\n'
        .. 'One stored row is one slot, whatever the stack size.\n'
        .. 'The server owns this number: rewards raise it, and so does Buy Slot.',

    find         = 'Narrows both lists to item names containing what you type.\n'
        .. 'Plain text, not a pattern -- brackets and dashes are safe.\n'
        .. 'It searches the WHOLE shelf, not just the page on screen.',

    sort         = 'How the shelf is ordered.\n'
        .. 'Name -- alphabetical.  Qty -- biggest stacks first.\n'
        .. 'Newest -- most recently deposited first.\n'
        .. 'Type -- weapons, armour, materials and so on together.\n'
        .. 'Level -- highest item level (or equip level) first.',

    wholeStack   = 'On: Take and Stash move the whole row or slot.\n'
        .. 'Off: they move the number in the box beside it.\n'
        .. 'Remembered for this character.',
    takeQty      = 'How many one Take or Stash moves while "Whole stack" is off.\n'
        .. 'Never below 1 -- a negative would reach the server as a huge number.',

    pagePrev     = 'The previous 300 rows.',
    pageNext     = 'The next 300 rows.',

    --[[
        THE REASON AN ARROW IS GREY LIVES HERE, ON THE COUNTER BETWEEN THEM
        (1.13.0), and not on the arrow it is about.

        ImGui reports NO hover for an item inside a BeginDisabled scope
        unless the hover is asked for with the newest-generation
        allow-when-disabled flag, which this suite deliberately does not use:
        a constant missing from the build a player happens to have installed
        is a Lua error sixty times a second. So a
        SetTooltip written after the EndDisabled of a greyed control never
        fires, while reading in the source exactly like the courtesy the
        house rule asks for. The two 'Already on the first/last page'
        sentences 1.13.0 added were that, and this is where they went.
        (dwbags found the same shape in the same week.)
    ]]
    pager        = 'Which 300-row slice of the list is on screen.\n'
        .. 'The arrow for the end you are already at is greyed out.\n'
        .. 'Find and the category chips still search every page, not just this one.',

    showing      = 'Only 300 rows are drawn at a time -- a thousand rows of widgets\n'
        .. 'costs frames. Find and the chips still search every page.',

    changed      = 'Another character on this account moved something, so the list\n'
        .. 'on screen is a moment behind. It is being read again by itself --\n'
        .. 'nothing is lost and there is nothing to press.',
    loading      = 'Reading the shelf, one page of 300 rows every 1.2 seconds:\n'
        .. 'the client rate-limits chat and every ! line is a chat line.\n'
        .. 'Rows appear as the pages land.',

    copy         = 'Copy the rows on this page to the clipboard, one per line,\n'
        .. 'as "name x qty" -- for a shopping list or a linkshell post.',
    copyEmpty    = 'Nothing to copy: no row matches the current search.',

    -- The selection strip (1.15.0). Every one of these earns a tip by the
    -- rule above: a label that does not say what it does, or a control whose
    -- scope is not obvious from looking at it -- which is all four, because
    -- "all" here means "all of what is filtered" and not "all of the shelf".
    rowTick      = 'Tick this row for Trash Selected or Vendor Selected.\n'
        .. 'Ticking is local: nothing is sent until you press one of them\n'
        .. 'and answer its question.',
    pickAll      = 'Tick every row the current search, chip and filter are showing --\n'
        .. 'all of them, not just the 300 drawn on this page. It ticks nothing\n'
        .. 'the filter is hiding, which is the point of filtering first.',
    pickNone     = 'Untick everything, including rows a filter is hiding right now.',
    pickInvert   = 'Tick what is unticked and untick what is ticked, across\n'
        .. 'everything the filter is showing.',
    pickSame     = 'Extend the tick to every row holding the same item as a row\n'
        .. 'you have already ticked -- the way out of twelve rows of one crystal.',
    pickReadout  = 'What is ticked right now, and what a shop would pay for it.\n'
        .. 'The gil is the shop price, not the market: the market usually pays more.',
    sellableOnly = 'Hide every row no shop buys, for when the plan is to sell.\n'
        .. 'It hides nothing else -- Find, the chips and the sort all still apply.',

    stashAll     = 'One command that sweeps your bag into the warehouse.\n'
        .. 'Asks first, and the question lists everything it leaves behind.',
    room         = 'Free slots on the shelf: what the server says your account owns,\n'
        .. 'minus what is in it. One stored row is one slot, so this is how many\n'
        .. 'more rows a deposit can make before Stash All stops at the ceiling.',
    clearTicks   = 'Untick everything on this tab. Nothing is sent.',

    statusEvent  = 'The last thing that happened -- what the server said about a\n'
        .. 'command, or what this window just did. It clears itself after\n'
        .. 'half a minute so it cannot be mistaken for a live problem.',
    statusSticky = 'This one is still TRUE, not something that happened: it stays\n'
        .. 'until whatever it describes is answered, usually by Refresh.',
    depositTick  = 'A tick is what "Stash ticked" puts away and what "Save selection"\n'
        .. 'writes into a kit. It names the ITEM, not the slot: two slots of the\n'
        .. 'same arrows tick and untick together, and stash as two commands.',
    tickShown    = 'Tick every bag row the search is showing, so "Stash ticked"\n'
        .. 'becomes "stash everything matching this search".\n'
        .. 'Only offered while the search is narrowing the list.',

    pinned       = 'Pinned items Stash All will not take. Pins are per character.\n'
        .. 'These are pinned but not in your bag right now, which is the only\n'
        .. 'place their row would otherwise be -- so they are unpinnable here.',

    kitName      = 'A name for the kit, up to 24 letters, digits, spaces and dashes.\n'
        .. 'Saving over a name you already used replaces that kit.',
    kitSaveSelection = 'Save everything ticked on the Deposit tab, at the quantities\n'
        .. 'you are holding, as a kit under the name in the box.',
    kitSaveBag   = 'Save your whole inventory as a kit, at the quantities you hold.\n'
        .. 'Items in several slots become one line each, split at 99.',
    -- The 'several commands' half moved to the row's own hover, where the
    -- number is (1.13.0): a tip that says "long kits become several" leaves
    -- the player to guess which kind theirs is.
    kitPull      = 'Take everything in this kit out of the warehouse.\n'
        .. 'Anything the shelf is short of is reported item by item.',
    kitDelete    = 'Forget this kit. Asks once more before it goes --\n'
        .. 'the list is kept here and nowhere else.',
    kitDeleteArmed = 'Press again within eight seconds to delete this kit for good.\n'
        .. 'Wait, or click anywhere else, and it stays.',

    ledgerFull   = 'This element is at the ledger cap, so Store will not take any more\n'
        .. 'of it -- the shelf keeps what it holds. Retrieve some first if you\n'
        .. 'want the slots back.',
};

-- How long one `!dww pull` line may be. RAW_LINE_BUDGET on the server is 130;
-- this leaves room for the verb and a margin, and a kit longer than one line
-- becomes several lines rather than a truncated one.
local PULL_BUDGET = 120;

-- A kit name is a local label and a settings key. Bounded so a pathological
-- one cannot make the settings file unreadable.
local KIT_NAME_MAX = 24;

--[[
* Moves whenever the kits table is written -- a save, a delete, a settings
* file reloaded under the addon. The Kits tab's rendered view is cached
* against it and against modelRev (see kitRows), so a frame that changed
* neither re-parses nothing. Declared up here rather than beside kitRows
* because the settings-reload callback bumps it and is registered first;
* a `local` declared after its reader is a DIFFERENT (global) name, which
* would have been nil the one time it mattered.
--]]
local kitsRev = 0;

--[[
* The sale-history cache's two bounds (1.13.0).
*
* HISTORY_MAX is how many items' answers are kept at once. The cache had no
* ceiling at all and grew one entry per item hovered, which on a shelf of a
* thousand rows and a window left open is a table nothing ever shrinks.
*
* HISTORY_TTL is how long one answer is believed. The `at` stamp was recorded
* from the first version and never read, so an answer fetched once was shown
* for the rest of the session -- on a live market, where the whole point of
* the card is what things are going for TODAY. Five minutes is long enough
* that a mouse sweeping the strip asks once, and short enough that a player
* who comes back to price a second item is not reading yesterday.
--]]
local HISTORY_MAX = 32;
local HISTORY_TTL = 300;

--[[
* How long an envelope may stay open before the watchdog closes it.
*
* Generous on purpose: this is a last resort for a `z|` that never arrived,
* not a timing anyone should be able to hit by playing. The answer clock is
* 5 seconds and a page walk is 1.2 seconds a line, so anything the sweep does
* legitimately finishes well inside this.
--]]
local ENVELOPE_TIMEOUT = 10.0;

local state = T{
    open      = T{ false },

    -- The warehouse model. `rows` is keyed by row id and `pins` by item id, so
    -- BOTH ARE PLAIN TABLES -- see the note on `requested` below; a T{} keyed
    -- by data resolves misses through the sugar metatable and hands back a
    -- function where nil was meant.
    --
    --[[
        `pinsArriving` is the pin list's STAGING TABLE and is not declared
        here, because nil between envelopes is the state a table constructor
        cannot spell -- the `historyArriving` rule, one record kind over.

        WHY THERE IS A STAGING TABLE AT ALL (1.13.0). The pin list is a full
        refresh, and it used to be emptied at `d|` and refilled from the `p|`
        lines behind it. That is the shape the house rule names outright: an
        answer is committed WHOLE at `z|`, because a section wiped at `d|` is
        an empty section for every frame until its records land -- and, far
        worse here, for ever if they never do. An envelope cut short (the
        exact case the watchdog below exists for) left this character with
        no pins drawn at all: every Deposit row said 'pin' about something
        the server was still pinning, and the strip that unpins what is not
        in the bag simply vanished. The server was right the whole time,
        which is what made it a rendering bug nobody could report.
    ]]
    rows      = {},
    pins      = {},

    used      = 0,
    cap       = 0,
    gen       = 0,

    -- Moves on EVERY write to `rows` (1.10.0): the filtered, sorted view
    -- and the per-item stored counts are cached against it, so a frame
    -- that changed nothing re-sorts nothing. See visibleRows.
    modelRev  = 0,

    -- Paging. `syncGen` is the generation the model on screen was built FROM;
    -- when it falls behind `gen` the model is stale and repages itself.
    -- `sweepGen` is the generation the sweep in flight started under, so a
    -- second client mutating halfway through a twelve-page walk is caught
    -- rather than stitched into a list that was never true at any one moment.
    syncing   = false,
    syncGen   = -1,
    sweepGen  = nil,
    resweeps  = 0,
    nextPage  = nil,
    pages     = nil,
    pagesSeen = 0,
    synced    = false,      -- a full sweep has been asked for this login

    -- Latched by the row-count repair below, so the repage it forces cannot
    -- force another one. See verifyRowCount.
    repaired  = false,

    -- The verb whose response is currently arriving. Records are only accepted
    -- between a `d|` and its `z|`, so a line that arrives on its own -- a
    -- response to something typed by hand, say -- cannot half-fill the UI.
    inbound   = nil,

    -- When that envelope opened, for the watchdog in d3d_present. An answer
    -- cut short -- a dropped 0x017, a reload mid-answer -- used to leave
    -- `inbound` open for the rest of the session, and because the `d|` had
    -- already stamped the ask ANSWERED the page clock never re-asked either:
    -- the sweep sat on "loading 1/?" for ever, with both self-repair paths
    -- disarmed behind `syncing`. dwah 1.6.0 found the same hole in the same
    -- shape (dwah.lua:355-360) and this is its fix, carried here.
    inboundAt = 0,

    --[[
        The one status line, whether it is a refusal, WHEN it arrived and
        whether it describes a STANDING CONDITION rather than something that
        happened (1.13.0, dwah 1.6.0's shape).

        Every sentence here used to stay until another one replaced it, and
        the two kinds read completely differently after a minute. 'Copied 12
        row(s) to the clipboard.' an hour later is clutter; a red 'The
        warehouse is full.' an hour later reads as a live problem the player
        cannot find -- and this header has exactly two colours, so red is the
        strongest thing the window can say. Events fade. Conditions -- the
        protocol mismatch, the row-count repair, a sweep that gave up, an
        account being written from somewhere else -- stay, because they are
        still true until something answers them.
    ]]
    status       = 'Press Refresh.',
    statusBad    = false,
    statusAt     = 0,
    statusSticky = false,

    reported  = false,      -- a render error is worth saying once, not per frame

    --[[
        The Trash confirmation's pending row: { rowid, itemid, qty, flags }.
        Non-nil is what keeps the popup open -- ImGui closes a popup on an
        outside click, and the render pass re-opens it while this is set, so
        the only ways past the question are its two buttons. Destroying an
        item is the one click in this window that cannot be taken back.
    ]]
    trashAsk  = nil,

    --[[
        Latched when the server answers that it has no trash verb -- an older
        server core, or a binary older than its Lua. The verb is additive and
        the protocol version deliberately did not move (an old addon reads a
        new server fine either way), so the server's own refusal sentence is
        the only signal there is; once seen, the Trash buttons stop drawing
        rather than every click re-earning the same red banner (the dwbags
        unknown-verb lesson).
    ]]
    noTrash   = false,

    -- The stack verb's twin of the latch above, for the same reason: the verb
    -- is additive, the protocol version did not move, and the server's own
    -- refusal sentence is the only signal an older server or binary has no
    -- restack. Once seen, the button stops drawing for the session.
    noStack   = false,

    -- The buy verb's latch, same family. And the purchase tier's standing
    -- from the `b|` record: nil until a `who` answers, which is also what an
    -- old binary looks like -- the confirmation then simply says less.
    noBuy     = false,
    buyAsk    = false,
    bought    = nil,
    buyMax    = 1000,

    --[[
        The market lane (1.9.0). `market` is the `s|` record -- { fee,
        listings, cap } -- and nil until a `who` carries one, which is also
        what a server without the lane looks like: no record, no Sell button,
        no refusal to earn. `noSell` is the refusal latch for the case the
        record cannot cover (a core newer than its binary answers the verb
        with a sentence). `sellAsk` is the row whose price strip is open --
        { rowid, itemid, qty, flags, augs } -- and the strip's price box.
    ]]
    market    = nil,
    noSell    = false,
    sellAsk   = nil,
    sellPrice = T{ '' },

    --[[
        The crystal ledger (1.12.0). `crystals` is the `c|` record -- { cap,
        stored = { eight counts in element order } } -- and nil until a `who`
        carries one, which is also what a server without the crystal verbs
        looks like: no record, no Cluster/Store/Retrieve button, no refusal
        to earn. `noCrystals` is the refusal latch for the case the record
        cannot cover (a core newer than its binary). `crystalQty` is one
        digits-only Retrieve box per element.
    ]]
    crystals   = nil,
    noCrystals = false,
    crystalQty = { T{ '' }, T{ '' }, T{ '' }, T{ '' }, T{ '' }, T{ '' }, T{ '' }, T{ '' } },

    --[[
        The vendor lane and the batch doors (1.15.0).

        `prices` is the `v|` record accumulated by ITEM ID -- the shop price of
        one unit -- and is a PLAIN TABLE for the `rows`/`pins` reason at the
        top of this table: a table indexed by data must not be one that has
        names of its own. It accumulates rather than being replaced, because
        the record is per RESPONSE (the ids that response happened to carry)
        and not a full refresh; an item's base price is a property of the item
        template and does not move while a client is logged in, so a price once
        learned is true for the session.

        `gil` and `gilCap` are the `g|` record, and BOTH ARE NIL until a `who`
        carries one -- which is also exactly what a server without the vendor
        lane looks like: no record, no Vendor button, no refusal to earn. A
        `gilCap` of 0 is a different thing entirely and is a real answer (no
        currency cell to be paid into), which greys the buttons WITH A REASON
        rather than hiding them.

        `noVendor` and `noTrashMany` are the refusal latches for the case the
        records cannot cover -- a core newer than its binary. They are separate
        because the two features are separate bindings: a build with `trash`
        but no `trashmany` must keep its per-row Trash button.

        `picked` is the shelf selection, keyed by ROW ID, plain for the same
        reason as `prices`. `vendorAsk` and `batchAsk` are the two pending
        confirmations -- the Trash popup's contract restated for a set, because
        destroying or selling a dozen rows at once is the one click in this
        window that is worse than the one it was modelled on.
    ]]
    prices      = {},
    gil         = nil,
    gilCap      = nil,
    noVendor    = false,
    noTrashMany = false,
    picked      = {},
    vendorAsk   = nil,
    batchAsk    = nil,

    -- The shelf-only filter that hides rows no shop buys (1.15.0). Remembered
    -- with the sort and the category chip, because it is the same kind of
    -- thing: a view, never world state.
    sellable    = T{ false },

    --[[
        The sale history (1.11.0), behind the Sell strip's History button.
        `saleHistory` is the committed answer keyed by item id, `historyAsked`
        when each id was last asked for, and `historyArriving` the staging
        table between `i|` and `z|` -- nil between envelopes, which a table
        constructor cannot spell, so it is the one of the three that is not
        declared here.

        BOTH TABLES ARE PLAIN, AND DECLARED RATHER THAN GROWN. They are keyed
        by item id, which is the `rows`/`pins` rule at the top of this table;
        and a field first WRITTEN in the middle of a render pass is a field
        that was READ through the T{} sugar metatable until then (`T{}` in
        Ashita resolves a miss to `table_mt[k] or table[k]`, which is exactly
        how `requested['find']` once answered a function -- dwbags.lua:427-442).
        Neither name collides today; declaring them means the next one does
        not have to be checked against that list either.

        `noHistory` is the verb's own latch, and 1.13.0 owes it: `history` is
        additive and the protocol version deliberately did not move, so a
        server core older than 2026-09-04 answers `unknown verb "history"`
        and a newer core over an older market binding says it keeps no sale
        history. Without a latch the hover asked again every twenty seconds
        and every ask painted a red banner AND a red chat line for a feature
        that simply is not there. Cleared on the login packet with its
        siblings, so a server that gains the verb is noticed at the next
        relog.
    ]]
    saleHistory  = { },
    historyAsked = { },
    noHistory    = false,

    --[[
        Which tab is on screen, and which one an open is ASKING the tab strip
        to select.

        `tab` is remembered per PC beside the sort and the category chip
        (1.13.0): a player who lives on the Deposit tab reopened on the
        Warehouse every time, and the two settings that were already
        remembered made that read like a bug rather than a gap.

        `wantTab` is nil on every frame but the ones acting on a request --
        an open restoring the remembered tab, or `/warehouse find` jumping to
        the shelf it just narrowed. ImGuiTabItemFlags_SetSelected LEFT
        STANDING fights every click the player then makes, which is the note
        dwport and dwgmpanel both carry; it is cleared by the tab that takes
        it, and the remembered index is not written while it is set (that
        would save the tab the window opened ON TOP OF the tab the player
        left -- dwfishing.lua:3968-3985).
    ]]
    tab       = 1,
    wantTab   = nil,
    wantTabAt = 0,

    -- Header controls.
    search    = T{ '' },
    category  = 1,
    sort      = 1,
    takeQty   = T{ 1 },
    takeAll   = T{ true },  -- move the whole stack unless told otherwise

    -- Kits.
    kitName   = T{ '' },

    -- Which kit's Delete button is armed, and when it was armed. A kit is
    -- player-authored text this window is the only copy of, and it was the one
    -- destructive click here that fired on the first press -- beside a Trash
    -- button that opens a modal and a Stash All that opens another. dwjobs
    -- says why its preset delete asks twice in as many words ("a preset is
    -- cheap to remake, but an accidental single click should still not cost
    -- one"), and a kit is the same kind of thing. The hold is dwmerc's
    -- CONFIRM_HOLD reasoning: long enough to read, short enough that it is
    -- never still armed when somebody comes back to the window.
    kitArmed  = nil,
    kitArmAt  = 0,
};

-- How long a kit's Delete stays armed after the first click.
local KIT_CONFIRM_HOLD = 8.0;

--[[
* How long an ordinary status sentence stays on the header (1.13.0).
*
* Long enough to read twice, short enough that it cannot be mistaken for a
* condition. Every sentence used to stay until the next one replaced it, so a
* green 'Copied 12 row(s)' and a red 'The warehouse is full.' were both still
* there an hour later -- and the red one reads as a live problem, in the
* strongest colour this header has, about something that was answered long
* ago.
*
* STAMPED WITH os.time (WALL SECONDS), NOT os.clock (CPU SECONDS), and that is
* deliberate: every other clock in this file measures a protocol window -- an
* answer, a throttle, an envelope -- where CPU time is the honest unit and a
* stalled client must not age its own asks out. This one measures how long a
* PERSON has had a sentence in front of them, which is wall time; the window's
* frame rate has nothing to do with it. (dwah.lua:1131-1142, the same split
* for the same reason.)
--]]
local STATUS_LINGER = 30;

--[[
* The one way a sentence reaches the header.
*
* `sticky` marks the four things that are conditions rather than events: they
* stay until something answers them, and the hover says which kind the player
* is looking at.
--]]
local function setStatus(text, bad, sticky)
    state.status       = text;
    state.statusBad    = bad == true;
    state.statusAt     = os.time();
    state.statusSticky = sticky == true;
end

--[[
* Which deposit rows are ticked, keyed by ITEM ID.
*
* A PLAIN TABLE, NOT `T{ }`, for the reason documented at dwbags.lua:427-442: a
* table indexed by names the caller chooses must not be one that already has
* names of its own. Item ids are numbers here rather than strings, so the
* specific trap is different -- but the rule is the rule, and the next edit
* that keys something by name is the one that pays for breaking it.
--]]
local selection = {};

--[[
* Which frame the render pass is on, counted in d3d_present (1.13.0).
*
* The one thing it is for is the bag read: the Deposit tab must re-read client
* memory every frame (see inventoryRows -- a stale slot is the whole reason
* the slot AND the item id both go on the wire), but it must not read it
* TWICE in one frame, which is what happened whenever a click handler asked
* for the bag the draw loop had already built. A frame number is the only key
* that means "the same instant" without pretending a cache can be older.
--]]
local frameNo = 0;

local icons     = T{ };
local iconCount = 0;

--[[
* The item icon out of the client's own resources.
*
* Cached because a page is a hundred rows redrawn every frame and
* D3DXCreateTextureFromFileInMemoryEx is not free. gc_safe_release hands back a
* texture that releases itself when Lua collects it, which is what keeps this
* from leaking across a reload. (dwbags.lua:289-330.)
--]]
--[[
* The SAME texture as a plain number, which is what imgui.Image actually
* wants (1.13.0).
*
* `imgui.Image(tonumber(ffi.cast('uint32_t', texture)), ...)` was run per drawn
* row per frame: three hundred `ffi.cast` calls a frame, each of them a fresh
* cdata object for the collector, to recompute a pointer value that cannot
* change while the texture is alive. The texture itself is held in `icons` (and
* released by gc_safe_release when THAT reference goes), so this table only
* ever holds a number belonging to an object something else is keeping.
--]]
local iconHandles = { };

local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));
    iconCount     = iconCount + 1;

    return icons[itemId];
end

--[[
* THE CEILING ON THE ICON CACHE (1.16.0).
*
* Every entry above is a live D3DPOOL_MANAGED texture and the key is an item
* id -- sixty-five thousand of them. FFXI is a 32-bit process that runs out of
* ADDRESSES long before it runs out of memory (the black-screen-after-zoning
* class), and an allocation that fails inside a client which does not check
* the result becomes a write through a null pointer. A cache keyed by
* something with that cardinality owes a bound like every other table in this
* suite, and this one had none: a whole account's storage is thousands of
* distinct ids in one sitting.
*
* Dropped WHOLE rather than evicted one at a time: `gc_safe_release` owns the
* release, so letting go of the last reference IS the free. dwcon's
* releaseIcons and dwmerc's gilCache are the same recipe.
*
* And dropped at the TOP OF A FRAME, never from inside iconOf. ImGui keeps the
* raw texture pointer in its draw list until Ashita renders that list at the
* end of the present hook, so a texture released in the middle of a pass is a
* dangling pointer inside the pass still using it. By the time the next present
* handler runs, the previous frame is already on the screen.
--]]
local ICON_MAX = 1024;

local function sweepIcons()
    if (iconCount < ICON_MAX) then
        return;
    end

    icons       = T{ };
    iconHandles = { };
    iconCount   = 0;

    collectgarbage('collect');
end

--[[
* Names and types CACHED per item id (1.10.0, the owner's frame-rate report:
* a thousand-row warehouse tanked the fps). The DAT never changes under a
* running client, and the old shape asked the resource manager for the same
* name several times per row per frame -- once to draw it, once to filter
* it, and once per comparison inside the sort. `lowerName` is the search
* key, lowercased once rather than sixty times a second per row.
--]]
local nameCache  = { };
local lowerCache = { };
local typeCache  = { };

local function itemName(itemId)
    local cached = nameCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    local name;

    if (item == nil or item.Name[1] == nil or item.Name[1]:len() == 0) then
        name = string.format('item %d', itemId);
    else
        name = item.Name[1];
    end

    nameCache[itemId] = name;

    return name;
end

local function lowerName(itemId)
    local cached = lowerCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local lowered = itemName(itemId):lower();

    lowerCache[itemId] = lowered;

    return lowered;
end

local function itemType(itemId)
    local cached = typeCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    local kind = item ~= nil and (item.Type or 0) or 0;

    typeCache[itemId] = kind;

    return kind;
end

--[[
* The { w, h } pair ImGui wants, one table per size rather than one per row
* per frame (1.13.0).
*
* Three hundred drawn rows is three hundred two-element tables a frame for two
* distinct sizes, and every one of them is garbage the moment the call returns
* -- the binding reads both fields synchronously and keeps nothing. Memoised
* by size, which is a table with two entries in it for the life of the addon.
--]]
local iconSizes = { };

local function iconSize(size)
    local pair = iconSizes[size];

    if (pair == nil) then
        pair = { size, size };
        iconSizes[size] = pair;
    end

    return pair;
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);
    local pair    = iconSize(size);

    if (texture ~= nil and texture ~= false) then
        local handle = iconHandles[itemId];

        if (handle == nil) then
            handle              = tonumber(ffi.cast('uint32_t', texture));
            iconHandles[itemId] = handle;
        end

        imgui.Image(handle, pair);
    else
        imgui.Dummy(pair);
    end

    imgui.SameLine();
end

--[[
* The item card (1.4.0): the hover pop-up on every item row -- name, iLvl,
* level, Rare/Ex, slots, jobs, augments where the bytes are readable, and
* the item's own description text with the elemental-resist icons folded to
* readable tags, all read from the client's OWN resources by id, so nobody
* has to alt-tab to a wiki to learn what a row in the warehouse is.
* Mirrored BY HAND from dwbags 1.17.0 (an addon folder is the unit of
* distribution, the dwtheme rule, so the lines are duplicated rather than
* shared) -- edit one, revisit the others (dwbags is the master; dwah,
* dwraid, dwquest carry siblings). The DAT flag bits are the same ones
* sql/item_basic.sql spells @FLAG_RARE and @FLAG_EX; everything here is
* presentation, and the server re-checks anything that matters.
--]]
local FLAG_EX   = 0x4000;
local FLAG_RARE = 0x8000;

--[[
* The eight elemental-resist icons in the client's item descriptions are
* FFXI-private Shift-JIS pairs -- 0xEF then 0x1F..0x26, in wheel order
* fire ice wind earth lightning water light dark (read straight out of
* ROM/118/107.DAT: item 6272 carries fire as EF 1F, item 4488 dark as
* EF 26, and the JP DAT spells the same slots 耐火/耐風/耐土). ImGui wants
* UTF-8, so the raw pair renders as the '?' players reported. Each icon
* (and the '+' that usually follows it) folds to a three-letter tag:
* '<fire>+20' reads FiR:20, '<dark>-10' reads DkR:-10.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function(b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

--[[
* Augment names -- augcatalog.lua beside this file, the same GENERATED
* catalog dwquest carries (tools/dwquest/gen_augment_catalog.py;
* Check-QuestAugments.ps1 keeps every copy byte-identical to dwquest's).
* pcall'd because a half-synced folder is a real deployment state: without
* the catalog the card still lists augments, as the raw ids they are.
--]]
local haveAugCatalog, augcatalog = pcall(require, 'augcatalog');

if (not haveAugCatalog or type(augcatalog) ~= 'table' or type(augcatalog.augments) ~= 'table') then
    augcatalog = { augments = { } };
end

--[[
* ONE AUGMENT'S MAGNITUDE AT A GIVEN RANK -- dwquest's `augmentWords`
* (dwquest.lua, the catalog block) character for character. `rank` is the
* HUMAN rank: the stored five-bit exdata value plus one, which is what
* extraAugments below adds and what the server's own records carry
* (alt_storage.cpp augsOf, quest_store.cpp:2346).
*
* A substitutable entry has its digit runs recomputed for this rank -- term k
* applies to the k-th digit run, a bare number n means n + stored, a pair
* { b, s } means b + stored * s. The generator emits a term ONLY where it
* verified that against the engine's own formula (item_equipment.cpp
* SetAugmentMod: `(value > 0 ? value + stored : value - stored) * max(mult, 1)`),
* so this never invents a magnitude.
*
* THE SECOND RETURN IS THE HONESTY BIT: an entry with no terms cannot be
* recomputed, so the words are rank 1's whatever rank was asked for, and
* `exact` is false. A caller that prints those beside a rank is the 2026-09-11
* defect -- a reader multiplies and expects five times the number.
--]]
local function augmentWords(augid, rank)
    local entry = augcatalog.augments[augid];

    if (entry == nil) then
        return string.format('augment %d', augid), false;
    end

    local label  = entry.l;
    local stored = rank - 1;

    if (entry.m == nil) then
        return label, stored == 0;
    end

    if (stored > 0) then
        local k = 0;

        label = string.gsub(label, '%d+', function(digits)
            k = k + 1;

            local term = entry.m[k];

            if (term == nil) then
                return digits;
            end

            if (type(term) == 'table') then
                return tostring(term[1] + stored * term[2]);
            end

            return tostring(term + stored);
        end);
    end

    return label, true;
end

--[[
* One augment, as a hover card names it: the magnitude AT THIS RANK, and the
* rank itself whenever it is not 1. dwquest's augmentText without the
* exchange id suffix -- a card names the augment, the Exchange window is
* where ids matter.
*
* THE RANK IS STATED ALONGSIDE THE MAGNITUDE (owner report, 2026-09-11). The
* card used to print a bare `Mag. Evasion +7` for a rank-5 augment while the
* SeeAugs reference printed the catalog's rank-1 `+3` with "rank 5" beside
* it, and a player holding both read the +7 as the window hiding eight
* points. +7 IS what rank 5 grants -- the engine adds the stored value ONCE,
* it does not multiply -- so every line that shows a magnitude now shows the
* rank it belongs to, and the two windows stop looking like two answers.
--]]
local function augmentText(augid, rank)
    if (augcatalog.augments[augid] == nil) then
        return string.format('augment %d rank %d', augid, rank);
    end

    local label = augmentWords(augid, rank);

    if (rank > 1) then
        return string.format('%s (rank %d)', label, rank);
    end

    return label;
end

--[[
* The four augment slots out of an item's exdata bytes, decoded the way
* quest_store.cpp augmentsOf does: byte one is the kind (0x02 = carries
* augments), byte two the sub-kind (any special bit 0x08..0x80 --
* escutcheon, serialized, mezzotint, trial, evolith -- is a DIFFERENT byte
* layout and is refused, quest_store.cpp extraIsAugmentable), then four
* packed uint16s -- id in the low 11 bits, stored value in the high 5, and
* the rank a player reads is stored + 1. Returns nil when there is nothing
* honest to say.
--]]
local function extraAugments(extra)
    if (type(extra) ~= 'string' or #extra < 12) then
        return nil;
    end

    if (extra:byte(1) ~= 0x02 or bit.band(extra:byte(2), 0xF8) ~= 0) then
        return nil;
    end

    local augs = T{ };

    for slot = 0, 3 do
        local packed = extra:byte(3 + slot * 2) + extra:byte(4 + slot * 2) * 256;
        local augid  = bit.band(packed, 0x07FF);

        if (augid ~= 0) then
            augs:append({ id = augid, rank = bit.band(bit.rshift(packed, 11), 0x1F) + 1 });
        end
    end

    if (#augs == 0) then
        return nil;
    end

    return augs;
end

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Display names for the card's slot line: ear and ring pairs fold into one
-- word each.
local CARD_SLOTS = {
    [0]  = 'Main',  [1]  = 'Sub',   [2]  = 'Ranged', [3]  = 'Ammo',
    [4]  = 'Head',  [5]  = 'Body',  [6]  = 'Hands',  [7]  = 'Legs',
    [8]  = 'Feet',  [9]  = 'Neck',  [10] = 'Waist',  [11] = 'Ear',
    [12] = 'Ear',   [13] = 'Ring',  [14] = 'Ring',   [15] = 'Back',
};

local function jobsText(mask)
    local names = T{ };

    for jobId = 1, #JOB_NAMES do
        if (bit.band(mask, bit.lshift(1, jobId)) ~= 0) then
            names:append(JOB_NAMES[jobId]);
        end
    end

    if (#names == 0) then
        return nil;
    end

    if (#names >= #JOB_NAMES) then
        return 'All jobs';
    end

    return table.concat(names, ' ');
end

local function slotsText(mask)
    local names = T{ };
    local seen  = { };

    for slot = 0, 15 do
        if (bit.band(mask, bit.lshift(1, slot)) ~= 0) then
            local label = CARD_SLOTS[slot];

            if (not seen[label]) then
                seen[label] = true;
                names:append(label);
            end
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, '/');
end

--[[
* Whether the player already knows the spell a scroll teaches (1.10.0, the
* owner's request): true, false, or nil when the item is not a scroll or
* the client cannot say. A scroll is recognised by its own description --
* every spell scroll's opens "Teaches the ..." -- and the spell is looked
* up by the scroll's DAT name (which IS the spell's name: the item is
* "Auspice", the log name "scroll of Auspice"), falling back to the last
* words of the description. The player's spell list is the client's own
* memory (IPlayer:HasSpell), read under pcall: the sol bindings for it are
* promised by Ashita's annotations and proven by no sibling, so a refusal
* costs one missing line rather than a card that throws. Mirrored BY HAND
* from dwah (edit one, revisit dwbags and this one).
--]]
local function scrollStatus(item)
    if (item == nil) then
        return nil;
    end

    local desc = item.Description ~= nil and item.Description[1] or nil;

    if (type(desc) ~= 'string' or desc:sub(1, 12) ~= 'Teaches the ') then
        return nil;
    end

    local ok, known = pcall(function()
        local mgr    = AshitaCore:GetResourceManager();
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (mgr == nil or player == nil) then
            return nil;
        end

        local names = { item.Name ~= nil and item.Name[1] or nil };
        local tail  = desc:match('^Teaches the [%a%-]+ [%a%-]+ (.-)%.') or desc:match('^Teaches the [%a%-]+ (.-)%.');

        if (tail ~= nil and tail ~= names[1]) then
            names[#names + 1] = tail;
        end

        for _, name in ipairs(names) do
            local spell = mgr:GetSpellByName(name, 0);

            if (spell ~= nil and spell.Index ~= nil) then
                return player:HasSpell(spell.Index) == true;
            end
        end

        return nil;
    end);

    if (not ok) then
        return nil;
    end

    return known;
end

--[[
* Whether the player already knows the phantom roll a Corsair die teaches
* (1.17.0, the owner's request): 'known', 'unlearned', 'offjob', or nil when
* the item is not a die or the client cannot say. Mirrored BY HAND beside
* scrollStatus (edit one, revisit dwah and dwbags).
*
* A die is recognised by its own description -- all 31 of them (item ids
* 5477..5505 plus 6368/6369, kDiceRolls in alt_storage.cpp) open "Teaches
* the job ability <Roll>.", and they are the only items in the game whose
* use teaches an ability -- and the roll is looked up BY THAT NAME in the
* client's own ability DATs, where a job ability sits at 512 + the server's
* ability id (dwgambits' ABILITY_CLIENT_OFFSET). The resource's own Id is
* already in that space, so it is what IPlayer:HasAbility wants; an id below
* the offset is a weapon skill and not our answer.
*
* THE CAVEAT, and it is why this answers three ways and not two: the
* client's job-ability list is packet 0x0AC, which the server fills from the
* CURRENT main and support job ONLY (charutils::BuildingCharAbilityTable
* walks GetMJob() then GetSJob(), each arm gated on that job's level). So an
* absent roll means "not learned" only while the character is on Corsair,
* and even then only up to the Corsair level being played -- the rolls run
* level 20..97 and a support job is capped at half the main level. Off
* Corsair the card says WHEN it could answer instead of answering, and on
* Corsair the negative names its own second reading. A false "not learned"
* would read as permission to spend a die the account has already eaten --
* and the learn is account-wide (alt_storage.cpp teaches every character on
* the account), so there is no second copy to spend.
--]]
local function rollStatus(item)
    -- Inside the function, not at file scope: this chunk is close enough to
    -- Lua's 200-locals-per-function ceiling (the raid_core lesson) that two
    -- more constants are not worth spending there, and a value read once per
    -- hovered card costs nothing where it is used.
    local COR_JOB_ID        = 17;  -- the client's job ids, WAR 1 .. RUN 22
    local ABILITY_DAT_FIRST = 512; -- DAT ids below this are weapon skills

    if (item == nil) then
        return nil;
    end

    local desc = item.Description ~= nil and item.Description[1] or nil;

    if (type(desc) ~= 'string') then
        return nil;
    end

    local roll = desc:match('^Teaches the job ability (.-)%.');

    if (roll == nil or #roll == 0) then
        return nil;
    end

    local ok, state = pcall(function()
        local mgr    = AshitaCore:GetResourceManager();
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (mgr == nil or player == nil) then
            return nil;
        end

        local ability = mgr:GetAbilityByName(roll, 0);

        if (ability == nil or ability.Id == nil or ability.Id < ABILITY_DAT_FIRST) then
            return nil;
        end

        if (player:HasAbility(ability.Id) == true) then
            return 'known';
        end

        -- A miss is only an answer once the list has arrived and once one of
        -- the jobs it was built from is the one that owns the roll. The data
        -- flag is asked in its own pcall: an install whose bindings lack it
        -- keeps the rest of the answer rather than losing all of it.
        local okData, hasData = pcall(function()
            return player:HasAbilityData();
        end);

        if (okData and hasData == false) then
            return nil;
        end

        if (player:GetMainJob() ~= COR_JOB_ID and player:GetSubJob() ~= COR_JOB_ID) then
            return 'offjob';
        end

        return 'unlearned';
    end);

    if (not ok) then
        return nil;
    end

    return state;
end

local function drawScrollStatus(item)
    local roll = rollStatus(item);

    if (roll ~= nil) then
        if (roll == 'known') then
            imgui.TextColored(theme.colors.ok, 'You already know this roll.');
        elseif (roll == 'unlearned') then
            imgui.TextColored(theme.colors.warn, 'Not learned yet, or above your Corsair level.');
        else
            imgui.TextDisabled('Learned status shows while on Corsair.');
        end

        return;
    end

    local known = scrollStatus(item);

    if (known == true) then
        imgui.TextColored(theme.colors.ok, 'You already know this spell.');
    elseif (known == false) then
        imgui.TextColored(theme.colors.warn, 'Not learned yet.');
    end
end

-- `aug` is one of three honest states: a list of { id, rank } (the bytes
-- were readable and decoded), `true` (the server said "augmented" about an
-- item whose bytes live in the warehouse -- say so without inventing
-- values), or nil.
local function itemCard(itemId, aug)
    imgui.BeginTooltip();

    local item = nil;

    if (itemId ~= nil and itemId ~= 0 and itemId ~= 65535) then
        item = AshitaCore:GetResourceManager():GetItemById(itemId);

        drawIcon(itemId, 32);
    end

    imgui.Text(itemName(itemId));

    if (item ~= nil) then
        local tags = T{ };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags:append(string.format('iLvl %d', item.ItemLevel));
        end

        if (item.Level ~= nil and item.Level > 0) then
            tags:append(string.format('Lv.%d', item.Level));
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_RARE) ~= 0) then
            tags:append('Rare');
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_EX) ~= 0) then
            tags:append('Ex');
        end

        if (#tags > 0) then
            imgui.TextColored(theme.colors.info, table.concat(tags, '  '));
        end

        local slots = item.Slots ~= nil and slotsText(item.Slots) or nil;
        local jobs  = item.Jobs ~= nil and jobsText(item.Jobs) or nil;

        if (slots ~= nil and jobs ~= nil) then
            imgui.TextDisabled(slots .. '  --  ' .. jobs);
        elseif (slots ~= nil or jobs ~= nil) then
            imgui.TextDisabled(slots or jobs);
        end

        drawScrollStatus(item);

        if (type(aug) == 'table') then
            imgui.Separator();
            imgui.TextColored(theme.colors.info, 'Augments');

            for _, a in ipairs(aug) do
                imgui.Text('  ' .. augmentText(a.id, a.rank));
            end
        elseif (aug == true) then
            imgui.Separator();
            imgui.TextColored(theme.colors.info, 'Augmented');
            imgui.TextDisabled('Values are readable where the item sits -- hover it there.');
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            -- A fixed wrap width, not one derived from imgui state: the
            -- card must render the same whatever window it floats over.
            imgui.PushTextWrapPos(320.0);
            imgui.Text(cleanDescription(desc));
            imgui.PopTextWrapPos();
        end
    end

    imgui.EndTooltip();
end

-- Call after an icon-and-name pair: `hoveredIcon` is IsItemHovered read
-- between the two draws (drawIcon leaves the cursor on the same line, and
-- IsItemHovered reads the LAST item, so the icon's hover must be taken
-- before the name is drawn). `aug` passes through to the card.
local function cardOnHover(itemId, hoveredIcon, aug)
    if (imgui.IsItemHovered() or hoveredIcon == true) then
        itemCard(itemId, aug);
    end
end

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A TIME.
*
* THE CLIENT RATE-LIMITS OUTGOING CHAT, AND A !dww COMMAND IS A CHAT LINE.
* Firing four of them in a single frame -- which is what a naive "sync
* everything" does, and this addon's whole first sync is a run of them -- gets
* the first one sent and the rest answered with "A command error occurred" by
* the client, before the server ever sees them. So everything queues here and
* drains at one command per SEND_INTERVAL. Duplicates collapse, because asking
* twice for the same page is never useful and the queue is the one place that
* can know. (dwbags.lua:354-403.)
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

--[[
* ONLY QUERIES COLLAPSE. The note above is about reads -- `page` and `who` --
* and asking twice for either really is never useful (needPage and startSync
* both lean on that). But this same queue carries every WRITE the window makes:
* take, trash, put and the kit `pull` lines. Two identical `!dww take 41 12`
* clicks are two commands the player asked for, and issue() has no way to
* report a refusal, so collapsing them silently loses one -- with the queue
* draining at one line per 1.2s, that window is wide enough to click twice in.
--]]
--[[
* AND THE QUEUE HAS A CEILING (1.13.0). It drains at one line per 1.2s and
* nothing bounded it, so a mouse run down three hundred Take buttons queued
* three hundred commands -- six minutes of a window that answers every click
* by doing nothing visible, with no way to call it back short of /addon
* reload. The biggest legitimate burst is one `put` per bag slot (eighty),
* so 200 is several times what any one press can ask for and still a number
* a player reaches only by mashing. Over it the line is refused OUT LOUD:
* a silently dropped click is the failure this ceiling exists to avoid
* repeating in a quieter voice.
--]]
local QUEUE_MAX = 200;

local function issue(command)
    if (command == '!dww who' or command:match('^!dww page ') ~= nil) then
        for _, queued in ipairs(queue) do
            if (queued == command) then
                return;
            end
        end
    end

    if (#queue >= QUEUE_MAX) then
        setStatus(string.format('Too many commands waiting (%d). Let them finish first.', #queue), true);

        return;
    end

    queue:append(command);
end

--[[
* Drains one queued command. Called every frame from d3d_present, including
* while the window is shut: a page walk started just before closing it still
* has to finish, and a Take issued a moment before closing still has to reach
* the server.
--]]
local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a frame drawn sixty times a second asks
* once, and so a command lost on the way out is asked again exactly once.
*
* A PLAIN TABLE, NOT `T{ }`, AND IN dwbags THIS COST A ROUND
* (dwbags.lua:427-442): the table is keyed by VERB, and a `T{ }` resolves
* unknown keys through its metatable to the sugar table methods -- so
* `requested['find']` answered a FUNCTION rather than nil, and writing a field
* to it threw. A table indexed by names the caller chooses must not be one that
* already has names of its own.
*
* THE ANSWER IS TRACKED, NOT JUST THE QUESTION, and here that is load-bearing
* rather than defensive: a lost `page` command does not leave one panel stale,
* it stalls the whole sweep and the list simply stops filling in. One retry,
* then left alone -- a retry that never terminates would be a command loop,
* which is worse than a short list.
--]]
local requested = {};

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local function forget()
    requested = {};
end

-- Called from the `d|` record: whatever response is arriving answers the
-- outstanding question for that verb.
local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

-- Ask for one page, at most once -- twice if the first one was never answered.
local function needPage(page)
    local asked = requested['page'];

    if (asked ~= nil and asked.page == page) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered) then
            return;
        end

        -- The answer window is checked BEFORE the try count, deliberately. In
        -- the other order the sweep would be declared dead on the very frame
        -- after the second send, with the retry still in flight.
        if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        --[[
            A SWEEP THAT GIVES UP HAS TO SAY SO AND STAND DOWN. The try count
            used to sit in the `or` chain above, which made running out of
            tries a silent `return` -- so needPage did nothing, forever, and
            `state.syncing` stayed TRUE for the rest of the session. That flag
            gates both self-repair paths (the row-count verify and the
            generation-gap repage), so the one state the addon could not
            recover from was the one it entered by failing. Nothing on screen
            said anything either: the "loading N/M" note simply stopped moving.
        --]]
        if (asked.tries >= ANSWER_TRIES) then
            state.syncing   = false;
            state.nextPage  = nil;

            -- AND THE START GENERATION IS SPENT WITH IT (1.13.0). `sweepGen`
            -- is only ever cleared where a sweep FINISHES, so a sweep that
            -- gave up here left it set -- and the next `q|` to land outside
            -- a sweep (a `!warehouse page` typed by hand, a late page of the
            -- dead walk) claimed the model at that long-gone generation and
            -- cost a twelve-command repage to discover nothing had moved.
            -- The same bug the 1.10.0 note below the `q|` handler describes,
            -- surviving on the one path that does not reach it.
            state.sweepGen  = nil;

            setStatus(string.format('The list stopped at page %d -- press Refresh.', page + 1), true, true);

            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['page'] = { page = page, at = os.clock(), answered = false, tries = 1 };
    end

    issue(string.format('!dww page %d', page));
end

--[[
* Start a full page sweep.
*
* THE MODEL IS CLEARED HERE RATHER THAN MERGED INTO. A sweep is the answer to
* "what is actually in there", and a row this addon holds that the server no
* longer has -- an alt on the same account took it -- would survive any number
* of merges. Clearing costs a rebuilding list for the length of the sweep,
* which is what the "loading N/M" note is for; keeping a ghost row costs a
* Take button that fails.
--]]
--[[
* Ask for the `who` line, at most once -- twice if the first one was never
* answered. needPage's clock, for the one ask that never had one (1.13.0).
*
* WHY IT MATTERS MORE THAN IT LOOKS. A page envelope carries `k|`, `w|` and
* `q|` and nothing else (warehouse_core.lua's verbs.page); everything that
* says what this SERVER and this CHARACTER can do rides the `who` answer and
* only that one -- the pin list, the market standing that draws the Sell
* buttons, the crystal ledger that draws the whole Crystals tab, and the
* purchase count. A `who` lost on the way out therefore left the window
* looking exactly like a server with none of those lanes, for the rest of the
* login, with no sentence anywhere and no button to press: the sweep still
* filled the list, so nothing looked broken. Every other ask in this addon has
* been retried once since 1.0.0; this one simply was not tracked.
--]]
local function needWho()
    local asked = requested['who'];

    if (asked == nil) then
        requested['who'] = { at = os.clock(), answered = false, tries = 1 };

        issue('!dww who');

        return;
    end

    if (asked.answered) then
        return;
    end

    -- A held send (zone-in) leaves the line queued; aging the clock against it
    -- would be a false timeout, needPage's reason.
    if (not echo.canSend()) then
        return;
    end

    --[[
        AND NOT WHILE THE PAGE WALK IS RUNNING. A sweep is a dozen commands
        down a pump that carries one line per 1.2 seconds, and the `who` was
        queued at the head of it: a retry racing the walk would only take a
        turn away from a page, and while pages keep landing the server is
        plainly answering. The loss this exists to notice is a `who` that is
        still unanswered when the walk is OVER -- which is also the first
        moment a missing Sell button or an empty Crystals tab is visible.
    ]]
    if (state.syncing) then
        return;
    end

    if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
        return;
    end

    -- Out of tries is a silent stop ON PURPOSE here, unlike needPage's: the
    -- list itself still fills from the page walk, so there is nothing to say
    -- that Refresh does not already offer, and a second sentence competing
    -- with the page walk's own would be noise about a strictly smaller loss.
    if (asked.tries >= ANSWER_TRIES) then
        return;
    end

    asked.at    = os.clock();
    asked.tries = asked.tries + 1;

    issue('!dww who');
end

local function startSync()
    forget();

    --[[
        AND ANY PAGE COMMAND STILL WAITING IS DROPPED WITH THE ASK IT BELONGED
        TO (1.13.0).

        `forget()` clears what was ASKED; the queue holds what has not gone out
        yet, and it drains at one line per 1.2 seconds -- so a sweep restarted
        while its `!dww page 7` sat in the queue sent that line anyway, a
        second later, against a model that had just been emptied. The answer
        opens `d|1|page`, which stamps the NEW sweep's page-0 ask answered,
        and its `q|7|8` then declares the walk finished at the last page. The
        result was a shelf showing one page of eight with `syncing` false,
        `syncGen` equal to `gen`, and therefore not one of this addon's four
        self-repair paths armed: a silently short list that every freshness
        check agreed was current. Pressing Refresh during a sweep is how you
        get there, which is the one moment a player is most likely to.

        Only `page` lines are dropped. A `take` or a `put` in the queue is a
        click the player made and is none of this function's business.
    ]]
    for index = #queue, 1, -1 do
        if (queue[index]:match('^!dww page ') ~= nil) then
            table.remove(queue, index);
        end
    end

    state.rows      = {};
    state.modelRev  = state.modelRev + 1;
    state.syncing   = true;
    state.syncGen   = state.gen;
    state.sweepGen  = nil;
    state.nextPage  = 0;
    state.pages     = nil;
    state.pagesSeen = 0;
    state.synced    = true;
    setStatus('Reading your warehouse...', false);

    needWho();
end

-- How many times a sweep may restart itself because the account moved under
-- it. Three is generous for two clients; a fourth means something is churning
-- the account faster than a 1.2s pump can read it, and the honest answer is a
-- sentence rather than a page walk that never ends.
local MAX_RESWEEPS = 3;

--[[
* Does the model hold as many rows as the server says are used?
*
* WHY THIS EXISTS, AND WHY THE GENERATION CHECK CANNOT COVER IT. A response is
* capped at 14 packed `w|` lines (warehouse_core.lua:57-58), which is four to
* six rows each depending on how wide the numbers happen to be. A `stashall`
* that deposits more rows than that produces MORE delta rows than fit, and the
* ones past the cap are simply not sent -- the Mes buffer truncates silently,
* which is the same reason the server packs to well under it in the first
* place. The envelope that arrives is well-formed, its `k|` carries the NEW
* generation, and this addon dutifully records that generation as the one its
* model was built from. So the freshness check agrees with itself while the
* rows it never received are missing: staleness that looks exactly like health.
*
* THE COUNTS ARE THE SAME UNIT, WHICH IS THE WHOLE TRICK. One warehouse row is
* one used slot -- `used` in the `k|` record IS a row count
* (warehouse_core.lua:331) -- so the model disagreeing with it is proof of a
* gap without needing to know what was dropped or why. That makes this a
* general repair rather than a stashall special case: any future response that
* loses a row, for any reason, is caught by the same arithmetic.
*
* ONE REPAGE, NEVER A LOOP. If the sweep that repairs it comes back still
* disagreeing, the honest answer is a sentence -- a repage that re-arms itself
* on a disagreement it cannot fix is a twelve-command page walk every time the
* player touches anything. The latch clears the moment the counts agree, so a
* transient gap costs one sweep and nothing after it.
--]]
--[[
* CACHED AGAINST modelRev (1.13.0). This walks every row with `pairs`, and
* the Warehouse tab's count line calls it EVERY FRAME -- a thousand-iteration
* loop sixty times a second, which is exactly the shape the 1.10.0 frame-rate
* pass took out of visibleRows and storedCounts and left in here. The other
* caller (verifyRowCount) runs once per envelope and is free either way.
--]]
local rowCountCache = { rev = nil, count = 0 };

local function modelRowCount()
    if (rowCountCache.rev == state.modelRev) then
        return rowCountCache.count;
    end

    local count = 0;

    for _ in pairs(state.rows) do
        count = count + 1;
    end

    rowCountCache.rev   = state.modelRev;
    rowCountCache.count = count;

    return count;
end

local function verifyRowCount()
    -- OFF DURING THE INITIAL SWEEP, and off before one has ever been asked
    -- for. A page walk holds a legitimately partial model the whole way
    -- through -- every page's `k|` carries the account's FULL used count while
    -- only the pages seen so far are in `rows` -- so this arithmetic is
    -- guaranteed to disagree and would fire a sweep from inside a sweep.
    if (state.syncing or not state.synced) then
        return;
    end

    local held = modelRowCount();

    if (held == state.used) then
        state.repaired = false;

        return;
    end

    if (state.repaired) then
        -- statusBad, because headerStrip has exactly two colours and this
        -- sentence is a WARNING: rows the server holds are missing from the
        -- list in front of the player. Drawn in the confirmation green it read
        -- like 'Pulled 5.' -- the same failure dwbags.lua:581-587 records
        -- against its protocol-mismatch banner.
        setStatus(string.format('Showing %d of %d stored slots -- press Refresh.', held, state.used), true, true);

        return;
    end

    state.repaired = true;

    startSync();
end

--[[
* Record parsing.
*
* Every record is pipe-separated with a single-character type. Anything this
* addon does not recognise is ignored rather than being an error: a server
* newer than the addon must not break it, which is the whole reason the `d|`
* record carries a protocol version.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* EVERY NUMBER OFF THE WIRE COMES THROUGH HERE (1.13.0), and it is not
* politeness.
*
* Almost every one of them is eventually handed to `string.format('%d', ...)`
* -- the row's own widget ids, the 'x12' beside it, the capacity readout, the
* ledger's '100 / 5000', the `!dww take <rowid> <qty>` the button sends -- and
* `tonumber` is generous where the protocol is not: it reads '2.5', '1e40',
* ' 12 ', '0x10' and 'nan'. What `%d` then does depends on the runtime, and
* neither answer is one this window can live with. The client's LuaJIT 2.1
* does NOT raise: it truncates 2.5 to 2 and formats a NaN or an infinity as
* -9223372036854775808 -- so a fractional row id became a `!dww take` aimed
* at a DIFFERENT row, silently, and a 'nan' became a huge negative on the
* wire. Lua 5.4, which is what the offline harness runs, raises "number has
* no integer representation" instead, and inside the render pass a throw is
* answered by the pcall CLOSING THE WINDOW. (Checked on 2026-09-06 against
* lupa's LuaJIT 2.1 on this box; the Ashita binding is that runtime.)
*
* The server's own tier does exactly this on the way out (warehouse_core.lua's
* clampInt: tonumber, NaN test, range, floor, in that order) because a thrown
* ! command broadcasts the typed line in /say. This is the same discipline on
* the way in, for the same reason one tier down.
*
* `n ~= n` is the NaN test and it has to come BEFORE the floor: math.floor of
* a NaN is a NaN, which formats no better than 2.5 did.
--]]
local function intOf(text, fallback)
    local number = tonumber(text);

    if (number == nil or number ~= number) then
        return fallback;
    end

    -- An infinity floors to itself and formats no better either, so it folds
    -- onto the fallback with the rest of what cannot be a count.
    if (number > 2147483647 or number < -2147483647) then
        return fallback;
    end

    return math.floor(number);
end

--[[
* The verbs whose response leaves the model current at whatever generation it
* carries -- this addon's own write landing, with the `w|`/`r|` rows that made
* it in the same envelope. A generation arriving with one of these is not a gap
* and must not trigger a repage of everything.
*
* `pin` and `unpin` are in the list defensively. R8 says every MUTATION bumps
* the counter and a pin changes no warehouse row, so they should not move it at
* all -- but if a future server counts them, a pin click must not cost a
* twelve-command page walk to discover that nothing changed.
--]]
local DELTA_VERBS = {
    put      = true,
    take     = true,
    trash    = true,
    stack    = true,
    stashall = true,
    pull     = true,
    pin      = true,
    unpin    = true,

    -- `buy` moves no rows but DOES bump the generation (capacity changed),
    -- and its own envelope carries the new `k|` -- so it is this addon's own
    -- write, not a gap another window caused. Without this a purchase would
    -- cost a twelve-command repage to rediscover an unchanged list.
    buy      = true,

    -- `sell` (1.9.0) trims or removes the row it listed and rides the delta
    -- in its own envelope, exactly as `trash` does.
    sell     = true,

    -- The crystal verbs (1.12.0). `cluster` and `storecrystals` rewrite and
    -- remove rows and ride the delta in their own envelope; `takecrystals`
    -- and `crystals` move no row and bump nothing, and are here defensively
    -- for the reason `pin` is.
    cluster       = true,
    storecrystals = true,
    takecrystals  = true,
    crystals      = true,

    -- The vendor lane and the batch doors (1.15.0). All three remove or trim
    -- rows and ride the delta in their own envelope, exactly as `trash` does,
    -- so the generation they carry is this client's own write and not a gap
    -- another window caused.
    trashmany     = true,
    vendor        = true,
    vendormany    = true,
};

--[[
* The subset of those that actually move rows, and so the ones whose closing
* `z|` is worth counting the model against the `k|` line (verifyRowCount).
*
* `pin` and `unpin` are deliberately NOT here even though they are delta verbs.
* A pin changes no warehouse row, so its envelope carries no `w|` at all and
* has nothing to truncate -- counting after one would only be asking the same
* question the last real mutation already answered.
--]]
local MUTATION_VERBS = {
    put           = true,
    take          = true,
    trash         = true,
    stack         = true,
    stashall      = true,
    pull          = true,
    sell          = true,
    cluster       = true,
    storecrystals = true,

    -- 1.15.0. A batch is the response most worth counting: it is the one that
    -- can remove a couple of dozen rows in a single envelope, which is exactly
    -- the size at which a lost line stops being obvious on screen.
    trashmany     = true,
    vendor        = true,
    vendormany    = true,
};

-- `<rowid>:<itemid>:<qty>:<flags>:<bound>,...`
local function parsePacked(packed)
    state.modelRev = state.modelRev + 1;

    for _, entry in ipairs(split(packed, ',')) do
        local bits = split(entry, ':');

        if (#bits >= 5) then
            local rowid = intOf(bits[1], 0);

            if (rowid > 0) then
                -- Upsert by row id: a `w|` from a delta replaces the row a
                -- page walk put there, and the two can never disagree about
                -- which row they mean.
                --
                -- `bound` is a legacy field: it used to be the charid a row
                -- was bound to, and since the lane was retired on 2026-08-08
                -- a migrated server always sends 0. It is still PARSED, and
                -- deliberately -- the record is five fields wide and reading
                -- four of them would silently accept a truncated line as a
                -- whole one. Nothing is drawn from it.
                state.rows[rowid] = {
                    rowid  = rowid,
                    itemid = intOf(bits[2], 0),
                    qty    = intOf(bits[3], 0),
                    flags  = intOf(bits[4], 0),
                    bound  = intOf(bits[5], 0),
                };
            end
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = intOf(parts[2], 0);

        if (version ~= PROTOCOL) then
            setStatus(string.format('Server protocol %d, addon expects %d. Update dwwarehouse.', version, PROTOCOL),
                true, true);

            state.inbound      = nil;

            -- Whatever was half-staged goes with the envelope that was
            -- carrying it: nothing from a layout this addon cannot read may
            -- reach the model (1.13.0).
            state.pinsArriving = nil;

            -- A d| envelope IS the answer, whatever version it announced, and
            -- re-asking a server that speaks a layout this addon cannot read
            -- cannot help -- a page walk least of all. One shape across the
            -- suite (dwfame, 2026-08-15); gated in harness_dwsuite.py.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            -- AND THE SWEEP STANDS DOWN WITH THEM (1.13.0). Retiring the asks
            -- stopped the page walk asking, but left `syncing` TRUE for the
            -- rest of the session -- so the freshness slot read "loading 0/?"
            -- for ever beside the accurate banner, and both self-repair paths
            -- (the row-count verify and the generation-gap repage) stayed
            -- disarmed behind that flag. The needPage give-up above is the
            -- shape this should always have had.
            state.syncing  = false;
            state.nextPage = nil;
            state.sweepGen = nil;

            return;
        end

        state.inbound   = parts[3];
        state.inboundAt = os.clock();

        --[[
            The pin list is a full refresh, so it is STAGED here and committed
            whole at `z|` (1.13.0) rather than emptied here and refilled from
            the `p|` lines behind it. A list long enough to be split across two
            lines still may not show only its tail -- which is what the empty
            table was for -- but the live list is no longer the thing being
            emptied, so an envelope that never finishes leaves the pins on
            screen exactly as they were. See the note beside `pins` in `state`;
            it is the house's commit-at-`z|` rule, and this was the one section
            of this window still breaking it.

            THIS RUNS BEFORE ANYTHING ELSE THE `d|` RECORD DOES, because
            handleRecord is called under a pcall: anything that throws above
            this line would leave the staging table from the last envelope in
            place and the records behind it would append to it
            (dwbags.lua:567-571).
        ]]
        if (state.inbound == 'who' or state.inbound == 'pin' or state.inbound == 'unpin') then
            state.pinsArriving = {};
        else
            state.pinsArriving = nil;
        end

        answered(state.inbound);

        return;
    end

    -- Status and error lines are accepted whatever the envelope state. They are
    -- the one thing a player must never lose: the sentence saying why a deposit
    -- was refused is worth more than the response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- Everything after the first pipe, not parts[2]: these carry prose and
        -- an item name may contain anything.
        local text = line:sub(3);

        -- The server saying it cannot trash: either sentence latches the
        -- feature off for the session, so the buttons stop drawing instead of
        -- every click re-earning the same refusal. 'unknown verb "trash"' is
        -- an older server core; 'no trash verb' is a newer core over an older
        -- binary. Both mean the same thing to this window.
        if (kind == 'e' and (text:find('unknown verb "trash"', 1, true) ~= nil
                or text:find('no trash verb', 1, true) ~= nil)) then
            state.noTrash  = true;
            state.trashAsk = nil;
        end

        -- The stack verb's twin, same two sentences one verb over: 'unknown
        -- verb "stack"' is an older server core, 'no stack verb' a newer core
        -- over an older binary. Either latches the button off for the session.
        if (kind == 'e' and (text:find('unknown verb "stack"', 1, true) ~= nil
                or text:find('no stack verb', 1, true) ~= nil)) then
            state.noStack = true;
        end

        -- And the buy verb's, one verb over again. A pending confirmation is
        -- dropped with it -- the question it asks can no longer be answered.
        if (kind == 'e' and (text:find('unknown verb "buy"', 1, true) ~= nil
                or text:find('no buy verb', 1, true) ~= nil)) then
            state.noBuy  = true;
            state.buyAsk = false;
        end

        -- And the sell verb's (1.9.0). 'unknown verb "sell"' is an older
        -- server core; 'cannot sell to the market' is a newer core over an
        -- older binary. The open price strip goes with it.
        if (kind == 'e' and (text:find('unknown verb "sell"', 1, true) ~= nil
                or text:find('cannot sell to the market', 1, true) ~= nil)) then
            state.noSell  = true;
            state.sellAsk = nil;
        end

        --[[
            And the vendor lane's (1.15.0), one latch for both its verbs.
            'unknown verb "vendor"' / 'unknown verb "vendormany"' is an older
            server core; 'no vendor verb' is a newer core over an older binary.

            THE CLOSING QUOTE IS LOAD-BEARING and is the reason these two
            spellings do not have to be tested in any particular order:
            `unknown verb "vendor"` is NOT a substring of
            `unknown verb "vendormany"`, so neither verb's refusal can be
            mistaken for the other's -- the same trick squad_storage.lua's
            `stash`/`stashall` pair turns on, one wire over. Any pending
            confirmation goes with the latch: the question it asks can no
            longer be answered.
        ]]
        if (kind == 'e' and (text:find('unknown verb "vendor"', 1, true) ~= nil
                or text:find('unknown verb "vendormany"', 1, true) ~= nil
                or text:find('no vendor verb', 1, true) ~= nil)) then
            state.noVendor  = true;
            state.vendorAsk = nil;

            if (state.batchAsk ~= nil and state.batchAsk.kind == 'vendor') then
                state.batchAsk = nil;
            end
        end

        --[[
            And the batch trash's (1.15.0), which is its OWN latch and not the
            single Trash button's -- deliberately. `trashmany` is a separate
            binding, so a build can perfectly well have `trash` and not have
            it, and latching `noTrash` here would take away the per-row button
            that still works. 'no trashmany verb' does not contain 'no trash
            verb', and `unknown verb "trashmany"` does not contain
            `unknown verb "trash"`, so the two latches cannot catch each
            other's sentences in either direction.
        ]]
        if (kind == 'e' and (text:find('unknown verb "trashmany"', 1, true) ~= nil
                or text:find('no trashmany verb', 1, true) ~= nil)) then
            state.noTrashMany = true;

            if (state.batchAsk ~= nil and state.batchAsk.kind == 'trash') then
                state.batchAsk = nil;
            end
        end

        -- And the crystal verbs' (1.12.0), one latch for all four: 'no
        -- crystal verbs' is a newer core over an older binary, and the
        -- unknown-verb spelling of any of them is an older core. Either way
        -- the tab's buttons stop drawing; the shelf counts do not depend on
        -- the server and keep showing.
        if (kind == 'e' and (text:find('no crystal verbs', 1, true) ~= nil
                or text:find('unknown verb "cluster"', 1, true) ~= nil
                or text:find('unknown verb "storecrystals"', 1, true) ~= nil
                or text:find('unknown verb "takecrystals"', 1, true) ~= nil
                or text:find('unknown verb "crystals"', 1, true) ~= nil)) then
            state.noCrystals = true;
        end

        --[[
            And the history verb's (1.13.0). `history` shipped on 2026-09-04
            and, like every verb above it, ADDITIVELY -- the protocol version
            did not move, so the server's own refusal is the only signal there
            is that a core predates it ('unknown verb "history"') or that a
            newer core sits over a market binding without the rows ('keeps no
            sale history'). It had no latch at all: the Sell strip's History
            hover re-asked every twenty seconds and every ask painted the red
            banner AND printed a red chat line, for a feature the server does
            not have. Latched, the hover simply says so once and stops asking.

            RETURN BEFORE THE BANNER AND THE PRINT, which is the half that
            makes it a latch rather than a note: this refusal answers a
            question the player never asked out loud (a mouse resting on a
            button), so it must not take the status line away from the
            deposit refusal that is sitting there.
        ]]
        if (kind == 'e' and (text:find('unknown verb "history"', 1, true) ~= nil
                or text:find('keeps no sale history', 1, true) ~= nil)) then
            state.noHistory       = true;
            state.historyArriving = nil;

            return;
        end

        -- A pull shortfall arrives as wire text -- 'short 4102:3,4238:1' --
        -- because the server does not own the name table; this addon does
        -- (the header's naming rule). Translate it before anyone reads it.
        if (kind == 'e') then
            local packed = text:match('^short (.+)$');

            if (packed ~= nil) then
                local names = {};

                for entry in string.gmatch(packed .. ',', '([^,]*),') do
                    local id, qty = entry:match('^(%d+):(%d+)$');

                    if (id ~= nil) then
                        names[#names + 1] = string.format('%s x%s', itemName(tonumber(id)), qty);
                    end
                end

                if (#names > 0) then
                    text = 'The warehouse came up short: ' .. table.concat(names, ', ')
                        .. '. Everything else was pulled.';
                end
            end
        end

        setStatus(text, kind == 'e');

        -- Also to the chat log: the window may not be open, and "nothing
        -- happened" is the worst possible feedback for a refused deposit.
        if (kind == 'e') then
            print(chat.header('dwwarehouse'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        -- The pin list commits here, whole (1.13.0). `emitPins` always writes
        -- at least one `p|`, even an empty one (warehouse_core.lua:278-281),
        -- so a `who`/`pin`/`unpin` that got this far has a real answer in the
        -- staging table and an empty one means "nothing is pinned any more".
        if (state.pinsArriving ~= nil) then
            state.pins         = state.pinsArriving;
            state.pinsArriving = nil;
        end

        -- The sale-history envelope (1.11.0) commits here, the protocol's own
        -- discipline: a half-arrived list never reaches the tooltip.
        --
        -- AND THE CACHE IS PRUNED (1.13.0). It grew one entry per item whose
        -- History was ever hovered and nothing ever took one out, which on a
        -- thousand-row shelf is a table with no ceiling in a window a player
        -- leaves open all evening (the bursts-need-ceilings rule). Emptied
        -- whole rather than aged one at a time: an entry costs one command to
        -- refill and the count is the honest bound to keep.
        if (closed == 'history' and state.historyArriving ~= nil) then
            local held = 0;

            for _ in pairs(state.saleHistory) do
                held = held + 1;
            end

            if (held >= HISTORY_MAX) then
                state.saleHistory  = { };
                -- The ask clock is the same table one key over and grows the
                -- same way, so it is emptied with it.
                state.historyAsked = { };
            end

            state.saleHistory[state.historyArriving.itemid] = { rows = state.historyArriving.rows, at = os.clock() };
            state.historyArriving = nil;
        end

        -- The envelope is complete, so this is the first moment the model can
        -- be counted against what the server just said it holds. Cleared
        -- FIRST: verifyRowCount may start a sweep, and a sweep must not begin
        -- with a stale verb still marked as arriving.
        if (MUTATION_VERBS[closed]) then
            verifyRowCount();
        end

        return;
    end

    if (kind == 'k') then
        state.used = intOf(parts[2], 0);
        state.cap  = intOf(parts[3], 0);

        local gen = intOf(parts[4], 0);

        state.gen = gen;

        -- This addon's own write: the same response carries the rows that
        -- changed, so the model is current at the new generation already.
        if (DELTA_VERBS[state.inbound]) then
            state.syncGen = gen;
        end

        -- The first generation a sweep sees is the one that sweep is OF. Later
        -- pages may carry a higher one -- that is another client writing while
        -- this one reads -- and the pages already collected are then a list of
        -- a moment that has passed.
        if (state.syncing and state.sweepGen == nil) then
            state.sweepGen = gen;
        end

        return;
    end

    if (kind == 'w') then
        -- `or ''` for the reason the `a|` and `c|` branches below already
        -- carry it (1.13.0): split() concatenates its argument, so a record
        -- that arrived as a bare `w|` -- the 150-byte Mes buffer truncating
        -- exactly on the pipe, which is the one truncation this protocol
        -- documents as silent -- threw inside the packet handler's pcall and
        -- printed "bad record" in the chat log instead of being the empty
        -- list it is.
        parsePacked(parts[2] or '');

        return;
    end

    -- b| -- the purchase tier's standing (1.7.0, server 2026-08-27; ADDITIVE,
    -- protocol still 1 -- an older server never sends it and the confirmation
    -- simply says less). On `who` and `buy` responses.
    if (kind == 'b') then
        state.bought = intOf(parts[2], nil);
        state.buyMax = intOf(parts[3], 1000);

        return;
    end

    -- s| -- the account's market standing (1.9.0, server 2026-09-01;
    -- ADDITIVE, protocol still 1). On `who` and `sell` responses. Its
    -- presence is what draws the Sell buttons: an older server never sends
    -- it, and a button that could only ever earn a refusal is not drawn.
    -- i| / y| -- an item's recent sales (1.11.0, server 2026-09-04): the Sell
    -- row's History button. i| names the item, the y| rows follow
    -- (price:date:stack:seller:buyer), and the list commits at z|.
    if (kind == 'i') then
        state.historyArriving = { itemid = intOf(parts[2], 0), rows = {} };

        return;
    end

    if (kind == 'y') then
        if (state.historyArriving ~= nil) then
            local bits = split(parts[2] or '', ':');

            state.historyArriving.rows[#state.historyArriving.rows + 1] = {
                price  = intOf(bits[1], 0),
                date   = intOf(bits[2], 0),
                stack  = intOf(bits[3], 0) == 1,
                seller = bits[4] or '',
                buyer  = bits[5] or '',
            };
        end

        return;
    end

    if (kind == 's') then
        state.market = {
            fee      = intOf(parts[2], 5),
            listings = intOf(parts[3], 0),
            cap      = intOf(parts[4], 0),
        };

        return;
    end

    --[[
        v| -- the NPC shop price of the item ids this response carried (1.15.0,
        server 2026-09-14; ADDITIVE, protocol still 1). `<itemid>:<price>,...`,
        distinct ids, non-zero prices only.

        IT ACCUMULATES AND IS NEVER EMPTIED, which is the one thing about this
        record that is not the `a|` rule. An augment decorates a ROW and dies
        with it; a base price is a property of an item TEMPLATE and cannot
        change while a client is logged in, so a price learned on page 3 is
        still true when a delta later brings that item id back with no `v|` of
        its own. Emptying it at `d|` would mean a Vendor button that blinks off
        every time a row it does not name arrives.

        `modelRev` moves with it: the Value sort and the ticked-total readout
        are cached against that revision (the 1.10.0 frame-rate rule), and a
        page that taught the window a new price has changed what both of them
        would answer.

        `or ''` for the `w|` branch's reason -- a line truncated exactly on the
        pipe must be the empty list it is, not a throw inside the packet
        handler's pcall.
    ]]
    if (kind == 'v') then
        state.modelRev = state.modelRev + 1;

        for _, entry in ipairs(split(parts[2] or '', ',')) do
            local bits   = split(entry, ':');
            local itemid = intOf(bits[1], 0);
            local price  = intOf(bits[2], 0);

            if (itemid > 0 and price > 0) then
                state.prices[itemid] = price;
            end
        end

        return;
    end

    --[[
        g| -- this character's gil in hand and the ceiling it may not pass
        (1.15.0, server 2026-09-14; ADDITIVE, protocol still 1). On `who`,
        `vendor` and `vendormany`.

        ITS PRESENCE IS WHAT DRAWS THE VENDOR BUTTONS, the `s|` record's rule:
        an older server never sends it, and a button that could only ever earn
        a refusal is not drawn at all. A ceiling of 0 is a REAL answer and not
        an absence -- it means there is no currency cell to be paid into -- and
        the buttons are then drawn greyed with that as the reason, because
        "nothing is there" and "this cannot work right now, here is why" are
        different sentences and a player is owed the second one.
    ]]
    if (kind == 'g') then
        state.gil    = intOf(parts[2], 0);
        state.gilCap = intOf(parts[3], 0);

        return;
    end

    -- c| -- the crystal ledger (1.12.0, server 2026-09-05; ADDITIVE, protocol
    -- still 1): the cap, then this character's eight Ephemeral Moogle counts
    -- in element order. On `who` and every crystal verb's answer. Its presence
    -- is what draws the Crystals tab's buttons: an older server never sends
    -- it, and a button that could only ever earn a refusal is not drawn.
    if (kind == 'c') then
        local stored = {};

        for index, entry in ipairs(split(parts[3] or '', ',')) do
            if (index <= #ELEMENTS) then
                stored[index] = intOf(entry, 0);
            end
        end

        for index = 1, #ELEMENTS do
            stored[index] = stored[index] or 0;
        end

        state.crystals = {
            cap    = intOf(parts[2], 5000),
            stored = stored,
        };

        return;
    end

    -- a| -- augment values for rows THIS response carried (1.5.0, server
    -- 2026-08-25; ADDITIVE, protocol still 1 -- an older server never sends
    -- it and the card keeps its flag-4 "Augmented" note). Emitted after the
    -- w| lines, so the row exists by the time this runs; an entry that
    -- matches no row decorates nothing, the v|-to-c| rule.
    if (kind == 'a') then
        state.modelRev = state.modelRev + 1;

        for _, entry in ipairs(split(parts[2] or '', ',')) do
            local bits  = split(entry, ':');
            local rowid = intOf(bits[1], 0);
            local row   = state.rows[rowid];

            if (row ~= nil) then
                local augs = T{ };

                -- Flat id:rank pairs; a torn pair at the end is dropped
                -- rather than half-read, and the server sends at most four.
                for index = 2, #bits - 1, 2 do
                    local id   = intOf(bits[index], 0);
                    local rank = intOf(bits[index + 1], 0);

                    if (id > 0 and rank > 0 and #augs < 4) then
                        augs:append({ id = id, rank = rank });
                    end
                end

                if (#augs > 0) then
                    row.augs = augs;
                end
            end
        end

        return;
    end

    if (kind == 'r') then
        state.modelRev = state.modelRev + 1;

        -- `or ''`, the `w|` branch's reason (1.13.0).
        for _, entry in ipairs(split(parts[2] or '', ',')) do
            local rowid = intOf(entry, 0);

            if (rowid > 0) then
                state.rows[rowid] = nil;
            end
        end

        return;
    end

    if (kind == 'p') then
        -- An empty `p|` is how the server says "nothing is pinned any more"
        -- (warehouse_core.lua's emitPins always emits, even empty), and
        -- `parts[2]` is then the empty string rather than nil -- but a
        -- truncated line can still land here as a bare `p|`, so the `w|`
        -- branch's `or ''` applies (1.13.0).
        --
        -- Written into the STAGING table (1.13.0), which is nil for any
        -- envelope that does not carry a pin refresh -- a stray `p|` inside,
        -- say, a `take` answer then decorates nothing rather than half-editing
        -- the live list. The `a|`-record-for-a-missing-row rule, one kind over.
        local into = state.pinsArriving;

        if (into == nil) then
            return;
        end

        for _, entry in ipairs(split(parts[2] or '', ',')) do
            local itemid = intOf(entry, 0);

            if (itemid > 0) then
                into[itemid] = true;
            end
        end

        return;
    end

    if (kind == 'q') then
        local page  = intOf(parts[2], 0);
        local pages = intOf(parts[3], 0);

        state.pages = pages;

        --[[
            AN ANSWER FOR A PAGE THE SWEEP DID NOT ASK FOR DRIVES NOTHING
            (1.13.0).

            `d|` stamps the outstanding `page` ask ANSWERED without looking at
            which page it is about -- the record does not say -- and the `q|`
            behind it then moved the walk to wherever that answer happened to
            land. Two ways in, both ordinary: a sweep restarted while an older
            `!dww page 7` was still in flight (startSync now drops the QUEUED
            ones, but one already on the wire cannot be recalled), and a page
            that timed out, was re-asked, and then answered twice. In the bad
            case the stale page is the LAST one, and the branch below declares
            the whole walk finished on a model holding one page of eight --
            with `syncing` false and `syncGen` equal to `gen`, which is every
            freshness check in this addon agreeing that a list missing seven
            eighths of the shelf is current.

            So a mismatch is ignored for paging AND puts the real ask back on
            the clock, which is the half that matters: needPage otherwise sees
            `answered` and never re-asks the page nobody answered. The rows the
            stale envelope carried are keyed by row id and stay -- they are
            real rows, and the row-count check is what decides whether the
            model is whole.
        ]]
        local asked = requested['page'];

        if (state.syncing and type(asked) == 'table' and asked.page ~= page) then
            asked.answered = false;

            return;
        end

        state.pagesSeen = page + 1;

        -- CLAMPED BEFORE IT BECOMES A COMMAND. A page count the addon
        -- misparsed would otherwise become an unbounded run of `!dww page N`
        -- lines at one every 1.2 seconds, which is a command loop wearing a
        -- sync's clothes. 1000 rows at 14 per page is 72 pages; 256 is room
        -- for a capacity grant several times over and still terminates.
        if (page + 1 < math.min(pages, 256)) then
            state.nextPage = page + 1;
        else
            state.nextPage = nil;
            state.syncing  = false;

            -- THE SWEEP IS ONLY EVER CLAIMED FOR THE GENERATION IT STARTED
            -- UNDER. If the account moved while it was walking, `gen` is now
            -- ahead of this and the render pass repages -- see MAX_RESWEEPS.
            -- The start generation is spent here (1.10.0): a page answer
            -- that lands OUTSIDE a sweep -- a `!warehouse page` typed by
            -- hand, a late page of a sweep already finished -- used to claim
            -- the model at a sweep long over and cost a twelve-command
            -- repage to learn nothing had moved.
            state.syncGen  = state.sweepGen or state.gen;
            state.sweepGen = nil;

            if (state.syncGen == state.gen) then
                state.resweeps = 0;
            end

            -- A sweep FORCED by the row-count check answers that check the
            -- moment it lands, rather than the answer waiting for whenever the
            -- player next moves something. Agreement clears the latch; a
            -- disagreement that survived a full repage takes the sentence,
            -- because `repaired` is already set and verifyRowCount will not
            -- sweep twice for it.
            if (state.repaired) then
                verifyRowCount();
            end
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017.
*
* Layout after the 4-byte header: Kind at 0x04, Attr at 0x05, Data at 0x06,
* sName[15] at 0x08, Mes at 0x17. Any line whose sender is _DWWDATA is ours: it
* is consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwwarehouse_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    --[[
        THE FIRST BYTE OF THE SENDER DECIDES, BEFORE ANY STRING IS BUILT
        (1.13.0).

        0x017 is the chat packet, so this handler runs for EVERY line anybody
        says in the zone -- a shout, a linkshell, a party, the twenty-odd
        machine senders the other Driftwood addons use -- and it built two
        strings for each of them (a 15-byte `sub`, then a `gsub` that
        allocates whether or not it matches) before comparing them and
        throwing both away. `_DWWDATA` begins with an underscore, which is a
        byte no player name may start with, so one integer compare answers
        "not ours" for essentially all of that traffic.

        Not a name test: the other addons' senders begin with it too, and they
        fall through to the real compare exactly as they always did.
    ]]
    if (e.data_modified:byte(0x09) ~= 0x5F) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwwarehouse'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Kits.
*
* Stored as the `id:qty,id:qty` string `pull` already takes, keyed by name. One
* level of nesting with a scalar leaf, which is the shape dwmacro proved the
* settings serializer round-trips (`dwmacro.lua:270-296`) -- a kit is not worth
* finding out where the serializer's nested-array support ends, and the string
* IS the wire form, so there is one representation rather than two.
--]]
local default_settings = T{
    kits = T{ },

    -- The view (1.9.0): which sort, which category chip and whether Take
    -- moves the whole stack, remembered across sessions. One level of
    -- nesting with scalar leaves, the shape the serializer is known to
    -- round-trip. Client-side chrome, never world state: the server hears
    -- nothing about any of it.
    view = T{
        sort       = 1,
        category   = 1,
        wholeStack = true,

        -- Which tab the window last had on screen (1.13.0). A fourth scalar
        -- leaf beside the three that were already here; an older settings
        -- file simply has no `tab` key and applyView falls back to 1, which
        -- is the shape the file has to keep (a missing field is a default,
        -- never a failure).
        tab        = 1,

        -- Whether the shelf is hiding rows no shop buys (1.15.0). A fifth
        -- scalar leaf on the same terms: an older file has no key and the
        -- filter is off, which is the behaviour every previous version had.
        sellable   = false,
    },
};

local config = settings.load(default_settings);

-- The remembered view onto the live controls. Every field is clamped on the
-- way in -- the settings file is a text file a player can edit, and a sort
-- index past the table would index nil sixty times a second.
local function applyView()
    local view = type(config.view) == 'table' and config.view or { };

    local sort     = math.floor(tonumber(view.sort) or 1);
    local category = math.floor(tonumber(view.category) or 1);
    local tab      = math.floor(tonumber(view.tab) or 1);

    state.sort       = (sort >= 1 and sort <= #SORTS) and sort or 1;
    state.category   = (category >= 1 and category <= #CATEGORIES) and category or 1;
    state.takeAll[1] = view.wholeStack ~= false;

    -- 1.15.0. `== true` and not `~= false`, the opposite of the line above it
    -- and deliberately: a missing key means OFF here (the shelf shows
    -- everything, which is what every version before this one did) and ON
    -- there.
    state.sellable[1] = view.sellable == true;

    -- Four tabs, clamped like its two neighbours. `math.floor` of a NaN is a
    -- NaN and every comparison against one is false, so the `or 1` catches
    -- the LuaJIT `tonumber('nan')` case as well as a missing key.
    state.tab        = (tab >= 1 and tab <= 4) and tab or 1;
end

-- Called on a change, never per frame: settings.save writes a file.
local function saveView()
    if (type(config.view) ~= 'table') then
        config.view = T{ };
    end

    config.view.sort       = state.sort;
    config.view.category   = state.category;
    config.view.wholeStack = state.takeAll[1] and true or false;
    config.view.tab        = state.tab;
    config.view.sellable   = state.sellable[1] and true or false;

    settings.save();
end

applyView();

settings.register('settings', 'dwwarehouse_settings_update', function (s)
    if (s ~= nil) then
        config = s;

        applyView();

        -- The kits table is a different table now, so the Kits tab's cached
        -- view is about a list that no longer exists.
        kitsRev = kitsRev + 1;
    end

    settings.save();
end);

-- 1234567 -> 1,234,567 (dwah.lua's gilText): a price is the whole point of
-- the strip below, and an ungrouped million is a misread waiting to happen.
local function gilText(amount)
    local text = tostring(math.floor(tonumber(amount) or 0));
    local out  = '';

    while #text > 3 do
        out  = ',' .. text:sub(-3) .. out;
        text = text:sub(1, -4);
    end

    return text .. out;
end

--[[
* A wire timestamp as a date, or '?' (1.13.0).
*
* `os.date` IS ANOTHER `string.format('%d', ...)`, and the 1.13.0 header note
* about intOf stops one step short of it. `localtime` has no answer for a
* stamp outside its range, and what the standard library does about that is
* again the runtime's choice: Lua 5.4 (the offline harness) RAISES -- "date
* result cannot be represented in this installation" -- and inside the
* History hover the render pcall answers a throw by CLOSING THE WINDOW; the
* client's LuaJIT 2.1 returns nil instead, and `%s` of nil is the four
* letters 'nil' in the sale line. Either way a sale row whose date arrived
* malformed, truncated or simply as the intOf fallback of 0 drew something
* that was not a date. (Checked on 2026-09-06 against lupa's LuaJIT 2.1 on
* this box: `os.date('%Y-%m-%d', -1)` is nil, and a negative stamp is what a
* CRT west of Greenwich sees for the epoch itself.)
*
* pcall'd AND type-checked rather than range-checked, because the range the
* player's own CRT accepts is not something this addon can know, and because
* the two runtimes fail in two different shapes.
--]]
local function dateText(stamp)
    local ok, text = pcall(os.date, '%Y-%m-%d', stamp);

    if (not ok or type(text) ~= 'string') then
        return '?';
    end

    return text;
end

-- What the seller keeps after the house's cut, from the fee the `s|` record
-- carried. Presentation only: the fee is charged in the server's trigger
-- when the listing sells, whichever door listed it.
local function netOf(price)
    local fee = state.market ~= nil and state.market.fee or 5;

    return price - math.floor(price * fee / 100);
end

-- How many of each item the model holds across every row, as one map -- the
-- number the Deposit tab's Stored column and the Kits tab's shortfall read.
-- Built once per MODEL CHANGE (cached against modelRev, 1.10.0), never per
-- row or per frame: eighty bag rows against a thousand-row model is eighty
-- thousand comparisons a frame the other way.
local countsCache = { rev = nil, counts = { } };

local function storedCounts()
    if (countsCache.rev == state.modelRev) then
        return countsCache.counts;
    end

    local counts = { };

    for _, row in pairs(state.rows) do
        counts[row.itemid] = (counts[row.itemid] or 0) + (tonumber(row.qty) or 0);
    end

    countsCache.rev    = state.modelRev;
    countsCache.counts = counts;

    return counts;
end

--[[
* The client DAT's stack size and equip level for an item, for the sell
* strip, the crystal retrieve preview and the Level sort. Both default when
* the resource has nothing to say, and neither is ever sent anywhere.
*
* CACHED PER ITEM ID, like the name and the type above (1.13.0). The 1.10.0
* frame-rate pass cached everything the sort reads EXCEPT this one, and the
* Level comparator asks for it twice per comparison -- a thousand-row shelf
* sorted by Level is about ten thousand comparisons and twenty thousand
* resource-manager lookups, run again on every keystroke in the Find box.
* The DAT does not change under a running client, which is what makes a
* cache with no invalidation the right shape here.
--]]
local stackCache = { };
local levelCache = { };

local function stackSizeOf(itemid)
    local cached = stackCache[itemid];

    if (cached ~= nil) then
        return cached;
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemid);
    local size = (item ~= nil and tonumber(item.StackSize)) or 1;

    stackCache[itemid] = size;

    return size;
end

local function itemLevel(itemid)
    local cached = levelCache[itemid];

    if (cached ~= nil) then
        return cached;
    end

    local item  = AshitaCore:GetResourceManager():GetItemById(itemid);
    local level = 0;

    if (item ~= nil) then
        -- Item level outranks equip level where both exist: a 119 piece is a
        -- 99 piece with more on it, and it belongs above the plain 99s.
        local ilvl = tonumber(item.ItemLevel) or 0;

        level = (ilvl > 0) and ilvl or (tonumber(item.Level) or 0);
    end

    levelCache[itemid] = level;

    return level;
end

local function kitNames()
    local names = T{ };

    if (type(config.kits) == 'table') then
        for name, _ in pairs(config.kits) do
            if (type(name) == 'string' and type(config.kits[name]) == 'string') then
                names:append(name);
            end
        end
    end

    table.sort(names);

    return names;
end

-- A kit name is a settings key and a widget id. Anything outside plain text
-- would make one of those two ambiguous, so it is trimmed to plain text here
-- rather than being rejected with a sentence nobody would read.
local function cleanKitName(raw)
    local name = tostring(raw or ''):gsub('[^%w%s%-]', ''):gsub('^%s+', ''):gsub('%s+$', '');

    return name:sub(1, KIT_NAME_MAX);
end

--[[
* Turn `id:qty,...` into `!dww pull` lines, none longer than PULL_BUDGET.
*
* SPLITTING IS THE POINT. The server's line budget is 130 bytes and a kit is
* whatever the player put in it, so a twenty-item kit has to become several
* commands. They queue like everything else, one per interval, and each one is
* answered on its own terms -- a shortfall in the second line does not undo the
* first, which is exactly what `pull`'s per-item shortfall reporting is for.
--]]
local function pullCommands(entries)
    local commands = T{ };
    local prefix   = '!dww pull ';
    local current  = '';

    for _, entry in ipairs(entries) do
        local piece     = string.format('%d:%d', entry.id, entry.qty);
        local candidate = (current == '') and piece or (current .. ',' .. piece);

        if (#prefix + #candidate > PULL_BUDGET) then
            if (current ~= '') then
                commands:append(prefix .. current);
            end

            current = piece;
        else
            current = candidate;
        end
    end

    if (current ~= '') then
        commands:append(prefix .. current);
    end

    return commands;
end

-- `id:qty,...` -> { { id, qty }, ... }, every field clamped. R7 applies to the
-- addon's own settings file too: it is a text file a player can edit.
local function parseKit(packed)
    local entries = T{ };

    for _, entry in ipairs(split(tostring(packed or ''), ',')) do
        local bits = split(entry, ':');

        if (#bits >= 2) then
            local id  = math.floor(tonumber(bits[1]) or 0);
            local qty = math.floor(tonumber(bits[2]) or 0);

            if (id > 0 and id < 65535) then
                entries:append({ id = id, qty = math.max(math.min(qty, 99), 1) });
            end
        end
    end

    return entries;
end

local function saveKit(name, entries)
    local clean = cleanKitName(name);

    if (clean == '' or #entries == 0) then
        -- SAY WHY. Both call sites put every side effect inside
        -- `if (saveKit(...))` with no else, so a bare `return false` made the
        -- button look dead -- and these two are the likeliest first attempts:
        -- an empty name box (its default) and a name typed with nothing ticked.
        setStatus((clean == '') and 'Name the kit first.'
            or 'Nothing to save -- tick items on the Deposit tab.', true);

        return false;
    end

    -- The settings file is a text file a player can edit, and an edit that
    -- removed the `kits` table would otherwise throw inside the render pcall
    -- and close the window. A missing table is an empty one.
    if (type(config.kits) ~= 'table') then
        config.kits = T{ };
    end

    -- Read BEFORE the write, obviously, and used only to say which of the two
    -- things just happened.
    local existed = type(config.kits[clean]) == 'string';

    local parts = T{ };

    for _, entry in ipairs(entries) do
        parts:append(string.format('%d:%d', entry.id, entry.qty));
    end

    config.kits[clean] = table.concat(parts, ',');
    settings.save();

    kitsRev = kitsRev + 1;

    --[[
        SAY WHEN IT REPLACED SOMETHING (1.13.0). Typing a name that already
        exists overwrote that kit and answered with the same green 'Saved kit
        "X".' a brand-new one gets, so the one destructive thing this button
        can do was the one thing it did not mention. The Delete button beside
        it asks twice because a kit is player-authored text this window is the
        only copy of; the least a silent overwrite can do is name itself.

        Said HERE rather than at the two call sites, which used to carry a
        copy of the sentence each and would have needed a copy of this one.
    ]]
    setStatus(existed
        and string.format('Replaced kit "%s" -- %d item(s).', clean, #entries)
        or string.format('Saved kit "%s" -- %d item(s).', clean, #entries), false);

    return true;
end

--[[
* Rendering
--]]

--[[
* Your own inventory, read straight out of client memory.
*
* THE SLOT AND THE ITEM ID BOTH GO ON THE WIRE and the server checks them
* against each other (R3, "bag changed"). This read can be stale -- a trade
* completing between the frame that drew the row and the frame that clicked it
* is enough -- and that staleness is precisely what the pair catches. So there
* is no cache here: the rows are re-read every frame the tab is open, and the
* worst outcome of a race is a refusal sentence.
*
* WITHIN ONE FRAME, THOUGH, THE ANSWER CANNOT HAVE CHANGED (1.13.0), and the
* draw loop and the click handlers in the same pass were asking twice --
* eighty sol calls and eighty-one tables built a second time for an answer
* that is by construction identical. Keyed on the FRAME NUMBER, never on a
* clock: a frame is the unit of "the same instant", so the cache can never
* hand back a bag from a frame the player has already moved through, which is
* the staleness the paragraph above is about. `T{}` is rebuilt rather than
* mutated so a caller holding last frame's list (kitEntriesFromBag walks it
* while the Kits tab is drawing) never sees it change under them.
--]]
local bagCache = { frame = -1, rows = T{ } };

local function inventoryRows()
    if (bagCache.frame == frameNo) then
        return bagCache.rows;
    end

    local rows = T{ };

    bagCache.frame = frameNo;
    bagCache.rows  = rows;

    local memory = AshitaCore:GetMemoryManager();

    if (memory == nil) then
        return rows;
    end

    local inventory = memory:GetInventory();

    if (inventory == nil) then
        return rows;
    end

    for slot = 1, INVENTORY_SLOTS do
        local item = inventory:GetContainerItem(INVENTORY_CONTAINER, slot);

        if (item ~= nil and item.Id ~= nil and item.Id ~= 0 and item.Id ~= 65535
                and (item.Count or 0) > 0) then
            rows:append(T{
                slot   = slot,
                itemid = item.Id,
                qty    = item.Count,
                flags  = item.Flags or 0,
                -- The raw exdata bytes, kept for the hover card's augment
                -- lines (1.4.0). Nothing else reads them and nothing sends
                -- them anywhere.
                extra  = item.Extra,
            });
        end
    end

    return rows;
end

--[[
* How many bag rows there are, for the Deposit tab's LABEL -- which is drawn
* on every frame the window is open, whatever tab is on screen (1.13.0).
*
* NOT A BAG WALK A FRAME. The label is drawn BEFORE any tab body, so the
* frame cache above is always cold when it asks; `#inventoryRows()` in the
* label was therefore eighty sol calls and eighty-one tables a frame on every
* tab -- the per-frame double read the round took out, put back for a number
* in a tab label, and on the three tabs that never read the bag it was a read
* 1.12.0 never made at all. The count is refreshed on a frame budget instead
* (and for free whenever something else has already read the bag this frame).
* A label half a second behind the bag is a label, not a slot going on the
* wire, which is the one read that must never be older than the frame -- and
* the Deposit body still makes that read every frame it draws.
--]]
local BAG_COUNT_FRAMES = 30;

local bagCount = { at = -BAG_COUNT_FRAMES, count = 0 };

local function bagRowCount()
    if (bagCache.frame ~= frameNo and (frameNo - bagCount.at) < BAG_COUNT_FRAMES) then
        return bagCount.count;
    end

    bagCount.at    = frameNo;
    bagCount.count = #inventoryRows();

    return bagCount.count;
end

--[[
* Every widget id a Deposit row needs, built once per SLOT (1.13.0).
*
* Unlike a shelf row there is no object to hang them on -- the bag is re-read
* every frame by design -- but a slot number is all four ids depend on, and
* there are eighty of those for the life of the addon. Eighty rows drew four
* `string.format`s each every frame for strings that can never differ.
--]]
local slotIds = { };

local function idsForSlot(slot)
    local ids = slotIds[slot];

    if (ids == nil) then
        ids = {
            tick  = string.format('##dww_sel_%d', slot),
            pin   = string.format('pin##dww_pin_%d', slot),
            unpin = string.format('unpin##dww_pin_%d', slot),
            stash = string.format('Stash##d%d', slot),

            --[[
                The checkbox's own value buffer, ONE PER SLOT rather than one
                per row per frame (1.13.0).

                `imgui.Checkbox` wants a table it can write the new value
                into, and the row built a fresh `T{ ... }` for it every frame
                -- eighty tables a frame, four thousand eight hundred a
                second, each of them garbage the instant the call returned.
                Reused instead: the value is written in before the call and
                read back out after, which is all the binding ever does with
                it. Plain, not `T{}`: nothing appends to it.
            ]]
            tickBuf = { false },

            -- The 'x12' beside the item and the '3 stored' two columns over,
            -- each memoised against the number that produced it -- rowLabels'
            -- rule, for the one table that has no row object to hang a cache
            -- on (1.13.0). Eighty rows formatted both of these every frame.
            qtyFor     = -1,
            qtyText    = '',
            storedFor  = -1,
            storedText = '',
        };

        slotIds[slot] = ids;
    end

    return ids;
end

-- The quantity label for a bag row, formatted once per (slot, quantity) pair.
local function slotQtyText(ids, qty)
    if (ids.qtyFor ~= qty) then
        ids.qtyFor  = qty;
        ids.qtyText = qty > 1 and string.format('x%d', qty) or '';
    end

    return ids.qtyText;
end

-- The Stored column's label, once per (slot, count) pair.
local function slotStoredText(ids, held)
    if (ids.storedFor ~= held) then
        ids.storedFor  = held;
        ids.storedText = string.format('%d stored', held);
    end

    return ids.storedText;
end

--[[
* The unpin button's label for one item id, built once (1.13.0).
*
* The strip is at most six buttons, but every one of them formatted an item
* NAME into a label every frame the Deposit tab was open -- and unlike the
* rest of the strip's work that is a string long enough to matter. Keyed by
* item id, which is what a pin is, so the table cannot grow past the pins the
* server has ever sent.
--]]
local unpinLabels = { };

local function unpinLabel(itemid)
    local label = unpinLabels[itemid];

    if (label == nil) then
        label                = string.format('unpin %s##dww_unpin_%d', itemName(itemid), itemid);
        unpinLabels[itemid]  = label;
    end

    return label;
end

--[[
* Kit entries for the bag, MERGED BY ITEM rather than one per inventory slot.
*
* The selection model is by item id -- `selection[row.itemid]` -- but both Save
* buttons walked inventory ROWS, so an item spread over three slots wrote three
* entries with the same id from a single tick, and a kit that said "99 arrows"
* was really three lines that happened to add up. The stated contract further
* up this file ("one entry per item, at the quantity you hold") was the thing
* that was true of neither button.
*
* Merged and then re-split into <=99 chunks, because a single id:qty pair is
* capped at 99 on BOTH sides (this addon clamps, and the server's pull caps at
* 99 too). A plain merge-then-clamp would quietly turn two full stacks into
* one. `filter` nil means the whole bag.
--]]
local function kitEntriesFromBag(filter)
    local order  = T{ };
    local totals = { };

    for _, row in ipairs(inventoryRows()) do
        if (filter == nil or filter[row.itemid]) then
            if (totals[row.itemid] == nil) then
                order:append(row.itemid);
            end

            totals[row.itemid] = (totals[row.itemid] or 0)
                + math.max(math.floor(tonumber(row.qty) or 1), 1);
        end
    end

    local entries = T{ };

    for _, id in ipairs(order) do
        local left = totals[id];

        while (left > 0) do
            entries:append({ id = id, qty = math.min(left, 99) });
            left = left - 99;
        end
    end

    return entries;
end

--[[
* How many of a row to move: the whole stack by default, or the spin box.
*
* THE FLOOR IS 1 AND IT IS APPLIED HERE AS WELL AS AT THE WIDGET. `InputInt`
* takes any integer it is given, including negative ones, and a negative
* quantity has no meaning in either direction -- it is not "move backwards", it
* is a number that lands in a `uint32` on the server as four billion. The
* widget clamps what the player can see and this clamps what the command can
* carry, so the two would both have to fail for a nonsense number to be sent.
* (dwbags.lua:996-1016; the map-side lesson is R7.)
--]]
local function moveCount(qty)
    local held = math.max(math.floor(tonumber(qty) or 1), 1);

    if (state.takeAll[1]) then
        return held;
    end

    local wanted = math.floor(tonumber(state.takeQty[1]) or 1);

    return math.max(math.min(wanted, held), 1);
end

local function matchesCategory(itemid)
    local category = CATEGORIES[state.category];

    if (category == nil or category.all) then
        return true;
    end

    local kind = itemType(itemid);

    if (category.other) then
        for _, other in ipairs(CATEGORIES) do
            if (other.types ~= nil and other.types[kind]) then
                return false;
            end
        end

        return true;
    end

    return category.types[kind] == true;
end

--[[
* The search key, lowercased ONCE per frame rather than once per row (1.13.0).
*
* matchesSearch ran `tostring(...)` and `:lower()` on the query for every row
* it tested, which on a thousand-row model is two thousand string allocations
* per rebuild -- and a rebuild happens on every keystroke, which is when the
* player is watching. The lowered form is memoised against the raw text, so a
* frame that did not change the box does no work at all.
--]]
local searchCache = { raw = nil, lowered = '' };

local function searchKey()
    local query = tostring(state.search[1] or '');

    if (searchCache.raw ~= query) then
        searchCache.raw     = query;
        searchCache.lowered = query:lower();
    end

    return searchCache.lowered;
end

local function matchesSearch(itemid)
    local query = searchKey();

    if (query == '') then
        return true;
    end

    -- Plain find, not a pattern: an item name may contain '(' or '-' and a
    -- player typing one must not get a Lua pattern error for their trouble.
    return lowerName(itemid):find(query, 1, true) ~= nil;
end

--[[
    Render pagination (1.8.0, owner report: a warehouse holding hundreds to
    thousands of rows tanked the frame rate -- every filtered row was ~7
    widgets a frame). The DRAW is sliced to RENDER_PAGE rows; filtering and
    sorting still run over the WHOLE model inside visibleRows, so Find and
    the category chips search every page -- only what is submitted to ImGui
    is bounded. The page number is client-side chrome, not world state
    (dwgambits' presetPage rule): a plain local, surviving Refresh, never in
    `state`, reset to 1 whenever the filter, category or sort changes so a
    narrowed list is never left staring at an empty late page.

    300 rows a page since 1.10.0 (500 before): the owner's second report,
    with the list still heavy at hundreds of items. Find still searches
    every page -- the filter runs over the whole model, only the draw is
    sliced.
--]]
local RENDER_PAGE = 300;
local viewPage    = 1;

-- What the view was filtered by last frame; a change from anywhere -- typing,
-- the clear x, a chip -- resets the page in one place.
local lastFilterKey = '';

--[[
    The model, filtered and ordered -- REBUILT ONLY WHEN SOMETHING CHANGED
    (1.10.0). It used to be rebuilt every frame, and at a thousand rows that
    was a thousand filter tests and a ten-thousand-comparison sort sixty
    times a second, each comparison two resource-manager lookups: the frame
    rate the owner reported. `state.modelRev` moves on every write to the
    model (a page landing, a delta, a removal, an augment decoration, a
    reset), and the view is cached against it and the filter key; typing in
    Find changes the key and rebuilds at once, so the search still filters
    as you type -- it just does not re-sort an unchanged list in between
    keystrokes.
--]]
local viewCache = { key = nil, rows = T{ } };

--[[
* What one unit of an item fetches at a shop, off the `v|` record (1.15.0).
*
* ZERO IS BOTH ANSWERS and they are told apart one level up: an item no shop
* buys has no entry, and so does every item on a server too old to send the
* record at all. `vendorReady()` below is the one that knows the difference --
* the `g|` record's presence -- so nothing here has to carry a third state.
--]]
local function priceOf(itemid)
    return state.prices[itemid] or 0;
end

-- What a whole row is worth at a shop: the unit price times what is on it.
local function rowValue(row)
    return priceOf(row.itemid) * (row.qty or 0);
end

--[[
* Whether this server can sell from the shelf at all.
*
* THE RECORD IS THE GATE, not the latch -- the `s|` rule (1.9.0) restated for
* the vendor lane. An older server sends no `g|` and earns no refusal for a
* feature it never advertised; `noVendor` is only for the case the record
* cannot cover, which is a core newer than its binary.
*
* A `gilCap` of ZERO still answers true here, on purpose: there IS a vendor
* lane, this character simply has no currency cell to be paid into, and the
* buttons are then drawn greyed with that sentence rather than vanishing.
--]]
local function vendorReady()
    return state.gilCap ~= nil and not state.noVendor;
end

local function visibleRows()
    local mode = SORTS[state.sort] ~= nil and SORTS[state.sort].name or 'Name';
    local key  = string.format('%d|%s|%d|%s|%s', state.modelRev, tostring(state.search[1] or ''),
        state.category or 1, mode, tostring(state.sellable[1] == true));

    if (viewCache.key == key) then
        return viewCache.rows;
    end

    local rows = T{ };

    -- 1.15.0: the sellable-only filter. Hides every row the server priced at
    -- nothing, for the one moment it is useful -- a purge where Vendor is the
    -- intent and the unsellable rows are noise. It hides nothing at all on a
    -- server that sends no prices, which is the honest behaviour: a window
    -- that emptied itself because it had not been told any prices would read
    -- as a broken warehouse.
    local sellableOnly = state.sellable[1] == true and vendorReady();

    for _, row in pairs(state.rows) do
        if (matchesCategory(row.itemid) and matchesSearch(row.itemid)
                and (not sellableOnly or priceOf(row.itemid) > 0)) then
            rows:append(row);
        end
    end

    -- Every comparator ends on row id. Lua's table.sort is not stable, so two
    -- rows that compare equal can swap places on every sort -- and sorting in
    -- the render pass means that is sixty times a second, which is the flicker
    -- that made dwbags' Gear tab unreadable (dwbags.lua:781-787).
    table.sort(rows, function (a, b)
        if (mode == 'Newest') then
            return a.rowid > b.rowid;
        end

        if (mode == 'Qty' and a.qty ~= b.qty) then
            return a.qty > b.qty;
        end

        if (mode == 'Value') then
            local valueA = rowValue(a);
            local valueB = rowValue(b);

            if (valueA ~= valueB) then
                return valueA > valueB;
            end
        end

        if (mode == 'Level') then
            local levelA = itemLevel(a.itemid);
            local levelB = itemLevel(b.itemid);

            if (levelA ~= levelB) then
                return levelA > levelB;
            end
        end

        if (mode == 'Type') then
            local typeA = itemType(a.itemid);
            local typeB = itemType(b.itemid);

            if (typeA ~= typeB) then
                return typeA < typeB;
            end
        end

        local nameA = itemName(a.itemid);
        local nameB = itemName(b.itemid);

        if (nameA ~= nameB) then
            return nameA < nameB;
        end

        return a.rowid < b.rowid;
    end);

    viewCache.key  = key;
    viewCache.rows = rows;

    return rows;
end

-- The greyed tags beside a name, rendered the way dwbags renders 'worn' and
-- 'placed' (dwbags.lua:1077-1095): a fact about the row, in the place a button
-- would otherwise be misread as available.
local function rowTags(row)
    local tags = T{ };

    if (bit.band(row.flags, WH_RARE) ~= 0) then
        tags:append('rare');
    end

    if (bit.band(row.flags, WH_EX) ~= 0) then
        tags:append('ex');
    end

    if (bit.band(row.flags, WH_AUGMENTED) ~= 0) then
        tags:append('aug');
    end

    -- A 'bound' tag stood here, drawn from bits 8/16. Both retired with the
    -- lane on 2026-08-08; the 'ex' and 'aug' tags above still say everything
    -- true about such a row, and neither of them implies it cannot move.

    return table.concat(tags, ' ');
end

--[[
* Every string one drawn shelf row needs, built once per ROW OBJECT (1.13.0).
*
* THE HOT PATH THE 1.8.0 PAGE CAP BOUNDED BUT DID NOT REMOVE. Three hundred
* rows drew four `string.format`s each -- the three widget ids and the
* quantity -- plus rowTags' own table and concat, every frame: about fifteen
* hundred short-lived strings and three hundred tables a second per sixty
* frames, all of them identical to last frame's.
*
* CACHED ON THE ROW OBJECT, which is what makes this need no invalidation and
* have no ceiling problem: parsePacked builds a WHOLE NEW table for a row id
* on every delta, so a row that changed brings a fresh object and the old
* strings are collected with it. `lblQty` is belt and braces against a future
* edit that mutates a row in place instead.
--]]
local function rowLabels(row)
    local labels = row.lbl;

    if (labels ~= nil and row.lblQty == row.qty) then
        return labels;
    end

    labels = {
        take   = string.format('Take##t%d', row.rowid),
        trash  = string.format('Trash##x%d', row.rowid),
        sell   = string.format('Sell##s%d', row.rowid),
        -- 1.15.0. The tick and the shop button, hoisted here with the other
        -- three for the same reason: three hundred drawn rows formatting them
        -- afresh sixty times a second is the cost this cache exists to remove.
        tick   = string.format('##dww_pick%d', row.rowid),
        vendor = string.format('Vendor##v%d', row.rowid),
        qty    = row.qty > 1 and string.format('x%d', row.qty) or '',
        tags   = rowTags(row),
    };

    row.lbl    = labels;
    row.lblQty = row.qty;

    return labels;
end

--[[
* The shelf selection (1.15.0), keyed by row id.
*
* IT IS PRUNED ON THE WAY OUT RATHER THAN ON THE WAY IN, which is what makes it
* correct without a hook on every delta: a row another window trashed, sold or
* emptied is simply no longer in `state.rows`, and this walk drops the tick
* with it. A selection can therefore never name a row the server would refuse
* -- the single Trash question's own 1.13.0 rule, applied to a set.
*
* CACHED AGAINST BOTH REVISIONS. `modelRev` moves when the model does and
* `pickRev` when a tick does, and the totals below are read once per frame by
* the strip and again by each confirmation -- which at three hundred rows is
* the same per-frame walk the 1.10.0 pass took out of `visibleRows`.
--]]
local pickRev   = 0;
local pickCache = { key = nil, rows = T{ }, sellRows = T{ }, value = 0, units = 0,
                    sellValue = 0, sellUnits = 0, flags = 0 };

local function selectedRows()
    local key = string.format('%d|%d', state.modelRev, pickRev);

    if (pickCache.key == key) then
        return pickCache;
    end

    local rows      = T{ };
    local sellRows  = T{ };
    local value     = 0;
    local units     = 0;
    local sellValue = 0;
    local sellUnits = 0;
    local flags     = 0;

    for rowid in pairs(state.picked) do
        local row = state.rows[rowid];

        if (row == nil) then
            -- The prune. Writing to the table being walked is legal in Lua
            -- only for a key that already exists, and this is that case:
            -- `rowid` is the key `next` just handed over.
            state.picked[rowid] = nil;
        else
            rows:append(row);

            value = value + rowValue(row);
            units = units + (row.qty or 0);
            flags = bit.bor(flags, row.flags or 0);

            -- THE SELLABLE SUBSET IS COUNTED HERE, so the Vendor confirmation
            -- can name what it is actually going to sell rather than what is
            -- ticked. A ticked row no shop buys is not an error and is not
            -- removed from the selection -- Trash Selected may perfectly well
            -- want it -- it is simply not part of the gil this sale is worth,
            -- and the question says so out loud.
            if (priceOf(row.itemid) > 0) then
                sellRows:append(row);

                sellValue = sellValue + rowValue(row);
                sellUnits = sellUnits + (row.qty or 0);
            end
        end
    end

    -- A STABLE ORDER, and it is not cosmetic: the batch lines below are built
    -- by walking this list, so an unordered walk would send the same selection
    -- as a different set of commands on every frame the player takes to read
    -- the confirmation. `pairs` over a table keyed by row id has no order at
    -- all.
    local byRow = function (a, b)
        return a.rowid < b.rowid;
    end;

    table.sort(rows, byRow);
    table.sort(sellRows, byRow);

    -- The strip's readout, built HERE rather than in the render pass for the
    -- reason countedLabel exists: it is three numbers that move when a tick
    -- moves, and this cache is already keyed on exactly that.
    if (#rows == 0) then
        pickCache.readout = 'Nothing ticked.';
    elseif (value > 0) then
        pickCache.readout = string.format('%d row(s), %d item(s), about %s gil.',
            #rows, units, gilText(value));
    else
        pickCache.readout = string.format('%d row(s), %d item(s).', #rows, units);
    end

    pickCache.key       = key;
    pickCache.rows      = rows;
    pickCache.sellRows  = sellRows;
    pickCache.value     = value;
    pickCache.units     = units;
    pickCache.sellValue = sellValue;
    pickCache.sellUnits = sellUnits;
    pickCache.flags     = flags;

    return pickCache;
end

-- Every write to the selection goes through here, so the cache above can be
-- keyed on a number instead of being rebuilt per frame.
local function pickChanged()
    pickRev = pickRev + 1;
end

--[[
* A button label carrying a live count, built once per VALUE of that count
* (1.15.0) -- `tabLabel`'s shape, which lives too far down this file to be
* reached from here and is doing the same job for the tab strip.
*
* IT IS NOT AN OPTIMISATION, IT IS THE HOUSE RULE, and the harness pins it as
* a number: a widget id formatted inside the render pass is three strings a
* frame per control for text that changes when the player ticks something, and
* this window draws at sixty frames a second whether or not anything moved.
* The id is part of the label, so caching the label caches the id -- and the
* id is a constant suffix, which is what makes the cached string safe to reuse.
--]]
local countedLabels = {};

local function countedLabel(key, format, count)
    local entry = countedLabels[key];

    if (entry == nil or entry.count ~= count) then
        entry = { count = count, text = string.format(format, count) };

        countedLabels[key] = entry;
    end

    return entry.text;
end

--[[
* The selection, chopped into command lines that fit (1.15.0).
*
* `pullCommands`' shape with one number per entry instead of two, and the SAME
* budget: the server's line budget is 130 and PULL_BUDGET leaves room for the
* verb and a margin, so a selection longer than one line becomes several lines
* rather than a truncated one. Each line is its own command with its own
* answer, which is also what makes a partial failure attributable -- the server
* accounts for every row id in the line it was given.
--]]
local function batchCommands(verb, rows)
    local commands = T{ };
    local prefix   = string.format('!dww %s ', verb);
    local current  = '';

    for _, row in ipairs(rows) do
        local piece     = tostring(row.rowid);
        local candidate = (current == '') and piece or (current .. ',' .. piece);

        if (#prefix + #candidate > PULL_BUDGET) then
            if (current ~= '') then
                commands:append(prefix .. current);
            end

            current = piece;
        else
            current = candidate;
        end
    end

    if (current ~= '') then
        commands:append(prefix .. current);
    end

    return commands;
end

local function capacityBar()
    local cap      = math.max(state.cap, 1);
    local fraction = math.min(state.used / cap, 1.0);

    imgui.PushItemWidth(220);
    -- 22 tall rather than 14: the overlay text is drawn at the font's full
    -- line height, so a bar shorter than that clipped the '323 / 1000 slots'
    -- label top and bottom.
    imgui.ProgressBar(fraction, { 220, 22 }, string.format('%d / %d slots', state.used, state.cap));
    imgui.PopItemWidth();

    --[[
        THE BAR EXPLAINS ITSELF (1.13.0). '323 / 1000 slots' is the most
        prominent number in the window and it was the only one with no hover
        at all -- the Buy Slot note beside it even says "the tooltip's fact
        moves into the bar's own hover", which was a promise the code never
        kept. What a slot IS is the part a player gets wrong: a row, not an
        item, so a stack of twelve costs one.
    ]]
    if (imgui.IsItemHovered()) then
        local free = math.max(state.cap - state.used, 0);

        imgui.SetTooltip(string.format('%s\n%d slot(s) free.', TIPS.capacity, free));
    end

    imgui.SameLine();
end

--[[
* The header strip: capacity, freshness, and the three controls that narrow the
* list. They live above the tab bar rather than inside the Warehouse tab
* because the search box is the fastest way to find a row to Take AND the
* fastest way to check whether something is already stored before stashing a
* second copy -- it belongs to both tabs, so it belongs to neither.
--]]
local function headerStrip()
    capacityBar();

    -- The purchase button (1.7.0, server 2026-08-27). NEVER SENDS ON ITS
    -- OWN, the Trash rule for money: the click only opens the question, and
    -- the command is issued by the confirmation popup below -- 100,000 gil
    -- on a misclick would be this window's worst bug. Gated by its latch
    -- exactly as the Trash buttons are; at the ceiling it stops drawing and
    -- the tooltip's fact moves into the bar's own hover.
    if (not state.noBuy) then
        if (state.bought ~= nil and state.bought >= state.buyMax) then
            imgui.TextDisabled('all bought');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format(
                    'Your account owns all %d purchasable slots.', state.buyMax));
            end
        else
            if (imgui.SmallButton('Buy Slot##dww_buy')) then
                state.buyAsk = true;
            end

            if (imgui.IsItemHovered()) then
                -- The ceiling comes from the `b|` record, not from a literal
                -- (1.13.0): the popup below has read it from the wire since
                -- 1.7.0 and this line was the one copy still saying 1,000
                -- out loud, which is a lie the day the server changes it.
                -- How many are already bought is said too, so the hover
                -- answers the question the popup would without the click.
                imgui.SetTooltip(string.format(
                    'Buy +1 maximum warehouse slot for 100,000 gil.\n'
                    .. 'Asks first. Up to %d slots can be bought, ever%s.',
                    state.buyMax,
                    state.bought ~= nil and string.format(' -- %d so far', state.bought) or ''));
            end
        end

        imgui.SameLine();
    end

    if (imgui.Button('Refresh##dww_refresh')) then
        -- A player pressing this is saying "try again", so the resweep budget
        -- AND the row-count latch both start over: neither give-up sentence
        -- may be permanent.
        state.resweeps = 0;
        state.repaired = false;

        startSync();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Ask the server for the whole list again.\n'
            .. 'Normally unnecessary -- every change answers with the rows it changed.');
    end

    imgui.SameLine();

    -- A generation this addon did not cause: another client on the same
    -- account moved something. Said out loud AND repaired on the next frame,
    -- because a number that is quietly wrong is the worst shape a bug has.
    if (state.gen ~= state.syncGen and not state.syncing) then
        imgui.TextColored(theme.colors.warn, 'Changed elsewhere -- refreshing.');

        -- Two sentences a player has no way to read out of three words
        -- (1.13.0): WHO changed it -- another character on this account, which
        -- is the only thing that can -- and that the repair needs no press.
        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.changed);
        end
    elseif (state.syncing) then
        imgui.TextDisabled(string.format('loading %d/%s...',
            state.pagesSeen, state.pages ~= nil and tostring(state.pages) or '?'));

        -- Why a shelf takes several seconds to appear, which reads as a hang
        -- and is really the client's own chat rate limit (1.13.0).
        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.loading);
        end
    elseif (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));

        -- The one number in the header a player has no way to interpret:
        -- clicks that have not gone out yet, and WHY they are waiting
        -- (1.13.0). Without it a Take that does nothing for four seconds
        -- reads as a click that missed.
        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Commands waiting to go out: %d.\n'
                .. 'The client rate-limits chat and every ! line is a chat line,\n'
                .. 'so they leave one every %.1f seconds rather than being refused.\n'
                .. 'At %d waiting, new clicks are turned away instead of queued.',
                #queue, SEND_INTERVAL, QUEUE_MAX));
        end
    else
        imgui.TextDisabled('');
    end

    -- The market standing (1.9.0), beside the freshness note: how many
    -- listings the account has up and the cap the Sell buttons work under.
    -- Drawn only from a real `s|` record -- a server without the lane says
    -- nothing here, and so does this.
    if (state.market ~= nil and not state.noSell) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('Market: %d of %d listed, fee %d%%',
            state.market.listings, state.market.cap, state.market.fee));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Listings your account has up on the market, across both stores.\n'
                .. 'Every shelf row has a Sell button: it lists straight from the warehouse,\n'
                .. 'free, and the house takes its cut only when it sells. /dwah shows them.');
        end
    end

    -- THE MESSAGE LINE GETS ITS OWN ROW, AND ERRORS ARE RED. Every refusal is a
    -- rule with a reason -- capacity, Rare on the way out, a full inventory --
    -- and that reason is the only thing telling a player what to do instead
    -- (dwbags.lua:1777-1783).
    --[[
        AN EVENT'S SENTENCE FADES; A CONDITION'S STAYS (1.13.0). Dropped here
        rather than on a timer of its own -- the header is the only thing that
        reads it, so nothing has to run while the window is shut.

        THE ROW IS KEPT EITHER WAY. Letting the line disappear would move the
        Find box, the six chips, the tab bar and the top of every table up by
        a line thirty seconds after each click, which is a window that shifts
        under the cursor for no reason the player can see. The freshness slot
        two rows up reserves itself the same way.
    ]]
    if (state.status ~= nil and not state.statusSticky
            and (os.time() - state.statusAt) > STATUS_LINGER) then
        state.status = nil;
    end

    if (state.status ~= nil and state.status ~= '') then
        -- WRAPPED (1.13.0). A refusal is a whole sentence -- the market's
        -- listing refusals and the pull shortfall translated into item names
        -- both run well past the window's width -- and an unwrapped one was
        -- simply cut off at the frame edge, taking the half that says what
        -- to do instead. 0.0 wraps at the content region's right edge, so it
        -- follows the window rather than a number chosen here.
        imgui.PushTextWrapPos(0.0);

        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end

        imgui.PopTextWrapPos();

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(state.statusSticky and TIPS.statusSticky or TIPS.statusEvent);
        end
    else
        imgui.Text('');
    end

    imgui.Text('Find:');
    imgui.SameLine();
    imgui.PushItemWidth(200);

    -- No EnterReturnsTrue: the filter is local, so it applies as it is typed
    -- and nothing is sent for it. The one control in this window that costs
    -- the server nothing should also cost the player no keystroke.
    imgui.InputText('##dww_search', state.search, 64);
    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.find);
    end

    -- One click back to the whole list. Only drawn while there is something to
    -- clear, so the header does not carry a dead button the rest of the time.
    if (state.search[1] ~= '') then
        imgui.SameLine();

        if (imgui.SmallButton('x##dww_search_clear')) then
            state.search[1] = '';
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Clear the search.');
        end
    end

    for index, category in ipairs(CATEGORIES) do
        imgui.SameLine();

        -- Both ids were built at load (1.13.0): the brackets are the only
        -- thing that ever moves, and formatting six labels a frame is six
        -- strings a frame for a row of buttons that cannot change.
        if (imgui.SmallButton(state.category == index and category.idPicked or category.idPlain)) then
            if (state.category ~= index) then
                state.category = index;

                saveView();
            end
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(category.hint);
        end
    end

    --[[
        A SECOND CONTROL ROW, and it is a measurement rather than a
        preference (1.13.0).

        Everything above -- 'Find:', a 200-wide box, the clear button and six
        chips -- comes to about 620 pixels at the default font. Everything
        below it used to be SameLine'd onto the same row: a 90-wide sort
        combo, the 'Whole stack' checkbox with its label, and, whenever that
        box is UNTICKED, a 90-wide quantity spin box after it. That is about
        910 in a window that opens at 840, and ImGui does not wrap a SameLine
        -- it clips it. So the quantity box, the one control the player just
        revealed by unticking Whole stack, was drawn past the right edge of
        the window at its own default size, with a tooltip nobody could ever
        reach to read.

        The split is also the honest grouping: the row above says WHICH rows
        are shown, this one says how they are ordered and how much one press
        moves. Neither runs past 620, so both survive the window's floor.
    ]]
    imgui.PushItemWidth(90);

    local sortName = SORTS[state.sort] ~= nil and SORTS[state.sort].name or 'Name';

    if (imgui.BeginCombo('##dww_sort', sortName)) then
        for index, sort in ipairs(SORTS) do
            if (imgui.Selectable(sort.name, state.sort == index)) then
                if (state.sort ~= index) then
                    state.sort = index;

                    saveView();
                end
            end
        end

        imgui.EndCombo();
    end

    -- After EndCombo, so the hover reads the closed combo rather than
    -- whichever Selectable the list drew last.
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.sort);
    end

    imgui.PopItemWidth();

    imgui.SameLine();

    if (imgui.Checkbox('Whole stack##dww_all', state.takeAll)) then
        saveView();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.wholeStack);
    end

    if (not state.takeAll[1]) then
        imgui.SameLine();
        imgui.PushItemWidth(90);
        imgui.InputInt('##dww_qty', state.takeQty, 1, 10);
        imgui.PopItemWidth();

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.takeQty);
        end

        -- ImGui's InputInt has no lower bound of its own -- the minus button
        -- and the keyboard will both take it below zero and leave it there --
        -- so the bound is applied to the buffer every frame. Done here as well
        -- as inside moveCount so the player never sees a number the window
        -- would not act on.
        if ((tonumber(state.takeQty[1]) or 1) < 1) then
            state.takeQty[1] = 1;
        end
    end

    --[[
        The purchase confirmation. OPENED EVERY FRAME THE QUESTION IS PENDING,
        the trash popup's modality: ImGui closes a popup on any outside click,
        and a silently dropped money question would leave the player unsure
        whether they just spent 100k. The copy is the contract, spelled out:
        what it costs, exactly what it buys (+1 slot, nothing else), and how
        many times it can ever be done -- the owner's requirement that nobody
        finds out AFTER paying that 100,000 gil bought one slot.
    ]]
    if (state.buyAsk) then
        imgui.OpenPopup('##dww_confirm_buy');
    end

    if (imgui.BeginPopup('##dww_confirm_buy')) then
        if (not state.buyAsk) then
            imgui.CloseCurrentPopup();
        else
            imgui.Text('Buy one warehouse slot for 100,000 gil?');
            imgui.TextDisabled('You get exactly +1 maximum warehouse storage. Nothing else.');
            imgui.TextDisabled(string.format('An account can buy at most %d slots, ever.', state.buyMax));

            if (state.bought ~= nil) then
                imgui.TextDisabled(string.format('This account has bought %d of %d so far.',
                    state.bought, state.buyMax));
            end

            imgui.TextDisabled('The gil is spent for good. This cannot be refunded.');

            if (imgui.Button('Buy for 100,000 gil##dww_buy_yes')) then
                issue('!dww buy');

                state.buyAsk = false;
                imgui.CloseCurrentPopup();
            end

            imgui.SameLine();

            if (imgui.Button('Cancel##dww_buy_no')) then
                state.buyAsk = false;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end
end

local function warehouseTab()
    local rows = visibleRows();

    -- NON-DESTRUCTIVE, SO NO CONFIRMATION. Nothing is created or lost -- the
    -- server shuffles quantities between rows of the same item and deletes
    -- only rows the shuffle emptied -- so unlike Trash and Stash All this is
    -- a plain click. Gated by its latch exactly as the Trash buttons are.
    if (not state.noStack) then
        if (imgui.Button('Stack Items##dww_stack')) then
            issue('!dww stack');
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Combine partial stacks of the same item into full ones --\n'
                .. '11 and 6 become 12 and 5, and rows left empty are freed.\n'
                .. 'Signed and augmented copies keep their own rows.');
        end

        imgui.SameLine();

        -- The line beside the button used to repeat the tooltip's first
        -- sentence back at it (1.13.0). Said once, and the space it was
        -- taking now carries the fact the button cannot: how many slots the
        -- shelf has left, which is the reason anybody presses it.
        imgui.TextDisabled(string.format('Frees slots -- %d of %d used.', state.used, state.cap));
    end

    if (state.cap == 0 and not state.syncing) then
        imgui.TextDisabled('Nothing loaded yet. Refresh asks the server for the list.');
    end

    --[[
        The sell strip (1.9.0): the row whose Sell button was pressed, its
        price box, what the seller keeps, and the List buttons -- dwah's own
        Sell tab shape, above the table so it cannot collide with the row
        that opened it. THE STRIP IS THE DELIBERATE ACT: a price typed and a
        List button pressed. There is no popup on top, because a listing is
        reversible (the market's Cancel puts it back in a bag) -- unlike Trash,
        where the popup exists because nothing brings the item back.

        The row is re-read from the model every frame: a delta from another
        window may have trimmed or removed it between the click and the
        press, and the strip then closes rather than sending a stale row id
        (the server would refuse it anyway; this just says so sooner).
    ]]
    if (state.sellAsk ~= nil) then
        local ask = state.sellAsk;
        local row = state.rows[ask.rowid];

        if (row == nil or state.noSell or state.market == nil) then
            state.sellAsk = nil;
        else
            drawIcon(row.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(string.format('Selling %s%s:', itemName(row.itemid),
                row.qty > 1 and string.format(' (x%d stored)', row.qty) or ''));
            cardOnHover(row.itemid, hovered,
                bit.band(row.flags or 0, WH_AUGMENTED) ~= 0 and (row.augs or true) or nil);

            imgui.SameLine();
            imgui.PushItemWidth(120);
            imgui.InputText(string.format('##dww_price%d', row.rowid), state.sellPrice, 10);
            imgui.PopItemWidth();

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('The asking price, in gil, for the whole listing.');
            end

            imgui.SameLine();

            -- Digits only: a comma or a space typed into the box would read
            -- as zero and the buttons would simply not appear, which is the
            -- honest answer but not a helpful one, so the strip says why.
            local typed = tostring(state.sellPrice[1] or '');
            local price = math.floor(tonumber(typed) or 0);

            if (typed ~= '' and typed:match('^%d+$') == nil) then
                imgui.TextColored(theme.colors.err, 'digits only');
            elseif (price > 0 and price <= MAX_PRICE) then
                imgui.TextDisabled(string.format('you get %s', gilText(netOf(price))));

                --[[
                    THE BUTTONS GET A ROW OF THEIR OWN (1.13.0), and it is
                    arithmetic rather than taste. The strip already carries an
                    icon, 'Selling <item name> (x12 stored):', a 120-wide price
                    box and the net -- about 470 pixels for an ordinary item
                    name and more for a long one -- and then SameLine'd 'List
                    single', 'List stack', 'Never mind' and 'History' after it:
                    roughly 830 in a window that opens at 840, and past the
                    right edge of one dragged anywhere near its floor. ImGui
                    clips a SameLine rather than wrapping it, so History was
                    the first thing to go and Never mind the second -- which is
                    the pair a player reaches for when the strip opened on the
                    wrong row.
                ]]
                if (imgui.Button(string.format('List single##dww_sell1_%d', row.rowid))) then
                    issue(string.format('!dww sell %d %d', row.rowid, price));

                    state.sellAsk = nil;
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('List one %s at %s gil.%s',
                        itemName(row.itemid), gilText(price),
                        row.qty > 1 and ' The rest stays on the shelf.' or ''));
                end

                -- A stack listing is the WHOLE stack or nothing (the market's
                -- full-stack rule), so the button exists only for a row that
                -- holds exactly one.
                local stackSize = stackSizeOf(row.itemid);

                if (state.sellAsk ~= nil and stackSize > 1 and row.qty == stackSize) then
                    imgui.SameLine();

                    if (imgui.Button(string.format('List stack##dww_sell12_%d', row.rowid))) then
                        issue(string.format('!dww sell %d %d stack', row.rowid, price));

                        state.sellAsk = nil;
                    end

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(string.format('List the whole stack of %d at %s gil for the lot.',
                            stackSize, gilText(price)));
                    end
                end
            elseif (price > MAX_PRICE) then
                imgui.TextColored(theme.colors.err, 'too high -- 999,999,999 at most');
            else
                imgui.TextDisabled('price?');
            end

            if (state.sellAsk ~= nil) then
                imgui.SameLine();

                if (imgui.Button('Never mind##dww_sell_no')) then
                    state.sellAsk = nil;
                end
            end

            -- History (1.11.0, owner request): hover = the last five sales,
            -- asked once over this wire (`!dww history`, the market's own rows
            -- served by the warehouse core); click = the market window's
            -- History tab on this item, through dwah's own command.
            --
            -- LATCHED OFF WHERE THE SERVER HAS NO SUCH VERB (1.13.0). `history`
            -- is additive and the protocol did not move for it, so an older
            -- core answers `unknown verb "history"` -- and the button that
            -- earns that refusal is worth less than the space it takes.
            if (state.sellAsk ~= nil and not state.noHistory) then
                imgui.SameLine();

                if (imgui.Button('History##dww_sell_hist')) then
                    -- THROUGH THE QUEUE, not straight at dwecho (1.13.0). The
                    -- direct send skipped both things the queue is for: the
                    -- 1.2-second throttle -- two clicks in one frame are two
                    -- chat lines, and the client answers the second with "A
                    -- command error occurred" -- and the canSend hold, which
                    -- is what keeps a line waiting through a zone rather than
                    -- being thrown away in it. Every other line this window
                    -- sends has gone through issue() since 1.0.0.
                    issue(string.format('/dwah history %d', row.itemid));
                end

                if (imgui.IsItemHovered()) then
                    local known = state.saleHistory[row.itemid];

                    -- A PRICE GOES STALE, so the answer is only believed for
                    -- HISTORY_TTL (1.13.0). The `at` stamp was recorded from
                    -- the first version and never read, so a list fetched
                    -- once was shown for the rest of the session -- about a
                    -- market that moves while the window is open.
                    if (known ~= nil and (os.clock() - (known.at or 0)) > HISTORY_TTL) then
                        state.saleHistory[row.itemid] = nil;
                        known                         = nil;
                    end

                    if (known == nil) then
                        if ((os.clock() - (state.historyAsked[row.itemid] or -100)) > 20) then
                            state.historyAsked[row.itemid] = os.clock();
                            issue(string.format('!dww history %d', row.itemid));
                        end

                        imgui.SetTooltip('Asking the market for recent sales... Click to open the full history in the market window.');
                    elseif (#known.rows == 0) then
                        imgui.SetTooltip('No recorded sales yet. Click to open the market window on its History tab.');
                    else
                        local lines = {};

                        for i, sale in ipairs(known.rows) do
                            if (i > 5) then break; end

                            lines[#lines + 1] = string.format('%s gil%s -- %s', gilText(sale.price),
                                sale.stack and ' (stack)' or '', dateText(sale.date));
                        end

                        lines[#lines + 1] = 'Click for the full history in the market window.';
                        imgui.SetTooltip(table.concat(lines, '\n'));
                    end
                end
            end
        end
    end

    -- Any change to what the list is filtered or ordered by resets the page.
    -- Watched here rather than at each widget because the search box has no
    -- reliable change return across imgui bindings, and the clear x, the
    -- chips and the sort all funnel through the same three fields anyway.
    local filterKey = string.format('%s|%d|%d', state.search[1] or '', state.category or 1, state.sort or 1);

    if (filterKey ~= lastFilterKey) then
        lastFilterKey = filterKey;
        viewPage      = 1;
    end

    -- The render slice. Clamped both ends every frame (dwgambits' shape):
    -- a list that shrank -- a trash, a narrower search -- pulls the page
    -- back into range instead of stranding the view past the end.
    local pages = math.max(1, math.ceil(#rows / RENDER_PAGE));

    if (viewPage > pages) then
        viewPage = pages;
    end

    if (viewPage < 1) then
        viewPage = 1;
    end

    local first = (viewPage - 1) * RENDER_PAGE + 1;
    local last  = math.min(#rows, first + RENDER_PAGE - 1);

    -- Said when the filter is hiding something ('showing all N' is noise,
    -- but a search that matched nothing looks exactly like an empty
    -- warehouse), AND whenever there is more than one render page -- a
    -- bounded view with no count line reads as the whole warehouse.
    local held = modelRowCount();

    -- Whether anything has been drawn on this row yet, so the controls that
    -- follow know whether to SameLine onto it or start it.
    local countLine = (#rows < held or pages > 1);

    if (countLine) then
        if (pages > 1) then
            imgui.TextDisabled(string.format('Showing %d-%d of %d%s.', first, last, #rows,
                #rows < held and ' matching (filtered)' or ' stored items'));
        else
            imgui.TextDisabled(string.format('Showing %d of %d stored items (filtered).', #rows, held));
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.showing);
        end
    end

    if (pages > 1) then
        imgui.SameLine();

        --[[
            THE ARROWS SAY WHY THEY CANNOT MOVE (1.13.0). Both used to draw
            live at either end and swallow the click behind an `and` -- the
            press registered, the page did not move, and nothing on screen
            said which of the two had happened. Greyed with the reason on
            hover instead, which is the rule the rest of this window follows
            for a control it will not act on.

            BeginDisabled takes the condition rather than being wrapped in
            an `if` (dwbags.lua:3552): the call is then unconditional and its
            End can never be skipped by a path added later.

            AND THE REASON LIVES ON THE COUNTER BETWEEN THEM (1.13.0), which
            is the half 1.13.0 got wrong. ImGui reports no hover at all for an
            item submitted inside a disabled scope unless the hover is asked
            for with the newest-generation allow-when-disabled flag, which
            this suite does not use: a constant missing from the build a
            player happens to have installed is a Lua error sixty times a
            second. So the two
            'Already on the first/last page' tooltips written after
            EndDisabled were dead code that read exactly like the courtesy the
            house asks for. Each arrow now explains itself only while it is
            LIVE, and the always-live page counter carries the rest.
        ]]
        local atFirst = (viewPage <= 1);

        imgui.BeginDisabled(atFirst);

        if (imgui.SmallButton('<##dww_page_prev') and not atFirst) then
            viewPage = viewPage - 1;
        end

        imgui.EndDisabled();

        if (not atFirst and imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.pagePrev);
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('page %d of %d', viewPage, pages));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.pager);
        end

        imgui.SameLine();

        local atLast = (viewPage >= pages);

        imgui.BeginDisabled(atLast);

        if (imgui.SmallButton('>##dww_page_next') and not atLast) then
            viewPage = viewPage + 1;
        end

        imgui.EndDisabled();

        if (not atLast and imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.pageNext);
        end
    end

    --[[
        Copy (1.13.0). A shelf is a shopping list somebody else is going to
        read -- what a linkshell has spare, what a crafter is short of -- and
        the only way to get one out of this window was to retype it. Copies
        the rows ON SCREEN, filter and page included, because that is what
        the player is looking at when they press it.

        GUARDED, the dwgambits rule: `SetClipboardText` is in Ashita's own
        SDK, but this addon runs against whatever build a player installed
        and a missing function is a Lua error sixty times a second. Asked
        once at load, latched, and the button simply does not draw where the
        call is not there.
    ]]
    if (CAN_CLIPBOARD) then
        if (countLine) then
            imgui.SameLine();
        end

        if (imgui.SmallButton('Copy##dww_copy')) then
            local lines = T{ };

            for rowIndex = first, last do
                local row = rows[rowIndex];

                lines:append(string.format('%s x%d', itemName(row.itemid), row.qty));
            end

            if (#lines == 0) then
                setStatus('Nothing to copy -- no row matches the search.', true);
            elseif (pcall(imgui.SetClipboardText, table.concat(lines, '\n'))) then
                setStatus(string.format('Copied %d row(s) to the clipboard.', #lines), false);
            else
                setStatus('This Ashita build refused the clipboard.', true);
            end
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(#rows == 0 and TIPS.copyEmpty or TIPS.copy);
        end
    end

    --[[
        THE SELECTION STRIP (1.15.0, the owner's request).

        "im avoiding purging my wh because its 1 by 1." The tick column in the
        table below is the half that lets a player say what they mean; this is
        the half that lets them say it about three hundred rows at once.

        EVERY BULK CONTROL HERE ACTS ON THE FILTERED VIEW AND NOTHING ELSE.
        `rows` is what is on screen -- the search, the category chip and the
        sellable filter already applied -- because "select all" about a
        thousand rows the player cannot see would be the most dangerous button
        in this suite. The page slice is deliberately NOT applied: a filter is
        a statement about what you want, a render page is a statement about
        what fits, and ticking only the visible three hundred of a four hundred
        row search would be a silent third rule.

        NOTHING HERE SENDS. Every one of these buttons edits a local table; the
        two that lead anywhere open a confirmation, which is the Trash button's
        contract restated for a set -- and a set is exactly where it matters
        more, not less.
    ]]
    local picked = selectedRows();
    local chosen = #picked.rows;

    if (imgui.SmallButton(countedLabel('pickAll', 'Tick all (%d)##dww_pick_all', #rows))) then
        for _, row in ipairs(rows) do
            state.picked[row.rowid] = true;
        end

        pickChanged();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pickAll);
    end

    imgui.SameLine();

    if (imgui.SmallButton('None##dww_pick_none')) then
        state.picked = {};

        pickChanged();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pickNone);
    end

    imgui.SameLine();

    if (imgui.SmallButton('Invert##dww_pick_invert')) then
        for _, row in ipairs(rows) do
            state.picked[row.rowid] = (state.picked[row.rowid] == nil) or nil;
        end

        pickChanged();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pickInvert);
    end

    imgui.SameLine();

    --[[
        "Select all of this item" without a button on every row (the owner's
        list). Tick one Bat Fang and press this, and every Bat Fang row the
        filter is showing joins it -- which is the shape a shelf silted up with
        twelve rows of one crystal actually needs, and it costs one control
        instead of three hundred.
    ]]
    if (imgui.SmallButton('Same item##dww_pick_same')) then
        local wanted = {};

        for _, row in ipairs(picked.rows) do
            wanted[row.itemid] = true;
        end

        for _, row in ipairs(rows) do
            if (wanted[row.itemid]) then
                state.picked[row.rowid] = true;
            end
        end

        pickChanged();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pickSame);
    end

    --[[
        The sellable-only filter, beside the controls it exists for rather than
        up in the shared header: it is a statement about the SHELF, and the
        header's chips narrow the Deposit tab too.

        DRAWN ONLY WHERE THE SERVER PRICES ANYTHING. A filter that can only
        ever hide everything, on a server that has told this window nothing
        about prices, is a button whose one outcome is an empty warehouse.
    ]]
    if (vendorReady()) then
        imgui.SameLine();

        if (imgui.Checkbox('Sellable only##dww_sellable', state.sellable)) then
            saveView();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.sellableOnly);
        end
    end

    --[[
        THE TWO BATCH BUTTONS TAKE A ROW OF THEIR OWN, which is the 1.13.0
        measuring lesson rather than taste: the row above already runs to four
        buttons and a checkbox, and ImGui clips a SameLine rather than wrapping
        it -- so anything added to the end of it would simply not be on screen
        at the width this window opens at.

        THEY ARE GREYED RATHER THAN HIDDEN when they cannot be pressed right
        now -- nothing ticked, no pouch, nothing a shop buys -- and the
        REASON LIVES ON THE ALWAYS-LIVE READOUT BESIDE THEM. (The one case that
        HIDES a control instead is a server that has no vendor lane at all; see
        the note on Vendor Selected below, and the `s|` rule it follows.)
        ImGui reports no
        hover at all for an item submitted inside a disabled scope unless the
        hover is asked for with a flag this suite does not use, so a tooltip
        written after EndDisabled is dead code that reads exactly like the
        courtesy the house rule asks for (the page arrows, 1.13.0). The
        readout is outside every disabled scope and says why for both.
    ]]
    local canTrashMany = chosen > 0 and not state.noTrashMany;
    local canVendor    = vendorReady() and #picked.sellRows > 0
        and (state.gilCap == nil or state.gilCap > 0);

    imgui.BeginDisabled(not canTrashMany);

    if (imgui.Button(countedLabel('pickTrash', 'Trash Selected (%d)##dww_pick_trash', chosen)) and canTrashMany) then
        -- NEVER SENDS ON ITS OWN, the single Trash button's whole rule: the
        -- click only records what is ticked, and the confirmation below is
        -- what issues the commands.
        state.batchAsk = { kind = 'trash' };
    end

    imgui.EndDisabled();

    --[[
        AND VENDOR SELECTED IS NOT DRAWN AT ALL where the server has not said
        it can sell from the shelf -- which is the `s|` rule and NOT the greyed
        treatment its neighbour gets. The two are different questions and are
        owed different answers: "this server does not have that feature" is not
        something a player can act on, so there is nothing to grey; "you have
        no gil pouch" and "no shop buys any of these" are, so those stay drawn
        with the reason on the readout beside them.
    ]]
    if (vendorReady()) then
        imgui.SameLine();

        imgui.BeginDisabled(not canVendor);

        if (imgui.Button(countedLabel('pickVendor', 'Vendor Selected (%d)##dww_pick_vendor', #picked.sellRows)) and canVendor) then
            state.batchAsk = { kind = 'vendor' };
        end

        imgui.EndDisabled();
    end

    imgui.SameLine();

    --[[
        The readout, and the one live thing on this row: what is ticked, what
        it is worth, and -- when either button beside it is greyed -- why.
    ]]
    imgui.TextDisabled(picked.readout);

    if (imgui.IsItemHovered()) then
        local why = T{ TIPS.pickReadout };

        if (chosen == 0) then
            why:append('Trash Selected and Vendor Selected are greyed because nothing is ticked.');
        else
            if (state.noTrashMany) then
                why:append('Trash Selected is greyed: this server has no batch trash verb.');
            end

            if (not vendorReady()) then
                why:append('There is no Vendor Selected button: this server cannot sell to a shop from the shelf.');
            elseif (state.gilCap == 0) then
                why:append('Vendor Selected is greyed: you have no gil pouch to be paid into.');
            elseif (#picked.sellRows == 0) then
                why:append('Vendor Selected is greyed: no shop buys any of the ticked rows.');
            elseif (#picked.sellRows < chosen) then
                why:append(string.format('%d of the ticked rows are not bought by any shop and would be left alone.',
                    chosen - #picked.sellRows));
            end
        end

        imgui.SetTooltip(table.concat(why, '\n'));
    end

    if (imgui.BeginTable('##dww_rows', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        --[[
            THE NAME COLUMN STRETCHES (1.13.0). The four fixed widths added
            up to 625 of an 840-wide window, so a long item name was clipped
            inside 300 pixels while two hundred sat empty to the right of the
            buttons -- and widening the window did not help, because a fixed
            column stays fixed. Stretch gives the name every pixel the three
            fixed columns do not need, at any window size. Only ScrollX makes
            stretch meaningless in an ImGui table, and this one scrolls Y.

            The three that stay fixed are the ones whose contents do not
            vary: a quantity, at most 'rare ex aug', and three small buttons.
            Fixing them is what stops the buttons moving as rows scroll past.
        ]]
        --[[
            TWO MORE FIXED COLUMNS SINCE 1.15.0, and both are the narrowest
            thing that can carry what they hold: a tick, and a gil figure. The
            stretch column is still the name, so neither of them takes a pixel
            from it at any window width -- which is the one property the
            1.13.0 measuring pass was about.
        ]]
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 26, 0);
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 45, 0);
        imgui.TableSetupColumn('Value', ImGuiTableColumnFlags_WidthFixed, 80, 0);
        imgui.TableSetupColumn('Tags', ImGuiTableColumnFlags_WidthFixed, 95, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 215, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for rowIndex = first, last do
            local row = rows[rowIndex];

            local labels = rowLabels(row);

            imgui.TableNextRow();
            imgui.TableNextColumn();

            --[[
                The tick (1.15.0). A PLAIN BUFFER PER FRAME rather than one
                cached on the row: the Deposit tab's ticks cache theirs per
                SLOT because a bag slot is a stable identity the render pass
                revisits, and a shelf row object is replaced wholesale by every
                delta that touches it (see rowLabels), so a cached buffer would
                be the one thing on the row that outlived its own row.

                The widget id carries the ROW id, like every other control in
                this table: two rows of the same item -- the normal outcome of
                depositing a stack twice -- would otherwise share an id and
                ImGui would merge their click handling.
            ]]
            local ticked = { state.picked[row.rowid] == true };

            if (imgui.Checkbox(labels.tick, ticked)) then
                state.picked[row.rowid] = ticked[1] and true or nil;

                pickChanged();
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.rowTick);
            end

            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(itemName(row.itemid));
            -- A shelf row's values ride the a| record when the blob is a
            -- standard augment blob (1.5.0); a flagged row the server sent
            -- no values for -- old server, signed or charged copy -- still
            -- says "Augmented" and invents nothing.
            cardOnHover(row.itemid, hovered,
                bit.band(row.flags or 0, WH_AUGMENTED) ~= 0 and (row.augs or true) or nil);

            imgui.TableNextColumn();
            imgui.Text(labels.qty);

            imgui.TableNextColumn();

            --[[
                What a shop pays for the whole row (1.15.0), off the `v|`
                record. Three states and they are three different sentences:
                a price the server sent, a server that priced this id at
                nothing ('--', because no shop buys it), and a server that
                sends no prices at all (blank, because this window knows
                nothing and must not imply it does).
            ]]
            if (not vendorReady()) then
                imgui.Text('');
            else
                local worth = rowValue(row);

                if (worth > 0) then
                    imgui.TextDisabled(gilText(worth));

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(string.format('A shop pays %s gil each, %s for the row.',
                            gilText(priceOf(row.itemid)), gilText(worth)));
                    end
                else
                    imgui.TextDisabled('--');

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('No shop buys this. Vendor will skip it and say so.');
                    end
                end
            end

            imgui.TableNextColumn();

            local tags = labels.tags;

            if (tags ~= '') then
                imgui.TextDisabled(tags);

                -- Three abbreviations in a greyed column, and what each one
                -- means for the buttons beside it is the whole reason a
                -- player is reading them (1.13.0).
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('rare -- only one may be held at a time.\n'
                        .. 'ex -- exclusive: it cannot be traded, sold or delivered.\n'
                        .. 'aug -- augmented, signed or charged: it keeps its own row and never merges.\n'
                        .. 'None of them stops any character on the account taking it back out.');
                end
            else
                imgui.Text('');
            end

            imgui.TableNextColumn();

            -- EVERY WIDGET ID CARRIES THE ROW ID. Two rows of the same item --
            -- which is the normal outcome of depositing a stack twice -- would
            -- otherwise share a `##<itemid>` suffix, and ImGui answers a
            -- conflicting id by merging their click handling
            -- (dwbags.lua:1018-1026).
            --
            -- EVERY ROW GETS A TAKE BUTTON NOW. A row whose bit 8 was set used
            -- to draw the words 'another character' and a tooltip instead, and
            -- that branch went with the lane on 2026-08-08: the server refuses
            -- no row on ownership grounds short of the account itself, and the
            -- account's rows are the only rows this window is ever sent.
            local count = moveCount(row.qty);

            if (imgui.SmallButton(labels.take)) then
                issue(string.format('!dww take %d %d', row.rowid, count));
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Take %d into your inventory.', count));
            end

            -- NEVER SENDS ON ITS OWN. The click only records what the player
            -- pointed at; the command is issued by the confirmation popup
            -- below, which is the whole reason the popup exists -- this is the
            -- one button in the window whose mistake cannot be undone.
            if (not state.noTrash) then
                imgui.SameLine();

                if (imgui.SmallButton(labels.trash)) then
                    state.trashAsk = {
                        rowid  = row.rowid,
                        itemid = row.itemid,
                        qty    = count,
                        flags  = row.flags,
                        augs   = row.augs,
                    };
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Throw %d away, straight from the warehouse.\n'
                        .. 'No inventory space needed. Asks first -- this cannot be undone.', count));
                end
            end

            --[[
                The Sell button (1.9.0). Drawn only when the server has said
                it can (the `s|` record) and not latched off, and not for a
                row the market's gate would refuse on sight: an EX copy never
                lists, and a row whose blob decoded to real augments is
                account-exclusive (D9). A flag-4 row WITHOUT decoded augments
                -- a signed or charged copy -- still draws it: those list
                legally, into the market's blob lane. The server re-decides
                every one of these from the bytes; this is only the addon
                declining to draw a button it knows would fail.
            ]]
            local sellable = state.market ~= nil and not state.noSell
                and bit.band(row.flags or 0, WH_EX) == 0
                and row.augs == nil;

            if (sellable) then
                imgui.SameLine();

                if (imgui.SmallButton(labels.sell)) then
                    state.sellAsk      = { rowid = row.rowid, itemid = row.itemid };
                    state.sellPrice[1] = '';
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('List it on the market straight from the warehouse --\n'
                        .. 'no bag slot needed. Listing is free; the house takes its cut when it sells.\n'
                        .. 'Cancel it later from /dwah and it comes back into a bag.');
                end
            end

            --[[
                The Vendor button (1.15.0). Drawn only where the server has
                said it can sell from the shelf (the `g|` record) and only for
                a row a shop actually buys -- an item the server priced at
                nothing gets the '--' in the Value column and no button, which
                is the same "do not offer what could only earn a refusal" rule
                the Sell button follows.

                RARE AND EX STILL GET ONE, deliberately: the shop counter buys
                both, so a window that refused them would be inventing a rule
                the game does not have. The confirmation below is the gate,
                and it says 'rare' and 'ex' in red exactly as the Trash
                question does.

                NEVER SENDS ON ITS OWN. Selling is as irreversible as trashing
                -- no shop sells it back -- so the click only records the row
                and the confirmation issues the line.
            ]]
            if (vendorReady() and state.gilCap > 0 and priceOf(row.itemid) > 0) then
                imgui.SameLine();

                if (imgui.SmallButton(labels.vendor)) then
                    state.vendorAsk = {
                        rowid  = row.rowid,
                        itemid = row.itemid,
                        qty    = row.qty,
                        flags  = row.flags,
                        augs   = row.augs,
                    };
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Sell the whole row to a shop for %s gil,\n'
                        .. 'straight from the warehouse -- no bag slot needed.\n'
                        .. 'Asks first -- no shop sells it back.', gilText(rowValue(row))));
                end
            end
        end

        imgui.EndTable();
    end

    --[[
        The trash confirmation. OPENED EVERY FRAME THE QUESTION IS PENDING:
        ImGui closes a popup on any outside click, and silently dropping the
        question would leave the player unsure whether the item is gone. While
        `trashAsk` is set the popup re-opens, so the only ways out are the two
        buttons -- which is exactly the modality a destructive action wants.
        Opened HERE, outside the table, because BeginTable pushes an ID scope
        and a popup opened inside it could not be begun outside it.
    ]]
    --[[
        AND THE ROW IS RE-READ FROM THE MODEL WHILE THE QUESTION STANDS
        (1.13.0), the sell strip's rule applied to the question that cannot be
        taken back. A delta from another window on the account can trash, take
        or list the row between the click and the confirmation, and the popup
        went on naming an item that was no longer there and would have sent
        its row id for the server to refuse. It closes instead, and says why
        -- the alternative is a red refusal a player reads as "the Trash
        button is broken".
    ]]
    if (state.trashAsk ~= nil and state.rows[state.trashAsk.rowid] == nil) then
        state.trashAsk  = nil;
        setStatus('That row is gone -- something else moved it. Nothing was thrown away.', true);
    end

    if (state.trashAsk ~= nil) then
        imgui.OpenPopup('##dww_confirm_trash');
    end

    if (imgui.BeginPopup('##dww_confirm_trash')) then
        local ask = state.trashAsk;

        if (ask == nil) then
            imgui.CloseCurrentPopup();
        else
            drawIcon(ask.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(string.format('Throw away %s x%d?', itemName(ask.itemid), ask.qty));
            -- The card inside the trash confirmation is the last look at
            -- what is about to be deleted -- exactly where it earns itself,
            -- values included when the shelf row carried them.
            cardOnHover(ask.itemid, hovered,
                bit.band(ask.flags or 0, WH_AUGMENTED) ~= 0 and (ask.augs or true) or nil);

            -- The tags are the last chance to notice this is the irreplaceable
            -- copy. Red, because 'rare' next to a delete button is a warning,
            -- not a fact.
            if (bit.band(ask.flags, WH_RARE + WH_EX + WH_AUGMENTED) ~= 0) then
                local tags = T{ };

                if (bit.band(ask.flags, WH_RARE) ~= 0) then tags:append('rare'); end
                if (bit.band(ask.flags, WH_EX) ~= 0) then tags:append('ex'); end
                if (bit.band(ask.flags, WH_AUGMENTED) ~= 0) then tags:append('augmented'); end

                imgui.TextColored(theme.colors.err,
                    string.format('This item is %s. It may be hard or impossible to replace.',
                        table.concat(tags, ', ')));
            end

            imgui.TextDisabled('It is destroyed for good. Nothing can bring it back.');

            if (imgui.Button('Throw away##dww_trash_yes')) then
                issue(string.format('!dww trash %d %d', ask.rowid, ask.qty));

                state.trashAsk = nil;
                imgui.CloseCurrentPopup();
            end

            imgui.SameLine();

            if (imgui.Button('Cancel##dww_trash_no')) then
                state.trashAsk = nil;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end

    --[[
        THE SINGLE VENDOR CONFIRMATION (1.15.0).

        Modelled on the Trash question above and for the same reason: no shop
        sells an item back, so a misclick on a row of Beitetsu is exactly as
        final as a misclick on Trash. The one thing it says that Trash cannot
        is the number the player is trading it for, which is also the number
        that makes the decision.

        THE ROW IS RE-READ WHILE THE QUESTION STANDS, the Trash popup's own
        1.13.0 rule: a delta from another window on the account can take, trash
        or list the row between the click and the confirmation, and a question
        about a row that is gone must close rather than send a row id for the
        server to refuse.
    ]]
    if (state.vendorAsk ~= nil and state.rows[state.vendorAsk.rowid] == nil) then
        state.vendorAsk = nil;
        setStatus('That row is gone -- something else moved it. Nothing was sold.', true);
    end

    if (state.vendorAsk ~= nil) then
        imgui.OpenPopup('##dww_confirm_vendor');
    end

    if (imgui.BeginPopup('##dww_confirm_vendor')) then
        local ask = state.vendorAsk;

        if (ask == nil) then
            imgui.CloseCurrentPopup();
        else
            drawIcon(ask.itemid, 20);

            local hovered = imgui.IsItemHovered();
            local worth   = priceOf(ask.itemid) * ask.qty;

            imgui.Text(string.format('Sell %s x%d to a shop for %s gil?',
                itemName(ask.itemid), ask.qty, gilText(worth)));
            cardOnHover(ask.itemid, hovered,
                bit.band(ask.flags or 0, WH_AUGMENTED) ~= 0 and (ask.augs or true) or nil);

            -- The same red line the Trash question carries, and it earns
            -- itself here twice over: a shop pays the same handful of gil for
            -- an artifact piece as it does for a Bronze Sword.
            if (bit.band(ask.flags or 0, WH_RARE + WH_EX + WH_AUGMENTED) ~= 0) then
                local tags = T{ };

                if (bit.band(ask.flags, WH_RARE) ~= 0) then tags:append('rare'); end
                if (bit.band(ask.flags, WH_EX) ~= 0) then tags:append('ex'); end
                if (bit.band(ask.flags, WH_AUGMENTED) ~= 0) then tags:append('augmented'); end

                imgui.TextColored(theme.colors.err,
                    string.format('This item is %s. It may be hard or impossible to replace, and a shop pays the same for it either way.',
                        table.concat(tags, ', ')));
            end

            imgui.TextDisabled('No shop sells it back. The market (Sell) usually pays more.');

            if (imgui.Button('Sell to shop##dww_vendor_yes')) then
                issue(string.format('!dww vendor %d %d', ask.rowid, ask.qty));

                state.vendorAsk = nil;
                imgui.CloseCurrentPopup();
            end

            imgui.SameLine();

            if (imgui.Button('Cancel##dww_vendor_no')) then
                state.vendorAsk = nil;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end

    --[[
        THE BATCH CONFIRMATION (1.15.0), one question for the whole set.

        The owner's instruction, and it is the right shape: a popup per row
        would be the "1 by 1" this feature exists to end wearing a different
        hat. So it asks ONCE, with the count and the total value in the
        sentence, and only its yes button issues anything.

        IT RE-READS THE SELECTION EVERY FRAME rather than snapshotting it at
        the click, which is the single question's rule applied to a set: a
        delta arriving while the question is on screen prunes the rows that
        went away (selectedRows does the pruning), so the count the player
        agrees to is the count that is actually sent. An emptied selection
        closes the question rather than sending a line about nothing.
    ]]
    if (state.batchAsk ~= nil) then
        local live = selectedRows();
        local kind = state.batchAsk.kind;
        local set  = (kind == 'vendor') and live.sellRows or live.rows;

        if (#set == 0) then
            state.batchAsk = nil;
            setStatus('Nothing is ticked any more -- something else moved those rows. Nothing was done.', true);
        end
    end

    if (state.batchAsk ~= nil) then
        imgui.OpenPopup('##dww_confirm_batch');
    end

    if (imgui.BeginPopup('##dww_confirm_batch')) then
        local ask = state.batchAsk;

        if (ask == nil) then
            imgui.CloseCurrentPopup();
        else
            local live    = selectedRows();
            local selling = (ask.kind == 'vendor');
            local set     = selling and live.sellRows or live.rows;
            local units   = selling and live.sellUnits or live.units;
            local worth   = selling and live.sellValue or live.value;

            if (selling) then
                imgui.Text(string.format('Sell %d row(s) -- %d item(s) -- to a shop for about %s gil?',
                    #set, units, gilText(worth)));
            elseif (worth > 0) then
                imgui.Text(string.format('Throw away %d row(s) -- %d item(s), worth about %s gil at a shop?',
                    #set, units, gilText(worth)));
            else
                imgui.Text(string.format('Throw away %d row(s) -- %d item(s)?', #set, units));
            end

            -- What is ticked but will NOT be sold, said before the press and
            -- not after it. A player who ticked forty rows and sees "Vendor
            -- Selected (31)" is owed the other nine in a sentence.
            if (selling and #live.rows > #set) then
                imgui.TextDisabled(string.format('%d ticked row(s) are not bought by any shop and stay where they are.',
                    #live.rows - #set));
            end

            -- The red line, from the OR of every ticked row's flags. One
            -- sentence for the set, because naming a dozen items would be a
            -- wall of text in the one place a player has to read carefully.
            if (bit.band(live.flags, WH_RARE + WH_EX + WH_AUGMENTED) ~= 0) then
                local tags = T{ };

                if (bit.band(live.flags, WH_RARE) ~= 0) then tags:append('rare'); end
                if (bit.band(live.flags, WH_EX) ~= 0) then tags:append('ex'); end
                if (bit.band(live.flags, WH_AUGMENTED) ~= 0) then tags:append('augmented'); end

                imgui.TextColored(theme.colors.err,
                    string.format('Some of these are %s. They may be hard or impossible to replace.',
                        table.concat(tags, ', ')));
            end

            if (selling) then
                imgui.TextDisabled('No shop sells them back. The market (Sell) usually pays more.');
            else
                imgui.TextDisabled('They are destroyed for good. Nothing can bring them back.');
            end

            -- HOW MANY COMMANDS IT IS, out loud. The queue drains at one line
            -- per 1.2 seconds, so a three hundred row selection is a minute of
            -- a window answering slowly -- which reads as a hang unless the
            -- question said so first.
            local commands = batchCommands(selling and 'vendormany' or 'trashmany', set);

            if (#commands > 1) then
                imgui.TextDisabled(string.format('This is %d commands, about %d seconds.',
                    #commands, math.ceil(#commands * SEND_INTERVAL)));
            end

            if (imgui.Button(selling and 'Sell them##dww_batch_yes' or 'Throw them away##dww_batch_yes')) then
                for _, command in ipairs(commands) do
                    issue(command);
                end

                -- THE TICKS GO WITH THE PRESS, not with the answer. The rows
                -- are on their way out and a selection that survived would
                -- have the player pressing the same button again on rows the
                -- server is already deleting.
                state.picked   = {};
                state.batchAsk = nil;

                pickChanged();
                setStatus(string.format('Sent %d command(s) for %d row(s). The shelf updates as they answer.',
                    #commands, #set), false);

                imgui.CloseCurrentPopup();
            end

            imgui.SameLine();

            if (imgui.Button('Cancel##dww_batch_no')) then
                state.batchAsk = nil;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end
end

local function depositTab()
    local rows = inventoryRows();

    -- The header strip's Find box filters HERE too (2026-08-26, player
    -- request) -- the box always belonged to both tabs (see headerStrip),
    -- it just never reached this one. Filtered at the DRAW loop and never
    -- inside inventoryRows(): "Save whole bag" and Stash All read the real
    -- bag, and a filter that quietly shrank a kit or a stash-all would be
    -- moving items the player never asked about. The count line says when
    -- the list is narrowed, exactly as the Warehouse tab's does.
    local shown = rows;

    if (state.search[1] ~= '') then
        shown = T{ };

        for _, row in ipairs(rows) do
            if (matchesSearch(row.itemid)) then
                shown:append(row);
            end
        end
    end

    if (imgui.Button('Stash All##dww_stashall')) then
        imgui.OpenPopup('##dww_confirm_stashall');
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.stashAll);
    end

    imgui.SameLine();

    --[[
        THE LINE BESIDE THE BUTTON CARRIES A FACT THE BUTTON CANNOT (1.13.0),
        which is the change 1.13.0 made beside Stack Items one tab over, for
        the same two reasons.

        It read 'Everything the server will take, in one command.' -- the
        first sentence of its own tooltip, said twice, and forty-six
        characters of a row that also has to hold Stash ticked, Clear ticks
        and Tick shown. Adding those up at the default font puts the last of
        them past the right edge of an 800-wide window, and ImGui clips a
        SameLine rather than wrapping it.

        Room on the shelf is the number that decides whether this button will
        finish: Stash All stops at capacity and says how many it took, and
        this is the only place on this tab that number appears at all.
    ]]
    imgui.TextDisabled(string.format('Room for %d more on the shelf.',
        math.max(state.cap - state.used, 0)));

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.room);
    end

    -- The confirmation is a popup rather than a second click on the same
    -- button, because the list this empties is the one a player is holding and
    -- the copy below is the only place the exceptions are written down.
    if (imgui.BeginPopup('##dww_confirm_stashall')) then
        imgui.Text('Stash everything in your inventory?');
        imgui.TextDisabled('Skipped, and left in your bag:');
        imgui.TextDisabled('  equipped, bazaared or reserved items');
        imgui.TextDisabled('  rare, EX and augmented copies');
        imgui.TextDisabled('  linkshells you are wearing, gil and currency');
        imgui.TextDisabled('  anything you have pinned on this tab');
        imgui.TextDisabled('It stops at capacity and says how many it took.');

        if (imgui.Button('Stash All##dww_confirm_yes')) then
            issue('!dww stashall');
            imgui.CloseCurrentPopup();
        end

        imgui.SameLine();

        if (imgui.Button('Cancel##dww_confirm_no')) then
            imgui.CloseCurrentPopup();
        end

        imgui.EndPopup();
    end

    --[[
        Stash ticked (1.9.0): every ticked item, every slot that holds it,
        one `!dww put` per slot -- the tick that used to exist only to save a
        kit now moves things too. Whole slots always, whatever the Whole
        stack box says: a tick is "this item", not "some of this item", and
        a partial move of five slots would be five refusals to read. Each
        line is its own command with its own answer, so one refused slot
        (a rare copy, a full shelf) never undoes the others. Reads the REAL
        bag, never the filtered view -- the Stash All rule.
    ]]
    local ticked = 0;

    for _, row in ipairs(rows) do
        if (selection[row.itemid] == true) then
            ticked = ticked + 1;
        end
    end

    if (ticked > 0) then
        imgui.SameLine();

        -- Counted in SLOTS, because that is how many commands the press
        -- sends: two slots of the same ticked arrow are two puts.
        if (imgui.Button(string.format('Stash ticked (%d slot%s)##dww_stash_ticked',
                ticked, ticked == 1 and '' or 's'))) then
            for _, row in ipairs(rows) do
                if (selection[row.itemid] == true) then
                    issue(string.format('!dww put %d %d %d', row.slot, row.itemid,
                        math.max(math.floor(tonumber(row.qty) or 1), 1)));
                end
            end

            selection = {};
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Put every ticked item into the warehouse, whole slots,\n'
                .. 'one command per slot -- a refused slot never stops the rest.');
        end

        imgui.SameLine();

        if (imgui.SmallButton('Clear ticks##dww_clear_ticks')) then
            selection = {};
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.clearTicks);
        end
    end

    --[[
        Tick shown (1.13.0), and ONLY while the Find box is narrowing the
        list. With a search typed, "tick these, then Stash ticked" is the
        thing the tab could not do: stash everything matching a word without
        also stashing the rest of the bag. Drawn only when filtered because
        with no filter it is Stash All with eighty commands instead of one --
        eighty times 1.2 seconds of queue for a worse answer -- and because
        the filter is also what bounds how many commands one press can ask
        for. It only TICKS: the deliberate act is still the Stash ticked
        press beside it, which is what says how many slots are going.
    ]]
    if (state.search[1] ~= '' and #shown > 0) then
        imgui.SameLine();

        if (imgui.SmallButton(string.format('Tick shown (%d)##dww_tick_shown', #shown))) then
            for _, row in ipairs(shown) do
                selection[row.itemid] = true;
            end
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tickShown);
        end
    end

    if (#shown < #rows) then
        imgui.TextDisabled(string.format('Showing %d of %d bag items (filtered).', #shown, #rows));
    end

    --[[
        THE PINS THAT ARE NOT IN THE BAG (1.13.0).

        A pin is per character and keyed by item id, and the only control for
        one was on the bag row that holds the item -- so pinning something and
        then stashing it (or spending it, or trading it away) left the pin set
        with no way in this window to take it off again. It kept working:
        Stash All went on skipping an item the player no longer had and had
        forgotten about. `!warehouse unpin <id>` was the whole recovery, and
        it needs an id nothing on screen shows.

        The list comes off the `p|` record the server already sends, so this
        costs no wire and no verb -- only the rows the bag cannot draw.
    ]]
    if (next(state.pins) ~= nil) then
        -- The bag's item ids as a set first, so this is eighty steps plus one
        -- per pin rather than eighty per pin.
        local held = { };

        for _, row in ipairs(rows) do
            held[row.itemid] = true;
        end

        local orphanPins = T{ };

        for itemid in pairs(state.pins) do
            if (not held[itemid]) then
                orphanPins:append(itemid);
            end
        end

        if (#orphanPins > 0) then
            -- Sorted so the strip does not reshuffle itself every frame:
            -- `pairs` over a hash has no order, and a row of buttons that
            -- swaps places under the cursor is unclickable.
            table.sort(orphanPins);

            imgui.TextDisabled('Pinned, not in your bag:');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.pinned);
            end

            --[[
                Bounded: this is a strip of buttons, and a player with forty
                stale pins would push the table off the window.

                AND IT BREAKS ITS LINE EVERY THIRD BUTTON (1.13.0). Every one
                of them is `unpin <item name>` -- eighteen characters for
                'unpin Fire Crystal' and thirty for a long one -- so six of
                them SameLine'd behind a label ran to about nine hundred
                pixels. That was already past the 840 the window opens at, and
                well past the width it can now be dragged to; ImGui does not
                wrap a SameLine, it clips it, so the last pins on the strip
                were unclickable exactly when there were most of them. Three a
                line fits the narrowest window this one allows even for long
                names, and two short lines cost less than one unreachable one.
            ]]
            for position = 1, math.min(#orphanPins, 6) do
                local itemid = orphanPins[position];

                -- The first of each three starts its own line; the label
                -- above owns the line before it, so position 1 does too.
                if (position % 3 ~= 1) then
                    imgui.SameLine();
                end

                if (imgui.SmallButton(unpinLabel(itemid))) then
                    issue(string.format('!dww unpin %d', itemid));
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Unpin %s. Stash All may take it again.\n'
                        .. 'It is pinned on this character and is not in your bag right now.',
                        itemName(itemid)));
                end
            end

            if (#orphanPins > 6) then
                -- Its own line, for the same reason the buttons take theirs.
                imgui.TextDisabled(string.format('and %d more -- `!warehouse who` lists them.',
                    #orphanPins - 6));
            end
        end
    end

    local stored = storedCounts();

    if (imgui.BeginTable('##dww_deposit', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 26, 0);
        -- Stretched for the Warehouse table's reason (1.13.0): the six fixed
        -- widths came to 571 of an 840-wide window and the name was the one
        -- being clipped.
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 45, 0);
        -- How many the shelf already holds (1.9.0): the answer to "do I
        -- already have some of these stashed", read off the model rather
        -- than off a second search box.
        imgui.TableSetupColumn('Stored', ImGuiTableColumnFlags_WidthFixed, 70, 0);
        imgui.TableSetupColumn('Pin', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(shown) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            -- The tick is what "save selection as kit" reads. Keyed by SLOT in
            -- the widget id and by ITEM ID in the set: two slots holding the
            -- same item are one line in a kit, and a kit names items.
            local ids    = idsForSlot(row.slot);
            local ticked = ids.tickBuf;

            ticked[1] = (selection[row.itemid] == true);

            if (imgui.Checkbox(ids.tick, ticked)) then
                selection[row.itemid] = ticked[1] and true or nil;
            end

            -- What a tick is FOR, which is neither of the two things the
            -- column header could say: it feeds two buttons on two different
            -- tabs, and it names the item rather than the slot (1.13.0).
            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.depositTick);
            end

            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(itemName(row.itemid));

            --[[
                A deposit row is the client's own item: the card gets the
                decoded augment slots, values included.

                DECODED ONLY WHEN THE CARD IS ACTUALLY DRAWN (1.13.0). This
                read `cardOnHover(id, hovered, extraAugments(row.extra))`, and
                Lua evaluates an argument whether or not the function uses it
                -- so every augmented row in the bag re-decoded its exdata
                bytes and allocated a T{} plus a table per augment slot EVERY
                FRAME, for a card nobody was looking at. A gear mule's eighty
                augmented pieces is four hundred throwaway tables a frame.
                The hover test is the same one cardOnHover makes; only the
                work behind it moved inside.
            ]]
            if (imgui.IsItemHovered() or hovered) then
                itemCard(row.itemid, extraAugments(row.extra));
            end

            imgui.TableNextColumn();
            imgui.Text(slotQtyText(ids, row.qty));

            imgui.TableNextColumn();

            local held = stored[row.itemid] or 0;

            if (held > 0) then
                imgui.TextDisabled(slotStoredText(ids, held));

                -- 'Stored' is the shelf, not the bag, and the number is a
                -- TOTAL across however many rows hold it -- which is exactly
                -- the thing a player about to stash a second copy wants
                -- spelled out (1.13.0).
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format(
                        'The warehouse already holds %d of these, across every row.\n'
                        .. 'Counted off the list the shelf last sent, not off your bag.', held));
                end
            else
                imgui.Text('');
            end

            imgui.TableNextColumn();

            local pinned = state.pins[row.itemid] == true;

            if (imgui.SmallButton(pinned and ids.unpin or ids.pin)) then
                issue(string.format('!dww %s %d', pinned and 'unpin' or 'pin', row.itemid));
            end

            if (imgui.IsItemHovered()) then
                -- Which way this press goes, said out loud: the label is one
                -- word and the two words look alike at a glance (1.13.0).
                imgui.SetTooltip((pinned and 'Unpin it: Stash All may take it again.\n'
                        or 'Pin it: Stash All will leave it in your bag.\n')
                    .. 'Pins are per character -- a mule and a main stash differently.');
            end

            imgui.TableNextColumn();

            local count = moveCount(row.qty);

            if (imgui.SmallButton(ids.stash)) then
                issue(string.format('!dww put %d %d %d', row.slot, row.itemid, count));
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Put %d into the warehouse.', count));
            end
        end

        imgui.EndTable();
    end
end

--[[
* The Kits tab's rendered view, REBUILT ONLY WHEN SOMETHING CHANGED (1.13.0).
*
* The tab did all of this every frame, for every kit: sorted the name list,
* re-parsed each kit's packed string into a fresh table of tables, formatted
* six item names into a summary line, summed the wanted totals, walked them
* against the stored counts and sorted the shortfall. Ten kits of twenty
* items is a few hundred tables and a dozen sorts a frame, sixty times a
* second, for a list that changes when a kit is saved or the shelf moves --
* which is the 1.10.0 frame-rate pass's own rule (`visibleRows`, `storedCounts`,
* `crystalView`), applied to the one tab it did not reach.
*
* Keyed on both revisions because the row has two halves: the name, entries
* and contents line come from the kits table (`kitsRev`), and the shortfall
* comes from the model (`modelRev`). `synced` rides the key too -- the
* shortfall is deliberately not drawn while the model is still a partial
* sweep, and that is a third thing the row can change with.
--]]
local kitCache = { key = nil, rows = T{ } };

local function kitRows()
    local key = string.format('%d|%d|%s', kitsRev, state.modelRev,
        tostring(state.synced and not state.syncing));

    if (kitCache.key == key) then
        return kitCache.rows;
    end

    local stored = storedCounts();
    local ready  = state.synced and not state.syncing;
    local rows   = T{ };

    for _, name in ipairs(kitNames()) do
        local entries = parseKit(config.kits[name]);
        local shown   = T{ };

        for position = 1, math.min(#entries, 6) do
            shown:append(string.format('%s x%d', itemName(entries[position].id), entries[position].qty));
        end

        if (#entries > 6) then
            shown:append(string.format('and %d more', #entries - 6));
        end

        --[[
            The shortfall preview (1.9.0): what the shelf is short of for
            this kit, counted off the model BEFORE anything is sent, so a kit
            that cannot be filled says so on the row instead of after a pull.
            The server's own shortfall sentence still arrives on a real pull
            -- the model can be a moment behind -- this is the earlier,
            cheaper warning. Totals are summed per item first: a kit that
            asks for 24 arrows as two lines of 12 is short by the pair, not
            by each line.
        ]]
        local wanted = { };

        for _, entry in ipairs(entries) do
            wanted[entry.id] = (wanted[entry.id] or 0) + entry.qty;
        end

        local short = T{ };

        for id, qty in pairs(wanted) do
            local held = stored[id] or 0;

            if (held < qty) then
                short:append({ id = id, missing = qty - held });
            end
        end

        local shortText = nil;
        local shortFull = nil;
        local shortHead = nil;

        if (#short > 0 and ready) then
            table.sort(short, function (a, b) return a.id < b.id; end);

            local words = T{ };
            local all   = T{ };

            for position = 1, #short do
                local phrase = string.format('%s x%d', itemName(short[position].id), short[position].missing);

                all:append(phrase);

                if (position <= 4) then
                    words:append(phrase);
                end
            end

            if (#short > 4) then
                words:append(string.format('and %d more', #short - 4));
            end

            shortText = 'short: ' .. table.concat(words, ', ');
            shortFull = table.concat(all, '\n');

            -- The hover's own heading, built here rather than at hover time,
            -- and NAMING THE KIT: the row is one of several and the pointer
            -- is on a red line four items long, not on the kit's name column
            -- (1.13.0).
            shortHead = string.format('%s -- everything the shelf is short of:', name);
        end

        -- The FULL contents, for the row's hover card: the summary line is
        -- capped at six names and clipped by its column on top of that, so
        -- without this a long kit could not be read at all from this tab.
        local full = T{ };

        for _, entry in ipairs(entries) do
            full:append(string.format('%s x%d', itemName(entry.id), entry.qty));
        end

        rows:append({
            name      = name,
            entries   = entries,
            contents  = table.concat(shown, ', '),
            full      = table.concat(full, '\n'),
            count     = #entries,
            shortText = shortText,
            shortFull = shortFull,
            shortHead = shortHead,

            -- The row's two widget ids, built with the row rather than
            -- formatted every frame (1.13.0) -- rowLabels' rule, for the one
            -- table that was still doing it per frame per kit. They carry the
            -- kit's INDEX for the reason the draw loop states: a name is
            -- player text and a '##' inside one would split the id ImGui
            -- parses. The index is the position in THIS list, which is what
            -- the cache is keyed on, so the two can never disagree.
            -- How many `!dww pull` lines this kit becomes, and so how long
            -- the press takes: the queue drains one line every 1.2 seconds
            -- and a twenty-item kit is several lines (1.13.0). The tooltip
            -- said "long kits become several commands" and left the player
            -- to guess which kind theirs was; the split is already computed
            -- here for the click, so saying it costs nothing.
            lines     = #pullCommands(entries),

            idPull    = string.format('Pull##dww_pull_%d', #rows + 1),
            idDelete  = string.format('Delete##dww_del_%d', #rows + 1),
            idArmed   = string.format('Really delete?##dww_del_%d', #rows + 1),
        });
    end

    kitCache.key  = key;
    kitCache.rows = rows;

    return rows;
end

local function kitsTab()
    imgui.TextDisabled('A kit is a name for a list of items. Pulling one sends ordinary pull');
    imgui.TextDisabled('commands -- the server never hears the name, and nothing is stored there.');
    imgui.TextDisabled('Kits are kept per character, on this machine only.');

    imgui.PushItemWidth(200);
    imgui.InputText('##dww_kitname', state.kitName, KIT_NAME_MAX + 1);
    imgui.PopItemWidth();

    -- The box is unlabelled -- it sits between a paragraph and two Save
    -- buttons -- and both facts a player needs are invisible: what characters
    -- survive it, and that a name already in the list REPLACES that kit.
    -- TIPS.kitName was written for this hover in the first 1.13.0 pass and
    -- never wired to it; the harness now refuses a TIPS entry nothing reads.
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.kitName);
    end

    imgui.SameLine();

    if (imgui.Button('Save selection##dww_kit_sel')) then
        if (saveKit(state.kitName[1], kitEntriesFromBag(selection))) then
            state.kitName[1] = '';
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.kitSaveSelection);
    end

    imgui.SameLine();

    if (imgui.Button('Save whole bag##dww_kit_bag')) then
        if (saveKit(state.kitName[1], kitEntriesFromBag(nil))) then
            state.kitName[1] = '';
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.kitSaveBag);
    end

    imgui.Separator();

    local rows = kitRows();

    if (#rows == 0) then
        imgui.Text('No kits yet. Name one above and save it.');

        return;
    end

    if (imgui.BeginTable('##dww_kits', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        -- The name column is fixed at a kit name's own ceiling; the contents
        -- STRETCH, because a kit's summary line is the widest thing on this
        -- tab and a fixed 380 clipped it at about four names on a six-name
        -- line (1.13.0). The buttons keep their fixed width so the pair never
        -- moves as the list changes.
        imgui.TableSetupColumn('Kit', ImGuiTableColumnFlags_WidthFixed, 180, 0);
        imgui.TableSetupColumn('Contents', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 150, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, kit in ipairs(rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(kit.name);

            imgui.TableNextColumn();

            imgui.TextDisabled(kit.contents);

            -- The summary line is capped at six names AND clipped by the
            -- column, so the hover is where a long kit is actually readable
            -- (1.13.0). The shortfall repeats in full for the same reason:
            -- the row says four of them and 'and N more'.
            if (imgui.IsItemHovered()) then
                imgui.BeginTooltip();
                imgui.Text(string.format('%s -- %d item(s)', kit.name, kit.count));
                imgui.Separator();
                imgui.TextDisabled(kit.full);

                if (kit.shortFull ~= nil) then
                    imgui.Separator();
                    imgui.TextColored(theme.colors.warn, 'The shelf is short of:');
                    imgui.TextDisabled(kit.shortFull);
                end

                imgui.EndTooltip();
            end

            if (kit.shortText ~= nil) then
                imgui.TextColored(theme.colors.warn, kit.shortText);

                -- The line names four of them and then 'and N more'; the
                -- whole list is one line above on the contents card, which is
                -- not where a player reading THIS line is pointing (1.13.0).
                if (imgui.IsItemHovered()) then
                    imgui.BeginTooltip();
                    imgui.TextColored(theme.colors.warn, kit.shortHead);
                    imgui.TextDisabled(kit.shortFull);
                    imgui.EndTooltip();
                end
            end

            imgui.TableNextColumn();

            -- Widget ids carry the kit's INDEX, not its name: a name is player
            -- text and '##' inside one would split the id ImGui parses. Both
            -- were built with the row (1.13.0).
            if (imgui.SmallButton(kit.idPull)) then
                for _, command in ipairs(pullCommands(kit.entries)) do
                    issue(command);
                end
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('%s\n%s', TIPS.kitPull,
                    kit.lines <= 1
                        and 'This kit is one command.'
                        or string.format('This kit is %d commands, one every %.1f seconds.',
                            kit.lines, SEND_INTERVAL)));
            end

            imgui.SameLine();

            -- Two clicks, the second inside the hold. Armed by NAME rather
            -- than by row index: the list is re-sorted by every save, and an
            -- armed "Really delete?" that stayed with row 3 while a new kit
            -- moved a different one into row 3 would delete the wrong one --
            -- the same reason dwgmpanel keys its Jail confirmation by name.
            local armed = state.kitArmed == kit.name
                and (os.clock() - state.kitArmAt) < KIT_CONFIRM_HOLD;

            if (imgui.SmallButton(armed and kit.idArmed or kit.idDelete)) then
                if (armed) then
                    config.kits[kit.name] = nil;
                    settings.save();

                    kitsRev = kitsRev + 1;

                    state.kitArmed = nil;

                    setStatus(string.format('Deleted kit "%s".', kit.name), false);
                else
                    state.kitArmed = kit.name;
                    state.kitArmAt = os.clock();
                end
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(armed and TIPS.kitDeleteArmed or TIPS.kitDelete);
            end
        end

        imgui.EndTable();
    end
end

--[[
* The Crystals tab's view of the model (1.12.0): per element, how many
* crystals and clusters the shelf holds and in how many rows, and what one
* Cluster press would make and free. Cached against modelRev like the view and
* the stored counts -- the frame-rate pass's rule -- because it walks every
* row.
*
* A flag-4 row is skipped on purpose: the server leaves a non-plain crystal
* row alone (a crystal cannot be signed or augmented, so such a row is one it
* will not pretend to understand), and a count that included it would promise
* a cluster the click never makes.
--]]
local crystalCache = { rev = -1, view = nil };

local function crystalView()
    if (crystalCache.rev == state.modelRev and crystalCache.view ~= nil) then
        return crystalCache.view;
    end

    local view      = {};
    local byCrystal = {};
    local byCluster = {};

    for index, element in ipairs(ELEMENTS) do
        view[index] = { crystals = 0, crystalRows = 0, clusters = 0, clusterRows = 0, made = 0, frees = 0 };

        byCrystal[element.crystal] = index;
        byCluster[element.cluster] = index;
    end

    for _, row in pairs(state.rows) do
        if (bit.band(row.flags or 0, WH_AUGMENTED) == 0) then
            local qty   = tonumber(row.qty) or 0;
            local index = byCrystal[row.itemid];

            if (index ~= nil) then
                view[index].crystals    = view[index].crystals + qty;
                view[index].crystalRows = view[index].crystalRows + 1;
            else
                index = byCluster[row.itemid];

                if (index ~= nil) then
                    view[index].clusters    = view[index].clusters + qty;
                    view[index].clusterRows = view[index].clusterRows + 1;
                end
            end
        end
    end

    -- The Cluster preview. Rows after a press: the remainder's row, if any,
    -- plus the fewest cluster rows the total needs. The server fills partial
    -- cluster rows first and never touches full ones, so this is the floor
    -- of what it frees -- and its click is bounded, so a huge shelf may take
    -- two presses. "Would", never "did".
    local made  = 0;
    local frees = 0;

    for index, entry in ipairs(view) do
        entry.made = math.floor(entry.crystals / CLUSTER_UNITS);

        if (entry.made > 0) then
            --[[
                HOW MANY CLUSTERS FIT A ROW COMES FROM THE CLIENT'S OWN DAT
                (1.13.0), not from CLUSTER_UNITS.

                Twelve is how many crystals ARE a cluster; how many clusters
                fit in one warehouse row is a separate fact that happens to be
                twelve too, and dividing a cluster COUNT by the exchange ratio
                made this line read as arithmetic when it is really a lookup.
                The Retrieve preview one screen down was corrected for exactly
                this in 1.13.0 and this half was missed. One warehouse row
                holds one stack (charutils::AddItem never merges across rows),
                so the stack size is the divisor.
            ]]
            local perCluster  = math.max(stackSizeOf(ELEMENTS[index].cluster), 1);
            local remainder   = entry.crystals % CLUSTER_UNITS;
            local clusterRows = math.ceil((entry.clusters + entry.made) / perCluster);
            local rowsAfter   = clusterRows + (remainder > 0 and 1 or 0);

            entry.frees = math.max(0, entry.crystalRows + entry.clusterRows - rowsAfter);
        end

        made  = made + entry.made;
        frees = frees + entry.frees;

        --[[
            The row's four strings, built with the view rather than every
            frame (1.13.0). Eight rows drew 'x26', '(3 slots)', 'x11' and
            '(1 slot, 132 crystals)' through `string.format` sixty times a
            second for numbers that only move when the model does -- which is
            exactly what this cache is keyed on. rowLabels' rule, one tab
            over, and the last per-row formatting left in the window.
        ]]
        entry.crystalText  = string.format('x%d', entry.crystals);
        entry.crystalSlots = string.format('(%d slot%s)', entry.crystalRows,
            entry.crystalRows == 1 and '' or 's');
        entry.clusterText  = string.format('x%d', entry.clusters);
        entry.clusterSlots = string.format('(%d slot%s, %d crystals)', entry.clusterRows,
            entry.clusterRows == 1 and '' or 's', entry.clusters * CLUSTER_UNITS);
    end

    view.made  = made;
    view.frees = frees;

    -- How many shelf ROWS the eight elements are sitting in, for the tab's
    -- own label (1.13.0). It is the number this whole tab exists to shrink,
    -- and the three sibling tabs already carry theirs.
    local rows = 0;

    for _, entry in ipairs(view) do
        rows = rows + entry.crystalRows + entry.clusterRows;
    end

    view.rows = rows;

    crystalCache.rev  = state.modelRev;
    crystalCache.view = view;

    return view;
end

--[[
* The Crystals tab (1.12.0, owner request 2026-09-05).
*
* A crafter's shelf silts up with crystals -- hundreds of rows of Earth
* Crystal x12 -- and the two buttons here are the two ways out that create
* nothing. Cluster asks the server to turn every twelve of an element into a
* cluster and stack the clusters: the exchange an Ephemeral Moogle makes when
* you deposit crystals and draw clusters, so nothing is minted. Store Crystals
* moves the shelf's crystals and clusters into THE MOOGLES' OWN LEDGER -- the
* per-character tally every Ephemeral Moogle reads and writes -- so a moogle
* can hand them back, and so can Retrieve here, as clusters plus a remainder
* of loose crystals, the moogle's own way.
*
* THE LEDGER IS THIS CHARACTER'S; THE SHELF IS THE ACCOUNT'S. The tab says so
* in words, because what Store writes belongs to whoever is logged in, exactly
* as a trade to a moogle does, while the rows it emptied belonged to everyone
* on the account.
*
* The shelf counts come off the model and show whatever the server is. The
* buttons and the Retrieve boxes draw only once a `who` has carried the `c|`
* ledger (the Sell button's rule): a server without the verbs advertises
* nothing and earns no refusal. Every command here is a plain click -- nothing
* is destroyed, so unlike Trash there is no popup.
--]]
local function crystalsTab()
    local view   = crystalView();
    local ledger = state.crystals;
    local live   = ledger ~= nil and not state.noCrystals;

    -- WRAPPED rather than hand-broken at a width nobody measured (1.13.0):
    -- the second of these two lines is 104 characters and ran past the right
    -- edge of any window narrower than the default, which is now a size a
    -- player can actually drag to.
    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled('Crystals on the shelf belong to the account. The ledger is this character\'s -- '
        .. 'the same tally every Ephemeral Moogle keeps, so any moogle hands back what Store '
        .. 'puts in, and so does Retrieve.');
    imgui.PopTextWrapPos();

    if (live) then
        if (imgui.Button('Cluster##dww_cluster')) then
            issue('!dww cluster');
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('Turn every 12 crystals of one element on the shelf into a cluster and stack\n'
                .. 'the clusters. Nothing is lost -- a cluster is 12 crystals. Right now this would\n'
                .. 'make %d cluster(s) and free about %d slot(s). A very full shelf may take two presses.',
                view.made, view.frees));
        end

        imgui.SameLine();

        if (imgui.Button('Store Crystals##dww_cstore')) then
            issue('!dww storecrystals all');
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('Move every crystal and cluster on the shelf into this character\'s ledger,\n'
                .. 'up to %d of each element. It is the Ephemeral Moogles\' own tally, so any moogle\n'
                .. 'can hand them back -- and so can Retrieve below. Frees their shelf slots entirely.',
                ledger.cap));
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('Cluster would make %d cluster(s), freeing about %d slot(s).', view.made, view.frees));
    elseif (state.noCrystals) then
        imgui.TextColored(theme.colors.warn, 'This server has no crystal verbs. The shelf counts below still show.');
    elseif (state.synced and not state.syncing) then
        imgui.TextDisabled('This server does not carry the crystal ledger yet. The shelf counts below still show.');
    else
        imgui.TextDisabled('Reading the ledger...');
    end

    --[[
        THE TABLE SCROLLS AND TAKES THE REST OF THE WINDOW (1.13.0), like the
        other three.

        It was sized `{ -1, 0 }` -- content height -- with no ScrollY, which
        is fine in a window that is always tall enough and is not one any
        more: the window carries NoScrollbar and manages its own scroll
        regions, so at the minimum height this addon now allows (and at any
        height a player drags to) the last elements of an eight-row table
        simply fell off the bottom with nothing to scroll. Dark and Light are
        the two at the end, and the Retrieve boxes are on those rows.
    ]]
    if (imgui.BeginTable('##dww_crystals', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        --[[
            RETUNED, AND THE ACTION COLUMN STRETCHES (1.13.0). The five fixed
            widths came to 820 in an 840-wide window: with the table's own
            padding and borders that overflowed, and the column ImGui squeezed
            was the last one -- the Store button, the quantity box, Retrieve
            and `all`, four controls on one line, clipped. The two count
            columns were also sized for numbers they never hold ('x1234 (12
            slots)' needs about 140, not 160). What is left over now goes to
            the buttons, at any window width.
        ]]
        -- Element 110 -> 100 and the crystal count 140 -> 130 (1.13.0): both
        -- were sized above anything they hold (an icon and 'Lightning' is
        -- about 90; 'x26 (3 slots)' is about 95, and the column's own header
        -- is the wider of the two at about 120), and the twenty pixels go to
        -- the action column -- four controls on one line, which is the one
        -- that runs short at the window's floor.
        imgui.TableSetupColumn('Element', ImGuiTableColumnFlags_WidthFixed, 100, 0);
        imgui.TableSetupColumn('Crystals on shelf', ImGuiTableColumnFlags_WidthFixed, 130, 0);
        imgui.TableSetupColumn('Clusters on shelf', ImGuiTableColumnFlags_WidthFixed, 190, 0);
        imgui.TableSetupColumn('Stored (ledger)', ImGuiTableColumnFlags_WidthFixed, 120, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for index, element in ipairs(ELEMENTS) do
            local entry = view[index];

            imgui.TableNextRow();
            imgui.TableNextColumn();

            drawIcon(element.crystal, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(element.name);
            cardOnHover(element.crystal, hovered, nil);

            imgui.TableNextColumn();

            if (entry.crystals > 0) then
                imgui.Text(entry.crystalText);
                imgui.SameLine();
                imgui.TextDisabled(entry.crystalSlots);

                -- The slot count is the number the tab exists to shrink, and
                -- what one Cluster press would do to THIS element is the
                -- answer the summary line above only gives for all eight
                -- (1.13.0).
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format(
                        '%d loose %s crystal(s) on the shelf, in %d slot(s).\n%s',
                        entry.crystals, element.name, entry.crystalRows,
                        entry.made > 0
                            and string.format('Cluster would make %d of them into cluster(s) and free about %d slot(s).',
                                entry.made, entry.frees)
                            or string.format('Not enough for a cluster yet -- that takes %d of one element.', CLUSTER_UNITS)));
                end
            else
                imgui.TextDisabled('none');
            end

            imgui.TableNextColumn();

            if (entry.clusters > 0) then
                imgui.Text(entry.clusterText);
                imgui.SameLine();
                imgui.TextDisabled(entry.clusterSlots);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format(
                        '%d %s cluster(s) on the shelf, in %d slot(s).\n'
                        .. 'A cluster is %d crystals, so these are worth %d -- which is what Store\n'
                        .. 'writes into the ledger and what a moogle hands back.',
                        entry.clusters, element.name, entry.clusterRows,
                        CLUSTER_UNITS, entry.clusters * CLUSTER_UNITS));
                end
            else
                imgui.TextDisabled('none');
            end

            imgui.TableNextColumn();

            local stored = ledger ~= nil and (ledger.stored[index] or 0) or nil;

            if (stored ~= nil) then
                imgui.Text(string.format('%d / %d', stored, ledger.cap));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('%s crystals this character has stored -- here or with any Ephemeral Moogle.\n'
                        .. 'Clusters count 12. Retrieve hands them back as clusters and crystals; so does a moogle.',
                        element.name));
                end

                if (stored >= ledger.cap) then
                    imgui.SameLine();
                    imgui.TextColored(theme.colors.warn, 'full');

                    -- One word, and what it stops is the whole point: the
                    -- Store button on this row is about to be missing
                    -- (1.13.0).
                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(TIPS.ledgerFull);
                    end
                end
            else
                imgui.TextDisabled('--');
            end

            imgui.TableNextColumn();

            if (live) then
                local onShelf = entry.crystals > 0 or entry.clusters > 0;

                if (onShelf and stored < ledger.cap) then
                    if (imgui.SmallButton(element.idStore)) then
                        issue(string.format('!dww storecrystals %s', element.word));
                    end

                    if (imgui.IsItemHovered()) then
                        -- And how many shelf slots it frees, which is the
                        -- number the tab exists to move and the one the
                        -- Cluster button has said since 1.12.0 (1.13.0). It
                        -- is every row this element holds: Store empties them
                        -- outright rather than repacking them.
                        imgui.SetTooltip(string.format('Store this element only: %d crystal(s) and %d cluster(s) off the shelf into\n'
                            .. 'the ledger, clusters first, up to the %d cap.\n'
                            .. 'Frees the %d shelf slot(s) they are sitting in.',
                            entry.crystals, entry.clusters, ledger.cap,
                            entry.crystalRows + entry.clusterRows));
                    end

                    imgui.SameLine();
                end

                if (stored > 0) then
                    -- Digits only, the sell strip's rule: a typo reads as a
                    -- sentence rather than as a request for zero.
                    imgui.PushItemWidth(50);
                    imgui.InputText(element.idQty, state.crystalQty[index], 6);
                    imgui.PopItemWidth();

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('How many to take back, counted in crystals: 26 arrives as 2 clusters and 2 crystals.');
                    end

                    imgui.SameLine();

                    local typed  = tostring(state.crystalQty[index][1] or '');
                    local digits = typed:match('^%d+$');
                    local qty    = digits ~= nil and tonumber(digits) or 0;

                    if (qty > 0 and qty <= stored) then
                        if (imgui.SmallButton(element.idRetrieve)) then
                            issue(string.format('!dww takecrystals %s %d', element.word, qty));

                            state.crystalQty[index][1] = '';
                        end

                        if (imgui.IsItemHovered()) then
                            local clusters = math.floor(qty / CLUSTER_UNITS);
                            local loose    = qty % CLUSTER_UNITS;

                            --[[
                                THE STACK SIZES COME FROM THE CLIENT'S OWN
                                DAT, not from CLUSTER_UNITS (1.13.0). Twelve
                                is how many crystals ARE a cluster; how many
                                clusters fit in a bag slot is a separate fact
                                that happens to be twelve too, and reusing
                                the one constant for both made this line read
                                as arithmetic when it is really two lookups.
                                The server counts free slots the same way
                                (charutils::AddItem never merges), and the DAT
                                is where the addon already gets every other
                                fact about an item.
                            ]]
                            local perCluster = math.max(stackSizeOf(element.cluster), 1);
                            local perCrystal = math.max(stackSizeOf(element.crystal), 1);

                            local slots = math.ceil(clusters / perCluster)
                                + math.ceil(loose / perCrystal);

                            imgui.SetTooltip(string.format('Take %d %s crystal(s) into your inventory as %d cluster(s) and %d crystal(s).\n'
                                .. 'Needs %d free slot(s). The whole request is refused if the room is short.',
                                qty, element.name, clusters, loose, slots));
                        end
                    elseif (typed ~= '' and digits == nil) then
                        imgui.TextColored(theme.colors.err, 'digits only');
                    elseif (typed ~= '' and qty > stored) then
                        imgui.TextColored(theme.colors.err, 'too many');
                    else
                        imgui.TextDisabled('qty');
                    end

                    imgui.SameLine();

                    if (imgui.SmallButton(element.idAll)) then
                        state.crystalQty[index][1] = tostring(stored);
                    end

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('Fill the box with everything stored of this element.');
                    end
                end
            end
        end

        imgui.EndTable();
    end
end

--[[
* A tab's label, rebuilt only when the count in it moves (1.13.0).
*
* Three of the four carry a live number, so three `string.format`s ran every
* frame for labels that change when a row lands and at no other time. Keyed by
* the tab's own short name, which is a table with three entries in it for the
* life of the addon -- the iconSize and idsForSlot shape, one widget up.
--]]
local tabLabels = { };

local function tabLabel(key, format, count)
    local entry = tabLabels[key];

    if (entry == nil or entry.count ~= count) then
        entry = { count = count, text = string.format(format, count) };

        tabLabels[key] = entry;
    end

    return entry.text;
end

--[[
* One tab, opened with a request to SELECT it where there is one (1.13.0).
*
* The plain one-argument call is what runs on every ordinary frame -- the
* three-argument form is only reached while `wantTab` is set, which is the
* frame after an open or a `/warehouse find`, and never twice in a row.
*
* PCALL'D, AND LATCHED OFF ON A THROW, for the CAN_CLIPBOARD reason. The
* three-argument spelling is in Ashita's own SDK annotations and five sibling
* addons call it, but this file runs against whatever build a player installed
* and a binding that refuses the arity would throw inside the render pass --
* which closes this window for good. One failure is enough to know: after it,
* the tabs all still work and the window simply opens on whichever one ImGui
* picks. (dwah.lua:4500-4530 carries the same latch for the same call.)
--]]
local tabSelectBroken = false;

--[[
* How many frames a tab request may stand before it is dropped.
*
* SetSelected takes effect on the NEXT frame, so two is all it ever needs;
* eight is the ceiling for the case where it does nothing at all -- a build
* whose binding quietly ignores the flag rather than throwing, which the
* pcall below cannot see. Without a ceiling the request would be re-asserted
* on every frame for the rest of the session, and `tabDrew` deliberately does
* not write the remembered index while one is outstanding: the tab a player
* then moved to would never be remembered. Any request that stands needs a
* hard cap measured from the moment it opened.
--]]
local WANT_TAB_FRAMES = 8;

local function askTab(index)
    state.wantTab   = index;
    state.wantTabAt = frameNo;
end

local function beginTab(label, index)
    if (state.wantTab ~= nil and not tabSelectBroken) then
        local flags = (state.wantTab == index)
            and ImGuiTabItemFlags_SetSelected
            or ImGuiTabItemFlags_None;

        local ok, opened = pcall(imgui.BeginTabItem, label, nil, flags);

        if (ok) then
            return opened;
        end

        tabSelectBroken = true;
        state.wantTab   = nil;
    end

    return imgui.BeginTabItem(label);
end

--[[
* Called by whichever tab actually drew: it takes the pending request and
* becomes the remembered one.
*
* SetSelected takes effect on the NEXT frame -- ImGui consumes the request at
* BeginTabBar -- so the flag is re-asserted until the wanted tab is the one
* drawing, and the remembered index is deliberately NOT written while a
* request is outstanding. Otherwise the frame in between would save the tab
* the window opened on top of the tab the player left, which is the one thing
* a remembered setting must never do (dwfishing.lua:3974-3985).
--]]
local tabDrewFrame = -1;

local function tabDrew(index)
    --[[
        AT MOST ONCE A FRAME, and that is a ceiling rather than a tidy-up.
        Exactly one tab item in a bar returns true per frame, so in the client
        this changes nothing -- but the consequence of being wrong about that
        is `settings.save()` running SIXTY TIMES A SECOND, a file write per
        frame, because two tabs claiming the frame would overwrite each
        other's remembered index for ever. Anything that writes on an event
        needs a bound on how often the event can be believed.
    ]]
    if (tabDrewFrame == frameNo) then
        return;
    end

    tabDrewFrame = frameNo;

    if (state.wantTab == index) then
        state.wantTab = nil;
    end

    if (state.wantTab == nil and state.tab ~= index) then
        state.tab = index;

        -- On a change, never per frame: settings.save writes a file.
        saveView();
    end
end

local function renderWindow()
    -- A request nobody took, dropped rather than re-asserted for ever.
    if (state.wantTab ~= nil and (frameNo - state.wantTabAt) > WANT_TAB_FRAMES) then
        state.wantTab = nil;
    end

    headerStrip();

    imgui.Separator();

    --[[
        THE TABS CARRY THEIR COUNTS AND EXPLAIN THEMSELVES (1.13.0).

        Four one-word labels, and the two questions a player opens a tab to
        answer -- "is there anything in there" and "how many kits do I have"
        -- are answered by the label itself now. The counts also mean the
        Warehouse tab says out loud when a sweep has not landed: `(0)` beside
        a full shelf is a symptom with a name.

        EVERY LABEL CARRIES `###`, and that is load-bearing rather than
        tidy: ImGui derives a tab's identity from its label, so a plain
        'Warehouse (12)' becomes a DIFFERENT tab the moment a row lands, and
        the tab bar drops the player's selection back to the first tab. The
        `###` suffix pins the id to a string that never changes while the
        visible half moves freely.

        The hover test sits between BeginTabItem and the body, not inside the
        `if`: ImGui submits the tab as an item inside BeginTabItem, so
        IsItemHovered reads the TAB there whether it opened or not, and the
        first widget the body draws would take the "last item" away
        (dwbags.lua:4898-4912).
    ]]
    if (imgui.BeginTabBar('##dww_tabs')) then
        local onWarehouse = beginTab(
            tabLabel('wh', 'Warehouse (%d)###dww_tab_wh', modelRowCount()), 1);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabWarehouse);
        end

        if (onWarehouse) then
            tabDrew(1);
            warehouseTab();
            imgui.EndTabItem();
        end

        -- The bag count rides the Deposit label too (1.13.0), for the reason
        -- the other two carry theirs: 'how full am I' is the question this tab
        -- is opened to answer. Budgeted (bagRowCount) rather than read every
        -- frame: the label comes before any tab body, so the frame cache
        -- cannot answer it, and a bag walk a frame is what the round removed.
        local onDeposit = beginTab(
            tabLabel('dep', 'Deposit (%d)###dww_tab_dep', bagRowCount()), 2);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabDeposit);
        end

        if (onDeposit) then
            tabDrew(2);
            depositTab();
            imgui.EndTabItem();
        end

        local onCrystals = beginTab(
            tabLabel('cry', 'Crystals (%d)###dww_tab_cry', crystalView().rows), 3);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabCrystals);
        end

        if (onCrystals) then
            tabDrew(3);
            crystalsTab();
            imgui.EndTabItem();
        end

        local onKits = beginTab(
            tabLabel('kit', 'Kits (%d)###dww_tab_kit', #kitRows()), 4);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabKits);
        end

        if (onKits) then
            tabDrew(4);
            kitsTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather than
* the addon.
*
* An error thrown inside a d3d_present handler is raised on EVERY frame -- sixty
* times a second -- and the addon host answers a long enough run of them by
* unloading the addon. So: Begin and End stay OUTSIDE the pcall, which is what
* keeps ImGui's window stack balanced whatever happens in between; the error is
* reported once; and the window closes itself. Everything the window does is
* still reachable as !warehouse commands, so closing it is a real fallback
* rather than a dead end. (dwbags.lua:1875-1889.)
--]]
ashita.events.register('d3d_present', 'dwwarehouse_present', function ()
    -- The icon cache's ceiling, taken here and nowhere else: last frame's draw
    -- list has already been rendered, and this frame has not asked for a
    -- texture yet (see sweepIcons).
    sweepIcons();

    frameNo = frameNo + 1;

    -- Before the visibility check: a page walk started a moment before the
    -- window was closed still has to finish, and a Take still has to be sent.
    pumpQueue();

    --[[
        THE ENVELOPE WATCHDOG (1.13.0), and it is not defensive.

        `inbound` is set at `d|` and cleared at `z|`, and nothing else ever
        cleared it. An answer cut short -- a dropped 0x017, an `/addon reload`
        landing mid-answer -- therefore left it open for the rest of the
        session; and because the `d|` had ALREADY stamped the page ask
        answered, needPage's clock never re-asked either. The sweep sat on
        "loading 1/?" for ever with both self-repair paths disarmed behind
        `syncing`, which is precisely the state the needPage give-up exists to
        keep the addon out of. dwah found the identical hole in the identical
        shape (dwah.lua:355-360, 1.6.0).

        The clock is read ONLY when an envelope is open (Lua's `and` short
        circuits), so an idle window costs nothing per frame.

        Putting the ask back on the clock is the repair: needPage then retries
        the page once and, failing that, says the sentence and stands down.
    ]]
    if (state.inbound ~= nil and (os.clock() - state.inboundAt) > ENVELOPE_TIMEOUT) then
        local stale = state.inbound;

        state.inbound         = nil;
        state.historyArriving = nil;

        -- The pin list stays exactly as it was: an envelope that never
        -- finished has no answer to commit, and half of one is worse than
        -- last envelope's whole (1.13.0).
        state.pinsArriving    = nil;

        local asked = requested[stale];

        if (type(asked) == 'table') then
            asked.answered = false;
        end

        -- A MUTATION whose tail was lost is exactly the silent gap the
        -- row-count check exists for: the rows that did arrive are in the
        -- model, the ones after the break never will be, and the `k|` that
        -- said how many the account holds arrived before either. Counted here
        -- rather than waiting for the next mutation to notice. Ordered after
        -- the re-arm above because verifyRowCount may start a sweep, and a
        -- sweep begins by forgetting every ask.
        if (MUTATION_VERBS[stale]) then
            verifyRowCount();
        end
    end

    -- The sweep drives itself from here rather than from the record handler, so
    -- a page command lost on the way out is re-asked (once) instead of leaving
    -- the list half-filled forever.
    if (state.syncing and state.nextPage ~= nil) then
        needPage(state.nextPage);
    end

    -- And the `who` ask, on the same terms (1.13.0). Driven off the ask
    -- itself rather than off `syncing`, because a `who` can still be
    -- unanswered after the page walk has finished -- the page walk does not
    -- need it -- and that is exactly the case where the loss is invisible.
    -- Two table lookups on an idle frame; nothing once it is answered.
    local askedWho = requested['who'];

    if (state.synced and askedWho ~= nil and not askedWho.answered) then
        needWho();
    end

    -- A generation the model on screen was not built from: another client on
    -- this account moved something, or moved it while the last sweep was
    -- walking. Repaired here rather than on a timer -- the gap is only visible
    -- once a response has landed, and startSync is idempotent because issue()
    -- collapses duplicate commands.
    if (not state.syncing and state.synced and state.gen ~= state.syncGen) then
        if (state.resweeps < MAX_RESWEEPS) then
            state.resweeps = state.resweeps + 1;

            startSync();
        else
            setStatus('The account is being changed elsewhere. Press Refresh when it settles.', true, true);

            state.syncGen = state.gen;
        end
    end

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    imgui.SetNextWindowSize({ 840, 480 }, ImGuiCond_FirstUseEver);

    --[[
        A FLOOR UNDER THE WINDOW (1.13.0). There was none, and the header
        strip is a hard shape: the capacity bar, Buy Slot, Refresh and the
        freshness note on one row, then Find, six category chips, the sort
        combo and the Whole stack box on the next. Dragged narrower than
        those, the chips run off the right edge -- ImGui does not wrap a
        SameLine, it clips it -- and there is no way back to a filter that is
        no longer on screen; dragged shorter, the tables (which take all the
        remaining height) collapse to nothing and the tab bar is all that is
        left.

        THE WIDTH WAS 620 AND THAT WAS NOT A MEASUREMENT (1.13.0). Add a
        header row up at the default font and the numbers are not close:
        'Find:' and its 200-wide box is about 240 and the six chips about 330
        with their spacing, so the filter row alone is 620 with nothing to
        spare -- and the TOP row (a 220-wide bar, Buy Slot, Refresh, the
        freshness note and the market standing) is about 700. A 620 floor
        therefore still let a player drag away the last chips and half the
        market line, which is exactly the failure the floor was added to
        prevent: ImGui does not wrap a SameLine, it clips it, and there is no
        way back to a control that is no longer on screen.

        800 is that top row with room for the window's own padding. It is
        below the 840 the window opens at, so nothing about a first open
        changes. (The sort combo and the quantity box moved to a row of their
        own in the same pass -- see headerStrip -- which is what makes 800
        enough rather than 950.)

        The height stays 300: the header is about 160 of it and a table with
        its own scroll region still shows rows in what is left, which is why
        the Crystals table gained one (see crystalsTab).

        Guarded and PCALL'D for the CAN_CLIPBOARD reason: the call is in
        Ashita's SDK annotations, and the window still has to open on a build
        that does not have it (dwah.lua:4586-4597).
    ]]
    if (CAN_CONSTRAIN) then
        pcall(imgui.SetNextWindowSizeConstraints, { 800, 300 }, { 99999, 99999 });
    end

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Warehouse##dwwarehouse', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwwarehouse'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwwarehouse'):append(chat.message('Window closed. Everything it does also works as !warehouse commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Watch what the player sends, so the window keeps up with commands typed
* outside it. 0x00B5 is Kind at 0x04, a pad byte, then the message at 0x06.
*
* Only `!warehouse` is matched for invalidation, not `!dww`: the addon's own
* commands already answer with what they changed.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE, though. The
* client's rate limit is on chat, not on this addon, so a page request fired in
* the same frame as something the player typed is the one that gets dropped --
* and on this addon that costs a whole sweep, not one panel. Stamping the
* player's own line as a send makes the follow-up wait its interval instead of
* racing it. (dwbags.lua:1935-1953.)
--]]
ashita.events.register('packet_out', 'dwwarehouse_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dww') then
        lastSend = os.clock();
    end

    if (message:lower():sub(1, 10) == '!warehouse') then
        startSync();
    end
end);

ashita.events.register('command', 'dwwarehouse_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Warehouse`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/warehouse' and first ~= '/wh') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        state.resweeps = 0;
        state.repaired = false;

        startSync();

        return;
    end

    --[[
        `/warehouse find <text>` (1.13.0): open the window with the Find box
        already narrowed to what was typed.

        WHY IT IS WORTH A VERB. Find is the fastest thing in this window and
        the slowest thing to reach: open, wait for the sweep, click the box,
        type. A macro or a linkshell instruction can now say `/wh find
        rolanberry` and land on the answer -- and it is the shape a crafter
        actually wants, checking whether the shelf has an ingredient without
        browsing a thousand rows.

        Everything here is LOCAL. The search is a client-side filter over a
        model the server already sent (matchesSearch is a plain `find`, not a
        pattern), so no number is formatted and no line goes out: the one
        typed argument this addon takes needs no integrality guard because it
        never becomes part of a command. The rest of the line is joined back
        together with single spaces -- `:args()` has already split it -- and
        clamped to the box's own 63 usable bytes.
    ]]
    if (#args >= 2 and args[2]:lower() == 'find') then
        local words = T{ };

        for index = 3, #args do
            words:append(args[index]);
        end

        state.search[1] = table.concat(words, ' '):sub(1, 63);
        state.open[1]   = true;
        state.reported  = false;

        -- AND LANDS ON THE SHELF. The Find box narrows both the shelf and the
        -- bag, but "is it in the warehouse" is the question this verb is
        -- asked, and a player who left the window on the Kits tab would
        -- otherwise open on a tab the search does not touch.
        askTab(1);

        if (not state.synced) then
            startSync();
        end

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported` only
        -- exists to stop one bad frame printing sixty lines a second, not to
        -- silence a different error a week later in the same session.
        state.reported = false;

        -- And it opens on the tab it was last left on (1.13.0). ImGui keeps a
        -- tab bar's selection while the window exists, so this only really
        -- moves anything on the first open after a load -- which is exactly
        -- the open that used to land on the Warehouse tab whatever the player
        -- had been doing.
        askTab(state.tab);

        -- ONCE PER LOGIN, not once per open. The model is kept current by the
        -- deltas every command answers with, so a second open has nothing to
        -- ask for -- and asking anyway would be a twelve-command page walk for
        -- a window the player only wanted to glance at. Refresh is the button
        -- for doing it on purpose; a generation gap does it automatically.
        if (not state.synced) then
            startSync();
        end
    end
end);

ashita.events.register('load', 'dwwarehouse_load', function ()
    print(chat.header('dwwarehouse'):append(chat.message('/warehouse opens your account storage. Everything it does also works typed as !warehouse.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new pin list and a new view. (The pool itself is
-- the account's and does not change with the character -- pins are per
-- character, which is what makes this reset necessary rather than tidy.)
ashita.events.register('packet_in', 'dwwarehouse_zonein', function (e)
    if (e.id == 0x000A) then
        state.rows      = {};
        state.modelRev  = state.modelRev + 1;
        state.pins      = {};
        state.used      = 0;
        state.cap       = 0;
        state.gen       = 0;
        state.syncing   = false;
        state.syncGen   = -1;
        state.sweepGen  = nil;
        state.resweeps  = 0;
        state.nextPage  = nil;
        state.pages     = nil;
        state.pagesSeen = 0;
        state.synced    = false;
        state.repaired  = false;
        state.inbound   = nil;
        setStatus('Press Refresh.', false);

        -- A pin refresh half-arrived from before the login is about the
        -- character that just logged out (1.13.0).
        state.pinsArriving = nil;

        -- A pending trash question is about a row id from before the zone
        -- line; the model it referred to has just been wiped.
        state.trashAsk  = nil;

        -- AND THE CAPABILITY LATCH IS RE-PROBED. This used to say "the server
        -- on the other side of a zone line is the same server", which is true
        -- of a zone line and NOT of the other thing 0x000A means: a login. A
        -- map restart logs everyone out, so a player who relogs after the
        -- trash verb was deployed was still being told it does not exist --
        -- for the rest of the client session, with the buttons simply not
        -- drawn and nothing on screen to say why. Every sibling latch in the
        -- suite is cleared here for exactly this reason (dwbags' three,
        -- dwgambits' two, dwmerc's two, dwscan and dwfishing's refusals), and
        -- the cost of being wrong is one refusal sentence the player earns
        -- back by clicking Trash once.
        state.noTrash   = false;
        state.noStack   = false;
        state.noBuy     = false;
        state.buyAsk    = false;

        -- The market lane's three, same reason: the standing is re-learned
        -- from the next `who`, and a strip open across a login names a row
        -- the wiped model no longer has.
        state.noSell    = false;
        state.market    = nil;
        state.sellAsk   = nil;

        -- The crystal ledger's, same reason -- and it is PER CHARACTER, so a
        -- login is a different ledger even before the re-probe: the next
        -- `who` brings the right one. The Retrieve boxes named counts of the
        -- old one.
        state.noCrystals = false;
        state.crystals   = nil;

        -- The sale history's, same family (1.13.0). `noHistory` is re-probed
        -- with its siblings; the cached answers and the ask clock go because
        -- a market moves while a client is on the log-in screen, and a
        -- half-arrived list must never commit into the session after it.
        state.noHistory       = false;
        state.saleHistory     = { };
        state.historyAsked    = { };
        state.historyArriving = nil;

        -- The vendor lane's and the batch door's (1.15.0), same family. The
        -- two latches are re-probed with their siblings; `gil` and `gilCap`
        -- go because gil is PER CHARACTER and the next `who` brings the right
        -- pouch; the two pending questions go because they name row ids from
        -- a model that has just been wiped. `prices` goes with them even
        -- though a base price is not per character -- the model it decorates
        -- is gone, and a table that only ever grows is a table that wants
        -- emptying at the one honest moment there is (the bursts-need-
        -- ceilings rule).
        state.noVendor    = false;
        state.noTrashMany = false;
        state.gil         = nil;
        state.gilCap      = nil;
        state.prices      = {};
        state.vendorAsk   = nil;
        state.batchAsk    = nil;
        state.picked      = {};

        for index = 1, #ELEMENTS do
            state.crystalQty[index][1] = '';
        end

        selection = {};
        forget();

        -- An open window restarts its own sweep: this reset just disarmed
        -- both self-repair paths (the open transition only fires on a
        -- toggle, and the generation-gap repair is gated on `synced`), so
        -- without this the window sits on an empty model until the player
        -- clicks Refresh.
        if (state.open[1]) then
            startSync();
        end
    end
end);
