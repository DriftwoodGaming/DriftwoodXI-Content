--[[
* dwhub -- the DriftwoodXI front door (owner request 2026-09-19).
*
* `/dw` opens one window that lists every other DriftwoodXI addon, says what
* each is for, and opens it on a click. It exists because the server's custom
* content lives behind twenty-eight slash commands, and a list of twenty-eight
* slash commands is something a new player reads once, in a chat log, while
* it scrolls away. This is the same list where it can be found again: grouped
* by when you will want it, searchable, and one click from the window itself.
*
* IT TALKS TO NO SERVER. There is no `!` line anywhere in this folder, no
* sender name, no protocol version, no packet handler -- so it needs no
* dwecho.lua (the library that hides an addon's own wire lines from the chat
* log) and carries only dwtheme.lua. Everything it shows is catalog.lua, which
* is a CHECKED COPY of modules/driftwoodxi/addons.lua: tools/dwhub/
* harness_dwhub.py holds the two equal, so this window cannot drift from what
* `!addons` says the way the login hint once did.
*
* WHAT A BUTTON DOES is queue the other addon's OWN slash command through
* Ashita's command parser (mode -1, the way `/addon load` itself is queued by
* every addon that reloads another). It reaches into nobody's state: if the
* other addon is loaded its window toggles, exactly as if the player had typed
* the command, and if it is not, nothing happens at all -- which is the one
* failure every new player hits and the reason each row carries a Load
* button. Loading is `/addon load <name>`; an addon already loaded answers
* that with one harmless line.
*
* These are CLIENT commands and are supposed to be visible as such -- the
* dwengage / dwmacro precedent -- which is why a direct QueueCommand is right
* here and would be wrong in any addon that carries dwecho.
*
* Commands:
*   /dw            toggle the window
*   /dw <words>    open it with the search box already filled ("/dw market")
*   /dwhub         the same, for anyone who guesses the folder's name
--]]

addon.name    = 'dwhub';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.1';
addon.desc    = 'The DriftwoodXI front door: every server addon in one window -- what it is for, a button that opens it, and a button that loads it when it is switched off.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat    = require('chat');
local imgui   = require('imgui');
local theme   = require('dwtheme');
local catalog = require('catalog');

local state = {
    -- Sugar tables, because that is what Ashita's ImGui binding writes back
    -- into: Begin's open flag and InputText's buffer are both read and
    -- written through index 1.
    open     = T{ false },
    find     = T{ '' },
    needle   = '',
    reported = false,

    -- The rows under each group, and each row's drawing strings, built ONCE
    -- at load: the catalog never changes while the addon runs, and a window
    -- that formats twenty-eight labels sixty times a second is paying for
    -- nothing.
    byGroup  = { },
};

for _, group in ipairs(catalog.groups) do
    state.byGroup[group.key] = { };
    group.tabLabel           = string.format('%s##dwhub_tab_%s', group.label, group.key);
end

for _, row in ipairs(catalog.rows) do
    local windowed = row.window ~= false;

    row.openLabel = string.format('%s##dwhub_open_%s', windowed and 'Open' or 'Help', row.id);
    row.loadLabel = string.format('Load##dwhub_load_%s', row.id);
    row.openTip   = windowed
        and string.format('Runs %s, exactly as if you had typed it.\nNothing happened? The addon is switched off -- press Load.', row.cmd)
        or string.format('%s has no window: it just works once it is loaded.\nThis runs %s, which prints what it can do.', row.id, row.cmd);
    row.loadTip   = string.format('Runs /addon load %s.\nTo keep it on for good, tick it in the DriftwoodXI launcher (Addons tab).', row.id);
    row.typedLine = row.typed ~= nil and string.format('No addon needed: type  !%s  in chat.', row.typed) or nil;
    row.firstLine = row.first ~= nil and ('First time: ' .. row.first) or nil;

    -- What the search box matches: the name, the shortcut and the sentence.
    row.haystack  = string.lower(table.concat({ row.id, row.cmd, row.blurb, row.first or '' }, ' '));

    if (state.byGroup[row.group] ~= nil) then
        table.insert(state.byGroup[row.group], row);
    end
end

-- One client command, through Ashita's own parser. Mode -1 is the mode every
-- addon that loads or reloads another one already uses.
local function run(command)
    AshitaCore:GetChatManager():QueueCommand(-1, command);
end

local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

-- The search needle: lowercased, outer whitespace gone. Parenthesised because
-- gsub answers two values and only the string is wanted.
local function trimmed(text)
    return (string.lower(tostring(text or '')):gsub('^%s+', ''):gsub('%s+$', ''));
end

local function matches(row)
    return state.needle == '' or string.find(row.haystack, state.needle, 1, true) ~= nil;
end

local function drawRow(row)
    if (imgui.SmallButton(row.openLabel)) then
        run(row.cmd);
    end

    tip(row.openTip);

    imgui.SameLine();

    if (imgui.SmallButton(row.loadLabel)) then
        run('/addon load ' .. row.id);
    end

    tip(row.loadTip);

    imgui.SameLine();
    imgui.TextColored(theme.colors.ok, row.cmd);
    imgui.SameLine();
    imgui.TextDisabled(row.id);

    -- Wrapped at the window's edge (the dwquest paragraph shape): a blurb is
    -- a sentence, and a sentence clipped at the right border is half of one.
    imgui.PushTextWrapPos(0.0);
    imgui.Text(row.blurb);

    if (row.firstLine ~= nil) then
        imgui.TextColored(theme.colors.hint, row.firstLine);
    end

    if (row.typedLine ~= nil) then
        imgui.TextDisabled(row.typedLine);
    end

    imgui.PopTextWrapPos();
    imgui.Separator();
end

-- One group's rows. `filtered` is the search view: only the matches, under the
-- group's NAME (there are no tabs to say it); unfiltered is a tab body, which
-- opens with the group's note instead. Returns how many rows it drew.
local function drawGroup(group, filtered)
    local drawn = 0;

    for _, row in ipairs(state.byGroup[group.key]) do
        if (not filtered or matches(row)) then
            if (drawn == 0) then
                if (filtered) then
                    imgui.TextColored(theme.colors.badge, group.label);
                else
                    imgui.PushTextWrapPos(0.0);
                    imgui.TextDisabled(group.note);
                    imgui.PopTextWrapPos();
                end

                imgui.Separator();
            end

            drawRow(row);

            drawn = drawn + 1;
        end
    end

    return drawn;
end

local function renderWindow()
    imgui.PushTextWrapPos(0.0);
    imgui.Text('Everything custom on DriftwoodXI opens from a window. Open runs the addon\'s own command; if nothing happens, that addon is switched off -- press Load, or tick it in the launcher\'s Addons tab to keep it on.');
    imgui.PopTextWrapPos();

    imgui.SetNextItemWidth(260);

    if (imgui.InputText('Find##dwhub_find', state.find, 48)) then
        state.needle = trimmed(state.find[1]);
    end

    tip('Filters every group by name, shortcut or description. Empty shows the groups as tabs.');

    imgui.Separator();

    -- The rows scroll; the header above them does not.
    if (not imgui.BeginChild('##dwhub_rows', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (state.needle ~= '') then
        -- A SEARCH IS ONE FLAT LIST. Results filed under tabs the player has
        -- to click through are results nobody finds; every match is drawn
        -- here, under its group's name, in the catalog's own order.
        local shown = 0;

        for _, group in ipairs(catalog.groups) do
            shown = shown + drawGroup(group, true);
        end

        if (shown == 0) then
            imgui.TextDisabled(string.format('Nothing matches "%s". The box searches names, shortcuts and descriptions.', state.needle));
        end
    elseif (imgui.BeginTabBar('##dwhub_tabs')) then
        for _, group in ipairs(catalog.groups) do
            if (imgui.BeginTabItem(group.tabLabel)) then
                drawGroup(group, false);
                imgui.EndTabItem();
            end
        end

        imgui.EndTabBar();
    end

    imgui.EndChild();
end

ashita.events.register('d3d_present', 'dwhub_present', function ()
    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 640, 520 }, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE. Nothing in ImGui stops a window being dragged to
    -- nothing; 460 keeps a row's two buttons, its shortcut and its name on
    -- one line, which is the narrowest the row still reads as a row.
    imgui.SetNextWindowSizeConstraints({ 460, 260 }, { 99999, 99999 });

    local visible = imgui.Begin('DriftwoodXI##dwhub', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwhub'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwhub'):append(chat.message('Window closed. The same list is printed by typing !addons in chat.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('command', 'dwhub_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, and a player
    -- who capitalises is not making a mistake.
    local first = #args > 0 and args[1]:lower() or '';

    -- EXACT MATCH ON THE FIRST WORD, which is what keeps `/dw` from eating
    -- /dwah, /dwcon, /dwscan, /dwfishing, /dwmacro and /dwengage: a prefix
    -- test here would swallow six other addons' commands.
    if (first ~= '/dw' and first ~= '/dwhub') then
        return;
    end

    e.blocked = true;

    -- `/dw market` OPENS the window on that search rather than toggling it: a
    -- player who named something has said what they want, and shutting the
    -- window on them because it happened to be open is the wrong answer.
    if (#args > 1) then
        local words = { };

        for index = 2, #args do
            words[#words + 1] = args[index];
        end

        local wanted = string.sub(table.concat(words, ' '), 1, 47);

        state.find[1]  = wanted;
        state.needle   = trimmed(wanted);
        state.open[1]  = true;
        state.reported = false;

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwhub_load', function ()
    print(chat.header('dwhub'):append(chat.message('/dw opens the DriftwoodXI front door: every server addon, what it is for, and a button that opens it. /dw <word> searches it.')));
end);
