--[[
* DriftwoodXI -- dwsquad
*
* Your squad in a window: every character on the account listed by name, job
* and level, with the five squad slots beside them -- add and remove members
* by clicking instead of remembering names and typing !squad set.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no roster of its own, caches nothing to disk, and has no way to
* change a squad the typed command surface could not. Every read is `!dws who`
* and every write is `!dws set|clear`, which reach exactly the same server
* functions `!squad set|clear` reach -- the only difference is that they
* answer in compact records under the sender name _DWSDATA, which this addon
* parses and blocks before the chat log sees them. The Call and Dismiss
* buttons send the literal `!squad call` and `!squad dismiss` a player would
* type, because their output is narrative and belongs in the chat log -- and
* the trust engage toggle sends the literal `!trustengage 0|1` the same way,
* drawn only when the roster's additive `t|` record has said what the mode
* currently is.
*
* ONE THING IT DOES THAT IS NOT RENDERING, since 1.4.1, and it is called out
* here so the claim above stays honest: it clears the collision bit on the
* trusts in your party AND ON THEIR PETS (1.5.0 -- the pets were the half
* that was missing, and a jug in a doorway blocks exactly as well as its
* master), so you walk through your own squad instead of into it.
* That is a write into your own client's memory and not a message to anybody,
* because the server has no say in it -- ghostSquad() below is the long
* version. Nobody else can see the difference and the server records none of
* it, which is why it sits inside a renderer without making it something else.
*
* The alliance row follows the same rule: Form sends the literal `!pally
* <name>`, Join sends `!join`, Dissolve sends `!pleave` -- the server's
* group command lane, which drives the REAL grouping packet handlers (the
* client greys its own grouping UI around squads, so the typed verbs are the
* reachable flow). The row is drawn only when the roster's additive `g|`
* record has said what the group state IS, which is also what tells it an
* invite is waiting to be Joined. Since 1.3.1 the row also states what an
* alliance COSTS -- two parties each earn half of what a kill pays, three
* each earn a third (charutils::AllianceShareDivisor, 2026-08-21) -- because
* the halving is otherwise a number that quietly got smaller.
*
* Since 1.4.0 that section carries a LEVEL SYNC row -- `!alliancesync <name>`,
* `!alliancesync off`, and the bare `!alliancesync` status question when the
* box is empty. It exists because retail's own level-sync menu is party-scoped
* and structurally cannot reach across an alliance (the 0x077 packet is gated
* to Kind == Party), so the typed command is the ONLY door to it and a door
* nobody can find is a door nobody uses. Note what the row does NOT do: it
* never displays the current sync level. There is no record carrying it, and
* inventing one for a button would be a protocol change -- so the buttons send
* the command and the SERVER answers in the chat log, exactly as typing does.
* Showing a level this addon cannot verify would be the one thing a renderer
* must never do.
*
* Since 1.6.0 the settings block also carries a FOLLOW DISTANCE slider --
* `!trustfollow <yalms>` underneath, the first trust's distance from you
* (the rest keep their spacing behind it). Every number on the slider -- the
* range, the stock mark, the value -- rides the roster's additive `f|` record
* from the server's own clamp (cpp/squad_follow.cpp), so this file states no
* yalm of its own; the slider sends the typed line once it has rested for
* half a second (a chat line per drag tick would be the client's rate limit
* refusing you), and the roster is re-asked for the settled truth.
*
* That constraint is deliberate and it is the reason a UI could be shipped at
* all: a bug in here cannot register a character the server would have
* refused, because it is not doing anything the typed command does not do.
* The ownership check lives in the server's C++ and runs identically
* whichever way the command arrived.
*
* TYPING `!squad` ON ITS OWN NOW OPENS THIS WINDOW. The line is intercepted
* before it leaves the client, so the server never sees it; every other
* !squad command passes through untouched. With the addon off, `!squad`
* prints its usage text exactly as before.
*
* TURN IT OFF AND NOTHING IS LOST. `!squad set <slot> <name>`, `!squad clear
* <slot>`, `!squad list`, `!squad call` and `!squad dismiss` all work typed.
* This is friendlier; it is not required.
--]]

addon.name    = 'dwsquad';
addon.author  = 'DriftwoodXI';
addon.version = '1.6.1';
addon.desc    = 'Squad roster window for DriftwoodXI -- add and remove members by clicking, with live buffs on summoned members.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. dwbags
-- owns _DWDATA and dwgambits owns _DWGDATA; this addon must never contend for
-- either, which is why !dws exists at all.
local DATA_SENDER = '_DWSDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

local MAX_SLOTS = 5;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Character flag bits, as the server packs them.
local CHAR_ONLINE = 1;
local CHAR_LOCKED = 2;
local CHAR_SELF   = 4;

local state = T{
    open      = T{ false },

    -- Replaced wholesale by a `who` response, never merged, so a stale row
    -- cannot survive a refresh.
    chars     = T{ },

    -- Status effects on summoned members, keyed by charid -- replaced
    -- wholesale by a `buffs` response for the same reason. The `at` stamp on
    -- each entry is what lets the timers count down between refreshes.
    buffs     = T{ },

    -- The caller's trust engage mode, from the `t|` record the roster carries
    -- (additive to protocol 1): 0 retail (trusts wait for your first swing),
    -- 1 attack (trusts engage the moment you draw your weapon). nil until a
    -- roster carries one -- a server from before the record, or one with the
    -- feature disabled, sends none, and the toggle is simply not drawn. That
    -- is the deployment-order rule every additive record follows here.
    trustEngage = nil,

    -- The caller's group state, from the additive `g|` record: whether their
    -- party stands in an alliance, and what invite (if any) is pending on
    -- them. Same lifecycle as trustEngage -- nil until a roster carries one,
    -- and the alliance row is simply not drawn against a server without the
    -- group command lane.
    group     = nil,

    -- The caller's trust follow distance, from the additive `f|` record:
    -- { tenths, min, max, stock }, all in tenths of a yalm, tenths 0 while
    -- stock. Same lifecycle as trustEngage -- nil until a roster carries
    -- one, and the slider is simply not drawn against a server without
    -- the follow-distance module.
    follow    = nil,

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its own
    -- cannot half-fill the UI.
    inbound   = nil,
    status    = 'Loading...',
    statusBad = false,
    reported  = false,     -- a render error is worth saying once, not per frame

    -- Set while the envelope being read is a refusal of the BACKGROUND buff
    -- poll, which the player never asked for. It keeps that one refusal out
    -- of the chat log without silencing any refusal the player provoked, and
    -- is cleared by the `z|` that closes the envelope.
    quietErr  = false,
};

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A
* TIME. The client rate-limits outgoing chat, and a !dws command is a chat
* line; anything over the limit is answered with "A command error occurred"
* before the server ever sees it. So everything queues here and drains at one
* command per SEND_INTERVAL, and duplicates collapse.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

--[[
* WALKING THROUGH YOUR OWN SQUAD (1.4.1; REWRITTEN 1.5.0 after it did not
* work).
*
* THE SERVER CANNOT DO THIS, and that is worth stating plainly because it is
* the obvious place to look. Collision between the player and another entity
* is decided entirely inside the client, from a render flag that lives in the
* client's own entity structure and is not built from any field the server
* sends -- not `status`, not `namevis`, and not the uint32 of EntityFlags the
* 0x00E packet carries at 0x21, whose seven bits are the whole set the server
* has (none, info_icon, hide_name, call_for_help, hide_model, hide_hp,
* untargetable -- build/generated/data/enums/entity_flags.h). There is no
* packet that says "you may walk through this". Ashita's own `casper` addon
* is the proof and the precedent: it does exactly this for other PLAYERS, by
* ORing 0x40 into Render.Flags0 after every 0x000D, and it exists precisely
* because no server can.
*
* WHAT 1.4.1 GOT WRONG. THE FEATURE NEVER RAN AT ALL. The write was gated on
* `SpawnFlags & 0x10` -- "is this entity mob-class" -- reasoning from the
* SERVER's C++ hierarchy (a trust is a CTrustEntity is a CMobEntity) to a
* CLIENT-side flag. The client has never heard of that hierarchy; it sets the
* flag from packet bits, and it keeps a DEDICATED bit for this:
*
*     Ashita-v4beta-2025_q3_update/plugins/sdk/ffxi/enums.h
*         Player 0x0001  Npc 0x0002  PartyMember 0x0004  AllianceMember 0x0008
*         Monster 0x0010 Object 0x0020 ... Fellow 0x0800  TRUST 0x1000
*
* A trust is not a Monster to the client -- it reads 0x0E (Npc | PartyMember |
* AllianceMember), which is exactly what Windower's own Trusts addon tests for
* (`mob.spawn_type == 14`) and what luashitacast's table calls "Party".
* `Monster` is a SEPARATE bit and a trust does not carry it. So the `== 0`
* early-out fired on every member of every squad, every pass, and the two
* lines below it -- the entire feature -- had never executed once.
*
* That is this tree's own named defect class landing at the client boundary:
* mirroring a taxonomy instead of asking the thing that owns the answer.
*
* THE SECOND GAP, which would have bitten the moment the first was fixed: THE
* PARTY LIST DOES NOT CONTAIN PETS. An alt-trust BST's jug, a squad summoner's
* avatar, a dragoon's wyvern and a puppetmaster's automaton are full-size
* bodies standing in the same doorway as their master, and not one of them
* could ever have been found this way. A squad of five fields up to five more
* bodies the old walk could not see.
*
* AND THE THIRD: IT WROTE THE BIT TWICE A SECOND. A trust following you pushes
* an 0x00E every 250ms (trust_entity.cpp's m_nextUpdateTimer), so the poll ran
* at half the rate of the packet that could clear it. `casper` does not poll
* at all -- it writes on the entity's own update packet, the moment the client
* has just touched that structure. The write now happens BOTH ways: on the
* update packet, casper's shape, and on the sweep as the backstop for anything
* standing still.
*
* HOW TARGETS ARE FOUND NOW, and why this cannot touch anything it should not:
*
*   TRUSTS come from the party list as before, but gated on the TARGET INDEX
*   RANGE rather than on a flag -- and the range is a fact THE SERVER
*   GUARANTEES rather than one the client reports. zone_entities.cpp hands
*   trusts and pets a dynamic targid in [0x700, 0x900)
*   (AssignDynamicTargIDandLongID), starts characters at 0x400
*   (GetNewCharTargID) and errors if one ever reaches 0x700. So "a party
*   member at 0x700 or above" IS "a party member who is not a person", with no
*   client flag to be wrong about a second time. Other players stay solid --
*   ghosting them is `casper`'s offer to make and not this addon's to make for
*   you -- and they are excluded structurally by the range, not by a test that
*   could quietly stop matching.
*
*   PETS come from their master, not from a scan: each entity carries the
*   target index of its own pet, so every ghosted trust is asked for one. That
*   is exact. The tempting alternative -- sweep [0x700, 0x900) for anything
*   whose owner is set -- would also catch a CLAIMED MOB, because a claimed
*   mob carries its claimer in the same packet field, and a DWRaid boss is a
*   dynamic entity sitting squarely in that range. Walking through the boss is
*   not a bug anybody would enjoy explaining.
*
* RE-APPLIED, NOT SET ONCE, because the flag is the client's and the client
* rebuilds it: a trust that zones, is dismissed and re-summoned, or drops out
* of render range comes back solid. Every read is wrapped -- a target index
* can go stale between the party list and the entity array on a zone line,
* which is the same reason dwparse's tracked-id walk wraps its pet read.
*
* AND IT REPORTS ITSELF. `/squad ghost` prints what this layer sees and what
* it wrote, per entity, including READING THE BIT BACK after the write. If a
* player still collides, that one line separates the three possible causes --
* nothing was found, the write did not stick, or the write stuck and 0x40 is
* not the lever for this entity class -- without another round of guessing.
--]]
local GHOST_INTERVAL = 0.5;
local GHOST_NO_CLIP  = 0x40;   -- Render.Flags0 bit: stop colliding with it
local GHOST_DYN_LOW  = 0x700;  -- first dynamic targid: trusts and pets
local GHOST_DYN_HIGH = 0x900;  -- one past the last

local ghostAt = 0;

-- The indices this layer decided are ghostable on the last sweep. The packet
-- hook re-applies to these and only these: it must not do a party walk on
-- every 0x00E (a busy zone sends hundreds a second), and an index that has
-- not been vetted by a sweep has no business being written to.
local ghostSet = { };

-- One write, and the truth about it. Returns nil when there is no entity at
-- this index, else a row the diagnostic prints: what was there before, what
-- was written, and WHAT IT READS BACK AS -- the read-back is the whole point,
-- because "wrote it and it did not stick" and "never wrote it" look identical
-- from outside and have completely different fixes.
local function ghostOne(idx)
    local row = nil;

    pcall(function ()
        local ent = GetEntity(idx);

        if (ent == nil) then
            return;
        end

        local before = ent.Render.Flags0;

        if (bit.band(before, GHOST_NO_CLIP) == 0) then
            ent.Render.Flags0 = bit.bor(before, GHOST_NO_CLIP);
        end

        row =
        {
            index  = idx,
            name   = ent.Name or '?',
            before = before,
            after  = ent.Render.Flags0,
            pet    = ent.PetTargetIndex or 0,
        };
    end);

    return row;
end

-- Walk the party, ghost every member that is not a person, then ghost that
-- member's pet. Returns the rows when asked to (the diagnostic), nil when not
-- -- the sweep runs 120 times a minute and must not build a table each time.
local function ghostWalk(collect)
    local rows  = collect and { } or nil;
    local party = AshitaCore:GetMemoryManager():GetParty();

    if (party == nil) then
        return rows;
    end

    -- Slot 0 active is the tree-wide "there is a logged-in character" test
    -- (dwmacro, dwscan). Without it this walks a stale party array at the
    -- character-select screen and writes into whatever the last session left
    -- in the entity table.
    if (party:GetMemberIsActive(0) ~= 1) then
        return rows;
    end

    local seen = { };

    -- 1..17, not 0..17: slot 0 is the player, and a player who cannot collide
    -- with the world is a different and much worse bug.
    for i = 1, 17 do
        local idx = nil;

        pcall(function ()
            if (party:GetMemberIsActive(i) ~= 1) then
                return;
            end

            local at = party:GetMemberTargetIndex(i);

            -- The range IS the test. Below 0x700 is a real character (or an
            -- unfilled slot reading 0) and stays solid.
            if (at ~= nil and at >= GHOST_DYN_LOW and at < GHOST_DYN_HIGH) then
                idx = at;
            end
        end);

        if (idx ~= nil) then
            local row = ghostOne(idx);

            if (row ~= nil) then
                seen[idx] = true;

                if (rows ~= nil) then
                    row.kind = 'trust';
                    table.insert(rows, row);
                end

                -- The master's own pet, asked of the master rather than
                -- hunted for. Range-checked too: a pet is a dynamic entity
                -- exactly like its summoner, and anything answering outside
                -- that range is a stale read, not a pet.
                local pet = row.pet;

                if (pet >= GHOST_DYN_LOW and pet < GHOST_DYN_HIGH) then
                    local petRow = ghostOne(pet);

                    if (petRow ~= nil) then
                        seen[pet] = true;

                        if (rows ~= nil) then
                            petRow.kind = 'pet of ' .. tostring(row.name);
                            table.insert(rows, petRow);
                        end
                    end
                end
            end
        end
    end

    ghostSet = seen;

    return rows;
end

local function ghostSquad()
    local now = os.clock();

    if (now - ghostAt < GHOST_INTERVAL) then
        return;
    end

    ghostAt = now;

    ghostWalk(false);
end

-- casper's shape: the entity's own update packet is the moment the client has
-- just written that entity's structure, so it is the moment to write the bit
-- back. 0x000E is the packet trusts and pets arrive on (they are sent with
-- UPDATE_ALL_MOB, zone_entities.cpp), and ActIndex sits at 0x08 in it exactly
-- as it does in the 0x000D casper reads.
--
-- Gated on the sweep's verdict AND re-checked against the client's own trust
-- marker, and the second half is not belt-and-braces -- it is required.
--
-- THE SERVER RECYCLES DYNAMIC TARGIDS IN EXACTLY THE BAND THIS SET HOLDS.
-- `m_nextDynamicTargID` walks [0x700, 0x900) and reuses a freed index as soon
-- as it comes back round. Dismiss a squad member mid-fight -- or let its
-- avatar go -- and within the next half second a DWRaid arena can insert an
-- add that inherits that very targid. The sweep would not have run yet, the
-- stale `ghostSet` entry would still say yes, and the player would be able to
-- WALK THROUGH A RAID BOSS. Half a second is a small window and a fight is
-- exactly when it opens.
--
-- So the set narrows the work (this fires for every entity in the zone and
-- must stay cheap) and `TrustOwnerTargetIndex` decides. That field is the
-- client's own trust marker -- our entity_update stamps the trust flag and
-- the summoner as owner for trusts AND their pets -- and a recycled index
-- belonging to a mob reads 0 the moment the client rebuilds the entity.
ashita.events.register('packet_in', 'dwsquad_ghost', function (e)
    if (e.id ~= 0x000E) then
        return;
    end

    pcall(function ()
        local idx = struct.unpack('H', e.data_modified, 0x08 + 1);

        if (not ghostSet[idx]) then
            return;
        end

        local entity = AshitaCore:GetMemoryManager():GetEntity();

        if (entity ~= nil and entity:GetTrustOwnerTargetIndex(idx) == 0) then
            -- The index was recycled onto something that is not a trust or a
            -- trust's pet. Drop it rather than write to it, and let the next
            -- sweep rebuild the set.
            ghostSet[idx] = nil;

            return;
        end

        ghostOne(idx);
    end);
end);

local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a window drawn sixty times a second asks
* once. THE ANSWER IS TRACKED, NOT JUST THE QUESTION: a command issued in the
* same instant as something the player typed can be eaten by the client's
* chat throttle, and one lost command must not leave the panel stale for
* ever. An unanswered request is asked once more after ANSWER_TIMEOUT and
* then left alone -- a retry that never terminates is a command loop, which
* is worse than a stale panel.
*
* A PLAIN TABLE, NOT `T{ }`: this table is keyed by verb names, and a `T{ }`
* resolves unknown keys through its metatable to the sugar table methods --
* which is exactly the dwbags round-7 bug, paid for once already.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

-- True once the server has said it has no `buffs` verb -- one from before that
-- verb was added. `buffs` is ADDITIVE to protocol 1, so the `d|` version guard
-- cannot see this: the version did not change, and the only thing that says so
-- is the dispatch's own unknown-verb sentence. Without this flag the poll is
-- unstoppable -- it fires off cached roster flags every BUFFS_INTERVAL for as
-- long as anyone is out, and each refusal repaints the window's banner red for
-- a command the player never typed. Detected and reset exactly the way dwbags
-- does its three: off the sentence, cleared on every login line, so a server
-- upgraded underneath a running client gets asked again rather than never.
local buffsUnsupported = false;

local function refresh()
    requested = {};
end

-- A write's response carries the fresh roster, so the roster question is
-- registered as pending without being asked: if the write's answer is lost,
-- needRoster's retry covers it.
local function expectRoster()
    -- `write = true` marks this as a roster the PLAYER's own set/clear is about
    -- to bring back, which the `d|<v>|status` branch below uses to stand down.
    -- needRoster's plain read deliberately does not carry it.
    requested['who'] = { at = os.clock(), answered = false, tries = 1, write = true };
end

local function needRoster()
    local asked = requested['who'];

    if (asked ~= nil) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['who'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dws who');
end

--[[
* Buffs are the one thing in this window that changes without the player
* clicking anything, so they are re-asked on an interval -- but only while a
* member is actually out, so an idle window sends nothing. The lost-answer
* rules are needRoster's; a fresh cycle starts clean rather than inheriting
* the retry count of the one before it.
--]]
local BUFFS_INTERVAL = 15.0;

local function anySummoned()
    for _, member in pairs(state.chars) do
        if (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
            return true;
        end
    end

    return false;
end

local function needBuffs()
    if (buffsUnsupported or not anySummoned()) then
        return;
    end

    local asked = requested['buffs'];

    if (asked ~= nil) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered) then
            if ((os.clock() - asked.at) < BUFFS_INTERVAL) then
                return;
            end
        else
            if (asked.tries >= ANSWER_TRIES) then
                -- A spent retry budget is a lost CYCLE, not a lost feature:
                -- left as a tombstone, this branch returns forever and the
                -- slot rows keep counting down a snapshot that only gets
                -- staler. Drop the tracker once the ordinary interval has
                -- passed and the next cycle starts clean, exactly as the
                -- header above promises.
                if ((os.clock() - asked.at) >= BUFFS_INTERVAL) then
                    requested['buffs'] = nil;
                end

                return;
            end

            if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
                return;
            end

            asked.at    = os.clock();
            asked.tries = asked.tries + 1;
            asked.quiet = true;

            issue('!dws buffs');

            return;
        end
    end

    -- `quiet` marks this as the one request in this addon that NOBODY ASKED
    -- FOR. It repeats on a timer off cached roster flags, so when those flags
    -- are stale -- the squad died, or was dismissed by something this window
    -- did not see -- the server's perfectly correct "nobody is out" refusal
    -- was printed into the player's chat log every fifteen seconds, for a
    -- command they never typed. See the `d|` handler for the other half.
    requested['buffs'] = { at = os.clock(), answered = false, tries = 1, quiet = true };

    issue('!dws buffs');
end

--[[
* Record parsing. Every record is pipe-separated with a single-character
* type. Anything this addon does not recognise is ignored rather than being
* an error: a server newer than the addon must not break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

-- Slots with an `!dws set` in flight, slot -> os.clock() at click time.
-- `assign` never mutates state.chars (the fresh roster is the server's to
-- send), so without this two Add clicks inside one send interval both read
-- the same firstEmptySlot() and the second silently overwrites the first.
-- Cleared when the next roster lands; the age test is the belt for a roster
-- that never comes. A plain table: slot numbers are safe keys, but the T{}
-- sugar rule is applied uniformly.
local pendingSlots = { };

local PENDING_SLOT_WINDOW = 6.0;

-- The engage toggle's ImGui holder (Checkbox writes into a table), re-synced
-- from state.trustEngage every frame it is drawn -- the server's answer is
-- the truth, this is just the widget's clipboard.
local engageUi = T{ false };

-- The follow slider's holder (SliderFloat writes into a table), in yalms.
-- Re-synced from state.follow every frame the player is NOT dragging it;
-- while they are, followEdited holds the clock of their last move, and the
-- typed line goes out only once the slider has rested FOLLOW_SETTLE seconds
-- -- one command per decision, never one per drag tick.
local followUi     = T{ 0 };
local followEdited = nil;

local FOLLOW_SETTLE = 0.5;

-- The alliance row's name box (InputText writes into a table). Purely local
-- until Form is clicked: the name is the one argument !pally needs. 16 is
-- the buffer, not the rule -- FFXI names run 3-15 characters, and the server
-- answers a wrong name with words.
local allyName = T{ '' };

-- The level sync row's own name box, deliberately NOT shared with allyName
-- above: Form wants the other party's LEADER, level sync wants ANY member of
-- the alliance, and a player who typed one and clicked the other would get a
-- refusal they did not earn. Same 16-character buffer for the same reason.
local syncName = T{ '' };

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwsquad.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- A d| envelope IS the answer, whatever version it announced, and
            -- re-asking a server that speaks a layout this addon cannot read
            -- cannot help -- the background buff poll least of all. One shape
            -- across the suite (dwfame, 2026-08-15); gated in
            -- harness_dwsuite.py.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright, and the reset runs
        -- FIRST: handleRecord is called under a pcall, and anything that
        -- throws after `state.inbound` is set must cost one record, not leave
        -- old rows for the records behind it to append to.
        if (state.inbound == 'who') then
            state.chars = T{ };

            -- Wholesale-replace, like the rows: a roster from a server that
            -- stopped sending `t|` (feature turned off) must also take the
            -- toggle with it, not leave a stale one clickable. The `g|` group
            -- state follows for the same reason.
            state.trustEngage = nil;
            state.group       = nil;
            state.follow      = nil;

            -- The fresh roster is the truth about which slots are taken, so
            -- the in-flight latches have done their job.
            pendingSlots = { };

            local asked = requested['who'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        end

        if (state.inbound == 'buffs') then
            state.buffs = T{ };

            local asked = requested['buffs'];

            if (type(asked) == 'table') then
                asked.answered = true;
                asked.at       = os.clock();
            end
        end

        --[[
            A REFUSAL IS AN ANSWER. A bare `fail` arrives in its own
            `d|1|status` envelope, so the buff poll's outstanding request was
            never marked answered by anything -- it retried, exhausted its
            tries, and left the roster still claiming somebody was out, which
            is the state that made it poll in the first place.

            Only the quiet poll is treated this way: a refusal the PLAYER
            provoked belongs in the chat log, loudly.
        --]]
        if (state.inbound == 'status') then
            local writing = requested['who'];
            local asked   = requested['buffs'];

            -- ...and the shared writer wraps EVERY pre-envelope note or refusal
            -- in `d|<v>|status`, whichever command it was answering -- set and
            -- clear included. One of those is not the poll's answer, and
            -- swallowing it costs the player their own refusal sentence AND
            -- blanks every buff row. So a player-provoked write that is still
            -- outstanding takes precedence; the `who` envelope it brings back
            -- marks itself answered, so the shield drops on its own.
            if (type(writing) == 'table' and writing.write and not writing.answered) then
                asked = nil;
            end

            if (type(asked) == 'table' and asked.quiet and not asked.answered) then
                asked.answered = true;
                asked.at       = os.clock();

                state.buffs    = T{ };
                state.quietErr = true;

                -- Re-ask the ROSTER only. A full refresh() would clear the
                -- entry just marked answered, needBuffs would fire again off
                -- the same stale rows, and that is a command loop.
                requested['who'] = nil;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- message saying why a change was refused is worth more than the response
    -- it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- The one refusal that is not worth a red banner: a server from before
        -- the buff read answering the background poll with its unknown-verb
        -- sentence. That means per-member buffs do not exist here yet, so the
        -- addon stops asking and draws no buff rows -- deployment order must
        -- not matter in either direction, and the rest of the window is
        -- untouched by it. Same shape as dwbags' three unsupported verbs.
        if (kind == 'e' and not buffsUnsupported
                and string.find(line, 'unknown verb "buffs"', 1, true) ~= nil) then
            buffsUnsupported = true;

            -- The outstanding request goes with it. Left behind it is an entry
            -- claiming a question is still in flight, and the `d|` handler's
            -- quiet-refusal branch would keep clearing the roster request off
            -- it -- a roster re-ask per refusal, for a poll that is now off.
            requested['buffs'] = nil;
            state.buffs        = T{ };

            return;
        end

        -- Everything after the first pipe, not parts[2]: these carry prose.
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        -- Errors also go to the chat log: the window may already be closed,
        -- and "nothing happened" is the worst possible feedback. The one
        -- exception is the background buff poll, which the player did not ask
        -- for -- its refusal still reaches the window's status bar, just not
        -- their chat log every fifteen seconds.
        if (kind == 'e' and not state.quietErr) then
            print(chat.header('dwsquad'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        -- The roster arriving is the moment "Loading..." stops being true.
        if (state.inbound == 'who' and state.status == 'Loading...') then
            state.status = '';
        end

        state.inbound  = nil;
        state.quietErr = false;

        return;
    end

    -- t|<0|1> -- the caller's trust engage mode, riding the roster.
    if (kind == 't' and state.inbound == 'who') then
        state.trustEngage = (tonumber(parts[2]) == 1) and 1 or 0;

        return;
    end

    -- f|<tenths>|<min>|<max>|<stock> -- the caller's trust follow distance,
    -- riding the roster (1.6.0). Tenths of a yalm throughout; tenths 0 is
    -- "stock". A record whose range does not bracket anything is dropped
    -- rather than drawn: a slider with no honest ends is worse than none.
    if (kind == 'f' and state.inbound == 'who') then
        local follow = T{
            tenths = tonumber(parts[2]) or 0,
            min    = tonumber(parts[3]) or 0,
            max    = tonumber(parts[4]) or 0,
            stock  = tonumber(parts[5]) or 0,
        };

        if (follow.min > 0 and follow.max > follow.min and follow.stock >= follow.min and follow.stock <= follow.max) then
            state.follow = follow;
        end

        return;
    end

    -- g|<in alliance 0|1>|<pending kind party|alliance|''>|<inviter or ''> --
    -- the caller's group state, riding the roster. The pending half is what
    -- draws the "an invite is waiting" line; an empty inviter name (a
    -- cross-process inviter the server could not resolve) still names the
    -- kind, which is the load-bearing part.
    if (kind == 'g' and state.inbound == 'who') then
        local pendingKind = parts[3];

        if (pendingKind ~= 'party' and pendingKind ~= 'alliance') then
            pendingKind = nil;
        end

        state.group = T{
            alliance    = (tonumber(parts[2]) == 1),
            pendingKind = pendingKind,
            pendingFrom = parts[4] or '',
        };

        return;
    end

    if (kind == 'c' and state.inbound == 'who') then
        local charid = tonumber(parts[2]) or 0;

        -- Fields 9 and 10 are bag used/size, which this window has no use
        -- for; field 11 is the squad slot, which is its whole subject.
        --
        -- Fields 12-14 are the experience tail (1.5.0). `or 0` is not
        -- defensive tidiness here, it is the compatibility contract: a server
        -- from before the tail sends ten fields, this reads three absences as
        -- three zeroes, and xpTextOf below renders that as NO CELL AT ALL
        -- rather than as a confident 0 / 0.
        state.chars[charid] = T{
            charid = charid,
            name   = parts[3],
            mjob   = tonumber(parts[4]) or 0,
            mlvl   = tonumber(parts[5]) or 0,
            sjob   = tonumber(parts[6]) or 0,
            slvl   = tonumber(parts[7]) or 0,
            flags  = tonumber(parts[8]) or 0,
            slot   = tonumber(parts[11]) or 0,
            exp    = tonumber(parts[12]) or 0,
            next   = tonumber(parts[13]) or 0,
            xflags = tonumber(parts[14]) or 0,
        };

        return;
    end

    -- b|<charid>|<name>|<id>:<icon>:<remaining>,... -- status effects on one
    -- summoned member. A member's effects can span several records (the
    -- server packs to its line budget), so entries append to the member and
    -- the wholesale reset happens at the `d|` above. A bare record with no
    -- entries is the member announcing it has nothing, which still replaces
    -- whatever was showing.
    if (kind == 'b' and state.inbound == 'buffs') then
        local charid = tonumber(parts[2]) or 0;
        local entry  = state.buffs[charid];

        if (entry == nil) then
            entry = T{ name = parts[3], at = os.clock(), list = T{ } };
            state.buffs[charid] = entry;
        end

        if (parts[4] ~= nil and parts[4] ~= '') then
            for id, icon, rem in string.gmatch(parts[4], '(%-?%d+):(%-?%d+):(%-?%d+)') do
                entry.list:append(T{
                    id   = tonumber(id) or 0,
                    icon = tonumber(icon) or 0,
                    rem  = tonumber(rem) or -1,
                });
            end
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Layout after the 4-byte header: sName[15]
* at 0x08, Mes at 0x17. Any line whose sender is _DWSDATA is ours: it is
* consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwsquad_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwsquad'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Helpers over the roster.
--]]

-- Characters in charid order, which is creation order and is stable.
local function orderedChars()
    local ordered = T{ };

    for _, member in pairs(state.chars) do
        ordered:append(member);
    end

    table.sort(ordered, function (a, b) return a.charid < b.charid; end);

    return ordered;
end

local function jobsOf(member)
    local text = string.format('%s%d', JOB_NAMES[member.mjob] or '?', member.mlvl);

    if (member.sjob ~= 0 and member.slvl ~= 0) then
        text = text .. string.format('/%s%d', JOB_NAMES[member.sjob] or '?', member.slvl);
    end

    return text;
end

local function isSelf(member)
    return bit.band(member.flags, CHAR_SELF) ~= 0;
end

--[[
* THE EXPERIENCE CELL (1.5.0, owner request: see everyone's EXP and TNL in
* /squad). Three states, and the two that are NOT a bar matter more than the
* one that is:
*
*   AT CAP -- a character sitting at its own genkai is not 55999 points from
*   anywhere, it is finished until a limit break. Drawing the number would
*   read as "one point to go" forever, which is the most confidently wrong
*   thing this cell could say.
*
*   MERIT MODE -- the bar is frozen because the experience is going somewhere
*   else entirely (charutils routes the whole award into limit points once a
*   master is past 74 with the mode on). A number here would be a lie about a
*   bar that is never going to move again.
*
*   OTHERWISE -- earned / needed for the MAIN JOB THIS CHARACTER IS WEARING,
*   which is the job its alt-trust fights as and therefore the one the owner
*   is deciding about.
*
* A zero `next` means either the tail was absent (an older server) or the
* character is outside the exp table's 1..99 range. Both draw nothing, which
* is the honest answer for both.
--]]
local XP_CAPPED = 1;
local XP_MERITS = 2;

local function xpTextOf(member)
    if (bit.band(member.xflags or 0, XP_MERITS) ~= 0) then
        return 'merit points';
    end

    if (bit.band(member.xflags or 0, XP_CAPPED) ~= 0) then
        return 'at cap';
    end

    if ((member.next or 0) <= 0) then
        return nil;
    end

    return string.format('%d / %d', member.exp or 0, member.next);
end

-- The same fact at length, for a hover. `next - exp` is the number a player is
-- actually asking for when they ask about TNL, and it is computed here rather
-- than sent: it is the difference of two numbers already on the wire, and a
-- third field would be a third thing free to disagree with the other two.
local function xpTooltipOf(member)
    if (bit.band(member.xflags or 0, XP_MERITS) ~= 0) then
        return 'In merit mode -- experience is going to limit points, not to the next level.';
    end

    if (bit.band(member.xflags or 0, XP_CAPPED) ~= 0) then
        return string.format('%s is at its level cap. A limit break raises it.', member.name);
    end

    if ((member.next or 0) <= 0) then
        return nil;
    end

    return string.format('%s: %d of %d experience as %s%d -- %d to the next level.',
        member.name, member.exp or 0, member.next,
        JOB_NAMES[member.mjob] or '?', member.mlvl,
        math.max(member.next - (member.exp or 0), 0));
end

local function tagOf(member)
    if (isSelf(member)) then
        return '(you)';
    elseif (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
        return '[summoned]';
    elseif (bit.band(member.flags, CHAR_ONLINE) ~= 0) then
        return '[logged in]';
    end

    return '';
end

-- [slot] = member, from the flat character list.
local function slotView()
    local slots = T{ };

    for _, member in pairs(state.chars) do
        if (member.slot >= 1 and member.slot <= MAX_SLOTS) then
            slots[member.slot] = member;
        end
    end

    return slots;
end

local function firstEmptySlot()
    local slots = slotView();
    local now   = os.clock();

    for slot = 1, MAX_SLOTS do
        if (slots[slot] == nil
                and (pendingSlots[slot] == nil
                     or (now - pendingSlots[slot]) >= PENDING_SLOT_WINDOW)) then
            return slot;
        end
    end

    return nil;
end

--[[
* Writes. Every one is the same server command a player could type, queued
* through the throttle, with the roster registered as an expected answer so a
* lost response is re-asked rather than trusted.
--]]
local function assign(slot, member)
    issue(string.format('!dws set %d %s', slot, member.name));
    expectRoster();

    pendingSlots[slot] = os.clock();

    state.status    = string.format('Adding %s to slot %d...', member.name, slot);
    state.statusBad = false;
end

local function unassign(slot, member)
    issue(string.format('!dws clear %d', slot));
    expectRoster();

    state.status    = string.format('Removing %s from slot %d...', member.name, slot);
    state.statusBad = false;
end

--[[
* Rendering.
--]]

-- The dropdown a click on an empty slot opens: every character that is
-- neither the one being played nor already in a slot. EVERY WIDGET ID
-- CARRIES THE CHARACTER ID, because two Selectables with the same label in
-- one combo would merge their click handling.
local function emptySlotCombo(slot)
    imgui.PushItemWidth(-1);

    if (imgui.BeginCombo(string.format('##dwsquad_add_%d', slot), '(empty -- click to add)')) then
        local offered = 0;

        for _, member in ipairs(orderedChars()) do
            if (not isSelf(member) and member.slot == 0) then
                offered = offered + 1;

                if (imgui.Selectable(string.format('%s  %s##add_%d_%d',
                        member.name, jobsOf(member), slot, member.charid))) then
                    assign(slot, member);
                end
            end
        end

        if (offered == 0) then
            imgui.TextDisabled('Every other character is already in the squad.');
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
end

--[[
* Buff display. Names come from the client's own resources -- the server
* sends ids, not strings, for the same reason dwbags' item records do: the
* client already owns the string table. The icon id is looked up first (it is
* the client status id), the server effect id second, and an id neither side
* can name still shows as something rather than vanishing.
--]]
local buffNames = {};

local function buffName(entry)
    local lookup = entry.icon ~= 0 and entry.icon or entry.id;

    if (buffNames[lookup] == nil) then
        local ok, name = pcall(function ()
            return AshitaCore:GetResourceManager():GetString('buffs.names', lookup);
        end);

        if (ok and name ~= nil and #name > 0) then
            buffNames[lookup] = name;
        else
            buffNames[lookup] = string.format('effect %d', entry.id);
        end
    end

    return buffNames[lookup];
end

-- "12:30" under an hour, "2h05" over it; -1 is an effect with no timer and
-- shows bare. The countdown runs client-side off the response's own arrival
-- stamp, so the numbers move between the 15-second refreshes.
local function buffPiece(entry, elapsed)
    if (entry.rem < 0) then
        return buffName(entry);
    end

    local seconds = math.max(entry.rem - math.floor(elapsed), 0);

    if (seconds >= 3600) then
        return string.format('%s %dh%02d', buffName(entry), math.floor(seconds / 3600), math.floor((seconds % 3600) / 60));
    end

    return string.format('%s %d:%02d', buffName(entry), math.floor(seconds / 60), seconds % 60);
end

local function buffTextOf(member)
    if (bit.band(member.flags, CHAR_LOCKED) == 0) then
        return nil;
    end

    local entry = state.buffs[member.charid];

    if (entry == nil or #entry.list == 0) then
        return nil;
    end

    local elapsed = os.clock() - entry.at;
    local pieces  = T{ };

    for _, buff in ipairs(entry.list) do
        pieces:append(buffPiece(buff, elapsed));
    end

    return pieces:concat(', ');
end

local function squadPanel()
    -- NOTE: the third argument is ImGuiChildFlags, not a bool -- Ashita ships
    -- ImGui 1.90+, and a bool here raises a Lua error on every frame.
    imgui.BeginChild('##dwsquad_slots', { 410, 0 }, ImGuiChildFlags_Borders);

    imgui.Text('Your squad');
    imgui.SameLine();
    imgui.TextDisabled('-- summoned as trusts by !squad call');
    imgui.Separator();

    local slots = slotView();

    if (imgui.BeginTable('##dwsquad_slot_table', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        -- WidthFixed throughout, like dwbags and dwgambits: only the flags
        -- those two already use are proven to exist in this environment's
        -- ImGui bindings, and a nil flag global is a Lua error per frame.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 18, 0);
        -- 290, down from 310 (2026-08-16): at 310 the three columns plus the
        -- table's cell padding came to more than the child's 410, and the
        -- overflow was paid by the LAST column -- every Remove button drew
        -- clipped to 'Remov'. 290 still holds the widest single line (a
        -- 15-character name, FFXI's maximum, plus 'WHM71/RDM51' plus
        -- '[logged in]' is ~275) and the buff text below wraps inside the
        -- cell either way; what it buys is the Remove column actually fitting
        -- at every window size, saved inis included.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 290, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 62, 0);

        for slot = 1, MAX_SLOTS do
            local member = slots[slot];

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(string.format('%d.', slot));

            imgui.TableNextColumn();

            if (member ~= nil) then
                imgui.Text(member.name);
                imgui.SameLine();
                imgui.TextDisabled(jobsOf(member));

                local tag = tagOf(member);

                if (tag ~= '') then
                    imgui.SameLine();
                    imgui.TextDisabled(tag);
                end

                -- Experience goes BELOW the name rather than beside it: this
                -- cell is 290 wide and the widest single line it already
                -- holds -- a 15-character name plus WHM71/RDM51 plus
                -- [logged in] -- is about 275. So it joins the buffs on the
                -- second line the cell is already shaped to carry, instead of
                -- becoming a fourth thing competing for the first.
                local xpText = xpTextOf(member);

                if (xpText ~= nil) then
                    imgui.TextDisabled(string.format('XP %s', xpText));

                    local tip = xpTooltipOf(member);

                    if (tip ~= nil and imgui.IsItemHovered()) then
                        imgui.SetTooltip(tip);
                    end
                end

                -- What is on them right now, wrapped inside the column.
                -- PushTextWrapPos(0) wraps at the available width, which in
                -- a fixed-width cell is the cell.
                local buffText = buffTextOf(member);

                if (buffText ~= nil) then
                    imgui.PushTextWrapPos(0);
                    imgui.TextDisabled(buffText);
                    imgui.PopTextWrapPos();
                end
            else
                emptySlotCombo(slot);
            end

            imgui.TableNextColumn();

            if (member ~= nil) then
                if (imgui.SmallButton(string.format('Remove##slot_%d', slot))) then
                    unassign(slot, member);
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Un-register %s from slot %d', member.name, slot));
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

local function charactersPanel()
    imgui.BeginChild('##dwsquad_chars', { 0, 0 }, ImGuiChildFlags_Borders);

    imgui.Text('Your characters');
    imgui.SameLine();
    imgui.TextDisabled('-- everyone on this account');
    imgui.Separator();

    local empty = firstEmptySlot();

    if (imgui.BeginTable('##dwsquad_char_table', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY), { -1, -1 })) then
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        -- 128 rather than 90: the widest pair a character can show is a
        -- two-digit main and a two-digit sub ('WHM71/RDM51'), which clipped
        -- the sub level off at the old width.
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, 128, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 76, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 62, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, member in ipairs(orderedChars()) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(member.name);

            imgui.TableNextColumn();
            imgui.TextDisabled(jobsOf(member));

            -- A SECOND LINE INSIDE THE SAME CELL RATHER THAN A FIFTH COLUMN.
            -- There is under 10px of slack across this table at the window's
            -- 850 default; the window carries ImGuiWindowFlags_NoScrollbar so
            -- an overflow cannot be scrolled away, it is clipped, and the LAST
            -- column pays it (the 2026-08-16 note above: every Remove button
            -- drew as 'Remov'). Widening the default would not help either --
            -- ImGuiCond_FirstUseEver means the saved ini wins for everyone who
            -- has opened this window once, which is everyone. A row that grows
            -- taller costs nobody a clipped button, and this panel already
            -- scrolls vertically.
            local xpText = xpTextOf(member);

            if (xpText ~= nil) then
                imgui.TextDisabled(xpText);

                local tip = xpTooltipOf(member);

                if (tip ~= nil and imgui.IsItemHovered()) then
                    imgui.SetTooltip(tip);
                end
            end

            imgui.TableNextColumn();

            if (member.slot > 0) then
                imgui.TextDisabled(string.format('slot %d', member.slot));
            else
                imgui.TextDisabled(tagOf(member));
            end

            imgui.TableNextColumn();

            if (isSelf(member)) then
                -- The character being played cannot be its own trust; the
                -- server refuses it, so the button is not offered.
                imgui.TextDisabled('');
            elseif (member.slot > 0) then
                if (imgui.SmallButton(string.format('Remove##c_%d', member.charid))) then
                    unassign(member.slot, member);
                end
            elseif (empty ~= nil) then
                if (imgui.SmallButton(string.format('Add##c_%d', member.charid))) then
                    assign(empty, member);
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Add %s to slot %d', member.name, empty));
                end
            else
                imgui.TextDisabled('full');
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

--[[
* The follow distance row (1.6.0): a slider in yalms between the server's
* own ends, the stock mark named beside it, and a Default button while
* something is set. Dragging edits the holder only; the typed `!trustfollow`
* line goes out once the slider has rested, snapped to half a yalm (the
* resolution the command speaks), and only when it differs from what the
* server said -- so a drag that lands where it started sends nothing.
--]]
local function followTenthsOf(yalms)
    -- To tenths -- the server's own unit, and since 1.6.1 its floor is a
    -- tenth (0.1 yalms), so nothing rounds to half yalms any more.
    return math.floor(yalms * 10 + 0.5);
end

local function followRow()
    local follow = state.follow;

    if (followEdited == nil) then
        followUi[1] = (follow.tenths > 0 and follow.tenths or follow.stock) / 10;
    end

    imgui.Text('Trusts follow at');
    imgui.SameLine();
    imgui.PushItemWidth(180);

    if (imgui.SliderFloat('##dwsquad_follow', followUi, follow.min / 10, follow.max / 10, '%.1f yalms')) then
        followEdited = os.clock();
    end

    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(string.format(
            'How close the first trust walks behind you; the rest keep their usual spacing behind it.\n' ..
            'Stock is %.1f yalms. Takes effect on their next step -- no dismiss, no re-call.\n' ..
            'Same as typing !trustfollow <yalms>.', follow.stock / 10));
    end

    imgui.SameLine();

    if (follow.tenths > 0) then
        if (imgui.SmallButton('Default##dwsquad_follow_default')) then
            followEdited  = nil;
            follow.tenths = 0;

            issue('!trustfollow default');

            requested['who'] = nil;
        end
    else
        imgui.TextDisabled('(stock)');
    end

    -- The slider has rested: one line, if it moved anywhere.
    if (followEdited ~= nil and (os.clock() - followEdited) >= FOLLOW_SETTLE) then
        followEdited = nil;

        local tenths = followTenthsOf(followUi[1]);

        if (tenths < follow.min) then
            tenths = follow.min;
        elseif (tenths > follow.max) then
            tenths = follow.max;
        end

        if (tenths ~= follow.tenths and not (follow.tenths == 0 and tenths == follow.stock)) then
            -- Optimistic, like the engage toggle; the roster re-ask below
            -- brings back the server's own `f|` as the settled truth.
            follow.tenths = tenths;

            issue(string.format('!trustfollow %.1f', tenths / 10));

            requested['who'] = nil;
        end
    end
end

local function renderWindow()
    if (imgui.Button('Call squad')) then
        -- The literal typed command: its narrative -- who answered, who was
        -- refused and why -- belongs in the chat log. The outgoing watcher
        -- below sees the line and refreshes the roster behind it.
        issue('!squad call');

        state.status    = 'Calling the squad...';
        state.statusBad = false;
    end

    imgui.SameLine();

    if (imgui.Button('Dismiss')) then
        issue('!squad dismiss');

        state.status    = 'Dismissing...';
        state.statusBad = false;
    end

    imgui.SameLine();

    if (imgui.Button('Refresh')) then
        refresh();
    end

    imgui.SameLine();

    -- A throttled queue has to look like progress rather than like nothing
    -- happening.
    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    else
        imgui.TextDisabled('');
    end

    -- The trust engage toggle -- drawn only when a roster has said what the
    -- current mode IS (the `t|` record). A server without the feature sends
    -- none, and this row simply does not exist, exactly like the buff rows
    -- on a server from before the buff read.
    if (state.trustEngage ~= nil) then
        engageUi[1] = (state.trustEngage == 1);

        if (imgui.Checkbox('Trusts engage when you draw your weapon', engageUi)) then
            local mode = engageUi[1] and 1 or 0;

            -- Optimistic, so the box does not snap back for the second or two
            -- the round trip takes; the literal typed command does the write
            -- (its confirmation belongs in the chat log, like !squad call),
            -- and the roster re-ask below brings back the server's own `t|`
            -- as the settled truth.
            state.trustEngage = mode;

            issue(string.format('!trustengage %i', mode));

            requested['who'] = nil;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'ON:  your trusts attack the moment you engage a mob -- as soon as your weapon comes out.\n' ..
                'OFF: retail behavior -- your trusts hold back until your first swing actually lands.\n' ..
                'Same as typing !trustengage 1 or !trustengage 0.');
        end
    end

    -- The follow distance slider -- drawn only when a roster has said what
    -- the distance IS and what its range is (the `f|` record), the toggle's
    -- deployment-order rule. The value, the ends and the stock mark are all
    -- the server's; this row invents no yalm.
    if (state.follow ~= nil) then
        followRow();
    end

    -- The alliance row -- drawn only when a roster has said what the group
    -- state IS (the `g|` record), the same deployment-order rule as the
    -- toggle above: a server without the group command lane sends none, and
    -- this row simply does not exist. The buttons send the lane's literal
    -- typed commands; their narrative belongs in the chat log, and the
    -- packet_out watcher below re-asks the roster behind every one of them
    -- so the row keeps telling the truth.
    if (state.group ~= nil) then
        imgui.Separator();

        imgui.Text('Alliance');
        imgui.SameLine();
        imgui.TextDisabled('-- up to three parties, eighteen strong with squads out');

        local function sendForm()
            local target = allyName[1]:gsub('^%s+', ''):gsub('%s+$', '');

            if (target == '') then
                state.status    = 'Type the name of the other party\'s leader, then Form.';
                state.statusBad = true;

                return;
            end

            issue(string.format('!pally %s', target));

            state.status    = string.format('Inviting %s\'s party into an alliance...', target);
            state.statusBad = false;
        end

        imgui.PushItemWidth(140);

        if (imgui.InputText('##dwsquad_ally_name', allyName, 16,
                ImGuiInputTextFlags_EnterReturnsTrue)) then
            sendForm();
        end

        imgui.PopItemWidth();

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('The name of the other party\'s leader -- the player you want to ally with.');
        end

        imgui.SameLine();

        if (imgui.Button('Form')) then
            sendForm();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'Invite that player\'s party into an alliance with yours -- same as typing !pally <name>.\n' ..
                'Both of you must lead a party; a summoned squad\'s own party counts.\n' ..
                'An alliance splits what a kill pays: two parties each earn half the experience,\n' ..
                'limit points and capacity points, three parties each earn a third.');
        end

        imgui.SameLine();

        if (imgui.Button('Join')) then
            issue('!join');

            state.status    = 'Accepting the invite...';
            state.statusBad = false;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'Accept the pending invite -- same as typing !join.\n' ..
                'Typing !decline refuses it instead.');
        end

        imgui.SameLine();

        if (imgui.Button('Dissolve')) then
            issue('!pleave');

            state.status    = 'Withdrawing from the alliance...';
            state.statusBad = false;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'Withdraw your party from the alliance -- same as typing !pleave.\n' ..
                'If only one party would remain, the whole alliance dissolves.');
        end

        -- LEVEL SYNC, its own row (owner's request 2026-08-23: "so players
        -- don't have to memorize the command"). Retail's own level-sync menu
        -- is party-scoped and cannot reach across an alliance -- the 0x077
        -- packet is gated to Kind == Party -- so !alliancesync is the only
        -- door to it, and a door nobody can find is a door nobody uses.
        --
        -- The addon is told nothing about the sync state: there is no `y|`
        -- record for it, and adding one would be a protocol change for a
        -- button. So this row deliberately does not TRY to show the current
        -- level -- it sends the typed command and lets the server answer in
        -- the chat log, which is exactly what typing it does. An empty box is
        -- the status question, which is the honest way to ask "what are we
        -- synced to?" without inventing state the addon cannot verify.
        imgui.Text('Level sync');
        imgui.SameLine();
        imgui.TextDisabled('-- the whole alliance fights at one member\'s level');

        local function sendSync()
            local target = syncName[1]:gsub('^%s+', ''):gsub('%s+$', '');

            if (target == '') then
                -- Bare !alliancesync is the status question. Answering it in
                -- chat beats a status line here that could go stale.
                issue('!alliancesync');

                state.status    = 'Asking what the alliance is synced to...';
                state.statusBad = false;

                return;
            end

            issue(string.format('!alliancesync %s', target));

            state.status    = string.format('Syncing the alliance to %s...', target);
            state.statusBad = false;
        end

        imgui.PushItemWidth(140);

        if (imgui.InputText('##dwsquad_sync_name', syncName, 16,
                ImGuiInputTextFlags_EnterReturnsTrue)) then
            sendSync();
        end

        imgui.PopItemWidth();

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'The character everyone should sync DOWN to -- any member of the alliance.\n' ..
                'Leave it empty and press Level Sync to be told what the alliance is synced to now.');
        end

        imgui.SameLine();

        if (imgui.Button('Level Sync')) then
            sendSync();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'Sync every party in the alliance down to that character\'s level --\n' ..
                'same as typing !alliancesync <name>.  Empty box: !alliancesync (asks).\n' ..
                'So friends of different levels can fight the same monsters together.\n' ..
                'Only the alliance leader can set it, the character must be in the\n' ..
                'alliance and at least level 10, and it can never be a trust.\n' ..
                'Syncing dismisses your summons -- call them back and they return\n' ..
                'at the synced level.');
        end

        imgui.SameLine();

        if (imgui.Button('Lift')) then
            issue('!alliancesync off');

            state.status    = 'Lifting the alliance level sync...';
            state.statusBad = false;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'Remove the alliance level sync -- same as typing !alliancesync off.\n' ..
                'It wears off over the next thirty seconds, as retail\'s does.\n' ..
                'Summons already out stay at the synced level until you call them again.');
        end

        -- What is waiting or standing, one quiet line. The invite line is the
        -- reason the record exists: the client suppresses its own dialog for
        -- squad-holders, so without this a pending invite is invisible.
        if (state.group.pendingKind ~= nil) then
            local from = state.group.pendingFrom ~= '' and state.group.pendingFrom or 'another player';

            imgui.TextColored(theme.colors.ok, string.format('%s invite from %s is waiting -- Join accepts it.',
                state.group.pendingKind == 'alliance' and 'An alliance' or 'A party', from));
        elseif (state.group.alliance) then
            imgui.TextDisabled('Your party stands in an alliance -- Dissolve withdraws it.');
            imgui.TextDisabled('Rewards are split between the alliance\'s parties while it stands.');
        end
    end

    -- The message line gets its own row, and errors are red: the reason a
    -- change was refused is the only thing telling a player what to do
    -- instead.
    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Separator();

    squadPanel();
    imgui.SameLine();
    charactersPanel();

    needRoster();
    needBuffs();
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather
* than the addon: an error thrown inside d3d_present is raised sixty times a
* second and the addon host answers a long enough run by unloading the addon.
* Begin and End stay outside the pcall to keep ImGui's window stack balanced;
* the error is reported once and the window closes itself. Everything it does
* is still reachable as !squad commands, so closing it is a real fallback.
--]]
ashita.events.register('d3d_present', 'dwsquad_present', function ()
    -- Before the visibility check: a click issued a moment before the window
    -- was closed still has to reach the server, and walking through your own
    -- squad is not a property of having the window open.
    pumpQueue();
    ghostSquad();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    -- Wide enough for both panels at their fixed widths: the 410 slot panel
    -- plus the character table's four columns, neither of which should have to
    -- clip or scroll horizontally at the default size.
    imgui.SetNextWindowSize({ 850, 340 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Squad##dwsquad', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwsquad'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwsquad'):append(chat.message('Window closed. Everything it does also works as !squad commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1] = true;

    -- Reopening is a fresh start for error reporting too: `reported` only
    -- exists to stop one bad frame printing sixty lines a second.
    state.reported  = false;
    state.status    = 'Loading...';
    state.statusBad = false;

    refresh();
end

--[[
* Watch what the player sends.
*
* Bare `!squad` (and `!squad ui`) is intercepted and opens this window
* instead of printing the server's usage text -- that line is blocked and
* never leaves the client. Every other `!squad` command passes through and
* invalidates the roster behind it, so `!squad set` typed by hand keeps the
* window honest.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped. Stamping
* the player's own line as a send makes the follow-up wait its interval.
--]]
ashita.events.register('packet_out', 'dwsquad_packet_out', function (e)
    -- A native invite answer (0x074) moves the group state without a chat
    -- line ever being typed -- the client's own dialog, where it still
    -- offers one. Re-ask the roster so the `g|` record catches up.
    if (e.id == 0x0074) then
        requested['who'] = nil;

        return;
    end

    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!squad' or lower == '!squad ui' or lower == '!squad window' or lower == '!squad gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dws') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 6) == '!squad') then
        refresh();
    end

    -- A typed !trustengage moves the state behind the toggle, so the next
    -- roster is re-asked to bring the fresh `t|` back -- the same keeping-
    -- honest rule the !squad line above follows. This also fires for the
    -- toggle's own queued send, which costs one redundant re-ask and nothing
    -- else (the toggle already cleared the tracker when it was clicked).
    if (lower:sub(1, 12) == '!trustengage') then
        requested['who'] = nil;
    end

    -- A typed !trustfollow moves the state behind the slider the same way;
    -- the slider's own queued send fires this too, one redundant re-ask.
    if (lower:sub(1, 12) == '!trustfollow') then
        requested['who'] = nil;
    end

    -- Every grouping command moves the state behind the alliance row -- and
    -- because the row's own buttons send these same literal lines through
    -- the queue, this one watcher keeps the `g|` record honest for clicked
    -- and typed alike.
    -- `!alliancesync` rides the same list, and it is the one that matters most:
    -- a sync that LANDS re-levels everyone and, through the LevelSync effect
    -- script, dismisses every summoned member (scripts/effects/level_sync.lua
    -- clearTrusts). Without the re-ask the window would keep drawing the squad
    -- as `[summoned]`, with live buff rows counting down, for characters that
    -- are no longer out -- the most confidently wrong thing a renderer can do.
    for _, prefix in ipairs({ '!pally', '!padd', '!join', '!decline', '!pleave', '!alliancesync' }) do
        if (lower:sub(1, #prefix) == prefix) then
            requested['who'] = nil;

            break;
        end
    end
end);

ashita.events.register('command', 'dwsquad_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Squad`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwsquad' and first ~= '/squad') then
        return;
    end

    e.blocked = true;

    -- `/squad ghost` -- the walk-through layer, out loud. Client-side and
    -- local: it sends nothing, because there is nothing on the server to ask.
    -- It exists because the 1.4.1 version of this layer looked correct and
    -- did nothing, and the only way to tell the three failure modes apart is
    -- to read the numbers off the running client. `after` is read back AFTER
    -- the write, so a row showing `no-clip=no` on the after column means the
    -- client refused or overwrote it, and a row showing `yes` that still
    -- blocks means 0x40 is not the lever for that entity class.
    if (#args > 1 and args[2]:lower() == 'ghost') then
        local rows = ghostWalk(true);

        if (rows == nil or #rows == 0) then
            print(chat.header('dwsquad'):append(chat.error(
                'ghost: nothing to walk through -- no party member sits in the dynamic entity range (0x700-0x8FF). Summon the squad first.')));

            return;
        end

        for _, row in ipairs(rows) do
            print(chat.header('dwsquad'):append(chat.message(string.format(
                '%s %s (0x%03X): flags0 %08X -> %08X, no-clip=%s, pet 0x%03X',
                row.kind, tostring(row.name), row.index, row.before, row.after,
                bit.band(row.after, GHOST_NO_CLIP) ~= 0 and 'yes' or 'NO',
                row.pet))));
        end

        return;
    end

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

ashita.events.register('load', 'dwsquad_load', function ()
    print(chat.header('dwsquad'):append(chat.message('!squad (or /squad) opens the squad window. Everything it does also works typed as !squad commands.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new account view. An incoming invite (0x0DC, the
-- native "X invites you" solicit) moves the group state the moment it lands,
-- so the roster is re-asked and the alliance row's waiting line appears
-- without anyone clicking Refresh -- event-driven, not polled.
ashita.events.register('packet_in', 'dwsquad_zonein', function (e)
    if (e.id == 0x00DC) then
        requested['who'] = nil;

        return;
    end

    if (e.id == 0x000A) then
        state.chars       = T{ };
        state.buffs       = T{ };
        state.trustEngage = nil;
        state.group       = nil;
        state.status      = 'Loading...';
        state.statusBad   = false;

        -- A login is the one moment a server may have been updated underneath
        -- this client, so the capability latch is re-probed rather than held
        -- for the session.
        buffsUnsupported = false;

        refresh();
    end
end);
