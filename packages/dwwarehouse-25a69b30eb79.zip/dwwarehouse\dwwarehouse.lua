--[[
* DriftwoodXI -- dwwarehouse
*
* One account-wide pool of storage, from whichever character you are logged in
* on. Search it, take things out of it, put things into it, and pull a named
* bundle of materials in one click.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It is a sibling of dwbags (`addons/dwbags/dwbags.lua:8-21`) and inherits that
* rule unchanged. It holds no item data of its own, caches nothing to disk
* except the player's own kit names, and has no way to move an item that the
* typed command surface does not already have. Every read is `!dww who|page`
* and every write is `!dww put|take|trash|stashall|pull|pin|unpin`, which are the
* same server-side functions `!warehouse` reaches -- the only difference is
* that they answer in compact records under the sender name _DWWDATA, which
* this addon parses and blocks before the chat log sees them.
*
* WHY THAT MATTERS HERE MORE THAN ANYWHERE. The warehouse is the one container
* whose capacity the server owns outright, so a client that could invent a row
* would be inventing storage. Every rule -- the Rare re-check on the way out,
* the deposit refusals, the capacity ceiling -- lives in the server's C++ and
* runs identically whichever way the command arrived. Nothing below is trusted
* by anything.
*
* THERE IS NO BOUND LANE ANY MORE (2026-08-08). An EX, augmented or NoDelivery
* item used to be stored FOR ITS DEPOSITOR: the row carried that charid and no
* other character on the account could take it back out. The warehouse exists
* to move gear around an account, so that rule was working against the feature
* it lived in, and it is gone -- every row belongs to the account and any
* character on it may withdraw any row. What this addon lost with it: the two
* wire flag bits below, and the disabled Take button they drew.
*
* WHY THE SERVER DOES NOT SEND ITEM NAMES. Same answer as dwbags: this addon is
* inside the client, and the client already has the name, the icon and the type
* of every item in its own DAT resources. Sending them would be paying twice,
* and it is what keeps a packed `w|` record inside the chat buffer the whole
* protocol has to fit through.
*
* THE MODEL IS PAGED, NOT PUSHED. A thousand rows do not fit in one chat line,
* so a full sync is `page 0..N` walked on this addon's own 1.2s pump with a
* progressive render behind it. After that, deltas keep it current: every
* mutation answers with the `w|`/`r|` rows it changed plus a `k|` carrying the
* account's generation counter. A generation this addon did not cause -- a
* second client on the same account moving something -- is a gap, and a gap
* repages rather than guessing.
*
* THE DEPOSIT TAB READS CLIENT MEMORY, WHICH IS THE ONE PLACE IT CAN. Nothing
* on the wire says what is in your own inventory right now; the client knows,
* and `!dww put` names the slot AND the item id precisely so the server can
* refuse a claim that has gone stale ("bag changed"). A wrong read here costs a
* refusal sentence, never a wrong item.
*
* KITS ARE LOCAL AND ALWAYS WILL BE. A kit is a name for a list of item ids and
* quantities; pulling one emits ordinary `!dww pull` lines. The server never
* hears the name and stores nothing about it. They live in Ashita's settings
* library, which already files everything under `<charname>_<serverid>`, so
* per-character separation is free (the dwmacro precedent,
* `addons/dwmacro/dwmacro.lua:85-90`).
*
* TURN IT OFF AND NOTHING IS LOST. `!warehouse` does all of it typed.
--]]

addon.name    = 'dwwarehouse';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.3';
addon.desc    = 'Account-wide virtual storage for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this file,
-- so a blocked line is already flagged by the time they see it.
echo.install();

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load.
*
* This addon is loaded from the launcher's boot script, which runs long before
* the client has a rendering device -- and `d3d.get_device()` at file scope
* makes the whole addon fail to load when it answers nothing. Nothing here
* needs a device until the first icon is drawn, by which point there certainly
* is one. (dwbags.lua:107-116.)
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server uses
-- it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWWDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

--[[
* `w|` flag bits, as the server packs them (DWWAREHOUSE_PLAN.md, wire section).
*
* BITS 8 AND 16 ARE NOT DEFINED HERE AND THAT IS THE POINT. They were
* BOUND_OTHER and BOUND_MINE, two halves of one fact: which side of a bound
* row's lane this character was on. The lane is retired (see the header) and
* the server sets neither bit, so a constant for them here would be a name for
* something that never arrives -- and the next reader would have to disprove it
* before trusting the Take button. They are not re-used for anything else, so
* an addon of any age against a server of any age reads a row the same way.
--]]
local WH_RARE        = 1;
local WH_EX          = 2;
local WH_AUGMENTED   = 4;

-- The client's own inventory, which is the only container `put` reads from.
-- Slot 0 is gil and is deliberately skipped: currency is a deposit refusal on
-- the server (R3) and a row for it would only ever be a button that fails.
local INVENTORY_CONTAINER = 0;
local INVENTORY_SLOTS     = 80;

--[[
* Category chips, keyed on the client DAT item type (Ashita's
* `plugins/sdk/ffxi/enums.h` ItemType).
*
* THESE ARE A FILTER, NOT A TAXONOMY, and the DAT does not have the categories
* a player has in their head. There is no "food" type -- food and medicine are
* both UsableItem -- so the Food chip shows both, which is the honest rendering
* of what the client actually knows. Nothing on the server turns on any of
* this; it narrows a list and that is all.
--]]
local CATEGORIES = {
    { name = 'All',       all   = true },
    { name = 'Weapons',   types = { [4] = true } },
    { name = 'Armor',     types = { [5] = true } },
    { name = 'Materials', types = { [1] = true, [3] = true, [8] = true } },
    { name = 'Food',      types = { [7] = true } },
    { name = 'Other',     other = true },
};

local SORTS = {
    { name = 'Name' },
    { name = 'Qty' },
    -- No timestamp rides the wire. `id` is AUTO_INCREMENT on the warehouse
    -- table, so a bigger row id IS a later deposit -- newest-first is rowid
    -- descending and needs nothing added to the protocol to be true.
    { name = 'Newest' },
};

-- How long one `!dww pull` line may be. RAW_LINE_BUDGET on the server is 130;
-- this leaves room for the verb and a margin, and a kit longer than one line
-- becomes several lines rather than a truncated one.
local PULL_BUDGET = 120;

-- A kit name is a local label and a settings key. Bounded so a pathological
-- one cannot make the settings file unreadable.
local KIT_NAME_MAX = 24;

local state = T{
    open      = T{ false },

    -- The warehouse model. `rows` is keyed by row id and `pins` by item id, so
    -- BOTH ARE PLAIN TABLES -- see the note on `requested` below; a T{} keyed
    -- by data resolves misses through the sugar metatable and hands back a
    -- function where nil was meant.
    rows      = {},
    pins      = {},

    used      = 0,
    cap       = 0,
    gen       = 0,

    -- Paging. `syncGen` is the generation the model on screen was built FROM;
    -- when it falls behind `gen` the model is stale and repages itself.
    -- `sweepGen` is the generation the sweep in flight started under, so a
    -- second client mutating halfway through a twelve-page walk is caught
    -- rather than stitched into a list that was never true at any one moment.
    syncing   = false,
    syncGen   = -1,
    sweepGen  = nil,
    resweeps  = 0,
    nextPage  = nil,
    pages     = nil,
    pagesSeen = 0,
    synced    = false,      -- a full sweep has been asked for this login

    -- Latched by the row-count repair below, so the repage it forces cannot
    -- force another one. See verifyRowCount.
    repaired  = false,

    -- The verb whose response is currently arriving. Records are only accepted
    -- between a `d|` and its `z|`, so a line that arrives on its own -- a
    -- response to something typed by hand, say -- cannot half-fill the UI.
    inbound   = nil,
    status    = 'Press Refresh.',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame

    --[[
        The Trash confirmation's pending row: { rowid, itemid, qty, flags }.
        Non-nil is what keeps the popup open -- ImGui closes a popup on an
        outside click, and the render pass re-opens it while this is set, so
        the only ways past the question are its two buttons. Destroying an
        item is the one click in this window that cannot be taken back.
    ]]
    trashAsk  = nil,

    --[[
        Latched when the server answers that it has no trash verb -- an older
        server core, or a binary older than its Lua. The verb is additive and
        the protocol version deliberately did not move (an old addon reads a
        new server fine either way), so the server's own refusal sentence is
        the only signal there is; once seen, the Trash buttons stop drawing
        rather than every click re-earning the same red banner (the dwbags
        unknown-verb lesson).
    ]]
    noTrash   = false,

    -- Header controls.
    search    = T{ '' },
    category  = 1,
    sort      = 1,
    takeQty   = T{ 1 },
    takeAll   = T{ true },  -- move the whole stack unless told otherwise

    -- Kits.
    kitName   = T{ '' },
};

--[[
* Which deposit rows are ticked, keyed by ITEM ID.
*
* A PLAIN TABLE, NOT `T{ }`, for the reason documented at dwbags.lua:427-442: a
* table indexed by names the caller chooses must not be one that already has
* names of its own. Item ids are numbers here rather than strings, so the
* specific trap is different -- but the rule is the rule, and the next edit
* that keys something by name is the one that pays for breaking it.
--]]
local selection = {};

local icons = T{ };

--[[
* The item icon out of the client's own resources.
*
* Cached because a page is a hundred rows redrawn every frame and
* D3DXCreateTextureFromFileInMemoryEx is not free. gc_safe_release hands back a
* texture that releases itself when Lua collects it, which is what keeps this
* from leaking across a reload. (dwbags.lua:289-330.)
--]]
local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

local function itemName(itemId)
    local item = AshitaCore:GetResourceManager():GetItemById(itemId);

    if (item == nil or item.Name[1] == nil or item.Name[1]:len() == 0) then
        return string.format('item %d', itemId);
    end

    return item.Name[1];
end

local function itemType(itemId)
    local item = AshitaCore:GetResourceManager():GetItemById(itemId);

    return item ~= nil and (item.Type or 0) or 0;
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A TIME.
*
* THE CLIENT RATE-LIMITS OUTGOING CHAT, AND A !dww COMMAND IS A CHAT LINE.
* Firing four of them in a single frame -- which is what a naive "sync
* everything" does, and this addon's whole first sync is a run of them -- gets
* the first one sent and the rest answered with "A command error occurred" by
* the client, before the server ever sees them. So everything queues here and
* drains at one command per SEND_INTERVAL. Duplicates collapse, because asking
* twice for the same page is never useful and the queue is the one place that
* can know. (dwbags.lua:354-403.)
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

--[[
* ONLY QUERIES COLLAPSE. The note above is about reads -- `page` and `who` --
* and asking twice for either really is never useful (needPage and startSync
* both lean on that). But this same queue carries every WRITE the window makes:
* take, trash, put and the kit `pull` lines. Two identical `!dww take 41 12`
* clicks are two commands the player asked for, and issue() has no way to
* report a refusal, so collapsing them silently loses one -- with the queue
* draining at one line per 1.2s, that window is wide enough to click twice in.
--]]
local function issue(command)
    if (command == '!dww who' or command:match('^!dww page ') ~= nil) then
        for _, queued in ipairs(queue) do
            if (queued == command) then
                return;
            end
        end
    end

    queue:append(command);
end

--[[
* Drains one queued command. Called every frame from d3d_present, including
* while the window is shut: a page walk started just before closing it still
* has to finish, and a Take issued a moment before closing still has to reach
* the server.
--]]
local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a frame drawn sixty times a second asks
* once, and so a command lost on the way out is asked again exactly once.
*
* A PLAIN TABLE, NOT `T{ }`, AND IN dwbags THIS COST A ROUND
* (dwbags.lua:427-442): the table is keyed by VERB, and a `T{ }` resolves
* unknown keys through its metatable to the sugar table methods -- so
* `requested['find']` answered a FUNCTION rather than nil, and writing a field
* to it threw. A table indexed by names the caller chooses must not be one that
* already has names of its own.
*
* THE ANSWER IS TRACKED, NOT JUST THE QUESTION, and here that is load-bearing
* rather than defensive: a lost `page` command does not leave one panel stale,
* it stalls the whole sweep and the list simply stops filling in. One retry,
* then left alone -- a retry that never terminates would be a command loop,
* which is worse than a short list.
--]]
local requested = {};

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local function forget()
    requested = {};
end

-- Called from the `d|` record: whatever response is arriving answers the
-- outstanding question for that verb.
local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

-- Ask for one page, at most once -- twice if the first one was never answered.
local function needPage(page)
    local asked = requested['page'];

    if (asked ~= nil and asked.page == page) then
        if (asked.answered) then
            return;
        end

        -- The answer window is checked BEFORE the try count, deliberately. In
        -- the other order the sweep would be declared dead on the very frame
        -- after the second send, with the retry still in flight.
        if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        --[[
            A SWEEP THAT GIVES UP HAS TO SAY SO AND STAND DOWN. The try count
            used to sit in the `or` chain above, which made running out of
            tries a silent `return` -- so needPage did nothing, forever, and
            `state.syncing` stayed TRUE for the rest of the session. That flag
            gates both self-repair paths (the row-count verify and the
            generation-gap repage), so the one state the addon could not
            recover from was the one it entered by failing. Nothing on screen
            said anything either: the "loading N/M" note simply stopped moving.
        --]]
        if (asked.tries >= ANSWER_TRIES) then
            state.syncing   = false;
            state.nextPage  = nil;
            state.status    = string.format('The list stopped at page %d -- press Refresh.', page + 1);
            state.statusBad = true;

            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['page'] = { page = page, at = os.clock(), answered = false, tries = 1 };
    end

    issue(string.format('!dww page %d', page));
end

--[[
* Start a full page sweep.
*
* THE MODEL IS CLEARED HERE RATHER THAN MERGED INTO. A sweep is the answer to
* "what is actually in there", and a row this addon holds that the server no
* longer has -- an alt on the same account took it -- would survive any number
* of merges. Clearing costs a rebuilding list for the length of the sweep,
* which is what the "loading N/M" note is for; keeping a ghost row costs a
* Take button that fails.
--]]
local function startSync()
    forget();

    state.rows      = {};
    state.syncing   = true;
    state.syncGen   = state.gen;
    state.sweepGen  = nil;
    state.nextPage  = 0;
    state.pages     = nil;
    state.pagesSeen = 0;
    state.synced    = true;
    state.status    = 'Reading your warehouse...';
    state.statusBad = false;

    issue('!dww who');
end

-- How many times a sweep may restart itself because the account moved under
-- it. Three is generous for two clients; a fourth means something is churning
-- the account faster than a 1.2s pump can read it, and the honest answer is a
-- sentence rather than a page walk that never ends.
local MAX_RESWEEPS = 3;

--[[
* Does the model hold as many rows as the server says are used?
*
* WHY THIS EXISTS, AND WHY THE GENERATION CHECK CANNOT COVER IT. A response is
* capped at 14 packed `w|` lines (warehouse_core.lua:57-58), which is four to
* six rows each depending on how wide the numbers happen to be. A `stashall`
* that deposits more rows than that produces MORE delta rows than fit, and the
* ones past the cap are simply not sent -- the Mes buffer truncates silently,
* which is the same reason the server packs to well under it in the first
* place. The envelope that arrives is well-formed, its `k|` carries the NEW
* generation, and this addon dutifully records that generation as the one its
* model was built from. So the freshness check agrees with itself while the
* rows it never received are missing: staleness that looks exactly like health.
*
* THE COUNTS ARE THE SAME UNIT, WHICH IS THE WHOLE TRICK. One warehouse row is
* one used slot -- `used` in the `k|` record IS a row count
* (warehouse_core.lua:331) -- so the model disagreeing with it is proof of a
* gap without needing to know what was dropped or why. That makes this a
* general repair rather than a stashall special case: any future response that
* loses a row, for any reason, is caught by the same arithmetic.
*
* ONE REPAGE, NEVER A LOOP. If the sweep that repairs it comes back still
* disagreeing, the honest answer is a sentence -- a repage that re-arms itself
* on a disagreement it cannot fix is a twelve-command page walk every time the
* player touches anything. The latch clears the moment the counts agree, so a
* transient gap costs one sweep and nothing after it.
--]]
local function modelRowCount()
    local count = 0;

    for _ in pairs(state.rows) do
        count = count + 1;
    end

    return count;
end

local function verifyRowCount()
    -- OFF DURING THE INITIAL SWEEP, and off before one has ever been asked
    -- for. A page walk holds a legitimately partial model the whole way
    -- through -- every page's `k|` carries the account's FULL used count while
    -- only the pages seen so far are in `rows` -- so this arithmetic is
    -- guaranteed to disagree and would fire a sweep from inside a sweep.
    if (state.syncing or not state.synced) then
        return;
    end

    local held = modelRowCount();

    if (held == state.used) then
        state.repaired = false;

        return;
    end

    if (state.repaired) then
        -- statusBad, because headerStrip has exactly two colours and this
        -- sentence is a WARNING: rows the server holds are missing from the
        -- list in front of the player. Drawn in the confirmation green it read
        -- like 'Pulled 5.' -- the same failure dwbags.lua:581-587 records
        -- against its protocol-mismatch banner.
        state.status    = string.format('Showing %d of %d stored slots -- press Refresh.', held, state.used);
        state.statusBad = true;

        return;
    end

    state.repaired = true;

    startSync();
end

--[[
* Record parsing.
*
* Every record is pipe-separated with a single-character type. Anything this
* addon does not recognise is ignored rather than being an error: a server
* newer than the addon must not break it, which is the whole reason the `d|`
* record carries a protocol version.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* The verbs whose response leaves the model current at whatever generation it
* carries -- this addon's own write landing, with the `w|`/`r|` rows that made
* it in the same envelope. A generation arriving with one of these is not a gap
* and must not trigger a repage of everything.
*
* `pin` and `unpin` are in the list defensively. R8 says every MUTATION bumps
* the counter and a pin changes no warehouse row, so they should not move it at
* all -- but if a future server counts them, a pin click must not cost a
* twelve-command page walk to discover that nothing changed.
--]]
local DELTA_VERBS = {
    put      = true,
    take     = true,
    trash    = true,
    stashall = true,
    pull     = true,
    pin      = true,
    unpin    = true,
};

--[[
* The subset of those that actually move rows, and so the ones whose closing
* `z|` is worth counting the model against the `k|` line (verifyRowCount).
*
* `pin` and `unpin` are deliberately NOT here even though they are delta verbs.
* A pin changes no warehouse row, so its envelope carries no `w|` at all and
* has nothing to truncate -- counting after one would only be asking the same
* question the last real mutation already answered.
--]]
local MUTATION_VERBS = {
    put      = true,
    take     = true,
    trash    = true,
    stashall = true,
    pull     = true,
};

-- `<rowid>:<itemid>:<qty>:<flags>:<bound>,...`
local function parsePacked(packed)
    for _, entry in ipairs(split(packed, ',')) do
        local bits = split(entry, ':');

        if (#bits >= 5) then
            local rowid = tonumber(bits[1]) or 0;

            if (rowid > 0) then
                -- Upsert by row id: a `w|` from a delta replaces the row a
                -- page walk put there, and the two can never disagree about
                -- which row they mean.
                --
                -- `bound` is a legacy field: it used to be the charid a row
                -- was bound to, and since the lane was retired on 2026-08-08
                -- a migrated server always sends 0. It is still PARSED, and
                -- deliberately -- the record is five fields wide and reading
                -- four of them would silently accept a truncated line as a
                -- whole one. Nothing is drawn from it.
                state.rows[rowid] = {
                    rowid  = rowid,
                    itemid = tonumber(bits[2]) or 0,
                    qty    = tonumber(bits[3]) or 0,
                    flags  = tonumber(bits[4]) or 0,
                    bound  = tonumber(bits[5]) or 0,
                };
            end
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwwarehouse.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.inbound = parts[3];

        -- The pin list is a full refresh, so it is emptied here rather than
        -- being rebuilt from the first `p|` line -- a list long enough to be
        -- split across two lines would otherwise only ever show its tail.
        -- THIS RUNS BEFORE ANYTHING ELSE THE `d|` RECORD DOES, because
        -- handleRecord is called under a pcall: anything that throws above
        -- this line leaves the old rows in place and the records behind it
        -- append to them (dwbags.lua:567-571).
        if (state.inbound == 'who' or state.inbound == 'pin' or state.inbound == 'unpin') then
            state.pins = {};
        end

        answered(state.inbound);

        return;
    end

    -- Status and error lines are accepted whatever the envelope state. They are
    -- the one thing a player must never lose: the sentence saying why a deposit
    -- was refused is worth more than the response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- Everything after the first pipe, not parts[2]: these carry prose and
        -- an item name may contain anything.
        local text = line:sub(3);

        -- The server saying it cannot trash: either sentence latches the
        -- feature off for the session, so the buttons stop drawing instead of
        -- every click re-earning the same refusal. 'unknown verb "trash"' is
        -- an older server core; 'no trash verb' is a newer core over an older
        -- binary. Both mean the same thing to this window.
        if (kind == 'e' and (text:find('unknown verb "trash"', 1, true) ~= nil
                or text:find('no trash verb', 1, true) ~= nil)) then
            state.noTrash  = true;
            state.trashAsk = nil;
        end

        -- A pull shortfall arrives as wire text -- 'short 4102:3,4238:1' --
        -- because the server does not own the name table; this addon does
        -- (the header's naming rule). Translate it before anyone reads it.
        if (kind == 'e') then
            local packed = text:match('^short (.+)$');

            if (packed ~= nil) then
                local names = {};

                for entry in string.gmatch(packed .. ',', '([^,]*),') do
                    local id, qty = entry:match('^(%d+):(%d+)$');

                    if (id ~= nil) then
                        names[#names + 1] = string.format('%s x%s', itemName(tonumber(id)), qty);
                    end
                end

                if (#names > 0) then
                    text = 'The warehouse came up short: ' .. table.concat(names, ', ')
                        .. '. Everything else was pulled.';
                end
            end
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        -- Also to the chat log: the window may not be open, and "nothing
        -- happened" is the worst possible feedback for a refused deposit.
        if (kind == 'e') then
            print(chat.header('dwwarehouse'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        -- The envelope is complete, so this is the first moment the model can
        -- be counted against what the server just said it holds. Cleared
        -- FIRST: verifyRowCount may start a sweep, and a sweep must not begin
        -- with a stale verb still marked as arriving.
        if (MUTATION_VERBS[closed]) then
            verifyRowCount();
        end

        return;
    end

    if (kind == 'k') then
        state.used = tonumber(parts[2]) or 0;
        state.cap  = tonumber(parts[3]) or 0;

        local gen = tonumber(parts[4]) or 0;

        state.gen = gen;

        -- This addon's own write: the same response carries the rows that
        -- changed, so the model is current at the new generation already.
        if (DELTA_VERBS[state.inbound]) then
            state.syncGen = gen;
        end

        -- The first generation a sweep sees is the one that sweep is OF. Later
        -- pages may carry a higher one -- that is another client writing while
        -- this one reads -- and the pages already collected are then a list of
        -- a moment that has passed.
        if (state.syncing and state.sweepGen == nil) then
            state.sweepGen = gen;
        end

        return;
    end

    if (kind == 'w') then
        parsePacked(parts[2]);

        return;
    end

    if (kind == 'r') then
        for _, entry in ipairs(split(parts[2], ',')) do
            local rowid = tonumber(entry) or 0;

            if (rowid > 0) then
                state.rows[rowid] = nil;
            end
        end

        return;
    end

    if (kind == 'p') then
        for _, entry in ipairs(split(parts[2], ',')) do
            local itemid = tonumber(entry) or 0;

            if (itemid > 0) then
                state.pins[itemid] = true;
            end
        end

        return;
    end

    if (kind == 'q') then
        local page  = tonumber(parts[2]) or 0;
        local pages = tonumber(parts[3]) or 0;

        state.pages     = pages;
        state.pagesSeen = page + 1;

        -- CLAMPED BEFORE IT BECOMES A COMMAND. A page count the addon
        -- misparsed would otherwise become an unbounded run of `!dww page N`
        -- lines at one every 1.2 seconds, which is a command loop wearing a
        -- sync's clothes. 1000 rows at 14 per page is 72 pages; 256 is room
        -- for a capacity grant several times over and still terminates.
        if (page + 1 < math.min(pages, 256)) then
            state.nextPage = page + 1;
        else
            state.nextPage = nil;
            state.syncing  = false;

            -- THE SWEEP IS ONLY EVER CLAIMED FOR THE GENERATION IT STARTED
            -- UNDER. If the account moved while it was walking, `gen` is now
            -- ahead of this and the render pass repages -- see MAX_RESWEEPS.
            state.syncGen  = state.sweepGen or state.gen;

            if (state.syncGen == state.gen) then
                state.resweeps = 0;
            end

            -- A sweep FORCED by the row-count check answers that check the
            -- moment it lands, rather than the answer waiting for whenever the
            -- player next moves something. Agreement clears the latch; a
            -- disagreement that survived a full repage takes the sentence,
            -- because `repaired` is already set and verifyRowCount will not
            -- sweep twice for it.
            if (state.repaired) then
                verifyRowCount();
            end
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017.
*
* Layout after the 4-byte header: Kind at 0x04, Attr at 0x05, Data at 0x06,
* sName[15] at 0x08, Mes at 0x17. Any line whose sender is _DWWDATA is ours: it
* is consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwwarehouse_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwwarehouse'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Kits.
*
* Stored as the `id:qty,id:qty` string `pull` already takes, keyed by name. One
* level of nesting with a scalar leaf, which is the shape dwmacro proved the
* settings serializer round-trips (`dwmacro.lua:270-296`) -- a kit is not worth
* finding out where the serializer's nested-array support ends, and the string
* IS the wire form, so there is one representation rather than two.
--]]
local default_settings = T{
    kits = T{ },
};

local config = settings.load(default_settings);

settings.register('settings', 'dwwarehouse_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end

    settings.save();
end);

local function kitNames()
    local names = T{ };

    if (type(config.kits) == 'table') then
        for name, _ in pairs(config.kits) do
            if (type(name) == 'string' and type(config.kits[name]) == 'string') then
                names:append(name);
            end
        end
    end

    table.sort(names);

    return names;
end

-- A kit name is a settings key and a widget id. Anything outside plain text
-- would make one of those two ambiguous, so it is trimmed to plain text here
-- rather than being rejected with a sentence nobody would read.
local function cleanKitName(raw)
    local name = tostring(raw or ''):gsub('[^%w%s%-]', ''):gsub('^%s+', ''):gsub('%s+$', '');

    return name:sub(1, KIT_NAME_MAX);
end

--[[
* Turn `id:qty,...` into `!dww pull` lines, none longer than PULL_BUDGET.
*
* SPLITTING IS THE POINT. The server's line budget is 130 bytes and a kit is
* whatever the player put in it, so a twenty-item kit has to become several
* commands. They queue like everything else, one per interval, and each one is
* answered on its own terms -- a shortfall in the second line does not undo the
* first, which is exactly what `pull`'s per-item shortfall reporting is for.
--]]
local function pullCommands(entries)
    local commands = T{ };
    local prefix   = '!dww pull ';
    local current  = '';

    for _, entry in ipairs(entries) do
        local piece     = string.format('%d:%d', entry.id, entry.qty);
        local candidate = (current == '') and piece or (current .. ',' .. piece);

        if (#prefix + #candidate > PULL_BUDGET) then
            if (current ~= '') then
                commands:append(prefix .. current);
            end

            current = piece;
        else
            current = candidate;
        end
    end

    if (current ~= '') then
        commands:append(prefix .. current);
    end

    return commands;
end

-- `id:qty,...` -> { { id, qty }, ... }, every field clamped. R7 applies to the
-- addon's own settings file too: it is a text file a player can edit.
local function parseKit(packed)
    local entries = T{ };

    for _, entry in ipairs(split(tostring(packed or ''), ',')) do
        local bits = split(entry, ':');

        if (#bits >= 2) then
            local id  = math.floor(tonumber(bits[1]) or 0);
            local qty = math.floor(tonumber(bits[2]) or 0);

            if (id > 0 and id < 65535) then
                entries:append({ id = id, qty = math.max(math.min(qty, 99), 1) });
            end
        end
    end

    return entries;
end

local function saveKit(name, entries)
    local clean = cleanKitName(name);

    if (clean == '' or #entries == 0) then
        -- SAY WHY. Both call sites put every side effect inside
        -- `if (saveKit(...))` with no else, so a bare `return false` made the
        -- button look dead -- and these two are the likeliest first attempts:
        -- an empty name box (its default) and a name typed with nothing ticked.
        state.status    = (clean == '') and 'Name the kit first.'
            or 'Nothing to save -- tick items on the Deposit tab.';
        state.statusBad = true;

        return false;
    end

    -- The settings file is a text file a player can edit, and an edit that
    -- removed the `kits` table would otherwise throw inside the render pcall
    -- and close the window. A missing table is an empty one.
    if (type(config.kits) ~= 'table') then
        config.kits = T{ };
    end

    local parts = T{ };

    for _, entry in ipairs(entries) do
        parts:append(string.format('%d:%d', entry.id, entry.qty));
    end

    config.kits[clean] = table.concat(parts, ',');
    settings.save();

    return true;
end

--[[
* Rendering
--]]

--[[
* Your own inventory, read straight out of client memory.
*
* THE SLOT AND THE ITEM ID BOTH GO ON THE WIRE and the server checks them
* against each other (R3, "bag changed"). This read can be stale -- a trade
* completing between the frame that drew the row and the frame that clicked it
* is enough -- and that staleness is precisely what the pair catches. So there
* is no cache here: the rows are re-read every frame the tab is open, and the
* worst outcome of a race is a refusal sentence.
--]]
local function inventoryRows()
    local rows = T{ };

    local memory = AshitaCore:GetMemoryManager();

    if (memory == nil) then
        return rows;
    end

    local inventory = memory:GetInventory();

    if (inventory == nil) then
        return rows;
    end

    for slot = 1, INVENTORY_SLOTS do
        local item = inventory:GetContainerItem(INVENTORY_CONTAINER, slot);

        if (item ~= nil and item.Id ~= nil and item.Id ~= 0 and item.Id ~= 65535
                and (item.Count or 0) > 0) then
            rows:append(T{
                slot   = slot,
                itemid = item.Id,
                qty    = item.Count,
                flags  = item.Flags or 0,
            });
        end
    end

    return rows;
end

--[[
* Kit entries for the bag, MERGED BY ITEM rather than one per inventory slot.
*
* The selection model is by item id -- `selection[row.itemid]` -- but both Save
* buttons walked inventory ROWS, so an item spread over three slots wrote three
* entries with the same id from a single tick, and a kit that said "99 arrows"
* was really three lines that happened to add up. The stated contract further
* up this file ("one entry per item, at the quantity you hold") was the thing
* that was true of neither button.
*
* Merged and then re-split into <=99 chunks, because a single id:qty pair is
* capped at 99 on BOTH sides (this addon clamps, and the server's pull caps at
* 99 too). A plain merge-then-clamp would quietly turn two full stacks into
* one. `filter` nil means the whole bag.
--]]
local function kitEntriesFromBag(filter)
    local order  = T{ };
    local totals = { };

    for _, row in ipairs(inventoryRows()) do
        if (filter == nil or filter[row.itemid]) then
            if (totals[row.itemid] == nil) then
                order:append(row.itemid);
            end

            totals[row.itemid] = (totals[row.itemid] or 0)
                + math.max(math.floor(tonumber(row.qty) or 1), 1);
        end
    end

    local entries = T{ };

    for _, id in ipairs(order) do
        local left = totals[id];

        while (left > 0) do
            entries:append({ id = id, qty = math.min(left, 99) });
            left = left - 99;
        end
    end

    return entries;
end

--[[
* How many of a row to move: the whole stack by default, or the spin box.
*
* THE FLOOR IS 1 AND IT IS APPLIED HERE AS WELL AS AT THE WIDGET. `InputInt`
* takes any integer it is given, including negative ones, and a negative
* quantity has no meaning in either direction -- it is not "move backwards", it
* is a number that lands in a `uint32` on the server as four billion. The
* widget clamps what the player can see and this clamps what the command can
* carry, so the two would both have to fail for a nonsense number to be sent.
* (dwbags.lua:996-1016; the map-side lesson is R7.)
--]]
local function moveCount(qty)
    local held = math.max(math.floor(tonumber(qty) or 1), 1);

    if (state.takeAll[1]) then
        return held;
    end

    local wanted = math.floor(tonumber(state.takeQty[1]) or 1);

    return math.max(math.min(wanted, held), 1);
end

local function matchesCategory(itemid)
    local category = CATEGORIES[state.category];

    if (category == nil or category.all) then
        return true;
    end

    local kind = itemType(itemid);

    if (category.other) then
        for _, other in ipairs(CATEGORIES) do
            if (other.types ~= nil and other.types[kind]) then
                return false;
            end
        end

        return true;
    end

    return category.types[kind] == true;
end

local function matchesSearch(itemid)
    local query = tostring(state.search[1] or '');

    if (query == '') then
        return true;
    end

    -- Plain find, not a pattern: an item name may contain '(' or '-' and a
    -- player typing one must not get a Lua pattern error for their trouble.
    return itemName(itemid):lower():find(query:lower(), 1, true) ~= nil;
end

-- The model, filtered and ordered, rebuilt per frame. Cheap enough at a
-- thousand rows and it is the only way a search box can filter as you type
-- without a second copy of the model to fall out of date.
local function visibleRows()
    local rows = T{ };

    for _, row in pairs(state.rows) do
        if (matchesCategory(row.itemid) and matchesSearch(row.itemid)) then
            rows:append(row);
        end
    end

    local mode = SORTS[state.sort] ~= nil and SORTS[state.sort].name or 'Name';

    -- Every comparator ends on row id. Lua's table.sort is not stable, so two
    -- rows that compare equal can swap places on every sort -- and sorting in
    -- the render pass means that is sixty times a second, which is the flicker
    -- that made dwbags' Gear tab unreadable (dwbags.lua:781-787).
    table.sort(rows, function (a, b)
        if (mode == 'Newest') then
            return a.rowid > b.rowid;
        end

        if (mode == 'Qty' and a.qty ~= b.qty) then
            return a.qty > b.qty;
        end

        local nameA = itemName(a.itemid);
        local nameB = itemName(b.itemid);

        if (nameA ~= nameB) then
            return nameA < nameB;
        end

        return a.rowid < b.rowid;
    end);

    return rows;
end

-- The greyed tags beside a name, rendered the way dwbags renders 'worn' and
-- 'placed' (dwbags.lua:1077-1095): a fact about the row, in the place a button
-- would otherwise be misread as available.
local function rowTags(row)
    local tags = T{ };

    if (bit.band(row.flags, WH_RARE) ~= 0) then
        tags:append('rare');
    end

    if (bit.band(row.flags, WH_EX) ~= 0) then
        tags:append('ex');
    end

    if (bit.band(row.flags, WH_AUGMENTED) ~= 0) then
        tags:append('aug');
    end

    -- A 'bound' tag stood here, drawn from bits 8/16. Both retired with the
    -- lane on 2026-08-08; the 'ex' and 'aug' tags above still say everything
    -- true about such a row, and neither of them implies it cannot move.

    return table.concat(tags, ' ');
end

local function capacityBar()
    local cap      = math.max(state.cap, 1);
    local fraction = math.min(state.used / cap, 1.0);

    imgui.PushItemWidth(220);
    -- 22 tall rather than 14: the overlay text is drawn at the font's full
    -- line height, so a bar shorter than that clipped the '323 / 1000 slots'
    -- label top and bottom.
    imgui.ProgressBar(fraction, { 220, 22 }, string.format('%d / %d slots', state.used, state.cap));
    imgui.PopItemWidth();

    imgui.SameLine();
end

--[[
* The header strip: capacity, freshness, and the three controls that narrow the
* list. They live above the tab bar rather than inside the Warehouse tab
* because the search box is the fastest way to find a row to Take AND the
* fastest way to check whether something is already stored before stashing a
* second copy -- it belongs to both tabs, so it belongs to neither.
--]]
local function headerStrip()
    capacityBar();

    if (imgui.Button('Refresh##dww_refresh')) then
        -- A player pressing this is saying "try again", so the resweep budget
        -- AND the row-count latch both start over: neither give-up sentence
        -- may be permanent.
        state.resweeps = 0;
        state.repaired = false;

        startSync();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Ask the server for the whole list again.\n'
            .. 'Normally unnecessary -- every change answers with the rows it changed.');
    end

    imgui.SameLine();

    -- A generation this addon did not cause: another client on the same
    -- account moved something. Said out loud AND repaired on the next frame,
    -- because a number that is quietly wrong is the worst shape a bug has.
    if (state.gen ~= state.syncGen and not state.syncing) then
        imgui.TextColored(theme.colors.warn, 'Changed elsewhere -- refreshing.');
    elseif (state.syncing) then
        imgui.TextDisabled(string.format('loading %d/%s...',
            state.pagesSeen, state.pages ~= nil and tostring(state.pages) or '?'));
    elseif (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    else
        imgui.TextDisabled('');
    end

    -- THE MESSAGE LINE GETS ITS OWN ROW, AND ERRORS ARE RED. Every refusal is a
    -- rule with a reason -- capacity, Rare on the way out, a full inventory --
    -- and that reason is the only thing telling a player what to do instead
    -- (dwbags.lua:1777-1783).
    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Text('Find:');
    imgui.SameLine();
    imgui.PushItemWidth(200);

    -- No EnterReturnsTrue: the filter is local, so it applies as it is typed
    -- and nothing is sent for it. The one control in this window that costs
    -- the server nothing should also cost the player no keystroke.
    imgui.InputText('##dww_search', state.search, 64);
    imgui.PopItemWidth();

    -- One click back to the whole list. Only drawn while there is something to
    -- clear, so the header does not carry a dead button the rest of the time.
    if (state.search[1] ~= '') then
        imgui.SameLine();

        if (imgui.SmallButton('x##dww_search_clear')) then
            state.search[1] = '';
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Clear the search.');
        end
    end

    for index, category in ipairs(CATEGORIES) do
        imgui.SameLine();

        local label = category.name;

        if (state.category == index) then
            label = '[' .. label .. ']';
        end

        if (imgui.SmallButton(string.format('%s##dww_cat_%d', label, index))) then
            state.category = index;
        end
    end

    imgui.SameLine();
    imgui.PushItemWidth(90);

    local sortName = SORTS[state.sort] ~= nil and SORTS[state.sort].name or 'Name';

    if (imgui.BeginCombo('##dww_sort', sortName)) then
        for index, sort in ipairs(SORTS) do
            if (imgui.Selectable(sort.name, state.sort == index)) then
                state.sort = index;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    imgui.SameLine();
    imgui.Checkbox('Whole stack##dww_all', state.takeAll);

    if (not state.takeAll[1]) then
        imgui.SameLine();
        imgui.PushItemWidth(90);
        imgui.InputInt('##dww_qty', state.takeQty, 1, 10);
        imgui.PopItemWidth();

        -- ImGui's InputInt has no lower bound of its own -- the minus button
        -- and the keyboard will both take it below zero and leave it there --
        -- so the bound is applied to the buffer every frame. Done here as well
        -- as inside moveCount so the player never sees a number the window
        -- would not act on.
        if ((tonumber(state.takeQty[1]) or 1) < 1) then
            state.takeQty[1] = 1;
        end
    end
end

local function warehouseTab()
    local rows = visibleRows();

    if (state.cap == 0 and not state.syncing) then
        imgui.TextDisabled('Nothing loaded yet. Refresh asks the server for the list.');
    end

    -- Said only when the filter is actually hiding something: 'showing all N'
    -- is noise, but a search that matched nothing looks exactly like an empty
    -- warehouse without this line.
    local held = modelRowCount();

    if (#rows < held) then
        imgui.TextDisabled(string.format('Showing %d of %d stored items (filtered).', #rows, held));
    end

    if (imgui.BeginTable('##dww_rows', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthFixed, 300, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 45, 0);
        imgui.TableSetupColumn('Tags', ImGuiTableColumnFlags_WidthFixed, 130, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 150, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);
            imgui.Text(itemName(row.itemid));

            imgui.TableNextColumn();
            imgui.Text(row.qty > 1 and string.format('x%d', row.qty) or '');

            imgui.TableNextColumn();

            local tags = rowTags(row);

            if (tags ~= '') then
                imgui.TextDisabled(tags);
            else
                imgui.Text('');
            end

            imgui.TableNextColumn();

            -- EVERY WIDGET ID CARRIES THE ROW ID. Two rows of the same item --
            -- which is the normal outcome of depositing a stack twice -- would
            -- otherwise share a `##<itemid>` suffix, and ImGui answers a
            -- conflicting id by merging their click handling
            -- (dwbags.lua:1018-1026).
            --
            -- EVERY ROW GETS A TAKE BUTTON NOW. A row whose bit 8 was set used
            -- to draw the words 'another character' and a tooltip instead, and
            -- that branch went with the lane on 2026-08-08: the server refuses
            -- no row on ownership grounds short of the account itself, and the
            -- account's rows are the only rows this window is ever sent.
            local count = moveCount(row.qty);

            if (imgui.SmallButton(string.format('Take##t%d', row.rowid))) then
                issue(string.format('!dww take %d %d', row.rowid, count));
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Take %d into your inventory.', count));
            end

            -- NEVER SENDS ON ITS OWN. The click only records what the player
            -- pointed at; the command is issued by the confirmation popup
            -- below, which is the whole reason the popup exists -- this is the
            -- one button in the window whose mistake cannot be undone.
            if (not state.noTrash) then
                imgui.SameLine();

                if (imgui.SmallButton(string.format('Trash##x%d', row.rowid))) then
                    state.trashAsk = {
                        rowid  = row.rowid,
                        itemid = row.itemid,
                        qty    = count,
                        flags  = row.flags,
                    };
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Throw %d away, straight from the warehouse.\n'
                        .. 'No inventory space needed. Asks first -- this cannot be undone.', count));
                end
            end
        end

        imgui.EndTable();
    end

    --[[
        The trash confirmation. OPENED EVERY FRAME THE QUESTION IS PENDING:
        ImGui closes a popup on any outside click, and silently dropping the
        question would leave the player unsure whether the item is gone. While
        `trashAsk` is set the popup re-opens, so the only ways out are the two
        buttons -- which is exactly the modality a destructive action wants.
        Opened HERE, outside the table, because BeginTable pushes an ID scope
        and a popup opened inside it could not be begun outside it.
    ]]
    if (state.trashAsk ~= nil) then
        imgui.OpenPopup('##dww_confirm_trash');
    end

    if (imgui.BeginPopup('##dww_confirm_trash')) then
        local ask = state.trashAsk;

        if (ask == nil) then
            imgui.CloseCurrentPopup();
        else
            drawIcon(ask.itemid, 20);
            imgui.Text(string.format('Throw away %s x%d?', itemName(ask.itemid), ask.qty));

            -- The tags are the last chance to notice this is the irreplaceable
            -- copy. Red, because 'rare' next to a delete button is a warning,
            -- not a fact.
            if (bit.band(ask.flags, WH_RARE + WH_EX + WH_AUGMENTED) ~= 0) then
                local tags = T{ };

                if (bit.band(ask.flags, WH_RARE) ~= 0) then tags:append('rare'); end
                if (bit.band(ask.flags, WH_EX) ~= 0) then tags:append('ex'); end
                if (bit.band(ask.flags, WH_AUGMENTED) ~= 0) then tags:append('augmented'); end

                imgui.TextColored(theme.colors.err,
                    string.format('This item is %s. It may be hard or impossible to replace.',
                        table.concat(tags, ', ')));
            end

            imgui.TextDisabled('It is destroyed for good. Nothing can bring it back.');

            if (imgui.Button(string.format('Throw away##dww_trash_yes'))) then
                issue(string.format('!dww trash %d %d', ask.rowid, ask.qty));

                state.trashAsk = nil;
                imgui.CloseCurrentPopup();
            end

            imgui.SameLine();

            if (imgui.Button('Cancel##dww_trash_no')) then
                state.trashAsk = nil;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end
end

local function depositTab()
    local rows = inventoryRows();

    if (imgui.Button('Stash All##dww_stashall')) then
        imgui.OpenPopup('##dww_confirm_stashall');
    end

    imgui.SameLine();
    imgui.TextDisabled('Everything the server will take, in one command.');

    -- The confirmation is a popup rather than a second click on the same
    -- button, because the list this empties is the one a player is holding and
    -- the copy below is the only place the exceptions are written down.
    if (imgui.BeginPopup('##dww_confirm_stashall')) then
        imgui.Text('Stash everything in your inventory?');
        imgui.TextDisabled('Skipped, and left in your bag:');
        imgui.TextDisabled('  equipped, bazaared or reserved items');
        imgui.TextDisabled('  rare, EX and augmented copies');
        imgui.TextDisabled('  linkshells you are wearing, gil and currency');
        imgui.TextDisabled('  anything you have pinned on this tab');
        imgui.TextDisabled('It stops at capacity and says how many it took.');

        if (imgui.Button('Stash All##dww_confirm_yes')) then
            issue('!dww stashall');
            imgui.CloseCurrentPopup();
        end

        imgui.SameLine();

        if (imgui.Button('Cancel##dww_confirm_no')) then
            imgui.CloseCurrentPopup();
        end

        imgui.EndPopup();
    end

    if (imgui.BeginTable('##dww_deposit', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 26, 0);
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthFixed, 280, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 45, 0);
        imgui.TableSetupColumn('Pin', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            -- The tick is what "save selection as kit" reads. Keyed by SLOT in
            -- the widget id and by ITEM ID in the set: two slots holding the
            -- same item are one line in a kit, and a kit names items.
            local ticked = T{ selection[row.itemid] == true };

            if (imgui.Checkbox(string.format('##dww_sel_%d', row.slot), ticked)) then
                selection[row.itemid] = ticked[1] and true or nil;
            end

            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);
            imgui.Text(itemName(row.itemid));

            imgui.TableNextColumn();
            imgui.Text(row.qty > 1 and string.format('x%d', row.qty) or '');

            imgui.TableNextColumn();

            local pinned = state.pins[row.itemid] == true;

            if (imgui.SmallButton(string.format('%s##dww_pin_%d', pinned and 'unpin' or 'pin', row.slot))) then
                issue(string.format('!dww %s %d', pinned and 'unpin' or 'pin', row.itemid));
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Pinned items are never taken by Stash All.\n'
                    .. 'Pins are per character -- a mule and a main stash differently.');
            end

            imgui.TableNextColumn();

            local count = moveCount(row.qty);

            if (imgui.SmallButton(string.format('Stash##d%d', row.slot))) then
                issue(string.format('!dww put %d %d %d', row.slot, row.itemid, count));
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Put %d into the warehouse.', count));
            end
        end

        imgui.EndTable();
    end
end

local function kitsTab()
    imgui.TextDisabled('A kit is a name for a list of items. Pulling one sends ordinary pull');
    imgui.TextDisabled('commands -- the server never hears the name, and nothing is stored there.');
    imgui.TextDisabled('Kits are kept per character, on this machine only.');

    imgui.PushItemWidth(200);
    imgui.InputText('##dww_kitname', state.kitName, KIT_NAME_MAX + 1);
    imgui.PopItemWidth();

    imgui.SameLine();

    if (imgui.Button('Save selection##dww_kit_sel')) then
        local entries = kitEntriesFromBag(selection);

        if (saveKit(state.kitName[1], entries)) then
            state.status    = string.format('Saved kit "%s".', cleanKitName(state.kitName[1]));
            state.statusBad = false;
            state.kitName[1] = '';
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Everything ticked on the Deposit tab, at the quantities you hold.');
    end

    imgui.SameLine();

    if (imgui.Button('Save whole bag##dww_kit_bag')) then
        local entries = kitEntriesFromBag(nil);

        if (saveKit(state.kitName[1], entries)) then
            state.status     = string.format('Saved kit "%s".', cleanKitName(state.kitName[1]));
            state.statusBad  = false;
            state.kitName[1] = '';
        end
    end

    imgui.Separator();

    local names = kitNames();

    if (#names == 0) then
        imgui.Text('No kits yet. Name one above and save it.');

        return;
    end

    if (imgui.BeginTable('##dww_kits', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Kit', ImGuiTableColumnFlags_WidthFixed, 180, 0);
        imgui.TableSetupColumn('Contents', ImGuiTableColumnFlags_WidthFixed, 380, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 140, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for index, name in ipairs(names) do
            local entries = parseKit(config.kits[name]);

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(name);

            imgui.TableNextColumn();

            local shown = T{ };

            for position = 1, math.min(#entries, 6) do
                shown:append(string.format('%s x%d', itemName(entries[position].id), entries[position].qty));
            end

            if (#entries > 6) then
                shown:append(string.format('and %d more', #entries - 6));
            end

            imgui.TextDisabled(table.concat(shown, ', '));

            imgui.TableNextColumn();

            -- Widget ids carry the kit's INDEX, not its name: a name is player
            -- text and '##' inside one would split the id ImGui parses.
            if (imgui.SmallButton(string.format('Pull##dww_pull_%d', index))) then
                for _, command in ipairs(pullCommands(entries)) do
                    issue(command);
                end
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Take everything in this kit out of the warehouse.\n'
                    .. 'Long kits become several commands, one per 1.2 seconds.\n'
                    .. 'Anything short is reported item by item.');
            end

            imgui.SameLine();

            if (imgui.SmallButton(string.format('Delete##dww_del_%d', index))) then
                config.kits[name] = nil;
                settings.save();
            end
        end

        imgui.EndTable();
    end
end

local function renderWindow()
    headerStrip();

    imgui.Separator();

    if (imgui.BeginTabBar('##dww_tabs')) then
        if (imgui.BeginTabItem('Warehouse')) then
            warehouseTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Deposit')) then
            depositTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Kits')) then
            kitsTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather than
* the addon.
*
* An error thrown inside a d3d_present handler is raised on EVERY frame -- sixty
* times a second -- and the addon host answers a long enough run of them by
* unloading the addon. So: Begin and End stay OUTSIDE the pcall, which is what
* keeps ImGui's window stack balanced whatever happens in between; the error is
* reported once; and the window closes itself. Everything the window does is
* still reachable as !warehouse commands, so closing it is a real fallback
* rather than a dead end. (dwbags.lua:1875-1889.)
--]]
ashita.events.register('d3d_present', 'dwwarehouse_present', function ()
    -- Before the visibility check: a page walk started a moment before the
    -- window was closed still has to finish, and a Take still has to be sent.
    pumpQueue();

    -- The sweep drives itself from here rather than from the record handler, so
    -- a page command lost on the way out is re-asked (once) instead of leaving
    -- the list half-filled forever.
    if (state.syncing and state.nextPage ~= nil) then
        needPage(state.nextPage);
    end

    -- A generation the model on screen was not built from: another client on
    -- this account moved something, or moved it while the last sweep was
    -- walking. Repaired here rather than on a timer -- the gap is only visible
    -- once a response has landed, and startSync is idempotent because issue()
    -- collapses duplicate commands.
    if (not state.syncing and state.synced and state.gen ~= state.syncGen) then
        if (state.resweeps < MAX_RESWEEPS) then
            state.resweeps = state.resweeps + 1;

            startSync();
        else
            state.status    = 'The account is being changed elsewhere. Press Refresh when it settles.';
            state.statusBad = true;
            state.syncGen   = state.gen;
        end
    end

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    imgui.SetNextWindowSize({ 840, 480 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Warehouse##dwwarehouse', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwwarehouse'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwwarehouse'):append(chat.message('Window closed. Everything it does also works as !warehouse commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Watch what the player sends, so the window keeps up with commands typed
* outside it. 0x00B5 is Kind at 0x04, a pad byte, then the message at 0x06.
*
* Only `!warehouse` is matched for invalidation, not `!dww`: the addon's own
* commands already answer with what they changed.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE, though. The
* client's rate limit is on chat, not on this addon, so a page request fired in
* the same frame as something the player typed is the one that gets dropped --
* and on this addon that costs a whole sweep, not one panel. Stamping the
* player's own line as a send makes the follow-up wait its interval instead of
* racing it. (dwbags.lua:1935-1953.)
--]]
ashita.events.register('packet_out', 'dwwarehouse_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dww') then
        lastSend = os.clock();
    end

    if (message:lower():sub(1, 10) == '!warehouse') then
        startSync();
    end
end);

ashita.events.register('command', 'dwwarehouse_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/warehouse' and args[1] ~= '/wh')) then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        state.resweeps = 0;
        state.repaired = false;

        startSync();

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported` only
        -- exists to stop one bad frame printing sixty lines a second, not to
        -- silence a different error a week later in the same session.
        state.reported = false;

        -- ONCE PER LOGIN, not once per open. The model is kept current by the
        -- deltas every command answers with, so a second open has nothing to
        -- ask for -- and asking anyway would be a twelve-command page walk for
        -- a window the player only wanted to glance at. Refresh is the button
        -- for doing it on purpose; a generation gap does it automatically.
        if (not state.synced) then
            startSync();
        end
    end
end);

ashita.events.register('load', 'dwwarehouse_load', function ()
    print(chat.header('dwwarehouse'):append(chat.message('/warehouse opens your account storage. Everything it does also works typed as !warehouse.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new pin list and a new view. (The pool itself is
-- the account's and does not change with the character -- pins are per
-- character, which is what makes this reset necessary rather than tidy.)
ashita.events.register('packet_in', 'dwwarehouse_zonein', function (e)
    if (e.id == 0x000A) then
        state.rows      = {};
        state.pins      = {};
        state.used      = 0;
        state.cap       = 0;
        state.gen       = 0;
        state.syncing   = false;
        state.syncGen   = -1;
        state.sweepGen  = nil;
        state.resweeps  = 0;
        state.nextPage  = nil;
        state.pages     = nil;
        state.pagesSeen = 0;
        state.synced    = false;
        state.repaired  = false;
        state.inbound   = nil;
        state.status    = 'Press Refresh.';
        state.statusBad = false;

        -- A pending trash question is about a row id from before the zone
        -- line; the model it referred to has just been wiped. `noTrash` is
        -- deliberately NOT reset -- the server on the other side of a zone
        -- line is the same server.
        state.trashAsk  = nil;

        selection = {};
        forget();

        -- An open window restarts its own sweep: this reset just disarmed
        -- both self-repair paths (the open transition only fires on a
        -- toggle, and the generation-gap repair is gated on `synced`), so
        -- without this the window sits on an empty model until the player
        -- clicks Refresh.
        if (state.open[1]) then
            startSync();
        end
    end
end);
