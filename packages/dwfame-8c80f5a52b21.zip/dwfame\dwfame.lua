--[[
* DriftwoodXI -- dwfame
*
* The fame ledger: every fame area in the game as a progress bar -- level,
* points, and how far the next level is -- plus a Guide tab that says the
* fastest repeatable way to raise each one, verified against this server's
* own quest scripts. Retail makes you walk to a different NPC per city and
* paraphrases the answer; this window is the whole answer at once.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It evaluates no fame arithmetic and holds no opinion about your progress.
* The server reads your real state -- the same getFame/getFameLevel the
* quest scripts themselves branch on -- and answers `!dwf sync` in compact
* records under the sender name _DWFDATA, which this addon parses and
* blocks before the chat log sees them. Every bar's floor and ceiling ride
* the wire beside the points, so not even the level thresholds live here.
* If the server does not assert something, this window does not show it.
*
* THE ONE THING IT REMEMBERS: the level each area held at the last sync,
* keyed to the character id the server stamps on every response -- so when
* a sync comes back a level higher, it says so in chat ("San d'Oria fame
* reached level 5!"), and an alt's ledger can never inherit the comparison.
*
* THE GUIDE IS AUTHORED DATA (data/guide.lua), not server state: NPC names,
* towns, items, counts and per-trade amounts read out of scripts/quests/*.
* Amounts are base points; the window states the server's live fame rate
* beside them, from the sync's own r| record.
*
* Authored-at-the-time was not good enough: the first cut sent players to
* the wrong half of San d'Oria for four days with every harness check green,
* because prose cannot be checked and so nothing checked it. Each guide line
* now carries the quest file, NPC key, zone and fame amount it was read
* from, and tools/dwfame/check_guide.py refuses to agree unless the scripts
* still say so AND the sentence still names the same NPC and town. The
* deploy gates on that verdict (PROD_LINUX.md 10.9).
*
* TURN IT OFF AND NOTHING IS LOST. `!fame` typed in chat prints the same
* numbers in prose, and `!dwf sync` shows exactly what this window is told.
--]]

addon.name    = 'dwfame';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.3';
addon.desc    = 'Fame ledger for DriftwoodXI: every fame area as a bar, with a guide.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server
-- uses it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWFDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

--[[
* The area catalogue: id and grouping only -- display order, names, and
* which section of the Fame tab each row lives in. Numbers all come from
* the wire. `key` matches fame_core.lua's AREAS table and data/guide.lua's
* entries; `note` is the one sentence a derived area needs so its bar does
* not look like something quests in that town would raise.
--]]
local AREAS =
{
    { id =  0, key = 'sandoria',   name = "San d'Oria",           group = 'Cities' },
    { id =  1, key = 'bastok',     name = 'Bastok',               group = 'Cities' },
    { id =  2, key = 'windurst',   name = 'Windurst',             group = 'Cities' },
    { id =  3, key = 'jeuno',      name = 'Jeuno',                group = 'Cities',
      note = 'No quest here raises it: the average of the three nations.' },
    { id =  4, key = 'selbina',    name = 'Selbina / Rabao',      group = 'Outlands',
      note = 'No counter of its own: the average of San d\'Oria and Bastok.' },
    { id =  5, key = 'norg',       name = 'Norg',                 group = 'Outlands' },
    { id =  6, key = 'konschtat',  name = 'Konschtat',            group = 'Abyssea' },
    { id =  7, key = 'tahrongi',   name = 'Tahrongi',             group = 'Abyssea' },
    { id =  8, key = 'latheine',   name = 'La Theine',            group = 'Abyssea' },
    { id =  9, key = 'misareaux',  name = 'Misareaux',            group = 'Abyssea' },
    { id = 10, key = 'vunkerl',    name = 'Vunkerl',              group = 'Abyssea' },
    { id = 11, key = 'attohwa',    name = 'Attohwa',              group = 'Abyssea' },
    { id = 12, key = 'altepa',     name = 'Altepa',               group = 'Abyssea' },
    { id = 13, key = 'grauberg',   name = 'Grauberg',             group = 'Abyssea' },
    { id = 14, key = 'uleguerand', name = 'Uleguerand',           group = 'Abyssea' },
    { id = 15, key = 'adoulin',    name = 'Adoulin',              group = 'Adoulin' },
};

local GROUP_ORDER = { 'Cities', 'Outlands', 'Abyssea', 'Adoulin' };

--[[
* One sentence under a group headline, for the case a per-area note would
* have to be repeated down the whole group to be honest. Abyssea is the only
* one that needs it: eight of its nine bars have no fame source implemented
* on this server, so a column of bars frozen at level 1 would otherwise read
* as "you have not done those yet" rather than "nothing does those yet".
* Which eight is the Guide tab's business (data/guide.lua says it per area,
* and tools/dwfame/check_guide.py fails the day that stops being true).
--]]
local GROUP_NOTES =
{
    Abyssea = 'Only La Theine has a fame source on this server today -- see the Guide tab.',
};

local areaById = {};

for _, area in ipairs(AREAS) do
    areaById[area.id] = area;
end

--[[
* The guide, loaded once from this addon's own data folder. io.read +
* loadstring rather than require so a file that is missing or refuses to
* parse costs only the Guide tab -- the bars must never die over prose.
--]]
local DATA_DIR = string.format('%s\\addons\\dwfame\\data\\',
    AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

local guide = nil;

local function loadGuide()
    local file = io.open(DATA_DIR .. 'guide.lua', 'rb');

    if (file == nil) then
        return;
    end

    local raw = file:read('*a');
    file:close();

    local chunk = loadstring(string.gsub(raw, '\r', ''), '@dwfame/data/guide.lua');

    if (chunk == nil) then
        return;
    end

    local ok, data = pcall(chunk);

    if (ok and type(data) == 'table' and type(data.entries) == 'table') then
        guide = data.entries;
    end
end

loadGuide();

if (guide == nil) then
    print(chat.header('dwfame'):append(chat.error('data/guide.lua missing or unreadable -- the Guide tab will be empty.')));
end

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged,
    -- so a stale row cannot survive a refresh (dwtracker's rule).
    charid    = nil,
    rate      = nil,          -- fame multiplier, integer percent
    areas     = T{ },         -- [id] = { fame, level, base, next }

    -- The one deliberate survivor: last sync's levels, for the level-up
    -- line. Keyed by the c| charid, wiped the moment a different character
    -- answers, and never populated from anything but a completed sync.
    prevLevels = { },
    prevChar   = nil,

    -- A level-up celebrated in the window as well as in chat, briefly.
    toast     = nil,
    toastAt   = nil,

    sortByNext = T{ false },  -- the "what is closest" lens

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its
    -- own cannot half-fill the UI.
    inbound   = nil,
    status    = 'Waiting for the first sync.',
    statusBad = false,
    reported  = false,        -- a render error is worth saying once, not per frame

    -- A zone-in sync is deferred a few seconds: 0x000A arrives while the
    -- client is still on the load screen, and a chat line sent there is a
    -- chat line lost.
    syncAt    = nil,
    syncSlot  = nil,
};

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. The client rate-limits outgoing chat and a !dwf command is a chat
* line; everything queues here and drains at one command per interval, with
* duplicates collapsed (dwbags' lesson, kept verbatim).
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking: a command can be lost on the way out, so an unanswered
* request is asked once more and then left alone. A PLAIN TABLE, NOT T{ }:
* keyed by verb names, and sugar-table method names shadowing a key cost
* dwbags a round once already.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

--[[
* True once this server has shown it does not speak dwfame -- either its own
* refusal arrived ("The fame ledger is not loaded.") or a request went
* unanswered twice. An unknown !command on this server falls through to
* ordinary /say chat, so every auto-sync against a dead verb is the player
* PUBLICLY SAYING "!dwf sync". While set, zone-in auto-syncs stop. Cleared
* by anything that proves the server speaks (a d| envelope, a p| ping) and
* by the player acting on purpose (window open, refresh).
--]]
local serverSilent = false;

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

local function ask(verb)
    requested[verb] = { at = os.clock(), answered = false, tries = 1 };

    issue('!dwf ' .. verb);
end

-- Re-ask an unanswered verb once; give up loudly after that. Called every
-- frame, window open or not.
local function checkAnswers()
    for verb, asked in pairs(requested) do
        if (not asked.answered and (os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue('!dwf ' .. verb);
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;
                serverSilent = true;

                state.status    = 'No answer from the server. Is DriftwoodXI up to date?';
                state.statusBad = true;
            end
        end
    end
end

local function requestSync()
    ask('sync');
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* A completed sync is the only moment the level-up comparison runs: the new
* levels against prevLevels, both full snapshots, both this character's.
* The first sync a character ever answers seeds the table silently --
* "reached level 3" with nothing to compare against would be a guess, and
* this addon does not guess.
--]]
local function celebrateLevelUps()
    if (state.charid == nil) then
        return;
    end

    if (state.prevChar ~= state.charid) then
        state.prevChar   = state.charid;
        state.prevLevels = { };
    end

    local seeded = next(state.prevLevels) ~= nil;

    for id, row in pairs(state.areas) do
        local area = areaById[id];
        local prev = state.prevLevels[id];

        if (seeded and area ~= nil and prev ~= nil and row.level > prev) then
            local line = string.format('%s fame reached level %d!', area.name, row.level);

            print(chat.header('dwfame'):append(chat.message(line)));

            state.toast   = line;
            state.toastAt = os.clock();
        end

        state.prevLevels[id] = row.level;
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        -- An envelope is the server speaking dwfame, whatever it carries.
        serverSilent = false;

        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwfame.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright, before anything
        -- else can throw (dwbags' rule). prevLevels deliberately survives:
        -- it is the comparison, and c| re-keys it if the character changed.
        if (state.inbound == 'sync') then
            state.charid = nil;
            state.rate   = nil;
            state.areas  = T{ };
        end

        answered(state.inbound);

        -- A refusal raised before a verb opened its own envelope arrives
        -- wrapped in `d|1|status` (dwf.lua's shape). That IS the answer to
        -- whatever was asked: left unanswered, checkAnswers re-sends the
        -- verb in five seconds and then replaces the server's precise
        -- sentence ("The fame ledger is not loaded.") with a "no answer"
        -- diagnosis that is simply untrue.
        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- sentence saying why something was refused is worth more than the
    -- response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwfame'):append(chat.error(state.status)));

            -- The command exists but fame_core.lua is not loaded (dwf.lua's
            -- own refusal). Asking again cannot help until a map restart --
            -- detect once and go quiet.
            if (string.find(line, 'The fame ledger is not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end
        end

        return;
    end

    -- The dirty ping, honoured from day one so deployment order between
    -- addon and server cannot matter: one record, outside any envelope,
    -- answered with a fresh sync.
    if (kind == 'p') then
        serverSilent = false;
        ask('sync');

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'sync') then
            celebrateLevelUps();
            state.status    = 'Synced.';
            state.statusBad = false;
        end

        return;
    end

    if (kind == 'c') then
        state.charid = tonumber(parts[2]);

        return;
    end

    if (kind == 'r') then
        state.rate = tonumber(parts[2]);

        return;
    end

    if (kind == 'f') then
        local id = tonumber(parts[2]);

        if (id ~= nil and areaById[id] ~= nil) then
            state.areas[id] = T{
                fame  = tonumber(parts[3]) or 0,
                level = tonumber(parts[4]) or 1,
                base  = tonumber(parts[5]) or 0,
                next  = tonumber(parts[6]) or 0,
            };
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWFDATA is
* ours: consumed here and blocked so the chat log never sees it -- before
* parsing, so a malformed record cannot leak as noise.
--]]
ashita.events.register('packet_in', 'dwfame_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwfame'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

local TOAST_SECONDS = 8.0;

--[[
* One fame bar, as a row of the two-column table fameTab opened. The
* fraction is pure arithmetic over what the wire said: how far between the
* level's floor (base) and ceiling (next) the points sit. next == 0 is the
* server saying "capped" -- full bar, said so in the overlay instead of
* pretending there is a next band to climb.
--]]
local function fameRow(area, row)
    imgui.TableNextRow();
    imgui.TableNextColumn();
    imgui.Text(area.name);
    imgui.TableNextColumn();

    local fraction, overlay;

    if (row.next <= row.base) then
        fraction = 1.0;
        overlay  = string.format('Lv %d  --  %d pts (max)', row.level, row.fame);
    else
        fraction = (row.fame - row.base) / (row.next - row.base);

        if (fraction < 0) then fraction = 0; end
        if (fraction > 1) then fraction = 1; end

        overlay = string.format('Lv %d  --  %d pts (%d to Lv %d)',
            row.level, row.fame, row.next - row.fame, row.level + 1);
    end

    imgui.ProgressBar(fraction, { -1, 16 }, overlay);

    if (area.note ~= nil) then
        imgui.TableNextRow();
        imgui.TableNextColumn();
        imgui.TableNextColumn();
        imgui.TextDisabled(area.note);
    end
end

local function orderedAreas()
    local rows = T{ };

    for _, area in ipairs(AREAS) do
        if (state.areas[area.id] ~= nil) then
            rows:append(area);
        end
    end

    -- The "what is closest" lens: every un-capped area by how few points
    -- its next level needs, capped ones last. A tie keeps catalogue order.
    if (state.sortByNext[1]) then
        table.sort(rows, function(a, b)
            local ra, rb = state.areas[a.id], state.areas[b.id];
            local da = ra.next > ra.base and (ra.next - ra.fame) or math.huge;
            local db = rb.next > rb.base and (rb.next - rb.fame) or math.huge;

            if (da == db) then
                return a.id < b.id;
            end

            return da < db;
        end);
    end

    return rows;
end

-- The two-column frame every bar row renders into. Opened and closed per
-- group (or once, sorted), so the group headline can sit between tables.
local function beginBarTable(id)
    if (imgui.BeginTable(id, 2, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Area', ImGuiTableColumnFlags_WidthFixed, 140, 0);
        imgui.TableSetupColumn('Fame', ImGuiTableColumnFlags_WidthStretch, 0, 0);

        return true;
    end

    return false;
end

local function fameTab()
    if (next(state.areas) == nil) then
        imgui.TextDisabled('No fame data yet. Refresh, or wait for the first sync.');

        return;
    end

    imgui.Checkbox('Sort by closest next level', state.sortByNext);

    if (not imgui.BeginChild('##dwfame_bars', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (state.sortByNext[1]) then
        if (beginBarTable('##dwfame_sorted')) then
            for _, area in ipairs(orderedAreas()) do
                fameRow(area, state.areas[area.id]);
            end

            imgui.EndTable();
        end
    else
        for _, groupName in ipairs(GROUP_ORDER) do
            imgui.TextDisabled(groupName);

            if (GROUP_NOTES[groupName] ~= nil) then
                imgui.TextDisabled(GROUP_NOTES[groupName]);
            end

            if (beginBarTable('##dwfame_' .. groupName)) then
                for _, area in ipairs(AREAS) do
                    if (area.group == groupName and state.areas[area.id] ~= nil) then
                        fameRow(area, state.areas[area.id]);
                    end
                end

                imgui.EndTable();
            end
        end
    end

    imgui.EndChild();
end

local function coloredWrapped(color, text)
    imgui.PushStyleColor(ImGuiCol_Text, color);
    imgui.TextWrapped(text);
    imgui.PopStyleColor();
end

local function guideTab()
    if (guide == nil) then
        imgui.TextDisabled('data/guide.lua missing or unreadable -- reinstall dwfame to get the guide back.');

        return;
    end

    if (not imgui.BeginChild('##dwfame_guide', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    coloredWrapped(theme.colors.dim,
        'Fame amounts below are base points, straight from this server\'s quest scripts.' ..
        (state.rate ~= nil and state.rate ~= 100
            and string.format(' This server multiplies fame gains by %.2fx.', state.rate / 100)
            or ''));
    imgui.Separator();

    for _, area in ipairs(AREAS) do
        local lines = guide[area.key];

        if (lines ~= nil) then
            local row     = state.areas[area.id];
            local summary = row ~= nil and string.format('(Lv %d)', row.level) or '';

            if (imgui.TreeNodeEx(string.format('%s %s##dwfame_g_%d', area.name, summary, area.id),
                    area.group ~= 'Abyssea' and ImGuiTreeNodeFlags_DefaultOpen or 0)) then
                for _, line in ipairs(lines) do
                    imgui.Bullet();
                    imgui.SameLine();
                    coloredWrapped(theme.colors.hint, line);
                end

                imgui.TreePop();
            end
        end
    end

    imgui.EndChild();
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        serverSilent = false;

        forget();
        requestSync();
    end

    imgui.SameLine();

    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    elseif (state.rate ~= nil and state.rate ~= 100) then
        imgui.TextDisabled(string.format('Server fame rate: %.2fx', state.rate / 100));
    else
        imgui.TextDisabled('');
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    if (state.toast ~= nil and state.toastAt ~= nil and (os.clock() - state.toastAt) <= TOAST_SECONDS) then
        imgui.TextColored(theme.colors.hint, state.toast);
    end

    imgui.Separator();

    if (imgui.BeginTabBar('##dwfame_tabs')) then
        if (imgui.BeginTabItem('Fame')) then
            fameTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Guide')) then
            guideTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape, and its
* reasoning, kept verbatim).
--]]
ashita.events.register('d3d_present', 'dwfame_present', function ()
    -- Before the visibility check: a sync requested by a zone-in still has
    -- to reach the server with the window shut.
    if (state.syncAt ~= nil and os.clock() >= state.syncAt) then
        -- The deferral exists because 0x000A arrives on the load screen --
        -- but a fixed delay only guesses at how long that screen stays up,
        -- and a typed line handed to a client that is still zoning is not
        -- delayed, it is LOST, with "A command error occurred." in the log
        -- as its residue (the per-zone error players were seeing). The
        -- client's own zoning flag is the fact; wait it out.
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (player ~= nil and player:GetIsZoning() ~= 0) then
            state.syncAt   = os.clock() + 1.0;
            state.syncSlot = nil;
        elseif (state.syncSlot == nil) then
            -- Zoning done. Every sibling clears its zoning flag on the SAME
            -- frame, so hold this addon's stagger slot before firing or the
            -- zone-in syncs collide at the client's chat throttle and all but
            -- one come back "A command error occurred." (dwecho.lua's ZONE_ORDER
            -- is the shared slot order; 2026-08-14).
            state.syncSlot = os.clock() + echo.zoneSlot('dwfame') * echo.SEND_INTERVAL;
            state.syncAt   = state.syncSlot;
        else
            state.syncAt   = nil;
            state.syncSlot = nil;

            forget();
            requestSync();
        end
    end

    -- Answer tracking runs whether or not the window is open: it is exactly
    -- the window-closed zone-in auto-syncs that must stop when the server
    -- has gone silent (an unknown !command here is /say chat).
    checkAnswers();

    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 620, 460 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Fame##dwfame', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwfame'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwfame'):append(chat.message('Window closed. `!fame` typed by hand shows the same numbers.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs: a window showing fame as it
* stood two quests ago is the quiet kind of wrong this project exists to
* rule out, and a sync costs one chat line.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting, and for the
        -- silent-server detection: opening the window is the deliberate
        -- act that earns one more try.
        state.reported = false;
        serverSilent   = false;

        forget();
        requestSync();
    end
end

ashita.events.register('command', 'dwfame_command', function (e)
    local args = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwfame' and first ~= '/fame' and first ~= '/dwf') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        serverSilent = false;

        forget();
        requestSync();

        return;
    end

    toggleWindow();
end);

--[[
* Sync on login and zone-in (0x000A serves both). Everything server-derived
* resets first -- a login may be a different character, and a stale ledger
* surviving into a new character's window is exactly the quiet wrongness
* this project exists to rule out. prevLevels deliberately survives: the
* level-up line only works if the comparison outlives the zone line, and
* the c| charid on the next sync wipes it the moment the character really
* is a different one.
--]]
ashita.events.register('packet_in', 'dwfame_zonein', function (e)
    if (e.id == 0x000A) then
        state.charid    = nil;
        state.rate      = nil;
        state.areas     = T{ };
        state.status    = 'Syncing...';
        state.statusBad = false;

        forget();

        -- No auto-sync against a server that has shown it does not speak
        -- dwfame: an unknown !command falls through to /say here, so each
        -- retry would be the player chatting "!dwf sync" at whoever is
        -- nearby. Opening the window retries deliberately.
        if (not serverSilent) then
            state.syncAt = os.clock() + 4.0;
        else
            state.status = 'Fame ledger paused (no answer from the server). Open the window to retry.';
        end
    end
end);

--[[
* Watch what the player sends.
*
* Bare `!dwf` and `!fame` (and the ui/window/gui spellings) are intercepted
* and toggle this window instead of going to the server -- the server verb
* is the name players learn from the news post, so it has to be a door and
* not a dead end. `!dwf sync` typed by hand still passes through untouched;
* that is the escape hatch this addon's header promises.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped.
* Stamping the player's own line as a send makes the next queued command
* wait its interval instead of racing it (dwbags' lesson, kept verbatim).
--]]
ashita.events.register('packet_out', 'dwfame_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!dwf' or lower == '!fame' or
        lower == '!dwf ui' or lower == '!dwf window' or lower == '!dwf gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwf') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwfame_load', function ()
    print(chat.header('dwfame'):append(chat.message('/fame, /dwfame or !fame opens the fame ledger.')));
end);
