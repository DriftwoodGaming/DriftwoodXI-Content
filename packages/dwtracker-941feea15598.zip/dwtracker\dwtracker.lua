--[[
* DriftwoodXI -- dwtracker
*
* The in-game quest and mission guide: four tabs -- Active Quests, Active
* Missions, Completed Quests, Completed Missions -- filled from your own
* journal state, synced from the server on login, zone-in and window-open.
* An active entry with authored steps opens into the step the server placed
* you on, what to do there, and how far away it is (the waypoint line,
* DWTRACKER_WAYPOINT_PLAN.md).
*
* The header used to say "This is Phase 0: names and state only. Step-by-step
* guidance arrives with the phases behind it." Phases 1-8 landed and it never
* got rewritten -- so the design document described a window with no step pane
* while the file underneath it drew one (corrected 2026-09-06).
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It evaluates no quest logic and holds no opinion about your progress. The
* server reads your real state -- the same quest status, mission line and
* completion bits the quest scripts themselves branch on -- and answers
* `!dwt sync` in compact records under the sender name _DWTDATA, which this
* addon parses and blocks before the chat log sees them. If the server does
* not assert something, this window does not show it. That split is the
* project's one non-negotiable: the tracker must never feed you a wrong
* step, and the addon's side of that promise is to never invent one.
*
* WHERE THE NAMES COME FROM. The data/ folder in this addon ships the same
* pure-data files the server loads -- one authored source, two consumers
* (plan decision T1). Quest and mission names render from those files; the
* wire carries only numeric ids. Every sync starts with a hash handshake
* over each data file, and any area whose bytes disagree with the server's
* copy is flagged in the window: names still render, but step guidance
* (when it exists) stays off for that area until the copies agree. Stale
* data says "update me"; it never says something wrong.
*
* WHAT THE WINDOW LETS YOU ARRANGE, and the one rule every switch obeys.
* A find box over all four tabs, A-Z on the completed lists, and "in this
* zone" over the active quests -- the last two remembered per character. Every
* one of them is a VIEW: nothing is asked of the server and nothing is
* computed here that the server did not assert. The zone switch is the one
* that needs saying out loud, because a filter hides rows and an omission can
* be read as an answer: it keeps only what `waypointFor` can place (see
* DWTRACKER_WAYPOINT_PLAN.md -- client geometry over the server's own current
* step, never quest logic), which makes it NARROWER than "what can I do here",
* so the tab states that it is on and how many rows it is holding back
* whenever it is -- hidden rows or none (1.1.0).
*
* TURN IT OFF AND NOTHING IS LOST. `!dwt sync` typed by hand shows exactly
* what the addon is being told, and your journal is still the journal.
--]]

addon.name    = 'dwtracker';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.0';
addon.desc    = 'In-game quest and mission tracker for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local theme    = require('dwtheme');
local echo     = require('dwecho');
local settings = require('settings');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server
-- uses it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWTDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

-- Completed bitmaps ride as 32-id chunks (DWTRACKER_FORMAT.md): LuaJIT's
-- bit library is 32-bit on both sides of this wire.
local CHUNK_BITS = 32;

local NATION_NAMES = {
    [0] = "San d'Oria",
    [1] = 'Bastok',
    [2] = 'Windurst',
};

--[[
* FNV-1a over the normalized data file bytes, 8 hex chars.
*
* MUST MATCH modules/driftwoodxi/tracker_core.lua's fnv1a exactly: these two
* functions hashing the same file differently would read as "data out of
* date" on every client forever. \r is stripped before hashing because git
* may check the two copies out with different line endings. The multiply is
* split at 16 bits because hash * 16777619 overflows the 2^53 integer range
* of a double.
--]]
local function fnv1a(text)
    local hash = 2166136261;

    for i = 1, #text do
        hash = bit.bxor(hash, string.byte(text, i)) % 4294967296;

        local lo = hash % 65536;

        hash = (((hash - lo) / 65536) * 16777619 % 65536) * 65536 + lo * 16777619;
        hash = hash % 4294967296;
    end

    return bit.tohex(hash);
end

--[[
* The data files, loaded once at addon load from this addon's own data/
* folder. io.read + loadstring rather than require, for the same reason the
* server does it that way: the hash must cover the bytes that produced the
* table. A file that is missing or refuses to parse takes only its own area
* down -- its names degrade to '#id' and the handshake flags it -- because
* a data problem must never cost the whole window.
--]]
local DATA_DIR = string.format('%s\\addons\\dwtracker\\data\\',
    AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

local dataAreas    = {};    -- manifest order
local questsByLog  = {};    -- [log] = area table (kind 'quests')
local missionsByLog = {};   -- [log] = area table (kind 'missions')

local function readAll(path)
    local file = io.open(path, 'rb');

    if (file == nil) then
        return nil;
    end

    local raw = file:read('*a');
    file:close();

    return raw;
end

local function loadArea(stem)
    local raw = readAll(DATA_DIR .. stem .. '.lua');

    if (raw == nil) then
        return nil;
    end

    local normalized = string.gsub(raw, '\r', '');
    local chunk = loadstring(normalized, '@dwtracker/data/' .. stem);

    if (chunk == nil) then
        return nil;
    end

    local ok, data = pcall(chunk);

    if (not ok or type(data) ~= 'table' or type(data.entries) ~= 'table') then
        return nil;
    end

    --[[
    * The SAME schema check tracker_core.lua's loadArea makes, and for the
    * reason the header promises: a data problem must never cost the whole
    * window. Without it a file that PARSES but omits `log` sailed past the
    * check above and reached `questsByLog[data.log] = data` -- indexing a
    * table with nil, which is a hard Lua error raised at addon load, outside
    * every pcall in this file. The one shape the header rules out (a data
    * file taking the addon down) was the one shape a half-written data file
    * produced (2026-09-06). `label` is defaulted rather than refused: it is
    * display text, and a missing one costs a column, not correctness.
    --]]
    if (type(data.log) ~= 'number' or data.log ~= math.floor(data.log) or
        data.area ~= stem or
        (data.kind ~= 'quests' and data.kind ~= 'missions' and data.kind ~= 'hidden'))
    then
        return nil;
    end

    if (type(data.label) ~= 'string' or data.label == '') then
        data.label = stem;
    end

    -- Integral numeric keys ONLY. `table.sort` over a list holding both a
    -- number and a string raises "attempt to compare number with string",
    -- and that error is raised at addon load outside every pcall here --
    -- the same whole-window cost the schema check above exists to rule out.
    data.ids = {};

    for id in pairs(data.entries) do
        if (type(id) == 'number' and id == math.floor(id)) then
            table.insert(data.ids, id);
        end
    end

    table.sort(data.ids);

    data.hash = fnv1a(normalized);

    return data;
end

local function loadData()
    local manifest = nil;
    local raw      = readAll(DATA_DIR .. 'manifest.lua');

    if (raw ~= nil) then
        local chunk = loadstring(string.gsub(raw, '\r', ''));

        if (chunk ~= nil) then
            local ok, list = pcall(chunk);

            if (ok and type(list) == 'table') then
                manifest = list;
            end
        end
    end

    if (manifest == nil) then
        print(chat.header('dwtracker'):append(chat.error('data/manifest.lua missing or unreadable -- names will not render.')));

        return;
    end

    for _, stem in ipairs(manifest) do
        -- A manifest entry that is not a file name would throw on the
        -- concatenation inside loadArea, at load, outside every pcall here --
        -- the whole-window cost this file's header rules out for data
        -- problems. Named and skipped instead.
        local data = type(stem) == 'string' and loadArea(stem) or nil;

        if (data == nil) then
            print(chat.header('dwtracker'):append(chat.error(string.format('data file %s.lua failed to load -- its names will not render.', tostring(stem)))));
        else
            table.insert(dataAreas, data);

            -- Hidden quests share the Active Quests surface: they ride the
            -- aq| record on a log number that is not a quest log (255), so
            -- they land in questsByLog beside the real ones and render
            -- through exactly the same row code. They are deliberately NOT
            -- in the completed rebuild below -- a hidden quest leaves no
            -- completion bit to build a row from.
            if (data.kind == 'quests' or data.kind == 'hidden') then
                questsByLog[data.log] = data;
            elseif (data.kind == 'missions') then
                missionsByLog[data.log] = data;
            end
        end
    end
end

loadData();

--[[
* PERSISTED PRESENTATION STATE (1.1.0), through Ashita's settings library --
* per character, under config\addons\dwtracker\.
*
* Two switches, and deliberately only two. This window holds no opinion worth
* keeping: the journal is the server's and is re-asked on every zone line, so
* there is nothing here to remember except how the player likes it ARRANGED.
* The find box is pointedly NOT persisted -- a search that survived a relog
* would go on hiding rows a player had long forgotten they filtered, and this
* is the one addon that must never quietly show less than it knows.
*
* Guarded throughout (the suite's rule): a settings file that is missing,
* corrupt, or written by a later version costs a preference and never the
* window. `settings.load` merges the defaults over whatever is on disk, so a
* file written today still reads under a version that adds a third key, and a
* key this version does not know is carried through untouched.
--]]
local defaultConfig = T{
    -- The completed tabs' A-Z switch. Off is the order the server sent.
    sortByName = false,

    -- Active Quests: draw only the rows whose current step is in the zone
    -- the player is standing in.
    hereOnly   = false,
};

local config = defaultConfig;

do
    local ok, loaded = pcall(settings.load, defaultConfig);

    if (ok and type(loaded) == 'table') then
        config = loaded;
    else
        print(chat.header('dwtracker'):append(chat.message('settings unreadable -- this session starts from the defaults.')));
    end
end

local function saveConfig()
    pcall(settings.save);
end

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a COMPLETED response, never
    -- merged, so a stale row cannot survive a refresh -- and never emptied by
    -- a response that has only started arriving (see `draft`, below).
    nation    = nil,
    rank      = nil,
    activeQuests   = T{ },   -- { { log, id, step, n }, ... } in arrival order
    activeMissions = T{ },   -- [mlog] = { id, step, n }
    cq        = T{ },        -- [log]  = { [chunk] = value }
    cm        = T{ },        -- [mlog] = { [chunk] = value }

    -- Built once per completed sync rather than per frame: several hundred
    -- completed entries iterated at render speed is waste for a list that
    -- only changes when a response lands.
    completedQuests   = T{ },
    completedMissions = T{ },

    serverHashes = { },      -- [area stem] = hash (plain table: stem-keyed,
                             -- so a future stem named like a T{} sugar method
                             -- cannot resolve to a function instead of nil)
    mismatched   = T{ },     -- display titles of the areas that disagree
    mismatchLine = nil,      -- the banner's sentence, built at each handshake
    mismatchSet  = { },      -- disagreeing STEMS as keys (plain table)

    -- The positive half of the handshake, for the status card: how many of
    -- this addon's data files the server confirmed, and whether it has
    -- answered a hello at all yet. "Nothing disagreed" and "everything
    -- agreed" are different sentences and the card must not conflate them --
    -- the same distinction verifiedSet exists to keep (1.1.0).
    verifiedCount = 0,
    verifiedSeen  = false,

    -- Areas whose hash AGREED at the last hello (plain table: stem-keyed).
    -- Steps render only for verified areas -- agreement is proven, never
    -- assumed. Phase 6 hardening: before this set existed, a hello response
    -- lost to packet drop left the mismatch list empty, and a sync arriving
    -- alone would render steps against data nothing had checked. The T1
    -- drift rule demands positive agreement, not absence of disagreement.
    verifiedSet  = { },

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its
    -- own cannot half-fill the UI.
    inbound   = nil,
    status    = 'Waiting for the first sync.',
    statusBad = false,
    reported  = false,       -- a render error is worth saying once, not per frame

    -- A zone-in sync is deferred a few seconds: 0x000A arrives while the
    -- client is still on the load screen, and a chat line sent there is a
    -- chat line lost.
    syncAt    = nil,
    syncSlot  = nil,

    -- os.clock() the journal on screen was committed, so the window can say
    -- how old the rows it is drawing are. nil until the first sync lands.
    syncedAt  = nil,
};

--[[
* THE ENVELOPE UNDER CONSTRUCTION.
*
* Records between `d|` and `z|` are a DRAFT and land here; `z|` swaps the
* finished draft into `state` in one assignment. The sections used to be wiped
* at `d|` and refilled record by record -- dwbags' "replace your own section
* before anything can throw" rule applied to a reader that receives its
* records ONE PACKET AT A TIME. A sync is fifteen-odd separate 0x017 packets,
* nothing promises they arrive in the same frame, and every frame in between
* drew whatever had turned up so far: "No active quests. Accept one and it
* appears here at the next sync." over a character with eleven of them, then a
* growing partial journal. That sentence is a claim about the player's own log
* and it was false while it was on screen -- the exact shape of quiet
* wrongness this addon's header exists to rule out.
*
* Worse, an envelope that never closes -- an `e|` raised mid-answer, a map
* restart between records -- left that partial journal up looking exactly like
* a complete one. A draft that never completes is simply discarded, and the
* last journal the server finished saying stays on screen (2026-09-06).
--]]
local draft = nil;

-- "A malformed record was already reported for the answer arriving now."
-- Cleared in the `d|` branch; see the print at the end of packet_in.
local badRecordSaid = false;

--[[
* Bumped on every committed write to the model above. The render caches its
* filtered row lists against it, so six hundred completed rows are lowercased
* and matched once per sync rather than once per frame.
--]]
local modelRev = 0;

--[[
* One wire field as a whole number, or the fallback.
*
* Every number on this wire is an id, a step index or a chunk index, and the
* server formats every one of them with `%i` -- integral by construction. But
* `tonumber` takes '2.5', 'nan' and '1e400' exactly as readily as '3', and the
* render hands these straight to `string.format('%d', ...)`. What that does
* with a number that has no integer representation is the runtime's choice:
* the client's LuaJIT 2.1 truncates 2.5 to 2 and prints a NaN or an infinity
* as -9223372036854775808 -- a confident wrong number on screen -- while Lua
* 5.4, which some of the suite's offline harnesses run, RAISES, and that
* throw lands in the render pcall, which closes the window (2026-09-06;
* measured against lupa's LuaJIT 2.1 on 2026-09-06, Phase 2 review).
* Range-checked as well, because inf is a number and floors to itself
* (dwfame's wireInt, same reasoning).
*
* A NON-INTEGRAL FIELD IS REFUSED, NOT FLOORED. This used to end in
* `math.floor(n)` with no integrality test, so '2.5' came back as 2 -- safe to
* format, and a claim the server never made. "Step 2 of 5" over a field this
* addon could not read is precisely the quiet wrongness the header exists to
* rule out; the callers below turn a refusal into the u| shape instead
* (active, nothing highlighted) or drop the record (2026-09-06).
--]]
local WIRE_LIMIT = 2147483647;

local function wireInt(text, fallback)
    local n = tonumber(text);

    if (n == nil or n ~= n or n > WIRE_LIMIT or n < -WIRE_LIMIT or n ~= math.floor(n)) then
        return fallback;
    end

    return math.floor(n);
end

--[[
* One wire field as a NON-NEGATIVE whole number, or nil.
*
* Every id, log, step, count and chunk index on this wire is a count: the
* server formats them from array indices, journal log numbers and bit
* positions, and not one of them can be negative. `wireInt`'s range stays
* symmetric because it is the general reader; this is the one the records
* actually use, and a negative field is a field this addon has misread --
* `aq|0|-5:1:1` used to render a row reading "quest #-5" (2026-09-06).
--]]
local function wireId(text)
    local n = wireInt(text, nil);

    if (n == nil or n < 0) then
        return nil;
    end

    return n;
end

--[[
* Is a (step, count) pair one the server could have meant?
*
* `0:0` is the format's "active, no guide authored yet" form, and every other
* honest pair places the step INSIDE the list -- `evalEntry` returns the index
* of the first unsatisfied step of n, so it cannot exceed n. A step past its
* own count is a pair this addon has misread, and "(step 9 of 5)" is a
* sentence with no reading; it takes the u| shape instead (2026-09-06).
--]]
local function stepPairOk(step, n)
    if (step == 0 and n == 0) then
        return true;
    end

    return n > 0 and step >= 1 and step <= n;
end

--[[
* One completed-bitmap chunk value, or nil.
*
* Eight hex digits by contract (`bit.tohex`), and the length matters: a field
* longer than that is a field this addon has misread, and `tonumber(x, 16)`
* would answer a number far past 32 bits which the bit ops then mask down to
* whatever the bottom word happens to be -- up to thirty-two completions
* claimed out of a misread. Refused instead; a chunk that never arrives is a
* row that never renders, which is the honest half of wrong (2026-09-06).
--]]
local function wireChunk(text)
    if (type(text) ~= 'string' or #text == 0 or #text > 8 or text:find('%X') ~= nil) then
        return nil;
    end

    return tonumber(text, 16);
end

--[[
* Answer tracking: a command can be lost on the way out (the client answers
* over-limit chat with "A command error occurred" before the server sees
* it), so an unanswered request is asked once more and then left alone.
*
* A PLAIN TABLE, NOT T{ }: this is keyed by verb names, and sugar-table
* method names shadowing a key cost dwbags a round once already.
*
* Declared here, ABOVE the queue, because the queue is what starts the clock:
* `at` stays nil until the line actually leaves (see pumpQueue). Everything
* else about answers -- ask, answered, checkAnswers -- stays below the queue,
* because it has to be able to call `issue`.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. The client rate-limits outgoing chat and a !dwt command is a chat
* line; everything queues here and drains at one command per interval, with
* duplicates collapsed (dwbags' lesson, kept verbatim).
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    local command = table.remove(queue, 1);

    echo.send(command);

    --[[
    * THE ANSWER CLOCK STARTS HERE, not at `ask`.
    *
    * `ask` used to stamp `at = os.clock()` when the line was QUEUED. The queue
    * holds shut for as long as the client calls itself zoning and then drains
    * at one line per SEND_INTERVAL, so a request could sit in it for twenty
    * seconds -- and every one of those seconds counted against a server that
    * had not been spoken to yet. Both asks were then already past
    * ANSWER_TIMEOUT the instant the load screen cleared, burned their retry on
    * the same frame, and the window said "No answer from the server. Is
    * DriftwoodXI up to date?" about a request that had been on the wire for
    * under four seconds. The clock has to measure the server's latency, so it
    * starts when the line leaves (2026-09-06).
    --]]
    local asked = requested[command:sub(6)];

    if (type(asked) == 'table' and not asked.answered) then
        asked.at = now;
    end
end

--[[
* True once this server has shown it does not speak dwtracker -- either its
* own refusal arrived ("The tracker is not loaded.", the module half missing)
* or a request went unanswered twice (no `!dwt` at all). dwbags' detect-once
* pattern, with one twist this addon needs and dwbags does not: an unknown
* `!command` on this server falls through to ordinary /say chat
* (0x0b5_chat_std.cpp:121), so every auto-sync against a dead verb is the
* player PUBLICLY SAYING "!dwt hello". While set, zone-in auto-syncs stop.
* Cleared by anything that proves the server speaks after all (a `d|`
* envelope, a `p|` ping) and by the player acting on purpose (window open,
* refresh) -- which is also how a server upgraded underneath a running
* client gets asked again, since its map restart forced a relog and the
* player's next window-open retries.
--]]
local serverSilent = false;

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

-- `at = nil` means "queued, not yet sent": pumpQueue stamps it the moment the
-- line leaves and checkAnswers ignores an ask that has none, so a line waiting
-- its turn behind the throttle can never time out before it is asked.
local function ask(verb)
    requested[verb] = { at = nil, answered = false, tries = 1 };

    issue('!dwt ' .. verb);
end

-- Re-ask an unanswered verb once; give up loudly after that. Called every
-- frame, window open or shut.
local function checkAnswers()
    -- A held send (zone-in) leaves the line queued; aging the answer clock
    -- against it would be a false timeout, and after ANSWER_TRIES a false
    -- "No answer from the server." (dwecho canSend; 2026-08-15.) The `at ==
    -- nil` test below closes the same hole from the other side -- this one
    -- only covers the frames the client is ACTUALLY zoning, and a line can
    -- wait behind the throttle for reasons that have nothing to do with a
    -- load screen.
    if (not echo.canSend()) then
        return;
    end

    for verb, asked in pairs(requested) do
        if (not asked.answered and asked.at ~= nil and
            (os.clock() - asked.at) >= ANSWER_TIMEOUT)
        then
            if (asked.tries < ANSWER_TRIES) then
                -- Back to "queued, not yet sent": the retry's own clock starts
                -- when pumpQueue actually puts it on the wire, which may be a
                -- throttle interval away if something else is ahead of it.
                asked.at    = nil;
                asked.tries = asked.tries + 1;

                issue('!dwt ' .. verb);
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;
                serverSilent = true;

                state.status    = 'No answer from the server. Is DriftwoodXI up to date?';
                state.statusBad = true;
            end
        end
    end
end

local function requestSync()
    ask('hello');
    ask('sync');
end

--[[
* Record parsing. Pipe-separated with a single-character (or two-character)
* type; anything unrecognised is ignored rather than being an error, so a
* server newer than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    -- A RECORD SHORTER THAN THE ONE IT NAMES SPLITS INTO NOTHING, not into a
    -- throw. `aq|0` with the packed payload missing reached this as
    -- `split(nil, ',')`, and `nil .. sep` is an error raised inside the
    -- packet_in pcall -- which writes one "bad record" chat line PER PACKET
    -- for a server that got a line wrong. An empty field list makes every
    -- `#bits >= 3` guard below refuse the entry on its own (2026-09-06).
    if (type(text) ~= 'string') then
        return parts;
    end

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function chunkBitSet(chunks, id)
    local value = chunks[math.floor(id / CHUNK_BITS)];

    return value ~= nil and bit.band(value, bit.lshift(1, id % CHUNK_BITS)) ~= 0;
end

--[[
* The first of the two per-sync rebuilds: completed rows in data order. (The
* second, rebuildMismatch, follows it and runs off the handshake instead.)
*
* THE LISTS ARE BUILT WHOLE AND ASSIGNED AT THE END, for the same
* reason the envelope is a draft. These two used to be emptied on the first
* line here and filled in place, so anything that threw in the loop below --
* this runs inside packet_in's pcall, which catches and carries on -- left the
* window holding two empty lists over a character with four hundred finished
* quests, and the completed tabs saying "Nothing completed yet. Plenty of
* time." A build that does not finish now costs the LAST answer's rows
* instead, which are stale rather than false (2026-09-06).
--]]
local function rebuildCompleted()
    local quests   = T{ };
    local missions = T{ };

    for _, area in ipairs(dataAreas) do
        -- `kind` has three values, and `hidden` areas are quests: bucketed
        -- by "not quests" they would surface under Completed MISSIONS the
        -- moment hidden quests grow a completion signal.
        local rows   = area.kind == 'missions' and missions or quests;
        local chunks = (area.kind == 'missions' and state.cm or state.cq)[area.log];

        -- Hidden quests have no completion bit at all (the container's vars
        -- are wiped on completion and nothing else is written), so they get
        -- no completed row rather than a guessed one.
        if (area.kind == 'hidden') then
            chunks = nil;
        end

        if (chunks ~= nil) then
            for _, id in ipairs(area.ids) do
                if (chunkBitSet(chunks, id)) then
                    local entry = area.entries[id];

                    -- A data file whose entry carries no `name` is malformed
                    -- (the linter refuses it), but a nil reaching imgui.Text
                    -- is a throw inside the render pcall -- so the row falls
                    -- back to its id rather than costing the window.
                    local name = type(entry.name) == 'string' and entry.name
                        or string.format('#%d', id);

                    rows:append(T{
                        label      = area.label,
                        name       = name,
                        repeatable = entry.repeatable == true,

                        -- The find box's haystack, lowercased ONCE per sync.
                        -- It used to be built and lowercased per row per
                        -- frame, which on a completion-heavy character is six
                        -- hundred format+lower+lower calls sixty times a
                        -- second for a string that only changes when an
                        -- answer lands (2026-09-06).
                        search     = string.lower(name .. ' ' .. tostring(area.label)),
                    });
                end
            end
        end
    end

    state.completedQuests   = quests;
    state.completedMissions = missions;
end

--[[
* WHAT THE BANNER CALLS AN AREA. `state.mismatched` is display text and
* nothing else -- the sets beside it stay keyed by the file stem, which is
* what the wire and `verifiedSet` compare -- so it says what a player can
* read. It used to name the file: "Data out of date for: sandoria_quests,
* cop_missions.", which asks the reader to know this addon's data folder in
* order to understand a sentence whose only instruction is "update through
* the launcher". The label alone is not enough either, because two files
* share one ("San d'Oria" is both a quest log and a mission line), so the
* kind rides along (2026-09-06).
--]]
local function areaTitle(area)
    return string.format('%s %s', tostring(area.label),
        area.kind == 'missions' and 'missions' or 'quests');
end

--[[
* The second per-sync rebuild: which areas the server confirmed.
*
* BUILT WHOLE AND ASSIGNED AT THE END, the same discipline rebuildCompleted
* keeps and for the same reason -- this runs inside packet_in's pcall, which
* catches and carries on. Written in place, a throw anywhere below left the
* four halves of one answer disagreeing: the sets saying an area is out of
* date while the banner that explains what to do about it had not been built
* yet, so the rows read "(update dwtracker for steps)" with nothing on screen
* saying why. A handshake that does not finish now costs the last one, which
* is stale rather than incoherent (2026-09-06).
--]]
local function rebuildMismatch(hashes)
    local count    = 0;
    local mismatch = T{ };
    local badSet   = { };
    local goodSet  = { };

    for _, area in ipairs(dataAreas) do
        if (hashes[area.area] == area.hash) then
            count               = count + 1;
            goodSet[area.area]  = true;
        else
            mismatch:append(areaTitle(area));
            badSet[area.area] = true;
        end
    end

    -- Areas the server offers that this addon has no file for at all.
    for stem in pairs(hashes) do
        local known = false;

        for _, area in ipairs(dataAreas) do
            if (area.area == stem) then
                known = true;
            end
        end

        if (not known) then
            mismatch:append(stem .. ' (missing here)');
        end
    end

    -- Sorted, because the second loop above walks a string-keyed table and
    -- `pairs` order is whatever the hash layout happens to be: the banner
    -- naming the same three areas in a different order after each handshake
    -- reads like the list changed when nothing did.
    table.sort(mismatch);

    -- The banner's sentence, built HERE rather than in the render. It was a
    -- `table.concat` over as many as twelve area names plus a `string.format`
    -- per frame, for a line that changes only when a handshake lands.
    local line = #mismatch > 0
        and string.format('Data out of date for: %s.', table.concat(mismatch, ', '))
        or nil;

    -- The commit: six assignments with nothing between them that can throw.
    -- `serverHashes` rides along rather than being written by the caller
    -- before the rebuild, so a throw cannot leave the window holding the new
    -- hashes and the old verdict about them.
    state.serverHashes  = hashes;
    state.verifiedCount = count;
    state.verifiedSet   = goodSet;
    state.verifiedSeen  = true;
    state.mismatched    = mismatch;
    state.mismatchSet   = badSet;
    state.mismatchLine  = line;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        -- An envelope is the server speaking dwtracker, whatever it carries.
        serverSilent  = false;

        -- A new answer earns a new complaint if it too is malformed.
        badRecordSaid = false;

        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %s, addon expects %d. Update dwtracker.',
                tostring(parts[2]), PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;
            draft           = nil;

            -- A d| envelope IS the answer, whatever version it announced.
            -- Returning with the hello/sync pair still outstanding let
            -- checkAnswers re-send them and then replace the one accurate
            -- diagnosis on screen ("Update dwtracker") with "No answer from
            -- the server. Is DriftwoodXI up to date?" -- about a server that
            -- had just answered twice. The same fix the `status` branch below
            -- already carries, and the one dwfame made on 2026-08-15.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.inbound = parts[3];

        -- A response is DRAFTED whole and committed at its `z|` (see `draft`
        -- above). The sections used to be emptied right here and refilled
        -- record by record -- which meant the window told the player they had
        -- no active quests for every frame between this packet and the last
        -- one of the burst, and told them so for good if the burst never
        -- finished.
        if (state.inbound == 'hello') then
            draft = { hashes = { } };
        elseif (state.inbound == 'sync') then
            draft = {
                nation         = nil,
                rank           = nil,
                activeQuests   = T{ },
                activeMissions = T{ },
                cq             = T{ },
                cm             = T{ },
            };
        else
            draft = nil;
        end

        --[[
        * THE ASK IS NOT MARKED ANSWERED HERE ANY MORE -- it is marked at the
        * `z|` that commits the draft (Phase 2 review, 2026-09-06; dwsquad's
        * fix in the same round). It used to be, and that was right while the
        * `d|` was also the reset: the envelope's arrival WAS the answer,
        * because its first record had already changed the window. Now the
        * answer is the close, and an envelope whose close never arrives -- a
        * dropped packet, a map restart between records -- leaves the last
        * complete journal standing. Marked answered here, that stale journal
        * would stand until the next zone line: checkAnswers never re-asks an
        * answered read. Marked at the close, a lost `z|` is a lost ANSWER and
        * the ordinary five-second retry recovers it. The `status` wrap below
        * still answers both verbs at once, because that envelope carries the
        * refusal that is the whole answer.
        --]]

        -- A refusal raised before a verb opened its own envelope arrives
        -- wrapped in `d|1|status` (dwt.lua's shape). That IS the answer to
        -- both outstanding verbs: left unanswered, checkAnswers re-sends the
        -- hello/sync pair in five seconds and then replaces the server's
        -- precise sentence ("The tracker is not loaded.") with a "no answer"
        -- diagnosis that is simply untrue.
        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state:
    -- the sentence saying why something was refused is worth more than the
    -- response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        --[[
        * A BARE `m|` OR `e|` MUST NOT BLANK THE STATUS LINE. The render skips
        * the whole status block for an empty string -- sentence, freshness
        * marker and all -- so a truncated status record made the window go
        * silent at precisely the moment the server was trying to say
        * something, and left `statusBad` set with nothing red to read
        * (2026-09-06).
        --]]
        if (text == '') then
            text = kind == 'e' and 'The server refused the request without saying why.'
                or 'The server sent a status line with nothing in it.';
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwtracker'):append(chat.error(state.status)));

            --[[
            * An error raised AFTER the envelope opened arrives bare, with no
            * `z|` behind it (squad_storage.lua's `wrapped` writes the record
            * straight out once `opened` is set), so nothing else would ever
            * close this envelope: the draft would keep accepting records from
            * whatever answer arrived next, outside any envelope of its own,
            * and the ask that raised it would still be outstanding -- so five
            * seconds later checkAnswers re-sends it and then replaces the
            * server's precise sentence with a "no answer" diagnosis that is
            * simply untrue. The refusal IS the end of this answer: say why,
            * throw the half-written draft away, and leave the last complete
            * journal on screen (2026-09-06).
            --]]
            state.inbound = nil;
            draft         = nil;

            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            -- The command exists but tracker_core.lua is not loaded (dwt.lua's
            -- own refusal). Asking again cannot help until a map restart, and
            -- a map restart logs everyone out -- detect once and go quiet.
            if (string.find(line, 'The tracker is not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end
        end

        return;
    end

    -- The Phase 6 dirty ping, honoured from day one so deployment order
    -- between addon and server cannot matter: one record, outside any
    -- envelope, answered with a fresh sync. Sync ALONE, not the hello pair:
    -- data hashes cannot change inside a map session (new data means a map
    -- restart, which logs everyone out), so re-asking would double the chat
    -- lines a ping costs for nothing. The mismatch state from the session's
    -- hello stands.
    if (kind == 'p') then
        serverSilent = false;
        ask('sync');

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    --[[
    * A `z|` CLOSES THE ENVELOPE WHATEVER THE ADDON MADE OF IT. This test used
    * to sit behind `draft ~= nil`, so a verb this addon does not model -- a
    * server newer than the client opening `d|1|<something>`, which the format
    * doc's additive rule explicitly allows -- left `state.inbound` set for the
    * rest of the session. The draft gate below kept anything from being
    * misread, so nothing was ever drawn wrong; but "which envelope am I
    * inside" is the reader's one statement about where it is on this wire,
    * and it must not be able to stay permanently false (2026-09-06).
    --]]
    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        -- The close is the answer (see the `d|` branch). Answered whatever the
        -- draft made of it: a verb this addon does not model still finished.
        answered(closing);

        if (draft == nil) then
            return;
        end

        if (closing == 'sync') then
            -- The one moment the journal changes: six assignments with no
            -- frame in between, so the tabs never draw a half-arrived log.
            state.nation         = draft.nation;
            state.rank           = draft.rank;
            state.activeQuests   = draft.activeQuests;
            state.activeMissions = draft.activeMissions;
            state.cq             = draft.cq;
            state.cm             = draft.cm;
            state.syncedAt       = os.clock();

            -- BUMPED BEFORE THE REBUILD, not after. The completed tabs cache
            -- their filtered row list against this counter, and the six
            -- assignments above have already moved the model -- so a rebuild
            -- that threw (packet_in's pcall catches and carries on) would
            -- otherwise leave the cache believing it still matched.
            modelRev = modelRev + 1;

            rebuildCompleted();

            state.status    = 'Synced.';
            state.statusBad = false;
        elseif (closing == 'hello') then
            rebuildMismatch(draft.hashes);

            modelRev = modelRev + 1;
        end

        draft = nil;

        return;
    end

    if (kind == 'h') then
        -- `hashes` exists only on the hello draft. An `h|` arriving inside a
        -- SYNC envelope is a server this addon cannot be right about, and
        -- indexing the absent table threw -- inside packet_in's pcall, which
        -- writes a "bad record" chat line per packet (2026-09-06).
        if (draft.hashes ~= nil and parts[2] ~= nil and parts[2] ~= '') then
            draft.hashes[parts[2]] = parts[3];
        end

        return;
    end

    -- Every record below fills the SYNC draft, and every one of them indexes
    -- a field the hello draft does not have. Same reasoning as `h|` above:
    -- refuse the record rather than throw once per packet.
    if (draft.activeQuests == nil) then
        return;
    end

    if (kind == 's') then
        draft.nation = wireId(parts[2]);
        draft.rank   = wireId(parts[3]);

        return;
    end

    --[[
    * AN ACTIVE ROW WHOSE NUMBERS DO NOT PARSE IS THE u| SHAPE, NOT A GUESS.
    *
    * Each of these fields used to come back through `wireInt(x, 0)`, which
    * both floored a fractional field and answered 0 for one that was not a
    * number at all -- so a misread step rendered as "(step 2 of 5)" with the
    * pane highlighting step 2, and a misread LOG filed the row under quest
    * log 0 (San d'Oria), name and all. Both are claims the server did not
    * make. A log or an id that refuses drops the record; a step or a count
    * that refuses -- or a pair that does not hang together, "(step 9 of 5)" --
    * keeps the entry and renders it exactly as the server's own u| record
    * does: active, nothing highlighted (2026-09-06).
    --]]
    if (kind == 'aq') then
        local log = wireId(parts[2]);

        if (log == nil) then
            return;
        end

        for _, entry in ipairs(split(parts[3], ',')) do
            local bits = split(entry, ':');

            if (#bits >= 3) then
                local id   = wireId(bits[1]);
                local step = wireId(bits[2]);
                local n    = wireId(bits[3]);

                if (id ~= nil and step ~= nil and n ~= nil and stepPairOk(step, n)) then
                    draft.activeQuests:append(T{ log = log, id = id, step = step, n = n });
                elseif (id ~= nil) then
                    draft.activeQuests:append(T{ log = log, id = id, step = 0, n = 0, unclear = true });
                end
            end
        end

        return;
    end

    if (kind == 'am') then
        local log  = wireId(parts[2]);
        local bits = split(parts[3], ':');

        if (log ~= nil and #bits >= 3) then
            local id   = wireId(bits[1]);
            local step = wireId(bits[2]);
            local n    = wireId(bits[3]);

            if (id ~= nil and step ~= nil and n ~= nil and stepPairOk(step, n)) then
                draft.activeMissions[log] = T{ id = id, step = step, n = n };
            elseif (id ~= nil) then
                draft.activeMissions[log] = T{ id = id, step = 0, n = 0, unclear = true };
            end
        end

        return;
    end

    -- u| -- the server evaluated this entry's authored steps and could not
    -- name a unique current one. The entry is active; nothing highlights.
    -- The honest alternative to guessing, rendered as exactly that.
    if (kind == 'u') then
        local log = wireId(parts[3]);
        local id  = wireId(parts[4]);

        if (log == nil or id == nil) then
            return;
        end

        if (parts[2] == 'q') then
            draft.activeQuests:append(T{ log = log, id = id, step = 0, n = 0, unclear = true });
        elseif (parts[2] == 'm') then
            draft.activeMissions[log] = T{ id = id, step = 0, n = 0, unclear = true };
        end

        return;
    end

    if (kind == 'cq' or kind == 'cm') then
        local store = kind == 'cq' and draft.cq or draft.cm;
        local log   = wireId(parts[2]);

        if (log == nil) then
            return;
        end

        store[log] = store[log] or T{ };

        for _, entry in ipairs(split(parts[3], ',')) do
            local bits = split(entry, ':');

            if (#bits >= 2) then
                -- A CHUNK WHOSE INDEX OR VALUE REFUSES IS DROPPED. Both used
                -- to fall back to a number: the index to 0 and the value to
                -- 0 via `tonumber(x, 16) or 0`. A misread index put the bits
                -- on the wrong thirty-two ids -- chunk 0 is quest ids 0-31,
                -- so one bad field could mark a character's first thirty-two
                -- San d'Oria quests complete (2026-09-06).
                local index = wireId(bits[1]);
                local value = wireChunk(bits[2]);

                if (index ~= nil and value ~= nil) then
                    store[log][index] = value;
                end
            end
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWTDATA is
* ours: consumed here and blocked so the chat log never sees it -- before
* parsing, so a malformed record cannot leak as noise.
--]]
ashita.events.register('packet_in', 'dwtracker_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    -- Every line anybody says in the zone comes through here, and cutting the
    -- fifteen-byte sender field out of each one to compare it was two string
    -- allocations per chat line in a crowded city. Every Driftwood data sender
    -- starts with an underscore and no character name can, so one byte answers
    -- "not ours" for every real sentence before any of that happens
    -- (dwfame's prefilter, 2026-09-06).
    if (e.data_modified:byte(0x09) ~= 0x5F) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    --[[
    * ONCE PER ENVELOPE, not once per packet. This print is the last resort
    * for a parser bug nobody foresaw, and the shape of the wire underneath it
    * is a burst: a sync is fifteen-odd records, a completion-heavy character's
    * is more, and whatever broke the first one usually breaks all of them --
    * fifteen identical red lines in the chat log, on every sync, for as long
    * as the server keeps answering. The latch clears at the next `d|`, so the
    * player is told about each broken answer exactly once and a server that
    * recovers says nothing at all (the suite's burst-ceiling rule; 1.1.0).
    --]]
    if (not ok and not badRecordSaid) then
        badRecordSaid = true;

        print(chat.header('dwtracker'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

--[[
* THE TOOLTIPS, in one table rather than one literal per call site, so the
* harness can assert them and so two controls that mean the same thing cannot
* drift into two sentences. The suite's rule: say what the control DOES, and
* for a greyed one say why it cannot right now; never repeat the label, never
* tooltip the self-evident. Tips carrying a number are formatted at the call
* site from the pieces below.
*
* The tone this window owes is not the suite's usual one. Every sentence here
* has to keep the renderer promise visible: what is on screen is the SERVER's
* reading of the player's own journal, and where the window cannot prove
* something it says so rather than filling the gap.
--]]
local TIPS = {
    refresh       = 'Ask the server for your journal again. Every zone line and every window-open does this on its own.',
    refreshSilent = 'The server has not answered twice running, so the automatic syncs have stopped. This asks once more, deliberately.',
    find          = 'Filters every tab by the entry\'s name or its area. Nothing is sent to the server, and nothing is forgotten when you empty it.\n`/dwt find <text>` fills this box from the chat line.',
    clear         = 'Empty the find box and show every row again.',
    queued        = 'Commands waiting on the client\'s chat throttle. One leaves about every second; nothing is lost while they wait.',
    copy          = 'Copy what Active Quests and Active Missions are showing -- names, the step you are on, and what that step says -- to the clipboard. The find box narrows it; the zone switch does not, because a paste has no way to say a row was left out.',
    expand        = 'Open every quest that has a step guide.',
    collapse      = 'Close them all again.',
    synced        = 'How long ago the server last answered. The window never recomputes anything between syncs -- it draws the last answer it was given.',
    statusOk      = 'What the server last said about this window. Green is the server answering normally.',
    statusBad     = 'What went wrong. The tracker shows nothing rather than guessing, so a red line here means rows may be missing, never that a row is wrong.',
    mismatch      = 'These areas\' data files here disagree with the server\'s copy. Names still render from your own files; step guidance stays off for those areas until dwtracker is updated through the launcher.',
    nation        = 'Your allegiance and rank, as the server\'s own mission log holds them.',
    completed     = 'Completed. The server\'s own log says so; this window adds nothing.',
    -- The truth per DWTRACKER_FORMAT.md 6.15, which both the old wording here
    -- ("once re-flagged it shows under Active too") and the obvious rewrite of
    -- it get wrong: `getQuestStatus` answers COMPLETED forever once the bit is
    -- set, so a re-accepted repeatable normally STAYS on this tab for its whole
    -- repeat run. Only the few scripts that delQuest themselves first (Divine
    -- Might) cycle back to Active. Saying otherwise sends a player to look for
    -- a row that is not going to appear.
    repeatable    = 'Finished, and it can be taken again. A repeat run usually stays on this tab rather than moving to Active -- the completion bit the server reads is still set -- so this row is where the quest lives either way.',
    areaColumn    = 'Which data file the entry comes from -- the quest log or mission line it belongs to.',
    stepCurrent   = 'The step the server places you on, from your real quest variables. Nothing here is this window\'s opinion.',
    stepDone      = 'A step your state says you are already past.',
    stepAhead     = 'A step ahead of where you are.',
    stepPos       = 'Where the step happens: the zone, the map cell you can read off your own map window, and the raw coordinates behind it.',
    waypoint      = 'Distance and compass bearing from where you are standing to this step\'s spot. Drawn only when the hint names the zone you are in; nothing is drawn rather than a direction that might be wrong.',
    waypointRow   = 'How far this row\'s current step is from where you are standing. It shows on a closed row so you can see what is nearby without opening anything, and only when the step names the zone you are in.',
    waypointHere  = 'You are standing on the spot this step names.',
    unclearPane   = 'Your variables fit more than one of these steps, so the server refused to choose. Every step is still listed; none is claimed.',
    pageCap       = 'The list is capped so a six-hundred-row tab stays quick. Type in the find box to reach the rest.',
    sortAZ        = 'Sort the list by name instead of by area. Off is the order the server sent it in -- area by area, entry by entry. Remembered for this character.',
    hereOnly      = 'Show only the quests whose current step names the zone you are standing in. It hides every row the tracker cannot place, cannot verify, or has no spot written for -- so it narrows the list, it does not answer "what can I do here". The count under the list says how many it is holding back. Remembered for this character.',
    coverage      = 'How many of your accepted quests have a step guide this addon can render. The rest are in your journal all the same; the tracker simply has nothing authored for them yet.',

    -- The active row, in each state it can be drawn in.
    rowTree       = 'Open this for the step you are on and what to do next.\nThe step is the server\'s own placement of you, not a guess from this window.',
    rowUnclear    = 'The server could not place you on one step of this entry -- your variables fit more than one. The guide below still lists every step.',
    rowNoGuide    = 'The server has your journal entry, but no step guide is written for it yet.',
    rowMismatch   = 'This addon\'s data for the area disagrees with the server\'s, so step guidance is off until dwtracker is updated through the launcher.',
    rowUnclearFlat = 'The server could not place you on one step of this entry.',
    rowNoGuideFlat = 'No step guide has been written for this entry yet. The name and the log are still the server\'s.',
    rowUnverified  = 'A guide is written for this one, but the server has not confirmed this addon\'s data for the area yet -- so the step number stands and the step text stays off. Refresh, or wait for the next sync.',

    -- The four empty tabs. Each of these is a CLAIM about the player's own
    -- journal, and the one thing a player cannot read off an empty list is
    -- how old the claim is or who made it (1.1.0).
    emptyAQ       = 'The server\'s own reading of your quest log at the last sync -- see the time beside the status line above. Nothing is hidden here; a quest you accept appears at the next sync.',
    emptyAM       = 'No mission underway on your nation\'s line, on Rise of the Zilart, or on Chains of Promathia, by the server\'s own reading at the last sync.',
    emptyCQ       = 'No completion bit is set on any quest in this addon\'s data files. Content the tracker has no data for is not counted here either way.',
    emptyCM       = 'No completion bit is set on any mission this addon carries data for.',
};

--[[
* The two completed tables.
*
* NAME STRETCHES, AREA IS FIXED TO ITS OWN WIDEST LABEL. Both columns used to
* be WidthFixed at 320 and 150, which is 470px plus padding and a scrollbar
* inside a window whose default is 560 wide: a player who narrowed the window
* at all clipped the quest names, and a player who widened it got the same
* 320px column with empty space beside it. A stretched name column spends
* every pixel the window has on the only text here that is long, and the area
* column is measured from the widest label the data files actually carry
* rather than from a guess (2026-09-06).
--]]
local areaColumnWidth = nil;

--[[
* One text measurement, guarded: a metric this window asks for must never be
* the thing that takes a frame down (dwcpx's helper, same reasoning). A client
* whose ImGui does not answer gets the fallback width instead of a throw.
--]]
local function textWidth(text)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return nil;
    end

    local ok, box = pcall(imgui.CalcTextSize, text);

    if (not ok) then
        return nil;
    end

    -- TWO NUMBERS (width, height) is what IGuiManager.lua declares and what
    -- the client answers -- dwah reads it that way in production. The first
    -- draft of this reader wanted a table and fell back to the 64-pixel floor
    -- on every real client, which is narrower than the fixed 150 it replaced;
    -- the harness stub happened to answer a table, so nothing offline could
    -- see it. Both shapes are read, because the binding is the client's
    -- (Phase 2 review, 2026-09-06).
    if (type(box) == 'number') then
        return box;
    end

    if (type(box) == 'table' and type(box[1]) == 'number') then
        return box[1];
    end

    return nil;
end

-- Measured ONCE, on the first frame that draws a table: the area labels come
-- out of the data files and cannot change while the addon is loaded.
local function areaColumn()
    if (areaColumnWidth == nil) then
        local widest = 0;

        for _, area in ipairs(dataAreas) do
            local width = textWidth(area.label);

            if (width ~= nil and width > widest) then
                widest = width;
            end
        end

        -- The header word is 'Area'; a column narrower than its own header is
        -- the one width that always looks broken.
        areaColumnWidth = math.max(widest + 16, 64);
    end

    return areaColumnWidth;
end

local function beginListTable(id)
    if (imgui.BeginTable(id, 2,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Area', ImGuiTableColumnFlags_WidthFixed, areaColumn(), 0);
        imgui.TableSetupScrollFreeze(0, 1);

        --[[
        * THE HEADER ROW IS SUBMITTED BY HAND (1.1.0) so the Area column can
        * explain itself where a column explanation belongs. `TableHeadersRow`
        * puts both headers out in one call and `IsItemHovered` after it can
        * only answer for the last one -- which is why that sentence used to
        * ride EVERY row's area cell instead: three hundred `IsItemHovered`
        * calls a frame, on the page cap, for one fact about the column. The
        * Name column is not tooltipped: its rows already carry the sentence
        * that matters, and the header says all a header can.
        *
        * ImGui's own TableHeadersRow skips a column whose TableSetColumnIndex
        * answers false, and this deliberately does not: the return value is a
        * binding contract from the annotations, not something this file can
        * see, and a client whose binding answers nil would draw NO headers at
        * all. Ignoring it is safe -- TableSetColumnIndex sets the current
        * column either way, and a clipped column's cell sets SkipItems, which
        * TableHeader honours on its first line.
        --]]
        imgui.TableNextRow(ImGuiTableRowFlags_Headers);

        imgui.TableSetColumnIndex(0);
        imgui.TableHeader('Name');

        imgui.TableSetColumnIndex(1);
        imgui.TableHeader('Area');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.areaColumn);
        end

        return true;
    end

    return false;
end

--[[
* The step pane (Phase 1). Steps render from THIS addon's data files, and
* only for areas whose hash agreed with the server at the last hello --
* stale guidance must say "update me", never something wrong. The
* highlight index comes exclusively from the server's record: done steps
* in the theme's dim, the current step in the theme's bright hint, the
* rest dim again. An `unclear` row (the server's u|) shows every step dim
* with a caution line -- active, nothing highlighted, the honest
* alternative to guessing. Colored wrapped text is push/pop rather than
* TextColored because step sentences are long enough to wrap at 560px.
--]]
local function coloredWrapped(color, text)
    --[[
    * THE STRING IS MADE SAFE BEFORE THE PUSH. Everything between
    * PushStyleColor and PopStyleColor is on the hook for the house's hardest
    * ImGui rule -- every Push has its Pop on EVERY path -- and a throw in
    * there is the one path that has none: the render pcall catches it, but
    * `theme.pop` only knows about theme's own pushes, so the frame ends with
    * an extra colour on ImGui's stack. Nothing in this file passes a
    * non-string today; the point is that nothing added later can either
    * (2026-09-06).
    --]]
    local safe = type(text) == 'string' and text or tostring(text);

    imgui.PushStyleColor(ImGuiCol_Text, color);
    imgui.TextWrapped(safe);
    imgui.PopStyleColor();
end

--[[
* THE WAYPOINT LINE (PLANS/DWTRACKER_WAYPOINT_PLAN.md).
*
* Under the bright step, one more line: how far away that step's `pos` is
* from where you are standing, and which way. `!pos` is a GM command --
* players cannot run it and cannot read it -- so the coordinates the hint
* has always carried were, for a player, decoration. This turns them into
* "212 yalms WSW". Nothing new is asked of the server: no wire, no
* protocol, no record. The addon already holds the step and the numbers.
*
* THE AXIS MAPPING IS THE LOAD-BEARING FACT, and it is measured, not
* reasoned. Client and server name their axes differently -- the 0x000A
* position head fills `.z = loc.p.y // Not a typo` and `.y = loc.p.z`
* (src/map/packets/s2c/0x00a_login.cpp:138) -- and a filed bug report caught
* both frames in the same instant: client (562.02, -322.87, 0.00) against
* server (x 562.0214, y 0, z -322.8665). So, with NO sign flip:
*
*     client X == server X       east/west
*     client Y == server Z       north/south   <- the one that matters here
*     client Z == server Y       elevation
*
* and +z is north, which falls out of the 185 map anchors that
* tools/dwtracker_mapgrid.py reproduces. Do not re-derive either from first
* principles: file a report from a known spot and read the two lines.
*
* AND IT DRAWS NOTHING RATHER THAN GUESS. A bearing that is confidently
* wrong is the bug this project exists to rule out, so there is no line at
* all for any of: a step that is not the current one; an unclear row; an
* unverified area (already true upstream -- stepPane is only reached
* through activeRow's verified branch, and that gate must not be weakened);
* a pos carrying no coordinates; no segment naming the zone you are
* standing in; a client that still calls itself zoning; any failed read; or
* a distance past WAYPOINT_MAX, which means the label matched a zone the
* coordinates do not belong to.
--]]

local COMPASS = {
    'N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
    'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW',
};

-- No FFXI zone is 2000 yalms across, so a reading that large is not a long
-- walk -- it is the wrong zone (an instance, a [S] twin, a mis-authored
-- hint). Refuse rather than point.
local WAYPOINT_MAX  = 2000;

-- Close enough that a bearing would spin uselessly as you shuffle.
local WAYPOINT_HERE = 6;

-- LuaJIT 5.1 (what Ashita ships) has math.atan2; 5.3 folded it into a
-- two-argument math.atan and dropped the old name. The offline harness runs
-- this file under the newer one, so bind whichever exists.
local atan2 = math.atan2 or math.atan;

local function normalised(text)
    local out = text:lower():gsub("'", ''):gsub('[^%a%d]+', ' ');

    return (out:gsub('^%s+', ''):gsub('%s+$', ''));
end

local function wordsOf(text)
    local out = {};

    for word in normalised(text):gmatch('%S+') do
        out[#out + 1] = word;
    end

    return out;
end

--[[
* Does this segment's label name the zone the player is standing in?
*
* Compared WORD by word, not character by character: a raw prefix test
* makes "The" match "The Sanctuary of Zi'Tah", while word-wise it takes
* "La Theine" to match La Theine Plateau and refuses "Windurst Waters"
* against Windurst Walls. Either may be the shorter -- hints abbreviate
* ("La Theine") and hints qualify ("Tavnazian Safehold, the lower ledge").
--]]
local function zoneMatches(labelWords, zoneWords)
    if (#labelWords == 0 or #zoneWords == 0) then
        return false;
    end

    for i = 1, math.min(#labelWords, #zoneWords) do
        if (labelWords[i] ~= zoneWords[i]) then
            return false;
        end
    end

    return true;
end

--[[
* One pos hint -> its destinations, in order.
*
* A hint may carry several ("La Theine (J-8) (!pos ...) / Konschtat (I-7)
* (!pos ...)"), and a segment with no label of its own inherits the last
* one that had a label -- which is how the multi-spot hints read.
*
* THE MAP CELL IS NOT PART OF THE LABEL. It sits between the label and the
* coordinates, so reading up to the first '(' takes "J-8)" for the zone
* name and matches nothing. That was a real bug in dwtracker_mapgrid.py for
* the hour after the cells first shipped; the strip below is the same fix.
*
* Memoised on the hint string, because this runs per open tree node per
* frame and these strings never change at runtime.
--]]
local segmentCache = {};

local function segmentsOf(pos)
    local cached = segmentCache[pos];

    if (cached ~= nil) then
        return cached;
    end

    local out     = {};
    local carried = nil;
    local from    = 1;

    while (true) do
        local s, e, x, y, z = pos:find('%(!pos%s+([%-%d%.]+)%s+([%-%d%.]+)%s+([%-%d%.]+)%s*%)', from);

        if (s == nil) then
            break;
        end

        local label = pos:sub(from, s - 1):gsub('%(%a%-%d+%)%s*$', '');

        label = label:match('([^/]*)$') or '';
        label = label:gsub('^[%s,%-]+', ''):gsub('[%s,%-]+$', '');

        if (label ~= '') then
            carried = label;
        end

        -- The character class the pattern matches ('-', digits, '.') also
        -- accepts '1.2.3' and '-.', which `tonumber` answers nil for -- and a
        -- nil reaching the subtraction in waypointFor is an arithmetic throw
        -- inside the render pcall, which closes the window. A segment whose
        -- coordinates do not parse is simply not a destination.
        local sx = tonumber(x);
        local sz = tonumber(z);

        if (sx ~= nil and sz ~= nil) then
            out[#out + 1] = {
                words = wordsOf(label ~= '' and label or (carried or '')),
                x     = sx,
                z     = sz,
            };
        end

        from = e + 1;
    end

    segmentCache[pos] = out;

    return out;
end

-- Zone names come from the client's own resource table, and the normalised
-- split is cached per zone id -- one resource call and one gsub chain per
-- zone rather than per frame.
local zoneWordCache = {};

local function zoneWordsFor(zoneId)
    local cached = zoneWordCache[zoneId];

    if (cached ~= nil) then
        return cached;
    end

    local ok, name = pcall(function ()
        return AshitaCore:GetResourceManager():GetString('zones.names', zoneId);
    end);

    local words = (ok and type(name) == 'string' and name ~= '') and wordsOf(name) or {};

    zoneWordCache[zoneId] = words;

    return words;
end

--[[
* Where the player is, in SERVER axes, or nil.
*
* Every read is inside one pcall: an entity index that has gone stale, a
* memory manager mid-teardown, a resource table that answers nil -- none of
* them may cost a frame, and all of them mean "no line" rather than a
* fallback. The zoning check is not politeness: the entity struct is
* garbage across a zone line, and this addon learned that the hard way
* already (the deferred zone-in sync above).
--]]
local function selfPosition()
    local ok, zoneId, x, z = pcall(function ()
        local memory = AshitaCore:GetMemoryManager();
        local party  = memory:GetParty();
        local player = memory:GetPlayer();
        local entity = memory:GetEntity();

        if (party == nil or player == nil or entity == nil or player:GetIsZoning() ~= 0) then
            return nil;
        end

        local index = party:GetMemberTargetIndex(0);

        if (index == nil or index <= 0) then
            return nil;
        end

        -- client Y IS the server's z; see the axis note above.
        return party:GetMemberZone(0),
            entity:GetLocalPositionX(index),
            entity:GetLocalPositionY(index);
    end);

    if (not ok or type(zoneId) ~= 'number' or type(x) ~= 'number' or type(z) ~= 'number') then
        return nil;
    end

    return zoneId, x, z;
end

--[[
* The player's position, read ONCE PER FRAME.
*
* `selfPosition` is four memory-manager calls inside a pcall, and it used to
* run per current step per open tree node -- the same answer, several times a
* frame, sixty times a second. The position cannot change between two draws of
* one frame, so the frame counter below is the whole cache (2026-09-06).
--]]
local frameNumber   = 0;
local posFrame      = -1;
local posZone, posX, posZ;

local function positionThisFrame()
    if (posFrame ~= frameNumber) then
        posFrame = frameNumber;
        posZone, posX, posZ = selfPosition();
    end

    return posZone, posX, posZ;
end

-- 'nnn yalms  DIR', 'here', or nil for every refusal in the note above.
--[[
* The numbers behind the line: distance in yalms and the offsets it came from,
* or nil for every refusal in the note above.
*
* SPLIT OUT OF waypointFor (1.1.0) because the "in this zone" filter asks only
* WHETHER there is a line -- and it asks twice per row per frame, once to count
* what it is hiding and once to draw what it is not. A formatted string built
* and thrown away is pure churn, and this is the half that decides.
--]]
local function waypointVector(step)
    if (type(step.pos) ~= 'string') then
        return nil;
    end

    local zoneId, px, pz = positionThisFrame();

    if (zoneId == nil) then
        return nil;
    end

    local zoneWords = zoneWordsFor(zoneId);

    for _, seg in ipairs(segmentsOf(step.pos)) do
        if (zoneMatches(seg.words, zoneWords)) then
            local dx   = seg.x - px;
            local dz   = seg.z - pz;
            local dist = math.sqrt(dx * dx + dz * dz);

            if (dist > WAYPOINT_MAX) then
                return nil;
            end

            return dist, dx, dz;
        end
    end

    return nil;
end

local function waypointFor(step)
    local dist, dx, dz = waypointVector(step);

    if (dist == nil) then
        return nil;
    end

    if (dist < WAYPOINT_HERE) then
        return 'here';
    end

    -- +z is north, +x is east, so the bearing clockwise from north
    -- is atan2(east, north) -- not the other way round.
    local bearing = math.deg(atan2(dx, dz)) % 360;

    return string.format('%d yalms  %s',
        math.floor(dist + 0.5),
        COMPASS[math.floor((bearing + 11.25) / 22.5) % 16 + 1]);
end

--[[
* The two lines a step can draw, memoised on the step table itself.
*
* Every one of these is a constant: the step's text and its `pos` hint come
* out of a data file loaded once, and the only thing that varies between
* frames is WHICH step carries the '>' marker. Building them with
* `string.format` and a concatenation per step per frame was pure churn for a
* window that can have several trees open at 60 fps (2026-09-06).
--]]
local stepLineCache = {};

local function stepLines(step, index)
    local lines = stepLineCache[step];

    if (lines == nil) then
        -- A step with no `text` is malformed data the linter refuses, and the
        -- server answers it with u| -- which still renders this pane. `%s` of
        -- nil is the four letters 'nil' on the client's LuaJIT 2.1 (measured
        -- 2026-09-06; it is Lua 5.1 PUC that raises, and 5.4 prints it too),
        -- so the step line would have read "3. nil". Say what is missing
        -- instead.
        local text = type(step.text) == 'string' and step.text
            or '(step text missing from this addon\'s data file)';

        lines = {
            plain   = string.format('   %d. %s', index, text),
            current = string.format('>  %d. %s', index, text),
            pos     = type(step.pos) == 'string' and ('        ' .. step.pos) or nil,
        };

        stepLineCache[step] = lines;
    end

    return lines;
end

local function stepPane(area, entry, row)
    local steps = entry.steps;

    for i, step in ipairs(steps) do
        local current = (not row.unclear) and i == row.step;
        local color   = current and theme.colors.hint or theme.colors.dim;
        local lines   = stepLines(step, i);

        coloredWrapped(color, current and lines.current or lines.plain);

        if (imgui.IsItemHovered()) then
            --[[
            * AN UNCLEAR ROW'S STEPS ARE NEITHER DONE NOR AHEAD. `row.step` is
            * 0 there, so `i < row.step` was false for every line and each one
            * was labelled "A step ahead of where you are." -- a claim about
            * the player's position made by the very pane whose caution line
            * says the server refused to make one (2026-09-06).
            --]]
            imgui.SetTooltip(row.unclear and TIPS.unclearPane
                or (current and TIPS.stepCurrent
                    or (i < row.step and TIPS.stepDone or TIPS.stepAhead)));
        end

        if (lines.pos ~= nil) then
            coloredWrapped(theme.colors.dim, lines.pos);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.stepPos);
            end
        end

        -- The waypoint rides the CURRENT step alone. A bearing under a step
        -- you have already done, or have not reached, is a direction to walk
        -- in for no reason -- and `current` is false for every step of an
        -- unclear row, which is the second refusal for free.
        if (current) then
            local waypoint = waypointFor(step);

            if (waypoint ~= nil) then
                coloredWrapped(theme.colors.hint, '        -> ' .. waypoint);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(waypoint == 'here' and TIPS.waypointHere or TIPS.waypoint);
                end
            end
        end
    end

    if (row.unclear) then
        coloredWrapped(theme.colors.warn,
            'The tracker cannot tell which step you are on right now, so none is highlighted.');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.unclearPane);
        end
    end
end

--[[
* Expand all / Collapse all (1.1.0).
*
* Quest rows collapse by default -- mission rows do not, because a line holds
* at most one -- so a player with a dozen accepted quests had a dozen arrows
* to click to see where they stood in each. The two buttons set this for ONE
* frame and it is cleared at the end of the render; ImGui keeps each node's
* own state afterwards, so a single arrow still works normally the moment the
* button is released.
--]]
local expandRequest = nil;

--[[
* The name a row draws.
*
* ONE function, called by the row AND by the find box, because the search has
* to match what the player reads -- these were two copies of the same
* expression before, one of them able to drift. A `name` that is not a string
* (malformed data) falls back to the id rather than reaching imgui.Text, where
* a nil is a throw inside the render pcall.
--]]
local function activeName(kind, area, id)
    local entry = area ~= nil and area.entries[id] or nil;
    local name  = entry ~= nil and entry.name or nil;

    if (type(name) == 'string' and name ~= '') then
        return name;
    end

    return string.format('%s #%d', kind == 'q' and 'quest' or 'mission', id);
end

--[[
* One active row: a tree node when the entry has renderable steps, a plain
* line when it does not. The summary after the name is server-asserted
* state, dimmed so the name stays the loudest thing on the row.
--]]
--[[
* One active row's presentation strings, MEMOISED ON THE ROW (1.1.0).
*
* Every string here is fixed for the life of the row: the entry's name comes
* out of a data file loaded once, and the step numbers come out of the same
* committed answer the row itself does -- and a commit replaces the row tables
* wholesale, so this memo cannot outlive what it was built from. They were two
* `string.format` calls and a concatenation per row per frame, plus the find
* box's `string.lower` over the pair of them once per row per frame again
* whenever a needle was set.
*
* `unverified` is deliberately NOT in here. It moves when a hello lands
* without the rows changing at all, and nothing below depends on it.
--]]
local function rowUI(kind, area, log, id, row, label)
    local ui = row.ui;

    if (ui ~= nil) then
        return ui;
    end

    local entry    = area ~= nil and area.entries[id] or nil;
    local hasSteps = entry ~= nil and type(entry.steps) == 'table' and #entry.steps > 0;
    local name     = activeName(kind, area, id);
    local summary;

    if (row.unclear) then
        summary = '(unclear)';
    elseif (hasSteps and row.step > 0) then
        summary = string.format('(step %d of %d)', row.step, row.n);
    else
        summary = '(no guide yet)';
    end

    ui = {
        entry    = entry,
        hasSteps = hasSteps,
        name     = name,
        summary  = summary,
        tree     = string.format('%s##dwt_%s_%d_%d', name, kind, log, id),
        dash     = label ~= nil and ('-- ' .. tostring(label)) or nil,
        search   = string.lower(name .. ' ' .. tostring(label)),
    };

    row.ui = ui;

    return ui;
end

--[[
* MAY THIS ROW BE GUIDED, AND IS ITS AREA PROVABLY OUT OF DATE.
*
* Steps render only for areas whose hash AGREED at this session's hello
* (verifiedSet), never merely for the absence of a recorded mismatch -- a sync
* that outran a dropped hello response must render plain rows, not unverified
* guidance. The '(update dwtracker for steps)' label is reserved for a PROVEN
* disagreement, where updating really is the fix. The belt to the handshake's
* suspenders is the step count: a count that disagrees with the server's is
* data drift the hash should have caught, and is treated exactly like a
* mismatch rather than highlighting into the wrong list.
*
* EXTRACTED (1.1.0) because two callers now need the identical answer -- the
* row itself and the "in this zone" filter beside it -- and a second copy of
* this decision is precisely the drift the T1 rule cannot survive. It is the
* same reason `activeName` exists: the search has to match what the player
* reads, and the filter has to hide only what the row would refuse to guide.
--]]
local function rowGuide(area, row, ui)
    local unverified = area == nil or state.verifiedSet[area.area] ~= true;
    local mismatched = area ~= nil and state.mismatchSet[area.area] == true;

    if (ui.hasSteps and not row.unclear and row.n ~= #ui.entry.steps) then
        unverified = true;
        mismatched = true;
    end

    return (ui.hasSteps and not unverified), mismatched;
end

--[[
* Is this row's current step in the zone the player is standing in?
*
* Every refusal DWTRACKER_WAYPOINT_PLAN.md lists still applies, because this
* asks `waypointFor` the same question the marker does -- so a row the tracker
* cannot place, cannot verify, or has no authored spot for answers false. That
* makes the filter narrower than "what can I do here", which is why the tab
* says how many rows it is holding back whenever the switch is on (1.1.0).
--]]
local function rowHereNow(area, row, ui)
    local guided = rowGuide(area, row, ui);

    if (not guided or row.unclear or row.step <= 0) then
        return false;
    end

    -- The numbers, not the sentence: this runs twice per row per frame while
    -- the switch is on and the string would be thrown away both times.
    local step = ui.entry.steps[row.step];

    return step ~= nil and waypointVector(step) ~= nil;
end

local function activeRow(kind, area, log, id, row, label)
    local ui       = rowUI(kind, area, log, id, row, label);
    local entry    = ui.entry;
    local name     = ui.name;
    local hasSteps = ui.hasSteps;
    local summary  = ui.summary;

    local guided, mismatched = rowGuide(area, row, ui);

    if (guided) then
        --[[
        * THE NAME IS PART OF THE TREE NODE'S LABEL, not a SameLine text after
        * it. The node used to be labelled '##dwt_q_0_5' -- an arrow and
        * nothing else -- so the only place a click opened the guide was the
        * twelve-pixel triangle, and clicking the quest name (which is what
        * anyone does) did nothing at all. The '##' id half is unchanged, so
        * ImGui's remembered open/closed state survives this (2026-09-06).
        --]]
        if (expandRequest ~= nil) then
            imgui.SetNextItemOpen(expandRequest, ImGuiCond_Always);
        end

        local open = imgui.TreeNodeEx(ui.tree,
            kind == 'm' and ImGuiTreeNodeFlags_DefaultOpen or 0);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.rowTree);
        end

        imgui.SameLine();

        if (row.unclear) then
            imgui.TextColored(theme.colors.warn, summary);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.rowUnclear);
            end
        else
            imgui.TextColored(theme.colors.hint, summary);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(row.step > 0
                    and string.format('Step %d of %d, by the server\'s reading of your progress. Open the row to see it.', row.step, row.n)
                    or TIPS.rowNoGuide);
            end
        end

        if (label ~= nil) then
            imgui.SameLine();
            imgui.TextDisabled(ui.dash);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.areaColumn);
            end
        end

        --[[
        * THE DISTANCE ON A CLOSED ROW (1.1.0).
        *
        * The waypoint line already lives under the current step, which means
        * it is invisible until the row is opened -- so "which of the eleven
        * things I have accepted can I do from where I am standing" took eleven
        * clicks to answer. On a CLOSED row the same reading rides the header;
        * on an open one it does not, because the pane below is already drawing
        * it and twice is noise.
        *
        * Every refusal in DWTRACKER_WAYPOINT_PLAN.md still applies unchanged:
        * this is reached only through the verified-area branch, only for the
        * server's own current step, and `waypointFor` still draws nothing at
        * all rather than a bearing it cannot stand behind.
        --]]
        if (open) then
            stepPane(area, entry, row);
            imgui.TreePop();
        elseif (not row.unclear and row.step > 0) then
            local step     = entry.steps[row.step];
            local waypoint = step ~= nil and waypointFor(step) or nil;

            if (waypoint ~= nil) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.hint, waypoint);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(waypoint == 'here' and TIPS.waypointHere or TIPS.waypointRow);
                end
            end
        end
    else
        imgui.Bullet();
        imgui.SameLine();
        imgui.Text(name);
        imgui.SameLine();
        imgui.TextDisabled(mismatched and hasSteps and '(update dwtracker for steps)' or summary);

        if (imgui.IsItemHovered()) then
            if (mismatched and hasSteps) then
                imgui.SetTooltip(TIPS.rowMismatch);
            elseif (row.unclear) then
                imgui.SetTooltip(TIPS.rowUnclearFlat);
            elseif (hasSteps) then
                --[[
                * A GUIDE EXISTS AND IS BEING WITHHELD, which is not the same
                * sentence as "none is written". This branch is reached with a
                * sync answered and its hello not -- a dropped handshake
                * packet, or the seconds between the two asks -- and the row
                * beside the tooltip is reading "(step 3 of 5)" at the time.
                * It used to be told, over that number, that no step guide has
                * been written for the entry yet (2026-09-06).
                --]]
                imgui.SetTooltip(TIPS.rowUnverified);
            else
                imgui.SetTooltip(TIPS.rowNoGuideFlat);
            end
        end

        if (label ~= nil) then
            imgui.SameLine();
            imgui.TextDisabled(ui.dash);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.areaColumn);
            end
        end
    end
end

--[[
* The journal search (1.0.15). One box above the tabs, matched case-blind
* against the entry's name and its area label on every tab -- six hundred
* entries is a list, not a menu. Purely a view: nothing is asked of the
* server and nothing is forgotten when the box empties.
--]]
local findText = T{ '' };

-- The box's own buffer length. Named because `/dwt find <text>` writes into
-- the same holder and the widget copies it into a C buffer of exactly this
-- size: a longer string would be cut somewhere this file did not choose.
local FIND_MAX = 47;

-- The needle, lowercased ONCE per frame in renderWindow rather than once per
-- row: on a completion-heavy character findMatches runs six hundred times a
-- frame, and it was lowercasing the same eight characters every one of them.
local needle = '';

local function findMatches(haystack)
    if (needle == '') then
        return true;
    end

    return string.find(haystack, needle, 1, true) ~= nil;
end

-- One active row's haystack, off the row's own memo (rowUI) -- the same string
-- the row draws its name from, lowercased once for the life of the row rather
-- than rebuilt per row per frame while a needle is set.
local function activeMatches(kind, area, log, id, row, label)
    if (needle == '') then
        return true;
    end

    return findMatches(rowUI(kind, area, log, id, row, label).search);
end

local function findRow()
    imgui.PushItemWidth(240);
    imgui.InputTextWithHint('##dwtracker_find', 'find a quest or mission...', findText, FIND_MAX + 1);
    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.find);
    end

    if ((findText[1] or '') ~= '') then
        imgui.SameLine();

        if (imgui.SmallButton('Clear##dwtracker_find_clear')) then
            findText[1] = '';
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.clear);
        end
    end
end

--[[
* WHAT THIS TAB CAN AND CANNOT GUIDE (1.1.0).
*
* Each row says "(step 3 of 5)", "(no guide yet)" or "(unclear)" on its own,
* and with a dozen accepted quests the shape of the answer -- how much of your
* own journal this window is actually able to walk you through -- takes
* reading all of them. One line says it, in the addon's own terms rather than
* by implication. Built once per model change, like everything else here that
* is a function of the last answer; `verifiedSet` moves the count and bumps
* `modelRev` when it does.
--]]
local coverageRev  = -1;
local coverageText = '';

local function questCoverage()
    if (coverageRev == modelRev) then
        return coverageText;
    end

    coverageRev = modelRev;

    local guided  = 0;
    local unclear = 0;

    for _, row in ipairs(state.activeQuests) do
        local area = questsByLog[row.log];
        local ui   = rowUI('q', area, row.log, row.id, row,
            area ~= nil and area.label or string.format('log %d', row.log));

        if (row.unclear) then
            unclear = unclear + 1;
        elseif (rowGuide(area, row, ui)) then
            guided = guided + 1;
        end
    end

    coverageText = string.format('%d of %d with a step guide%s', guided, #state.activeQuests,
        unclear > 0 and string.format(', %d the server could not place.', unclear) or '.');

    return coverageText;
end

--[[
* The "in this zone" switch (1.1.0), and the reason it is on THIS tab only.
*
* A mission line holds at most one row per log and all three are on screen at
* once, so filtering the missions tab would hide more than it helps; the quest
* tab is the one that runs to a dozen rows. The switch is narrower than "what
* can I do here" -- it hides every row the tracker cannot place, cannot verify
* or has no authored spot for -- so the tab says so out loud whenever it is
* on, rather than letting an omission read as an answer.
--]]
local hereOnly = T{ config.hereOnly == true };

local function setHereOnly(value)
    value = (value == true);

    hereOnly[1]     = value;
    config.hereOnly = value;

    saveConfig();
end

local function activeQuestsTab()
    if (#state.activeQuests == 0) then
        imgui.TextDisabled('No active quests. Accept one and it appears here at the next sync.');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.emptyAQ);
        end

        return;
    end

    -- Quest rows collapse by default (a mission line holds one row, a quest
    -- log holds a dozen), so these two exist for the player who wants to read
    -- every step at once. Small buttons and a fixed pair of labels: neither
    -- changes width, so the row never shifts under the mouse.
    if (imgui.SmallButton('Expand all##dwtracker_expand')) then
        expandRequest = true;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.expand);
    end

    imgui.SameLine();

    if (imgui.SmallButton('Collapse all##dwtracker_collapse')) then
        expandRequest = false;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.collapse);
    end

    imgui.SameLine();

    if (imgui.Checkbox('In this zone##dwtracker_here', hereOnly)) then
        setHereOnly(hereOnly[1]);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.hereOnly);
    end

    --[[
    * THE COVERAGE LINE GETS ITS OWN LINE, not a SameLine after the switch.
    * Its longest form -- "4 of 11 with a step guide, 1 the server could not
    * place." -- is close to 380px, and the three controls above it are
    * another 250: past the 520px this window's own minimum lets a player drag
    * it to, and text after a SameLine does not wrap, it runs off the edge.
    --]]
    imgui.TextDisabled(questCoverage());

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.coverage);
    end

    -- The filter needs a position to mean anything, and the client answers
    -- none while it is zoning or before the entity list is up. It stands down
    -- for those frames rather than hiding the whole tab behind a reading that
    -- does not exist, and the line below says which of the two this is.
    --
    -- ASKED ONLY WHILE THE SWITCH IS ON. `positionThisFrame` caches, but the
    -- first call of a frame is nine memory-manager calls inside a pcall, and a
    -- tab whose rows happen to need no waypoint should not pay for one.
    local hereZone  = hereOnly[1] == true and positionThisFrame() or nil;
    local filtering = hereZone ~= nil;

    --[[
    * THE SWITCH ALWAYS SAYS IT IS ON, hidden rows or none, and it says so
    * ABOVE the list rather than under it. A filter whose only trace is the
    * absence of rows turns "the tracker cannot place these" into "there is
    * nothing here", which is the one reading this addon may not let a player
    * make -- and the switch persists across a relog, so it can be on from a
    * session they have forgotten. A note at the bottom of a scrolling child
    * is a note a long list hides, which is why the count is taken in a pass
    * of its own before anything is drawn. That pass costs nothing at all
    * while the switch is off.
    --]]
    local hidden = 0;

    if (filtering) then
        for _, row in ipairs(state.activeQuests) do
            local area  = questsByLog[row.log];
            local label = area ~= nil and area.label or string.format('log %d', row.log);

            if (activeMatches('q', area, row.log, row.id, row, label) and
                not rowHereNow(area, row, rowUI('q', area, row.log, row.id, row, label)))
            then
                hidden = hidden + 1;
            end
        end
    end

    if (hereOnly[1] == true) then
        if (hereZone == nil) then
            imgui.TextColored(theme.colors.warn, '"In this zone" is on, but your position cannot be read right now, so every row is shown.');
        elseif (hidden == 0) then
            imgui.TextColored(theme.colors.hint, 'Showing only steps in this zone.');
        else
            imgui.TextColored(theme.colors.hint, string.format('Showing only steps in this zone -- %d hidden: their next step is elsewhere, or the tracker cannot place it.', hidden));
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.hereOnly);
        end
    end

    imgui.Separator();

    -- Sized from what is left rather than a hard number, so the list ends
    -- where the window does at any height the player drags it to.
    if (imgui.BeginChild('##dwtracker_aq', { -1, -1 }, ImGuiChildFlags_None)) then
        local shown = 0;

        for _, row in ipairs(state.activeQuests) do
            local area  = questsByLog[row.log];
            local label = area ~= nil and area.label or string.format('log %d', row.log);

            if (activeMatches('q', area, row.log, row.id, row, label) and
                (not filtering or rowHereNow(area, row, rowUI('q', area, row.log, row.id, row, label))))
            then
                shown = shown + 1;
                activeRow('q', area, row.log, row.id, row, label);
            end
        end

        if (shown == 0 and hidden == 0) then
            imgui.TextDisabled('No active quest matches the find box.');
        end
    end

    imgui.EndChild();
end

--[[
* The mission logs this window will draw, nation first.
*
* The tail used to be whatever order `pairs` walked the table in -- Zilart
* before Chains of Promathia on one login and after it on the next, for a list
* that had not changed. Sorted, the tail is the order the logs shipped in,
* which is also the order a player met them.
*
* CACHED ON `modelRev`. The answer changes only when a sync commits, and this
* was two table allocations and a sort per frame -- for three logs, sixty
* times a second, plus once more every time the clipboard button asked. The
* list is read-only to every caller (1.1.0).
--]]
local missionRev   = -1;
local missionCache = T{ };

local function missionOrder()
    if (missionRev == modelRev) then
        return missionCache;
    end

    local order = T{ };

    if (state.nation ~= nil and state.activeMissions[state.nation] ~= nil) then
        order:append(state.nation);
    end

    local rest = T{ };

    for log, _ in pairs(state.activeMissions) do
        if (log ~= state.nation) then
            rest:append(log);
        end
    end

    table.sort(rest);

    for _, log in ipairs(rest) do
        order:append(log);
    end

    missionRev   = modelRev;
    missionCache = order;

    return order;
end

local function activeMissionsTab(order)
    if (state.nation ~= nil and state.rank ~= nil) then
        imgui.Text(string.format('%s -- Rank %d', NATION_NAMES[state.nation] or 'Adventurer', state.rank));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.nation);
        end

        imgui.Separator();
    end

    if (#order == 0) then
        imgui.TextDisabled('No mission underway.');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.emptyAM);
        end

        return;
    end

    if (imgui.BeginChild('##dwtracker_am', { -1, -1 }, ImGuiChildFlags_None)) then
        local shown = 0;

        for _, log in ipairs(order) do
            local row   = state.activeMissions[log];
            local area  = missionsByLog[log];
            local label = area ~= nil and area.label or string.format('log %d', log);

            if (activeMatches('m', area, log, row.id, row, label)) then
                shown = shown + 1;
                activeRow('m', area, log, row.id, row, label);
            end
        end

        if (shown == 0) then
            imgui.TextDisabled('No mission matches the find box.');
        end
    end

    imgui.EndChild();
end

--[[
* The filtered completed lists, cached.
*
* Filtering six hundred rows is cheap ONCE and wasteful sixty times a second
* for an answer that only changes when the model changes or the player types.
* The cache is keyed on `modelRev` and the needle exactly as dwah keys its
* view cache -- and it is the whole reason the rows carry a prebuilt `search`
* string (2026-09-06).
--]]
local PAGE_ROWS = 300;

--[[
* A-Z (1.1.0). The completed lists arrive in DATA order -- area by area, id by
* id -- which is the order the areas were authored in and means nothing to a
* player scanning four hundred finished quests for one title. One switch, and
* it is a view: nothing is asked of the server, and the data order is still
* one click away because it is the one the server sent.
*
* ImGui writes a checkbox through a holder table and the persisted value is a
* plain boolean, so the two are synced at each of the places either can move:
* this load, the click, and the settings callback a character change fires
* (dwport's shape, and its reasoning, kept verbatim).
--]]
local sortByName = T{ config.sortByName == true };

local function setSortByName(value)
    value = (value == true);

    sortByName[1]     = value;
    config.sortByName = value;

    saveConfig();
end

-- Strict weak ordering, with the area label as the tiebreak: LuaJIT raises
-- "invalid order function for sorting" on a comparator that answers true both
-- ways, and two entries CAN share a name across two areas.
local function byName(a, b)
    if (a.name == b.name) then
        return a.label < b.label;
    end

    return a.name < b.name;
end

local viewCache = { };

local function completedView(key, rows)
    local cached = viewCache[key];
    local sorted = sortByName[1] == true;

    if (cached ~= nil and cached.rev == modelRev and cached.needle == needle and
        cached.sorted == sorted)
    then
        return cached.list;
    end

    local list = { };

    for _, row in ipairs(rows) do
        if (findMatches(row.search)) then
            list[#list + 1] = row;
        end
    end

    if (sorted) then
        table.sort(list, byName);
    end

    viewCache[key] = { rev = modelRev, needle = needle, sorted = sorted, list = list };

    return list;
end

local function completedTab(rows, id, emptyText, emptyTip)
    -- THE SWITCH IS DRAWN BEFORE THE VIEW IS BUILT, deliberately: ImGui writes
    -- a checkbox's new value during the Checkbox call, so a view built above it
    -- is a view built on the previous frame's answer -- the list would reorder
    -- one frame after the click, and the count line beside it would disagree
    -- with the rows underneath for that frame.
    if (imgui.Checkbox('A-Z##dwtracker_sort', sortByName)) then
        setSortByName(sortByName[1]);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.sortAZ);
    end

    imgui.SameLine();

    local view    = completedView(id, rows);
    local matched = #view;

    -- The count used to be `#rows` whatever the find box held, so a search
    -- narrowing 623 rows to four still said "623 completed." over four lines.
    if (needle ~= '' and matched ~= #rows) then
        imgui.TextDisabled(string.format('%d of %d completed match the find box.', matched, #rows));
    else
        imgui.TextDisabled(string.format('%d completed.', #rows));
    end

    if (#rows == 0) then
        imgui.TextDisabled(emptyText);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(emptyTip);
        end

        return;
    end

    if (beginListTable(id)) then
        -- The house page. A maxed character's completed-quest list is past six
        -- hundred rows and every one of them is two ImGui calls a frame; the
        -- find box above is how the rest is reached, and the footer below says
        -- so rather than letting the list simply stop.
        local shown = math.min(matched, PAGE_ROWS);

        for i = 1, shown do
            local row = view[i];

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row.name);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(row.repeatable and TIPS.repeatable or TIPS.completed);
            end

            -- T7's repeat marker: the quest can be taken again. What it does
            -- NOT mean is that a repeat run moves to the Active tab -- see
            -- TIPS.repeatable and FORMAT 6.15; the comment here claimed it did
            -- until 2026-09-06, which is where the old tooltip got it from.
            if (row.repeatable) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.badge, '(repeatable)');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.repeatable);
                end
            end

            -- No tooltip on the cell: the column header carries that sentence
            -- now (beginListTable), and asking it here was three hundred
            -- IsItemHovered calls a frame for one fact about the column.
            imgui.TableNextColumn();
            imgui.TextDisabled(row.label);
        end

        if (matched == 0) then
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextDisabled('Nothing completed matches the find box.');
        elseif (matched > shown) then
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextDisabled(string.format('%d more not shown -- narrow the find box.', matched - shown));

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.pageCap);
            end
        end

        imgui.EndTable();
    end
end

--[[
* The active journal as plain text, for the clipboard (1.1.0).
*
* "Which step am I on?" is the question this window exists to answer, and the
* answer is worth pasting into a linkshell or a bug report. It copies exactly
* what the window shows -- names, the server's step placement, and the
* sentence for that step -- and nothing it did not draw: an entry whose area
* is unverified has no step here either, for the same reason the pane refuses
* to render one.
*
* The step's place rides along with the `(!pos x y z)` half CUT OUT. `!pos` is
* a GM command; a player reading the paste cannot run it and cannot read it,
* while the part in front of it -- "Beaucedine Glacier (F-7)" -- is the zone
* and the cell off their own map window.
--]]
local function placeOf(step)
    if (step == nil or type(step.pos) ~= 'string') then
        return nil;
    end

    local place = step.pos:gsub('%s*%(!pos[^)]*%)', '');

    place = place:gsub('^[%s,%-]+', ''):gsub('[%s,%-]+$', '');

    return place ~= '' and place or nil;
end

local function activeAsText()
    local function push(out, kind, area, log, id, row, label)
        -- IT COPIES WHAT THE WINDOW IS SHOWING. The find box is a view over
        -- these same two tabs, and a Copy that ignored it handed the player
        -- eleven rows when four were on screen -- which is the opposite of
        -- what a button beside a filter is for (1.1.0).
        if (not activeMatches(kind, area, log, id, row, label)) then
            return;
        end

        local ui   = rowUI(kind, area, log, id, row, label);
        local line = string.format('%s (%s)', ui.name, label);

        --[[
        * THE SAME DECISION THE ROW MAKES, through the same function. This used
        * to spell the test out again -- verified set, step count against the
        * data file, a step above zero -- which is two copies of the rule that
        * decides whether this addon may quote a step at all, and the one thing
        * the T1 rule cannot survive is those two drifting (1.1.0).
        --]]
        if (row.unclear) then
            line = line .. ' -- step unclear';
        elseif (rowGuide(area, row, ui) and row.step > 0) then
            local step  = ui.entry.steps[row.step];
            local place = placeOf(step);

            line = string.format('%s -- step %d of %d: %s', line, row.step, row.n,
                (step ~= nil and type(step.text) == 'string' and step.text) or '');

            if (place ~= nil) then
                line = string.format('%s  [%s]', line, place);
            end
        end

        out[#out + 1] = line;
    end

    --[[
    * THE HEADINGS FOLLOW THE ROWS, not the tab. Each surface is gathered
    * first and titled only if something landed in it: with a find box
    * narrowing both tabs, a surface can come out empty, and a paste reading
    * "Active quests:" with nothing beneath it makes a claim about the
    * player's journal that the window itself is not making.
    --]]
    local quests   = { };
    local missions = { };

    for _, row in ipairs(state.activeQuests) do
        local area = questsByLog[row.log];

        push(quests, 'q', area, row.log, row.id, row,
            area ~= nil and area.label or string.format('log %d', row.log));
    end

    for _, log in ipairs(missionOrder()) do
        local row  = state.activeMissions[log];
        local area = missionsByLog[log];

        push(missions, 'm', area, log, row.id, row,
            area ~= nil and area.label or string.format('log %d', log));
    end

    local text = { };

    if (#quests > 0) then
        text[#text + 1] = 'Active quests:';
        text[#text + 1] = table.concat(quests, '\n');
    end

    if (#missions > 0) then
        if (#text > 0) then
            text[#text + 1] = '';
        end

        text[#text + 1] = 'Active missions:';
        text[#text + 1] = table.concat(missions, '\n');
    end

    return table.concat(text, '\n');
end

--[[
* How old the rows on screen are, in words -- 'just now', '(12 seconds ago)',
* '(4 minutes ago)'. Recomputed only when the ANSWER would change, not once a
* frame: the string is the same for a whole second (and then for a whole
* minute), and building it sixty times a second is the churn dwfame's syncAge
* was written to avoid. Same shape, kept deliberately.
--]]
local ageBucket = nil;
local ageWords  = nil;

local function syncAge()
    if (state.syncedAt == nil) then
        return nil;
    end

    local seconds = math.floor(os.clock() - state.syncedAt);

    -- A clock that appears to run backwards (a reload, a stamp taken on the
    -- other side of one) reads as brand new rather than as a negative age.
    if (seconds < 0) then
        seconds = 0;
    end

    local bucket = seconds < 60 and seconds or math.floor(seconds / 60) * 60;

    if (bucket ~= ageBucket) then
        ageBucket = bucket;

        -- Singular where it is one. "(1 minutes ago)" and "(1 hours ago)" are
        -- what this said for a whole minute and a whole hour of every session
        -- respectively, and the minute one is on screen constantly.
        if (seconds < 5) then
            ageWords = '(just now)';
        elseif (seconds < 60) then
            ageWords = string.format('(%d seconds ago)', seconds);
        elseif (seconds < 120) then
            ageWords = '(1 minute ago)';
        elseif (seconds < 3600) then
            ageWords = string.format('(%d minutes ago)', math.floor(seconds / 60));
        elseif (seconds < 7200) then
            ageWords = '(1 hour ago)';
        else
            ageWords = string.format('(%d hours ago)', math.floor(seconds / 3600));
        end
    end

    return ageWords;
end

-- Tab labels carry their row counts, and the id half is `###` so the tab bar
-- keeps the player's selection when a count changes under it.
local TAB_TIPS = {
    aq = 'Every quest your journal has ACCEPTED, with the step the server places you on where a guide is written.',
    am = 'The mission underway on each line the server will answer for: your nation\'s, Rise of the Zilart, and Chains of Promathia.',
    cq = 'Every quest the server\'s own completion bits say you have finished.',
    cm = 'Every mission the server\'s own completion bits say you have finished, this nation\'s and any other you once served.',
};

--[[
* The four tab labels, built once per model change rather than once per frame.
*
* Same reasoning as the closure note below and the same order of magnitude:
* four `string.format` calls a frame is 240 a second for four strings that
* change only when a sync commits. Keyed on `modelRev`, which is also what
* moves the counts inside them (1.1.0).
--]]
local tabRev    = -1;
local tabLabels = { };

local function tabLabelsFor(missionCount)
    if (tabRev ~= modelRev) then
        tabRev = modelRev;

        tabLabels.aq = string.format('Active Quests (%d)###dwt_tab_aq', #state.activeQuests);
        tabLabels.am = string.format('Active Missions (%d)###dwt_tab_am', missionCount);
        tabLabels.cq = string.format('Completed Quests (%d)###dwt_tab_cq', #state.completedQuests);
        tabLabels.cm = string.format('Completed Missions (%d)###dwt_tab_cm', #state.completedMissions);
    end

    return tabLabels;
end

-- `body` takes `arg` rather than being a closure over it: a closure built at
-- the call site is a table allocated per tab per frame, which is 240 a second
-- for four tabs that never change.
local function tab(label, key, body, arg)
    local open = imgui.BeginTabItem(label);

    -- Hovered on the TAB, which is the item BeginTabItem just submitted -- so
    -- this has to be asked before the body draws anything of its own.
    if (imgui.IsItemHovered() and TAB_TIPS[key] ~= nil) then
        imgui.SetTooltip(TAB_TIPS[key]);
    end

    if (open) then
        body(arg);
        imgui.EndTabItem();
    end
end

local function completedQuestsTab()
    completedTab(state.completedQuests, '##dwtracker_cq',
        'Nothing completed yet. Plenty of time.', TIPS.emptyCQ);
end

local function completedMissionsTab()
    completedTab(state.completedMissions, '##dwtracker_cm',
        'Nothing completed yet.', TIPS.emptyCM);
end

--[[
* THE STATUS CARD (1.1.0).
*
* A hover card rather than one sentence, because the status line answers only
* half of "can I trust what is under this". The other half is the handshake,
* and this window says NOTHING when every data file agreed: the mismatch
* banner is drawn only for a disagreement, so "all twelve confirmed" and "the
* hello answer never arrived" look identical from outside -- which is exactly
* the pair the T1 rule (agreement must be POSITIVE, never merely un-denied)
* exists to keep apart. The card is where a player can read which of the two
* they are looking at, and the version and protocol under it are what a bug
* report wants first. dwtoau's BeginTooltip shape; Begin and End on every
* path, including the ones the counts skip.
--]]
local function statusCard()
    imgui.BeginTooltip();

    imgui.TextWrapped(state.statusBad and TIPS.statusBad or TIPS.statusOk);

    if (not state.verifiedSeen) then
        imgui.TextDisabled('The server has not answered a data handshake this session, so no step guidance is rendered.');
    elseif (#state.mismatched == 0) then
        imgui.TextDisabled(string.format('Data: all %d areas confirmed against the server.', state.verifiedCount));
    else
        imgui.TextDisabled(string.format('Data: %d of %d areas confirmed; %d out of date (named below).',
            state.verifiedCount, #dataAreas, #state.mismatched));
    end

    imgui.TextDisabled(string.format('dwtracker %s, protocol %d.', tostring(addon.version), PROTOCOL));

    imgui.EndTooltip();
end

local function renderWindow()
    -- The mission ordering, once. It is cached on `modelRev` now, so this is
    -- no longer about the allocation -- three call sites below simply want the
    -- same answer and one of them is the tab label.
    local missions = missionOrder();

    -- `serverSilent = false` here as well as in the queue: this button IS the
    -- deliberate act the flag's own comment says clears it (window open,
    -- refresh). Without it, clicking Refresh on a silent server re-asked once
    -- but left the zone-in auto-syncs switched off until the window was closed
    -- and reopened -- which is not what the button says it does (2026-09-06).
    if (imgui.Button('Refresh')) then
        forget();
        serverSilent = false;
        requestSync();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(serverSilent and TIPS.refreshSilent or TIPS.refresh);
    end

    imgui.SameLine();

    local anyActive = #state.activeQuests > 0 or #missions > 0;

    imgui.BeginDisabled(not anyActive);

    if (imgui.Button('Copy##dwtracker_copy') and anyActive) then
        -- `needle` is the previous frame's text here -- the find box is drawn
        -- further along this toolbar, and ImGui writes its buffer during that
        -- call. So is `findText[1]`, for the same reason, which is why this
        -- does not read the buffer instead: the two are the same value at this
        -- point, and it is the value the rows the player is looking at were
        -- filtered by. A click always lands a frame after the keystroke.
        local text = activeAsText();

        -- NEVER THE EMPTY STRING. Copy honours the find box, so a needle that
        -- matches nothing leaves nothing to copy -- and handing ImGui '' does
        -- not fail quietly, it wipes whatever the player had on the clipboard
        -- (1.1.0).
        -- PCALL'D (dwtoau's shape): the call is in Ashita's annotations, but
        -- a player's install is frozen at whatever build they first installed,
        -- and a missing binding called inside the render pcall closes the
        -- whole window over a button that was only ever a courtesy.
        if (text ~= '') then
            pcall(imgui.SetClipboardText, text);
        end
    end

    imgui.EndDisabled();

    -- THE REASON COPY IS GREY CANNOT LIVE ON COPY: ImGui reports no hover at
    -- all for a disabled item unless the test is asked to allow it, and that
    -- flag is the newest-generation API this suite does not use -- a
    -- SetTooltip written for the greyed case would be dead code wearing the
    -- courtesy's name (dwtoau's note, same reasoning). The greyed case answers
    -- itself two lines below without a hover: the tab labels read "Active
    -- Quests (0)" and "Active Missions (0)".
    if (anyActive and imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.copy);
    end

    imgui.SameLine();
    findRow();

    -- The needle, once per frame, for every findMatches call below -- and
    -- AFTER findRow, because that is the call in which ImGui writes what the
    -- player just typed into the buffer. Read before it, the whole window
    -- filters on the previous frame's text.
    needle = string.lower(findText[1] or '');

    if (#queue > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d queued...', #queue));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.queued);
        end
    end

    --[[
    * The status line, and under it how old the rows underneath are. The window
    * recomputes nothing between syncs -- it draws the last answer it was
    * handed -- so the age of that answer is the one thing a player cannot read
    * off the rows themselves (1.1.0).
    *
    * WRAPPED, and the age is a LINE OF ITS OWN because of that. The status can
    * be any sentence the server chose to send, up to the 130-byte line budget
    * -- 'unknown verb "..." -- hello|sync' already runs past the window's
    * minimum width -- and an unwrapped one walks off the right edge (dwcraft
    * made the same fix on 2026-09-06). `SameLine` after a wrapped block is not
    * the answer: ImGui measures the whole block, so the marker would land at
    * the right edge beside the FIRST line.
    --]]
    if (state.status ~= nil and state.status ~= '') then
        coloredWrapped(state.statusBad and theme.colors.err or theme.colors.ok, state.status);

        if (imgui.IsItemHovered()) then
            statusCard();
        end

        local age = syncAge();

        if (age ~= nil) then
            imgui.TextDisabled(age);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.synced);
            end
        end
    end

    -- THE MISMATCH BANNER. Names below still render from this addon's own
    -- files; what a mismatched area can never do is render steps -- stale
    -- guidance must say "update me", not something wrong.
    if (state.mismatchLine ~= nil) then
        -- Wrapped for the same reason as the status: twelve area names joined
        -- with commas is well past any width a player would drag this to.
        coloredWrapped(theme.colors.warn, state.mismatchLine);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.mismatch);
        end

        coloredWrapped(theme.colors.warn,
            'Names may be stale; step guidance stays off for those areas until dwtracker is updated.');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.mismatch);
        end
    end

    imgui.Separator();

    if (imgui.BeginTabBar('##dwtracker_tabs')) then
        local labels = tabLabelsFor(#missions);

        tab(labels.aq, 'aq', activeQuestsTab);
        tab(labels.am, 'am', activeMissionsTab, missions);
        tab(labels.cq, 'cq', completedQuestsTab);
        tab(labels.cm, 'cm', completedMissionsTab);

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape, and its
* reasoning, kept verbatim).
--]]
ashita.events.register('d3d_present', 'dwtracker_present', function ()
    -- Before the visibility check: a sync requested by a zone-in still has
    -- to reach the server with the window shut.
    if (state.syncAt ~= nil and os.clock() >= state.syncAt) then
        -- The deferral exists because 0x000A arrives on the load screen --
        -- but a fixed delay only guesses at how long that screen stays up,
        -- and a typed line handed to a client that is still zoning is not
        -- delayed, it is LOST, with "A command error occurred." in the log
        -- as its residue (the per-zone error players were seeing). The
        -- client's own zoning flag is the fact; wait it out.
        --
        -- The memory manager can answer nil mid-teardown, and this handler is
        -- NOT inside the render pcall -- a throw here is a Lua error sixty
        -- times a second. A nil manager reads as "not zoning" and the sync is
        -- scheduled; the queue still refuses to send it, because
        -- echo.canSend() answers false for exactly the same nil.
        local memory = AshitaCore:GetMemoryManager();
        local player = memory ~= nil and memory:GetPlayer() or nil;

        if (player ~= nil and player:GetIsZoning() ~= 0) then
            state.syncAt   = os.clock() + 1.0;
            state.syncSlot = nil;
        elseif (state.syncSlot == nil) then
            -- Zoning done. Every sibling clears its zoning flag on the SAME
            -- frame, so hold this addon's stagger slot before firing or the
            -- zone-in syncs collide at the client's chat throttle and all but
            -- one come back "A command error occurred." (dwecho.lua's ZONE_ORDER
            -- is the shared slot order; 2026-08-14).
            state.syncSlot = os.clock() + echo.zoneSlot('dwtracker') * echo.SEND_INTERVAL;
            state.syncAt   = state.syncSlot;
        else
            state.syncAt   = nil;
            state.syncSlot = nil;

            forget();
            requestSync();
        end
    end

    -- Answer tracking runs whether or not the window is open. It used to
    -- live inside the window render, which meant a closed window could
    -- never notice the server had gone silent -- and it is exactly the
    -- window-closed zone-in auto-syncs that must stop when it has
    -- (see serverSilent: on this server an unknown !command is /say chat).
    checkAnswers();

    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    -- One tick per drawn frame; the position cache reads it (positionThisFrame).
    frameNumber = frameNumber + 1;

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 620, 460 }, ImGuiCond_FirstUseEver);

    --[[
    * A FLOOR UNDER THE WINDOW. Nothing stopped a player dragging this one down
    * to a strip: the toolbar wrapped, the four tab labels collapsed into the
    * scroll arrows, and the completed table's own scrollbar took what was left
    * of the rows. The minimum below is measured from what the toolbar actually
    * contains -- Refresh, Copy, a 240px find box, the Clear button and the
    * queue note -- plus a few rows of list under it. There is no maximum: a
    * player with a 4K screen is welcome to the whole thing.
    *
    * The height went 260 -> 300 in 1.1.0: Active Quests grew two more header
    * lines (the coverage line, and the zone switch's own state when it is on),
    * and 260 left that tab with about three rows of list under five rows of
    * chrome.
    --]]
    imgui.SetNextWindowSizeConstraints({ 520, 300 }, { 99999, 99999 });

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Tracker##dwtracker', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwtracker'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwtracker'):append(chat.message('Window closed. `!dwt sync` typed by hand shows the same data.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);

    -- Cleared HERE rather than at the end of renderWindow, which is inside the
    -- pcall: a throw between the button and the clear would have left every
    -- tree node pinned open (or shut) for the rest of the session.
    expandRequest = nil;
end);

--[[
* Open, close, toggle. Opening always resyncs: a window showing the journal
* as it stood two zones ago is the quiet kind of wrong this project exists
* to rule out, and a sync costs one chat line.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported`
        -- only exists to stop one bad frame printing sixty lines a second.
        -- And a fresh start for the silent-server detection: opening the
        -- window is the deliberate act that earns one more try.
        state.reported = false;
        serverSilent   = false;

        forget();
        requestSync();
    end
end

ashita.events.register('command', 'dwtracker_command', function (e)
    local args = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwtracker' and first ~= '/tracker' and first ~= '/dwt') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        serverSilent = false;

        forget();
        requestSync();

        return;
    end

    --[[
    * `/dwt find <text>` (1.1.0). The find box is the fastest way into a
    * four-hundred-row tab and the slowest thing to reach: open the window,
    * click the box, type. A player who already knows the name says it once
    * here instead. Purely a view, exactly like the box itself -- nothing is
    * sent to the server, and the text is not remembered past this session.
    --]]
    if (#args >= 3 and args[2]:lower() == 'find') then
        findText[1] = table.concat(args, ' ', 3):sub(1, FIND_MAX);

        if (not state.open[1]) then
            toggleWindow();
        end

        return;
    end

    --[[
    * ANY OTHER SUBCOMMAND IS ANSWERED, NOT SWALLOWED. Everything that was not
    * exactly `refresh` used to fall through to the toggle, so `/dwt find` with
    * nothing after it, or a typo, quietly opened or CLOSED the window -- which
    * reads as the addon having done something else entirely. The bare command
    * still toggles; a word this file does not know gets the list of the ones
    * it does (2026-09-06).
    --]]
    if (#args >= 2) then
        print(chat.header('dwtracker'):append(chat.message('/dwt opens the window; /dwt refresh re-asks the server; /dwt find <text> filters every tab.')));

        return;
    end

    toggleWindow();
end);

--[[
* Sync on login and zone-in (0x000A serves both). Everything server-derived
* resets first: a login may be a different character, and stale journal
* rows surviving into a new character's window is exactly the kind of
* quiet wrongness this project exists to rule out.
--]]
ashita.events.register('packet_in', 'dwtracker_zonein', function (e)
    if (e.id == 0x000A) then
        state.nation         = nil;
        state.rank           = nil;
        state.activeQuests   = T{ };
        state.activeMissions = T{ };
        state.cq             = T{ };
        state.cm             = T{ };
        state.completedQuests   = T{ };
        state.completedMissions = T{ };
        state.serverHashes = { };
        state.mismatched   = T{ };
        state.mismatchLine = nil;
        state.mismatchSet  = { };
        state.verifiedSet  = { };
        state.verifiedCount = 0;
        state.verifiedSeen  = false;
        state.status       = 'Syncing...';
        state.statusBad    = false;
        state.syncedAt     = nil;

        -- A login may be a different character, so a half-arrived answer for
        -- the previous one must not be able to commit into this one's window.
        state.inbound      = nil;
        draft              = nil;
        modelRev           = modelRev + 1;

        --[[
        * AND THE QUEUE GOES WITH IT. A line asked for a moment before the zone
        * line (a Refresh click, say) is still sitting in the queue when 0x000A
        * arrives -- held, correctly, because the client is zoning -- and it
        * used to go out on the very first frame after the load screen cleared.
        * That is the exact instant every sibling addon's zone-in sync fires,
        * which is what echo.ZONE_ORDER's stagger exists to spread out; a line
        * that jumps the queue that way is one of the ones the client answers
        * with "A command error occurred." and drops. Its ask is already gone
        * (forget, below) and the deferred sync re-asks the same two verbs at
        * this addon's slot, so nothing is lost by dropping it (2026-09-06).
        --]]
        queue = T{ };

        forget();

        -- No auto-sync against a server that has shown it does not speak
        -- dwtracker: an unknown !command falls through to /say here, so each
        -- retry would be the player chatting "!dwt hello" at whoever is
        -- nearby. Opening the window retries deliberately.
        if (not serverSilent) then
            state.syncAt = os.clock() + 4.0;
        else
            -- AND IT IS A BAD STATUS. `statusBad` was cleared with everything
            -- else six lines above and never set again here, so the one
            -- sentence in this window that says the tracker has given up
            -- rendered in the theme's OK green -- with the green line's own
            -- tooltip under it, which says "the server answering normally"
            -- (2026-09-06).
            state.status    = 'Tracker paused (no answer from the server). Open the window to retry.';
            state.statusBad = true;
        end
    end
end);

--[[
* Watch what the player sends.
*
* Bare `!dwt` (and its ui/window/gui spellings) is intercepted and toggles
* this window instead of going to the server -- dwsquad's pattern, and the
* reason it exists: the server verb is the name players learn from the news
* post and from each other, so it has to be a door and not a dead end. The
* line is blocked and never leaves the client. `!dwt sync` and `!dwt hello`
* typed by hand still pass through untouched -- that is the escape hatch
* this addon's header promises, and it must keep working.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped.
* Stamping the player's own line as a send makes the next queued command
* wait its interval instead of racing it (dwbags' lesson, kept verbatim).
--]]
ashita.events.register('packet_out', 'dwtracker_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!dwt' or lower == '!dwt ui' or lower == '!dwt window' or lower == '!dwt gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwt') then
        lastSend = os.clock();
    end
end);

--[[
* Ashita re-reads the settings file when the CHARACTER changes, and hands the
* new table here. Both holders are refreshed from it: they are what ImGui
* draws from, and a holder left on the previous character's preference is a
* switch whose box and whose behaviour disagree until it is clicked twice
* (dwport's callback, same reasoning).
--]]
pcall(settings.register, 'settings', 'dwtracker_settings_update', function (s)
    if (type(s) == 'table') then
        config          = s;
        sortByName[1]   = (config.sortByName == true);
        hereOnly[1]     = (config.hereOnly == true);
    end
end);

ashita.events.register('load', 'dwtracker_load', function ()
    print(chat.header('dwtracker'):append(chat.message('/dwtracker, /tracker, /dwt or !dwt opens the quest & mission tracker. /dwt refresh re-asks the server; /dwt find <text> filters every tab.')));
end);
