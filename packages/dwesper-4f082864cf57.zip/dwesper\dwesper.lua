--[[
* DriftwoodXI -- dwesper
*
* Magicite, Espers and attunement, in a window (PLANS/DWESPER_PLAN.md). Kills
* pay Magicite -- a wallet of thirty counters, eight elements and twenty-two
* jobs -- and Magicite plus Esper Cores make Espers: the thirty-one Final
* Fantasy VI Espers and a thirty-second, Driftwood. One Esper is equipped at a
* time (two once Driftwood is mastered), fighting with it equipped attunes it,
* and an equipped or mastered Esper lends its spells and job abilities to
* whatever job the player is on.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited whole
* through dwspoils). It carries no roster, no price table and no rate: every
* name, tier, price, grant and line of prose it draws arrived on the wire as a
* record, and the addon authors only navigation tokens -- the eight element
* words and the tier words, which are the game's own. The seven lines it can
* send (`sync`, `roster`, `create`, `equip`, `unequip`, `cast`, `use`) reach
* exactly the dispatch `!esper` typed reaches, and the server enforces every
* rule: the prices are re-read from the roster at confirm, the engaged gate,
* the Core count, the Driftwood condition. A greyed button here is a courtesy.
*
* THREE TABS. Espers is a 4x8 grid of the thirty-two, each tile its name in
* its tier's colour, its element, an attunement bar for an owned one and a
* badge for equipped or mastered; selecting a tile shows what it grants, its
* line, its price against the Magicite you hold, its Cores against the Cores
* you hold, and Create / Equip / Unequip. Magicite is the wallet: eight element
* rows then twenty-two job rows, amount and lifetime. Grants is every spell and
* ability the ACTIVE Espers -- equipped or mastered -- lend, with a Cast or Use
* button that asks the server to cast it at your current target.
*
* CASTING GOES THROUGH THE SERVER (T10). The stock client builds its magic
* menu from the current main and sub job, so a granted Blizzard III on a WAR is
* not something the client can send. The Grants buttons send `!dwes cast
* <spellId> <targetIndex>`, and the `command` hook below rewrites a typed or
* macro'd `/ma "Blizzard III" <t>` -- for a GRANTED spell only -- into the same
* line, so macros work. Everything that is not a granted spell or ability
* passes through untouched. The `intercept` setting turns the hook off.
*
* ...AND ONLY WHAT THE CLIENT CANNOT DO ITSELF (2026-09-27, the Esper audit).
* A granted spell the current main or sub job already casts at its level goes
* to the client as typed -- a WHM's Cure III with Kirin made is the client's,
* `<p2>` and `<stpc>` and all. The target word must be one this file can
* place: `<t>`, `<me>`, `<bt>`, `<p0>`..`<p5>`, `<a10>`..`<a25>`, `<pet>` or
* a bare index. Any other word (a name, `<st>`, `<lastst>`) is the client's
* too, because the current target is not what the player named.
*
* IT TAKES NO ZONE-IN SLOT. The first ask is LAZY -- the first frame the
* window is actually shown in a zone -- so a player who never opens it never
* handshakes and the login burst is exactly as long as it was before (the
* dwspoils decision; see dwecho.lua's ZONE_ORDER, which this addon is
* deliberately absent from). While shown it re-asks `sync` every sixty
* seconds and after every answered create, equip or unequip; the static
* roster is asked ONCE per session and cached, re-asked on a zone line only
* when the cache is empty (T15: bursts need ceilings).
*
* ONE ASK IN FLIGHT. Reads are queued and deduplicated; writes -- create,
* equip, unequip, cast, use -- go out one at a time, never collapsed, never
* retried, and the buttons disarm until the envelope's `z|` (or a refusal, or
* five seconds) clears the latch. A write inside the send interval of the
* last chat line is PARKED, not dropped, and goes out first when the
* interval clears. A refusal is drawn in the window's status line and never
* printed to chat -- except that, with the window SHUT, a `/ma` or `/ja` the
* hook took says its refusal once in chat, because nothing else would.
*
* A FROZEN RECORD IS SAID, AND ITS BUTTONS GREY (1.2.1, 2026-09-27). When the
* server could not read this character's Esper rows at login it freezes them
* -- every write refused, nothing written over the stored rows -- and the s|
* record's appended eighth field says so. The window then draws a red banner
* in the header on every tab ("Your Esper record could not be read at login
* -- log out and back in; nothing will change until then.") and greys Create,
* Equip and Unequip with that sentence as their reason, because the zeros on
* screen are UNKNOWN, not none, and the three writes would only be refused.
* Cast and Use stay live: they write nothing, and whatever the login did read
* still lends. A cast or use the level cap holds back ("<name> is lent by your
* Esper, but not at your capped level here.") is said once in chat when the
* window is shut, like "not lent" -- but it re-asks nothing: a cap is not a
* stale map.
*
* THE BAR IS A FIXED SCALE (1.2.2, 2026-09-27). Mastering an Esper now takes
* three times the attunement (300000 units, was 100000). The server sends the
* p| attune field as thousandths of a percent of ITS mastery, so this window
* -- and every older one -- draws the same bar at any threshold; a mastered
* Esper draws full whatever its units (one mastered before the change sits
* at the old 100000 and stays mastered).
*
* THE MAGICITE FEED (1.1.0). The server says one tagged line per paid kill
* and per boss credit -- `[Esper] Magicite: +5 Earth (1234), +5 WAR (567).`
* -- and the text_in handler at the bottom of this file moves it into Window 2
* with every kind in its own colour (kindColor), or drops it when the player
* unticks "Chat notifications when gaining Magicite". ON by default.
*
* TURN IT OFF AND NOTHING IS LOST. `!esper` typed says all of it in prose, and
* `!esper cast <spell>` is the same door the buttons press.
*
* Over `!dwes` (`documentation/dwes_protocol.md`, sender `_DWESDATA`); the
* offline guard is tools/dwesper/harness_dwesper.py.
--]]

addon.name    = 'dwesper';
addon.author  = 'DriftwoodXI';
-- 1.2.3 (2026-10-18): dwtheme.lua's printf door -- a `%` in wrapped text, a tooltip or a bullet can no longer crash the client.
addon.version = '1.2.3';
addon.desc    = 'DriftwoodXI Espers: your Magicite, the Espers you can make and have made, and the spells and abilities they lend you.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. The
-- THIRD two-letter door (`dwsp`, `dwto`, now `dwes`): dwa.lua through dwz.lua
-- are all doors already, and the registry is dww.lua's header.
local DATA_SENDER = '_DWESDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

--[[
* EVERY NUMBER OFF THE WIRE COMES THROUGH HERE (the dwnemesis shape). LuaJIT
* -- which is what Ashita runs -- answers `tonumber` for 'inf', 'nan', '0x10'
* and '2.5' as readily as for '7', and everything downstream is a pile of
* string.format('%d'). A field that is not a plain integer inside the wire's
* own range is not a number this window can draw, so it reads as the record's
* default and the rest of the record still lands.
--]]
local WIRE_MAX = 2147483647;

local function wireInt(text, default)
    local value = tonumber(text);

    if (value == nil
            or value ~= value                            -- nan
            or value < -WIRE_MAX or value > WIRE_MAX     -- inf, and anything absurd
            or value ~= math.floor(value)) then
        return default or 0;
    end

    return value;
end

--[[
* THE NAVIGATION TOKENS THIS ADDON AUTHORS, and the whole of them. Magicite
* kinds 1..8 are the eight elements in the engine's own order; kinds 9..30 are
* 8 + the job id (WAR = 1 .. RUN = 22). The job short names are asked of the
* client's own resource manager first (`jobs.names_abbr`) and fall back to
* these twenty-two three-letter words -- the same list dwmerits carries --
* only on an install whose string table does not answer. The tier words are
* the plan's (T8). Nothing else here is a name: Esper names, prices and grants
* all ride the `r|` record.
--]]
local ELEMENT_NAMES = { 'Fire', 'Ice', 'Wind', 'Earth', 'Thunder', 'Water', 'Light', 'Dark' };

local JOB_ABBR = {
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK', 'BST', 'BRD',
    'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU', 'COR', 'PUP', 'DNC', 'SCH',
    'GEO', 'RUN',
};

local TIER_NAMES = { [1] = 'Minor', [2] = 'Major', [3] = 'Greater', [4] = 'Driftwood' };

--[[
* ONE COLOUR PER MAGICITE KIND, for the chat feed and the Magicite tab alike,
* so the tab is the legend for the log. Each is { chat code, imgui RGBA }: the
* code is Ashita's colour table 1 (`\30\NN`, a colour libs/chat.lua names --
* dwchat's COLOR_CHOICES, less the three unreadable on the dark log), and
* the RGBA is the web colour of the same NAME, so the chat log's own shade
* can differ a little. Elements take the game's own element colours; jobs
* take their ROLE's colour, because twenty-two distinct readable colours do
* not exist in the table and a role is what a player reads a job as.
--]]
local ELEMENT_COLORS = {
    { 76, { 1.00, 0.39, 0.28, 1.0 } },  -- Fire     Tomato
    { 92, { 0.88, 1.00, 1.00, 1.0 } },  -- Ice      LightCyan
    { 79, { 0.00, 1.00, 0.00, 1.0 } },  -- Wind     Lime
    { 69, { 1.00, 1.00, 0.00, 1.0 } },  -- Earth    Yellow
    { 73, { 0.93, 0.51, 0.93, 1.0 } },  -- Thunder  Violet
    { 6,  { 0.00, 1.00, 1.00, 1.0 } },  -- Water    Cyan
    { 90, { 0.94, 1.00, 1.00, 1.0 } },  -- Light    Azure
    { 81, { 0.60, 0.20, 0.80, 1.0 } },  -- Dark     DarkOrchid
};

local ROLE_COLORS = {
    melee   = { 8,   { 1.00, 0.50, 0.31, 1.0 } },  -- Coral
    tank    = { 78,  { 0.93, 0.91, 0.67, 1.0 } },  -- PaleGoldenRod
    healer  = { 83,  { 0.00, 1.00, 0.50, 1.0 } },  -- SpringGreen
    mage    = { 5,   { 1.00, 0.00, 1.00, 1.0 } },  -- Magenta
    support = { 105, { 0.87, 0.63, 0.87, 1.0 } },  -- Plum
};

-- By job id, WAR = 1 .. RUN = 22 (JOB_ABBR's order).
local JOB_ROLES = {
    'melee', 'melee', 'healer', 'mage', 'mage', 'melee', 'tank', 'melee', 'melee', 'support', -- WAR..BRD
    'melee', 'melee', 'tank', 'melee', 'mage', 'mage', 'support', 'melee', 'melee', 'healer', -- RNG..SCH
    'support', 'tank',                                                                        -- GEO, RUN
};

local ELEMENT_COUNT = 8;
local JOB_COUNT     = 22;
local KIND_COUNT    = ELEMENT_COUNT + JOB_COUNT;
local ESPER_COUNT   = 32;
local GRID_COLUMNS  = 4;

-- The p| record's attune field is on a FIXED scale: thousandths of a percent,
-- WIRE_ATTUNE_FULL (100000) = mastered (documentation/dwes_protocol.md, p|).
-- It is NOT the store's units and NOT the roster's MASTERY -- the server scales
-- its units by MASTERY before it sends them (esper_core.lua E.wireAttune),
-- which is how every dwesper ever shipped still draws the bar right after
-- MASTERY tripled to 300000 units on 2026-09-27 (1.2.2). Do not "update" this
-- to 300000: it would draw every Esper at a third. Used only to draw; the
-- server judges mastery. harness_dwesper.py holds it to the core's
-- E.WIRE_ATTUNE_FULL.
local WIRE_ATTUNE_FULL = 100000;

-- Job abilities live at DAT ids 512..1535 in the client's resource table and
-- the wire carries the SERVER id (dwgambits' ABILITY_CLIENT_OFFSET, the same
-- offset dwg_protocol.md documents).
local ABILITY_CLIENT_OFFSET = 512;

--[[
* Persisted presentation state, through Ashita's settings library (the
* dwspoils shape). Three scalars: which tab this character was last looking
* at, whether the `/ma` / `/ja` hook is on, and whether the Magicite feed is. Nothing the server said is ever
* written to disk -- a cached wallet is a wallet that can be wrong, and this
* one is cheap to ask for again.
*
* THE DEFAULTS ARE A SUGAR TABLE, and that `T` is load-bearing rather than
* decorative: settings.lua calls `defaults:copy(true)` (:180) and
* `settings:merge(defaults)` (:338), both sugar-table methods, so a plain
* table raises 'attempt to call a nil value'. The pcall below hides it at
* load; the library's own UNGUARDED packet_in handler re-loads on the
* zone-enter packet (:538) and Ashita answers a raise inside an event callback
* by UNLOADING THE ADDON -- so a missing `T` works at the desk and then the
* window disappears on the player's next zone line.
--]]
local defaultConfig = T{
    tab       = 'espers',
    intercept = true,
    notify    = true,
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

local TABS = { 'espers', 'magicite', 'grants' };

local function rememberedTab(cfg)
    if (type(cfg) ~= 'table' or type(cfg.tab) ~= 'string') then
        return 'espers';
    end

    for _, key in ipairs(TABS) do
        if (cfg.tab == key) then
            return key;
        end
    end

    return 'espers';
end

local function rememberedIntercept(cfg)
    if (type(cfg) ~= 'table') then
        return true;
    end

    -- Absent (a file from before the setting existed) reads as ON, the
    -- default; only an explicit false turns the hook off.
    return cfg.intercept ~= false;
end

local function rememberedNotify(cfg)
    -- Same reading as the hook's: absent is ON, only an explicit false is off.
    return type(cfg) ~= 'table' or cfg.notify ~= false;
end

--[[
* Outbound: `!dwes` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat.
--]]
local SEND_INTERVAL = 1.2;

-- The answer clock, per read (the dwfame shape): one retry after five
-- seconds, then the silent latch. An unknown `!` command falls through to
-- PUBLIC /say on a server without dwes.lua, and the latch is what contains
-- that to two lines rather than one every send interval, forever.
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- A write's own clock: no retry, just the buttons back. The next sync shows
-- whatever really happened.
local WRITE_TIMEOUT = 5.0;

-- How often an OPEN window re-asks `sync`. Magicite moves on every paid kill
-- and attunement with it, so a minute is the backstop between the re-asks
-- every answered write already fires.
local POLL_INTERVAL = 60.0;

-- How long the same refusal stays said: a shut window's chat line for a
-- hooked /ma or /ja (tellShut) is not repeated inside this.
local TELL_GAP = 5.0;

--[[
* THE TWO REFUSALS A SHUT WINDOW SAYS, matched lowercased on the server's own
* words (esper_core.lua) -- the words are a contract, and harness_dwesper.py
* holds each phrase against the core's real sentence. "not lent by an esper"
* is verbCast / verbUse's refusal for a grant the picture got wrong (it also
* re-asks sync, ESP-06); "but not at your capped level" is E.cappedSentence,
* a grant the level cap holds back (ESP-14, said since 1.2.1 -- the hook had
* blocked the player's line, so nothing else would say anything).
--]]
local NOT_LENT_PHRASE = 'not lent by an esper';
local CAPPED_PHRASE   = 'but not at your capped level';

-- The frozen-record banner (1.2.1): the owner's sentence, and the reason every
-- write button carries while the s| record's unreadable flag stands.
local UNREADABLE_BANNER = 'Your Esper record could not be read at login -- log out and back in; nothing will change until then.';

--[[
* THE LINES THIS ADDON EVER SENDS, SPELLED OUT IN FULL.
*
* Written as whole literals rather than built with `'!dwes ' .. verb`, and
* the reason is a gate rather than taste: harness_dwsuite.py discovers every
* verb every addon sends by reading its `'!dwX <verb>'` literals and proves
* some module under modules/driftwoodxi spells that word. A concatenated verb
* is invisible to that scan -- so the addon would be exempt from the one check
* that catches an addon newer than its server sending a verb the doorway has
* never heard of, whose refusal is a PUBLIC line in chat on every window open.
--]]
local LINES = {
    sync   = '!dwes sync',
    roster = '!dwes roster',
};

local WRITE_LINES = {
    create  = '!dwes create %d',
    equip   = '!dwes equip %d %d',
    unequip = '!dwes unequip %d',
    cast    = '!dwes cast %d %d',
    use     = '!dwes use %d %d',
};

local state = T{
    open = T{ false },

    -- The committed picture, swapped in at `z|` from staging copies so a
    -- half-arrived reply can never half-fill the window (dwbags' rule).
    sheet   = nil,       -- the s| record, as one table
    sheetAt = nil,
    wallet  = { },       -- [kind] = { amount, lifetime }, merged per w|
    owned   = { },       -- [id] = { attune, mastered, slot }, merged per p|
    roster  = nil,       -- [id] = { name, tier, elem, jobA, jobB, ... } committed whole
    rosterAt = nil,

    pendingSheet  = nil,
    pendingWallet = nil,
    pendingOwned  = nil,
    pendingRoster = nil,

    inbound   = nil,     -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,   -- a render error is worth saying once, not per frame

    -- The answer clock for READS, keyed by verb: { [verb] = { at, tries } }.
    requested    = T{ },
    serverSilent = false,

    -- The one WRITE in flight: { verb, at, line, sent }. Buttons and the hook
    -- disarm while set; cleared by the envelope's z|, by any refusal, or by
    -- WRITE_TIMEOUT. `sent` false is a write PARKED behind the send interval
    -- (2026-09-27): the line rides in here rather than in a slot of its own,
    -- so every place that clears the write -- a zone line above all, where
    -- the target index would name somebody else -- drops the line with it.
    pendingWrite = nil,

    -- The character the committed picture belongs to, by server id, read off
    -- the 0x000A packet itself (dwhub's guard). A different one wipes it.
    charId = nil,

    -- The last refusal said in chat with the window shut, and when: the same
    -- sentence is not said twice inside TELL_GAP (a macro mashed on a busy
    -- latch is one line, not six).
    saidText = nil,
    saidAt   = nil,

    -- An unknown d| version was seen: one warning, then silence until a zone
    -- line re-probes it. A click does NOT lift this one.
    refused = false,

    -- Per-verb unknown-verb latches (the dwbags shape): a server older than
    -- this addon answers a verb it lacks with its unknown-verb sentence, and
    -- that verb is then not asked again until a zone line.
    unsupported = { },

    -- The lazy hello has fired in THIS zone, and the roster has been asked
    -- for this session.
    helloSent   = false,
    rosterAsked = false,
    polledAt    = nil,

    -- Which tile is selected on the Espers tab, by esper id.
    selected = nil,

    -- The Grants tab's rows, rebuilt when owned/roster commit rather than
    -- walked sixty times a second: { kind, id, name, from, buttonId }, plus
    -- the two name maps the command hook reads.
    grants          = { },
    grantSpellByName   = { },
    grantAbilityByName = { },

    -- Which tab is drawn, restored from the settings file; `wantTab` is a tab
    -- the player named on the command line and is spent the frame it is taken.
    tab     = rememberedTab(config),
    wantTab = nil,

    -- The `/ma` / `/ja` hook switch, as the checkbox buffer.
    intercept = T{ rememberedIntercept(config) },

    -- The Magicite feed switch, as the checkbox buffer.
    notify = T{ rememberedNotify(config) },
};

-- The settings profile changes when the CHARACTER does, and the library hands
-- the new one over here.
pcall(settings.register, 'settings', 'dwesper_settings_update', function (s)
    if (type(s) ~= 'table') then
        return;
    end

    config             = s;
    state.tab          = rememberedTab(config);
    state.intercept[1] = rememberedIntercept(config);
    state.notify[1]    = rememberedNotify(config);
end);

local function saveConfig()
    config.tab       = state.tab;
    config.intercept = state.intercept[1] == true;
    config.notify    = state.notify[1] == true;

    pcall(settings.save);
end

--[[
* THE TOOLTIPS, in one table rather than one literal per call site, so two
* controls that mean the same thing cannot drift into two sentences.
--]]
local TIPS = {
    refresh      = 'Ask the server again, now. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks, and Refresh cannot fix that -- update dwesper through the launcher.',
    intercept    = 'When on, a typed or macro\'d /ma or /ja naming a spell or ability an active Esper lends you is sent to the server to cast instead of to the client, which does not know your job can cast it. Anything not lent by an Esper, a spell your own job already casts, and a target this window cannot place (a name, <st>) pass through untouched.',
    tile         = 'Click to see what this Esper grants, what it costs, and the buttons.',
    attune       = 'Attunement. It accrues only while this Esper is equipped and only on kills that paid experience; 100 percent is mastered, forever.',
    cores        = 'Esper Cores are a wallet counter, never an item. They drop from Unleashed kills, once per paid account per kill.',
    notify       = 'When on, every kill or boss that pays you Magicite says so in Window 2, one line per kill, each kind in the colour the Magicite tab draws it in. When off, those lines are not shown at all.',
    wallet       = 'Magicite is currency, never an item: every kill that pays you experience pays the element of what died, its job, and your own job.',
    lifetime     = 'Everything this character has ever earned of this kind, spent or not.',
    grants       = 'Every spell and job ability the Espers you have EQUIPPED or MASTERED lend you right now, whatever job you are on.',
    cast         = 'Ask the server to cast this at your current target (or at yourself when nothing is targeted). Your recast is honoured.',
    use          = 'Ask the server to use this on your current target (or on yourself when nothing is targeted).',
    create       = 'Make this Esper. The Magicite and the Cores are spent by the server, which re-reads the price from its own roster.',
    needMastered = 'Driftwood is made of everything: every other Esper must be mastered before it can be made. The server counts them itself.',
    equip1       = 'Equip this Esper in slot 1. Not while engaged.',
    equip2       = 'Equip this Esper in slot 2, opened by mastering Driftwood. Not while engaged.',
    unequip      = 'Take this Esper off. Attunement is KEPT; only what it lends you stops until it is equipped again. Not while engaged.',
    pending      = 'One action is in flight. Buttons come back when the server answers, or after five seconds.',
};

--[[
* Record parsing (dwes protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

-- A comma-separated id list off one record field, as a plain array of ints.
-- An empty field is an empty list; a token that is not an integer is skipped.
local function csvIds(text)
    local ids = { };

    if (type(text) ~= 'string' or text == '') then
        return ids;
    end

    for token in string.gmatch(text, '[^,]+') do
        local id = wireInt(token, -1);

        if (id > 0) then
            ids[#ids + 1] = id;
        end
    end

    return ids;
end

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

-- Is the client's chat limit still counting the last line? A clock that reads
-- EARLIER than the stamp has wrapped (dwecho's elapsed note, ~24.8 days of
-- client uptime) and the stamp is long ago, not in the future forever.
local function throttled(now)
    return now >= lastSend and (now - lastSend) < SEND_INTERVAL;
end

-- The write in state.pendingWrite, onto the wire now. Its answer clock starts
-- HERE, at the send, not at the park (the 2026-08-15 answer-clock lesson).
local function putWrite(now)
    local write = state.pendingWrite;

    write.sent = true;
    write.at   = now;
    lastSend   = now;

    echo.send(write.line);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST. This runs on every rendered frame for
    -- the life of the session and the queue is empty in almost all of them,
    -- while echo.canSend() is three calls across the C++ boundary. A write
    -- parked behind the send interval (2026-09-27) is queued work too.
    local write  = state.pendingWrite;
    local parked = write ~= nil and not write.sent;

    if (#queue == 0 and not parked) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (throttled(now)) then
        return;
    end

    -- THE PARKED WRITE GOES FIRST, ahead of any read: it is a press the
    -- player is waiting on, and the reads wait their interval behind it.
    if (parked) then
        putWrite(now);

        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

-- Is a read outstanding? Deliberately NOT a render helper: the suite's
-- `d|`-wipe gate judges a name by whether some imgui-drawing function reads
-- it, and the ask table is bookkeeping rather than a pane.
local function asking()
    return next(state.requested) ~= nil;
end

local function latched()
    return state.refused or state.serverSilent;
end

-- Anything in flight at all -- a read or a write. ONE ask at a time.
local function busy()
    return asking() or state.pendingWrite ~= nil;
end

-- The committed sheet says this login could not read the Esper rows (1.2.1):
-- the store refuses every write until the next login, so the three write
-- buttons grey with UNREADABLE_BANNER as their reason. A relog onto another
-- character drops the sheet, and with it the banner, until its own sync.
local function frozen()
    return state.sheet ~= nil and state.sheet.unreadable == true;
end

-- The roster was asked this session and nothing is coming: not in flight, not
-- arriving, not answered (2026-09-27, the Esper audit -- a refused or
-- cut-off roster used to leave the grid "Waiting" for the rest of the zone,
-- and Refresh asked only for sync). Bookkeeping, not a pane, like asking().
local function rosterStalled()
    return state.roster == nil and state.rosterAsked and not state.unsupported.roster
        and state.requested.roster == nil and state.inbound ~= 'roster';
end

--[[
* A REFUSAL SAID IN CHAT, AND ONLY WITH THE WINDOW SHUT (2026-09-27, the
* Esper audit). The status line is this addon's one voice, and a shut window
* draws none of it -- so a hooked `/ma` refused as busy, or as no longer lent,
* or never answered, was a cast the player lost with nothing said anywhere.
* The same sentence is not said twice inside TELL_GAP: a macro mashed on a
* busy latch is one line, which is what "drawn, never printed" was protecting.
--]]
local function tellShut(text)
    if (state.open[1] or type(text) ~= 'string' or text == '') then
        return;
    end

    local now = os.clock();

    if (state.saidText == text and state.saidAt ~= nil and now >= state.saidAt
            and (now - state.saidAt) < TELL_GAP) then
        return;
    end

    state.saidText = text;
    state.saidAt   = now;

    print(chat.header('dwesper'):append(chat.error(text)));
end

-- `force` is the Refresh button: a click is the player asking, and the silent
-- latch exists to contain AUTOMATIC re-asks, not to ignore the player. The
-- PROTOCOL refusal and the unknown-verb latches are not lifted by a click.
local function ask(verb, force)
    if (state.refused) then
        return;
    end

    if (LINES[verb] == nil or state.unsupported[verb]) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    if (not force and busy()) then
        return;
    end

    -- A CLICK REPLACES THE OLD ANSWER. Only a REFUSAL is dropped; a note is
    -- still true.
    if (force and state.statusBad) then
        state.status    = '';
        state.statusBad = false;
    end

    state.requested[verb] = { at = os.clock(), tries = 1 };

    if (verb == 'sync') then
        state.polledAt = os.clock();
    elseif (verb == 'roster') then
        state.rosterAsked = true;
    end

    issue(LINES[verb]);
end

--[[
* The one WRITE path (dwmerits' sendEdit shape). Never queued with the reads,
* never deduplicated, never retried: one in flight, buttons and the hook
* disarmed until its envelope closes. `line` is one of WRITE_LINES already
* formatted; `verb` names it for the clock.
*
* Answers true when the write is taken, else false and WHY (2026-09-27):
* 'closed' (a refused protocol or an unknown-verb latch -- the door is shut),
* 'busy' or 'zoning'. The `/ma` hook blocks the player's line on true and on
* 'busy', and hands it back to the client on the other two.
*
* PARKED, NOT DROPPED (2026-09-27, the Esper audit). The client refuses a chat
* line inside SEND_INTERVAL of the last one ("A command error occurred.",
* dwecho's one client fact) and dwecho swallows both that refusal and the
* echo -- so a hooked `/ma "Stun"` one line behind a macro's `/p Stun >>`
* never reached the server, said nothing, and held every button for five
* seconds. The reads always waited the interval out in pumpQueue; a write
* now does too, parked in pendingWrite and sent by the pump ahead of any read.
--]]
local function sendWrite(verb, line)
    if (state.refused or state.unsupported[verb]) then
        return false, 'closed';
    end

    if (busy()) then
        state.status    = 'One action at a time -- the last one has not been answered yet.';
        state.statusBad = true;

        return false, 'busy';
    end

    -- A click handed to a zoning client is not delayed, it is lost -- and a
    -- write is never queued, so there is nothing to hold it in. Say so.
    if (not echo.canSend()) then
        state.status    = 'Not while the client is zoning -- that was not sent. Try again in a moment.';
        state.statusBad = true;

        return false, 'zoning';
    end

    local now = os.clock();

    state.pendingWrite = { verb = verb, at = now, line = line, sent = false };

    if (not throttled(now)) then
        putWrite(now);
    end

    return true;
end

local function checkAnswers()
    local now = os.clock();

    for verb, asked in pairs(state.requested) do
        -- THE CLOCK DOES NOT AGE WHILE THE CLIENT IS ZONING -- it is
        -- RE-STAMPED, not merely skipped (dwspoils' note).
        if (not echo.canSend()) then
            asked.at = now;
        elseif ((now - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries >= ANSWER_TRIES) then
                -- NO SENTENCE IS WRITTEN HERE: the header draws the silent
                -- latch in preference to state.status.
                state.requested[verb] = nil;
                state.serverSilent    = true;

                -- A ROSTER THAT NEVER CAME is asked again (2026-09-27, the
                -- Esper audit): the latch was "asked", so a timed-out roster
                -- left the grid waiting for the rest of the zone. The silent
                -- latch set beside it still holds the automatic re-ask until
                -- an envelope or a Refresh lifts it -- two tries per cycle.
                if (verb == 'roster') then
                    state.rosterAsked = false;
                end
            else
                asked.at    = now;
                asked.tries = asked.tries + 1;

                issue(LINES[verb]);
            end
        end
    end

    -- A SENT write ages from its send; a PARKED one from its park, and one
    -- still parked after WRITE_TIMEOUT (a client that would not take a line
    -- for five seconds) is dropped rather than fired late at a target that
    -- may have moved on.
    local write = state.pendingWrite;

    if (write ~= nil and (now - write.at) >= WRITE_TIMEOUT) then
        state.pendingWrite = nil;
        state.statusBad    = true;

        if (write.sent) then
            state.status = 'No answer to that one -- nothing retried. Refresh to see where things stand.';
        else
            state.status = 'That one never went out -- the client was not taking lines. Try again.';
        end

        -- A cast the hook took, lost behind a shut window, is said.
        if (write.verb == 'cast' or write.verb == 'use') then
            tellShut(state.status);
        end
    end
end

--[[
* The client's own names, asked ONCE PER ID (the dwspoils resourceOf shape).
* The DATs are static from load, so an id that answers nil now answers nil
* forever and a negative result caches as safely as a positive one. `false`
* is "the client does not know this id"; nil is "not asked yet".
--]]
local spellNames   = { };
local abilityNames = { };
local jobNames     = { };

local function spellName(id)
    local hit = spellNames[id];

    if (hit ~= nil) then
        return hit ~= false and hit or string.format('spell %d', id);
    end

    local ok, name = pcall(function ()
        local spell = AshitaCore:GetResourceManager():GetSpellById(id);

        return spell ~= nil and spell.Name ~= nil and spell.Name[1] or nil;
    end);

    if (ok and type(name) == 'string' and name ~= '') then
        spellNames[id] = name;

        return name;
    end

    spellNames[id] = false;

    return string.format('spell %d', id);
end

local function abilityName(id)
    local hit = abilityNames[id];

    if (hit ~= nil) then
        return hit ~= false and hit or string.format('ability %d', id);
    end

    local ok, name = pcall(function ()
        local ability = AshitaCore:GetResourceManager():GetAbilityById(id + ABILITY_CLIENT_OFFSET);

        return ability ~= nil and ability.Name ~= nil and ability.Name[1] or nil;
    end);

    if (ok and type(name) == 'string' and name ~= '') then
        abilityNames[id] = name;

        return name;
    end

    abilityNames[id] = false;

    return string.format('ability %d', id);
end

-- A job's three-letter name: the client's string table first, the local
-- list second, the bare number last.
local function jobName(jobId)
    local hit = jobNames[jobId];

    if (hit ~= nil) then
        return hit;
    end

    local ok, name = pcall(function ()
        return AshitaCore:GetResourceManager():GetString('jobs.names_abbr', jobId);
    end);

    if (not (ok and type(name) == 'string' and name ~= '')) then
        name = JOB_ABBR[jobId] or string.format('job %d', jobId);
    end

    jobNames[jobId] = name;

    return name;
end

-- A Magicite kind's name: an element word for 1..8, a job word for 9..30.
local function kindName(kind)
    if (kind >= 1 and kind <= ELEMENT_COUNT) then
        return ELEMENT_NAMES[kind];
    end

    if (kind > ELEMENT_COUNT and kind <= KIND_COUNT) then
        return jobName(kind - ELEMENT_COUNT);
    end

    return string.format('kind %d', kind);
end

-- A Magicite kind's { chat code, imgui RGBA }, or nil for a kind outside 1..30.
local function kindColor(kind)
    if (kind >= 1 and kind <= ELEMENT_COUNT) then
        return ELEMENT_COLORS[kind];
    end

    local role = JOB_ROLES[kind - ELEMENT_COUNT];

    return role ~= nil and ROLE_COLORS[role] or nil;
end

local function tierName(tier)
    return TIER_NAMES[tier] or string.format('tier %d', tier);
end

local function tierColour(tier)
    if (tier == 4) then
        return theme.colors.pin;
    elseif (tier == 3) then
        return theme.colors.warn;
    elseif (tier == 2) then
        return theme.colors.hint;
    end

    return theme.colors.text;
end

--[[
* THE GRANTS, REBUILT ON COMMIT -- never per frame. The union of every spell
* and ability lent by an ACTIVE Esper: one that is equipped (slot 1 or 2) or
* mastered. Walked in roster id order so the tab reads the way the grid does;
* an id lent by two Espers appears once, credited to the first. The two name
* maps are what the `/ma` / `/ja` hook consults, lowercased once here rather
* than on every command the player types.
--]]
local function rebuildGrants()
    local rows      = { };
    local bySpell   = { };
    local byAbility = { };
    local seenSpell = { };
    local seenAbil  = { };

    if (state.roster ~= nil) then
        for id = 1, ESPER_COUNT do
            local row   = state.roster[id];
            local owned = state.owned[id];

            if (row ~= nil and owned ~= nil and (owned.mastered or owned.slot > 0)) then
                for _, spellId in ipairs(row.spells) do
                    if (not seenSpell[spellId]) then
                        seenSpell[spellId] = true;

                        local name = spellName(spellId);

                        rows[#rows + 1] = {
                            kind     = 'spell',
                            id       = spellId,
                            name     = name,
                            from     = row.name,
                            buttonId = string.format('Cast##dwes_cast_%d', spellId),
                        };

                        bySpell[name:lower()] = spellId;
                    end
                end

                for _, abilityId in ipairs(row.abilities) do
                    if (not seenAbil[abilityId]) then
                        seenAbil[abilityId] = true;

                        local name = abilityName(abilityId);

                        rows[#rows + 1] = {
                            kind     = 'ability',
                            id       = abilityId,
                            name     = name,
                            from     = row.name,
                            buttonId = string.format('Use##dwes_use_%d', abilityId),
                        };

                        byAbility[name:lower()] = abilityId;
                    end
                end
            end
        end
    end

    state.grants             = rows;
    state.grantSpellByName   = bySpell;
    state.grantAbilityByName = byAbility;
end

-- A little-endian uint32 out of a packet (dwhub's and dwcraft's helper).
local function u32(data, off)
    local b1, b2, b3, b4 = string.byte(data, off + 1, off + 4);

    return (b1 or 0) + (b2 or 0) * 256 + (b3 or 0) * 65536 + (b4 or 0) * 16777216;
end

-- The player's own server id off the party list, or nil. Read at a sync's
-- commit, never inside 0x000A: while that packet is handled the list can
-- still hold the previous character, which is why the zone line reads the
-- packet's own bytes instead.
local function playerServerId()
    local ok, id = pcall(function ()
        return AshitaCore:GetMemoryManager():GetParty():GetMemberServerId(0);
    end);

    if (ok and type(id) == 'number' and id > 0) then
        return id;
    end

    return nil;
end

--[[
* Commit helpers.
*
* A `sync` answer that arrived WHOLE replaces the wallet and the owned set
* wholesale (dwtracker's rule: never merged, so a stale row cannot survive a
* refresh -- and the row that matters is an alt's, after a relog under a
* window that was never reloaded: this wire carries no charid, so the full
* picture is the only thing that can retire the previous character's).
* "Whole" is judged by the server's own counts: thirty `w|` rows, and as
* many `p|` rows as the `s|` line says are owned. Anything short of that --
* the client's chat rate limit drops lines, which is the whole reason this
* addon carries an answer clock -- is MERGED by key instead, so a dropped
* line costs one stale figure until the next poll rather than an Esper that
* reads "not made" for a minute.
*
* A write's answer (create / equip / unequip) carries only the rows it
* touched and is always merged.
--]]
local function countKeys(tbl)
    local count = 0;

    for _ in pairs(tbl) do
        count = count + 1;
    end

    return count;
end

local function commitSheet(sheet)
    if (sheet ~= nil and sheet.seen) then
        state.sheet   = sheet;
        state.sheetAt = os.clock();
    end
end

local function commitWallet(pending, whole)
    if (pending == nil) then
        return;
    end

    if (whole and countKeys(pending) == KIND_COUNT) then
        state.wallet = pending;

        return;
    end

    for kind, row in pairs(pending) do
        state.wallet[kind] = row;
    end
end

local function commitOwned(pending, sheet, whole)
    if (pending == nil) then
        return;
    end

    if (whole and sheet ~= nil and sheet.seen and countKeys(pending) == sheet.owned) then
        state.owned = pending;

        return;
    end

    for id, row in pairs(pending) do
        state.owned[id] = row;
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], -1);

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            --[[
            * THE REFUSAL RETIRES THE ASKS (dwspoils' note, kept whole). A
            * mismatched `d|` IS an answer -- the server spoke, in a dialect
            * this addon does not read -- and leaving the clock running
            * against it costs twice: the retry goes out against the protocol
            * document's own promise to stop asking, and the silent latch then
            * paints "No answer from the server" over the accurate "Update
            * dwesper" banner. The staging copies go too, and so does the
            * queue: a line already sitting in the pump would go out a beat
            * later and be answered in the same dialect.
            --]]
            state.requested     = T{ };
            state.pendingWrite  = nil;
            state.pendingSheet  = nil;
            state.pendingWallet = nil;
            state.pendingOwned  = nil;
            state.pendingRoster = nil;
            state.serverSilent  = false;

            for index = #queue, 1, -1 do
                table.remove(queue, index);
            end

            print(chat.header('dwesper'):append(chat.error(string.format(
                'Server protocol %d, addon expects %d. Update dwesper.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope proves the server is there (the silent
        -- latch lifts), but only the MATCHING verb retires its own ask.
        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.requested[state.inbound] ~= nil) then
            state.requested[state.inbound] = nil;
        end

        -- A NEW ANSWER CLEARS THE OLD BANNER. Whatever the server wants to
        -- say about THIS answer rides inside this envelope as m| or e|.
        state.status    = '';
        state.statusBad = false;

        -- Every verb but roster may carry s|, w| and p| rows: sync sends the
        -- whole picture, a write sends what it touched. Staged here, swapped
        -- at z|.
        if (state.inbound ~= 'roster') then
            state.pendingSheet  = { seen = false };
            state.pendingWallet = { };
            state.pendingOwned  = { };
        end

        if (state.inbound == 'roster') then
            state.pendingRoster = { };
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        if (kind == 'e') then
            --[[
            * A REFUSAL INSIDE AN OPEN ENVELOPE KILLS THAT ANSWER (dwspoils'
            * rule): a door emits exactly `d|1|sync`, `e|Espers are not loaded
            * on this build.`, `z|sync` when the core did not load, and
            * committing that staging copy would leave the window drawing a
            * confident false picture of a server that answered nothing.
            --]]
            state.pendingSheet  = nil;
            state.pendingWallet = nil;
            state.pendingOwned  = nil;
            state.pendingRoster = nil;

            -- A refusal answers the write in flight, whatever the envelope
            -- says: the buttons come back now rather than in five seconds.
            -- A write still PARKED (2026-09-27) is not in flight -- nothing
            -- this server said can be about a line it never received.
            local pending = state.pendingWrite;

            if (pending ~= nil and pending.sent) then
                state.pendingWrite = nil;
            else
                pending = nil;
            end

            --[[
            * THE UNKNOWN-VERB LATCH (the dwbags shape, per verb). A server
            * older than this addon answers a verb it lacks with its
            * unknown-verb sentence, once per ask, forever -- so the verb the
            * sentence names is latched and not asked again until a zone line
            * re-probes it. Matched on the QUOTED verb and the word `verb`,
            * which is how squad_storage.lua and every door since spell it;
            * a refusal that quotes no verb latches nothing.
            --]]
            local lowered = text:lower();

            if (string.find(lowered, 'verb', 1, true) ~= nil) then
                for verb in pairs(LINES) do
                    if (string.find(lowered, '"' .. verb .. '"', 1, true) ~= nil) then
                        state.unsupported[verb] = true;
                        state.requested[verb]   = nil;
                    end
                end

                for verb in pairs(WRITE_LINES) do
                    if (string.find(lowered, '"' .. verb .. '"', 1, true) ~= nil) then
                        state.unsupported[verb] = true;
                    end
                end

                -- The verb the refused write named is latched even when the
                -- sentence does not quote it in full: the ask and the answer
                -- are one pair.
                if (pending ~= nil and string.find(lowered, 'unknown', 1, true) ~= nil) then
                    state.unsupported[pending.verb] = true;
                end
            end

            --[[
            * THE HOOK'S MAP WAS STALE (2026-09-27, the Esper audit). The
            * name maps are rebuilt only when a sync commits, and an Esper
            * taken off through the typed `!esper unequip` -- whose prose this
            * addon never reads -- leaves its names in them: an RDM's own
            * Blizzard III macro was sent to the door and refused in a window
            * that was shut, cast after cast. The server's refusal for a cast
            * or use it does not lend (esper_core verbCast/verbUse: "... is
            * not lent by an Esper you hold") re-asks the picture, so the
            * next press finds the name gone and goes to the client; with the
            * window shut the sentence is also said once in chat. At most one
            * press is lost per stale map.
            --]]
            if (pending ~= nil and (pending.verb == 'cast' or pending.verb == 'use')
                    and string.find(lowered, NOT_LENT_PHRASE, 1, true) ~= nil) then
                ask('sync');
                tellShut(text);
            end

            --[[
            * THE LEVEL CAP IS SAID TOO, AND RE-ASKS NOTHING (1.2.1). Inside
            * capped content the server refuses a lent spell or ability the
            * cap holds back in its own words (esper_core cappedSentence) --
            * and with the window shut those words went nowhere: the hook had
            * blocked the player's `/ma`, so a macro in a level-30 battlefield
            * simply did nothing, press after press. Said once in chat, the
            * TELL_GAP rule against a mashed macro; no sync, because the
            * picture is right and a re-ask per press would be a poll.
            --]]
            if (pending ~= nil and (pending.verb == 'cast' or pending.verb == 'use')
                    and string.find(lowered, CAPPED_PHRASE, 1, true) ~= nil) then
                tellShut(text);
            end
        end

        -- A NOTE WITH NO SENTENCE IN IT SAYS NOTHING. The bookkeeping above
        -- still ran: a refusal with nothing to say is still a refusal.
        if (text == '') then
            return;
        end

        -- DRAWN, NEVER PRINTED. A refusal is the window's status line and
        -- nothing else: a macro that presses a granted spell six times inside
        -- its recast would otherwise print six red lines into the chat log.
        -- (The two exceptions are tellShut's, above: "not lent" and the
        -- capped level, with the window shut, once per TELL_GAP.)
        state.status    = text;
        state.statusBad = (kind == 'e');

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    -- s| -- the state line: the two slots, how many slots are open, the Core
    -- count, and the owned/mastered tallies.
    if (kind == 's' and state.pendingSheet ~= nil) then
        state.pendingSheet.seen     = true;
        state.pendingSheet.slot1    = wireInt(parts[2]);
        state.pendingSheet.slot2    = wireInt(parts[3]);
        state.pendingSheet.slots    = math.max(1, math.min(2, wireInt(parts[4], 1)));
        state.pendingSheet.cores    = wireInt(parts[5]);
        state.pendingSheet.owned    = wireInt(parts[6]);
        state.pendingSheet.mastered = wireInt(parts[7]);

        -- Appended 2026-09-27 (1.2.1): 1 when this login could not read the
        -- character's Esper rows -- the banner and the greyed writes. A
        -- server older than the field sends seven and this reads 0; only an
        -- exact 1 freezes, so a garbled field never greys a working window.
        state.pendingSheet.unreadable = wireInt(parts[8], 0) == 1;

        return;
    end

    -- w| -- one Magicite kind: amount held and lifetime earned.
    if (kind == 'w' and state.pendingWallet ~= nil) then
        local which = wireInt(parts[2]);

        if (which >= 1 and which <= KIND_COUNT) then
            state.pendingWallet[which] = {
                amount   = wireInt(parts[3]),
                lifetime = wireInt(parts[4]),
            };
        end

        return;
    end

    -- p| -- one OWNED Esper: attunement units, mastered, the slot it sits in.
    if (kind == 'p' and state.pendingOwned ~= nil) then
        local id = wireInt(parts[2]);

        if (id >= 1 and id <= ESPER_COUNT) then
            -- A MASTERED Esper draws full whatever the number says (1.2.2):
            -- the bit is the truth, exactly as the store keeps it.
            local mastered = wireInt(parts[4]) ~= 0;
            local attune   = mastered and WIRE_ATTUNE_FULL or math.max(0, math.min(WIRE_ATTUNE_FULL, wireInt(parts[3])));

            state.pendingOwned[id] = {
                attune   = attune,
                mastered = mastered,
                slot     = math.max(0, math.min(2, wireInt(parts[5]))),
                -- Drawn every frame, built once here.
                fraction = attune / WIRE_ATTUNE_FULL,
                percent  = string.format('%d%%', math.floor(attune / (WIRE_ATTUNE_FULL / 100))),
            };
        end

        return;
    end

    -- r| -- one roster row: everything static about an Esper.
    if (kind == 'r' and state.pendingRoster ~= nil) then
        local id = wireInt(parts[2]);

        if (id >= 1 and id <= ESPER_COUNT) then
            local row = state.pendingRoster[id] or { grants = '', line = '' };

            row.id        = id;
            row.name      = parts[3] ~= '' and parts[3] or string.format('Esper %d', id);
            row.tier      = wireInt(parts[4], 1);
            row.elem      = wireInt(parts[5]);
            row.jobA      = wireInt(parts[6]);
            row.jobB      = wireInt(parts[7]);
            row.priceE    = wireInt(parts[8]);
            row.priceA    = wireInt(parts[9]);
            row.priceB    = wireInt(parts[10]);
            row.cores     = wireInt(parts[11]);
            row.spells    = csvIds(parts[12]);
            row.abilities = csvIds(parts[13]);

            -- Appended 2026-09-24: how many OTHER Espers must be mastered
            -- first (31 for Driftwood, 0 for the rest). A server older than
            -- the field sends thirteen and this reads 0; the store enforces
            -- the condition either way, this only lets the pane say so.
            row.needMastered = wireInt(parts[14], 0);

            -- Priced on EVERY kind: element 0 and no job pair with a price
            -- (Driftwood). The three price columns carry the same number.
            row.priceEvery = (row.elem < 1 and row.jobA < 1 and row.jobB < 1) and row.priceE or 0;

            -- Drawn every frame, built once here.
            row.tileId   = string.format('%s##dwes_tile_%d', row.name, id);
            row.tierText = tierName(row.tier);
            row.elemText = row.elem >= 1 and row.elem <= ELEMENT_COUNT and ELEMENT_NAMES[row.elem] or 'any';
            row.jobsText = (row.jobA >= 1 and row.jobB >= 1)
                and string.format('%s / %s', jobName(row.jobA), jobName(row.jobB))
                or 'any';
            row.subText  = string.format('%s  %s', row.tierText, row.elemText);

            state.pendingRoster[id] = row;
        end

        return;
    end

    -- q| -- the grant text for one roster row; l| -- its line of prose. Either
    -- may arrive before its r| under the rate limit, so a shell is made.
    if ((kind == 'q' or kind == 'l') and state.pendingRoster ~= nil) then
        local id = wireInt(parts[2]);

        if (id >= 1 and id <= ESPER_COUNT) then
            local row = state.pendingRoster[id] or { grants = '', line = '' };

            if (kind == 'q') then
                row.grants = line:sub(#parts[1] + #parts[2] + 3);
            else
                row.line = line:sub(#parts[1] + #parts[2] + 3);
            end

            state.pendingRoster[id] = row;
        end

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        --[[
        * ONLY A COMPLETE ANSWER COMMITS. The staging copies are nil when a
        * refusal killed the envelope. A roster with no rows is not committed
        * either -- the door answered and there was nothing in it, and the
        * grid keeps saying "Waiting for the roster" rather than drawing
        * thirty-two empty tiles.
        --]]
        local sheet = state.pendingSheet;
        local whole = closed == 'sync';

        commitSheet(sheet);
        commitWallet(state.pendingWallet, whole);
        commitOwned(state.pendingOwned, sheet, whole);

        -- WHOSE PICTURE THIS IS, when no zone line has said yet (an addon
        -- loaded mid-session): the 0x000A guard below can then tell this
        -- character's next zone line from a relog, rather than wiping a
        -- picture it cannot place.
        if (whole and sheet ~= nil and state.charId == nil) then
            state.charId = playerServerId();
        end

        state.pendingSheet  = nil;
        state.pendingWallet = nil;
        state.pendingOwned  = nil;

        if (closed == 'roster') then
            local pending = state.pendingRoster;

            state.pendingRoster = nil;

            if (pending ~= nil and next(pending) ~= nil) then
                -- A shell made by a q|/l| that never got its r| is not a
                -- row the grid can draw; only complete rows commit.
                local roster = { };
                local count  = 0;

                for id, row in pairs(pending) do
                    if (row.name ~= nil) then
                        roster[id] = row;
                        count      = count + 1;
                    end
                end

                if (count > 0) then
                    state.roster   = roster;
                    state.rosterAt = os.clock();
                end
            end
        end

        rebuildGrants();

        -- A write's envelope closing is what re-arms the buttons -- and, for
        -- the three that move the wallet or the slots, what re-asks sync so
        -- the picture on screen is the server's rather than this addon's
        -- guess at it. Only a write that WENT OUT is closed by one: a parked
        -- one (2026-09-27) is not answered by a late envelope of its verb.
        if (state.pendingWrite ~= nil and state.pendingWrite.sent and closed == state.pendingWrite.verb) then
            state.pendingWrite = nil;

            if (closed == 'create' or closed == 'equip' or closed == 'unequip') then
                ask('sync');
            end
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwesper_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        -- BLOCKED BEFORE IT IS PARSED (the dwbags rule), and ONLY for this
        -- sender. A record that throws inside handleRecord must still not
        -- reach the chat log.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwesper'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line re-probes every latch and re-arms the lazy hello. The
    -- roster CACHE survives it -- the roster is static for the session and
    -- was asked once -- but a roster that never arrived is asked again. A
    -- half-arrived envelope dies with the zone.
    if (e.id == 0x000A) then
        state.requested     = T{ };
        state.serverSilent  = false;
        state.refused       = false;
        state.unsupported   = { };
        state.inbound       = nil;
        state.pendingSheet  = nil;
        state.pendingWallet = nil;
        state.pendingOwned  = nil;
        state.pendingRoster = nil;
        state.pendingWrite  = nil;
        state.helloSent     = false;
        state.polledAt      = nil;
        state.rosterAsked   = state.roster ~= nil;

        --[[
        * A DIFFERENT CHARACTER GETS NONE OF THE LAST ONE'S PICTURE
        * (2026-09-27, the Esper audit). The addon outlives a relog, and a
        * sync -- the only thing that replaces the owned set -- is asked only
        * while the window is shown: so a WHM who never opened /esper kept the
        * Kirin and Carbuncle grants of the character before, and the hook
        * sent every Cure and Protect to a door that refused them in a shut
        * window. The id is the packet's own (offset 0x04, dwhub's guard); an
        * id this addon never saw -- nil included -- wipes, and the static
        * roster is kept. A zone line by the same character wipes nothing.
        --]]
        local uid = (e.data ~= nil) and u32(e.data, 0x04) or 0;

        if (uid ~= 0 and uid ~= state.charId) then
            state.charId   = uid;
            state.sheet    = nil;
            state.sheetAt  = nil;
            state.wallet   = { };
            state.owned    = { };
            state.selected = nil;

            rebuildGrants();
        end

        -- A RED REFUSAL DOES NOT OUTLIVE THE PLACE IT WAS ABOUT.
        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end
    end
end);

--[[
* THE TARGET INDEX THE DOOR IS HANDED. The current target when one is active,
* else 0 -- which the server reads as "the default for this action": the
* player's battle target for something offensive, the player for something
* beneficial (T10). The `<me>` word resolves to the player's own index off the
* party list, the way dwengage and dwtracker read it. Every call is pcall'd:
* the memory manager can answer nil for a frame around a zone line.
--]]
local function currentTargetIndex()
    local ok, index = pcall(function ()
        local target = AshitaCore:GetMemoryManager():GetTarget();

        if (target == nil or target:GetIsActive(0) == 0) then
            return 0;
        end

        return target:GetTargetIndex(0);
    end);

    if (ok and type(index) == 'number' and index > 0) then
        return index;
    end

    return 0;
end

local function selfIndex()
    local ok, index = pcall(function ()
        return AshitaCore:GetMemoryManager():GetParty():GetMemberTargetIndex(0);
    end);

    if (ok and type(index) == 'number' and index > 0) then
        return index;
    end

    return 0;
end

--[[
* A party or alliance slot's entity index (0..5 the party, 6..11 and 12..17
* the other two alliance parties -- Ashita's party list order), or nil. A
* member in ANOTHER ZONE keeps an index that is stale here and can name a
* different entity, and a zero index is the server's "default target" -- so
* either is nil, never a guess.
--]]
local function memberIndex(slot)
    local ok, index = pcall(function ()
        local party  = AshitaCore:GetMemoryManager():GetParty();
        local active = party:GetMemberIsActive(slot);

        if (active == nil or active == 0 or active == false) then
            return 0;
        end

        if (party:GetMemberZone(slot) ~= party:GetMemberZone(0)) then
            return 0;
        end

        return party:GetMemberTargetIndex(slot);
    end);

    if (ok and type(index) == 'number' and index > 0) then
        return index;
    end

    return nil;
end

-- The player's pet's entity index (dwchat's read), or nil when there is none.
local function petIndex()
    local ok, index = pcall(function ()
        return AshitaCore:GetMemoryManager():GetEntity():GetPetTargetIndex(selfIndex());
    end);

    if (ok and type(index) == 'number' and index > 0) then
        return index;
    end

    return nil;
end

--[[
* The target word of a `/ma` or `/ja` line to an index, or NIL for "not a
* word this file can place" -- and the hook hands a nil back to the client
* untouched (2026-09-27, the Esper audit: every word but three used to become
* the current target, so `/ma "Cure III" <p2>` cured the mob the healer had
* targeted, and `<stpc>` or a name fired at once at whatever was under the
* cursor).
*
* `<t>` or no word is the current target. `<me>` is the player; `<bt>` is sent
* as 0, because the house has no helper for the client's own battle target and
* 0 IS the server's "your battle target for an offensive action, yourself for
* a beneficial one" (T10; esper_core's resolveTarget honours only an index
* above zero) -- the cursor target would be wrong exactly when it differs from
* the thing being fought. `<p0>`..`<p5>`, `<a10>`..`<a15>` and `<a20>`..`<a25>`
* are party-list slots and `<pet>` the player's pet; one that is absent or in
* another zone is nil, NOT 0 (0 would cast at the caster). A bare index of
* digits is passed through. Everything else -- a player's name, `<st>` and the
* sub-target words, `<lastst>`, `<ft>` -- is nil: the client opens its own
* cursor or finds its own name, and the current target is not what the player
* named.
--]]
local function resolveTargetWord(word)
    if (type(word) ~= 'string' or word == '') then
        return currentTargetIndex();
    end

    local lowered = word:lower();

    if (lowered == '<t>') then
        return currentTargetIndex();
    end

    if (lowered == '<me>') then
        return selfIndex();
    end

    if (lowered == '<bt>') then
        return 0;
    end

    if (lowered == '<pet>') then
        return petIndex();
    end

    local partySlot = lowered:match('^<p([0-5])>$');

    if (partySlot ~= nil) then
        return memberIndex(tonumber(partySlot));
    end

    local alliance, member = lowered:match('^<a([12])([0-5])>$');

    if (alliance ~= nil) then
        return memberIndex(tonumber(alliance) * 6 + tonumber(member));
    end

    -- Digits only: `tonumber` would take '0x10', '1e3' and 'inf' as readily,
    -- and the wire's target field is sixteen bits wide.
    if (lowered:match('^%d+$') ~= nil) then
        local number = tonumber(lowered);

        if (number ~= nil and number <= 0xFFFF) then
            return number;
        end
    end

    return nil;
end

--[[
* CAN THE CLIENT CAST THIS ONE ITSELF? (2026-09-27, the Esper audit.) The hook
* exists because the stock client will not send a spell the current jobs
* cannot cast (T10) -- so a granted spell they CAN cast is the client's, and
* goes to it exactly as typed: the client's own targeting, `<p2>` and `<stpc>`
* included, and no dependence on this addon's picture being current.
*
* "Can" is the client's own test: the spell is in the player's spell list
* (IPlayer:HasSpell, dwbags' read) AND the main job's level reaches the DAT's
* LevelRequired for it, or the sub job's does. HasSpell alone would answer
* yes for every grant -- the server lends an active Esper's spells into the
* list (esper_store.cpp lendSpells, memory only) -- so the level half is the
* one that decides.
* LevelRequired is indexed jobId + 1 (dwgambits' note, verified 2026-09-18);
* -1 is "never", and a value above 99 is a job-point gift, not a level. Any
* surprise from a binding reads as "not native": the door still works.
*
* Spells only. An ability has no per-job level in the client's resources, and
* the server writes granted abilities into the player's own ability list, so
* no test here could tell a WAR's Provoke from Gilgamesh's -- a /ja keeps
* going through the door, which casts it either way.
--]]
local function castsNatively(spellId)
    local ok, native = pcall(function ()
        local player = AshitaCore:GetMemoryManager():GetPlayer();
        local spell  = AshitaCore:GetResourceManager():GetSpellById(spellId);

        if (player == nil or spell == nil or player:HasSpell(spellId) ~= true) then
            return false;
        end

        local levels = spell.LevelRequired;

        local function reaches(job, level)
            if (type(job) ~= 'number' or job < 1 or type(level) ~= 'number' or level < 1) then
                return false;
            end

            local need = levels[job + 1];

            return type(need) == 'number' and need >= 1 and need <= 99 and need <= level;
        end

        return reaches(player:GetMainJob(), player:GetMainJobLevel())
            or reaches(player:GetSubJob(), player:GetSubJobLevel());
    end);

    return ok and native == true;
end

-- The Grants tab's buttons and the hook share one door.
local function castSpell(spellId, targetIndex)
    return sendWrite('cast', string.format(WRITE_LINES.cast, spellId, targetIndex));
end

local function useAbility(abilityId, targetIndex)
    return sendWrite('use', string.format(WRITE_LINES.use, abilityId, targetIndex));
end

--[[
* Rendering.
*
* MEASURED LAYOUT, NOT GUESSED (dwcraft's rule, reached here through
* dwspoils). Both helpers read the LIVE font each frame and fall back to a
* conservative constant when a binding does not answer.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

-- What a scrolling region must leave below itself (the dwnemesis
-- footerReserve shape): a NEGATIVE outer height reads as "available minus
-- this".
local function footerReserve()
    return -(metric('GetFrameHeightWithSpacing', 26) + 12);
end

-- One short tip on the item just drawn.
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local SZ_BAR   = { -1, 6 };
local SZ_FILL  = { 0, 0 };
local SZ_MAX   = { 99999, 99999 };
local SZ_MIN   = { 720, 420 };
local SZ_FIRST = { 780, 480 };

local function esperNameOf(id)
    if (id == nil or id == 0) then
        return '--';
    end

    local row = state.roster ~= nil and state.roster[id] or nil;

    return row ~= nil and row.name or string.format('Esper %d', id);
end

local function refreshTip()
    if (state.refused) then
        return TIPS.refreshStale;
    end

    if (state.sheetAt == nil) then
        return TIPS.refresh;
    end

    return string.format('%s\nWhat is on screen arrived about %d second(s) ago.',
        TIPS.refresh, math.max(0, math.floor(os.clock() - state.sheetAt)));
end

local function renderHeader()
    if (imgui.Button('Refresh##dwes_refresh')) then
        -- A ROSTER THAT NEVER CAME is asked again behind the sync: the click
        -- is the player asking (2026-09-27). Re-armed HERE and not at the
        -- refused envelope, where it would re-ask every send interval
        -- against a server that keeps refusing.
        if (rosterStalled()) then
            state.rosterAsked = false;
        end

        ask('sync', true);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(refreshTip());
    end

    imgui.SameLine();

    -- REFUSED OUTRANKS SILENT, and the status line outranks the sheet line.
    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwesper through the launcher.');
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server. Refresh to ask again.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or busy()) then
        imgui.TextDisabled('asking...');
    elseif (state.sheet ~= nil) then
        local sheet = state.sheet;

        imgui.Text(string.format('Slot 1: %s', esperNameOf(sheet.slot1)));

        if (sheet.slots >= 2) then
            imgui.SameLine();
            imgui.Text(string.format('   Slot 2: %s', esperNameOf(sheet.slot2)));
        end

        imgui.SameLine();
        imgui.TextColored(theme.colors.warn, string.format('   Cores %d', sheet.cores));
        tip(TIPS.cores);

        imgui.SameLine();
        imgui.TextDisabled(string.format('   %d owned, %d mastered', sheet.owned, sheet.mastered));
    else
        imgui.TextDisabled('Kills that pay experience pay Magicite. Magicite and Cores make Espers.');
    end

    imgui.SameLine();

    -- The settings row: one switch, right of the status. Saved on change.
    if (imgui.Checkbox('Route /ma and /ja##dwes_intercept', state.intercept)) then
        saveConfig();
    end

    tip(TIPS.intercept);

    imgui.SameLine();

    -- The Magicite feed: nothing to ask the server; the text_in handler reads
    -- the switch on the next line that arrives.
    if (imgui.Checkbox('Chat notifications when gaining Magicite##dwes_notify', state.notify)) then
        saveConfig();
    end

    tip(TIPS.notify);

    --[[
    * THE FROZEN RECORD, ON ITS OWN LINE AND ON EVERY TAB (1.2.1). Not the
    * status line: that is the last answer's voice, cleared by the next `d|`,
    * and this stands until the player logs out -- a sync every minute must
    * not blink it away. Wrapped, so a narrow window keeps all of it.
    --]]
    if (frozen()) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(theme.colors.err, UNREADABLE_BANNER);
        imgui.PopTextWrapPos();
    end

    imgui.Separator();
end

-- Can a kind's price be paid, by the wallet on screen? A courtesy: the
-- server re-reads both sides at confirm.
local function held(kind)
    local row = state.wallet[kind];

    return row ~= nil and row.amount or 0;
end

-- The least held of every kind, for a row priced on all of them.
local function leastHeld()
    local least = nil;

    for kind = 1, KIND_COUNT do
        local have = held(kind);

        if (least == nil or have < least) then
            least = have;
        end
    end

    return least or 0;
end

local function masteredCount()
    return state.sheet ~= nil and state.sheet.mastered or 0;
end

local function priceLine(kind, price)
    local have = held(kind);

    imgui.TextColored(have >= price and theme.colors.ok or theme.colors.err,
        string.format('%s Magicite %d  (you hold %d)', kindName(kind), price, have));
end

-- The Create button's greyed reason, built on hover only.
local function createReason(row)
    if (state.sheet == nil) then
        return 'Waiting for the server.';
    end

    -- Ahead of the in-flight reason: that one clears in a second, this one
    -- only at the next login (1.2.1).
    if (frozen()) then
        return UNREADABLE_BANNER;
    end

    if (state.pendingWrite ~= nil) then
        return TIPS.pending;
    end

    if (state.unsupported.create) then
        return 'This server does not answer the create verb -- it is older than dwesper.';
    end

    if (row.needMastered > 0 and masteredCount() < row.needMastered) then
        return string.format('Needs every other Esper mastered first; you have mastered %d of %d.', masteredCount(), row.needMastered);
    end

    if (row.priceEvery > 0 and leastHeld() < row.priceEvery) then
        return string.format('Needs %d of every Magicite kind; the least you hold is %d.', row.priceEvery, leastHeld());
    end

    if (row.cores > 0 and state.sheet.cores < row.cores) then
        return string.format('Needs %d Esper Core(s); you hold %d.', row.cores, state.sheet.cores);
    end

    if (row.elem >= 1 and held(row.elem) < row.priceE) then
        return string.format('Needs %d %s Magicite; you hold %d.', row.priceE, kindName(row.elem), held(row.elem));
    end

    if (row.jobA >= 1 and held(ELEMENT_COUNT + row.jobA) < row.priceA) then
        return string.format('Needs %d %s Magicite; you hold %d.', row.priceA, jobName(row.jobA), held(ELEMENT_COUNT + row.jobA));
    end

    if (row.jobB >= 1 and held(ELEMENT_COUNT + row.jobB) < row.priceB) then
        return string.format('Needs %d %s Magicite; you hold %d.', row.priceB, jobName(row.jobB), held(ELEMENT_COUNT + row.jobB));
    end

    return TIPS.create;
end

local function canCreate(row)
    return state.sheet ~= nil
        and state.pendingWrite == nil
        and not latched()
        and not frozen()
        and not state.unsupported.create
        and (row.cores <= 0 or state.sheet.cores >= row.cores)
        and (row.needMastered <= 0 or masteredCount() >= row.needMastered)
        and (row.priceEvery <= 0 or leastHeld() >= row.priceEvery)
        and (row.elem < 1 or held(row.elem) >= row.priceE)
        and (row.jobA < 1 or held(ELEMENT_COUNT + row.jobA) >= row.priceA)
        and (row.jobB < 1 or held(ELEMENT_COUNT + row.jobB) >= row.priceB);
end

-- A button that greys itself and explains why on hover (dwmerits' shape:
-- hovered OUTSIDE the disabled block, because ImGui does not report a hover
-- over a disabled item and "why is this grey" is the question).
local function actionButton(label, enabled, why, onPress)
    if (not enabled) then imgui.BeginDisabled(); end

    local pressed = imgui.Button(label);

    if (not enabled) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(why);
    end

    if (pressed and enabled) then
        onPress();
    end
end

local function renderDetail()
    local row = state.selected ~= nil and state.roster ~= nil and state.roster[state.selected] or nil;

    if (row == nil) then
        imgui.TextDisabled('Select an Esper.');

        return;
    end

    local owned = state.owned[row.id];

    imgui.TextColored(tierColour(row.tier), row.name);
    imgui.TextDisabled(string.format('%s Esper  --  %s  --  %s', row.tierText, row.elemText, row.jobsText));

    if (owned ~= nil) then
        imgui.ProgressBar(owned.fraction, SZ_BAR, '');
        tip(TIPS.attune);

        if (owned.mastered) then
            imgui.TextColored(theme.colors.ok, 'Mastered');
        else
            imgui.Text(string.format('Attunement %s', owned.percent));
        end

        if (owned.slot > 0) then
            imgui.SameLine();
            imgui.TextColored(theme.colors.warn, string.format('   Equipped (slot %d)', owned.slot));
        end
    else
        imgui.TextDisabled('Not yet made.');
    end

    imgui.Separator();

    if (row.grants ~= '') then
        imgui.PushTextWrapPos(0);
        imgui.Text(row.grants);
        imgui.PopTextWrapPos();
    end

    if (row.line ~= '') then
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled(row.line);
        imgui.PopTextWrapPos();
    end

    imgui.Separator();

    if (owned == nil) then
        imgui.Text('Price:');
        tip(TIPS.wallet);

        if (row.elem >= 1 and row.priceE > 0) then
            priceLine(row.elem, row.priceE);
        end

        if (row.jobA >= 1 and row.priceA > 0) then
            priceLine(ELEMENT_COUNT + row.jobA, row.priceA);
        end

        if (row.jobB >= 1 and row.priceB > 0) then
            priceLine(ELEMENT_COUNT + row.jobB, row.priceB);
        end

        if (row.priceEvery > 0) then
            local least = leastHeld();

            imgui.TextColored(least >= row.priceEvery and theme.colors.ok or theme.colors.err,
                string.format('Every Magicite kind %d  (the least you hold is %d)', row.priceEvery, least));
            tip(TIPS.wallet);
        end

        if (row.needMastered > 0) then
            local have = masteredCount();

            imgui.TextColored(have >= row.needMastered and theme.colors.ok or theme.colors.err,
                string.format('Every other Esper mastered  (you have mastered %d of %d)', have, row.needMastered));
            tip(TIPS.needMastered);
        end

        if (row.cores > 0) then
            local have = state.sheet ~= nil and state.sheet.cores or 0;

            imgui.TextColored(have >= row.cores and theme.colors.ok or theme.colors.err,
                string.format('Esper Cores %d  (you hold %d)', row.cores, have));
            tip(TIPS.cores);
        end

        actionButton(string.format('Create##dwes_create_%d', row.id), canCreate(row), createReason(row), function ()
            sendWrite('create', string.format(WRITE_LINES.create, row.id));
        end);

        return;
    end

    -- A frozen record greys all three, its sentence the reason, ahead of the
    -- in-flight one (1.2.1; createReason's order).
    local slots = state.sheet ~= nil and state.sheet.slots or 1;
    local free  = state.pendingWrite == nil and not latched() and not frozen();
    local why   = (frozen() and UNREADABLE_BANNER) or (state.pendingWrite ~= nil and TIPS.pending) or nil;

    if (owned.slot ~= 1) then
        local can = free and not state.unsupported.equip;

        actionButton(string.format('Equip slot 1##dwes_equip1_%d', row.id), can, why or TIPS.equip1, function ()
            sendWrite('equip', string.format(WRITE_LINES.equip, row.id, 1));
        end);

        imgui.SameLine();
    end

    if (slots >= 2 and owned.slot ~= 2) then
        local can = free and not state.unsupported.equip;

        actionButton(string.format('Equip slot 2##dwes_equip2_%d', row.id), can, why or TIPS.equip2, function ()
            sendWrite('equip', string.format(WRITE_LINES.equip, row.id, 2));
        end);

        imgui.SameLine();
    end

    if (owned.slot > 0) then
        local slot = owned.slot;
        local can  = free and not state.unsupported.unequip;

        actionButton(string.format('Unequip##dwes_unequip_%d', row.id), can, why or TIPS.unequip, function ()
            sendWrite('unequip', string.format(WRITE_LINES.unequip, slot));
        end);
    end
end

local function renderTile(row)
    local owned    = state.owned[row.id];
    local selected = state.selected == row.id;

    if (imgui.Selectable(row.tileId, selected)) then
        state.selected = row.id;
    end

    tip(TIPS.tile);

    imgui.TextColored(tierColour(row.tier), row.subText);

    if (owned ~= nil) then
        if (owned.mastered) then
            imgui.TextColored(theme.colors.ok, 'Mastered');
        else
            imgui.TextDisabled(string.format('Attunement %s', owned.percent));
        end

        if (owned.slot > 0) then
            imgui.SameLine();
            imgui.TextColored(theme.colors.warn, string.format(' Equipped %d', owned.slot));
        end

        imgui.ProgressBar(owned.fraction, SZ_BAR, '');
        tip(TIPS.attune);
    else
        imgui.TextDisabled('not made');
    end
end

-- What the Espers and Grants tabs say with no roster to draw. "Waiting" only
-- while one can still come; a roster that did not is said so, with the
-- Refresh that now asks for it again (2026-09-27).
local function renderNoRoster()
    if (state.unsupported.roster) then
        imgui.TextDisabled('This server does not answer the roster verb -- it is older than dwesper.');
    elseif (rosterStalled()) then
        imgui.TextDisabled('The Esper roster did not arrive. Refresh to ask for it again.');
    else
        imgui.TextDisabled('Waiting for the roster...');
    end
end

local function renderEspers()
    if (state.roster == nil) then
        renderNoRoster();

        return;
    end

    if (imgui.BeginTable('dwes_espers', 2, ImGuiTableFlags_SizingStretchProp, { 0, footerReserve() })) then
        imgui.TableSetupColumn('##dwes_grid_col', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('##dwes_detail_col', ImGuiTableColumnFlags_WidthStretch, 2.0);

        imgui.TableNextRow();
        imgui.TableNextColumn();

        -- The grid scrolls in its own child; the detail pane beside it does
        -- not move when it does. EndChild is Begin's kind of pair: always
        -- called, whatever BeginChild answered.
        if (imgui.BeginChild('dwes_gridpane', SZ_FILL, ImGuiChildFlags_None)) then
            if (imgui.BeginTable('dwes_grid', GRID_COLUMNS,
                    bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchSame))) then
                for id = 1, ESPER_COUNT do
                    if ((id - 1) % GRID_COLUMNS == 0) then
                        imgui.TableNextRow();
                    end

                    imgui.TableNextColumn();

                    local row = state.roster[id];

                    if (row ~= nil) then
                        renderTile(row);
                    else
                        imgui.TextDisabled(string.format('Esper %d', id));
                    end
                end

                imgui.EndTable();
            end
        end

        imgui.EndChild();

        imgui.TableNextColumn();

        if (imgui.BeginChild('dwes_detailpane', SZ_FILL, ImGuiChildFlags_None)) then
            renderDetail();
        end

        imgui.EndChild();

        imgui.EndTable();
    end
end

local function renderMagicite()
    if (state.sheet == nil and next(state.wallet) == nil) then
        imgui.TextDisabled('Waiting for the server...');

        return;
    end

    imgui.Text('Your Magicite:');
    tip(TIPS.wallet);
    imgui.Separator();

    if (imgui.BeginTable('dwes_wallet', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad = textWidth('nn', 14);

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Kind', ImGuiTableColumnFlags_WidthStretch, 2.0);
        imgui.TableSetupColumn('Held', ImGuiTableColumnFlags_WidthFixed, textWidth('9999999', 60) + pad);
        imgui.TableSetupColumn('Lifetime', ImGuiTableColumnFlags_WidthFixed, textWidth('9999999', 60) + pad);
        imgui.TableHeadersRow();

        for kind = 1, KIND_COUNT do
            local row = state.wallet[kind];

            imgui.TableNextRow();

            imgui.TableNextColumn();

            -- The feed's colours, so this column is the legend for the log.
            local color = kindColor(kind);

            if (color ~= nil) then
                imgui.TextColored(color[2], kindName(kind));
            else
                imgui.Text(kindName(kind));
            end

            imgui.TableNextColumn();

            if (row ~= nil) then
                imgui.Text(string.format('%d', row.amount));
            else
                imgui.TextDisabled('--');
            end

            imgui.TableNextColumn();

            if (row ~= nil) then
                imgui.TextDisabled(string.format('%d', row.lifetime));
                tip(TIPS.lifetime);
            else
                imgui.TextDisabled('--');
            end
        end

        imgui.EndTable();
    end
end

local function renderGrants()
    if (state.roster == nil) then
        renderNoRoster();

        return;
    end

    local rows = state.grants;

    if (#rows == 0) then
        imgui.TextWrapped('Nothing yet. Equip an Esper and everything it lends -- spells and job '
            .. 'abilities alike -- lands here with a button, whatever job you are on. A mastered '
            .. 'Esper lends its set forever.');

        return;
    end

    imgui.Text(string.format('%d granted:', #rows));
    tip(TIPS.grants);
    imgui.Separator();

    if (imgui.BeginTable('dwes_grants', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad = textWidth('nn', 14);

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Kind', ImGuiTableColumnFlags_WidthFixed, textWidth('Ability', 50) + pad);
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('From', ImGuiTableColumnFlags_WidthStretch, 2.0);
        imgui.TableSetupColumn('##dwes_press', ImGuiTableColumnFlags_WidthFixed, textWidth('Cast', 40) + pad * 2);
        imgui.TableHeadersRow();

        local free = state.pendingWrite == nil and not latched();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.TextDisabled(row.kind == 'spell' and 'Spell' or 'Ability');

            imgui.TableNextColumn();
            imgui.Text(row.name);

            imgui.TableNextColumn();
            imgui.TextDisabled(row.from);

            imgui.TableNextColumn();

            if (row.kind == 'spell') then
                local can = free and not state.unsupported.cast;

                actionButton(row.buttonId, can, can and TIPS.cast or TIPS.pending, function ()
                    castSpell(row.id, currentTargetIndex());
                end);
            else
                local can = free and not state.unsupported.use;

                actionButton(row.buttonId, can, can and TIPS.use or TIPS.pending, function ()
                    useAbility(row.id, currentTargetIndex());
                end);
            end
        end

        imgui.EndTable();
    end
end

--[[
* One tab. The remembered choice is written back only when the PLAYER moves,
* never when a `wantTab` from the command line takes the window somewhere for
* one frame -- and SetSelected is spent the frame it lands (the dwparse note).
--]]
local function tabItem(key, label, body)
    local flags = ImGuiTabItemFlags_None;

    if (state.wantTab == key) then
        flags = ImGuiTabItemFlags_SetSelected;
    end

    if (imgui.BeginTabItem(label, nil, flags)) then
        if (state.wantTab == key) then
            state.wantTab = nil;
        end

        if (state.wantTab == nil and state.tab ~= key) then
            state.tab = key;

            saveConfig();
        end

        body();
        imgui.EndTabItem();
    end
end

local function renderWindow()
    renderHeader();

    if (imgui.BeginTabBar('dwes_tabs')) then
        tabItem('espers', string.format('Espers %d###dwes_tab_espers',
            state.sheet ~= nil and state.sheet.owned or 0), renderEspers);
        tabItem('magicite', 'Magicite###dwes_tab_magicite', renderMagicite);
        tabItem('grants', string.format('Grants %d###dwes_tab_grants', #state.grants), renderGrants);

        imgui.EndTabBar();
    end
end

ashita.events.register('d3d_present', 'dwesper_present', function ()
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    -- THE FIRST ASK IS LAZY AND IT IS ASKED HERE, the first frame the window
    -- is actually shown in this zone -- never on the zone line, never at load.
    -- Every latch is consulted here as well as inside ask(): this test runs
    -- sixty times a second and the call it saves is not free.
    if (not state.helloSent and not latched() and not busy()) then
        state.helloSent = true;

        ask('sync');
    elseif (not latched() and not busy()) then
        if (state.roster == nil and not state.rosterAsked) then
            -- ONCE PER SESSION. The roster is static; it is asked the first
            -- time the sync has been answered and the cache is empty.
            ask('roster');
        elseif (state.polledAt == nil or (os.clock() - state.polledAt) >= POLL_INTERVAL) then
            ask('sync');
        end
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize(SZ_FIRST, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE. Nothing in ImGui stops a window being dragged to
    -- nothing, and this one carries a three-tab bar, a four-column grid and a
    -- detail pane beside it. 720x420 is the plan's floor.
    imgui.SetNextWindowSizeConstraints(SZ_MIN, SZ_MAX);

    -- The visible title is the SHORT name (1.1.1, DWHub rail round
    -- 2026-09-26, player request): a collapsed or stacked window reads as
    -- what it is. `###` pins the ImGui ID to `dwesper` alone, independent of
    -- the text; the switch from `##` reset the saved position and size once.
    local visible = imgui.Begin('Espers###dwesper', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwesper'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwesper'):append(chat.message('Window closed. Everything it shows also works typed as !esper.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwesper_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    -- THE THROTTLE IS STAMPED BY WHAT THE PLAYER SENDS, NOT ONLY BY US. The
    -- limit it exists to respect is the CLIENT's, on chat, and that counts the
    -- player's own typing.
    if (message:sub(1, 5):lower() ~= '!dwes') then
        lastSend = os.clock();
    end
end);

--[[
* A command line into words, quote-aware: `/ma "Blizzard III" <t>` is three
* words, the middle one without its quotes. Written here rather than through
* the sugar library's `:args()` so the split is one this file can be judged
* on -- the spell name is the whole of the hook's match key.
--]]
local function splitCommand(text)
    local words = { };

    text = tostring(text);

    local at  = 1;
    local len = #text;

    while (at <= len) do
        local c = text:sub(at, at);

        if (c == ' ' or c == '\t') then
            at = at + 1;
        elseif (c == '"') then
            local close = text:find('"', at + 1, true);

            if (close == nil) then
                words[#words + 1] = text:sub(at + 1);

                break;
            end

            words[#words + 1] = text:sub(at + 1, close - 1);
            at = close + 1;
        else
            local stop = text:find('[ \t]', at) or (len + 1);

            words[#words + 1] = text:sub(at, stop - 1);
            at = stop;
        end
    end

    return words;
end

--[[
* THE COMMANDS THAT PUT A CHAT LINE ON THE WIRE (2026-09-27, the Esper
* audit), stamped into the throttle the moment the command is HANDLED. The
* packet_out stamp above comes a frame or more later, when the client flushes
* its outgoing chunk -- so a macro's `/p Stun >> <t>` followed by a hooked
* `/ma "Stun" <t>` reached the hook before the `/p` line had stamped anything,
* and the two lines raced into the client's limit. A line with no slash at all
* is a /say (a `!` command included). A second stamp for the same line only
* costs the throttle a frame, which is the right direction.
--]]
local CHAT_COMMANDS = {
    ['/s']  = true, ['/say']   = true, ['/p']  = true, ['/party']     = true,
    ['/l']  = true, ['/linkshell'] = true, ['/l2'] = true, ['/linkshell2'] = true,
    ['/t']  = true, ['/tell']  = true, ['/sh'] = true, ['/shout']     = true,
    ['/y']  = true, ['/yell']  = true, ['/em'] = true, ['/emote']     = true,
    ['/u']  = true, ['/unity'] = true,
};

--[[
* THE COMMAND HOOK (T10). Two jobs in one handler: `/esper` opens the window,
* and a `/ma` or `/ja` naming a spell or ability an active Esper lends is
* rewritten into the server door -- for GRANTED names only. Everything else is
* left exactly as typed. The names are matched lowercased against the maps
* rebuildGrants filled, so the client's own spelling is the key.
--]]
ashita.events.register('command', 'dwesper_command', function (e)
    local args = splitCommand(e.command);

    -- LOWERCASED: what was typed is what arrives, and a player who
    -- capitalises is not making a mistake.
    local first = #args > 0 and args[1]:lower() or '';

    -- A chat line the client is about to send moves the throttle now (see
    -- CHAT_COMMANDS). Our own `!dwes` lines stamp themselves at send, the
    -- packet_out handler's exclusion; a line somebody blocked sends nothing.
    if (not e.blocked and first ~= '' and first:sub(1, 5) ~= '!dwes'
            and (CHAT_COMMANDS[first] or first:sub(1, 1) ~= '/')) then
        lastSend = os.clock();
    end

    if (first == '/esper' or first == '/dwesper') then
        e.blocked = true;

        -- `/esper grants` OPENS the window on that tab rather than toggling
        -- it: a player who named a tab has already said what they want.
        if (#args > 1) then
            local word = args[2]:lower();

            -- The bare command TOGGLES; `open` / `close` (1.1.1) are the
            -- idempotent doors DWHub's rail and its startup list use -- a
            -- bare toggle sent to a window the player already opened would
            -- shut it. `open` keeps whatever tab was showing.
            if (#args == 2 and word == 'open') then
                if (not state.open[1]) then
                    state.open[1]  = true;
                    state.reported = false;
                end

                return;
            end

            if (#args == 2 and word == 'close') then
                state.open[1] = false;

                return;
            end

            if (word == 'espers' or word == 'magicite' or word == 'grants') then
                state.wantTab  = word;
                state.open[1]  = true;
                state.reported = false;

                return;
            end

            print(chat.header('dwesper'):append(chat.message('/esper opens or shuts the window; /esper open | close only opens or only shuts it; /esper magicite or /esper grants opens it on that tab.')));

            return;
        end

        state.open[1] = not state.open[1];

        if (state.open[1]) then
            state.reported = false;
        end

        return;
    end

    if (not state.intercept[1]) then
        return;
    end

    if (first ~= '/ma' and first ~= '/ja') then
        return;
    end

    local name = args[2];

    if (type(name) ~= 'string' or name == '') then
        return;
    end

    local id;

    if (first == '/ma') then
        id = state.grantSpellByName[name:lower()];
    else
        id = state.grantAbilityByName[name:lower()];
    end

    -- Not granted: the client's own business, untouched.
    if (id == nil) then
        return;
    end

    -- Granted, but the current jobs cast it anyway: the client's too
    -- (castsNatively, 2026-09-27).
    if (first == '/ma' and castsNatively(id)) then
        return;
    end

    -- A target word this file cannot place is the client's (resolveTargetWord)
    -- -- and since the client will refuse a spell its jobs cannot cast, the
    -- player is told which words an Esper cast does take.
    local targetIndex = resolveTargetWord(args[3]);

    if (targetIndex == nil) then
        state.status    = string.format('%s went to the client as typed: an Esper cast takes <t>, <me>, <bt>, <p0>-<p5>, <a10>-<a25> or <pet>, in this zone.', tostring(args[3]));
        state.statusBad = true;

        tellShut(state.status);

        return;
    end

    local sent, why;

    if (first == '/ma') then
        sent, why = castSpell(id, targetIndex);
    else
        sent, why = useAbility(id, targetIndex);
    end

    --[[
    * BLOCKED ONLY WHEN THE DOOR HAS IT, or when it is busy with the last one
    * (2026-09-27; harness B7 pins the busy half: blocked, NOT sent, said). A
    * busy press handed to the client would get its "cannot cast" for a spell
    * this character can cast, so it is refused here and said -- in the status
    * line, and in chat once when the window is shut. A door that is SHUT (a
    * refused protocol, an unknown-verb latch) or a zoning client used to eat
    * the line too, with nothing said; those are the client's own business
    * now, as they are with the addon off, and its answer is at least one.
    --]]
    if (sent) then
        e.blocked = true;
    elseif (why == 'busy') then
        e.blocked = true;

        tellShut(state.status);
    end
end);

--[[
* THE MAGICITE FEED (1.1.0, owner 2026-09-24): "chat notifications for when
* the player gains Magicite ... colour coded to the element/job ... in
* Window #2", ON by default, a switch in the header.
*
* The server says, once per paid kill and per boss credit (esper_core.lua,
* tellMagicite -- THE SHAPE IS A CONTRACT, and harness_dwesper.py feeds the
* core's real output through this handler):
*
*   [Esper] Magicite: +5 Earth (1234), +5 WAR (567), +5 THF (89).
*
* on SYSTEM_3, which reaches text_in as mode 121. THIS DOES NOT print(): it
* is dwquest's kill feed lever, live and on by default since 2026-08-30. The
* client files a line between its two logs by CATEGORY, and on the stock Log
* config Window 2 is the chat group, so the line is re-moded IN PLACE to 222
* (Assist E, a chat-group channel nothing on this server speaks on; the
* packed extension bits above the low byte are kept) and re-written as its
* own words, less the tag, with each `+N Kind (Total)` entry wrapped in that
* kind's colour. An entry that does not parse keeps the game's colour -- a
* drifted server line still moves, it just is not tinted. Switch off and the
* line is BLOCKED: the player asked not to see it.
*
* THE GATES, in order: a line somebody already blocked or an addon injected
* is not ours; the mode must be exactly 121 (a player can type the tag, not
* the mode); the cleaned line must OPEN with the tag and the Magicite
* prefix. The other `[Esper] ` sentences -- attunement, mastery, Cores --
* stay exactly where and how the server put them.
--]]
local NOTICE_TAG      = '[Esper] ';
local NOTICE_MODE     = 121;
local FEED_MODE       = 222;
local MAGICITE_PREFIX = 'Magicite: ';
local MAGICITE_ENTRY  = '^%+(%d+) (%a+) %((%d+)%)$';

-- The server's kind words (esper_core.lua E.ELEMENT_NAMES / E.JOB_NAMES) ->
-- kind. JOB_ABBR, NOT the client's string table: these are the server's
-- words, and a client that spells a job differently must still match.
local KIND_BY_WORD = { };

for kind, word in ipairs(ELEMENT_NAMES) do
    KIND_BY_WORD[word] = kind;
end

for job, word in ipairs(JOB_ABBR) do
    KIND_BY_WORD[word] = ELEMENT_COUNT + job;
end

-- The printable text of a text_in line: the client's two-byte tag pairs out
-- first, then anything undrawable, then a leading clock the timestamp addon
-- may have stamped (dwspoils' plainText).
local function plainText(raw)
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    text = text:gsub('[^\032-\126]', '');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return text;
end

-- `Magicite: +5 Earth (1234), +5 WAR (567).` with every entry that parses
-- in its kind's colour.
local function tintMagicite(said)
    local body   = said:sub(#MAGICITE_PREFIX + 1):gsub('%.$', '');
    local pieces = { };

    for entry in (body .. ', '):gmatch('(.-), ') do
        local _, word = entry:match(MAGICITE_ENTRY);
        local kind    = word ~= nil and KIND_BY_WORD[word] or nil;
        local color   = kind ~= nil and kindColor(kind) or nil;

        pieces[#pieces + 1] = color ~= nil and chat.color1(color[1], entry) or entry;
    end

    return MAGICITE_PREFIX .. table.concat(pieces, ', ') .. '.';
end

ashita.events.register('text_in', 'dwesper_text_in', function (e)
    if (e.blocked or e.injected) then
        return;
    end

    local raw = e.message_modified or e.message;

    if (raw == nil) then
        return;
    end

    -- THE MODE GATE FIRST. A missing mode refuses too: the live client always
    -- supplies one, so its absence is not a server line.
    local mode = e.mode_modified or e.mode;
    local low  = mode ~= nil and bit.band(mode, 0xFF) or nil;

    if (low ~= NOTICE_MODE) then
        return;
    end

    local line = (plainText(raw):gsub('^%s+', ''):gsub('%s+$', ''));

    if (line:find(NOTICE_TAG .. MAGICITE_PREFIX, 1, true) ~= 1) then
        return;
    end

    if (not state.notify[1]) then
        e.blocked = true;

        return;
    end

    -- KEEP A LEADING CLOCK SOMEBODY ELSE PUT THERE (dwquest's feed): this
    -- rewrites rather than re-prints, so nothing would put it back.
    local stamp = raw:match('^(\30.%[%d%d?:%d%d:%d%d%]\30.%s*)')
               or raw:match('^(%[%d%d?:%d%d:%d%d%]%s*)')
               or '';

    e.mode_modified    = bit.bor(bit.band(mode, 0xFFFFFF00), FEED_MODE);
    e.message_modified = stamp .. tintMagicite(line:sub(#NOTICE_TAG + 1));
end);

ashita.events.register('load', 'dwesper_load', function ()
    print(chat.header('dwesper'):append(chat.message('/esper opens the Espers window: your Magicite, the Espers you can make, and the spells they lend you. Everything it shows also works typed as !esper.')));
end);
