--[[
* DriftwoodXI -- dwfame
*
* The fame ledger: every fame area in the game as a progress bar -- level,
* points, and how far the next level is -- plus a Guide tab that says the
* fastest repeatable way to raise each one, verified against this server's
* own quest scripts. Retail makes you walk to a different NPC per city and
* paraphrases the answer; this window is the whole answer at once.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It evaluates no fame arithmetic and holds no opinion about your progress.
* The server reads your real state -- the same getFame/getFameLevel the
* quest scripts themselves branch on -- and answers `!dwf sync` in compact
* records under the sender name _DWFDATA, which this addon parses and
* blocks before the chat log sees them. Every bar's floor and ceiling ride
* the wire beside the points, so not even the level thresholds live here.
* If the server does not assert something, this window does not show it.
*
* THE ONE THING IT REMEMBERS is the last sync's own readings -- the level and
* the points each area held -- keyed to the character id the server stamps on
* every response. That is what lets it say a level was crossed ("San d'Oria
* fame reached level 5!") in chat, and what a bar's hover means by "up 13
* points since the sync before this one". Both are comparisons of two things
* the server said, both are silent until this addon has watched two syncs of
* the SAME character, and an alt's ledger can never inherit either.
*
* THE GUIDE IS AUTHORED DATA (data/guide.lua), not server state: NPC names,
* towns, items, counts and per-trade amounts read out of scripts/quests/*.
* Amounts are base points; the window states the server's live fame rate
* beside them, from the sync's own r| record.
*
* Authored-at-the-time was not good enough: the first cut sent players to
* the wrong half of San d'Oria for four days with every harness check green,
* because prose cannot be checked and so nothing checked it. Each guide line
* now carries the quest file, NPC key, zone and fame amount it was read
* from, and tools/dwfame/check_guide.py refuses to agree unless the scripts
* still say so AND the sentence still names the same NPC and town. The
* deploy gates on that verdict (PROD_LINUX.md 10.9).
*
* SINCE 1.1.0 THE GUIDE ANSWERS "WHY SHOULD I BELIEVE THAT". Hovering a
* sentence the checker backs opens the row it was read from -- the quest
* script, the NPC and town, the fame it pays and which bar that lands on --
* and a find box over the tab filters all sixteen areas by any of those. A
* sentence nothing backs deliberately shows no card; the eight Abyssea areas
* nothing raises say how "nothing raises this" is itself checked. Clicking an
* area's name on the Fame tab opens it here.
*
* WHAT THE WINDOW REMEMBERS ABOUT YOU, and it is only presentation: which
* lens the bars are under and which tab was open, per character, through
* Ashita's settings library. Not fame, not a level, nothing the server said.
* A second opinion about your standing is the one thing this addon must never
* keep.
*
* TURN IT OFF AND NOTHING IS LOST. `!fame` typed in chat prints the same
* numbers in prose, and `!dwf sync` shows exactly what this window is told.
* And if the window itself ever fails to draw, it stops intercepting `!fame`
* so that prose tier answers instead -- the fallback the closing message
* names has to be a fallback that works.
--]]

addon.name    = 'dwfame';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.0';
addon.desc    = 'Fame ledger for DriftwoodXI: every fame area as a bar, with a guide.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server
-- uses it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWFDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

--[[
* The area catalogue: id and grouping only -- display order, names, and
* which section of the Fame tab each row lives in. Numbers all come from
* the wire. `key` matches fame_core.lua's AREAS table and data/guide.lua's
* entries; `note` is the one sentence a derived area needs so its bar does
* not look like something quests in that town would raise.
*
* `enum` is the name scripts/enum/fame_area.lua gives the same id, and it is
* here for one job: data/guide.lua's provenance rows name the fame area they
* pay in that spelling, and the hover card says which bar a cross-paying
* quest actually moves. The pairing is asserted against the real enum file by
* tools/dwfame/harness_dwfame.py rather than trusted (2026-09-06).
--]]
local AREAS =
{
    { id =  0, key = 'sandoria',   name = "San d'Oria",           group = 'Cities',   enum = 'SANDORIA' },
    { id =  1, key = 'bastok',     name = 'Bastok',               group = 'Cities',   enum = 'BASTOK' },
    { id =  2, key = 'windurst',   name = 'Windurst',             group = 'Cities',   enum = 'WINDURST' },
    { id =  3, key = 'jeuno',      name = 'Jeuno',                group = 'Cities',   enum = 'JEUNO',
      note = 'No quest here raises it: the average of the three nations.' },
    { id =  4, key = 'selbina',    name = 'Selbina / Rabao',      group = 'Outlands', enum = 'SELBINA_RABAO',
      note = 'No counter of its own: the average of San d\'Oria and Bastok.' },
    { id =  5, key = 'norg',       name = 'Norg',                 group = 'Outlands', enum = 'NORG' },
    { id =  6, key = 'konschtat',  name = 'Konschtat',            group = 'Abyssea',  enum = 'ABYSSEA_KONSCHTAT' },
    { id =  7, key = 'tahrongi',   name = 'Tahrongi',             group = 'Abyssea',  enum = 'ABYSSEA_TAHRONGI' },
    { id =  8, key = 'latheine',   name = 'La Theine',            group = 'Abyssea',  enum = 'ABYSSEA_LATHEINE' },
    { id =  9, key = 'misareaux',  name = 'Misareaux',            group = 'Abyssea',  enum = 'ABYSSEA_MISAREAUX' },
    { id = 10, key = 'vunkerl',    name = 'Vunkerl',              group = 'Abyssea',  enum = 'ABYSSEA_VUNKERL' },
    { id = 11, key = 'attohwa',    name = 'Attohwa',              group = 'Abyssea',  enum = 'ABYSSEA_ATTOHWA' },
    { id = 12, key = 'altepa',     name = 'Altepa',               group = 'Abyssea',  enum = 'ABYSSEA_ALTEPA' },
    { id = 13, key = 'grauberg',   name = 'Grauberg',             group = 'Abyssea',  enum = 'ABYSSEA_GRAUBERG' },
    { id = 14, key = 'uleguerand', name = 'Uleguerand',           group = 'Abyssea',  enum = 'ABYSSEA_ULEGUERAND' },
    { id = 15, key = 'adoulin',    name = 'Adoulin',              group = 'Adoulin',  enum = 'ADOULIN' },
};

local GROUP_ORDER = { 'Cities', 'Outlands', 'Abyssea', 'Adoulin' };

--[[
* One sentence under a group headline, for the case a per-area note would
* have to be repeated down the whole group to be honest. Abyssea is the only
* one that needs it: eight of its nine bars have no fame source implemented
* on this server, so a column of bars frozen at level 1 would otherwise read
* as "you have not done those yet" rather than "nothing does those yet".
* Which eight is the Guide tab's business (data/guide.lua says it per area,
* and tools/dwfame/check_guide.py fails the day that stops being true).
--]]
local GROUP_NOTES =
{
    Abyssea = 'Only La Theine has a fame source on this server today -- see the Guide tab.',
};

local areaById   = {};
local areaByEnum = {};
local rowLabel   = {};

for _, area in ipairs(AREAS) do
    areaById[area.id]     = area;
    areaByEnum[area.enum] = area;

    -- The name as the Fame tab's clickable row draws it: the label a player
    -- reads, and an id ImGui can tell from every other row's.
    rowLabel[area.id] = string.format('%s##dwfame_row_%d', area.name, area.id);
end

--[[
* The guide, loaded once from this addon's own data folder. io.read +
* loadstring rather than require so a file that is missing or refuses to
* parse costs only the Guide tab -- the bars must never die over prose.
--]]
local DATA_DIR = string.format('%s\\addons\\dwfame\\data\\',
    AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

local guide = nil;

--[[
* The provenance behind each guide sentence, indexed the way the window asks
* for it: [areaKey][lineIndex] = { source row, ... }, and the same for the
* claims that are true by absence.
*
* data/guide.lua's own header called `sources` un-rendered, and that was the
* honest description of it until this build: it existed so
* tools/dwfame/check_guide.py could refuse a sentence the quest scripts no
* longer back. Showing it on hover changes nothing about who checks what --
* the rows are still authored beside the prose and still gate the deploy --
* and it puts the reason a player should believe the line where the line is,
* instead of in a checker they will never run (2026-09-06).
--]]
local guideFacts   = { };
local guideAbsence = { };

local function indexProvenance(rows, into, textField)
    if (type(rows) ~= 'table') then
        return;
    end

    for _, row in ipairs(rows) do
        if (type(row) == 'table' and type(row.area) == 'string' and type(row.line) == 'number') then
            local perArea = into[row.area];

            if (perArea == nil) then
                perArea = { };

                into[row.area] = perArea;
            end

            local perLine = perArea[row.line];

            if (perLine == nil) then
                perLine = { };

                perArea[row.line] = perLine;
            end

            perLine[#perLine + 1] = textField ~= nil and row[textField] or row;
        end
    end
end

local function loadGuide()
    local file = io.open(DATA_DIR .. 'guide.lua', 'rb');

    if (file == nil) then
        return;
    end

    local raw = file:read('*a');
    file:close();

    local chunk = loadstring(string.gsub(raw, '\r', ''), '@dwfame/data/guide.lua');

    if (chunk == nil) then
        return;
    end

    local ok, data = pcall(chunk);

    if (ok and type(data) == 'table' and type(data.entries) == 'table') then
        guide = data.entries;

        -- Provenance is optional: an older data file that predates the
        -- sources table still renders every sentence, just without the card.
        pcall(indexProvenance, data.sources, guideFacts, nil);
        pcall(indexProvenance, data.absences, guideAbsence, 'fameArea');
    end
end

loadGuide();

if (guide == nil) then
    print(chat.header('dwfame'):append(chat.error('data/guide.lua missing or unreadable -- the Guide tab will be empty.')));
end

--[[
* Remembered presentation, per character, through Ashita's settings library
* (1.1.0). Two answers a player gives the window once and had to give it again
* on every load: which lens the bars are under, and which tab was open. NOT
* fame, and nothing the server said -- this file must never become a second
* opinion about your standing. Guarded end to end: a missing or unreadable
* settings file selects the defaults and costs nothing else.
--]]
local defaultConfig = T{
    sortByNext = false,
    tab        = 'Fame',
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

local function rememberSetting(key, value)
    if (config[key] == value) then
        return;
    end

    config[key] = value;

    pcall(settings.save);
end

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a completed response, never
    -- merged, so a stale row cannot survive a refresh (dwtracker's rule).
    charid    = nil,
    rate      = nil,          -- fame multiplier, integer percent
    areas     = T{ },         -- [id] = { fame, level, base, next }

    -- The one deliberate survivor: last sync's levels AND points, for the
    -- level-up line and the "up 13 since the last sync" the bars carry.
    -- Keyed by the c| charid, wiped the moment a different character
    -- answers, and never populated from anything but a completed sync.
    prevLevels = { },
    prevPoints = { },
    prevChar   = nil,

    -- [id] = points gained between the last two completed syncs, when that
    -- is a number this addon actually watched happen. Never a guess: an area
    -- with no previous reading for THIS character is simply absent here.
    gained     = { },

    -- A level-up celebrated in the window as well as in chat, briefly.
    toast     = nil,
    toastAt   = nil,

    -- The "what is closest" lens, seeded from the remembered answer.
    sortByNext = T{ config.sortByNext == true },

    -- The find box over the Guide tab (1.1.0). Deliberately NOT remembered:
    -- a filter you cannot see the cause of is the worst thing a window can
    -- do to you on the next login.
    find       = T{ '' },

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its
    -- own cannot half-fill the UI.
    inbound   = nil,
    status    = 'Waiting for the first sync.',

    -- 'ok', 'warn' or 'err'. THREE and not two: the ledger being paused
    -- because the server stopped answering is neither fine nor an error, and
    -- painting it in the same green as "Synced." was the window saying
    -- everything was in order over numbers that had stopped moving
    -- (2026-09-06).
    statusTone = 'ok',
    reported  = false,        -- a render error is worth saying once, not per frame

    -- A zone-in sync is deferred a few seconds: 0x000A arrives while the
    -- client is still on the load screen, and a chat line sent there is a
    -- chat line lost.
    syncAt    = nil,
    syncSlot  = nil,

    -- os.clock() the ledger on screen was committed, so the window can say
    -- how old the numbers it is drawing are. nil until the first sync lands.
    syncedAt  = nil,
};

--[[
* Ashita hands the settings library's table back on a character switch, and
* the two things this window remembers are bound to tables of its OWN -- so
* they have to be told as well, or the previous character's lens stays on
* screen and the very next frame writes it into the new character's settings
* file. The tab is applied by the render (requestTab lives with the tab bar);
* this only raises the flag. Registered here rather than beside settings.load
* because it has to be able to see `state` (1.1.0).
--]]
local adoptConfig = false;

pcall(settings.register, 'settings', 'dwfame_settings_update', function (s)
    if (s ~= nil) then
        config      = s;
        adoptConfig = true;

        state.sortByNext[1] = config.sortByNext == true;
    end
end);

--[[
* The envelope under construction.
*
* Records between `d|` and `z|` are a DRAFT and land here; `z|` swaps the
* finished draft into `state` in one assignment. The section used to be wiped
* at `d|` and refilled record by record, which is dwbags' rule applied to a
* reader that receives its records ONE PACKET AT A TIME: sixteen `f|` lines
* are sixteen separate 0x017 packets, nothing promises they arrive in the same
* frame, and every frame in between drew whatever had turned up so far -- an
* empty table right after the `d|` (the Fame tab's "No fame data yet", and the
* sort checkbox vanishing under the mouse), then a growing partial ledger.
* Worse, an envelope that never closed -- an `e|` raised mid-answer, a map
* restart between records -- left that partial ledger on screen looking exactly
* like a complete one. A draft that never completes is simply discarded, and
* the last ledger the server finished saying stays up (2026-09-06).
--]]
local draft = nil;

--[[
* Bumped on every write to the model above. The render caches its derived
* strings against it, so the sixteen overlays and the sort order are built
* once per sync rather than once per frame.
--]]
local modelRev = 0;

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. The client rate-limits outgoing chat and a !dwf command is a chat
* line; everything queues here and drains at one command per interval, with
* duplicates collapsed (dwbags' lesson, kept verbatim).
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking: a command can be lost on the way out, so an unanswered
* request is asked once more and then left alone. A PLAIN TABLE, NOT T{ }:
* keyed by verb names, and sugar-table method names shadowing a key cost
* dwbags a round once already.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

--[[
* True once this server has shown it does not speak dwfame -- either its own
* refusal arrived ("The fame ledger is not loaded.") or a request went
* unanswered twice. An unknown !command on this server falls through to
* ordinary /say chat, so every auto-sync against a dead verb is the player
* PUBLICLY SAYING "!dwf sync". While set, zone-in auto-syncs stop. Cleared
* by anything that proves the server speaks (a d| envelope, a p| ping) and
* by the player acting on purpose (window open, refresh).
--]]
local serverSilent = false;

--[[
* True once the render pcall has thrown and closed the window. It exists for
* one reason: while it is set, `!fame` typed in chat is left alone so the
* server's prose tier can answer it -- the fallback the closing message names.
* Cleared the moment the player opens the window on purpose.
--]]
local renderBroken = false;

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

local function ask(verb)
    requested[verb] = { at = os.clock(), answered = false, tries = 1 };

    issue('!dwf ' .. verb);
end

-- Re-ask an unanswered verb once; give up loudly after that. Called every
-- frame, window open or not.
local function checkAnswers()
    -- A held send (zone-in) leaves the line queued; aging the answer clock
    -- against it would be a false timeout, and after ANSWER_TRIES a false
    -- "No answer from the server." (dwecho canSend; 2026-08-15.)
    --
    -- RE-STAMPED, not merely skipped (2026-09-06, the dwarena 1.1.0 finding):
    -- os.clock() runs through the load screen whether or not the test below
    -- does, so a bare return here meant the instant zoning ended the elapsed
    -- time was the whole load screen -- the retry fired at once, collapsed
    -- into the line still waiting in the queue, and the ask had spent its one
    -- retry before the server had been asked even once: two lost lines
    -- later the silent latch closed against a server that never heard us.
    if (not echo.canSend()) then
        for _, asked in pairs(requested) do
            if (not asked.answered) then
                asked.at = os.clock();
            end
        end

        return;
    end

    for verb, asked in pairs(requested) do
        if (not asked.answered and (os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue('!dwf ' .. verb);
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;
                serverSilent = true;

                state.status     = 'No answer from the server. Is DriftwoodXI up to date?';
                state.statusTone = 'err';
            end
        end
    end
end

local function requestSync()
    ask('sync');
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* One wire field as a whole number, or the fallback.
*
* `tonumber` takes '2.5', 'nan' and '1e400' exactly as readily as '250', and
* every number on this wire is a count of fame points -- an integer by
* construction on the server (fame_core.lua formats each one with %i). A field
* that is not one is a field this addon has misread or a server it does not
* understand, and either way the honest answer is the fallback rather than a
* bar drawn from it: LuaJIT prints a NaN through %d as -9223372036854775808,
* and a NaN compares false against every threshold, so the level-up line for
* that area could never fire again. Range-checked as well as integrality-
* checked, because inf is a number, floors to itself, and prints the same
* garbage (2026-09-06).
--]]
local WIRE_LIMIT = 2147483647;

local function wireInt(text, fallback)
    local n = tonumber(text);

    if (n == nil or n ~= n or n > WIRE_LIMIT or n < -WIRE_LIMIT) then
        return fallback;
    end

    return math.floor(n);
end

-- Plain little-endian byte reads; offsets are packet offsets (0-based), the
-- +1 is Lua's string indexing (dwcraft's helpers, kept verbatim).
local function u8(data, off)
    return string.byte(data, off + 1) or 0;
end

local function u16(data, off)
    return (string.byte(data, off + 1) or 0) + (string.byte(data, off + 2) or 0) * 256;
end

local function u32(data, off)
    return u16(data, off) + u16(data, off + 2) * 65536;
end

--[[
* A completed sync is the only moment the level-up comparison runs: the new
* levels against prevLevels, both full snapshots, both this character's.
* The first sync a character ever answers seeds the table silently --
* "reached level 3" with nothing to compare against would be a guess, and
* this addon does not guess.
--]]
local function celebrateLevelUps()
    if (state.charid == nil) then
        return;
    end

    if (state.prevChar ~= state.charid) then
        state.prevChar   = state.charid;
        state.prevLevels = { };
        state.prevPoints = { };
    end

    local seeded = next(state.prevLevels) ~= nil;

    state.gained = { };

    for id, row in pairs(state.areas) do
        local area = areaById[id];
        local prev = state.prevLevels[id];

        if (seeded and area ~= nil and prev ~= nil and row.level > prev) then
            local line = string.format('%s fame reached level %d!', area.name, row.level);

            print(chat.header('dwfame'):append(chat.message(line)));

            state.toast   = line;
            state.toastAt = os.clock();
        end

        -- The points half of the same comparison, and it says nothing at all
        -- unless this addon watched both readings on this character: a
        -- difference against a number from somebody else's ledger, or from
        -- before a reload, would be a guess wearing a plus sign (1.1.0).
        local before = state.prevPoints[id];

        if (seeded and before ~= nil and row.fame > before) then
            state.gained[id] = row.fame - before;
        end

        state.prevLevels[id] = row.level;
        state.prevPoints[id] = row.fame;
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        -- An envelope is the server speaking dwfame, whatever it carries.
        serverSilent = false;

        -- Through the same guard as every other number on this wire: a `d|`
        -- announcing "2.5" used to reach %d as a fraction, which prints a
        -- truncation on the player's LuaJIT and raises outright on any newer
        -- Lua -- inside the packet handler, where the throw is swallowed and
        -- the envelope is simply lost (found by the harness's record fuzz,
        -- 2026-09-06). 0 stands for "did not say".
        local version = wireInt(parts[2], 0);

        if (version ~= PROTOCOL) then
            state.status     = string.format('Server protocol %d, addon expects %d. Update dwfame.', version, PROTOCOL);
            state.statusTone = 'err';
            state.inbound    = nil;
            draft            = nil;

            -- A d| envelope IS the answer, whatever version it announced.
            -- This return used to leave the request unanswered, so five
            -- seconds later checkAnswers re-sent it and then replaced the one
            -- accurate diagnosis on screen ("Update dwfame") with the one that
            -- is definitely wrong ("No answer from the server") -- about a
            -- server that had just answered twice. Same hazard the `status`
            -- branch below already documents and closes.
            --
            -- Every pending entry, not parts[3]: a record whose version this
            -- addon cannot parse is exactly the record whose field 3 cannot be
            -- assumed to still be the verb.
            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            return;
        end

        state.inbound = parts[3];

        -- A response is drafted whole and committed at its `z|`; the ledger
        -- on screen is the last COMPLETE one until then. prevLevels
        -- deliberately survives the swap: it is the comparison, and the
        -- draft's own c| re-keys it if the character changed.
        if (state.inbound == 'sync') then
            draft = { charid = nil, rate = nil, areas = T{ } };
        else
            draft = nil;
        end

        answered(state.inbound);

        -- A refusal raised before a verb opened its own envelope arrives
        -- wrapped in `d|1|status` (dwf.lua's shape). That IS the answer to
        -- whatever was asked: left unanswered, checkAnswers re-sends the
        -- verb in five seconds and then replaces the server's precise
        -- sentence ("The fame ledger is not loaded.") with a "no answer"
        -- diagnosis that is simply untrue.
        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- sentence saying why something was refused is worth more than the
    -- response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status     = line:sub(3);
        state.statusTone = kind == 'e' and 'err' or 'ok';

        if (kind == 'e') then
            print(chat.header('dwfame'):append(chat.error(state.status)));

            -- An error raised AFTER the envelope opened arrives bare, with no
            -- `z|` behind it (squad_storage.lua's `wrapped` writes the record
            -- straight out when `opened` is set), so nothing else would ever
            -- close this envelope: the draft would keep accepting records
            -- from whatever answer arrived next, outside any envelope of its
            -- own. The refusal IS the end of this answer -- say why, throw the
            -- half-written draft away, and leave the last complete ledger on
            -- screen (2026-09-06).
            state.inbound = nil;
            draft         = nil;

            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            -- The command exists but fame_core.lua is not loaded (dwf.lua's
            -- own refusal). Asking again cannot help until a map restart --
            -- detect once and go quiet.
            if (string.find(line, 'The fame ledger is not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end
        end

        return;
    end

    -- The dirty ping, honoured from day one so deployment order between
    -- addon and server cannot matter: one record, outside any envelope,
    -- answered with a fresh sync.
    if (kind == 'p') then
        serverSilent = false;
        ask('sync');

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'sync' and draft ~= nil) then
            -- The one moment the ledger changes: three assignments, no
            -- frame in between, and the level-up comparison runs against a
            -- ledger that is whole.
            state.charid   = draft.charid;
            state.rate     = draft.rate;
            state.areas    = draft.areas;
            state.syncedAt = os.clock();

            modelRev = modelRev + 1;

            celebrateLevelUps();

            -- "Synced." over "No fame data yet." is a window contradicting
            -- itself. An envelope that closed without a single `f|` is a
            -- complete answer that happens to say nothing, and the status is
            -- the only place that can tell a player which of the two they are
            -- looking at (2026-09-06).
            if (next(state.areas) ~= nil) then
                state.status     = 'Synced.';
                state.statusTone = 'ok';
            else
                state.status     = 'The server answered without a single area. Refresh, or ask a GM.';
                state.statusTone = 'warn';
            end
        end

        draft = nil;

        return;
    end

    if (draft == nil) then
        return;
    end

    if (kind == 'c') then
        draft.charid = wireInt(parts[2], nil);

        return;
    end

    if (kind == 'r') then
        draft.rate = wireInt(parts[2], nil);

        return;
    end

    if (kind == 'f') then
        local id = wireInt(parts[2], nil);

        if (id ~= nil and areaById[id] ~= nil) then
            draft.areas[id] = T{
                fame  = wireInt(parts[3], 0),
                level = wireInt(parts[4], 1),
                base  = wireInt(parts[5], 0),
                next  = wireInt(parts[6], 0),
            };
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWFDATA is
* ours: consumed here and blocked so the chat log never sees it -- before
* parsing, so a malformed record cannot leak as noise.
--]]
ashita.events.register('packet_in', 'dwfame_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    -- Every line anybody says in the zone comes through here, and cutting the
    -- sender field out of each one to compare it was two string allocations
    -- per chat line in a crowded city. Every Driftwood data sender starts with
    -- an underscore and no character name can, so one byte answers "not ours"
    -- for every real sentence before any of that happens (2026-09-06).
    if (e.data_modified:byte(0x09) ~= 0x5F) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwfame'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

local TOAST_SECONDS = 8.0;

--[[
* An ImGui metric with a fallback, so a measurement this addon asks for can
* never be the thing that takes a frame down (dwcpx's helper, kept verbatim).
* The fallbacks are the stock font's numbers.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

--[[
* CalcTextSize memoised (dwah's idiom). The area column used to be a hard 140
* pixels, which is a guess about a font this addon does not own: the widest
* name it has to hold is "Selbina / Rabao", and a player running a larger
* ImGui font had it clipped with no way to widen it. Measured instead, once
* per string -- the font is fixed for the life of the window.
--]]
local widths = {};

local function textWidth(text)
    local key    = tostring(text);
    local cached = widths[key];

    if (cached == nil) then
        cached = (imgui.CalcTextSize(key));

        if (type(cached) ~= 'number' or cached <= 0) then
            cached = #key * 7;
        end

        widths[key] = cached;
    end

    return cached;
end

--[[
* The fixed tooltips, as data. One short sentence each, in the window's own
* voice, saying what a control does -- and for anything the window refuses,
* why it cannot right now. Kept in a table so the harness can assert both
* that every control has one and that the sentences still say what the code
* does (the house shape; dwah's TIPS).
--]]
local TIPS =
{
    refresh    = 'Ask the server for your fame again. Every zone line does this on its own, unless the server has stopped answering -- then this button is what tries again.',
    sort       = 'One list, the area nearest its next level first, instead of the nation groups. Areas at their cap sink to the bottom.',
    rate       = 'This server multiplies fame, so a quest paying 10 base points does not move the bar by exactly 10. The Guide tab quotes the base points.',
    queued     = 'Commands wait their turn: the client rate-limits outgoing chat, and a !dwf line is a chat line. This clears itself.',
    summary    = 'Counted from the bars below -- the server named every level and every threshold in them.',
    syncAge    = 'How old the ledger below is. The server is asked again on every zone line, and by the Refresh button.',
    toast      = 'A level crossed since the last sync. It says the same thing in chat, and clears itself after a few seconds.',
    find       = 'Filters the guide by area, NPC, item or town. Matching an area name keeps all of its lines.',
    findClear  = 'Empty the find box and show every area again.',
    tabFame    = 'Your standing in all sixteen fame areas, as the server computes it.',
    tabGuide   = 'The fastest repeatable way to raise each area, read out of this server\'s own quest scripts.',
    guideRate  = 'Amounts below are base points, before the server\'s multiplier -- which is what the quest scripts award and therefore the only number that cannot go stale.',
    absence    = 'Checked by a search that has to come back empty: the day a quest script starts awarding this fame, the deploy fails instead of this line going quietly wrong.',
    provenance = 'The quest script this line was read out of. tools/dwfame/check_guide.py re-reads it at every deploy and refuses to agree unless it still says this.',
};

local GROUP_TIPS =
{
    Cities   = 'The three nations and Jeuno -- the fame every city quest moves.',
    Outlands = 'Standing outside the nations: Selbina and Rabao (an average of two of them) and Norg.',
    Abyssea  = 'Abyssea standing, tracked per zone and capped at level 6.',
    Adoulin  = 'Western Adoulin, whose quests pay 30 fame apiece unless the script says otherwise.',
};

-- The house tooltip shape: `IsItemHovered` reads the item just drawn, and one
-- short sentence is the whole tooltip (BeginTooltip cards are for provenance).
local function tip(key)
    local text = TIPS[key];

    if (text ~= nil and imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* The view cache.
*
* Every string the Fame tab draws is derived from a ledger that changes once
* per sync and a lens that changes on a click, and all of it used to be
* rebuilt sixty times a second: sixteen `string.format` overlays, sixteen
* tooltip sentences, a table allocated and sorted for the closest-next lens,
* and a `##dwfame_<group>` concatenation per group. Built once per model
* revision instead, and thrown away by the same `modelRev` bump that replaces
* the ledger (2026-09-06).
--]]
local view =
{
    rev     = -1,
    sort    = nil,
    rows    = T{ },     -- the closest-next lens, ordered
    groups  = { },      -- [groupName] = T{ area, ... } with data, catalogue order
    bars    = { },      -- [id] = { fraction, overlay, tip }
    labels  = { },      -- [id] = the Guide tab's tree label
    summary = nil,
    nameW   = 140,

    -- The Guide tab's opening sentence: it quotes the server's fame rate,
    -- which arrives with the ledger.
    guideIntro = 'Fame amounts below are base points, straight from this server\'s quest scripts.',
};

-- Table ids, built once rather than concatenated per group per frame.
local GROUP_TABLE_ID = {};

for _, groupName in ipairs(GROUP_ORDER) do
    GROUP_TABLE_ID[groupName] = '##dwfame_' .. groupName;
end

--[[
* What the bar's tooltip is allowed to promise about the Guide tab, per area
* -- and it is not the same promise for all sixteen. Eight Abyssea bars have
* no fame source implemented on this server and the Guide says exactly that;
* Jeuno and Selbina/Rabao have no counter of their own at all. Pointing all
* three cases at "the fastest repeatable quest for this area" was the tooltip
* telling a player to go and find something that is not there (2026-09-06).
* Which case an area is in comes from the checked data file, never from a
* list kept here.
--]]
--[[
* "Up 13 since the last sync", for the one area a player is actually working
* on. Silent unless this addon watched both readings on this character: the
* comparison is the only thing in this window that is not the server talking,
* so it says nothing it did not see happen (1.1.0).
--]]
local function sinceLastSync(id)
    local gained = state.gained[id];

    if (gained == nil or gained <= 0) then
        return '';
    end

    return string.format('\nUp %d points since the sync before this one.', gained);
end

local function guidePromise(area)
    if (area.note ~= nil) then
        return '\nA derived bar: the Guide tab says which fames it follows.';
    end

    if (guideAbsence[area.key] ~= nil) then
        return '\nNo quest on this server raises this fame yet -- the Guide tab says so.';
    end

    if (guide ~= nil and guide[area.key] ~= nil) then
        return '\nThe Guide tab names the fastest repeatable quest for this area.';
    end

    return '';
end

local function rebuildView()
    local sort = state.sortByNext[1] == true;

    view.rev  = modelRev;
    view.sort = sort;

    view.rows    = T{ };
    view.groups  = { };
    view.bars    = { };
    view.labels  = { };
    view.summary = nil;

    for _, groupName in ipairs(GROUP_ORDER) do
        view.groups[groupName] = T{ };
    end

    local counted, capped, bestArea, bestGap, bestLevel = 0, 0, nil, nil, nil;

    for _, area in ipairs(AREAS) do
        local row = state.areas[area.id];

        if (row ~= nil) then
            counted = counted + 1;

            view.rows:append(area);
            view.groups[area.group]:append(area);

            local bar = { };

            if (row.next <= row.base) then
                bar.fraction  = 1.0;
                bar.remaining = math.huge;
                bar.overlay   = string.format('Lv %d  --  %d pts (max)', row.level, row.fame);
                bar.tip       = string.format('%s: level %d, the top. %d points, straight from the server\'s fame arithmetic.%s%s',
                    area.name, row.level, row.fame, sinceLastSync(area.id), guidePromise(area));

                capped = capped + 1;
            else
                local fraction = (row.fame - row.base) / (row.next - row.base);

                if (fraction < 0) then fraction = 0; end
                if (fraction > 1) then fraction = 1; end

                -- Points ABOVE the level's ceiling are a server caught
                -- mid-recompute (getFame and getFameLevel are two reads, and a
                -- turn-in can land between them). The bar clamps; the overlay
                -- used to print the subtraction raw and say "-75 to Lv 5",
                -- which is the one thing a distance must never be.
                local remaining = row.next - row.fame;

                if (remaining < 0) then remaining = 0; end

                bar.fraction  = fraction;
                bar.remaining = remaining;
                bar.overlay   = string.format('Lv %d  --  %d pts (%d to Lv %d)',
                    row.level, row.fame, remaining, row.level + 1);
                bar.tip       = string.format('%s: level %d with %d points. %d more reach level %d.%s%s',
                    area.name, row.level, row.fame, remaining, row.level + 1,
                    sinceLastSync(area.id), guidePromise(area));

                if (bestGap == nil or remaining < bestGap) then
                    bestArea  = area;
                    bestGap   = remaining;
                    bestLevel = row.level + 1;
                end
            end

            -- Two tooltips, because only ONE of the two items in the row
            -- answers a click: the name is a Selectable and the bar is not,
            -- and a tooltip that says "click" over something that does
            -- nothing is worse than no tooltip at all.
            bar.nameTip = bar.tip;

            if (guide ~= nil and guide[area.key] ~= nil) then
                bar.nameTip = bar.tip .. '\nClick this name to open the area in the Guide tab.';
            end

            view.bars[area.id] = bar;
            view.labels[area.id] = string.format('%s (Lv %d)##dwfame_g_%d', area.name, row.level, area.id);
        else
            view.labels[area.id] = string.format('%s##dwfame_g_%d', area.name, area.id);
        end
    end

    -- The closest-next lens: every un-capped area by how few points its next
    -- level needs, capped ones last. A tie keeps catalogue order, which makes
    -- this a strict weak ordering -- LuaJIT raises "invalid order function"
    -- on anything less.
    if (sort) then
        table.sort(view.rows, function(a, b)
            local da = view.bars[a.id].remaining;
            local db = view.bars[b.id].remaining;

            if (da == db) then
                return a.id < b.id;
            end

            return da < db;
        end);
    end

    if (counted > 0) then
        if (bestArea == nil) then
            view.summary = string.format('%d areas, every one at its cap.', counted);
        elseif (capped > 0) then
            view.summary = string.format('%d areas, %d at the cap. Closest: %s, %d points to level %d.',
                counted, capped, bestArea.name, bestGap, bestLevel);
        else
            view.summary = string.format('%d areas. Closest: %s, %d points to level %d.',
                counted, bestArea.name, bestGap, bestLevel);
        end
    end

    -- Both sentences that quote the server's fame rate change exactly when
    -- the ledger does, so they are written here and not once a frame.
    view.guideIntro = 'Fame amounts below are base points, straight from this server\'s quest scripts.';
    view.rateText   = nil;

    if (state.rate ~= nil and state.rate ~= 100) then
        view.rateText   = string.format('Server fame rate: %.2fx', state.rate / 100);
        view.guideIntro = view.guideIntro ..
            string.format(' This server multiplies fame gains by %.2fx.', state.rate / 100);
    end

    local widest = 0;

    for _, area in ipairs(AREAS) do
        local measured = textWidth(area.name);

        if (measured > widest) then
            widest = measured;
        end
    end

    view.nameW = widest + 12;
end

local function ensureView()
    if (view.rev ~= modelRev or view.sort ~= (state.sortByNext[1] == true)) then
        rebuildView();
    end
end

--[[
* Where the Fame tab wants the Guide tab opened, and at which area. Set by a
* click on an area's name, consumed by the next frames' tab bar and tree.
*
* ASHITA'S ANNOTATIONS ARE NOT THE BINDING. The three-argument BeginTabItem
* (label, open table, flags) is declared in the SDK, and so were
* SameLine(offset) and two-argument InputInt -- both of which the live sol
* bindings REFUSED the first time dwah tried them (dwah 1.4.0's 5a lesson).
* So the flagged call runs under pcall, one spelling per frame -- nil first,
* then { true }, which is what every p_open in this suite passes -- and a
* refusal of both latches the whole idea off. The tab still opens; the player
* just clicks it themselves. The same rule covers SetNextItemOpen and
* SetNextWindowSizeConstraints below: no call this window has not seen a
* sibling make in anger may be the thing that takes a frame down.
--]]
local tabSelect   = { want = nil, tries = 0, broken = false };
local pendingArea = nil;

local function requestTab(name)
    if (tabSelect.broken) then
        return;
    end

    tabSelect.want  = name;
    tabSelect.tries = 2;
end

local function beginTab(label, wanted, spelling)
    if (wanted and not tabSelect.broken) then
        local openArg = nil;

        if (spelling == 1) then
            openArg = { true };
        end

        local ok, opened = pcall(imgui.BeginTabItem, label, openArg, ImGuiTabItemFlags_SetSelected);

        if (ok) then
            tabSelect.want  = nil;
            tabSelect.tries = 0;

            return opened;
        end

        if (spelling <= 1) then
            tabSelect.broken = true;
            tabSelect.want   = nil;
            tabSelect.tries  = 0;
        end
    end

    return imgui.BeginTabItem(label);
end

local openNodeBroken = false;

local function forceNodeOpen()
    if (openNodeBroken) then
        return;
    end

    if (not pcall(imgui.SetNextItemOpen, true, ImGuiCond_Always)) then
        openNodeBroken = true;
    end
end

-- The bar's size, reused rather than allocated sixty times a second. The
-- height rides the font: 16 pixels was the stock line height and clipped the
-- overlay for anyone running a larger one.
local barSize = { -1, 16 };

-- "Fill what is left", allocated once instead of sixty times a second.
local FILL_SIZE = { -1, -1 };

--[[
* A dim sentence that wraps. Both notes this window draws -- the one under an
* Abyssea headline and the one under a derived area's bar -- run past seventy
* characters, and at the window's minimum width an unwrapped TextDisabled
* simply stops mid-word at the edge of its column. Wrap position 0 is ImGui's
* "the end of the window, or of the column", so the same call is right inside
* a table cell and outside one.
--]]
local function dimWrapped(text)
    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled(text);
    imgui.PopTextWrapPos();
end

--[[
* One fame bar, as a row of the two-column table fameTab opened. Everything
* it draws was computed at the last sync; this is the part that has to happen
* every frame and nothing else is.
--]]
local function fameRow(area)
    local bar = view.bars[area.id];

    if (bar == nil) then
        return;
    end

    imgui.TableNextRow();
    imgui.TableNextColumn();

    -- The name is a Selectable rather than Text so the row can answer the
    -- question the bar provokes: a click opens this area in the Guide tab,
    -- where the sentence about how to raise it lives.
    if (imgui.Selectable(rowLabel[area.id], false)) then
        if (guide ~= nil and guide[area.key] ~= nil) then
            requestTab('Guide');

            pendingArea = area.key;
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(bar.nameTip);
    end

    imgui.TableNextColumn();
    imgui.ProgressBar(bar.fraction, barSize, bar.overlay);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(bar.tip);
    end

    if (area.note ~= nil) then
        imgui.TableNextRow();
        imgui.TableNextColumn();
        imgui.TableNextColumn();
        dimWrapped(area.note);
    end
end

-- The two-column frame every bar row renders into. Opened and closed per
-- group (or once, sorted), so the group headline can sit between tables.
local BAR_TABLE_FLAGS = bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit);
local BAR_TABLE_SIZE  = { -1, 0 };

local function beginBarTable(id)
    if (imgui.BeginTable(id, 2, BAR_TABLE_FLAGS, BAR_TABLE_SIZE)) then
        imgui.TableSetupColumn('Area', ImGuiTableColumnFlags_WidthFixed, view.nameW, 0);
        imgui.TableSetupColumn('Fame', ImGuiTableColumnFlags_WidthStretch, 0, 0);

        return true;
    end

    return false;
end

local function fameTab()
    if (next(state.areas) == nil) then
        imgui.TextDisabled('No fame data yet. Refresh, or wait for the first sync.');

        return;
    end

    barSize[2] = metric('GetTextLineHeight', 14) + 4;

    imgui.Checkbox('Sort by closest next level', state.sortByNext);
    tip('sort');

    if ((state.sortByNext[1] == true) ~= (config.sortByNext == true)) then
        rememberSetting('sortByNext', state.sortByNext[1] == true);
    end

    if (view.summary ~= nil) then
        imgui.TextDisabled(view.summary);
        tip('summary');
    end

    if (not imgui.BeginChild('##dwfame_bars', FILL_SIZE, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (state.sortByNext[1]) then
        if (beginBarTable('##dwfame_sorted')) then
            for _, area in ipairs(view.rows) do
                fameRow(area);
            end

            imgui.EndTable();
        end
    else
        for _, groupName in ipairs(GROUP_ORDER) do
            local rows = view.groups[groupName];

            if (rows ~= nil and #rows > 0) then
                imgui.TextDisabled(groupName);

                if (GROUP_TIPS[groupName] ~= nil and imgui.IsItemHovered()) then
                    imgui.SetTooltip(GROUP_TIPS[groupName]);
                end

                if (GROUP_NOTES[groupName] ~= nil) then
                    dimWrapped(GROUP_NOTES[groupName]);
                end

                if (beginBarTable(GROUP_TABLE_ID[groupName])) then
                    for _, area in ipairs(rows) do
                        fameRow(area);
                    end

                    imgui.EndTable();
                end
            end
        end
    end

    imgui.EndChild();
end

local function coloredWrapped(color, text)
    imgui.PushStyleColor(ImGuiCol_Text, color);
    imgui.TextWrapped(text);
    imgui.PopStyleColor();
end

--[[
* The provenance card behind one guide sentence, built once at load from the
* rows data/guide.lua carries beside the prose. A card is a list of
* { text, dim } lines, so drawing it is a loop and no formatting happens on
* the frame a player hovers.
--]]
local guideCards = { };

local function questTitle(path)
    local file = tostring(path):match('([^/\\]+)%.lua$');

    if (file == nil) then
        return tostring(path);
    end

    return (file:gsub('_', ' '));
end

local function buildGuideCards()
    for areaKey, perLine in pairs(guideFacts) do
        local cards = { };

        for lineIndex, rows in pairs(perLine) do
            local card = { };

            for _, row in ipairs(rows) do
                -- A row whose provenance is not a quest file has nothing to
                -- show a player: the checker is what those were written for,
                -- and a card headed "nil" is worse than no card at all.
                if (type(row.quest) == 'string') then
                    if (#card > 0) then
                        card[#card + 1] = { text = '', dim = true };
                    end

                    card[#card + 1] = { text = questTitle(row.quest), dim = false };

                    if (type(row.npc) == 'string' and type(row.town) == 'string') then
                        card[#card + 1] = {
                            text = string.format('%s -- %s', (row.npc:gsub('_', ' ')), row.town),
                            dim  = false,
                        };
                    end

                    if (type(row.fame) == 'number') then
                        local paid = areaByEnum[row.fameArea];

                        card[#card + 1] = {
                            text = string.format('%d fame to %s per completion, before this server\'s rate.',
                                math.floor(row.fame), paid ~= nil and paid.name or tostring(row.fameArea)),
                            dim  = false,
                        };
                    end

                    card[#card + 1] = { text = 'scripts/quests/' .. row.quest, dim = true };
                end
            end

            if (#card > 0) then
                cards[lineIndex] = card;
            end
        end

        guideCards[areaKey] = cards;
    end
end

buildGuideCards();

--[[
* The guide, lowercased once at load for the find box. Sixteen area names and
* fifty-odd sentences, folded on every keystroke instead of on every frame.
--]]
local guideLower = { };
local areaLower  = { };

for _, area in ipairs(AREAS) do
    areaLower[area.key] = string.lower(area.name);

    local lines = guide ~= nil and guide[area.key] or nil;

    if (lines ~= nil) then
        local folded = { };

        for index, line in ipairs(lines) do
            folded[index] = string.lower(line);
        end

        guideLower[area.key] = folded;
    end
end

--[[
* What the Guide tab draws for the current find box: one section per area
* that still has lines, each carrying the ORIGINAL line indexes so a filtered
* sentence keeps its own provenance card. Rebuilt when the box changes, not
* when the frame changes -- the guide itself is loaded once and never moves.
--]]
local guideView = { needle = nil, sections = nil, shown = 0 };

-- The find box's text and its lowercase twin, so the fold happens on a
-- keystroke rather than on a frame.
local foldedFind = { raw = '', needle = '' };

local function rebuildGuideView(needle)
    local sections = { };
    local shown    = 0;

    for _, area in ipairs(AREAS) do
        local lines = guide ~= nil and guide[area.key] or nil;

        if (lines ~= nil) then
            -- An area whose NAME matches keeps every line it has: typing
            -- "norg" is asking for the Norg section, not for the sentences
            -- inside it that happen to spell the word.
            local wholeArea = needle == '' or string.find(areaLower[area.key], needle, 1, true) ~= nil;
            local folded    = guideLower[area.key];
            local kept      = { };

            for index, line in ipairs(lines) do
                if (wholeArea or (folded ~= nil and string.find(folded[index], needle, 1, true) ~= nil)) then
                    kept[#kept + 1] = { index = index, text = line };
                end
            end

            if (#kept > 0) then
                sections[#sections + 1] = { area = area, lines = kept };
                shown = shown + #kept;
            end
        end
    end

    guideView.needle   = needle;
    guideView.sections = sections;
    guideView.shown    = shown;
end

local function ensureGuideView(needle)
    if (guideView.needle ~= needle) then
        rebuildGuideView(needle);
    end
end

local function guideLine(area, index, line)
    imgui.Bullet();
    imgui.SameLine();
    coloredWrapped(theme.colors.hint, line);

    if (not imgui.IsItemHovered()) then
        return;
    end

    -- A sentence the checker backs gets its receipt; a sentence that is true
    -- by ABSENCE says how absence is checked; the rest -- auction house
    -- notes, the doors a level opens, the cross-references -- get nothing,
    -- because the old blanket tooltip called every one of them "a repeatable
    -- quest verified against this server's own quest scripts", which for the
    -- eight Abyssea "nothing raises this yet" lines was the exact opposite of
    -- what the line said (2026-09-06).
    local cards = guideCards[area.key];
    local card  = cards ~= nil and cards[index] or nil;

    if (card ~= nil) then
        imgui.BeginTooltip();

        for _, entry in ipairs(card) do
            if (entry.dim) then
                imgui.TextDisabled(entry.text);
            else
                imgui.Text(entry.text);
            end
        end

        -- Wrapped, because it is the longest sentence in the window and an
        -- unwrapped one would set the width of the whole card (dwtoau's
        -- TextWrapped-inside-a-card shape).
        imgui.Separator();
        coloredWrapped(theme.colors.dim, TIPS.provenance);
        imgui.EndTooltip();

        return;
    end

    local absent = guideAbsence[area.key];

    if (absent ~= nil and absent[index] ~= nil) then
        imgui.SetTooltip(TIPS.absence);
    end
end

local function guideTab()
    if (guide == nil) then
        dimWrapped('data/guide.lua missing or unreadable -- reinstall dwfame to get the guide back.');

        return;
    end

    imgui.PushItemWidth(260);
    imgui.InputTextWithHint('##dwfame_find', 'find an area, NPC, item or town...', state.find, 64);
    imgui.PopItemWidth();
    tip('find');

    -- The box's text is folded when it CHANGES, not on every frame the tab
    -- is open: string.lower allocates, and a find box sits still for minutes
    -- at a time.
    local typed = state.find[1] or '';

    if (typed ~= foldedFind.raw) then
        foldedFind.raw    = typed;
        foldedFind.needle = string.lower(typed);
    end

    local needle = foldedFind.needle;

    if (needle ~= '') then
        imgui.SameLine();

        if (imgui.SmallButton('Clear##dwfame_find_clear')) then
            state.find[1]     = '';
            foldedFind.raw    = '';
            foldedFind.needle = '';
            needle            = '';
        end

        tip('findClear');
    end

    if (not imgui.BeginChild('##dwfame_guide', FILL_SIZE, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    coloredWrapped(theme.colors.dim, view.guideIntro);
    tip('guideRate');
    imgui.Separator();

    ensureGuideView(needle);

    for _, section in ipairs(guideView.sections) do
        local area = section.area;

        -- A filtered guide opens what it found, and a name clicked on the
        -- Fame tab opens the area it named; otherwise the Abyssea eight stay
        -- folded away, because eight "nothing raises this yet" sentences are
        -- not what the tab is for.
        if (needle ~= '' or pendingArea == area.key) then
            forceNodeOpen();
        end

        local flags = (area.group ~= 'Abyssea') and ImGuiTreeNodeFlags_DefaultOpen or 0;

        if (imgui.TreeNodeEx(view.labels[area.id] or area.name, flags)) then
            for _, entry in ipairs(section.lines) do
                guideLine(area, entry.index, entry.text);
            end

            imgui.TreePop();
        end
    end

    if (guideView.shown == 0) then
        imgui.TextDisabled('Nothing in the guide matches the find box.');
    end

    pendingArea = nil;

    imgui.EndChild();
end

--[[
* How old the numbers on screen are, in words, recomputed only when the
* answer would change. The window is a renderer of a ledger that goes stale
* the moment a quest pays out, and "Synced." with no age on it read the same
* one second and ten minutes after the sync (2026-09-06).
--]]
local ageBucket = nil;
local ageText   = nil;

local function syncAge(now)
    if (state.syncedAt == nil) then
        return nil;
    end

    local seconds = math.floor(now - state.syncedAt);

    if (seconds < 0) then
        seconds = 0;
    end

    local bucket = seconds < 60 and seconds or math.floor(seconds / 60) * 60;

    if (bucket ~= ageBucket) then
        ageBucket = bucket;

        if (seconds < 5) then
            ageText = 'just now';
        elseif (seconds < 60) then
            ageText = string.format('%d seconds ago', seconds);
        elseif (seconds < 3600) then
            ageText = string.format('%d minutes ago', math.floor(seconds / 60));
        else
            ageText = string.format('%d hours ago', math.floor(seconds / 3600));
        end
    end

    return ageText;
end

-- Which colour each status tone paints in. The theme rewrites these tables in
-- place when the launcher's palette changes, so holding the reference is what
-- keeps the status recolouring live.
local STATUS_COLOR =
{
    ok   = theme.colors.ok,
    warn = theme.colors.warn,
    err  = theme.colors.err,
};

-- The status sentence and its age, composed once per second rather than once
-- per frame.
local statusCache = { status = nil, age = nil, text = nil };

-- One line of the status, wrapped: a refusal can be a whole sentence, and at
-- the window's minimum width an unwrapped one walked off the right edge.
local function statusLine(color, text)
    imgui.PushStyleColor(ImGuiCol_Text, color);
    imgui.TextWrapped(text);
    imgui.PopStyleColor();
end

local function renderWindow()
    local now = os.clock();

    -- Once per frame, before anything reads it: the header row quotes the
    -- server's fame rate out of the view, and the tab that would otherwise
    -- have built it may not be the one on screen.
    ensureView();

    if (imgui.Button('Refresh')) then
        serverSilent = false;

        forget();
        requestSync();
    end

    tip('refresh');

    imgui.SameLine();

    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
        tip('queued');
    elseif (view.rateText ~= nil) then
        imgui.TextDisabled(view.rateText);
        tip('rate');
    else
        imgui.TextDisabled('');
    end

    if (state.status ~= nil and state.status ~= '') then
        -- The age rides INSIDE the status string rather than beside it: the
        -- status wraps, and SameLine after a wrapped item lands beside its
        -- first line, off the right edge of the window.
        -- Not on an error: "Update dwfame.  --  5 minutes ago" reads as if
        -- the REFUSAL were five minutes old, and the sentence a player has to
        -- act on should not have to compete with the ledger's age.
        local age      = syncAge(now);
        local showAge  = age ~= nil and state.statusTone ~= 'err';
        local text     = state.status;

        if (showAge) then
            if (statusCache.status ~= state.status or statusCache.age ~= age) then
                statusCache.status = state.status;
                statusCache.age    = age;
                statusCache.text   = string.format('%s  --  %s', state.status, age);
            end

            text = statusCache.text;
        end

        statusLine(STATUS_COLOR[state.statusTone] or theme.colors.ok, text);

        if (showAge) then
            tip('syncAge');
        end
    end

    if (state.toast ~= nil and state.toastAt ~= nil and (now - state.toastAt) <= TOAST_SECONDS) then
        imgui.TextColored(theme.colors.hint, state.toast);
        tip('toast');
    end

    imgui.Separator();

    -- A character switch arrived while the window was open: honour the tab
    -- that character was last on, exactly as opening the window would.
    if (adoptConfig) then
        adoptConfig = false;

        requestTab(config.tab == 'Guide' and 'Guide' or 'Fame');
    end

    if (imgui.BeginTabBar('##dwfame_tabs')) then
        -- A requested tab is applied for at most two frames, one spelling
        -- each: ImGui owns which tab is active from then on, and forcing it
        -- every frame would nail the window shut on the tab a player is
        -- trying to leave.
        local wanted   = tabSelect.want;
        local spelling = tabSelect.tries;

        if (tabSelect.tries > 0) then
            tabSelect.tries = tabSelect.tries - 1;

            if (tabSelect.tries == 0) then
                tabSelect.want = nil;
            end
        end

        local openFame = beginTab('Fame##dwfame_tab_fame', wanted == 'Fame', spelling);

        tip('tabFame');

        if (openFame) then
            -- Not while a selection is still being applied: on the frame a
            -- requested tab is asked for, the tab bar still reports the OLD
            -- one as open, and recording that would persist the tab the
            -- player is being moved AWAY from -- then overwrite it again a
            -- frame later.
            if (tabSelect.want == nil) then
                rememberSetting('tab', 'Fame');
            end

            fameTab();
            imgui.EndTabItem();
        end

        local openGuide = beginTab('Guide##dwfame_tab_guide', wanted == 'Guide', spelling);

        tip('tabGuide');

        if (openGuide) then
            if (tabSelect.want == nil) then
                rememberSetting('tab', 'Guide');
            end

            guideTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The window's own numbers, allocated once. The default is what sixteen bars
* and their group headlines need without a scrollbar; the minimum is the
* smallest size at which the tab bar, the status line and a bar overlay are
* all still readable.
--]]
local WINDOW_SIZE = { 620, 460 };
local WINDOW_MIN  = { 480, 300 };
local WINDOW_MAX  = { 99999, 99999 };

local constraintsBroken = false;

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape, and its
* reasoning, kept verbatim).
--]]
ashita.events.register('d3d_present', 'dwfame_present', function ()
    -- Before the visibility check: a sync requested by a zone-in still has
    -- to reach the server with the window shut.
    if (state.syncAt ~= nil and os.clock() >= state.syncAt) then
        -- The deferral exists because 0x000A arrives on the load screen --
        -- but a fixed delay only guesses at how long that screen stays up,
        -- and a typed line handed to a client that is still zoning is not
        -- delayed, it is LOST, with "A command error occurred." in the log
        -- as its residue (the per-zone error players were seeing). The
        -- client's own zoning flag is the fact; wait it out.
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (player ~= nil and player:GetIsZoning() ~= 0) then
            state.syncAt   = os.clock() + 1.0;
            state.syncSlot = nil;
        elseif (state.syncSlot == nil) then
            -- Zoning done. Every sibling clears its zoning flag on the SAME
            -- frame, so hold this addon's stagger slot before firing or the
            -- zone-in syncs collide at the client's chat throttle and all but
            -- one come back "A command error occurred." (dwecho.lua's ZONE_ORDER
            -- is the shared slot order; 2026-08-14).
            state.syncSlot = os.clock() + echo.zoneSlot('dwfame') * echo.SEND_INTERVAL;
            state.syncAt   = state.syncSlot;
        else
            state.syncAt   = nil;
            state.syncSlot = nil;

            forget();
            requestSync();
        end
    end

    -- Answer tracking runs whether or not the window is open: it is exactly
    -- the window-closed zone-in auto-syncs that must stop when the server
    -- has gone silent (an unknown !command here is /say chat).
    checkAnswers();

    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize(WINDOW_SIZE, ImGuiCond_FirstUseEver);

    -- A floor under the window (1.1.0). Sixteen bars, a tab bar and a status
    -- sentence do not survive being dragged down to a hundred pixels: the
    -- tabs wrap out of reach and the bars' own overlays clip. The ceiling is
    -- ImGui's own "no limit" idiom. Latched like every other call this window
    -- makes that no sibling has proven live -- and this one sits OUTSIDE the
    -- render pcall, where a throw would cost the whole present handler.
    if (not constraintsBroken and
        not pcall(imgui.SetNextWindowSizeConstraints, WINDOW_MIN, WINDOW_MAX)) then
        constraintsBroken = true;
    end

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Fame##dwfame', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            -- The escape hatch this addon's header promises is `!fame` typed
            -- in chat -- and packet_out below swallows exactly that line and
            -- reopens THIS window with it, so the advice printed here used to
            -- send the player straight back into the window that had just
            -- failed. While the latch is set the typed line goes to the
            -- server, which answers the same ledger in prose; opening the
            -- window on purpose clears it and earns another try (2026-09-06).
            renderBroken = true;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwfame'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwfame'):append(chat.message('Window closed. `!fame` typed in chat now answers with the same numbers in prose; /fame tries the window again.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs: a window showing fame as it
* stood two quests ago is the quiet kind of wrong this project exists to
* rule out, and a sync costs one chat line.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting, and for the
        -- silent-server detection: opening the window is the deliberate
        -- act that earns one more try.
        state.reported = false;
        serverSilent   = false;
        renderBroken   = false;

        -- The tab this character was last looking at, applied on the first
        -- frames of the window and owned by ImGui after that.
        requestTab(config.tab == 'Guide' and 'Guide' or 'Fame');

        forget();
        requestSync();
    end
end

ashita.events.register('command', 'dwfame_command', function (e)
    local args = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwfame' and first ~= '/fame' and first ~= '/dwf') then
        return;
    end

    e.blocked = true;

    local sub = #args >= 2 and args[2]:lower() or '';

    if (sub == 'refresh') then
        serverSilent = false;

        forget();
        requestSync();

        return;
    end

    --[[
    * `/fame guide <anything>` is the shortest path there is between a
    * question and its answer: it opens the window on the Guide tab with the
    * words already in the find box. Nothing here is a number and nothing is
    * sent to the server -- the text only ever reaches string.find as a PLAIN
    * needle (1.1.0).
    --]]
    if (sub == 'guide') then
        if (not state.open[1]) then
            toggleWindow();
        end

        requestTab('Guide');

        local needle = '';

        for index = 3, #args do
            needle = needle == '' and args[index] or (needle .. ' ' .. args[index]);
        end

        -- The find box holds 64 bytes; a longer line would be truncated by
        -- ImGui on the next keystroke anyway, so cut it here and match what
        -- the box will show.
        state.find[1] = needle:sub(1, 63);

        return;
    end

    toggleWindow();
end);

--[[
* Sync on login and zone-in (0x000A serves both). Everything server-derived
* resets first -- a login may be a different character, and a stale ledger
* surviving into a new character's window is exactly the quiet wrongness
* this project exists to rule out. prevLevels deliberately survives: the
* level-up line only works if the comparison outlives the zone line, and
* the c| charid on the next sync wipes it the moment the character really
* is a different one.
--]]
ashita.events.register('packet_in', 'dwfame_zonein', function (e)
    if (e.id == 0x000A) then
        -- 0x000A leads with the PosHead's UniqueNo -- the same id the server
        -- stamps into `c|` -- so a zone line can be told apart from a
        -- different character logging in under this addon instance (dwcraft's
        -- guard). It matters because the two want opposite things: a login is
        -- somebody else's ledger and must be gone before it can be misread,
        -- while a zone line invalidates nothing the server ever said, and
        -- blanking on it left the window empty for the four-second defer plus
        -- this addon's stagger slot -- six seconds of "No fame data yet" on
        -- every door, every time (2026-09-06). Unknown counts as different:
        -- the packet not being readable is not evidence that it is us.
        local uid  = e.data_modified ~= nil and u32(e.data_modified, 0x04) or 0;
        local same = uid ~= 0 and state.charid ~= nil and uid == state.charid;

        if (not same) then
            state.charid   = nil;
            state.rate     = nil;
            state.areas    = T{ };
            state.syncedAt = nil;
            state.gained   = { };

            -- Somebody else's level-up has no business celebrating over
            -- this character's window.
            state.toast   = nil;
            state.toastAt = nil;

            modelRev = modelRev + 1;
        end

        -- A half-arrived answer belongs to the world we just left either way.
        state.inbound    = nil;
        draft            = nil;
        state.status     = 'Syncing...';
        state.statusTone = 'ok';

        forget();

        -- No auto-sync against a server that has shown it does not speak
        -- dwfame: an unknown !command falls through to /say here, so each
        -- retry would be the player chatting "!dwf sync" at whoever is
        -- nearby. Opening the window retries deliberately.
        if (not serverSilent) then
            state.syncAt = os.clock() + 4.0;
        else
            state.status     = 'Fame ledger paused (no answer from the server). Open the window to retry.';
            state.statusTone = 'warn';
        end
    end
end);

--[[
* Leaving the world forgives the silent latch.
*
* 0x000B carries a LogoutState at 0x04: 2 is a zone change, 4 is a cancelled
* logout, and anything else is this character actually leaving (dwcraft's
* reading of the same packet). Leaving is the one moment it is safe to clear
* `serverSilent`: the next login is a new session, quite possibly against a
* map that has been restarted since, and it earns exactly one more probe.
*
* Per LOGIN and not per zone line, which is the whole point. A latch that
* forgave itself on every door would broadcast "!dwf sync" in /say at whoever
* is standing there, once per door, on a server that really does not speak it
* -- which is why the latch exists at all. Without this, a pair of chat lines
* lost to a lag spike left the ledger paused for the rest of the session, and
* with the window shut the level-up line simply stopped happening (1.1.0).
--]]
local LOGOUT_ZONECHANGE = 2;
local LOGOUT_CANCEL     = 4;

ashita.events.register('packet_in', 'dwfame_logout', function (e)
    if (e.id ~= 0x000B) then
        return;
    end

    local logoutState = u8(e.data_modified or '', 0x04);

    if (logoutState ~= LOGOUT_ZONECHANGE and logoutState ~= LOGOUT_CANCEL and logoutState ~= 0) then
        serverSilent = false;
    end
end);

--[[
* Watch what the player sends.
*
* Bare `!dwf` and `!fame` (and the ui/window/gui spellings) are intercepted
* and toggle this window instead of going to the server -- the server verb
* is the name players learn from the news post, so it has to be a door and
* not a dead end. `!dwf sync` typed by hand still passes through untouched;
* that is the escape hatch this addon's header promises.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped.
* Stamping the player's own line as a send makes the next queued command
* wait its interval instead of racing it (dwbags' lesson, kept verbatim).
--]]
ashita.events.register('packet_out', 'dwfame_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    -- `!fame` is the ONE door that also exists without this addon, so it is
    -- the one that stops being intercepted when the window cannot draw: the
    -- server answers it in prose (fame_core.lua's typed tier), which is
    -- exactly what a player whose window just closed was told to type. The
    -- `!dwf` spellings stay intercepted -- their server answer is machine
    -- records this addon blocks, so passing them through would print nothing
    -- at all -- and one of them reopening the window is the deliberate retry.
    if (lower == '!dwf' or lower == '!dwf ui' or lower == '!dwf window' or lower == '!dwf gui' or
        (lower == '!fame' and not renderBroken)) then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwf') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwfame_load', function ()
    print(chat.header('dwfame'):append(chat.message('/fame, /dwfame or !fame opens the fame ledger. /fame guide <words> opens the guide already searching for them.')));
end);
