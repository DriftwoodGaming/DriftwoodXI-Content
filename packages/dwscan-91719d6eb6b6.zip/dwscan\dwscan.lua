--[[
* DriftwoodXI -- dwscan
*
* Everything the server knows about the thing you are looking at, in one
* window, one click away. Level and the con it wears for you, the spawn band
* it rolls inside, what it drops and how often -- at THIS server's rates, with
* the icons -- what magic it resists and what it is simply immune to, how far
* away it notices you and by what sense, what it pays in exp and gil, which
* crystal Signet adds to the pile, its TP moves by name, and which of your
* quests want it dead.
*
* THE NUMBERS HERE ARE NOT THE WIKI'S, AND THAT IS THE POINT. DriftwoodXI
* doubles drop rates, triples exp, halves aggro bubbles and link radii, and
* runs its own con curve. Every figure in this window is read off the running
* server, through the same code that rolls the loot -- so it is the only place
* those numbers are true. Every one of them was computed server-side: this
* addon does no arithmetic on anything it is told (dwn_protocol.md client
* discipline 2 -- if the window computes a number, it is a bug).
*
* IT ASKS ONLY WHEN YOU ASK. There is no polling, no tick and no server push.
* Scan is a button and `/dwscan` is a window; a scan is one chat line, and the
* client rate-limits those. (The first scan of a zone is two: the handshake the
* zone line owes rides out behind it, so the capability record cannot go on
* describing a map that was still coming up when the window opened.) A scan on
* a timer would be a line per tick and a server answer nobody read. (The Wide Scan tab's opt-in Auto box is the one
* thing on a clock, and it is not on this wire at all -- it re-injects the
* retail widescan packet the native menu sends, only while that tab is drawing,
* and it costs the scan protocol nothing.)
*
* WHAT IT WILL NOT TELL YOU. The server refuses to gauge notorious monsters,
* battlefield mobs and anything flagged CheckAsNm -- exactly as `/check` does
* -- so their level and difficulty arrive withheld and this window says so
* rather than inventing them. The quest list is what the server's own
* interaction index holds for this mob: things that want it DEAD. It is not a
* claim that nothing else wants it.
*
* TURN IT OFF AND THE ANSWERS ARE STILL THERE. `!scan` works typed, on
* whatever you have selected, and says the mob and its family, its level band
* and HP, the exp it pays, whether it starts fights, what wants it dead, and
* its best eight drop rows -- in sentences, with no addon. What it does NOT
* say is the per-element resistance table, the immunity list and the aggro
* ranges in yalms: those are what this window adds, and they are three tables
* rather than three sentences. (The claim here read "says the same things"
* until 2026-09-06, which was never true of the resistance table and stopped
* being true of the rest the day the typed tier grew a shorter answer.)
--]]

addon.name    = 'dwscan';
addon.author  = 'DriftwoodXI';
addon.version = '1.5.0';
addon.desc    = 'Scan your target: level, drops with this server\'s real rates, resistances, aggro and quests.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the `!dwn` lines sent below; installed
-- before any other text_in handler in this file (dwecho.lua). Without it the
-- player reads `Blaster : !dwn scan 42` in their own log on every scan.
echo.install();

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load.
*
* This addon is loaded from the launcher's boot script, which runs long before
* the client has a rendering device -- and `d3d.get_device()` at file scope
* makes the whole addon fail to load when it answers nothing (the dwbags
* lesson). Nothing here needs a device until the first item icon is drawn.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; the fifteenth `_DW*DATA` name,
-- and nothing else on the server uses it, so matching it exactly is a safe
-- filter.
local DATA_SENDER = '_DWNDATA';

-- Protocol version the server announces in its `d|` record. An unknown one is
-- HARD REFUSED (one message, then silence) rather than guessed at: a scan
-- rendered from a record layout this addon does not understand is a confident
-- lie about how dangerous something is, which is worse than no scan at all.
local PROTOCOL = 1;

-- The server withholds a field by sending -1. Rendering that as a number would
-- be the window stating something the server refused to state.
local WITHHELD = -1;

--[[
* A RUNAWAY GUARD ON THE TREASURE HUNTER CAP, and deliberately not a copy of
* the server's bracket table.
*
* `f|`'s `maxth` is a number read straight off the wire, and it is the bound of
* a `for` loop that draws one Selectable per tier every frame the dropdown is
* open. The server says 14 today; a server that ever said 60000 by accident
* would be sixty thousand widgets a frame, which is a frozen client rather than
* a wrong number. This ceiling is not "how many tiers there are" -- the server
* still owns that, and the dropdown still resizes with it -- it is the point
* past which the answer cannot be a Treasure Hunter tier at all.
--]]
local MAX_TH_CEILING = 50;

--[[
* The dropdown's labels, built once at load (2026-09-06).
*
* The preview was a string.format on every frame the Drops tab drew, and each
* Selectable another one on every frame the popup was open -- for fifteen
* labels that are the same fifteen strings for the life of the session. The
* table runs to the ceiling above rather than to the server's `maxth`, because
* the ceiling is what bounds the loop that reads it.
--]]
local TH_LABELS = { };
local TH_ITEMS  = { };

for level = 0, MAX_TH_CEILING do
    TH_LABELS[level] = string.format('TH %d', level);
    TH_ITEMS[level]  = string.format('TH %d##dwscan_th_%d', level, level);
end

--[[
* Element order on the `r|` record, and the two pseudo-elements the physical
* lanes ride on. Index is the wire's element id.
--]]
local ELEMENTS = {
    [1] = { name = 'Fire',      r = 236, g = 98,  b = 62  },
    [2] = { name = 'Ice',       r = 132, g = 214, b = 236 },
    [3] = { name = 'Wind',      r = 126, g = 214, b = 152 },
    [4] = { name = 'Earth',     r = 197, g = 160, b = 96  },
    [5] = { name = 'Lightning', r = 190, g = 138, b = 236 },
    [6] = { name = 'Water',     r = 96,  g = 156, b = 236 },
    [7] = { name = 'Light',     r = 240, g = 236, b = 208 },
    [8] = { name = 'Dark',      r = 168, g = 140, b = 190 },
};

local ELEMENT_ORDER = { 1, 2, 3, 4, 5, 6, 7, 8 };

-- The four physical lanes, in the order the wire packs them. A module-level
-- constant rather than a table literal rebuilt inside the draw: the names never
-- change and the values are read off the scan beside them. It sits up here with
-- the element order because derivedOf composes both lists' verdicts, and that
-- runs well above the Magic tab that draws them.
local PHYSICAL_LANES = {
    { name = 'Slashing',     key = 'slash'  },
    { name = 'Piercing',     key = 'pierce' },
    { name = 'Hand-to-hand', key = 'hth'    },
    { name = 'Blunt',        key = 'impact' },
};

--[[
* Con tiers, the dwcon palette, so the two windows cannot disagree about what
* a colour means. Tier 1 is absent on purpose: the DriftwoodXI curve retires
* Incredibly Easy Prey, so a row for it is a legend nobody can ever see.
--]]
local TIERS = {
    [0] = { short = 'Too Weak',         r = 150, g = 150, b = 150 },
    [2] = { short = 'Easy Prey',        r = 60,  g = 180, b = 75  },
    [3] = { short = 'Decent Challenge', r = 240, g = 200, b = 40  },
    [4] = { short = 'Even Match',       r = 245, g = 130, b = 32  },
    [5] = { short = 'Tough',            r = 220, g = 50,  b = 47  },
    [6] = { short = 'Very Tough',       r = 230, g = 60,  b = 230 },
    [7] = { short = 'Incredibly Tough', r = 120, g = 50,  b = 200 },
};

-- `h|` flag bits.
local FLAG_GAUGED      = 1;
local FLAG_NM          = 2;
local FLAG_UNDEAD      = 4;
local FLAG_BATTLEFIELD = 8;
local FLAG_ALIVE       = 16;

-- `a|` detection bits, the server's own xi.detects.
local DETECTS = {
    { bit = 0x0001, name = 'sight' },
    { bit = 0x0002, name = 'sound' },
    { bit = 0x0004, name = 'low HP' },
    { bit = 0x0020, name = 'magic' },
    { bit = 0x0040, name = 'job abilities' },
    { bit = 0x0100, name = 'scent' },
};

-- `a|` spawn-type bits, the server's own xi.spawnType.
local SPAWN_TYPES = {
    { bit = 0x0001, name = 'at night' },
    { bit = 0x0002, name = 'evenings' },
    { bit = 0x0004, name = 'in weather' },
    { bit = 0x0008, name = 'in fog' },
    { bit = 0x0010, name = 'on a moon phase' },
    -- Worded to read inside the sentence that uses them ("Spawns %s."):
    -- "Spawns lottery." was a label wedged into a clause (fixed 1.5.0).
    { bit = 0x0020, name = 'by lottery' },
    { bit = 0x0040, name = 'on a window' },
    { bit = 0x0080, name = 'by script' },
};

--[[
* Persisted presentation state, through Ashita's settings library (the dwport
* shape). Flat scalars only -- the settings serializer takes booleans, numbers
* and strings, and a nested table here would be a silent loss on save.
--]]
local defaultConfig = T{
    icons     = true,      -- draw item icons beside drop rows
    autoScan  = false,     -- re-scan when the target changes, window open only
    minRate   = 0.0,       -- hide drops under this percent
    thLevel   = 0,         -- Treasure Hunter level scans are asked at; sticky across targets
    wsAuto    = false,     -- Wide Scan tab: re-scan on a timer while the tab is visible
    wsMobs    = true,      -- Wide Scan tab: show monsters
    wsNpcs    = true,      -- Wide Scan tab: show NPCs
    wsSort    = 1,         -- Wide Scan tab: 1 distance, 2 level, 3 name
    tab       = 1,         -- the tab that was open last; reopened on the next open
};

--[[
* THE LOADED FILE IS FORCED BACK INTO THE SHAPE THE REST OF THIS FILE ASSUMES
* (2026-09-06).
*
* `config\addons\dwscan\*.lua` is a plain Lua table on disk. A player may edit
* it by hand, a half-written save may leave a field truncated, and an older
* addon may have written a field this one has since retyped -- and none of
* those is a hypothetical kind of corruption, they are the ordinary life of a
* settings file. What makes it worth defending here rather than at each use is
* WHERE the values land: `thLevel` reaches `string.format('%d', ...)` inside
* pumpAnswer, and pumpAnswer runs in `d3d_present` OUTSIDE the render pcall --
* so a string there is a Lua error sixty times a second with the window shut
* and no way to reach the setting that caused it. `minRate` reaches a `<`
* against a number one tab over, which is the same error inside the pcall: the
* window closes itself every time the Drops tab is drawn.
*
* Sanitised once on load and again on the settings-update callback, because
* the callback is another way the same table arrives.
--]]
local function boolOr(value, fallback)
    if (type(value) == 'boolean') then
        return value;
    end

    return fallback;
end

local function numberIn(value, low, high, fallback)
    local n = tonumber(value);

    -- `n ~= n` is the NaN test, and it has to come first: LuaJIT's tonumber
    -- accepts 'nan' as a real number and EVERY comparison against it is false,
    -- so a range check written the obvious way lets it straight through.
    if (n == nil or n ~= n or n < low or n > high) then
        return fallback;
    end

    return n;
end

-- An index into a list declared further down this file. The real ceiling is
-- that list's own length and is applied where it is read (`WS_SORTS[n] or
-- WS_SORTS[1]`); all this has to guarantee is a small positive integer, so
-- nothing downstream is handed a string or a fraction.
local function indexOr(value, fallback)
    local n = tonumber(value);

    if (n == nil or n ~= n or n < 1 or n > 999) then
        return fallback;
    end

    return math.floor(n);
end

local function sanitize(c)
    -- A FRESH table rather than `defaultConfig` itself: handing the defaults
    -- back would alias them, and the next commit() would write the player's
    -- choices into the constants every later sanitize reads its fallbacks
    -- from. Filled from the defaults field by field below, which is the same
    -- answer without the aliasing.
    if (type(c) ~= 'table') then
        c = { };
    end

    c.icons    = boolOr(c.icons,    defaultConfig.icons);
    c.autoScan = boolOr(c.autoScan, defaultConfig.autoScan);
    c.wsAuto   = boolOr(c.wsAuto,   defaultConfig.wsAuto);
    c.wsMobs   = boolOr(c.wsMobs,   defaultConfig.wsMobs);
    c.wsNpcs   = boolOr(c.wsNpcs,   defaultConfig.wsNpcs);

    c.minRate  = numberIn(c.minRate, 0.0, 25.0, defaultConfig.minRate);
    c.thLevel  = math.floor(numberIn(c.thLevel, 0, MAX_TH_CEILING, defaultConfig.thLevel));
    c.wsSort   = indexOr(c.wsSort, defaultConfig.wsSort);

    -- Like wsSort: a small positive integer here, and the real ceiling (#TABS)
    -- applied where it is read -- this runs long before the tab list exists.
    c.tab      = indexOr(c.tab, defaultConfig.tab);

    return c;
end

--[[
* AND THE FAILED-LOAD PATH GETS A FRESH TABLE TOO (2026-09-06).
*
* `config = defaultConfig` was exactly the aliasing sanitize() goes out of its
* way to avoid three lines above: with the two names pointing at one table,
* apply() writes the player's choices INTO the constants, and every later
* sanitize() then reads its fallbacks out of them -- so a settings file that
* arrived corrupt through the update callback would "fall back" to whatever the
* player had last set rather than to what this addon ships. sanitize(nil) is
* the same defaults in a table of their own.
--]]
local config = sanitize(nil);

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = sanitize(loaded);
end

--[[
* ImGui widget holders. Every ImGui input wants a table it can write into, so
* the window edits these and copies back into `config` on the frame the widget
* reports a change. Keeping the two apart is what lets `config` stay flat
* scalars for the serializer.
--]]
local ui = {
    icons    = T{ true  },
    autoScan = T{ false },
    minRate  = T{ 0.0   },
    thLevel  = T{ 0     },
    wsAuto   = T{ false },
    wsMobs   = T{ true  },
    wsNpcs   = T{ true  },
};

--[[
* config -> ui, which has to happen on EVERY way a config arrives and not only
* on the first.
*
* Ashita re-fires the settings callback whenever the file changes on disk, and
* until 2026-09-06 that replaced `config` and left every widget holder showing
* what the file used to say. Two things then went wrong at once: the
* checkboxes disagreed with the settings actually in force, and the next click
* on any of them ran commit(), which copies the WHOLE ui table back -- so one
* click silently reverted every change the player had just made in the file.
--]]
local function syncUi()
    ui.icons[1]    = config.icons    ~= false;
    ui.autoScan[1] = config.autoScan == true;
    ui.minRate[1]  = config.minRate  or 0.0;
    ui.thLevel[1]  = config.thLevel  or 0;
    ui.wsAuto[1]   = config.wsAuto   == true;
    ui.wsMobs[1]   = config.wsMobs   ~= false;
    ui.wsNpcs[1]   = config.wsNpcs   ~= false;
end

syncUi();

pcall(settings.register, 'settings', 'dwscan_settings_update', function (s)
    if (s ~= nil) then
        config = sanitize(s);

        syncUi();
    end
end);

local function apply()
    config.icons    = ui.icons[1];
    config.autoScan = ui.autoScan[1];
    config.minRate  = ui.minRate[1];
    config.thLevel  = ui.thLevel[1];
    config.wsAuto   = ui.wsAuto[1];
    config.wsMobs   = ui.wsMobs[1];
    config.wsNpcs   = ui.wsNpcs[1];
end

-- A button, a checkbox or a dropdown reports its change ONCE, so the write can
-- ride the click.
local function commit()
    apply();

    pcall(settings.save);
end

--[[
* THE SAME THING FOR A WIDGET THAT REPORTS A CHANGE EVERY FRAME (2026-09-06).
*
* SliderFloat answers true on every frame of a drag, and `settings.save()`
* serialises the config and WRITES A FILE. Committing straight through it meant
* holding the mouse down on "Hide under" wrote `config\addons\dwscan\*.lua`
* sixty times a second for as long as the drag lasted -- disk churn nobody
* asked for, in the middle of the frame that is also drawing the table the
* slider is filtering.
*
* Applying is free and stays instant, so the filter still moves under the
* cursor; only the WRITE waits for the drag to settle. The delay is short
* enough that a player who drags and immediately alt-F4s loses at most the last
* nudge of a cosmetic filter.
--]]
local SAVE_DELAY = 0.6;

--[[
* SECONDS SINCE A STAMP, AND A STAMP FROM THE FUTURE READS AS VERY OLD
* (Phase 2, 2026-09-06). os.clock() on Windows is a 32-bit clock_t and goes
* negative after about 24.8 days of client uptime. Every gate in this file was
* `now - stamp` or `now < until`, so one wrap held every Rescan forever ("inside
* the throttle", since the difference is hugely negative), froze the Auto box,
* and left the deferred settings write, the envelope watchdog and the answer
* clock waiting until a zone line happened to reset the stamps. Erring expired
* is the permissive side for every one of them. Finite, so nothing downstream
* meets math.huge in an arithmetic it did not expect. `now` is optional so a
* caller that already read the clock this frame can hand it in: the offline
* harness strides its clock on every read, and the count of reads is part of
* what its timing checks stand on.
--]]
local WRAPPED = 2147483647;

local function elapsed(stamp, now)
    now = now or os.clock();

    if (now < stamp) then
        return WRAPPED;
    end

    return now - stamp;
end

local saveAt = nil;

local function commitSoon()
    apply();

    saveAt = os.clock() + SAVE_DELAY;
end

local function pumpSave()
    if (saveAt == nil or elapsed(saveAt - SAVE_DELAY) < SAVE_DELAY) then
        return;
    end

    saveAt = nil;

    pcall(settings.save);
end

--[[
* Session state.
*
* Everything under `scan` is REPLACED wholesale by an answer, never merged, so
* a row from the last mob cannot survive into this one's table. `targid` is the
* identity of what is being shown; a window still holding it after a zone line
* is describing a stranger, which is why the zone handler clears it.
--]]
local state = {
    open     = T{ false },

    scan     = nil,        -- the finished answer being rendered
    building = nil,        -- the answer currently arriving

    wantTab  = nil,        -- a tab index the next frame should select, then forget

    inbound  = nil,        -- the verb of the envelope currently open
    inboundAt = 0,         -- when that envelope's d| arrived; the watchdog's anchor
    failed   = false,      -- an e| was raised inside the envelope currently open
    refused  = false,      -- an unknown protocol version was seen; stay silent
    spoke    = false,      -- a d| has arrived this session
    helloed  = false,      -- the blind handshake has already gone out
    reported = false,      -- a render error has already been reported once
    badRec   = false,      -- a malformed record has already been reported once
    caps     = nil,        -- the f| capability record, nil until a handshake answers

    -- Bumped on every committed answer. The render caches below key on it, so
    -- "the model moved" is one comparison rather than a deep compare of a
    -- table that is replaced wholesale anyway.
    scanRev  = 0,

    status    = 'Select a monster and press Scan.',
    statusBad = false,

    asked     = nil,       -- targid of the scan we are waiting on
    askedAt   = 0,
    tries     = 0,
    lastAuto  = nil,       -- targid the auto-scan last fired for

    -- A scan asked for before the server had spoken. Held rather than sent, and
    -- released by pumpPending on the first `d|` -- see requestScan.
    pending   = nil,
    pendingAt = 0,
};

--[[
* Outbound: one line per 1.2s with duplicate collapse -- the client rate-limits
* chat and a `!dwn` command IS a chat line. `readyAt` holds the queue shut for a
* moment after a zone line so a scan is not the first thing sent into a
* half-built zone.
--]]
local SEND_INTERVAL  = 1.2;
local ZONE_SETTLE    = 3.0;
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- A ceiling on the queue. Duplicate collapse already keeps the ordinary case
-- at one or two lines, and pumpAutoScan will not ask while an answer is
-- outstanding -- but "already bounded by the callers" is a claim about every
-- caller, and one is enough to make it false. A scan queue is one where the
-- NEWEST question is the interesting one, so an overflow drops the oldest
-- rather than refusing the click the player just made. (2026-09-06.)
local MAX_QUEUE = 8;

local queue    = T{ };
local lastSend = 0;
local readyAt  = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    while (#queue >= MAX_QUEUE) do
        table.remove(queue, 1);
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    -- Both through elapsed(): a wrapped clock must not hold the queue shut.
    if (elapsed(readyAt - ZONE_SETTLE, now) < ZONE_SETTLE or elapsed(lastSend, now) < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* The handshake. This is the ONE line the addon sends blind, and it is sent on
* window open rather than on load: an unknown `!command` falls through to
* ordinary /say, so an automatic hello against a server without the module is
* the player publicly saying "!dwn hello".
--]]
local function hello()
    -- LATCHED, because `issue`'s duplicate collapse only sees what is still IN
    -- the queue: a hello that has already been sent and popped would be sent
    -- again by the next caller. This is the one line the addon puts on the wire
    -- blind, so sending it twice is twice the cost of the only thing that can
    -- cost anything. Cleared on the zone line, where the server's per-session
    -- state dies and a fresh handshake is owed.
    if (state.helloed) then
        return;
    end

    state.helloed = true;

    issue('!dwn hello');
end

--[[
* Record parsing. Every record is pipe-separated with a single-character kind.
* Anything this addon does not recognise falls off the end of the chain rather
* than being an error: a server newer than the addon must not break it, which
* is the whole reason the `d|` record carries a version at all. Additive record
* kinds therefore never bump PROTOCOL.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function num(text, fallback)
    return tonumber(text or '') or fallback or 0;
end

local function blank()
    return {
        targid  = nil,
        name    = '?',
        level   = WITHHELD,
        lo      = WITHHELD,
        hi      = WITHHELD,
        con     = WITHHELD,
        flags   = 0,
        maxhp   = 0,
        maxmp   = 0,

        familyId = 0,
        ecoId    = 0,
        crystal  = 0,
        eco      = '',
        family   = '',

        detects    = 0,
        sight      = 0,
        sound      = 0,
        magic      = 0,
        aggro      = 0,
        link       = 0,
        linkRadius = 0,
        trueDetect = 0,
        respawn    = 0,
        spawnType  = 0,

        -- `l|`. Absent for everything that is not a lottery pop, so phCount
        -- -1 means "the server said nothing", which is not the same claim as
        -- phCount 0 ("lottery, and the server could not name a placeholder").
        phWindow   = 0,
        phCount    = -1,
        phNames    = '',

        exp     = WITHHELD,
        gilMin  = 0,
        gilMax  = 0,
        shown   = 0,
        total   = 0,
        mult    = 100,
        th      = 0,       -- the TH level the server says it computed the rates at

        -- PLAIN tables keyed by data. T{}'s sugar method names would shadow a
        -- key, which is the dwbags trap.
        resists = {},
        physical = {},
        immunities = {},
        drops   = {},
        skills  = {},
        quests  = {},
        notes   = {},
    };
end

local function applyIdentity(b, parts)
    -- tonumber directly, NOT num(..., nil): `x or nil or 0` collapses to
    -- `x or 0`, so num can never actually answer nil -- and 0 slips past the
    -- `targid ~= nil` re-scan guard as if it named a mob.
    b.targid = tonumber(parts[2] or '');
    b.level  = num(parts[3], WITHHELD);
    b.lo     = num(parts[4], WITHHELD);
    b.hi     = num(parts[5], WITHHELD);
    b.con    = num(parts[6], WITHHELD);
    b.flags  = num(parts[7], 0);
    b.maxhp  = num(parts[8], 0);
    b.maxmp  = num(parts[9], 0);
    b.name   = parts[10] or '?';
end

local function applyTaxonomy(b, parts)
    b.familyId = num(parts[2], 0);
    b.ecoId    = num(parts[3], 0);
    b.crystal  = num(parts[4], 0);
    b.eco      = parts[5] or '';
    b.family   = parts[6] or '';
end

local function applyAwareness(b, parts)
    b.detects    = num(parts[2], 0);
    b.sight      = num(parts[3], 0);
    b.sound      = num(parts[4], 0);
    b.magic      = num(parts[5], 0);
    b.aggro      = num(parts[6], 0);
    b.link       = num(parts[7], 0);
    b.linkRadius = num(parts[8], 0);
    b.trueDetect = num(parts[9], 0);
    b.respawn    = num(parts[10], 0);
    b.spawnType  = num(parts[11], 0);
end

--[[
* `l|` -- the lottery a notorious monster is the prize of (1.5.0, 2026-09-16).
*
* WHY IT EXISTS. A lottery NM has no respawn of its own: it takes a
* PLACEHOLDER'S slot when a roll goes its way, and the server arms it on the
* placeholder's clock. `respawn` therefore used to read back as the
* placeholder's window -- five minutes for the four Fei'Yin Shadows -- and
* this window printed "Respawn: 5 min 0 sec." about a monster that can be
* days apart. A player camped it for hours on that sentence and filed a
* report, which is the correct response to being lied to.
*
* The server now sends 0 in `respawn` for a lottery mob and puts the
* placeholder's real window here. What it CANNOT send is the roll chance or
* the post-death lockout: those live only as arguments inside the
* placeholder's own Lua call and nothing indexes them. So this window says
* what is known and stops, rather than inventing a percentage.
--]]
local function applyLottery(b, parts)
    b.phWindow = num(parts[2], 0);
    b.phCount  = num(parts[3], 0);
    b.phNames  = parts[4] or '';
end

local function applyYield(b, parts)
    b.exp    = num(parts[2], WITHHELD);
    b.gilMin = num(parts[3], 0);
    b.gilMax = num(parts[4], 0);
    b.shown  = num(parts[5], 0);
    b.total  = num(parts[6], 0);
    b.mult   = num(parts[7], 100);

    -- The TH level the server COMPUTED at, which is the only number the label
    -- may state. A server from before this field (or one that ignored the
    -- argument) reads as 0 here, and the window then says TH 0 no matter what
    -- the dropdown asked for -- honest rather than flattering.
    b.th     = num(parts[8], 0);
end

--[[
* `r|` carries `<element>:<sdt>:<rank>` entries. Element 0 and 9 are the
* physical lanes rather than elements -- 0 is slash/pierce and 9 is
* hand-to-hand/impact -- so they are kept apart from the eight rather than
* being drawn as if they had a resistance rank they do not have.
--]]
local function applyResists(b, packed)
    for _, entry in ipairs(split(packed or '', ',')) do
        if (entry ~= '') then
            local bits    = split(entry, ':');
            local element = num(bits[1], -1);
            local sdt     = num(bits[2], 0);
            local rank    = num(bits[3], 0);

            if (element == 0) then
                b.physical.slash  = sdt;
                b.physical.pierce = rank;
            elseif (element == 9) then
                b.physical.hth    = sdt;
                b.physical.impact = rank;
            elseif (ELEMENTS[element] ~= nil) then
                b.resists[element] = { sdt = sdt, rank = rank };
            end
        end
    end
end

--[[
* CEILINGS ON THE LISTS AN ANSWER GROWS (2026-09-06).
*
* Every packed record kind appends, and how many records an envelope carries is
* the SERVER's business rather than this addon's: the drop list stops where the
* line budget stops, the quest list stops at twelve, and those are the caps the
* window reports. These are not those. These are the point past which an
* envelope has stopped being an answer at all -- a stuck emitter, or a build
* that streams `p|` in a loop, is otherwise a table that grows for as long as
* the packets keep coming and a drop table redrawn from all of it sixty times a
* second. (Bursts need ceilings.)
*
* Generous by an order of magnitude on purpose. Reaching one of these is a
* server fault, and silently truncating a real answer would be the worse bug.
--]]
local MAX_LIST_ROWS = 256;
local MAX_NOTES     = 8;

local function applyImmunities(b, packed)
    for _, entry in ipairs(split(packed or '', ',')) do
        if (entry ~= '' and #b.immunities < MAX_LIST_ROWS) then
            b.immunities[#b.immunities + 1] = entry;
        end
    end
end

local function applyDrops(b, packed)
    for _, entry in ipairs(split(packed or '', ',')) do
        if (entry ~= '' and #b.drops < MAX_LIST_ROWS) then
            local bits = split(entry, ':');

            b.drops[#b.drops + 1] = {
                itemid = num(bits[1], 0),
                kind   = bits[2] or 'n',
                rate   = num(bits[3], 0),
                group  = num(bits[4], 0),
            };
        end
    end
end

local function applySkills(b, packed)
    for _, entry in ipairs(split(packed or '', ',')) do
        if (entry ~= '' and #b.skills < MAX_LIST_ROWS) then
            b.skills[#b.skills + 1] = entry;
        end
    end
end

local function applyQuest(b, parts)
    if (#b.quests >= MAX_LIST_ROWS) then
        return;
    end

    b.quests[#b.quests + 1] = {
        kind  = parts[2] or 'q',
        area  = num(parts[3], 0),
        id    = num(parts[4], 0),
        state = parts[5] or '-',
        name  = parts[6] or '?',
    };
end

local function handleRecord(line)
    -- A refusal is silence. The packets are still blocked (that happens before
    -- this function is reached), so a mismatched server cannot spill records
    -- into the chat log either.
    if (state.refused) then
        return;
    end

    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.refused   = true;
            state.inbound   = nil;
            state.failed    = false;
            state.building  = nil;
            state.status    = 'This server speaks a scan protocol this addon does not.';
            state.statusBad = true;

            --[[
            * AND THE ASK IN FLIGHT IS RETIRED WITH IT (2026-09-06).
            *
            * Without this the answer clock kept aging a scan nobody was ever
            * going to answer. Five seconds later pumpAnswer re-issued
            * `!dwn scan` to the very server this addon had just refused, and
            * five after that it overwrote the accurate "Update dwscan"
            * banner with "The server did not answer. Is this DriftwoodXI...?"
            * -- the one sentence that sends a player looking in exactly the
            * wrong place, on the one occasion the addon knows precisely what
            * is wrong. Retired here rather than guarded inside pumpAnswer so
            * the banner is the last word and there is nothing left to age.
            --]]
            state.asked     = nil;
            state.tries     = 0;
            state.pending   = nil;

            print(chat.header('dwscan'):append(chat.error(string.format(
                'server scan protocol %d, addon expects %d. Update dwscan through the launcher.',
                version, PROTOCOL))));

            return;
        end

        state.spoke     = true;
        state.inbound   = parts[3];
        state.inboundAt = os.clock();
        state.failed    = false;

        -- A scan replaces the whole model, and the reset runs FIRST: this
        -- function is called under a pcall, and a throw after `inbound` is set
        -- must cost one record rather than leave half of the last mob's answer
        -- in place for the records behind it to merge into.
        if (state.inbound == 'scan') then
            state.building = blank();
        end

        return;
    end

    -- Records outside an envelope are not ours to act on.
    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        if (state.inbound == 'scan' and state.building ~= nil and not state.failed) then
            state.scan      = state.building;
            state.scanRev   = state.scanRev + 1;
            state.asked     = nil;
            state.status    = '';
            state.statusBad = false;
        end

        -- Whatever the envelope was, it is over: a half-built answer that did
        -- not commit must not be left lying around for a later stray `m|` to
        -- append a note to.
        state.building = nil;
        state.inbound  = nil;
        state.failed   = false;

        return;
    end

    -- `m|` and `e|` may arrive anywhere, including in a `status` envelope of
    -- their own when the refusal was raised before a scan ever opened.
    if (kind == 'm') then
        if (state.building ~= nil) then
            if (#state.building.notes < MAX_NOTES) then
                state.building.notes[#state.building.notes + 1] = parts[2] or '';
            end
        elseif (not state.failed) then
            state.status    = parts[2] or '';
            state.statusBad = false;
        end

        return;
    end

    if (kind == 'e') then
        state.status    = parts[2] or 'The server refused.';
        state.statusBad = true;
        state.asked     = nil;

        --[[
        * AND THE ENVELOPE IT ARRIVED IN IS OVER (2026-09-06).
        *
        * An `e|` raised mid-answer used to leave `building` in place for the
        * `z|` behind it to commit, and the window then rendered half a mob as
        * though it were whole. That is worse than it sounds, because a
        * blank() reads as a series of confident sentences: an `a|` that never
        * arrived is "Never aggressive -- it will not start a fight", a `y|`
        * that never arrived is "No gil", a missing respawn is "not on a
        * timer". The window was stating facts about a mob the server had just
        * said it could not read. Worse still, the `z|` commit clears the
        * status line, so the sentence explaining the failure was wiped by the
        * record that followed it.
        *
        * Dropping the partial and latching `failed` for the rest of the
        * envelope is what makes the refusal the last word: `z|` will not
        * commit it and a trailing `m|` will not talk over it.
        --]]
        state.building = nil;
        state.failed   = true;

        return;
    end

    if (kind == 'f') then
        -- Capabilities. A section whose binding is missing is greyed with the
        -- reason rather than drawn empty, so "the server cannot answer this"
        -- never looks like "there is nothing here".
        state.caps = {
            drops  = num(parts[2], 0) == 1,
            facts  = num(parts[3], 0) == 1,
            quests = num(parts[4], 0) == 1,

            -- The highest TH tier the server's bracket table holds. The
            -- dropdown is built from THIS, never from a local copy of the
            -- table -- a retune server-side resizes the dropdown by itself.
            -- 0 from an older server collapses the dropdown to TH 0, which is
            -- the only level that server can answer anyway.
            maxth  = num(parts[5], 0),
        };

        return;
    end

    local b = state.building;

    if (b == nil) then
        return;
    end

    if     (kind == 'h') then applyIdentity(b, parts);
    elseif (kind == 't') then applyTaxonomy(b, parts);
    elseif (kind == 'a') then applyAwareness(b, parts);
    elseif (kind == 'l') then applyLottery(b, parts);
    elseif (kind == 'y') then applyYield(b, parts);
    elseif (kind == 'r') then applyResists(b, parts[2]);
    elseif (kind == 'x') then applyImmunities(b, parts[2]);
    elseif (kind == 'p') then applyDrops(b, parts[2]);
    elseif (kind == 'k') then applySkills(b, parts[2]);
    elseif (kind == 'q') then applyQuest(b, parts);
    end
end

--[[
* Wide Scan (1.2.0). A modernised Wide Scan list: searchable, sortable,
* paged -- and CLICKING A ROW STARTS THE GAME'S OWN MAP TRACKING, because the
* whole feature is the retail packet flow driven from a window:
*
*   out 0x0F4 (SendFlg=1)  ask for the list -- byte-identical to opening the
*                          native Wide Scan menu (every job widescans here)
*   in  0x0F6              ListStart/ListEnd brackets around the answer
*   in  0x0F4              one entry per entity: targid, level, type, and
*                          x/z as int16 OFFSETS from the player, whole yalms
*   out 0x0F5 (ActIndex)   start tracking -- byte-identical to the native
*                          list's Track option; the server latches
*                          WideScanTarget and pushes the /map dot from then on
*   in  0x0F5              the server's tracking pushes; State 1 confirms who
*                          is tracked, 2/3 says the track was lost or ended
*   out 0x0F6              stop tracking
*
* No `!dwn` verb, no protocol motion, no server half: the addon can never do
* anything the native Wide Scan menu cannot (dwn_protocol.md's discipline,
* one layer down). The native menu still works, and its answers populate
* this tab too -- the brackets and entries are the same packets whoever
* asked for them.
*
* NAMES ARE THE ONE GAP: the server's list entries carry a zeroed sName (the
* memcpy is commented out upstream), so the native menu reads names from the
* zone's NPC-list DAT -- and so does this tab, the filterscan recipe: 0x20-byte
* records of name[28] + id u32, targid = id & 0xFFF. The entity table is the
* fallback (it only knows nearby spawns), then a literal #targid.
--]]
local widescan = {
    rows      = T{ },      -- the live list: { idx, level, type, x, z, dist }
    pending   = nil,       -- the list being assembled between the 0x0F6 brackets
    tracking  = 0,         -- targid the SERVER says it is tracking (0 = none)
    askedAt   = 0,         -- last 0x0F4 injection, for the throttle
    scannedAt = 0,         -- when the live list last swapped in
    names     = nil,       -- targid -> name, from the zone NPC-list DAT
    -- A Rescan the throttle could not honour yet. HELD rather than dropped,
    -- which is the rule the chat queue already follows one file over -- see
    -- requestWideScan.
    wanted    = false,

    -- Bumped whenever `rows` is replaced, which is the only way it ever
    -- changes. The filtered view below keys on it rather than re-deriving
    -- itself from a list that has not moved.
    rev       = 0,

    -- Resolved display names, keyed by targid, thrown away with each new list
    -- (see applyWideScanState). NOT held across a scan: the entity-table
    -- fallback answers nothing for a mob that has not spawned client-side yet,
    -- and caching that miss forever would freeze an honest `#292` in place
    -- long after the thing walked into view.
    nameCache = { },
};

--[[
* A ceiling on the list, and it is about the pathological case rather than the
* ordinary one. A widescan answer is the zone's own roster inside range -- a
* busy camp is a hundred-odd rows and that is fine. What has no natural bound
* is the ASSEMBLY: entries arrive one packet at a time and the ListEnd bracket
* that ends them can simply not arrive (a dropped packet, an addon loaded
* mid-answer), at which point an append with no cap is a table that grows for
* as long as the zone keeps answering. (Bursts need ceilings; 2026-09-06.)
--]]
local WS_MAX_ROWS = 512;

-- Little-endian readers over packet strings. `offset` is the ZERO-based byte
-- offset the packet docs use; string.byte is 1-based, hence the +1. No
-- `struct` on purpose: these four lines are the whole dependency.
local function packetU8(data, offset)
    return data:byte(offset + 1);
end

local function packetU16(data, offset)
    local lo, hi = data:byte(offset + 1, offset + 2);

    if (lo == nil or hi == nil) then
        return nil;
    end

    return lo + hi * 256;
end

local function packetI16(data, offset)
    local value = packetU16(data, offset);

    if (value == nil) then
        return nil;
    end

    return value >= 0x8000 and value - 0x10000 or value;
end

--[[
* The zone NPC-list DAT, keyed by targid. Loaded on the zone line (and lazily
* on the first draw after an addon reload mid-session). A DAT that cannot be
* read is not an error -- names fall back to the entity table and a literal.
--]]
local function loadZoneNames(zoneId, zoneSubId)
    widescan.names = nil;

    local okDats, dats = pcall(require, 'ffxi.dats');

    if (not okDats or dats == nil) then
        return;
    end

    local ok = pcall(function ()
        local file = dats.get_zone_npclist(zoneId, zoneSubId);

        if (file == nil or file:len() == 0) then
            return;
        end

        local f = io.open(file, 'rb');

        if (f == nil) then
            return;
        end

        local size = f:seek('end');
        f:seek('set', 0);

        if (size == 0 or size % 0x20 ~= 0) then
            f:close();
            return;
        end

        local names = { };

        for _ = 1, size / 0x20 do
            local record = f:read(0x20);
            local name   = record:sub(1, 28):gsub('%z.*$', '');
            local id     = packetU16(record, 28) + packetU16(record, 30) * 65536;

            if (name ~= '') then
                names[bit.band(id, 0x0FFF)] = name;
            end
        end

        f:close();

        widescan.names = names;
    end);

    if (not ok) then
        widescan.names = nil;
    end
end

-- Lazy names for a mid-session addon reload: no zone packet will come, so ask
-- the party table which zone this is, once, on the first draw that needs it.
local function ensureZoneNames()
    if (widescan.names ~= nil) then
        return;
    end

    pcall(function ()
        local party = AshitaCore:GetMemoryManager():GetParty();

        if (party ~= nil and party:GetMemberIsActive(0) > 0) then
            loadZoneNames(party:GetMemberZone(0), 0);
        end
    end);

    -- Whatever happened above, do not retry every frame: an unreadable DAT
    -- stays unreadable, and the fallbacks below are perfectly serviceable.
    if (widescan.names == nil) then
        widescan.names = { };
    end
end

-- One entry off an incoming 0x0F4. The brackets normally open the pending
-- list first; an entry with no open bracket starts one anyway, so a native
-- menu scan whose ListStart we missed (addon loaded mid-answer) still lands.
local function applyWideScanEntry(data)
    local idx = packetU16(data, 0x04);

    if (idx == nil or idx == 0) then
        return;
    end

    if (widescan.pending == nil) then
        widescan.pending = T{ };
    end

    if (#widescan.pending >= WS_MAX_ROWS) then
        return;
    end

    local x = packetI16(data, 0x08) or 0;
    local z = packetI16(data, 0x0A) or 0;

    widescan.pending:append({
        idx   = idx,
        level = packetU8(data, 0x06) or 0,
        -- Type is objtype/2: 1 NPC (the green dot), 2 mob (the red dot).
        type  = bit.band(packetU8(data, 0x07) or 0, 0x07),
        x     = x,
        z     = z,
        dist  = math.sqrt(x * x + z * z),
    });
end

-- The 0x0F6 brackets. ListEnd swaps the pending list in wholesale -- the
-- scan.building discipline one packet family over: a half-arrived list is
-- never what the table renders.
local function applyWideScanState(data)
    local bracket = packetU8(data, 0x04);

    if (bracket == 1) then
        widescan.pending = T{ };
    elseif (bracket == 2) then
        if (widescan.pending ~= nil) then
            widescan.rows      = widescan.pending;
            widescan.rev       = widescan.rev + 1;
            widescan.nameCache = { };
            widescan.pending   = nil;
            widescan.scannedAt = os.clock();
        end
    end
end

-- The server's own tracking pushes (0x0F5 in): State 1 names the tracked
-- targid, 2/3 says the track was lost or ended. The server is the authority
-- -- a click only proposes; this is what confirms, so the row highlight can
-- never disagree with the dot on /map.
local function applyWideScanTrack(data)
    local idx      = packetU16(data, 0x12);
    local trackBit = packetU8(data, 0x14);

    if (trackBit == 1 and idx ~= nil and idx ~= 0) then
        widescan.tracking = idx;
    elseif (trackBit == 2 or trackBit == 3) then
        widescan.tracking = 0;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017.
*
* Layout after the 4-byte header: Kind at 0x04, Attr at 0x05, Data at 0x06,
* sName[15] at 0x08, Mes at 0x17. Any line whose sender is _DWNDATA is ours.
*
* The addon owns the line WHATEVER happens to be in it, so it is blocked before
* parsing rather than after: a malformed record must not leak into the chat log
* as noise, and a record that throws must not leak either.
--]]
ashita.events.register('packet_in', 'dwscan_packet_in', function (e)
    -- The Wide Scan family rides the same registration (the harness pins the
    -- handler roster, and a third packet_in hook would be a new name for the
    -- same job). Never blocked: the native Wide Scan menu is reading these
    -- exact packets too, and this tab is a second reader, not an owner.
    if (e.id == 0x00F4 or e.id == 0x00F5 or e.id == 0x00F6) then
        pcall(function ()
            local data = e.data_modified or e.data;

            if (data == nil) then
                return;
            end

            if (e.id == 0x00F4) then
                applyWideScanEntry(data);
            elseif (e.id == 0x00F6) then
                applyWideScanState(data);
            else
                applyWideScanTrack(data);
            end
        end);

        return;
    end

    if (e.id ~= 0x0017) then
        return;
    end

    -- `data_modified or data`, the same fallback the Wide Scan branch above
    -- uses: an addon ahead of this one in the chain that hands the packet on
    -- without a modified copy would otherwise be a Lua error PER PACKET here,
    -- and this handler is not inside a pcall until three lines further down.
    local data = e.data_modified or e.data;

    if (data == nil) then
        return;
    end

    local sender = data:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = data:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    --[[
    * REPORTED ONCE, then silence until the zone line (2026-09-06).
    *
    * Whatever makes one record throw makes the next one throw too -- a wire
    * this addon has misread is misread the same way every line -- so this was
    * a chat line per RECORD, and a scan is a dozen records. The protocol
    * refusal two functions down already answers "one message, then silence"
    * for the same shape of fault; this is that answer for the shape nobody
    * anticipated. The zone line clears it because a map restart on the other
    * side of one may be a different build.
    --]]
    if (not ok and not state.badRec) then
        state.badRec = true;

        print(chat.header('dwscan'):append(chat.error('bad record: ' .. tostring(err))));
        print(chat.header('dwscan'):append(chat.message('Further bad records this zone are not reported. !scan still works, typed.')));
    end
end);

--[[
* A zone line is a new entity table: every targid means a different mob, or
* nothing. The answer on screen is about a stranger now, so it goes.
*
* The refusal latch is cleared here too. A map restart logs everyone out, so
* the server on the other side of a zone line may well be the updated one.
--]]
ashita.events.register('packet_in', 'dwscan_zonein', function (e)
    if (e.id ~= 0x000A) then
        return;
    end

    state.scan      = nil;
    state.scanRev   = state.scanRev + 1;
    state.building  = nil;
    state.inbound   = nil;
    state.failed    = false;
    state.refused   = false;
    state.badRec    = false;
    state.asked     = nil;
    state.pending   = nil;
    state.helloed   = false;
    state.lastAuto  = nil;
    state.status    = 'Select a monster and press Scan.';
    state.statusBad = false;

    -- AND THE OUTBOUND QUEUE, which the reset above forgot. Every line this
    -- addon queues is targid-scoped, and a targid means nothing across a zone
    -- line -- so a scan queued just before zoning fired into the new zone and
    -- asked about whatever now happens to hold that number. Drained in place
    -- rather than reassigned: issue() and pumpQueue close over this upvalue.
    -- Dropping a queued `!dwn hello` is safe and self-healing; helloed was
    -- just set false above, so the next request re-issues it.
    while (#queue > 0) do
        table.remove(queue);
    end

    readyAt = os.clock() + ZONE_SETTLE;

    -- The Wide Scan list is targid-scoped exactly like everything above, and
    -- the server clears its own WideScanTarget on zone leave -- mirror it.
    -- The zone id and sub id ride this very packet (0x30/0x9E, the
    -- filterscan offsets; 0x80 is the mog-house byte, whose zone has no
    -- NPC list worth loading), so this is also where the name DAT reloads.
    widescan.rows      = T{ };
    widescan.rev       = widescan.rev + 1;
    widescan.nameCache = { };
    widescan.pending   = nil;
    widescan.tracking  = 0;
    widescan.wanted    = false;
    widescan.askedAt   = 0;
    widescan.scannedAt = 0;
    widescan.names     = nil;

    pcall(function ()
        local data = e.data_modified or e.data;

        if (data ~= nil and #data >= 0xA0 and packetU8(data, 0x80) ~= 1) then
            loadZoneNames(packetU16(data, 0x30), packetU16(data, 0x9E));
        end
    end);
end);

--[[
* The client's current target, as a targid.
*
* Ashita's entity index IS the server targid, which is what makes a scan
* addressable at all: the client already knows the number the server will
* resolve. Index 0 is "nothing selected" and no mob is ever index 0.
--]]
--[[
* AND BOTH READERS BELOW ARE PCALL'D (2026-09-06), which is not the belt and
* braces it looks like.
*
* These two are asked from `d3d_present` itself -- the frame handler reads them
* before the theme is pushed, and pumpAnswer and requestScan ask again for the
* cursor-path election -- so they run OUTSIDE the render pcall that catches
* everything else in this file. Ashita's managers answer nil for "not ready"
* and both functions already handle that; what they did not handle is a manager
* that does not answer AT ALL, which is a Lua error sixty times a second with
* no window to close, nothing on screen to explain it, and the frame handler
* dead for the rest of the session.
*
* Written as two plain locals called through pcall rather than as `pcall(
* function() ... end)`: a closure with an upvalue is allocated on every call,
* and these run once a frame each.
--]]
local function readTargetIndex()
    local memory = AshitaCore:GetMemoryManager();

    if (memory == nil) then
        return 0;
    end

    local target = memory:GetTarget();

    if (target == nil or target:GetIsActive(0) == 0) then
        return 0;
    end

    return target:GetTargetIndex(0);
end

local function currentTarget()
    local ok, index = pcall(readTargetIndex);

    -- The type test is the same guard in a second place: this number reaches
    -- `string.format('!dwn scan %d ...')` on a path with no pcall around it.
    if (not ok or type(index) ~= 'number') then
        return 0;
    end

    return index;
end

local function readEntityName(index)
    local memory = AshitaCore:GetMemoryManager();
    local entity = memory ~= nil and memory:GetEntity() or nil;

    if (entity == nil) then
        return nil;
    end

    return entity:GetName(index);
end

local function targetName(index)
    if (index == nil or index == 0) then
        return nil;
    end

    local ok, name = pcall(readEntityName, index);

    if (not ok or type(name) ~= 'string' or name == '') then
        return nil;
    end

    return name;
end

--[[
* Wide Scan outbound. Injected packets, not chat lines -- these are the exact
* bytes the native Wide Scan menu sends (8 bytes: header, then one u32), so
* they ride no chat throttle and reach any FFXI server. The header's second
* byte is the size in dwords shifted left once: 0x04 = 2 dwords = 8 bytes.
*
* The refresh throttle exists because a scan is a full list from the server
* (easily 100+ entries in a camp) and holding the button should not be a
* packet stream. The zone settle gate is shared with the chat queue: the
* client ignores most of the world while the load screen is up, and the
* server refuses both packets mid-event anyway.
--]]
local WS_REFRESH_INTERVAL = 2.0;  -- seconds between 0x0F4 asks, however asked
local WS_AUTO_INTERVAL    = 5.0;  -- the auto-refresh cadence, tab visible only

local function injectPacket(id, bytes)
    pcall(function ()
        AshitaCore:GetPacketManager():AddOutgoingPacket(id, bytes);
    end);
end

--[[
* A REFUSED ASK IS HELD, NOT DROPPED (2026-09-06).
*
* The throttle is real and has to stay -- a widescan answer is the zone's whole
* roster and holding the button should not be a packet stream -- but a press
* inside it used to vanish. Rescan is a live-looking button that answered
* nothing for up to two seconds, and after a zone line for three more, which
* reads as a broken window rather than as a rate limit; it is the same fault
* the paging arrows were given BeginDisabled for, and the same answer the chat
* queue gives: the ask waits its turn instead of being thrown away.
*
* Released from the top of the tab's own draw, so it can only ever fire while
* the player is looking at the list it refreshes, and cleared by the zone line
* with the rest of the widescan state.
--]]
local function requestWideScan()
    local now = os.clock();

    -- Through elapsed(): a wrapped clock read as "inside the throttle" for
    -- good, and a held ask is then a Rescan that never fires.
    if (elapsed(readyAt - ZONE_SETTLE, now) < ZONE_SETTLE or elapsed(widescan.askedAt, now) < WS_REFRESH_INTERVAL) then
        widescan.wanted = true;

        return;
    end

    widescan.wanted  = false;
    widescan.askedAt = now;

    -- SendFlg must be exactly 1 -- the server validates it.
    injectPacket(0xF4, { 0xF4, 0x04, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00 });
end

local function requestTrack(idx)
    if (idx == nil or idx < 1 or idx > 0x0FFF) then
        return;
    end

    injectPacket(0xF5, {
        0xF5, 0x04, 0x00, 0x00,
        bit.band(idx, 0xFF), bit.band(math.floor(idx / 256), 0xFF), 0x00, 0x00,
    });

    -- Optimistic: the row highlights now, and the server's own 0x0F5 push
    -- (applyWideScanTrack) confirms or corrects it a moment later. A target
    -- out of widescan range is simply never confirmed.
    widescan.tracking = idx;
end

local function requestTrackStop()
    injectPacket(0xF6, { 0xF6, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 });

    widescan.tracking = 0;
end

--[[
* Names, best source first: the zone DAT (covers the whole list), the entity
* table (covers whatever is near enough to be spawned client-side), then the
* targid itself -- an honest label, and still clickable for tracking.
*
* CACHED PER LIST (2026-09-06). The name sort asks for a name on BOTH sides of
* every comparison, and the filter asks for one per row: a hundred-row camp was
* something like fourteen hundred resolutions a frame, each of them an entity
* binding call and a fresh formatted string, eighty thousand a second to draw
* fifty rows that had not changed. The cache is thrown away whenever a new list
* swaps in (applyWideScanState) rather than held for the zone, so a mob that
* was out of client range on one scan and spawned by the next is named on the
* next -- which is the only case where a cached miss would have been wrong.
--]]
local function wideScanName(idx)
    local cached = widescan.nameCache[idx];

    if (cached ~= nil) then
        return cached;
    end

    local name = widescan.names ~= nil and widescan.names[idx] or nil;

    if (name == nil) then
        name = targetName(idx);
    end

    if (name == nil) then
        name = string.format('#%d', idx);
    end

    widescan.nameCache[idx] = name;

    return name;
end

--[[
* Ask. Every click issues a line a player could type, and the server re-resolves
* the targid in its own zone whichever way the command arrived -- so a bug in
* this window cannot make it answer about anything `!scan` would refuse.
--]]
local function requestScan(targid)
    if (state.refused) then
        return;
    end

    if (targid == nil or targid == 0) then
        state.status    = 'Select a monster first.';
        state.statusBad = true;

        return;
    end

    --[[
    * NOT SENT UNTIL THE SERVER HAS SPOKEN, and the scan is HELD rather than
    * dropped so the happy path is unchanged.
    *
    * `hello` is the one line this addon is sanctioned to send blind. Everything
    * else waits for a `d|`, because an unknown `!command` falls through to
    * ordinary /say (0x0b5_chat_std.cpp:121) -- so on a server whose dwn.lua is
    * absent, a launcher release that landed ahead of a server deploy, or any
    * non-Driftwood server the boot script loaded this into, an ungated scan is
    * the player publicly saying "!dwn scan 4242" to the whole zone. Worse, they
    * never see it: dwecho blocks the local echo of our own lines, so the only
    * thing on their screen is "The server did not answer."
    *
    * Holding it costs one round trip on the very first scan of a session and
    * nothing afterwards -- and it is the rule dwn_protocol.md's client
    * discipline 1 states, which pumpAutoScan already honours and this path did
    * not.
    --]]
    if (not state.spoke) then
        state.pending   = targid;
        state.pendingAt = os.clock();
        state.status    = 'Waiting for the server...';
        state.statusBad = false;

        hello();

        return;
    end

    state.pending   = nil;
    state.asked     = targid;
    state.askedAt   = os.clock();
    state.tries     = 1;
    state.status    = 'Scanning...';
    state.statusBad = false;

    -- The TH level rides the QUESTION, because the server owns the arithmetic:
    -- this addon never rescales a rate, it asks for the table at a different
    -- level and renders what comes back (client discipline 2). The server
    -- clamps it against its own bracket table.
    --
    -- A scan of the CURRENT target rides the cursor path (`scan 0`), which
    -- the server deliberately leaves ungated: a mob that died while still
    -- selected keeps answering (its alive bit going dark is a real thing to
    -- be told, and the by-id path refuses before the 'dead' mark can ever be
    -- seen), and the by-id path refuses past 50 yalms with "...or just
    -- target it" -- advice that is useless when the thing IS targeted. An
    -- explicit id is kept for everything else.
    local wireId = (targid == currentTarget()) and 0 or targid;

    issue(string.format('!dwn scan %d %d', wireId, config.thLevel or 0));

    --[[
    * AND THE HANDSHAKE THE ZONE LINE OWES (2026-09-06).
    *
    * `helloed` is cleared on 0x000A, and the comment on that latch says why in
    * so many words: "the server's per-session state dies and a fresh handshake
    * is owed". Nothing ever paid it. hello() had exactly two callers -- opening
    * the window, and a scan asked for before the server had spoken -- and
    * `spoke` is NOT cleared by a zone line, so after zoning every scan went
    * straight out and the capability record stayed whatever the FIRST handshake
    * of the session said. That matters for a handshake answered while the map
    * was still coming up: the C++ scan bindings register about two seconds
    * after the Lua modules, so a window opened inside that window is told
    * drops=0 and greys the Drops tab -- correctly at the time, and then for the
    * rest of the session, with no way back but an addon reload.
    *
    * It rides the scan rather than the zone line so the addon still only ever
    * speaks when asked, and it is issued AFTER the scan so the answer the
    * player is waiting for is not delayed by the send throttle. The latch
    * makes it one line per zone at most, and only for a player who scans.
    --]]
    hello();
end

--[[
* Answer tracking: ask once, retry once on a 5s silence, then stop and say so.
* A retry that never terminates is a command loop, and this one is a chat line
* per attempt.
--]]
local function pumpAnswer()
    if (state.asked == nil) then
        return;
    end

    -- A held send (zone-in) leaves the line queued; aging the answer clock
    -- against it would be a false timeout, and after ANSWER_TRIES a false
    -- "The server did not answer." (dwecho canSend; 2026-08-15.)
    --
    -- RE-STAMPED, not merely skipped (Phase 2, 2026-09-06 -- the dwarena
    -- 1.1.0 finding): os.clock() runs through the load screen whether or not
    -- the test below does, so a bare return here meant the retry fired the
    -- instant zoning ended and collapsed into the line still queued -- the
    -- ask had spent its retry before the server was asked once.
    if (not echo.canSend()) then
        state.askedAt = os.clock();

        return;
    end

    local waited = elapsed(state.askedAt);

    if (waited < ANSWER_TIMEOUT) then
        return;
    end

    if (state.tries >= ANSWER_TRIES) then
        state.asked = nil;

        if (not state.spoke) then
            state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
            state.statusBad = true;
        else
            state.status    = 'No answer. Try again.';
            state.statusBad = true;
        end

        return;
    end

    state.tries   = state.tries + 1;
    state.askedAt = os.clock();

    -- Same cursor-path election as requestScan.
    local wireId = (state.asked == currentTarget()) and 0 or state.asked;

    issue(string.format('!dwn scan %d %d', wireId, config.thLevel or 0));
end

--[[
* AN ENVELOPE THAT NEVER CLOSED IS CLOSED HERE (2026-09-06).
*
* `inbound` is set by `d|` and cleared by `z|`, and a 0x017 dropped between the
* two leaves it set for the rest of the session -- the dwah 1.6.0 incident, one
* wire over. Two things then go wrong and neither raises anything. A stray `m|`
* is filed as a NOTE on a half-built answer instead of as the status line it
* was sent as. And a LATER answer whose own `d|` was the packet that went
* missing has its records merged into the previous mob's leftovers, and the
* `z|` behind it commits the two of them as one mob -- a window stating this
* one's drops beside that one's level, with nothing anywhere saying so.
*
* An answer is a handful of records written inside one server tick, so any gap
* worth measuring here is already a failure. The timeout is generous on purpose:
* it is a floor under "this cannot still be arriving", not a deadline.
*
* Silent, because the answer clock owns the sentence: an ask still in flight is
* about to be retried or about to say "No answer", and an ask that already gave
* up has said its piece.
--]]
local ENVELOPE_TIMEOUT = 10.0;

local function pumpEnvelope()
    if (state.inbound == nil) then
        return;
    end

    if (elapsed(state.inboundAt) < ENVELOPE_TIMEOUT) then
        return;
    end

    state.inbound  = nil;
    state.building = nil;
    state.failed   = false;
end

--[[
* Release a scan that was asked for before the server had spoken.
*
* It terminates in both directions, which is the only thing that makes holding
* it safe: the first `d|` sends it, and a hello that is never answered gives up
* after the same 5s the answer tracker uses and says so. A pending scan that
* could sit forever would be a window stuck on "Waiting for the server..." with
* no way out but a reload.
--]]
local function pumpPending()
    if (state.pending == nil) then
        return;
    end

    if (state.refused) then
        state.pending = nil;

        return;
    end

    if (state.spoke) then
        local targid = state.pending;

        state.pending = nil;

        requestScan(targid);

        return;
    end

    -- While a send is held (zone-in) the hello cannot go out, so measure the
    -- give-up from when a line can actually be sent rather than from the queued
    -- ask -- there is no retry here to re-stamp it. (dwecho canSend; 2026-08-15.)
    if (not echo.canSend()) then
        state.pendingAt = os.clock();
    elseif (elapsed(state.pendingAt) >= ANSWER_TIMEOUT) then
        state.pending   = nil;
        state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
        state.statusBad = true;
    end
end

--[[
* Item names and icons come out of the CLIENT's own resources, which is why no
* item name is ever on the wire: the server's `item_basic.name` is the internal
* snake_case form, and the client already holds the real one -- and the icon.
--]]
local icons = T{ };

local function resourceOf(itemId)
    if (itemId == nil or itemId <= 0 or itemId == 65535) then
        return nil;
    end

    return AshitaCore:GetResourceManager():GetItemById(itemId);
end

--[[
* Item names, cached by id (the dwah pattern).
*
* The drop table is redrawn every frame and this was a resource-manager lookup
* per row per frame -- a forty-eight-row Dynamis boss at sixty frames a second
* is nearly three thousand lookups a second for names that cannot change. The
* cache is keyed on the id alone because an item's name is a CLIENT resource,
* not server state: nothing that arrives on this wire can invalidate it.
*
* Only a resolved name is cached. The `item %d` fallback is what an id the
* client cannot resolve looks like before login has finished handing the
* resource manager its DATs, and caching that would freeze a real item's row as
* a number for the rest of the session.
--]]
local itemNames = { };

local function itemName(itemId)
    if (itemId == nil) then
        return 'item ?';
    end

    local cached = itemNames[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item = resourceOf(itemId);

    if (item == nil or item.Name[1] == nil or item.Name[1]:len() == 0) then
        return string.format('item %d', itemId);
    end

    itemNames[itemId] = item.Name[1];

    return item.Name[1];
end

--[[
* Cached, because a drop table is forty rows redrawn every frame and
* D3DXCreateTextureFromFileInMemoryEx is not free. gc_safe_release hands back a
* texture that releases itself when Lua collects it, which is what keeps this
* from leaking across a reload. (The dwbags implementation, unchanged.)
--]]
local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);

    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* The client's own description card for a drop row, the dwah/dwbags shape. It
* is the answer to the question the drop table cannot answer by itself -- "is
* this thing worth the camp" -- and every word of it comes out of the client's
* DATs, so it costs the wire nothing and works on a server that has never heard
* of DWScan.
*
* Only drawn while the row is hovered, so the resource lookups here are one
* row's worth once, not the table's worth every frame.
--]]
local FLAG_RARE = 0x8000;
local FLAG_EX   = 0x4000;

-- The resistance markup the client packs into a description string. Left as
-- the abbreviation the game's own menus use rather than expanded, so the card
-- reads like the item help it is a copy of.
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function (b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

local function itemCard(itemId)
    local item = resourceOf(itemId);

    imgui.BeginTooltip();

    drawIcon(itemId, 32);
    imgui.Text(itemName(itemId));

    if (item ~= nil) then
        local tags = { };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags[#tags + 1] = string.format('iLvl %d', item.ItemLevel);
        elseif (item.Level ~= nil and item.Level > 0) then
            tags[#tags + 1] = string.format('Lv %d', item.Level);
        end

        if (bit.band(item.Flags or 0, FLAG_RARE) ~= 0) then
            tags[#tags + 1] = 'Rare';
        end

        if (bit.band(item.Flags or 0, FLAG_EX) ~= 0) then
            tags[#tags + 1] = 'Ex';
        end

        if (#tags > 0) then
            imgui.TextDisabled(table.concat(tags, '  '));
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            imgui.PushTextWrapPos(320.0);
            imgui.Text(cleanDescription(desc));
            imgui.PopTextWrapPos();
        end
    end

    imgui.EndTooltip();
end

--[[
* Rendering helpers.
--]]
--[[
* A theme colour out of one of this file's constant palettes.
*
* MEMOISED ON THE ENTRY (2026-09-06). Every caller passes one of about a dozen
* constant tables -- an element, a con tier, a widescan dot -- and none of them
* passes an alpha, so this was a dozen fresh tables allocated on every frame
* for colours that never change. ImGui reads the table inside the call and does
* not keep it, so handing back the same one is safe.
--]]
local function colorOf(entry, alpha)
    if (alpha ~= nil) then
        return { entry.r / 255, entry.g / 255, entry.b / 255, alpha };
    end

    local cached = entry.rgba;

    if (cached == nil) then
        cached = { entry.r / 255, entry.g / 255, entry.b / 255, 1.0 };

        entry.rgba = cached;
    end

    return cached;
end

local function hasFlag(scan, flag)
    return bit.band(scan.flags, flag) == flag;
end

-- The server sent hundredths of a percent. Dividing by 100 to print it is
-- formatting, not arithmetic on the answer.
local function ratePercent(rate)
    return rate / 100.0;
end

local function bitList(value, table_, joiner)
    local names = {};

    for _, entry in ipairs(table_) do
        if (bit.band(value, entry.bit) == entry.bit) then
            names[#names + 1] = entry.name;
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, joiner or ', ');
end

--[[
* SDT reads as a damage multiplier and its sign runs one way; the resistance
* rank reads as a magic-evasion tier and its sign runs the OTHER way. They are
* rendered as separate columns with separate words for exactly that reason --
* one scale over both would be backwards for one of them, confidently.
--]]
local function sdtWord(sdt)
    if (sdt <= -5000) then return 'halves it or better', theme.colors.ok;   end
    if (sdt <= -1000) then return 'resists',             theme.colors.ok;   end
    if (sdt <   0)    then return 'shrugs slightly',     theme.colors.dim;  end
    if (sdt ==  0)    then return 'neutral',             theme.colors.dim;  end
    if (sdt <  1000)  then return 'slightly weak',       theme.colors.warn; end
    if (sdt <  5000)  then return 'weak',                theme.colors.warn; end

    return 'very weak', theme.colors.err;
end

local function rankWord(rank)
    if (rank >= 11) then return 'always resists', theme.colors.err;  end
    if (rank >= 5)  then return 'very hard',      theme.colors.err;  end
    if (rank >= 1)  then return 'hard',           theme.colors.warn; end
    if (rank == 0)  then return 'normal',         theme.colors.dim;  end

    return 'easy', theme.colors.ok;
end

local function secondsWord(seconds)
    if (seconds <= 0) then
        return 'not on a timer';
    end

    if (seconds < 60) then
        return string.format('%d sec', seconds);
    end

    if (seconds < 3600) then
        return string.format('%d min %d sec', math.floor(seconds / 60), seconds % 60);
    end

    return string.format('%.1f hours', seconds / 3600);
end

--[[
* THE RESPAWN SENTENCE IS TWO SENTENCES (1.5.0, 2026-09-16).
*
* A mob on a timer has a respawn. A LOTTERY pop does not: it takes a
* placeholder's slot when a roll goes its way, and the only clock anywhere in
* that camp is the placeholder's. Saying "Respawn: 5 min" about the second
* kind is not a rounding error, it is the wrong mechanic -- and it is the
* sentence that sent a player to Fei'Yin for an afternoon (2026-09-15).
*
* What this window will NOT say is a chance or a lockout. Both exist only as
* arguments inside the placeholder script's own xi.mob.phOnDespawn call and
* nothing on this server indexes them, so there is no number to send and
* inventing one would be the same mistake wearing a different unit.
--]]
local SPAWN_LOTTERY = 0x0020;

local function isLotteryPop(scan)
    return bit.band(scan.spawnType, SPAWN_LOTTERY) ~= 0;
end

local function respawnWords(scan)
    if (not isLotteryPop(scan)) then
        return string.format('Respawn: %s.', secondsWord(scan.respawn));
    end

    if (scan.phCount > 0 and scan.phNames ~= '') then
        return string.format('Lottery pop -- no respawn of its own. Kill its placeholder (%s); each one that dies rolls for it. The placeholder itself comes back every %s.',
            scan.phNames:gsub(',', ', '), secondsWord(scan.phWindow));
    end

    return 'Lottery pop -- no respawn of its own. It takes a placeholder\'s slot when a roll goes its way, and this server did not name the placeholder.';
end

--[[
* HOVER TEXT, IN ONE TABLE (2026-09-06).
*
* Every sentence this window says on hover lives here rather than as a literal
* wedged between two ImGui calls, for the reason the rest of the suite keeps
* its catalogs out of its render passes: a sentence buried in a draw is a
* sentence nobody re-reads, and a harness cannot assert what it cannot find.
* Keys name the CONTROL, never its label -- a label can be reworded without the
* thing behind it changing meaning.
*
* WHAT EARNS A TIP HERE. A number with a unit, an abbreviation, a word whose
* scale runs the opposite way to the word beside it, or a claim whose LIMITS
* are the interesting part ("aggressive" says nothing about how far). Anything
* the label already says is left alone.
--]]
local TIPS = {
    --[[
    * The tab bar (2026-09-06). Five labels, three of which name something no
    * other window in the game shows -- and the parenthesised count is the
    * number of rows BEHIND a tab, which is not always the number on screen:
    * the find box and the rate filter are local to this window and the count
    * is not. That is exactly the sort of thing a player finds out by opening
    * the tab, which is the reason to say it on hover instead.
    --]]
    taboverview = 'Level, con, HP, exp and gil, how it notices you and from how far, what it\nlinks with, and what has to be true for it to spawn at all.',
    tabdrops    = 'The whole drop table at THIS server\'s rates, with steal and despoil shares\nand groups resolved. The count is what the server sent, before this tab\'s\nown filters.',
    tabmagic    = 'Elemental damage taken and resistance to LANDING -- two different axes whose\nscales run opposite ways -- the four weapon lanes, and what cannot land at all.',
    tabquests   = 'Its TP moves, and which quests or missions on YOUR character want it dead.\nThe count is what the server\'s kill handlers hold, not everything that\nwants it.',
    tabwide     = 'The zone around you rather than this mob: the native Wide Scan list, made\nsearchable and sortable, and one click tracks a row on /map. This tab speaks\nthe retail packets and costs the scan protocol nothing.',

    -- The header row.
    scan     = 'Reads whatever you have targeted. Also works typed, as !scan.',
    target   = 'What you have selected RIGHT NOW. The name under the notes is what this\nwindow is actually describing, and the two are not always the same.',
    scanned  = 'The mob this window is describing, under the name the server gave it.\nEverything on every tab below is about this one.',
    stale    = 'You have changed target since this scan. Everything below still describes\nthe mob named beside this -- press Scan to read the new one.',
    note     = 'Something the SERVER said about this answer, usually that a list did not\nfit on the wire. It is about the scan rather than about the mob.',
    follow   = 'Scan automatically when you change target, while this window is open.\nOne chat line per change -- leave it off in a crowd.',
    queued   = 'Scans waiting on the client\'s own chat rate limit -- a scan IS a chat line.\nThey are held, never dropped, and go out about one a second.',

    -- Overview.
    con      = 'The /check difficulty, computed for YOU: your level and your job against\nthis one. Another character standing here reads a different word.',
    level    = 'The level /check would state for this spawn, which is not always the level\nin the band below it -- some mobs carry a level modifier.',
    band     = 'This mob re-rolls its level inside this band every time it spawns. The\nlevel above is the one standing in front of you now.',
    ungauged = 'The game itself refuses to rate notorious monsters, battlefield mobs and\nanything flagged to check as one. Everything else on this window is still true.',
    hp       = 'This spawn\'s maximum HP and MP, as the server has them -- not a wiki figure.',
    family   = 'The monster family and the ecosystem it belongs to. Killer traits, and most\nquests that ask for "a kind of" monster, key on these.',
    crystal  = 'Signet, Sanction or Sigil adds a roll for this crystal when the mob dies --\nonce per player standing near it. It is NOT one of the rows on the Drops tab,\nand its chance is the engine\'s rather than anything on this wire.',
    marks    = 'notorious: the game withholds its gauge. undead: sleeps to Repose, not Sleep.\nbattlefield: it belongs to an instance. dead: it was not alive when scanned.',
    exp      = 'One kill, solo, no chain and no signet, at YOUR level -- with this server\'s\nexp rate already in it. A party, a chain or a level gap all move it.',
    gil      = 'Both ends of the gil roll, inclusive: gilmax is a figure this mob can\nactually drop, not one above it.',
    senses   = 'Which senses can start a fight. Sound and sight are what sneak and invisible\nhide you from; scent, magic and job abilities are not hidden by either.',
    ranges   = 'These are this server\'s ranges, already halved from retail. A mob keeps\nfull retail range once it has you -- these decide whether it starts.',
    truedet  = 'True detection ignores sneak and invisible entirely. Distance is the only\nthing between you and the fight.',
    link     = 'If you pull one and another of its kind is inside this radius, you get both.\nAlready halved the way this server halves it.',
    nolink   = 'This one fights alone: pulling it will not bring its neighbours.',
    spawn    = 'What has to be true for this one to spawn at all. A lottery mob replaces a\nplaceholder; a windowed one only pops inside its window.',
    respawn  = 'The CONFIGURED interval between one death and the next spawn, not a\ncountdown -- the server does not say how much of it has run.',
    lottery  = 'A lottery pop has no timer of its own -- it takes a placeholder\'s slot when\na kill rolls in its favour, so the only clock in the camp is the\nplaceholder\'s. The roll chance and the lockout after it is killed live only\ninside the placeholder\'s script and are not on this wire, so this window\ndoes not guess at them.',

    -- Drops.
    dropcount   = 'Rows the server sent, and rows it has. The server sends the best ones and\nstops; anything past that never left the map, so there is nowhere else to look.',
    drophidden  = 'Rows the "Hide under" filter is holding back. That filter is local to this\nwindow -- it changes nothing the server said.',
    dropmult    = 'The rates on this tab already carry this server\'s drop multiplier and the\nTreasure Hunter level the SERVER answered at. Nothing here is scaled locally.',
    droptrunc   = 'The server\'s own cap, not this window\'s. Typing !scan shows fewer rows, not\nmore.',
    minrate     = 'Hide any row under this chance. A local filter on a finished list -- it never\nre-asks the server and never changes a number.',
    dropicons   = 'Draw each item\'s own icon from the client\'s resources. Turn it off on a slow\nmachine; the rows and rates are unchanged.',
    th          = 'Show drop rates as if this Treasure Hunter level lands the kill.\nThe server recomputes the whole table -- nothing here is scaled locally.',
    dropfind    = 'Filter the rows by item name. Local to this window; the rates and the counts\nabove still describe the whole list.',
    dropcopy    = 'Copy every row you can currently see -- name, kind and rate -- to the\nclipboard as plain text, for a linkshell or a spreadsheet.',
    dropordinary = 'An ordinary drop: its own roll, independent of every other row here.',
    dropsteal   = 'One item is taken per successful Steal, picked at random from the\nsteal pool. This is that share -- it assumes the Steal lands.',
    dropdespoil = 'The despoil pool, same rule as Steal: this share assumes it lands.',
    dropgroup   = 'Exactly one item from a group drops, never two. This is the chance\nthat item is the one.',
    colitem     = 'The item, by the name and icon your own client holds. No item name is ever\non this wire.',
    colchance   = 'The finished chance this server rolls, in percent -- multiplier, groups,\nduplicate rows and Treasure Hunter all already folded in.',

    -- Magic.
    coldamage = 'How much a landed spell of that element HURTS: the damage multiplier, where\nnegative resists and positive takes more.',
    colland   = 'Whether a spell of that element LANDS at all: the resistance rank, whose\nscale runs the OTHER WAY -- higher is harder.',
    element   = 'Two separate mechanics ride this row. Damage taken and resistance to landing\nare different numbers and can disagree.',
    weapons   = 'Damage taken by weapon type, on the same scale as the element column:\nnegative resists, positive takes more. These have no resistance rank.',
    immunity  = 'Immunity is not resistance. These will never land, at any accuracy.',

    -- The greyed panels. WHICH section is missing is already on the panel; what
    -- is not is when the server said so, and that a handshake can change the
    -- answer -- a map still registering its scan bindings when this window
    -- first said hello reports them missing, correctly, and for as long as
    -- nothing asks again.
    nobinding = 'The server said so at the handshake, which is the first thing this window\nsends. It handshakes again after a zone line, so a server that was still\ncoming up when you opened this answers differently then.',

    -- Quests.
    tpmoves   = 'The TP moves this one has, by the names the client prints when they go off.\nA long list is truncated by the server, and it says so above the window.',
    qstate    = 'Your own standing on it: this line is computed for your character, and\nanother player reads a different word on the same mob.',
    qlimit    = 'Read from the server\'s own kill handlers. A quest that wants an item this\nthing drops watches the item, not the death, and cannot appear here.',

    -- Wide Scan.
    wsrescan  = 'Ask for a fresh list -- the same packet the native Wide Scan menu sends.',
    wsauto    = 'Rescan every few seconds while this tab is visible.',
    wsmobs    = 'Show monsters -- the red dots. Unticking hides them from the list below.',
    wsnpcs    = 'Show NPCs and other non-monsters -- the green dots.',
    wssort    = 'Order the list: by distance from where you stood at the scan, by level, or\nby name.',
    wssearch  = 'Filter by name. Names come from the zone\'s own list file, so this searches\nwhat you read rather than the targids underneath.',
    wstrack   = 'Follow this on /map -- the same dot the native Wide Scan tracks.',
    wsstop    = 'Put the /map dot away. The server is what actually stops tracking.',
    wsbanner  = 'What the SERVER says it is tracking, not what this window asked for -- so\nthe row highlight can never disagree with the dot on /map.',
    wscounts  = 'Everything the last scan returned, and how much of it survived the filters\nabove. Positions are a snapshot of where things stood at the scan.',
    wsage     = 'When this list arrived. Every distance on it is measured from where you\nstood then, so an old list is a list of where things used to be.',
    wslevel   = 'The level the widescan list reports. NPCs have none and read as --.',
    wsdist    = 'Yalms from where YOU stood when the scan answered, not from where you are\nnow. Rescan after you move.',
    wspage    = 'Fifty rows a page. Paging is local -- it does not re-ask the server.',
    wskind    = 'mob is the red dot on the native list, npc the green one. The Mobs and\nNPCs boxes above hide either.',
    wsname    = 'Read from the zone\'s own list file, exactly as the native menu reads it.\nA row the file cannot name shows its targid instead, and still tracks.',
};

local function tip(key)
    local text = TIPS[key];

    if (text ~= nil and imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* A table's header row, drawn cell by cell rather than through
* TableHeadersRow.
*
* TableHeadersRow submits the whole row as one item, which leaves nothing for
* IsItemHovered to be about -- and a column header is exactly where a column's
* UNITS belong ("Chance" of what, measured how). Each entry is
* `{ label, tipKey }`, and a nil key is a header that needs no explaining.
--]]
local function headers(columns)
    imgui.TableNextRow(ImGuiTableRowFlags_Headers, 0);

    for _, column in ipairs(columns) do
        imgui.TableNextColumn();
        imgui.TableHeader(column[1]);

        if (column[2] ~= nil) then
            tip(column[2]);
        end
    end
end

--[[
* Tabs.
--]]
-- The four `q|` states, as the word the player reads plus the colour that word
-- wears. A table rather than an if-chain rebuilt per row per frame, and it
-- makes the fourth state ('-' -- the server could not tell) visibly a state
-- rather than a fall-through.
local QUEST_STATES = {
    active   = { label = 'in progress', color = 'ok'    },
    done     = { label = 'completed',   color = 'badge' },
    open     = { label = 'not started', color = 'dim'   },
    ['-']    = { label = 'unknown',     color = 'dim'   },
};

local QUEST_STATE_TIPS = {
    active = 'You have this one accepted right now. Killing this mob advances it.',
    done   = 'You have already finished this one. It is listed because the handler\nis still on this mob for everyone who has not.',
    open   = 'On this server and available to you, but you have not started it.',
    ['-']  = 'The server could not read your standing on this one.',
};

--[[
* The sentences a tab derives from one answer, composed once per answer instead
* of once per frame.
*
* None of this is arithmetic on the answer -- it is the same bit walks and
* concatenations the draw pass already did, moved off the sixty-a-second path.
* It hangs on the scan table itself because that table is REPLACED wholesale by
* every answer (never merged), so the cache cannot outlive the mob it describes
* and there is no invalidation to get wrong.
--]]
local function derivedOf(scan)
    if (scan.derived ~= nil) then
        return scan.derived;
    end

    local marks = { };

    if (hasFlag(scan, FLAG_NM))          then marks[#marks + 1] = 'notorious';   end
    if (hasFlag(scan, FLAG_UNDEAD))      then marks[#marks + 1] = 'undead';      end
    if (hasFlag(scan, FLAG_BATTLEFIELD)) then marks[#marks + 1] = 'battlefield'; end
    if (not hasFlag(scan, FLAG_ALIVE))   then marks[#marks + 1] = 'dead';        end

    local ranges = { };

    if (scan.sight > 0 and bit.band(scan.detects, 0x0001) ~= 0) then
        ranges[#ranges + 1] = string.format('sight %d', scan.sight);
    end

    if (scan.sound > 0 and bit.band(scan.detects, 0x0002) ~= 0) then
        ranges[#ranges + 1] = string.format('sound %d', scan.sound);
    end

    if (scan.magic > 0 and bit.band(scan.detects, 0x0020) ~= 0) then
        ranges[#ranges + 1] = string.format('magic %d', scan.magic);
    end

    local hp = string.format('%d HP', scan.maxhp);

    if (scan.maxmp > 0) then
        hp = string.format('%s / %d MP', hp, scan.maxmp);
    end

    local gil = 'No gil.';

    if (scan.gilMax > 0) then
        if (scan.gilMin == scan.gilMax) then
            gil = string.format('%d gil', scan.gilMin);
        else
            gil = string.format('%d-%d gil', scan.gilMin, scan.gilMax);
        end
    end

    --[[
    * THE ELEMENT AND WEAPON VERDICTS, COMPOSED ONCE (2026-09-06).
    *
    * The Magic tab was twenty string.formats a frame -- eight elements times
    * two axes, plus four physical lanes -- for words and percentages that
    * cannot move until the next answer replaces this table. The COLOUR is
    * cached with the word because dwtheme's palette tables are mutated in
    * place by the launcher's live retheme (`setInPlace`), so a reference taken
    * once still follows a colour change.
    --]]
    local elements = { };

    for _, id in ipairs(ELEMENT_ORDER) do
        local row = scan.resists[id];

        if (row ~= nil) then
            local word,  color  = sdtWord(row.sdt);
            local rword, rcolor = rankWord(row.rank);

            elements[id] = {
                damage      = string.format('%s (%+.0f percent)', word, row.sdt / 100.0),
                damageColor = color,
                land        = string.format('%s to land', rword),
                landColor   = rcolor,
            };
        end
    end

    local lanes = { };

    for index, lane in ipairs(PHYSICAL_LANES) do
        local value = scan.physical[lane.key];

        if (value ~= nil) then
            local word, color = sdtWord(value);

            lanes[index] = {
                damage      = string.format('%s (%+.0f percent)', word, value / 100.0),
                damageColor = color,
            };
        end
    end

    --[[
    * The Quests tab's rows, composed once for the reason the Magic tab's
    * verdicts are (2026-09-06): the badge and the sentence beside it were two
    * string.formats PER ROW per frame, and a mob with a dozen involvements is
    * twenty-four of them sixty times a second for text that cannot move.
    --]]
    local quests = { };

    for index, row in ipairs(scan.quests) do
        local entry = QUEST_STATES[row.state] or QUEST_STATES['-'];

        quests[index] = {
            badge = string.format('[%s]', entry.label),
            color = entry.color,
            tip   = QUEST_STATE_TIPS[row.state] or QUEST_STATE_TIPS['-'],
            line  = string.format('%s %s', row.kind == 'm' and 'Mission:' or 'Quest:', row.name),
        };
    end

    -- Walked once and used twice below: the bare list names the senses and the
    -- sentence wraps it, and computing the bit walk twice for one answer is
    -- two answers waiting to disagree.
    local senses = bitList(scan.detects, DETECTS, ', ');
    local spawn  = bitList(scan.spawnType, SPAWN_TYPES, ', ');

    scan.derived = {
        quests  = quests,
        senses  = senses,
        spawn   = spawn,
        marks   = #marks > 0 and table.concat(marks, ', ') or nil,
        ranges  = #ranges > 0 and string.format('Ranges in yalms: %s.', table.concat(ranges, ', ')) or nil,
        hp      = hp,
        gil     = gil,
        gilled  = scan.gilMax > 0,
        family  = scan.family ~= '' and string.format('-- %s, %s', scan.family, scan.eco) or nil,
        respawn = respawnWords(scan),
        lottery = isLotteryPop(scan),

        -- The Overview's own sentences, off the sixty-a-second path for the
        -- same reason. `con` is the fallback a server newer than this addon
        -- gets; the named tiers need no format at all.
        level     = string.format('-- level %d', scan.level),
        band      = string.format('(this one spawns %d-%d)', scan.lo, scan.hi),
        con       = string.format('difficulty %d', scan.con),
        exp       = string.format('%d exp', scan.exp),
        aggressive = string.format('Aggressive by %s.', senses or '?'),
        links     = string.format('Links, within %d yalms.', scan.linkRadius),
        spawnAt   = string.format('Spawns %s.', spawn or '?'),

        elements = elements,
        lanes    = lanes,

        -- The Magic tab's list. Several `x|` records may have arrived, so this
        -- can be a long sentence and the tab wraps it.
        immune  = #scan.immunities > 0 and table.concat(scan.immunities, ', ') or nil,

        -- The Quests tab's TP move line, same reasoning: several `k|` records,
        -- one wrapped sentence, concatenated once instead of every frame.
        skills  = table.concat(scan.skills, ', '),

        -- The crystal ITEM, not a name this addon composed: the engine adds
        -- item 4095 + element to the pool (mob_entity.cpp:1180), so the client
        -- has both the display name and the icon already. Element 0 is "no
        -- crystal", which is most NMs and every non-elemental family.
        crystal = (scan.crystal > 0 and scan.crystal <= 8) and (4095 + scan.crystal) or nil,
    };

    return scan.derived;
end

--[[
* WHETHER THE SERVER'S FACTS BINDING ANSWERED (2026-09-06).
*
* `f|` has carried this capability since 1.0 and nothing in this file ever
* looked at it -- the drop binding got a greyed panel with a reason and the
* quest index got one, and the third stayed unread. A build without
* DwscanFacts answers the whole record set with defaults: `aggressive` nil,
* `gilmin`/`gilmax` 0, `respawn` 0, `skills` absent. blank() then renders
* those as four confident sentences -- "Never aggressive -- it will not start
* a fight", "No gil.", "Respawn: not on a timer.", "None listed." -- about a
* mob the server never read, and the first of them is the one that gets
* somebody killed.
*
* Only those four are affected. The detection ranges, the link radius, HP, the
* family and the con come off mob bindings the map always has, so they stay --
* greying the whole tab would throw away facts that ARE true.
--]]
local function hasFacts()
    return state.caps == nil or state.caps.facts;
end

local function tabOverview(scan)
    local view  = derivedOf(scan);
    local facts = hasFacts();

    if (hasFlag(scan, FLAG_GAUGED)) then
        local tier = TIERS[scan.con];

        if (tier ~= nil) then
            imgui.TextColored(colorOf(tier), tier.short);
        else
            -- A tier from a server newer than this addon. Say the number rather
            -- than falling back to one we do know, which would be a lie with a
            -- colour on it.
            imgui.TextColored(theme.colors.warn, view.con);
        end

        tip('con');

        imgui.SameLine();
        imgui.Text(view.level);
        tip('level');

        if (scan.lo >= 0 and scan.hi >= 0 and scan.lo ~= scan.hi) then
            imgui.SameLine();
            imgui.TextDisabled(view.band);
            tip('band');
        end
    else
        imgui.TextColored(theme.colors.warn, 'Impossible to gauge.');
        tip('ungauged');

        -- WRAPPED rather than hand-broken (2026-09-06): these two lines were
        -- split at a fixed column that only fits the default window width, so
        -- narrowing the window clipped them and widening it left a ragged
        -- break in the middle of a sentence. PushTextWrapPos rather than
        -- TextWrapped because the line is meant to stay dim.
        imgui.PushTextWrapPos(0.0);
        imgui.TextDisabled('The game withholds the level and the difficulty for notorious monsters and battlefield mobs, so this window does not guess at them either.');
        imgui.PopTextWrapPos();
    end

    imgui.Separator();

    imgui.Text(view.hp);
    tip('hp');

    if (view.family ~= nil) then
        imgui.SameLine();

        -- WRAPPED (2026-09-06). `t|` fits the family name to whatever is left
        -- of the 130-byte line, so it can be far longer than the two words the
        -- common case is -- and it rides a SameLine after the HP, which is the
        -- half of the line already spent.
        imgui.PushTextWrapPos(0.0);
        imgui.TextDisabled(view.family);
        imgui.PopTextWrapPos();
        tip('family');
    end

    if (view.marks ~= nil) then
        imgui.TextDisabled(view.marks);
        tip('marks');
    end

    imgui.Separator();

    if (scan.exp ~= WITHHELD) then
        imgui.Text(view.exp);
        tip('exp');
        imgui.SameLine();
        imgui.TextDisabled('solo, no chain or signet');
        tip('exp');
    else
        imgui.TextDisabled('Experience withheld with the rest of the gauge.');
        tip('ungauged');
    end

    if (not facts) then
        imgui.TextColored(theme.colors.err, 'Gil unknown -- this server build has no facts binding.');
        tip('nobinding');
    elseif (view.gilled) then
        imgui.Text(view.gil);
        tip('gil');
    else
        imgui.TextDisabled(view.gil);
    end

    -- The crystal (1.3.0). It rides `t|`'s element field, which every version
    -- of this wire has carried and which nothing rendered until now.
    if (view.crystal ~= nil) then
        if (config.icons ~= false) then
            drawIcon(view.crystal, 18);
        end

        --[[
        * COMPOSED IN THE DRAW, and it is the one sentence on this tab that is
        * (2026-09-06). Everything else here comes off the wire and is composed
        * once in derivedOf; this one needs an item NAME, and itemName does not
        * cache a name it could not resolve -- so freezing this sentence into
        * the answer would freeze `item 4099` there for as long as the answer
        * lived. One format a frame, and only for a mob that drops a crystal.
        *
        * "a roll for Earth Crystal" rather than "a Earth Crystal roll": the
        * article was wrong for half the elements, and the line is wrapped
        * because with the icon in front of it it is about as wide as the
        * narrowest window the size constraint allows.
        --]]
        imgui.PushTextWrapPos(0.0);
        imgui.TextDisabled(string.format('Signet adds a roll for %s -- not one of the Drops rows.', itemName(view.crystal)));
        imgui.PopTextWrapPos();
        tip('crystal');
    end

    imgui.Separator();
    imgui.Text('How it notices you');

    if (not facts) then
        -- The one claim on this tab that can get somebody killed, so it is the
        -- one that must never be guessed: `aggressive` rides the facts binding
        -- and a build without it answers "not aggressive" for everything.
        imgui.PushTextWrapPos(0.0);
        imgui.TextColored(theme.colors.err, 'Whether it starts fights is unknown -- this server build has no facts binding. The ranges below are real; treat it as aggressive until you know.');
        imgui.PopTextWrapPos();
        tip('nobinding');
    elseif (scan.aggro == 0) then
        imgui.TextColored(theme.colors.ok, 'Never aggressive -- it will not start a fight.');
    elseif (view.senses == nil) then
        imgui.TextDisabled('Aggressive, but by no sense this addon knows.');
        tip('senses');
    else
        imgui.TextColored(theme.colors.warn, view.aggressive);
        tip('senses');
    end

    if (view.ranges ~= nil) then
        imgui.TextDisabled(view.ranges);
        tip('ranges');
    end

    if (facts and scan.trueDetect == 1) then
        imgui.TextColored(theme.colors.err, 'True detection -- sneak and invisible will not hide you.');
        tip('truedet');
    end

    if (scan.link == 1) then
        imgui.Text(view.links);
        tip('link');
    else
        imgui.TextDisabled('Does not link.');
        tip('nolink');
    end

    imgui.Separator();

    if (view.spawn ~= nil) then
        imgui.Text(view.spawnAt);
        tip('spawn');
    end

    if (facts) then
        -- Wrapped: the lottery sentence names a placeholder and is long on
        -- purpose, and a camp instruction that runs off the panel edge is the
        -- half of the answer nobody reads.
        imgui.PushTextWrapPos(0.0);

        if (view.lottery) then
            imgui.TextColored(theme.colors.warn, view.respawn);
        else
            imgui.Text(view.respawn);
        end

        imgui.PopTextWrapPos();
        tip(view.lottery and 'lottery' or 'respawn');
    else
        imgui.TextDisabled('Respawn unknown -- this server build has no facts binding.');
        tip('nobinding');
    end
end

--[[
* The Drops tab's view: the rows that survive the rate filter and the find box,
* with each row's name and its rate sentence already composed.
*
* WHY IT IS CACHED. Every one of those was per row PER FRAME: an item name is a
* resource-manager lookup, the rate sentence is a string.format, the "hidden"
* counter walked the whole table a second time, and a Dynamis droplist is
* forty-eight rows at sixty frames a second. None of it can change between
* frames -- the model is replaced wholesale by an answer and nothing else
* touches it -- so what it is keyed on is the answer's revision plus the two
* local filters, and a frame that changes none of them does no work at all.
*
* `dropsKey` is now a plain "the view is built" flag rather than a string: the
* three things it was built from are kept beside it and compared one by one.
--]]
local dropsSearch = T{ '' };
local dropsView   = T{ };
local dropsHidden = 0;
local dropsKey    = nil;

--[[
* The tab's header sentences, composed where the view is (2026-09-06).
*
* All of them were string.format inside the draw, so a tab left open on one
* answer re-composed the row counts, the multiplier line and the truncation
* warning sixty times a second out of numbers that cannot move until the next
* answer replaces the whole model. They key on exactly what the view keys on.
--]]
local dropsHead   = { };

-- What the view above was built FROM. Three comparisons rather than a key
-- string composed every frame -- and a key is worse than slow here: `%.2f`
-- rounded two rate filters a thousandth apart onto the same key, so a drag
-- could land on a value whose rows were the previous one's (2026-09-06).
local dropsRev    = -1;
local dropsMin    = nil;
local dropsNeedle = nil;

local KIND_TIPS = {
    s = 'dropsteal',
    d = 'dropdespoil',
    g = 'dropgroup',
};

local DROP_COLUMNS = {
    { '' },
    { 'Item',   'colitem'   },
    { 'Chance', 'colchance' },
};

local function dropRows(scan)
    local minRate = config.minRate or 0.0;
    local needle  = dropsSearch[1]:lower();

    if (dropsKey and dropsRev == state.scanRev and dropsMin == minRate and dropsNeedle == needle) then
        return dropsView;
    end

    dropsKey    = true;
    dropsRev    = state.scanRev;
    dropsMin    = minRate;
    dropsNeedle = needle;
    dropsView   = T{ };
    dropsHidden = 0;
    dropsHead   = { };

    -- Set by any row whose name the client could not answer for yet; see the
    -- note where it is read, below the loop.
    local unresolved = false;

    for _, row in ipairs(scan.drops) do
        local percent = ratePercent(row.rate);

        if (percent < minRate) then
            dropsHidden = dropsHidden + 1;
        else
            local name = itemName(row.itemid);

            -- itemName caches only a name it actually RESOLVED, so an id still
            -- absent from that cache is one the client could not name on this
            -- frame. An id the resource manager can never answer for (0, and
            -- the 65535 sentinel) is not "not yet" and must not put this view
            -- on a rebuild every frame for the rest of the session.
            if (itemNames[row.itemid] == nil and row.itemid > 0 and row.itemid ~= 65535) then
                unresolved = true;
            end

            if (needle == '' or name:lower():find(needle, 1, true) ~= nil) then
                local rate, group;

                if (row.kind == 's') then
                    rate = string.format('steal %.2f percent', percent);
                elseif (row.kind == 'd') then
                    rate = string.format('despoil %.2f percent', percent);
                else
                    rate = string.format('%.2f percent', percent);

                    if (row.kind == 'g') then
                        group = string.format('(group %d)', row.group);
                    end
                end

                dropsView:append({
                    itemid = row.itemid,
                    kind   = row.kind,
                    name   = name,
                    rate   = rate,
                    group  = group,
                });
            end
        end
    end

    --[[
    * AND A VIEW BUILT OUT OF UNRESOLVED NAMES DOES NOT GET TO BE THE CACHE
    * (2026-09-06).
    *
    * itemName deliberately does not cache the `item 1234` fallback, because
    * that is what an id looks like before the client has finished handing the
    * resource manager its DATs -- caching it would freeze a real item's row as
    * a number for the rest of the session. This view then quietly undid that
    * care: the fallback string was copied into the row and the row was cached
    * under a key that only moves when the ANSWER or a filter does, so the
    * number stayed on screen until the player scanned something else.
    *
    * Dropping the key rebuilds next frame, and only for as long as anything on
    * the list is still nameless -- once the client can answer, the frame after
    * that is cached like every other.
    --]]
    if (unresolved) then
        dropsKey = nil;
    end

    dropsHead = {
        counts = string.format('%d of %d rows', scan.shown, scan.total),

        hidden = dropsHidden > 0
            and string.format('(%d hidden by the rate filter)', dropsHidden) or nil,

        matched = dropsSearch[1] ~= ''
            and string.format('(%d match "%s")', #dropsView, dropsSearch[1]) or nil,

        mult = string.format('Rates include this server\'s %.2fx drop multiplier, at TH %d.',
            scan.mult / 100.0, scan.th or 0),

        trunc = scan.total > scan.shown
            and string.format('%d more rows exist. The server sends the best %d and stops.',
                scan.total - scan.shown, scan.shown) or nil,

        -- The two ways this table can be empty, said apart: a filter that ate
        -- every row must never read as a mob with nothing to drop.
        noMatch = string.format('No row here matches "%s".', dropsSearch[1]),
        allHid  = string.format('All %d rows are under the "Hide under" filter.', dropsHidden),
    };

    return dropsView;
end

local function tabDrops(scan)
    if (state.caps ~= nil and not state.caps.drops) then
        imgui.TextColored(theme.colors.err, 'This server build has no drop binding, so nothing can be listed.');
        tip('nobinding');

        return;
    end

    -- The TH in this label is the one the SERVER answered at (`y|`'s th
    -- field), never the dropdown's -- on a server that ignored or predates the
    -- argument it stays 0, and the window then cannot flatter the rates with a
    -- level nobody applied.
    -- Counted against the LOCAL filter too (client discipline 7: say what
    -- did not fit): "48 of 61 rows" over a table showing three, because
    -- "Hide under" ate the rest, read as a broken table.
    local rows = dropRows(scan);

    imgui.Text(dropsHead.counts);
    tip('dropcount');

    if (dropsHead.hidden ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(dropsHead.hidden);
        tip('drophidden');
    end

    -- AND WHAT THE FIND BOX IS HOLDING BACK (2026-09-06). The counts above are
    -- the server's; with something typed in the box the table shows fewer rows
    -- than they claim, and a header that says "3 of 9 rows" over a table
    -- showing one reads as a broken table rather than as a filter working.
    if (dropsHead.matched ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(dropsHead.matched);
        tip('dropfind');
    end

    -- ON ITS OWN LINE (2026-09-06). This trailed the counts on a SameLine, and
    -- the three of them together run about seven hundred pixels -- a third of
    -- it past the right edge of the default window, with the multiplier and
    -- the TH level (the two things the sentence exists to say) the part that
    -- fell off.
    imgui.TextDisabled(dropsHead.mult);
    tip('dropmult');

    -- The truncation is the SERVER's cap, so there is nowhere else to look: the
    -- rows past it never left the map. Saying "type !scan for the rest" -- which
    -- 1.0 did -- sent the player to a tier that shows eight rows and points back
    -- here. Say what is true instead.
    if (dropsHead.trunc ~= nil) then
        imgui.TextColored(theme.colors.warn, dropsHead.trunc);
        tip('droptrunc');
    end

    imgui.PushItemWidth(160);
    -- commitSoon, not commit: the slider reports a change on every frame of a
    -- drag and settings.save() writes a file.
    if (imgui.SliderFloat('Hide under', ui.minRate, 0.0, 25.0, '%.1f percent')) then
        commitSoon();
    end
    imgui.PopItemWidth();
    tip('minrate');

    imgui.SameLine();

    if (imgui.Checkbox('Icons', ui.icons)) then
        commit();
    end

    tip('dropicons');

    --[[
    * The Treasure Hunter dropdown. Its entries run 0..maxth where maxth came
    * off the server's own hello (`f|`), so the list resizes itself if the
    * bracket table is ever retuned -- this addon holds no copy of it. Picking
    * a level re-asks the server about the mob already on screen; the addon
    * still computes nothing, it just asks a different question. The choice is
    * persisted, so it survives target changes, reloads and sessions.
    --]]
    imgui.SameLine();
    imgui.PushItemWidth(72);

    local maxTh = 0;

    if (state.caps ~= nil and state.caps.maxth ~= nil) then
        -- CLAMPED to MAX_TH_CEILING (2026-09-06). This bound comes off the
        -- wire and it is the bound of a loop that draws a widget per tier
        -- every frame the dropdown is open, so a server answering a wrong
        -- large number is a frozen client rather than a wrong list. The
        -- server still owns how many tiers there are; this only says what
        -- cannot be a tier at all.
        maxTh = math.floor(math.max(0, math.min(state.caps.maxth, MAX_TH_CEILING)));
    end

    local thOpen = imgui.BeginCombo('##dwscan_th', TH_LABELS[config.thLevel or 0] or 'TH ?');

    -- Asked BEFORE the popup is drawn: once a Selectable inside the combo has
    -- been submitted, "the last item" is that Selectable and the tip would
    -- follow the mouse into the list instead of describing the control.
    tip('th');

    if (thOpen) then
        for level = 0, maxTh do
            if (imgui.Selectable(TH_ITEMS[level], (config.thLevel or 0) == level)) then
                ui.thLevel[1] = level;
                commit();

                if (state.scan ~= nil and state.scan.targid ~= nil) then
                    requestScan(state.scan.targid);
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    -- A SECOND ROW (2026-09-06), for the reason the Wide Scan controls got
    -- one: the slider carries a visible label, and slider + Icons + the TH
    -- dropdown + a find box + a button is about 590 pixels of controls -- more
    -- than the interior of the default window, let alone of the narrowest one
    -- the size constraint allows.
    imgui.PushItemWidth(150);
    imgui.InputTextWithHint('##dwscan_drop_find', 'find an item', dropsSearch, 48);
    imgui.PopItemWidth();
    tip('dropfind');

    imgui.SameLine();

    -- Copies what is ON SCREEN, not the whole answer: the filters above are
    -- the player's own question, and a copy that quietly re-includes what they
    -- filtered out is a different list than the one they were looking at.
    if (imgui.SmallButton('Copy##dwscan_drop_copy')) then
        local out = { string.format('%s -- %d of %d drop rows, TH %d, %.2fx',
            scan.name, scan.shown, scan.total, scan.th or 0, scan.mult / 100.0) };

        for _, row in ipairs(rows) do
            out[#out + 1] = string.format('%s  %s%s', row.name, row.rate,
                row.group ~= nil and (' ' .. row.group) or '');
        end

        -- Under pcall (Phase 2, 2026-09-06): the annotation is not the
        -- binding (dwah 5a), and a refused call here would otherwise be a
        -- render error that closes the whole window for one click on Copy.
        if (type(imgui.SetClipboardText) ~= 'function'
                or not pcall(imgui.SetClipboardText, table.concat(out, '\n'))) then
            state.status    = 'This client will not let an addon reach the clipboard.';
            state.statusBad = true;
        end
    end

    tip('dropcopy');

    imgui.Separator();

    if (#scan.drops == 0) then
        imgui.TextDisabled('Nothing drops from this one.');

        return;
    end

    -- SAID OUT LOUD (2026-09-06): an empty table under a filter that ate every
    -- row read exactly like a mob with no drops, which is the one thing this
    -- tab must never accidentally claim.
    if (#rows == 0) then
        if (dropsSearch[1] ~= '') then
            imgui.TextDisabled(dropsHead.noMatch);
        else
            imgui.TextDisabled(dropsHead.allHid);
        end

        return;
    end

    -- The name column STRETCHES and the chance column is measured (2026-09-06).
    -- Both were fixed pixel widths, and the chance column's 150 was narrower
    -- than its own widest sentence: "12.34 percent (group 255)" is about 175
    -- pixels, so every grouped row had its group label cut in half.
    --[[
    * MEASURED OFF WHAT THIS COLUMN CAN ACTUALLY HOLD (2026-09-06).
    *
    * It was one literal, 'despoil 100.00 percent (group 255)', and no row can
    * ever say that: the four kinds are exclusive, so a despoil row is never in
    * a group. The column reserved about eight characters it could never need
    * out of an interior the size constraint lets fall to five hundred pixels,
    * and it took them from the Item column -- the one that clips a long item
    * name.
    *
    * The two shapes that CAN appear are a steal or despoil sentence, and a
    * plain rate followed on a SameLine by its group label; the leading space
    * in the second stands in for that SameLine's spacing.
    --]]
    local groupedW = imgui.CalcTextSize('100.00 percent') + imgui.CalcTextSize(' (group 255)');
    local plainW   = (imgui.CalcTextSize('despoil 100.00 percent'));
    local chanceW  = math.max(groupedW, plainW);

    if (not imgui.BeginTable('##dwscan_drops', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY), { -1, -1 })) then
        return;
    end

    imgui.TableSetupColumn('',       ImGuiTableColumnFlags_WidthFixed,          26, 0);
    imgui.TableSetupColumn('Item',   ImGuiTableColumnFlags_WidthStretch,         0, 0);
    imgui.TableSetupColumn('Chance', ImGuiTableColumnFlags_WidthFixed, chanceW + 12, 0);
    imgui.TableSetupScrollFreeze(0, 1);
    headers(DROP_COLUMNS);

    for _, row in ipairs(rows) do
        imgui.TableNextRow();
        imgui.TableNextColumn();

        local hoveredIcon = false;

        if (config.icons ~= false) then
            drawIcon(row.itemid, 20);
            hoveredIcon = imgui.IsItemHovered();
        end

        imgui.TableNextColumn();
        imgui.Text(row.name);

        -- The client's own item help, the dwah/dwbags card. Answered off the
        -- hovered row only, so it costs one lookup and not the table's worth.
        if (imgui.IsItemHovered() or hoveredIcon) then
            itemCard(row.itemid);
        end

        imgui.TableNextColumn();

        if (row.kind == 's' or row.kind == 'd') then
            imgui.TextColored(theme.colors.info, row.rate);
        else
            imgui.Text(row.rate);

            if (row.group ~= nil) then
                imgui.SameLine();
                imgui.TextDisabled(row.group);
            end
        end

        tip(KIND_TIPS[row.kind] or 'dropordinary');
    end

    imgui.EndTable();
end

local ELEMENT_COLUMNS = {
    { '' },
    { 'Damage taken', 'coldamage' },
    { 'Lands',        'colland'   },
};

local function tabMagic(scan)
    local view = derivedOf(scan);

    imgui.Text('Elements');
    imgui.TextDisabled('Damage taken, and how well it resists being hit at all.');
    tip('element');
    imgui.Separator();

    -- The element column is measured off its own widest name and the two
    -- verdict columns off their own widest sentences (2026-09-06). They were
    -- 90/170/150, and "halves it or better (-50 percent)" is about 210 pixels
    -- wide -- so the mobs whose resistance is most worth reading were the ones
    -- whose word got cut.
    local elemW   = (imgui.CalcTextSize('Lightning'));
    local damageW = (imgui.CalcTextSize('halves it or better (-100 percent)'));

    if (not imgui.BeginTable('##dwscan_elements', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    -- The last column STRETCHES so the table cannot be wider than the window:
    -- the three fixed widths together are close to the interior of the
    -- narrowest window the size constraint allows, and a fixed third column
    -- would push its own contents past the right edge with nothing to scroll.
    imgui.TableSetupColumn('',             ImGuiTableColumnFlags_WidthFixed,   elemW + 12,   0);
    imgui.TableSetupColumn('Damage taken', ImGuiTableColumnFlags_WidthFixed,   damageW + 12, 0);
    imgui.TableSetupColumn('Lands',        ImGuiTableColumnFlags_WidthStretch, 0,            0);
    headers(ELEMENT_COLUMNS);

    for _, id in ipairs(ELEMENT_ORDER) do
        local element = ELEMENTS[id];
        local row     = view.elements[id];

        imgui.TableNextRow();
        imgui.TableNextColumn();
        imgui.TextColored(colorOf(element), element.name);
        tip('element');

        imgui.TableNextColumn();

        if (row == nil) then
            imgui.TextDisabled('-');
            imgui.TableNextColumn();
            imgui.TextDisabled('-');
        else
            -- Both verdicts were composed by derivedOf when the answer landed;
            -- this loop only draws them (2026-09-06).
            imgui.TextColored(row.damageColor, row.damage);
            tip('coldamage');

            imgui.TableNextColumn();

            imgui.TextColored(row.landColor, row.land);
            tip('colland');
        end
    end

    imgui.EndTable();

    imgui.Separator();
    imgui.Text('Weapons');
    tip('weapons');

    -- A TABLE rather than string.format('%-14s') and a SameLine (2026-09-06):
    -- ImGui's font is proportional, so padding a name to a fixed character
    -- count lines nothing up -- "Blunt" and "Hand-to-hand" started their
    -- verdicts at different x. A column does what the padding was reaching for.
    if (imgui.BeginTable('##dwscan_physical', 2,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, elemW + 34,   0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, damageW + 12, 0);

        for index, lane in ipairs(PHYSICAL_LANES) do
            local row = view.lanes[index];

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(lane.name);
            tip('weapons');

            imgui.TableNextColumn();

            if (row == nil) then
                imgui.TextDisabled('-');
            else
                imgui.TextColored(row.damageColor, row.damage);
                tip('coldamage');
            end
        end

        imgui.EndTable();
    end

    imgui.Separator();
    imgui.Text('Cannot be given at all');
    tip('immunity');

    local immune = view.immune;

    if (immune == nil) then
        imgui.TextDisabled('Nothing -- every status effect can land on this one.');
        tip('immunity');
    else
        -- Wrapped as well as coloured: several `x|` records may have arrived
        -- and the list then runs off the right edge, which is where the
        -- interesting entries sit (the server sorts them alphabetically).
        imgui.PushTextWrapPos(0.0);
        imgui.TextColored(theme.colors.err, immune);
        imgui.PopTextWrapPos();
        tip('immunity');
    end
end

--[[
* THE TP MOVES ARE DRAWN FIRST, and the ordering is load-bearing rather than
* cosmetic. They arrive on `k|` from the FACTS binding, which has nothing to do
* with the quest index -- so a `return` above them (which is what 1.0 did) meant
* a server missing its interaction index also silently swallowed a move list the
* server had sent and the addon had already parsed. A refusal must only refuse
* the thing it is about.
--]]
local function tabQuests(scan)
    imgui.Text('TP moves');
    tip('tpmoves');

    if (not hasFacts()) then
        -- `k|` rides the facts binding too, so "None listed." on a build
        -- without it is a claim about a list the server never opened.
        imgui.TextColored(theme.colors.err, 'Unknown -- this server build has no facts binding.');
        tip('nobinding');
    elseif (#scan.skills == 0) then
        imgui.TextDisabled('None listed.');
        tip('tpmoves');
    else
        imgui.TextWrapped(derivedOf(scan).skills);
        tip('tpmoves');
    end

    imgui.Separator();

    if (state.caps ~= nil and not state.caps.quests) then
        imgui.TextColored(theme.colors.err, 'The server\'s quest index is not loaded, so nothing is claimed here.');
        tip('nobinding');

        return;
    end

    if (#scan.quests == 0) then
        imgui.TextDisabled('No quest or mission on this server watches for this one\'s death.');
        tip('qlimit');
    else
        for _, row in ipairs(derivedOf(scan).quests) do
            imgui.TextColored(theme.colors[row.color], row.badge);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(row.tip);
            end

            imgui.SameLine();

            -- WRAPPED (2026-09-06). `q|` fits the quest name to whatever is
            -- left of the 130-byte line, so it can be far longer than the
            -- three or four words the common case is -- and it starts after a
            -- badge, which is a third of the line already spent, in a window
            -- with nothing to scroll sideways. PushTextWrapPos starts the
            -- continuation under the item, which is under "Quest:".
            imgui.PushTextWrapPos(0.0);
            imgui.Text(row.line);
            imgui.PopTextWrapPos();
            tip('qstate');
        end
    end

    imgui.Separator();

    -- WRAPPED rather than hand-broken (2026-09-06), for the reason the
    -- Overview's ungauged notice is: the break was cut for one window width.
    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled('This is read from the server\'s own kill handlers -- what wants this thing DEAD. A quest that wants an item it drops will not appear here.');
    imgui.PopTextWrapPos();
    tip('qlimit');
end

--[[
* The Wide Scan tab (1.2.0). Renders `widescan`, which the packet handlers
* fill; every button is an injected retail packet (see the Wide Scan header
* further up). The MODEL may hold a whole camp; the SCREEN holds at most
* WS_VIEW_ROWS of it -- the dwah drawer lesson: hundreds of rows in one
* BeginTable, every frame, is an fps sink.
--]]
local WS_VIEW_ROWS = 50;
local WS_SORTS     = { 'Distance', 'Level', 'Name' };

-- The Selectable labels with their ImGui ids attached, built once: three
-- string.formats on every frame the popup was open, for three strings that
-- never change (2026-09-06).
local WS_SORT_ITEMS = { };

for index, label in ipairs(WS_SORTS) do
    WS_SORT_ITEMS[index] = string.format('%s##dwscan_ws_sort_%d', label, index);
end
local WS_MOB_COLOR = { r = 224, g = 96,  b = 84  }; -- the red dot
local WS_NPC_COLOR = { r = 112, g = 200, b = 124 }; -- the green dot

local WS_COLUMNS = {
    { '' },
    { 'Kind', 'wskind'  },
    { 'Lv',   'wslevel' },
    { 'Away', 'wsdist'  },
    { 'Name', 'wsname'  },
};

local wsSearch     = T{ '' };
local wsLastSearch = '';
local wsPage       = 1;

--[[
* THE FILTERED, SORTED VIEW, REBUILT ONLY WHEN SOMETHING IT DEPENDS ON MOVES
* (2026-09-06).
*
* This whole pass ran every frame, and the name sort is the reason that
* mattered: `table.sort` asks the comparator O(n log n) times and the
* comparator resolved a name on BOTH sides of every comparison. A hundred-row
* camp is roughly six hundred comparisons, so twelve hundred name resolutions
* plus a hundred more for the filter -- each one an entity binding call, a
* `:lower()` and, for anything the DAT could not name, a fresh formatted
* string. Eighty thousand a second, to redraw fifty rows that had not changed.
*
* The key is everything the answer depends on: the list's own revision (bumped
* only where `rows` is replaced) and the four local filters. A frame that moves
* none of them does no work at all. `dist` and `level` are snapshot values off
* the packet, so nothing in a row can change without a new list.
--]]
local wsView    = T{ };
local wsViewKey = false;

-- The five things the view is built from, kept as fields rather than folded
-- into a key string: five comparisons a frame allocate nothing, and a format
-- did (2026-09-06).
local wsViewRev  = -1;
local wsViewFind = nil;
local wsViewSort = nil;
local wsViewMobs = nil;
local wsViewNpcs = nil;

-- The one sentence the tab derives from the view, composed where the view is:
-- it was a string.format a frame for two counts that only move when the list
-- or a filter does (2026-09-06).
local wsCounts  = '';

local function wideScanView()
    local needle   = wsSearch[1]:lower();
    local sortMode = config.wsSort or 1;
    local mobs     = config.wsMobs ~= false;
    local npcs     = config.wsNpcs ~= false;
    if (wsViewKey and wsViewRev == widescan.rev and wsViewFind == needle
        and wsViewSort == sortMode and wsViewMobs == mobs and wsViewNpcs == npcs) then
        return wsView;
    end

    wsViewKey  = true;
    wsViewRev  = widescan.rev;
    wsViewFind = needle;
    wsViewSort = sortMode;
    wsViewMobs = mobs;
    wsViewNpcs = npcs;

    local view = T{ };

    for _, row in ipairs(widescan.rows) do
        local wanted = (row.type == 2 and mobs) or (row.type ~= 2 and npcs);

        if (wanted) then
            -- Resolved ONCE per row and kept on the view entry, so the sort
            -- comparator below and the draw loop both read a field instead of
            -- calling the resolver again.
            local name = wideScanName(row.idx);

            if (needle == '' or name:lower():find(needle, 1, true) ~= nil) then
                view:append({
                    idx   = row.idx,
                    level = row.level,
                    type  = row.type,
                    dist  = row.dist,
                    name  = name,
                    lower = name:lower(),

                    -- COMPOSED HERE (2026-09-06), because the draw loop below
                    -- built all three of these with string.format per row per
                    -- frame: the Track button's ImGui id, the level and the
                    -- distance. Fifty rows a page at sixty frames a second is
                    -- nine thousand formatted strings a second for text that
                    -- cannot change until the next list swaps in -- `dist` and
                    -- `level` are snapshot values off the packet.
                    track = string.format('Track##dwscan_ws_%d', row.idx),
                    lv    = row.level > 0 and string.format('%d', row.level) or '--',
                    away  = string.format('%dy', math.floor(row.dist + 0.5)),
                });
            end
        end
    end

    if (sortMode == 2) then
        table.sort(view, function (a, b)
            if (a.level ~= b.level) then
                return a.level > b.level;
            end

            -- Falls through to the targid like the other two (2026-09-06):
            -- two rows at the same level AND the same distance are a real
            -- case (a mob at 3,4 and one at 4,3 are both five yalms away),
            -- and a comparator that answers false both ways for them leaves
            -- their order to whatever the sort happened to do -- so the same
            -- camp came back in a different order each time the list moved.
            if (a.dist ~= b.dist) then
                return a.dist < b.dist;
            end

            return a.idx < b.idx;
        end);
    elseif (sortMode == 3) then
        -- The tie-break is the targid, which is unique: two mobs of one family
        -- share a name, and a comparator that answers false both ways for
        -- equal keys is a valid ordering but an unstable one -- the list
        -- reshuffled between frames for no reason a player could see.
        table.sort(view, function (a, b)
            if (a.lower ~= b.lower) then
                return a.lower < b.lower;
            end

            return a.idx < b.idx;
        end);
    else
        table.sort(view, function (a, b)
            if (a.dist ~= b.dist) then
                return a.dist < b.dist;
            end

            return a.idx < b.idx;
        end);
    end

    wsView   = view;
    wsCounts = string.format('%d in range, %d shown -- positions are a snapshot from the scan.',
        #widescan.rows, #view);

    return wsView;
end

--[[
* HOW OLD THE LIST IS (1.4.0).
*
* Positions are a snapshot -- the tab has always said so -- but "a snapshot"
* does not answer the question a player actually has, which is whether to press
* Rescan. With Auto off (the default) a list can be several minutes old and
* look exactly like one from a second ago, and every distance on it is then
* measured from somewhere the player no longer is.
*
* `scannedAt` is stamped by the ListEnd bracket, so it is the moment the list
* on screen became this list. Memoised on the whole second: the sentence is
* composed once a second rather than sixty times, and the clock is read once a
* frame on a tab that already reads it for the auto-refresh.
--]]
local wsAgeText = nil;
local wsAgeAt   = -1;

-- The tracking banner, remembered against the targid it names: it was a
-- string.format on every frame something was tracked, for a sentence that only
-- changes when the SERVER changes what it is tracking (2026-09-06).
local wsTrackText = nil;
local wsTrackFor  = nil;
local wsTrackRev  = -1;

local function wideScanTrackLine(idx)
    -- Keyed on the list REVISION as well as the targid, because the name in
    -- this sentence comes out of a cache that is thrown away with every new
    -- list and every zone line: the same targid across a zone is a different
    -- mob, and a memo on the number alone would keep the old one's name.
    if (idx ~= wsTrackFor or wsTrackRev ~= widescan.rev) then
        wsTrackFor  = idx;
        wsTrackRev  = widescan.rev;
        wsTrackText = string.format('Tracking on /map: %s', wideScanName(idx));
    end

    return wsTrackText;
end

local function wideScanAge()
    if (widescan.scannedAt == 0) then
        return nil;
    end

    local age = math.floor(os.clock() - widescan.scannedAt);

    if (age ~= wsAgeAt) then
        wsAgeAt = age;

        if (age < 2) then
            wsAgeText = 'scanned just now';
        elseif (age < 60) then
            wsAgeText = string.format('scanned %d seconds ago', age);
        elseif (age < 120) then
            wsAgeText = 'scanned a minute ago';
        else
            wsAgeText = string.format('scanned %d minutes ago', math.floor(age / 60));
        end
    end

    return wsAgeText;
end

local function tabWideScan()
    ensureZoneNames();

    -- A press the throttle held (see requestWideScan). It answers immediately
    -- once the throttle opens, and does nothing at all until then.
    if (widescan.wanted) then
        requestWideScan();
    end

    -- The first look asks by itself -- an empty tab whose one button is
    -- "Rescan" is a menu pretending to be a window. Once, and throttled:
    -- askedAt is 0 only before the first ask of a zone.
    if (widescan.askedAt == 0 and #widescan.rows == 0) then
        requestWideScan();
    end

    -- Auto-refresh runs only while this tab is actually drawing, which is
    -- exactly the "window open + tab visible" scope, and rides the same
    -- throttle as the button.
    if (config.wsAuto and elapsed(widescan.askedAt) >= WS_AUTO_INTERVAL) then
        requestWideScan();
    end

    --[[
    * TWO ROWS, NOT ONE (2026-09-06). Rescan, Auto, Mobs, NPCs, the sort combo
    * and the search box together run about 540 pixels of controls plus their
    * spacing -- wider than the interior of the default window, so the search
    * box (the one control a player is looking for in a hundred-row camp) sat
    * off the right edge until somebody widened the window.
    --]]
    if (imgui.Button('Rescan##dwscan_ws_rescan')) then
        requestWideScan();
    end

    tip('wsrescan');

    imgui.SameLine();

    if (imgui.Checkbox('Auto##dwscan_ws_auto', ui.wsAuto)) then
        commit();
    end

    tip('wsauto');

    imgui.SameLine();

    if (imgui.Checkbox('Mobs##dwscan_ws_mobs', ui.wsMobs)) then
        commit();
    end

    tip('wsmobs');

    imgui.SameLine();

    if (imgui.Checkbox('NPCs##dwscan_ws_npcs', ui.wsNpcs)) then
        commit();
    end

    tip('wsnpcs');

    imgui.PushItemWidth(104);

    local sortOpen = imgui.BeginCombo('##dwscan_ws_sort', WS_SORTS[config.wsSort] or WS_SORTS[1]);

    -- Asked before the popup's own items are submitted; see the TH dropdown.
    tip('wssort');

    if (sortOpen) then
        for index in ipairs(WS_SORTS) do
            if (imgui.Selectable(WS_SORT_ITEMS[index], config.wsSort == index)) then
                config.wsSort = index;

                -- commit(), like every other widget here. `apply()` does not
                -- carry wsSort (there is no ui holder for a combo), so this
                -- writes the choice above and re-applies the rest unchanged --
                -- which is what keeps every setting on one door.
                commit();
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
    imgui.SameLine();
    imgui.PushItemWidth(180);
    imgui.InputTextWithHint('##dwscan_ws_search', 'search by name', wsSearch, 48);
    imgui.PopItemWidth();
    tip('wssearch');

    if (wsSearch[1] ~= wsLastSearch) then
        wsLastSearch = wsSearch[1];
        wsPage       = 1;
    end

    if (widescan.tracking ~= 0) then
        imgui.TextColored(theme.colors.ok, wideScanTrackLine(widescan.tracking));
        tip('wsbanner');
        imgui.SameLine();

        if (imgui.SmallButton('Stop##dwscan_ws_stop')) then
            requestTrackStop();
        end

        tip('wsstop');
    else
        imgui.PushTextWrapPos(0.0);
        imgui.TextDisabled('Track a row to follow it on /map -- the native Wide Scan\'s Track, one click.');
        imgui.PopTextWrapPos();
        tip('wstrack');
    end

    local view = wideScanView();

    if (#widescan.rows == 0) then
        imgui.PushTextWrapPos(0.0);

        -- TWO DIFFERENT EMPTIES (2026-09-06). "No entries yet" was said both
        -- before the first answer and after an answer that legitimately
        -- contained nothing, so a scan of a quiet corner read as a scan that
        -- had not happened -- and the player pressed Rescan at a list that was
        -- already current. `scannedAt` is stamped by the ListEnd bracket, so it
        -- is the fact that separates them.
        if (widescan.scannedAt == 0) then
            imgui.TextDisabled('No entries yet. The list is range-limited (150 yalms for most jobs, more on RNG or BST) and same-floor -- every job widescans on DriftwoodXI.');
        else
            imgui.TextDisabled('Nothing in widescan range. The list reaches about 150 yalms for most jobs, further on RNG or BST, and only on your own floor.');
        end

        imgui.PopTextWrapPos();

        -- The age belongs on THIS branch too, and arguably more: "nothing in
        -- range" off a list five minutes old is a statement about where the
        -- player used to be standing (2026-09-06).
        local emptyAge = wideScanAge();

        if (emptyAge ~= nil) then
            imgui.TextDisabled(emptyAge);
            tip('wsage');
        end
    else
        imgui.TextDisabled(wsCounts);
        tip('wscounts');

        local age = wideScanAge();

        if (age ~= nil) then
            imgui.SameLine();
            imgui.TextDisabled(age);
            tip('wsage');
        end
    end

    imgui.Separator();

    local pages = math.max(1, math.ceil(#view / WS_VIEW_ROWS));

    if (wsPage > pages) then
        wsPage = pages;
    end

    if (pages > 1) then
        -- DISABLED AT THE ENDS (2026-09-06) rather than silently doing
        -- nothing: the two arrows used to look identical on page one and page
        -- five, and a button that reads as live and answers nothing reads as
        -- a broken window rather than as an edge.
        imgui.BeginDisabled(wsPage <= 1);

        if (imgui.SmallButton('<##dwscan_ws_prev')) then
            wsPage = wsPage - 1;
        end

        imgui.EndDisabled();

        imgui.SameLine();
        imgui.TextDisabled(string.format('Page %d / %d', wsPage, pages));
        tip('wspage');
        imgui.SameLine();

        imgui.BeginDisabled(wsPage >= pages);

        if (imgui.SmallButton('>##dwscan_ws_next')) then
            wsPage = wsPage + 1;
        end

        imgui.EndDisabled();
    end

    -- The name column STRETCHES (2026-09-06). It was a fixed 250, so the
    -- longest zone-list names clipped at the default width and a widened
    -- window grew nothing but empty space to the right of them.
    if (imgui.BeginTable('##dwscan_ws_rows', 5,
        bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY), { -1, -1 })) then
        imgui.TableSetupColumn('',      ImGuiTableColumnFlags_WidthFixed,   54, 0);
        imgui.TableSetupColumn('Kind',  ImGuiTableColumnFlags_WidthFixed,   34, 0);
        imgui.TableSetupColumn('Lv',    ImGuiTableColumnFlags_WidthFixed,   36, 0);
        imgui.TableSetupColumn('Away',  ImGuiTableColumnFlags_WidthFixed,   52, 0);
        imgui.TableSetupColumn('Name',  ImGuiTableColumnFlags_WidthStretch,  0, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        headers(WS_COLUMNS);

        local first = (wsPage - 1) * WS_VIEW_ROWS;

        for offset = 1, WS_VIEW_ROWS do
            local row = view[first + offset];

            if (row == nil) then
                break;
            end

            local tracked = widescan.tracking == row.idx;

            imgui.TableNextRow();
            imgui.TableNextColumn();

            if (tracked) then
                imgui.TextColored(theme.colors.ok, 'now');
                tip('wsbanner');
            else
                if (imgui.SmallButton(row.track)) then
                    requestTrack(row.idx);
                end

                tip('wstrack');
            end

            imgui.TableNextColumn();

            if (row.type == 2) then
                imgui.TextColored(colorOf(WS_MOB_COLOR), 'mob');
            else
                imgui.TextColored(colorOf(WS_NPC_COLOR), 'npc');
            end

            imgui.TableNextColumn();
            imgui.Text(row.lv);
            tip('wslevel');
            imgui.TableNextColumn();
            imgui.Text(row.away);
            tip('wsdist');
            imgui.TableNextColumn();

            if (tracked) then
                imgui.TextColored(theme.colors.ok, row.name);
            else
                imgui.Text(row.name);
            end
        end

        imgui.EndTable();
    end
end

--[[
* The tabs.
*
* `count` (1.3.0) is what goes in the parentheses after a label -- how many
* rows are behind that tab, so the tab bar itself says whether anything is
* there. A tab whose count is nil never grows parentheses (Overview is a page,
* not a list). The label is only ever the visible half: the ImGui identity is
* the `##dwscan_tab_<n>` suffix, so a count that changes does not make the tab
* bar think it is looking at a different tab.
--]]
-- A count is only ever drawn when the number MEANS something. A section the
-- server said it cannot answer reads "(0)" as "there are none of these", which
-- is exactly the confusion the greyed-with-a-reason panels exist to prevent.
local function dropCount(scan)
    if (scan == nil or (state.caps ~= nil and not state.caps.drops)) then
        return nil;
    end

    return scan.total;
end

local function questCount(scan)
    if (scan == nil or (state.caps ~= nil and not state.caps.quests)) then
        return nil;
    end

    return #scan.quests;
end

local function wideScanCount()
    return #widescan.rows > 0 and #widescan.rows or nil;
end

local TABS = {
    { label = 'Overview',  tip = 'taboverview', draw = tabOverview, needsScan = true },
    { label = 'Drops',     tip = 'tabdrops',    draw = tabDrops,    needsScan = true, scrolls = true, count = dropCount    },
    { label = 'Magic',     tip = 'tabmagic',    draw = tabMagic,    needsScan = true },
    { label = 'Quests',    tip = 'tabquests',   draw = tabQuests,   needsScan = true,                 count = questCount   },
    { label = 'Wide Scan', tip = 'tabwide',     draw = tabWideScan,                   scrolls = true, count = wideScanCount },
};

--[[
* The ImGui identities, composed once at load rather than per tab per frame
* (2026-09-06). `###dwscan_tab_N` is the suffix that keeps a tab's identity
* under a label whose count changes, and `##dwscan_body_<label>` names the
* scroll region; neither ever moves, and both were a string.format inside the
* draw. `shown` is the finished label remembered against the count it was built
* for, so a tab bar whose counts have not changed allocates nothing at all.
--]]
-- The Wide Scan tab's index, found by its label rather than written down as a
-- number: a tab inserted above it would otherwise retarget `/dwscan wide` in
-- silence.
local WIDE_TAB = 1;

for index, tab in ipairs(TABS) do
    if (tab.label == 'Wide Scan') then
        WIDE_TAB = index;
    end

    tab.id     = string.format('###dwscan_tab_%d', index);
    tab.bodyId = string.format('##dwscan_body_%s', tab.label);
    tab.plain  = tab.label .. tab.id;
    tab.shown  = nil;
    tab.shownN = nil;
end

-- The label a tab wears this frame, with its count if it has one.
local function tabLabel(tab, scan)
    local n = tab.count ~= nil and tab.count(scan) or nil;

    if (tab.shown ~= nil and tab.shownN == n) then
        return tab.shown;
    end

    tab.shownN = n;
    tab.shown  = n ~= nil and string.format('%s (%d)%s', tab.label, n, tab.id) or tab.plain;

    return tab.shown;
end

--[[
* The window.
--]]
local function headerRow(targid, name)
    if (imgui.Button('Scan##dwscan_scan')) then
        requestScan(targid);
    end

    tip('scan');

    imgui.SameLine();

    if (name ~= nil) then
        imgui.Text(name);
    else
        imgui.TextDisabled('nothing selected');
    end

    tip('target');

    imgui.SameLine();

    if (imgui.Checkbox('Follow target', ui.autoScan)) then
        commit();
    end

    tip('follow');

    if (#queue > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d queued...', #queue));
        tip('queued');
    end

    if (state.status ~= nil and state.status ~= '') then
        -- WRAPPED (2026-09-06). The longest status this window can show --
        -- "The server did not answer. Is this DriftwoodXI, and is the update
        -- installed?" -- is wider than the default window, and it is the one
        -- sentence a player most needs to read in full: the half that fell off
        -- the right edge was the half that says what to do about it.
        imgui.PushTextWrapPos(0.0);

        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end

        imgui.PopTextWrapPos();
    end

    imgui.Separator();
end

-- The tab bodies that are NOT tables of their own scroll inside this, because
-- the window carries NoScrollbar and manages its own regions: without it the
-- Overview of a mob with a long spawn line, or the Quests tab of one with
-- twelve involvements and a long TP list, simply ran off the bottom of the
-- default window with no way to reach the rest. The two tabs that ARE one big
-- table (Drops, Wide Scan) already scroll inside it and must not be nested in
-- a second scroll region.
local function tabBody(tab, scan)
    if (tab.scrolls) then
        tab.draw(scan);

        return;
    end

    if (imgui.BeginChild(tab.bodyId, { -1, -1 }, ImGuiChildFlags_None)) then
        tab.draw(scan);
    end

    imgui.EndChild();
end

local function renderWindow(targid, name)
    headerRow(targid, name);

    local scan = state.scan;

    -- The tab bar renders with or without a scan (1.2.0): the Wide Scan tab
    -- is about the zone, not the target, and must not sit behind a "press
    -- Scan first" wall. The scan-shaped tabs carry the placeholder INSIDE
    -- themselves instead of the whole window early-returning.
    if (scan ~= nil) then
        imgui.Text(scan.name);
        tip('scanned');

        -- WHOSE MOB THIS IS (1.3.0). The header line above says what you have
        -- targeted NOW and this line says what the window is describing, and
        -- until this note the two silently disagreed the moment you tabbed to
        -- the next mob -- a drop table read as the new target's.
        if (scan.targid ~= nil and targid ~= 0 and scan.targid ~= targid) then
            imgui.SameLine();
            imgui.TextDisabled('(not your current target -- press Scan)');
            tip('stale');
        end

        -- Wrapped: a note is a whole server sentence and the budget lets it
        -- run to 128 bytes, which is wider than any window this addon opens.
        if (#scan.notes > 0) then
            imgui.PushTextWrapPos(0.0);

            for _, note in ipairs(scan.notes) do
                imgui.TextColored(theme.colors.warn, note);
                tip('note');
            end

            imgui.PopTextWrapPos();
        end
    end

    if (imgui.BeginTabBar('##dwscan_tabs')) then
        for index, tab in ipairs(TABS) do
            --[[
            * THE TAB THIS WINDOW OPENS ON (1.4.0).
            *
            * ImGui does not persist a tab bar's selection, so every session
            * started on the Overview -- including for a player who lives on
            * the Wide Scan tab, and including the window `/dwscan wide` opens
            * specifically to show it. `wantTab` is a ONE-SHOT: the flag is
            * only passed while it names this tab, and the body clears it the
            * first frame the tab actually opens, so the player can still
            * click anywhere afterwards. (The dwparse shape.)
            --]]
            local flags = ImGuiTabItemFlags_None;

            if (state.wantTab == index) then
                flags = ImGuiTabItemFlags_SetSelected;
            end

            -- `###` and not `##` (1.3.0): with `##` the ImGui id is a hash of
            -- the WHOLE label, so a count that ticks from (8) to (9) is a
            -- different tab as far as the tab bar is concerned -- it loses the
            -- selection and re-lays the bar out. `###` makes the id the suffix
            -- alone, which is the dwah Orders-tab precedent.
            local open = imgui.BeginTabItem(tabLabel(tab, scan), nil, flags);

            --[[
            * THE TABS EXPLAIN THEMSELVES ON HOVER (2026-09-06), and the test
            * sits HERE rather than inside the `if`: ImGui submits the tab as
            * an item inside BeginTabItem, so this reads the TAB whether it
            * opened or not, and the first widget the body draws would take
            * "the last item" away. (The dwbags shape.)
            --]]
            tip(tab.tip);

            if (open) then
                if (state.wantTab == index) then
                    state.wantTab = nil;
                end

                -- Remembered per PC, and only once the forced selection has
                -- been consumed: writing while wantTab is still steering would
                -- record the tab the player was pushed to rather than the one
                -- they chose. commitSoon rather than commit, because clicking
                -- along a tab bar should not be a file write per tab.
                if (state.wantTab == nil and config.tab ~= index) then
                    config.tab = index;

                    commitSoon();
                end

                if (tab.needsScan and scan == nil) then
                    imgui.TextDisabled('Target a monster and press Scan.');
                    imgui.Separator();
                    imgui.TextWrapped('Everything here is read off this server, not a wiki: drop rates carry the ' ..
                        'server multiplier, exp carries the server rate, and aggro ranges are the ones actually used.');
                else
                    tabBody(tab, scan);
                end

                imgui.EndTabItem();
            end
        end

        imgui.EndTabBar();
    end
end

--[[
* Follow-target. Fires at most once per target change and never while a scan is
* already in flight -- one chat line per change is the budget, and a player
* sweeping a camp with the tab key must not queue twelve of them.
--]]
local function pumpAutoScan(targid)
    if (not config.autoScan or state.refused or not state.spoke) then
        return;
    end

    if (targid == 0) then
        state.lastAuto = nil;

        return;
    end

    if (state.lastAuto == targid or state.asked ~= nil) then
        return;
    end

    --[[
    * Only monsters (dwcon's spawn-flag gate, 0x10): the budget is one chat
    * line per target CHANGE, and tabbing through a town spent it asking the
    * server about NPCs and players it refuses by sentence -- a red status bar
    * per click. A refusal the lookup actually STATED is latched, so a non-mob
    * costs one decision and no line.
    *
    * BUT THE LATCH NOW WAITS FOR AN ANSWER (2026-09-06). It used to be set
    * before the lookup ran, and a pcall that FAILED is not an answer of "not a
    * monster" -- the entity table is briefly unreadable around a zone line and
    * before the entity list is handed over, which is exactly when a player
    * tabs to the first thing they see. One unlucky frame retired that target
    * from Follow target for as long as it stayed selected, silently, in the
    * one moment the feature exists for. Asking again next frame costs a pcall.
    --]]
    local ok, isMob = pcall(function ()
        local entity = AshitaCore:GetMemoryManager():GetEntity();

        return bit.band(entity:GetSpawnFlags(targid), 0x10) ~= 0;
    end);

    if (not ok) then
        return;
    end

    state.lastAuto = targid;

    if (not isMob) then
        return;
    end

    requestScan(targid);
end

--[[
* The frame. The queue is pumped first so a line goes out whether or not
* anything is being drawn, then the window -- Begin/End and the theme push/pop
* sit OUTSIDE the render pcall so both stacks stay balanced whatever the render
* pass does.
--]]
ashita.events.register('d3d_present', 'dwscan_present', function ()
    pumpQueue();
    pumpEnvelope();
    pumpPending();
    pumpAnswer();
    pumpSave();

    if (not state.open[1]) then
        return;
    end

    -- Read ONCE per frame and handed down (2026-09-06). The header row asked
    -- the memory manager for the target and then for its name, and
    -- pumpAutoScan asked for it again -- several binding calls a frame for one
    -- number that cannot change inside a frame.
    local targid = currentTarget();
    local name   = targetName(targid);

    pumpAutoScan(targid);

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 540, 520 }, ImGuiCond_FirstUseEver);

    -- A FLOOR ON THE SIZE (2026-09-06). Nothing stopped this window being
    -- dragged down to a title bar and a sliver: the tab bar collapsed to a
    -- scroll arrow, the Drops footer buttons went under the bottom edge, and
    -- the size is remembered in imgui.ini -- so the next login reopened it
    -- unusable with no obvious way back. The minimum is the width of the
    -- widest control row plus the height of the header, the tab bar and a few
    -- rows.
    imgui.SetNextWindowSizeConstraints({ 500, 320 }, { 99999, 99999 });

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads.
    local visible = imgui.Begin('DriftwoodXI Scan##dwscan', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow, targid, name);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwscan'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwscan'):append(chat.message('Window closed. !scan still works, typed.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow(tabIndex)
    state.open[1]  = true;
    state.reported = false;

    -- The remembered tab, or the one a verb asked for. Range-checked here
    -- rather than in sanitize(), which runs long before TABS exists: a value a
    -- hand-edited settings file put out of range would otherwise leave
    -- `wantTab` naming a tab that never opens, and nothing would ever clear it.
    local wanted = tabIndex or config.tab or 1;

    if (type(wanted) ~= 'number' or wanted < 1 or wanted > #TABS) then
        wanted = 1;
    end

    state.wantTab = math.floor(wanted);

    -- The handshake goes on window open, not on load: an automatic line against
    -- a server without the module is the player saying it in /say.
    hello();
end

--[[
* `/dwscan` (and `/scan`) opens the window on the tab it was last left on;
* `/dwscan now` scans immediately without opening anything, which is the
* one-key version for a hotkey; `/dwscan wide` opens straight onto the Wide
* Scan tab; `/dwscan track` follows the current target on /map; `/dwscan help`
* lists them. A word that is none of those is answered rather than swallowed.
--]]
ashita.events.register('command', 'dwscan_command', function (e)
    local args = e.command:args();

    if (#args == 0) then
        return;
    end

    local first = args[1]:lower();

    if (first ~= '/dwscan' and first ~= '/scan') then
        return;
    end

    e.blocked = true;

    local verb = (args[2] or ''):lower();

    -- requestScan handshakes for itself when the server has not spoken yet and
    -- holds the scan until it has, so there is no hello to send by hand here --
    -- doing it separately is what put a blind `!dwn scan` on the wire in 1.0.
    if (verb == 'now') then
        requestScan(currentTarget());

        -- AND THE REFUSAL IS SAID OUT LOUD (2026-09-06). `now` is the hotkey
        -- lane and it exists to work with the window SHUT -- which is exactly
        -- where requestScan's red status line has nowhere to appear. Pressed
        -- with nothing targeted, or against a server that has not spoken, the
        -- key did nothing at all and said nothing about it. Only the refusals:
        -- a scan that went out is answered by the window a moment later, and
        -- announcing "Scanning..." in chat would be noise on every press.
        if (not state.open[1] and state.statusBad and state.status ~= '') then
            print(chat.header('dwscan'):append(chat.error(state.status)));
        end

        return;
    end

    -- `/dwscan track` follows the current target on /map without opening
    -- anything -- the hotkey version of the Wide Scan tab's Track button,
    -- and `/dwscan track off` puts the dot away. Injected retail packets,
    -- so it works on anything the native Wide Scan could track.
    if (verb == 'track') then
        local mode = (args[3] or ''):lower();

        if (mode == 'off' or mode == 'stop') then
            requestTrackStop();
        else
            local targid = currentTarget();

            if (targid == 0) then
                print(chat.header('dwscan'):append(chat.message('Select something to track first.')));
            else
                requestTrack(targid);
            end
        end

        return;
    end

    --[[
    * `/dwscan wide` (1.4.0), with the two spellings a player is likely to
    * reach for. The Wide Scan tab is the one thing in this window that is
    * about the ZONE rather than about a target, so it is the one a player
    * wants a key for -- and until now the only way to it was to open the
    * window and click, on whatever tab the session happened to start on.
    --]]
    if (verb == 'wide' or verb == 'widescan' or verb == 'ws') then
        openWindow(WIDE_TAB);

        return;
    end

    -- `/dwscan help` (1.3.0). Every other verb this addon answers is
    -- undiscoverable: `now` and `track` exist only in the load line and in
    -- this file, so a player who wanted a hotkey had to be told. Printed
    -- rather than opened, because a player asking for help may not want a
    -- window in front of them.
    if (verb == 'help' or verb == '?') then
        print(chat.header('dwscan'):append(chat.message('/dwscan         -- open or close the window')));
        print(chat.header('dwscan'):append(chat.message('/dwscan now     -- scan what you have targeted, no window')));
        print(chat.header('dwscan'):append(chat.message('/dwscan wide    -- open the window on the Wide Scan tab')));
        print(chat.header('dwscan'):append(chat.message('/dwscan track   -- follow your target on /map (track off puts it away)')));
        print(chat.header('dwscan'):append(chat.message('!scan           -- the same answers typed, in sentences, with no addon')));

        return;
    end

    --[[
    * AND A WORD THIS FILE DOES NOT KNOW IS ANSWERED (1.4.0).
    *
    * Every unrecognised verb fell through to the toggle, so `/dwscan trak` --
    * one letter off the tracking verb -- opened or closed the window instead
    * of tracking anything, and said nothing about why. A bare `/dwscan` is
    * still the toggle; this only catches a word that was meant to be a verb.
    --]]
    if (verb ~= '') then
        print(chat.header('dwscan'):append(chat.error(
            string.format('"%s" is not a dwscan command. Try /dwscan help.', verb))));

        return;
    end

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

--[[
* Watch what the player sends.
*
* `!scan ui` (and `window`, and `gui`) is caught here and opens the window
* instead of going out -- the `!port ui` / `!warehouse ui` idiom. A BARE
* `!scan` is deliberately NOT caught: it is the typed tier, it has to keep
* answering in sentences for a player with no addon and for anyone checking
* what the server is actually saying when the window looks wrong, and
* swallowing it would make the addon required for a command that exists
* because it is not. (The header here claimed the opposite until 2026-09-06;
* the code was right and the comment was not.)
*
* Any other outgoing chat line stamps the send throttle, because the client's
* rate limit is on chat and not on this addon.
--]]
ashita.events.register('packet_out', 'dwscan_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    -- `data_modified or data`, for the reason the 0x017 reader takes it: this
    -- handler is not inside a pcall and an addon ahead of us that hands the
    -- packet on unmodified would be a Lua error on every line the player types.
    local data = e.data_modified or e.data;

    if (data == nil) then
        return;
    end

    local message = data:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!scan ui' or lower == '!scan window' or lower == '!scan gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwn') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwscan_load', function ()
    print(chat.header('dwscan'):append(chat.message('/dwscan reads your target -- level, drops at this server\'s rates, resistances, quests. /dwscan help lists the rest; !scan does it typed.')));
end);

--[[
* THE DEFERRED WRITE IS FLUSHED HERE (2026-09-06).
*
* commitSoon applies instantly and puts the FILE write 0.6s out, which is what
* keeps a drag of the rate slider from writing sixty times a second. The write
* rides d3d_present, and `/addon reload dwscan` -- which is how the launcher
* installs an update and how anyone iterating on this file re-runs it -- stops
* the frames before that 0.6s is up. The setting the player had just moved was
* then applied for the rest of the session and gone by the next one, which
* reads exactly like a setting that does not persist.
*
* Unconditional rather than gated on `saveAt`: settings.save() with nothing
* pending writes the same bytes that are already on disk.
--]]
ashita.events.register('unload', 'dwscan_unload', function ()
    saveAt = nil;

    pcall(settings.save);
end);
