--[[
* DriftwoodXI -- dwquest
*
* The Drift Board in a window: the three daily and three weekly contracts
* offered to your level band, the ones you have signed with their counters
* moving as you fight, what each pays, how long is left, and your Drift Coins.
* Accept and abandon are buttons. `/quests` opens it from anywhere -- there is
* no NPC to walk to, because the window IS the quest giver.
*
* The arrows by the band label page through every level band's board -- a
* read, so a player can see what other jobs would be offered before deciding
* to switch. Accepting stays own-band only (the server resolves accept off
* the real level), and one contract per slot per reset holds ACROSS bands:
* an offer whose slot is already spent renders its sentence, not a button.
*
* Below them sits the server-wide contract: one bar the whole server pushes,
* with no button, because there is no verb that accepts it -- you contribute by
* killing, and the card's job is to say whether this account is on the payout.
*
* The second tab is the Drift Exchange: today's four augment offers, the gear
* they can go on -- yours and your offline alts' -- how many of an item's four
* augment slots are used, and the two-step price-then-buy that spends the
* coins the first tab earns.
*
* The third tab is the Augments reference (2026-08-19): every augment id the
* server's engine implements, with the label a player can read beside the
* number the exdata actually stores -- because the Exchange shows occupied
* slots by id, and "which augment do I give up" is unanswerable in raw
* numbers. Rows the Exchange sells are marked with their tier price, and the
* four on offer TODAY are marked off the same u| records the Exchange tab
* renders, with a Choose button that feeds the same picker. The catalog
* itself is augcatalog.lua beside this file -- GENERATED from sql/augments.sql
* by tools/dwquest/gen_augment_catalog.py, never edited by hand, and gated
* byte-for-byte by the same checkers that gate the storefront -- because ~700
* labeled rows can never ride a 130-byte-per-line chat wire. The same catalog
* decodes the Exchange tab's slot views in place ("Dbl.Atk.+3%" instead of
* "augment 143 rank 3"), computing each rank's real magnitude only where the
* generator could VERIFY the arithmetic against the engine's own formula.
* Missing catalog file = the raw numbers this window always showed, plus a
* line saying so; nothing else degrades.
*
* The fourth tab is the Outfitter (Phase 7; the relic tier joined 2026-08-22,
* the Empyrean +2 and AF +1 tiers 2026-09-03): the level 50-60 artifact
* sets, the level-74 AF +1 sets, the relic sets and the level 81-89
* Empyrean +2 sets, each row priced off the wire
* (the tiers differ), paged by job, every row drawn with the
* client's own item icon
* and hover card off the id the f| record carries. Static stock, no rotation
* -- and every piece is Rare/Ex, so what this shop sells can reach your own
* characters through the dwbags lane and can never leave your account.
*
* The ArmsDealer (2026-08-20) and the Pop-Items shelf (2026-08-30) follow it,
* and the Jeweler (2026-09-03) sits last: the CoP-era earrings and rings --
* the Wyrmking five, the Sea three, the Apocalypse Nigh rings -- priced per
* case off the wire, the whole shelf on one read under its case headers, the
* same Buy-quotes / Confirm-spends dance and the same Rare/Ex rule.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It ships no pool, no prices, no progress and no arithmetic. Every contract,
* every count, every reward and every countdown arrives as _DWUDATA records
* answering `!dwu hello` (documentation/dwu_protocol.md), and the server
* re-resolves the contract from its own rotation whichever way the command
* arrived. A click issues a line a player could type (`!dwu accept d1`), and
* THE CLIENT NEVER SENDS A QUEST DEFINITION -- it sends a slot name. There is
* no record on this wire that could tell the server what a contract needs,
* pays, or is worth, so a bug in this window cannot mint a coin.
*
* THE SAME IS TRUE OF THE STOREFRONT, WHERE IT MATTERS MORE. The price is a
* `p|` record; the item is named by the id a `c|` record carried; the eligible
* gear is the server's own screen and not this client's inventory, which
* cannot see an offline alt's bags and knows none of the rules. The Confirm
* button exists only while a quote is armed, a quote is armed only by a `p|`,
* and the click that sends `confirm` disarms it in the same statement -- so
* one quote can buy at most one thing, and a window that never asked can buy
* nothing at all.
*
* THE ONE NUMBER THAT MOVES LOCALLY IS A CLOCK. The board header and every
* contract carry countdowns that were exact when the server built the record;
* the window ticks them down between syncs and re-asks when the rotation one
* reaches zero (dwu_protocol.md, `y|`). Nothing else here is computed --
* not a price, not a payout, not a progress count.
*
* TYPING `!drift` ON ITS OWN OPENS THIS WINDOW. The line is intercepted before
* it leaves the client; every other !drift command passes through.
*
* IT ALSO MOVES REWARD TEXT OUT OF THE BATTLE LOG. Fields of Valor, Grounds of
* Valor and Records of Eminence payouts are drawn by the CLIENT from message
* ids, so the server cannot tag them the way it tags a Drift Board notice --
* and they land in the same window as a dozen damage lines a second. This addon
* blocks them and re-prints them where the rest of its output goes.
* `/quests rewards off` turns that off and it stays off.
*
* TURN IT OFF AND NOTHING IS LOST. `!drift`, `!drift accept d1`,
* `!drift abandon a1`, `!drift balance`, `!drift augments`, `!drift gear x1`,
* `!drift augment x1 Bronze Sword`, `!drift shelf war`, `!drift buy 21` and
* `!drift confirm` all work typed. This is friendlier; it is not required.
--]]

addon.name    = 'dwquest';
addon.author  = 'DriftwoodXI';
addon.version = '1.18.0';
addon.desc    = 'The Drift Board for DriftwoodXI -- daily, weekly and server-wide contracts, live progress, Drift Coins, the augment Exchange with a full augment reference, the Outfitter, the ArmsDealer, the Pop-Items shelf, and the Jeweler.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local theme    = require('dwtheme');
local echo     = require('dwecho');
local settings = require('settings');

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load: this addon is
* loaded from the launcher's boot script, long before the client has a
* rendering device, and a file-scope d3d.get_device() would make the whole
* addon fail to load (dwbags' lesson, kept verbatim via dwraid). Nothing
* here needs a device until the first Outfitter icon is drawn.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. Nine
-- other addons own nine other names; this addon must never contend for any of
-- them, which is why `!dwu` exists at all -- the obvious `!dwq` belongs to
-- alt storage (DWQUEST_PLAN.md F1).
local DATA_SENDER = '_DWUDATA';

-- Bumped only for a breaking change to the record layout.
local PROTOCOL = 1;

--[[
* The augment catalog -- augcatalog.lua beside this file, GENERATED by
* tools/dwquest/gen_augment_catalog.py (see the header). pcall'd because a
* half-synced addon folder is a real deployment state (the 2026-08-16 stamped
* bundle closed the common case, not every case), and a missing reference
* file must cost exactly the reference: the window falls back to the raw
* numbers it always showed, and the Augments tab says what is missing.
--]]
local haveCatalog, augcatalog = pcall(require, 'augcatalog');

if (not haveCatalog or type(augcatalog) ~= 'table'
        or type(augcatalog.augments) ~= 'table' or type(augcatalog.pool) ~= 'table') then
    haveCatalog = false;
    augcatalog  = { augments = { }, pool = { } };
end

--[[
* The Weapon Burst shelf's ten augments (weapon_burst.sql ids 2030..2039)
* are DriftwoodXI's own, so the generated catalog never learns them --
* overlaid here rather than hand-edited into the generated file, which a
* catalog rebuild would silently drop. Without a name the slot renders as
* 'augment 2030 rank 1' (owner report, 2026-08-25).
--]]
for offset, element in ipairs({
    'Fire', 'Ice', 'Wind', 'Earth', 'Thunder',
    'Water', 'Light', 'Dark', 'Shield', 'Enfeeble',
}) do
    local augid = 2029 + offset;

    if (augcatalog.augments[augid] == nil) then
        augcatalog.augments[augid] = { l = string.format('Weapon Burst: %s', element) };
    end
end

--[[
* One augment slot, in words. `rank` is the wire's human rank (the stored
* exdata value plus one -- quest_store.cpp:2110).
*
* An entry with substitution terms gets its digit runs recomputed for this
* rank: term k applies to the k-th digit run, a bare number n means
* n + stored, a pair { b, s } means b + stored * s -- the generator emits a
* term ONLY where it verified that arithmetic against the engine's own
* formula, so this function never invents a magnitude. An entry without
* terms keeps its rank-1 label and says the rank instead; an id the catalog
* does not know renders as the raw number it always was.
--]]
local function augmentText(augid, rank)
    local entry = augcatalog.augments[augid];

    if (entry == nil) then
        return string.format('augment %d rank %d', augid, rank);
    end

    local label  = entry.l;
    local stored = rank - 1;

    if (entry.m ~= nil) then
        if (stored > 0) then
            local k = 0;

            label = string.gsub(label, '%d+', function(digits)
                k = k + 1;

                local term = entry.m[k];

                if (term == nil) then
                    return digits;
                end

                if (type(term) == 'table') then
                    return tostring(term[1] + stored * term[2]);
                end

                return tostring(term + stored);
            end);
        end
    elseif (rank > 1) then
        label = string.format('%s (rank %d)', label, rank);
    end

    return string.format('%s  [%d]', label, augid);
end

--[[
* THE NOTICE TAG -- the literal quest_core.lua puts in front of every
* unsolicited line the Drift Board prints into chat, and the whole reason the
* text_in handler at the bottom of this file exists.
*
* WHY THE SERVER CANNOT JUST SEND IT TO THE RIGHT WINDOW. The client shows two
* chat logs and routes a line between them by the message CATEGORY, mapped to a
* window by the player's own filter config. The 0x017 packet the server writes
* with has a Kind, an Attr, a zone id and 150 bytes of text -- and no window
* field (src/map/packets/s2c/0x017_chat_std.h). Every DriftwoodXI module prints
* on SYSTEM_3, so on the ordinary two-window setup -- battle left, chat right --
* a payout arrives in the same window as a dozen lines a second of somebody
* else's damage numbers. That is the complaint this answers.
*
* WHAT ACTUALLY MOVES IT. An addon's own `print()` does not travel the 0x017
* path at all; it is written into the log directly and lands with the rest of a
* player's addon chatter, which is the window they keep for reading. So the
* server tags, this file blocks the tagged line, and print() puts the same
* sentence back where it can be read. Nothing else in the client is reachable
* from here, and nothing on the server can substitute for it.
*
* KEEP IN SYNC WITH `NOTICE` IN modules/driftwoodxi/quest_core.lua. One literal
* across a server module and a client addon that ship on separate paths is the
* shape that drifts silently -- a mismatch is not an error anywhere, it is just
* every notice quietly back in the battle log. harness_dwquest.py reads both
* real files and fails when they disagree, and the map's boot line prints this
* value verbatim so prod can be asked what it is actually sending.
*
* MATCHED ANYWHERE IN THE LINE, not anchored: the client hands a line to
* text_in with whatever decoration it carries, and a tag that only matches at
* byte one is a tag that silently stops matching the day a prefix appears. The
* cost of the loose match is that a player who types the tag by hand has the
* rest of their sentence re-printed one window over, which is a curiosity
* rather than a bug -- against a payout line that arrives during an AoE pull
* and is never seen, that trade is not close.
--]]
local NOTICE_TAG = '[Drift] ';

--[[
* THE REWARD REROUTE -- the same lever as the notice tag, pointed at lines the
* server cannot tag at all.
*
* Fields of Valor, Grounds of Valor and Records of Eminence do not print
* sentences. They send message ids -- `player:messageBasic(xi.msg.basic.
* FOV_OBTAINS_TABS, ...)` in scripts/globals/regimes.lua, ROE_COMPLETE and
* friends in scripts/globals/roe.lua -- and the CLIENT draws the words out of
* its own dat files. There is no string on the server to put `[Drift] ` in
* front of, and 0x0029 (GP_SERV_COMMAND_BATTLE_MESSAGE) has no window field any
* more than 0x0017 does. So a payout of 426 tabs lands in the battle log beside
* a dozen damage lines a second, which is the complaint this answers, and the
* ONLY place it can be answered is here: text_in sees the line after the client
* has rendered it, print() can put it somewhere else.
*
* (That text_in sees client-rendered battle messages at all is not an
* assumption: the bundled LootScope reads `X defeats MobName.` from it, and
* customcolors recolours the whole venture/trial family the same way.)
*
* MATCHING IS ON THE RENDERED ENGLISH, which is the part that can rot. A dat
* file wording that moves is a pattern that silently stops matching -- so the
* patterns are deliberately the SHORTEST distinctive fragment of each line
* rather than the whole sentence, and every one of them is asserted against the
* xi.msg.basic comment for its own message id in harness_dwquest.py. That
* harness reads scripts/enum/msg.lua, so a server that renumbers or reworders a
* message is a red gate rather than a feature that quietly stopped working.
*
* TWO LISTS, BECAUSE HALF THESE LINES ARE NOT EXCLUSIVE TO A REWARD.
*
*   FAMILY  -- fragments that can only come from a regime or a record. `obtains
*              426 tabs.` is one: tabs exist nowhere else on this server.
*              Rerouted whenever they arrive.
*
*   BURST   -- fragments that are ordinary battle-log traffic on their own.
*              `gains 2140 experience points.` is the same message id on a
*              regime completion and on every mob you kill, so rerouting it by
*              pattern would empty the battle log of exp. These move ONLY
*              inside a reward burst: a short window opened by one of the
*              ANCHOR lines below, which are the sentences a payout always
*              follows (`...completed the training regime.`, `...Records of
*              Eminence objective: ...`).
*
* THE PER-KILL PROGRESS LINE IS NOT AN ANCHOR, deliberately. `You defeated a
* designated target. (Progress: 2/2)` fires on every credited kill, so opening
* a burst on it would reroute the exp line of every kill a player makes while
* a regime is up -- which is not "the reward text", it is the battle log.
*
* THE BURST REFRESHES ON EVERY LINE IT TAKES rather than counting from the
* anchor. A completion is seven lines that arrive together and the window only
* has to outlive the gap between two of them; a fixed deadline from the anchor
* would have to be long enough for the whole burst and would therefore be long
* enough to catch an unrelated kill at the end of it.
--]]
local REWARD_FAMILY = T{
    -- Fields of Valor / Grounds of Valor (scripts/globals/regimes.lua).
    'You defeated a designated target',              -- FOV_DEFEATED_TARGET 558
    'successfully completed the training regime',    -- FOV_COMPLETED_REGIME 559
    'training regime will begin anew',               -- FOV_REGIME_BEGINS_ANEW 643
    'obtains [%d,]+ tabs?%.',                        -- FOV_OBTAINS_TABS 566
    'Prowess attained',                              -- the GoV prowess effects

    -- Records of Eminence (scripts/globals/roe.lua).
    'completed the following Records of Eminence objective', -- ROE_COMPLETE 690
    'This objective may be repeated',                -- ROE_REPEAT_OR_CANCEL 691
    'sparks of eminence',                            -- ROE_RECEIVE_SPARKS 692, FIRST_TIME 707
    'As a special bonus for your valiant efforts',   -- ROE_BONUS_ITEM 693/694/709
    'Records of Eminence: ',                         -- ROE_RECORD 697
    'A new objective has been added',                -- ROE_NEW_OBJECTIVE 699
    'as a special reward',                           -- ROE_OBTAINED_KEY_ITEM 706
    'cleared to fulfill this objective once again',  -- ROE_TIMED_CLEAR 710
    'Unity accolade',                                -- ROE_RECEIVED_ACCOLADES 741
};

local REWARD_BURST = T{
    'obtains [%d,]+ gil',                            -- FOV_OBTAINS_GIL 565
    'gains [%d,]+ experience points',                -- and the record's exp
    'gains [%d,]+ limit points',
    'Progress: %d+/%d+%.',                           -- ROE_PROGRESS 698
};

local REWARD_ANCHORS = T{
    'successfully completed the training regime',
    'completed the following Records of Eminence objective',
    'Records of Eminence: ',
};

--[[
* WHAT COLOUR A MOVED LINE IS PRINTED IN.
*
* Seven lines arrive together on a page completion and they are not seven of
* the same thing: one says a regime finished, three say what it paid, one is a
* counter. Printed in a single colour they read as a wall -- which is what the
* battle log did to them, and moving the wall one window over only makes it a
* quieter wall. Four buckets, so the eye can find the payout without reading.
*
* THE CODES ARE COLOUR TABLE 1, and every one of them is a colour the Ashita
* chat library names, so a reader can look it up rather than trust a number:
* LawnGreen 2, Cyan 6, Moccasin 7 and Yellow 69 (libs/chat.lua, chat.colors).
* `chat.message`'s own cream 106 is deliberately NOT one of them -- it stays the
* colour of everything else this addon prints, so a rerouted reward line is
* visibly a different kind of line from a Drift Board notice.
*
* KEYED BY THE ADDON'S OWN PATTERN TEXT, and every pattern in REWARD_FAMILY and
* REWARD_BURST must appear here -- harness_dwquest.py fails when one does not.
* That is the same shape as the harness's REWARD_SOURCES map and it is there
* for the same reason: the cost of a missing entry is not a crash, it is one
* line that quietly goes back to looking like all the others, which nobody
* would notice for months. A plain table, not T{ }: the keys are arbitrary
* pattern text and T{ }'s sugar method names shadow string keys.
--]]
local TINT_MILESTONE = 2;   -- LawnGreen: the thing that completed.
local TINT_CURRENCY  = 69;  -- Yellow:    gil, tabs, sparks, accolades, items.
local TINT_POINTS    = 6;   -- Cyan:      experience and limit points.
local TINT_PROGRESS  = 7;   -- Moccasin:  counters and bookkeeping.
local TINT_LIMIT     = 73;  -- Violet:    limit points and limit chains (the feed).
local TINT_CAPACITY  = 8;   -- Coral:     capacity points and capacity chains (the feed).

local REWARD_TINTS = {
    ['You defeated a designated target']                      = TINT_PROGRESS,
    ['successfully completed the training regime']             = TINT_MILESTONE,
    ['training regime will begin anew']                        = TINT_PROGRESS,
    ['obtains [%d,]+ tabs?%.']                                 = TINT_CURRENCY,
    ['Prowess attained']                                       = TINT_MILESTONE,
    ['completed the following Records of Eminence objective']  = TINT_MILESTONE,
    ['This objective may be repeated']                         = TINT_PROGRESS,
    ['sparks of eminence']                                     = TINT_CURRENCY,
    ['As a special bonus for your valiant efforts']            = TINT_CURRENCY,
    ['Records of Eminence: ']                                  = TINT_MILESTONE,
    ['A new objective has been added']                         = TINT_PROGRESS,
    ['as a special reward']                                    = TINT_CURRENCY,
    ['cleared to fulfill this objective once again']           = TINT_PROGRESS,
    ['Unity accolade']                                         = TINT_CURRENCY,
    ['obtains [%d,]+ gil']                                     = TINT_CURRENCY,
    ['gains [%d,]+ experience points']                         = TINT_POINTS,
    ['gains [%d,]+ limit points']                              = TINT_POINTS,
    ['Progress: %d+/%d+%.']                                    = TINT_PROGRESS,
};

--[[
* THE KILL FEED (2026-08-30) -- the owner's report, verbatim shape: the defeat
* line, the limit and capacity chains and their payouts, and the gil line "get
* drowned out quickly during the spam that's sent to Window #1".
*
* THIS ONE DOES NOT print(). The client draws two chat logs and files a line
* between them by its CATEGORY; the player's Log config maps categories to
* windows, and on the STOCK config (config addon README, ids 185-188) Window 1
* is all battle/system and Window 2 is all chat. So the lever is the line's
* MODE: text_in hands it to us writable as e.mode_modified (the bundled
* timestamp addon rewrites it the same way), and a line re-moded into the CHAT
* group is a line the client files in Window 2. Mode 222 is Assist E
* (server Kind NA_ASSIST) -- a chat-group channel nothing on this server ever
* speaks on, so hijacking it collides with nobody. The line itself is
* re-written as its cleaned text wrapped in a colour tag, so the feed is
* colour-coded per family at a glance.
*
* WHAT THE HARNESS CANNOT PROVE, stated rather than hidden: that the client
* files a line by its MODIFIED mode, and which Log-config bit maps Assist E to
* which window, are facts about the running client -- the harness proves what
* this handler emits, not where the client draws it (DWQUEST_PLAN.md said the
* same of the reward reroute). If the feed still lands left, the fallback is
* the reward reroute's block-and-print shape. `/quests feed off` either way.
*
* POLARITY, OPPOSITE OF THE REWARD REROUTE'S, on purpose. The reroute is a
* refusal list because a missed notice is the failure that matters there. The
* feed MOVES lines out of the battle log wholesale, so here the harmful
* failure is taking a line that was not ours -- it matches only on an exact
* battle-message mode AND a pattern, and an event with no mode is refused.
* The mode numbers are the client's, read out of the DAT-extracted resource
* tables shipped with both Windower and simplelog (res/action_messages), not
* guessed: 36 carries the defeat family, 127 the obtains family, 131 the
* exp/limit/capacity family.
*
* EVERY PATTERN NAMES ITS MESSAGE ID -- harness_dwquest.py reads them out of
* this table and holds each against the wording recorded beside that id in
* src/map/enums/msg_basic.h, the same contract the reward patterns keep with
* scripts/enum/msg.lua. The chain messages carry their payout sentence in the
* same message (a <br> seam), so 'Limit chain' and 'gains ... limit points'
* both match one rendered event; the chain patterns sit first so the tint of
* a chain line is the chain family's.
--]]
local FEED_MODE_DEFEATS = 36;   -- DefeatsTarget 6
local FEED_MODE_OBTAINS = 127;  -- Obtains 565 (and 582, the actor form)
local FEED_MODE_POINTS  = 131;  -- exp 8/253, limit 371/372, capacity 718/735

-- Assist E: chat-group, Window 2 on the stock config, dead on this server.
local FEED_WINDOW_MODE = 222;

local FEED_LINES = T{
    ' defeats ',                          -- DefeatsTarget 6
    'EXP chain',                          -- ExpChain 253
    'gains [%d,]+ experience points',     -- ExperiencePointsGained 8
    'Limit chain',                        -- LimitChain 372
    'gains [%d,]+ limit points',          -- LimitPointsGained 371
    'Capacity chain',                     -- CapacityChain 735
    'gains [%d,]+ capacity points',       -- CapacityPointsGained 718
    'obtains [%d,]+ gil',                 -- Obtains 565
};

-- Which of the three battle modes each pattern is allowed to take a line on.
-- Keyed by the addon's own pattern text, same as REWARD_TINTS; a pattern
-- listed without a mode here never fires (the harness holds both directions).
local FEED_MODES = {
    [' defeats ']                      = FEED_MODE_DEFEATS,
    ['EXP chain']                      = FEED_MODE_POINTS,
    ['gains [%d,]+ experience points'] = FEED_MODE_POINTS,
    ['Limit chain']                    = FEED_MODE_POINTS,
    ['gains [%d,]+ limit points']      = FEED_MODE_POINTS,
    ['Capacity chain']                 = FEED_MODE_POINTS,
    ['gains [%d,]+ capacity points']   = FEED_MODE_POINTS,
    ['obtains [%d,]+ gil']             = FEED_MODE_OBTAINS,
};

-- One colour per family, so the feed reads at a glance: kills green, gil
-- yellow, experience cyan, limit violet, capacity coral.
local FEED_TINTS = {
    [' defeats ']                      = TINT_MILESTONE,
    ['EXP chain']                      = TINT_POINTS,
    ['gains [%d,]+ experience points'] = TINT_POINTS,
    ['Limit chain']                    = TINT_LIMIT,
    ['gains [%d,]+ limit points']      = TINT_LIMIT,
    ['Capacity chain']                 = TINT_CAPACITY,
    ['gains [%d,]+ capacity points']   = TINT_CAPACITY,
    ['obtains [%d,]+ gil']             = TINT_CURRENCY,
};

--[[
* Modes the UNTAGGED reward reroute refuses to look at.
*
* The tagged reroute below is deliberately mode-blind and stays that way: the
* tag is a far narrower match than any mode is. This list guards the OTHER
* branch, which has no tag to match on and therefore matches plain English --
* 'Records of Eminence: ', 'sparks of eminence', 'Prowess attained'. All three
* are sentences a player can type, and the first is also a burst ANCHOR, so a
* single shout reading "Records of Eminence: anyone want to duo?" was blocked
* AND opened a five-second window that pulled the next exp and gil lines out of
* the battle log with it.
*
* Written as a REFUSAL LIST rather than an allow list, on purpose and for this
* file's stated priority: missing a notice is the failure that matters, so a
* mode nobody has enumerated must still reroute. Only what is known to carry
* text a person typed is excluded.
*
* What is known here: the mode arrives packed and the id is its low byte
* (customcolors.lua in the shipped bundle: `bit.band(e.mode_modified, 0xFF)`).
* That file names the two anchors this boundary sits between -- NS_SAY is 9,
* another player's say; SYSTEM_3, the channel every DriftwoodXI module and
* every server reward message speaks on, is 121. The client's chat modes are
* the low block and its system and battle-log modes are far above it, so 32 is
* a boundary with room on both sides rather than a measured edge. If a reward
* line ever turns up below it, narrow this to the exact ids instead of raising
* it -- that direction fails safe and this one does not.
--]]
local PLAYER_CHAT_MODE_MAX = 31;

-- Seconds a burst stays open past the last line it took. Long enough to cross
-- the gap inside one payout, short enough that the next mob's exp is not in it.
local REWARD_BURST_SECS = 5.0;

-- The ceiling on one burst's WHOLE life, measured from the anchor that opened
-- it. Extension alone never closes: the per-kill progress line is family, so
-- with kills under five seconds apart every extension bought another window,
-- the exp line it dragged out extended it again, and one page completion moved
-- every subsequent kill's exp and gil out of the battle log for as long as the
-- pace held. A payout's own lines arrive inside a second or two; ten is
-- generous to the payout and nothing else.
local REWARD_BURST_MAX_SECS = 10.0;

--[[
* The one thing in this addon a player can turn off and have it stay off.
*
* Flat scalars only -- Ashita's settings serializer takes booleans, numbers and
* strings, and a nested table here is a silent loss on save (dwcon's note).
*
* The notice tag is NOT on this switch. That reroute is the Drift Board's own
* output and a player who did not want it would uninstall the addon; this one
* moves lines that belong to systems the addon does not own, so it is the one
* that owes an off switch.
--]]
local defaultConfig = T{
    rewards = true,
    feed    = true,
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

pcall(settings.register, 'settings', 'dwquest_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end
end);

-- os.clock() at which the open reward burst lapses. Nil means no burst.
local rewardBurstUntil = nil;

-- os.clock() at which the open burst was ANCHORED -- the fixed point the
-- REWARD_BURST_MAX_SECS ceiling is measured from. Set and cleared with
-- rewardBurstUntil, never separately.
local rewardBurstOpened = nil;

--[[
* A chat line with the client's and the other addons' decoration taken off.
*
* WHY THE OLD ONE-LINER WAS NOT ENOUGH (2026-08-11). This used to be a single
* `gsub('[^\032-\126]', '')` inline in the handler, which deletes every byte
* outside printable ASCII. That is right about which bytes are decoration and
* wrong about how wide a piece of decoration is: the client and Ashita both
* mark text up with TWO-byte tags -- a control byte and an ARGUMENT byte that
* is very often an ordinary letter or digit. Strip only the control byte and
* the argument is left sitting in the sentence. Three of them were, in every
* rerouted line, and the screenshot that reported it reads:
*
*     [22:05:12] [dwquest] Q[22:05:12] Realtester obtains 315 tabs. (...)1
*                          ^ ^^^^^^^^^                                    ^
*
*   Q   is `\30\81` -- DarkOrchid, opened by the bundled `timestamp` addon
*       (addons/timestamp/timestamp.lua, format '\30\81[%H:%M:%S]\30\01').
*       81 is 'Q'. The closing `\30\01` loses both bytes because 1 is not
*       printable either, which is why only the OPENING tag left a scar.
*   [22:05:12] is that addon's stamp. It runs on text_in ahead of this handler,
*       so what we read is already stamped -- and our own print() goes back
*       through text_in and is stamped AGAIN. Re-emitting the first stamp is
*       how one line ends up wearing two.
*   1   is `\127\49`, the client's own end-of-message marker. The bundled
*       `enternity` addon strips exactly this pair (`string.char(0x7F, 0x31)`),
*       which is where the identification comes from rather than a guess.
*
* SO THE TAG AND ITS ARGUMENT GO TOGETHER -- the colour tags, the client's
* end-of-message pair, AND the auto-translate brackets, whose argument bytes
* (\39, \40) are printable and would otherwise be left as a stray quote and
* parenthesis -- and the blanket strip stays behind them for everything else:
* the packet's NUL padding, anything a future addon decorates with. A lone tag
* byte at the very end of a string has no argument to eat and is caught by the
* blanket pass.
*
* THE STAMP IS TAKEN OFF THE FRONT AND OFF EVERY SEAM. Anchored-only was the
* first fix, and it survived exactly until a message with a `<br>` in its dat
* text: the timestamp addon stamps every RENDERED line, so a two-line message
* arrives wearing two clocks, and the second sits mid-string where an anchored
* pattern never looks. The seam form requires leading whitespace (which the
* line-break replacement guarantees) and a full bracketed clock; a player who
* has typed `/ts format` into something else keeps their own prefix, and that
* is the right failure -- a looser match would start eating the front of
* sentences that merely open with a bracket.
--]]
local function plainText(raw)
    -- Two-byte tags first, BOTH bytes: `\30`/`\31` are the colour tags Ashita's
    -- own chat library writes, `\127` is the client's, and `\239` leads the
    -- auto-translate brackets (\239\39 opens, \239\40 closes) -- whose argument
    -- bytes are a printable quote and parenthesis, exactly the kind of scar the
    -- blanket pass below cannot see.
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    -- The line-break bytes become a seam SPACE, not nothing: the dat files
    -- break several reward messages across two lines (`<br>` renders as \7,
    -- and the timestamp addon rewrites it to a real newline), and deleting the
    -- byte glued the halves together -- "...target.(Progress: 2/2)".
    text = text:gsub('[\007\010\013]+', ' ');

    -- Then everything else that cannot be drawn: NUL padding, a tag byte that
    -- had no argument left to take.
    text = text:gsub('[^\032-\126]', '');

    -- And the stamps, which we are about to be given a fresh one of. The
    -- timestamp addon stamps every RENDERED line, so a message the dat file
    -- breaks with <br> carries two clocks and only the first is at the front.
    -- The seam form goes FIRST and must follow whitespace (the seam space
    -- above guarantees one), so a sentence that merely contains a bracketed
    -- clock hard against a word keeps it; then the anchored form takes the
    -- leading stamp. This order, because the anchored strip eats the
    -- whitespace after itself -- run first, it would leave a second
    -- consecutive stamp sitting at the front with nothing for the seam form
    -- to match on.
    text = text:gsub('%s%[%d%d?:%d%d:%d%d%]%s*', ' ');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return text;
end

--[[
* Does this line belong to a reward payout, and may it be moved?
*
* Returns THE PATTERN THAT TOOK IT when the caller should block and re-print,
* and nil when it should not. A pattern is truthy, so every `if isRewardLine`
* written against the old boolean still reads correctly -- and the caller needs
* the identity, not the verdict, to pick the line's colour (REWARD_TINTS). A
* second lookup in the caller would have been a second copy of this loop, and
* two copies of a match is two copies to disagree.
*
* `now` is passed in rather than read here so one text_in call reads the clock
* exactly once: a handler that asked twice could open a burst against one
* reading and test it against another, which is the kind of thing that works on
* every machine except somebody's.
--]]
local function isRewardLine(line, now)
    if (config.rewards == false) then
        return nil;
    end

    for _, pattern in ipairs(REWARD_FAMILY) do
        if (line:find(pattern) ~= nil) then
            local opens = false;

            for _, anchor in ipairs(REWARD_ANCHORS) do
                if (line:find(anchor) ~= nil) then
                    opens = true;
                    break;
                end
            end

            -- An anchor OPENS a burst; any other family line only EXTENDS one
            -- that is already open. The distinction is the per-kill progress
            -- line: it is family (nothing else says it) but it must not drag
            -- an ordinary kill's exp out of the battle log with it.
            if (opens) then
                rewardBurstOpened = now;
                rewardBurstUntil  = now + REWARD_BURST_SECS;
            elseif (rewardBurstUntil ~= nil and now <= rewardBurstUntil) then
                -- An extension never outlives the ceiling: without it, kills
                -- under five seconds apart renewed each other forever (see
                -- REWARD_BURST_MAX_SECS).
                rewardBurstUntil = math.min(now + REWARD_BURST_SECS, rewardBurstOpened + REWARD_BURST_MAX_SECS);
            end

            return pattern;
        end
    end

    if (rewardBurstUntil == nil or now > rewardBurstUntil) then
        return nil;
    end

    for _, pattern in ipairs(REWARD_BURST) do
        if (line:find(pattern) ~= nil) then
            -- Refreshed, not merely tested -- but never past the ceiling: a
            -- taken exp line renewing the window that took it is exactly the
            -- loop REWARD_BURST_MAX_SECS exists to close.
            rewardBurstUntil = math.min(now + REWARD_BURST_SECS, rewardBurstOpened + REWARD_BURST_MAX_SECS);
            return pattern;
        end
    end

    return nil;
end

--[[
* The colour a moved line is printed in, by the pattern that took it.
*
* Falls back to `chat.message`'s cream rather than throwing or printing
* colourless, because the one thing this must not do is lose the line: a
* pattern added to REWARD_FAMILY without an entry in REWARD_TINTS is a harness
* failure at the desk, not a swallowed payout in somebody's chat log.
--]]
local function tintFor(pattern)
    local tint = REWARD_TINTS[pattern];

    if (tint == nil) then
        return 106;
    end

    return tint;
end

--[[
* State.
*
* Everything server-derived is replaced wholesale by a `board` envelope and
* never merged, so a contract that expired between syncs cannot survive as a
* stale card. A `ping` is the deliberate exception: it carries only the rows
* that moved, so it merges (dwu_protocol.md, "The ping").
*
* `actives` and `offerByKey` are PLAIN tables, not T{ }: they are keyed by
* quest keys and slot names, and T{ }'s sugar method names shadow string keys
* -- the collision that cost dwbags a round.
--]]
local state = T{
    open        = T{ false },

    -- The y| header. clockAt is the os.clock() at which the two countdowns
    -- were true, which is the only thing that makes ticking them down honest.
    poolVersion = nil,
    day         = nil,
    band        = nil,     -- the band the board ON SCREEN was resolved for
    playerBand  = nil,     -- the character's own band (y|'s appended field)
    secsToDay   = nil,
    secsToWeek  = nil,
    clockAt     = nil,
    rollAsked   = false,

    -- The band the player asked to LOOK at, nil for their own. Drives which
    -- board is requested; what is RENDERED is always the y| the server
    -- answered with, so the label cannot outrun the data under it.
    viewBand    = nil,

    offers      = { },     -- o| records, in wire order
    actives     = { },     -- [qkey] = a| record
    activeOrder = { },     -- qkeys, in the order the server listed them

    balance     = nil,     -- g|; nil means the server did not say

    -- q| -- the server-wide contract. nil means the server sent no q| record,
    -- which means there is no community contract this week. It is NOT drawn as
    -- an empty bar: a bar at 0/0 is a contract the window invented.
    community   = nil,

    synced      = false,   -- gates the panel: no cards until the first z|board

    -- True once a d| has arrived this session. Auto-syncs (zone-in) stay off
    -- until then: an unknown !command falls through to /say, and an automatic
    -- line against a dead verb is the player saying it in public.
    serverSpoke = false,

    inbound     = nil,     -- the verb whose envelope is currently open

    status      = 'Loading...',
    statusBad   = false,
    reported    = false,   -- a render error is worth saying once, not per frame

    toast       = nil,
    toastAt     = nil,

    now         = 0,       -- os.clock(), read once per frame (see present)
};

--[[
* THE EXCHANGE TAB (DWQUEST_PLAN.md Phase 4).
*
* Everything here arrives on the wire and nothing here is decided locally. The
* four offers and their prices are `u|` records; the list of gear that can take
* one is `c|` records off the server's own eligibility screen -- NOT the
* client's inventory, which cannot see an offline alt's bags and does not know
* a single one of the rules; the "N of 4 slots used" line is `k|`; and the
* price a purchase is confirmed at is the `p|` record's, never a number this
* file worked out.
*
* THE ONE RULE WITH MONEY BEHIND IT: `quote` is created by a `p|` record and by
* nothing else, and the Confirm button does not exist unless one is armed. A
* storefront button that could buy on the line it also uses to ask is the
* incident that produced dwmerc's quote/confirm pair -- an addon that reloaded
* and forgot it had already asked. Clicking Confirm disarms the quote in the
* same statement that queues the line, so one `p|` can be confirmed at most
* once, and a refusal arms nothing.
*
* PLAIN TABLES, not T{ }: `slots` is keyed by index and `gear` by wire order,
* and T{ }'s sugar method names shadow string keys.
--]]
local shop = {
    -- The v| header. clockAt is the os.clock() the countdown was true at.
    poolVersion = nil,
    day         = nil,
    secsToRoll  = nil,
    clockAt     = nil,
    rollAsked   = false,

    offers      = { },     -- u| records, in wire order
    burst       = { },     -- b| records, the static Weapon Burst shelf (2026-08-25)
    roster      = { },     -- w| records, in wire order
    synced      = false,

    -- The picker.
    picked      = nil,     -- the offer handle chosen: x1..x4
    who         = '',      -- '' is you; otherwise an offline character's name
    filter      = T{ '' }, -- InputText writes into element 1, EVERY keystroke
    -- The last COMMITTED search -- what gearRequest reads. The live buffer
    -- above changes on every character typed, and the request is built from
    -- whatever it holds, so reading it there made the command line change
    -- under the request de-dup and fired one `!dwu gear` per keystroke.
    filterApplied = '',
    gear        = { },     -- c| records, in wire order
    gearShown   = 0,
    gearTotal   = 0,
    gearMax     = 0,
    gearFor     = nil,     -- the request the list on screen answers
    gearSynced  = false,

    -- The item under consideration, off k| and s|.
    item        = nil,
    slots       = { },

    -- The armed quote. ONLY a p| record puts one here.
    quote       = nil,
};

--[[
* THE OUTFITTER TAB (DWQUEST_PLAN.md Phase 7).
*
* The same renderer-only contract as the Exchange, with a simpler shape:
* static stock, no rotation, no countdown. The job directory is `j|` records
* (sent whole on every shelf read), the rows are `f|` records for the ONE job
* that was asked -- the window fetches per selected job, because the whole
* catalog through the paced writer is a flood -- and the armed quote is a
* `t|` record and nothing else.
*
* ONE PENDING PURCHASE ACROSS BOTH STOREFRONTS, mirrored client-side: a `t|`
* clears the Exchange's p| quote and a `p|` clears this one, exactly as the
* server disarms them (D14) -- so this window can never draw two Confirm
* buttons for one `confirm` verb.
*
* PLAIN TABLES, not T{ }: rows keyed by wire order, jobs by wire order.
--]]
local outfit = {
    jobs    = { },     -- j| records, in wire order
    rows    = { },     -- f| records for the selected job, in wire order
    rowsFor = nil,     -- the request the rows on screen answer
    job     = nil,     -- the selected three-letter job word, nil for none
    synced  = false,

    -- The armed quote. ONLY a t| record puts one here.
    quote   = nil,
};

-- The ArmsDealer tab, the Outfitter's twin one storefront over: the dropdown
-- pages by CATEGORY where the Outfitter pages by job. Its own state so the two
-- panels never share a row list or a quote; the server enforces one pending
-- purchase across both.
--
-- `category` opens on 'dynamis' -- deliberately NOT "whatever the wire lists
-- first". The 2026-08-21 round put 'artifact' at the top of the dropdown, and
-- re-pointing the default at it would have silently changed which case an
-- existing player's window opened on. A default that follows the wire is a
-- default that moves whenever the shelf is restocked.
local arms = {
    categories = { },        -- j| records for the arms envelope, in wire order
    rows       = { },        -- f| records for the selected category
    rowsFor    = nil,        -- the request the rows on screen answer
    category   = 'dynamis',  -- selected category key; 'dynamis' by default
    synced     = false,

    -- The armed quote. ONLY a t| record in the armsbuy envelope puts one here.
    quote      = nil,
};

-- The Jeweler tab (owner request 2026-09-03): the CoP-era earrings and rings
-- for Drift Coins, the ArmsDealer's money path with the Pop-Items' shape --
-- the whole shelf travels on one read (eleven rows, no per-case fetch),
-- grouped under the case headers the j| directory names, each row priced
-- off the wire. Its own state so no panel shares a row list or a quote; the
-- server enforces one pending purchase across all of them.
local jewel = {
    cases  = { },            -- j| records for the jeweler envelope, in wire order
    rows   = { },            -- f| records, every case, in wire order
    synced = false,

    -- The armed quote. ONLY a t| record in the jewelbuy envelope puts one here.
    quote  = nil,
};

-- The Pop-Items tab (owner request 2026-08-30, the Huntboard round): NM pop
-- items priced in ITEMS -- Dynamis hundred-pieces plus DIFFERENT Job
-- Testimonies -- charged from the bag, no Drift Coins involved. The whole
-- shelf travels on one read (twenty-odd rows, no per-tier fetch), grouped
-- under the tier headers the j| directory names; `hundreds`/`types` are the
-- h| bag-side purse, nil until the server says (the state.balance rule).
local pop = {
    tiers    = { },          -- j| records for the pops envelope, in wire order
    rows     = { },          -- r| records, in wire order (server groups by tier)
    synced   = false,
    hundreds = nil,          -- h|: hundred-pieces in the bag
    types    = nil,          -- h|: DIFFERENT testimony types in the bag

    -- The armed quote. ONLY an x| record in the popbuy envelope puts one here.
    quote    = nil,
};

--[[
* Item icons, from the client's own resources -- dwbags' iconOf/drawIcon by
* way of dwraid, kept verbatim, reasoning and all: cached because the shelf
* is rows redrawn every frame and D3DXCreateTextureFromFileInMemoryEx is not
* free; gc_safe_release hands back a texture that releases itself when Lua
* collects it, which is what keeps this from leaking across a reload.
--]]
local icons = T{ };

local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* The hover card's vocabulary and the card itself -- dwraid's, kept verbatim:
* client DAT bitmasks decoded to the words a player reads. All of it is
* presentation; the server re-checks everything that matters (the Rare
* pre-pay refusal lives in quest_core.lua).
--]]
local FLAG_EX   = 0x4000;
local FLAG_RARE = 0x8000;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

local SLOT_LABELS = {
    [0]  = 'Main',  [1]  = 'Sub',   [2]  = 'Ranged', [3]  = 'Ammo',
    [4]  = 'Head',  [5]  = 'Body',  [6]  = 'Hands',  [7]  = 'Legs',
    [8]  = 'Feet',  [9]  = 'Neck',  [10] = 'Waist',  [11] = 'Ear',
    [12] = 'Ear',   [13] = 'Ring',  [14] = 'Ring',   [15] = 'Back',
};

local function jobsText(mask)
    local names = T{ };

    for jobId = 1, #JOB_NAMES do
        if (bit.band(mask, bit.lshift(1, jobId)) ~= 0) then
            names:append(JOB_NAMES[jobId]);
        end
    end

    if (#names == 0) then
        return nil;
    end

    if (#names >= #JOB_NAMES) then
        return 'All jobs';
    end

    return table.concat(names, ' ');
end

local function slotsText(mask)
    local names = T{ };
    local seen  = { };

    for slot = 0, 15 do
        if (bit.band(mask, bit.lshift(1, slot)) ~= 0) then
            local label = SLOT_LABELS[slot];

            if (not seen[label]) then
                seen[label] = true;
                names:append(label);
            end
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, '/');
end

--[[
* The eight elemental-resist icons in the client's item descriptions are
* FFXI-private Shift-JIS pairs -- 0xEF then 0x1F..0x26, in wheel order
* fire ice wind earth lightning water light dark (read straight out of
* ROM/118/107.DAT: item 6272 carries fire as EF 1F, item 4488 dark as
* EF 26, and the JP DAT spells the same slots 耐火/耐風/耐土). ImGui wants
* UTF-8, so the raw pair renders as the '?' players reported. Each icon
* (and the '+' that usually follows it) folds to a three-letter tag:
* '<fire>+20' reads FiR:20, '<dark>-10' reads DkR:-10. Mirrored BY HAND
* from dwbags 1.17.0 -- edit one, revisit the others.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function(b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

local function itemTooltip(row)
    imgui.BeginTooltip();

    local item = nil;

    if (row.itemid ~= nil and row.itemid ~= 0) then
        item = AshitaCore:GetResourceManager():GetItemById(row.itemid);

        drawIcon(row.itemid, 32);
    end

    imgui.Text(row.label);

    if (item ~= nil) then
        local tags = T{ };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags:append(string.format('iLvl %d', item.ItemLevel));
        end

        if (item.Level ~= nil and item.Level > 0) then
            tags:append(string.format('Lv.%d', item.Level));
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_RARE) ~= 0) then
            tags:append('Rare');
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_EX) ~= 0) then
            tags:append('Ex');
        end

        if (#tags > 0) then
            imgui.TextColored(theme.colors.info, table.concat(tags, '  '));
        end

        local slots = item.Slots ~= nil and slotsText(item.Slots) or nil;
        local jobs  = item.Jobs ~= nil and jobsText(item.Jobs) or nil;

        if (slots ~= nil and jobs ~= nil) then
            imgui.TextDisabled(slots .. '  --  ' .. jobs);
        elseif (slots ~= nil or jobs ~= nil) then
            imgui.TextDisabled(slots or jobs);
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            -- A fixed wrap width, not one derived from imgui state: the
            -- card must render the same whatever window it floats over.
            imgui.PushTextWrapPos(320.0);
            imgui.Text(cleanDescription(desc));
            imgui.PopTextWrapPos();
        end
    end

    imgui.EndTooltip();
end

--[[
* Sending: one command per interval, reads deduplicated, WRITES NEVER
* COLLAPSED AND NEVER RETRIED (the dwmerc rule, dwu_protocol.md client
* discipline 4). A lost `accept` that was re-sent could arrive after a
* rotation, which is a contract the player did not click on. Both verbs are
* idempotent server-side; that is not a licence to re-send them.
*
* Writes drain first: an accept stuck behind two queued board reads spends
* three seconds looking broken.
--]]
local SEND_INTERVAL = 1.2;

local readQueue  = { };
local writeQueue = { };
local lastSend   = 0;

local function issueRead(command)
    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

local function issueWrite(command)
    table.insert(writeQueue, command);
end

local function pumpQueue(now)
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#writeQueue > 0) then
        lastSend = now;
        echo.send(table.remove(writeQueue, 1));

        return;
    end

    if (#readQueue > 0) then
        lastSend = now;
        echo.send(table.remove(readQueue, 1));
    end
end

--[[
* Answer tracking for the board read: ask once, retry once on a 5s silence,
* then stop and say so -- a retry that never terminates is a command loop.
*
* `hello` and `board` are tracked under ONE key because the server answers
* both with a `board` envelope (quest_core.lua's dispatch): keying on the verb
* we sent would leave a `hello` waiting forever for a `z|hello` that the
* protocol does not have.
*
* A PLAIN TABLE, not T{ }, for the reason above.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = { };

-- `hello` is the verb that arms the post-kill ping for the session, and it is
-- the one verb only the addon sends. It goes out when the arming might not be
-- in place: window open, and after a zone line. An in-session re-read is
-- `board`, which is the same records without re-arming.
local wantVerb = 'hello';

local function refresh(verb)
    requested = { };
    wantVerb  = verb or 'board';
end

-- The board read that keeps the current view: `board 3` while looking at
-- band 3, plain `board` for your own. Every re-sync that is not the arming
-- handshake goes through this, so an accept, a rotation roll or a typed
-- command cannot silently snap the window back to the player's own band.
local function boardVerb()
    if (state.viewBand ~= nil) then
        return string.format('board %d', state.viewBand);
    end

    return 'board';
end

local function needBoard(now)
    local asked = requested['board'];

    if (asked ~= nil) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout, and a false "The server did not
        -- answer." (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or (now - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp = true;

                if (not state.serverSpoke) then
                    state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
                    state.statusBad = true;
                end
            end

            return;
        end

        asked.at    = now;
        asked.tries = asked.tries + 1;
    else
        requested['board'] = { at = now, answered = false, tries = 1 };
    end

    issueRead('!dwu ' .. wantVerb);
end

--[[
* The same ask-once-retry-once discipline as needBoard, for the reads the
* Exchange tab makes. Keyed separately so a storefront read and a gear read
* cannot answer for each other, and so neither can answer for the board.
*
* Reads only. The three things this window sends that are NOT reads -- accept,
* abandon and confirm -- never come through here, because a write that times
* out is a write that stays sent (client discipline 4).
--]]
local function askOnce(key, command, now)
    local asked = requested[key];

    if (asked ~= nil) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout, and a false "The server did not
        -- answer." (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or (now - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp   = true;
                state.status    = 'The server did not answer. Refresh to try again.';
                state.statusBad = true;
            end

            return;
        end

        asked.at    = now;
        asked.tries = asked.tries + 1;
    else
        requested[key] = { at = now, answered = false, tries = 1 };
    end

    issueRead(command);
end

--[[
* A write in flight. Nothing here moves money and the store re-checks the
* account on both verbs, but a button clicked twice while the first click is
* still queued is a second line on the wire for a decision the player made
* once -- so the card says what it is doing instead of accepting the click.
*
* IT COVERS THE PURCHASE PAIR TOO (Phase 4). `augment` and `confirm` are both
* queued as writes and neither is ever re-sent; while one is in flight the
* buttons say what they are doing rather than taking a second click -- which
* for `confirm` is the difference between one purchase and two lines on the
* wire for one decision. The quote is disarmed at the click, so even a window
* that somehow got past this has nothing left to confirm with.
--]]
local WRITE_TIMEOUT = 10.0;

local writePending = nil;

local function beginWrite(what, label, command)
    writePending = { what = what, label = label, at = os.clock() };

    issueWrite(command);
end

--[[
* Record parsing.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function num(text, fallback)
    return tonumber(text or '') or fallback;
end

local TOAST_SECONDS = 8.0;

local function toast(text)
    state.toast   = text;
    state.toastAt = os.clock();
end

--[[
* One a| record -- an accepted contract. It carries its own name and reward
* rather than pointing back at an o|, because a contract inside its grace
* period is not on today's board and this window still has to draw it
* (dwu_protocol.md, `a|`).
*
* KEYED ON qkey, NEVER ON handle: handles are a typed-tier label that
* renumbers between syncs, and a model keyed on one abandons the wrong
* contract exactly once (client discipline 3).
--]]
local function handleContract(parts)
    local qkey = parts[3];

    if (qkey == nil or qkey == '') then
        return;
    end

    local row = {
        handle   = parts[2],
        qkey     = qkey,
        kind     = parts[4],
        period   = parts[5],
        name     = parts[6],
        progress = num(parts[7], 0),
        needed   = num(parts[8], 0),
        reward   = num(parts[9], 0),
        secsLeft = num(parts[10], 0),
        state    = parts[11],
        at       = os.clock(),
    };

    local prev = state.actives[qkey];

    -- The toast fires off the PING only. A board sync is the window catching
    -- up with kills it already celebrated, and re-celebrating them on every
    -- zone line would make the toast mean nothing.
    if (state.inbound == 'ping') then
        if (row.state == 'done' and (prev == nil or prev.state ~= 'done')) then
            toast(string.format('Contract complete: %s   +%d DC', row.name, row.reward));
        elseif (prev == nil or row.progress > prev.progress) then
            toast(string.format('%s   %d / %d', row.name, row.progress, row.needed));

            -- THE COUNTER IS ALWAYS A CHAT LINE TOO, and it is deliberately
            -- NOT conditional on the window being shut any more.
            --
            -- quest_core stops printing the per-kill progress line the moment a
            -- session is armed, because the window animates it instead -- so
            -- this print is the only copy an armed session ever gets. Gating it
            -- on the window being closed made where the line appeared depend on
            -- which of four states the session happened to be in (armed or not,
            -- window up or not), which is exactly the "sometimes over here,
            -- sometimes over there" the notice tag exists to end. One rule now:
            -- every progress step and every payout is a chat line, in the same
            -- window, every time. The toast still fires; a toast is eight
            -- seconds of a window you may not be looking at.
            --
            -- Payouts are not repeated here -- the server announces those to
            -- both tiers, tagged, and the handler at the bottom of this file
            -- moves them to the same place this line goes.
            print(chat.header('dwquest'):append(chat.message(
                string.format('%s: %d/%d', row.name, row.progress, row.needed))));
        end
    end

    if (prev == nil) then
        table.insert(state.activeOrder, qkey);
    end

    state.actives[qkey] = row;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = num(parts[2], 0);

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwquest.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- A d| envelope IS the answer, whatever version it announced.
            -- Returning with the asks still outstanding let needBoard and
            -- askOnce re-send them and then replace the one accurate diagnosis
            -- on screen ("Update dwquest") with "The server did not answer" --
            -- about a server that had just answered twice. `serverSpoke`
            -- deliberately stays false: this server does not speak a dwquest
            -- this addon understands. dwfame closed the same hole 2026-08-15.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.serverSpoke = true;
        state.inbound     = parts[3];

        -- A board replaces its whole section, and the reset runs FIRST: this
        -- runs under a pcall, and a throw after inbound is set must cost one
        -- record rather than leave old rows for the ones behind it. A ping is
        -- deliberately not reset -- it carries only what moved.
        if (state.inbound == 'board') then
            state.offers      = { };
            state.actives     = { };
            state.activeOrder = { };
            -- Cleared with the rest of the board: a week whose contract has
            -- ended sends no q| at all, and a bar left behind from last week
            -- would keep asking for kills nothing counts.
            state.community   = nil;

            local asked = requested['board'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'augments') then
            shop.offers = { };
            shop.burst  = { };
            shop.roster = { };

            local asked = requested['augments'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'gear') then
            shop.gear      = { };
            shop.gearShown = 0;
            shop.gearTotal = 0;

            local asked = requested['gear'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'slots' or state.inbound == 'augment') then
            -- A fresh look at an item replaces the old one wholesale, and THE
            -- QUOTE GOES WITH IT. An `augment` that refuses arms nothing --
            -- which is the whole point of clearing here rather than on the way
            -- out: the refusal path never runs a line that could leave one.
            shop.item  = nil;
            shop.slots = { };
            shop.quote = nil;
        elseif (state.inbound == 'shelf') then
            -- A shelf read replaces the directory AND the rows: the directory
            -- always travels with the answer, and the rows belong to whichever
            -- job the request named (an unnamed request carries none).
            outfit.jobs = { };
            outfit.rows = { };

            local asked = requested['shelf'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'arms') then
            -- The ArmsDealer read: the category directory AND the rows for the
            -- category the request named, the Outfitter's shape one case over.
            arms.categories = { };
            arms.rows       = { };

            local asked = requested['arms'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'pops') then
            -- The Pop-Items read: tier directory, bag-side purse and every
            -- row travel together -- one read, whole shelf.
            pop.tiers = { };
            pop.rows  = { };

            local asked = requested['pops'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'jeweler') then
            -- The Jeweler read: case directory and every row together -- one
            -- read, whole shelf, the Pop-Items shape.
            jewel.cases = { };
            jewel.rows  = { };

            local asked = requested['jeweler'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        end

        -- `buy` is deliberately absent from that list too: its answer is a
        -- t| quote (or a refusal), and there is nothing behind it to reset.

        -- `confirm` is deliberately absent from that list. Its answer carries
        -- only what changed (the item's new slot view and the purse), the same
        -- way a ping does, and resetting would blank the panel the player is
        -- reading the result on.

        return;
    end

    -- Status lines are accepted whatever the envelope state: the sentence
    -- saying why something was refused is worth more than the response it
    -- happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwquest'):append(chat.error(state.status)));
        end

        -- A write that has answered is a write that is no longer in flight,
        -- whichever way it went. Nothing is re-sent either way. A refusal
        -- raised BEFORE the verb opened its own envelope arrives wrapped in
        -- `d|1|status` (dwu_protocol.md inherits dwg's envelope rules), and
        -- that ends the write too: left in flight, every board card read
        -- "Signing..." for ten seconds and the timeout then replaced the
        -- server's real sentence with a false "no answer" diagnosis.
        local endsWrite = state.inbound == 'accept' or state.inbound == 'abandon'
            or state.inbound == 'augment' or state.inbound == 'confirm'
            or state.inbound == 'buy' or state.inbound == 'armsbuy'
            or state.inbound == 'popbuy' or state.inbound == 'jewelbuy'
            or (state.inbound == 'status' and writePending ~= nil);

        -- A REFUSED CONFIRM IS A REFUSAL, NOT A RETRY PROMPT (client
        -- discipline 6). Every reason it can fail -- the item moved, the
        -- storefront rotated, the purse was short, the purchase was already
        -- settled -- is fixed by a fresh quote and none of them by sending the
        -- same word again, so the quote is torn up here rather than left armed
        -- (or worse: left spent-but-visible, wedging the slot view whose Back
        -- button is gated on the quote being gone).
        if (kind == 'e' and (state.inbound == 'confirm'
                or (state.inbound == 'status' and writePending ~= nil
                    and writePending.what == 'confirm'))) then
            shop.quote   = nil;
            -- All storefronts: whichever quote the refused confirm was
            -- spending, none survives it (the same reasons, one tab over).
            outfit.quote = nil;
            arms.quote   = nil;
            pop.quote    = nil;
            jewel.quote  = nil;
        end

        if (endsWrite) then
            writePending = nil;
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'board') then
            state.synced = true;

            if (state.status == 'Loading...') then
                state.status = '';
            end
        elseif (closing == 'accept' or closing == 'abandon') then
            writePending = nil;

            -- The write answered with a sentence, not with rows: the board it
            -- produced has to be read back before the cards are true. A read,
            -- so it is retried; the write itself never is.
            refresh(boardVerb());
        elseif (closing == 'augments') then
            shop.synced = true;
        elseif (closing == 'gear') then
            shop.gearSynced = true;
        elseif (closing == 'shelf') then
            outfit.synced = true;
        elseif (closing == 'arms') then
            arms.synced = true;
        elseif (closing == 'pops') then
            pop.synced = true;
        elseif (closing == 'jeweler') then
            jewel.synced = true;
        elseif (closing == 'augment' or closing == 'confirm' or closing == 'buy'
                or closing == 'armsbuy' or closing == 'popbuy' or closing == 'jewelbuy') then
            writePending = nil;

            if (closing == 'confirm') then
                -- Armed or not, this quote is spent. The k| that came with the
                -- answer is already on screen and says what the item is now.
                shop.quote   = nil;
                outfit.quote = nil;
                arms.quote   = nil;
                jewel.quote  = nil;

                -- A settled pop confirm took coins and testimonies out of the
                -- bag; the h| purse on screen is now a frame of the past. A
                -- read, so it may be re-asked; nothing here is re-sent.
                if (pop.quote ~= nil) then
                    pop.quote        = nil;
                    pop.synced       = false;
                    requested['pops'] = nil;
                end

                -- The used/free counts in the picker moved under it. A read,
                -- so it may be re-asked; nothing here is re-sent.
                shop.gearFor = nil;
            end
        end

        return;
    end

    if (kind == 'y') then
        state.poolVersion = num(parts[2], nil);
        state.day         = num(parts[3], nil);
        state.band        = num(parts[5], nil);
        state.secsToDay   = num(parts[6], 0);
        state.secsToWeek  = num(parts[7], 0);
        state.playerBand  = num(parts[8], nil);
        state.clockAt     = os.clock();
        state.rollAsked   = false;

        -- A server that predates the band look never sends the appended
        -- field and ignores a band argument -- so stop asking with one, or
        -- the arrows would relabel a board that never changes.
        if (state.playerBand == nil) then
            state.viewBand   = nil;
            state.playerBand = state.band;
        end

        return;
    end

    if (kind == 'o') then
        -- parts[9] is the expansion tag ('COP'), APPENDED in 2026-08-21 and
        -- present only on a gated slot. nil when absent, never '' -- a card
        -- must be able to tell "no tag" from "a tag whose text is empty", and
        -- the badge below is drawn on the nil test.
        local tag = parts[9];

        if (tag ~= nil and tag == '') then
            tag = nil;
        end

        table.insert(state.offers, {
            slot   = parts[2],
            kind   = parts[3],
            qkey   = parts[4],
            name   = parts[5],
            needed = num(parts[6], 0),
            reward = num(parts[7], 0),
            state  = parts[8],
            tag    = tag,
        });

        return;
    end

    if (kind == 'a') then
        handleContract(parts);

        return;
    end

    if (kind == 'g') then
        state.balance = num(parts[2], nil);

        -- Part 3 joined 2026-08-25 (append-only growth): the Burst Token
        -- balance, the arena's currency. Absent on an older server, so the
        -- previous number is KEPT rather than replaced with an invented
        -- zero -- nil until the first server that knows about it answers.
        state.burstBalance = num(parts[3], state.burstBalance);

        return;
    end

    -- q| -- the server-wide contract (Phase 5). Every number is the server's;
    -- `mine` and `minKills` are what the card uses to say whether this account
    -- is on the payout roster, and the window never works that out for itself.
    if (kind == 'q') then
        state.community =
        {
            qkey     = parts[2],
            id       = num(parts[3], 0),
            name     = parts[4] or '?',
            progress = num(parts[5], 0),
            needed   = num(parts[6], 0),
            mine     = num(parts[7], 0),
            minKills = num(parts[8], 0),
            reward   = num(parts[9], 0),
            state    = parts[10] or 'open',
        };

        return;
    end

    --[[
    * The Exchange records. Every one of them is rendered as it arrived.
    --]]

    -- v| -- the storefront header and its rotation countdown.
    if (kind == 'v') then
        shop.poolVersion = num(parts[2], nil);
        shop.day         = num(parts[3], nil);
        shop.secsToRoll  = num(parts[4], 0);
        shop.clockAt     = os.clock();
        shop.rollAsked   = false;

        return;
    end

    -- u| -- one augment offer. It also rides the `augment` (quote) answer,
    -- where it is context for the p| rather than a storefront row: appending
    -- it there would grow the storefront by one every time somebody asked a
    -- price.
    if (kind == 'u') then
        if (state.inbound == 'augments') then
            table.insert(shop.offers, {
                slot  = parts[2],
                augid = num(parts[3], 0),
                rank  = num(parts[4], 0),
                price = num(parts[5], 0),
                fits  = parts[6],
                label = parts[7],
            });
        end

        return;
    end

    -- w| -- one character on the account. `state` is the server's word on
    -- whether that character can be augmented, and the reason is worth
    -- showing: "logged in" is a thing the player can fix.
    if (kind == 'w') then
        table.insert(shop.roster, { name = parts[2], state = parts[3] });

        return;
    end

    -- b| -- one STATIC shelf offer (Weapon Burst 2026-08-25, X-Magic
    -- 2026-08-30). Never rotating, priced in Burst Tokens AND DC -- its own
    -- record kind so a window that cannot state both prices never renders
    -- the offer at all.
    --
    -- fits ARRIVES ON THE WIRE (field 7) and is not stamped here. It used to
    -- be the constant 'wield', which was true while Weapon Burst was the only
    -- static shelf and became a lie the moment X-Magic arrived: rings only,
    -- and the card would have told the player to augment a weapon that the
    -- server was about to refuse. The default below is that same constant, so
    -- a window talking to a server too old to send the field behaves exactly
    -- as it did before -- which is what lets the field be APPENDED rather
    -- than versioned.
    if (kind == 'b') then
        if (state.inbound == 'augments') then
            local fits = parts[7];

            table.insert(shop.burst, {
                slot    = parts[2],
                augid   = num(parts[3], 0),
                btPrice = num(parts[4], 0),
                price   = num(parts[5], 0),
                fits    = (type(fits) == 'string' and fits ~= '') and fits or 'wield',
                label   = parts[6],
            });
        end

        return;
    end

    -- n| -- the gear header. shown < total means the list is TRUNCATED, and
    -- the window says so rather than letting a cap read as an inventory.
    if (kind == 'n') then
        shop.gearShown = num(parts[2], 0);
        shop.gearTotal = num(parts[3], 0);
        shop.gearMax   = num(parts[4], 0);

        return;
    end

    -- c| -- one item that can take an augment. The id is what a purchase
    -- names; used/free are the server's own counts.
    if (kind == 'c') then
        table.insert(shop.gear, {
            itemid = num(parts[2], 0),
            used   = num(parts[3], 0),
            free   = num(parts[4], 0),
            count  = num(parts[5], 1),
            name   = parts[6],
        });

        return;
    end

    -- k| -- an item's slot view. It is the header of a slot list, so it clears
    -- the rows behind it: s| records are emitted only for OCCUPIED slots, and
    -- a slot that emptied would otherwise linger from the previous answer.
    if (kind == 'k') then
        shop.item = {
            used     = num(parts[2], 0),
            free     = num(parts[3], 0),

            -- CLAMPED, because this one number is a per-frame RENDER-LOOP
            -- BOUND (`for index = 1, item.maxslots` in the slot view) and
            -- LuaJIT's tonumber accepts 'inf' as readily as it accepts 4 --
            -- so a corrupt or truncated record does not cost a row, it costs
            -- the frame loop, and the client with it. The server's own
            -- xi.dwQuestAugments.MAX_SLOTS is 4; 16 leaves additive headroom
            -- and still terminates. (dwcraft.lua's `a|` count carries the
            -- same clamp for the same reason, its Phase 6 finding.)
            maxslots = math.max(math.min(num(parts[4], 4), 16), 0),
            itemid   = num(parts[5], 0),
            name     = parts[6],
            charname = parts[7],
            stamp    = parts[8],
        };

        shop.slots = { };

        -- The purchase landed. The sentence is the server's own (it prints one
        -- in chat on every tier, because money always says so); this is the
        -- window's acknowledgement that the click did something.
        if (state.inbound == 'confirm') then
            toast(string.format('%s: %d of %d slots used.',
                shop.item.name, shop.item.used, shop.item.maxslots));
        end

        return;
    end

    -- s| -- one occupied augment slot. An absent index is an empty slot.
    if (kind == 's') then
        local index = num(parts[2], 0);

        if (index >= 1 and index <= 4) then
            shop.slots[index] = { augid = num(parts[3], 0), rank = num(parts[4], 0) };
        end

        return;
    end

    -- p| -- A QUOTE, AND THE ONLY THING THAT CAN ARM AN EXCHANGE CONFIRM.
    -- Not a purchase, and incapable of becoming one on its own. It disarms
    -- the Outfitter's quote the way the server does (D14): one pending
    -- purchase per character, both storefronts.
    if (kind == 'p') then
        shop.quote = {
            price   = num(parts[2], 0),
            augid   = num(parts[3], 0),
            rank    = num(parts[4], 0),
            landing = num(parts[5], 0),
            holds   = num(parts[6], 0),
            label   = parts[7],

            -- Part 8 joined 2026-08-25 (append-only): the Burst Token half
            -- of a Weapon Burst quote. 0 for the rotating offers.
            btPrice = num(parts[8], 0),
            at      = os.clock(),
            armed   = true,
        };

        outfit.quote = nil;
        -- All four storefronts (D14): the server disarmed every other side
        -- when it quoted this one, so no other Confirm may stay on screen.
        -- arms.quote joined this teardown with pop.quote on 2026-08-30 -- it
        -- had been missing since the ArmsDealer shipped, a stale-Confirm
        -- window the server's own router made harmless but the screen showed.
        arms.quote  = nil;
        pop.quote   = nil;
        jewel.quote = nil;

        return;
    end

    --[[
    * The Outfitter records (Phase 7). Every one rendered as it arrived.
    --]]

    -- j| -- one job in the shelf directory.
    if (kind == 'j') then
        if (state.inbound == 'shelf') then
            table.insert(outfit.jobs, {
                jobId = num(parts[2], 0),
                word  = parts[3],
                label = parts[4],
            });
        elseif (state.inbound == 'arms') then
            -- The ArmsDealer's category directory rides the same letter, told
            -- apart by the envelope: catId | key | label.
            table.insert(arms.categories, {
                catId = num(parts[2], 0),
                key   = parts[3],
                label = parts[4],
            });
        elseif (state.inbound == 'pops') then
            -- The Pop-Items tier directory, same letter, same rule:
            -- tierId | key | label.
            table.insert(pop.tiers, {
                tierId = num(parts[2], 0),
                key    = parts[3],
                label  = parts[4],
            });
        elseif (state.inbound == 'jeweler') then
            -- The Jeweler's case directory, same letter, same rule:
            -- catId | key | label. The rows are grouped under these.
            table.insert(jewel.cases, {
                catId = num(parts[2], 0),
                key   = parts[3],
                label = parts[4],
            });
        end

        return;
    end

    -- r| -- one pop row (the pops envelope only). The two item ids at the
    -- middle are what the icons and hover cards draw from -- the second is 0
    -- outside the sky pairs; the item NAMES resolve from the client's own
    -- DATs, never the wire (the dwbags rule).
    if (kind == 'r' and state.inbound == 'pops') then
        table.insert(pop.rows, {
            index       = num(parts[2], 0),
            tier        = parts[3],
            hundreds    = num(parts[4], 0),
            testimonies = num(parts[5], 0),
            itemid      = num(parts[6], 0),
            itemid2     = num(parts[7], 0),
            where       = parts[8],
            label       = parts[9],
        });

        return;
    end

    -- h| -- the bag-side purse: hundred-pieces held, DIFFERENT testimony
    -- types held. Counted server-side by the exact walk the confirm charges
    -- with, so this line and the refusal sentences can never disagree.
    if (kind == 'h' and state.inbound == 'pops') then
        pop.hundreds = num(parts[2], 0);
        pop.types    = num(parts[3], 0);

        return;
    end

    -- x| -- THE ONLY THING THAT CAN ARM A POP-ITEMS CONFIRM (the t| rule,
    -- one storefront over). Carries no label -- the r| row the index names
    -- is already on screen.
    if (kind == 'x') then
        pop.quote = {
            index       = num(parts[2], 0),
            hundreds    = num(parts[3], 0),
            testimonies = num(parts[4], 0),
            holds       = num(parts[5], 0),
            at          = os.clock(),
        };

        shop.quote   = nil;
        outfit.quote = nil;
        arms.quote   = nil;
        jewel.quote  = nil;

        return;
    end

    -- f| -- one row for the job/category that was asked. The id at the tail is
    -- what the icon and the hover card are drawn from. The middle fields differ
    -- by envelope: level|slot for the shelf, wtype|jobs for the ArmsDealer,
    -- slot|jobs for the Jeweler (whose rows carry their case key from the
    -- index band, 3000 + catId*100, so the panel can group them).
    if (kind == 'f') then
        if (state.inbound == 'shelf') then
            table.insert(outfit.rows, {
                index  = num(parts[2], 0),
                price  = num(parts[3], 0),
                itemid = num(parts[4], 0),
                level  = num(parts[5], 0),
                slot   = parts[6],
                label  = parts[7],
            });
        elseif (state.inbound == 'arms') then
            table.insert(arms.rows, {
                index  = num(parts[2], 0),
                price  = num(parts[3], 0),
                itemid = num(parts[4], 0),
                wtype  = parts[5],
                jobs   = parts[6],
                label  = parts[7],
            });
        elseif (state.inbound == 'jeweler') then
            local index = num(parts[2], 0);

            table.insert(jewel.rows, {
                index  = index,
                -- The case is the index band (3000 + catId*100 + ordinal),
                -- the server's own numbering: nothing here invents one.
                catId  = math.floor((index - 3000) / 100),
                price  = num(parts[3], 0),
                itemid = num(parts[4], 0),
                slot   = parts[5],
                jobs   = parts[6],
                label  = parts[7],
            });
        end

        return;
    end

    -- t| -- THE ONLY THING THAT CAN ARM A STOREFRONT CONFIRM. Not a purchase,
    -- and incapable of becoming one on its own. Routed by the envelope it
    -- arrived in: the ArmsDealer's armsbuy answer arms the ArmsDealer, the
    -- Outfitter's buy answer arms the Outfitter, and each disarms the others
    -- for the same reason p| disarms the Exchange's.
    if (kind == 't') then
        local quote = {
            index = num(parts[2], 0),
            price = num(parts[3], 0),
            holds = num(parts[4], 0),
            label = parts[5],
            at    = os.clock(),
        };

        if (state.inbound == 'armsbuy') then
            arms.quote   = quote;
            outfit.quote = nil;
            jewel.quote  = nil;
        elseif (state.inbound == 'jewelbuy') then
            jewel.quote  = quote;
            arms.quote   = nil;
            outfit.quote = nil;
        else
            outfit.quote = quote;
            arms.quote   = nil;
            jewel.quote  = nil;
        end

        shop.quote = nil;
        pop.quote  = nil;

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWUDATA is ours -- consumed and blocked before parsing so a
* malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwquest_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwquest'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Reads over the synced state.
--]]

-- A countdown the server sent, aged by the wall clock since it arrived. Never
-- below zero: `secsLeft` is documented as never negative, and a bar counting
-- backwards past its own expiry is a number nobody can act on.
local function ticked(base, at, now)
    if (base == nil or at == nil) then
        return nil;
    end

    local left = base - (now - at);

    return left > 0 and left or 0;
end

local function fmtClock(secs)
    if (secs == nil) then
        return '--';
    end

    secs = math.floor(secs);

    if (secs <= 0) then
        return 'now';
    end

    if (secs >= 3600) then
        return string.format('%dh %02dm', math.floor(secs / 3600), math.floor((secs % 3600) / 60));
    end

    if (secs >= 60) then
        return string.format('%dm %02ds', math.floor(secs / 60), secs % 60);
    end

    return string.format('%ds', secs);
end

-- The rotation rolled while the window was open: the offers on screen belong
-- to the period that just ended. Asked ONCE per header -- y| clears the flag.
local function checkRotation(now)
    if (state.rollAsked or not state.synced or state.clockAt == nil) then
        return;
    end

    local day  = ticked(state.secsToDay, state.clockAt, now);
    local week = ticked(state.secsToWeek, state.clockAt, now);

    if ((day ~= nil and day <= 0) or (week ~= nil and week <= 0)) then
        state.rollAsked = true;

        refresh(boardVerb());
    end
end

--[[
* Actions. Every one is a line a player could type.
*
* Abandon names the QUEST KEY, not the handle: the server takes either, and
* the key cannot be renumbered out from under a click (client discipline 3).
--]]
local function acceptSlot(offer)
    beginWrite('accept', offer.name, string.format('!dwu accept %s', offer.slot));

    state.status    = string.format('Signing %s...', offer.name);
    state.statusBad = false;
end

local function abandonContract(row)
    beginWrite('abandon', row.name, string.format('!dwu abandon %s', row.qkey));

    state.status    = string.format('Tearing up %s...', row.name);
    state.statusBad = false;
end

--[[
* The Exchange's actions. Every one is a line a player could type, and the
* three that name an item name it BY ID -- which is a thing the typed tier
* takes (`!drift augment x1 17324`) and the one form no item name can be
* ambiguous in.
--]]

-- The filter goes on a command line, so the two markers the server's argument
-- parser reads out of ANY token come off it first. A player typing "@Yakapo"
-- into a search box means it as words, not as a character switch, and a window
-- that let it through would quietly search somebody else's bags. `|` goes for
-- the wire's own reason.
local function safeFilter(text)
    return tostring(text or ''):gsub('[@#|\r\n]', ' '):gsub('%s+', ' '):gsub('^%s+', ''):gsub('%s+$', '');
end

local function gearRequest()
    if (shop.picked == nil) then
        return nil;
    end

    local command = string.format('!dwu gear %s', shop.picked);

    if (shop.who ~= '') then
        command = string.format('%s @%s', command, shop.who);
    end

    -- The committed search, never the live buffer. safeFilter already ran at
    -- the commit, which is where the marker scrub belongs.
    local filter = shop.filterApplied or '';

    if (filter ~= '') then
        command = string.format('%s %s', command, filter);
    end

    return command;
end

-- The list on screen answers exactly one request; when the request changes the
-- list is stale and the tracker has to be re-armed, or the window would sit
-- showing yesterday's bag under today's question.
local function invalidateGear()
    shop.gearFor    = nil;
    shop.gearSynced = false;
    requested['gear'] = nil;
end

local function chooseOffer(offer)
    shop.picked = offer.slot;
    shop.item   = nil;
    shop.slots  = { };
    shop.quote  = nil;

    invalidateGear();

    state.status    = string.format('%s -- pick what it goes on.', offer.label);
    state.statusBad = false;
end

local function chooseCharacter(name)
    shop.who   = name or '';
    shop.item  = nil;
    shop.slots = { };
    shop.quote = nil;

    invalidateGear();
end

-- Ask a price. A quote spends nothing, but it is queued as a write and never
-- retried all the same: it arms a confirmation server-side, and a duplicate
-- arriving late is a second armed quote for one click.
local function quoteItem(row, replaceSlot)
    local command = string.format('!dwu augment %s %s%d', shop.picked,
        shop.who ~= '' and ('@' .. shop.who .. ' ') or '', row.itemid);

    if (replaceSlot ~= nil) then
        command = string.format('%s #%d', command, replaceSlot);
    end

    beginWrite('augment', row.name, command);

    state.status    = string.format('Pricing %s...', row.name);
    state.statusBad = false;
end

-- The slot view on its own, for an item with nothing free: the player has to
-- see what is in the four slots before they can say which one to give up. A
-- read, so it may be re-asked; it quotes nothing and arms nothing.
local function inspectItem(row)
    shop.item  = nil;
    shop.slots = { };
    shop.quote = nil;

    issueRead(string.format('!dwu slots %s%d',
        shop.who ~= '' and ('@' .. shop.who .. ' ') or '', row.itemid));

    state.status    = string.format('Reading %s...', row.name);
    state.statusBad = false;
end

--[[
* THE PURCHASE. The only place this addon can spend anything.
*
* The quote is disarmed in the same statement that queues the line, so the
* record that authorised this purchase cannot authorise another one -- not on a
* double click, not on a frame that renders twice, not on a retry that does not
* exist. A refusal comes back as an `e|` and clears the quote outright; there
* is no path here that re-sends `confirm`.
--]]
local function confirmPurchase()
    if (shop.quote == nil or not shop.quote.armed) then
        return;
    end

    local label = shop.quote.label;

    shop.quote.armed = false;

    beginWrite('confirm', label, '!dwu confirm');

    state.status    = string.format('Buying %s...', label);
    state.statusBad = false;
end

--[[
* Rendering.
--]]

-- The period label comes off the slot handle, which IS the period: `d1`/`d2`
-- are the dailies and `w1`/`w2` the weeklies, fixed by the protocol
-- (dwu_protocol.md, `o|`). Reading a documented handle is not arithmetic over
-- server data -- there is no other number here the window invents.
local function periodLabel(slotOrPeriod)
    return tostring(slotOrPeriod or ''):sub(1, 1) == 'w' and 'Weekly' or 'Daily';
end

-- The level range a band number covers, fixed by the protocol (dwu_protocol.md,
-- `y|`: 1-20, 21-40, 41-60, 61-80, 81-99). Reading a documented mapping, like
-- periodLabel above -- the server prints the same range from the same band.
local BAND_COUNT = 5;

local function bandRange(band)
    return (band - 1) * 20 + 1, band == BAND_COUNT and 99 or band * 20;
end

--[[
* The band look: which band's board is asked for next. Stepping is a READ of a
* different board, never a write -- accept stays own-band only and the server
* enforces it besides. What the label renders is the y| the server answered
* with (state.band), so the arrows can never label a board they merely hoped
* for.
--]]
local function stepBand(delta)
    local current = state.viewBand or state.band or state.playerBand;

    if (current == nil) then
        return;
    end

    local target = current + delta;

    if (target < 1) then target = 1; end
    if (target > BAND_COUNT) then target = BAND_COUNT; end

    if (target == current) then
        return;
    end

    if (state.playerBand ~= nil and target == state.playerBand) then
        state.viewBand = nil;
    else
        state.viewBand = target;
    end

    refresh(boardVerb());
end

-- The objective clause, per kind. This mirrors quest_core.lua's objectiveFor
-- exactly, and the harness asserts the two say the same thing -- a window that
-- describes a contract differently from the server that scores it is a bug
-- report about the wrong half.
--
-- THE WEAPON-SKILL WORDING IS THE SERVER'S, NOT A PARAPHRASE. The flag is a
-- fact about the mob's death and is handed to every alliance member alike, so
-- "finished with a weapon skill" is true and "finish it yourself" is not.
local function objectiveText(kind, needed, name)
    if (kind == 'fam') then
        return string.format('Slay %d of the %s family', needed, name);
    elseif (kind == 'eco') then
        return string.format('Slay %d %s', needed, name);
    elseif (kind == 'ws') then
        return string.format('Slay %d in %s, each finished with a weapon skill', needed, name);
    elseif (kind == 'night') then
        return string.format('Slay %d in %s between dusk and dawn', needed, name);
    elseif (kind == 'wthr') then
        return string.format('Slay %d in %s while the weather is up', needed, name);
    elseif (kind == 'comm') then
        return string.format('The server slays %d %s', needed, name);
    elseif (kind == 'zone') then
        return string.format('Slay %d creatures in %s', needed, name);
    end

    -- An unknown kind is one the server added after this addon shipped.
    -- Rendered as its own wire word, never as another kind's sentence
    -- (dwu_protocol.md: "the objective text a window composes for `zone` is
    -- not true of `night`, and showing it is the window telling the player
    -- something the server never said"). The KIND_BADGE table below already
    -- follows this rule; the sentence the player acts on must too.
    return string.format('[%s] %d x %s', kind, needed, name);
end

-- The kind badge. An UNKNOWN kind renders as itself rather than falling back
-- to 'zone': a server newer than this addon can offer a kind that did not
-- exist when it was built, and labelling it with the wrong one is worse than
-- showing a word the player has not seen before (dwu_protocol.md's rule about
-- never guessing at ids you do not recognise).
local KIND_BADGE =
{
    fam = 'family', zone = 'zone', eco = 'ecosystem',
    ws = 'weapon skill', night = 'night', wthr = 'weather', comm = 'server',
};

local function badge(text)
    imgui.TextColored(theme.colors.badge, string.format('[%s]', text));
    imgui.SameLine();
end

local function progressRow(row)
    local fraction = 0;

    if (row.needed > 0) then
        fraction = row.progress / row.needed;

        if (fraction < 0) then fraction = 0; end
        if (fraction > 1) then fraction = 1; end
    end

    imgui.ProgressBar(fraction, { -1, 16 }, string.format('%d / %d', row.progress, row.needed));
end

-- One card: the badge line, the bar, then reward, countdown and the one
-- button the card's state allows. Everything on it came off the wire.
--
-- `note` replaces the Accept button when the offer cannot be accepted from
-- here -- the slot lock, or a board being viewed from outside its band. The
-- sentence is decided by the caller off the o| state; the card only ever
-- draws one of {Accept, Abandon, note}.
local function contractCard(id, period, kind, title, reward, signed, note, tag)
    badge(period);
    badge(KIND_BADGE[kind] or tostring(kind));

    -- The expansion tag, WHEN THE SERVER SENT ONE. Never derived from the slot
    -- handle: which slots are gated is the server's decision and a window that
    -- guessed would be wrong the day the gating moves (dwu_protocol.md's rule
    -- about never inventing what the wire did not say).
    if (tag ~= nil) then
        badge(tag);
    end

    imgui.Text(title);

    if (signed ~= nil) then
        progressRow(signed);
    else
        imgui.ProgressBar(0, { -1, 16 }, 'Not signed');
    end

    imgui.TextDisabled(string.format('%d DC', reward));

    if (signed ~= nil) then
        imgui.SameLine();

        if (signed.state == 'done') then
            imgui.TextColored(theme.colors.ok, 'paid');
        else
            local left = ticked(signed.secsLeft, signed.at, state.now);

            if (left ~= nil and left <= 0) then
                imgui.TextDisabled('expired');
            else
                imgui.TextDisabled(string.format('%s left', fmtClock(left)));
            end
        end
    end

    imgui.SameLine();

    if (writePending ~= nil
            and (writePending.what == 'accept' or writePending.what == 'abandon')) then
        -- Only a BOARD write locks the cards: an augment or confirm in
        -- flight on the Exchange tab has nothing to do with these buttons,
        -- and labelled every card "Signing..." while it ran.
        imgui.TextDisabled(string.format('%s...',
            writePending.what == 'abandon' and 'Tearing up' or 'Signing'));
    elseif (signed == nil) then
        if (note ~= nil) then
            imgui.TextDisabled(note);
        elseif (imgui.SmallButton(string.format('Accept##dwquest_accept_%s', id))) then
            return 'accept';
        end
    elseif (signed.state ~= 'done') then
        if (imgui.SmallButton(string.format('Abandon##dwquest_abandon_%s', id))) then
            return 'abandon';
        end
    else
        imgui.TextDisabled('done');
    end

    imgui.Separator();

    return nil;
end

--[[
* The band row: arrows either side of "Band N (Lv lo-hi)", near the top so
* every band's board is readable without changing jobs. The label names the
* board actually on screen (the y| the server answered with); the arrows only
* ever ask. Rendered once the first board has landed -- an arrow before the
* server has said which band you are would be paging through a guess.
--]]
local function bandNavRow()
    local shown = state.band;

    if (shown == nil) then
        return;
    end

    if (imgui.SmallButton('<##dwquest_bandprev')) then
        stepBand(-1);
    end

    imgui.SameLine();

    local lo, hi = bandRange(shown);

    if (state.playerBand ~= nil and shown ~= state.playerBand) then
        imgui.Text(string.format('Band %d (Lv %d-%d)', shown, lo, hi));
        imgui.SameLine();

        if (state.viewBand ~= nil and state.viewBand ~= shown) then
            imgui.TextDisabled('loading...');
        else
            imgui.TextDisabled(string.format('-- yours is band %d', state.playerBand));
        end
    else
        imgui.Text(string.format('Band %d (Lv %d-%d)', shown, lo, hi));
        imgui.SameLine();

        if (state.viewBand ~= nil and state.viewBand ~= shown) then
            imgui.TextDisabled('loading...');
        else
            imgui.TextDisabled('-- your jobs');
        end
    end

    imgui.SameLine();

    if (imgui.SmallButton('>##dwquest_bandnext')) then
        stepBand(1);
    end

    imgui.Separator();
end

local function boardPanel()
    if (not imgui.BeginChild('##dwquest_board', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    bandNavRow();

    local offered = { };

    -- A board from outside the player's own band is a look: its open offers
    -- carry a sentence instead of an Accept, because the accept verb resolves
    -- off the real level and would sign the wrong band's slot.
    local foreign = state.playerBand ~= nil and state.band ~= nil
        and state.band ~= state.playerBand;

    for _, offer in ipairs(state.offers) do
        offered[offer.qkey] = true;

        local signed = state.actives[offer.qkey];
        local note   = nil;

        if (signed == nil) then
            if (offer.state == 'locked') then
                -- The slot lock (o| state `locked`): this slot is spent for
                -- the period by a contract signed at some band, so the server
                -- would refuse the accept this card could invite.
                note = string.format('slot spent -- back at the %s reset',
                    periodLabel(offer.slot) == 'Weekly' and 'weekly' or 'daily');
            elseif (foreign) then
                local lo, hi = bandRange(state.band);

                note = string.format('for Lv %d-%d jobs', lo, hi);
            end
        end

        local click = contractCard(offer.slot, periodLabel(offer.slot), offer.kind,
            objectiveText(offer.kind, offer.needed, offer.name), offer.reward, signed, note,
            offer.tag);

        if (click == 'accept') then
            acceptSlot(offer);
        elseif (click == 'abandon' and signed ~= nil) then
            abandonContract(signed);
        end
    end

    if (#state.offers == 0) then
        imgui.TextDisabled('No contracts offered. The board is not loaded on this server build.');
    end

    -- Contracts inside their grace period: signed under an earlier rotation,
    -- still completable, and NOT on today's board -- which is the whole reason
    -- the a| record carries its own name and reward.
    local extra = { };

    for _, qkey in ipairs(state.activeOrder) do
        if (not offered[qkey] and state.actives[qkey] ~= nil) then
            table.insert(extra, state.actives[qkey]);
        end
    end

    if (#extra > 0) then
        imgui.TextDisabled('Still yours, from an earlier board:');

        for _, row in ipairs(extra) do
            local click = contractCard(row.qkey, periodLabel(row.period), row.kind,
                objectiveText(row.kind, row.needed, row.name), row.reward, row);

            if (click == 'abandon') then
                abandonContract(row);
            end
        end
    end

    --[[
    * The server-wide contract. Drawn last, with NO BUTTON -- there is no verb
    * to accept it and inventing a button that does nothing is worse than
    * having none. What the card has to answer is "am I getting paid for this",
    * and it answers it with the server's own two numbers rather than a rule of
    * its own.
    --]]
    local community = state.community;

    if (community ~= nil) then
        imgui.Separator();

        badge('server');
        badge(KIND_BADGE.comm);
        imgui.Text(objectiveText('comm', community.needed, community.name));

        progressRow(community);

        if (community.state == 'done') then
            if (community.mine >= community.minKills) then
                imgui.TextColored(theme.colors.ok,
                    string.format('Finished. %d DC paid to your account.', community.reward));
            else
                imgui.TextDisabled(string.format(
                    'Finished. Your %d did not reach the %d needed to be paid.',
                    community.mine, community.minKills));
            end
        elseif (community.mine >= community.minKills) then
            imgui.TextColored(theme.colors.ok, string.format(
                'Your part: %d. You are on the payout -- %d DC when the server finishes it.',
                community.mine, community.reward));
        else
            imgui.TextDisabled(string.format(
                'Your part: %d of %d needed to be paid -- %d DC when the server finishes it.',
                community.mine, community.minKills, community.reward));
        end
    end

    imgui.EndChild();
end

--[[
* The Exchange panel.
*
* Reading order is the order the decisions happen in: what is for sale, who it
* is going on, which item, which slot, then the price and the one button that
* pays. Nothing further down the panel exists until the step above it has been
* answered BY THE SERVER -- there is no step here the window can complete on
* its own.
--]]
-- The fits class in words. ONE function rather than the two divergent inline
-- ternaries this used to be: the Exchange card said 'wielded weapons' and the
-- augment browser said nothing at all for the same class, so a new class had
-- to be remembered in two places to be shown in both. The fallthrough returns
-- the raw class, so an unknown one from a newer server reads as itself instead
-- of vanishing.
local function fitsWords(fits)
    if (fits == 'any') then
        return 'any gear';
    elseif (fits == 'wield') then
        return 'wielded weapons';
    elseif (fits == 'ring') then
        return 'rings only';
    end

    return tostring(fits);
end

local function offerCard(offer)
    badge(offer.slot);
    imgui.Text(offer.label);

    -- The price is the server's, rendered. So is `fits`: the window does not
    -- know what `weapon` means for an offer, and the list it asks for is
    -- filtered by the server against that same column. A Weapon Burst row
    -- carries a second currency, and the card states BOTH -- understating a
    -- burst offer's cost is the reason the shelf has its own record kind.
    if (offer.btPrice ~= nil and offer.btPrice > 0) then
        imgui.TextDisabled(string.format('%d Burst Tokens + %d DC', offer.btPrice, offer.price));
    else
        imgui.TextDisabled(string.format('%d DC', offer.price));
    end

    imgui.SameLine();
    imgui.TextDisabled(fitsWords(offer.fits));
    imgui.SameLine();

    if (writePending ~= nil) then
        imgui.TextDisabled('busy...');
    elseif (shop.picked == offer.slot) then
        imgui.TextColored(theme.colors.ok, 'chosen');
    elseif (imgui.SmallButton(string.format('Choose##dwquest_offer_%s', offer.slot))) then
        return true;
    end

    return false;
end

local function characterRow()
    local label = shop.who ~= '' and shop.who or 'You';

    imgui.TextDisabled('On:');
    imgui.SameLine();
    imgui.PushItemWidth(160);

    if (imgui.BeginCombo('##dwquest_who', label)) then
        if (imgui.Selectable('You##dwquest_who_self', shop.who == '')) then
            chooseCharacter('');
        end

        for _, member in ipairs(shop.roster) do
            -- `self` is reached by leaving the name off and `online` is a
            -- refusal the server would make, so only offline alts are
            -- selectable -- and the others are still SHOWN, greyed, with the
            -- reason, because "my alt is missing from the list" is a worse
            -- question than "my alt is logged in".
            if (member.state == 'offline') then
                if (imgui.Selectable(string.format('%s##dwquest_who_%s', member.name, member.name),
                        shop.who == member.name)) then
                    chooseCharacter(member.name);
                end
            elseif (member.state == 'online') then
                imgui.TextDisabled(string.format('%s (logged in)', member.name));
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
    imgui.SameLine();
    imgui.PushItemWidth(160);

    -- EnterReturnsTrue, so this fires on Enter and not on each character --
    -- the commit, and the only place the live buffer is read.
    if (imgui.InputText('##dwquest_filter', shop.filter, 64, ImGuiInputTextFlags_EnterReturnsTrue)) then
        shop.filterApplied = safeFilter(shop.filter[1]);
        invalidateGear();
    end

    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.SmallButton('Search##dwquest_gearsearch')) then
        shop.filterApplied = safeFilter(shop.filter[1]);
        invalidateGear();
    end
end

local function slotView()
    local item = shop.item;

    if (item == nil) then
        return;
    end

    imgui.Text(string.format('%s%s', item.name,
        (item.charname ~= nil and item.charname ~= '' and shop.who ~= '') and (' (' .. item.charname .. ')') or ''));

    -- USED AND FREE COME OFF k| (client discipline 7 and the owner's brief
    -- #8). The window does not count the s| records -- they are only emitted
    -- for occupied slots, so counting them would be the window deriving a
    -- number the player is about to consent against.
    imgui.TextDisabled(string.format('%d of %d augment slots used', item.used, item.maxslots));

    local landing = shop.quote ~= nil and shop.quote.landing or 0;
    local full    = item.free == 0;

    for index = 1, item.maxslots do
        local slot = shop.slots[index];

        -- Decoded through the catalog ("Dbl.Atk.+3%  [143]"), because "which
        -- augment do I give up" is the question this view exists to answer
        -- and raw ids cannot. Falls back to the raw pair when the catalog is
        -- missing or the id is not in it.
        if (index == landing) then
            imgui.TextColored(theme.colors.hint, string.format('  slot %d: %s', index,
                slot ~= nil and string.format('%s -- REPLACED', augmentText(slot.augid, slot.rank)) or 'empty -- lands here'));
        elseif (slot ~= nil) then
            imgui.Text(string.format('  slot %d: %s', index, augmentText(slot.augid, slot.rank)));
        else
            imgui.TextDisabled(string.format('  slot %d: empty', index));
        end

        -- A full item can only take a purchase by giving something up, and the
        -- server refuses to guess which. One button per occupied slot, and the
        -- click is a fresh quote naming that slot -- never a confirm.
        if (full and slot ~= nil and shop.quote == nil and writePending == nil) then
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Replace##dwquest_replace_%d', index))) then
                return index;
            end
        end
    end

    return nil;
end

local function quoteRow()
    local quote = shop.quote;

    if (quote == nil) then
        return;
    end

    -- THE PRICE IS THE QUOTE'S. Not the offer card's, not a lookup by handle,
    -- not anything this file could have got wrong: the record the player is
    -- consenting to is the record the purchase is settled against. A Weapon
    -- Burst quote carries a second currency in the same record (p| part 8).
    if (quote.btPrice ~= nil and quote.btPrice > 0) then
        imgui.TextColored(theme.colors.ok, string.format('%s -- %d Burst Tokens + %d DC', quote.label, quote.btPrice, quote.price));
    else
        imgui.TextColored(theme.colors.ok, string.format('%s -- %d DC', quote.label, quote.price));
    end
    imgui.TextDisabled(string.format('Lands in slot %d. Once augmented it is bound to your account: no auction house, no trade, no bazaar.',
        quote.landing));

    if (writePending ~= nil) then
        imgui.TextDisabled(string.format('%s...',
            writePending.what == 'confirm' and 'Buying' or 'Pricing'));

        return false;
    end

    -- THE BUTTON DOES NOT EXIST WITHOUT AN ARMED QUOTE. `armed` is set only by
    -- a p| record and cleared by the click itself, so there is no frame in
    -- which a second Confirm is drawable for one quote.
    if (not quote.armed) then
        imgui.TextDisabled('Sent.');

        return false;
    end

    if (imgui.SmallButton('Confirm##dwquest_confirm')) then
        return true;
    end

    imgui.SameLine();

    if (imgui.SmallButton('Cancel##dwquest_cancel')) then
        -- Local only. The server's quote ages out on its own (p| says how
        -- long); there is no verb for "never mind" and inventing one would be
        -- a line the typed tier does not have.
        shop.quote = nil;
        shop.item  = nil;
        shop.slots = { };
    end

    return false;
end

local function gearList()
    if (not shop.gearSynced) then
        imgui.TextDisabled('Looking through the bags...');

        return;
    end

    if (#shop.gear == 0) then
        -- A committed search filter is invisible once the box is cleared,
        -- and an old term reads exactly like 'no valid targets' (the
        -- 2026-08-25 'snoll' hunt) -- so an empty list NAMES it.
        if (shop.filterApplied ~= nil and shop.filterApplied ~= '') then
            imgui.TextDisabled(string.format('Nothing matches the search "%s". Clear it with Search on an empty box.', shop.filterApplied));

            return;
        end

        imgui.TextDisabled('Nothing here can take that augment. Equipment only, not equipped, not enchanted, not priced in a bazaar.');

        return;
    end

    for _, row in ipairs(shop.gear) do
        imgui.Text(string.format('%s%s', row.name, row.count > 1 and string.format('  (x%d)', row.count) or ''));
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d of 4 used', row.used));
        imgui.SameLine();

        if (writePending ~= nil) then
            imgui.TextDisabled('busy...');
        elseif (row.free > 0) then
            if (imgui.SmallButton(string.format('Pick##dwquest_pick_%d', row.itemid))) then
                quoteItem(row, nil);
            end
        elseif (imgui.SmallButton(string.format('Slots##dwquest_slots_%d', row.itemid))) then
            -- Full: there is nothing to quote until the player says what to
            -- give up, so this asks to SEE the slots rather than to price one.
            inspectItem(row);
        end
    end

    -- A CAP THAT DOES NOT SAY SO READS AS AN INVENTORY. Both numbers are the
    -- server's; the window compares them and says which one it drew.
    if (shop.gearShown < shop.gearTotal) then
        imgui.TextDisabled(string.format('Showing %d of %d. Type part of a name to narrow it.',
            shop.gearShown, shop.gearTotal));
    end
end

local function exchangePanel()
    if (not imgui.BeginChild('##dwquest_exchange', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not shop.synced) then
        imgui.TextDisabled('Waiting for the Exchange...');
        imgui.EndChild();

        return;
    end

    if (shop.clockAt ~= nil) then
        imgui.TextDisabled(string.format('New offers in %s',
            fmtClock(ticked(shop.secsToRoll, shop.clockAt, state.now))));
    end

    if (#shop.offers == 0) then
        imgui.TextDisabled('The Exchange has nothing today. The offer pool is not loaded on this server build.');
        imgui.EndChild();

        return;
    end

    imgui.Separator();

    for _, offer in ipairs(shop.offers) do
        if (offerCard(offer)) then
            chooseOffer(offer);
        end
    end

    -- The Weapon Burst shelf (2026-08-25): always available, never part of
    -- the rotation above, priced in the arena's currency AND coins. Rendered
    -- as it arrived, the same contract as everything else in this window.
    if (#shop.burst > 0) then
        imgui.Separator();
        imgui.TextDisabled('Weapon Burst -- always available. The arena pays the tokens: floor cleared = tokens earned.');

        for _, offer in ipairs(shop.burst) do
            if (offerCard(offer)) then
                chooseOffer(offer);
            end
        end
    end

    imgui.Separator();

    if (shop.picked == nil) then
        imgui.TextDisabled('Choose an augment above, then pick the gear it goes on.');
        imgui.EndChild();

        return;
    end

    characterRow();
    imgui.Separator();

    if (shop.item == nil) then
        gearList();
    else
        local replace = slotView();

        if (replace ~= nil) then
            -- A replace click is a NEW QUOTE naming the slot, which is the
            -- only way the price and the landing slot the player consents to
            -- can both be the server's.
            quoteItem({ itemid = shop.item.itemid, name = shop.item.name }, replace);
        end

        imgui.Separator();

        if (quoteRow()) then
            confirmPurchase();
        end

        if (shop.quote == nil and writePending == nil) then
            if (imgui.SmallButton('Back to the list##dwquest_back')) then
                shop.item  = nil;
                shop.slots = { };
            end
        end
    end

    imgui.EndChild();
end

-- The storefront rolled while the tab was open: the four offers on screen
-- belong to the Vana'diel day that just ended, and a quote taken against them
-- is refused (dwu_protocol.md, `v|`). Asked ONCE per header -- v| clears it.
local function checkShopRotation(now)
    if (shop.rollAsked or not shop.synced or shop.clockAt == nil) then
        return;
    end

    local left = ticked(shop.secsToRoll, shop.clockAt, now);

    if (left ~= nil and left <= 0) then
        shop.rollAsked = true;
        shop.synced    = false;
        shop.picked    = nil;
        shop.item      = nil;
        shop.slots     = { };
        shop.quote     = nil;

        invalidateGear();

        requested['augments'] = nil;
    end
end

--[[
* The Outfitter tab (Phase 7). Static stock: no rotation clock, no re-ask on
* a roll -- the only reads are the directory-plus-rows fetch for the selected
* job, through the same ask-once-retry-once tracker as every other read.
--]]
local function outfitterPanel()
    if (not imgui.BeginChild('##dwquest_outfit', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not outfit.synced) then
        imgui.TextDisabled('Waiting for the Outfitter...');
        imgui.EndChild();

        return;
    end

    if (#outfit.jobs == 0) then
        imgui.TextDisabled('The Outfitter is not stocked on this server build.');
        imgui.EndChild();

        return;
    end

    -- No price in this line ON PURPOSE: the shelf carries two tiers now
    -- (AF and relic) and each row states its own price off the wire -- a
    -- single number here would be a second source of truth for MONEY.
    imgui.TextDisabled('Artifact and AF+1, relic and Empyrean +2 sets, the job capes (lv1/40/75/99), and the lv27-33 race gear.\nAF, AF+1, relic, Empyrean and capes are Rare/Ex (account-bound); the race gear is plain and tradeable.');

    -- The job picker: the directory the server sent, never a local list. The
    -- selection change invalidates the rows (needOutfit re-arms the read).
    local current = nil;

    for _, job in ipairs(outfit.jobs) do
        if (job.word == outfit.job) then
            current = job;
        end
    end

    imgui.SetNextItemWidth(180);

    if (imgui.BeginCombo('##dwquest_outfit_job', current ~= nil and current.label or 'Pick a job...')) then
        for _, job in ipairs(outfit.jobs) do
            if (imgui.Selectable(string.format('%s##dwquest_outfit_job_%s', job.label, job.word),
                    outfit.job == job.word)) then
                if (outfit.job ~= job.word) then
                    outfit.job  = job.word;
                    outfit.rows = { };
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.Separator();

    if (outfit.job == nil) then
        imgui.TextDisabled('Pick a job to see its shelf.');
        imgui.EndChild();

        return;
    end

    if (#outfit.rows == 0) then
        imgui.TextDisabled('Fetching the shelf...');
        imgui.EndChild();

        return;
    end

    for _, row in ipairs(outfit.rows) do
        -- The icon, then the label -- and the hover card on either (the
        -- dwraid row shape: drawIcon leaves the cursor on the same line, and
        -- IsItemHovered reads the LAST item, so both get their own check).
        drawIcon(row.itemid, 20);

        if (imgui.IsItemHovered()) then
            itemTooltip(row);
        end

        imgui.Text(row.label);

        if (imgui.IsItemHovered()) then
            itemTooltip(row);
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('lv%d %s', row.level, row.slot));
        imgui.SameLine();
        imgui.TextColored(theme.colors.ok, string.format('%d DC', row.price));
        imgui.SameLine();

        if (writePending ~= nil) then
            imgui.TextDisabled('busy...');
        elseif (outfit.quote == nil) then
            -- A buy is a QUOTE (the t| that answers is the only thing that
            -- can arm Confirm), but it is queued as a WRITE: never collapsed,
            -- never re-sent, and the buttons wait while it is in flight.
            if (imgui.SmallButton(string.format('Buy##dwquest_outfit_buy_%d', row.index))) then
                beginWrite('buy', row.label, string.format('!dwu buy %d', row.index));
            end
        end
    end

    -- The armed quote, and the ONLY place Confirm exists. The click disarms
    -- it in the same statement that queues the line (the Exchange's rule,
    -- money behind it): one t| confirms at most once.
    if (outfit.quote ~= nil) then
        imgui.Separator();

        local left = ticked(outfit.quote.holds, outfit.quote.at, state.now);

        if (left ~= nil and left <= 0) then
            outfit.quote = nil;
        else
            imgui.TextColored(theme.colors.hint, string.format('%s -- %d DC   (%ds to confirm)',
                outfit.quote.label, outfit.quote.price, left or 0));

            if (writePending ~= nil) then
                imgui.TextDisabled('buying...');
            else
                if (imgui.SmallButton('Confirm##dwquest_outfit_confirm')) then
                    local line = '!dwu confirm';

                    outfit.quote = nil;
                    beginWrite('confirm', line, line);
                end

                imgui.SameLine();

                if (imgui.SmallButton('Cancel##dwquest_outfit_cancel')) then
                    -- Local teardown only: the server's quote ages out on its
                    -- own clock, and nothing un-asks a price.
                    outfit.quote = nil;
                end
            end
        end
    end

    imgui.EndChild();
end

--[[
* The Outfitter's read, issued only while its tab is on screen. The request
* names the selected job (rows travel per job); a selection change re-arms
* the tracker the way the gear list's signature does.
--]]
local function needOutfit(now)
    local wanted = '!dwu shelf';

    if (outfit.job ~= nil) then
        wanted = string.format('!dwu shelf %s', outfit.job);
    end

    if (outfit.rowsFor ~= wanted) then
        outfit.rowsFor      = wanted;
        outfit.synced       = false;
        requested['shelf']  = nil;
    end

    askOnce('shelf', wanted, now);
end

--[[
* The ArmsDealer tab (owner request 2026-08-20; the Artifact Weapons case
* added 2026-08-21). The Outfitter's panel one storefront over: a category
* dropdown and that case's weapons under it, each a Buy that quotes and a
* Confirm that spends -- the same ask-once tracker, the same quote-then-confirm
* dance, its own state.
*
* THE CASES ARE PRICED SEPARATELY and this file never says how much anything
* costs: the price on every row and on the quote comes off the wire. The
* dropdown's ORDER is the wire's order too, so which case sits on top is the
* server's decision, not a sort here.
--]]
local function armsdealerPanel()
    if (not imgui.BeginChild('##dwquest_arms', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not arms.synced) then
        imgui.TextDisabled('Waiting for the ArmsDealer...');
        imgui.EndChild();

        return;
    end

    if (#arms.categories == 0) then
        imgui.TextDisabled('The ArmsDealer is not stocked on this server build.');
        imgui.EndChild();

        return;
    end

    -- The selected case, from the directory the server sent -- never a local
    -- list. The selection change invalidates the rows (needArms re-arms the
    -- read).
    local current = nil;

    for _, cat in ipairs(arms.categories) do
        if (cat.key == arms.category) then
            current = cat;
        end
    end

    -- The header names the SELECTED case and takes its price off the rows the
    -- server sent, never a constant of this file's own: the cases are priced an
    -- order of magnitude apart (25 DC vs 250 DC) and a hardcoded number here
    -- would be a second source of truth for MONEY. The server carries the
    -- resolved price onto the quote and spends exactly that, so a window that
    -- disagreed would be charged, not refused.
    if (current ~= nil and #arms.rows > 0) then
        imgui.TextDisabled(string.format('%s -- %d pieces, %d DC each. Rare/Ex: yours, and your account\'s.',
            current.label, #arms.rows, arms.rows[1].price));
    else
        imgui.TextDisabled('Weapons for Drift Coins. Rare/Ex: yours, and your account\'s.');
    end

    imgui.SetNextItemWidth(180);

    if (imgui.BeginCombo('##dwquest_arms_cat', current ~= nil and current.label or 'Pick a case...')) then
        for _, cat in ipairs(arms.categories) do
            if (imgui.Selectable(string.format('%s##dwquest_arms_cat_%s', cat.label, cat.key),
                    arms.category == cat.key)) then
                if (arms.category ~= cat.key) then
                    arms.category = cat.key;
                    arms.rows     = { };
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.Separator();

    if (arms.category == nil) then
        imgui.TextDisabled('Pick a case to see its weapons.');
        imgui.EndChild();

        return;
    end

    if (#arms.rows == 0) then
        imgui.TextDisabled('Fetching the case...');
        imgui.EndChild();

        return;
    end

    for _, row in ipairs(arms.rows) do
        -- The icon, then the label -- and the hover card on either (the
        -- Outfitter's row shape: drawIcon leaves the cursor on the same line,
        -- and IsItemHovered reads the LAST item, so both get their own check).
        drawIcon(row.itemid, 20);

        if (imgui.IsItemHovered()) then
            itemTooltip(row);
        end

        imgui.Text(row.label);

        if (imgui.IsItemHovered()) then
            itemTooltip(row);
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('%s, %s', row.wtype, row.jobs));
        imgui.SameLine();
        imgui.TextColored(theme.colors.ok, string.format('%d DC', row.price));
        imgui.SameLine();

        if (writePending ~= nil) then
            imgui.TextDisabled('busy...');
        elseif (arms.quote == nil) then
            -- A buy is a QUOTE (the t| that answers is the only thing that can
            -- arm Confirm), queued as a WRITE: never collapsed, never re-sent,
            -- and the buttons wait while it is in flight.
            if (imgui.SmallButton(string.format('Buy##dwquest_arms_buy_%d', row.index))) then
                beginWrite('armsbuy', row.label, string.format('!dwu armsbuy %d', row.index));
            end
        end
    end

    -- The armed quote, and the ONLY place Confirm exists for this tab.
    if (arms.quote ~= nil) then
        imgui.Separator();

        local left = ticked(arms.quote.holds, arms.quote.at, state.now);

        if (left ~= nil and left <= 0) then
            arms.quote = nil;
        else
            imgui.TextColored(theme.colors.hint, string.format('%s -- %d DC   (%ds to confirm)',
                arms.quote.label, arms.quote.price, left or 0));

            if (writePending ~= nil) then
                imgui.TextDisabled('buying...');
            else
                if (imgui.SmallButton('Confirm##dwquest_arms_confirm')) then
                    local line = '!dwu confirm';

                    arms.quote = nil;
                    beginWrite('confirm', line, line);
                end

                imgui.SameLine();

                if (imgui.SmallButton('Cancel##dwquest_arms_cancel')) then
                    -- Local teardown only: the server's quote ages out on its
                    -- own clock, and nothing un-asks a price.
                    arms.quote = nil;
                end
            end
        end
    end

    imgui.EndChild();
end

--[[
* The ArmsDealer's read, issued only while its tab is on screen. The request
* names the selected category (rows travel per category); a selection change
* re-arms the tracker the way the Outfitter's does.
--]]
local function needArms(now)
    local wanted = '!dwu arms';

    if (arms.category ~= nil) then
        wanted = string.format('!dwu arms %s', arms.category);
    end

    if (arms.rowsFor ~= wanted) then
        arms.rowsFor      = wanted;
        arms.synced       = false;
        requested['arms'] = nil;
    end

    askOnce('arms', wanted, now);
end

-- The client's own name for an item id (the dwbags/dwraid shape). The other
-- storefronts never need this -- their labels ride the wire -- but the pop
-- rows carry only ids, and the ids are the point: names resolve from the
-- DATs the player is actually running.
local function popItemName(itemId)
    local item = AshitaCore:GetResourceManager():GetItemById(itemId or 0);

    if (item ~= nil and item.Name ~= nil and item.Name[1] ~= nil and #item.Name[1] > 0) then
        return item.Name[1];
    end

    return string.format('item %d', itemId or 0);
end

--[[
* The Pop-Items tab (owner request 2026-08-30, the Huntboard round). The
* ArmsDealer's dance -- Buy quotes, Confirm settles, one pending purchase
* per character -- with the bag for a purse: every price is Dynamis
* hundred-pieces plus DIFFERENT Job Testimonies, charged from the inventory
* cell by cell, and the h| line under the header shows the same two numbers
* the confirm will read. This file never says what anything costs: every
* number on every row and on the quote comes off the wire.
--]]
local function popitemsPanel()
    if (not imgui.BeginChild('##dwquest_pops', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not pop.synced) then
        imgui.TextDisabled('Waiting for the Pop-Items shelf...');
        imgui.EndChild();

        return;
    end

    if (#pop.rows == 0) then
        imgui.TextDisabled('The Pop-Items shelf is not stocked on this server build.');
        imgui.EndChild();

        return;
    end

    imgui.TextDisabled('Forced-spawn keys for Dynamis hundred-pieces + Job Testimonies, from your bag.');
    imgui.TextDisabled('Testimonies must each be a DIFFERENT job\'s. Any mix of the three coin families pays.');

    if (pop.hundreds ~= nil) then
        imgui.TextColored(theme.colors.ok, string.format('Your bag: %d hundred-piece(s), %d testimony type(s).',
            pop.hundreds, pop.types or 0));
        imgui.SameLine();
        imgui.TextDisabled('The warehouse does not pay.');
    end

    for _, tier in ipairs(pop.tiers) do
        local first = true;

        for _, row in ipairs(pop.rows) do
            if (row.tier == tier.key) then
                if (first) then
                    first = false;

                    imgui.Separator();
                    imgui.TextColored(theme.colors.hint, string.format('%s -- %d hundred-piece(s) + %d testimon%s',
                        tier.label, row.hundreds, row.testimonies, row.testimonies == 1 and 'y' or 'ies'));
                end

                -- The icon(s), then the item name(s) resolved from the DATs,
                -- then the NM and its zone -- the hover card on each icon and
                -- name (the arms row shape, with a second item for the sky
                -- pairs).
                drawIcon(row.itemid, 20);

                if (imgui.IsItemHovered()) then
                    itemTooltip({ itemid = row.itemid, label = popItemName(row.itemid) });
                end

                imgui.Text(popItemName(row.itemid));

                if (imgui.IsItemHovered()) then
                    itemTooltip({ itemid = row.itemid, label = popItemName(row.itemid) });
                end

                if (row.itemid2 ~= 0) then
                    imgui.SameLine();
                    imgui.TextDisabled('+');
                    imgui.SameLine();

                    drawIcon(row.itemid2, 20);

                    if (imgui.IsItemHovered()) then
                        itemTooltip({ itemid = row.itemid2, label = popItemName(row.itemid2) });
                    end

                    imgui.Text(popItemName(row.itemid2));

                    if (imgui.IsItemHovered()) then
                        itemTooltip({ itemid = row.itemid2, label = popItemName(row.itemid2) });
                    end
                end

                imgui.SameLine();
                imgui.TextDisabled(string.format('pops %s (%s)', row.label, row.where));
                imgui.SameLine();

                if (writePending ~= nil) then
                    imgui.TextDisabled('busy...');
                elseif (pop.quote == nil) then
                    if (imgui.SmallButton(string.format('Buy##dwquest_pop_buy_%d', row.index))) then
                        beginWrite('popbuy', row.label, string.format('!dwu popbuy %d', row.index));
                    end
                end
            end
        end
    end

    -- The armed quote, and the ONLY place Confirm exists for this tab.
    if (pop.quote ~= nil) then
        imgui.Separator();

        local left = ticked(pop.quote.holds, pop.quote.at, state.now);

        if (left ~= nil and left <= 0) then
            pop.quote = nil;
        else
            local quoted = nil;

            for _, row in ipairs(pop.rows) do
                if (row.index == pop.quote.index) then
                    quoted = row;
                end
            end

            imgui.TextColored(theme.colors.hint, string.format('%s -- %d hundred-piece(s) + %d different testimon%s, from your bag   (%ds to confirm)',
                quoted ~= nil and quoted.label or '?', pop.quote.hundreds,
                pop.quote.testimonies, pop.quote.testimonies == 1 and 'y' or 'ies', left or 0));

            if (writePending ~= nil) then
                imgui.TextDisabled('buying...');
            else
                if (imgui.SmallButton('Confirm##dwquest_pop_confirm')) then
                    local line = '!dwu confirm';

                    pop.quote = nil;
                    beginWrite('confirm', line, line);
                end

                imgui.SameLine();

                if (imgui.SmallButton('Cancel##dwquest_pop_cancel')) then
                    -- Local teardown only: the server's quote ages out on its
                    -- own clock, and nothing un-asks a price.
                    pop.quote = nil;
                end
            end
        end
    end

    imgui.EndChild();
end

-- The Pop-Items read, issued only while its tab is on screen. One request,
-- whole shelf -- there is no per-tier fetch to re-arm for.
local function needPops(now)
    askOnce('pops', '!dwu pops', now);
end

--[[
* The Jeweler tab (owner request 2026-09-03). The ArmsDealer's dance -- Buy
* quotes, Confirm settles, one pending purchase per character -- over the
* Pop-Items' shape: the whole shelf on one read, grouped under the case
* headers the j| directory names, no dropdown. THE CASES ARE PRICED
* SEPARATELY and this file never says how much anything costs: the price on
* every row, on every header and on the quote comes off the wire.
--]]
local function jewelerPanel()
    if (not imgui.BeginChild('##dwquest_jewel', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not jewel.synced) then
        imgui.TextDisabled('Waiting for the Jeweler...');
        imgui.EndChild();

        return;
    end

    if (#jewel.cases == 0 or #jewel.rows == 0) then
        imgui.TextDisabled('The Jeweler is not stocked on this server build.');
        imgui.EndChild();

        return;
    end

    imgui.TextDisabled('Earrings and rings for Drift Coins. Rare/Ex: yours, and your account\'s.');

    for _, case in ipairs(jewel.cases) do
        local first = true;

        for _, row in ipairs(jewel.rows) do
            if (row.catId == case.catId) then
                if (first) then
                    first = false;

                    imgui.Separator();
                    -- The header's price is the FIRST ROW'S, off the wire --
                    -- never a constant of this file's own (the ArmsDealer's
                    -- rule: a hardcoded number here would be a second source
                    -- of truth for MONEY).
                    imgui.TextColored(theme.colors.hint, string.format('%s -- %d DC each',
                        case.label, row.price));
                end

                -- The icon, then the label -- and the hover card on either
                -- (the Outfitter's row shape).
                drawIcon(row.itemid, 20);

                if (imgui.IsItemHovered()) then
                    itemTooltip(row);
                end

                imgui.Text(row.label);

                if (imgui.IsItemHovered()) then
                    itemTooltip(row);
                end

                imgui.SameLine();
                imgui.TextDisabled(string.format('%s, %s', row.slot, row.jobs));
                imgui.SameLine();
                imgui.TextColored(theme.colors.ok, string.format('%d DC', row.price));
                imgui.SameLine();

                if (writePending ~= nil) then
                    imgui.TextDisabled('busy...');
                elseif (jewel.quote == nil) then
                    -- A buy is a QUOTE (the t| that answers is the only thing
                    -- that can arm Confirm), queued as a WRITE: never
                    -- collapsed, never re-sent, and the buttons wait while it
                    -- is in flight.
                    if (imgui.SmallButton(string.format('Buy##dwquest_jewel_buy_%d', row.index))) then
                        beginWrite('jewelbuy', row.label, string.format('!dwu jewelbuy %d', row.index));
                    end
                end
            end
        end
    end

    -- The armed quote, and the ONLY place Confirm exists for this tab.
    if (jewel.quote ~= nil) then
        imgui.Separator();

        local left = ticked(jewel.quote.holds, jewel.quote.at, state.now);

        if (left ~= nil and left <= 0) then
            jewel.quote = nil;
        else
            imgui.TextColored(theme.colors.hint, string.format('%s -- %d DC   (%ds to confirm)',
                jewel.quote.label, jewel.quote.price, left or 0));

            if (writePending ~= nil) then
                imgui.TextDisabled('buying...');
            else
                if (imgui.SmallButton('Confirm##dwquest_jewel_confirm')) then
                    local line = '!dwu confirm';

                    jewel.quote = nil;
                    beginWrite('confirm', line, line);
                end

                imgui.SameLine();

                if (imgui.SmallButton('Cancel##dwquest_jewel_cancel')) then
                    -- Local teardown only: the server's quote ages out on its
                    -- own clock, and nothing un-asks a price.
                    jewel.quote = nil;
                end
            end
        end
    end

    imgui.EndChild();
end

-- The Jeweler's read, issued only while its tab is on screen. One request,
-- whole shelf -- there is no per-case fetch to re-arm for.
local function needJewel(now)
    askOnce('jeweler', '!dwu jeweler', now);
end

local function headerRow()
    -- Refresh re-says `hello`, not `board`. It is the player's deliberate
    -- "make this right" click, and the one thing a plain re-read could not fix
    -- is a lost arming -- a map that restarted under the session drops the
    -- local var the ping rides on, and every following board read would come
    -- back correct and silent forever after. Re-arming is a no-op when it was
    -- never lost.
    if (imgui.Button('Refresh##dwquest_refresh')) then
        -- Home first: `hello` answers the player's own board, and a view flag
        -- left set would have the next auto-sync silently steer away again.
        state.viewBand = nil;

        refresh('hello');
    end

    imgui.SameLine();

    if (state.balance ~= nil) then
        imgui.TextColored(theme.colors.ok, string.format('%d DC', state.balance));
    else
        imgui.TextDisabled('-- DC');
    end

    -- The Burst Token purse (2026-08-25), shown only once a server that
    -- knows the currency has answered -- an invented zero would read as
    -- "you have none" on a server that simply predates the arena.
    if (state.burstBalance ~= nil) then
        imgui.SameLine();
        imgui.TextColored(theme.colors.ok, string.format('%d BT', state.burstBalance));
    end

    local queued = #readQueue + #writeQueue;

    if (queued > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d queued...', queued));
    end

    if (state.day ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('day %d  band %d  pool v%d',
            state.day, state.band or 0, state.poolVersion or 0));
    end

    if (state.clockAt ~= nil) then
        imgui.TextDisabled(string.format('New dailies in %s   New weeklies in %s',
            fmtClock(ticked(state.secsToDay, state.clockAt, state.now)),
            fmtClock(ticked(state.secsToWeek, state.clockAt, state.now))));
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    if (state.toast ~= nil and state.toastAt ~= nil and (state.now - state.toastAt) <= TOAST_SECONDS) then
        imgui.TextColored(theme.colors.hint, state.toast);
    end

    imgui.Separator();
end

--[[
* The Exchange's reads, issued only while its tab is the one on screen. A
* window sitting on the Board tab has no business asking for a storefront.
--]]
local function needShop(now)
    askOnce('augments', '!dwu augments', now);

    if (shop.picked == nil) then
        return;
    end

    local wanted = gearRequest();

    if (wanted == nil) then
        return;
    end

    -- The signature of the request the list would answer. When it changes --
    -- a different offer, a different character, a different search -- the
    -- tracker is re-armed and the list on screen is stale until the answer
    -- lands.
    if (shop.gearFor ~= wanted) then
        shop.gearFor      = wanted;
        shop.gearSynced   = false;
        requested['gear'] = nil;
    end

    askOnce('gear', wanted, now);
end

--[[
* The Augments reference tab (2026-08-19).
*
* Everything static here comes off augcatalog.lua (generated, see the header);
* the only live ingredient is TODAY's four offers, read off the same
* shop.offers the Exchange tab renders -- so the [today] markers and the
* Exchange's cards can never disagree about what is on sale. The tab issues
* the same `!dwu augments` read under the same ask-once tracker, so whichever
* tab is opened first pays for the one fetch.
*
* The view is CACHED against the search-and-scope key rather than filtered
* every frame: ~700 rows through string.find per frame is work a window
* redraws sixty times a second for no new answer (dwwarehouse's caching
* lesson, one tab over). Paged locally because a filtered-down list is the
* normal way to use a reference; the pager exists for the browse case.
--]]
local AUGREF_PAGE = 200;

local augref = {
    filter   = T{ '' },  -- InputText live buffer; committed on Enter/Search
    applied  = '',       -- the committed search, lowercased
    poolOnly = false,    -- scope: everything, or only what the Exchange sells
    page     = 1,
    ids      = nil,      -- every catalog id, sorted once on first draw
    view     = nil,      -- the filtered id list the pager walks
    viewKey  = nil,      -- the (applied, poolOnly) the view answers
};

local function augrefView()
    if (augref.ids == nil) then
        augref.ids = { };

        for id in pairs(augcatalog.augments) do
            table.insert(augref.ids, id);
        end

        table.sort(augref.ids);
    end

    local key = string.format('%s|%s', augref.applied, tostring(augref.poolOnly));

    if (augref.view == nil or augref.viewKey ~= key) then
        augref.viewKey = key;
        augref.view    = { };

        for _, id in ipairs(augref.ids) do
            if (not augref.poolOnly or augcatalog.pool[id] ~= nil) then
                if (augref.applied == ''
                        or string.find(string.lower(augcatalog.augments[id].l), augref.applied, 1, true) ~= nil
                        or string.find(tostring(id), augref.applied, 1, true) ~= nil) then
                    table.insert(augref.view, id);
                end
            end
        end
    end

    return augref.view;
end

local function augrefPanel()
    if (not imgui.BeginChild('##dwquest_augref', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not haveCatalog) then
        imgui.TextDisabled('The augment catalog (augcatalog.lua) is missing from this addon folder.');
        imgui.TextDisabled('Slot views fall back to raw augment numbers. Re-syncing the addon restores the reference.');
        imgui.EndChild();

        return;
    end

    -- Today's offers, by augment id. Four entries, rebuilt per frame, so a
    -- rotation that lands mid-session moves the markers the same frame it
    -- moves the Exchange's cards.
    local today = { };

    for _, offer in ipairs(shop.offers) do
        today[offer.augid] = offer;
    end

    imgui.TextColored(theme.colors.ok, '[today]');
    imgui.SameLine();
    imgui.TextDisabled('on the Exchange right now.');
    imgui.SameLine();
    imgui.TextColored(theme.colors.hint, '[sold]');
    imgui.SameLine();
    imgui.TextDisabled('the Exchange sells it -- the rank, price and gear it fits are beside the row.');

    imgui.TextDisabled('Numbers in brackets are what gear slots store; the Exchange tab shows the same numbers decoded.');

    imgui.PushItemWidth(180);

    -- EnterReturnsTrue: the commit, and the only read of the live buffer --
    -- the Exchange search's rule, for the Exchange search's reason.
    if (imgui.InputText('##dwquest_augref_search', augref.filter, 64, ImGuiInputTextFlags_EnterReturnsTrue)) then
        augref.applied = string.lower(augref.filter[1] or '');
        augref.page    = 1;
    end

    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.SmallButton('Search##dwquest_augref_go')) then
        augref.applied = string.lower(augref.filter[1] or '');
        augref.page    = 1;
    end

    imgui.SameLine();

    -- A two-state button rather than a checkbox: no ImGui surface this addon
    -- does not already use.
    if (imgui.SmallButton(augref.poolOnly and 'Showing: Exchange only##dwquest_augref_scope'
            or 'Showing: everything##dwquest_augref_scope')) then
        augref.poolOnly = not augref.poolOnly;
        augref.page     = 1;
    end

    local view  = augrefView();
    local total = #view;
    local pages = math.max(1, math.ceil(total / AUGREF_PAGE));

    if (augref.page > pages) then
        augref.page = pages;
    end

    local first = (augref.page - 1) * AUGREF_PAGE + 1;
    local last  = math.min(total, first + AUGREF_PAGE - 1);

    imgui.TextDisabled(string.format('%d augment(s)%s%s', total,
        augref.applied ~= '' and string.format(' matching "%s"', augref.applied) or '',
        pages > 1 and string.format(' -- page %d of %d', augref.page, pages) or ''));

    if (pages > 1) then
        imgui.SameLine();

        if (imgui.SmallButton('<##dwquest_augref_prev')) then
            augref.page = math.max(1, augref.page - 1);
        end

        imgui.SameLine();

        if (imgui.SmallButton('>##dwquest_augref_next')) then
            augref.page = math.min(pages, augref.page + 1);
        end
    end

    imgui.Separator();

    for index = first, last do
        local id    = view[index];
        local entry = augcatalog.augments[id];
        local offer = today[id];
        local sold  = augcatalog.pool[id];

        if (offer ~= nil) then
            imgui.TextColored(theme.colors.ok, '[today]');
            imgui.SameLine();
        elseif (sold ~= nil) then
            imgui.TextColored(theme.colors.hint, '[sold]');
            imgui.SameLine();
        end

        imgui.Text(string.format('%4d  %s', id, entry.l));

        if (sold ~= nil) then
            imgui.SameLine();
            imgui.TextDisabled(string.format('rank %d, %d DC, %s',
                sold.rank, sold.price, fitsWords(sold.fits)));
        end

        -- A [today] row can start the purchase from here: the SAME picker the
        -- Exchange's cards feed, so there is one chosen offer whichever tab
        -- chose it. Blocked while a write is in flight, like the cards.
        if (offer ~= nil) then
            imgui.SameLine();

            if (writePending ~= nil) then
                imgui.TextDisabled('busy...');
            elseif (shop.picked == offer.slot) then
                imgui.TextColored(theme.colors.ok, 'chosen -- the Exchange tab picks the gear');
            elseif (imgui.SmallButton(string.format('Choose##dwquest_augref_%d', id))) then
                chooseOffer(offer);
                toast('Chosen. Open the Exchange tab to pick the gear it goes on.');
            end
        end
    end

    imgui.EndChild();
end

local function renderWindow()
    headerRow();

    -- Which tab is on screen decides which reads run, and the flag is set from
    -- what ImGui actually drew rather than from a click handler: a tab
    -- restored from imgui.ini is one nobody clicked this session.
    local onExchange = false;
    local onAugref   = false;
    local onOutfit   = false;
    local onArms     = false;
    local onPops     = false;
    local onJewel    = false;

    if (imgui.BeginTabBar('##dwquest_tabs')) then
        if (imgui.BeginTabItem('Board##dwquest_tab_board')) then
            if (state.synced) then
                boardPanel();
            else
                imgui.TextDisabled('Waiting for the board...');
            end

            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Exchange##dwquest_tab_shop')) then
            onExchange = true;

            exchangePanel();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Augments##dwquest_tab_augref')) then
            onAugref = true;

            augrefPanel();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Outfitter##dwquest_tab_outfit')) then
            onOutfit = true;

            outfitterPanel();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('ArmsDealer##dwquest_tab_arms')) then
            onArms = true;

            armsdealerPanel();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Pop-Items##dwquest_tab_pops')) then
            onPops = true;

            popitemsPanel();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Jeweler##dwquest_tab_jewel')) then
            onJewel = true;

            jewelerPanel();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    -- Inside the pcall, and last: the syncs are the one thing here that can
    -- queue a line, and a throw in them must cost the window rather than the
    -- present handler that draws every other addon after us.
    checkRotation(state.now);
    needBoard(state.now);

    if (onExchange) then
        checkShopRotation(state.now);
        needShop(state.now);
    end

    -- The reference tab's [today] markers ride the same storefront read and
    -- the same rotation clock as the Exchange -- same tracker key, so
    -- whichever tab asks first answers for both.
    if (onAugref) then
        checkShopRotation(state.now);
        askOnce('augments', '!dwu augments', state.now);
    end

    if (onOutfit) then
        needOutfit(state.now);
    end

    if (onArms) then
        needArms(state.now);
    end

    if (onPops) then
        needPops(state.now);
    end

    if (onJewel) then
        needJewel(state.now);
    end
end

--[[
* The render pass: pcall'd body, Begin/End and theme push/pop outside it so
* both stacks stay balanced; an error closes the window once, loudly, and the
* typed commands remain as the fallback.
--]]
ashita.events.register('d3d_present', 'dwquest_present', function ()
    -- Read once per frame. Two reads of the clock inside one frame would let
    -- a countdown and the bar beside it disagree, and the offline harness's
    -- clock strides deliberately to make that visible.
    state.now = os.clock();

    -- A write that was never answered must not hold the card hostage. Nothing
    -- was charged, nothing is re-sent: Refresh shows where the contract
    -- actually stands.
    if (writePending ~= nil and (state.now - writePending.at) > WRITE_TIMEOUT) then
        writePending    = nil;
        state.status    = 'No answer from the server. Nothing was re-sent -- Refresh shows where you stand.';
        state.statusBad = true;
    end

    pumpQueue(state.now);

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 560, 520 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Drift Board##dwquest', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwquest'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwquest'):append(chat.message('Window closed. Everything it does also works as !drift commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening asks `hello`, which is both the board read and
* the handshake that arms the post-kill ping for the session -- the one verb
* only the addon sends (dwu_protocol.md).
--]]
local function openWindow()
    state.open[1]   = true;
    state.reported  = false;
    state.status    = state.synced and '' or 'Loading...';
    state.statusBad = false;
    state.viewBand  = nil;

    refresh('hello');
end

local function toggleWindow()
    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end

--[[
* Watch what the player sends. Bare `!drift` (and ui/window/gui) toggles the
* window and never leaves the client; every other !drift line passes through
* and marks our state stale, because a typed accept changes the board under
* the window. Any other outgoing line stamps the throttle -- the client's rate
* limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwquest_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!drift' or lower == '!drift ui' or lower == '!drift window' or lower == '!drift gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwu') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 6) == '!drift') then
        refresh(boardVerb());
    end
end);

ashita.events.register('command', 'dwquest_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Quests`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwquest' and first ~= '/quests') then
        return;
    end

    e.blocked = true;

    --[[
    * `/quests rewards [on|off]` -- the switch on the reward reroute, and the
    * only subcommand this addon has.
    *
    * Anything else after /quests still opens the window rather than erroring:
    * the command has always taken its arguments as noise and a player who
    * typed a typo wanted the board. A bare `rewards` reports and toggles,
    * which is what a switch with no argument means everywhere else in the
    * suite.
    --]]
    if (#args >= 2 and args[2]:lower() == 'rewards') then
        local want = nil;

        if (#args >= 3) then
            local arg = args[3]:lower();

            if (arg == 'on' or arg == 'true' or arg == '1') then
                want = true;
            elseif (arg == 'off' or arg == 'false' or arg == '0') then
                want = false;
            end
        end

        if (want == nil) then
            want = (config.rewards == false);
        end

        config.rewards = want;
        pcall(settings.save);

        if (want) then
            print(chat.header('dwquest'):append(chat.message('Fields of Valor, Grounds of Valor and Records of Eminence reward lines are moved out of the battle log.')));
        else
            print(chat.header('dwquest'):append(chat.message('Reward lines are left where the client puts them. `/quests rewards on` puts them back here.')));
        end

        return;
    end

    -- `/quests feed [on|off]` -- the switch on the kill feed, same shape as
    -- `rewards` above: a bare `feed` reports and toggles.
    if (#args >= 2 and args[2]:lower() == 'feed') then
        local want = nil;

        if (#args >= 3) then
            local arg = args[3]:lower();

            if (arg == 'on' or arg == 'true' or arg == '1') then
                want = true;
            elseif (arg == 'off' or arg == 'false' or arg == '0') then
                want = false;
            end
        end

        if (want == nil) then
            want = (config.feed == false);
        end

        config.feed = want;
        pcall(settings.save);

        if (want) then
            print(chat.header('dwquest'):append(chat.message('Kill, gil, experience, limit and capacity lines are colour-coded and filed under chat (Window 2 on the stock log config).')));
        else
            print(chat.header('dwquest'):append(chat.message('The kill feed is off; those lines stay in the battle log. `/quests feed on` moves them back.')));
        end

        return;
    end

    toggleWindow();
end);

ashita.events.register('load', 'dwquest_load', function ()
    print(chat.header('dwquest'):append(chat.message('/quests opens the Drift Board and the Drift Exchange. Everything it does also works typed as !drift commands.')));
    print(chat.header('dwquest'):append(chat.message('Fields of Valor, Grounds of Valor and Records of Eminence reward lines are printed here instead of the battle log. `/quests rewards off` stops that.')));
    print(chat.header('dwquest'):append(chat.message('Kills, gil, experience, limit and capacity lines are colour-coded and filed under chat -- Window 2 on the stock log config. `/quests feed off` stops that.')));
end);

--[[
* THE NOTICE REROUTE. The one thing in this file that touches a line the player
* did not ask this window for.
*
* A tagged line (see NOTICE_TAG above) is blocked and re-emitted through
* print(), which is the only way anything here can decide WHICH chat log a
* sentence lands in -- the server has no such lever, and every DriftwoodXI
* module prints on the same channel as the battle log's system messages.
*
* IT WORKS WITH THE WINDOW SHUT AND WITH THE SESSION UNARMED, which is the
* point. The addon only sends `!dwu hello` -- the verb that arms the post-kill
* ping -- once the player has opened the window, so most sessions are unarmed
* and every notice in them comes from the server rather than from the ping
* handler above. Those are precisely the sessions the player was losing lines
* in, and a reroute that needed arming would have missed all of them.
*
* THREE GUARDS, EACH FOR A DIFFERENT WAY THIS COULD MISBEHAVE:
*
*   e.blocked   -- dwecho installs first and blocks this addon's own command
*                  echoes. A line somebody already took is not ours to re-print.
*   e.injected  -- our own print() re-enters text_in. Stripping the tag before
*                  re-emitting already breaks the loop (the new line cannot
*                  match), but a guard that does not depend on getting the
*                  strip right is cheaper than the incident.
*   the strip   -- what goes back out carries no tag, for the reason above.
*
* The non-printable strip is dwecho's, for dwecho's reason: the line arrives
* with the packet's padding and any colour bytes still on it, and a match
* against raw bytes is a match that works until the day it does not.
*
* IT READS `message_modified`, NOT `message`. Ashita hands a text_in handler
* both: the line as it arrived, and the line as it will be DRAWN once every
* handler ahead of this one has had it. They are the same string until an addon
* that runs first rewrites one -- and the Ashita bundle ships several that do
* (customcolors recolours SYSTEM_3, changecall rewrites call tags), so this is
* the ordinary case rather than the exotic one. Re-emitting `message` would
* quietly undo their work, because what we put back is what the player reads.
* `message` is the fallback for the same reason dwecho matches on it: a field
* that is not there must not throw inside a chat handler.
*
* (Server SYSTEM_3 does reach text_in -- customcolors.lua matches it by mode
* 121, and NS_SAY by 9. The TAGGED branch deliberately does NOT gate on the
* mode: the tag is already a far narrower match than any mode is, and a mode
* test would be one more thing to be wrong on the day a notice is sent some
* other way -- printToArea's server-wide contract line being the obvious
* candidate. Missing a notice is the failure that matters here; re-routing a
* stray line is not.
*
* The UNTAGGED reward branch below is the exception, and it earned it: it has
* no tag to be narrow with, so it matches plain English a player can type, and
* one of those phrases opens a burst. See PLAYER_CHAT_MODE_MAX above -- the
* exclusion is a refusal list rather than an allow list precisely so this
* paragraph's rule still holds everywhere else.)
--]]
ashita.events.register('text_in', 'dwquest_text_in', function (e)
    if (e.blocked or e.injected) then
        return;
    end

    local raw = e.message_modified or e.message;

    if (raw == nil) then
        return;
    end

    local line = plainText(raw);
    local at   = line:find(NOTICE_TAG, 1, true);

    if (at == nil) then
        -- Not one of ours to re-print, but it may still be a payout the client
        -- drew from its own dat files (see THE REWARD REROUTE above). That
        -- line is moved WHOLE: there is no tag on it to strip, and rewriting a
        -- sentence the client wrote is how a reroute becomes a rewrite.
        -- BUT NOT OFF A LINE SOMEBODY TYPED. See PLAYER_CHAT_MODE_MAX: this
        -- branch matches plain English, one phrase of which opens a burst, so
        -- a player-chat mode must never be tested against it.
        -- ABSENT IS NOT PLAYER CHAT. Only a mode actually present refuses --
        -- an event without one still reroutes, because this is a refusal list
        -- and missing a notice is the failure that matters (see the header).
        local mode = e.mode_modified or e.mode;
        local low  = mode ~= nil and bit.band(mode, 0xFF) or nil;

        -- NPC DIALOGUE REFUSES TOO. 150 and 151 are the client's NPC-speech
        -- modes (the bundled timestamp addon special-cases exactly those), and
        -- an RoE or Field Manual NPC can say "Records of Eminence:" in
        -- dialogue -- which this branch would block out of the conversation,
        -- re-print under our header, AND treat as a burst anchor that drags
        -- the next exp line out of the battle log. Same defect the player-chat
        -- band was excluded for, one band up. Still a refusal list: only what
        -- is KNOWN to carry speech is named.
        if (low ~= nil and (low <= PLAYER_CHAT_MODE_MAX or low == 150 or low == 151)) then
            return;
        end

        local trimmed = line:gsub('^%s+', ''):gsub('%s+$', '');

        if (trimmed == '') then
            return;
        end

        -- The PATTERN, not a yes/no: it is also what says what colour the line
        -- is printed in. Asking twice would be two copies of the same match.
        local took = isRewardLine(trimmed, os.clock());

        if (took ~= nil) then
            e.blocked = true;
            print(chat.header('dwquest'):append(chat.color1(tintFor(took), trimmed)));
            return;
        end

        -- THE KILL FEED (see FEED_LINES above). Reached only when the reward
        -- reroute left the line alone, so a payout's own gil and exp still
        -- arrive grouped under the completion notice rather than split across
        -- two windows. No block, no print: the line is re-moded into the chat
        -- group (Window 2 on the stock config) and re-written as its cleaned
        -- text in the family's colour. Allow-list polarity, both halves: an
        -- event with no mode, or a mode that is not the pattern's own battle
        -- mode, is refused -- moving somebody else's line out of the battle
        -- log is this feature's harmful failure, not missing one.
        if (config.feed ~= false and low ~= nil) then
            for _, pattern in ipairs(FEED_LINES) do
                if (FEED_MODES[pattern] == low and trimmed:find(pattern) ~= nil) then
                    -- KEEP A LEADING CLOCK SOMEBODY ELSE PUT THERE. plainText
                    -- strips the bundled timestamp addon's stamp (it has to --
                    -- the stamp would otherwise sit inside our colour and a
                    -- two-line message wears two of them), but this branch
                    -- REWRITES rather than re-prints, so nothing puts the
                    -- stamp back the way the reward reroute's print() does.
                    -- Take it off the RAW line, with its own colour bytes, and
                    -- re-attach it in front: the clock stays the timestamp
                    -- addon's colour and the sentence gets the feed's.
                    -- (`timestamp` is not a default addon here, so this is the
                    -- narrow case -- and it is the case where the loss would
                    -- show up on feed lines only, which reads as a bug.)
                    local stamp = raw:match('^(\30.%[%d%d?:%d%d:%d%d%]\30.%s*)')
                               or raw:match('^(%[%d%d?:%d%d:%d%d%]%s*)')
                               or '';

                    e.mode_modified    = bit.bor(bit.band(mode, 0xFFFFFF00), FEED_WINDOW_MODE);
                    e.message_modified = stamp .. chat.color1(FEED_TINTS[pattern] or 106, trimmed);
                    break;
                end
            end
        end

        return;
    end

    -- THE TRIM IS ON THE REMAINDER, NOT ON THE LINE, and the order is the
    -- whole of it. Trimming first would eat the tag's own trailing space, so a
    -- line that is nothing BUT a tag would stop matching -- and a guard that
    -- cannot be reached is not a guard, it is a comment that looks like one.
    -- Trim what is left instead, and refuse when that is nothing: blocking a
    -- bare tag would swallow a line and put an empty one back.
    local said = line:sub(at + #NOTICE_TAG):gsub('%s+$', '');

    if (said == '') then
        return;
    end

    e.blocked = true;

    print(chat.header('dwquest'):append(chat.message(said)));
end);

--[[
* A login is a new character and a new account view; a zone line is a good
* moment to catch up on kills the ping may have missed. Re-sync either way --
* but only once the server has spoken this session (an automatic line against
* a dead verb is the player saying it in public).
*
* The re-ask is `hello`, not `board`: the ping arming is a local var on the
* character the server was talking to, and this is exactly the event after
* which it may no longer be there.
--]]
ashita.events.register('packet_in', 'dwquest_zonein', function (e)
    if (e.id == 0x000A) then
        state.synced      = false;
        state.offers      = { };
        state.actives     = { };
        state.activeOrder = { };
        state.balance     = nil;
        state.clockAt     = nil;
        state.status      = 'Loading...';
        state.statusBad   = false;

        -- A new zone may be a new character; the band look belongs to the
        -- session it was clicked in.
        state.viewBand   = nil;
        state.playerBand = nil;

        -- A write cannot survive the zone line it was in flight across: the
        -- answer, if there was one, went to a session that is gone.
        writePending = nil;

        -- NEITHER CAN A QUOTE. It was priced against an item in a state this
        -- window can no longer vouch for, and the server would refuse it on
        -- the stamp anyway -- so the button goes rather than the refusal.
        shop.synced = false;
        shop.item   = nil;
        shop.slots  = { };
        shop.quote  = nil;

        -- The Pop-Items shelf is static stock like the Outfitter's, but its
        -- h| purse and its quote are BAG state -- and a new zone may be a new
        -- character with a different bag. Re-read on the next look.
        pop.synced        = false;
        pop.quote         = nil;
        pop.hundreds      = nil;
        pop.types         = nil;
        requested['pops'] = nil;

        invalidateGear();

        if (state.serverSpoke) then
            refresh('hello');
        end
    end
end);
