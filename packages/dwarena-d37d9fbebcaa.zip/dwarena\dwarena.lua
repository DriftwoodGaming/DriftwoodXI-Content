--[[
* DriftwoodXI -- dwarena
*
* The Gauntlet in a window: which of Qu'bia Arena's three battlegrounds are
* running and for how long, one button that warps your whole party or
* alliance in (up to eighteen seats, alt-trusts welcome inside), and one
* that takes you back to the tile you left. Waves rise every minute, one
* level higher each floor from 101 to 150; every floor cleared pays its
* number in Burst Tokens -- the Weapon Burst currency on the Drift Board --
* plus experience and capacity points. Dying costs nothing.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited
* whole). It holds no data of its own: occupancy arrives as `a|` records
* and live runs as `r|` records, and every button is a real typed command
* (`!dwz enter` reaches exactly the dispatch `!arena enter` reaches). The
* server gates entry -- the whole raid refusal battery, re-checked
* server-side -- and this window can never do anything a player cannot.
*
* TURN IT OFF AND NOTHING IS LOST. `!arena` does all of it typed, and
* /port or !home leave the Gauntlet from inside exactly like the button.
--]]

addon.name    = 'dwarena';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.0';
addon.desc    = 'The DriftwoodXI Gauntlet: wave survival for the whole alliance, floors 1 to 50.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line.
local DATA_SENDER = '_DWZDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

local state = T{
    open      = T{ false },

    -- Occupancy (a|) and the live runs (r|), COMMITTED ON z| from pending
    -- copies so a half-arrived reply can never half-fill the window.
    areas     = nil,        -- { busy1, busy2, busy3 } as booleans
    runs      = {},         -- { [area] = seconds since the run began }
    syncedAt  = nil,        -- os.clock() the last status landed, for the tickers

    pendingAreas = nil,
    pendingRuns  = nil,

    inbound   = nil,        -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame

    -- The answer clock, per read (the dwfame shape): one retry after five
    -- seconds, then the silent latch -- an unknown ! command falls through to
    -- PUBLIC /say on a server without dwz.lua, and the latch contains that.
    requested    = nil,     -- { at, tries }
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until the
    -- zone line re-probes it (a map restart is also a login).
    refused   = false,
};

--[[
* Outbound: `!dwz` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat and
* answers a burst with "A command error occurred" before the server sees it.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    -- Duplicates collapse: a double-clicked Enter must reach the server
    -- once. There is exactly one write on this wire and it is idempotent
    -- server-side anyway (a pending entry refuses a second one).
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- Held, not dropped, while the client is zoning (dwecho's canSend).
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local function askStatus()
    if (state.refused or state.serverSilent) then
        return;
    end

    state.requested = { at = os.clock(), tries = 1 };

    issue('!dwz status');
end

-- The retry pass, from the render loop. The clock never ages while the
-- client is zoning: a held queue is not an unanswered server.
local function checkAnswers()
    local asked = state.requested;

    if (asked == nil or not echo.canSend()) then
        return;
    end

    if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
        return;
    end

    if (asked.tries >= ANSWER_TRIES) then
        state.requested    = nil;
        state.serverSilent = true;
        state.status       = 'No answer from the server. Is DriftwoodXI up to date?';
        state.statusBad    = true;

        return;
    end

    asked.at    = os.clock();
    asked.tries = asked.tries + 1;

    issue('!dwz status');
end

--[[
* Record parsing. Records are accepted only between a `d|` and its `z|`;
* anything unrecognised falls off the chain rather than being an error,
* which is what lets the server grow record kinds without breaking this
* addon (dwz protocol, client discipline 3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            print(chat.header('dwarena'):append(chat.error(string.format(
                'server protocol %d, addon expects %d. Update dwarena through the launcher.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope answers the outstanding ask and clears
        -- a silent latch earned against a server since updated.
        state.requested    = nil;
        state.serverSilent = false;

        state.inbound = parts[3];

        if (state.inbound == 'status') then
            state.pendingAreas = { false, false, false };
            state.pendingRuns  = {};
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwarena'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    -- a| -- the three areas, busy flags in area order.
    if (kind == 'a' and state.pendingAreas ~= nil) then
        for area = 1, 3 do
            state.pendingAreas[area] = (tonumber(parts[area + 1]) or 0) ~= 0;
        end

        return;
    end

    -- r| -- one live run: area, seconds since it began.
    if (kind == 'r' and state.pendingRuns ~= nil) then
        local area = tonumber(parts[2]) or 0;

        if (area >= 1 and area <= 3) then
            state.pendingRuns[area] = tonumber(parts[3]) or 0;
        end

        return;
    end

    -- k| -- the enter acknowledgement; the zone line that follows the warp
    -- re-probes everything, so nothing else needs doing here.
    if (kind == 'k') then
        state.status    = 'The Gauntlet rises.';
        state.statusBad = false;

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        if (closed == 'status' and state.pendingAreas ~= nil) then
            state.areas        = state.pendingAreas;
            state.runs         = state.pendingRuns or {};
            state.syncedAt     = os.clock();
            state.pendingAreas = nil;
            state.pendingRuns  = nil;
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwarena_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        -- Blocked before parsing: a malformed record must not leak into the
        -- chat log as noise.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwarena'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line invalidates the whole picture -- entering, leaving and
    -- being evicted are all zone changes -- and re-probes both latches:
    -- 0x000A is also a login, and the server on the far side of a map
    -- restart may be the updated one.
    if (e.id == 0x000A) then
        state.requested    = nil;
        state.serverSilent = false;
        state.refused      = false;
        state.areas        = nil;
        state.runs         = {};
        state.syncedAt     = nil;
    end
end);

--[[
* Rendering.
--]]
local function clockText(seconds)
    return string.format('%d:%02d', math.floor(seconds / 60), math.floor(seconds) % 60);
end

local function renderWindow()
    if (imgui.Button('Refresh##dwz_refresh')) then
        askStatus();
    end

    imgui.SameLine();

    if (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server.');
    elseif (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwarena through the launcher.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or state.requested ~= nil) then
        imgui.TextDisabled('asking...');
    else
        imgui.TextDisabled('Floor cleared = tokens earned.');
    end

    imgui.Separator();

    imgui.TextWrapped('A trio of foes rises every minute, one level higher each floor, 101 to 150. '
        .. 'Every floor cleared pays its number in Burst Tokens -- spend them with Drift Coins on '
        .. 'Weapon Burst augments in the Drift Board Exchange. Dying costs no experience. '
        .. 'The whole party or alliance enters together, up to eighteen seats; alt-trusts can be '
        .. 'summoned inside.');

    imgui.Separator();

    -- The three arenas. Times tick locally off the last sync -- the server
    -- is asked once, not per frame.
    if (state.areas == nil) then
        imgui.TextDisabled('Waiting for the arena board...');
    else
        local drift = state.syncedAt ~= nil and (os.clock() - state.syncedAt) or 0;

        for area = 1, 3 do
            if (state.areas[area]) then
                local since = (state.runs[area] or 0) + drift;

                imgui.TextColored(theme.colors.warn, string.format('Arena %d', area));
                imgui.SameLine();
                imgui.Text(string.format('running -- %s in', clockText(since)));
            else
                imgui.TextColored(theme.colors.ok, string.format('Arena %d', area));
                imgui.SameLine();
                imgui.TextDisabled('free');
            end
        end
    end

    imgui.Separator();

    if (imgui.Button('Enter the Gauntlet##dwz_enter')) then
        -- Debounced BEYOND the queue's dupe-collapse, which only sees lines
        -- still waiting: a second click after the first line pumped would
        -- otherwise send a second enter (harmless server-side -- the pending
        -- paperwork refuses it -- but a needless refusal in the player's
        -- chat). Found by this addon's own harness on its first run.
        if (os.clock() - (state.enterAt or 0) > 5.0) then
            state.enterAt = os.clock();

            issue('!dwz enter');

            state.status    = 'Entering...';
            state.statusBad = false;
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Warps your whole party or alliance in together. The server checks everyone first.');
    end

    imgui.SameLine();

    if (imgui.Button('Leave##dwz_leave')) then
        issue('!dwz leave');
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Back to the tile you entered from. /port and !home work from inside too.');
    end
end

ashita.events.register('d3d_present', 'dwarena_present', function ()
    -- Before the visibility check: a request issued a moment before the
    -- window was closed still has to reach the server.
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    -- The board is asked for LAZILY -- the first frame the window is
    -- actually open -- so a player who never opens it never handshakes.
    if (state.areas == nil and state.requested == nil
            and not state.serverSilent and not state.refused) then
        askStatus();
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 430, 330 }, ImGuiCond_FirstUseEver);

    -- NoDocking: the suite-wide flag (fused dw windows survive imgui.ini).
    local visible = imgui.Begin('DriftwoodXI Gauntlet##dwarena', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwarena'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwarena'):append(chat.message('Window closed. Everything it shows also works typed as !arena.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

-- Anything the player types counts against the client's chat rate limit, so
-- a queued line behind a typed one waits its interval instead of racing it.
ashita.events.register('packet_out', 'dwarena_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dwz') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwarena_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed (the suite-wide
    -- /Warehouse lesson).
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/arena' and first ~= '/dwarena') then
        return;
    end

    e.blocked = true;

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwarena_load', function ()
    print(chat.header('dwarena'):append(chat.message('/arena opens the Gauntlet board. Everything it shows also works typed as !arena.')));
end);
