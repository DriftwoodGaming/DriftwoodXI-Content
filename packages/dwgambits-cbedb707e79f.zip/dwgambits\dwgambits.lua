--[[
* DriftwoodXI -- dwgambits
*
* The visual editor for the player gambit system: your squad's rule sets as a
* window instead of a grammar. Pick who a rule watches, when it fires and what
* it does from dropdowns, reorder by priority, keep your posture honest, and
* assign the result to any character on the account -- summoned or at home.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no vocabulary of its own and no way to write a rule the typed
* command surface would refuse. Every read is a `!dwg` line and every write is
* a `!dwg` line -- the same dispatch, parser, validator and C++ store that
* `!squad rules ...` reaches (documentation/dwg_protocol.md is the contract).
* The ownership check, the caps and the whitelist all live server-side and run
* identically whichever way the command arrived, which is what makes shipping
* a UI safe at all: a bug in here cannot save anything the server would have
* refused a typed player.
*
* EVERY DROPDOWN IS BUILT FROM THE WIRE. The vocabulary -- targets, conditions,
* action kinds, pickers, posture options, the caps -- arrives as `v|` records
* at startup and nothing vocabulary-shaped is hardcoded here (ground rule 4).
* The whitelist can grow server-side and this file does not change. What IS
* known locally is the client's own DAT resources (spell and ability names,
* exactly as dwbags uses item names) and the typed tier's *grammar* words --
* grammar is how a renderer speaks, not what it is allowed to say.
*
* HOW SAVING WORKS, AND WHY. The editor edits a local copy of one rule set and
* nothing touches the server until Save. Save diffs the local document against
* the server's copy and issues the smallest `del` / `add` / `move` / `posture`
* sequence that makes the two agree -- each step is a complete, valid command,
* so killing the client mid-save leaves a shorter document, never a corrupt
* one. Mutating commands are sent strictly one at a time, are NEVER retried
* automatically (a lost `add` re-sent is a duplicated rule), and any `e|` from
* the server aborts the rest of the plan on the spot.
*
* TURN IT OFF AND NOTHING IS LOST. `!squad rules` does everything this window
* does, typed, and `!squad menu` covers assignment as client dialogs. This is
* faster; it is not required.
*
* UPGRADE HINTS (1.1) render the `h|` records `!dwg hints` answers: a compact
* strip under each summoned member, and what-it-would-take detail on the hover
* of a greyed inert rule. Both are display only -- every sentence arrives
* finished from the server, and a server too old to know the verb is detected
* once and never asked again, so deployment order cannot matter.
*
* WEAPON-SKILL PICKS (1.2, 2026-08-06) render the posture's two appended
* fields: up to four ordered weapon-skill picks (first is the opener; names
* from the client DATs -- weapon skills are ability ids with NO offset) and
* the tphold amount the amount-reading TP triggers use. Both diff into the
* same `!dwg posture` grammar every other posture field uses, and both parse
* as APPENDED s|/v|h fields, so an older server simply never sends them and
* the block renders as it did in 1.1.
*
* THE TOGGLE ROUND (1.4, 2026-08-18, player requests). Two checkboxes, one
* latch. Each rule row grows an On switch (`!dwg toggle <set> <n> on|off` --
* the rule stays in the document at its ordinal, the member just ignores it)
* and the posture strip grows Allow AoE WS (`!dwg posture <set> aoews`,
* keeping area weapon skills out of the member's TP spending). Both diff
* through the save plan like everything else -- toggles by FINAL ordinal,
* after the moves. The latch is the s| record's appended `aoews` field: a
* server that sends it speaks the whole round, a server that does not gets
* neither checkbox nor either command, so deployment order cannot matter.
*
* SONG BURST (1.5, 2026-08-23, player request). The posture strip grows Allow
* Song Burst (`!dwg posture <set> songburst on|off`): off keeps bard songs out
* of the member's burst-matching pick -- threnodies and requiems outrank every
* nuke by spell id, so a bard-subbed member kept "bursting" with songs -- while
* rules that name a song on purpose still fire. The aoews shape exactly: its
* own appended s| field is its own latch, so deployment order cannot matter.
*
* THE FIRST HARNESS (1.10.0, 2026-09-06). Until this round nothing in the tree
* had ever executed a line of this file: harness_dwsuite read it statically and
* harness_squad_vocab asserted the whitelist it renders, and every fix in the
* eight rounds above was verified by reading. `tools/dwgambits/
* harness_dwgambits.py` now loads the REAL vocabulary out of
* squad_rule_vocab.lua, emits the real `v|` records, loads this file under
* Ashita and ImGui stubs that COUNT Begin/End pairs, and drives packets, frames
* and clicks. It found, among others, four things no amount of reading had: a
* topic answer (`!dwg vocab conditions`, which the paragraph below recommends
* typing) rebuilt the whitelist out of one topic and left the editor with no
* action kinds at all, permanently; a second condition dropped after its and/or
* was chosen left the and/or behind, and the store keeps 0 there, so the
* document never diffed clean again and every Save answered "Saved with
* differences" forever; switching the Do dropdown away from a canned pairing
* left the pairing's own condition -- which the whitelist does not list -- in
* the When column and made the whole document unsaveable; and the protocol
* mismatch banner was never taken down by a server that spoke the protocol.
* NOTHING IN THIS FILE IS EXERCISED BY ANYTHING ELSE. Add a check when you add
* a control.
*
* THE SONG AUDIENCE (1.11.0, 2026-09-07, player request: "make BRD only cast
* Ballad on the caster group and Minuet/March on melee"). A party-song rule
* grows a [Sings to] dropdown beside its action, holding one checkbox per job
* group the server names in `v|o|audience` -- the client invents none of them,
* ground rule 4 -- and the choice diffs into `!dwg audience <set> <n> <keys>`
* by FINAL ordinal, the toggle pass's shape exactly.
*
* TWO LATCHES, because the two halves fail differently. The GROUP LIST comes
* from `v|o|audience`: no records, no control, so a server that never heard of
* the round offers nothing. WHICH RULES may have one comes from the r| record's
* appended `aud` field: `-` means this rule is not a party song the song layer
* keeps up, and the strip is not drawn for it. The server decides both, which
* is what keeps a checkbox from ever appearing on a rule that would ignore it
* -- and it means a song rule the player has only just added shows its
* checkboxes on the next read-back rather than instantly, because until the
* server has seen the rule it has not said whether it qualifies.
*
* A CANNED PAIRING MAY TAKE AN ARGUMENT (1.12, 2026-09-11). `v|n` grew a
* tenth field, the argument domain, and the two pet pairings carry
* `p:avatar`: "Summon and keep the pet out" and "Release the pet" each draw a
* second dropdown listing the eighteen summons plus "Their best avatar",
* which is the shipped id 0 and the way back out. The pairing's argument is
* the rule's ordinary actionid, serialised as `<key>:<pick>` and read back
* from the same field -- so a set written on an older client, which sends the
* bare key, keeps meaning exactly what it meant. The old hard-coded "no
* argument" is why the petout note promised a named avatar this window could
* not offer, which is the report this round answers.
*
* THE ELEMENTAL ROTATION (1.13, 2026-09-11, player report: "I can't seem to
* get my BLM to cast only tier V spells -- he will cast Stone V, Stone IV,
* Stone III instead of going Stone V, Water V"). The server's vocabulary
* grows a `rotate` selector under Cast a spell, and this file learns the one
* word its serialiser needs for it (GRAMMAR_WORDS). Everything else is
* wire-built as always: the dropdown, the label and the rule row need no code
* here. A 1.12 client OFFERS the row -- the dropdown is the wire's -- and
* then refuses the Save in words, which is the right failure and the reason
* the selector carries no argument: a picker-argument one would have fallen
* through to the `-family` default and been read by the server as an
* ordinary best-of-family rule, silently.
*
* THE SONG REFRESH THRESHOLD (1.14, 2026-09-11, the round that fixed a bard
* report about stacking). A party-song row grows a [Refresh] drag beside
* [Sings to]: how many seconds of the song may be left when the bard starts it
* over, zero meaning "wait until it is gone", which is what every rule did
* before. Two latches again, and the same two shapes: the ceiling is the v|h
* caps record's appended `songRefreshMax`, and WHICH rules may have one is the
* r| record's appended `ref` field -- `-` for every rule the song layer does
* not keep up, so the box never appears on a row that would ignore it. The
* choice diffs into `!dwg refresh <set> <n> <seconds|off>` by FINAL ordinal,
* the audience pass's shape exactly.
*
* THE TWO SONG CELLS ACTUALLY STICK (1.14.2, 2026-09-13, reports from Barthal
* and Captain Tightpants: "it won't save and reverts back to default 0", and
* "if I change the Bard rules rows then the changes are rejected by the
* server"). Both were this window, not the store, and both were the same
* omission twice: `audience` and `refresh` are mutating verbs and answer with
* the whole document like every other one, but neither was in DOC_VERBS, so
* the proof the save had landed was thrown away and the post-save residue
* reported a refusal the server never made. The three halves of the fix are
* DOC_VERBS/VERDICT_VERBS (below), buildSavePlan's append mirror (a re-added
* row carries the server's DEFAULTS for both cells, not the local values), and
* the settling pass in finishPlanStep (the two cells of a re-added row can
* only be typed once the read-back says the row still qualifies).
*
* THE PRE-ToAU ROUND (1.15.0, 2026-09-18, an audit of all six thousand lines
* before Blue Mage, Corsair and Puppetmaster reach players). Nine client
* defects and one missing feature, each pinned by the harness:
*
*   - An edited rule the server REFUSES no longer costs the rule it replaced.
*     The save plan used to send every `del` before any `add`, so turning a
*     working potion rule into a shape the validator refuses deleted the
*     potion rule and then stopped. Appends now go FIRST whenever the set has
*     room for them (buildSavePlan says why the ordinals still work), and the
*     refusal names the rule it was about. A FULL set (the 48-rule cap), which
*     has no room to add first, sends each edited row as one `replace` -- the
*     server's one-write edit (the final fix pass) -- so there too a refusal
*     costs nothing.
*   - A fresh row's who follows its Do and When until the player picks one:
*     the server's appended `aim` / `subject` tags move it to The enemy for a
*     ranged attack, a rotation, a burst-matching nuke, a weapon skill or a
*     monster condition, which the server refuses on the old default, Self.
*   - Refresh re-fetches the vocabulary, and so does a login/zone line --
*     additive growth never moves the version number, so nothing else could
*     ever tell this window the whitelist had grown.
*   - The job-ability list stops at server id 511: everything above is a
*     blood pact or a Ready move, which `ja:` saves and nothing ever presses.
*   - Duplicate DAT names (Sleepga, five weapon skills) are offered once, at
*     the lowest id, which is the one the server's name index keeps.
*   - A set name is trimmed and single-spaced before it is used, because the
*     server stores it that way and adoption compares the two.
*   - `party use` resets the inert verdicts it re-describes, and five more
*     verbs make the hint strip stale.
*   - The share-code paste box holds the longest legal code (it held 511
*     characters; a 48-rule set with two conditions runs to 680).
*   - Right-click a rule's number to move it to the top or the bottom;
*     Revert asks once more before it throws unsaved work away.
*   - "Lists for": the spell dropdown is cut to the job and level of the
*     member it is for, a Blue Mage's SET spells come first and the unset ones
*     are greyed, a Corsair's usable rolls come first and the rest are greyed
*     -- read off two appended `c|` fields and a new `u|` record
*     (dwg_protocol.md), so an older server simply draws the lists unmarked.
--]]

addon.name    = 'dwgambits';
addon.author  = 'DriftwoodXI';
addon.version = '1.15.0';
addon.desc    = 'Visual gambit rule editor for the DriftwoodXI squad system.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. This is
-- _DWGDATA and never _DWDATA: dwbags owns that one, and two addons contending
-- to block the same sender is a load-order bug where the loser eats the
-- winner's records (dwg_protocol.md says so at length).
local DATA_SENDER = '_DWGDATA';

-- Protocol version the server announces in every `d|` record.
local PROTOCOL = 1;

-- The store's sentinel for "no second condition", mirrored so the local
-- document and the wire agree about what absent looks like.
local NO_CONDITION = 255;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Client ability DAT ids sit 512 above the server's job ability ids -- the
-- same offset every Ashita addon that names a JA uses (timers, luashitacast).
-- The server speaks its own ids on the wire; the client's resources answer to
-- these.
local ABILITY_CLIENT_OFFSET = 512;

-- SERVER job-ability ids from here up are pet commands, not job abilities
-- (1.15.0): every one of them is a blood pact or a Ready move. `ja:` saves
-- them -- xi.jobAbility has 257 such ids -- and then the member's own ability
-- walk stops below ABILITY_HEALING_RUBY (squad_actions.cpp forEachKnownAbility),
-- so a rule naming one is inert forever. Blood pacts have their own selector;
-- the list simply stops short of the block, the TRUST_SPELL_FIRST precedent.
local PET_COMMAND_FIRST = 512;

-- Client DAT facts the "Lists for" marks read (1.15.0). Blue magic is spell
-- skill 43 -- the number Ashita's own blucheck tests -- and every Corsair roll
-- shares the Phantom Roll recast timer, 193, which is how the ability list
-- tells a roll from the rest of the kit without a job field IAbility lacks.
local BLUE_MAGIC_SKILL  = 43;
local ROLL_RECAST_TIMER = 193;

-- The client's trust-call spells occupy this id block. They are real spells
-- with real names, so an unfiltered dropdown would offer "Kupipi" as a thing
-- to cast; the server would take it and report it inert, which is polite but
-- useless. Everything else questionable is left in -- the server's refusals
-- are the authority and they are sentences, not errors.
local TRUST_SPELL_FIRST = 896;
local TRUST_SPELL_LAST  = 1023;

-- All of these live in dwtheme and follow the launcher's Appearance theme.
local COLOR_ERROR  = theme.colors.err;
local COLOR_OK     = theme.colors.ok;
local COLOR_DIRTY  = theme.colors.warn;
local COLOR_INERT  = theme.colors.inert;
local COLOR_BADGE  = theme.colors.badge;
local COLOR_HINT   = theme.colors.hint;

local state = T{
    open      = T{ false },

    -- World state, replaced wholesale by the response that owns it (never
    -- merged across responses of the same verb), so a stale row cannot
    -- survive a refresh.
    members     = {},       -- [charid] = live squad member (c| records)
    memberOrder = {},       -- charids in arrival order
    sets        = {},       -- [setid] = owned set header (s| records)
    assigns     = {},       -- ['charid:job'] = assignment (a| records)
    presets     = {},       -- array of shipped sets (p| records)
    loadouts    = {},       -- array of party presets (y| records)

    -- The last share code exported, as its parts (x| records), and which set it
    -- was for. Kept beside the set rather than in it: a code is a snapshot of a
    -- set at a moment, and one held against a set that has since been edited
    -- would be a wrong code shown with confidence.
    codes       = {},
    codeTotal   = 0,        -- the x| record's own part count, so a gap is visible
    codesFor    = nil,

    -- Per-member inert verdicts (k| records): [charid] = { setid, presetid,
    -- list = { [ordinal] = reason } }. Reset whenever a verdict-bearing
    -- response re-describes that member, so a stale reason cannot outlive the
    -- install it was true of.
    verdicts  = {},

    -- Per-member upgrade hints (h| records, `!dwg hints`): [charid] = array of
    -- { kind, ordinal, distance, command, text } in the server's own rank
    -- order. Replaced wholesale by every hints response -- the addon always
    -- asks for the whole squad, so an absent member genuinely has none.
    hints     = {},

    selected  = nil,        -- charid highlighted in the left pane
    assignTo  = nil,        -- 'all' or a character name, for the Assign controls

    -- The envelope being read. Records are buffered between `d|` and `z|` and
    -- processed as one response, so a torn or foreign line can never half-fill
    -- the UI -- and so records can be read with their context (a k| belongs to
    -- the c| or s| above it).
    inbound   = nil,
    buffer    = {},

    -- Bumped by every envelope that lands. The window's derived views --
    -- the owned-set list, the Assign dropdown, the at-home list, the per-job
    -- assignment counts -- hang off it rather than being rebuilt per frame.
    rev       = 0,

    status    = 'Fetching...',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame

    -- True between a `d|` whose version this addon cannot read and the next
    -- one it can. It exists because "Update dwgambits" is the ONE status line
    -- nothing else overwrites -- every other sentence is replaced by the next
    -- m|/e| or the next button press, and a mismatch answers with neither.
    protocolBad = false,
};

--[[
* The vocabulary.
*
* `vocab` is nil until every page has arrived, and the editor renders a
* fetching notice rather than a window with empty dropdowns. `vocabWork`
* accumulates pages; a `g|` announcing a different version than the one being
* staged (or the one in use) throws the stale copy away and starts over --
* a client that caches the whitelist has to notice a server that changed it.
--]]
local vocab     = nil;
local vocabWork = nil;

--[[
* THE COPY IN USE CAN BE OUT OF DATE WITHOUT ITS VERSION MOVING (1.15.0).
*
* Additive growth -- a new status effect, a new picker entry, a new selector --
* is exactly what ground rule 4 promises needs no addon release, and it never
* bumps the vocabulary version (squad_rule_vocab.lua says so), so the version
* test below can only ever notice a MEANING change. Until this round nothing
* else re-asked either: needVocab stopped at "vocab is not nil", so a client
* whose Ashita stayed up across a map restart kept the old whitelist until the
* game was restarted -- every new entry missing from every dropdown, and a set
* that used one rendering "#321" and refusing Save-as with "the vocabulary no
* longer lists", which reads as the server having removed something.
*
* Set by Refresh and by a login/zone line (a map restart logs everyone out),
* never by an ordinary window open: a full fetch is a dozen chat lines. The
* copy in use STAYS in use while the replacement pages arrive -- no dropdown
* ever blanks -- and a complete build clears the flag.
--]]
local vocabStale = false;

local function normalise(text)
    return (string.gsub(string.lower(text or ''), '[^%a%d]', ''));
end

local function split(text, sep)
    local parts = {};

    for piece in string.gmatch((text or '') .. sep, '([^' .. sep .. ']*)' .. sep) do
        table.insert(parts, piece);
    end

    return parts;
end

-- `-` | `action` | `n:<min>:<max>:<unit>` | `p:<picker>`, per the protocol's
-- argument-domain field.
local function parseDomain(text)
    if (text == nil or text == '' or text == '-') then
        return { kind = 'none' };
    end

    if (text == 'action') then
        return { kind = 'action' };
    end

    local min, max, unit = string.match(text, '^n:(%-?%d+):(%-?%d+):(.*)$');

    if (min ~= nil) then
        return { kind = 'number', min = tonumber(min), max = tonumber(max), unit = unit };
    end

    local picker = string.match(text, '^p:(.+)$');

    if (picker ~= nil) then
        return { kind = 'pick', picker = picker };
    end

    return { kind = 'none' };
end

--[[
* Build the working vocabulary out of one complete set of pages.
*
* Everything the UI renders hangs off this table: the dropdown lists in wire
* order, the by-id indexes the parser of incoming rules needs, and the derived
* "action kind" list -- one entry per (reaction, selector) pair the server
* says is legal, plus one per canned pairing. A canned pairing is ONE choice,
* never a free combination; where it carries its own condition the When
* column locks, because the samba ladder without its "no samba up" half
* re-dances every pass (the v|n record is explicit about this).
--]]
local function buildVocab(work)
    local built = {
        version    = work.version,
        caps       = { rulesPerSet = 24, setsPerAccount = 16, conditionsPerRule = 2, nameLength = 24, retryMax = 300, installPerMember = 40,
                       tpSkillPicks = 4, tpHoldMin = 1000, tpHoldMax = 3000 },
        targets    = {},  targetById    = {},
        logic      = {},  logicById     = {},
        conditions = {},  conditionById = {},
        reactions  = {},  reactionById  = {},
        selectors  = {},  selectorById  = {}, selectorByKey = {},
        canned     = {},  cannedByPair  = {},
        posture    = { swing = {}, stance = {}, tpwhen = {}, tpuse = {} },
        pickers    = {},  pickerById    = {},
        familyKeys = {},
        kinds      = {},  kindByPair    = {},
    };

    for page = 1, work.pages do
        for _, parts in ipairs(work.rows[page] or {}) do
            local sub = parts[2];

            --[[
            * A KEY THE PACKET CUT OFF IS NOT A KEY (2026-09-06).
            *
            * Three of the branches below index a table BY the key they read,
            * and `t[nil] = v` is "table index is nil" -- thrown inside
            * handleRecord's pcall, which turns one truncated record into a
            * whole vocabulary that never assembles and a "bad record" line in
            * the player's chat log. The others store the key and hand it to
            * table.concat when a rule is serialised, which throws inside the
            * render instead.
            *
            * This is a live shape rather than a hypothetical one: the 150-byte
            * Mes buffer truncates in SILENCE, and squad_rules_cmd.lua's own
            * boot check reports vocabulary records over the 130-byte budget --
            * four of them today. A record whose key did not survive describes
            * nothing this window can offer, so it is skipped whole.
            --]]
            local key = (sub == 'n' or sub == 'o' or sub == 'p') and parts[3] or parts[4];

            if (sub ~= 'h' and key == nil) then
                sub = nil;
            end

            if (sub == 'h') then
                built.caps = {
                    rulesPerSet       = tonumber(parts[4]) or 24,
                    setsPerAccount    = tonumber(parts[5]) or 16,
                    conditionsPerRule = tonumber(parts[6]) or 2,
                    nameLength        = tonumber(parts[7]) or 24,
                    retryMax          = tonumber(parts[8]) or 300,
                    installPerMember  = tonumber(parts[9]) or 40,

                    -- Appended 2026-08-06 (dwg_protocol.md): absent from an
                    -- older server, so the defaults are that server's truth.
                    tpSkillPicks      = tonumber(parts[10]) or 4,
                    tpHoldMin         = tonumber(parts[11]) or 1000,
                    tpHoldMax         = tonumber(parts[12]) or 3000,

                    -- Appended 2026-09-11 with the song refresh threshold.
                    songRefreshMax    = tonumber(parts[13]) or 120,
                };
            elseif (sub == 't') then
                local entry = { id = tonumber(parts[3]) or 0, key = parts[4], label = parts[5], note = parts[6] };

                table.insert(built.targets, entry);
                built.targetById[entry.id] = entry;
            elseif (sub == 'l') then
                local entry = { id = tonumber(parts[3]) or 0, key = parts[4], label = parts[5] };

                table.insert(built.logic, entry);
                built.logicById[entry.id] = entry;
            elseif (sub == 'c') then
                local entry = {
                    id    = tonumber(parts[3]) or 0,
                    key   = parts[4],
                    arg   = parseDomain(parts[5]),
                    solo  = parts[6] == '1',
                    label = parts[7],
                    note  = parts[8],

                    -- APPENDED (1.15.0, the final fix pass): `enemy` for a
                    -- condition that reads the MONSTER. An older server sends
                    -- nothing and nothing moves the who, which is how it was.
                    subject = parts[9] == 'enemy',
                };

                table.insert(built.conditions, entry);
                built.conditionById[entry.id] = entry;
            elseif (sub == 'r') then
                -- `aim` APPENDED (1.15.0, the final fix pass): `enemy` where the
                -- action can only land on a monster; see settleAutoWho.
                local entry = { id = tonumber(parts[3]) or 0, key = parts[4], selectors = split(parts[5], ','), label = parts[6],
                                aim = parts[7] == 'enemy' };

                table.insert(built.reactions, entry);
                built.reactionById[entry.id] = entry;
            elseif (sub == 's') then
                local entry = { id = tonumber(parts[3]) or 0, key = parts[4], arg = parseDomain(parts[5]), label = parts[6],
                                aim = parts[7] == 'enemy' };

                table.insert(built.selectors, entry);
                built.selectorById[entry.id]   = entry;
                built.selectorByKey[entry.key] = entry;
            elseif (sub == 'n') then
                local entry = {
                    key       = parts[3],
                    reaction  = tonumber(parts[4]) or 0,
                    selector  = tonumber(parts[5]) or 0,
                    actionid  = tonumber(parts[6]) or 0,
                    condition = tonumber(parts[7]) or NO_CONDITION,
                    label     = parts[8],
                    note      = parts[9],

                    -- APPENDED 2026-09-11: the argument domain a pairing
                    -- takes, `-` for the three that take none. A server that
                    -- predates the field sends eight fields and parseDomain
                    -- answers "none" for the nil, which is the behaviour this
                    -- addon hard-coded until today.
                    arg       = parseDomain(parts[10]),
                };

                table.insert(built.canned, entry);
                built.cannedByPair[entry.reaction] = built.cannedByPair[entry.reaction] or {};
                built.cannedByPair[entry.reaction][entry.selector] = entry;
            elseif (sub == 'o') then
                local field = key;
                local entry = { id = tonumber(parts[4]) or 0, key = parts[5], label = parts[6], note = parts[7] };

                built.posture[field] = built.posture[field] or {};
                table.insert(built.posture[field], entry);
            elseif (sub == 'p') then
                local name = key;

                built.pickers[name]  = built.pickers[name] or {};
                built.pickerById[name] = built.pickerById[name] or {};

                for _, packed in ipairs(split(parts[4], ',')) do
                    local bits = split(packed, ':');

                    if (#bits >= 3) then
                        local entry = { key = bits[1], id = tonumber(bits[2]) or 0, label = bits[3] };

                        table.insert(built.pickers[name], entry);
                        built.pickerById[name][entry.id] = entry;
                    end
                end
            end
        end
    end

    for _, entry in ipairs(built.pickers.spellfamily or {}) do
        built.familyKeys[entry.key] = true;
    end

    -- The conditions that may share a rule with another. Built here rather
    -- than in the row that needs it: the second-condition dropdown filtered
    -- the whole condition list on every frame of every row that had one.
    built.nonSolo = {};

    for _, entry in ipairs(built.conditions) do
        if (not entry.solo) then
            table.insert(built.nonSolo, entry);
        end
    end

    -- The action-kind list: what the [Do ▾] dropdown offers. Derived, never
    -- listed: a reaction that gains a selector server-side gains a dropdown
    -- entry here with no addon release.
    for _, reaction in ipairs(built.reactions) do
        for _, selKey in ipairs(reaction.selectors) do
            local selector = built.selectorByKey[selKey];

            if (selector ~= nil) then
                local kind = {
                    reaction    = reaction.id,
                    selector    = selector.id,
                    reactionKey = reaction.key,
                    selectorKey = selector.key,
                    arg         = selector.arg,
                    label       = #reaction.selectors == 1 and reaction.label
                        or string.format('%s: %s', reaction.label, selector.label),

                    -- Lands only on a monster (the selector's tag, else the
                    -- reaction's -- validate's own order). 1.15.0.
                    aim         = selector.aim or reaction.aim,
                };

                -- The ranged attack ignores its selector argument entirely --
                -- the engine hands the target straight to RangedAttack and the
                -- server's own `shoot` sugar stores 0 -- so offering an
                -- argument here would be offering a knob wired to nothing.
                if (reaction.key == 'shoot') then
                    kind.arg = { kind = 'none' };
                end

                table.insert(built.kinds, kind);
                built.kindByPair[reaction.id] = built.kindByPair[reaction.id] or {};
                built.kindByPair[reaction.id][selector.id] = kind;
            end
        end
    end

    for _, canned in ipairs(built.canned) do
        local kind = {
            reaction = canned.reaction,
            selector = canned.selector,
            actionid = canned.actionid,
            canned   = canned,
            pinned   = canned.condition ~= NO_CONDITION and canned.condition or nil,

            -- FROM THE RECORD SINCE 1.12 (2026-09-11, player report: "'Summon
            -- and keep pet out' says ... you can name one. But there's no
            -- dropdown to name one"). This was hard-coded to "none", so the
            -- pairing's own note promised an avatar the window had no way to
            -- offer. A pairing with an argument draws the same second
            -- dropdown every picker-argument action draws, and the id it
            -- stores is a plain actionid the server reads back.
            arg      = canned.arg or { kind = 'none' },
            label    = canned.label,

            -- The pairing's own note, on the kind itself (1.15.0), so the
            -- OPEN Do list explains an entry while the player is choosing --
            -- pickCombo hovers `entry.note`, and until now only the closed
            -- combo, after the choice was made, ever showed it.
            note     = canned.note,
        };

        table.insert(built.kinds, kind);
        built.kindByPair[canned.reaction] = built.kindByPair[canned.reaction] or {};
        built.kindByPair[canned.reaction][canned.selector] = kind;
    end

    -- AN INCOMPLETE ANSWER IS REFUSED (2026-09-06), and that is not paranoia.
    -- `!dwg vocab conditions` is a line this addon never sends and a player
    -- may well type -- the header at the top of this file recommends typing
    -- `!dwg` to see what the window is actually being told -- and the server
    -- answers a TOPIC with a complete, correct `g|1|1|<version>` envelope
    -- carrying that topic alone. Staged and adopted, that left an editor with
    -- no targets, no reactions and no action kinds, every rule reading "an
    -- action the vocabulary no longer lists" and every Save refusing -- and it
    -- never repaired itself, because needVocab stops asking the moment `vocab`
    -- is not nil. A whitelist missing any of its load-bearing lists is not a
    -- whitelist: say so, and let the caller restart the fetch with the copy in
    -- use (if there is one) untouched.
    if (#built.targets == 0 or #built.logic == 0 or #built.conditions == 0
            or #built.reactions == 0 or #built.selectors == 0) then
        return false;
    end

    vocab      = built;
    vocabWork  = nil;
    vocabStale = false;

    return true;
end

--[[
* Client resources: spell and ability names out of the DATs.
*
* The server does not send action names and does not need to -- this addon is
* inside the client, which already knows the name of every spell and ability
* it can render a menu for. That is the dwbags rule (item names, same
* reasoning) and it is what keeps an r| record inside the line budget.
*
* Built once, on first use: the resource manager is not guaranteed while the
* addon is loading from the launcher's boot script, and nothing here is
* needed before the first frame that draws an action dropdown.
--]]
local actionLists = { spell = nil, ability = nil };

local function playerCanLearn(spell)
    -- LevelRequired holds one entry per job; a spell no job learns between 1
    -- and 99 is monster-only and just noise in a dropdown. Guarded because the
    -- SDK table's shape is the client's business, not ours: on any surprise,
    -- include the spell and let the server be the judge.
    local ok, usable = pcall(function()
        local levels = spell.LevelRequired;

        for job = 1, 24 do
            local level = levels[job];

            if (type(level) == 'number' and level >= 1 and level <= 99) then
                return true;
            end
        end

        return false;
    end);

    if (not ok) then
        return true;
    end

    return usable;
end

-- One field of a resource object, or nil. The SDK types are the client's
-- business: a field an older Ashita build does not expose must cost the mark
-- it feeds, never the whole list.
local function resourceField(object, field)
    local ok, value = pcall(function () return object[field]; end);

    return ok and value or nil;
end

-- A spell's per-job level requirement, as [jobId] = level for jobs 1..22.
--
-- THE INDEX IS jobId + 1 (verified 2026-09-18). LevelRequired is the DAT's
-- int16 array of 24, one per job starting at job 0 ("none"), and Ashita hands
-- it to Lua 1-based -- so Blue Mage (job 16) is [17], which is exactly how
-- Ashita's own blucheck addon reads it (`spell.LevelRequired[16 + 1]`). A
-- job that cannot learn the spell holds -1; a job-point gift holds its point
-- cost (550, 1200), which playerCanLearn above keeps out of the lists.
local function spellLevels(spell)
    local ok, levels = pcall(function ()
        local raw = spell.LevelRequired;
        local out = {};

        for job = 1, #JOB_NAMES do
            local level = raw[job + 1];

            if (type(level) == 'number') then
                out[job] = level;
            end
        end

        return out;
    end);

    return ok and levels or nil;
end

--[[
* ONE ENTRY PER NAME, AT THE LOWEST ID (1.15.0).
*
* The client DATs name some things twice: Sleepga and Sleepga II are spells 273
* and 363, 274 and 364 (the second pair unlearnable, but every job-level test
* passes them), and Netherspikes, Carnal Nightmare, Aegis Schism, Dancing
* Chains and Barbed Crescent are weapon skills 241-245 AND 249-253. A rule
* leaves this window as a NAME, and the server's name index keeps the lowest
* id on a collision (squad_rules_cmd.lua actionNames) -- so picking the second
* row stored an id the server never writes back, the read-back never matched,
* and every Save reported "the server refused part of it" and re-installed the
* member, forever. The walk is ascending and a name is claimed by its FIRST
* id whether or not that id makes the list, the server's rule exactly.
--]]
local function claimName(seen, name)
    local key = normalise(name);

    if (key == '' or seen[key]) then
        return false;
    end

    seen[key] = true;

    return true;
end

local function buildActionLists()
    local resources = AshitaCore:GetResourceManager();
    local spells    = {};
    local abilities = {};
    local seen      = {};

    for id = 1, 1299 do
        if (id < TRUST_SPELL_FIRST or id > TRUST_SPELL_LAST) then
            local spell = resources:GetSpellById(id);

            if (spell ~= nil) then
                local name = spell.Name[1];

                if (name ~= nil and #name > 1 and name ~= '.' and claimName(seen, name) and playerCanLearn(spell)) then
                    table.insert(spells, {
                        id     = id,
                        label  = name,
                        levels = spellLevels(spell),
                        skill  = resourceField(spell, 'Skill'),
                    });
                end
            end
        end
    end

    -- Job abilities live at DAT ids 512..1535; the value stored in a rule is
    -- the server id, so it is the DAT id minus the offset. The walk stops
    -- short of PET_COMMAND_FIRST (1.15.0): past it is nothing a `ja:` rule
    -- can ever press.
    seen = {};

    for clientId = ABILITY_CLIENT_OFFSET + 1, ABILITY_CLIENT_OFFSET + PET_COMMAND_FIRST - 1 do
        local ability = resources:GetAbilityById(clientId);

        if (ability ~= nil) then
            local name = ability.Name[1];

            if (name ~= nil and #name > 1 and name ~= '.' and claimName(seen, name)) then
                table.insert(abilities, {
                    id     = clientId - ABILITY_CLIENT_OFFSET,
                    label  = name,
                    recast = resourceField(ability, 'RecastTimerId'),
                });
            end
        end
    end

    -- Weapon skills are DAT ability ids 1..255 with NO offset -- the server's
    -- weapon-skill id IS the client ability id (dwg_protocol.md, the s|
    -- tpskills field). The whole list, not this character's: a posture stores
    -- intent, and the set being edited may be for an alt with a different
    -- weapon in its hands. The server reports what a member cannot use.
    --
    -- The DAT's list rather than the wire's curated `weaponskill` picker, on
    -- purpose: `posture tpskill` resolves a name against the WHOLE weapon-skill
    -- enum, and the picker is the rule tier's shorter list -- building the
    -- posture slots from it would take away picks the server accepts.
    local weaponskills = {};

    seen = {};

    for clientId = 1, 255 do
        local ability = resources:GetAbilityById(clientId);

        if (ability ~= nil) then
            local name = ability.Name[1];

            if (name ~= nil and #name > 1 and name ~= '.' and claimName(seen, name)) then
                table.insert(weaponskills, { id = clientId, label = name });
            end
        end
    end

    table.sort(spells, function (a, b) return a.label < b.label; end);
    table.sort(abilities, function (a, b) return a.label < b.label; end);
    table.sort(weaponskills, function (a, b) return a.label < b.label; end);

    actionLists.spell   = spells;
    actionLists.ability = abilities;
    actionLists.ws      = weaponskills;
end

-- Three attempts, and then it stops (2026-09-06). Building the lists is 2,577
-- resource-manager reads and about thirteen hundred pcalls -- a one-frame cost
-- when it works, and the addon making the client unplayable if it throws and is
-- retried on every call of every frame. Three rather than one because the
-- comment above is right that the resource manager is not guaranteed on the
-- frame the addon loads; three frames later it is, or it never will be, and an
-- empty dropdown with the server's own refusals behind it is the honest
-- outcome.
local ACTION_LIST_TRIES = 3;
local actionListTries   = 0;

local function actionList(resource)
    if (actionLists[resource] == nil and actionListTries < ACTION_LIST_TRIES) then
        actionListTries = actionListTries + 1;

        local ok, err = pcall(buildActionLists);

        if (not ok) then
            if (actionListTries >= ACTION_LIST_TRIES) then
                print(chat.header('dwgambits'):append(chat.error(
                    'the client would not give up its spell and ability names: ' .. tostring(err))));
                print(chat.header('dwgambits'):append(chat.message(
                    'The action dropdowns will be empty. Everything else still works, and !squad rules names actions by hand.')));
            end

            return {};
        end
    end

    return actionLists[resource] or {};
end

--[[
* The weapon-skill dropdown, with its clear entry in front of it.
*
* BUILT ONCE (2026-09-06). The posture strip drew this list per SLOT per FRAME
* -- four fresh copies of a two-hundred-entry table, sixty times a second, for a
* list whose contents come out of the client's own DATs and cannot change while
* the game is running. Not cached until the resource manager has actually
* answered, because an empty list cached here would be an empty dropdown for
* the rest of the session.
--]]
local wsPickList = nil;

local function weaponSkillPicks()
    if (wsPickList ~= nil) then
        return wsPickList;
    end

    local list  = actionList('ws');
    local built = { { id = 0, label = '(any)' } };

    for _, entry in ipairs(list) do
        table.insert(built, entry);
    end

    if (#list > 0) then
        wsPickList = built;
    end

    return built;
end

--[[
* Resource names, memoised.
*
* ASKED ONCE PER ID (2026-09-06). The editor resolves the current pick's name
* for every rule row on every frame, and the posture strip does the same for
* every weapon-skill slot -- a GetSpellById or GetAbilityById into the client's
* DATs each time, forty-eight of them a frame on a full set, for names that
* cannot change while the game is running. `false` is the cached "this client
* has no name for that id", which is a real answer and has to be remembered
* like any other.
--]]
local nameCache = { spell = {}, ability = {}, ws = {} };

-- Emptied by forget() -- Refresh, `/gambits refresh`, a `!squad` line, a zone.
-- The cache remembers "this client has no name for that id" as firmly as it
-- remembers a name, which is right for a DAT gap and wrong for a moment when
-- the resource manager was not answering at all, so the player is given the
-- same lever they already use for everything else stale.
local function forgetNames()
    nameCache = { spell = {}, ability = {}, ws = {} };
end

local function cachedName(bucket, id, lookup)
    local store = nameCache[bucket];
    local hit   = store[id];

    if (hit == nil) then
        hit = lookup(id) or false;

        store[id] = hit;
    end

    if (hit == false) then
        return nil;
    end

    return hit;
end

--[[
* THE RESOURCE MANAGER IS NOT GUARANTEED, AND THESE RUN INSIDE THE RENDER.
*
* buildActionLists says so in as many words and is pcall'd for it; these three
* were not, and they are the ones a rule row calls -- one per row per frame,
* from inside d3d_present. `AshitaCore:GetResourceManager()` answering nil is
* an index of a nil value, which the render pcall turns into a closed window
* and a sentence, once, for the rest of the session. Guarded here instead: the
* name is simply unknown, the row draws "(pick)" or "#id", and the server's own
* refusals go on being the authority about what a member can use. (2026-09-06.)
--]]
local function readSpellName(id)
    local ok, name = pcall(function ()
        local spell = AshitaCore:GetResourceManager():GetSpellById(id);

        return spell ~= nil and spell.Name[1] or nil;
    end);

    if (ok and type(name) == 'string' and #name > 0) then
        return name;
    end

    return nil;
end

local function readAbilityName(clientId)
    local ok, name = pcall(function ()
        local ability = AshitaCore:GetResourceManager():GetAbilityById(clientId);

        return ability ~= nil and ability.Name[1] or nil;
    end);

    if (ok and type(name) == 'string' and #name > 0) then
        return name;
    end

    return nil;
end

local function readAbilityNameOffset(serverId)
    return readAbilityName(serverId + ABILITY_CLIENT_OFFSET);
end

local function spellName(id)
    return cachedName('spell', id, readSpellName);
end

local function abilityName(serverId)
    return cachedName('ability', serverId, readAbilityNameOffset);
end

-- Weapon skills: client ability ids with no offset (see buildActionLists).
-- The nil-returning form is what the save plan needs: a pick this client
-- cannot name must be refused with a sentence rather than sent as `#123`.
local function weaponSkillLookup(id)
    return cachedName('ws', id, readAbilityName);
end

local function weaponSkillName(id)
    return weaponSkillLookup(id) or string.format('#%d', id);
end

--[[
* Labels for whatever a rule holds, including things the vocabulary no longer
* lists -- a set saved before an entry narrowed still has to render as
* SOMETHING the player can select and delete, so unknown ids show as #n
* rather than taking the row down.
--]]
local function kindOf(rule)
    if (vocab == nil) then
        return nil;
    end

    local byReaction = vocab.kindByPair[rule.reaction];

    return byReaction ~= nil and byReaction[rule.selector] or nil;
end

--[[
* A FRESH ROW'S WHO FOLLOWS WHAT IT DOES (1.15.0, the final fix pass).
*
* A new row starts on the whitelist's first target, Self, and a player who
* then only changes the Do dropdown to "Ranged attack", "Elemental rotation",
* "Burst-matching nuke" or a weapon skill -- or the When to "Burst window
* open" -- wrote a rule the server refuses at Save ("... lands on the monster --
* make the who The enemy"), about a who they never chose. So while the who is
* still the one the row was CREATED with (`autoWho`, cleared the moment the
* player picks one), it is settled from the server's own tags: `aim` on the
* action kind (v|r / v|s, appended this round) and `subject` on a condition
* (v|c), and it becomes "The enemy" -- the one who every aim and subject set
* accepts. Otherwise it goes back to the first target. Conditions count only
* for the kinds the gambit ENGINE reads them for: a pact, a summon, an item or
* a weapon-skill row answers its own conditions against a subject its own
* block fixes, and the server does not judge the who there
* (squad_rules.lua engineReadsConditions). Nothing here ever moves a who the
* player chose, or one a saved row came back with.
--]]
local ENGINE_REACTIONS = { spell = true, ability = true, shoot = true };
local DIVERTED_SELECTORS = { avatar = true, bloodpact = true };

local function settleAutoWho(rule)
    if (not rule.autoWho or vocab == nil) then
        return;
    end

    local kind       = kindOf(rule);
    local wantsEnemy = kind ~= nil and kind.aim == true;

    if (not wantsEnemy and kind ~= nil and kind.canned == nil
            and ENGINE_REACTIONS[kind.reactionKey] and not DIVERTED_SELECTORS[kind.selectorKey]) then
        for _, cond in ipairs({ rule.cond1, rule.cond2 }) do
            local entry = cond ~= NO_CONDITION and vocab.conditionById[cond] or nil;

            if (entry ~= nil and entry.subject) then
                wantsEnemy = true;
            end
        end
    end

    local chosen = vocab.targets[1];

    if (wantsEnemy) then
        for _, target in ipairs(vocab.targets) do
            if (target.key == 'enemy') then
                chosen = target;
            end
        end
    end

    if (chosen ~= nil) then
        rule.target = chosen.id;
    end
end

local function conditionText(cond, arg)
    if (cond == NO_CONDITION) then
        return '';
    end

    local entry = vocab ~= nil and vocab.conditionById[cond] or nil;

    if (entry == nil) then
        return string.format('condition #%d', cond);
    end

    if (entry.arg.kind == 'number') then
        return string.format('%s %d%s', entry.label, arg, entry.arg.unit or '');
    end

    if (entry.arg.kind == 'pick') then
        local pick = vocab.pickerById[entry.arg.picker];
        local hit  = pick ~= nil and pick[arg] or nil;

        return string.format('%s: %s', entry.label, hit ~= nil and hit.label or ('#' .. arg));
    end

    return entry.label;
end

local function actionText(rule)
    local kind = kindOf(rule);

    if (kind == nil) then
        return string.format('engine %d/%d/%d', rule.reaction, rule.selector, rule.actionid);
    end

    if (kind.canned ~= nil) then
        -- Say which one when the pairing named one (1.12): a row reading
        -- "Release the pet" next to a row that only ever releases Garuda is
        -- the difference between a set that converges and one that does not.
        if (kind.arg.kind == 'pick' and rule.actionid ~= kind.canned.actionid) then
            local pick = vocab.pickerById[kind.arg.picker];
            local hit  = pick ~= nil and pick[rule.actionid] or nil;

            if (hit ~= nil) then
                return string.format('%s (%s)', kind.label, hit.label);
            end
        end

        return kind.label;
    end

    if (kind.arg.kind == 'pick') then
        local pick = vocab.pickerById[kind.arg.picker];
        local hit  = pick ~= nil and pick[rule.actionid] or nil;

        return string.format('Best %s', hit ~= nil and hit.label or ('#' .. rule.actionid));
    end

    if (kind.arg.kind == 'action') then
        -- Split for the same reason as the serialiser: the collapsed form
        -- renders a nameless ability id as some unrelated spell.
        local name;

        if (kind.reactionKey == 'ability') then
            name = abilityName(rule.actionid);
        else
            name = spellName(rule.actionid);
        end

        return name or string.format('%s #%d', kind.reactionKey, rule.actionid);
    end

    return kind.label;
end

--[[
* Sending: one command per interval, queued, with the reads deduplicated.
*
* THE CLIENT RATE-LIMITS OUTGOING CHAT AND A !dwg COMMAND IS A CHAT LINE.
* Fire two in one frame and the second is answered "A command error occurred"
* before the server ever sees it -- the dwbags lesson, paid for once, applied
* from day one here.
*
* Two queues, and the difference is the whole design. Reads collapse
* duplicates because asking twice for the same thing is never useful. The
* PLAN queue -- the mutating command sequence a Save builds -- must never
* collapse anything (two identical `add` lines can be two identical rules the
* player genuinely wants) and must run strictly one command at a time, each
* step waiting for its answer, because a plan step landing out of order would
* edit the wrong ordinal.
--]]
local SEND_INTERVAL = 1.2;

local readQueue = {};
local plan      = {};       -- pending mutating commands, in order
local planWait  = nil;      -- { verb, command, at, info } -- the step in flight
local planTotal = 0;        -- for the progress line
local lastSend  = 0;

-- What each pending plan step is ABOUT, in lockstep with `plan` (1.15.0): an
-- `add` carries { ordinal = n }, the editor row it writes, so a refusal can
-- say "Rule 4: ..." instead of a bare sentence about a rule the player has to
-- work out for themselves. `false` for every other step. Kept beside the plan
-- rather than in it because the plan's entries are the lines themselves, and
-- every reader of `plan` counts or sends strings.
local planInfo  = {};

-- Forward declaration. pumpQueue's watchdog (below) has to clear the save
-- latch, and the editor table it lives on is not defined until much further
-- down; without this the watchdog would close over a global.
local editor;

-- Answered-question tracking, keyed by envelope verb. A PLAIN TABLE, NOT T{}:
-- string keys on a T{} resolve through the sugar metatable and `find` is both
-- a table method and a plausible verb name -- the collision that cost dwbags
-- a round.
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

-- True once the server has said it has no hints verb -- one from before
-- UPGRADE_HINTS_PLAN.md Phase 2. Detected off the dispatch's own unknown-verb
-- sentence (frozen on any server old enough to say it) and reset on every
-- login/zone line, so a server upgraded underneath a running client gets
-- asked again at the next zone rather than never.
local hintsUnsupported = false;

-- The same latch for the party-preset verb (2026-08-16): `party` is additive
-- to protocol 1, so a server from before it answers with the unknown-verb
-- sentence rather than a version mismatch. Latched off that sentence, reset
-- on every login/zone line -- deployment order must not matter either way.
local partyUnsupported = false;

local function forget()
    requested = {};

    -- The resource-name cache goes with it: it is the one other thing this
    -- window remembers that a player pressing Refresh might be trying to
    -- shake loose (see forgetNames).
    forgetNames();
end

-- forget(), and the vocabulary too (1.15.0). Its own function rather than a
-- line in forget(), because forget() also runs on every window open and every
-- `!squad` line the player types, and a full whitelist fetch is a dozen chat
-- lines -- it belongs to the two moments the whitelist can really have grown
-- under a running client: the player asking (Refresh), and a login (a map
-- restart logs everyone out; the zone handler calls this).
local function forgetAll()
    forget();

    if (vocab ~= nil) then
        vocabStale = true;
    end
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

local function issueRead(command)
    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

-- Ask for one verb (optionally about one qualifier -- a set name, a vocab
-- page) at most once, twice if the first ask was never answered. Called from
-- whatever pane needs the data, every frame, so the guard is the entire
-- point.
local function need(verb, qualifier, command)
    local asked = requested[verb];

    if (asked ~= nil and asked.qualifier == qualifier) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested[verb] = { qualifier = qualifier, at = os.clock(), answered = false, tries = 1 };
    end

    issueRead(command);
end

--[[
* True once an ask has been made its full number of times and none of them was
* answered.
*
* SAID WHERE THE PANE IS WAITING, NEVER IN THE STATUS LINE (2026-09-06). Half
* the suite prints a give-up sentence into its shared status line when the
* retries run out, and harness_dwsuite's protocol gate exists because of what
* that does: it replaces the server's own refusal -- the one accurate sentence
* on screen -- with a wrong one about a server that had just answered twice.
* A pane that has nothing to show can say so in its own words, in its own
* space, without touching anything else.
*
* A protocol mismatch retires every ask as answered, so this is false there
* too, which is the point: "Update dwgambits" is the truth and stays.
--]]
local function gaveUp(verb)
    local asked = requested[verb];

    return asked ~= nil and not asked.answered and asked.tries >= ANSWER_TRIES
        and (os.clock() - asked.at) >= ANSWER_TIMEOUT;
end

local function planVerbOf(command)
    return string.match(command, '^!dwg%s+(%S+)') or '?';
end

local function abortPlan(reason)
    if (#plan == 0 and planWait == nil) then
        return;
    end

    plan      = {};
    planInfo  = {};
    planWait  = nil;
    planTotal = 0;

    state.status    = reason;
    state.statusBad = true;
end

--[[
* Undo the identity change a Save-as makes before its `new` is confirmed.
*
* Save-as points the editor at the new name the moment the plan starts, so the
* document the server sends back adopts as "the one on screen". A `new` that
* was refused -- or that was never answered at all -- means that set does not
* exist, and an editor left pointing at the name adopts the PRE-EXISTING set of
* that name on the next read and overwrites it on the next Save. beginSave's
* fallback comment says so at length; this is the undo both paths share.
*
* Returns true when there was something to roll back. The fallback is dropped
* either way: a stale one lets a LATER refused `new` -- from the New button,
* which never set one -- roll the identity back to a set the player has since
* moved away from.
--]]
local function rollbackSaveAs()
    local fallback = editor.saveFallback;

    editor.saveFallback = nil;

    if (fallback == nil) then
        return false;
    end

    editor.name    = fallback.name;
    editor.setid   = fallback.setid;
    editor.shipped = fallback.shipped;
    editor.server  = fallback.server;

    return true;
end

-- Re-read the server's copy of whatever is on screen. `pendingRef` is left nil
-- on purpose: the arriving document then refreshes `editor.server` -- the
-- ground a Save diffs against -- without touching the player's unsaved side.
local function reloadServerCopy()
    if (editor.name == nil or editor.shipped) then
        return;
    end

    requested['show'] = nil;

    need('show', string.lower(editor.name), string.format('!dwg show "%s"', editor.name));
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and both queues are empty in
    -- almost all of them, while echo.canSend() is three calls across the C++
    -- boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it first
    -- spent a hundred and eighty of those a second to decide to do nothing.
    -- A plan step still waiting on its answer keeps the pump running so the
    -- watchdog below can time it out; otherwise an empty queue has no line
    -- to hold or to drop, and the order is free.
    if (#plan == 0 and #readQueue == 0 and planWait == nil) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    -- A plan step that was never answered is NOT re-sent -- re-sending a
    -- mutating command is how a rule gets added twice. The plan dies, the
    -- editor stays dirty, and the reload below shows what actually landed.
    if (planWait ~= nil) then
        if (now - planWait.at > 8.0) then
            local lostNew = planWait.verb == 'new';

            abortPlan('No answer from the server mid-save. Nothing was lost -- press Save to try again.');

            -- AND CLEAR THE SAVE LATCH, exactly as the `e|` refusal path does.
            -- Without this the message above is a lie by omission: Save and
            -- Save as both answer 'A save is already running.' for the rest of
            -- the session, so the button the sentence tells the player to press
            -- is the one this abort just disabled. finishPlanStep cannot rescue
            -- it either -- it returns early on the planWait we just nil'd.
            editor.saving     = false;
            editor.settling   = false;
            editor.pendingRef = nil;

            -- A Save-as whose `new` was never answered leaves the editor
            -- pointed at a set that may not exist (2026-09-06). Rolled back
            -- for the reason the refusal path rolls it back: otherwise the
            -- re-read below adopts the PRE-EXISTING set of that name and the
            -- next Save overwrites it. A lost step that was NOT the `new` only
            -- drops the fallback, which by then is already spent.
            if (lostNew) then
                rollbackSaveAs();
            else
                editor.saveFallback = nil;
            end

            -- AND RE-READ THE SERVER'S COPY (2026-09-06). The sentence above
            -- promises "nothing was lost" and this comment used to promise "the
            -- reload below shows what actually landed" -- there was no reload.
            -- `editor.server` still described the document as it was BEFORE the
            -- lost step, so pressing Save again diffed against a copy the
            -- server no longer had and re-issued every `add` the plan had
            -- already landed, duplicating rules. The `e|` refusal path has
            -- always re-read for exactly this reason.
            reloadServerCopy();
        end

        return;
    end

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#plan > 0) then
        local command = table.remove(plan, 1);
        local info    = table.remove(planInfo, 1);

        planWait = { verb = planVerbOf(command), command = command, at = now, info = info or nil };
        lastSend = now;

        echo.send(command);

        return;
    end

    -- READS ARE FOR THE WINDOW, AND ONLY FOR THE WINDOW (2026-09-06). The pump
    -- runs before the visibility check so a Save issued a moment before closing
    -- still reaches the server -- but a READ has nobody to show its answer to,
    -- and a player who opened the window and closed it again had four `!dwg`
    -- lines still going out over the next five seconds, into a chat throttle
    -- they share with everything they type. Held rather than dropped: a window
    -- closed for one frame must not restart its fetch, and issueRead already
    -- collapses a duplicate against whatever reopening asks for.
    if (#readQueue > 0 and state.open[1]) then
        lastSend = now;

        echo.send(table.remove(readQueue, 1));
    end
end

--[[
* The editor's document.
*
* `doc` is what the player is editing; `server` is the last complete copy the
* server sent of the same set. `touched` -- not a computed diff -- is the
* unsaved-changes flag, because the server copy can legitimately change
* underneath (a `!squad rules` line typed outside the window) and an edit the
* player did not make must never be reported as theirs. Save diffs doc
* against server; Revert copies server over doc.
--]]
editor = {
    name       = nil,       -- the set being edited, as the server spells it
    setid      = 0,
    shipped    = false,     -- true = read-only view of a preset
    doc        = nil,       -- { posture, rules }
    server     = nil,       -- { posture, rules, verdicts }
    touched    = false,
    pendingRef = nil,       -- a `show` is in flight for this name
    saving     = false,

    -- One-shot latch for the settling pass (see finishPlanStep): the two song
    -- cells of a re-added row can only be sent AFTER the server's read-back
    -- says the row still qualifies for them, and that follow-up runs once per
    -- save. Without the latch a server that kept answering with something
    -- else would be asked for ever.
    settling   = false,
    armDelete  = 0,         -- setid the Delete button is armed for (two-click)

    -- Revert's two-click arm (1.15.0). Only a TOUCHED document arms it -- a
    -- clean one has nothing to lose -- and any further edit disarms it, so
    -- "Really revert?" can never throw away an edit made after it was asked.
    armRevert  = false,

    -- True once a `del` of the running save has landed (1.15.0). A refused
    -- `add` after that point is the one refusal that has cost the server a
    -- rule, and the sentence has to say so.
    removedThisSave = false,

    -- Whose job and level the spell and ability lists are cut to (1.15.0):
    -- nil is automatic (listTarget), `'all'` is everything, a number is a
    -- summoned member's charid, `'job:<id>'` is a job at any level.
    listFor    = nil,
};

local function copyRule(rule)
    return {
        target = rule.target, logic = rule.logic,
        cond1 = rule.cond1, arg1 = rule.arg1,
        cond2 = rule.cond2, arg2 = rule.arg2,
        reaction = rule.reaction, selector = rule.selector,
        actionid = rule.actionid, retry = rule.retry,
        gate = rule.gate, srv = rule.srv,

        -- nil on a server that predates the toggle round (1.4); the
        -- checkboxes latch off the s| record's aoews field, not this.
        enabled = rule.enabled,

        -- nil on a server that predates the audience round (1.11), and also
        -- on every rule the server says is not a party song -- the two are
        -- indistinguishable here on purpose, because the answer to both is
        -- "draw nothing and send nothing".
        audience = rule.audience,

        -- The refresh threshold (1.14, 2026-09-11), the same latch and the
        -- same reasoning one field over.
        refresh = rule.refresh,
    };
end

local function copyDocOf(source)
    local rules = {};

    for index, rule in ipairs(source.rules) do
        rules[index] = copyRule(rule);
    end

    local posture = {};

    for key, value in pairs(source.posture) do
        if (type(value) == 'table') then
            -- The pick list. Copied by value: a shared reference would make
            -- every editor reorder silently rewrite the server mirror, and
            -- the save diff would then see nothing to save.
            local list = {};

            for index, entry in ipairs(value) do
                list[index] = entry;
            end

            posture[key] = list;
        else
            posture[key] = value;
        end
    end

    return { posture = posture, rules = rules };
end

--[[
* One string per rule, so "the same rule" is one comparison. Everything the
* store persists is in it; the gate is not, because a gate only ever appears
* on a shipped set and a shipped set is never diffed.
*
* AND `logic` AND `arg2` ONLY COUNT WHEN THERE IS A SECOND CONDITION
* (2026-09-06). The store keeps `logic or 0` and `arg2 or 0` there, and the
* addon omits both from the `add` line for the same reason, so the server's
* read-back of a single-condition rule ALWAYS says 0 for each. A local document
* that still carried what a dropped second condition had left behind therefore
* differed from a server copy that was byte-for-byte what it had just written:
* every Save rewrote the rule, every Save answered "Saved with differences --
* the server refused part of it", and because that branch keeps the document
* dirty the next Save did it again. Forever, until the player pressed Revert.
--]]
local function ruleKey(rule)
    local paired = rule.cond2 ~= NO_CONDITION;
    local logic  = paired and rule.logic or 0;
    local arg2   = paired and rule.arg2 or 0;

    return string.format('%d/%d/%d/%d/%d/%d/%d/%d/%d/%d',
        rule.target, logic, rule.cond1, rule.arg1, rule.cond2, arg2,
        rule.reaction, rule.selector, rule.actionid, rule.retry);
end

local function loadIntoEditor(ref)
    editor.armDelete  = 0;
    editor.armRevert  = false;
    editor.pendingRef = string.match(string.lower(ref), '^preset:(.+)$') or ref;

    state.status    = string.format('Loading %s...', editor.pendingRef);
    state.statusBad = false;

    requested['show'] = nil;
    need('show', string.lower(editor.pendingRef), string.format('!dwg show "%s"', editor.pendingRef));
end

local function adoptDoc(doc)
    editor.name    = doc.name;
    editor.setid   = doc.setid;
    editor.shipped = doc.setid == 0;
    editor.server  = doc;

    for index, rule in ipairs(doc.rules) do
        rule.srv = index;
    end

    if (not editor.touched) then
        editor.doc = copyDocOf(doc);
    end
end

--[[
* Serialisation: a local rule back into the one line a player could type.
*
* This is the renderer constraint made concrete. The addon does not write
* fields to the store; it says `add "Medic" party hplt:40 cure-family` and the
* server's own grammar, whitelist and validator take it from there. The
* condition uses the key:value shape (`hplt:40`, `status:sleep`) because every
* exposed condition accepts it and the comparison sugar is for people. The
* words below are GRAMMAR -- the typed tier's own documented sugar -- keyed by
* wire keys, so a selector the vocabulary drops stops being emitted too.
--]]
local GRAMMAR_WORDS = {
    ['spell:random']    = 'anything',
    ['spell:mbelement'] = 'burst',
    ['shoot:specific']  = 'shoot',

    -- The elemental rotation (1.13, 2026-09-11). A selector with NO argument
    -- on purpose -- the wheel is all six elemental families and the engine
    -- owns its order -- which is also what makes it safe for an OLDER client:
    -- the [Do] dropdown is wire-built, so a 1.12 offers the row, but its
    -- serialiser finds no word here and refuses the Save in words ("an action
    -- shape this addon does not know how to type") instead of quietly
    -- sending something else. A picker-argument selector could not have said
    -- that: it would have fallen through to the `-family` default and the
    -- server would have read it as an ordinary best-of-family rule.
    ['spell:rotate']    = 'rotate',
};

--[[
* The typed tier's action SUGAR -- every word squad_rules_cmd.lua's parseAction
* reads before it looks a name up at all (its ACTION_SUGAR table, mirrored key
* for key and held to it by harness_dwgambits.py).
*
* FOUND BY PUTTING THE CLIENT'S REAL NAMES THROUGH THE REAL PARSER (1.15.0).
* The black-magic spell Burst (212) left this window as the bare word `Burst`,
* which the parser reads as the burst-matching-nuke sugar -- so "Exactly this:
* Burst" saved as "Burst-matching nuke", a different rule, and the read-back
* never matched. A spell whose name IS a sugar word takes the grammar's `1`
* suffix, the same way a tier-one name that is also a family key does.
--]]
local ACTION_SUGAR_WORDS = {
    shoot = true, shot = true, ranged = true, rattack = true,
    burst = true, mb = true, magicburst = true,
    anything = true, whatever = true,
    nuke = true, nukes = true,
    rotate = true, rotation = true, wheel = true,
};

local function conditionToken(cond, arg)
    local entry = vocab.conditionById[cond];

    if (entry == nil) then
        return nil, string.format('a condition (#%d) the vocabulary no longer lists', cond);
    end

    if (entry.arg.kind == 'number') then
        return string.format('%s:%d', entry.key, arg);
    end

    if (entry.arg.kind == 'pick') then
        local pick = vocab.pickerById[entry.arg.picker];
        local hit  = pick ~= nil and pick[arg] or nil;

        if (hit == nil) then
            return nil, string.format('a %s entry (#%d) the vocabulary no longer lists', entry.arg.picker, arg);
        end

        return string.format('%s:%s', entry.key, hit.key);
    end

    return entry.key;
end

local function actionToken(rule)
    local kind = kindOf(rule);

    if (kind == nil) then
        return nil, 'an action the vocabulary no longer lists';
    end

    if (kind.canned ~= nil) then
        -- A pairing that took an argument serialises as `<key>:<pick>` (1.12,
        -- 2026-09-11) -- `petout:garuda`, `petrelease:garuda`. The BARE key
        -- still means the shipped id, which is what every pairing without an
        -- argument sends and what an older client sends for these two, so a
        -- rule that names nobody round-trips exactly as it always did. Gated
        -- by harness_dwsuite's PAIRED_LITERALS against the parser branch in
        -- squad_rules_cmd.lua, the ja:/item:/ws:/avatar: precedent.
        if (kind.arg.kind == 'pick' and rule.actionid ~= kind.canned.actionid) then
            local pick = vocab.pickerById[kind.arg.picker];
            local hit  = pick ~= nil and pick[rule.actionid] or nil;

            if (hit == nil) then
                return nil, string.format('a %s entry the vocabulary no longer lists', kind.arg.picker);
            end

            return kind.canned.key .. ':' .. hit.key;
        end

        return kind.canned.key;
    end

    if (kind.arg.kind == 'pick') then
        local pick = vocab.pickerById[kind.arg.picker];
        local hit  = pick ~= nil and pick[rule.actionid] or nil;

        if (hit == nil) then
            return nil, string.format('a %s entry the vocabulary no longer lists', kind.arg.picker);
        end

        -- An item rule serialises as the explicit `item:` form (2026-08-16)
        -- -- every medicine name is also an ordinary word, so the bare-name
        -- reading stays with spells. Gated by harness_dwsuite's
        -- PAIRED_LITERALS against the parser branch in squad_rules_cmd.lua,
        -- the ja: precedent.
        if (kind.reactionKey == 'item') then
            return 'item:' .. hit.key;
        end

        -- The weapon-skill tier (1.6) needs its own explicit prefix for a
        -- sharper version of the same reason: half the weapon-skill names in
        -- the game are also spell or ability names, and without this branch a
        -- picker-argument rule falls through to the `-family` default below
        -- and the server reads it as a spell family. Gated by
        -- harness_dwsuite's PAIRED_LITERALS against the parser branch.
        if (kind.reactionKey == 'weaponskill') then
            return 'ws:' .. hit.key;
        end

        -- The summoner tier (1.9, 2026-09-02): two more picker-argument
        -- shapes with explicit prefixes, for the same reason as `ws:` --
        -- the `-family` default below would read a pact key as a spell
        -- family and refuse it. `avatar:` rather than the bare spell name
        -- so the server stores the picker's own (reaction, selector) pair
        -- and reads the row back as the same kind. Both gated by
        -- harness_dwsuite's PAIRED_LITERALS against the parser branches.
        if (kind.selectorKey == 'avatar') then
            return 'avatar:' .. hit.key;
        end

        if (kind.selectorKey == 'bloodpact') then
            return 'bp:' .. hit.key;
        end

        -- `-family` IS ONLY EVER A SPELL FAMILY (1.15.0). It used to be the
        -- default for EVERY picker selector this file had no prefix for, so a
        -- selector the server grows tomorrow -- a roll picker, a maneuver
        -- picker -- would have gone out as `samurairoll-family` and come back
        -- as "There is no spell family", or worse, as a best-of-family rule
        -- if the key happened to be a family too: silently the wrong rule,
        -- which is the trap the `rotate` header above describes. An unknown
        -- picker shape now refuses the Save in words, before the wire, the
        -- same way an unknown no-argument shape always has. (The generic
        -- cure is the server naming the word on `v|s` -- see dwg_protocol.md;
        -- it is a server change, so it is not this file's to invent.)
        if (kind.arg.picker ~= 'spellfamily') then
            return nil, 'an action shape this addon does not know how to type -- a newer dwgambits does';
        end

        return hit.key .. '-family';
    end

    if (kind.arg.kind == 'action') then
        -- SPLIT, not the `a and b or c` collapse: when the reaction IS an
        -- ability but abilityName returns nil, that idiom falls through to
        -- spellName and silently borrows an unrelated SPELL's name for an
        -- ability id -- so the refusal below could never be reached for the
        -- case it was written for.
        local name;

        if (kind.reactionKey == 'ability') then
            name = abilityName(rule.actionid);
        else
            name = spellName(rule.actionid);
        end

        if (name == nil) then
            return nil, string.format('a %s id (%d) this client has no name for', kind.reactionKey, rule.actionid);
        end

        -- A tier-one spell whose bare name is also a family key -- Cure,
        -- Stone, Sleep -- would be read as the family ladder, because that is
        -- the documented default reading. The `1` suffix is the grammar's own
        -- way of saying "exactly that one".
        --
        -- And a name that is a sugar word, for the same reason (1.15.0,
        -- ACTION_SUGAR_WORDS): `Burst` alone is the burst-matching nuke.
        if (kind.reactionKey == 'spell' and (vocab.familyKeys[normalise(name)] or ACTION_SUGAR_WORDS[normalise(name)])) then
            name = name .. '1';
        end

        -- EVERY ability rule carries the prefix, not just the names that
        -- happen to collide today. A bare name is resolved as a SPELL first
        -- by the server's grammar, so `Fire II` -- a black-magic spell AND a
        -- Blue Mage ability -- round-tripped an ability rule into a spell
        -- rule, and the Waltzes and Sambas landed on their canned pairings.
        -- Deterministic beats a collision table that drifts with the enums.
        if (kind.reactionKey == 'ability') then
            return 'ja:' .. name;
        end

        return name;
    end

    local word = GRAMMAR_WORDS[kind.reactionKey .. ':' .. kind.selectorKey];

    if (word == nil) then
        return nil, 'an action shape this addon does not know how to type';
    end

    return word;
end

local function serialiseRule(quotedName, rule)
    local action, actionWhy = actionToken(rule);

    if (action == nil) then
        return nil, actionWhy;
    end

    local kind = kindOf(rule);
    local condToken, condWhy;

    if (kind ~= nil and kind.pinned ~= nil) then
        -- The pairing owns its condition, and the grammar's required spelling
        -- for that is the word `always` in the condition slot.
        condToken = 'always';
    else
        condToken, condWhy = conditionToken(rule.cond1, rule.arg1);

        if (condToken == nil) then
            return nil, condWhy;
        end
    end

    local target = vocab.targetById[rule.target];

    if (target == nil) then
        return nil, string.format('a target (#%d) the vocabulary no longer lists', rule.target);
    end

    local parts = { '!dwg add', quotedName, target.key, condToken };

    if (rule.cond2 ~= NO_CONDITION and (kind == nil or kind.pinned == nil)) then
        local logic = vocab.logicById[rule.logic];
        local second, secondWhy = conditionToken(rule.cond2, rule.arg2);

        if (second == nil) then
            return nil, secondWhy;
        end

        table.insert(parts, logic ~= nil and logic.key or 'and');
        table.insert(parts, second);
    end

    table.insert(parts, action);

    if (rule.retry > 0) then
        table.insert(parts, string.format('retry:%d', rule.retry));
    end

    return table.concat(parts, ' ');
end

-- The posture fields as the `posture` verb spells them. The switch fields are
-- booleans; the option fields name a v|o list whose keys are the values the
-- command takes.
local POSTURE_PLAN = {
    { field = 'autoattack', word = 'swing',  list = 'swing'  },
    { field = 'movement',   word = 'stance', list = 'stance' },
    { field = 'tptrigger',  word = 'tpwhen', list = 'tpwhen' },
    { field = 'tpselect',   word = 'tpuse',  list = 'tpuse'  },
    { field = 'spendtp',    word = 'tp'   },
    { field = 'hold',       word = 'hold' },

    -- `latched`: only ever diffed when the server sent the field at all --
    -- an older server refuses `posture X aoews` with a sentence, and a save
    -- plan must never contain a line it knows will refuse.
    { field = 'aoews',      word = 'aoews', latched = true },

    -- Song burst (1.5), the aoews shape one field over: latched on its own
    -- presence, appended at the s| tail, wired to `posture X songburst`.
    { field = 'songburst',  word = 'songburst', latched = true },

    -- The two 2026-08-24 switches, same latched shape one field over each.
    { field = 'runin',      word = 'runin',    latched = true },
    { field = 'manualws',   word = 'manualws', latched = true },

    -- Enfeeble burst (1.7, 2026-08-26): songburst's sibling, same latch.
    { field = 'enfeebleburst', word = 'enfeebleburst', latched = true },
};

local function postureOptionKey(list, id)
    for _, option in ipairs(vocab.posture[list] or {}) do
        if (option.id == id) then
            return option.key;
        end
    end

    return nil;
end

--[[
* The song audience (1.11, 2026-09-07).
*
* The groups themselves are the server's -- `v|o|audience` records, filed by
* the generic v|o reader under the word the command takes, which is exactly
* how the posture option lists arrive. No list here, no ids here: a fourth
* group added server-side appears in the dropdown with no addon release, and a
* server that sends none makes audienceGroups() nil and the whole feature
* invisible.
*
* Arithmetic rather than bit.band throughout, because the ids are 1/2/4 and
* Ashita's bit library is one more dependency this file does not need for
* three numbers.
--]]
local function audienceGroups()
    local list = vocab.posture ~= nil and vocab.posture.audience or nil;

    return (list ~= nil and #list > 0) and list or nil;
end

local function audienceAll()
    local total = 0;

    for _, entry in ipairs(audienceGroups() or {}) do
        total = total + entry.id;
    end

    return total;
end

local function audienceHas(mask, id)
    return math.floor(mask / id) % 2 == 1;
end

-- The command argument: the chosen groups by key, joined with `+`, or `all`
-- when every group is in. `all` is not shorter for three groups but it is what
-- a player would type, and the server understands both.
local function audienceKeys(mask)
    if (mask >= audienceAll()) then
        return 'all';
    end

    local parts = {};

    for _, entry in ipairs(audienceGroups() or {}) do
        if (audienceHas(mask, entry.id)) then
            table.insert(parts, entry.key);
        end
    end

    return #parts > 0 and table.concat(parts, '+') or 'all';
end

-- The dropdown's own label. Short on purpose: it sits inside a table cell
-- beside two other controls.
local function audienceLabel(mask)
    if (mask >= audienceAll()) then
        return 'Everyone';
    end

    local parts = {};

    for _, entry in ipairs(audienceGroups() or {}) do
        if (audienceHas(mask, entry.id)) then
            table.insert(parts, entry.label);
        end
    end

    return #parts > 0 and table.concat(parts, '+') or 'Everyone';
end

--[[
* The save plan: the shortest command sequence that makes the server's copy of
* the set equal the editor's.
*
* Appends and deletions (appends first when the set has room -- see below --
* deletions always descending, so earlier ordinals stay true), then moves --
* `add` only ever appends, so order is restored last. The moves
* are computed against a local mirror that applies each step exactly as the
* server will, which is what makes ordinal arithmetic safe to do at all.
--]]
--[[
* The client's outgoing chat buffer is 128 bytes (GP_CLI_COMMAND_CHAT_STD.Str,
* 0x0b5_chat_std.h:44) and it REFUSES an over-length line rather than
* truncating it -- before the server ever sees it. A plan step that never
* leaves is a plan that dies eight seconds later reporting a failed save for a
* command nobody ever ran, which is the least informative failure this window
* can produce. squad_rule_codes.lua caps its own code parts against the same
* number, and shareTab's Import already checks it by hand.
*
* Reachable rather than theoretical: a twenty-four character set name is 26
* once quoted, a two-condition rule can carry two twenty-odd character
* condition tokens, and four long weapon-skill names in one `tpskill` line
* clear it on their own.
--]]
local CHAT_LINE_MAX = 127;

local function buildSavePlan(name, serverDoc, localDoc, createFirst)
    local commands = {};
    local info     = {};        -- parallel to commands: { ordinal } for an add
    local quoted   = '"' .. name .. '"';

    if (createFirst) then
        -- Unquoted deliberately: `new` reads its name as the raw tail of the
        -- line, so quotes would end up inside the name and cleanName would
        -- refuse them.
        table.insert(commands, '!dwg new ' .. name);
    end

    local mirror = {};

    for index, rule in ipairs(serverDoc.rules) do
        mirror[index] = rule;
    end

    -- Deletions: keep the first server occurrence of every rule the local
    -- document still wants, delete the rest.
    local wanted = {};

    for _, rule in ipairs(localDoc.rules) do
        local key = ruleKey(rule);

        wanted[key] = (wanted[key] or 0) + 1;
    end

    local keep      = {};
    local remaining = {};

    for index, rule in ipairs(mirror) do
        local key = ruleKey(rule);

        if ((wanted[key] or 0) > 0) then
            wanted[key] = wanted[key] - 1;
            keep[index] = true;
            table.insert(remaining, rule);
        end
    end

    local deletes = {};

    for index = #mirror, 1, -1 do
        if (not keep[index]) then
            table.insert(deletes, string.format('!dwg del %s %d', quoted, index));
        end
    end

    local serverCount = #mirror;

    mirror = remaining;

    -- Appends: whatever the local document holds beyond what survived.
    local have    = {};
    local appends = {};

    for _, rule in ipairs(mirror) do
        local key = ruleKey(rule);

        have[key] = (have[key] or 0) + 1;
    end

    for ordinal, rule in ipairs(localDoc.rules) do
        local key = ruleKey(rule);

        if ((have[key] or 0) > 0) then
            have[key] = have[key] - 1;
        else
            local line, why = serialiseRule(quoted, rule);

            if (line == nil) then
                return nil, string.format('Rule %d cannot be saved: it uses %s.', ordinal, why);
            end

            -- `srv` is the server ordinal the row was loaded from (adoptDoc),
            -- nil for a row the player added: an edited row's append and its
            -- old form's delete are one edit, which the full-set plan below
            -- sends as one `replace`.
            local entry = { line = line, ordinal = ordinal, srv = rule.srv };

            table.insert(appends, entry);

            -- A copy with the switch forced ON, because that is what `add`
            -- creates server-side -- mirroring the local rule (possibly off)
            -- would hide exactly the toggle the pass below must emit.
            local fresh = copyRule(rule);

            fresh.enabled = true;

            -- AND WITH THE TWO SONG CELLS BLANK (2026-09-13). `add` writes a
            -- row the server has been told nothing else about -- its audience
            -- is everyone and its refresh is 0, whatever the row being
            -- re-added used to hold -- so nil is what the mirror honestly
            -- knows about it. It changes no command today (every appended
            -- entry is compared against the very rule it was copied from, so
            -- the two passes below already found them equal); it is here
            -- because the SETTLING pass in finishPlanStep rests on exactly
            -- this invariant -- the window never types a song-cell line for a
            -- row the server has not yet said qualifies -- and a mirror that
            -- claims a fresh row already carries the player's numbers is the
            -- one way a future pass could break it.
            fresh.audience = nil;
            fresh.refresh  = nil;

            entry.fresh = fresh;

            table.insert(mirror, fresh);
        end
    end

    --[[
    * APPENDS BEFORE DELETIONS, WHENEVER THE SET HAS ROOM (1.15.0).
    *
    * The wire has no edit verb, so an edited row is a `del` of the old one and
    * an `add` of the new -- and until this round every `del` went first. The
    * editor lets a player choose any who and any when for every action kind,
    * while the server's validator narrows five of them (item, weapon-skill,
    * pact, avatar, release); so "Self / HP% below 30 / Hi-Potion" edited to
    * "Any ally" sent `del 4`, which landed and took the potion rule off the
    * member, then `add ... party ... item:hipotion`, which was refused. The
    * plan stopped there with the set one rule SHORTER than before the Save, and
    * the red sentence never said so.
    *
    * Sent the other way round, a refused `add` has removed nothing. The
    * ordinal arithmetic still holds: `add` only ever appends, so the tail
    * grows PAST every ordinal the deletions name, and the deletions still run
    * from the highest down. The mirror after both phases is the one the moves
    * below were always computed against, so every later pass is unchanged.
    *
    * The price is the set briefly holding both versions, so it is paid only
    * when the ceiling allows it. A plan that would push the set past
    * rulesPerSet on the way takes the branch below instead.
    --]]
    local ceiling     = vocab ~= nil and vocab.caps.rulesPerSet or 0;
    local appendFirst = serverCount + #appends <= ceiling;

    --[[
    * A FULL SET EDITS IN PLACE (1.15.0, the final fix pass). With no room to
    * add first, the old order sent the `del` of an edited row before its
    * `add`, and a refused add then cost the player the very rule they were
    * editing -- at the 48-rule cap, every edit was that gamble. `replace` is
    * the add and the delete as one server write that lands whole or not at
    * all, so every EDITED row (an append whose `srv` names a server row this
    * plan deletes) goes as one; it rewrites that row in place, so no ordinal
    * moves. What is left is plain removals and plain new rows: new rows go
    * first when the set now has room for them, and otherwise the removals do
    * -- rows the player deleted on purpose, so nothing they meant to keep is
    * spent. The mirror is rebuilt to match: kept and replaced rows in server
    * order, then the new rows.
    --]]
    local replaces = {};

    if (not appendFirst) then
        local deleting = {};

        for index = 1, serverCount do
            if (not keep[index]) then
                deleting[index] = true;
            end
        end

        local unpaired = {};

        for _, entry in ipairs(appends) do
            if (entry.srv ~= nil and deleting[entry.srv]) then
                deleting[entry.srv] = nil;
                replaces[entry.srv] = entry;
            else
                table.insert(unpaired, entry);
            end
        end

        if (next(replaces) ~= nil) then
            deletes = {};

            for index = serverCount, 1, -1 do
                if (deleting[index]) then
                    table.insert(deletes, string.format('!dwg del %s %d', quoted, index));
                end
            end

            local rebuilt = {};

            for index, rule in ipairs(serverDoc.rules) do
                if (keep[index]) then
                    table.insert(rebuilt, rule);
                elseif (replaces[index] ~= nil) then
                    table.insert(rebuilt, replaces[index].fresh);
                end
            end

            for _, entry in ipairs(unpaired) do
                table.insert(rebuilt, entry.fresh);
            end

            mirror      = rebuilt;
            appends     = unpaired;
            appendFirst = serverCount + #unpaired <= ceiling;
        end
    end

    local function emitDeletes()
        for _, line in ipairs(deletes) do
            table.insert(commands, line);
            table.insert(info, false);
        end
    end

    local function emitAppends()
        for _, entry in ipairs(appends) do
            table.insert(commands, entry.line);
            table.insert(info, { ordinal = entry.ordinal });
        end
    end

    -- The `new` of a Save-as is step one whichever order follows it.
    if (createFirst) then
        table.insert(info, 1, false);
    end

    -- Replaces first, in server order: none moves an ordinal, so the deletes
    -- and appends after them read the same numbers they always did.
    for index = 1, serverCount do
        local entry = replaces[index];

        if (entry ~= nil) then
            local head = '!dwg add ' .. quoted;

            table.insert(commands, string.format('!dwg replace %s %d%s', quoted, index, string.sub(entry.line, #head + 1)));
            table.insert(info, { ordinal = entry.ordinal });
        end
    end

    if (appendFirst) then
        emitAppends();
        emitDeletes();
    else
        emitDeletes();
        emitAppends();
    end

    -- Moves: selection-sort the mirror into the local order.
    for index = 1, #localDoc.rules do
        if (mirror[index] == nil or ruleKey(mirror[index]) ~= ruleKey(localDoc.rules[index])) then
            for from = index + 1, #mirror do
                if (ruleKey(mirror[from]) == ruleKey(localDoc.rules[index])) then
                    table.insert(commands, string.format('!dwg move %s %d to %d', quoted, from, index));
                    table.insert(mirror, index, table.remove(mirror, from));

                    break;
                end
            end
        end
    end

    -- Toggles (1.4), by FINAL ordinal -- after the moves, because `toggle`
    -- names a position and every earlier phase shuffles them. ruleKey
    -- deliberately excludes the switch (a toggled rule is the same rule),
    -- so this positional pass is the only place the diff can see it.
    -- Latched exactly as the aoews posture field is: a server that never
    -- sent aoews does not speak `toggle` either.
    if (serverDoc.posture ~= nil and serverDoc.posture.aoews ~= nil) then
        for index, rule in ipairs(localDoc.rules) do
            local mine   = rule.enabled ~= false;
            local theirs = mirror[index] == nil or mirror[index].enabled ~= false;

            if (mine ~= theirs) then
                table.insert(commands, string.format('!dwg toggle %s %d %s', quoted, index, mine and 'on' or 'off'));
            end
        end
    end

    -- The song audience (1.11), the toggle pass's shape exactly: by FINAL
    -- ordinal, after the moves, because `audience` names a position too.
    -- ruleKey excludes it for the same reason it excludes the switch -- a
    -- rule sung to a different group is the same rule.
    --
    -- Sent only where BOTH sides carry a mask. A local nil is a rule the
    -- server never called a party song; a mirror nil is a rule the server has
    -- not seen yet (it was appended by this very plan, and `add` gives it
    -- everyone). Either way there is nothing honest to diff, and the read-back
    -- brings the strip in for the next edit.
    if (audienceGroups() ~= nil) then
        for index, rule in ipairs(localDoc.rules) do
            local mine   = rule.audience;
            local theirs = mirror[index] ~= nil and mirror[index].audience or nil;

            if (mine ~= nil and theirs ~= nil and mine ~= theirs) then
                table.insert(commands, string.format('!dwg audience %s %d %s',
                    quoted, index, audienceKeys(mine)));
            end
        end
    end

    -- The refresh threshold (1.14, 2026-09-11), the audience pass's shape
    -- exactly -- by FINAL ordinal, after the moves, and only where both sides
    -- carry a number, because the field is latched the same way.
    for index, rule in ipairs(localDoc.rules) do
        local mine   = rule.refresh;
        local theirs = mirror[index] ~= nil and mirror[index].refresh or nil;

        if (mine ~= nil and theirs ~= nil and mine ~= theirs) then
            table.insert(commands, string.format('!dwg refresh %s %d %s',
                quoted, index, mine > 0 and tostring(mine) or 'off'));
        end
    end

    -- Posture, field by changed field.
    for _, spec in ipairs(POSTURE_PLAN) do
        local mine   = localDoc.posture[spec.field];
        local theirs = serverDoc.posture[spec.field];

        if (mine ~= theirs and (not spec.latched or (theirs ~= nil and mine ~= nil))) then
            if (spec.list ~= nil) then
                local key = postureOptionKey(spec.list, mine);

                if (key ~= nil) then
                    table.insert(commands, string.format('!dwg posture %s %s %s', quoted, spec.word, key));
                end
            else
                table.insert(commands, string.format('!dwg posture %s %s %s', quoted, spec.word, mine and 'on' or 'off'));
            end
        end
    end

    -- The weapon-skill pair (2026-08-06). tphold is a number, not a key list;
    -- the picks are one command carrying the whole ordered list, because order
    -- is the preference and a per-slot diff could not express a reorder.
    local myHold    = localDoc.posture.tphold or 0;
    local theirHold = serverDoc.posture.tphold;

    if (myHold ~= theirHold) then
        table.insert(commands, string.format('!dwg posture %s tphold %s', quoted, myHold > 0 and tostring(myHold) or 'off'));
    end

    local function picksKey(list)
        return type(list) == 'table' and table.concat(list, ',') or tostring(list);
    end

    local myPicks = localDoc.posture.tpskills or {};

    if (picksKey(myPicks) ~= picksKey(serverDoc.posture.tpskills)) then
        if (#myPicks == 0) then
            table.insert(commands, string.format('!dwg posture %s tpskill any', quoted));
        else
            local names = {};

            for _, id in ipairs(myPicks) do
                -- The command names weapon skills, not ids, so a pick this
                -- client has no name for cannot be typed at all -- and
                -- weaponSkillName's `#123` display form would go out as a name
                -- and be refused with a sentence about the wrong thing.
                local name = weaponSkillLookup(id);

                if (name == nil) then
                    return nil, string.format('weapon-skill pick %d, an id (%d) this client has no name for',
                        #names + 1, id);
                end

                table.insert(names, name);
            end

            table.insert(commands, string.format('!dwg posture %s tpskill %s', quoted, table.concat(names, ', ')));
        end
    end

    -- NOTHING GOES INTO A PLAN THE CLIENT WILL REFUSE TO SEND (2026-09-06).
    -- See CHAT_LINE_MAX: an over-length line never reaches the server, and the
    -- only thing that ever noticed was the eight-second save watchdog, whose
    -- sentence is about the server not answering.
    for _, command in ipairs(commands) do
        if (#command > CHAT_LINE_MAX) then
            return nil, string.format(
                'one line of %d characters, and a chat line holds %d -- shorten the set name, or say the rule in two. It starts "%s"',
                #command, CHAT_LINE_MAX, string.sub(command, 1, 46));
        end
    end

    return commands, info;
end

--[[
* Is every step of this plan one of the two per-rule song cells?
*
* The settling pass in finishPlanStep is gated on it: those two lines are the
* only ones buildSavePlan emits which the FIRST pass could not have sent (the
* server has to say whether the row qualifies before either may be typed), so
* a residue made of nothing else is work still owed rather than a refusal.
* Anything else in the list means a step really was turned down.
--]]
local function songCellsOnly(commands)
    if (#commands == 0) then
        return false;
    end

    for _, command in ipairs(commands) do
        local verb = string.match(command, '^!dwg%s+(%S+)');

        if (verb ~= 'audience' and verb ~= 'refresh') then
            return false;
        end
    end

    return true;
end

-- The store's naming rule, checked before a plan is built on it: a refused
-- `new` at the head of a Save As would leave the editor pointed at a set that
-- does not exist, which is a far worse conversation than this sentence.
local function validName(name)
    if (name == nil or #name == 0 or #name > vocab.caps.nameLength) then
        return false;
    end

    return string.match(name, '^[%w][%w %-]*$') ~= nil;
end

--[[
* A name as the server will store it: trimmed, every run of whitespace one
* space (1.15.0).
*
* validName's pattern accepts "COR Rolls " and "COR  Rolls", and the server
* stores neither: the typed tier rejoins its tokens with single spaces
* (squad_rules_cmd.lua tail) and the store trims (squad_gambit_store.cpp
* cleanName). Document adoption compares the name the server sends back with
* the one this window asked for, so a Save-as under "COR Rolls " created and
* filled the set, never recognised its own answer, reported "Saved with
* differences" and stayed dirty -- and the next Save sent every `add` again,
* duplicating every rule. Every name box goes through this before the name is
* checked, sent or remembered.
--]]
local function tidyName(text)
    local trimmed = string.gsub(string.gsub(text or '', '^%s+', ''), '%s+$', '');

    return (string.gsub(trimmed, '%s+', ' '));
end

local function nameProblem(name)
    if (name == nil or #name == 0) then
        return 'Name it first.';
    end

    return string.format('Names are letters, digits, spaces and dashes -- %d characters at most.', vocab.caps.nameLength);
end

local function startPlan(commands, statusText, info)
    local running = (#plan > 0 or planWait ~= nil);

    for index, command in ipairs(commands) do
        table.insert(plan, command);
        table.insert(planInfo, (info ~= nil and info[index]) or false);
    end

    -- Additive while a plan is already running: `#plan` is the REMAINING
    -- length, and resetting the total mid-save restarted the "Saving -- N of
    -- M" counter for whoever clicked a second button.
    if (running) then
        planTotal = planTotal + #commands;
    else
        planTotal = #plan;
    end

    if (statusText ~= nil) then
        state.status    = statusText;
        state.statusBad = false;
    end
end

local function beginSave(asName)
    if (vocab == nil or editor.doc == nil) then
        return;
    end

    -- Client-side sanity the caps record asks for: an action that still says
    -- "pick one" would be refused server-side with a sentence about grammar,
    -- which is the wrong sentence for what the player actually forgot.
    for ordinal, rule in ipairs(editor.doc.rules) do
        local kind = kindOf(rule);

        -- A canned pairing is exempt (1.12): its shipped actionid IS 0 for
        -- both pet pairings, and 0 means "this member's own pet" -- a real,
        -- deliberate, saveable choice. The guard is about an action-kind
        -- dropdown left on "(pick)".
        if (kind ~= nil and kind.canned == nil and kind.arg.kind ~= 'none' and rule.actionid == 0) then
            state.status    = string.format('Rule %d has no action picked yet.', ordinal);
            state.statusBad = true;

            return;
        end
    end

    local name       = asName or editor.name;
    local serverDoc  = asName ~= nil and { posture = {}, rules = {} } or editor.server;

    -- A brand-new document diffs against silence: posture fields all "changed"
    -- if they differ from what `new` will write. `new` creates the store's
    -- defaults, which the server's own s| record for the created set reports
    -- -- so posture lines are emitted for every field here and the harmless
    -- duplicates cost one command each. Simpler than guessing defaults.
    if (asName ~= nil) then
        serverDoc.posture = { autoattack = -1000, spendtp = 'unset', hold = 'unset', movement = -1000, tptrigger = -1000, tpselect = -1000,
                              tphold = -1000, tpskills = 'unset' };

        -- The aoews sentinel rides only when the live server actually sent
        -- the field: it doubles as the toggle latch inside buildSavePlan,
        -- and a synthetic doc must not promise a verb an older server
        -- refuses. (`unset` diffs against either boolean, like the rest.)
        if (editor.server ~= nil and editor.server.posture ~= nil and editor.server.posture.aoews ~= nil) then
            serverDoc.posture.aoews = 'unset';
        end

        -- The songburst sentinel, same rule, its own latch (1.5).
        if (editor.server ~= nil and editor.server.posture ~= nil and editor.server.posture.songburst ~= nil) then
            serverDoc.posture.songburst = 'unset';
        end

        -- The two 2026-08-24 switches, same rule and same latch each.
        if (editor.server ~= nil and editor.server.posture ~= nil and editor.server.posture.runin ~= nil) then
            serverDoc.posture.runin = 'unset';
        end

        if (editor.server ~= nil and editor.server.posture ~= nil and editor.server.posture.manualws ~= nil) then
            serverDoc.posture.manualws = 'unset';
        end

        -- Enfeeble burst (1.7), same rule and same latch.
        if (editor.server ~= nil and editor.server.posture ~= nil and editor.server.posture.enfeebleburst ~= nil) then
            serverDoc.posture.enfeebleburst = 'unset';
        end
    end

    local commands, extra = buildSavePlan(name, serverDoc, editor.doc, asName ~= nil);

    if (commands == nil) then
        state.status    = extra;
        state.statusBad = true;

        return;
    end

    if (#commands == 0) then
        editor.touched = false;
        state.status   = 'Nothing to save.';
        state.statusBad = false;

        return;
    end

    editor.saving          = true;
    editor.settling        = false;
    editor.armRevert       = false;
    editor.removedThisSave = false;

    if (asName ~= nil) then
        -- Kept until the `new` step is confirmed: if `new` is refused
        -- (typically "a set called X already exists"), the abort path rolls
        -- the identity back to this. Without it the editor adopted the
        -- PRE-EXISTING set of that name, and the next Save built a plan that
        -- deleted its rules and replaced them with this document's -- a set
        -- the player never meant to touch, destroyed with no confirmation.
        editor.saveFallback = {
            name    = editor.name,
            setid   = editor.setid,
            shipped = editor.shipped,
            server  = editor.server,
        };

        -- The editor follows the copy: from here on the document being edited
        -- IS the new set, and the `new` response adopts the server's spelling.
        editor.name    = asName;
        editor.setid   = 0;
        editor.shipped = false;
        editor.server  = { name = asName, setid = 0, posture = {}, rules = {}, verdicts = {} };
    else
        editor.saveFallback = nil;
    end

    startPlan(commands, string.format('Saving -- %d step%s...', #commands, #commands == 1 and '' or 's'), extra);
end

local function finishPlanStep()
    if (planWait == nil) then
        return;
    end

    -- Once `new` has been ANSWERED the created set is real, and a refusal of
    -- a later step must keep today's behaviour (re-show the new set): the
    -- rollback below is only for a `new` that never happened.
    if (planWait.verb == 'new') then
        editor.saveFallback = nil;
    end

    -- A `del` of this save has landed: from here a refused `add` has cost the
    -- server a rule, and handleRecord's refusal sentence says so.
    if (planWait.verb == 'del' and editor.saving) then
        editor.removedThisSave = true;
    end

    planWait = nil;

    if (#plan > 0) then
        if (editor.saving) then
            state.status    = string.format('Saving -- %d of %d...', planTotal - #plan + 1, planTotal);
            state.statusBad = false;
        end

        return;
    end

    planTotal = 0;

    if (editor.saving) then
        -- The server's read-back of every step has been folded into
        -- editor.server as it arrived; if the two documents now agree the
        -- edit is truly on disk, and if they do not, something was refused
        -- and the difference is exactly what to look at.
        local residue = editor.server ~= nil
            and buildSavePlan(editor.name, editor.server, editor.doc, false) or nil;

        if (residue ~= nil and #residue == 0) then
            editor.saving   = false;
            editor.settling = false;

            -- Re-copied from the server's read-back rather than just marked
            -- clean: the copy re-numbers each row's server ordinal, which is
            -- the key the inert verdicts are reported against.
            editor.doc      = copyDocOf(editor.server);
            editor.touched  = false;
            state.status    = string.format('"%s" saved.', editor.name);
            state.statusBad = false;
        elseif (residue ~= nil and not editor.settling and songCellsOnly(residue)) then
            --[[
            * THE SETTLING PASS (2026-09-13, Barthal's report).
            *
            * A party-song row edited in any other field is deleted and
            * re-added -- the wire has no edit verb -- and the row `add` writes
            * carries the server's defaults for the two song cells, because
            * only the server decides whether a row qualifies for them at all.
            * The first pass therefore CANNOT send them: before the read-back
            * the addon does not know whether the edited row still qualifies,
            * and an `audience`/`refresh` line for a row that no longer does is
            * a refusal that aborts the rest of the save.
            *
            * Once the document has come back the server has answered that
            * question, and buildSavePlan only ever emits these two lines where
            * BOTH sides carry a value -- which is the server saying the row
            * qualifies. So a residue made of nothing else is not a refusal at
            * all; it is the half of the save that had to wait for an answer.
            * Send it, ONCE (the latch), and judge the result the same way.
            *
            * A residue with anything else in it is a genuine refusal and takes
            * the branch below, unchanged.
            --]]
            editor.settling = true;

            startPlan(residue, string.format('Saving -- the song cells, %d step%s...',
                #residue, #residue == 1 and '' or 's'));
        else
            editor.saving   = false;
            editor.settling = false;
            state.status    = 'Saved with differences -- the server refused part of it. Revert shows what held.';
            state.statusBad = true;
        end
    end
end

--[[
* Record parsing.
*
* Lines arrive one per chat packet. `m|` and `e|` are handled the moment they
* arrive -- a refusal is the one thing a player must never lose, and it also
* has to be able to abort a running save plan RIGHT NOW, before the next step
* goes out. Everything else buffers between `d|` and `z|` and is processed as
* one response: records get their context back (a k| belongs to the c| above
* it) and a torn envelope fills nothing.
--]]

-- Which verbs re-describe members thoroughly enough to reset their inert
-- verdicts. The bare listing (`rules`) sends counts of -1 and no verdicts, so
-- it must not wipe what `report` said.
--
-- `party` (1.15.0): `party use` re-installs every member it moves and answers
-- c| and k| for each inside the `party` envelope, exactly as `use` does. Left
-- out, the bare-listing branch below threw away the verdicts of every member
-- whose set changed and then dropped the k| lines that followed (no entry to
-- put them in), so a party preset loaded with no inert markers at all until
-- the player pressed Check. Safe for the other party sub-verbs: only `use`
-- emits c|.
local VERDICT_VERBS = { add = true, del = true, move = true, toggle = true, posture = true, use = true, report = true, show = true,
                        audience = true, refresh = true, party = true, replace = true };

--[[
* Which verbs answer with a full document (s| followed by its r| rows).
*
* THE ANSWER IS "EVERY MUTATING VERB", and the list has to be kept equal to
* that (squad_rules_cmd.lua's saveAndRefresh: "IT IS ALSO WHERE THE MACHINE
* TIER LEARNS WHAT THE SET NOW IS" -- every editing verb goes through it and
* every one of them emits the whole document).
*
* `audience` (1.11, 2026-09-07) and `refresh` (1.14, 2026-09-11) were left out
* of this list when they shipped, and that ONE omission is the whole of two
* player reports (2026-09-13, Barthal and Captain Tightpants). The server
* saved the change and answered with the document proving it; the addon threw
* that document away, so `editor.server` still said what the cell used to
* hold. The post-save residue then found a difference the server did not have
* -- "Saved with differences -- the server refused part of it" over a save the
* server had accepted -- the document stayed dirty, and Revert (which copies
* the server mirror over the document) put the old number back. "It won't save
* and reverts back to default 0" is exactly what a discarded read-back looks
* like from the outside.
*
* So: a verb that mutates goes in BOTH tables, or the window lies about what
* the server did.
--]]
local DOC_VERBS = { show = true, new = true, copy = true, rename = true, add = true, del = true, move = true,
                    toggle = true, posture = true, ['import'] = true,
                    audience = true, refresh = true, replace = true };

local function parseSetRecord(parts)
    -- The two weapon-skill fields were appended 2026-08-06; absent from an
    -- older server they read as "engine default, no picks", which is that
    -- server's truth. '-' is the record grammar's "no picks".
    local tpskills = {};

    if (parts[12] ~= nil and parts[12] ~= '-' and parts[12] ~= '') then
        for _, piece in ipairs(split(parts[12], ',')) do
            local id = tonumber(piece);

            if (id ~= nil and id > 0) then
                table.insert(tpskills, id);
            end
        end
    end

    -- `aoews` was appended 2026-08-18. nil -- an older server -- doubles as
    -- THE latch for the whole toggle round: a server that sends it also
    -- speaks the `toggle` verb and the r| record's on/off field, so the
    -- editor only offers its new checkboxes when this field arrived.
    local aoews = nil;

    if (parts[13] ~= nil) then
        aoews = parts[13] ~= '0';
    end

    -- `songburst` was appended 2026-08-23, its own latch for its own round:
    -- a server that sends it speaks `posture X songburst`. Absent reads as
    -- "this server always lets songs burst", which is that server's truth.
    local songburst = nil;

    if (parts[14] ~= nil) then
        songburst = parts[14] ~= '0';
    end

    -- `runin` and `manualws` were appended 2026-08-24 as parts[15] and parts[16], each
    -- its own latch for its own switch. Absent reads as "this server always
    -- walks its bards in" and "this server has no manual weapon-skill mode",
    -- which is that server's truth in both cases.
    local runin = nil;

    if (parts[15] ~= nil) then
        runin = parts[15] ~= '0';
    end

    local manualws = nil;

    if (parts[16] ~= nil) then
        manualws = parts[16] ~= '0';
    end

    -- `enfeebleburst` was appended 2026-08-26 as parts[17], songburst's
    -- sibling latch. Absent reads as "this server always lets enfeebles
    -- burst", which is that server's truth.
    local enfeebleburst = nil;

    if (parts[17] ~= nil) then
        enfeebleburst = parts[17] ~= '0';
    end

    return {
        setid   = tonumber(parts[2]) or 0,

        -- '' rather than nil for a name the packet cut off: the owned-set
        -- list is SORTED, and `nil < 'Medic'` throws inside table.sort, inside
        -- the render. A set with no name cannot be adopted either way -- the
        -- adoption test compares it against a name the player asked for -- so
        -- the empty string costs nothing and keeps the sort honest.
        name    = parts[3] or '',
        count   = tonumber(parts[4]) or 0,
        posture = {
            autoattack = tonumber(parts[5]) or 2,
            spendtp    = parts[6] == '1',
            hold       = parts[7] == '1',
            movement   = tonumber(parts[8]) or 127,
            tptrigger  = tonumber(parts[9]) or 0,
            tpselect   = tonumber(parts[10]) or 0,
            tphold     = tonumber(parts[11]) or 0,
            tpskills   = tpskills,
            aoews      = aoews,
            songburst  = songburst,
            runin      = runin,
            manualws   = manualws,
            enfeebleburst = enfeebleburst,
        },
        rules    = {},
        verdicts = {},
    };
end

local function parseRuleRecord(parts)
    -- The on/off field was appended 2026-08-18. Absent -- an older server --
    -- stays nil, which is how the editor knows not to offer the switch.
    local enabled = nil;

    if (parts[14] ~= nil) then
        enabled = parts[14] ~= '0';
    end

    -- The song audience was appended 2026-09-07. `-` means the server says
    -- this rule is not a party song it keeps up, so there is nobody to choose
    -- and no strip to draw; absent means a server from before the round, and
    -- the two are treated alike.
    local audience = nil;

    if (parts[15] ~= nil and parts[15] ~= '-') then
        audience = tonumber(parts[15]);
    end

    -- The song refresh threshold was appended 2026-09-11, behind the SAME
    -- latch as the audience beside it: `-` means the server says this rule is
    -- not a party song it keeps up, so there is nothing to refresh and no
    -- field to draw; absent means a server from before the round, and the two
    -- are treated alike.
    local refresh = nil;

    if (parts[16] ~= nil and parts[16] ~= '-') then
        refresh = tonumber(parts[16]);
    end

    return {
        target   = tonumber(parts[3]) or 0,
        logic    = tonumber(parts[4]) or 0,
        cond1    = tonumber(parts[5]) or 0,
        arg1     = tonumber(parts[6]) or 0,
        cond2    = tonumber(parts[7]) or NO_CONDITION,
        arg2     = tonumber(parts[8]) or 0,
        reaction = tonumber(parts[9]) or 0,
        selector = tonumber(parts[10]) or 0,
        actionid = tonumber(parts[11]) or 0,
        retry    = tonumber(parts[12]) or 0,
        gate     = parts[13] ~= nil and parts[13] ~= '-' and parts[13] or nil,
        enabled  = enabled,
        audience = audience,
        refresh  = refresh,
    };
end

local function processEnvelope(verb, records)
    --[[
    * WHICH SET AN EXPORT ANSWERS FOR IS NOT ON THE WIRE (2026-09-06).
    *
    * It is read off the command still in flight instead: an `export` answer can
    * only belong to the `export` that is waiting for one. A player who picks a
    * second set before the first answer lands -- two clicks inside the 1.2
    * second throttle is all it takes -- otherwise read the FIRST set's code
    * under the SECOND set's name, which the header of shareTab calls the one
    * failure of that pane a player could not possibly diagnose. A mismatched
    * answer is dropped whole rather than shown: the pane goes on saying
    * "Fetching..." until the right one arrives, which it will, because the
    * second export is the next step of the same plan.
    --]]
    local acceptCodes = true;

    if (verb == 'export' and planWait ~= nil and state.codesFor ~= nil) then
        local forName = string.match(planWait.command, '^!dwg export "(.*)"$');

        acceptCodes = forName == nil or string.lower(forName) == string.lower(state.codesFor);
    end

    -- Wholesale resets FIRST, before anything can throw: a response replaces
    -- its own section outright, never merges with it.
    if (verb == 'rules') then
        state.members     = {};
        state.memberOrder = {};
    elseif (verb == 'list' or verb == 'menu' or verb == 'delete') then
        state.sets    = {};
        state.assigns = {};
    elseif (verb == 'presets') then
        state.presets = {};
    elseif (verb == 'export' and acceptCodes) then
        state.codes     = {};
        state.codeTotal = 0;
    elseif (verb == 'hints') then
        state.hints = {};
    elseif (verb == 'party') then
        -- Only the listing: every party envelope opens with the full y|
        -- stream (dwg_protocol.md), while its a| records cover just the rows
        -- a `use` actually wrote -- resetting assigns here would blank the
        -- characters a load deliberately skipped.
        state.loadouts = {};
    end

    local doc      = nil;
    local lastDoc  = nil;

    -- The members a c| of THIS envelope described (1.15.0): a u| hangs only
    -- on one of them, never on a member some earlier answer left behind.
    local described = {};
    local vocabPage = nil;

    for _, parts in ipairs(records) do
        local kind = parts[1];

        if (kind == 's') then
            doc     = parseSetRecord(parts);
            lastDoc = doc;

            if (doc.setid ~= 0) then
                state.sets[doc.setid] = doc;
            end
        elseif (kind == 'r') then
            if (doc ~= nil) then
                table.insert(doc.rules, parseRuleRecord(parts));
            end
        elseif (kind == 'k') then
            local charid  = tonumber(parts[2]) or 0;
            local ordinal = tonumber(parts[3]) or 0;

            -- THE OVERFLOW LINE HAS ITS OWN ORDINAL, -1 (1.15.0). The server
            -- caps the verdicts it sends per member and says how many it held
            -- back in one "...and N more" line, which rode ordinal 0 -- the
            -- ordinal that has meant "the posture's weapon-skill picks" since
            -- 2026-08-06, so the overflow was drawn under the picks as if it
            -- were about them, and overwrote a real picks verdict. A server
            -- from before the move still sends 0; its sentence is the only
            -- one that opens with "...and", and it is read as -1 here too.
            if (ordinal == 0 and charid ~= 0 and string.sub(parts[4] or '', 1, 7) == '...and ') then
                ordinal = -1;
            end

            if (charid == 0) then
                if (doc ~= nil) then
                    doc.verdicts[ordinal] = parts[4] or '';
                end
            else
                local entry = state.verdicts[charid];

                if (entry ~= nil) then
                    entry.list[ordinal] = parts[4] or '';
                end
            end
        elseif (kind == 'c') then
            local member = {
                charid     = tonumber(parts[2]) or 0,
                name       = parts[3] or '?',
                job        = tonumber(parts[4]) or 0,
                lvl        = tonumber(parts[5]) or 0,
                setid      = tonumber(parts[6]) or 0,
                presetid   = tonumber(parts[7]) or 0,
                installed  = tonumber(parts[8]) or -1,
                considered = tonumber(parts[9]) or -1,
                capped     = parts[10] == '1',

                -- APPENDED 1.15.0: the support job and its level, 0 for none.
                -- A server from before them sends ten fields and the member
                -- simply has no support job as far as the lists are concerned.
                sjob       = tonumber(parts[11]) or 0,
                slvl       = tonumber(parts[12]) or 0,

                -- The u| lists that follow this record (1.15.0), by kind:
                -- lists.b = the blue spells SET on it, lists.r = the rolls it
                -- can use, each a set of ids. A kind the server never sent is
                -- nil -- "not told", which is not the same as "none".
                lists      = {},
            };

            if (state.members[member.charid] == nil) then
                table.insert(state.memberOrder, member.charid);
            end

            state.members[member.charid] = member;
            described[member.charid] = true;

            if (VERDICT_VERBS[verb]) then
                state.verdicts[member.charid] = { setid = member.setid, presetid = member.presetid, list = {} };
            else
                -- The bare listing measured nothing; old verdicts stand
                -- unless the member is visibly on a different set now.
                local entry = state.verdicts[member.charid];

                if (entry ~= nil and (entry.setid ~= member.setid or entry.presetid ~= member.presetid)) then
                    state.verdicts[member.charid] = nil;
                end
            end
        elseif (kind == 'a') then
            local entry = {
                charid = tonumber(parts[2]) or 0,
                name   = parts[3] or '?',
                job    = tonumber(parts[4]) or 0,
                kind   = parts[5] or 'none',
                setid  = tonumber(parts[6]) or 0,
                ref    = parts[7] or '',
            };

            state.assigns[entry.charid .. ':' .. entry.job] = entry;
        elseif (kind == 'u') then
            --[[
            * A member's own lists (1.15.0, dwg_protocol.md): `b` the blue
            * spells SET on it, `r` the rolls it can use. They follow that
            * member's c| in the same envelope, and the c| built a fresh
            * `lists` table, so what accumulates here is exactly this answer's
            * -- several records of one kind are one list (a long set does not
            * fit on one line), and an empty ids field is a real "none". A
            * kind this file does not know is somebody else's growth and is
            * ignored, and so is a u| for a member no c| described: there is
            * nothing to hang it on.
            --]]
            local charid = tonumber(parts[2]) or 0;
            local member = described[charid] and state.members[charid] or nil;
            local which  = parts[3];

            if (member ~= nil and member.lists ~= nil and (which == 'b' or which == 'r')) then
                local into = member.lists[which] or {};

                member.lists[which] = into;

                for _, piece in ipairs(split(parts[4] or '', ',')) do
                    local id = tonumber(piece);

                    if (id ~= nil and id > 0) then
                        into[id] = true;
                    end
                end
            end
        elseif (kind == 'p') then
            table.insert(state.presets, {
                name    = parts[2] or '?',
                id      = tonumber(parts[3]) or 0,
                count   = tonumber(parts[4]) or 0,
                summary = parts[5] or '',
            });
        elseif (kind == 'y') then
            table.insert(state.loadouts, {
                name    = parts[2] or '?',
                members = tonumber(parts[3]) or 0,
                rows    = tonumber(parts[4]) or 0,
            });
        elseif (kind == 'x' and acceptCodes) then
            -- Stored at its part number rather than appended: parts arrive in
            -- order today and a code assembled out of order would be a code
            -- that looks right and is not.
            --
            -- The record's own `total` is kept as well as the parts, so a part
            -- that never arrived is a sentence rather than a code the player
            -- copies and the other end refuses (2026-09-06). Counting what
            -- turned up cannot see what did not.
            state.codes[tonumber(parts[2]) or 1] = parts[4];
            state.codeTotal = tonumber(parts[3]) or state.codeTotal;
        elseif (kind == 'h') then
            -- An upgrade hint (dwg_protocol.md): the finished sentence plus
            -- the fields that let this renderer label it without parsing
            -- prose. Arrival order is the server's rank order and is kept.
            local charid = tonumber(parts[2]) or 0;

            state.hints[charid] = state.hints[charid] or {};

            table.insert(state.hints[charid], {
                kind     = parts[3],
                ordinal  = tonumber(parts[4]) or 0,
                distance = tonumber(parts[5]) or 0,
                command  = (parts[6] ~= nil and parts[6] ~= '-' and parts[6] ~= '') and parts[6] or nil,
                text     = parts[7] or '',
            });
        elseif (kind == 'g') then
            vocabPage = {
                page    = tonumber(parts[2]) or 1,
                pages   = tonumber(parts[3]) or 1,
                version = tonumber(parts[4]) or 0,
                rows    = {},
            };
        elseif (kind == 'v') then
            if (vocabPage ~= nil) then
                table.insert(vocabPage.rows, parts);
            end
        end
    end

    -- The vocabulary pages assemble into one whitelist; a version change mid
    -- flight (or against the copy in use) restarts from nothing, because half
    -- of one vocabulary and half of another is worse than a second of delay.
    if (vocabPage ~= nil) then
        if (vocab ~= nil and vocab.version ~= vocabPage.version) then
            vocab = nil;
        end

        if (vocabWork == nil or vocabWork.version ~= vocabPage.version) then
            vocabWork = { version = vocabPage.version, pages = vocabPage.pages, got = {}, rows = {} };
        end

        vocabWork.pages = vocabPage.pages;

        if (not vocabWork.got[vocabPage.page]) then
            vocabWork.got[vocabPage.page]  = true;
            vocabWork.rows[vocabPage.page] = vocabPage.rows;
        end

        local complete = true;

        for page = 1, vocabWork.pages do
            if (not vocabWork.got[page]) then
                complete = false;

                break;
            end
        end

        -- The render loop drives the next page (needVocab): asking here as
        -- well would race the tracker and re-request pages already staged.
        if (complete and not buildVocab(vocabWork)) then
            -- The pages described one TOPIC rather than the whitelist (see
            -- buildVocab's refusal). Throw the staged copy away AND clear the
            -- answer tracker: the question this envelope answered was not the
            -- one the addon asked, so leaving it marked answered would park
            -- the fetch forever.
            vocabWork          = nil;
            requested['vocab'] = nil;
        end
    end

    -- Document adoption. Three ways a doc can be "the one on screen": it is
    -- the one a click just asked for, it carries the name being edited, or it
    -- carries the setid being edited (which is how a rename typed outside the
    -- window follows into the title).
    if (lastDoc ~= nil and DOC_VERBS[verb]) then
        local docName = string.lower(lastDoc.name or '');

        if (editor.pendingRef ~= nil and docName == string.lower(editor.pendingRef)) then
            editor.pendingRef = nil;
            editor.touched    = false;
            adoptDoc(lastDoc);

            -- The document the "Loading X..." line was about is on screen
            -- (2026-09-06). Nothing used to take that line back down, so the
            -- window sat there saying it was still loading a set the player
            -- was already editing -- until some other action happened to
            -- overwrite the status. Only ours is replaced: a server sentence
            -- that arrived inside the same envelope is worth more than a
            -- progress note and must survive.
            if (not state.statusBad and string.sub(state.status, 1, 8) == 'Loading ') then
                state.status    = string.format('"%s" -- %d rule%s.', lastDoc.name,
                    #lastDoc.rules, #lastDoc.rules == 1 and '' or 's');
                state.statusBad = false;
            end
        elseif (editor.name ~= nil and docName == string.lower(editor.name)) then
            adoptDoc(lastDoc);
        elseif (editor.setid ~= 0 and lastDoc.setid == editor.setid) then
            adoptDoc(lastDoc);
        end
    end

    -- A deleted set (this UI's own Delete button, or typed outside the
    -- window) must not stay on screen as editable.
    if (verb == 'delete' and editor.setid ~= 0 and state.sets[editor.setid] == nil) then
        editor.name      = nil;
        editor.setid     = 0;
        editor.doc       = nil;
        editor.server    = nil;
        editor.touched   = false;
        editor.armDelete = 0;

        -- And the two promises about a document that no longer exists: a
        -- pendingRef would adopt a later answer for the deleted name over
        -- whatever is on screen by then, and a saveFallback would roll a
        -- refused `new` back to a set the account has lost. (2026-09-06.)
        editor.pendingRef   = nil;
        editor.saveFallback = nil;
    end

    -- One bump per envelope, after every section has been committed. The
    -- derived views (views()) hang off it; a missed bump is a window showing a
    -- set that is gone, so it is deliberately coarse -- an envelope is a rare
    -- event and rebuilding four small lists is cheaper than proving which of
    -- them a given verb could not have touched.
    state.rev = state.rev + 1;

    if (planWait ~= nil and planWait.verb == verb) then
        finishPlanStep();
    end

    -- A response that can change what a member is running -- or how well the
    -- set fits it -- makes the hint strip stale, so the next frame re-asks.
    -- `show` is deliberately not here: loading a document changes nothing
    -- about anybody, and hints per set-load would be a command per click.
    --
    -- Five more since 1.15.0: `party` (a load re-installs everyone it moves),
    -- `toggle`, `audience` and `refresh` (each re-installs whoever runs the set
    -- -- saveAndRefresh), and `delete` (a member on the deleted set falls back
    -- to the squad profile). And `replace` (the final fix pass): an edit in
    -- place re-installs whoever runs the set, exactly as `add` does.
    if (verb == 'use' or verb == 'add' or verb == 'del' or verb == 'move'
            or verb == 'posture' or verb == 'report' or verb == 'party'
            or verb == 'toggle' or verb == 'audience' or verb == 'refresh' or verb == 'delete'
            or verb == 'replace') then
        requested['hints'] = nil;
    end

    -- AND `delete` MAKES THE LEFT PANE WRONG, not just the hints. Its answer is
    -- the account's sets and assignments, never the members -- so a member
    -- that was running the deleted set went on reading "set #N" under its
    -- name. The bare listing is asked again, which is what that pane is drawn
    -- from, and it says what each member fell back to.
    if (verb == 'delete') then
        requested['rules'] = nil;
    end

    answered(verb);
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status      = string.format('Server protocol %d, addon expects %d. Update dwgambits.', version, PROTOCOL);
            state.statusBad   = true;
            state.inbound     = nil;
            state.protocolBad = true;

            -- A d| envelope IS the answer, whatever version it announced, and
            -- re-asking a server that speaks a layout this addon cannot read
            -- cannot help. One shape across the suite (dwfame, 2026-08-15);
            -- gated in harness_dwsuite.py.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        -- A server that DOES speak this protocol clears the mismatch banner
        -- (2026-09-06). Nothing else ever did: the banner is set by a branch
        -- that returns before any record is read, so a client that reloaded
        -- onto a matching server -- or whose relog landed on the map that had
        -- just been upgraded -- went on reading "Update dwgambits" over a
        -- window that was working perfectly, for the rest of the session.
        if (state.protocolBad) then
            state.protocolBad = false;
            state.status      = 'Fetching...';
            state.statusBad   = false;
        end

        state.inbound = parts[3];
        state.buffer  = {};

        return;
    end

    -- Status lines land whatever the envelope state -- they are the one thing
    -- a player must never lose -- and a refusal mid-save stops the plan
    -- before the next step can compound it.
    if (kind == 'm' or kind == 'e') then
        -- The one refusal that is not worth a red banner: a server from
        -- before the hint tier answering `!dwg hints` with its unknown-verb
        -- sentence. That means hints do not exist here yet, so the addon
        -- stops asking and renders nothing -- deployment order must not
        -- matter in either direction (UPGRADE_HINTS_PLAN.md Phase 3).
        if (kind == 'e' and not hintsUnsupported
                and string.find(line, 'no rules subcommand called "hints"', 1, true) ~= nil) then
            hintsUnsupported = true;

            return;
        end

        -- Its twin for the party-preset tier: an older server has no `party`
        -- verb, so the Party tab goes quiet instead of red. The tab renders
        -- the explanation itself.
        if (kind == 'e' and not partyUnsupported
                and string.find(line, 'no rules subcommand called "party"', 1, true) ~= nil) then
            partyUnsupported = true;

            return;
        end

        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwgambits'):append(chat.error(state.status)));

            -- A `show` this window is waiting for and the server refused is a
            -- promise it can no longer keep (2026-09-06). Left set, pendingRef
            -- adopts a LATER document of that name over whatever the player
            -- has since started editing -- with `touched` cleared, so the
            -- unsaved side goes with it. Only cleared when the refusal names
            -- the reference being waited on, so a refusal about anything else
            -- cannot throw away a load that is still in flight.
            if (editor.pendingRef ~= nil and string.find(string.lower(state.status),
                    string.lower(editor.pendingRef), 1, true) ~= nil) then
                editor.pendingRef = nil;
            end

            if (#plan > 0 or planWait ~= nil) then
                local refusedNew = (planWait ~= nil and planWait.verb == 'new');

                -- WHICH RULE, AND WHAT IT HAS ALREADY COST (1.15.0). A refused
                -- `add` is about one row of the editor, and the server's
                -- sentence cannot know which -- the add's ordinal is the tail
                -- of the set, not the row on screen -- so the row is named
                -- here. And if a `del` of this same save has already landed,
                -- the server now holds a rule fewer than the player can see
                -- was ever there; that only happens when the set was too near
                -- its ceiling to add first (buildSavePlan), and it is said
                -- rather than left for the player to discover.
                local origin  = planWait ~= nil and planWait.info ~= nil and planWait.info.ordinal or nil;
                local removed = origin ~= nil and editor.saving and editor.removedThisSave;

                abortPlan(state.status);

                if (origin ~= nil) then
                    state.status    = string.format('Rule %d: %s', origin, state.status);
                    state.statusBad = true;
                end

                if (removed) then
                    state.status    = state.status .. ' A rule this save removed is already gone from the server'
                        .. ' -- fix this one and Save again, or Revert to see what it holds.';
                    state.statusBad = true;
                end

                editor.saving     = false;
                editor.settling   = false;
                editor.pendingRef = nil;

                -- A refused `new` rolls the Save-as identity change back:
                -- left pointed at the refused name, the re-show below would
                -- adopt the PRE-EXISTING set of that name and the next Save
                -- would overwrite it (see beginSave's fallback comment). Any
                -- other refusal only drops the fallback -- keeping it would
                -- let a LATER refused `new` roll the identity back to a set
                -- the player has since moved away from.
                if (refusedNew) then
                    rollbackSaveAs();
                else
                    editor.saveFallback = nil;
                end

                -- What actually landed is the only trustworthy ground to
                -- retry from, so the server copy is re-fetched -- with
                -- pendingRef left nil, so the arriving document refreshes
                -- editor.server without clobbering the player's unsaved side.
                reloadServerCopy();
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local verb    = state.inbound;
        local records = state.buffer;

        state.inbound = nil;
        state.buffer  = {};

        processEnvelope(verb, records);

        return;
    end

    table.insert(state.buffer, parts);
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWGDATA is ours: consumed and blocked before parsing, so a
* malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwgambits_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwgambits'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering.
--]]

-- Per-widget scratch: combo filter text and the pending-name input boxes.
-- PLAIN tables -- these are keyed by strings the code chooses and T{}'s sugar
-- metatable answers unknown string keys with functions.
local filters   = {};
local nameBoxes = {};

local function filterOf(id)
    if (filters[id] == nil) then
        filters[id] = T{ '' };
    end

    return filters[id];
end

local function nameBoxOf(id)
    if (nameBoxes[id] == nil) then
        nameBoxes[id] = T{ '' };
    end

    return nameBoxes[id];
end

local function tooltipOnHover(text)
    if (text ~= nil and text ~= '' and imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* The hover text.
*
* A TABLE RATHER THAN SIXTY INLINE STRINGS, for two reasons. The harness can
* assert that a control which owns a sentence still has one -- a tip attached
* to the wrong widget is invisible to every other kind of check -- and the
* sentences can be read side by side and kept in one voice.
*
* Nothing whose wording comes off the WIRE is in here: a vocabulary note, an
* inert verdict and an upgrade hint are the server's sentences and this addon
* only renders them. What is here is what the window itself means.
--]]
local TIPS = {
    refresh    = 'Throws away every answer this window is holding and asks the server again. Unsaved edits are not touched.',
    queued     = 'Commands still waiting to go out. One leaves every 1.2 seconds: the client rate-limits chat, and a line sent too soon is refused before the server ever sees it.',

    outNow     = 'The squad members standing in the world right now. Click one to open the rule set it is running.',
    atHome     = 'Account characters that are not summoned. Click one to open whatever it will be holding when it is.',
    liveCount  = 'Rules live on this member, out of the rules of its set that applied to it at all. Check re-measures both.',
    assigned   = 'What this character is set to run the next time it is summoned. "automatic" means it falls back to the squad profile.',

    setPick    = 'Which of your sets to edit. Everything you change is local until you press Save.',
    newName    = 'A name for a new, empty set.',
    addRule    = 'Adds a blank rule at the bottom. Nothing reaches the server until you press Save.',
    full       = 'This set is at the server\'s rule ceiling. Delete a rule to make room for another.',
    dirty      = 'Changes that live only in this window. Save writes them; Revert throws them away.',
    clean      = 'This window and the server agree about this set.',
    save       = 'Works out the shortest run of add, delete, move, toggle and posture commands that makes the server\'s copy match what you see, and sends them one at a time. Every step is a line you could have typed.',
    revert     = 'Throws your unsaved edits away and shows the server\'s copy again. With edits on screen it asks once more first.',
    revertArmed = 'Click again to throw away every unsaved edit on screen. Any other edit first puts this button back.',
    saveAsBox  = 'A name to save what is on screen under as a NEW set, leaving the one you opened as it was.',
    saveAs     = 'Creates a new set of that name holding this document. The original is untouched.',
    renameBox  = 'A new name for the set being edited.',
    duplicate  = 'Adds a copy of this rule directly below it -- the quick way to write two rules that differ in one dropdown.',
    remove     = 'Removes this rule from the document. Nothing reaches the server until you press Save.',

    colOrder   = 'Priority. A member reads its rules top down and acts on the first one that fits, so an earlier rule starves a later one.',
    colOn      = 'Off keeps a rule in the set without running it. It keeps its number, so nothing below it renumbers.',
    colWho     = 'Who the rule watches. A few entries watch one thing and act on another; hover an entry in the list for what it means.',
    colWhen    = 'When the rule may fire. Two conditions at most, joined by and/or -- and the timer condition has to be a rule\'s only one, because its clock is spent by being checked.',
    colDo      = 'What happens when the condition holds. A family entry picks the best tier the member can afford and keeps up as it levels; an exact spell or ability stays exact forever.',
    colRetry   = 'How long a rule waits after firing before it may fire again.',

    swing      = 'Whether the member melees at all once it is engaged.',
    stance     = 'How far back it stands, in yalms. A member takes its stance before its first action of a fight.',
    tpwhen     = 'What makes the member spend a full TP bar.',
    tpuse      = 'Which weapon skill the automatic spender reaches for.',

    gate       = 'Which members of the composition receive this rule. A shipped set is written for a whole party rather than for one job.',
    view       = 'Opens it read-only, rule by rule, so you can see what it actually does.',
    presetFind = 'Narrows the shipped sets to the ones whose name or description carries what you type. The descriptions say which job each is written for, so "whm" and "tank" both find something.',
    codeWait   = 'The server is writing the code. It arrives as one or more lines of text in boxes here.',
    codeGap    = 'One line of the code never arrived. A code is only usable whole, so make it again rather than sharing what is here.',
    pagePrev   = 'The previous ten shipped sets.',
    pageNext   = 'The next ten shipped sets.',
    pageFirst  = 'You are already on the first page.',
    pageLast   = 'You are already on the last page.',
    presetFindClear = 'Empties the find box and shows all forty again.',
    copyName   = 'A name for your editable copy.',
    copyFor    = 'A shipped set is a composition, so flattening it has to know whose half to keep. With nobody summoned it uses the job you are playing.',
    copyMake   = 'Writes the rules that member would receive into a new set of your own.',

    sharePick  = 'Which of your sets to turn into a code.',
    codeBox    = 'Click into the box and Ctrl-C, or press Copy. A code is a snapshot -- edit the set and make a new one.',
    codeCopy   = 'Puts this line on the clipboard.',
    codeCopyAll = 'Puts every line of the code on the clipboard at once, space-joined -- one paste is a whole import.',
    codeParts  = 'A long set does not fit on one chat line, so its code comes back in parts. All of them are needed.',
    pasteBox   = 'Paste a code somebody gave you -- every line of it at once, the way Copy all puts it on the clipboard.',

    partyName  = 'A name for the snapshot. Party preset names are their own list -- one called "Medic" can sit beside a rule set of the same name.',

    tabEditor  = 'Write and change your own rule sets.',
    tabParty   = 'Save how the whole squad is assigned right now, under one name, and load it back later.',
    tabShipped = 'The sets that ship with the server: always available, never edited, and the fastest way to start.',
    tabShare   = 'Turn one of your sets into text, and somebody else\'s text into a set of yours.',

    -- Moved here from the call sites 2026-09-06, so every sentence the
    -- window owns is held to the same shape by the harness. The wrapped
    -- ones keep their line breaks: SetTooltip does not wrap, and these are
    -- the longest things this window says.
    -- The ones that carry a number off the wire. Format strings, in the table
    -- for the same reason as the rest: the numbers are the server's and the
    -- words are the window's.
    newSet     = '%d of %d sets used. Names are letters, digits, spaces and dashes, %d characters at most.',
    retrySecs  = 'Seconds to wait after this rule fires before it may fire again. Anything from 0 to %d.',
    tpHold     = '0 uses the engine default. %d-%d is the amount "attp" spends at, "random" rolls from and "opener" waits for.',
    condRange  = 'The amount this condition compares against. Anything from %d to %d%s.',
    presetAssign = 'Assign it to %s. The member receives only the rules its job can use.',

    assignWho = 'Who the Assign beside it puts a set on: a summoned member, a character at home, or the whole squad at once.',
    assign = 'Puts this set on whoever the box beside it names, and installs it at once on anyone already summoned. The typed form is !squad rules use <who> <set>.',
    dropCond2 = 'Drops the second condition and leaves the first one alone.',
    addCond2 = 'Adds a second condition, joined to the first by and/or.',
    ruleOff = 'Switched off -- the member ignores this rule until it is switched back on. Right-click the number to move it.',
    ruleOrdinal = 'Rules are read top down; an earlier rule beats a later one. Right-click the number to move it to the top or the bottom.',
    toggleOn = 'Off keeps the rule in the set without running it -- no more deleting and retyping. Save applies it.',
    spendTp = 'Off is the only honest \'do not use weapon skills\': the engine spends a full bar before it reads a single rule.',
    holdPos = 'On means the member never engages by itself.',
    wsPicks = 'Up to four, in order -- the first is what a full bar opens with. (any) lets the member choose from everything it knows.',
    check = 'Re-measures every summoned member: which rules are live, which are inert and why.',
    rename = 'Assignments and party presets point at the set itself, so they follow a rename.',
    deleteArmed = 'This cannot be undone. Any character running it goes back to the squad profile; a party preset that names it will skip those members.',
    deleteSet = 'Deletes this set. Asks once more before anything happens.',
    refreshCode = 'Makes the code again from the set as it stands now. A code is a snapshot, so an edited set needs a new one.',
    importName = 'Leave it empty to keep the name the set was shared under.',
    importBtn = 'Reads the code in the box and writes the set it describes. A long code\'s lines are sent one after another, for you.',
    partySave = 'Snapshots every character\'s current assignment under this name. Re-saving a name overwrites it.',
    partyLoad = 'Every character goes back to the set this preset remembers. Skips are reported in the status line.',
    partyDeleteArmed = 'This cannot be undone. The rule sets themselves are untouched.',
    partyDelete = 'Forgets the snapshot. Asks once more before anything happens.',
    aoews = 'Off keeps every area weapon skill out of this member\'s TP spending,\nso it stops dragging bystanders into the fight.',
    songBurst = 'Off keeps bard songs out of this member\'s magic bursts --\nthe burst-matching pick considers real nukes only. Rules that\nname a song on purpose still fire.',

    -- The song audience (1.11). The sentence explains the SLOT, not the
    -- radius: a player who has already tried standing the bard further away
    -- knows distance does not work and needs to be told why this does.
    songRefresh = 'Sing this one again before it runs out, instead of waiting for it\nto vanish. The number is how many SECONDS of the song may be left when the\nbard starts over, so it follows the song\'s own length rather than a clock\nyou have to keep in step with it. Zero waits for the song to end, which is\nwhat every rule did before this box existed.\nThe server decides which rules get this box, so a rule you have just\nwritten grows one after the first Save.',

    audience = 'Who hears this song. Everybody else gets no effect from it --\nand spends no song slot on it, which is the point: an ally holds only as\nmany of this bard\'s songs as its instrument allows (two on an ordinary\nharp or flute, four on a Daurdabla), so Ballad aimed at the mages and\nMarch aimed at the melee is three songs standing instead of two.\nThe server decides which rules get this box, so a rule you have just\nwritten grows one after the first Save.',
    enfeebleBurst = 'Off keeps enfeebling magic (Sleep, Bind, Gravity, Dia...) out of\nthis member\'s magic bursts -- the burst-matching pick considers\nreal nukes only. Rules that name an enfeeble on purpose still fire.',
    runIn = 'On walks a bard to within a yalm of you before it sings, so\nyou are inside the song\'s radius. Off sings from where it stands --\nthis server already widens every party song to four times its\nretail radius, so a bard that stays put usually still covers you.',
    manualWs = 'On empties the automatic weapon-skill list, so this member\nholds its TP until a rule tells it to spend it. Add rules with\n\'Use a weapon skill\' to say when. Off is the automatic spender,\nwhich fires before any rule is read and leaves a weapon-skill\nrule no bar to work with.',

    -- "Lists for" (1.15.0). The format strings carry the member's name and
    -- levels off the wire; the words are the window's.
    listFor = 'Whose job and level the spell list is cut to, and whose Blue Magic and rolls are marked.\nAutomatic follows the member you clicked on the left, then whoever runs this set.\nA set is not tied to one member -- this only shapes the lists.',
    showAll = 'Shows every spell again, including the ones the chosen member\'s jobs never learn. They stay greyed.',
    spellLater = '%s learns this at %s%d, and %s is %s%d now. The rule can be saved today and starts working at that level.',
    spellOtherJob = 'Neither of %s\'s jobs learns this. A rule naming it saves, and stays inert on that member.',
    blueSet = 'Set on %s\'s Blue Magic right now, so a rule naming it can fire.',
    blueUnset = 'Not set on %s, so a rule naming it stays inert -- set it with /toau (or !toau blu) and it starts working.',
    rollUsable = '%s can use this roll today, so a rule naming it can fire.',
    rollUnusable = 'Not usable by %s yet: a squad Corsair rolls only what has been learned on this account, at its level.',
    overflow = 'The server lists the first few inert rules one by one and counts the rest. !squad rules report names every one of them.',
};

--[[
* The clipboard.
*
* GUARDED, NOT ASSUMED. `SetClipboardText` is declared in Ashita's own SDK
* (addons/libs/annotations/SDK/IGuiManager.lua), but this addon reaches players
* through the content feed and runs on whatever Ashita build they installed
* first -- and a nil global called inside the render pass is an error sixty
* times a second until the host unloads the addon. On any build that does not
* have it the boxes are still there to select from, and the sentence says so.
--]]
local function copyToClipboard(text)
    if (type(imgui.SetClipboardText) ~= 'function') then
        state.status    = 'This Ashita build has no clipboard call -- click into the box and press Ctrl-C instead.';
        state.statusBad = true;

        return false;
    end

    local ok = pcall(imgui.SetClipboardText, text);

    if (not ok) then
        state.status    = 'The clipboard refused the code -- click into the box and press Ctrl-C instead.';
        state.statusBad = true;

        return false;
    end

    return true;
end

-- The style's own numbers, guarded: `GetStyle` is a host call and its members
-- are the host's business, so every read of one falls back to Ashita's stock
-- value rather than throwing inside the render pcall. (dwcon's shape.)
local function styleGap(field, axis, fallback)
    local style = imgui.GetStyle();
    local pair  = style ~= nil and style[field] or nil;

    if (pair ~= nil and type(pair[axis]) == 'number') then
        return pair[axis];
    end

    return fallback;
end

local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

-- A dropdown over { {id/key, label, note} } entries. Returns the newly
-- selected entry or nil. `current` is compared against `value(entry)`.
local function pickCombo(id, width, currentLabel, entries, isCurrent)
    local chosen = nil;

    imgui.PushItemWidth(width);

    if (imgui.BeginCombo(id, currentLabel)) then
        for index, entry in ipairs(entries) do
            if (imgui.Selectable(string.format('%s##%s_%d', entry.label, id, index), isCurrent(entry))) then
                chosen = entry;
            end

            tooltipOnHover(entry.note);
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    return chosen;
end

-- The same, with a filter box on top -- for the spell and ability lists,
-- which run to hundreds of names.
--
-- An entry may carry, besides `label` (what the filter matches): `shown`, the
-- text drawn instead (a "(set)" mark); `dim`, drawn greyed but still
-- choosable -- a set stores intent, and a rule for a spell the member has not
-- learned yet is reported, never refused (decision G3); and `why`, its hover.
-- `extras.header()` draws under the filter box and `extras.emptyHint()` answers
-- a sentence to say when nothing matches, or nil (1.15.0, both for the action
-- lists; functions, so neither costs anything while the dropdown is shut).
local function pickComboFiltered(id, width, currentLabel, entries, isCurrent, extras)
    local chosen = nil;

    imgui.PushItemWidth(width);

    if (imgui.BeginCombo(id, currentLabel)) then
        local filter = filterOf(id);

        imgui.PushItemWidth(150);

        -- HINTED (2026-09-06). An unlabelled box at the top of a dropdown of
        -- two hundred names is a box nobody knows is a filter, and the filter
        -- survives the combo closing -- which is useful when refining a search
        -- and baffling when the list looks half empty on the next open.
        imgui.InputTextWithHint('##filter_' .. id, 'type to narrow', filter, 32);
        imgui.PopItemWidth();

        if (extras ~= nil and extras.header ~= nil) then
            extras.header();
        end

        local needle = string.lower(filter[1] or '');
        local shown  = 0;

        for index, entry in ipairs(entries) do
            if (needle == '' or string.find(string.lower(entry.label), needle, 1, true) ~= nil) then
                shown = shown + 1;

                if (entry.dim) then
                    imgui.PushStyleColor(ImGuiCol_Text, COLOR_INERT);
                end

                local hit = imgui.Selectable(string.format('%s##%s_%d', entry.shown or entry.label, id, index), isCurrent(entry));

                if (entry.dim) then
                    imgui.PopStyleColor();
                end

                if (hit) then
                    chosen = entry;
                end

                tooltipOnHover(entry.why);
            end
        end

        -- A dropdown that matched nothing used to be an empty popup: no rows,
        -- no reason, and the box above it easy to miss.
        if (shown == 0) then
            imgui.TextDisabled(string.format('Nothing here matches "%s".', filter[1] or ''));

            local hint = extras ~= nil and extras.emptyHint ~= nil and extras.emptyHint() or nil;

            if (hint ~= nil) then
                imgui.TextDisabled(hint);
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    return chosen;
end

local function markTouched()
    editor.touched   = true;

    -- Any further edit disarms Revert: the player asked "really?" about the
    -- document as it stood then, not about the one they have typed into since.
    editor.armRevert = false;
end

-- One page of the whitelist at a time, in order, driven from the render loop
-- so the answer tracker holds exactly one outstanding page and a lost one is
-- re-asked on its own timeout rather than restarting the fetch.
--
-- A STALE copy is re-fetched the same way (1.15.0, forgetAll): the pages
-- stage into vocabWork beside the copy in use, which is replaced only when the
-- last one lands.
local function needVocab()
    if (vocab ~= nil and not vocabStale) then
        return;
    end

    if (vocabWork == nil) then
        need('vocab', 1, '!dwg vocab');

        return;
    end

    for page = 1, vocabWork.pages do
        if (not vocabWork.got[page]) then
            need('vocab', page, page == 1 and '!dwg vocab' or string.format('!dwg vocab %d', page));

            return;
        end
    end
end

--[[
* Derived views of the world, rebuilt only when the world changes.
*
* THIS IS ALL WORK THAT USED TO HAPPEN SIXTY TIMES A SECOND (2026-09-06). Every
* frame the window rebuilt and sorted the owned-set list, rebuilt and sorted the
* Assign dropdown, rebuilt and sorted the at-home list, walked every assignment
* on the account ONCE PER AT-HOME ROW to count that character's per-job rows,
* and walked all forty shipped sets once per summoned member to name the one it
* is running. None of it can change except when an envelope lands, so all of it
* now hangs off one revision counter that processEnvelope bumps -- the dwah
* view-cache shape, and the reason the counter is bumped for EVERY envelope
* rather than per section is that an envelope is a rare event and a missed
* invalidation is a window showing a set that is gone.
--]]
local derived = { rev = -1 };

local function views()
    if (derived.rev == state.rev) then
        return derived;
    end

    local owned    = {};
    local out      = {};
    local extras   = {};
    local presetById = {};
    local seen     = {};
    local home     = {};
    local targets  = {};

    for _, set in pairs(state.sets) do
        table.insert(owned, { setid = set.setid, name = set.name, label = set.name });
    end

    table.sort(owned, function (a, b) return (a.name or '') < (b.name or ''); end);

    for _, preset in ipairs(state.presets) do
        presetById[preset.id] = preset;
    end

    for _, charid in ipairs(state.memberOrder) do
        local member = state.members[charid];

        if (member ~= nil) then
            out[string.lower(member.name)] = true;
        end
    end

    -- The per-job assignment rows, counted once for every character rather
    -- than once for every character for every character.
    for _, entry in pairs(state.assigns) do
        if (entry.job ~= 0) then
            extras[entry.charid] = (extras[entry.charid] or 0) + 1;
        end
    end

    for _, entry in pairs(state.assigns) do
        if (not seen[entry.charid] and not out[string.lower(entry.name or '')]) then
            seen[entry.charid] = true;

            table.insert(home, entry);
        end
    end

    table.sort(home, function (a, b) return (a.name or '') < (b.name or ''); end);

    -- The Assign dropdown: live members, then everyone at home, then the whole
    -- squad at once. Built here because it is the same two walks.
    local named = {};

    for _, charid in ipairs(state.memberOrder) do
        local member = state.members[charid];

        if (member ~= nil and not named[string.lower(member.name)]) then
            named[string.lower(member.name)] = true;

            table.insert(targets, { key = member.name, label = string.format('%s (out)', member.name) });
        end
    end

    local away = {};

    for _, entry in pairs(state.assigns) do
        local key = string.lower(entry.name or '');

        if (key ~= '' and not named[key]) then
            named[key] = true;

            table.insert(away, { key = entry.name, label = entry.name });
        end
    end

    table.sort(away, function (a, b) return (a.label or '') < (b.label or ''); end);

    for _, entry in ipairs(away) do
        table.insert(targets, entry);
    end

    table.insert(targets, { key = 'all', label = 'the whole squad' });

    derived.rev        = state.rev;
    derived.owned      = owned;
    derived.home       = home;
    derived.extras     = extras;
    derived.presetById = presetById;
    derived.targets    = targets;

    -- The two lists of rows the left pane draws, spelled out here. Both used
    -- to be four string.format calls per row per frame, one of them behind a
    -- table walk (assignedLabel's per-job count) and another behind a walk of
    -- the whole shipped roster (runningLabel).
    local rows = {};

    for _, charid in ipairs(state.memberOrder) do
        local member = state.members[charid];

        if (member ~= nil) then
            local counts = '';

            if (member.installed >= 0) then
                counts = string.format('  %d/%d live', member.installed, member.considered);
            end

            local running;

            if (member.setid ~= 0) then
                local set = state.sets[member.setid];

                running = set ~= nil and set.name or string.format('set #%d', member.setid);
            else
                local preset = presetById[member.presetid];

                running = preset ~= nil and preset.name or 'profile';
            end

            -- The support job since 1.15.0 (the c| record's appended fields):
            -- "Yakapo (BLU99/NIN49)", and exactly what it always said when
            -- there is none or the server predates the field.
            local jobs = string.format('%s%d', JOB_NAMES[member.job] or '?', member.lvl);

            if ((member.sjob or 0) > 0) then
                jobs = string.format('%s/%s%d', jobs, JOB_NAMES[member.sjob] or '?', member.slvl or 0);
            end

            table.insert(rows, {
                charid   = charid,
                name     = member.name,
                label    = string.format('%s (%s)##m%d', member.name, jobs, charid),
                subtitle = string.format('   > %s%s', running, counts),
                measured = counts ~= '',
            });
        end
    end

    derived.members = rows;

    for _, entry in ipairs(home) do
        local base  = state.assigns[entry.charid .. ':0'];
        local label;

        if (base ~= nil and base.kind == 'set') then
            label = base.ref or 'automatic';
        elseif (base ~= nil and base.kind == 'preset') then
            label = string.match(base.ref or '', '^preset:(.+)$') or base.ref or 'automatic';
        else
            label = 'automatic';
        end

        if ((extras[entry.charid] or 0) > 0) then
            label = string.format('%s (+%d per-job)', label, extras[entry.charid]);
        end

        entry.row      = string.format('%s##h%d', entry.name, entry.charid);
        entry.subtitle = string.format('   > %s', label);
    end

    return derived;
end

-- The two tabs that cannot draw a control without the whitelist say the same
-- thing while they wait for it, and the same thing again once waiting has
-- stopped being the truth.
local function vocabNotice()
    -- The fetch itself is advanced by renderWindow, once a frame for every tab
    -- (1.15.0); asking twice a frame would age the answer clock twice as fast.
    if (gaveUp('vocab')) then
        imgui.TextWrapped('The server did not answer for the rule vocabulary, and this tab cannot draw a single dropdown without it. Press Refresh above to ask again.');
    else
        imgui.Text('Fetching the rule vocabulary from the server...');
    end
end

local function runningLabel(member)
    if (member.setid ~= 0) then
        local set = state.sets[member.setid];

        return set ~= nil and set.name or string.format('set #%d', member.setid);
    end

    local preset = views().presetById[member.presetid];

    return preset ~= nil and preset.name or 'profile';
end

local function tryLoadFor(charid)
    if (editor.touched) then
        state.status    = 'Save or revert your edits before switching sets.';
        state.statusBad = true;

        return;
    end

    local member = state.members[charid];

    if (member ~= nil and member.setid ~= 0) then
        local set = state.sets[member.setid];

        if (set ~= nil) then
            loadIntoEditor(set.name);
        end

        return;
    end

    if (member ~= nil and member.presetid ~= 0) then
        local label = runningLabel(member);

        if (label ~= 'profile') then
            loadIntoEditor(label);
        end

        return;
    end

    local base = state.assigns[charid .. ':0'];

    if (base ~= nil and base.kind ~= 'none' and base.ref ~= '') then
        loadIntoEditor(base.ref);
    end
end

--[[
* The hints strip: one compact line per summoned member with hints, chips
* derived from the record's FIELDS -- `kind` and `distance` exist on the wire
* precisely so a client can label a hint without parsing its prose
* (dwg_protocol.md) -- and the finished sentences, verbatim, on the hover.
--]]
local HINT_STRIP_CHIPS   = 3;
local HINT_TOOLTIP_LINES = 8;

local function hintChip(hint)
    if (hint.kind == 'learn') then
        return 'scroll';
    elseif (hint.kind == 'fit') then
        return 'set';
    elseif (hint.kind == 'sub') then
        return string.format('sub %dlv', hint.distance);
    elseif (hint.kind == 'tier') then
        return string.format('tier %dlv', hint.distance);
    end

    -- `level` and `abil` are both a number of main-job levels away.
    return string.format('%dlv', hint.distance);
end

-- The chip line, formatted once per answer rather than once per frame.
-- `state.hints[charid]` is a fresh table for every hints envelope, so caching
-- the finished line ON that table is invalidated by the only thing that can
-- change it. (2026-09-06: this ran through three string.format calls, a table
-- and a concat for every member with hints, sixty times a second.)
local function hintStrip(list)
    if (list.line ~= nil) then
        return list.line;
    end

    local chips = {};

    for index = 1, math.min(#list, HINT_STRIP_CHIPS) do
        table.insert(chips, hintChip(list[index]));
    end

    local text = table.concat(chips, ', ');

    if (#list > HINT_STRIP_CHIPS) then
        text = string.format('%s +%d', text, #list - HINT_STRIP_CHIPS);
    end

    list.line = string.format('   ^ %s', text);

    return list.line;
end

local function hintTooltip(name, list)
    local lines = {};

    for index = 1, math.min(#list, HINT_TOOLTIP_LINES) do
        local hint = list[index];

        table.insert(lines, hint.text);

        if (hint.command ~= nil) then
            table.insert(lines, '  ' .. hint.command);
        end
    end

    if (#list > HINT_TOOLTIP_LINES) then
        table.insert(lines, string.format('...and %d more -- !squad hints %s lists everything.',
            #list - HINT_TOOLTIP_LINES, name));
    end

    return table.concat(lines, '\n');
end

local function leftPane()
    -- ASKED FROM THE PANE THAT DRAWS THE ANSWER (moved here 2026-09-06). These
    -- three used to be asked from editorTab, and this pane draws all three:
    -- `rules` is the summoned members, `list` is every character at home and
    -- the sets they are assigned, `presets` is what runningLabel names a member
    -- by. Asked from a tab body, they were asked only while the Editor tab was
    -- showing -- so a player whose window reopened on Party or Share (ImGui
    -- remembers the tab) looked at an empty left pane until they clicked
    -- Editor. Worse, editorTab returns BEFORE them while the vocabulary is
    -- still arriving, so on a cold open the whole squad waited out eleven
    -- paged vocabulary reads at one line per 1.2 seconds before the first
    -- member appeared. `need` deduplicates by verb, so the tab bodies that
    -- still ask cost nothing.
    need('rules', 0, '!dwg');
    need('list', 0, '!dwg list');
    need('presets', 0, '!dwg presets');

    imgui.BeginChild('##dwg_chars', { 205, 0 }, ImGuiChildFlags_Borders);

    imgui.TextDisabled('Squad -- out now');
    tooltipOnHover(TIPS.outNow);

    if (#state.memberOrder == 0) then
        imgui.Text('  (nobody summoned)');
    end

    -- Asked from the pane that draws the answer, like every other read.
    -- Only with members out: hints are about running sets, and `!dwg hints`
    -- on an empty squad is a refusal nobody needs to see every frame.
    if (not hintsUnsupported and #state.memberOrder > 0) then
        need('hints', 0, '!dwg hints');
    end

    for _, row in ipairs(views().members) do
        if (imgui.Selectable(row.label, state.selected == row.charid)) then
            state.selected = row.charid;
            state.assignTo = row.name;

            tryLoadFor(row.charid);
        end

        imgui.TextDisabled(row.subtitle);
        tooltipOnHover(row.measured and TIPS.liveCount or TIPS.assigned);

        -- The server's count of the inert rules it did not list one by one
        -- (k| ordinal -1, 1.15.0) -- about this member, so drawn under it,
        -- wrapped to the pane, in the server's own words.
        local verdicts = state.verdicts[row.charid];

        if (verdicts ~= nil and verdicts.list[-1] ~= nil) then
            imgui.PushTextWrapPos(0);
            imgui.TextColored(COLOR_INERT, verdicts.list[-1]);
            imgui.PopTextWrapPos();
            tooltipOnHover(TIPS.overflow);
        end

        local hintList = state.hints[row.charid];

        if (hintList ~= nil and #hintList > 0) then
            imgui.TextColored(COLOR_HINT, hintStrip(hintList));

            -- BUILT ON THE HOVER, NOT BEFORE IT (2026-09-06). tooltipOnHover
            -- takes its text as an ARGUMENT, so passing a call to it built the
            -- whole eight-line card -- a table, up to seventeen inserts and a
            -- concat, per member -- on every frame of a window nobody was
            -- pointing at.
            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(hintTooltip(row.name, hintList));
            end
        end
    end

    imgui.Separator();
    imgui.TextDisabled('At home');
    tooltipOnHover(TIPS.atHome);

    -- Every account character the a| stream named, minus the ones standing in
    -- the world above. Built with the rest of the derived views.
    for _, entry in ipairs(views().home) do
        if (imgui.Selectable(entry.row, state.selected == entry.charid)) then
            state.selected = entry.charid;
            state.assignTo = entry.name;

            tryLoadFor(entry.charid);
        end

        imgui.TextDisabled(entry.subtitle);
        tooltipOnHover(TIPS.assigned);
    end

    imgui.EndChild();
end

-- Who an Assign lands on. Split out of assignControls 2026-09-06 so the
-- Shipped sets tab can offer it too: that tab has an Assign button on every
-- row and used to have no way to choose the target, so its own refusal told
-- the player to go and use a box on a different tab.
local function assignTargetCombo(id)
    -- Live members, then everyone at home, then the whole squad at once --
    -- built with the rest of the derived views, because it is the same two
    -- walks over the same two tables.
    local targets = views().targets;
    local current = state.assignTo or (targets[1] ~= nil and targets[1].key or nil);

    state.assignTo = current;

    local currentLabel = current or '(pick one)';

    for _, entry in ipairs(targets) do
        if (entry.key == current) then
            currentLabel = entry.label;
        end
    end

    local picked = pickCombo('##assign_' .. id, 150, currentLabel, targets,
        function (entry) return entry.key == current; end);

    tooltipOnHover(TIPS.assignWho);

    if (picked ~= nil) then
        state.assignTo = picked.key;
    end
end

local function assignControls(id, ref)
    assignTargetCombo(id);

    imgui.SameLine();

    if (imgui.Button('Assign##' .. id)) then
        if (state.assignTo ~= nil and ref ~= nil) then
            -- SAY WHICH COPY IS BEING ASSIGNED (2026-09-06). `use` installs
            -- what the SERVER holds, and the editor is a local document -- so
            -- assigning a set with unsaved edits hands the member the version
            -- before them, silently, while the screen shows the version after.
            local stale = editor.touched and editor.name ~= nil
                and string.lower(ref) == string.lower(editor.name);

            startPlan({ string.format('!dwg use %s "%s"', state.assignTo, ref) },
                stale
                    and string.format('Assigning %s -- the SAVED copy. Your unsaved edits are not in it.', ref)
                    or string.format('Assigning %s...', ref));
        end
    end

    tooltipOnHover(TIPS.assign);
end

-- The range sentence for one condition, spelled once and kept on the
-- vocabulary entry it describes. Both condition slots drew it for every row on
-- every frame; it only changes when the whitelist does, and the entry is
-- replaced wholesale by a rebuild.
local function conditionRangeTip(entry)
    if (entry.rangeTip == nil) then
        entry.rangeTip = string.format(TIPS.condRange, entry.arg.min, entry.arg.max, entry.arg.unit or '');
    end

    return entry.rangeTip;
end

--[[
* One rule row of the editor table. Everything writes into the local document
* and nothing but Save talks to the server.
*
* DROPPING THE SECOND CONDITION MEANS ITS ARGUMENT AND ITS AND/OR TOO
* (2026-09-06). Both places that drop it -- the x button below and a solo
* condition chosen in the first slot -- used to clear the condition id alone.
* The store keeps `arg2 or 0` and `logic or 0` where there is no second
* condition, and the addon omits both from the `add` line for the same reason,
* so a document that carried either afterwards differed from a server copy
* that was exactly what it had just written: every Save rewrote the rule and
* answered "Saved with differences", forever, because that branch leaves the
* document dirty. ruleKey normalises both as well, so a document that arrives
* carrying them still diffs clean.
--]]
local function dropSecondCondition(rule)
    rule.cond2 = NO_CONDITION;
    rule.arg2  = 0;
    rule.logic = 0;
end

local function conditionCell(rule, row, locked)
    if (locked) then
        -- A canned pairing owns its condition; showing a dropdown would offer
        -- a choice the grammar will refuse.
        imgui.TextDisabled('(built into the pairing)');

        return;
    end

    local entry = vocab.conditionById[rule.cond1];
    local label = entry ~= nil and entry.label or string.format('#%d', rule.cond1);

    local picked = pickCombo(string.format('##cond1_%d', row), 150, label, vocab.conditions,
        function (candidate) return entry ~= nil and candidate.id == entry.id; end);

    if (picked ~= nil and (entry == nil or picked.id ~= entry.id)) then
        rule.cond1 = picked.id;
        rule.arg1  = picked.arg.kind == 'number' and picked.arg.min or 0;

        if (picked.arg.kind == 'pick') then
            local list = vocab.pickers[picked.arg.picker];

            rule.arg1 = list ~= nil and list[1] ~= nil and list[1].id or 0;
        end

        -- A solo condition is a whole rule's worth of When on its own -- the
        -- timer's clock is spent by evaluation, not firing, and the server
        -- would refuse the pair anyway. Dropping the second half here is the
        -- refusal the player never has to read.
        if (picked.solo) then
            dropSecondCondition(rule);
        end

        markTouched();
    end

    entry = vocab.conditionById[rule.cond1];

    -- The argument widget, shaped by the condition's declared domain.
    if (entry ~= nil and entry.arg.kind == 'number') then
        imgui.SameLine();

        local buffer = T{ rule.arg1 };

        imgui.PushItemWidth(70);

        if (imgui.InputInt(string.format('##arg1_%d', row), buffer, 0, 0)) then
            local value = tonumber(buffer[1]);

            -- INTEGRALITY IS PART OF THE RANGE TEST, NOT A FLOOR BEFORE IT.
            -- math.floor(nan) is nan and every comparison against nan is
            -- false, so a floored parse walks straight past a min/max clamp
            -- and reaches string.format, which writes a 64-bit sentinel into
            -- the command. squad_rules_cmd.lua's move verb states the same
            -- rule about the same trap, in its own words.
            if (value == nil or value ~= math.floor(value)) then
                value = entry.arg.min;
            end

            rule.arg1 = math.max(math.min(value, entry.arg.max), entry.arg.min);

            markTouched();
        end

        imgui.PopItemWidth();
        tooltipOnHover(conditionRangeTip(entry));
    elseif (entry ~= nil and entry.arg.kind == 'pick') then
        imgui.SameLine();

        local list = vocab.pickers[entry.arg.picker] or {};
        local byId = vocab.pickerById[entry.arg.picker] or {};
        local hit  = byId[rule.arg1];

        -- Filtered since 1.8: the status picker outgrew a bare list when the
        -- job-ability shelf landed (2026-08-26).
        local picked2 = pickComboFiltered(string.format('##arg1p_%d', row), 120,
            hit ~= nil and hit.label or '(pick)', list,
            function (candidate) return candidate.id == rule.arg1; end);

        if (picked2 ~= nil) then
            rule.arg1 = picked2.id;

            markTouched();
        end
    end

    -- The second condition: present when the sentinel says so, offered when
    -- the first condition may share a rule at all.
    --
    -- It starts a new line inside the cell -- there is deliberately no SameLine
    -- before the and/or combo below -- and that line is the widest thing the
    -- When column ever has to hold: the and/or combo, the condition, its
    -- argument and the drop button, a shade over three hundred and forty
    -- pixels. The column stretches for exactly that reason (2026-09-06); at the
    -- fixed 320 it used to carry, the drop button of a picker-argument second
    -- condition fell off the end of the cell, and an ImGui table cell clips to
    -- its column.
    if (rule.cond2 ~= NO_CONDITION) then
        local logic  = vocab.logicById[rule.logic];
        local picked3 = pickCombo(string.format('##logic_%d', row), 55,
            logic ~= nil and logic.key or 'and', vocab.logic,
            function (candidate) return logic ~= nil and candidate.id == logic.id; end);

        if (picked3 ~= nil) then
            rule.logic = picked3.id;

            markTouched();
        end

        imgui.SameLine();

        local second = vocab.conditionById[rule.cond2];

        -- Solo conditions are excluded from the second slot for the same
        -- reason they clear it from the first. Built once with the vocabulary,
        -- not once per row per frame.
        local eligible = vocab.nonSolo;

        local picked4 = pickCombo(string.format('##cond2_%d', row), 150,
            second ~= nil and second.label or string.format('#%d', rule.cond2), eligible,
            function (candidate) return second ~= nil and candidate.id == second.id; end);

        if (picked4 ~= nil and (second == nil or picked4.id ~= second.id)) then
            rule.cond2 = picked4.id;
            rule.arg2  = picked4.arg.kind == 'number' and picked4.arg.min or 0;

            if (picked4.arg.kind == 'pick') then
                local list = vocab.pickers[picked4.arg.picker];

                rule.arg2 = list ~= nil and list[1] ~= nil and list[1].id or 0;
            end

            markTouched();
        end

        second = vocab.conditionById[rule.cond2];

        if (second ~= nil and second.arg.kind == 'number') then
            imgui.SameLine();

            local buffer = T{ rule.arg2 };

            imgui.PushItemWidth(70);

            if (imgui.InputInt(string.format('##arg2_%d', row), buffer, 0, 0)) then
                local value = tonumber(buffer[1]);

                -- Integrality first, for the reason the first slot states.
                if (value == nil or value ~= math.floor(value)) then
                    value = second.arg.min;
                end

                rule.arg2 = math.max(math.min(value, second.arg.max), second.arg.min);

                markTouched();
            end

            imgui.PopItemWidth();
            tooltipOnHover(conditionRangeTip(second));
        elseif (second ~= nil and second.arg.kind == 'pick') then
            imgui.SameLine();

            local list = vocab.pickers[second.arg.picker] or {};
            local byId = vocab.pickerById[second.arg.picker] or {};
            local hit  = byId[rule.arg2];

            -- Filtered since 1.8, like the first condition's arg above.
            local picked5 = pickComboFiltered(string.format('##arg2p_%d', row), 120,
                hit ~= nil and hit.label or '(pick)', list,
                function (candidate) return candidate.id == rule.arg2; end);

            if (picked5 ~= nil) then
                rule.arg2 = picked5.id;

                markTouched();
            end
        end

        imgui.SameLine();

        if (imgui.SmallButton(string.format('x##nocond2_%d', row))) then
            dropSecondCondition(rule);

            markTouched();
        end

        tooltipOnHover(TIPS.dropCond2);
    else
        local first = vocab.conditionById[rule.cond1];

        if (first == nil or not first.solo) then
            imgui.SameLine();

            if (imgui.SmallButton(string.format('+##addcond_%d', row))) then
                rule.logic = vocab.logic[1] ~= nil and vocab.logic[1].id or 0;

                -- The first non-solo condition is the sane blank.
                local candidate = vocab.nonSolo[1];

                if (candidate ~= nil) then
                    rule.cond2 = candidate.id;
                    rule.arg2  = candidate.arg.kind == 'number' and candidate.arg.min or 0;
                end

                markTouched();
            end

            tooltipOnHover(TIPS.addCond2);
        end
    end
end

-- The blank a condition slot falls back to: the first entry the whitelist
-- lists, with whatever argument that entry's own domain calls for.
local function resetCondition(rule)
    local first = vocab.conditions[1];

    rule.cond1 = first ~= nil and first.id or 0;
    rule.arg1  = 0;
    rule.cond2 = NO_CONDITION;
    rule.arg2  = 0;
    rule.logic = 0;

    if (first == nil) then
        return;
    end

    if (first.arg.kind == 'number') then
        rule.arg1 = first.arg.min;
    elseif (first.arg.kind == 'pick') then
        local list = vocab.pickers[first.arg.picker];

        rule.arg1 = list ~= nil and list[1] ~= nil and list[1].id or 0;
    end
end

--[[
* "Lists for" (1.15.0): whose job and level the spell list is cut to.
*
* THE EDITOR EDITS A SET, NOT A MEMBER, and a set can be assigned to anybody,
* so there is no one right answer -- which is why the choice is explicit and
* shown, rather than inferred and hidden. Automatic resolves, in order, to the
* summoned member the player last clicked on the left (clicking a member is how
* a player opens the set that member runs, so it is nearly always who they are
* writing for), then to the first summoned member running THIS set, then to
* nobody -- and nobody means the whole list, which is what every version
* before this one showed. A member picked explicitly who is dismissed since
* falls back to Automatic rather than to a stale job.
*
* A member target carries the job levels of the c| record (support job since
* the two appended fields) and the u| lists; a bare job target is that job at
* any level, for writing a set for somebody at home, and carries no lists.
--]]
local function memberTarget(member)
    return {
        name  = member.name,
        job   = member.job,
        lvl   = member.lvl,
        sjob  = member.sjob or 0,
        slvl  = member.slvl or 0,
        lists = member.lists,
    };
end

local function listTarget()
    local pick = editor.listFor;

    if (pick == 'all') then
        return nil;
    end

    if (type(pick) == 'number' and state.members[pick] ~= nil) then
        return memberTarget(state.members[pick]);
    end

    local job = type(pick) == 'string' and tonumber(string.match(pick, '^job:(%d+)$')) or nil;

    if (job ~= nil and job > 0 and JOB_NAMES[job] ~= nil) then
        return { name = JOB_NAMES[job], job = job, lvl = 99, sjob = 0, slvl = 0, anyLevel = true };
    end

    local selected = state.selected ~= nil and state.members[state.selected] or nil;

    if (selected ~= nil) then
        return memberTarget(selected);
    end

    if (editor.setid ~= 0) then
        for _, charid in ipairs(state.memberOrder) do
            local member = state.members[charid];

            if (member ~= nil and member.setid == editor.setid) then
                return memberTarget(member);
            end
        end
    end

    return nil;
end

-- "Yakapo (BLU99/NIN49)", "any BLU", "everything".
local function targetLabel(target)
    if (target == nil) then
        return 'everything';
    end

    if (target.anyLevel) then
        return string.format('any %s', target.name);
    end

    if ((target.sjob or 0) > 0) then
        return string.format('%s (%s%d/%s%d)', target.name, JOB_NAMES[target.job] or '?', target.lvl,
            JOB_NAMES[target.sjob] or '?', target.slvl);
    end

    return string.format('%s (%s%d)', target.name, JOB_NAMES[target.job] or '?', target.lvl);
end

-- The module-level switch behind "Show everything": one for the window, not
-- one per row, because a player who wants the whole list wants it everywhere.
local listShowAll = T{ false };

-- How a target reaches one spell: 'now', 'later' (with the job and level it
-- is waiting on), or nil when neither of its jobs learns it. A spell whose
-- levels the client would not give up is 'now' -- the server is the judge.
local function spellReach(entry, target)
    if (entry.levels == nil) then
        return 'now';
    end

    local wait = nil;

    for _, pair in ipairs({ { target.job, target.lvl }, { target.sjob, target.slvl } }) do
        local job, level = pair[1], pair[2] or 0;
        local need       = (job ~= nil and job > 0) and entry.levels[job] or nil;

        if (type(need) == 'number' and need >= 1 and need <= 99) then
            if (need <= level) then
                return 'now';
            end

            if (wait == nil or need < wait.level) then
                wait = { job = job, level = need };
            end
        end
    end

    if (wait ~= nil) then
        return 'later', wait;
    end

    return nil;
end

--[[
* The spell or ability list, shaped for the target. Cached on everything that
* can change it -- the resource list itself, the target's identity, jobs,
* levels and lists (a fresh `lists` table arrives with every c|), and the
* show-everything switch -- because it is drawn per row per frame and walks
* nine hundred spells when it is rebuilt.
*
* Spells: the target's jobs only, unless the switch is on; a spell above the
* target's level greyed with the level it is waiting on. A Blue Mage's SET
* spells first and marked, its unset ones greyed -- the server's `b` list.
* Abilities cannot be cut by job (IAbility carries none), so they are all
* shown; a Corsair's usable rolls come first and marked, its other rolls
* greyed -- the server's `r` list, rolls told apart by their shared recast.
--]]
local shaped   = {};
local NO_LISTS = {};     -- a bare job target's lists: none, and never written to

local function shapedList(resource, target)
    local base = actionList(resource);

    if (target == nil) then
        return base;
    end

    -- Compared field by field rather than through a built key: this runs for
    -- every exact-action row on every frame, and a string key would be a
    -- table and a concat each time to learn that nothing changed.
    local lists = target.lists or NO_LISTS;
    local hit   = shaped[resource];

    if (hit ~= nil and hit.base == base and hit.name == target.name and hit.job == target.job
            and hit.lvl == target.lvl and hit.sjob == target.sjob and hit.slvl == target.slvl
            and hit.b == lists.b and hit.r == lists.r and hit.all == listShowAll[1]) then
        return hit.list, hit.hidden;
    end

    local first, rest = {}, {};
    local hidden      = 0;

    local function item(entry)
        return { id = entry.id, label = entry.label };
    end

    if (resource == 'spell') then
        local blue = lists.b;

        for _, entry in ipairs(base) do
            local reach, wait = spellReach(entry, target);

            if (reach == nil and not listShowAll[1]) then
                hidden = hidden + 1;
            else
                local out = item(entry);

                if (blue ~= nil and entry.skill == BLUE_MAGIC_SKILL and reach ~= nil) then
                    if (blue[entry.id]) then
                        out.shown = entry.label .. '  (set)';
                        out.why   = string.format(TIPS.blueSet, target.name);

                        table.insert(first, out);
                    else
                        out.dim = true;
                        out.why = string.format(TIPS.blueUnset, target.name);

                        table.insert(rest, out);
                    end
                else
                    if (reach == 'later') then
                        out.dim = true;
                        out.why = string.format(TIPS.spellLater, target.name, JOB_NAMES[wait.job] or '?', wait.level,
                            target.name, JOB_NAMES[wait.job] or '?', wait.job == target.job and target.lvl or target.slvl);
                    elseif (reach == nil) then
                        out.dim = true;
                        out.why = string.format(TIPS.spellOtherJob, target.name);
                    end

                    table.insert(rest, out);
                end
            end
        end
    else
        local rolls = lists.r;

        for _, entry in ipairs(base) do
            local out = item(entry);

            if (rolls ~= nil and entry.recast == ROLL_RECAST_TIMER) then
                if (rolls[entry.id]) then
                    out.shown = entry.label .. '  (usable)';
                    out.why   = string.format(TIPS.rollUsable, target.name);

                    table.insert(first, out);
                else
                    out.dim = true;
                    out.why = string.format(TIPS.rollUnusable, target.name);

                    table.insert(rest, out);
                end
            else
                table.insert(rest, out);
            end
        end
    end

    for _, entry in ipairs(rest) do
        table.insert(first, entry);
    end

    -- Not cached while the resource list is still empty: the DATs had not
    -- answered, and an empty list cached here would outlive their answer.
    if (#base > 0) then
        shaped[resource] = {
            base = base, name = target.name, job = target.job, lvl = target.lvl, sjob = target.sjob,
            slvl = target.slvl, b = lists.b, r = lists.r, all = listShowAll[1],
            list = first, hidden = hidden,
        };
    end

    return first, hidden;
end

-- The "Lists for" combo's entries: Automatic, Everything, every summoned
-- member, then every job at any level. Rebuilt with the derived views.
local listForEntries = { rev = -1, list = {} };

local function listForChoices()
    if (listForEntries.rev == state.rev) then
        return listForEntries.list;
    end

    local list = {
        { key = 'auto', label = 'Automatic' },
        { key = 'all',  label = 'Everything' },
    };

    for _, charid in ipairs(state.memberOrder) do
        local member = state.members[charid];

        if (member ~= nil) then
            table.insert(list, { key = charid, label = targetLabel(memberTarget(member)) });
        end
    end

    for job = 1, #JOB_NAMES do
        table.insert(list, { key = 'job:' .. job, label = string.format('Any %s', JOB_NAMES[job]) });
    end

    listForEntries.rev  = state.rev;
    listForEntries.list = list;

    return list;
end

local function listForControl()
    local target  = listTarget();
    local current = editor.listFor;
    local label;

    -- A member picked by hand who has since been dismissed reads as what it
    -- falls back to, Automatic, rather than as a member who is not there.
    if (current == nil or (type(current) == 'number' and state.members[current] == nil)) then
        label = string.format('Automatic: %s', targetLabel(target));
    elseif (current == 'all') then
        label = 'Everything';
    else
        label = targetLabel(target);
    end

    imgui.Text('Lists for');
    tooltipOnHover(TIPS.listFor);
    imgui.SameLine();

    local picked = pickCombo('##listfor', 200, label, listForChoices(),
        function (entry) return (entry.key == 'auto' and current == nil) or entry.key == current; end);

    tooltipOnHover(TIPS.listFor);

    if (picked ~= nil) then
        editor.listFor = picked.key ~= 'auto' and picked.key or nil;
    end
end

-- What the open action dropdown says about its own shaping. Built once and
-- handed to pickComboFiltered by reference, with the target it is about in
-- two upvalues, because the dropdown is drawn per row per frame and only one
-- is ever open: a closure and a format per row per frame would be paid for a
-- popup nobody is looking at. Both halves run only while it IS open.
local spellListFor    = nil;
local spellListHidden = 0;

local SPELL_LIST_EXTRAS = {
    header = function ()
        -- One id for every row: only one dropdown can be open at a time.
        imgui.Checkbox('Show everything##showall', listShowAll);
        tooltipOnHover(TIPS.showAll);
        imgui.SameLine();
        imgui.TextDisabled(string.format('for %s', targetLabel(spellListFor)));
    end,

    emptyHint = function ()
        if (spellListHidden == 0 or spellListFor == nil) then
            return nil;
        end

        return string.format('%d spell%s %s never learns %s hidden -- tick Show everything.',
            spellListHidden, spellListHidden == 1 and '' or 's', spellListFor.name,
            spellListHidden == 1 and 'is' or 'are');
    end,
};

-- The blood pacts and Ready moves the ability list no longer carries
-- (PET_COMMAND_FIRST) are where a player will look for them first, so a
-- search that finds nothing says where they went -- naming the Do entry the
-- vocabulary actually calls it, when the server has one.
local ABILITY_LIST_EXTRAS = {
    emptyHint = function ()
        for _, candidate in ipairs(vocab ~= nil and vocab.kinds or {}) do
            if (candidate.selectorKey == 'bloodpact') then
                return string.format('Blood pacts and pet moves are not job abilities here -- a summoner\'s are under "%s".',
                    candidate.label);
            end
        end

        return 'Blood pacts and pet moves are not job abilities here.';
    end,
};

local function actionCell(rule, row, target)
    local kind   = kindOf(rule);
    local picked = pickCombo(string.format('##kind_%d', row), 175,
        kind ~= nil and kind.label or string.format('engine %d/%d', rule.reaction, rule.selector),
        vocab.kinds,
        function (candidate) return kind ~= nil and candidate.reaction == kind.reaction and candidate.selector == kind.selector; end);

    if (picked ~= nil and (kind == nil or picked.reaction ~= kind.reaction or picked.selector ~= kind.selector)) then
        local wasPinned = kind ~= nil and kind.pinned ~= nil;

        rule.reaction = picked.reaction;
        rule.selector = picked.selector;
        rule.actionid = 0;

        if (picked.canned ~= nil) then
            rule.actionid = picked.actionid;

            -- A pairing that carries its own condition takes the rule's When
            -- with it -- stored exactly as the server will store it, so the
            -- diff sees the same rule the read-back will contain.
            if (picked.pinned ~= nil) then
                rule.cond1 = picked.pinned;
                rule.arg1  = 0;
                rule.cond2 = NO_CONDITION;
                rule.arg2  = 0;
                rule.logic = 0;
            end
        elseif (picked.arg.kind == 'pick') then
            local list = vocab.pickers[picked.arg.picker];

            rule.actionid = list ~= nil and list[1] ~= nil and list[1].id or 0;
        end

        -- LEAVING A PAIRING THAT OWNED ITS CONDITION (2026-09-06). A pinned
        -- pairing stores a condition the whitelist does not offer: samba's is
        -- id 23 and there is no v|c record for it, because it is not a
        -- condition a player may choose. Switching the Do dropdown away left
        -- that id sitting in the When column, where it rendered as "#23" and
        -- made the WHOLE document unsaveable -- "Rule 1 cannot be saved: it
        -- uses a condition (#23) the vocabulary no longer lists" -- about a
        -- condition the player had never chosen and could only escape by
        -- noticing they had to touch a second dropdown.
        if (wasPinned and picked.pinned == nil) then
            resetCondition(rule);
        end

        markTouched();
    end

    if (kind ~= nil and kind.canned ~= nil) then
        tooltipOnHover(kind.canned.note);
    end

    kind = kindOf(rule);

    if (kind == nil) then
        return;
    end

    if (kind.arg.kind == 'pick') then
        imgui.SameLine();

        local list = vocab.pickers[kind.arg.picker] or {};
        local byId = vocab.pickerById[kind.arg.picker] or {};
        local hit  = byId[rule.actionid];

        -- A CANNED PAIRING'S ARGUMENT IS OPTIONAL (1.12), and the way back to
        -- "no argument" has to be in the dropdown or it is not a choice the
        -- player can unmake. The entry is built HERE rather than shipped in
        -- the picker: no picker entry may have id 0 (the server's own harness
        -- pins that, because 0 is how every other action kind spells "nothing
        -- picked yet"), so the one place it can honestly exist is the one
        -- control where 0 is a real answer.
        --
        -- "THEIR OWN PET", NOT "THEIR BEST AVATAR" (1.15.0). Both pairings
        -- that take an argument draw from the avatar picker, but their id 0 is
        -- the member's OWN pet -- an automaton on a Puppetmaster, a wyvern on a
        -- Dragoon, whatever is out for Release -- and the old label told a
        -- Puppetmaster the pairing was about summoners.
        local anyLabel = kind.arg.picker == 'avatar' and 'Their own pet' or 'Their own';

        if (kind.canned ~= nil) then
            local widened = { { key = '', id = kind.canned.actionid, label = anyLabel } };

            for _, entry in ipairs(list) do
                table.insert(widened, entry);
            end

            list = widened;
        end

        -- Filtered since 1.8: the weapon-skill picker runs to 208 names now
        -- that the relic/mythic/empyrean tier is in it (2026-08-26).
        local pickedArg = pickComboFiltered(string.format('##act_%d', row), 130,
            hit ~= nil and hit.label or (kind.canned ~= nil and anyLabel or '(pick)'), list,
            function (candidate) return candidate.id == rule.actionid; end);

        if (pickedArg ~= nil) then
            rule.actionid = pickedArg.id;

            markTouched();
        end
    elseif (kind.arg.kind == 'action') then
        imgui.SameLine();

        local resource = kind.reactionKey == 'ability' and 'ability' or 'spell';
        local current;

        -- Split for the third time, same reason: an ability id this client
        -- has no name for must read as '(pick)', never as a spell that
        -- happens to share the number.
        if (rule.actionid ~= 0) then
            if (resource == 'ability') then
                current = abilityName(rule.actionid);
            else
                current = spellName(rule.actionid);
            end
        end

        -- Shaped for whoever "Lists for" names (1.15.0); the whole list when
        -- that is nobody. What the combo says above the names, and when
        -- nothing matches, is about the shaping, so the player can always see
        -- why a name they expected is missing and how to bring it back.
        local entries, hidden = shapedList(resource, target);
        local extras = nil;

        if (target ~= nil and resource == 'spell') then
            spellListFor    = target;
            spellListHidden = hidden or 0;
            extras          = SPELL_LIST_EXTRAS;
        elseif (resource == 'ability') then
            extras = ABILITY_LIST_EXTRAS;
        end

        local pickedArg = pickComboFiltered(string.format('##act_%d', row), 150,
            current or '(pick)', entries,
            function (candidate) return candidate.id == rule.actionid; end, extras);

        if (pickedArg ~= nil) then
            rule.actionid = pickedArg.id;

            markTouched();
        end
    end
end

--[[
* [Sings to] -- the song audience (1.11, 2026-09-07).
*
* Its own cell function rather than a tail of actionCell, because actionCell
* returns early on an unrecognised action kind and this strip must draw for
* every rule the server called a party song, recognised kind or not.
*
* DRAWN ONLY WHERE BOTH LATCHES ARE UP: the server sent group records
* (audienceGroups) and the server called THIS rule a party song
* (rule.audience ~= nil). Anything else renders nothing at all -- not a
* disabled control -- because a rule that would ignore the mask should not
* advertise one.
*
* A COMBO HOLDING CHECKBOXES, not a row of them: the Do column is shared with
* two dropdowns already, and three labelled checkboxes inline pushed the
* buttons column off the right edge at the window's default width, which is
* the regression 2026-09-06 spent a round fixing. The preview text says the
* current answer, so the row still reads without opening anything.
*
* THE LAST GROUP CANNOT BE CLEARED. An empty mask is a song nobody hears; the
* server clamps it back to everyone, so honouring the click here would show a
* state the next read-back contradicts.
--]]
local function audienceCell(rule, row)
    local groups = audienceGroups();

    if (groups == nil or rule.audience == nil) then
        return;
    end

    imgui.SameLine();
    imgui.PushItemWidth(110);

    if (imgui.BeginCombo(string.format('##aud_%d', row), audienceLabel(rule.audience))) then
        for _, entry in ipairs(groups) do
            local on = T{ audienceHas(rule.audience, entry.id) };

            if (imgui.Checkbox(string.format('%s##aud_%d_%d', entry.label, row, entry.id), on)) then
                if (on[1]) then
                    rule.audience = rule.audience + entry.id;

                    markTouched();
                elseif (rule.audience > entry.id) then
                    rule.audience = rule.audience - entry.id;

                    markTouched();
                end
            end

            tooltipOnHover(entry.note);
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    tooltipOnHover(TIPS.audience);
end

--[[
* [Refresh] -- the song refresh threshold (1.14, 2026-09-11).
*
* Its own cell for the same reason [Sings to] has one, and behind the same two
* latches: the server sent a number for THIS rule (rule.refresh ~= nil, which
* is the `-`/number the r| record carries) and the ceiling came off the v|h
* caps record. Nothing drawn otherwise -- not a disabled box -- because a rule
* the song layer does not keep up has nothing to refresh.
*
* AN INPUT BOX, the retry column's own control: the number is seconds and a
* player who wants twenty types twenty. CLAMPED HERE as well as in the store,
* because a box the server would fold is a box that shows a state the next
* read-back contradicts -- the audience strip's "last group cannot be cleared"
* rule, one cell over. Zero is a real value and means "wait until it ends".
--]]
local function refreshCell(rule, row)
    if (rule.refresh == nil) then
        return;
    end

    local ceiling = (vocab ~= nil and vocab.caps ~= nil and vocab.caps.songRefreshMax) or 120;

    imgui.SameLine();
    imgui.PushItemWidth(90);

    local seconds = T{ rule.refresh };

    if (imgui.InputInt(string.format('##ref_%d', row), seconds)) then
        local wanted = math.floor(tonumber(seconds[1]) or 0);

        if (wanted < 0) then
            wanted = 0;
        elseif (wanted > ceiling) then
            wanted = ceiling;
        end

        if (wanted ~= rule.refresh) then
            rule.refresh = wanted;

            markTouched();
        end
    end

    imgui.PopItemWidth();

    tooltipOnHover(TIPS.songRefresh);
end

-- The reason this ordinal is doing nothing, if anybody said so: the set's own
-- verdict (a rule the vocabulary would refuse today), or the selected
-- member's -- filtered by selection, because a verdict about a member the
-- player clicked away from belongs to that member, not to this pane.
local function inertReason(rule)
    if (rule.srv == nil) then
        return nil;
    end

    if (editor.server ~= nil and editor.server.verdicts[rule.srv] ~= nil) then
        return editor.server.verdicts[rule.srv];
    end

    local member = state.selected ~= nil and state.members[state.selected] or nil;

    if (member == nil) then
        return nil;
    end

    local verdicts = state.verdicts[member.charid];

    if (verdicts == nil or verdicts.list[rule.srv] == nil) then
        return nil;
    end

    -- Only if that member is actually running this document.
    if (editor.setid ~= 0 and verdicts.setid == editor.setid) then
        return verdicts.list[rule.srv];
    end

    return nil;
end

-- What the selected member's hints add to an inert rule's hover: the
-- what-it-would-take sentences whose ordinal is this rule's server ordinal.
-- Gated exactly as inertReason gates a member verdict -- the hints describe
-- the member's RUNNING set, so they only belong on this row when that member
-- is running this document.
local function inertHints(rule)
    if (rule.srv == nil) then
        return nil;
    end

    local member = state.selected ~= nil and state.members[state.selected] or nil;

    if (member == nil) then
        return nil;
    end

    local verdicts = state.verdicts[member.charid];

    if (verdicts == nil or editor.setid == 0 or verdicts.setid ~= editor.setid) then
        return nil;
    end

    local hintList = state.hints[member.charid];

    if (hintList == nil) then
        return nil;
    end

    local lines = {};

    for _, hint in ipairs(hintList) do
        if (hint.ordinal == rule.srv) then
            table.insert(lines, hint.text);
        end
    end

    if (#lines == 0) then
        return nil;
    end

    return table.concat(lines, '\n');
end

-- The rule table's columns, in order, with what each one means. Kept beside
-- the tips rather than inline because the header row is drawn by hand and the
-- loop that draws it wants the pair.
local RULE_COLUMNS = {
    { label = '#',     tip = TIPS.colOrder },
    { label = 'On',    tip = TIPS.colOn    },
    { label = 'Who',   tip = TIPS.colWho   },
    { label = 'When',  tip = TIPS.colWhen  },
    { label = 'Do',    tip = TIPS.colDo    },
    { label = 'Retry', tip = TIPS.colRetry },
    { label = '',      tip = nil           },
};

-- Four SmallButtons on a full row -- up, down, duplicate, delete -- and the
-- three gaps between them.
local function rowButtonsWidth()
    return textWidth('^', 8) + textWidth('v', 8) + textWidth('+', 8) + textWidth('x', 8)
        + styleGap('FramePadding', 'x', 4) * 8
        + styleGap('ItemSpacing', 'x', 8) * 3;
end

local function ruleTable()
    local doc = editor.doc;

    -- The toggle latch (1.4): the server that appended aoews to s| also
    -- speaks `toggle` and the r| on/off field, so its presence is the one
    -- honest test for whether the switch column may do anything. Rendered
    -- always (a conditional column count reshuffles ImGui's layout ids);
    -- the cell just stays empty against an older server.
    local speaksToggles = editor.server ~= nil and editor.server.posture ~= nil
        and editor.server.posture.aoews ~= nil;

    --[[
    * THE TWO WIDE COLUMNS STRETCH, AND THE FOOTER IS MEASURED (2026-09-06).
    *
    * All seven columns used to be WidthFixed and the height reserve was the
    * magic -80. Both were wrong at the window's own default size.
    *
    * The widths added up to 940 pixels before cell padding, in a right-hand
    * pane 875 wide at the default 1120 -- and a non-scrolling ImGui table does
    * not shrink fixed columns to fit, it positions them past the right edge
    * and skips the ones whose clip rectangle came out empty. The rightmost
    * column is the one holding every row's reorder and delete button. Stretch
    * columns cannot be dropped that way: they take what is left after the
    * fixed ones and always draw. The two that stretch are the two that hold
    * text, which is the only sane choice of which to make elastic.
    *
    * The reserve is the three footer rows this tab really draws -- the Add
    * rule / Save row, the Assign row and the Rename row -- measured from the
    * frame height rather than guessed. At -80 against a 27-pixel frame height
    * the third row was already short of fitting.
    --]]
    local footer = imgui.GetFrameHeightWithSpacing() * 3 + imgui.GetTextLineHeightWithSpacing();

    if (imgui.BeginTable('##dwg_rules', 7,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -footer })) then
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 26, 0);
        imgui.TableSetupColumn('On', ImGuiTableColumnFlags_WidthFixed, 30, 0);
        imgui.TableSetupColumn('Who', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthStretch, 1.0, 0);
        imgui.TableSetupColumn('Do', ImGuiTableColumnFlags_WidthStretch, 0.95, 0);
        imgui.TableSetupColumn('Retry', ImGuiTableColumnFlags_WidthFixed, 58, 0);

        -- Measured (rowButtonsWidth), because the label text is the only
        -- thing that decides a SmallButton's width -- and 76 was a guess made
        -- when the row held three buttons rather than four.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, rowButtonsWidth(), 0);
        imgui.TableSetupScrollFreeze(0, 1);

        -- The header row is drawn by hand so every column can say what it
        -- means on hover: TableHeadersRow() submits all seven as one item and
        -- leaves nothing for IsItemHovered to be about. (dwleaderboard's
        -- shape, 2026-08-23.) The two nameless columns still get a header cell
        -- so the freeze row is the full width.
        imgui.TableNextRow(ImGuiTableRowFlags_Headers, 0);

        for _, column in ipairs(RULE_COLUMNS) do
            imgui.TableNextColumn();
            imgui.TableHeader(column.label);
            tooltipOnHover(column.tip);
        end

        local moveUp, moveDown, remove, duplicate = nil, nil, nil, nil;
        local moveTop, moveBottom = nil, nil;
        local room = #doc.rules < vocab.caps.rulesPerSet;

        -- One sentence for the whole table rather than one per row per frame.
        local retryTip = string.format(TIPS.retrySecs, vocab.caps.retryMax);

        -- Whose lists the action dropdowns are cut to, resolved once a frame
        -- rather than once a row (1.15.0). Not called `target`: the Who
        -- column below has a local of that name, for the rule's target.
        local listsFor = listTarget();

        -- The row menu (1.15.0) is a right-click on the rule's number. Asked
        -- whether the binding exists rather than assumed, the clipboard's
        -- rule: a player's Ashita is whatever they installed first, and the
        -- ^ and v buttons still reorder without it.
        local rowMenus = type(imgui.BeginPopupContextItem) == 'function' and type(imgui.MenuItem) == 'function';

        for row, rule in ipairs(doc.rules) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            local off    = rule.enabled == false;
            local reason = inertReason(rule);

            if (off) then
                -- Off outranks inert in the margin: an inert verdict is
                -- about a rule that is trying, and this one is not.
                imgui.TextColored(COLOR_INERT, string.format('%d.', row));
                tooltipOnHover(TIPS.ruleOff);
            elseif (reason ~= nil) then
                imgui.TextColored(COLOR_INERT, string.format('%d!', row));

                -- The reason says why it is doing nothing; the hint lines say
                -- what it would take and how far away that is. Built on the
                -- hover: inertHints walks the selected member's whole hint list
                -- and concatenates, and it was doing that for every inert row
                -- on every frame whether anybody was pointing at one or not.
                if (imgui.IsItemHovered()) then
                    local extra = inertHints(rule);

                    imgui.SetTooltip(extra ~= nil and (reason .. '\n\n' .. extra) or reason);
                end
            else
                imgui.Text(string.format('%d', row));

                -- Order is priority: the engine reads top down and an earlier
                -- rule starves a later one.
                tooltipOnHover(TIPS.ruleOrdinal);
            end

            --[[
            * MOVE TO TOP / BOTTOM (1.15.0). A 48-rule set moved one step per
            * click, so putting a new emergency heal at priority 1 under forty
            * others was forty clicks. The menu hangs off the number (an
            * explicit id, because the number is a Text and has none of its
            * own) and records its choice like the buttons do, for the pass
            * after the loop -- the list is never mutated mid-draw.
            --]]
            if (rowMenus and imgui.BeginPopupContextItem(string.format('##rowmenu_%d', row))) then
                if (row > 1 and imgui.MenuItem(string.format('Move to top##top_%d', row))) then
                    moveTop = row;
                end

                if (row < #doc.rules and imgui.MenuItem(string.format('Move to bottom##bottom_%d', row))) then
                    moveBottom = row;
                end

                if (room and imgui.MenuItem(string.format('Duplicate##menudup_%d', row))) then
                    duplicate = row;
                end

                imgui.EndPopup();
            end

            imgui.TableNextColumn();

            if (speaksToggles) then
                local on = T{ not off };

                if (imgui.Checkbox(string.format('##on_%d', row), on)) then
                    rule.enabled = on[1];

                    markTouched();
                end

                tooltipOnHover(TIPS.toggleOn);
            end

            imgui.TableNextColumn();

            -- A fresh row's who follows its Do and When until the player
            -- picks one (settleAutoWho). Settled BEFORE the combo draws, so
            -- the label is the who that will be sent.
            settleAutoWho(rule);

            local target = vocab.targetById[rule.target];
            local pickedTarget = pickCombo(string.format('##target_%d', row), 100,
                target ~= nil and target.label or string.format('#%d', rule.target), vocab.targets,
                function (candidate) return target ~= nil and candidate.id == target.id; end);

            if (pickedTarget ~= nil) then
                -- Any pick is the player's choice, the same entry included:
                -- from here the Do and When leave the who alone.
                rule.autoWho = nil;

                if (target == nil or pickedTarget.id ~= target.id) then
                    rule.target = pickedTarget.id;

                    markTouched();
                end
            end

            imgui.TableNextColumn();

            local kind = kindOf(rule);

            conditionCell(rule, row, kind ~= nil and kind.pinned ~= nil);

            imgui.TableNextColumn();

            actionCell(rule, row, listsFor);

            -- [Sings to], for the rules the server called party songs. Its own
            -- call rather than a tail of actionCell, which returns early on an
            -- unrecognised action kind.
            audienceCell(rule, row);
            refreshCell(rule, row);

            imgui.TableNextColumn();

            local buffer = T{ rule.retry };

            imgui.PushItemWidth(48);

            if (imgui.InputInt(string.format('##retry_%d', row), buffer, 0, 0)) then
                local value = tonumber(buffer[1]);

                -- Integrality first, for the reason conditionCell states.
                if (value == nil or value ~= math.floor(value)) then
                    value = 0;
                end

                rule.retry = math.max(math.min(value, vocab.caps.retryMax), 0);

                markTouched();
            end

            imgui.PopItemWidth();
            tooltipOnHover(retryTip);

            imgui.TableNextColumn();

            if (row > 1) then
                if (imgui.SmallButton(string.format('^##up_%d', row))) then
                    moveUp = row;
                end

                imgui.SameLine();
            end

            if (row < #doc.rules) then
                if (imgui.SmallButton(string.format('v##dn_%d', row))) then
                    moveDown = row;
                end

                imgui.SameLine();
            end

            -- Duplicate (1.10.0). Two rules that differ in one dropdown -- the
            -- same cure ladder for `party` and for `master`, the same weapon
            -- skill under two conditions -- were eight dropdowns of retyping,
            -- and the typed tier has the same gap. Purely local: the copy
            -- serialises as another `add` like any other new rule.
            if (room) then
                if (imgui.SmallButton(string.format('+##dup_%d', row))) then
                    duplicate = row;
                end

                tooltipOnHover(TIPS.duplicate);

                imgui.SameLine();
            end

            if (imgui.SmallButton(string.format('x##del_%d', row))) then
                remove = row;
            end

            tooltipOnHover(TIPS.remove);
        end

        imgui.EndTable();

        -- Applied after the loop: mutating the list mid-iteration renders one
        -- frame from two different documents.
        if (moveUp ~= nil) then
            table.insert(doc.rules, moveUp - 1, table.remove(doc.rules, moveUp));

            markTouched();
        elseif (moveDown ~= nil) then
            table.insert(doc.rules, moveDown + 1, table.remove(doc.rules, moveDown));

            markTouched();
        elseif (moveTop ~= nil) then
            table.insert(doc.rules, 1, table.remove(doc.rules, moveTop));

            markTouched();
        elseif (moveBottom ~= nil) then
            table.insert(doc.rules, table.remove(doc.rules, moveBottom));

            markTouched();
        elseif (duplicate ~= nil) then
            local fresh = copyRule(doc.rules[duplicate]);

            -- The copy has no server ordinal of its own until it is saved.
            -- Left with the original's, the inert verdict and the upgrade
            -- hints reported against that ordinal would be drawn beside a row
            -- the server has never seen.
            fresh.srv = nil;

            table.insert(doc.rules, duplicate + 1, fresh);

            markTouched();
        elseif (remove ~= nil) then
            table.remove(doc.rules, remove);

            markTouched();
        end
    end
end

local function postureBlock()
    local doc = editor.doc;

    local function optionCombo(field, listName, id, width)
        local list    = vocab.posture[listName] or {};
        local current = nil;

        for _, option in ipairs(list) do
            if (option.id == doc.posture[field]) then
                current = option;
            end
        end

        local picked = pickCombo(id, width, current ~= nil and current.label or '(?)', list,
            function (candidate) return current ~= nil and candidate.id == current.id; end);

        if (picked ~= nil and (current == nil or picked.id ~= current.id)) then
            doc.posture[field] = picked.id;

            markTouched();
        end
    end

    imgui.Text('Swing');
    tooltipOnHover(TIPS.swing);
    imgui.SameLine();
    optionCombo('autoattack', 'swing', '##po_swing', 170);
    tooltipOnHover(TIPS.swing);
    imgui.SameLine();
    imgui.Text('Stance');
    tooltipOnHover(TIPS.stance);
    imgui.SameLine();
    optionCombo('movement', 'stance', '##po_stance', 140);
    tooltipOnHover(TIPS.stance);
    imgui.SameLine();

    local spendtp = T{ doc.posture.spendtp };

    if (imgui.Checkbox('Spend TP##po_tp', spendtp)) then
        doc.posture.spendtp = spendtp[1];

        markTouched();
    end

    tooltipOnHover(TIPS.spendTp);

    imgui.SameLine();

    local hold = T{ doc.posture.hold };

    if (imgui.Checkbox('Hold position##po_hold', hold)) then
        doc.posture.hold = hold[1];

        markTouched();
    end

    tooltipOnHover(TIPS.holdPos);

    --[[
    * THE LATCHED SWITCHES GO ON A LINE OF THEIR OWN (2026-09-06).
    *
    * All four appended themselves to the end of the first line as they shipped
    * -- AoE WS in 1.4, Song Burst in 1.5, Bard Runs In in 1.6, Enfeeble Burst
    * in 1.7 -- and by the fourth the strip ran past eleven hundred pixels,
    * which is wider than the right-hand pane at any window size a player is
    * likely to drag to. The right pane is a child with scrollbars of its own,
    * so the overflow was a horizontal scrollbar under the posture strip rather
    * than a clip, which is worse: it moves everything else.
    *
    * Which of them exist is decided by the wire (each is its own latch), so
    * the line cannot be written as a fixed sequence of SameLines -- the FIRST
    * present switch starts the line and the rest follow it.
    --]]
    local switchRow = false;

    local function switchLine()
        if (switchRow) then
            imgui.SameLine();
        end

        switchRow = true;
    end

    -- The AoE switch (1.4). Latched on the field's presence: a server that
    -- never sends it does not speak `posture aoews` either, and a checkbox
    -- that saves into a refusal is worse than no checkbox.
    if (doc.posture.aoews ~= nil) then
        switchLine();

        local aoe = T{ doc.posture.aoews };

        if (imgui.Checkbox('Allow AoE WS##po_aoews', aoe)) then
            doc.posture.aoews = aoe[1];

            markTouched();
        end

        tooltipOnHover(TIPS.aoews);
    end

    -- The song-burst switch (1.5), latched the same way on its own field.
    if (doc.posture.songburst ~= nil) then
        switchLine();

        local songburst = T{ doc.posture.songburst };

        if (imgui.Checkbox('Allow Song Burst##po_songburst', songburst)) then
            doc.posture.songburst = songburst[1];

            markTouched();
        end

        tooltipOnHover(TIPS.songBurst);
    end

    -- Allow Enfeeble Burst (1.7), songburst's sibling: same latch on its own
    -- field, same one-pick scope on the server.
    if (doc.posture.enfeebleburst ~= nil) then
        switchLine();

        local enfeebleburst = T{ doc.posture.enfeebleburst };

        if (imgui.Checkbox('Allow Enfeeble Burst##po_enfeebleburst', enfeebleburst)) then
            doc.posture.enfeebleburst = enfeebleburst[1];

            markTouched();
        end

        tooltipOnHover(TIPS.enfeebleBurst);
    end

    -- Bard Runs In (1.6), latched the same way on its own field.
    if (doc.posture.runin ~= nil) then
        switchLine();

        local runin = T{ doc.posture.runin };

        if (imgui.Checkbox('Bard Runs In##po_runin', runin)) then
            doc.posture.runin = runin[1];

            markTouched();
        end

        tooltipOnHover(TIPS.runIn);
    end

    if (doc.posture.spendtp) then
        imgui.Text('TP when');
        tooltipOnHover(TIPS.tpwhen);
        imgui.SameLine();
        optionCombo('tptrigger', 'tpwhen', '##po_tpwhen', 210);
        tooltipOnHover(TIPS.tpwhen);
        imgui.SameLine();
        imgui.Text('using');
        tooltipOnHover(TIPS.tpuse);
        imgui.SameLine();
        optionCombo('tpselect', 'tpuse', '##po_tpuse', 210);
        tooltipOnHover(TIPS.tpuse);

        -- Hold amount (2026-08-06). 0 is "engine default" and anything else
        -- clamps into the server's band the moment it is typed -- the caps
        -- are v|h fields, never hardcoded.
        imgui.SameLine();
        imgui.Text('holding to');
        imgui.SameLine();

        local hold = T{ doc.posture.tphold or 0 };

        imgui.PushItemWidth(80);

        if (imgui.InputInt('##po_tphold', hold, 0, 0)) then
            local value = tonumber(hold[1]);

            -- Integrality first, for the reason conditionCell states -- and
            -- this one reaches a `posture ... tphold <n>` command line.
            if (value == nil or value ~= math.floor(value)) then
                value = 0;
            end

            if (value <= 0) then
                value = 0;
            else
                value = math.max(math.min(value, vocab.caps.tpHoldMax), vocab.caps.tpHoldMin);
            end

            doc.posture.tphold = value;

            markTouched();
        end

        imgui.PopItemWidth();

        tooltipOnHover(string.format(TIPS.tpHold, vocab.caps.tpHoldMin, vocab.caps.tpHoldMax));

        -- Manual WS Mode (1.6). It sits HERE, beside the TP amount, because
        -- that is what it is about -- and inside the Spend TP block on
        -- purpose: with Spend TP off there is no automatic weapon skill left
        -- to suppress, so the switch would be a control with nothing to do.
        if (doc.posture.manualws ~= nil) then
            imgui.SameLine();

            local manualws = T{ doc.posture.manualws };

            if (imgui.Checkbox('Manual WS Mode##po_manualws', manualws)) then
                doc.posture.manualws = manualws[1];

                markTouched();
            end

            tooltipOnHover(TIPS.manualWs);
        end

        -- The weapon-skill picks (2026-08-06): ordered, first is the opener.
        -- The whole DAT list, not this character's -- a posture stores intent
        -- and the server reports what a member cannot use yet. Slots compact
        -- left on every edit so the order on screen is the order saved.
        imgui.Text('Weapon skills');
        imgui.SameLine();

        local picks   = doc.posture.tpskills or {};
        local edited  = false;
        local entries = weaponSkillPicks();
        local slots   = math.min(#picks + 1, vocab.caps.tpSkillPicks);

        doc.posture.tpskills = picks;

        for slot = 1, slots do
            if (slot > 1) then
                imgui.SameLine();
            end

            local current = picks[slot];
            local label   = current ~= nil and weaponSkillName(current) or '(any)';

            -- '(any)' leads the list as the clear entry; picking it empties
            -- the slot and the compact pass below closes the gap.
            local picked = pickComboFiltered(string.format('##po_ws_%d', slot), 160, label, entries,
                function (candidate) return current ~= nil and candidate.id == current; end);

            if (picked ~= nil) then
                if (picked.id == 0) then
                    table.remove(picks, slot);
                else
                    -- The same skill twice is a server refusal; close the
                    -- duplicate here instead of after the save.
                    local dupe = nil;

                    for index, id in ipairs(picks) do
                        if (id == picked.id and index ~= slot) then
                            dupe = index;
                        end
                    end

                    if (dupe == nil) then
                        picks[slot] = picked.id;
                    else
                        -- SAY SO (2026-09-06). The click was simply dropped
                        -- before, so picking a skill already in another slot
                        -- looked like a dead dropdown.
                        state.status    = string.format('%s is already pick %d -- a skill can only be named once.',
                            picked.label, dupe);
                        state.statusBad = true;
                    end
                end

                edited = true;
            end
        end

        if (edited) then
            markTouched();
        end

        tooltipOnHover(TIPS.wsPicks);

        -- The server's verdict on the picks (k| ordinal 0), shown only when
        -- the member selected in the left pane is actually running this set.
        local member = state.selected ~= nil and state.members[state.selected] or nil;

        if (member ~= nil and editor.setid ~= 0) then
            local verdicts = state.verdicts[member.charid];

            if (verdicts ~= nil and verdicts.setid == editor.setid and verdicts.list[0] ~= nil) then
                imgui.TextColored(COLOR_INERT, verdicts.list[0]);
            end
        end
    end
end

-- A read-only rendering of a shipped set: the composition as a document, gate
-- and all, with the way forward being a copy rather than an edit.
--[[
* A shipped set's rows, written out once per document.
*
* SAID ONCE, NOT SIXTY TIMES A SECOND (2026-09-06). Every row of a preset went
* through conditionText twice, actionText once -- which is a GetSpellById or a
* GetAbilityById into the client's DATs -- and three string.format calls, on
* every frame, for text that cannot change while the same read-only document is
* on screen. A composed preset runs to forty-odd rows.
*
* Keyed on the document TABLE, not on a revision: adoptDoc replaces
* editor.server wholesale, so identity is exactly the right invalidation, and
* it also covers the vocabulary being rebuilt under it (a rebuild replaces the
* document too, because the fetch that caused it re-reads).
--]]
local shippedRows = { doc = nil, vocab = nil, rows = {} };

local function shippedRowText(doc)
    if (shippedRows.doc == doc and shippedRows.vocab == vocab) then
        return shippedRows.rows;
    end

    local rows = {};

    for row, rule in ipairs(doc.rules) do
        local target = vocab.targetById[rule.target];
        local when   = conditionText(rule.cond1, rule.arg1);

        if (rule.cond2 ~= NO_CONDITION) then
            local logic = vocab.logicById[rule.logic];

            when = string.format('%s %s %s', when,
                logic ~= nil and logic.key or 'and', conditionText(rule.cond2, rule.arg2));
        end

        rows[row] = {
            ordinal = string.format('%d', row),
            gate    = rule.gate or 'all',
            text    = string.format('%s: %s -> %s',
                target ~= nil and target.label or ('#' .. rule.target), when, actionText(rule)),
            retry   = rule.retry > 0 and string.format('%ds', rule.retry) or '',
        };
    end

    shippedRows.doc   = doc;
    shippedRows.vocab = vocab;
    shippedRows.rows  = rows;

    return rows;
end

local function shippedView()
    imgui.TextColored(COLOR_BADGE, string.format('%s -- a shipped set. Copy it to make one you can edit.', editor.name));

    local doc  = editor.server;
    local rows = shippedRowText(doc);

    -- One footer row (Copy as / Copy to editable / Assign), measured, and a
    -- Rule column that takes what is left rather than a fixed 560: a composed
    -- preset's longest sentence -- target, two conditions and a named action --
    -- runs well past that, and a table cell clips to its column.
    if (imgui.BeginTable('##dwg_shipped', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit),
            { -1, -(imgui.GetFrameHeightWithSpacing() + imgui.GetTextLineHeightWithSpacing()) })) then
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 26, 0);
        imgui.TableSetupColumn('For', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Rule', ImGuiTableColumnFlags_WidthStretch, 1.0, 0);
        imgui.TableSetupColumn('Retry', ImGuiTableColumnFlags_WidthFixed, 50, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row.ordinal);
            imgui.TableNextColumn();

            -- The role gate: which members of the composition receive this
            -- rule at all. Only shipped sets carry one.
            imgui.TextDisabled(row.gate);
            tooltipOnHover(TIPS.gate);

            imgui.TableNextColumn();
            imgui.Text(row.text);

            imgui.TableNextColumn();
            imgui.Text(row.retry);
        end

        imgui.EndTable();
    end

    local nameBox = nameBoxOf('copyname');

    imgui.Text('Copy as');
    imgui.SameLine();
    imgui.PushItemWidth(160);
    imgui.InputText('##copyname', nameBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    tooltipOnHover(TIPS.copyName);
    imgui.SameLine();

    -- A shipped set is a composition; flattening it needs to know for WHOM.
    -- A summoned member names a role; with nobody out the server falls back
    -- to the player's own job and says so.
    local memberTags = { { key = '', label = '(my own job)' } };

    for _, charid in ipairs(state.memberOrder) do
        local member = state.members[charid];

        if (member ~= nil) then
            table.insert(memberTags, {
                key   = string.lower(JOB_NAMES[member.job] or ''),
                label = string.format('%s (%s)', member.name, JOB_NAMES[member.job] or '?'),
            });
        end
    end

    local flat = nameBoxOf('copyfor');
    local currentLabel = '(my own job)';

    for _, entry in ipairs(memberTags) do
        if (entry.key == flat[1]) then
            currentLabel = entry.label;
        end
    end

    local picked = pickCombo('##copyfor', 150, currentLabel, memberTags,
        function (entry) return entry.key == flat[1]; end);

    tooltipOnHover(TIPS.copyFor);

    if (picked ~= nil) then
        flat[1] = picked.key;
    end

    imgui.SameLine();

    if (imgui.Button('Copy to editable##copybtn')) then
        local name = tidyName(nameBox[1]);

        if (validName(name)) then
            local command = string.format('!dwg copy "%s" %s', editor.name, name);

            if (flat[1] ~= nil and #flat[1] > 0) then
                command = command .. ' ' .. flat[1];
            end

            -- The copy becomes the document on screen the moment it exists.
            editor.pendingRef = name;
            editor.touched    = false;

            startPlan({ command }, string.format('Copying %s...', editor.name));
        else
            state.status    = nameProblem(name);
            state.statusBad = true;
        end
    end

    tooltipOnHover(TIPS.copyMake);

    imgui.SameLine();

    assignControls('shipped', 'preset:' .. editor.name);
end

local function editorTab()
    if (vocab == nil) then
        vocabNotice();

        return;
    end

    -- `list` is what the set picker below is made of. `rules` and `presets`
    -- are asked by leftPane, which is the pane that draws them.
    need('list', 0, '!dwg list');

    -- The set picker: everything the account owns, then a way to start fresh.
    -- Built and sorted with the rest of the derived views rather than per frame.
    local owned = views().owned;

    imgui.Text('Set');
    imgui.SameLine();

    -- Filtered since 1.10.0: an account holds thirty-two sets and the picker
    -- had no way through them but scrolling.
    local picked = pickComboFiltered('##setpick', 170, editor.name or '(pick a set)', owned,
        function (set) return editor.setid ~= 0 and set.setid == editor.setid; end);

    tooltipOnHover(TIPS.setPick);

    if (picked ~= nil) then
        if (editor.touched) then
            state.status    = 'Save or revert your edits before switching sets.';
            state.statusBad = true;
        else
            loadIntoEditor(picked.name);
        end
    end

    imgui.SameLine();

    local newBox = nameBoxOf('newname');

    imgui.PushItemWidth(140);
    imgui.InputText('##newname', newBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    tooltipOnHover(TIPS.newName);
    imgui.SameLine();

    local ownedCount = #owned;

    if (imgui.Button('New##newset')) then
        local name = tidyName(newBox[1]);

        if (editor.touched) then
            state.status    = 'Save or revert your edits first.';
            state.statusBad = true;
        elseif (not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        elseif (ownedCount >= vocab.caps.setsPerAccount) then
            -- The cap, enforced here as the v|h record intends: refused in
            -- the UI rather than after the server throws it away.
            state.status    = string.format('An account holds %d sets, and this one is full. Delete one first (the Delete button below, or !squad rules delete).', vocab.caps.setsPerAccount);
            state.statusBad = true;
        else
            editor.pendingRef = name;
            editor.touched    = false;

            startPlan({ '!dwg new ' .. name }, string.format('Creating "%s"...', name));

            newBox[1] = '';
        end
    end

    tooltipOnHover(string.format(TIPS.newSet, ownedCount, vocab.caps.setsPerAccount, vocab.caps.nameLength));

    -- "Lists for" (1.15.0) ends the header row, and only over a document
    -- that can be edited: it shapes the action dropdowns and nothing else.
    if (editor.name ~= nil and not editor.shipped and editor.doc ~= nil) then
        imgui.SameLine();
        listForControl();
    end

    if (editor.name == nil) then
        imgui.Separator();
        imgui.Text('Pick a set to edit, create a new one, or browse the shipped sets.');
        imgui.Text('Clicking a character on the left opens whatever they are running.');

        return;
    end

    if (editor.shipped) then
        shippedView();

        return;
    end

    if (editor.doc == nil) then
        if (gaveUp('show')) then
            imgui.TextWrapped('The server did not answer for this set. Press Refresh above, or pick it again.');
        else
            imgui.Text('Loading...');
        end

        return;
    end

    imgui.Separator();

    postureBlock();

    imgui.Separator();

    ruleTable();

    -- The bottom bar: everything that leaves the local document.
    local doc = editor.doc;

    if (#doc.rules < vocab.caps.rulesPerSet) then
        if (imgui.Button('Add rule##addrule')) then
            -- The blank rule: the first target, the first condition, the
            -- first action kind -- all of them real entries off the wire, so
            -- the new row is already a saveable rule.
            local target = vocab.targets[1];
            local kind   = vocab.kinds[1];

            local rule = {
                target   = target ~= nil and target.id or 0,
                logic    = 0,
                cond1    = 0,
                arg1     = 0,
                cond2    = NO_CONDITION,
                arg2     = 0,
                reaction = kind ~= nil and kind.reaction or 0,
                selector = kind ~= nil and kind.selector or 0,
                actionid = 0,
                retry    = 0,

                -- The who is the window's, not the player's, until they pick
                -- one (settleAutoWho). Not in ruleKey and never sent.
                autoWho  = true,
            };

            -- The When half is the whitelist's own first entry WITH whatever
            -- argument its domain calls for, rather than that entry's id and a
            -- hardcoded 0. `always` takes no argument today, so the two agree;
            -- a whitelist whose first entry took a number would have made
            -- every new rule start below its own minimum and be refused by the
            -- server on the first Save. It is the same blank a rule falls back
            -- to when it leaves a canned pairing.
            resetCondition(rule);

            if (kind ~= nil and kind.arg.kind == 'pick') then
                local list = vocab.pickers[kind.arg.picker];

                rule.actionid = list ~= nil and list[1] ~= nil and list[1].id or 0;
            end

            settleAutoWho(rule);

            table.insert(doc.rules, rule);

            markTouched();
        end

        tooltipOnHover(TIPS.addRule);
    else
        imgui.TextDisabled(string.format('A set holds %d rules, and this one is full.', vocab.caps.rulesPerSet));
        tooltipOnHover(TIPS.full);
    end

    imgui.SameLine();

    if (editor.touched) then
        imgui.TextColored(COLOR_DIRTY, 'o unsaved changes');
        tooltipOnHover(TIPS.dirty);
    else
        imgui.TextDisabled('saved');
        tooltipOnHover(TIPS.clean);
    end

    imgui.SameLine();

    if (imgui.Button('Save##save')) then
        if (editor.saving) then
            state.status    = 'A save is already running.';
            state.statusBad = false;
        elseif (editor.touched) then
            beginSave(nil);
        else
            -- A click that does nothing has to say so. It used to be silent,
            -- which reads exactly like a Save that failed.
            state.status    = 'Nothing to save -- this window and the server already agree.';
            state.statusBad = false;
        end
    end

    tooltipOnHover(TIPS.save);

    imgui.SameLine();

    --[[
    * REVERT ASKS ONCE MORE WHEN IT WOULD LOSE SOMETHING (1.15.0). It replaced
    * the document on the first click, while Delete set and the party delete
    * both asked twice -- so the one button that throws away an hour of unsaved
    * editing was the one with no second chance. Armed only over a touched
    * document (a clean one has nothing to lose) and disarmed by any further
    * edit (markTouched), so the confirmation is always about what is on screen.
    --]]
    local revertArmed = editor.armRevert and editor.touched;

    if (imgui.Button(revertArmed and 'Really revert?##revert' or 'Revert##revert')) then
        if (editor.server ~= nil) then
            if (editor.touched and not revertArmed) then
                editor.armRevert = true;
            else
                editor.armRevert = false;
                editor.doc       = copyDocOf(editor.server);
                editor.touched   = false;
                state.status     = 'Reverted to the saved copy.';
                state.statusBad  = false;
            end
        end
    end

    tooltipOnHover(revertArmed and TIPS.revertArmed or TIPS.revert);

    imgui.SameLine();

    local asBox = nameBoxOf('saveas');

    imgui.PushItemWidth(130);
    imgui.InputText('##saveas', asBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    tooltipOnHover(TIPS.saveAsBox);
    imgui.SameLine();

    if (imgui.Button('Save as##saveasbtn')) then
        local name = tidyName(asBox[1]);

        if (editor.saving) then
            state.status    = 'A save is already running.';
            state.statusBad = false;
        elseif (not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        elseif (ownedCount >= vocab.caps.setsPerAccount) then
            state.status    = string.format('An account holds %d sets, and this one is full.', vocab.caps.setsPerAccount);
            state.statusBad = true;
        else
            beginSave(name);
            asBox[1] = '';
        end
    end

    tooltipOnHover(TIPS.saveAs);

    imgui.Text('Assign to');
    imgui.SameLine();
    assignControls('editor', editor.name);

    imgui.SameLine();

    if (imgui.Button('Check##report')) then
        requested['report'] = nil;
        need('report', os.clock(), '!dwg report');
    end

    tooltipOnHover(TIPS.check);

    -- The manage row: the two verbs the typed tier has owned since Phase 2,
    -- finally given buttons. Rename is safe mid-edit -- adoptDoc keeps a
    -- touched doc and follows the setid into the new name -- so it only
    -- guards against a running save (whose remaining steps quote the old
    -- name). Delete asks twice, dwjobs' pattern, because there is no undo;
    -- the armed state is keyed on the setid so switching sets disarms it.
    imgui.Text('Rename to');
    imgui.SameLine();

    local renameBox = nameBoxOf('renameset');

    imgui.PushItemWidth(130);
    imgui.InputText('##renameset', renameBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    tooltipOnHover(TIPS.renameBox);
    imgui.SameLine();

    if (imgui.Button('Rename##renamebtn')) then
        editor.armDelete = 0;

        local name = tidyName(renameBox[1]);

        if (editor.saving) then
            state.status    = 'A save is already running.';
            state.statusBad = false;
        elseif (not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        else
            startPlan({ string.format('!dwg rename "%s" %s', editor.name, name) },
                string.format('Renaming "%s" to "%s"...', editor.name, name));

            renameBox[1] = '';
        end
    end

    tooltipOnHover(TIPS.rename);

    imgui.SameLine();

    if (editor.armDelete == editor.setid and editor.setid ~= 0) then
        if (imgui.Button('Really delete?##deletebtn')) then
            editor.armDelete = 0;

            if (editor.saving) then
                state.status    = 'A save is already running.';
                state.statusBad = false;
            else
                startPlan({ string.format('!dwg delete "%s"', editor.name) },
                    string.format('Deleting "%s"...', editor.name));
            end
        end

        tooltipOnHover(TIPS.deleteArmed);
    else
        if (imgui.Button('Delete##deletebtn')) then
            if (editor.setid == 0) then
                -- A set the server has not confirmed yet has no id to arm
                -- against, so the two-click guard could never fire and the
                -- button simply did nothing, twice.
                state.status    = 'This set is still being created -- wait for the server to confirm it, then delete.';
                state.statusBad = false;
            else
                editor.armDelete = editor.setid;
            end
        end

        tooltipOnHover(TIPS.deleteSet);
    end
end

--[[
* The Share tab.
*
* Two halves of one idea: turn a set of mine into text, and turn somebody
* else's text into a set of mine.
*
* THE CODE BOXES ARE INPUTS AND NOT LABELS, deliberately: Ashita's chat log is
* not selectable, so a read-only InputText the player can click into, select
* and Ctrl-C is a way the code can leave the window that needs nothing of the
* host. Marked read-only rather than merely "please do not type in it", because
* a code with a character changed is a code that will be refused on the other
* end with no clue as to why.
*
* This comment used to say ImGui had no "copy this text" affordance and that
* the box was therefore the ONLY way out. That was wrong: Ashita declares
* `SetClipboardText` in its own SDK, and 1.10.0 puts a Copy button beside every
* part and a Copy all beside a multi-part code. The box stays, because the
* button is guarded on a call an older Ashita build may not have (see
* copyToClipboard) and a player on such a build must still be able to share.
*
* IMPORT SENDS ONE PART PER COMMAND, through the same queue everything else
* uses. A pasted two-line code is split on whitespace here and issued as two
* `!dwg import` lines; the server buffers the parts and answers the last one
* with the set. That is not the client being clever -- it is exactly what a
* player typing both lines does, which is the rule the whole addon is built on.
--]]

--[[
* THE PASTE BOX HOLDS THE LONGEST LEGAL CODE (1.15.0).
*
* It held 511 characters -- "two full parts", from when a set had 24 rules --
* and Copy all hands over every part of a code joined by spaces. Since the
* raise to 48 rules a real code runs well past that: 36 rules of two
* conditions and a retry are 521 characters, 48 of them 682. ImGui answers an
* over-long paste by refusing it or cutting it short, so the receiver saw
* "Paste a code into the box first." or had the last part refused as damaged,
* and a big set could not be shared through the window at all.
*
* The size is the code format's own ceiling: MAX_PARTS parts of PART_CHUNK
* payload characters, each behind a seven-character head, plus the spaces
* between them -- 8 x (7 + 99) + 7 = 855 in squad_rule_codes.lua today.
* harness_dwgambits.py reads both numbers out of that file and holds this one
* above them, so the format cannot grow past the box unnoticed.
--]]
local CODE_BOX = 1024;

local function longestToken(tokens)
    local longest = 0;

    for _, token in ipairs(tokens) do
        longest = math.max(longest, #token);
    end

    return longest;
end

local function shareTab()
    need('list', 0, '!dwg list');

    -- The vocabulary fetch used to be advanced from here too, because
    -- needVocab lived in editorTab alone and a player who left that tab after
    -- page 1 left `vocab` nil forever while this tab's Import needs its name
    -- caps. renderWindow advances it for every tab since 1.15.0.

    imgui.TextWrapped('A rule set as text. Say it, write it down, paste it into Discord -- anyone on any DriftwoodXI character can put it to work.');
    imgui.Separator();

    -- Export.
    imgui.Text('Share one of yours');

    local owned = views().owned;

    -- Filtered since 1.15.0, like the Editor's own set picker: an account
    -- holds thirty-two sets and this one had no way through them but scrolling.
    local picked = pickComboFiltered('##sharepick', 170, state.codesFor or '(pick a set)', owned,
        function (set) return state.codesFor ~= nil and set.name == state.codesFor; end);

    tooltipOnHover(TIPS.sharePick);

    if (picked ~= nil) then
        -- The old code goes the moment a different set is chosen: a stale code
        -- sitting under a new name is the one failure mode of this pane that
        -- the player could not possibly diagnose.
        state.codes    = {};
        state.codesFor = picked.name;

        startPlan({ string.format('!dwg export "%s"', picked.name) },
            string.format('Making a code for %s...', picked.name));
    end

    imgui.SameLine();

    -- A click with nothing picked used to do nothing at all, silently. The
    -- button stays live rather than greyed because a greyed control cannot be
    -- hovered for its reason in every ImGui build, and this addon's own idiom
    -- for a refusal is a sentence in the status line.
    if (imgui.Button('Refresh code##sharerefresh')) then
        if (state.codesFor == nil) then
            state.status    = 'Pick one of your sets in the box beside this first.';
            state.statusBad = true;
        else
            state.codes = {};

            startPlan({ string.format('!dwg export "%s"', state.codesFor) },
                string.format('Making a code for %s...', state.codesFor));
        end
    end

    tooltipOnHover(TIPS.refreshCode);

    -- The server's own part count, not a count of what arrived: a lost part
    -- has to be visible.
    local arrived = 0;

    for _ in pairs(state.codes) do
        arrived = arrived + 1;
    end

    local total = math.max(state.codeTotal or 0, arrived);

    if (total > arrived) then
        imgui.TextColored(COLOR_ERROR, string.format(
            'Only %d of the %d lines of this code arrived. Press Refresh code -- half a code is refused on the other end.',
            arrived, total));
        tooltipOnHover(TIPS.codeGap);
    end

    if (total > 1) then
        imgui.TextColored(COLOR_DIRTY, string.format('%d lines, and all of them are needed.', total));
        tooltipOnHover(TIPS.codeParts);

        imgui.SameLine();

        -- Joined by a space, which is exactly what the paste box below splits
        -- on: one copy, one paste, one Import.
        if (imgui.Button('Copy all##codecopyall')) then
            local pieces = {};

            for part = 1, total do
                if (state.codes[part] ~= nil) then
                    table.insert(pieces, state.codes[part]);
                end
            end

            if (copyToClipboard(table.concat(pieces, ' '))) then
                state.status    = string.format('All %d lines copied.', #pieces);
                state.statusBad = false;
            end
        end

        tooltipOnHover(TIPS.codeCopyAll);
    end

    for part = 1, total do
        local code = state.codes[part];

        if (code ~= nil) then
            local box = nameBoxOf('code' .. part);

            box[1] = code;

            -- Room kept for the Copy button beside it.
            imgui.PushItemWidth(-(textWidth('Copy', 34)
                + styleGap('FramePadding', 'x', 4) * 2 + styleGap('ItemSpacing', 'x', 8) * 2));
            imgui.InputText(string.format('##code%d', part), box, CODE_BOX, ImGuiInputTextFlags_ReadOnly);
            imgui.PopItemWidth();
            tooltipOnHover(TIPS.codeBox);

            imgui.SameLine();

            if (imgui.Button(string.format('Copy##codecopy%d', part))) then
                if (copyToClipboard(code)) then
                    state.status    = total > 1
                        and string.format('Line %d of %d copied.', part, total)
                        or 'Code copied.';
                    state.statusBad = false;
                end
            end

            tooltipOnHover(TIPS.codeCopy);
        end
    end

    if (total == 0 and state.codesFor ~= nil) then
        imgui.TextDisabled('Fetching...');
        tooltipOnHover(TIPS.codeWait);
    end

    imgui.Separator();

    -- Import.
    imgui.Text('Take somebody else\'s');

    local pasteBox = nameBoxOf('paste');
    local nameBox  = nameBoxOf('importname');

    imgui.PushItemWidth(-1);
    imgui.InputTextMultiline('##paste', pasteBox, CODE_BOX, { -1, 54 });
    imgui.PopItemWidth();
    tooltipOnHover(TIPS.pasteBox);

    imgui.Text('Call it');
    imgui.SameLine();
    imgui.PushItemWidth(160);
    imgui.InputText('##importname', nameBox, vocab ~= nil and (vocab.caps.nameLength + 1) or 25);
    imgui.PopItemWidth();

    tooltipOnHover(TIPS.importName);

    imgui.SameLine();

    if (imgui.Button('Import##importbtn')) then
        local pasted = pasteBox[1] or '';
        local codes  = {};

        for token in string.gmatch(pasted, '%S+') do
            table.insert(codes, token);
        end

        local name = tidyName(nameBox[1]);

        if (#codes == 0) then
            state.status    = 'Paste a code into the box first.';
            state.statusBad = true;
        elseif (#pasted >= CODE_BOX - 1) then
            -- A box filled to the brim was very likely cut: ImGui stops at the
            -- buffer and says nothing. No legal code reaches this size, so it
            -- is refused here rather than sent as a code the server will call
            -- damaged about a part the player cannot see is short.
            state.status    = 'The paste box is full, so the code may have been cut short. Paste its lines a few at a time instead.';
            state.statusBad = true;
        elseif (longestToken(codes) + #'!dwg import ' > CHAT_LINE_MAX) then
            -- Every line of a real code fits a chat line with room for the
            -- command in front of it (squad_rule_codes.lua sizes its parts that
            -- way), so a longer word is not a code -- two lines pasted with no
            -- space between them, or something else entirely. Sent anyway it
            -- was refused by the CLIENT before the server saw it, and the plan
            -- died eight seconds later reporting a failed save.
            state.status    = 'That is not a share code -- a code\'s lines are separate words, each well under a chat line. Paste them with a space between.';
            state.statusBad = true;
        elseif (#name > 0 and vocab == nil) then
            -- validName and nameProblem both index vocab.caps unconditionally,
            -- and this is the ONE tab that can run before the vocabulary lands
            -- (its own InputText size already guards for that). Indexing nil
            -- here threw inside renderWindow, and the pcall around it closes
            -- the window on the player with the paste still unsent.
            state.status    = 'Still fetching the rule vocabulary -- try again in a moment.';
            state.statusBad = true;
        elseif (#name > 0 and not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        elseif (#name > 0 and (#codes[#codes] + #name) > 114) then
            -- `!dwg import ` is 12 characters and the space before the name one
            -- more, out of the 127 a chat line holds -- and the client REFUSES
            -- an over-length line rather than truncating it, before the server
            -- ever sees it. Unchecked, the command never left the box and the
            -- plan died eight seconds later reporting a failed SAVE for an
            -- import that was never attempted. squad_rule_codes.lua says the
            -- same thing about its own import command: the code already
            -- carries the name it was exported under, and rename is cheap.
            state.status    = string.format(
                'That name will not fit on the same line as this code -- %d characters at most here. Import it unnamed and rename it.',
                math.max(0, 114 - #codes[#codes]));
            state.statusBad = true;
        else
            local commands = {};

            for index, code in ipairs(codes) do
                -- The name rides on the LAST part only: every part before it is
                -- answered with "still waiting" and a name handed to one of
                -- those would be read and thrown away.
                if (index == #codes and #name > 0) then
                    table.insert(commands, string.format('!dwg import %s %s', code, name));
                else
                    table.insert(commands, string.format('!dwg import %s', code));
                end
            end

            -- The imported set becomes the document on screen the moment it
            -- exists, the same way a copy does.
            if (#name > 0) then
                editor.pendingRef = name;
                editor.touched    = false;
            end

            startPlan(commands, string.format('Importing %d line%s...', #codes, #codes == 1 and '' or 's'));

            -- THE BOXES ARE NOT CLEARED, and that is the point. The plan runs
            -- asynchronously and the commonest refusal is a name already in
            -- use -- so the retry is "type a different name and click again".
            -- Clearing optimistically would throw away the code the player
            -- pasted at the exact moment they need it back.
        end
    end

    tooltipOnHover(TIPS.importBtn);
end

-- Ten shipped sets a page. The roster grew to thirty (one per job and role,
-- 2026-07-27) and a single column of thirty buries the four a new player
-- actually reaches for first. The page number is client-side chrome, not
-- world state: it survives a Refresh, and the clamp below handles a roster
-- that shrank while it was open.
local PRESET_PAGE = 10;
local presetPage  = 1;
local presetFind  = T{ '' };

--[[
* The find box (1.10.0).
*
* There are FORTY shipped sets and the tab shows ten at a time, so finding the
* one written for a job meant paging until it appeared -- and the thing that
* tells them apart is the server's summary, which the pager cannot see. The
* needle matches a set's name OR its summary, because "the one for a paladin"
* is a sentence about the summary far more often than it is a name.
*
* Matched once per (roster, needle) rather than once per frame: forty
* string.lower calls and eighty string.find calls, sixty times a second, is a
* lot of work to decide which ten rows to draw.
--]]
local presetMatch = { rev = -1, needle = nil, list = {} };

local function matchingPresets()
    local needle = string.lower(presetFind[1] or '');

    if (presetMatch.rev == state.rev and presetMatch.needle == needle) then
        return presetMatch.list;
    end

    local list = {};

    for index, preset in ipairs(state.presets) do
        if (needle == ''
                or string.find(string.lower(preset.name or ''), needle, 1, true) ~= nil
                or string.find(string.lower(preset.summary or ''), needle, 1, true) ~= nil) then
            table.insert(list, { index = index, preset = preset });
        end
    end

    presetMatch.rev    = state.rev;
    presetMatch.needle = needle;
    presetMatch.list   = list;

    return list;
end

local function presetsTab()
    need('presets', 0, '!dwg presets');

    imgui.Text('Shipped sets -- always available, never edited. Assign one, or copy it and make it yours.');

    if (#state.presets == 0) then
        if (gaveUp('presets')) then
            imgui.TextWrapped('The server did not answer for the shipped sets. Press Refresh above to ask again.');
        else
            imgui.Text('Fetching...');
        end

        return;
    end

    imgui.Text('Assign to');
    imgui.SameLine();
    assignTargetCombo('presets');
    imgui.SameLine();

    imgui.Text('Find');
    imgui.SameLine();
    imgui.PushItemWidth(180);
    imgui.InputTextWithHint('##presetfind', 'job or role', presetFind, 32);
    imgui.PopItemWidth();
    tooltipOnHover(TIPS.presetFind);
    imgui.SameLine();

    if (imgui.SmallButton('Clear##presetfindclear')) then
        presetFind[1] = '';
    end

    tooltipOnHover(TIPS.presetFindClear);

    local matches = matchingPresets();

    -- Said once for the whole page rather than once per row: the sentence only
    -- changes when the Assign box does.
    local assignTip = string.format(TIPS.presetAssign, state.assignTo or 'whoever the box above names');

    imgui.SameLine();
    imgui.TextDisabled(string.format('%d of %d', #matches, #state.presets));

    if (#matches == 0) then
        imgui.Separator();
        imgui.TextWrapped(string.format('No shipped set matches "%s". The roster is named by job and by role -- try "whm", "tank" or "heal".',
            presetFind[1] or ''));

        return;
    end

    local pages = math.ceil(#matches / PRESET_PAGE);

    if (presetPage > pages) then
        presetPage = pages;
    end

    if (presetPage < 1) then
        presetPage = 1;
    end

    if (pages > 1) then
        -- Both arrows always draw, and the one that can do nothing says so
        -- rather than doing nothing: a live button that ignores a click reads
        -- as a broken button.
        local first = presetPage <= 1;
        local last  = presetPage >= pages;

        if (imgui.SmallButton('< Prev##pp_prev') and not first) then
            presetPage = presetPage - 1;
        end

        tooltipOnHover(first and TIPS.pageFirst or TIPS.pagePrev);

        imgui.SameLine();
        imgui.TextDisabled(string.format('page %d of %d', presetPage, pages));
        imgui.SameLine();

        if (imgui.SmallButton('Next >##pp_next') and not last) then
            presetPage = presetPage + 1;
        end

        tooltipOnHover(last and TIPS.pageLast or TIPS.pageNext);
    end

    for slot = (presetPage - 1) * PRESET_PAGE + 1, math.min(presetPage * PRESET_PAGE, #matches) do
        -- The widget ids stay keyed on the set's place in the ROSTER, not on
        -- its place in the filtered page: an id that moves as the player types
        -- hands one row's click to another row.
        local index  = matches[slot].index;
        local preset = matches[slot].preset;

        imgui.Separator();
        imgui.TextColored(COLOR_BADGE, preset.name);
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d rules', preset.count));

        imgui.TextWrapped(preset.summary or '');

        if (imgui.SmallButton(string.format('View##pv_%d', index))) then
            if (editor.touched) then
                state.status    = 'Save or revert your edits before opening another set.';
                state.statusBad = true;
            else
                loadIntoEditor(preset.name);
            end
        end

        tooltipOnHover(TIPS.view);

        imgui.SameLine();

        if (imgui.SmallButton(string.format('Assign##pa_%d', index))) then
            if (state.assignTo ~= nil) then
                startPlan({ string.format('!dwg use %s "preset:%s"', state.assignTo, preset.name) },
                    string.format('Assigning %s...', preset.name));
            else
                state.status    = 'Pick who runs it in the Assign box on the Editor tab first.';
                state.statusBad = true;
            end
        end

        tooltipOnHover(assignTip);
    end
end

-- The Party tab (2026-08-16): whole-squad snapshots, the gambit twin of
-- dwjobs' presets. Save asks nothing else of the player -- the server
-- snapshots what is assigned RIGHT NOW -- so unlike dwjobs there is no
-- staged-changes guard to need. Delete asks twice, keyed on the name so
-- pressing anything else disarms it.
local partyDeleteArm = nil;

local function partyTab()
    if (partyUnsupported) then
        imgui.TextWrapped('This server does not have party presets yet. Everything else still works.');

        return;
    end

    if (vocab == nil) then
        vocabNotice();

        return;
    end

    need('party', 0, '!dwg party');
    need('list', 0, '!dwg list');

    imgui.TextWrapped('Party presets -- one name for how the whole squad fights. Save remembers every assignment as it stands; Load brings it back.');
    imgui.TextWrapped('A renamed set follows into its presets on its own. A character whose set was deleted since the save is skipped, and keeps running what it was.');

    local saveBox = nameBoxOf('partysave');

    imgui.PushItemWidth(140);
    imgui.InputText('##partysave', saveBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    tooltipOnHover(TIPS.partyName);
    imgui.SameLine();

    if (imgui.Button('Save party preset##party_save')) then
        partyDeleteArm = nil;

        local name = tidyName(saveBox[1]);

        if (not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        else
            startPlan({ string.format('!dwg party save "%s"', name) },
                string.format('Saving party preset "%s"...', name));

            saveBox[1] = '';
        end
    end

    tooltipOnHover(TIPS.partySave);

    if (#state.loadouts == 0) then
        imgui.Separator();

        -- "None saved yet" is a lie when the answer never arrived, and it is
        -- the kind of lie a player acts on by saving a second one.
        if (gaveUp('party')) then
            imgui.TextWrapped('The server did not answer for your party presets. Press Refresh above to ask again.');
        else
            imgui.TextDisabled('No party presets saved yet.');
        end

        return;
    end

    for index, loadout in ipairs(state.loadouts) do
        imgui.Separator();
        imgui.TextColored(COLOR_BADGE, loadout.name);
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d character%s', loadout.members, loadout.members == 1 and '' or 's'));

        if (imgui.SmallButton(string.format('Load##py_use_%d', index))) then
            partyDeleteArm = nil;

            startPlan({ string.format('!dwg party use "%s"', loadout.name) },
                string.format('Loading party preset "%s"...', loadout.name));
        end

        tooltipOnHover(TIPS.partyLoad);

        imgui.SameLine();

        if (partyDeleteArm == loadout.name) then
            if (imgui.SmallButton(string.format('Really delete?##py_del_%d', index))) then
                partyDeleteArm = nil;

                startPlan({ string.format('!dwg party delete "%s"', loadout.name) },
                    string.format('Deleting party preset "%s"...', loadout.name));
            end

            tooltipOnHover(TIPS.partyDeleteArmed);
        else
            if (imgui.SmallButton(string.format('Delete##py_del_%d', index))) then
                partyDeleteArm = loadout.name;
            end

            tooltipOnHover(TIPS.partyDelete);
        end
    end
end

local function renderWindow()
    -- forgetAll, not forget (1.15.0): Refresh re-fetches the vocabulary as
    -- well, which is what TIPS.refresh has always promised it did.
    if (imgui.Button('Refresh')) then
        forgetAll();
    end

    tooltipOnHover(TIPS.refresh);

    imgui.SameLine();

    local pending = #readQueue + #plan + (planWait ~= nil and 1 or 0);

    if (pending > 0) then
        imgui.TextDisabled(string.format('%d queued...', pending));
        tooltipOnHover(TIPS.queued);
    else
        imgui.TextDisabled('');
    end

    -- The message line gets its own row and errors are red: a refusal's
    -- reason is the only thing telling the player what to do instead.
    --
    -- WRAPPED, AND THE ROW IS ALWAYS THERE (2026-09-06). A server refusal runs
    -- to the protocol's whole 130-byte budget and was drawn as one unbroken
    -- line, so the longest and most important sentences in the window ran off
    -- the right edge of a window with NoScrollbar -- there was no way to read
    -- the end of them. And drawing nothing when there is nothing to say moved
    -- everything below up by a line the moment a sentence cleared.
    imgui.PushTextWrapPos(0);

    if (state.status == nil or state.status == '') then
        imgui.TextDisabled('');
    elseif (state.statusBad) then
        imgui.TextColored(COLOR_ERROR, state.status);
    else
        imgui.TextColored(COLOR_OK, state.status);
    end

    imgui.PopTextWrapPos();

    imgui.Separator();

    leftPane();

    -- The vocabulary fetch is advanced from here, whatever tab is showing
    -- (1.15.0): a STALE copy keeps the editor drawing, so editorTab never
    -- reaches its fetching notice, and without this nothing would ever ask
    -- for the replacement. After leftPane, so the world is still asked first.
    needVocab();

    imgui.SameLine();

    imgui.BeginChild('##dwg_right', { 0, 0 }, ImGuiChildFlags_None);

    if (imgui.BeginTabBar('##dwg_tabs')) then
        -- The tip goes immediately after BeginTabItem and OUTSIDE the `if`: a
        -- tab strip is a row of items and IsItemHovered is about the one just
        -- submitted, so a tip inside the branch would only ever be reachable
        -- on the tab the player is already reading.
        local editorOpen = imgui.BeginTabItem('Editor');

        tooltipOnHover(TIPS.tabEditor);

        if (editorOpen) then
            editorTab();
            imgui.EndTabItem();
        end

        local partyOpen = imgui.BeginTabItem('Party');

        tooltipOnHover(TIPS.tabParty);

        if (partyOpen) then
            partyTab();
            imgui.EndTabItem();
        end

        local shippedOpen = imgui.BeginTabItem('Shipped sets');

        tooltipOnHover(TIPS.tabShipped);

        if (shippedOpen) then
            presetsTab();
            imgui.EndTabItem();
        end

        local shareOpen = imgui.BeginTabItem('Share');

        tooltipOnHover(TIPS.tabShare);

        if (shareOpen) then
            shareTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    imgui.EndChild();
end

--[[
* The render pass, wrapped so a mistake costs one frame rather than the addon:
* an error thrown inside d3d_present is raised sixty times a second and the
* host answers a long enough run of them by unloading the addon. Begin/End
* stay outside the pcall to keep ImGui's stack balanced; the error is reported
* once; the window closes itself. Everything it does is still reachable as
* !squad rules commands, so closing it is a fallback rather than a dead end.
--]]
-- Closed the first time SetNextWindowSizeConstraints refuses; see the call.
local constraintsBroken = false;

ashita.events.register('d3d_present', 'dwgambits_present', function ()
    -- Before the visibility check: a Save issued a moment before closing the
    -- window still has to finish reaching the server.
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    -- 1120x620 until 2026-09-06, which was a size the rule table did not fit
    -- in: the left pane is 205 of it, and seven columns of editor need a shade
    -- over a thousand of what is left. FirstUseEver, so a window that has
    -- already been placed keeps whatever the player dragged it to -- the two
    -- text columns stretch now, so widening it is what fixes a cramped one.
    imgui.SetNextWindowSize({ 1320, 660 }, ImGuiCond_FirstUseEver);

    -- AND A FLOOR UNDER IT. Nothing stopped the window being dragged down to a
    -- title bar: the tab strip vanished first, then the footer buttons, and
    -- the only way back was to delete imgui.ini. The minimum is the width the
    -- left pane plus a readable Who/When/Do needs, and the height of the
    -- posture strip plus the footer plus a couple of rules.
    --
    -- PCALL'D AND LATCHED (2026-09-06, review). This call sits OUTSIDE the
    -- render pcall, and a player's Ashita is whatever they installed first: a
    -- binding that is not there is a raise in d3d_present sixty times a second
    -- with no window to close, which the host answers by unloading the addon.
    -- Refused once, never asked again, and the window simply has no floor --
    -- which is 1.9.0. dwmerits' shape.
    if (not constraintsBroken) then
        if (not pcall(imgui.SetNextWindowSizeConstraints, { 980, 420 }, { 99999, 99999 })) then
            constraintsBroken = true;
        end
    end

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Gambits##dwgambits', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwgambits'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwgambits'):append(chat.message('Window closed. Everything it does also works as !squad rules commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Watch what the player types, so the window keeps up with edits made outside
* it. `!squad rules ...` answers in prose this addon never sees, so the only
* way to notice is to notice the question. Every other outgoing line still
* counts against the chat throttle -- the client's rate limit is on chat, not
* on this addon -- so foreign lines stamp the send clock.
--]]
ashita.events.register('packet_out', 'dwgambits_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower();

    -- ON A WORD BOUNDARY. A four-character prefix test also matched `!dwgm`,
    -- so every line dwgmpanel sent looked like one of ours and this addon
    -- skipped its own backoff stamp for it -- the throttle exists to stop us
    -- talking over somebody else's traffic, and it stood down for exactly the
    -- traffic it should have yielded to. The bare form is load-bearing:
    -- need('rules', 0, '!dwg') sends `!dwg` with no argument and no trailing
    -- space, so the space test alone would stamp our own send.
    if (lower ~= '!dwg' and lower:sub(1, 5) ~= '!dwg ') then
        lastSend = os.clock();
    end

    -- ON A WORD BOUNDARY HERE TOO (2026-09-06), for the reason the `!dwg` test
    -- above carries: a bare prefix also matches somebody else's `!squadfoo`,
    -- and this branch answers by throwing away every cached answer and issuing
    -- a read.
    if (lower ~= '!squad' and lower:sub(1, 7) ~= '!squad ') then
        return;
    end

    forget();

    -- A typed edit may have changed the set on screen. An untouched editor
    -- follows along; a touched one is the player's, and the adoption logic
    -- will flag the divergence rather than overwrite it.
    --
    -- ONLY FOR A `rules` LINE (2026-09-06). Every other !squad verb changes
    -- members rather than documents, and forget() already re-reads those from
    -- the render loop -- so reloading on all of them spent a `show` on every
    -- `!squad call`, `!squad dismiss` and `!squad follow` the player typed,
    -- out of the same chat throttle the typed line itself is competing for.
    -- `rule` is the dispatch's own alias for `rules` (squad.lua:1283).
    local verb = string.match(lower, '^!squad%s+(%a+)');

    if (verb ~= 'rules' and verb ~= 'rule') then
        return;
    end

    if (editor.name ~= nil and not editor.touched and not editor.shipped) then
        loadIntoEditor(editor.name);
    end
end);

ashita.events.register('command', 'dwgambits_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Gambits`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/gambits' and first ~= '/dwgambits') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        forgetAll();

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported`
        -- exists to stop one bad frame printing sixty lines a second, not to
        -- silence a different error a week later.
        state.reported = false;

        forget();
    end
end);

ashita.events.register('load', 'dwgambits_load', function ()
    print(chat.header('dwgambits'):append(chat.message('/gambits opens the rule editor. Everything it does also works typed as !squad rules.')));
end);

-- A login is a different account view; the world state resets. The editor's
-- unsaved document deliberately survives -- 0x000A also fires on every zone
-- line, and a zone must not eat an hour of rule writing. If the document
-- belongs to the wrong account after a relog, Save is refused server-side
-- with a sentence, which is the correct outcome.
ashita.events.register('packet_in', 'dwgambits_zonein', function (e)
    if (e.id == 0x000A) then
        state.members     = {};
        state.memberOrder = {};
        state.sets        = {};
        state.assigns     = {};
        state.presets     = {};
        state.loadouts    = {};
        state.verdicts    = {};
        state.hints       = {};
        state.codes       = {};
        state.codeTotal   = 0;
        state.codesFor    = nil;
        state.selected    = nil;
        state.assignTo    = nil;
        state.rev         = state.rev + 1;

        -- DISARM BOTH TWO-CLICK DELETES (2026-09-06). They are armed by the
        -- first click and disarmed by any other button, but a zone line is not
        -- a button: a player who armed "Really delete?" and then zoned instead
        -- came back to a window whose next click on that spot deletes, with
        -- nothing on screen to say the arming survived a load screen. The
        -- listings behind them have just been emptied here anyway, so nothing
        -- is lost by asking again.
        editor.armDelete = 0;
        editor.armRevert = false;
        partyDeleteArm   = nil;

        -- Asked again on the other side: the server may have grown the hints
        -- or party verbs since the last look (a map restart logs everyone out).
        hintsUnsupported = false;
        partyUnsupported = false;

        -- ...and its vocabulary (1.15.0), for the same reason: a restart is
        -- when the whitelist grows, and growth never moves its version. The
        -- copy in use stays in use until the fresh one is whole, and nothing is
        -- asked until the window is next open (reads are the window's).
        forgetAll();
    end
end);
