--[[
* DriftwoodXI -- dwspoils
*
* Augmented gear off ordinary kills, in a window. Every monster that pays you
* experience has a small chance of handing you a piece of equipment carrying
* one to four random augments, levelled to the monster that died, straight
* into your bags -- no treasure pool, no lot, no trade. This window draws what
* your ACCOUNT has been handed: the last thirty, newest first, with the item's
* own icon and card, WHICH AUGMENTS it rolled, the monster and its level, the
* zone, how long ago, and where it landed when that was not your inventory. A
* second tab holds the server's last hundred FOUR-augment awards, which are the
* ones the world hears about, and those name their four as well.
*
* 1.3.0 (2026-09-27) ADDS THE RUNES TAB, and with it the first button this
* window has ever had that SPENDS something. A Rune is a one-use token an
* experience-yielding kill can hand your account on top of (never instead of)
* the spoils roll; it names the augment it attaches ("Rune LXXVIII" is augment
* 78), and applying it puts that one augment on one piece of your gear. The
* tab lists every kind the server knows, grouped by where it fits, with what
* your account has found and still holds -- out of runecatalog.lua beside this
* file, which is GENERATED (tools/dwspoils/gen_rune_catalog.py) from the
* server's own Super Auged pool, so the ranges drawn here are the server's.
* `Apply...` opens a panel inside the window that asks the server which of
* your pieces the Rune fits (`!dwsp runegear`), shows the four slots of the
* one you pick and exactly what will happen to them, and only after a
* Confirm sends `!dwsp runeapply` -- ONE outstanding at a time, never re-sent
* by anything but another click, and refused by the server if the piece
* moved or changed since the list was drawn (the stamp). An answer lost on
* the way back is settled by READING: the wallet and the bags are read again
* and the panel says whether the Rune was spent before it offers another
* Confirm; a late answer is held to the Rune and the piece it names, so it
* can never settle a different Confirm. The server decides
* everything that matters: whether it fits, which slot it lands in, the rank
* it rolls. The window says what came back -- the words, "rank R of lo-hi",
* and a low / average / high / max verdict. Still no odds: nothing on this
* wire says how often a Rune turns up, and nothing here does either. All of
* it is ADDITIVE on protocol 1 behind the Super tab's kind of latch.
*
* 1.2.2 (2026-09-26, owner: "30 -> 100 in the Hall of Four and Super Auged
* tabs"). The row ceiling is the SERVER's (spoils_core.lua HALL_LIMIT and the
* store's clamp); this window never capped a list, it only said "thirty" in
* its tips. Both hall tables already scroll inside a fixed-height child
* (ScrollY + footerReserve), so a hundred rows is a longer scroll, not a
* taller window. My Spoils stays thirty.
*
* 1.1.0 (2026-09-21) IS WHEN IT STARTED NAMING THEM. Both tabs used to say how
* MANY augments a piece carried and nothing about which -- the hover card's
* last line was a bare "4 augment(s) on this piece" -- so the one fact the
* whole feature exists to produce was the one fact this window did not draw.
* The names are decoded here, from the ids the server already sent: the same
* GENERATED augcatalog.lua dwquest, dwbags, dwah and dwwarehouse carry, and
* the same rank arithmetic, so a piece reads the same in every window on the
* server. The Hall of Four's `w|` record grew an `augs` field for it, appended
* last, which is why an older copy of this addon keeps working unchanged.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited whole
* through dwunleashed). It carries no item table, no rate table and no clock
* of its own: everything it draws arrived on the wire as records, and the only
* lines it ever sends are `!dwsp mine`, `!dwsp hall`, (1.2.0)
* `!dwsp superauged` and (1.3.0) `!dwsp runes`, `!dwsp runegear` and
* `!dwsp runeapply`, which reach exactly the dispatch the typed `!spoils`
* verbs reach. Its ONE spending button is the Runes panel's Confirm, and
* even that decides nothing: it names a Rune, a piece and a slot the server
* just drew for it, and the server re-checks every one of them. Nothing here
* moves your character or touches a spoils roll. It cannot: the wire has no
* verb for any of that.
*
* TURN IT OFF AND NOTHING IS LOST. `!spoils` says all of it typed, and the
* `[Spoils] ` lines the server prints on every award arrive whether this is
* loaded or not.
*
* IT SAYS NOTHING ABOUT THE ODDS beyond "a small chance" (owner, 2026-09-20):
* not the rate, not the split, and nothing at all about how a dry run is
* treated. None of that is on this wire -- there is no field a future version
* of this window could read it out of by accident -- and the quiet is the
* feature.
*
* IT TAKES NO ZONE-IN SLOT. The first ask is LAZY -- the first frame the
* window is actually shown in a zone -- so a player who never opens it never
* handshakes and the login burst is exactly as long as it was before this
* addon existed (the dwparse decision; see dwecho.lua's ZONE_ORDER, which this
* addon is deliberately absent from). While the window is open it re-asks the
* tab on screen every sixty seconds, on Refresh, and once a couple of seconds
* after it sees one of the server's own `[Spoils] You obtain` lines go by --
* which is the only moment the list is KNOWN to have changed.
*
* 1.2.0 (2026-09-26) ADDS THE SUPER AUGED TAB. Five percent of the rolls a
* player WINS are Super Auged: one to four augments from a stronger pool than
* the casket's, announced to the whole server whatever their count. The third
* tab is the Hall of Four's shape for every one of them, with the count drawn
* as pips (`!dwsp superauged`, record `s|`); My Spoils marks your own; the
* header counts them. All of it is ADDITIVE on protocol 1 -- `c|` and `r|`
* each grew an APPENDED field -- so this window against a server from before
* it gets the door's `unknown verb "superauged"` sentence, latches on it
* quietly, and draws "not on this server yet" in that one tab; every other tab
* works exactly as it did (the additive-verb latch, dwbags' shape).
*
* Over `!dwsp` (`documentation/dwsp_protocol.md`); the offline guard is
* tools/dwspoils/harness_dwspoils.py.
--]]

addon.name    = 'dwspoils';
addon.author  = 'DriftwoodXI';
addon.version = '1.3.0';
addon.desc    = 'DriftwoodXI Spoils: the augmented gear ordinary kills have handed your account, your Runes, the server\'s four-augment hall and its Super Auged finds.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

local C = ffi.C;

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. The FIRST
-- two-letter door: dwa.lua through dwz.lua are all doors already, so `dwsp`
-- and `_DWSPDATA` are where the registry in dww.lua's header goes next.
local DATA_SENDER = '_DWSPDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

--[[
* THE TAG THE SERVER PREFIXES EVERY SPOILS SENTENCE WITH. This addon does NOT
* block or reroute those lines -- they are ordinary system chat and the player
* is meant to read them where the rest of the game's sentences land. It reads
* them only as a NUDGE: an award has just happened, so the list on screen is
* stale, and a re-ask a couple of seconds later collects it.
*
* THE THREE SENTENCES, AND WHY TWO OF THEM ARE MATCHED AND THE THIRD IS NOT
* (2026-09-20, independent review). spoils_core.lua says exactly three things
* under this tag:
*
*   1. the award -- `You obtain <item> with N augments from <mob>.`
*   2. the LOST award -- `<A Mob> yielded <item> with N augments, but nothing
*      on your account could hold it and it was lost.`
*   3. the world line, to EVERYBODY -- `<Name> obtained <item> with four
*      augments from DWSpoils when slaying <mob>!`
*
* The first cut matched `[Spoils] You obtain` and got both halves wrong. It
* missed (2) -- which is the row most worth drawing promptly, because a lost
* award is the one the player will want to see booked -- and it matched (3)
* for a character named `You`, whose every four-augment award would have made
* every open window on the server re-ask at once.
*
* So: the award is matched WITH ITS TRAILING SPACE, which is what separates
* `You obtain ` from the world line's `You obtained `; and the lost line is
* matched on its own unmistakable tail, because its FIRST word is the mob's
* name and there is no fixed prefix to anchor on. The world line contains
* neither and can never nudge anything.
*
* ALL THREE LITERALS ARE THE SERVER'S OWN. Part C of
* tools/dwspoils/harness_dwspoils.py parses the tag and both format strings
* out of modules/driftwoodxi/spoils_core.lua and the three constants below
* out of this file, and fails when they stop agreeing -- so rewording either
* side turns the harness red instead of silently costing the nudge.
--]]
local NOTICE_TAG  = '[Spoils] ';
local NUDGE_AWARD = '[Spoils] You obtain ';
local NUDGE_LOST  = 'nothing on your account could hold it and it was lost.';

--[[
* THE MODE GATE (dwnemesis 1.3.1's lesson, inherited whole). A line is
* anything text_in sees, INCLUDING another player's yell -- so a player typing
* "[Spoils] You obtain deez nuts" would otherwise make every client in earshot
* re-ask the server. The server writes every module notice on SYSTEM_3, which
* the client hands to text_in as mode 121 (low byte); a player cannot choose
* that mode. An allow list of one, and a wrong number here merely costs the
* nudge -- the sixty-second poll still collects the award.
--]]
local NOTICE_MODE = 121;

--[[
* EVERY NUMBER OFF THE WIRE COMES THROUGH HERE (the dwnemesis shape). LuaJIT
* -- which is what Ashita runs -- answers `tonumber` for 'inf', 'nan', '0x10'
* and '2.5' as readily as for '7', and everything downstream is a pile of
* string.format('%d'). A field that is not a plain integer inside the wire's
* own range is not a number this window can draw, so it reads as the record's
* default and the rest of the record still lands.
--]]
local WIRE_MAX = 2147483647;

local function wireInt(text, default)
    local value = tonumber(text);

    if (value == nil
            or value ~= value                            -- nan
            or value < -WIRE_MAX or value > WIRE_MAX     -- inf, and anything absurd
            or value ~= math.floor(value)) then
        return default or 0;
    end

    return value;
end

--[[
* AUGMENT NAMES -- augcatalog.lua beside this file, the same GENERATED catalog
* dwquest, dwbags, dwah and dwwarehouse carry (tools/dwquest/
* gen_augment_catalog.py writes dwquest's; every other copy is byte-identical
* to it, which PLANS/Check-QuestAugments.ps1 and Part C of
* tools/dwspoils/harness_dwspoils.py both assert).
*
* WHY A COPY RATHER THAN A WIRE FIELD. The words are two to forty bytes each
* and a record is 130; four augments in prose would not fit in the row they
* belong to, let alone beside the item, the monster, the zone and the landing.
* So the server sends what it sends everywhere else -- `id:value` pairs -- and
* every window on the server turns them into the same sentence out of the same
* generated table. A second table here would be a second answer.
*
* pcall'd because a half-synced addon folder is a real deployment state: with
* no catalog the rows and the card still list their augments, as the raw ids
* they are, and nothing else about the window changes.
--]]
local haveAugCatalog, augcatalog = pcall(require, 'augcatalog');

if (not haveAugCatalog or type(augcatalog) ~= 'table' or type(augcatalog.augments) ~= 'table') then
    augcatalog = { augments = { } };
end

--[[
* ONE AUGMENT'S MAGNITUDE AT A GIVEN RANK -- dwbags' `augmentWords` character
* for character, which is dwquest's. `rank` is the HUMAN rank: the stored
* five-bit exdata value plus one, and the wire's `augs` field carries the
* STORED number (spoils_augments.lua writes `rank - 1`), so every call site
* below adds the one.
*
* A substitutable entry has its digit runs recomputed for this rank -- term k
* applies to the k-th digit run, a bare number n means n + stored, a pair
* { b, s } means b + stored * s. The generator emits a term ONLY where it
* verified that against the engine's own formula (item_equipment.cpp
* SetAugmentMod: the stored value is ADDED once, never multiplied), so this
* never invents a magnitude.
--]]
local function augmentWords(augid, rank)
    local entry = augcatalog.augments[augid];

    if (entry == nil) then
        return string.format('augment %d', augid);
    end

    local label  = entry.l;
    local stored = rank - 1;

    if (entry.m == nil) then
        return label;
    end

    if (stored > 0) then
        local k = 0;

        label = string.gsub(label, '%d+', function (digits)
            k = k + 1;

            local term = entry.m[k];

            if (term == nil) then
                return digits;
            end

            if (type(term) == 'table') then
                return tostring(term[1] + stored * term[2]);
            end

            return tostring(term + stored);
        end);
    end

    return label;
end

--[[
* One augment as this window names it: the magnitude AT THIS RANK, and the
* rank itself whenever it is not 1. dwbags' `augmentText`, and the rank is
* stated ALONGSIDE the magnitude for the reason that file records at length
* (owner report, 2026-09-11): a card that printed a bare `Mag. Evasion +7`
* beside a reference showing the catalog's rank-1 `+3` read as the window
* hiding eight points. +7 IS what rank 5 grants.
--]]
local function augmentText(augid, rank)
    if (augcatalog.augments[augid] == nil) then
        return string.format('augment %d rank %d', augid, rank);
    end

    local label = augmentWords(augid, rank);

    if (rank > 1) then
        return string.format('%s (rank %d)', label, rank);
    end

    return label;
end

--[[
* THE WIRE'S `augs` FIELD, DECODED ONCE, AT PARSE TIME -- never per frame.
* A hundred hall rows times four augments is 400 string.gsub calls, and a row is
* redrawn sixty times a second for as long as the window is open; composing
* these in the render pass would be seven thousand substitutions a second to
* produce text that cannot change until the next answer arrives (the dwcpx
* per-frame-cost rule).
*
* Answers a LIST (one entry per augment, for the card) and a single compact
* LINE (for the row), or nil and nil when there is nothing to say -- which is
* what an old ledger row with no `augs`, an old server that does not send the
* Hall's field yet, and an empty string all look like. Every caller draws the
* count sentence it drew before when it gets nil, so nothing regresses.
*
* THE TWO DIFFER BY THE RANK AND BY NOTHING ELSE. The card is a reference and
* says `HP+6 (rank 6)`; the row is a glance and says `HP+6`, which is also
* exactly what the server's own `[Spoils] It carries ...` chat line and its
* map-log line say. The MAGNITUDE is the same figure in all four places --
* that is the part a player compares against their own bag -- and the rank
* appears only where there is room to explain it.
--]]
local function decodeAugs(text)
    if (type(text) ~= 'string' or text == '') then
        return nil, nil;
    end

    local list  = { };
    local short = { };

    for id, stored in string.gmatch(text, '(%d+):(%d+)') do
        local rank = tonumber(stored) + 1;

        list[#list + 1]  = augmentText(tonumber(id), rank);
        short[#short + 1] = augmentWords(tonumber(id), rank);
    end

    if (#list == 0) then
        return nil, nil;
    end

    return list, table.concat(short, ', ');
end

--[[
* A RANK RANGE IN WORDS (1.3.0). `lo .. hi` when the catalog can compute the
* magnitude at both ends ("HP+10 .. HP+40"); the label and the ranks when it
* cannot, because a label whose numbers are not per-rank substitutable reads
* the same at every rank and "HP+ counted by two .. HP+ counted by two" would
* say nothing. The ranks are the SERVER's (g|/a| records, or the generated
* catalog) -- this only spells them.
--]]
local function spanWords(loWords, hiWords, lo, hi)
    if (loWords ~= hiWords) then
        return string.format('%s .. %s', loWords, hiWords);
    end

    return string.format('%s, rank %d-%d', loWords, lo, hi);
end

local function rangeWords(augid, lo, hi)
    return spanWords(augmentWords(augid, lo), augmentWords(augid, hi), lo, hi);
end

-- The same range as a clause for the confirm step's sentence.
local function rangeLong(augid, lo, hi)
    local loWords, hiWords = augmentWords(augid, lo), augmentWords(augid, hi);

    if (loWords ~= hiWords) then
        return string.format('anywhere from %s to %s (rank %d-%d)', loWords, hiWords, lo, hi);
    end

    return string.format('%s at any rank from %d to %d', loWords, lo, hi);
end

--[[
* THE RUNE CATALOG (1.3.0) -- runecatalog.lua beside this file, GENERATED by
* tools/dwspoils/gen_rune_catalog.py from the server's Super Auged pool
* (modules/driftwoodxi/super_augments.lua) and the short names in
* modules/driftwoodxi/spoils_runes.lua. One entry per augment id the Super
* list carries: its numeral, its short name, the world line's fits phrase,
* the group it is drawn under, and every range it rolls by item class.
*
* WHY A GENERATED COPY AND NOT A WIRE RECORD: augcatalog.lua's reason. Ninety-
* odd rows of ranges would be a hundred more packets on every ask of a tab
* whose wallet is five numbers; the wallet travels (`q|`/`n|`), the reference
* ships. The generator's --check keeps the two from drifting, and a range
* this file shows is never the one that is ROLLED -- the apply panel draws
* the range the server sent for THAT piece (`g|`), and the server rolls it.
*
* pcall'd for augcatalog's reason: with no catalog the tab still lists the
* Runes the account holds, by numeral and augment id, and the apply panel
* still works, because everything it needs comes off the wire.
--]]
local haveRuneCatalog, runecatalog = pcall(require, 'runecatalog');

if (not haveRuneCatalog or type(runecatalog) ~= 'table' or type(runecatalog.runes) ~= 'table') then
    runecatalog = nil;
end

-- Standard subtractive numerals, the spec's roman(): 78 -> LXXVIII, 1806 ->
-- MDCCCVI. Only ever used when the catalog did not say, so a Rune the catalog
-- names is named exactly as the server's world line names it.
local ROMAN = {
    { 1000, 'M' }, { 900, 'CM' }, { 500, 'D' }, { 400, 'CD' }, { 100, 'C' }, { 90, 'XC' },
    { 50, 'L' }, { 40, 'XL' }, { 10, 'X' }, { 9, 'IX' }, { 5, 'V' }, { 4, 'IV' }, { 1, 'I' },
};

local function roman(n)
    local out = { };

    for _, step in ipairs(ROMAN) do
        while (n >= step[1]) do
            out[#out + 1] = step[2];
            n             = n - step[1];
        end
    end

    return table.concat(out);
end

--[[
* EVERY STRING A RUNE ROW DRAWS, BUILT ONCE AT LOAD (the decodeAugs rule: the
* list is redrawn sixty times a second and none of this can change until the
* addon reloads). `search` is the lowercased haystack the tab's search box is
* matched against; `rangeLines` is the table cell (one line per class when a
* Rune has several); `cardRanges` is the hover card, which always names the
* class and the ranks.
--]]
local RUNE = {
    list    = { },     -- every Rune, catalog order (ascending id)
    byId    = { },
    groups  = { },     -- display order: { key, label, runes }
    count   = 0,
    missing = runecatalog == nil,
    synth   = { },     -- entries made up for ids the catalog does not carry
    widest  = 'Rune MDCCCVI',   -- the widest title, which sizes the list's first column
};

local function prepareRune(entry, groupLabel)
    local id = tonumber(entry.id);

    if (id == nil or id <= 0 or id > 2047 or id ~= math.floor(id)) then
        return nil;
    end

    local r = {
        id         = id,
        roman      = (type(entry.roman) == 'string' and entry.roman ~= '') and entry.roman or roman(id),
        name       = type(entry.name) == 'string' and entry.name or '',
        fits       = type(entry.fits) == 'string' and entry.fits or '',
        group      = type(entry.group) == 'string' and entry.group or 'other',
        rangeLines = { },
        cardRanges = { },
    };

    r.title    = 'Rune ' .. r.roman;
    r.applyBtn = string.format('Apply...##dwsp_rune_apply_%d', id);

    local spans = { };
    local words = { r.title, r.roman, r.name, r.fits, groupLabel or '', tostring(id) };

    for _, range in ipairs(type(entry.ranges) == 'table' and entry.ranges or { }) do
        local lo = type(range) == 'table' and tonumber(range.min) or nil;
        local hi = type(range) == 'table' and tonumber(range.max) or nil;

        if (lo ~= nil and hi ~= nil and lo >= 1 and hi >= lo) then
            local label  = type(range.label) == 'string' and range.label or '';
            local loWord = type(range.lo) == 'string' and range.lo or augmentWords(id, lo);
            local hiWord = type(range.hi) == 'string' and range.hi or augmentWords(id, hi);
            local span   = spanWords(loWord, hiWord, lo, hi);

            spans[#spans + 1] = { label = label, span = span };

            if (loWord ~= hiWord) then
                span = string.format('%s (rank %d-%d)', span, lo, hi);
            end

            r.cardRanges[#r.cardRanges + 1] = label ~= '' and (label .. ': ' .. span) or span;
            words[#words + 1] = label .. ' ' .. loWord .. ' ' .. hiWord;
        end
    end

    if (#spans == 1) then
        r.rangeLines[1] = spans[1].span;
    else
        for _, s in ipairs(spans) do
            r.rangeLines[#r.rangeLines + 1] = s.label ~= '' and (s.label .. ': ' .. s.span) or s.span;
        end
    end

    if (#r.rangeLines == 0) then
        r.rangeLines[1] = '-';
    end

    r.search = string.lower(table.concat(words, ' '));

    return r;
end

if (runecatalog ~= nil) then
    local byKey = { };

    for _, group in ipairs(type(runecatalog.groups) == 'table' and runecatalog.groups or { }) do
        if (type(group) == 'table' and type(group.key) == 'string' and byKey[group.key] == nil) then
            local g = { key = group.key, label = type(group.label) == 'string' and group.label or group.key, runes = { } };

            byKey[g.key] = g;
            RUNE.groups[#RUNE.groups + 1] = g;
        end
    end

    for _, entry in ipairs(runecatalog.runes) do
        local key   = type(entry) == 'table' and type(entry.group) == 'string' and entry.group or 'other';
        local group = byKey[key];

        -- A Rune under a group the catalog did not declare is still drawn --
        -- under "Other", last -- rather than vanishing from a list whose whole
        -- point is that it is every kind.
        if (group == nil) then
            group = { key = key, label = 'Other', runes = { } };

            byKey[key] = group;
            RUNE.groups[#RUNE.groups + 1] = group;
        end

        local r = type(entry) == 'table' and prepareRune(entry, group.label) or nil;

        if (r ~= nil and RUNE.byId[r.id] == nil) then
            RUNE.byId[r.id]               = r;
            RUNE.list[#RUNE.list + 1]     = r;
            group.runes[#group.runes + 1] = r;

            if (#r.title > #RUNE.widest) then
                RUNE.widest = r.title;
            end
        end
    end

    RUNE.count = tonumber(runecatalog.count) or #RUNE.list;
end

-- The catalog's entry for a Rune, or one made up from the id alone -- which is
-- every Rune on a half-synced folder, and a Rune the server grew after this
-- copy of the catalog was generated.
local function runeInfo(id)
    local r = RUNE.byId[id] or RUNE.synth[id];

    if (r == nil) then
        local entry = augcatalog.augments[id];

        r = prepareRune({ id = id, name = entry ~= nil and entry.l or string.format('augment %d', id) }, '');

        if (r == nil) then
            r = { id = id, roman = tostring(id), title = string.format('Rune %d', id), name = '', fits = '',
                  rangeLines = { '-' }, cardRanges = { }, search = '', applyBtn = string.format('Apply...##dwsp_rune_apply_%d', id) };
        end

        r.unlisted     = true;
        RUNE.synth[id] = r;
    end

    return r;
end

--[[
* Persisted presentation state, through Ashita's settings library (the
* dwunleashed shape). ONE flat scalar: which tab this character was last
* looking at. Nothing the server said is ever written to disk -- a cached
* ledger is a ledger that can be wrong, and this one is cheap to ask for
* again. The window's own size and position are ImGui's business, through the
* FirstUseEver sizing below and its ini file.
*
* THE DEFAULTS ARE A SUGAR TABLE, and that `T` is load-bearing rather than
* decorative: settings.lua calls `defaults:copy(true)` (:180) and
* `settings:merge(defaults)` (:338), both sugar-table methods, so a plain
* table raises 'attempt to call a nil value'. The pcall below hides it at
* load; the library's own UNGUARDED packet_in handler re-loads on the
* zone-enter packet (:538) and Ashita answers a raise inside an event callback
* by UNLOADING THE ADDON -- so a missing `T` works at the desk and then the
* window disappears on the player's next zone line.
--]]
local defaultConfig = T{
    tab = 'mine',
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

local TABS = { 'mine', 'runes', 'hall', 'superauged' };

local function rememberedTab(cfg)
    if (type(cfg) ~= 'table' or type(cfg.tab) ~= 'string') then
        return 'mine';
    end

    for _, key in ipairs(TABS) do
        if (cfg.tab == key) then
            return key;
        end
    end

    return 'mine';
end

--[[
* Outbound: `!dwsp` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat.
--]]
local SEND_INTERVAL = 1.2;

-- The answer clock, per read (the dwfame shape): one retry after five
-- seconds, then the silent latch. An unknown `!` command falls through to
-- PUBLIC /say on a server without dwsp.lua, and the latch is what contains
-- that to two lines rather than one every send interval, forever.
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- How often an OPEN window re-asks the tab on screen. A ledger only moves
-- when something is awarded, and an award announces itself in chat (see
-- NUDGE_PREFIX), so sixty seconds is the backstop rather than the mechanism.
local POLL_INTERVAL = 60.0;

-- How long after an award line to collect it. The server writes the ledger
-- row and the chat line in the same breath, but the row has to be readable
-- by the time the answer is built, and a couple of seconds costs the player
-- nothing they can perceive.
local NUDGE_DELAY = 2.0;

--[[
* THE TWO LINES THIS ADDON EVER SENDS, SPELLED OUT IN FULL.
*
* Written as whole literals rather than built with `'!dwsp ' .. verb`, and the
* reason is a gate rather than taste: harness_dwsuite.py discovers every verb
* every addon sends by reading its `'!dwX <verb>'` literals and proves some
* module under modules/driftwoodxi spells that word. A concatenated verb is
* invisible to that scan -- so the addon would be exempt from the one check
* that catches an addon newer than its server sending a verb the doorway has
* never heard of, whose refusal is a PUBLIC line in chat on every window open.
--]]
local LINES = {
    mine       = '!dwsp mine',
    hall       = '!dwsp hall',
    superauged = '!dwsp superauged',
    runes      = '!dwsp runes',
};

--[[
* THE TWO RUNE LINES THAT CARRY ARGUMENTS (1.3.0), as whole format literals
* for the reason above: each still OPENS `'!dwsp <verb>`, which is all the
* suite's discovery reads. Built in exactly two places -- gearLine() and
* confirmApply() -- and nowhere else.
*
*   runegear  <rune> <loc|all> [name words]
*   runeapply <rune> <loc> <slot> <itemId> <stamp> <slotIndex>
--]]
local RUNEGEAR_LINE  = '!dwsp runegear %d %s';
local RUNEAPPLY_LINE = '!dwsp runeapply %d %d %d %d %s %d';

--[[
* THE ADDITIVE-VERB LATCH FOR `superauged` (1.2.0; dwbags' hints / stack /
* restock flags are the reference). The verb is additive on protocol 1, so
* the `d|` guard cannot see a server that predates it -- the only signal is
* the door's own refusal sentence, `unknown verb "superauged" -- mine|hall`,
* which the writer wraps in a `status` envelope that retires nothing. Without
* this flag that refusal is a red line in chat and, because the Super tab
* re-asks on its poll, a red line every minute forever. Set on that sentence
* (or on a newer door over a binary with no Super hall read yet), consulted
* by ask(), and cleared on the login packet so a server upgraded under a
* running client is asked again. A PLAIN BOOLEAN, not a field of `state`:
* nothing renders a latch.
--]]
local superUnsupported = false;

-- The two sentences that mean "no Super Auged hall on this server yet": an
-- old door's unknown-verb refusal, and a new door over an old binary.
local SUPER_UNKNOWN = 'unknown verb "superauged"';
local SUPER_NOBUILD = 'Super Auged hall is not on this build';

--[[
* THE SAME LATCH FOR THE RUNES TAB (1.3.0). Three verbs arrived together and
* leave together, so ONE flag answers for all of them: the door's refusal of
* any of `runes`, `runegear` or `runeapply` -- each spelled WHOLE, closing
* quote and all, the way SUPER_UNKNOWN is, so a typed `!dwsp rune` (a typo,
* refused as `unknown verb "rune"`) can never latch the tab -- or a new core
* over a binary with no Rune ledger. Set, the Runes tab says "not on this
* server yet" and asks nothing; every other tab is untouched; the zone line
* re-probes. Part C of the harness holds every literal to the server's own
* sentences.
--]]
local runesUnsupported = false;

local RUNES_UNKNOWN = { 'unknown verb "runes"', 'unknown verb "runegear"', 'unknown verb "runeapply"' };
local RUNES_NOBUILD = 'Runes are not on this build';

-- Does this refusal say the server has no Runes? (The latch's one test.)
local function runesRefused(line)
    if (string.find(line, RUNES_NOBUILD, 1, true) ~= nil) then
        return true;
    end

    for _, sentence in ipairs(RUNES_UNKNOWN) do
        if (string.find(line, sentence, 1, true) ~= nil) then
            return true;
        end
    end

    return false;
end

--[[
* THE RUNE NUDGE (1.3.0). A Rune find is said under its OWN tag, the owner's
* `[DWSpoils] `, and never under `[Spoils] ` -- so no Rune sentence can reach
* the award or lost nudges above, which both demand that the line OPEN with
* `[Spoils] `. The finder's personal line is the only Rune sentence that
* means "your wallet moved", and it has the Hall of Four's problem in a new
* place: the WORLD line opens `[DWSpoils] <Name> found Rune ...`, so a
* character called `You` speaks a world line that opens exactly like the
* personal one. The prefix alone cannot tell them apart; the personal line's
* own tail can -- only it says how many you hold now -- so the nudge needs
* BOTH, and the world line can never re-ask a window anywhere.
--]]
local RUNE_TAG        = '[DWSpoils] ';
local NUDGE_RUNE      = '[DWSpoils] You found Rune ';
local NUDGE_RUNE_HELD = '. You now hold ';

-- A refused apply the panel answers by going BACK TO THE LIST: the piece
-- moved or changed between the list and the Confirm (`stale`), the store's
-- slot rule saw a different piece than the list did (`wrongslot`), the same
-- apply already landed (`duplicate`), or the store could not say what the
-- piece holds now (`unverified`). The server names the reason as a word in an
-- `x|` record ahead of its sentence; the stale sentence's own fixed words are
-- the fallback for an answer without one. Each of those sentences tells the
-- player to pick again from a refreshed list, so the panel does not keep
-- holding a piece whose slots it no longer knows. Every other refusal (none
-- held, equipped, does not fit...) keeps the piece on screen.
local RUNE_STALE   = 'has changed since the list was drawn';
local RUNE_RELIST  = { stale = true, wrongslot = true, duplicate = true, unverified = true };

-- A Confirm that was never answered must not hold the panel hostage, and it
-- must never be answered by sending it again: after this long the panel says
-- so and re-reads the wallet and the bags (both reads, both safe) -- and the
-- button comes back only once BOTH have landed and said whether the Rune was
-- spent (see runes.lost). Ten seconds is dwquest's WRITE_TIMEOUT, for its
-- reason.
local APPLY_TIMEOUT = 10.0;

--[[
* WHERE AN AWARD LANDED, by the wire's own code. The window says nothing at
* all for code 0: an item in your inventory is where an item goes, and a
* column that says "Inventory" thirty times is a column that hides the four
* rows worth reading.
--]]
local LANDED_WORD = {
    [0] = '',
    [1] = 'Mog Satchel',
    [2] = 'Mog Sack',
    [3] = 'Mog Case',
    [4] = 'another character',
    [5] = 'delivery box',
    [9] = 'lost',
};

local state = T{
    open = T{ false },

    -- The header counts and the two lists, COMMITTED ON z| from pending
    -- copies so a half-arrived reply can never half-fill the window.
    counts   = nil,      -- the c| record, as one table
    countsAt = nil,      -- os.clock() when it committed, so `now` can be aged
    rows     = nil,      -- the r| rows, newest first
    rowsAt   = nil,
    hall     = nil,      -- the w| rows, newest first
    hallAt   = nil,
    super    = nil,      -- the s| rows, newest first (1.2.0)
    superAt  = nil,

    pendingCounts = nil,
    pendingRows   = nil,
    pendingHall   = nil,
    pendingSuper  = nil,

    inbound   = nil,     -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,   -- a render error is worth saying once, not per frame

    -- The answer clock, keyed by verb: { [verb] = { at, tries } }. Keyed
    -- rather than single because the two reads are independent -- a hall
    -- answer arriving while a mine is outstanding must not mark the mine
    -- answered, or a lost list is never re-asked.
    requested    = T{ },
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until a zone
    -- line re-probes it. A click does NOT lift this one -- an addon that is
    -- the wrong version stays the wrong version.
    refused = false,

    -- The lazy hello has fired in THIS zone. Not "the rows are nil": a server
    -- that answers the ask with a refusal leaves them nil forever, and
    -- re-arming on emptiness asks once per throttle window for as long as the
    -- window stays open (the dwleaderboard lesson).
    helloSent = false,
    polledAt  = T{ },    -- per verb, so switching tabs does not reset the other
    nudgeAt   = nil,     -- os.clock() at which an award line should be collected

    -- Which tab is drawn, restored from the settings file; `wantTab` is a tab
    -- the player named on the command line and is spent the frame it is taken
    -- (the dwparse shape: SetSelected left standing fights the player's own
    -- clicks every other frame).
    tab     = rememberedTab(config),
    wantTab = nil,
};

--[[
* THE RUNES TAB'S STATE (1.3.0), in one table beside `state` rather than in
* it, because it is three things at once -- a wallet, a bag read and a write
* in flight -- and every one of them has its own staging copy, committed on
* its own `z|` exactly like the lists above.
--]]
local runes = {
    -- `runes`: the wallet. `byId[id] = { found, left }` for every Rune the
    -- account has ever found; `walletSerial` moves on every commit, which is
    -- what tells the list's cached view it is stale.
    wallet        = nil,
    walletAt      = nil,
    walletSerial  = 0,
    pendingWallet = nil,

    -- The list's own controls. Live buffers: the list is local, so it
    -- filters as the player types and never asks the server anything.
    search    = T{ '' },
    ownedOnly = T{ false },
    view      = nil,

    -- The apply panel. `target` is the Rune it is open for (nil: the list is
    -- drawn); `bag` is 'all' or a container id; `filterApplied` is the name
    -- the server was last asked for (the live `filter` buffer is read only
    -- on Enter / Search, dwquest's rule).
    target        = nil,
    bag           = 'all',
    filter        = T{ '' },
    filterApplied = '',
    gear          = nil,
    pendingGear   = nil,
    gearWanted    = false,
    gearSent      = nil,
    gearFailed    = false,   -- the last bag read was REFUSED (not merely unanswered)

    -- A SHORT ANSWER IS ASKED FOR ONCE MORE, never forever: the question a
    -- short bag list was re-asked for (so its second short answer is drawn
    -- with the "incomplete" line instead of re-asked again), and whether a
    -- short wallet has had its one re-ask.
    gearRetry     = nil,
    walletRetry   = false,

    -- The piece the player picked (`loc:slot:itemId`), the slot they chose
    -- to give up when it is full, and whether the confirm step is showing.
    pick       = nil,
    choice     = nil,
    confirming = false,

    -- THE WRITE. `applying` is the one `runeapply` in flight, nil otherwise;
    -- nothing re-sends it. `result` is the last `a|`, drawn as a card.
    applying     = nil,
    pendingApply = nil,
    result       = nil,
    note         = nil,
    noteBad      = false,

    --[[
    * A WRITE WHOSE ANSWER WAS LOST -- it timed out, or the store could not
    * verify it -- so nobody knows yet whether the Rune was spent. It is
    * settled by READING, never by sending again: a wallet read and a bag
    * read, each asked AFTER this was set (walletAsked / gearAsked, so an
    * answer to a read already in flight before the loss cannot settle it),
    * and then the Rune's count now against `before`, the count at the
    * click. The Confirm stays shut until then, so a second click cannot
    * spend a second Rune on a first one nobody has accounted for.
    --]]
    lost = nil,

    nudgeAt = nil,
};

-- The two ImGui calls this tab makes that no sibling had made in exactly this
-- shape before it, each behind a pcall that latches off on the first refusal
-- (dwhub's radio(), dwfame's forceNodeOpen): a binding that turns one down
-- costs a fold that no longer opens itself, or radio buttons drawn as small
-- buttons, never the frame.
local hedge = { nodeBroken = false, radioBroken = false };

--[[
* The bags a Rune can be applied in, in the server's own walk order
* (kAugmentContainers: inventory, the safes, storage, locker, satchel, sack,
* case, the eight wardrobes), under the names the rest of this window uses.
* `all` is the server's word for every one of them.
--]]
local RUNE_BAGS = {
    { key = 'all', label = 'All bags' },
    { key = 0,  label = 'Inventory' },     { key = 1,  label = 'Mog Safe' },
    { key = 9,  label = 'Mog Safe 2' },    { key = 2,  label = 'Storage' },
    { key = 4,  label = 'Mog Locker' },    { key = 5,  label = 'Mog Satchel' },
    { key = 6,  label = 'Mog Sack' },      { key = 7,  label = 'Mog Case' },
    { key = 8,  label = 'Mog Wardrobe' },  { key = 10, label = 'Mog Wardrobe 2' },
    { key = 11, label = 'Mog Wardrobe 3' }, { key = 12, label = 'Mog Wardrobe 4' },
    { key = 13, label = 'Mog Wardrobe 5' }, { key = 14, label = 'Mog Wardrobe 6' },
    { key = 15, label = 'Mog Wardrobe 7' }, { key = 16, label = 'Mog Wardrobe 8' },
};

local BAG_NAME = { };

for _, bag in ipairs(RUNE_BAGS) do
    bag.id             = string.format('%s##dwsp_rune_bag_%s', bag.label, tostring(bag.key));
    BAG_NAME[bag.key]  = bag.label;
end

-- The settings profile changes when the CHARACTER does, and the library hands
-- the new one over here.
pcall(settings.register, 'settings', 'dwspoils_settings_update', function (s)
    if (type(s) ~= 'table') then
        return;
    end

    config    = s;
    state.tab = rememberedTab(config);
end);

local function saveConfig()
    config.tab = state.tab;

    pcall(settings.save);
end

--[[
* THE TOOLTIPS, in one table rather than one literal per call site, so two
* controls that mean the same thing cannot drift into two sentences. The
* house rule: say what the control DOES, and for a greyed one say why it
* cannot right now; never repeat the label, never tooltip the self-evident.
--]]
local TIPS = {
    refresh      = 'Ask the server again, now. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks, and Refresh cannot fix that -- update dwspoils through the launcher.',
    lifetime     = 'Every piece of augmented gear ordinary kills have handed this ACCOUNT, since the ledger began.',
    fours        = 'How many of them carried four augments. Those are the ones the whole server hears about.',
    pips         = 'One pip per augment on the piece. Four pips are drawn in gold.',
    augs         = 'What the piece rolled, at the rank it rolled -- the same numbers your own bag shows. Hover the item for the full card.',
    monster      = 'What died for it, and the level it was. NM marks a notorious monster.',
    zone         = 'Where you were standing.',
    when         = 'How long ago, measured from the SERVER\'s own clock -- a machine whose clock is out still reads right.',
    landed       = 'Where the piece ended up. Nothing here means it went straight into your inventory.',
    rows         = 'The last thirty pieces this account was handed, newest first.',
    hallRows     = 'The last hundred four-augment awards on the server, newest first.',
    first        = 'Nobody on the server had ever been handed a four-augment copy of this item before.',
    supers       = 'Super Auged finds on this ACCOUNT. A few of the rolls you win are Super Auged: one to four augments from a stronger pool, and the whole server hears about each one.',
    superRows    = 'The last hundred Super Auged finds on the server, newest first. The pips are how many augments each carries.',
    superFirst   = 'Nobody on the server had found a Super Auged copy of this item before.',
    superMark    = 'A Super Auged find: its augments came from the stronger Super pool.',
    superMissing = 'This server does not have Super Auged finds yet. The other two tabs work as always.',

    -- The Runes tab (1.3.0).
    runesHeld    = 'Runes this ACCOUNT holds right now, ready to apply. Any character on the account can spend them.',
    runesFound   = 'Every Rune this account has ever found.',
    runesKinds   = 'How many different kinds of Rune this account has found at least once.',
    runeSearch   = 'Type part of a Rune, an augment or where it fits: "LXXVIII", "accuracy", "shields".',
    runeOwned    = 'Show only the Runes you hold right now.',
    runeFoundCol = 'How many of this Rune the account has found, ever.',
    runeLeftCol  = 'How many the account holds now. Applying one uses it up.',
    runeApply    = 'Choose a piece of your gear for this Rune. Nothing is spent until you confirm.',
    runeNone     = 'You hold none of this Rune. Runes turn up on experience-yielding kills.',
    runeWaiting  = 'Waiting for the server to say how many you hold.',
    runeBag      = 'Which of your bags to look through.',
    runeFilter   = 'Part of an item name. Enter, or Search, asks the server again.',
    runeFind     = 'Look through the chosen bags again for that name.',
    runeHere     = 'What this Rune rolls on THIS piece. The range depends on the kind of item.',
    runePlan     = 'Where the Rune would land on this piece.',
    runePick     = 'Choose this piece. You see its four slots and exactly what happens before anything is spent.',
    runeEquipped = 'Take it off first: a Rune cannot go on a piece you are wearing.',
    runeBazaar   = 'Take it out of your bazaar first.',
    runeInUse    = 'In use (a synthesis or trade is holding it) -- try again once it finishes.',
    runeBlocked  = 'This piece can\'t take a Rune right now.',
    runeCapped   = 'The server lists only so many pieces at a time. Choose a bag or type part of a name to narrow it.',
    runeBusy     = 'Waiting for the server to answer. Nothing is ever sent twice.',
    runeLost     = 'Checking whether your last Rune landed: your Runes and your bags are being read again. Refresh if this does not clear.',
    runeShort    = 'Part of the answer did not arrive (the chat line limit can drop one). Refresh reads it again.',
    runeConfirm  = 'Spend the Rune. The server rolls the rank and writes it onto the piece.',
    runeCancel   = 'Back to the slots. Nothing was sent.',
    runeBack     = 'Back to the list of Runes.',
    runeBackBusy = 'Waiting for the server to answer the Rune you just applied.',
    runeUnpick   = 'Back to the list of your gear. Nothing was sent.',
    runeChoose   = 'Choose the slot this Rune overwrites first.',
    runeNoneLeft = 'You hold none of this Rune any more.',
    runeVerdict  = 'Where the roll landed between the lowest and the highest rank this piece could take.',
    runeRules    = 'Applying a Rune uses it up. It goes into a free augment slot -- or re-rolls that slot if the piece already carries this augment -- and on a piece with four other augments you choose which one it overwrites.',
    runesMissing = 'This server does not have Runes yet. The other tabs work as always.',
    runeNoList   = 'This copy of dwspoils is missing its Rune list (runecatalog.lua), so only the Runes you hold are listed, without their ranges. Update dwspoils through the launcher.',
    runeFooter   = 'Runes turn up on experience-yielding kills. Hover a Rune for where it fits and how it applies.',
    runeSigned   = 'Signed (crafted) gear and gear in use can\'t take a Rune, so they are not listed.',
    runeEmpty    = 'No Runes yet -- they turn up on experience-yielding kills.',
};

--[[
* Record parsing (dwsp protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST. This runs on every rendered frame for
    -- the life of the session and the queue is empty in almost all of them,
    -- while echo.canSend() is three calls across the C++ boundary
    -- (GetMemoryManager, GetPlayer, GetIsZoning). Asking it first spends a
    -- hundred and eighty of those a second to decide to do nothing.
    if (#queue == 0) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

-- Is anything outstanding? Deliberately NOT a render helper: the suite's
-- `d|`-wipe gate judges a name by whether some imgui-drawing function reads
-- it, and the ask table is bookkeeping rather than a pane.
local function asking()
    return next(state.requested) ~= nil;
end

local function latched()
    return state.refused or state.serverSilent;
end

--[[
* THE BAG READ THE APPLY PANEL WANTS, AS ONE LINE (1.3.0): the Rune, the bag
* (`all` spelled out even when it is the default, so a name that starts with
* a digit can never be read as a container id), and the committed name
* filter, if any. nil when the panel is shut.
--]]
local function gearLine()
    if (runes.target == nil) then
        return nil;
    end

    local line = string.format(RUNEGEAR_LINE, runes.target, tostring(runes.bag));

    if (runes.filterApplied ~= '') then
        line = line .. ' ' .. runes.filterApplied;
    end

    return line;
end

-- The line a read goes out as: the fixed table, or the bag read built from
-- the panel. A WRITE is never here -- nothing retries `runeapply`.
local function lineFor(verb)
    if (verb == 'runegear') then
        return gearLine();
    end

    return LINES[verb];
end

-- `force` is the Refresh button: a click is the player asking, and the silent
-- latch exists to contain AUTOMATIC re-asks, not to ignore the player. The
-- PROTOCOL refusal is not lifted by a click.
local function ask(verb, force)
    if (state.refused) then
        return;
    end

    local line = lineFor(verb);

    if (line == nil) then
        return;
    end

    -- A server with no Super Auged hall has said so once; asking again would
    -- only have it say so again (see superUnsupported). A Refresh click does
    -- not lift it either -- the zone line re-probes, as for the protocol.
    if (verb == 'superauged' and superUnsupported) then
        return;
    end

    -- The Runes tab's two reads, the same way (see runesUnsupported).
    if ((verb == 'runes' or verb == 'runegear') and runesUnsupported) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    -- ONE OUTSTANDING ASK AT A TIME. Two reads in flight is two lines in the
    -- client's chat throttle for a window that can only show one tab, and the
    -- answers arrive interleaved on a wire whose envelopes are not nested.
    if (not force and asking()) then
        return;
    end

    -- A CLICK REPLACES THE OLD ANSWER. Lifting a latch without clearing the
    -- sentence that set it leaves the last refusal red in the header while the
    -- window is actively asking again. Only a REFUSAL is dropped; a note is
    -- still true.
    if (force and state.statusBad) then
        state.status    = '';
        state.statusBad = false;
    end

    -- The line is kept with the ask, because a bag read's line is built from
    -- the panel and the retry must repeat what was ASKED, not what the panel
    -- says now. `gearSent` is what the answer is later held to.
    state.requested[verb] = { at = os.clock(), tries = 1, line = line };
    state.polledAt[verb]  = os.clock();

    if (verb == 'runegear') then
        runes.gearSent   = line;
        runes.gearWanted = false;
        runes.gearFailed = false;
    end

    -- A read asked after a write's answer was lost is one that can settle it.
    if (runes.lost ~= nil) then
        if (verb == 'runes') then
            runes.lost.walletAsked = true;
        elseif (verb == 'runegear') then
            runes.lost.gearAsked = true;
        end
    end

    issue(line);
end

local function checkAnswers()
    for verb, asked in pairs(state.requested) do
        -- THE CLOCK DOES NOT AGE WHILE THE CLIENT IS ZONING -- it is
        -- RE-STAMPED, not merely skipped. A line still sitting in the queue
        -- behind echo.canSend() had already burned its timeout by the time it
        -- went out, so the retry fired 1.2 s behind the first send: both
        -- inside the client's chat settle window, both dropped, and the latch
        -- set with the server never asked.
        if (not echo.canSend()) then
            asked.at = os.clock();
        elseif ((os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries >= ANSWER_TRIES) then
                -- NO SENTENCE IS WRITTEN HERE: the header draws the silent
                -- latch in preference to state.status, so a line set here is
                -- never read and outlives the latch that hid it.
                state.requested[verb] = nil;
                state.serverSilent    = true;
            else
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue(asked.line or LINES[verb]);
            end
        end
    end
end

--[[
* THE RUNE RECORDS' PARSE HALF (1.3.0). Everything a row of the apply panel
* draws is built here, once, when the record lands -- the four slots in words,
* this piece's range, and what the Rune would do to it -- so the render pass
* is Text calls and nothing else.
--]]

-- What the Rune would do to a piece, by the server's own slot rule (spec,
-- "Applying"): the SAME augment id already there is re-rolled in its slot --
-- always, free slots or not, because a piece never carries one id twice;
-- otherwise the FIRST free slot; otherwise the player chooses. The server
-- applies the same rule and refuses anything else, so this is a preview of
-- its answer and never a decision.
local function planFor(slots, runeId)
    for index = 1, 4 do
        if (slots[index].id == runeId) then
            return { kind = 'reroll', slot = index };
        end
    end

    for index = 1, 4 do
        if (slots[index].id == 0) then
            return { kind = 'free', slot = index };
        end
    end

    return { kind = 'choose' };
end

-- The g| flags: 0 ready, 1 equipped, 2 bazaared, 3 in use (a synthesis or a
-- trade window holds it, or the character is crafting). Every non-zero row is
-- drawn greyed with its reason and is never pickable.
local GEAR_STATUS = {
    [1] = { word = 'equipped',       tip = 'runeEquipped' },
    [2] = { word = 'in your bazaar', tip = 'runeBazaar' },
    [3] = { word = 'in use',         tip = 'runeInUse' },
};

local function gearRow(locText, slotText, itemText, flagsText, minText, maxText, stamp, augs, runeId)
    local loc, slot, itemId = wireInt(locText, -1), wireInt(slotText, -1), wireInt(itemText, 0);
    local lo, hi            = wireInt(minText, 0), wireInt(maxText, 0);
    local flags             = wireInt(flagsText, 0);

    stamp = tostring(stamp or '');

    -- A row this window could not hand back to the server intact is a row it
    -- must not offer: the apply line repeats loc, slot, id and stamp, and a
    -- mangled one is a refusal at best.
    if (loc < 0 or loc > 255 or slot < 0 or slot > 255 or itemId <= 0 or itemId > 65535
            or lo < 1 or hi < lo or hi > 32 or #stamp == 0 or #stamp > 16
            or string.find(stamp, '^%x+$') == nil) then
        return nil;
    end

    local row = {
        loc     = loc,
        slot    = slot,
        itemId  = itemId,
        flags   = flags,
        min     = lo,
        max     = hi,
        stamp   = stamp,
        key     = string.format('%d:%d:%d', loc, slot, itemId),
        pickBtn = string.format('Pick##dwsp_rg_%d_%d', loc, slot),
        bag     = BAG_NAME[loc] or string.format('bag %d', loc),
        range   = rangeWords(runeId, lo, hi),
        rangeLong = rangeLong(runeId, lo, hi),
        slots   = { },
    };

    local short = { };

    for id, stored in string.gmatch(tostring(augs or ''), '(%d+):(%d+)') do
        if (#row.slots == 4) then
            break;
        end

        id, stored = tonumber(id), math.min(31, tonumber(stored));

        if (id == 0) then
            row.slots[#row.slots + 1] = { id = 0 };
        else
            local rank = stored + 1;

            row.slots[#row.slots + 1] = { id = id, rank = rank, text = augmentText(id, rank) };
            short[#short + 1]         = augmentWords(id, rank);
        end
    end

    -- Exactly four on the wire; a short field reads as empty slots rather
    -- than as a row that cannot be drawn.
    for index = #row.slots + 1, 4 do
        row.slots[index] = { id = 0 };
    end

    row.augLine = #short > 0 and table.concat(short, ', ') or 'no augments yet';
    row.plan    = planFor(row.slots, runeId);

    if (row.plan.kind == 'reroll') then
        row.planWords = string.format('re-rolls slot %d', row.plan.slot);
    elseif (row.plan.kind == 'free') then
        row.planWords = string.format('goes into slot %d', row.plan.slot);
    else
        row.planWords = 'full: you choose the slot';
    end

    -- Flags 1 to 3 are named above; anything else non-zero -- a flag a newer
    -- server added after this copy -- is a piece the server says is not
    -- ready, drawn greyed the same way with the generic reason. Never ready.
    if (flags ~= 0) then
        row.status = GEAR_STATUS[flags] or { word = 'not available', tip = 'runeBlocked' };
    end

    return row;
end

-- Where a roll landed in its range, in integers so a boundary never depends
-- on a float: the top rank is the Max; the top third High; the middle third
-- Average; the rest Low. A range of one rank can only ever be its Max.
local function verdictOf(rank, lo, hi)
    if (rank >= hi) then
        return 'Max roll', 'warn';
    end

    local span, at = hi - lo, rank - lo;

    if (3 * at >= 2 * span) then
        return 'High roll', 'ok';
    end

    if (3 * at >= span) then
        return 'Average roll', 'text';
    end

    return 'Low roll', 'dim';
end

local function applyResult(runeText, itemText, locText, slotText, augSlotText, rankText, minText,
        maxText, replacedText, replacedRankText, leftText)
    local res = {
        rune         = wireInt(runeText),
        itemId       = wireInt(itemText),
        loc          = wireInt(locText),
        slot         = wireInt(slotText),
        augSlot      = wireInt(augSlotText),
        rank         = wireInt(rankText),
        min          = wireInt(minText),
        max          = wireInt(maxText),
        replaced     = wireInt(replacedText),
        replacedRank = wireInt(replacedRankText),
        left         = wireInt(leftText, -1),
    };

    res.words = augmentWords(res.rune, math.max(1, res.rank));
    res.rankLine = string.format('rank %d of %d-%d', res.rank, res.min, res.max);
    res.verdict, res.colour = verdictOf(res.rank, res.min, res.max);

    if (res.replaced == 0) then
        res.where = string.format('It went into slot %d.', res.augSlot);
    elseif (res.replaced == res.rune) then
        res.where = string.format('It re-rolled slot %d, which held %s.', res.augSlot,
            augmentWords(res.replaced, math.max(1, res.replacedRank)));
    else
        res.where = string.format('It replaced %s in slot %d.', augmentWords(res.replaced,
            math.max(1, res.replacedRank)), res.augSlot);
    end

    if (res.left > 0) then
        res.leftLine = string.format('You hold %d more of this Rune.', res.left);
    elseif (res.left == 0) then
        res.leftLine = 'That was your last one of this Rune.';
    end

    return res;
end

-- The row the player picked, in the list on screen, or nil.
local function pickedRow()
    if (runes.pick == nil or runes.gear == nil) then
        return nil;
    end

    for _, row in ipairs(runes.gear.rows) do
        if (row.key == runes.pick) then
            return row;
        end
    end

    return nil;
end

-- The re-reads a finished (or refused, or unanswered) apply owes: the wallet
-- and the bags, both READS, taken by the frame loop in that order.
local function rereadAfterApply()
    state.polledAt.runes = nil;
    runes.gearWanted     = runes.target ~= nil;
end

-- How many of a Rune the account holds now: nil before the wallet arrives
-- (which is a different sentence from "none").
local function heldOf(id)
    local wallet = runes.wallet;

    if (wallet == nil) then
        return nil;
    end

    local entry = wallet.byId[id];

    return entry ~= nil and entry.left or 0;
end

-- Is this answer (an `a|`, or an `x|`'s naming of the piece) about THAT
-- write? The Rune and the item, both: a late answer to an earlier Confirm
-- must not settle a later one, nor another Rune's panel.
local function answers(record, write)
    return record ~= nil and write ~= nil and record.rune == write.rune and record.itemId == write.itemId;
end

--[[
* A LOST ANSWER, SETTLED (the lost-write rule above runes.lost). Once a
* wallet read and a bag read asked after the loss have BOTH landed -- the
* bag read is not owed when the panel has been left -- the Rune's count now
* against the count at the click says what happened, in words the player can
* act on. Then, and only then, the Confirm comes back.
--]]
local function settleLost()
    local lost = runes.lost;

    if (lost == nil or not lost.walletDone or not (lost.gearDone or runes.target == nil)) then
        return;
    end

    runes.lost = nil;

    local now   = heldOf(lost.rune);
    local title = string.format('Rune %s', lost.roman);

    if (lost.before ~= nil and now ~= nil and now < lost.before) then
        runes.note = string.format('Your %s was applied -- its answer was lost on the way back. '
            .. 'Check the piece: its slots below are the server\'s own, read just now.', title);
    else
        runes.note = string.format('Nothing was spent: you still hold every %s you had.', title);
    end

    runes.noteBad = false;

    -- Settled with the panel shut: the sentence goes to chat, where it will
    -- still be read, rather than into a panel nobody is looking at.
    if (runes.target == nil) then
        print(chat.header('dwspoils'):append(chat.message(runes.note)));
    end
end

-- A write's answer is lost from here: the timeout ran out, or the store
-- said it could not verify its own write. Reads, never a resend.
local function loseAnswer(write)
    runes.lost = { rune = write.rune, itemId = write.itemId, roman = write.roman, before = write.before };

    rereadAfterApply();
end

--[[
* A BAG ANSWER COMMITS ONLY IF IT ANSWERS THE QUESTION ON SCREEN. The panel
* can move on while a read is in flight -- another bag, another name, back to
* the list and into another Rune -- and rows for the wrong Rune would draw
* the wrong range beside every piece. So an answer for a Rune the panel is no
* longer open for is dropped, and one for another bag or name is dropped and
* asked again. The picked piece is carried across a commit when it is still
* there; when its stamp moved, the confirm step closes, because what the
* player was about to consent to is no longer what the piece holds.
*
* A SHORT ANSWER IS ASKED FOR ONCE MORE. `t|` says how many rows follow; the
* client's chat throttle can drop any of them, and a row this window could
* not hand back intact is dropped here too. Fewer rows than `t|` promised is
* drawn as it stands AND asked for again -- once per question, so a row that
* is always malformed is marked incomplete rather than asked for forever.
--]]
local function commitGear(pending)
    if (pending == nil or not pending.seen) then
        return;
    end

    if (runes.target == nil or pending.rune ~= runes.target) then
        return;
    end

    if (pending.line ~= nil and pending.line ~= gearLine()) then
        runes.gearWanted = true;

        return;
    end

    local before = pickedRow();

    pending.incomplete = #pending.rows < pending.shown;

    if (pending.incomplete and runes.gearRetry ~= pending.line) then
        runes.gearRetry  = pending.line;
        runes.gearWanted = true;
    elseif (not pending.incomplete) then
        runes.gearRetry = nil;
    end

    runes.gear       = pending;
    runes.gearFailed = false;

    if (runes.lost ~= nil and runes.lost.gearAsked) then
        runes.lost.gearDone = true;
    end

    if (runes.pick ~= nil) then
        local after = pickedRow();

        if (after == nil) then
            runes.pick       = nil;
            runes.choice     = nil;
            runes.confirming = false;
            runes.note       = 'That piece is no longer where it was. Pick it again from the list.';
            runes.noteBad    = false;
        elseif (before ~= nil and before.stamp ~= after.stamp) then
            runes.choice     = nil;
            runes.confirming = false;
            runes.note       = 'That piece changed since you picked it. Check its slots again.';
            runes.noteBad    = false;
        end
    end

    settleLost();
end

--[[
* THE APPLY'S ANSWER COMMITS ONLY IF IT IS THE ANSWER TO THE WRITE ON SCREEN.
* `a|` names its Rune and its item; one that names another write -- a late
* answer to an earlier Confirm, arriving after a later one went out -- is
* not allowed to clear the later one's in-flight flag or draw its card in
* the wrong Rune's panel. With nothing in flight, an `a|` that answers the
* write whose answer was LOST settles it the best possible way: it landed,
* and here is what it rolled. Anything else answers nothing on screen and
* only means the wallet moved, so it is read again.
--]]
local function commitApply(pending)
    if (pending == nil) then
        return;
    end

    local write = runes.applying;
    local res   = pending.result;

    if (res == nil) then
        -- An envelope with neither an answer nor a refusal in it: the server
        -- spoke and said nothing this window can read. Nothing is re-sent; the
        -- write is treated as LOST and settled by the reads, like a timeout.
        if (write == nil) then
            return;
        end

        runes.applying   = nil;
        runes.confirming = false;
        runes.choice     = nil;
        runes.note       = 'The server answered without saying what happened. Nothing was sent again -- '
            .. 'your Runes and your bags are being read to show whether it landed.';
        runes.noteBad    = true;

        loseAnswer(write);

        return;
    end

    if (write ~= nil and not answers(res, write)) then
        return;
    end

    if (write == nil) then
        if (not answers(res, runes.lost)) then
            rereadAfterApply();

            return;
        end

        runes.lost = nil;
    end

    runes.applying   = nil;
    runes.confirming = false;
    runes.choice     = nil;
    runes.result     = res;
    runes.pick       = nil;
    runes.note       = nil;

    -- THE SERVER'S OWN COUNT, drawn at once. The re-read below confirms it,
    -- but a Left column that says 3 for the second after the card says "you
    -- hold 2 more" is a window arguing with itself.
    local wallet = runes.wallet;

    if (wallet ~= nil and res.left >= 0) then
        local entry = wallet.byId[res.rune];

        if (entry ~= nil and entry.left ~= res.left) then
            wallet.left        = math.max(0, wallet.left - (entry.left - res.left));
            entry.left         = res.left;
            runes.walletSerial = runes.walletSerial + 1;
        end
    end

    rereadAfterApply();
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], -1);

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            --[[
            * THE REFUSAL RETIRES THE ASKS. A mismatched `d|` IS an answer --
            * the server spoke, in a dialect this addon does not read -- and
            * leaving the clock running against it costs twice: five seconds
            * later the retry goes out against the protocol document's own
            * promise to stop asking, and five after that the silent latch
            * paints "No answer from the server" over the accurate "Update
            * dwspoils" banner, which points the player at the server when the
            * addon is the problem.
            * The staging copies go too: they belong to an envelope that can no
            * longer be trusted to mean what this addon thinks it means.
            *
            * AND SO DOES THE QUEUE (2026-09-20, independent review). Retiring
            * the answer clock stops this addon ASKING again; it does not
            * unsend a line that is already sitting in the pump behind the
            * client's throttle. That line went out a beat later, the server
            * answered it in the same dialect, and the player read a second
            * identical red sentence about a version they cannot fix from
            * here -- a refusal that has to be said twice reads like a fault
            * rather than an instruction. Drained in place rather than
            * reassigned: `queue` is an upvalue the render pass reads for its
            * "asking..." line.
            --]]
            state.requested     = T{ };
            state.pendingCounts = nil;
            state.pendingRows   = nil;
            state.pendingHall   = nil;
            state.pendingSuper  = nil;
            state.serverSilent  = false;

            -- The Rune staging copies go with the rest, and so does a Confirm
            -- in flight: the drain below may take its line with it, and an
            -- answer in a dialect this addon cannot read is no answer to it.
            -- Nothing re-sends it; the button comes back on the next good read.
            runes.pendingWallet = nil;
            runes.pendingGear   = nil;
            runes.pendingApply  = nil;
            runes.applying      = nil;

            for index = #queue, 1, -1 do
                table.remove(queue, index);
            end

            print(chat.header('dwspoils'):append(chat.error(string.format(
                'Server protocol %d, addon expects %d. Update dwspoils.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope proves the server is there (the silent
        -- latch lifts), but only the MATCHING verb retires its own ask.
        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.inbound == 'mine' or state.inbound == 'hall' or state.inbound == 'superauged') then
            state.requested[state.inbound] = nil;
            state.pendingCounts            = { seen = false, lifetime = 0, fours = 0, now = 0 };

            -- A NEW ANSWER CLEARS THE OLD BANNER. Whatever the server wants to
            -- say about THIS answer rides inside this envelope as m| or e|,
            -- after this line.
            state.status    = '';
            state.statusBad = false;
        end

        if (state.inbound == 'mine') then
            state.pendingRows = T{ };
        elseif (state.inbound == 'hall') then
            state.pendingHall = T{ };
        elseif (state.inbound == 'superauged') then
            state.pendingSuper = T{ };
        end

        --[[
        * THE RUNES TAB'S THREE ENVELOPES (1.3.0), each staged the same way.
        * `runes` is the tab's read, so it clears the banner like the three
        * above; the panel's two carry their own sentences into the panel.
        * `runeapply` is a WRITE and is not on the answer clock, so there is
        * no ask to retire -- `applying` is settled at its `z|`.
        --]]
        if (state.inbound == 'runes') then
            state.requested.runes = nil;
            state.status          = '';
            state.statusBad       = false;
            runes.pendingWallet   = { seen = false, found = 0, left = 0, applied = 0, kinds = 0, byId = { } };
        elseif (state.inbound == 'runegear') then
            state.requested.runegear = nil;
            runes.pendingGear        = { seen = false, rune = 0, shown = 0, total = 0, rows = { }, line = runes.gearSent };
        elseif (state.inbound == 'runeapply') then
            runes.pendingApply = { result = nil };
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        --[[
        * NO SUPER AUGED HALL ON THIS SERVER YET (1.2.0). Matched on the
        * server's own sentence and RETURNED before anything is printed or
        * bannered: the ask is retired (an old door answers in a `status`
        * envelope, which retires nothing by itself), the Super staging copy
        * goes, and the tab says so in its own words. Every other tab's
        * answer is untouched.
        --]]
        if (kind == 'e' and (string.find(line, SUPER_UNKNOWN, 1, true) ~= nil
                or string.find(line, SUPER_NOBUILD, 1, true) ~= nil)) then
            superUnsupported             = true;
            state.requested.superauged   = nil;
            state.pendingSuper           = nil;

            return;
        end

        -- NO RUNES ON THIS SERVER YET (1.3.0), the same quiet way: both reads
        -- retired, every Rune staging copy dropped, a Confirm in flight let
        -- go (a server that does not know the verb applied nothing), and the
        -- tab says so in its own words.
        if (kind == 'e' and runesRefused(line)) then
            runesUnsupported         = true;
            state.requested.runes    = nil;
            state.requested.runegear = nil;
            runes.pendingWallet      = nil;
            runes.pendingGear        = nil;
            runes.pendingApply       = nil;
            runes.applying           = nil;
            runes.lost               = nil;
            runes.confirming         = false;
            runes.gearWanted         = false;

            return;
        end

        --[[
        * THE APPLY PANEL'S OWN SENTENCES (1.3.0). A note or a refusal inside
        * a `runegear` or `runeapply` envelope is about the panel, so it is
        * drawn IN the panel -- next to the button that caused it -- rather
        * than as the window's header banner, which belongs to the tab reads.
        * A refusal is still said in chat, as every refusal here is.
        *
        * A REFUSED APPLY RE-READS, ALWAYS. The one the spec names is the
        * stale stamp -- the piece moved or changed after the list was drawn,
        * so the list on screen is the thing that is wrong -- but a refusal for
        * any other reason (no Rune left, the slot rule, the brake) is also
        * one where the wallet or the bag might not be what the panel shows.
        * Both are READS, both are safe, and neither re-sends the apply: only
        * another click can do that, against the rows the re-read brings.
        *
        * A REFUSAL IS HELD TO ITS WRITE the way an `a|` is (commitApply):
        * the `x|` ahead of it names the Rune and the piece, so a late refusal
        * of an earlier Confirm cannot clear a later one's in-flight flag. It
        * is still said in chat; it just changes nothing on screen. With
        * nothing in flight, a refusal of the write whose answer was LOST
        * settles it: refused means nothing was spent. `unverified` is the one
        * refusal that settles nothing -- the store could not say whether its
        * own write landed -- so it LOSES the answer instead, and the reads
        * decide.
        --]]
        if (state.inbound == 'runegear' or state.inbound == 'runeapply') then
            local ours = true;

            if (kind == 'e' and state.inbound == 'runegear') then
                runes.pendingGear = nil;
                runes.gearFailed  = true;
            elseif (kind == 'e') then
                local pending = runes.pendingApply;
                local reason  = pending ~= nil and pending.reason or nil;
                local named   = pending ~= nil and pending.refused or nil;
                local write   = runes.applying;
                local relist  = RUNE_RELIST[reason or ''] or (reason == nil
                    and string.find(text, RUNE_STALE, 1, true) ~= nil);

                runes.pendingApply = nil;

                if (write ~= nil and (named == nil or answers(named, write))) then
                    runes.applying   = nil;
                    runes.confirming = false;
                    runes.choice     = nil;

                    if (relist) then
                        runes.pick = nil;
                    end

                    if (reason == 'unverified') then
                        loseAnswer(write);
                    else
                        rereadAfterApply();
                    end
                elseif (write == nil and runes.lost ~= nil and (named == nil or answers(named, runes.lost))) then
                    if (reason ~= 'unverified') then
                        runes.lost = nil;
                    end

                    if (relist) then
                        runes.pick = nil;
                    end

                    rereadAfterApply();
                else
                    ours = false;
                end
            end

            if (text ~= '') then
                if (ours) then
                    runes.note    = text;
                    runes.noteBad = (kind == 'e');
                end

                if (kind == 'e') then
                    print(chat.header('dwspoils'):append(chat.error(text)));
                end
            end

            return;
        end

        if (kind == 'e') then
            --[[
            * A REFUSAL INSIDE AN OPEN ENVELOPE KILLS THAT ANSWER. This is not
            * a rare shape: a door emits exactly `d|1|mine`, `e|Spoils is not
            * loaded on this build.`, `z|mine` when the core did not load, and
            * squad_storage's writer wraps ANY bare fail in the same three
            * lines. Committing that staging copy at z| would leave the tab
            * drawing "Nothing yet" -- a confident false sentence about a
            * server that answered nothing at all.
            --]]
            state.pendingCounts = nil;
            state.pendingRows   = nil;
            state.pendingHall   = nil;
            state.pendingSuper  = nil;
            runes.pendingWallet = nil;
        end

        -- A NOTE WITH NO SENTENCE IN IT SAYS NOTHING. `out:fail(nil)` writes a
        -- bare `e|`, and blanking the header with it is worse than ignoring
        -- it. The bookkeeping above still ran: a refusal with nothing to say
        -- is still a refusal.
        if (text == '') then
            return;
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwspoils'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    -- c| -- the account's lifetime counts and the SERVER's clock. Sent on
    -- every verb, because every tab draws the header line. The fifth field,
    -- `supers`, was APPENDED in 1.2.0's server round: nil against an older
    -- server, which reads as zero and draws nothing extra.
    if (kind == 'c' and state.pendingCounts ~= nil) then
        state.pendingCounts.seen     = true;
        state.pendingCounts.lifetime = wireInt(parts[2]);
        state.pendingCounts.fours    = wireInt(parts[3]);
        state.pendingCounts.now      = wireInt(parts[4]);
        state.pendingCounts.supers   = wireInt(parts[5]);

        return;
    end

    -- r| -- one award on this account, newest first.
    if (kind == 'r' and state.pendingRows ~= nil) then
        local augs           = parts[10] or '';
        local augList, augLine = decodeAugs(augs);

        state.pendingRows:append({
            id       = wireInt(parts[2]),
            at       = wireInt(parts[3]),
            itemId   = wireInt(parts[4]),
            augCount = wireInt(parts[5]),
            mobLvl   = wireInt(parts[6]),
            zoneId   = wireInt(parts[7]),
            nm       = wireInt(parts[8]) ~= 0,
            landed   = wireInt(parts[9]),
            augs     = augs,
            augList  = augList,
            augLine  = augLine,
            mobName  = parts[11] or '',
            taker    = parts[12] or '',
            -- APPENDED (1.2.0's server round): 1 for a Super Auged find. nil
            -- from an older server, which reads as an ordinary row.
            super    = wireInt(parts[13]) ~= 0,
        });

        return;
    end

    --[[
    * w| -- one four-augment award anywhere on the server, newest first.
    *
    * THE TENTH FIELD IS NEW AND IT IS OPTIONAL (dwspoils 1.1.0 / server
    * 2026-09-21). It was APPENDED to the record rather than inserted, so this
    * branch reads it exactly the way client discipline 2 says an added field
    * is read: `parts[10]` is nil against a server that has not been updated,
    * decodeAugs answers nil twice, and the Hall draws what it drew in 1.0.0.
    * The protocol version did not move and must not -- a bump is a HARD
    * refusal on this side and would brick every installed copy over a field
    * they would otherwise have skipped.
    --]]
    if (kind == 'w' and state.pendingHall ~= nil) then
        local augs           = parts[10] or '';
        local augList, augLine = decodeAugs(augs);

        state.pendingHall:append({
            id       = wireInt(parts[2]),
            at       = wireInt(parts[3]),
            itemId   = wireInt(parts[4]),
            mobLvl   = wireInt(parts[5]),
            zoneId   = wireInt(parts[6]),
            first    = wireInt(parts[7]) ~= 0,
            charName = parts[8] or '',
            mobName  = parts[9] or '',
            augs     = augs,
            augList  = augList,
            augLine  = augLine,
        });

        return;
    end

    --[[
    * s| -- one Super Auged find anywhere on the server, newest first (1.2.0).
    * The Hall of Four's record with the COUNT added, because a Super row
    * carries one to four augments where a Hall row is four by definition;
    * `first` is the first Super Auged copy of that item on the server.
    --]]
    if (kind == 's' and state.pendingSuper ~= nil) then
        local augs           = parts[11] or '';
        local augList, augLine = decodeAugs(augs);

        state.pendingSuper:append({
            id       = wireInt(parts[2]),
            at       = wireInt(parts[3]),
            itemId   = wireInt(parts[4]),
            augCount = wireInt(parts[5]),
            mobLvl   = wireInt(parts[6]),
            zoneId   = wireInt(parts[7]),
            first    = wireInt(parts[8]) ~= 0,
            charName = parts[9] or '',
            mobName  = parts[10] or '',
            augs     = augs,
            augList  = augList,
            augLine  = augLine,
        });

        return;
    end

    --[[
    * q| -- the account's Rune wallet in totals (1.3.0, `runes`): found ever,
    * held now, applied ever, and how many kinds the SERVER's catalog has --
    * the "of N" in the tab's header, the server's number rather than this
    * copy's, so a catalog that lags says so by disagreeing out loud.
    --]]
    if (kind == 'q' and runes.pendingWallet ~= nil) then
        runes.pendingWallet.seen    = true;
        runes.pendingWallet.found   = wireInt(parts[2]);
        runes.pendingWallet.left    = wireInt(parts[3]);
        runes.pendingWallet.applied = wireInt(parts[4]);
        runes.pendingWallet.kinds   = wireInt(parts[5]);

        return;
    end

    --[[
    * n| -- the wallet by Rune, packed `id:found:left` triples, as many per
    * record as fit (1.3.0). Only Runes found at least once travel; a Rune
    * missing here is a Rune this account has never found, which the tab draws
    * as 0 and 0.
    --]]
    if (kind == 'n' and runes.pendingWallet ~= nil) then
        for id, found, left in string.gmatch(parts[2] or '', '(%d+):(%d+):(%d+)') do
            id, found, left = wireInt(id, 0), wireInt(found, 0), wireInt(left, 0);

            if (id > 0 and id <= 2047) then
                runes.pendingWallet.byId[id] = { found = found, left = left };
            end
        end

        return;
    end

    -- t| -- the bag read's header (1.3.0, `runegear`): which Rune the rows are
    -- for, how many follow, and how many fit before the server's cap.
    if (kind == 't' and runes.pendingGear ~= nil) then
        runes.pendingGear.seen  = true;
        runes.pendingGear.rune  = wireInt(parts[2]);
        runes.pendingGear.shown = wireInt(parts[3]);
        runes.pendingGear.total = wireInt(parts[4]);

        return;
    end

    -- g| -- one piece the Rune fits, with the range it would roll on THAT
    -- piece and its four augments as stored (1.3.0). Built into a drawable
    -- row here, once (gearRow); a row that could not be handed back to the
    -- server intact is dropped.
    if (kind == 'g' and runes.pendingGear ~= nil) then
        local row = gearRow(parts[2], parts[3], parts[4], parts[5], parts[6], parts[7], parts[8],
            parts[9], runes.pendingGear.rune ~= 0 and runes.pendingGear.rune or (runes.target or 0));

        if (row ~= nil) then
            runes.pendingGear.rows[#runes.pendingGear.rows + 1] = row;
        end

        return;
    end

    -- x| -- a refused apply's reason as a WORD (1.3.0, `stale`, `insufficient`,
    -- `wrongslot`...), sent ahead of its e| sentence so the panel can decide
    -- what to do next without reading prose, and naming the piece it was
    -- about. Kept on the staging copy; the e| that follows acts on it.
    if (kind == 'x' and runes.pendingApply ~= nil) then
        runes.pendingApply.reason  = string.lower(parts[2] or '');
        runes.pendingApply.refused = {
            rune   = wireInt(parts[3]),
            loc    = wireInt(parts[4]),
            slot   = wireInt(parts[5]),
            itemId = wireInt(parts[6]),
        };

        return;
    end

    -- a| -- the apply's answer (1.3.0): what landed where, the rank it rolled
    -- inside which range, what it replaced, and the Rune's balance after.
    if (kind == 'a' and runes.pendingApply ~= nil) then
        runes.pendingApply.result = applyResult(parts[2], parts[3], parts[4], parts[5], parts[6],
            parts[7], parts[8], parts[9], parts[10], parts[11], parts[12]);

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        --[[
        * ONLY A COMPLETE ANSWER COMMITS. The staging copies are nil when a
        * refusal killed the envelope; the counts are present but hollow when
        * the reply ended before its `c|` arrived -- the client's chat rate
        * limit drops lines, which is the whole reason this addon carries an
        * answer clock. An EMPTY LIST is a legitimate answer and commits: a
        * player who has been handed nothing yet is told so in the tab's own
        * words.
        --]]
        local counts = state.pendingCounts;

        state.pendingCounts = nil;

        if (counts ~= nil and counts.seen) then
            state.counts   = counts;
            state.countsAt = os.clock();
        end

        if (closed == 'mine') then
            if (state.pendingRows ~= nil) then
                state.rows   = state.pendingRows;
                state.rowsAt = os.clock();
            end

            state.pendingRows = nil;
        elseif (closed == 'hall') then
            if (state.pendingHall ~= nil) then
                state.hall   = state.pendingHall;
                state.hallAt = os.clock();
            end

            state.pendingHall = nil;
        elseif (closed == 'superauged') then
            if (state.pendingSuper ~= nil) then
                state.super   = state.pendingSuper;
                state.superAt = os.clock();
            end

            state.pendingSuper = nil;
        elseif (closed == 'runes') then
            -- The wallet commits only with its q| in it: an n| stream the
            -- client's throttle cut short of its header is not a wallet.
            local wallet = runes.pendingWallet;

            if (wallet ~= nil and wallet.seen) then
                local kinds, found, left = 0, 0, 0;

                for _, entry in pairs(wallet.byId) do
                    found = found + entry.found;
                    left  = left + entry.left;

                    if (entry.found > 0) then
                        kinds = kinds + 1;
                    end
                end

                --[[
                * A SHORT WALLET IS ASKED FOR ONCE MORE. `q|`'s totals are the
                * sums of the very rows `n|` packs (the store adds them up
                * that way), so a mismatch means an `n|` the throttle dropped:
                * drawn as it stands -- the totals are still true -- marked,
                * and asked for once more. A second short one stays marked
                * rather than asking forever; Refresh is the player's.
                --]]
                wallet.short = found ~= wallet.found or left ~= wallet.left;

                if (wallet.short and not runes.walletRetry) then
                    runes.walletRetry    = true;
                    state.polledAt.runes = nil;
                elseif (not wallet.short) then
                    runes.walletRetry = false;
                end

                wallet.kindsFound  = kinds;
                runes.wallet       = wallet;
                runes.walletAt     = os.clock();
                runes.walletSerial = runes.walletSerial + 1;

                -- A whole wallet read asked after a lost answer can settle it
                -- (a short one cannot: the Rune in question may be the row
                -- that fell out).
                if (runes.lost ~= nil and runes.lost.walletAsked and not wallet.short) then
                    runes.lost.walletDone = true;

                    settleLost();
                end
            end

            runes.pendingWallet = nil;
        elseif (closed == 'runegear') then
            commitGear(runes.pendingGear);

            runes.pendingGear = nil;
        elseif (closed == 'runeapply') then
            commitApply(runes.pendingApply);

            runes.pendingApply = nil;
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwspoils_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        -- BLOCKED BEFORE IT IS PARSED (the dwbags rule), and ONLY for this
        -- sender. The server's own `[Spoils] ` sentences carry no sender name
        -- of ours and are left exactly where the game put them. A record that
        -- throws inside handleRecord must still not reach the chat log: the
        -- player's window would fill with `r|12|178...|` for as long as the
        -- bug lived, and a parse error is exactly when that is most likely.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwspoils'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line invalidates the whole picture and re-probes every latch. The
    -- lazy hello re-arms with it: a player who zoned is exactly the one whose
    -- window has been shut for a while. A half-arrived envelope dies with the
    -- zone too, or its stray tail would be accepted into a stale pending copy
    -- on the far side.
    if (e.id == 0x000A) then
        state.requested     = T{ };
        state.serverSilent  = false;
        state.refused       = false;
        state.inbound       = nil;
        state.pendingCounts = nil;
        state.pendingRows   = nil;
        state.pendingHall   = nil;
        state.pendingSuper  = nil;
        state.helloSent     = false;

        -- A server upgraded under a running client is asked again.
        superUnsupported    = false;
        state.polledAt      = T{ };
        state.nudgeAt       = nil;

        -- The Runes tab, the same way (1.3.0). A Confirm in flight is NOT let
        -- go here: its answer may still arrive, and its own timeout -- which
        -- does not run while the client is zoning -- is what settles it.
        runesUnsupported    = false;
        runes.pendingWallet = nil;
        runes.pendingGear   = nil;
        runes.pendingApply  = nil;
        runes.nudgeAt       = nil;
        runes.gearWanted    = runes.target ~= nil;

        -- A RED REFUSAL DOES NOT OUTLIVE THE PLACE IT WAS ABOUT. A note is
        -- still true after a zone and stays.
        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end
    end
end);

--[[
* The client's own item data, asked ONCE PER ID (the dwcpx shape, which is
* dwbags' by way of dwquest). The item DAT is static from load, so an id that
* answers nil now answers nil forever and a negative result caches as safely
* as a positive one. `false` is "the client does not know this id"; nil is
* "not asked yet".
--]]
local resources = { };

local function resourceOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    local hit = resources[itemId];

    if (hit ~= nil) then
        return hit ~= false and hit or nil;
    end

    local ok, item = pcall(function ()
        return AshitaCore:GetResourceManager():GetItemById(itemId);
    end);

    if (not ok or item == nil) then
        resources[itemId] = false;

        return nil;
    end

    resources[itemId] = item;

    return item;
end

local function itemName(itemId)
    local item = resourceOf(itemId);

    if (item == nil or item.Name == nil or item.Name[1] == nil or item.Name[1] == '') then
        return string.format('item %d', itemId or 0);
    end

    return item.Name[1];
end

local function zoneName(zoneId)
    if (zoneId == nil or zoneId <= 0) then
        return '';
    end

    local ok, name = pcall(function ()
        return AshitaCore:GetResourceManager():GetString('zones.names', zoneId);
    end);

    if (ok and type(name) == 'string' and name ~= '') then
        return name;
    end

    return string.format('zone %d', zoneId);
end

--[[
* The D3D device, fetched on first use rather than at load: this addon can be
* loaded from the launcher's boot script, long before the client has a
* rendering device, and a file-scope d3d.get_device() would make the whole
* addon fail to load (dwbags' lesson, kept verbatim through dwcpx).
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        local ok, dev = pcall(d3d.get_device);

        if (ok) then
            d3d8dev = dev;
        end
    end

    return d3d8dev;
end

--[[
* Item icons, from the client's own resources -- dwbags' iconOf/drawIcon by
* way of dwcpx, kept verbatim, reasoning and all: cached because the rows are
* redrawn every frame and D3DXCreateTextureFromFileInMemoryEx is not free;
* gc_safe_release hands back a texture that releases itself when Lua collects
* it, which is what keeps this from leaking across a reload.
--]]
local icons     = T{ };
local iconCount = 0;

local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = resourceOf(itemId);

    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;

        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;

        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));
    iconCount     = iconCount + 1;

    return icons[itemId];
end

--[[
* THE CEILING ON THE ICON CACHE (dwcpx 1.4.0's rule). Every entry is a live
* D3DPOOL_MANAGED texture and the key is an item id -- sixty-five thousand of
* them. FFXI is a 32-bit process that runs out of ADDRESSES long before it
* runs out of memory. The tabs hold at most 30 + 100 + 100 = 230 ids (1.2.2:
* the two halls went 30 -> 100) plus the Runes panel's forty (1.3.0,
* spoils_runes.lua RUNE_GEAR_LIMIT), 270 in all, and ONE tab -- at most a
* hundred ids -- is drawn a frame, so this is a brace rather than a working
* limit: a sweep can only ever fire across answers, never thrash inside one
* frame's demand. 256 -> 320 with the Runes panel, so every list at its
* ceiling still fits at once. It costs one comparison a frame. Keep it above
* the sum (harness B18 and Part C pin it).
*
* Dropped WHOLE rather than evicted one at a time (gc_safe_release owns the
* release, so letting go of the last reference IS the free), and dropped at
* the TOP OF A FRAME, never from inside iconOf: ImGui keeps the raw texture
* pointer in its draw list until Ashita renders that list at the end of the
* present hook.
--]]
local ICON_MAX = 320;

local function sweepIcons()
    if (iconCount < ICON_MAX) then
        return;
    end

    icons     = T{ };
    iconCount = 0;

    collectgarbage('collect');
end

--[[
* Rendering.
*
* MEASURED LAYOUT, NOT GUESSED (dwcraft's rule, reached here through
* dwunleashed). Both helpers read the LIVE font each frame and fall back to a
* conservative constant when a binding does not answer; the asymmetry is
* deliberate, because a fallback that is too big spends a few pixels of list
* and one that is too small hides a control the player needs to click.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

-- What a scrolling table must leave below itself: a table carrying ScrollY
-- owns a child window, and a child window given a ZERO outer height takes the
-- whole remaining content region -- so anything drawn after it lands below the
-- window's bottom edge. A NEGATIVE outer height reads as "available minus
-- this" (the dwnemesis footerReserve shape).
local function footerReserve()
    return -(metric('GetFrameHeightWithSpacing', 26) + 12);
end

-- One short tip on the item just drawn. Every plain tooltip in this file goes
-- through here so the pattern cannot drift call site by call site.
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

-- The server's clock at the moment the counts were built, advanced by however
-- long they have been on screen. THE CLIENT'S CLOCK IS ONLY EVER USED FOR THE
-- DELTA: a machine whose clock is minutes out still draws the right age,
-- because the base is the server's own `now`.
local function serverNow()
    if (state.counts == nil) then
        return 0;
    end

    local aged = state.countsAt ~= nil and math.max(0, os.clock() - state.countsAt) or 0;

    return state.counts.now + math.floor(aged);
end

-- "12 Sep 21:14"-ish is not available without a date library the client does
-- not ship, so a row is aged instead: how long ago, in the server's own clock.
local function ago(at)
    local now = serverNow();

    if (at <= 0 or now <= 0 or now < at) then
        return 'just now';
    end

    local seconds = now - at;

    if (seconds < 60) then
        return 'just now';
    end

    if (seconds < 3600) then
        return string.format('%dm ago', math.floor(seconds / 60));
    end

    if (seconds < 86400) then
        return string.format('%dh ago', math.floor(seconds / 3600));
    end

    return string.format('%dd ago', math.floor(seconds / 86400));
end

-- The augment pips. Four are GOLD, because four is the count the whole server
-- is told about; one to three are the theme's ordinary accent. Drawn as text
-- rather than as shapes so they scale with whatever font the player runs.
local function pips(count)
    local n = math.max(0, math.min(4, count or 0));

    if (n == 0) then
        imgui.TextDisabled('-');
        tip(TIPS.pips);

        return;
    end

    imgui.TextColored(n >= 4 and theme.colors.warn or theme.colors.hint, string.rep('*', n));
    tip(TIPS.pips);
end

--[[
* THE ITEM'S OWN CARD (the dwnemesis dropCard shape). The client already
* carries every word of this; a window that re-typed it would be a second
* source of truth for something the player can check in their own bag.
--]]
local FLAG_RARE = 0x8000;
local FLAG_EX   = 0x4000;

--[[
* The client packs an elemental-resistance icon as \239 plus a byte in the
* 0x1F..0x26 band. It is not UTF-8, so it renders as the '?' players reported
* against dwbags; each icon folds to a three-letter tag instead. MIRRORED BY
* HAND from dwnemesis 1.3.0 / dwah 1.4.0 / dwbags 1.17.0 -- edit one, revisit
* the others.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function (icon)
        return RESIST_TAGS[icon:byte()] .. ':';
    end));
end

local cardCache = { };

local function cardFor(itemId)
    local card = cardCache[itemId];

    if (card ~= nil) then
        return card;
    end

    local item = resourceOf(itemId);

    card = { };

    if (item ~= nil) then
        local tags = { };

        if (item.Level ~= nil and item.Level > 0) then
            tags[#tags + 1] = string.format('Lv %d', item.Level);
        end

        if (bit.band(item.Flags or 0, FLAG_RARE) ~= 0) then
            tags[#tags + 1] = 'Rare';
        end

        if (bit.band(item.Flags or 0, FLAG_EX) ~= 0) then
            tags[#tags + 1] = 'Ex';
        end

        if (#tags > 0) then
            card.tags = table.concat(tags, '  ');
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            card.desc = cleanDescription(desc);
        end
    else
        card.missing = true;
    end

    cardCache[itemId] = card;

    return card;
end

--[[
* `augList` is the decoded list this row carried, or nil; `augCount` is the
* wire's own count, which is all an old row (or an old server's Hall record)
* can offer. The card names every augment when it can and falls back to the
* count sentence when it cannot -- the 1.0.0 behaviour, kept exactly, because
* there are rows on prod written before the server sent any of this.
--]]
local function itemCard(itemId, augList, augCount, augs)
    local card = cardFor(itemId);

    imgui.BeginTooltip();
    imgui.Text(itemName(itemId));

    if (card.missing) then
        imgui.TextDisabled('(the client\'s own item data has nothing under this id)');
    else
        if (card.tags ~= nil) then
            imgui.TextDisabled(card.tags);
        end

        if (card.desc ~= nil) then
            imgui.Separator();
            imgui.PushTextWrapPos(320.0);
            imgui.Text(card.desc);
            imgui.PopTextWrapPos();
        end
    end

    imgui.Separator();

    --[[
    * WHICH AUGMENTS, NOT HOW MANY (1.1.0, the owner's ask). This line used to
    * end at "4 augment(s) on this piece." with the raw `1:5,2:9,25:3` under
    * it, on the reasoning that the catalog which turns one into a sentence is
    * DWQuest's and a second copy here would be a second thing to keep right.
    * The second half of that was true and is now handled the way dwbags, dwah
    * and dwwarehouse handle it -- a byte-identical copy of the SAME generated
    * file, gated -- and the first half meant the window drew everything about
    * a piece except the part the player opened it for.
    *
    * The raw pairs stay, dimmed, at the foot: they are what the server's own
    * log line and the `dw_spoils_ledger.augs` column spell, so a player
    * reporting something odd and the owner grepping for it are looking at the
    * same fourteen characters.
    --]]
    if (augList ~= nil) then
        imgui.TextDisabled(string.format('%d augment(s) on this piece:', #augList));

        for _, words in ipairs(augList) do
            imgui.TextColored(theme.colors.hint, '  ' .. words);
        end
    else
        imgui.TextDisabled(string.format('%d augment(s) on this piece.', augCount or 0));
    end

    if (augs ~= nil and augs ~= '') then
        imgui.TextDisabled(augs);
    end

    imgui.EndTooltip();
end

-- The icon cell. A row whose id the client cannot draw gets the same gap, so
-- the column never jumps between rows.
local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end
end

local function refreshTip()
    if (state.refused) then
        return TIPS.refreshStale;
    end

    local at = state.rowsAt;

    if (state.tab == 'hall') then
        at = state.hallAt;
    elseif (state.tab == 'superauged') then
        at = state.superAt;
    elseif (state.tab == 'runes') then
        at = runes.walletAt;
    end

    if (at == nil) then
        return TIPS.refresh;
    end

    return string.format('%s\nWhat is on screen arrived about %d second(s) ago.',
        TIPS.refresh, math.max(0, math.floor(os.clock() - at)));
end

local function renderHeader()
    if (imgui.Button('Refresh##dwsp_refresh')) then
        -- A click is the player asking: it lifts the liftable latch, clears a
        -- stale refusal, and re-asks whichever tab is on screen. On the Runes
        -- tab with the panel open the bags are read again too, right after.
        ask(state.tab, true);

        if (state.tab == 'runes' and runes.target ~= nil) then
            runes.gearWanted = true;
        end
    end

    -- Built only when it is going to be read: refreshTip formats a sentence
    -- and reads the clock, and tip() would evaluate it every frame.
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(refreshTip());
    end

    imgui.SameLine();

    -- REFUSED OUTRANKS SILENT. A protocol mismatch is the one state here with
    -- an action attached to it, and the mismatch branch retires the answer
    -- clock precisely so the silent latch cannot paint over the sentence that
    -- is true.
    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwspoils through the launcher.');
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server. Refresh to ask again.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or asking()) then
        imgui.TextDisabled('asking...');
    elseif (state.counts ~= nil) then
        imgui.Text(string.format('%d award(s) on this account', state.counts.lifetime));
        tip(TIPS.lifetime);

        imgui.SameLine();

        imgui.TextColored(theme.colors.warn, string.format('   %d with four augments',
            state.counts.fours));
        tip(TIPS.fours);

        -- 1.2.0. Drawn only when there is one: a zero here on every account
        -- that has never had a Super find is a number nobody needs to read.
        if ((state.counts.supers or 0) > 0) then
            imgui.SameLine();
            imgui.TextColored(theme.colors.hint, string.format('   %d Super Auged', state.counts.supers));
            tip(TIPS.supers);
        end
    else
        imgui.TextDisabled('Anything that pays you experience can pay you gear.');
    end

    imgui.Separator();
end

local function renderMine()
    local rows = state.rows;

    if (rows == nil) then
        imgui.TextDisabled('Waiting for the server...');

        return;
    end

    if (#rows == 0) then
        -- THE ONE SENTENCE, and it says nothing about the odds beyond "a small
        -- chance" (owner, 2026-09-20). There is no rate on this wire and there
        -- is nothing here for a future version to read one out of.
        imgui.TextWrapped('Nothing yet. Every monster that pays you experience has a small '
            .. 'chance to hand you a piece of augmented gear, levelled to whatever died -- '
            .. 'straight into your bags, no lot and no trade.');

        return;
    end

    imgui.Text(string.format('Your last %d:', #rows));
    tip(TIPS.rows);
    imgui.Separator();

    if (imgui.BeginTable('dwsp_mine', 7,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad  = textWidth('nn', 14);
        local size = metric('GetTextLineHeight', 14) + 4;

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('##dwsp_icon', ImGuiTableColumnFlags_WidthFixed, size + pad);
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('Augs', ImGuiTableColumnFlags_WidthFixed, textWidth('Augs', 40) + pad);
        imgui.TableSetupColumn('Monster', ImGuiTableColumnFlags_WidthStretch, 2.6);
        imgui.TableSetupColumn('Zone', ImGuiTableColumnFlags_WidthStretch, 2.2);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, textWidth('999d ago', 66) + pad);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 1.8);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            drawIcon(row.itemId, size);

            imgui.TableNextColumn();
            imgui.Text(itemName(row.itemId));

            if (imgui.IsItemHovered()) then
                itemCard(row.itemId, row.augList, row.augCount, row.augs);
            end

            -- A Super Auged find says so beside its name (1.2.0).
            if (row.super) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.hint, '(Super Auged)');
                tip(TIPS.superMark);
            end

            -- THE SECOND LINE, under the item, dimmed: what it rolled. Built
            -- once when the record arrived (decodeAugs), so this is one Text
            -- call and no formatting. A row the server sent no augments for
            -- simply does not get one, and the table's rows stay the height
            -- they were.
            if (row.augLine ~= nil) then
                imgui.TextDisabled(row.augLine);
                tip(TIPS.augs);
            end

            imgui.TableNextColumn();
            pips(row.augCount);

            imgui.TableNextColumn();

            if (row.nm) then
                imgui.TextColored(theme.colors.hint, string.format('%s (NM %d)',
                    row.mobName ~= '' and row.mobName or 'something', row.mobLvl));
            else
                imgui.Text(string.format('%s (%d)',
                    row.mobName ~= '' and row.mobName or 'something', row.mobLvl));
            end

            tip(TIPS.monster);

            imgui.TableNextColumn();
            imgui.Text(zoneName(row.zoneId));
            tip(TIPS.zone);

            imgui.TableNextColumn();
            imgui.Text(ago(row.at));
            tip(TIPS.when);

            imgui.TableNextColumn();

            local word = LANDED_WORD[row.landed];

            if (row.landed == 9) then
                imgui.TextColored(theme.colors.err, 'lost');
                tip(TIPS.landed);
            elseif (row.landed == 4) then
                imgui.TextDisabled(row.taker ~= '' and row.taker or 'another character');
                tip(TIPS.landed);
            elseif (word ~= nil and word ~= '') then
                imgui.TextDisabled(word);
                tip(TIPS.landed);
            else
                imgui.TextDisabled('');
            end
        end

        imgui.EndTable();
    end
end

local function renderHall()
    local rows = state.hall;

    if (rows == nil) then
        imgui.TextDisabled('Waiting for the server...');

        return;
    end

    if (#rows == 0) then
        imgui.TextWrapped('Nothing yet. A piece handed over with four augments is announced to '
            .. 'the whole server, and every one of them lands here.');

        return;
    end

    imgui.Text(string.format('The last %d on the server:', #rows));
    tip(TIPS.hallRows);
    imgui.Separator();

    if (imgui.BeginTable('dwsp_hall', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad  = textWidth('nn', 14);
        local size = metric('GetTextLineHeight', 14) + 4;

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, textWidth('999d ago', 66) + pad);
        imgui.TableSetupColumn('Who', ImGuiTableColumnFlags_WidthStretch, 1.8);
        imgui.TableSetupColumn('##dwsp_hall_icon', ImGuiTableColumnFlags_WidthFixed, size + pad);
        imgui.TableSetupColumn('What', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('Off', ImGuiTableColumnFlags_WidthStretch, 2.6);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 2.2);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.Text(ago(row.at));
            tip(TIPS.when);

            imgui.TableNextColumn();
            imgui.Text(row.charName ~= '' and row.charName or 'someone');

            imgui.TableNextColumn();
            drawIcon(row.itemId, size);

            imgui.TableNextColumn();

            if (row.first) then
                imgui.TextColored(theme.colors.warn, itemName(row.itemId));
            else
                imgui.Text(itemName(row.itemId));
            end

            if (imgui.IsItemHovered()) then
                itemCard(row.itemId, row.augList, 4, row.augs);
            end

            if (row.first) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.warn, '(first)');
                tip(TIPS.first);
            end

            -- The four, under the name. This is the tab's whole point: a Hall
            -- row is four augments BY DEFINITION, so the count was never the
            -- interesting number and which four always was.
            if (row.augLine ~= nil) then
                imgui.TextDisabled(row.augLine);
                tip(TIPS.augs);
            end

            imgui.TableNextColumn();
            imgui.Text(string.format('%s (%d)',
                row.mobName ~= '' and row.mobName or 'something', row.mobLvl));
            tip(TIPS.monster);

            imgui.TableNextColumn();
            imgui.Text(zoneName(row.zoneId));
            tip(TIPS.zone);
        end

        imgui.EndTable();
    end
end

--[[
* THE SUPER AUGED TAB (1.2.0). renderHall's shape with two differences, both
* forced by what a Super row IS: it carries one to four augments, so the
* count comes off the wire and is drawn as pips in its own column (the Hall
* hard-codes four, which is true there and false here); and `first` means
* the first Super Auged copy of that item on the server, with its own tip.
--]]
local function renderSuper()
    if (superUnsupported) then
        imgui.TextWrapped(TIPS.superMissing);

        return;
    end

    local rows = state.super;

    if (rows == nil) then
        imgui.TextDisabled('Waiting for the server...');

        return;
    end

    if (#rows == 0) then
        imgui.TextWrapped('Nothing yet. A few of the rolls anybody wins are Super Auged -- one to four '
            .. 'augments from a stronger pool -- and every one of them is announced to the whole '
            .. 'server and lands here.');

        return;
    end

    imgui.Text(string.format('The last %d on the server:', #rows));
    tip(TIPS.superRows);
    imgui.Separator();

    if (imgui.BeginTable('dwsp_super', 7,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad  = textWidth('nn', 14);
        local size = metric('GetTextLineHeight', 14) + 4;

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, textWidth('999d ago', 66) + pad);
        imgui.TableSetupColumn('Who', ImGuiTableColumnFlags_WidthStretch, 1.8);
        imgui.TableSetupColumn('##dwsp_super_icon', ImGuiTableColumnFlags_WidthFixed, size + pad);
        imgui.TableSetupColumn('What', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('Augs', ImGuiTableColumnFlags_WidthFixed, textWidth('Augs', 40) + pad);
        imgui.TableSetupColumn('Off', ImGuiTableColumnFlags_WidthStretch, 2.6);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 2.2);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.Text(ago(row.at));
            tip(TIPS.when);

            imgui.TableNextColumn();
            imgui.Text(row.charName ~= '' and row.charName or 'someone');

            imgui.TableNextColumn();
            drawIcon(row.itemId, size);

            imgui.TableNextColumn();

            if (row.first) then
                imgui.TextColored(theme.colors.warn, itemName(row.itemId));
            else
                imgui.Text(itemName(row.itemId));
            end

            if (imgui.IsItemHovered()) then
                itemCard(row.itemId, row.augList, row.augCount, row.augs);
            end

            if (row.first) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.warn, '(first)');
                tip(TIPS.superFirst);
            end

            if (row.augLine ~= nil) then
                imgui.TextDisabled(row.augLine);
                tip(TIPS.augs);
            end

            imgui.TableNextColumn();
            pips(row.augCount);

            imgui.TableNextColumn();
            imgui.Text(string.format('%s (%d)',
                row.mobName ~= '' and row.mobName or 'something', row.mobLvl));
            tip(TIPS.monster);

            imgui.TableNextColumn();
            imgui.Text(zoneName(row.zoneId));
            tip(TIPS.zone);
        end

        imgui.EndTable();
    end
end

--[[
* THE RUNES TAB (1.3.0).
*
* Two faces in one tab, never both at once: the LIST -- every kind of Rune
* the catalog knows, grouped by where it fits, with what this account has
* found and still holds -- and, once a Rune's Apply... is clicked, the
* PANEL: which of your pieces it fits (the server's answer, `runegear`), the
* four slots of the one you pick, what the Rune would do to them, a confirm
* step, and the result. `runes.target` is the switch.
--]]

-- A sentence that should wrap at the window's edge, in a colour. TextColored
-- does not wrap on its own, and a refusal cut off at the right edge is a
-- refusal the player cannot finish reading.
local function wrapColored(colour, text)
    imgui.PushTextWrapPos(0.0);
    imgui.TextColored(colour, text);
    imgui.PopTextWrapPos();
end

--[[
* THE LIST'S VIEW: the groups and rows that survive the search box and the
* Owned-only toggle, with every per-row string already built. Rebuilt only
* when one of the three things it depends on moved -- the search text, the
* toggle, the wallet (walletSerial) -- and otherwise handed back as it was,
* so a frame is Text calls and nothing else. The search is local: the whole
* catalog is in this folder, so typing never asks the server anything.
--]]
local function runeView()
    local needle = string.lower(tostring(runes.search[1] or '')):gsub('^%s+', ''):gsub('%s+$', '');
    local owned  = runes.ownedOnly[1] == true;
    local key    = string.format('%s|%s|%d', needle, owned and '1' or '0', runes.walletSerial);
    local old    = runes.view;

    if (old ~= nil and old.key == key) then
        return old;
    end

    local view = {
        key    = key,
        needle = needle,
        groups = { },
        shown  = 0,

        -- A NEW search opens every group it found something in, once (the
        -- dwfame rule): a match folded away under a closed header is a match
        -- the player cannot see. Once -- after that the headers are theirs.
        force = needle ~= '' and (old == nil or old.needle ~= needle),
    };

    local groups = RUNE.groups;

    -- No catalog in this folder: the Runes the wallet names, under one
    -- heading, by numeral and augment -- the degraded list the header warns of.
    if (RUNE.missing) then
        local ids, list = { }, { };

        if (runes.wallet ~= nil) then
            for id in pairs(runes.wallet.byId) do
                ids[#ids + 1] = id;
            end
        end

        table.sort(ids);

        for _, id in ipairs(ids) do
            list[#list + 1] = runeInfo(id);
        end

        groups = { { key = 'held', label = 'Your Runes', runes = list } };
    end

    local wallet = runes.wallet;

    for _, group in ipairs(groups) do
        local rows, holding = { }, 0;

        for _, r in ipairs(group.runes) do
            local left  = heldOf(r.id);
            local entry = wallet ~= nil and wallet.byId[r.id] or nil;
            local found = wallet ~= nil and (entry ~= nil and entry.found or 0) or nil;

            if ((needle == '' or string.find(r.search, needle, 1, true) ~= nil)
                    and (not owned or (left or 0) > 0)) then
                rows[#rows + 1] = {
                    rune      = r,
                    left      = left or 0,
                    foundText = found ~= nil and tostring(found) or '-',
                    leftText  = left ~= nil and tostring(left) or '-',
                    whyNot    = left == nil and TIPS.runeWaiting or TIPS.runeNone,
                    counts    = found ~= nil and string.format('You hold %d. The account has found %d.', left, found) or nil,
                };

                if ((left or 0) > 0) then
                    holding = holding + 1;
                end
            end
        end

        -- A group with nothing left in it after the search is not drawn at
        -- all: an empty header is a question with no answer under it.
        if (#rows > 0) then
            view.groups[#view.groups + 1] = {
                rows    = rows,
                tableId = 'dwsp_runes_' .. group.key,
                header  = string.format('%s  (%d%s)###dwsp_rg_%s', group.label, #rows,
                    holding > 0 and string.format(', %d held', holding) or '', group.key),
            };

            view.shown = view.shown + #rows;
        end
    end

    if (view.shown == 0) then
        if (needle ~= '') then
            view.empty = string.format('No Rune matches "%s".', needle);
        elseif (owned) then
            view.empty = 'You hold no Runes right now.';
        else
            view.empty = 'No Runes to list yet.';
        end
    end

    runes.view = view;

    return view;
end

--[[
* A RUNE'S CARD: its full name, the augment it attaches, every range it can
* roll and on what, where it fits, and the rule for where it lands -- the
* one place the rule is written out, because it is the thing a player has
* to know before they reach the Confirm.
--]]
local function runeCard(r, row)
    imgui.BeginTooltip();

    -- The whole card wraps at one width: a range line can be far longer than
    -- a tooltip should be wide, and a card as wide as the screen is unread.
    imgui.PushTextWrapPos(380.0);
    imgui.Text(r.title);

    if (r.name ~= '') then
        imgui.TextColored(theme.colors.hint, string.format('Applies %s (augment %d)', r.name, r.id));
    end

    imgui.Separator();

    if (#r.cardRanges > 0) then
        imgui.TextDisabled('Rolls, lowest to highest:');

        for _, line in ipairs(r.cardRanges) do
            imgui.Text('  ' .. line);
        end
    elseif (r.unlisted) then
        imgui.TextDisabled('Not in this copy\'s Rune list: the apply panel asks the server what it fits.');
    end

    if (r.fits ~= '') then
        imgui.TextDisabled('Fits ' .. r.fits .. '.');
    end

    imgui.Separator();
    imgui.Text(TIPS.runeRules);

    if (row ~= nil and row.counts ~= nil) then
        imgui.TextDisabled(row.counts);
    end

    imgui.PopTextWrapPos();
    imgui.EndTooltip();
end

local function resetPick()
    runes.pick       = nil;
    runes.choice     = nil;
    runes.confirming = false;
end

-- Into the panel for one Rune: a fresh bag read of every bag, no name, no
-- piece chosen. The read itself goes out from the frame loop, behind any
-- read already in flight (one outstanding ask at a time).
local function openRunePanel(id)
    resetPick();

    runes.target        = id;
    runes.bag           = 'all';
    runes.filter[1]     = '';
    runes.filterApplied = '';
    runes.gear          = nil;
    runes.gearSent      = nil;
    runes.result        = nil;
    runes.note          = nil;
    runes.noteBad       = false;
    runes.gearWanted    = true;
end

local function closeRunePanel()
    resetPick();

    runes.target     = nil;
    runes.gear       = nil;
    runes.gearSent   = nil;
    runes.gearFailed = false;
    runes.gearRetry  = nil;
    runes.result     = nil;
    runes.note       = nil;
    runes.gearWanted = false;

    -- A lost answer owes no bag read once the panel is left: the wallet alone
    -- settles it, and says so in chat (settleLost).
    settleLost();
end

--[[
* TEXT THAT WRAPS AT ITS CELL'S RIGHT EDGE. Inside a table a wrap position of
* 0 is the cell's own edge, so a long range or name breaks between words onto
* a second line instead of running under the next column. The window's
* default width and the 700 a player may have saved from before 1.3.0 are
* both narrower than the widest range the catalog carries.
--]]
local function cellText(text)
    imgui.PushTextWrapPos(0.0);
    imgui.Text(text);
    imgui.PopTextWrapPos();
end

local function cellDim(text)
    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled(text);
    imgui.PopTextWrapPos();
end

--[[
* THE FIXED COLUMNS, MEASURED ONCE PER FONT SIZE. Thirteen group tables are
* set up every frame; measuring their five fixed widths each time was sixty-
* five CalcTextSize calls a frame to learn five numbers that move only when
* the player's font does -- so they are measured when the line height
* changes, and handed back otherwise.
--]]
local columns = { height = nil };

local function columnWidths()
    local height = metric('GetTextLineHeight', 14);

    if (columns.height ~= height) then
        local pad = textWidth('nn', 14);

        columns.height = height;
        columns.rune   = textWidth(RUNE.widest, 84) + pad;
        columns.count  = textWidth('Found', 35) + pad;
        columns.act    = textWidth('Apply...', 56) + pad;
        columns.icon   = height + 4 + pad;
        columns.pick   = textWidth('in your bazaar', 98) + pad;
    end

    return columns;
end

-- One opened-by-default fold (dwcon's shape: SetNextItemOpen, then the one-
-- argument CollapsingHeader) behind the hedge. `cond` is Once for "open the
-- first time it is drawn, the player's thereafter", Always for a new search.
local function openNextNode(cond)
    if (hedge.nodeBroken or cond == nil) then
        return;
    end

    if (not pcall(imgui.SetNextItemOpen, true, cond)) then
        hedge.nodeBroken = true;
    end
end

-- A radio button, or -- if the live binding ever refuses the call -- a small
-- button that says which is chosen (dwhub's radio(), kept to the letter).
-- Returns whether it was pressed.
local function radio(label, active)
    if (not hedge.radioBroken) then
        local ok, pressed = pcall(imgui.RadioButton, label, active);

        if (ok) then
            return pressed == true;
        end

        hedge.radioBroken = true;
    end

    return imgui.SmallButton((active and '[x] ' or '[ ] ') .. label);
end

--[[
* THE LIST'S TABLE: six columns, the same in every group so they line up
* down the whole list. WHERE A RUNE FITS IS NOT A COLUMN: the group header
* already says it for every single-kind Rune, and a Rune with several kinds
* names each one on its own range line ("Armor: ..", "Melee weapons: ..") --
* so the phrase lives in the card, whole, and its width goes to the range,
* which is the column a player reads.
--]]
local function runeTable(group, cols)
    if (not imgui.BeginTable(group.tableId, 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
        return;
    end

    imgui.TableSetupColumn('Rune', ImGuiTableColumnFlags_WidthFixed, cols.rune);
    imgui.TableSetupColumn('Augment', ImGuiTableColumnFlags_WidthStretch, 2.0);
    imgui.TableSetupColumn('Roll range', ImGuiTableColumnFlags_WidthStretch, 3.4);
    imgui.TableSetupColumn('Found', ImGuiTableColumnFlags_WidthFixed, cols.count);
    imgui.TableSetupColumn('Left', ImGuiTableColumnFlags_WidthFixed, cols.count);
    imgui.TableSetupColumn('##dwsp_rune_act', ImGuiTableColumnFlags_WidthFixed, cols.act);
    imgui.TableHeadersRow();

    for _, row in ipairs(group.rows) do
        local r = row.rune;

        imgui.TableNextRow();

        imgui.TableNextColumn();

        if (row.left > 0) then
            imgui.TextColored(theme.colors.hint, r.title);
        else
            imgui.Text(r.title);
        end

        if (imgui.IsItemHovered()) then
            runeCard(r, row);
        end

        imgui.TableNextColumn();
        cellText(r.name);

        if (imgui.IsItemHovered()) then
            runeCard(r, row);
        end

        -- Every range line opens the whole card: the range is what a player
        -- hovers to learn more about, and the card has every range and where
        -- each one applies.
        imgui.TableNextColumn();

        for _, text in ipairs(r.rangeLines) do
            cellText(text);

            if (imgui.IsItemHovered()) then
                runeCard(r, row);
            end
        end

        imgui.TableNextColumn();
        imgui.Text(row.foundText);
        tip(TIPS.runeFoundCol);

        imgui.TableNextColumn();
        imgui.Text(row.leftText);
        tip(TIPS.runeLeftCol);

        imgui.TableNextColumn();

        -- A GREYED WORD, NOT A DISABLED BUTTON, when there is nothing to
        -- spend (dwcpx's rule): ImGui reports no hover over a disabled item
        -- without a flag this suite refuses, so a greyed button could never
        -- say why it is grey.
        if (row.left > 0) then
            local applying = imgui.SmallButton(r.applyBtn);

            tip(TIPS.runeApply);

            if (applying) then
                openRunePanel(r.id);
            end
        else
            imgui.TextDisabled('Apply...');
            tip(row.whyNot);
        end
    end

    imgui.EndTable();
end

local function renderRuneList()
    local wallet = runes.wallet;

    if (wallet == nil) then
        imgui.TextDisabled('Waiting for the server...');
    else
        imgui.Text(string.format('Runes held %d', wallet.left));
        tip(TIPS.runesHeld);
        imgui.SameLine();
        imgui.TextDisabled(string.format('   found %d lifetime', wallet.found));
        tip(TIPS.runesFound);
        imgui.SameLine();

        -- "of N" is the SERVER's count of kinds (q| field 5); this copy's own
        -- count only when an older core did not send one.
        imgui.TextDisabled(string.format('   %d kinds of %d found', wallet.kindsFound or 0,
            wallet.kinds > 0 and wallet.kinds or RUNE.count));
        tip(TIPS.runesKinds);
    end

    if (RUNE.missing) then
        wrapColored(theme.colors.warn, TIPS.runeNoList);
    end

    imgui.TextDisabled('Find:');
    imgui.SameLine();
    imgui.PushItemWidth(textWidth('mmmmmmmmmmmmmmmmmm', 126));
    imgui.InputText('##dwsp_rune_search', runes.search, 48);
    tip(TIPS.runeSearch);
    imgui.PopItemWidth();
    imgui.SameLine();
    imgui.Checkbox('Owned only##dwsp_rune_owned', runes.ownedOnly);
    tip(TIPS.runeOwned);

    -- THE EMPTY STATE, and like the spoils one it names no rate: where Runes
    -- come from, and nothing about how often (spec D4).
    if (wallet ~= nil and wallet.found == 0) then
        imgui.TextColored(theme.colors.note, TIPS.runeEmpty);
    end

    -- A wallet whose rows did not add up to its totals (the handler asked
    -- once more): the totals are true, some rows may read 0 that are not.
    if (wallet ~= nil and wallet.short) then
        wrapColored(theme.colors.warn, 'Part of your Rune list did not arrive. Refresh to read it again.');
        tip(TIPS.runeShort);
    end

    local view = runeView();

    if (view.shown == 0) then
        imgui.TextDisabled(view.empty);

        return;
    end

    -- ONE scrolling child for the whole list, with the footer reserve the
    -- hall tables use: ninety-odd Runes is a longer scroll, never a taller
    -- window, and the footnote below it stays on screen.
    local listOpen = imgui.BeginChild('##dwsp_runes_list', { 0, footerReserve() }, ImGuiChildFlags_None);

    if (listOpen) then
        local cols = columnWidths();

        for _, group in ipairs(view.groups) do
            openNextNode(view.force and ImGuiCond_Always or ImGuiCond_Once);

            if (imgui.CollapsingHeader(group.header)) then
                runeTable(group, cols);
            end
        end

        view.force = false;
    end

    -- EndChild answers BeginChild WHATEVER it returned (Begin's rule).
    imgui.EndChild();

    imgui.TextDisabled(TIPS.runeFooter);
end

-- The apply panel's piece, with its four slots and the range this Rune rolls
-- on it: the client's own card for the item first, then what is on it.
local function gearCard(row)
    local card = cardFor(row.itemId);

    imgui.BeginTooltip();
    imgui.Text(itemName(row.itemId));

    if (card.tags ~= nil) then
        imgui.TextDisabled(card.tags);
    end

    if (card.desc ~= nil) then
        imgui.Separator();
        imgui.PushTextWrapPos(320.0);
        imgui.Text(card.desc);
        imgui.PopTextWrapPos();
    end

    imgui.Separator();
    imgui.TextDisabled(row.bag);

    for index, s in ipairs(row.slots) do
        if (s.id == 0) then
            imgui.TextDisabled(string.format('  slot %d: empty', index));
        else
            imgui.TextColored(theme.colors.hint, string.format('  slot %d: %s', index, s.text));
        end
    end

    imgui.TextDisabled(string.format('This Rune rolls %s here.', row.range));
    imgui.EndTooltip();
end

-- A NEW QUESTION CLEARS THE OLD ANSWER: rows drawn under a bag or a name
-- they were not read for are rows the player could pick believing the combo
-- beside them. "Looking through your bags..." until the new answer lands.
local function chooseBag(key)
    if (runes.bag ~= key) then
        resetPick();

        runes.bag        = key;
        runes.gear       = nil;
        runes.gearWanted = true;
    end
end

--[[
* THE NAME FILTER GOES ON A COMMAND LINE, so it is scrubbed first (dwquest's
* safeFilter, one character wider): `@` and `#` are the server's own argument
* markers, `|` is the wire's separator, `%` is the one byte a server log line
* formats, and nothing outside plain ASCII is a name the client shows. Capped
* so the line always fits one chat packet with room to spare.
--]]
local RUNE_FILTER_MAX = 30;

local function applyFilter()
    local clean = tostring(runes.filter[1] or ''):gsub('[^\32-\126]', ' '):gsub('[@#|%%]', ' ');

    clean = clean:gsub('%s+', ' '):gsub('^%s+', '');
    clean = string.sub(clean, 1, RUNE_FILTER_MAX):gsub('%s+$', '');

    resetPick();

    runes.filterApplied = clean;
    runes.gear          = nil;
    runes.gearWanted    = true;
end

local function gearControls()
    imgui.TextDisabled('Bag:');
    imgui.SameLine();
    imgui.PushItemWidth(textWidth('Mog Wardrobe 8', 98) + 30);

    local open = imgui.BeginCombo('##dwsp_rune_bag', BAG_NAME[runes.bag] or 'All bags');

    -- Right after BeginCombo and outside the `if` (dwquest's characterRow
    -- rule): the combo is the last item whether it opened or not.
    tip(TIPS.runeBag);

    if (open) then
        for _, bag in ipairs(RUNE_BAGS) do
            if (imgui.Selectable(bag.id, runes.bag == bag.key)) then
                chooseBag(bag.key);
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
    imgui.SameLine();
    imgui.TextDisabled('Name:');
    imgui.SameLine();
    imgui.PushItemWidth(textWidth('mmmmmmmmmmmmmmmm', 112));

    -- EnterReturnsTrue: the server is asked on Enter or Search, never per
    -- keystroke, and the live buffer is read only there.
    local entered = imgui.InputText('##dwsp_rune_filter', runes.filter, RUNE_FILTER_MAX + 2,
        ImGuiInputTextFlags_EnterReturnsTrue);

    tip(TIPS.runeFilter);
    imgui.PopItemWidth();
    imgui.SameLine();

    local searched = imgui.SmallButton('Search##dwsp_rune_find');

    tip(TIPS.runeFind);

    if (entered or searched) then
        applyFilter();
    end
end

-- The slot the Rune would land in: the rule's, or the player's choice on a
-- full piece; nil until a full piece's choice is made.
local function targetSlot(row)
    return row.plan.slot or runes.choice;
end

-- Why the Apply / Confirm button is not there right now, or nil. The first
-- answer that applies is the one said.
local function applyBlocker(row)
    if (runes.applying ~= nil) then
        return TIPS.runeBusy;
    end

    -- A write whose answer was lost is accounted for before another is made.
    if (runes.lost ~= nil) then
        return TIPS.runeLost;
    end

    -- A server this addon cannot read is not one to spend against.
    if (state.refused) then
        return TIPS.refreshStale;
    end

    if (row.status ~= nil) then
        return TIPS[row.status.tip];
    end

    local held = heldOf(runes.target);

    if (held == nil) then
        return TIPS.runeWaiting;
    end

    if (held <= 0) then
        return TIPS.runeNoneLeft;
    end

    if (targetSlot(row) == nil) then
        return TIPS.runeChoose;
    end

    return nil;
end

--[[
* THE CONFIRM, and the only place this window spends anything.
*
* One write in flight at a time: `applying` is set in the same statement
* that queues the line, the button is gone for as long as it is set, and it
* is cleared only by the answer (`a|` / `e|` at its `z|`), by the latch, or
* by APPLY_TIMEOUT -- never by sending it again. The line names the piece by
* its loc, slot, id AND stamp exactly as the server drew them, so a piece
* that moved or changed since is a refusal rather than a Rune spent on the
* wrong thing. The slot is the one the confirm step named: the rule's slot,
* or the player's choice on a full piece -- the server holds it to the same
* rule and refuses anything else, so what the player read is what happens.
--]]
local function confirmApply(row)
    if (runes.applying ~= nil or runesUnsupported or runes.target == nil or applyBlocker(row) ~= nil) then
        return;
    end

    local line = string.format(RUNEAPPLY_LINE, runes.target, row.loc, row.slot, row.itemId, row.stamp,
        targetSlot(row));

    -- `before` is the count this click was made against: if the answer is
    -- lost, the re-read's count against it is how the panel learns whether
    -- the Rune was spent (settleLost).
    runes.applying = { at = os.clock(), line = line, rune = runes.target, itemId = row.itemId,
                       before = heldOf(runes.target), roman = runeInfo(runes.target).roman };
    runes.result   = nil;
    runes.note     = nil;
    runes.noteBad  = false;

    issue(line);
end

local function confirmBox(row)
    local r    = runeInfo(runes.target);
    local held = heldOf(runes.target) or 0;
    local slot = targetSlot(row);
    local s    = slot ~= nil and row.slots[slot] or nil;

    wrapColored(theme.colors.warn, string.format('Spend one %s%s on your %s?', r.title,
        r.name ~= '' and (' (' .. r.name .. ')') or '', itemName(row.itemId)));
    imgui.TextDisabled(string.format('You hold %d; %d after this.', held, math.max(0, held - 1)));
    imgui.TextWrapped(string.format('It rolls %s on this piece.', row.rangeLong));

    if (row.plan.kind == 'reroll' and s ~= nil) then
        imgui.TextWrapped(string.format('It re-rolls slot %d, which holds %s now.', slot, s.text));
    elseif (row.plan.kind == 'free') then
        imgui.TextWrapped(string.format('It goes into free slot %d. Nothing is overwritten.', slot));
    elseif (s ~= nil) then
        wrapColored(theme.colors.err, string.format('It overwrites slot %d: %s is gone for good.', slot, s.text));
    end

    if (runes.applying ~= nil) then
        imgui.TextDisabled('Applying...');
        tip(TIPS.runeBusy);

        return;
    end

    local why = applyBlocker(row);

    if (why ~= nil) then
        imgui.TextDisabled('Confirm');
        tip(why);
    else
        local confirmed = imgui.SmallButton('Confirm##dwsp_rune_confirm');

        tip(TIPS.runeConfirm);

        if (confirmed) then
            confirmApply(row);

            return;
        end
    end

    imgui.SameLine();

    local cancelled = imgui.SmallButton('Cancel##dwsp_rune_cancel');

    tip(TIPS.runeCancel);

    if (cancelled) then
        runes.confirming = false;
    end
end

local function slotView(row)
    local size = metric('GetTextLineHeight', 14) + 4;
    local plan = row.plan;

    drawIcon(row.itemId, size);

    if (imgui.IsItemHovered()) then
        gearCard(row);
    end

    imgui.SameLine();
    imgui.Text(itemName(row.itemId));

    if (imgui.IsItemHovered()) then
        gearCard(row);
    end

    imgui.SameLine();
    imgui.TextDisabled(string.format('(%s)', row.bag));
    cellDim(string.format('This Rune rolls %s on this piece.', row.range));
    tip(TIPS.runeHere);

    -- The four slots. A choice is offered ONLY when the rule leaves one --
    -- every slot full and none of them this augment -- and only until the
    -- confirm step opens; everywhere else the landing slot is marked. Every
    -- line wraps at the window's edge: a four-stat pet line at its rank, with
    -- the marker after it, is wider than the window's default width.
    local choosing = plan.kind == 'choose' and row.status == nil and not runes.confirming
        and runes.applying == nil;

    for index = 1, 4 do
        local s     = row.slots[index];
        local words = s.id == 0 and 'empty' or s.text;

        if (choosing) then
            if (radio(string.format('slot %d: %s###dwsp_rune_slot_%d', index, words, index), runes.choice == index)) then
                runes.choice = index;
            end
        elseif (targetSlot(row) == index) then
            wrapColored(theme.colors.hint, string.format('  slot %d: %s  <- %s', index, words,
                plan.kind == 'reroll' and 're-rolled' or (plan.kind == 'free' and 'the Rune goes here' or 'overwritten')));
        elseif (s.id == 0) then
            imgui.TextDisabled(string.format('  slot %d: empty', index));
        else
            cellText(string.format('  slot %d: %s', index, words));
        end
    end

    if (plan.kind == 'reroll') then
        imgui.TextWrapped(string.format('This piece already carries %s in slot %d, so the Rune re-rolls that '
            .. 'slot -- the new roll can come out lower than the one there now.', row.slots[plan.slot].text, plan.slot));
    elseif (plan.kind == 'free') then
        imgui.TextWrapped(string.format('It goes into free slot %d. Nothing on the piece is overwritten.', plan.slot));
    else
        imgui.TextWrapped('All four slots are full. Choose the one this Rune overwrites -- what is there now is gone for good.');
    end

    if (row.status ~= nil) then
        wrapColored(theme.colors.err, string.format('This piece is %s. %s', row.status.word, TIPS[row.status.tip]));
    end

    imgui.Separator();

    if (runes.confirming) then
        confirmBox(row);

        return;
    end

    local why = applyBlocker(row);

    if (why == nil) then
        local going = imgui.SmallButton('Apply...##dwsp_rune_go');

        tip(TIPS.runeApply);

        if (going) then
            runes.confirming = true;
        end
    else
        imgui.TextDisabled('Apply...');
        tip(why);
    end

    imgui.SameLine();

    local unpick = imgui.SmallButton('Pick another##dwsp_rune_unpick');

    tip(TIPS.runeUnpick);

    if (unpick) then
        resetPick();
    end
end

local function gearTable()
    local gear = runes.gear;
    local r    = runeInfo(runes.target);

    if (#gear.rows == 0) then
        local where = runes.bag == 'all' and 'your bags' or (BAG_NAME[runes.bag] or 'that bag');

        if (runes.filterApplied ~= '') then
            imgui.TextWrapped(string.format('Nothing in %s named like "%s" can take this Rune.', where, runes.filterApplied));
        else
            imgui.TextWrapped(string.format('Nothing in %s can take this Rune.%s', where,
                r.fits ~= '' and (' It fits ' .. r.fits .. '.') or ''));
        end

        -- THE PIECES THE SERVER LEAVES OUT, SAID OUT LOUD: an empty list is
        -- exactly where a player looks for the sword they know they carry.
        cellDim(TIPS.runeSigned);

        return;
    end

    -- A CAP THAT DOES NOT SAY SO READS AS AN INVENTORY (dwquest's rule).
    if (gear.shown < gear.total) then
        imgui.TextDisabled(string.format('Showing %d of %d.', gear.shown, gear.total));
        tip(TIPS.runeCapped);
    end

    -- ...and neither does a list that came up short (commitGear re-asks once).
    if (gear.incomplete) then
        wrapColored(theme.colors.warn, string.format('Only %d of the %d pieces arrived. Refresh to read the list again.',
            #gear.rows, gear.shown));
        tip(TIPS.runeShort);
    end

    if (imgui.BeginTable('dwsp_rune_gear', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local cols = columnWidths();
        local size = cols.height + 4;

        -- The wordy cells WRAP at their edge (cellText): an item's four
        -- augments, its bag and the range it rolls are each wider than their
        -- column at the window's default width.
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('##dwsp_rune_icon', ImGuiTableColumnFlags_WidthFixed, cols.icon);
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('Bag', ImGuiTableColumnFlags_WidthStretch, 1.6);
        imgui.TableSetupColumn('Rolls here', ImGuiTableColumnFlags_WidthStretch, 2.6);
        imgui.TableSetupColumn('##dwsp_rune_pickcol', ImGuiTableColumnFlags_WidthFixed, cols.pick);
        imgui.TableHeadersRow();

        for _, row in ipairs(gear.rows) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            drawIcon(row.itemId, size);

            if (imgui.IsItemHovered()) then
                gearCard(row);
            end

            imgui.TableNextColumn();

            -- EQUIPPED AND BAZAARED PIECES ARE LISTED, GREYED, WITH THE REASON
            -- (spec D3): "where did my sword go" is a worse question than "why
            -- can I not pick it".
            if (row.status ~= nil) then
                cellDim(itemName(row.itemId));
            else
                cellText(itemName(row.itemId));
            end

            if (imgui.IsItemHovered()) then
                gearCard(row);
            end

            cellDim(row.augLine);
            tip(TIPS.augs);

            imgui.TableNextColumn();
            cellDim(row.bag);

            imgui.TableNextColumn();
            cellText(row.range);
            tip(TIPS.runeHere);
            cellDim(row.planWords);
            tip(TIPS.runePlan);

            imgui.TableNextColumn();

            if (row.status ~= nil) then
                imgui.TextDisabled(row.status.word);
                tip(TIPS[row.status.tip]);
            else
                local picking = imgui.SmallButton(row.pickBtn);

                tip(TIPS.runePick);

                if (picking) then
                    resetPick();

                    runes.pick   = row.key;
                    runes.result = nil;
                    runes.note   = nil;
                end
            end
        end

        imgui.EndTable();
    end

    -- Under the list, in the footer room the table leaves: what is not in it
    -- and why. The server omits signed (crafted) pieces -- their extra bytes
    -- hold the signature, not augments -- and pieces in use; saying nothing
    -- made the omission look like a missing sword.
    cellDim(TIPS.runeSigned);
end

-- The `a|` answer, as a card at the top of the panel until the player picks
-- another piece or leaves: the words it rolled, where that sits in the range,
-- and what it did to the piece.
local function resultCard(res)
    local r = runeInfo(res.rune);

    wrapColored(theme.colors.ok, string.format('%s applied to your %s.', r.title, itemName(res.itemId)));
    imgui.Text(res.words);
    imgui.SameLine();
    imgui.TextDisabled(res.rankLine);
    imgui.SameLine();
    imgui.TextColored(theme.colors[res.colour] or theme.colors.text, res.verdict);
    tip(TIPS.runeVerdict);
    cellDim(res.where);

    if (res.leftLine ~= nil) then
        imgui.TextDisabled(res.leftLine);
    end

    imgui.Separator();
end

local function renderRunePanel()
    local r    = runeInfo(runes.target);
    local held = heldOf(runes.target);

    -- NO WAY OUT WHILE A CONFIRM IS IN FLIGHT. The answer is what the result
    -- card is for; leaving would drop the card the player is waiting on.
    if (runes.applying ~= nil) then
        imgui.TextDisabled('< Runes');
        tip(TIPS.runeBackBusy);
    else
        local back = imgui.SmallButton('< Runes##dwsp_rune_back');

        tip(TIPS.runeBack);

        if (back) then
            closeRunePanel();

            return;
        end
    end

    imgui.SameLine();
    imgui.TextColored(theme.colors.hint, r.title);

    if (imgui.IsItemHovered()) then
        runeCard(r, nil);
    end

    imgui.SameLine();
    imgui.Text(r.name);
    imgui.SameLine();
    imgui.TextDisabled(held == nil and '  (waiting for your count)' or string.format('  you hold %d', held));
    tip(TIPS.runesHeld);

    -- Where it fits, whole: the list keeps this phrase in the card, and here
    -- it is the reason the list below holds what it holds.
    if (r.fits ~= '') then
        cellDim(string.format('Fits %s.', r.fits));
    end

    gearControls();
    imgui.Separator();

    if (runes.result ~= nil) then
        resultCard(runes.result);
    end

    if (runes.note ~= nil) then
        wrapColored(runes.noteBad and theme.colors.err or theme.colors.note, runes.note);
    end

    -- NO LIST YET, and three different reasons why: the read was REFUSED (the
    -- refusal is the note above; waiting would be a lie), nobody answered at
    -- all (the header's banner says so too), or it is simply on its way.
    if (runes.gear == nil) then
        if (runes.gearFailed) then
            imgui.TextDisabled('Your bags could not be read. Refresh to try again.');
        elseif (state.serverSilent) then
            imgui.TextDisabled('No answer from the server. Refresh to ask again.');
        else
            imgui.TextDisabled('Looking through your bags...');
        end

        return;
    end

    local row = pickedRow();

    if (row == nil) then
        gearTable();
    else
        slotView(row);
    end
end

local function renderRunes()
    if (runesUnsupported) then
        imgui.TextWrapped(TIPS.runesMissing);

        return;
    end

    if (runes.target ~= nil) then
        renderRunePanel();
    else
        renderRuneList();
    end
end

--[[
* One tab. The remembered choice is written back only when the PLAYER moves,
* never when a `wantTab` from the command line takes the window somewhere for
* one frame -- and SetSelected is spent the frame it lands, because leaving it
* standing fights the player's own clicks on every other frame (the dwparse
* note).
--]]
local function tabItem(key, label, body)
    local flags = ImGuiTabItemFlags_None;

    if (state.wantTab == key) then
        flags = ImGuiTabItemFlags_SetSelected;
    end

    if (imgui.BeginTabItem(label, nil, flags)) then
        if (state.wantTab == key) then
            state.wantTab = nil;
        end

        if (state.wantTab == nil and state.tab ~= key) then
            state.tab = key;

            saveConfig();
        end

        body();
        imgui.EndTabItem();
    end
end

local function renderWindow()
    renderHeader();

    if (imgui.BeginTabBar('dwsp_tabs')) then
        tabItem('mine', string.format('My Spoils %d###dwsp_tab_mine',
            state.rows ~= nil and #state.rows or 0), renderMine);
        -- 1.3.0, right of My Spoils (the owner's placement). Its count is the
        -- Runes held, which is the number a player opens the tab to spend.
        tabItem('runes', string.format('Runes %d###dwsp_tab_runes',
            runes.wallet ~= nil and runes.wallet.left or 0), renderRunes);
        tabItem('hall', string.format('Hall of Four %d###dwsp_tab_hall',
            state.hall ~= nil and #state.hall or 0), renderHall);
        tabItem('superauged', string.format('Super Auged %d###dwsp_tab_super',
            state.super ~= nil and #state.super or 0), renderSuper);

        imgui.EndTabBar();
    end
end

--[[
* THE CONFIRM'S CLOCK (1.3.0), run every frame, window open or not -- a
* write outlives the window it was clicked in. It does NOT AGE while the
* line is still waiting in the queue or the client is zoning (the answer
* clock's re-stamp rule): a line that has not gone out yet has not gone
* unanswered, and a timeout that fired first would hand the button back for
* a click whose first line was still to be sent. When it does run out the
* panel says so and READS again; the write itself is never re-sent.
--]]
local function applyClock()
    local pending = runes.applying;

    if (pending == nil) then
        return;
    end

    local queued = false;

    for _, command in ipairs(queue) do
        if (command == pending.line) then
            queued = true;

            break;
        end
    end

    if (queued or not echo.canSend()) then
        pending.at = os.clock();

        return;
    end

    if ((os.clock() - pending.at) >= APPLY_TIMEOUT) then
        runes.applying   = nil;
        runes.confirming = false;
        runes.note       = 'No answer from the server. Nothing was sent again -- your Runes and your bags '
            .. 'are being read to show whether it landed.';
        runes.noteBad    = true;

        loseAnswer(pending);
    end
end

ashita.events.register('d3d_present', 'dwspoils_present', function ()
    pumpQueue();
    checkAnswers();
    applyClock();

    if (not state.open[1]) then
        return;
    end

    sweepIcons();

    -- THE FIRST ASK IS LAZY AND IT IS ASKED HERE, the first frame the window
    -- is actually shown in this zone -- never on the zone line, never at load.
    -- That is what keeps this addon out of dwecho's ZONE_ORDER entirely: it
    -- adds nothing to the login burst, because a closed window says nothing.
    -- Every latch is consulted here as well as inside ask(): this test runs
    -- sixty times a second and the call it saves is not free.
    --
    -- IT ASKS FOR `wantTab` WHEN THERE IS ONE, and that is not a nicety.
    -- `/spoils hall` from a CLOSED window sets wantTab and opens the window,
    -- but wantTab is only consumed inside the render pass -- so a hello that
    -- read state.tab asked for the remembered tab, waited out an answer, and
    -- only then asked for the one the player actually named: two lines and a
    -- couple of seconds of "Waiting for the server..." on the tab in front of
    -- them (2026-09-20, independent review).
    if (not state.helloSent and not latched() and not asking()) then
        state.helloSent = true;

        ask(state.wantTab or state.tab);
    elseif (not latched() and not asking()) then
        local verb = state.tab;

        -- THE NUDGE. An award line has just gone by, so the list on screen is
        -- known stale; collect it once, a couple of seconds later.
        --
        -- ON THE RUNES TAB IT IS HELD, NOT SPENT ON THE WRONG READ (1.3.0): a
        -- spoils award moves nothing a Rune row draws, so the spoils tabs are
        -- marked stale instead and each is asked the moment it is shown.
        if (state.nudgeAt ~= nil and os.clock() >= state.nudgeAt) then
            state.nudgeAt = nil;

            if (verb == 'runes') then
                state.polledAt.mine       = nil;
                state.polledAt.hall       = nil;
                state.polledAt.superauged = nil;
            else
                ask(verb);
            end
        elseif (runes.nudgeAt ~= nil and os.clock() >= runes.nudgeAt) then
            -- THE RUNE NUDGE, the same way round: the wallet is asked now if
            -- it is the tab on screen, and marked stale for later if not.
            runes.nudgeAt = nil;

            if (verb == 'runes') then
                ask('runes');
            else
                state.polledAt.runes = nil;
            end
        elseif (verb == 'runes' and runes.gearWanted and runes.target ~= nil
                and state.polledAt.runes ~= nil) then
            -- The apply panel's bag read, once the wallet has been asked: the
            -- held count is what the panel's buttons are gated on, so it goes
            -- first whenever both are owed (after an apply, after a zone).
            ask('runegear');
        else
            -- The poll, per verb, so opening the other tab asks for it at once
            -- rather than inheriting a clock that has just been stamped.
            local at = state.polledAt[verb];

            if (at == nil or (os.clock() - at) >= POLL_INTERVAL) then
                ask(verb);
            end
        end
    end

    local pushed = theme.push();

    -- 760 x 460 since 1.3.0 (700 x 430 before): the Runes list's seven
    -- columns carry an augment, a range and a fits phrase side by side, and at
    -- 700 the range column clipped its widest line. FirstUseEver, so a window
    -- whose size ImGui already saved keeps it.
    imgui.SetNextWindowSize({ 760, 460 }, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE. Nothing in ImGui stops a window being dragged to
    -- nothing, and this one carries a two-tab bar and a seven-column table.
    -- 560 IS MEASURED, NOT ROUND: the seven columns' own minimum widths plus
    -- the padding between them, at the stock font.
    imgui.SetNextWindowSizeConstraints({ 560, 300 }, { 99999, 99999 });

    -- The title is the short name alone (DWHub rail round, 2026-09-26, a
    -- player request): a collapsed or stacked window reads as what it is, the
    -- same word the hub's rail button carries. `###` keeps the ImGui ID
    -- independent of the visible text; the ID itself changed from
    -- `##dwspoils` here, which resets the window's saved position and size once.
    local visible = imgui.Begin('Spoils###dwspoils', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwspoils'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwspoils'):append(chat.message('Window closed. Everything it shows also works typed as !spoils.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwspoils_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    -- THE THROTTLE IS STAMPED BY WHAT THE PLAYER SENDS, NOT ONLY BY US. The
    -- limit it exists to respect is the CLIENT's, on chat, and that counts the
    -- player's own typing -- so an addon that stamps only from its own pump
    -- believes the channel is idle when it is not and fires into the same beat
    -- as a line the player typed. The client then drops one of them.
    if (message:sub(1, 5):lower() ~= '!dwsp') then
        lastSend = os.clock();
    end
end);

--[[
* THE AWARD NUDGE. The server's own `[Spoils] ` sentences are ordinary system
* chat and this handler LEAVES THEM ALONE -- it never blocks, never reroutes
* and never re-prints one. It reads a single fact off them: an award has just
* happened, so whatever is on screen is stale. The mode gate comes first (see
* NOTICE_MODE) and the tag must OPEN the cleaned line, or a player's yell
* would be able to drive this window's traffic.
--]]
local function plainText(raw)
    -- Two-byte tags and their argument first (Ashita's colour tags, the
    -- client's, the auto-translate brackets), then anything undrawable, then a
    -- leading clock the timestamp addon may have stamped.
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    text = text:gsub('[^\032-\126]', '');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return text;
end

ashita.events.register('text_in', 'dwspoils_text_in', function (e)
    if (e.blocked or e.injected) then
        return;
    end

    -- A closed window asks for nothing, so there is nothing to make stale.
    if (not state.open[1]) then
        return;
    end

    local raw = e.message_modified or e.message;

    if (raw == nil) then
        return;
    end

    -- THE MODE GATE FIRST. A missing mode refuses too: the live client always
    -- supplies one, so its absence is not a server line.
    local mode = e.mode_modified or e.mode;
    local low  = mode ~= nil and bit.band(mode, 0xFF) or nil;

    if (low ~= NOTICE_MODE) then
        return;
    end

    local line = (plainText(raw):gsub('^%s+', ''));

    -- THE RUNE FIND (1.3.0), under its own tag and settled here, before the
    -- spoils tag is even looked at, so no `[DWSpoils] ` line can reach the
    -- award or lost nudges below. The personal line only: it must OPEN with
    -- the prefix AND say how many you hold now, which the world line -- even
    -- spoken by a character called `You` -- never does (see NUDGE_RUNE).
    if (line:find(RUNE_TAG, 1, true) == 1) then
        if (line:find(NUDGE_RUNE, 1, true) == 1 and line:find(NUDGE_RUNE_HELD, 1, true) ~= nil
                and runes.nudgeAt == nil) then
            runes.nudgeAt = os.clock() + NUDGE_DELAY;
        end

        return;
    end

    -- THE TAG MUST OPEN THE LINE for either shape: a system sentence that
    -- merely CONTAINS the tag (one quoting something a player typed) is not a
    -- notice either.
    if (line:find(NOTICE_TAG, 1, true) ~= 1) then
        return;
    end

    local award = line:find(NUDGE_AWARD, 1, true) == 1;
    local lost  = line:find(NUDGE_LOST, 1, true) ~= nil;

    if (not award and not lost) then
        return;
    end

    -- Already pending: one nudge per settling window, not one per line. A
    -- party wiping a camp can produce two awards inside the delay.
    if (state.nudgeAt == nil) then
        state.nudgeAt = os.clock() + NUDGE_DELAY;
    end
end);

ashita.events.register('command', 'dwspoils_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, and a player
    -- who capitalises is not making a mistake.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/spoils' and first ~= '/dwspoils') then
        return;
    end

    e.blocked = true;

    -- `/spoils hall` OPENS the window on that tab rather than toggling it: a
    -- player who named a tab has already said what they want, and toggling the
    -- window shut on them because it happened to be open is the wrong answer
    -- to the only thing they said. `/spoils superauged` (1.2.0; `super` is the
    -- short spelling of the same word) opens the Super Auged tab.
    if (#args > 1) then
        local word = args[2]:lower();

        -- The bare command toggles; `open` and `close` are the idempotent
        -- doors DWHub's rail and its startup list use (2026-09-26) -- a hub
        -- that sent a bare `/spoils` to a window already up would shut it.
        -- `open` is the toggle's own opening branch, taken only when the
        -- window is shut (the lazy first ask still happens in the frame, as
        -- it does for the toggle); `close` is its closing branch.
        if (#args == 2 and word == 'open') then
            if (not state.open[1]) then
                state.open[1]  = true;
                state.reported = false;
            end

            return;
        end

        if (#args == 2 and word == 'close') then
            state.open[1] = false;

            return;
        end

        if (word == 'super') then
            word = 'superauged';
        end

        -- `/spoils runes` (1.3.0; `rune` is the same word) opens the Runes tab.
        if (word == 'rune') then
            word = 'runes';
        end

        if (word == 'hall' or word == 'mine' or word == 'superauged' or word == 'runes') then
            state.wantTab  = word;
            state.open[1]  = true;
            state.reported = false;

            return;
        end

        print(chat.header('dwspoils'):append(chat.message('/spoils opens or closes the window (/spoils open and /spoils close set it); /spoils runes opens it on your Runes; /spoils hall opens it on the Hall of Four; /spoils superauged on the Super Auged finds.')));

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwspoils_load', function ()
    print(chat.header('dwspoils'):append(chat.message('/spoils opens the Spoils window, /spoils runes opens it on your Runes, /spoils hall on the Hall of Four, /spoils superauged on the Super Auged finds. Everything it shows also works typed as !spoils.')));
end);
