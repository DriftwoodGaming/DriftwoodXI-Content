--[[
* dwchat -- a cleaner chat log (owner request 2026-09-22).
*
* "Clean up our chat windows and make them more readable with color coding and
* combining information spam into less outputs ... an option players can
* choose to enable or disable." This is that option, first slice: it works IN
* the client's own log windows rather than replacing them, so every other
* addon that reads or rewrites chat keeps working, and turning it off puts the
* log back exactly as it was.
*
* IT IS OFF UNTIL THE PLAYER SWITCHES IT ON (`/dwchat on`, or the master
* checkbox in the `/dwchat` window). With the master off every line passes
* through untouched and unblocked -- the harness asserts exactly that.
*
* IT TALKS TO NO SERVER. No `!` line, no sender, no protocol, no packet
* handler: it carries dwtheme.lua (it draws a settings window) and no
* dwecho.lua, the dwhub shape. Everything it does happens to lines the client
* was already going to draw.
*
* THE TWO LEVERS, AND WHICH ONE EACH FEATURE USES (client-owns-the-chat-window):
*
*   1. e.message_modified -- a line's text can be rewritten in flight. COLOUR
*      CODING uses only this: nothing is blocked, nothing is re-printed, the
*      line keeps its mode and so its window, and the timestamp addon's stamp
*      (it runs ahead of us) and the client's end-of-message pair stay where
*      they were.
*   2. block + re-emit -- COMBINING has to use this, because several lines
*      become one. The originals are blocked (`e.blocked = true`) and the
*      combined line is emitted LATER, from the d3d_present tick, through
*      AddChatMessage with the ORIGINAL mode id so the client files it in the
*      same window the originals would have gone to. NEVER from inside
*      text_in: Ashita.h forbids Write/AddChatMessage from inside the handler
*      (the emitted line re-enters text_in, and re-entering from inside is a
*      stack-overflow hazard).
*
* RE-ENTRY. Every line this addon emits starts with MARK, two colour resets in
* a row -- zero width, drawn as nothing. When the emitted line comes back
* through text_in (it always does; the timestamp addon stamps it there), the
* handler finds MARK, takes it out of the line and leaves everything else
* alone. That is the loop guard, and it does not depend on `e.injected` (which
* is ALSO honoured: another addon's print() is never coloured or combined).
*
* WHAT IT NEVER TOUCHES: a line somebody already blocked; a line carrying a
* DriftwoodXI wire sender (`_DW...DATA` -- every sender name in
* modules/driftwoodxi matches SENDER_PATTERN, and the harness greps them to
* prove it); a `[dw...]`-prefixed addon line; and any line whose mode is not
* one of the battle families in MODE_FAMILY. Chat people typed is on none of
* those modes. A line re-moded by dwquest's kill feed (Assist E, 222) is not
* on them either, so the feed and this addon never fight over a line when
* dwquest runs first.
*
* THE PALETTE (colour table 1, `\30\NN`; every code is a colour Ashita's own
* libs/chat.lua names, chosen to read on the stock dark log -- the dark blues
* and dark magentas, 3 / 71 / 72, are deliberately not used). The three point
* colours and the item colour are dwquest's kill-feed tints, so a line reads
* the same whichever addon coloured it.
*
*   category   code  name            what
*   dealt       78   PaleGoldenRod   you / your party / a party pet hitting something
*   taken       76   Tomato          something hitting you / your party / a party pet
*   heal        83   SpringGreen     HP or MP recovered by a party member
*   buff        82   Aqua            a party member gains an effect
*   wear        67   Grey            a party member's effect wears off
*   exp          6   Cyan            experience points, level ups
*   limit       73   Violet          limit points
*   merit       73   Violet          merit points (limit points' payout)
*   capacity     8   Coral           capacity points
*   jobpoint     8   Coral           job points (capacity points' payout)
*   item        69   Yellow          obtains an item or gil
*   skill        5   Magenta         skill-ups
*
* "Your party" is the client's own party and alliance list -- which on this
* server is usually six squad alt-trusts -- plus their pets, read from the
* memory manager and refreshed at most once a second.
*
* COMBINING (each with its own switch; all bucketed for `window` seconds,
* 1.5 by default, measured from the FIRST line of a bucket):
*
*   points  per (actor, kind): "Yukimura gains 1,872 experience points (3)".
*           Kinds: experience, limit, capacity, merit points, job points.
*           Chain lines ("EXP chain #2! ...") and level ups are NOT combined
*           -- the chain number is information -- they are only coloured.
*   skill   per (actor, skill): "Makalov's sword skill rises 0.3 points (3)".
*   melee   per (attacker, target), plain melee only (hits, critical hits,
*           misses; not ranged, not weapon skills, not spells):
*           "Makalov hits the Forest Funguar 3 times for 84 damage (crit x1, miss x1)".
*
* A bucket that caught ONE line re-emits that line's own words, so a lone hit
* reads exactly as it would have. A line arriving after its bucket's window
* has closed opens a new bucket; the old one flushes on its own. Combined
* lines arrive up to `window` seconds after the fight moved on, and after any
* line that was not combined -- that is the trade, and the window is short.
*
* Harness: tools/dwchat/harness_dwchat.py. Plan: PLANS/DWCHAT_PLAN.md.
* Behaviour, palette and settings keys: documentation/dwchat_protocol.md.
*
* Commands:
*   /dwchat           toggle the settings window
*   /dwchat on|off    the master switch
*   /dwchat status    what is on
*   /dwchat help      this list
--]]

addon.name    = 'dwchat';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.0';
addon.desc    = 'A cleaner chat log: colour-coded battle lines and combined experience, skill-up and melee spam -- off until you switch it on.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');

-- The palette above, as data. A plain table: the keys are category names and
-- a T{ }'s sugar method names would shadow them.
local PALETTE = {
    dealt    = 78,
    taken    = 76,
    heal     = 83,
    buff     = 82,
    wear     = 67,
    exp      = 6,
    limit    = 73,
    merit    = 73,
    capacity = 8,
    jobpoint = 8,
    item     = 69,
    skill    = 5,
};

-- The colour reset. `\30\1` ends any table-1 colour and is zero width.
local RESET = '\30\1';

-- Two resets in a row: invisible, and not something the client or any addon
-- in the shipped bundle writes, so a line carrying it is one of ours.
local MARK = RESET .. RESET;

-- Every DriftwoodXI wire sender is `_DW` + capitals + `DATA` (_DWDATA,
-- _DWODATA, _DWTODATA, _DWSPDATA, ...). The harness greps modules/driftwoodxi
-- for the names and holds each to this pattern.
local SENDER_PATTERN = '_DW%u*DATA';

--[[
* MODE FAMILIES: the low byte of a line's mode, mapped to the battle family
* whose patterns may classify it. An ALLOW list, because the harmful failure
* here is rewriting or swallowing somebody's chat; a mode not listed is left
* alone whatever it says. The ids are the client's (DAT-derived), read out of
* the resource tables the shipped bundle's simplelog carries
* (res/action_messages.lua `color`, and its lib/constants.lua block_modes for
* the relation-dependent damage/miss/heal families):
*
*   combat   20-35, 40-43, 104, 109, 114, 162-165, 181, 185-188 -- hits,
*            misses, damage and recovery, every actor/target relation
*   status   56, 57, 60, 61, 64, 65, 81, 191 -- gains / receives an effect,
*            wears off / is no longer
*   item    127 -- obtains an item or gil
*   skill   129 -- skill rises / reaches level
*   points  131 -- experience, limit, capacity, job points, level ups, chains
*
* Deliberately absent: 36 (defeats -- dwquest's kill feed), 121 (server
* SYSTEM_3, which every DriftwoodXI module prints on), every player-chat mode,
* and 222 (where dwquest's feed re-modes the lines it takes).
--]]
local MODE_FAMILY = { };

for _, id in ipairs({ 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
                      40, 41, 42, 43, 104, 109, 114, 162, 163, 164, 165, 181,
                      185, 186, 187, 188 }) do
    MODE_FAMILY[id] = 'combat';
end

for _, id in ipairs({ 56, 57, 60, 61, 64, 65, 81, 191 }) do
    MODE_FAMILY[id] = 'status';
end

MODE_FAMILY[127] = 'item';
MODE_FAMILY[129] = 'skill';
MODE_FAMILY[131] = 'points';

-- Seconds a combine window may be set to. The slider and the loader both
-- clamp to these, so a hand-edited settings file cannot hold a bucket open
-- for ever or flush it every frame.
local WINDOW_MIN     = 0.5;
local WINDOW_MAX     = 5.0;
local WINDOW_DEFAULT = 1.5;

-- A ceiling on open buckets (bursts need ceilings). A party of six plus pets
-- fighting one mob is a dozen; past this a line is coloured, not captured.
local MAX_BUCKETS = 64;

-- How often the party list is re-read, in seconds.
local PARTY_REFRESH = 1.0;

--[[
* Persisted, through Ashita's settings library, per character. Flat scalars
* only (the serializer drops nested tables). A SUGAR table, and the `T` is
* load-bearing: settings.lua calls defaults:copy(true) and
* settings:merge(defaults), and a plain table raises on the zone-in reload,
* which Ashita answers by unloading the addon (ashita-settings-defaults-must-be-T).
*
* `enabled` is the master switch and it DEFAULTS TO OFF. The feature switches
* default on, so the master alone turns the whole thing on.
--]]
local defaultConfig = T{
    enabled       = false,
    colors        = true,
    combinePoints = true,
    combineSkill  = true,
    combineMelee  = true,
    window        = WINDOW_DEFAULT,
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

local function save()
    pcall(settings.save);
end

pcall(settings.register, 'settings', 'dwchat_settings_update', function (s)
    if (type(s) == 'table') then
        config = s;
    end
end);

local function windowSeconds()
    local w = tonumber(config.window) or WINDOW_DEFAULT;

    if (w ~= w) then
        w = WINDOW_DEFAULT;
    end

    return math.max(WINDOW_MIN, math.min(WINDOW_MAX, w));
end

local function featureOn(name)
    return config.enabled == true and config[name] ~= false;
end

--[[
* The bytes of a line a player can read: the two-byte tags WITH their
* argument bytes first (the argument is often a printable letter -- `\30\81`
* is 'Q', `\127\49` is '1'), then line breaks as a seam space, then anything
* else that cannot be drawn, then the timestamp addon's clocks off every seam
* and off the front (chat-tags-are-two-bytes-wide). dwecho.lua's plainText,
* spelled here because this folder carries no dwecho.lua.
--]]
local function plainText(raw)
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    text = text:gsub('[\007\010\013]+', ' ');
    text = text:gsub('[^\032-\126]', '');
    text = text:gsub('%s%[%d%d?:%d%d:%d%d%]%s*', ' ');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return (text:gsub('^%s+', ''):gsub('%s+$', ''));
end

--[[
* Colour a line IN PLACE. The leading stamp (coloured `\30\NN[hh:mm:ss]\30\1`
* or plain `[hh:mm:ss]`) stays in front, untouched; the client's trailing
* end-of-message pair (`\127\49`, and any padding after it) stays at the end;
* the sentence between them is wrapped in the category's colour. A colour
* reset INSIDE the sentence (the client highlights item names, and a
* two-line message carries a second stamp at its seam) re-opens our colour
* rather than dropping the rest of the line back to the default.
--]]
local function paint(raw, code)
    local stamp = raw:match('^(\30.%[%d%d?:%d%d:%d%d%]\30.%s*)')
               or raw:match('^(%[%d%d?:%d%d:%d%d%]%s*)')
               or '';
    local rest  = raw:sub(#stamp + 1);
    local tail  = rest:match('(\127.[%s%z]*)$') or '';
    local body  = rest:sub(1, #rest - #tail);

    if (body:match('^%s*$') ~= nil) then
        return raw;
    end

    local open = '\30' .. string.char(code);

    body = body:gsub(RESET, open);

    return stamp .. open .. body .. RESET .. tail;
end

-- A whole number with thousands separators: 1872 -> "1,872".
local function commas(n)
    local digits = tostring(math.floor(tonumber(n) or 0));
    local out    = digits:reverse():gsub('(%d%d%d)', '%1,'):reverse();

    return (out:gsub('^,', ''));
end

-- "1,872" or "1872" -> 1872.
local function number(text)
    return tonumber((tostring(text or ''):gsub(',', ''))) or 0;
end

-- The subject of the LAST sentence in `prefix`: "Makalov casts Protect.
-- Yukimura" -> "Yukimura". A two-sentence message is one line here once the
-- seam is a space, and the target is the second sentence's subject.
local function lastSubject(prefix)
    local subject = prefix:match('.*[%.!]%s+(.-)$') or prefix;

    return (subject:gsub('^%s+', ''):gsub('%s+$', ''));
end

----------------------------------------------------------------------------
-- Who is "the party"
----------------------------------------------------------------------------

local party = {
    names = { },
    at    = nil,
};

local function readParty()
    local names = { };

    pcall(function ()
        local memory = AshitaCore:GetMemoryManager();
        local list   = memory:GetParty();
        local entity = memory:GetEntity();

        for i = 0, 17 do
            local active = list:GetMemberIsActive(i);

            if (active ~= nil and active ~= 0 and active ~= false) then
                local name = list:GetMemberName(i);

                if (type(name) == 'string' and name ~= '') then
                    names[name] = true;
                end

                -- A member's pet (an avatar, a wyvern, an automaton) fights
                -- for the party, so its hits are the party's hits.
                if (entity ~= nil) then
                    local index = list:GetMemberTargetIndex(i);
                    local pet   = index ~= nil and index > 0 and entity:GetPetTargetIndex(index) or 0;

                    if (pet ~= nil and pet > 0) then
                        local petName = entity:GetName(pet);

                        if (type(petName) == 'string' and petName ~= '') then
                            names[petName] = true;
                        end
                    end
                end
            end
        end
    end);

    return names;
end

local function isParty(name, now)
    if (party.at == nil or now < party.at or (now - party.at) >= PARTY_REFRESH) then
        party.names = readParty();
        party.at    = now;
    end

    return name ~= nil and party.names[name] == true;
end

-- dealt / taken / nil for an actor -> target line. A line between two
-- strangers is nobody's business here and is left alone.
local function combatSide(actor, target, now)
    -- The TARGET decides first: a party member hitting a party member (a
    -- charmed friend) is damage the party took, whoever swung.
    if (target ~= nil and isParty(target, now)) then
        return 'taken';
    end

    if (actor ~= nil and isParty(actor, now)) then
        return 'dealt';
    end

    return nil;
end

----------------------------------------------------------------------------
-- Classification
--
-- Every pattern runs on the plain, trimmed text and names the message id it
-- was written against (src/map/enums/msg_basic.h carries the wording; the
-- harness renders those comments and holds the patterns to them).
--
-- Returns nil (leave the line alone) or a verdict:
--   { cat = <palette key>, combine = nil | 'points' | 'skill' | 'melee',
--     key = <bucket key>, ... what the combiner needs }
----------------------------------------------------------------------------

local POINT_LINES = {
    -- ExperiencePointsGained 8, LimitPointsGained 371, CapacityPointsGained 718
    { pattern = '^(.-) gains ([%d,]+) experience points%.$', kind = 'exp' },
    { pattern = '^(.-) gains ([%d,]+) limit points%.$',      kind = 'limit' },
    { pattern = '^(.-) gains ([%d,]+) capacity points%.$',   kind = 'capacity' },
};

local POINT_WORDS = {
    exp      = 'experience points',
    limit    = 'limit points',
    capacity = 'capacity points',
};

local function classifyPoints(text)
    -- Coloured, never combined -- and tested FIRST, because "EXP chain #2!
    -- Yukimura gains 300 experience points." also ends in a plain gain and
    -- would otherwise be bucketed under an actor called "EXP chain #2!
    -- Yukimura": ExpChain 253 / LimitChain 372 / CapacityChain 735 (the chain
    -- number is information) and LevelUp 9.
    if (text:find('^EXP chain') ~= nil or text:find(' attains level %d+!$') ~= nil) then
        return { cat = 'exp' };
    end

    if (text:find('^Limit chain') ~= nil) then
        return { cat = 'limit' };
    end

    if (text:find('^Capacity chain') ~= nil) then
        return { cat = 'capacity' };
    end

    for _, line in ipairs(POINT_LINES) do
        local actor, amount = text:match(line.pattern);

        if (actor ~= nil) then
            return { cat = line.kind, combine = 'points', key = actor .. '\0' .. line.kind,
                     actor = actor, kind = line.kind, amount = number(amount) };
        end
    end

    -- MeritPointGained 50, JobPointGained 719: one point per line, and the
    -- running total the client printed on the last one is kept.
    local actor, total = text:match('^(.-) earns a merit point! %(Total: ([%d,]+)%)$');

    if (actor ~= nil) then
        return { cat = 'merit', combine = 'points', key = actor .. '\0merit',
                 actor = actor, kind = 'merit', amount = 1, total = number(total) };
    end

    actor, total = text:match('^(.-) earns a job point! %(Total: ([%d,]+)%)$');

    if (actor ~= nil) then
        return { cat = 'jobpoint', combine = 'points', key = actor .. '\0jobpoint',
                 actor = actor, kind = 'jobpoint', amount = 1, total = number(total) };
    end

    return nil;
end

local function classifySkill(text)
    -- SkillGain 38: "<target>'s <skill> skill rises 0.X points."
    local actor, skill, tenths = text:match("^(.-)'s (.-) skill rises 0%.(%d) points?%.$");

    if (actor ~= nil) then
        return { cat = 'skill', combine = 'skill', key = actor .. '\0' .. skill,
                 actor = actor, skill = skill, tenths = tonumber(tenths) or 0 };
    end

    -- SkillLevelUp 53, coloured only.
    if (text:find("^.-'s .- skill reaches level %d+%.$") ~= nil) then
        return { cat = 'skill' };
    end

    return nil;
end

local function classifyCombat(text, now)
    -- Ranged first, so "X's ranged attack" is never read as a melee actor.
    -- RangedAttackHit 352 / RangedAttackCrit 353 / RangedAttackMiss 354:
    -- coloured, not combined (slice 1 combines plain melee only).
    local actor, target = text:match("^(.-)'s ranged attack hits (.-) for [%d,]+ points? of damage%.$");

    if (actor == nil) then
        actor, target = text:match("^(.-)'s ranged attack scores a critical hit! (.-) takes [%d,]+ points? of damage%.$");
    end

    if (actor ~= nil) then
        local side = combatSide(actor, target, now);

        return side ~= nil and { cat = side } or nil;
    end

    actor = text:match("^(.-)'s ranged attack misses%.$");

    if (actor ~= nil) then
        return isParty(actor, now) and { cat = 'dealt' } or nil;
    end

    -- MELEE. AttackHits 1, AttackCrit 67 (two lines joined at the seam),
    -- AttackMisses 15.
    local swing = nil;
    local amount = 0;

    actor, target, amount = text:match('^(.-) hits (.-) for ([%d,]+) points? of damage%.$');

    if (actor ~= nil) then
        swing = 'hit';
    else
        actor, target, amount = text:match('^(.-) scores a critical hit! (.-) takes ([%d,]+) points? of damage%.$');

        if (actor ~= nil) then
            swing = 'crit';
        else
            actor, target = text:match('^(.-) misses (.-)%.$');

            if (actor ~= nil) then
                swing, amount = 'miss', 0;
            end
        end
    end

    -- A melee-shaped line with a sentence break in the ACTOR is not melee:
    -- "X uses Y. Z hits ..." is some ability's second half.
    if (swing ~= nil and actor:find('[%.!]') == nil) then
        local side = combatSide(actor, target, now);

        if (side == nil) then
            return nil;
        end

        -- A monster is "the Forest Funguar" mid-sentence and "The Forest
        -- Funguar" at the head of the critical hit's second line. One
        -- monster, one bucket -- and the combined sentence names it
        -- mid-sentence, so the lower-case article is the one it keeps.
        target = target:gsub('^The ', 'the ');

        return { cat = side, combine = 'melee', key = actor .. '\0' .. target,
                 actor = actor, target = target, swing = swing, amount = number(amount) };
    end

    -- Everything else that did damage: weapon skills, abilities, spells,
    -- skillchains, additional effects. "... <target> takes N points of damage."
    local before, victim = text:match('^(.-)%s*([^%.!]-) takes [%d,]+ points? of damage%.$');

    if (victim ~= nil and victim ~= '') then
        local doer = before:match('^(.-) uses ') or before:match('^(.-) casts ')
                  or before:match('^(.-) leads the casting of ');

        local side = combatSide(doer, victim, now);

        return side ~= nil and { cat = side } or nil;
    end

    -- Recovery: "<target> recovers N HP." / "... MP." (Cure, Regen, drains,
    -- Chakra, additional effects -- 7, 24, 263, 306, 318, 384 ...).
    local healed = text:match('^(.-) recovers [%d,]+ [HM]P%.$')
                or text:match('^(.-) recovers [%d,]+ hit points!$');

    if (healed ~= nil and isParty(lastSubject(healed), now)) then
        return { cat = 'heal' };
    end

    return nil;
end

local function classifyStatus(text, now)
    -- Gains: TargetGainsEffect 266 / 205, MagicGainsEffect 230,
    -- UsesAbilityGainsEffect 319, UsesSkillGainsEffect 186.
    local who = text:match('^(.-) gains the effect of .-%.$');

    if (who ~= nil and isParty(lastSubject(who), now)) then
        return { cat = 'buff' };
    end

    -- Wears off: 206 "<target>'s <status> effect wears off." and 204
    -- "<target> is no longer <status>."
    who = text:match("^(.-)'s .- effect wears off%.$") or text:match('^(.-) is no longer .-%.$');

    if (who ~= nil and isParty(lastSubject(who), now)) then
        return { cat = 'wear' };
    end

    return nil;
end

local function classifyItem(text)
    -- Obtains 565 / 582 (gil), the treasure pool's distribution line, and
    -- "You find a ... on the ...". Coloured only.
    if (text:find(' obtains ') ~= nil or text:find('^You obtain ') ~= nil
        or text:find('^You find ') ~= nil) then
        return { cat = 'item' };
    end

    return nil;
end

local function classify(text, family, now)
    if (family == 'points') then
        return classifyPoints(text);
    elseif (family == 'skill') then
        return classifySkill(text);
    elseif (family == 'combat') then
        return classifyCombat(text, now);
    elseif (family == 'status') then
        return classifyStatus(text, now);
    elseif (family == 'item') then
        return classifyItem(text);
    end

    return nil;
end

----------------------------------------------------------------------------
-- The combiner
----------------------------------------------------------------------------

-- Which switch owns which combine kind.
local COMBINE_SWITCH = {
    points = 'combinePoints',
    skill  = 'combineSkill',
    melee  = 'combineMelee',
};

local buckets = {
    open  = { },   -- key -> bucket, still collecting
    ready = { },   -- closed buckets waiting for the next tick, in close order
    count = 0,     -- #open, kept by hand (open is keyed)
    seq   = 0,     -- open order, so a flush is in the order the fight happened
};

local function describe(b)
    if (b.lines == 1) then
        return b.first;
    end

    if (b.combine == 'points') then
        if (b.kind == 'merit' or b.kind == 'jobpoint') then
            return string.format('%s earns %s %s (Total: %s)', b.actor, commas(b.amount),
                b.kind == 'merit' and 'merit points' or 'job points', commas(b.total or 0));
        end

        return string.format('%s gains %s %s (%d)', b.actor, commas(b.amount), POINT_WORDS[b.kind], b.lines);
    end

    if (b.combine == 'skill') then
        return string.format("%s's %s skill rises %d.%d points (%d)", b.actor, b.skill,
            math.floor(b.tenths / 10), b.tenths % 10, b.lines);
    end

    -- melee
    local landed = b.hits + b.crits;
    local extras = { };

    if (b.crits > 0) then
        extras[#extras + 1] = 'crit x' .. b.crits;
    end

    if (landed == 0) then
        return string.format('%s misses %s %d times', b.actor, b.target, b.misses);
    end

    if (b.misses > 0) then
        extras[#extras + 1] = 'miss x' .. b.misses;
    end

    local text = string.format('%s hits %s %s for %s damage', b.actor, b.target,
        landed == 1 and '1 time' or (landed .. ' times'), commas(b.amount));

    if (#extras > 0) then
        text = text .. ' (' .. table.concat(extras, ', ') .. ')';
    end

    return text;
end

-- The finished line, exactly as it goes to AddChatMessage.
local function render(b)
    local text = describe(b);

    if (config.colors ~= false and PALETTE[b.cat] ~= nil) then
        text = '\30' .. string.char(PALETTE[b.cat]) .. text .. RESET;
    end

    return MARK .. text;
end

local function close(key)
    local b = buckets.open[key];

    if (b ~= nil) then
        buckets.open[key] = nil;
        buckets.count     = buckets.count - 1;
        buckets.ready[#buckets.ready + 1] = b;
    end
end

-- Take a line into its bucket. Returns false when it could not be taken (the
-- ceiling), and the caller then leaves the line in the log.
local function capture(v, text, mode, now)
    local b = buckets.open[v.key];

    -- A bucket whose window has closed is finished even if the tick has not
    -- reached it yet: this line starts the next one.
    if (b ~= nil and (now < b.opened or (now - b.opened) >= windowSeconds())) then
        close(v.key);
        b = nil;
    end

    if (b == nil) then
        if (buckets.count >= MAX_BUCKETS) then
            return false;
        end

        buckets.seq = buckets.seq + 1;

        b = {
            key = v.key, combine = v.combine, cat = v.cat, mode = mode,
            opened = now, seq = buckets.seq, first = text, lines = 0,
            actor = v.actor, target = v.target, kind = v.kind, skill = v.skill,
            amount = 0, tenths = 0, total = nil, hits = 0, crits = 0, misses = 0,
        };

        buckets.open[v.key] = b;
        buckets.count       = buckets.count + 1;
    end

    b.lines = b.lines + 1;

    if (v.combine == 'points') then
        b.amount = b.amount + v.amount;
        b.total  = v.total or b.total;
    elseif (v.combine == 'skill') then
        b.tenths = b.tenths + v.tenths;
    else
        b.amount = b.amount + v.amount;

        if (v.swing == 'hit') then
            b.hits = b.hits + 1;
        elseif (v.swing == 'crit') then
            b.crits = b.crits + 1;
        else
            b.misses = b.misses + 1;
        end
    end

    return true;
end

local function emit(b)
    local line = render(b);

    pcall(function ()
        AshitaCore:GetChatManager():AddChatMessage(b.mode, false, line);
    end);
end

-- THE FLUSH. Called from d3d_present (and unload), never from text_in. A
-- bucket goes when its window has closed, when the master or its own switch
-- has been turned off since it opened (nothing is ever left blocked and
-- unsaid), or unconditionally when `all` is set.
local function flush(now, all)
    for key, b in pairs(buckets.open) do
        local switch = COMBINE_SWITCH[b.combine];

        if (all or now < b.opened or (now - b.opened) >= windowSeconds() or not featureOn(switch)) then
            close(key);
        end
    end

    if (#buckets.ready == 0) then
        return 0;
    end

    local ready = buckets.ready;

    buckets.ready = { };

    table.sort(ready, function (a, b) return a.seq < b.seq; end);

    for _, b in ipairs(ready) do
        emit(b);
    end

    return #ready;
end

----------------------------------------------------------------------------
-- The line handler
----------------------------------------------------------------------------

ashita.events.register('text_in', 'dwchat_text_in', function (e)
    local raw = e.message_modified or e.message;

    if (type(raw) ~= 'string') then
        return;
    end

    -- OUR OWN LINE, back from AddChatMessage: take the mark out and leave it
    -- be. First, and whatever the switches say -- a line emitted just before
    -- the player turned the addon off still comes back through here.
    local at = raw:find(MARK, 1, true);

    if (at ~= nil) then
        e.message_modified = raw:sub(1, at - 1) .. raw:sub(at + #MARK);

        return;
    end

    if (config.enabled ~= true or e.blocked or e.injected) then
        return;
    end

    local mode = e.mode_modified or e.mode;

    if (type(mode) ~= 'number') then
        return;
    end

    local family = MODE_FAMILY[bit.band(mode, 0xFF)];

    if (family == nil) then
        return;
    end

    local text = plainText(raw);

    if (text == '' or text:find(SENDER_PATTERN) ~= nil or text:sub(1, 3) == '[dw') then
        return;
    end

    local now     = os.clock();
    local verdict = classify(text, family, now);

    if (verdict == nil) then
        return;
    end

    local switch = verdict.combine ~= nil and COMBINE_SWITCH[verdict.combine] or nil;

    -- The bucket keeps the line's WHOLE mode, extension bits and all: the
    -- combined line goes back to the client exactly as the first original
    -- was filed, so it lands in the same window.
    if (switch ~= nil and featureOn(switch) and capture(verdict, text, mode, now)) then
        -- Said later, from the present tick, as part of its bucket.
        e.blocked = true;

        return;
    end

    if (config.colors ~= false and PALETTE[verdict.cat] ~= nil) then
        e.message_modified = paint(raw, PALETTE[verdict.cat]);
    end
end);

----------------------------------------------------------------------------
-- The settings window
----------------------------------------------------------------------------

local state = {
    open     = T{ false },
    reported = false,
    master   = T{ false },
    colors   = T{ true },
    points   = T{ true },
    skill    = T{ true },
    melee    = T{ true },
    window   = T{ WINDOW_DEFAULT },
};

local SAMPLES = {
    { 'dealt',    'Makalov hits the Forest Funguar for 28 points of damage.' },
    { 'taken',    'The Forest Funguar hits Makalov for 12 points of damage.' },
    { 'heal',     'Makalov recovers 64 HP.' },
    { 'buff',     'Makalov gains the effect of Protect.' },
    { 'wear',     "Makalov's Protect effect wears off." },
    { 'exp',      'Makalov gains 1,872 experience points (3)' },
    { 'limit',    'Makalov gains 600 limit points (2)' },
    { 'capacity', 'Makalov gains 1,029 capacity points (2)' },
    { 'item',     'Makalov obtains a bronze sword.' },
    { 'skill',    "Makalov's sword skill rises 0.3 points (3)" },
};

local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local function say(text)
    print(chat.header('dwchat'):append(chat.message(text)));
end

local function setMaster(on)
    config.enabled = on == true;
    save();
end

local function checkbox(label, buffer, key, hint)
    buffer[1] = config[key] ~= false;

    if (imgui.Checkbox(label, buffer)) then
        config[key] = buffer[1] == true;
        save();
    end

    tip(hint);
end

local function renderWindow()
    imgui.PushTextWrapPos(0.0);
    imgui.Text('Colour-codes the battle log and folds its spam into fewer lines, inside the game\'s own chat windows. Off until you switch it on; switching it off puts the log back exactly as it was.');
    imgui.PopTextWrapPos();

    imgui.Separator();

    state.master[1] = config.enabled == true;

    if (imgui.Checkbox('DWChat is on##dwchat_master', state.master)) then
        setMaster(state.master[1]);
    end

    tip('The master switch. Off: every chat line is left exactly as the game sent it.\nSame as typing /dwchat on or /dwchat off.');

    if (config.enabled ~= true) then
        imgui.SameLine();
        imgui.TextDisabled('(everything below waits for this)');
    end

    imgui.Separator();

    checkbox('Colour-code battle lines##dwchat_colors', state.colors, 'colors',
        'Your party\'s hits, damage taken, healing, buffs and what wears off, points, items\nand skill-ups each in their own colour. Nothing is moved or removed.');
    checkbox('Combine experience, limit, capacity and merit gains##dwchat_points', state.points, 'combinePoints',
        'Several gains by the same character inside the window become one line:\n"Makalov gains 1,872 experience points (3)".');
    checkbox('Combine skill-ups##dwchat_skill', state.skill, 'combineSkill',
        'Several rises of the same skill inside the window become one line:\n"Makalov\'s sword skill rises 0.3 points (3)".');
    checkbox('Combine melee rounds##dwchat_melee', state.melee, 'combineMelee',
        'Plain melee from one attacker to one target inside the window becomes one line:\n"Makalov hits the Forest Funguar 3 times for 84 damage (crit x1, miss x1)".\nRanged attacks, weapon skills and spells are only coloured.');

    state.window[1] = windowSeconds();
    imgui.SetNextItemWidth(200);

    if (imgui.SliderFloat('Combine window##dwchat_window', state.window, WINDOW_MIN, WINDOW_MAX, '%.1f s')) then
        config.window = math.max(WINDOW_MIN, math.min(WINDOW_MAX, tonumber(state.window[1]) or WINDOW_DEFAULT));
        save();
    end

    tip('How long a combined line waits for more of the same before it is printed.\nLonger folds more lines together; shorter keeps the log closer to real time.');

    imgui.Separator();

    if (imgui.Button('Preview the colours##dwchat_preview')) then
        for _, sample in ipairs(SAMPLES) do
            print(MARK .. '\30' .. string.char(PALETTE[sample[1]]) .. sample[2] .. RESET);
        end
    end

    tip('Prints one sample line per colour into the chat log, so you can see them on your own window.');

    imgui.SameLine();
    imgui.TextDisabled(string.format('%d line(s) waiting to be combined', buckets.count));
end

ashita.events.register('d3d_present', 'dwchat_present', function ()
    flush(os.clock(), false);

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 460, 330 }, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE: the widest checkbox label and its tooltip-bearing row
    -- on one line, and the slider under them.
    imgui.SetNextWindowSizeConstraints({ 420, 280 }, { 99999, 99999 });

    local visible = imgui.Begin('DriftwoodXI Chat##dwchat', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwchat'):append(chat.error('render error: ' .. tostring(err))));
                say('Window closed. /dwchat on and /dwchat off still work.');
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function status()
    if (config.enabled ~= true) then
        say('DWChat is OFF: the chat log is untouched. /dwchat on switches it on; /dwchat opens the settings.');
        return;
    end

    say(string.format('DWChat is ON: colours %s; combining points %s, skill-ups %s, melee %s; window %.1f s.',
        config.colors ~= false and 'on' or 'off',
        config.combinePoints ~= false and 'on' or 'off',
        config.combineSkill ~= false and 'on' or 'off',
        config.combineMelee ~= false and 'on' or 'off',
        windowSeconds()));
end

ashita.events.register('command', 'dwchat_command', function (e)
    local args  = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwchat') then
        return;
    end

    e.blocked = true;

    local verb = #args > 1 and args[2]:lower() or '';

    if (verb == '') then
        state.open[1] = not state.open[1];

        if (state.open[1]) then
            state.reported = false;
        end

        return;
    end

    if (verb == 'on' or verb == 'off') then
        setMaster(verb == 'on');
        status();

        return;
    end

    if (verb == 'status') then
        status();

        return;
    end

    say('/dwchat opens the settings window.');
    say('/dwchat on | off switches the whole thing; /dwchat status says what is on.');
end);

ashita.events.register('load', 'dwchat_load', function ()
    if (config.enabled == true) then
        status();
    else
        say('DWChat is loaded and OFF. /dwchat on colour-codes the battle log and combines its spam; /dwchat opens the settings.');
    end
end);

-- Nothing the addon blocked is left unsaid: whatever is still collecting goes
-- out now, in the order it happened.
ashita.events.register('unload', 'dwchat_unload', function ()
    flush(os.clock(), true);
end);
