--[[
* DriftwoodXI -- dwtracker
*
* The in-game quest and mission guide: four tabs -- Active Quests, Active
* Missions, Completed Quests, Completed Missions -- filled from your own
* journal state, synced from the server on login, zone-in and window-open.
* This is Phase 0 of DWTRACKER_PLAN.md: names and state only. Step-by-step
* guidance arrives with the phases behind it.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It evaluates no quest logic and holds no opinion about your progress. The
* server reads your real state -- the same quest status, mission line and
* completion bits the quest scripts themselves branch on -- and answers
* `!dwt sync` in compact records under the sender name _DWTDATA, which this
* addon parses and blocks before the chat log sees them. If the server does
* not assert something, this window does not show it. That split is the
* project's one non-negotiable: the tracker must never feed you a wrong
* step, and the addon's side of that promise is to never invent one.
*
* WHERE THE NAMES COME FROM. The data/ folder in this addon ships the same
* pure-data files the server loads -- one authored source, two consumers
* (plan decision T1). Quest and mission names render from those files; the
* wire carries only numeric ids. Every sync starts with a hash handshake
* over each data file, and any area whose bytes disagree with the server's
* copy is flagged in the window: names still render, but step guidance
* (when it exists) stays off for that area until the copies agree. Stale
* data says "update me"; it never says something wrong.
*
* TURN IT OFF AND NOTHING IS LOST. `!dwt sync` typed by hand shows exactly
* what the addon is being told, and your journal is still the journal.
--]]

addon.name    = 'dwtracker';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.10';
addon.desc    = 'In-game quest and mission tracker for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server
-- uses it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWTDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

-- Completed bitmaps ride as 32-id chunks (DWTRACKER_FORMAT.md): LuaJIT's
-- bit library is 32-bit on both sides of this wire.
local CHUNK_BITS = 32;

local NATION_NAMES = {
    [0] = "San d'Oria",
    [1] = 'Bastok',
    [2] = 'Windurst',
};

--[[
* FNV-1a over the normalized data file bytes, 8 hex chars.
*
* MUST MATCH modules/driftwoodxi/tracker_core.lua's fnv1a exactly: these two
* functions hashing the same file differently would read as "data out of
* date" on every client forever. \r is stripped before hashing because git
* may check the two copies out with different line endings. The multiply is
* split at 16 bits because hash * 16777619 overflows the 2^53 integer range
* of a double.
--]]
local function fnv1a(text)
    local hash = 2166136261;

    for i = 1, #text do
        hash = bit.bxor(hash, string.byte(text, i)) % 4294967296;

        local lo = hash % 65536;

        hash = (((hash - lo) / 65536) * 16777619 % 65536) * 65536 + lo * 16777619;
        hash = hash % 4294967296;
    end

    return bit.tohex(hash);
end

--[[
* The data files, loaded once at addon load from this addon's own data/
* folder. io.read + loadstring rather than require, for the same reason the
* server does it that way: the hash must cover the bytes that produced the
* table. A file that is missing or refuses to parse takes only its own area
* down -- its names degrade to '#id' and the handshake flags it -- because
* a data problem must never cost the whole window.
--]]
local DATA_DIR = string.format('%s\\addons\\dwtracker\\data\\',
    AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

local dataAreas    = {};    -- manifest order
local questsByLog  = {};    -- [log] = area table (kind 'quests')
local missionsByLog = {};   -- [log] = area table (kind 'missions')

local function readAll(path)
    local file = io.open(path, 'rb');

    if (file == nil) then
        return nil;
    end

    local raw = file:read('*a');
    file:close();

    return raw;
end

local function loadArea(stem)
    local raw = readAll(DATA_DIR .. stem .. '.lua');

    if (raw == nil) then
        return nil;
    end

    local normalized = string.gsub(raw, '\r', '');
    local chunk = loadstring(normalized, '@dwtracker/data/' .. stem);

    if (chunk == nil) then
        return nil;
    end

    local ok, data = pcall(chunk);

    if (not ok or type(data) ~= 'table' or type(data.entries) ~= 'table') then
        return nil;
    end

    data.ids = {};

    for id in pairs(data.entries) do
        table.insert(data.ids, id);
    end

    table.sort(data.ids);

    data.hash = fnv1a(normalized);

    return data;
end

local function loadData()
    local manifest = nil;
    local raw      = readAll(DATA_DIR .. 'manifest.lua');

    if (raw ~= nil) then
        local chunk = loadstring(string.gsub(raw, '\r', ''));

        if (chunk ~= nil) then
            local ok, list = pcall(chunk);

            if (ok and type(list) == 'table') then
                manifest = list;
            end
        end
    end

    if (manifest == nil) then
        print(chat.header('dwtracker'):append(chat.error('data/manifest.lua missing or unreadable -- names will not render.')));

        return;
    end

    for _, stem in ipairs(manifest) do
        local data = loadArea(stem);

        if (data == nil) then
            print(chat.header('dwtracker'):append(chat.error(string.format('data file %s.lua failed to load -- its names will not render.', stem))));
        else
            table.insert(dataAreas, data);

            -- Hidden quests share the Active Quests surface: they ride the
            -- aq| record on a log number that is not a quest log (255), so
            -- they land in questsByLog beside the real ones and render
            -- through exactly the same row code. They are deliberately NOT
            -- in the completed rebuild below -- a hidden quest leaves no
            -- completion bit to build a row from.
            if (data.kind == 'quests' or data.kind == 'hidden') then
                questsByLog[data.log] = data;
            elseif (data.kind == 'missions') then
                missionsByLog[data.log] = data;
            end
        end
    end
end

loadData();

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged,
    -- so a stale row cannot survive a refresh.
    nation    = nil,
    rank      = nil,
    activeQuests   = T{ },   -- { { log, id, step, n }, ... } in arrival order
    activeMissions = T{ },   -- [mlog] = { id, step, n }
    cq        = T{ },        -- [log]  = { [chunk] = value }
    cm        = T{ },        -- [mlog] = { [chunk] = value }

    -- Built once per completed sync rather than per frame: several hundred
    -- completed entries iterated at render speed is waste for a list that
    -- only changes when a response lands.
    completedQuests   = T{ },
    completedMissions = T{ },

    serverHashes = { },      -- [area stem] = hash (plain table: stem-keyed,
                             -- so a future stem named like a T{} sugar method
                             -- cannot resolve to a function instead of nil)
    mismatched   = T{ },     -- area stems whose data disagrees with the server
    mismatchSet  = { },      -- same stems as keys (plain table: stem-keyed)

    -- Areas whose hash AGREED at the last hello (plain table: stem-keyed).
    -- Steps render only for verified areas -- agreement is proven, never
    -- assumed. Phase 6 hardening: before this set existed, a hello response
    -- lost to packet drop left the mismatch list empty, and a sync arriving
    -- alone would render steps against data nothing had checked. The T1
    -- drift rule demands positive agreement, not absence of disagreement.
    verifiedSet  = { },

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its
    -- own cannot half-fill the UI.
    inbound   = nil,
    status    = 'Waiting for the first sync.',
    statusBad = false,
    reported  = false,       -- a render error is worth saying once, not per frame

    -- A zone-in sync is deferred a few seconds: 0x000A arrives while the
    -- client is still on the load screen, and a chat line sent there is a
    -- chat line lost.
    syncAt    = nil,
    syncSlot  = nil,
};

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. The client rate-limits outgoing chat and a !dwt command is a chat
* line; everything queues here and drains at one command per interval, with
* duplicates collapsed (dwbags' lesson, kept verbatim).
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking: a command can be lost on the way out (the client answers
* over-limit chat with "A command error occurred" before the server sees
* it), so an unanswered request is asked once more and then left alone.
*
* A PLAIN TABLE, NOT T{ }: this is keyed by verb names, and sugar-table
* method names shadowing a key cost dwbags a round once already.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

--[[
* True once this server has shown it does not speak dwtracker -- either its
* own refusal arrived ("The tracker is not loaded.", the module half missing)
* or a request went unanswered twice (no `!dwt` at all). dwbags' detect-once
* pattern, with one twist this addon needs and dwbags does not: an unknown
* `!command` on this server falls through to ordinary /say chat
* (0x0b5_chat_std.cpp:121), so every auto-sync against a dead verb is the
* player PUBLICLY SAYING "!dwt hello". While set, zone-in auto-syncs stop.
* Cleared by anything that proves the server speaks after all (a `d|`
* envelope, a `p|` ping) and by the player acting on purpose (window open,
* refresh) -- which is also how a server upgraded underneath a running
* client gets asked again, since its map restart forced a relog and the
* player's next window-open retries.
--]]
local serverSilent = false;

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

local function ask(verb)
    requested[verb] = { at = os.clock(), answered = false, tries = 1 };

    issue('!dwt ' .. verb);
end

-- Re-ask an unanswered verb once; give up loudly after that. Called every
-- frame while the window is open.
local function checkAnswers()
    -- A held send (zone-in) leaves the line queued; aging the answer clock
    -- against it would be a false timeout, and after ANSWER_TRIES a false
    -- "No answer from the server." (dwecho canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    for verb, asked in pairs(requested) do
        if (not asked.answered and (os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue('!dwt ' .. verb);
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;
                serverSilent = true;

                state.status    = 'No answer from the server. Is DriftwoodXI up to date?';
                state.statusBad = true;
            end
        end
    end
end

local function requestSync()
    ask('hello');
    ask('sync');
end

--[[
* Record parsing. Pipe-separated with a single-character (or two-character)
* type; anything unrecognised is ignored rather than being an error, so a
* server newer than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function chunkBitSet(chunks, id)
    local value = chunks[math.floor(id / CHUNK_BITS)];

    return value ~= nil and bit.band(value, bit.lshift(1, id % CHUNK_BITS)) ~= 0;
end

-- The per-sync rebuilds: completed rows in data order, and the mismatch
-- list from the last handshake.
local function rebuildCompleted()
    state.completedQuests   = T{ };
    state.completedMissions = T{ };

    for _, area in ipairs(dataAreas) do
        -- `kind` has three values, and `hidden` areas are quests: bucketed
        -- by "not quests" they would surface under Completed MISSIONS the
        -- moment hidden quests grow a completion signal.
        local rows   = area.kind == 'missions' and state.completedMissions or state.completedQuests;
        local chunks = (area.kind == 'missions' and state.cm or state.cq)[area.log];

        -- Hidden quests have no completion bit at all (the container's vars
        -- are wiped on completion and nothing else is written), so they get
        -- no completed row rather than a guessed one.
        if (area.kind == 'hidden') then
            chunks = nil;
        end

        if (chunks ~= nil) then
            for _, id in ipairs(area.ids) do
                if (chunkBitSet(chunks, id)) then
                    rows:append(T{
                        label      = area.label,
                        name       = area.entries[id].name,
                        repeatable = area.entries[id].repeatable == true,
                    });
                end
            end
        end
    end
end

local function rebuildMismatch()
    state.mismatched  = T{ };
    state.mismatchSet = { };
    state.verifiedSet = { };

    for _, area in ipairs(dataAreas) do
        if (state.serverHashes[area.area] == area.hash) then
            state.verifiedSet[area.area] = true;
        else
            state.mismatched:append(area.area);
            state.mismatchSet[area.area] = true;
        end
    end

    -- Areas the server offers that this addon has no file for at all.
    for stem in pairs(state.serverHashes) do
        local known = false;

        for _, area in ipairs(dataAreas) do
            if (area.area == stem) then
                known = true;
            end
        end

        if (not known) then
            state.mismatched:append(stem .. ' (missing here)');
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        -- An envelope is the server speaking dwtracker, whatever it carries.
        serverSilent = false;

        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwtracker.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- A d| envelope IS the answer, whatever version it announced.
            -- Returning with the hello/sync pair still outstanding let
            -- checkAnswers re-send them and then replace the one accurate
            -- diagnosis on screen ("Update dwtracker") with "No answer from
            -- the server. Is DriftwoodXI up to date?" -- about a server that
            -- had just answered twice. The same fix the `status` branch below
            -- already carries, and the one dwfame made on 2026-08-15.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright, before anything
        -- else can throw (dwbags' rule).
        if (state.inbound == 'hello') then
            state.serverHashes = { };
        elseif (state.inbound == 'sync') then
            state.nation         = nil;
            state.rank           = nil;
            state.activeQuests   = T{ };
            state.activeMissions = T{ };
            state.cq             = T{ };
            state.cm             = T{ };
        end

        answered(state.inbound);

        -- A refusal raised before a verb opened its own envelope arrives
        -- wrapped in `d|1|status` (dwt.lua's shape). That IS the answer to
        -- both outstanding verbs: left unanswered, checkAnswers re-sends the
        -- hello/sync pair in five seconds and then replaces the server's
        -- precise sentence ("The tracker is not loaded.") with a "no answer"
        -- diagnosis that is simply untrue.
        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state:
    -- the sentence saying why something was refused is worth more than the
    -- response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwtracker'):append(chat.error(state.status)));

            -- The command exists but tracker_core.lua is not loaded (dwt.lua's
            -- own refusal). Asking again cannot help until a map restart, and
            -- a map restart logs everyone out -- detect once and go quiet.
            if (string.find(line, 'The tracker is not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end
        end

        return;
    end

    -- The Phase 6 dirty ping, honoured from day one so deployment order
    -- between addon and server cannot matter: one record, outside any
    -- envelope, answered with a fresh sync. Sync ALONE, not the hello pair:
    -- data hashes cannot change inside a map session (new data means a map
    -- restart, which logs everyone out), so re-asking would double the chat
    -- lines a ping costs for nothing. The mismatch state from the session's
    -- hello stands.
    if (kind == 'p') then
        serverSilent = false;
        ask('sync');

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'sync') then
            rebuildCompleted();
            state.status    = 'Synced.';
            state.statusBad = false;
        elseif (closing == 'hello') then
            rebuildMismatch();
        end

        return;
    end

    if (kind == 'h') then
        state.serverHashes[parts[2]] = parts[3];

        return;
    end

    if (kind == 's') then
        state.nation = tonumber(parts[2]);
        state.rank   = tonumber(parts[3]);

        return;
    end

    if (kind == 'aq') then
        local log = tonumber(parts[2]) or 0;

        for _, entry in ipairs(split(parts[3], ',')) do
            local bits = split(entry, ':');

            if (#bits >= 3) then
                state.activeQuests:append(T{
                    log  = log,
                    id   = tonumber(bits[1]) or 0,
                    step = tonumber(bits[2]) or 0,
                    n    = tonumber(bits[3]) or 0,
                });
            end
        end

        return;
    end

    if (kind == 'am') then
        local log  = tonumber(parts[2]) or 0;
        local bits = split(parts[3], ':');

        if (#bits >= 3) then
            state.activeMissions[log] = T{
                id   = tonumber(bits[1]) or 0,
                step = tonumber(bits[2]) or 0,
                n    = tonumber(bits[3]) or 0,
            };
        end

        return;
    end

    -- u| -- the server evaluated this entry's authored steps and could not
    -- name a unique current one. The entry is active; nothing highlights.
    -- The honest alternative to guessing, rendered as exactly that.
    if (kind == 'u') then
        local log = tonumber(parts[3]) or 0;
        local id  = tonumber(parts[4]) or 0;

        if (parts[2] == 'q') then
            state.activeQuests:append(T{ log = log, id = id, step = 0, n = 0, unclear = true });
        elseif (parts[2] == 'm') then
            state.activeMissions[log] = T{ id = id, step = 0, n = 0, unclear = true };
        end

        return;
    end

    if (kind == 'cq' or kind == 'cm') then
        local store = kind == 'cq' and state.cq or state.cm;
        local log   = tonumber(parts[2]) or 0;

        store[log] = store[log] or T{ };

        for _, entry in ipairs(split(parts[3], ',')) do
            local bits = split(entry, ':');

            if (#bits >= 2) then
                store[log][tonumber(bits[1]) or 0] = tonumber(bits[2], 16) or 0;
            end
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWTDATA is
* ours: consumed here and blocked so the chat log never sees it -- before
* parsing, so a malformed record cannot leak as noise.
--]]
ashita.events.register('packet_in', 'dwtracker_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwtracker'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

local function beginListTable(id)
    if (imgui.BeginTable(id, 2,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthFixed, 320, 0);
        imgui.TableSetupColumn('Area', ImGuiTableColumnFlags_WidthFixed, 150, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        return true;
    end

    return false;
end

--[[
* The step pane (Phase 1). Steps render from THIS addon's data files, and
* only for areas whose hash agreed with the server at the last hello --
* stale guidance must say "update me", never something wrong. The
* highlight index comes exclusively from the server's record: done steps
* in the theme's dim, the current step in the theme's bright hint, the
* rest dim again. An `unclear` row (the server's u|) shows every step dim
* with a caution line -- active, nothing highlighted, the honest
* alternative to guessing. Colored wrapped text is push/pop rather than
* TextColored because step sentences are long enough to wrap at 560px.
--]]
local function coloredWrapped(color, text)
    imgui.PushStyleColor(ImGuiCol_Text, color);
    imgui.TextWrapped(text);
    imgui.PopStyleColor();
end

local function stepPane(area, entry, row)
    local steps = entry.steps;

    for i, step in ipairs(steps) do
        local current = (not row.unclear) and i == row.step;
        local color   = current and theme.colors.hint or theme.colors.dim;

        coloredWrapped(color, string.format('%s %d. %s', current and '>' or '  ', i, step.text));

        if (step.pos ~= nil) then
            coloredWrapped(theme.colors.dim, '        ' .. step.pos);
        end
    end

    if (row.unclear) then
        coloredWrapped(theme.colors.warn,
            'The tracker cannot tell which step you are on right now, so none is highlighted.');
    end
end

--[[
* One active row: a tree node when the entry has renderable steps, a plain
* line when it does not. The summary after the name is server-asserted
* state, dimmed so the name stays the loudest thing on the row.
--]]
local function activeRow(kind, area, log, id, row, label)
    local entry = area ~= nil and area.entries[id] or nil;
    local name  = entry ~= nil and entry.name
        or string.format('%s #%d', kind == 'q' and 'quest' or 'mission', id);

    -- Steps render only for areas whose hash AGREED at this session's hello
    -- (verifiedSet), never merely for the absence of a recorded mismatch --
    -- a sync that outran a dropped hello response must render plain rows,
    -- not unverified guidance. The '(update dwtracker for steps)' label is
    -- reserved for a PROVEN disagreement, where updating is really the fix.
    local unverified = area == nil or state.verifiedSet[area.area] ~= true;
    local mismatched = area ~= nil and state.mismatchSet[area.area] == true;
    local hasSteps   = entry ~= nil and type(entry.steps) == 'table' and #entry.steps > 0;

    -- The belt to the handshake's suspenders: a step count that disagrees
    -- with the server's is data drift the hash should have caught -- treat
    -- it exactly like a mismatch rather than highlight into the wrong list.
    if (hasSteps and not row.unclear and row.n ~= #entry.steps) then
        unverified = true;
        mismatched = true;
    end

    local summary;

    if (row.unclear) then
        summary = '(unclear)';
    elseif (hasSteps and row.step > 0) then
        summary = string.format('(step %d of %d)', row.step, row.n);
    else
        summary = '(no guide yet)';
    end

    if (hasSteps and not unverified) then
        local open = imgui.TreeNodeEx(string.format('##dwt_%s_%d_%d', kind, log, id),
            kind == 'm' and ImGuiTreeNodeFlags_DefaultOpen or 0);

        imgui.SameLine();
        imgui.Text(name);
        imgui.SameLine();

        if (row.unclear) then
            imgui.TextColored(theme.colors.warn, summary);
        else
            imgui.TextColored(theme.colors.hint, summary);
        end

        if (label ~= nil) then
            imgui.SameLine();
            imgui.TextDisabled('-- ' .. label);
        end

        if (open) then
            stepPane(area, entry, row);
            imgui.TreePop();
        end
    else
        imgui.Bullet();
        imgui.SameLine();
        imgui.Text(name);
        imgui.SameLine();
        imgui.TextDisabled(mismatched and hasSteps and '(update dwtracker for steps)' or summary);

        if (label ~= nil) then
            imgui.SameLine();
            imgui.TextDisabled('-- ' .. label);
        end
    end
end

local function activeQuestsTab()
    if (#state.activeQuests == 0) then
        imgui.TextDisabled('No active quests. Accept one and it appears here at the next sync.');

        return;
    end

    if (imgui.BeginChild('##dwtracker_aq', { -1, -1 }, ImGuiChildFlags_None)) then
        for _, row in ipairs(state.activeQuests) do
            local area = questsByLog[row.log];

            activeRow('q', area, row.log, row.id, row, area ~= nil and area.label or string.format('log %d', row.log));
        end
    end

    imgui.EndChild();
end

local function activeMissionsTab()
    if (state.nation ~= nil and state.rank ~= nil) then
        imgui.Text(string.format('%s -- Rank %d', NATION_NAMES[state.nation] or 'Adventurer', state.rank));
        imgui.Separator();
    end

    -- Nation line first, Zilart after: the order a player thinks in.
    local order = T{ };

    if (state.nation ~= nil and state.activeMissions[state.nation] ~= nil) then
        order:append(state.nation);
    end

    for log, _ in pairs(state.activeMissions) do
        if (log ~= state.nation) then
            order:append(log);
        end
    end

    if (#order == 0) then
        imgui.TextDisabled('No mission underway.');

        return;
    end

    if (imgui.BeginChild('##dwtracker_am', { -1, -1 }, ImGuiChildFlags_None)) then
        for _, log in ipairs(order) do
            local row  = state.activeMissions[log];
            local area = missionsByLog[log];

            activeRow('m', area, log, row.id, row, area ~= nil and area.label or string.format('log %d', log));
        end
    end

    imgui.EndChild();
end

local function completedTab(rows, id, emptyText)
    imgui.TextDisabled(string.format('%d completed.', #rows));

    if (#rows == 0) then
        imgui.TextDisabled(emptyText);

        return;
    end

    if (beginListTable(id)) then
        for _, row in ipairs(rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row.name);

            -- T7's repeat marker: the quest can be done again (and, once
            -- re-flagged or re-run, shows in Active too).
            if (row.repeatable) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.badge, '(repeatable)');
            end

            imgui.TableNextColumn();
            imgui.TextDisabled(row.label);
        end

        imgui.EndTable();
    end
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        forget();
        requestSync();
    end

    imgui.SameLine();

    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    else
        imgui.TextDisabled('');
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    -- THE MISMATCH BANNER. Names below still render from this addon's own
    -- files; what a mismatched area can never do is render steps -- stale
    -- guidance must say "update me", not something wrong. Phase 0 has no
    -- steps anywhere, but the contract starts now.
    if (#state.mismatched > 0) then
        imgui.TextColored(theme.colors.warn,
            string.format('Data out of date for: %s.', table.concat(state.mismatched, ', ')));
        imgui.TextColored(theme.colors.warn,
            'Names may be stale; step guidance stays off for those areas until dwtracker is updated.');
    end

    imgui.Separator();

    if (imgui.BeginTabBar('##dwtracker_tabs')) then
        if (imgui.BeginTabItem('Active Quests')) then
            activeQuestsTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Active Missions')) then
            activeMissionsTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Completed Quests')) then
            completedTab(state.completedQuests, '##dwtracker_cq', 'Nothing completed yet. Plenty of time.');
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Completed Missions')) then
            completedTab(state.completedMissions, '##dwtracker_cm', 'Nothing completed yet.');
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape, and its
* reasoning, kept verbatim).
--]]
ashita.events.register('d3d_present', 'dwtracker_present', function ()
    -- Before the visibility check: a sync requested by a zone-in still has
    -- to reach the server with the window shut.
    if (state.syncAt ~= nil and os.clock() >= state.syncAt) then
        -- The deferral exists because 0x000A arrives on the load screen --
        -- but a fixed delay only guesses at how long that screen stays up,
        -- and a typed line handed to a client that is still zoning is not
        -- delayed, it is LOST, with "A command error occurred." in the log
        -- as its residue (the per-zone error players were seeing). The
        -- client's own zoning flag is the fact; wait it out.
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (player ~= nil and player:GetIsZoning() ~= 0) then
            state.syncAt   = os.clock() + 1.0;
            state.syncSlot = nil;
        elseif (state.syncSlot == nil) then
            -- Zoning done. Every sibling clears its zoning flag on the SAME
            -- frame, so hold this addon's stagger slot before firing or the
            -- zone-in syncs collide at the client's chat throttle and all but
            -- one come back "A command error occurred." (dwecho.lua's ZONE_ORDER
            -- is the shared slot order; 2026-08-14).
            state.syncSlot = os.clock() + echo.zoneSlot('dwtracker') * echo.SEND_INTERVAL;
            state.syncAt   = state.syncSlot;
        else
            state.syncAt   = nil;
            state.syncSlot = nil;

            forget();
            requestSync();
        end
    end

    -- Answer tracking runs whether or not the window is open. It used to
    -- live inside the window render, which meant a closed window could
    -- never notice the server had gone silent -- and it is exactly the
    -- window-closed zone-in auto-syncs that must stop when it has
    -- (see serverSilent: on this server an unknown !command is /say chat).
    checkAnswers();

    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 560, 420 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Tracker##dwtracker', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwtracker'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwtracker'):append(chat.message('Window closed. `!dwt sync` typed by hand shows the same data.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs: a window showing the journal
* as it stood two zones ago is the quiet kind of wrong this project exists
* to rule out, and a sync costs one chat line.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported`
        -- only exists to stop one bad frame printing sixty lines a second.
        -- And a fresh start for the silent-server detection: opening the
        -- window is the deliberate act that earns one more try.
        state.reported = false;
        serverSilent   = false;

        forget();
        requestSync();
    end
end

ashita.events.register('command', 'dwtracker_command', function (e)
    local args = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwtracker' and first ~= '/tracker' and first ~= '/dwt') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        serverSilent = false;

        forget();
        requestSync();

        return;
    end

    toggleWindow();
end);

--[[
* Sync on login and zone-in (0x000A serves both). Everything server-derived
* resets first: a login may be a different character, and stale journal
* rows surviving into a new character's window is exactly the kind of
* quiet wrongness this project exists to rule out.
--]]
ashita.events.register('packet_in', 'dwtracker_zonein', function (e)
    if (e.id == 0x000A) then
        state.nation         = nil;
        state.rank           = nil;
        state.activeQuests   = T{ };
        state.activeMissions = T{ };
        state.cq             = T{ };
        state.cm             = T{ };
        state.completedQuests   = T{ };
        state.completedMissions = T{ };
        state.serverHashes = { };
        state.mismatched   = T{ };
        state.mismatchSet  = { };
        state.verifiedSet  = { };
        state.status       = 'Syncing...';
        state.statusBad    = false;

        forget();

        -- No auto-sync against a server that has shown it does not speak
        -- dwtracker: an unknown !command falls through to /say here, so each
        -- retry would be the player chatting "!dwt hello" at whoever is
        -- nearby. Opening the window retries deliberately.
        if (not serverSilent) then
            state.syncAt = os.clock() + 4.0;
        else
            state.status = 'Tracker paused (no answer from the server). Open the window to retry.';
        end
    end
end);

--[[
* Watch what the player sends.
*
* Bare `!dwt` (and its ui/window/gui spellings) is intercepted and toggles
* this window instead of going to the server -- dwsquad's pattern, and the
* reason it exists: the server verb is the name players learn from the news
* post and from each other, so it has to be a door and not a dead end. The
* line is blocked and never leaves the client. `!dwt sync` and `!dwt hello`
* typed by hand still pass through untouched -- that is the escape hatch
* this addon's header promises, and it must keep working.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped.
* Stamping the player's own line as a send makes the next queued command
* wait its interval instead of racing it (dwbags' lesson, kept verbatim).
--]]
ashita.events.register('packet_out', 'dwtracker_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!dwt' or lower == '!dwt ui' or lower == '!dwt window' or lower == '!dwt gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwt') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwtracker_load', function ()
    print(chat.header('dwtracker'):append(chat.message('/dwtracker, /tracker, /dwt or !dwt opens the quest & mission tracker.')));
end);
