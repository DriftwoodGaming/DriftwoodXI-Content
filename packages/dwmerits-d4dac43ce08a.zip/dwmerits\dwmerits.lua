--[[
* DriftwoodXI -- dwmerits
*
* The merit sheet with this SERVER's numbers: every category's true Combo
* Total (Weapon Skills 70, both job groups 20 per job, Attributes 210,
* Others 20, HP/MP 75), every entry's real ceiling and next cost, and
* raise/lower buttons that reach past the stock menu's caps.
*
* WHY THIS WINDOW EXISTS: the retail client bakes its own category maximums
* into the built-in merit menu and refuses clicks past them -- the server
* stopped enforcing those caps in the 2026-08-30/09-01 expansion, but the
* menu never got the memo and cannot be patched. The menu's counts are
* always right; its maximums and its refusals are retail's, not ours. This
* window is the one that tells the truth and clicks the whole way up.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no merit arithmetic and no category table: names, ceilings,
* costs, totals and maximums all ride the wire (`!dwi`, sender _DWIDATA,
* documentation/dwi_protocol.md), and a raise clicked here reaches exactly
* the xi.dwMerits.edit that `!merits raise hp` typed reaches -- the Mog
* House gate, the ceilings and the wallet are the server's to enforce, and
* this window's greyed buttons are a courtesy, not the authority.
*
* LAZY BY DESIGN: sync fetches the wallet and the six shared category
* summaries; a category's rows arrive when you look at it. The whole
* 296-entry sheet never rides one response (bursts need ceilings).
*
* ONE EDIT IN FLIGHT: raise/lower are writes, so they are never collapsed,
* never retried, and never stacked -- the buttons disarm until the server's
* r| answer lands (or five seconds pass). A lost click costs a click; a
* replayed click would cost merit points.
*
* SINCE 1.1.0 (2026-09-01): a JOB POINTS tab (any job's job points, capacity
* points, every type with its next cost, the gift ladder, and raise buttons
* through the 0x0bf chain -- Mog House, same as the menu) and an ASCENSION
* tab (the limit point bank -- every limit point you ever earned, banked
* beside the retail pool -- convertible to merits at 10,000 each or spent on
* mastery tiers: permanent power that reaches you and every squad member
* you call). Both additive on the same wire, no protocol bump.
*
* TURN IT OFF AND NOTHING IS LOST. `!merits` typed in chat says the same
* numbers in prose, and `!dwi sync` shows exactly what this window is told.
--]]

addon.name    = 'dwmerits';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.2';
addon.desc    = 'Merit sheet for DriftwoodXI: true totals, raise/lower past the stock menu, job points, and Ascension.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

local DATA_SENDER = '_DWIDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

--[[
* The selector: which slice of the sheet the window is looking at. The six
* shared tokens and the job list are the protocol's own vocabulary
* (documentation/dwi_protocol.md); labels, totals, ceilings and rows all
* still come off the wire, so this is navigation, not data --
* tools/dwmerits/harness_dwmerits.py holds these tokens equal to the
* server's own category table so the two can never drift.
--]]
local SHARED = T{
    { token = 'hpmp',       label = 'HP / MP' },
    { token = 'attributes', label = 'Attributes' },
    { token = 'combat',     label = 'Combat Skills' },
    { token = 'magic',      label = 'Magic Skills' },
    { token = 'others',     label = 'Others' },
    { token = 'ws',         label = 'Weapon Skills' },
};

local JOBS = T{
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK', 'BST', 'BRD',
    'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU', 'COR', 'PUP', 'DNC', 'SCH',
    'GEO', 'RUN',
};

-- The combo's flat item list: the six shared slices, then one entry per
-- job (both of its groups arrive in one `job` response).
local PICKS = T{ };

for _, entry in ipairs(SHARED) do
    PICKS:append({ kind = 'cat', token = entry.token, label = entry.label });
end

for _, job in ipairs(JOBS) do
    PICKS:append({ kind = 'job', token = job:lower(), label = job .. ' Job Groups' });
end

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged,
    -- so a stale row cannot survive a refresh (dwtracker's rule).
    charid    = nil,
    wallet    = nil,          -- { points, ceiling, mog }

    -- cats[cat]   = { total, max, token, label }   (from c| records)
    -- rows[token] = ordered { cat-block, ... } for the selected slice; each
    --               block = { cat, entries = { {id,count,ceiling,next,value,name}, ... } }
    cats      = T{ },
    rows      = T{ },

    pick      = T{ 1 },       -- combo index into PICKS
    jobPick   = T{ 1 },       -- combo index into JOBS, for the Job Points tab

    -- Job Points: the fetched job's header, its types and its gift ladder,
    -- replaced wholesale per response (j|/k|/g|).
    jp        = T{ token = nil, header = nil, types = T{ }, gifts = T{ } },

    -- Ascension: the bank (b|) and the mastery sheet (y|), replaced
    -- wholesale per response.
    bank      = nil,
    sheet     = T{ },

    -- Response assembly: records are accepted only between d| and z|, and
    -- cat/job responses build here before replacing the cache, so a
    -- half-arrived slice can never render (dwbags' rule).
    inbound   = nil,
    staging   = nil,
    stageCat  = nil,

    -- The one write in flight: { id, verb, at }. Buttons disarm while set.
    pending   = nil,

    status    = 'Waiting for the first sync.',
    statusBad = false,
    reported  = false,
};

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. Reads are deduplicated; WRITES ARE NOT QUEUED HERE AT ALL -- they go
* through sendEdit below, one in flight, never collapsed, never retried.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- Held shut while zoning: a line handed to a zoning client is not
    -- delayed, it is LOST, with "A command error occurred." as its residue
    -- (dwecho.lua's canSend; 2026-08-15).
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking for READS: an unanswered request is asked once more and
* then left alone. A PLAIN TABLE, NOT T{ } (dwbags' shadowed-key lesson).
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

-- True once this server has shown it does not speak dwmerits -- an unknown
-- !command falls through to /say, so retrying against a dead verb is the
-- player publicly chatting "!dwi sync". Cleared by any d| envelope and by
-- the player acting on purpose (window open, refresh).
local serverSilent = false;

local function forget()
    requested = {};
end

-- Requests are keyed by the whole line ('cat hpmp', 'job war', 'jp war');
-- the envelope names only the verb ('d|1|cat', 'd|1|jp'). Match on the first
-- word, or every argument-carrying read goes unanswered by name, is re-asked
-- once and then reports "No answer from the server" over a server that
-- answered twice (1.1.2, the 2026-09-01 reports).
local function answered(verb)
    for key, asked in pairs(requested) do
        if (type(asked) == 'table' and (key == verb or key:match('^(%S+)') == verb)) then
            asked.answered = true;
        end
    end
end

local function ask(verb)
    requested[verb] = { at = os.clock(), answered = false, tries = 1 };

    issue('!dwi ' .. verb);
end

local function checkAnswers()
    if (not echo.canSend()) then
        return;
    end

    for verb, asked in pairs(requested) do
        if (not asked.answered and (os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue('!dwi ' .. verb);
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;
                serverSilent = true;

                state.status    = 'No answer from the server. Is DriftwoodXI up to date?';
                state.statusBad = true;
            end
        end
    end

    -- The write's own clock: no retry, just the buttons back. The next
    -- sync shows whatever really happened.
    if (state.pending ~= nil and (os.clock() - state.pending.at) >= ANSWER_TIMEOUT) then
        state.pending   = nil;
        state.status    = 'No answer to that edit -- nothing retried. Refresh to see where things stand.';
        state.statusBad = true;
    end
end

local function currentPick()
    return PICKS[state.pick[1]] or PICKS[1];
end

local function fetchVerbFor(pick)
    if (pick.kind == 'job') then
        return 'job ' .. pick.token;
    end

    return 'cat ' .. pick.token;
end

local function requestSync()
    ask('sync');
end

local function requestPick()
    local pick = currentPick();

    -- Remember WHICH slice was asked for: the response commits under this
    -- token, so a combo change while a fetch is in flight can never file
    -- one slice's rows under another's name.
    state.fetching = pick.token;

    ask(fetchVerbFor(pick));
end

--[[
* The one write path. Never queued with the reads, never deduplicated,
* never retried: one edit in flight, buttons disarmed until its r| lands.
--]]
local function sendEdit(verb, meritId, count)
    if (state.pending ~= nil) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    state.pending = { id = meritId, verb = verb, at = os.clock() };
    lastSend      = os.clock();

    echo.send(string.format('!dwi %s %d %d', verb, meritId, count));
end

-- The Ascension writes: `convert <n>` and `ascend <key>` -- the same one-in-
-- flight discipline, a different argument shape.
local function sendBankAction(line)
    if (state.pending ~= nil) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    state.pending = { id = 0, verb = 'bank', at = os.clock() };
    lastSend      = os.clock();

    echo.send('!dwi ' .. line);
end

local function requestJob()
    local job = JOBS[state.jobPick[1]] or JOBS[1];

    state.jpFetching = job:lower();

    ask('jp ' .. job:lower());
end

local function requestMastery()
    ask('mastery');
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

-- A u| row into a plain entry table.
local function parseEntry(parts)
    return {
        id      = tonumber(parts[2]) or 0,
        count   = tonumber(parts[3]) or 0,
        ceiling = tonumber(parts[4]) or 0,
        next    = tonumber(parts[5]) or 0,
        value   = tonumber(parts[6]) or 0,
        name    = parts[7] or '?',
    };
end

-- An edit's refreshed u| replaces its row wherever the cache holds it.
local function replaceRow(entry)
    for _, blocks in pairs(state.rows) do
        for _, block in ipairs(blocks) do
            for i, row in ipairs(block.entries) do
                if (row.id == entry.id) then
                    block.entries[i] = entry;

                    return;
                end
            end
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        serverSilent = false;

        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwmerits.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- The envelope IS the answer, whatever version it announced
            -- (dwfame's re-send hazard, closed the same way).
            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            state.pending = nil;

            return;
        end

        state.inbound = parts[3];

        if (state.inbound == 'cat' or state.inbound == 'job') then
            state.staging  = T{ };
            state.stageCat = nil;
        end

        if (state.inbound == 'jp' or state.inbound == 'jpraise') then
            state.jpStaging = T{ header = nil, types = T{ }, gifts = T{ } };
        end

        if (state.inbound == 'mastery' or state.inbound == 'ascend') then
            state.sheetStaging = T{ };
        end

        answered(state.inbound);

        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            state.pending = nil;
        end

        return;
    end

    -- Notes and refusals are accepted whatever the envelope state: the
    -- sentence saying why something was refused outranks the response it
    -- happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwmerits'):append(chat.error(state.status)));

            if (string.find(line, 'not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'cat' or closing == 'job') then
            -- Commit the staged slice wholesale under the token that was
            -- ASKED FOR (state.fetching), so a refresh can never leave
            -- yesterday's rows under today's bars and a combo change mid-
            -- flight can never file one slice under another's name.
            if (state.staging ~= nil and #state.staging > 0 and state.fetching ~= nil) then
                state.rows[state.fetching] = state.staging;
            end

            state.staging  = nil;
            state.stageCat = nil;
            state.status    = 'Synced.';
            state.statusBad = false;
        elseif (closing == 'sync') then
            state.status    = 'Synced.';
            state.statusBad = false;
        elseif (closing == 'jp' or closing == 'jpraise') then
            if (state.jpStaging ~= nil and state.jpStaging.header ~= nil) then
                state.jp = T{
                    token  = state.jpStaging.header.token,
                    header = state.jpStaging.header,
                    types  = state.jpStaging.types,
                    gifts  = state.jpStaging.gifts,
                };
            end

            state.jpStaging = nil;

            if (closing == 'jp') then
                state.status    = 'Synced.';
                state.statusBad = false;
            end
        elseif (closing == 'mastery' or closing == 'ascend') then
            if (state.sheetStaging ~= nil and #state.sheetStaging > 0) then
                state.sheet = state.sheetStaging;
            end

            state.sheetStaging = nil;

            if (closing == 'mastery') then
                state.status    = 'Synced.';
                state.statusBad = false;
            end
        end

        return;
    end

    -- The bank (b|) and a mastery line (y|): Ascension, additive.
    if (kind == 'b') then
        state.bank = {
            banked   = tonumber(parts[2]) or 0,
            lifetime = tonumber(parts[3]) or 0,
            spent    = tonumber(parts[4]) or 0,
            perMerit = tonumber(parts[5]) or 10000,
        };

        return;
    end

    if (kind == 'y') then
        if (state.sheetStaging ~= nil) then
            state.sheetStaging:append({
                id    = tonumber(parts[2]) or 0,
                key   = parts[3] or '',
                tier  = tonumber(parts[4]) or 0,
                max   = tonumber(parts[5]) or 0,
                price = tonumber(parts[6]) or 0,
                name  = parts[7] or '?',
                desc  = parts[8] or '',
            });
        end

        return;
    end

    -- A bank action's outcome, in words (convert / ascend).
    if (kind == 'a') then
        state.pending   = nil;
        state.status    = parts[3] or '';
        state.statusBad = (tonumber(parts[2]) or 0) == 0;

        return;
    end

    -- Job points: a job header (j|), a type (k|), a gift rung (g|).
    if (kind == 'j') then
        if (state.jpStaging ~= nil) then
            state.jpStaging.header = {
                token = parts[2] or '',
                jp    = tonumber(parts[3]) or 0,
                cp    = tonumber(parts[4]) or 0,
                spent = tonumber(parts[5]) or 0,
                label = parts[6] or '',
            };
        end

        return;
    end

    if (kind == 'k') then
        if (state.jpStaging ~= nil) then
            state.jpStaging.types:append({
                id    = tonumber(parts[2]) or 0,
                level = tonumber(parts[3]) or 0,
                max   = tonumber(parts[4]) or 20,
                next  = tonumber(parts[5]) or 0,
                name  = parts[6] or '?',
            });
        end

        return;
    end

    if (kind == 'g') then
        if (state.jpStaging ~= nil) then
            local mod = tonumber(parts[3]) or 0;

            state.jpStaging.gifts:append({
                jp    = tonumber(parts[2]) or 0,
                mod   = mod,
                value = tonumber(parts[4]) or 0,
                -- The gift's own name rides the wire since 1.1.1 (the
                -- job_point_gifts desc column); an older server sends four
                -- fields and the rung reads "mod N" as it did before.
                name  = (parts[5] ~= nil and parts[5] ~= '') and parts[5] or string.format('mod %d', mod),
            });
        end

        return;
    end

    if (kind == 'w') then
        local charid = tonumber(parts[5]);

        -- A different character answering wipes the whole cache: an alt's
        -- merit sheet surviving into this one's window is exactly the quiet
        -- wrongness this project exists to rule out.
        if (state.charid ~= nil and charid ~= nil and charid ~= state.charid) then
            state.cats = T{ };
            state.rows = T{ };
        end

        state.charid = charid;
        state.wallet = {
            points  = tonumber(parts[2]) or 0,
            ceiling = tonumber(parts[3]) or 0,
            mog     = (tonumber(parts[4]) or 0) == 1,
        };

        return;
    end

    if (kind == 'c') then
        local cat = tonumber(parts[2]);

        if (cat == nil) then
            return;
        end

        state.cats[cat] = {
            total = tonumber(parts[3]) or 0,
            max   = tonumber(parts[4]) or 0,
            token = parts[5] or '',
            label = parts[6] or '',
        };

        if (state.staging ~= nil) then
            state.staging:append({ cat = cat, entries = T{ } });
            state.stageCat = cat;
        end

        return;
    end

    if (kind == 'u') then
        local entry = parseEntry(parts);

        if (state.staging ~= nil and state.stageCat ~= nil) then
            state.staging[#state.staging].entries:append(entry);
        else
            -- An edit's refresh: replace the row in place, wherever the
            -- cache holds it.
            replaceRow(entry);
        end

        return;
    end

    if (kind == 'r') then
        local done = tonumber(parts[2]) or 0;
        local why  = parts[4];

        state.pending = nil;

        if (why ~= nil and why ~= '') then
            state.status    = (done > 0 and 'Stopped early: ' or 'Refused: ') .. why;
            state.statusBad = (done == 0);
        else
            state.status    = string.format('%d point(s) %s.', done, state.inbound == 'lower' and 'refunded' or 'assigned');
            state.statusBad = false;
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWIDATA is
* ours: consumed and blocked before parsing, so a malformed record cannot
* leak as chat noise.
--]]
ashita.events.register('packet_in', 'dwmerits_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwmerits'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

local function walletLine()
    if (state.wallet == nil) then
        return 'Merit points: ?';
    end

    return string.format('Merit points: %d / %d', state.wallet.points, state.wallet.ceiling);
end

local function canEdit()
    return state.wallet ~= nil and state.wallet.mog and state.pending == nil;
end

-- One category's header bar: label, total against the TRUE maximum.
local function categoryBar(cat)
    local info = state.cats[cat];

    if (info == nil) then
        return;
    end

    local fraction = info.max > 0 and (info.total / info.max) or 0;

    if (fraction > 1) then fraction = 1; end

    imgui.ProgressBar(fraction, { -1, 16 }, string.format('%s  --  %d / %d', info.label, info.total, info.max));
end

-- The +/- buttons for one row. Greys itself on every fact already on hand;
-- the server re-checks all of them anyway.
local function editButtons(row, cat)
    local info      = state.cats[cat];
    local editable  = canEdit();
    local canRaise  = editable and row.count < row.ceiling and row.next > 0
        and state.wallet.points >= row.next
        and (info == nil or info.total < info.max);
    local canLower  = editable and row.count > 0;

    if (not canLower) then imgui.BeginDisabled(); end

    if (imgui.Button(string.format('-##dwmerits_l_%d', row.id), { 22, 0 })) then
        sendEdit('lower', row.id, 1);
    end

    if (not canLower) then imgui.EndDisabled(); end

    imgui.SameLine();

    if (not canRaise) then imgui.BeginDisabled(); end

    if (imgui.Button(string.format('+##dwmerits_r_%d', row.id), { 22, 0 })) then
        sendEdit('raise', row.id, 1);
    end

    imgui.SameLine();

    if (imgui.Button(string.format('+5##dwmerits_r5_%d', row.id), { 30, 0 })) then
        sendEdit('raise', row.id, 5);
    end

    if (not canRaise) then imgui.EndDisabled(); end
end

local function entryRow(row, cat)
    imgui.TableNextRow();
    imgui.TableNextColumn();
    imgui.Text(row.name);

    if (imgui.IsItemHovered() and row.value > 0) then
        imgui.SetTooltip(string.format('+%d per upgrade (merit id %d)', row.value, row.id));
    end

    imgui.TableNextColumn();

    if (row.count >= row.ceiling) then
        imgui.TextColored(theme.colors.ok, string.format('%d / %d', row.count, row.ceiling));
    else
        imgui.Text(string.format('%d / %d', row.count, row.ceiling));
    end

    imgui.TableNextColumn();

    if (row.next > 0) then
        imgui.Text(string.format('%d', row.next));
    else
        imgui.TextDisabled('--');
    end

    imgui.TableNextColumn();
    editButtons(row, cat);
end

local function sheetTable(pick)
    local blocks = state.rows[pick.token];

    if (blocks == nil or #blocks == 0) then
        imgui.TextDisabled('Fetching this category from the server...');

        return;
    end

    for b, block in ipairs(blocks) do
        categoryBar(block.cat);

        if (imgui.BeginTable(string.format('##dwmerits_t_%d_%d', block.cat, b), 4,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
            imgui.TableSetupColumn('Merit', ImGuiTableColumnFlags_WidthStretch, 0, 0);
            imgui.TableSetupColumn('Taken', ImGuiTableColumnFlags_WidthFixed, 70, 0);
            imgui.TableSetupColumn('Next costs', ImGuiTableColumnFlags_WidthFixed, 76, 0);
            imgui.TableSetupColumn('Adjust', ImGuiTableColumnFlags_WidthFixed, 96, 0);
            imgui.TableHeadersRow();

            for _, row in ipairs(block.entries) do
                entryRow(row, block.cat);
            end

            imgui.EndTable();
        end

        imgui.Spacing();
    end
end

-- The six shared categories as one glance: bars only, from the sync.
local function overviewBars()
    for _, entry in ipairs(SHARED) do
        for cat, info in pairs(state.cats) do
            if (info.token == entry.token) then
                categoryBar(cat);
            end
        end
    end
end

--[[
* Job Points tab: pick a job, read its points, raise a type. The raise button
* greys on every fact on hand (ceiling, points to spend, Mog House, one edit in
* flight); the server re-checks all of them through the 0x0bf chain.
--]]
local function jobPointsTab()
    imgui.SetNextItemWidth(120);

    local current = JOBS[state.jobPick[1]] or JOBS[1];

    if (imgui.BeginCombo('##dwmerits_jobpick', current)) then
        for i, job in ipairs(JOBS) do
            if (imgui.Selectable(string.format('%s##dwmerits_jobpick_%d', job, i), state.jobPick[1] == i)) then
                if (state.jobPick[1] ~= i) then
                    state.jobPick[1] = i;

                    requestJob();
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.SameLine();
    imgui.TextDisabled('Any job -- your squad members are paid your job points for THEIR job.');

    imgui.Separator();

    if (state.jp.header == nil or state.jp.token ~= current:lower()) then
        imgui.TextDisabled('Fetching this job from the server...');

        if (state.jp.token ~= current:lower() and state.jpFetching ~= current:lower()) then
            requestJob();
        end

        return;
    end

    local header = state.jp.header;

    imgui.Text(string.format('%s: %d job points to spend, %d / 30000 capacity points, %d spent in all.',
        header.label, header.jp, header.cp, header.spent));

    if (not imgui.BeginChild('##dwmerits_jp', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (imgui.BeginTable('##dwmerits_jptable', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Job point', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Level', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableSetupColumn('Next costs', ImGuiTableColumnFlags_WidthFixed, 76, 0);
        imgui.TableSetupColumn('Raise', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableHeadersRow();

        for _, row in ipairs(state.jp.types) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row.name);
            imgui.TableNextColumn();

            if (row.level >= row.max) then
                imgui.TextColored(theme.colors.ok, string.format('%d / %d', row.level, row.max));
            else
                imgui.Text(string.format('%d / %d', row.level, row.max));
            end

            imgui.TableNextColumn();

            if (row.next > 0) then
                imgui.Text(string.format('%d JP', row.next));
            else
                imgui.TextDisabled('--');
            end

            imgui.TableNextColumn();

            local canRaise = canEdit() and row.level < row.max and row.next > 0 and header.jp >= row.next;

            if (not canRaise) then imgui.BeginDisabled(); end

            if (imgui.Button(string.format('+##dwmerits_jp_%d', row.id), { 22, 0 })) then
                sendEdit('jpraise', row.id, 1);
            end

            if (not canRaise) then imgui.EndDisabled(); end
        end

        imgui.EndTable();
    end

    if (#state.jp.gifts > 0) then
        imgui.Spacing();
        imgui.TextDisabled(string.format('Gifts -- %d rungs, unlocked by total job points spent on this job:', #state.jp.gifts));

        for _, gift in ipairs(state.jp.gifts) do
            local unlocked = header.spent >= gift.jp;
            local line     = string.format('  %5d JP  %s %+d', gift.jp, gift.name, gift.value);

            if (unlocked) then
                imgui.TextColored(theme.colors.ok, line);
            else
                imgui.TextDisabled(line);
            end
        end
    end

    imgui.EndChild();
end

--[[
* Ascension tab: the bank, the merit conversion, the mastery sheet. Every
* number is the store's; the Buy button greys when the store would refuse.
--]]
local function ascensionTab()
    if (state.bank == nil) then
        imgui.TextDisabled('Fetching the bank from the server...');

        return;
    end

    local bank = state.bank;

    imgui.Text(string.format('Limit points banked: %d', bank.banked));
    imgui.TextDisabled(string.format('%d earned in all, %d spent. Every limit point you earn banks here, beside the retail bar.', bank.lifetime, bank.spent));

    imgui.Separator();
    imgui.Text(string.format('Merit points cost %d banked limit points each.', bank.perMerit));
    imgui.SameLine();

    local wallet     = state.wallet;
    local canConvert = state.pending == nil and wallet ~= nil and wallet.points < wallet.ceiling and bank.banked >= bank.perMerit;

    if (not canConvert) then imgui.BeginDisabled(); end

    if (imgui.Button('Buy 1 merit##dwmerits_conv1')) then
        sendBankAction('convert 1');
    end

    imgui.SameLine();

    if (imgui.Button('Buy 5##dwmerits_conv5')) then
        sendBankAction('convert 5');
    end

    imgui.SameLine();

    if (imgui.Button('Fill wallet##dwmerits_convall')) then
        sendBankAction('convert 127');
    end

    if (not canConvert) then imgui.EndDisabled(); end

    imgui.Separator();
    imgui.TextDisabled('Mastery -- permanent, and every squad member you call is paid your tiers:');

    if (#state.sheet == 0) then
        imgui.TextDisabled('Fetching the mastery sheet...');

        return;
    end

    if (not imgui.BeginChild('##dwmerits_mastery', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (imgui.BeginTable('##dwmerits_masterytable', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Line', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Tier', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableSetupColumn('Next tier costs', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Buy', ImGuiTableColumnFlags_WidthFixed, 50, 0);
        imgui.TableHeadersRow();

        for _, row in ipairs(state.sheet) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row.name);
            imgui.TextDisabled(row.desc);
            imgui.TableNextColumn();

            if (row.tier >= row.max) then
                imgui.TextColored(theme.colors.ok, string.format('%d / %d', row.tier, row.max));
            else
                imgui.Text(string.format('%d / %d', row.tier, row.max));
            end

            imgui.TableNextColumn();

            if (row.price > 0) then
                imgui.Text(string.format('%d LP', row.price));
            else
                imgui.TextDisabled('complete');
            end

            imgui.TableNextColumn();

            local canBuy = state.pending == nil and row.price > 0 and bank.banked >= row.price;

            if (not canBuy) then imgui.BeginDisabled(); end

            if (imgui.Button(string.format('Buy##dwmerits_asc_%s', row.key), { 44, 0 })) then
                sendBankAction('ascend ' .. row.key);
            end

            if (not canBuy) then imgui.EndDisabled(); end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        serverSilent = false;

        forget();
        requestSync();
        requestPick();
        requestMastery();
        requestJob();
    end

    imgui.SameLine();
    imgui.Text(walletLine());
    imgui.SameLine();

    if (state.wallet ~= nil and state.wallet.mog) then
        imgui.TextColored(theme.colors.ok, '[Mog House: assignment open]');
    else
        imgui.TextDisabled('[Enter your Mog House to assign]');
    end

    if (state.pending ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled('applying...');
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Separator();

    if (imgui.BeginTabBar('##dwmerits_tabs')) then
        if (imgui.BeginTabItem('Overview')) then
            if (next(state.cats) == nil) then
                imgui.TextDisabled('No merit data yet. Refresh, or wait for the first sync.');
            else
                imgui.TextDisabled('The six shared categories, against this server\'s true totals:');
                overviewBars();
                imgui.Spacing();
                imgui.TextDisabled('The Assign tab lists every entry -- pick a category or a job\'s groups.');
            end

            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Assign')) then
            imgui.SetNextItemWidth(220);

            local current = currentPick();

            if (imgui.BeginCombo('##dwmerits_pick', current.label)) then
                for i, pickEntry in ipairs(PICKS) do
                    if (imgui.Selectable(string.format('%s##dwmerits_pick_%d', pickEntry.label, i), state.pick[1] == i)) then
                        if (state.pick[1] ~= i) then
                            state.pick[1] = i;

                            requestPick();
                        end
                    end
                end

                imgui.EndCombo();
            end

            imgui.SameLine();
            imgui.TextDisabled('The stock menu shows retail\'s maximums; these are ours.');

            imgui.Separator();

            if (imgui.BeginChild('##dwmerits_sheet', { -1, -1 }, ImGuiChildFlags_None)) then
                sheetTable(currentPick());
            end

            imgui.EndChild();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Job Points')) then
            jobPointsTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Ascension')) then
            ascensionTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape).
--]]
ashita.events.register('d3d_present', 'dwmerits_present', function ()
    checkAnswers();
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 560, 520 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dw windows fused into an unthemed dock once; never again.
    local visible = imgui.Begin('DriftwoodXI Merits##dwmerits', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwmerits'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwmerits'):append(chat.message('Window closed. `!merits` typed by hand says the same numbers.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs and refetches the current
* slice: a sheet showing merits as they stood before the Mog House visit is
* the quiet kind of wrong this project exists to rule out.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
        serverSilent   = false;

        forget();
        requestSync();
        requestPick();
        requestMastery();
        requestJob();
    end
end

ashita.events.register('command', 'dwmerits_command', function (e)
    local args  = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwmerits' and first ~= '/merits' and first ~= '/dwi') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        serverSilent = false;

        forget();
        requestSync();
        requestPick();

        return;
    end

    toggleWindow();
end);

--[[
* No zone-in auto-sync, on purpose: unlike fame, merits change only when
* the player changes them, and this window resyncs itself every time it
* opens or edits. What zoning DOES invalidate is the Mog House flag -- so a
* zone line just clears the wallet, and the next open asks fresh.
--]]
ashita.events.register('packet_in', 'dwmerits_zonein', function (e)
    if (e.id == 0x000A) then
        state.wallet  = nil;
        state.pending = nil;

        forget();

        if (state.open[1] and not serverSilent) then
            requestSync();
            requestPick();
        end
    end
end);

--[[
* Watch what the player sends. Bare `!merits` toggles this window instead
* of going to the server -- the typed verb is a door, not a dead end; any
* `!merits <verb>` line still passes through untouched (that is the escape
* hatch this addon's header promises). Every other outgoing line stamps the
* throttle so a queued query never races something the player typed.
--]]
ashita.events.register('packet_out', 'dwmerits_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!merits' or lower == '!merits ui' or lower == '!merits window' or lower == '!merits gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwi') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwmerits_load', function ()
    print(chat.header('dwmerits'):append(chat.message('/merits or /dwmerits opens the merit sheet -- this server\'s true totals, and assignment past the stock menu\'s caps.')));
end);
