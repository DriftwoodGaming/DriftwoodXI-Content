--[[
* dwah -- the Driftwood market window (DWAH_PLAN.md)
*
* WHAT THIS IS. The player-only market, drawn: every active listing on the
* server -- the classic Auction House rows AND the blob lane -- in one
* searchable, sortable window, with real prices, one-click selling from the
* bag with no listing fee, player buy orders that escrow gil until a crafter
* fills them, and the account wallet every sale pays into. It is the same
* market the Jeuno counter shows, because it is the same tables: this window
* adds no rules, holds no secrets and owns no state the server does not.
*
* WHAT THIS IS NOT. A renderer, only. Every decision -- who owns a listing,
* what a fill pays, whether a price moved -- is re-made server-side in
* cpp/market_store.cpp, and the economics live one layer further down, in
* the auction_house_buy trigger. Anything this file sends is a CLAIM the
* server re-checks; anything it draws is a fact the server sent.
*
* THE WIRE (documentation/dwa_protocol.md): requests are typed chat lines
* (`!dwa page 0 3`) sent through dwecho at one per 1.2 s; answers are 0x017
* lines from sender _DWADATA, records between `d|1|<verb>` and `z|<verb>`.
* The model is a DRAWER sync (1.1.0; the full-market sweep died the day the
* kept legacy shelf put 5,000 rows behind it -- a 122-page walk and an fps
* sink): sweep the pages of ONE retail-AH drawer, sort and search locally
* within it, patch in place from this window's own mutations, and re-sweep
* only when the k| generation says another window moved the market.
*
* THE DRAWER IS SORTED AND SEARCHED ONCE PER CHANGE, NOT ONCE PER FRAME
* (1.6.0). Every write to the model bumps `state.modelRev`, and the filtered,
* sorted, labelled view is rebuilt only when that -- or the search text, the
* sort mode, the Mine tick or the scope -- has moved. Item names, levels,
* stack sizes, icon handles and measured text widths are memoised beside it;
* the DAT they come from cannot change while the client runs. A WRITE THAT
* FORGETS TO BUMP modelRev SHOWS THE OLD MARKET, and that is the only way
* any of this can be wrong.
*
* NOTHING THIS WINDOW ASKS FOR ARRIVES IN A BURST. One line per 1.2 s is the
* whole budget, shared with every other dw addon, so the market box drains
* one row at a time behind an answer rather than queueing one line per row
* (1.6.0), the quotes go as many ids to a line as the CLIENT's chat buffer
* will carry (1.6.1 -- a flat twenty overflowed it and the un-swallowed
* echoes went to the player's chat log), and an unanswered anything is
* re-asked twice and then said out loud.
*
* TURN IT OFF AND NOTHING IS LOST. `!market` does all of it typed.
--]]

addon.name    = 'dwah';
addon.author  = 'DriftwoodXI';
addon.version = '1.8.0';
addon.desc    = 'The Driftwood player market for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this file,
-- so a blocked line is already flagged by the time they see it.
echo.install();

local C = ffi.C;

-- The D3D device, fetched on first use rather than at load: this addon loads
-- from the launcher's boot script, long before the client has a rendering
-- device, and a file-scope get_device() makes the whole addon fail to load
-- (dwbags.lua:107-116).
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line.
local DATA_SENDER = '_DWADATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout; additive fields never move it.
local PROTOCOL = 1;

-- `l|` flag bits, as the server packs them. Bit 4 marks a blob-lane row (a
-- signed or charge-carrying copy); rare/EX this addon reads off the client
-- DAT for itself.
local L_EXDATA = 4;

local INVENTORY_CONTAINER = 0;
local INVENTORY_SLOTS     = 80;

-- The gil cap, for previews only; the server clamps for real.
local MAX_PRICE = 999999999;

-- How many units one `fill` may carry -- market_core.lua's MAX_COUNT, which
-- is market_store.cpp's kMaxFillPerCall. Named rather than the bare 12 it
-- was, because it is the SERVER'S number and drifting from it silently
-- turns a Fill button into a refusal.
local MAX_FILL_UNITS = 12;

--[[
* The retail Auction House tree, exactly as the client's own counter menu
* has drilled it into players for two decades: nine drawers, most opening a
* sub-list. The numbers are item_basic.aH, VERIFIED AGAINST THE LIVE TABLE
* (2026-08-20) -- never the wiki's (the dwscan lesson); the server filters
* pages by the same column, and folds the drawerless (aH 0, which only the
* blob lane can carry) into Others > Misc. (46) so nothing is unreachable.
--]]
local CATEGORIES = {
    { label = 'Weapons', subs = {
        { label = 'Hand-to-Hand', cat = 1 },
        { label = 'Daggers',      cat = 2 },
        { label = 'Swords',       cat = 3 },
        { label = 'Great Swords', cat = 4 },
        { label = 'Axes',         cat = 5 },
        { label = 'Great Axes',   cat = 6 },
        { label = 'Scythes',      cat = 7 },
        { label = 'Polearms',     cat = 8 },
        { label = 'Katana',       cat = 9 },
        { label = 'Great Katana', cat = 10 },
        { label = 'Clubs',        cat = 11 },
        { label = 'Staves',       cat = 12 },
        { label = 'Ranged',       cat = 13 },
        { label = 'Instruments',  cat = 14 },
        { label = 'Ammunition',   cat = 15 },
        { label = 'Grips',        cat = 62 },
        { label = 'Fishing Gear', cat = 47 },
        { label = 'Pet Items',    cat = 48 },
    } },
    { label = 'Armor', subs = {
        { label = 'Shields',  cat = 16 },
        { label = 'Head',     cat = 17 },
        { label = 'Body',     cat = 18 },
        { label = 'Hands',    cat = 19 },
        { label = 'Legs',     cat = 20 },
        { label = 'Feet',     cat = 21 },
        { label = 'Neck',     cat = 22 },
        { label = 'Waist',    cat = 23 },
        { label = 'Earrings', cat = 24 },
        { label = 'Rings',    cat = 25 },
        { label = 'Back',     cat = 26 },
    } },
    { label = 'Scrolls', subs = {
        { label = 'White Magic', cat = 28 },
        { label = 'Black Magic', cat = 29 },
        { label = 'Songs',       cat = 32 },
        { label = 'Ninjutsu',    cat = 31 },
        { label = 'Summoning',   cat = 30 },
        { label = 'Geomancy',    cat = 45 },
    } },
    { label = 'Medicines',   cat = 33 },
    { label = 'Furnishings', cat = 34 },
    { label = 'Materials', subs = {
        { label = 'Smithing',     cat = 38 },
        { label = 'Goldsmithing', cat = 39 },
        { label = 'Clothcraft',   cat = 40 },
        { label = 'Leathercraft', cat = 41 },
        { label = 'Bonecraft',    cat = 42 },
        { label = 'Woodworking',  cat = 43 },
        { label = 'Alchemy',      cat = 44 },
    } },
    { label = 'Food', subs = {
        { label = 'Meat & Eggs',   cat = 52 },
        { label = 'Seafood',       cat = 53 },
        { label = 'Vegetables',    cat = 54 },
        { label = 'Soups',         cat = 55 },
        { label = 'Breads & Rice', cat = 56 },
        { label = 'Sweets',        cat = 57 },
        { label = 'Drinks',        cat = 58 },
        { label = 'Ingredients',   cat = 59 },
        { label = 'Fish',          cat = 51 },
    } },
    { label = 'Crystals', cat = 35 },
    { label = 'Others', subs = {
        { label = 'Misc.',        cat = 46 },
        { label = 'Beast-Made',   cat = 50 },
        { label = 'Cards',        cat = 36 },
        { label = 'Ninja Tools',  cat = 49 },
        { label = 'Cursed Items', cat = 37 },
        { label = 'Dice',         cat = 60 },
        { label = 'Automaton',    cat = 61 },
        { label = 'Fireworks',    cat = 63 },
        { label = 'Skirmish',     cat = 64 },
        { label = 'Spoils',       cat = 65 },
    } },
};

-- The Misc. drawer id, where the server files the drawerless (aH 0).
local MISC_CAT = 46;

--[[
* The server's numbers, replaced field-by-field by the `h|` handshake --
* these fallbacks exist so the fee preview is drawable before the first
* answer, each `tonumber or` so a short record degrades rather than zeroes
* (the dwreport limits pattern).
--]]
--[[
* `cap` here is the h| copy of the account listing cap, kept because the
* handshake carries it and a short record must degrade field by field; the
* number the header actually draws is `state.cap` off the account line,
* which every response refreshes. They are the same number from the same
* store constant -- this one just arrives once, at hello.
--]]
local limits = {
    fee      = 5,
    bounty   = 2000,
    cap      = 200,
    ordercap = 50,
};

local function netOf(price)
    return price - math.floor(price * limits.fee / 100);
end

--[[
* A typed price, or nil. THE INTEGRALITY IS THE POINT (1.6.0): `tonumber`
* reads '2.5', '1e3' and 'inf' as happily as '900', and the number goes
* straight into `string.format('%d', ...)` on the wire -- which truncates
* silently under the client's LuaJIT and RAISES under other Luas, so the
* window either sent a price the player never typed or threw mid-table. A
* price is a whole number of gil between 1 and the cap; nothing else is a
* price, and the form says so instead of guessing.
--]]
local function wholeGil(text)
    local value = tonumber(text);

    if (value == nil or value ~= math.floor(value) or value < 1 or value > MAX_PRICE) then
        return nil;
    end

    return value;
end

-----------------------------------
-- State: everything the server said, plus what the window is doing about it.
-----------------------------------
local state = {
    open   = { false },
    synced = false,

    -- The account line (k|).
    mine    = 0,
    cap     = 200,
    wallet  = 0,
    orders  = 0,
    boxrows = 0,
    gen     = 0,

    -- The browse model: every listing of the CURRENT SCOPE -- one retail-AH
    -- drawer, or the account's own rows -- keyed by ref ('a1042'). The whole
    -- market never loads at once any more: 5,000 rows in one frame was the
    -- fps sink this window shipped with (2026-08-20).
    listings = {},
    pages    = 1,
    total    = 0,

    --[[
        THE MODEL REVISION (1.6.0). Every write to `listings` or `orderRows`
        bumps it, and the filtered/sorted view below is rebuilt only when it
        (or the search, sort, scope or Mine tick) has moved. The rebuild used
        to run sixty times a second over the whole drawer, with a DAT lookup
        per row for the search and two more per comparison inside the sort --
        the same per-frame re-sort dwwarehouse found and fixed in 1.10.0.
        A WRITE THAT FORGETS TO BUMP THIS LEAVES THE SCREEN SHOWING THE OLD
        MARKET, which is the one way this cache can be wrong.
    ]]
    modelRev = 0,

    -- What the model is OF: nil (nothing picked yet), { mine = true } (the
    -- Activity tab's view), or { cat = N, label = 'Weapons > Swords' }.
    scope    = nil,

    -- The category combos (indices into CATEGORIES / its subs).
    catTop = nil,
    catSub = nil,

    -- The frame counter, moved on once per d3d_present. Nothing measures
    -- TIME with it: it answers "was that drawn on the previous frame", which
    -- is what the hover dwell below actually needs and what no time window
    -- can say at an unknown frame rate.
    frame = 0,

    -- Which fifty of the sorted rows the screen shows (pagedRows). The
    -- order board keeps its own place (1.6.0): the two boards are different
    -- lists and sharing one counter jumped whichever tab was looked at
    -- second to the other one's page.
    viewPage   = 1,
    ordersPage = 1,
    orderFind  = { '' },
    lastSearch = '',

    -- The order board, keyed by order id.
    orderRows = {},

    -- Sweep state (browse and orders walk their pages independently).
    syncing        = false,
    nextPage       = nil,
    repaired       = false,
    ordersSyncing  = false,
    ordersNextPage = nil,

    -- Which generation the model was built at. The reconcile runs at z|
    -- (see handleRecord): a closed envelope whose k| generation disagrees
    -- with the model's -- a refusal, a hello after the counter sold
    -- something, a sweep another window raced -- re-sweeps once per
    -- generation value, so the window heals itself instead of asking the
    -- player to press Refresh (the 2026-08-19 live finding).
    syncGen        = nil,
    envelopeFailed = false,
    resyncFor      = nil,

    -- The History tab's model (1.2.0): the item asked about, the y| rows
    -- that came back, when the ask left (the tab's loading line), and the
    -- session's recent lookups (ids, newest first, at most eight).
    -- Populated by the tab's own lookup box and by the History button every
    -- listing and order row carries; all of it is this window's bookkeeping
    -- over the same `history` verb the typed tier has always had.
    history = { itemid = nil, name = nil, rows = {}, pendingAt = nil, recent = {} },

    --[[
        The history CACHE (1.4.0): every answer the window has had this
        session, keyed by item id -- { rows, at } -- so the hover card on a
        History button can show the sale list without a round trip, and
        the tab can show a fresh-enough answer at once. `arriving` is the
        list an open history envelope is building aside (committed at z|,
        the protocol's own discipline), `arrivingItem` the id the i| record
        named for it, and `asked` the ids of history lines queued and not
        yet answered, in order -- the routing for a server too old to send
        i|. `hoverAsk` is the History button the mouse is resting on and
        since when: a hover asks the server only after a short dwell, so a
        mouse swept down a column of buttons does not ask for every item.
    ]]
    historyCache = {},
    arriving     = nil,
    arrivingItem = nil,
    asked        = {},
    hoverAsk     = nil,

    -- A click asked for the History tab: the next frames' BeginTabItem
    -- carry ImGuiTabItemFlags_SetSelected. Two spellings of the call are
    -- tried before the latch closes -- see beginHistoryTab for why.
    historyFocus    = 0,
    tabSelectBroken = false,

    -- Which envelope is arriving (the verb from d|), nil between envelopes,
    -- and when it opened. An answer cut short -- a dropped 0x017, a reload
    -- mid-answer -- used to leave `inbound` open for the rest of the
    -- session: every later record was filed under the wrong verb, and the
    -- ask was already stamped answered at d|, so the answer clock never
    -- re-asked and the sweep hung on 'Loading...' forever. The watchdog in
    -- d3d_present closes a stale envelope and puts its ask back on the
    -- clock (1.6.0).
    inbound   = nil,
    inboundAt = 0,

    --[[
        One status line, whether it is a refusal, when it arrived, and
        whether it describes a STANDING CONDITION rather than something that
        happened (1.6.0). An `m|`/`e|` sentence is an event -- "bought Fire
        Crystal for 900", "that listing is gone" -- and half an hour later it
        was still sitting red under the header reading like a live problem.
        Those expire. The three that are conditions -- the protocol
        mismatch, the silence latch and the count repair -- do not, because
        they are still true until something answers them.
    ]]
    status       = nil,
    statusBad    = false,
    statusAt     = 0,
    statusSticky = false,

    -- The protocol latch and the silence latch (dwa_protocol.md discipline).
    protocolBad  = false,
    serverSilent = false,

    --[[
        UI: tab, search text, sort mode, pending confirmations. The Activity
        tab keeps its OWN find text (1.6.0): both views run through the same
        filter, so a word left in the Browse box silently hid rows on a tab
        that had no box to show it in -- your listings, missing, with nothing
        on screen saying why.
    ]]
    search     = { '' },
    mineFind   = { '' },
    sortMode   = 1, -- 1 level, 2 price, 3 name, 4 newest
    onlyMine   = { false },
    confirmBuy = nil, -- { ref, price, name }
    sellSlot   = nil, -- selected bag slot on the Sell tab
    sellPrice  = { '' },

    -- The order form.
    orderText  = { '' },
    orderId    = nil, -- resolved item id
    orderQty   = { 1 },
    orderPrice = { '' },
    orderStack = { false },
    confirmOrder = false,
    confirmFill  = nil, -- { id, name, price, count, slot }

    -- History search box.
    historyText = { '' },

    --[[
        The Sell tab's quotes (1.5.0): [itemid] = { single, singles, stack,
        stacks } off the u| record -- the average of the last ten real
        sales and how many it stands on. `quotesAsked` remembers which ids
        a `quotes` line has already carried this session (once per item;
        Refresh forgets), `noQuotes` latches off the server's own refusal
        sentence (an older binary), and `quickSell` is the row whose
        QuickSell was pressed, waiting for its confirm.
    ]]
    quotes      = {},
    quotesAsked = {},
    noQuotes    = false,
    quickSell   = nil,
    sellFind    = { '' },

    --[[
        The quotes batch in flight (1.6.0): the ids of the line last sent and
        when it left. Two holes it closes. An id the answer did not carry --
        an older store, a truncated line -- used to read '...' for the rest
        of the session, because `quotesAsked` had already spoken for it; at
        z| every id of the batch the answer did not name is written down as
        the honest 'no sales yet'. And a batch that is never answered at all
        used to disarm those items permanently; after QUOTE_TIMEOUT they go
        back in the pool and are asked once more.

        IT IS ALSO THE IN-FLIGHT MARKER (1.6.1): while it is set no second
        quotes line is built, so the two repairs above can never be applied
        to the wrong batch.
    ]]
    quotesBatch = nil,

    --[[
        The market-box drain (1.6.0). The Collect button used to queue one
        `!dwa collect` PER BOX ROW at once: a box of forty parked the send
        queue for forty-eight seconds -- no page sweep, no history, nothing
        -- and every row past the free space in the bag came back a refusal
        that printed its own red chat line. One collect is in flight at a
        time now, `collectLeft` is the ceiling that guarantees it stops, and
        a refusal inside a collect envelope ends the drain outright.
    ]]
    collectLeft    = 0,
    collectAt      = 0,
    collectPending = false,
};

-----------------------------------
-- Client DAT lookups (names, levels, icons, cards)
-----------------------------------

--[[
* Whether an id is worth handing to the resource manager at all. The bindings
* take an integer, and a FRACTION reaching one is the class of mistake this
* suite refuses on principle (`/dwah history 2.5` used to walk straight into
* GetItemById and string.format('%d', ...)); a bad id is answered nil here
* rather than at the binding.
--]]
local function usableItemId(itemId)
    return type(itemId) == 'number'
        and itemId > 0
        and itemId < 65536
        and itemId == math.floor(itemId);
end

local function resourceOf(itemId)
    if (not usableItemId(itemId)) then
        return nil;
    end

    return AshitaCore:GetResourceManager():GetItemById(itemId);
end

--[[
* THE NAME AND LEVEL CACHES (1.6.0), the dwwarehouse 1.10.0 recipe brought
* home to the window it was copied from. Both are read in the HOT loop:
* sortedListings asks for a name once per row to run the search, and again
* twice per comparison inside table.sort -- so a two-thousand-row drawer was
* tens of thousands of sol calls into the client's DAT tables EVERY FRAME.
* The DAT is static for the life of the client, so the answer is asked once
* and kept. Bounded by the item table (65,535 ids) the way `icons` below is,
* and dropped on zone-in with the rest of the session's caches.
*
* A BLANK-NAMED ITEM IS A MISS, not an empty label: the DAT carries a few
* placeholder rows whose Name[1] is '', and a row drawn as nothing at all is
* a row the player cannot search for or read.
--]]
local nameCache  = {};
local levelCache = {};

local function itemName(itemId)
    if (not usableItemId(itemId)) then
        -- Named for the player anyway, because a row with no label is worse
        -- than a row with a wrong one -- but the id itself has to survive
        -- `%d`, and inf and nan do not.
        local shown = 0;

        if (type(itemId) == 'number' and itemId > -1e12 and itemId < 1e12) then
            shown = math.floor(itemId);
        end

        return string.format('item %d', shown);
    end

    local cached = nameCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item = resourceOf(itemId);
    local name = nil;

    if (item ~= nil and item.Name ~= nil) then
        name = item.Name[1];
    end

    if (type(name) ~= 'string' or #name == 0) then
        name = string.format('item %d', itemId);
    end

    nameCache[itemId] = name;

    return name;
end

-- The level-sort key (D8): item level where the DAT has one, equip level
-- otherwise; materials and consumables read 0 and sort together.
local function levelOf(itemId)
    if (not usableItemId(itemId)) then
        return 0;
    end

    local cached = levelCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local level = 0;
    local item  = resourceOf(itemId);

    if (item ~= nil) then
        local ilvl = item.ItemLevel or 0;

        level = ilvl > 0 and ilvl or (item.Level or 0);
    end

    levelCache[itemId] = level;

    return level;
end

-- How many of an item fit in one bag cell. Read three times per bag row per
-- frame (the QuickSell gate, the QuickSell-stack gate and the List stack
-- gate) and once per order row, so it joins the other two caches (1.6.0).
local stackCache = {};

local function stackSizeOf(itemId)
    if (not usableItemId(itemId)) then
        return 1;
    end

    local cached = stackCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item = resourceOf(itemId);
    local size = 1;

    if (item ~= nil and type(item.StackSize) == 'number' and item.StackSize > 0) then
        size = item.StackSize;
    end

    stackCache[itemId] = size;

    return size;
end

--[[
* Item icons, cached per id -- dwbags' iconOf/drawIcon, kept verbatim (the
* dwraid copy of the same recipe). `false` memoises a failure so a bad id is
* asked of D3D once, not sixty times a second.
--]]
local icons     = {};
local iconCount = 0;

local function iconOf(itemId)
    local cached = icons[itemId];

    if (cached ~= nil) then
        return cached ~= false and cached or nil;
    end

    local item = resourceOf(itemId);

    -- `ImageSize == 0` is the third of the three checks every other copy of
    -- this recipe makes (dwbags, dwcpx, dwquest, dwraid, dwscan, dwwarehouse,
    -- dwcon, dwsquad) and the only one this one had dropped. A non-null
    -- Bitmap with a zero length hands D3DXCreateTextureFromFileInMemoryEx a
    -- SrcDataSize of 0 and lets its in-memory image parser decide for itself
    -- where the data ends -- on Wine's d3dx8 in particular, a path nobody has
    -- hardened. There is no picture behind a zero-length bitmap either way.
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;

        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    local result = C.D3DXCreateTextureFromFileInMemoryEx(
        dev, item.Bitmap, item.ImageSize, 0xFFFFFFFF, 0xFFFFFFFF, 1, 0,
        C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED, C.D3DX_DEFAULT, C.D3DX_DEFAULT,
        0xFF000000, nil, nil, ptr);

    if (result ~= 0) then
        icons[itemId] = false;

        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));
    iconCount     = iconCount + 1;

    return icons[itemId];
end

--[[
* The number ImGui wants for a texture, memoised beside the texture itself
* (1.6.0). `tonumber(ffi.cast('uint32_t', texture))` is two FFI round trips
* for an answer that cannot change while the texture lives, and this ran once
* per drawn row per frame -- fifty rows plus a card is fifty-one of them,
* sixty times a second, for fifty-one constants.
--]]
local iconHandles = {};

--[[
* THE CEILING ON THE ICON CACHE (1.8.0).
*
* Every entry above is a live D3DPOOL_MANAGED texture and the key is an item
* id -- sixty-five thousand of them. FFXI is a 32-bit process that runs out of
* ADDRESSES long before it runs out of memory (the black-screen-after-zoning
* class), and an allocation that fails inside a client which does not check
* the result becomes a write through a null pointer. A cache keyed by
* something with that cardinality owes a bound like every other table in this
* suite, and this one had none -- in the addon a player leaves open at the
* counter for an hour, paging other people's listings.
*
* Dropped WHOLE rather than evicted one at a time: `gc_safe_release` owns the
* release, so letting go of the last reference IS the free. dwcon's
* releaseIcons and dwmerc's gilCache are the same recipe.
*
* And dropped at the TOP OF A FRAME, never from inside iconOf. ImGui keeps the
* raw texture pointer in its draw list until Ashita renders that list at the
* end of the present hook, so a texture released in the middle of a pass is a
* dangling pointer inside the pass still using it. By the time the next present
* handler runs, the previous frame is already on the screen.
--]]
local ICON_MAX = 1024;

local function sweepIcons()
    if (iconCount < ICON_MAX) then
        return;
    end

    icons       = {};
    iconHandles = {};
    iconCount   = 0;

    collectgarbage('collect');
end

-- Draws the icon (or a spacer) and leaves the cursor on the same line.
local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil) then
        local handle = iconHandles[itemId];

        if (handle == nil) then
            handle = tonumber(ffi.cast('uint32_t', texture));

            iconHandles[itemId] = handle;
        end

        imgui.Image(handle, { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

local JOB_NAMES = {
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK', 'BST', 'BRD',
    'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU', 'COR', 'PUP', 'DNC', 'SCH',
    'GEO', 'RUN',
};

local FLAG_RARE      = 0x8000;
local FLAG_EX        = 0x4000;
local FLAG_NOAUCTION = 0x0040;

--[[
* COULD THE SERVER EVER LET THIS ITEM BE LISTED? (1.6.1.)
*
* The item half of `copyRefusal` (modules/driftwoodxi/cpp/market_store.cpp:
* 663-676): EX never lists -- the D9 account-exclusivity doctrine -- and the
* DAT's NoAuction flag is the retail counter's own refusal. Bits 0-15 of the
* server's `ItemFlag` mirror the retail DAT layout verbatim
* (src/map/enums/item_flag.h:27-31), so `Exclusive` 0x4000 and `NoAuction`
* 0x0040 are the same two bits the client reads.
*
* THE SERVER STILL DECIDES -- nothing here refuses a listing, and an item we
* cannot look up answers "yes, ask" so a DAT we do not understand never hides
* a sellable row. This is asked for two reasons only: a bag of EX gear used
* to spend the shared send budget asking for quotes nobody could ever act on
* (a full bag was five `quotes` lines, most of them about items with no
* counter to sell at), and a row with no QuickSell deserves a reason in the
* cell rather than an empty one.
*
* Cached like the name/level/stack lookups beside it: this is read once per
* bag row per frame, and the DAT cannot change while the client runs.
--]]
local listCache = {};

local function listable(itemId)
    if (not usableItemId(itemId)) then
        return true;
    end

    local cached = listCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item  = resourceOf(itemId);
    local allow = true;

    if (item ~= nil) then
        local flags = item.Flags or 0;

        allow = bit.band(flags, FLAG_EX) == 0
            and bit.band(flags, FLAG_NOAUCTION) == 0;
    end

    listCache[itemId] = allow;

    return allow;
end

--[[
* The eight elemental-resist icons in the client's item descriptions are
* FFXI-private Shift-JIS pairs -- 0xEF then 0x1F..0x26, in wheel order
* fire ice wind earth lightning water light dark (read straight out of
* ROM/118/107.DAT: item 6272 carries fire as EF 1F, item 4488 dark as
* EF 26, and the JP DAT spells the same slots 耐火/耐風/耐土). ImGui wants
* UTF-8, so the raw pair renders as the '?' players reported. Each icon
* (and the '+' that usually follows it) folds to a three-letter tag:
* '<fire>+20' reads FiR:20, '<dark>-10' reads DkR:-10. Mirrored BY HAND
* from dwbags 1.17.0 -- edit one, revisit the others.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function(b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

--[[
* Augment names -- augcatalog.lua beside this file, the same GENERATED
* catalog dwquest carries (tools/dwquest/gen_augment_catalog.py;
* Check-QuestAugments.ps1 keeps every copy byte-identical to dwquest's).
* pcall'd because a half-synced folder is a real deployment state: without
* the catalog the card still lists augments, as the raw ids they are.
--]]
local haveAugCatalog, augcatalog = pcall(require, 'augcatalog');

if (not haveAugCatalog or type(augcatalog) ~= 'table' or type(augcatalog.augments) ~= 'table') then
    augcatalog = { augments = { } };
end

--[[
* ONE AUGMENT'S MAGNITUDE AT A GIVEN RANK -- dwquest's `augmentWords`
* (dwquest.lua, the catalog block) character for character. `rank` is the
* HUMAN rank: the stored five-bit exdata value plus one, which is what
* extraAugments below adds and what the server's own records carry
* (alt_storage.cpp augsOf, quest_store.cpp:2346).
*
* A substitutable entry has its digit runs recomputed for this rank -- term k
* applies to the k-th digit run, a bare number n means n + stored, a pair
* { b, s } means b + stored * s. The generator emits a term ONLY where it
* verified that against the engine's own formula (item_equipment.cpp
* SetAugmentMod: `(value > 0 ? value + stored : value - stored) * max(mult, 1)`),
* so this never invents a magnitude.
*
* THE SECOND RETURN IS THE HONESTY BIT: an entry with no terms cannot be
* recomputed, so the words are rank 1's whatever rank was asked for, and
* `exact` is false. A caller that prints those beside a rank is the 2026-09-11
* defect -- a reader multiplies and expects five times the number.
--]]
local function augmentWords(augid, rank)
    local entry = augcatalog.augments[augid];

    if (entry == nil) then
        return string.format('augment %d', augid), false;
    end

    local label  = entry.l;
    local stored = rank - 1;

    if (entry.m == nil) then
        return label, stored == 0;
    end

    if (stored > 0) then
        local k = 0;

        label = string.gsub(label, '%d+', function(digits)
            k = k + 1;

            local term = entry.m[k];

            if (term == nil) then
                return digits;
            end

            if (type(term) == 'table') then
                return tostring(term[1] + stored * term[2]);
            end

            return tostring(term + stored);
        end);
    end

    return label, true;
end

--[[
* One augment, as a hover card names it: the magnitude AT THIS RANK, and the
* rank itself whenever it is not 1. dwquest's augmentText without the
* exchange id suffix -- a card names the augment, the Exchange window is
* where ids matter.
*
* THE RANK IS STATED ALONGSIDE THE MAGNITUDE (owner report, 2026-09-11). The
* card used to print a bare `Mag. Evasion +7` for a rank-5 augment while the
* SeeAugs reference printed the catalog's rank-1 `+3` with "rank 5" beside
* it, and a player holding both read the +7 as the window hiding eight
* points. +7 IS what rank 5 grants -- the engine adds the stored value ONCE,
* it does not multiply -- so every line that shows a magnitude now shows the
* rank it belongs to, and the two windows stop looking like two answers.
--]]
local function augmentText(augid, rank)
    if (augcatalog.augments[augid] == nil) then
        return string.format('augment %d rank %d', augid, rank);
    end

    local label = augmentWords(augid, rank);

    if (rank > 1) then
        return string.format('%s (rank %d)', label, rank);
    end

    return label;
end

--[[
* The four augment slots out of an item's exdata bytes, decoded the way
* quest_store.cpp augmentsOf does: byte one is the kind (0x02 = carries
* augments), byte two the sub-kind (any special bit 0x08..0x80 --
* escutcheon, serialized, mezzotint, trial, evolith -- is a DIFFERENT byte
* layout and is refused, quest_store.cpp extraIsAugmentable), then four
* packed uint16s -- id in the low 11 bits, stored value in the high 5, and
* the rank a player reads is stored + 1. Returns nil when there is nothing
* honest to say. The market refuses augmented listings at the counter, so
* the only rows this can decorate are the Sell tab's own bag rows.
--]]
local function extraAugments(extra)
    if (type(extra) ~= 'string' or #extra < 12) then
        return nil;
    end

    if (extra:byte(1) ~= 0x02 or bit.band(extra:byte(2), 0xF8) ~= 0) then
        return nil;
    end

    local augs = {};

    for slot = 0, 3 do
        local packed = extra:byte(3 + slot * 2) + extra:byte(4 + slot * 2) * 256;
        local augid  = bit.band(packed, 0x07FF);

        if (augid ~= 0) then
            augs[#augs + 1] = { id = augid, rank = bit.band(bit.rshift(packed, 11), 0x1F) + 1 };
        end
    end

    if (#augs == 0) then
        return nil;
    end

    return augs;
end

local function jobsText(mask)
    if (mask == nil or mask == 0) then
        return nil;
    end

    local names = {};

    for index, name in ipairs(JOB_NAMES) do
        if (bit.band(mask, bit.lshift(1, index)) ~= 0) then
            names[#names + 1] = name;
        end
    end

    if (#names == 0 or #names == #JOB_NAMES) then
        return nil;
    end

    return table.concat(names, ' ');
end

--[[
* Whether the player already knows the spell a scroll teaches (1.4.0, the
* owner's request): true, false, or nil when the item is not a scroll or
* the client cannot say. A scroll is recognised by its own description --
* every spell scroll's opens "Teaches the ..." -- and the spell is looked
* up by the scroll's DAT name (which IS the spell's name: the item is
* "Auspice", the log name "scroll of Auspice"), falling back to the last
* words of the description. The player's spell list is the client's own
* memory (IPlayer:HasSpell), read under pcall: the sol bindings for it are
* promised by Ashita's annotations and proven by no sibling, so a refusal
* costs one missing line rather than a card that throws. Mirrored BY HAND
* into dwbags and dwwarehouse (edit one, revisit the others).
--]]
local function scrollStatus(item)
    if (item == nil) then
        return nil;
    end

    local desc = item.Description ~= nil and item.Description[1] or nil;

    if (type(desc) ~= 'string' or desc:sub(1, 12) ~= 'Teaches the ') then
        return nil;
    end

    local ok, known = pcall(function()
        local mgr    = AshitaCore:GetResourceManager();
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (mgr == nil or player == nil) then
            return nil;
        end

        local names = { item.Name ~= nil and item.Name[1] or nil };

        -- "Teaches the white magic Auspice." / "Teaches the song Foe
        -- Requiem." -- the spell is whatever follows the kind words.
        local tail = desc:match('^Teaches the [%a%-]+ [%a%-]+ (.-)%.') or desc:match('^Teaches the [%a%-]+ (.-)%.');

        if (tail ~= nil and tail ~= names[1]) then
            names[#names + 1] = tail;
        end

        for _, name in ipairs(names) do
            local spell = mgr:GetSpellByName(name, 0);

            if (spell ~= nil and spell.Index ~= nil) then
                return player:HasSpell(spell.Index) == true;
            end
        end

        return nil;
    end);

    if (not ok) then
        return nil;
    end

    return known;
end

-- The one line the status draws, shared by every card that shows it.
local function drawScrollStatus(item)
    local known = scrollStatus(item);

    if (known == true) then
        imgui.TextColored(theme.colors.ok, 'You already know this spell.');
    elseif (known == false) then
        imgui.TextColored(theme.colors.warn, 'Not learned yet.');
    end
end

--[[
* THE UNWIND STACK (1.6.0). Every tab body runs under its own pcall, which
* is what keeps one throw from taking the whole window down -- but a pcall
* cannot unwind ImGui's stack, and every throw this window has ever had came
* from INSIDE a table or a hover card: that is where the wire numbers, the
* arithmetic and the sol calls are. The table then stayed open for the rest
* of the frame and Dear ImGui put its assert box over the client, which is
* the exact 5a failure that made these pcalls necessary in the first place.
*
* So the Begins that a throw can be caught across push their own End here,
* and `guarded` pops back to the depth it entered at. Structure, not hope --
* the same sentence the pcalls themselves were written under. LIFO, one
* stack rather than a counter per kind, because a card inside a table has to
* close before the table does.
--]]
local openStack = {};

local function beginTable(id, columns, flags, size)
    if (not imgui.BeginTable(id, columns, flags, size)) then
        return false;
    end

    openStack[#openStack + 1] = imgui.EndTable;

    return true;
end

local function endTable()
    openStack[#openStack] = nil;

    imgui.EndTable();
end

local function beginTooltip()
    imgui.BeginTooltip();

    openStack[#openStack + 1] = imgui.EndTooltip;
end

local function endTooltip()
    openStack[#openStack] = nil;

    imgui.EndTooltip();
end

local function beginTabBar(id)
    if (not imgui.BeginTabBar(id)) then
        return false;
    end

    openStack[#openStack + 1] = imgui.EndTabBar;

    return true;
end

local function endTabBar()
    openStack[#openStack] = nil;

    imgui.EndTabBar();
end

-- The hover card: icon, tags decoded from the client DAT, augments where
-- the bytes are readable, description under a fixed wrap width
-- (dwraid.lua:238-306 -- the card must render the same whatever window it
-- floats over). `aug` is a list of { id, rank } or nil.
local function itemCard(itemId, aug)
    local item = resourceOf(itemId);

    beginTooltip();

    drawIcon(itemId, 32);
    imgui.Text(itemName(itemId));

    if (item ~= nil) then
        local tags = {};

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags[#tags + 1] = string.format('iLvl %d', item.ItemLevel);
        elseif (item.Level ~= nil and item.Level > 0) then
            tags[#tags + 1] = string.format('Lv %d', item.Level);
        end

        if (bit.band(item.Flags or 0, FLAG_RARE) ~= 0) then
            tags[#tags + 1] = 'Rare';
        end

        if (bit.band(item.Flags or 0, FLAG_EX) ~= 0) then
            tags[#tags + 1] = 'Ex';
        end

        if (#tags > 0) then
            imgui.TextDisabled(table.concat(tags, '  '));
        end

        local jobs = jobsText(item.Jobs);

        if (jobs ~= nil) then
            imgui.TextDisabled(jobs);
        end

        drawScrollStatus(item);

        if (type(aug) == 'table') then
            imgui.Separator();
            imgui.TextColored(theme.colors.info, 'Augments');

            for _, a in ipairs(aug) do
                imgui.Text('  ' .. augmentText(a.id, a.rank));
            end
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            imgui.PushTextWrapPos(320.0);
            imgui.Text(cleanDescription(desc));
            imgui.PopTextWrapPos();
        end
    end

    endTooltip();
end

-- drawIcon leaves the cursor on the same line, and IsItemHovered reads the
-- LAST item, so the icon's hover is taken before the label is drawn
-- (dwraid.lua:1097-1108). `aug` passes through to the card.
local function cardOnHover(itemId, hoveredIcon, aug)
    if (imgui.IsItemHovered() or hoveredIcon == true) then
        itemCard(itemId, aug);
    end
end

-----------------------------------
-- The send queue (the dwbags/dwwarehouse machinery, kept whole)
-----------------------------------

local SEND_INTERVAL = 1.2;

--[[
* WHAT FITS ON ONE COMMAND LINE, AND WHY IT IS NOT 127 (1.6.1, 2026-09-11).
*
* The client's outgoing chat buffer is 128 bytes
* (`GP_CLI_COMMAND_CHAT_STD.Str`, src/map/packets/c2s/0x0b5_chat_std.h:44),
* and dwgambits.lua:1632-1647 pins 127 as the ceiling for a line a player's
* own click builds. A `!` command an ADDON sends answers to a second, tighter
* length as well, and forgetting it is what this constant exists to stop.
*
* The client renders every line it sends as `<name> : <command>` in the chat
* log, and dwecho swallows that local echo only by matching the command as an
* exact SUFFIX of the rendered line (dwecho.lua's text_in handler). Push
* `<name> : <command>` past the client's chat buffer and what arrives is no
* longer the line we sent -- the suffix test misses and the player reads
* their own plumbing, one line per send, in chat.
*
* THAT IS THE 1.5.0 quotes BUG, reported by two players and the owner on
* 2026-09-11: `!dwa quotes ` plus twenty five-digit ids is 131 characters
* (149 with the longest name in front of it), and the Sell tab sent one every
* time it was drawn over a bag with more than twenty items. The field lines
* ran ~123 characters and arrived CUT MID-ID, which is the fingerprint of an
* echo that did not survive the buffer -- a server-side /say fall-through
* would have carried the whole line (`Mes[150]`, 0x017_chat_std.h:50), and a
* line the client refuses outright never renders as `<name> : ...` at all.
*
* report_core.lua:51-71 bought exactly this lesson once already, in the other
* direction: `!dwr t` lines were pulled back to 102 characters after a
* 122-character one lost its tail in the field, with the same wall of
* un-swallowed echoes beside it.
*
* A character name is at most fifteen bytes (`GP_SERV_COMMAND_CHAT_STD.sName`,
* src/map/packets/s2c/0x017_chat_std.h:50) and the echo puts ` : ` in front
* of the command, so the widest command this window may ever build is 127
* minus those eighteen. harness_dwah.py measures EVERY line the addon sends
* against it, which is the half that was missing: the 1.5.0 harness only ever
* drove a two-item bag, so the longest line this addon can produce had never
* been on a scale.
--]]
local CHAT_LINE_MAX = 127;
local ECHO_PREFIX   = 15 + 3;
local COMMAND_MAX   = CHAT_LINE_MAX - ECHO_PREFIX;

--[[
* The market-box drain's ceiling and its pace (1.6.0). Eighty is one bagful
* -- the client cannot hold more than that whatever the box says -- and the
* gap is longer than the send throttle, so exactly one collect is ever in
* flight and the sweep, the history asks and the quotes keep their turns.
--]]
local COLLECT_MAX = 80;
local COLLECT_GAP = 2.0;

-- ...and how long one collect may go unanswered before the drain stops
-- waiting for it. A dropped line must cost one row's delay, never the rest
-- of the box.
local COLLECT_LOST = 10.0;

local queue    = T{ };
local lastSend = 0;

-- A query is machinery traffic -- a sweep's page walk, a re-asked hello.
-- Everything else left the player's own finger: a Buy confirm, a Post
-- order, a Claim. The two classes get opposite treatment twice below.
local function isQuery(command)
    return command == '!dwa hello'
        or command:match('^!dwa page ') ~= nil
        or command:match('^!dwa orders ') ~= nil
        or command:match('^!dwa history ') ~= nil
        or command:match('^!dwa quotes ') ~= nil;
end

-- ONLY QUERIES COLLAPSE (dwwarehouse.lua:487-506): asking twice for a page
-- is never useful, but two identical Buy clicks are two commands the player
-- asked for, and collapsing a write silently loses one.
local function issue(command)
    if (isQuery(command)) then
        for _, queued in ipairs(queue) do
            if (queued == command) then
                return;
            end
        end
    end

    queue:append(command);
end

-- Drains one queued command per interval. Called every frame from
-- d3d_present, including while the window is shut: a sweep started just
-- before closing still has to finish.
local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while zoning and answers with
    -- "A command error occurred." before the server ever sees the line, so
    -- the queue holds shut -- held, not dropped -- until the load screen is
    -- gone (dwecho.canSend, 2026-08-15).
    if (not echo.canSend()) then
        return;
    end

    -- The protocol latch parks EVERYTHING: a version mismatch has no safe
    -- line to send.
    if (state.protocolBad) then
        queue = T{ };

        return;
    end

    -- The silence latch parks only the MACHINERY: on a server without
    -- dwa.lua an unknown ! command falls through to public /say, and a
    -- sweep's auto-sends would be the player chatting at bystanders. But a
    -- MUTATION is one line the player asked for by clicking through a
    -- confirm -- exactly the deliberate act pressing Refresh is -- and
    -- dropping it here, silently, was the 2026-08-20 order-post bug: the
    -- latch ate the Post order and nothing said so.
    if (state.serverSilent) then
        local kept = T{ };

        for _, queued in ipairs(queue) do
            if (not isQuery(queued)) then
                kept:append(queued);
            end
        end

        queue = kept;

        if (#queue == 0) then
            return;
        end
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

-----------------------------------
-- The answer clock (dwwarehouse.lua:539-623, kept whole)
-----------------------------------

-- A PLAIN TABLE, NOT T{ } -- keyed by verb, and T{}'s metatable resolves
-- unknown keys to the sugar methods (the dwbags lesson).
local requested = {};

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- How long an OPEN envelope may stay open before the watchdog in d3d_present
-- declares it lost. Every record of one answer arrives inside a tick or two
-- of the server's own write, so this is generous by a factor of tens; it
-- exists to catch a truncated answer, not a slow one.
local ENVELOPE_TIMEOUT = 8.0;

-- One exact sentence, so the d| revival below can tell its own stale status
-- line from anything else worth keeping.
local SILENCE_STATUS = 'The server is not answering -- press Refresh to try again.';

--[[
* How long an ordinary status sentence stays on the header. Long enough to
* read twice, short enough that it cannot be mistaken for a condition.
*
* STAMPED WITH os.time (WALL SECONDS), NOT os.clock (CPU SECONDS), and that
* is deliberate: every other clock in this file measures a protocol window --
* an answer, a dwell, a throttle -- where CPU time is the honest unit and a
* stalled client should not age its own asks out. This one measures how long
* a person has had a sentence in front of them, which is wall time; the
* window's own frame rate has nothing to do with it.
--]]
local STATUS_LINGER = 30;

local function setStatus(text, bad, sticky)
    state.status       = text;
    state.statusBad    = bad == true;
    state.statusAt     = os.time();
    state.statusSticky = sticky == true;
end

local function clearStatus()
    state.status       = nil;
    state.statusBad    = false;
    state.statusSticky = false;
end

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

-- Ask for one thing, at most once -- twice if the first was never answered;
-- then say so and stand down (a silent give-up disarmed dwwarehouse's
-- self-repair for a whole session once).
local function need(verb, key, command, onDead)
    local asked = requested[verb];

    if (asked ~= nil and asked.key == key) then
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered) then
            return;
        end

        -- THE CLOCK STARTS WHEN THE LINE LEAVES, not when the need was
        -- registered: the queue drains one line per 1.2 s, and an ask born
        -- behind a backlog -- collect clicks, the orders sweep, another
        -- window's traffic moving the shared throttle -- used to age past
        -- five seconds before its first send. The silence latch then read
        -- the queue's own depth as a dead server (the 2026-08-20 live
        -- report, 42 of 5,090 loaded and 'not answering').
        for _, queued in ipairs(queue) do
            if (queued == command) then
                asked.at = os.clock();

                return;
            end
        end

        -- The window is checked BEFORE the try count: in the other order the
        -- sweep is declared dead on the frame after the second send.
        if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (onDead ~= nil) then
                onDead();
            end

            state.serverSilent = true;

            setStatus(SILENCE_STATUS, true, true);

            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested[verb] = { key = key, at = os.clock(), answered = false, tries = 1 };
    end

    issue(command);
end

-----------------------------------
-- Sweeps: the browse pages and the order board
-----------------------------------

-- The scope's wire spelling: the drawer number, or -1 for mine -- the same
-- value the server's q| tail echoes back, which is how a page answer racing
-- a drawer switch is told from the sweep actually running.
local function scopeCat()
    if (state.scope == nil) then
        return nil;
    end

    if (state.scope.mine) then
        return -1;
    end

    return state.scope.cat;
end

-- Whether a model row belongs to the current scope. Rows can only be off
-- scope through a mutation's patch-in-place (a sell files into whatever
-- drawer the item lives in) or a raced answer; both stay held but unseen,
-- and the next sweep clears them.
local function scopeMatches(row)
    if (state.scope == nil) then
        return false;
    end

    if (state.scope.mine) then
        return row.mine;
    end

    return row.cat == state.scope.cat
        or (state.scope.cat == MISC_CAT and row.cat == 0);
end

-- Cleared rather than merged into (the dwwarehouse sweep rule): a row this
-- window holds that the server no longer has would survive any number of
-- merges, and a ghost row is a Buy button that fails. No scope, no sweep:
-- until a drawer is picked there is nothing to ask for, which is the whole
-- fix -- the full-market walk was 122 pages and 2.5 minutes.
local function startSync()
    state.listings = {};
    state.syncGen  = nil;
    state.modelRev = state.modelRev + 1;

    if (state.scope == nil) then
        state.syncing  = false;
        state.nextPage = nil;
    else
        state.syncing  = true;
        state.nextPage = 0;
    end

    requested['page'] = nil;
end

local function startOrdersSync()
    state.orderRows      = {};
    state.modelRev       = state.modelRev + 1;
    state.ordersSyncing  = true;
    state.ordersNextPage = 0;

    requested['orders'] = nil;
end

local function refreshAll()
    -- ...AND WHILE IT IS UP, REFRESH DOES NOTHING AT ALL (1.6.0). It used to
    -- arm both sweeps anyway: the driver then refused to send them (rightly),
    -- so the header sat under 'Update dwah' saying 'Loading Weapons > Swords
    -- 0 / 0...' forever -- a window that looks busy and is not. There is
    -- nothing to ask a server whose records this addon cannot read.
    if (state.protocolBad) then
        return;
    end

    state.serverSilent = false;
    state.repaired     = false;

    -- THE PROTOCOL LATCH IS DELIBERATELY *NOT* CLEARED HERE, and that is a
    -- gated contract rather than an oversight: harness_dwah.py's "the latch
    -- stops every automatic send" drives a mismatch, then `/dwah refresh`, and
    -- asserts nothing at all goes out. A client that cannot read this server's
    -- records has no line worth sending, and Refresh is not new information.
    -- The one thing that IS new information is a login (the zone handler
    -- clears it there): a map restart logs everyone out, so the server on the
    -- other side may well be the updated one.

    -- The quotes are re-asked from scratch: a Refresh is the one gesture
    -- that means "the numbers may have moved".
    state.quotes      = {};
    state.quotesAsked = {};

    issue('!dwa hello');
    startSync();
    startOrdersSync();
end

-- The scope's wire spelling as a cache key: the drawer number, 'mine', or
-- '-' for no scope at all.
local function scopeKey()
    if (state.scope == nil) then
        return '-';
    end

    return state.scope.mine and 'mine' or tostring(state.scope.cat);
end

-- Counts only the rows OF THE SCOPE: the server's q| total is the scope's
-- total, and an off-scope row a mutation patched in must not read as a
-- miscount (verifySweep re-sweeps on exactly that disagreement).
--
-- Cached against the model revision (1.6.0): the header strip asks for this
-- on every frame of a sweep -- the one time the model is at its biggest --
-- and the walk is over every row the drawer holds.
local countCache = { key = nil, count = 0 };

local function listingCount()
    local key = string.format('%d|%s', state.modelRev, scopeKey());

    if (countCache.key == key) then
        return countCache.count;
    end

    local count = 0;

    for _, row in pairs(state.listings) do
        if (scopeMatches(row)) then
            count = count + 1;
        end
    end

    countCache.key   = key;
    countCache.count = count;

    return count;
end

-- The count repair (the dwwarehouse verify shape): a completed sweep whose
-- model disagrees with the server's own total re-sweeps ONCE, never a loop.
local function verifySweep()
    if (listingCount() == state.total) then
        state.repaired = false;

        return;
    end

    if (state.repaired) then
        setStatus(string.format('Showing %d of %d listings -- press Refresh.', listingCount(), state.total), true, true);

        return;
    end

    state.repaired = true;

    startSync();
end

-- Points the model at a scope, re-sweeping only on an actual change: the
-- tabs call this every frame they are visible (Browse with its picked
-- drawer, Activity with mine), and a no-op must cost nothing.
local function ensureScope(scope)
    local oldKey = state.scope ~= nil and (state.scope.mine and 'mine' or tostring(state.scope.cat)) or '';
    local newKey = scope ~= nil and (scope.mine and 'mine' or tostring(scope.cat)) or '';

    if (oldKey == newKey) then
        return;
    end

    state.scope    = scope;
    state.viewPage = 1;
    state.repaired = false;

    startSync();
end

-----------------------------------
-- Record parsing
-----------------------------------

local function split(text, sep)
    local out = {};

    for piece in string.gmatch(text .. sep, '(.-)' .. sep) do
        out[#out + 1] = piece;
    end

    return out;
end

--[[
* A NUMBER OFF THE WIRE, WHOLE (1.6.0). Every numeric field the server emits
* goes through market_core.lua's own clampInt and `%i`, so they are whole
* today -- but this window's job is to render whatever arrives, and the
* numbers below reach `string.format('%d', ...)` in forty places, several of
* them inside a BeginTable. A fraction there truncates silently under the
* client's LuaJIT (the window then SENDS a price the player never saw) and
* raises under any other Lua -- and a raise mid-table skips the EndTable and
* leaves ImGui's stack unbalanced for the frame. Floored once where it
* enters instead of guarded at every use. nan fails its own equality; inf
* fails the bound.
*
* THE GENERATION IS NOT PARSED THROUGH THIS: it is a microsecond stamp near
* 1.8e15, it is only ever compared, and clamping it would break the
* staleness test that keeps the window honest.
--]]
local WIRE_MAX = 1e12;

local function wireInt(text, fallback)
    local value = tonumber(text);

    if (value == nil or value ~= value or value < -WIRE_MAX or value > WIRE_MAX) then
        return fallback;
    end

    return math.floor(value);
end

-- `<ref>:<itemid>:<stk>:<price>:<flags>:<mine>:<seller>:<cat>,...` -- cat
-- is the retail-AH drawer, appended 1.1.0; a seven-field entry from an
-- older server reads cat 0, which files under Misc. (the server's own fold).
local function parseListings(packed)
    state.modelRev = state.modelRev + 1;

    for _, entry in ipairs(split(packed, ',')) do
        local bits = split(entry, ':');

        if (#bits >= 7) then
            local ref = bits[1];
            local src = ref:sub(1, 1);
            local id  = wireInt(ref:sub(2), 0);

            if ((src == 'a' or src == 'm') and id > 0) then
                -- Upsert by ref: a row from a delta replaces the row a page
                -- walk put there, and the two can never disagree.
                state.listings[ref] = {
                    ref    = ref,
                    src    = src,
                    id     = id,
                    itemid = wireInt(bits[2], 0),
                    stack  = wireInt(bits[3], 0),
                    price  = wireInt(bits[4], 0),
                    flags  = wireInt(bits[5], 0),
                    mine   = wireInt(bits[6], 0) == 1,
                    seller = bits[7] or '?',
                    cat    = wireInt(bits[8], 0),
                };
            end
        end
    end
end

-- `<id>:<itemid>:<stk>:<qty>:<price>:<mine>:<owner>,...`
local function parseOrders(packed)
    state.modelRev = state.modelRev + 1;

    for _, entry in ipairs(split(packed, ',')) do
        local bits = split(entry, ':');

        if (#bits >= 7) then
            local id = wireInt(bits[1], 0);

            if (id > 0) then
                -- A patch row may not re-carry the item (a fill response
                -- names only what changed, itemid 0): keep what the sweep
                -- knew rather than forgetting it under the upsert.
                local itemid   = wireInt(bits[2], 0);
                local existing = state.orderRows[id];

                if (itemid == 0 and existing ~= nil) then
                    itemid = existing.itemid;
                end

                state.orderRows[id] = {
                    id     = id,
                    itemid = itemid,
                    stack  = wireInt(bits[3], 0),
                    qty    = wireInt(bits[4], 0),
                    price  = wireInt(bits[5], 0),
                    mine   = wireInt(bits[6], 0) == 1,
                    owner  = bits[7] or '?',
                };
            end
        end
    end
end

-- `r|<ref>,...` -- listings by lane letter, orders by 'o'. An unknown prefix
-- is ignored: an older addon against a newer server must shrug, not throw.
local function parseRemoved(packed)
    state.modelRev = state.modelRev + 1;

    for _, ref in ipairs(split(packed, ',')) do
        local prefix = ref:sub(1, 1);

        if (prefix == 'a' or prefix == 'm') then
            state.listings[ref] = nil;

            -- ...and any question that was still being asked ABOUT it
            -- (1.6.0). A Buy confirm names a ref; once the server says that
            -- ref is gone -- somebody was faster, the owner cancelled -- the
            -- question on screen has no answer left, and Confirm could only
            -- earn a refusal for a row the window had already been told
            -- about.
            if (state.confirmBuy ~= nil and state.confirmBuy.ref == ref) then
                state.confirmBuy = nil;
            end
        elseif (prefix == 'o') then
            local id = wireInt(ref:sub(2), 0);

            if (id > 0) then
                state.orderRows[id] = nil;

                if (state.confirmFill ~= nil and state.confirmFill.id == id) then
                    state.confirmFill = nil;
                end
            end
        end
    end
end

-- `y|<price>:<date>:<stk>:<seller>:<buyer>[:<seeded>]` -- one per record,
-- built ASIDE in `arriving` and committed at z|. The seeded tail (1.4.0,
-- server 2026-09-02) marks the retired bot's placeholder row; a five-field
-- record from an older server reads as a real sale, which is what it
-- always was to that server.
-- The server sends ten rows at most (market_store.cpp's kHistoryRows), and
-- this cap is the bound the house rule asks of any table that grows on
-- events: an envelope that carried thousands would otherwise build a list
-- this window then tried to draw.
local HISTORY_ROWS_MAX = 64;

local function parseHistory(line)
    local bits = split(line:sub(3), ':');

    if (#bits >= 5 and state.arriving ~= nil and #state.arriving < HISTORY_ROWS_MAX) then
        state.arriving[#state.arriving + 1] = {
            price  = wireInt(bits[1], 0),
            date   = wireInt(bits[2], 0),
            stack  = wireInt(bits[3], 0),
            seller = bits[4] or '?',
            buyer  = bits[5] or '?',
            seeded = wireInt(bits[6], 0) == 1,
        };
    end
end

-- Which item an arriving history answer is about. The i| record names it
-- outright (server 2026-09-02); without one -- an older server -- the
-- oldest unanswered ask is the answer's owner, because the queue drains in
-- order and history is never retried. Asks older than the answer window
-- are dropped first: a line the client's rate limit ate must not shift
-- every answer after it onto the wrong item for the rest of the session.
local HISTORY_ASK_TTL = 15.0;

-- The ask list is pruned on the way IN as well as on the way out (1.6.0):
-- a server that never answers meant `asked` only ever grew, one entry per
-- item the mouse rested on, for the life of the session (the house rule --
-- a table that grows on events owes a bound or a prune).
local function pruneAsks()
    local now  = os.clock();
    local kept = {};

    for _, ask in ipairs(state.asked) do
        if (now - ask.at <= HISTORY_ASK_TTL) then
            kept[#kept + 1] = ask;
        end
    end

    state.asked = kept;
end

local function routeHistoryAnswer()
    pruneAsks();

    if (state.arrivingItem ~= nil) then
        -- Named: take that ask off the list wherever it sits.
        for index, ask in ipairs(state.asked) do
            if (ask.itemid == state.arrivingItem) then
                table.remove(state.asked, index);

                break;
            end
        end

        return state.arrivingItem;
    end

    local head = table.remove(state.asked, 1);

    if (head ~= nil) then
        return head.itemid;
    end

    return state.history.itemid;
end

--[[
* How many items' sale lists the session keeps. Hovering a column of History
* buttons adds one per item and nothing ever dropped one: the cache is the
* one table here whose size is the player's own mouse. Sixty-four is far
* more than a comparison needs and small enough to be free; the oldest goes
* when a new one arrives (1.6.0).
--]]
local HISTORY_CACHE_MAX = 64;

local function pruneHistoryCache()
    local count    = 0;
    local oldestId = nil;
    local oldestAt = nil;

    for id, entry in pairs(state.historyCache) do
        count = count + 1;

        if (oldestAt == nil or entry.at < oldestAt) then
            oldestAt = entry.at;
            oldestId = id;
        end
    end

    -- One per commit, and a commit adds one: the table cannot drift above
    -- the cap, and the walk stays a single pass.
    if (count > HISTORY_CACHE_MAX and oldestId ~= nil) then
        state.historyCache[oldestId] = nil;
    end
end

-- Commit an arrived history list: into the cache always, into the tab when
-- it is the item the tab is showing.
local function commitHistory(itemId, rows)
    if (itemId == nil) then
        return;
    end

    state.historyCache[itemId] = { rows = rows, at = os.clock() };

    pruneHistoryCache();

    if (itemId == state.history.itemid) then
        state.history.rows      = rows;
        state.history.pendingAt = nil;
    end
end

local MUTATION_VERBS = {
    sell        = true,
    buy         = true,
    cancel      = true,
    order       = true,
    fill        = true,
    cancelorder = true,
    claim       = true,
    collect     = true,
};

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], 0);

        if (version ~= PROTOCOL) then
            setStatus(string.format('Server protocol %d, addon expects %d. Update dwah.', version, PROTOCOL), true, true);

            state.protocolBad = true;
            state.inbound     = nil;

            -- AND THE PENDING ASKS GO WITH IT (1.6.0, the suite's protocol
            -- rule). pumpQueue already parks every line, but the answer
            -- clock kept running against asks that had left before the
            -- mismatch: five seconds later it re-armed them, five after
            -- that it declared the server silent and overwrote the one
            -- accurate sentence on screen -- "Update dwah" replaced by
            -- "The server is not answering", about a server that had just
            -- answered. Retire the asks and stand the sweeps down; the
            -- driver in d3d_present will not restart them while the latch
            -- is up, and a login clears the latch.
            forget();

            state.syncing        = false;
            state.nextPage       = nil;
            state.ordersSyncing  = false;
            state.ordersNextPage = nil;
            state.collectLeft    = 0;
            state.collectPending = false;

            return;
        end

        state.inbound        = parts[3];
        state.inboundAt      = os.clock();
        state.serverSilent   = false;
        state.envelopeFailed = false;

        -- The server just spoke: any ask the silence latch declared dead
        -- gets a fresh clock and re-asks by itself, so the sweep a backlog
        -- killed resumes the moment ANY answer proves the road open --
        -- typically the mutation the player pushed through the latch
        -- (2026-08-20). The stale silence sentence goes with it.
        for _, asked in pairs(requested) do
            if (type(asked) == 'table' and not asked.answered and asked.tries >= ANSWER_TRIES) then
                asked.tries = 0;
                asked.at    = os.clock() - ANSWER_TIMEOUT;
            end
        end

        if (state.status == SILENCE_STATUS) then
            clearStatus();
        end

        -- A history answer builds ASIDE (1.4.0) and commits at z|, so the
        -- tab never shows a half-arrived list and an answer for a hovered
        -- button never blanks the tab's own item. Started here, BEFORE
        -- anything below can throw (handleRecord runs under pcall).
        if (state.inbound == 'history') then
            state.arriving     = {};
            state.arrivingItem = nil;
        end

        answered(state.inbound);

        return;
    end

    -- Status and refusals are accepted whatever the envelope state: the
    -- sentence saying why a buy was refused is worth more than the response
    -- it arrived with.
    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        -- The quotes verb's latch (1.5.0): 'unknown verb "quotes"' is an
        -- older core, 'no quotes verb' a newer core over an older binary.
        -- Either way the Sell tab stops asking and draws no QuickSell.
        --
        -- IT RETURNS BEFORE THE BANNER AND THE CHAT LINE (fixed 1.6.0, the
        -- dwbags latch shape, dwbags.lua:1428-1487). This sentence is the
        -- one refusal that is not worth showing anybody: it says the server
        -- is older than a feature the addon offered on its own, which is a
        -- deployment order the player did not choose and cannot fix. Shown,
        -- it was a red chat line AND a red status banner that never cleared
        -- -- for a capability that simply is not there.
        if (kind == 'e' and (text:find('unknown verb "quotes"', 1, true) ~= nil
                or text:find('no quotes verb', 1, true) ~= nil)) then
            state.noQuotes    = true;
            state.quickSell   = nil;
            state.quotesBatch = nil;

            return;
        end

        --[[
            A refused COLLECT ends the drain (1.6.0). The commonest refusal
            here is a full bag, and the box can hold more rows than the bag
            has cells: the old burst queued one collect per row and every
            one past the last free cell came back refused, each printing its
            own red chat line. One refusal is the answer for all of them.
        ]]
        if (kind == 'e' and state.inbound == 'collect') then
            state.collectLeft    = 0;
            state.collectPending = false;
        end

        setStatus(text, kind == 'e', false);

        -- A refusal inside an envelope marks it failed: the z| reconcile
        -- must not stamp the model current off a mutation that did nothing.
        if (kind == 'e' and state.inbound ~= nil) then
            state.envelopeFailed = true;
        end

        if (kind == 'e') then
            print(chat.header('dwah'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'h') then
        limits.fee      = wireInt(parts[3], limits.fee);
        limits.bounty   = wireInt(parts[4], limits.bounty);
        limits.cap      = wireInt(parts[5], limits.cap);
        limits.ordercap = wireInt(parts[6], limits.ordercap);

        return;
    end

    if (kind == 'k') then
        state.mine    = wireInt(parts[2], 0);
        state.cap     = wireInt(parts[3], state.cap);
        state.wallet  = wireInt(parts[4], 0);
        state.orders  = wireInt(parts[5], 0);
        state.boxrows = wireInt(parts[6], 0);

        state.gen = tonumber(parts[7]) or 0;

        -- The first generation a sweep sees is the one that sweep is OF.
        -- Everything else about generations is decided at z|, where success
        -- and failure can be told apart.
        if (state.syncing and state.syncGen == nil) then
            state.syncGen = state.gen;
        end

        return;
    end

    if (kind == 'l') then
        parseListings(line:sub(3));

        return;
    end

    if (kind == 'o') then
        parseOrders(line:sub(3));

        return;
    end

    if (kind == 'r') then
        parseRemoved(line:sub(3));

        return;
    end

    if (kind == 'y') then
        parseHistory(line);

        return;
    end

    -- u| -- quick quotes (1.5.0, server 2026-09-02; ADDITIVE, protocol still
    -- 1): `itemid:avgSingle:nSingles:avgStack:nStacks,...`. Keyed by item,
    -- so the answer needs no routing -- whichever ask carried the id.
    if (kind == 'u') then
        for _, entry in ipairs(split(line:sub(3), ',')) do
            local bits   = split(entry, ':');
            local itemId = wireInt(bits[1], 0);

            if (itemId > 0 and #bits >= 5) then
                state.quotes[itemId] = {
                    single  = wireInt(bits[2], 0),
                    singles = wireInt(bits[3], 0),
                    stack   = wireInt(bits[4], 0),
                    stacks  = wireInt(bits[5], 0),
                };
            end
        end

        return;
    end

    -- i| -- which item the history answer is OF (1.4.0, server 2026-09-02;
    -- ADDITIVE, protocol still 1). Read only inside a history envelope.
    if (kind == 'i') then
        if (state.inbound == 'history') then
            state.arrivingItem = wireInt(parts[2], nil);
        end

        return;
    end

    if (kind == 'q') then
        local page  = wireInt(parts[2], 0);
        local pages = wireInt(parts[3], 1);
        local total = wireInt(parts[4], 0);
        local qcat  = wireInt(parts[5], nil);

        if (state.inbound == 'page') then
            -- A page of a drawer this window is no longer sweeping -- the
            -- player switched drawers while an answer was in flight -- must
            -- not steer THIS sweep's walk or totals. An old server sends no
            -- tail and is believed as-is.
            if (qcat ~= nil and qcat ~= scopeCat()) then
                return;
            end

            state.pages = pages;
            state.total = total;

            if (state.syncing) then
                if (page + 1 < pages) then
                    state.nextPage = page + 1;
                else
                    state.nextPage = nil;
                end
            end
        elseif (state.inbound == 'orders') then
            if (state.ordersSyncing) then
                if (page + 1 < pages) then
                    state.ordersNextPage = page + 1;
                else
                    state.ordersNextPage = nil;
                end
            end
        end

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;
        local failed = state.envelopeFailed;

        state.inbound        = nil;
        state.envelopeFailed = false;

        -- A closed history envelope commits the list it built aside --
        -- routed to the item it was about -- and ends the tab's loading
        -- line when it was the tab's own ask. A refused ask commits an
        -- empty list, which is the honest answer for it.
        if (closed == 'history') then
            local itemId = routeHistoryAnswer();
            local rows   = state.arriving or {};

            state.arriving     = nil;
            state.arrivingItem = nil;

            commitHistory(itemId, rows);

            if (itemId ~= state.history.itemid and #state.asked == 0) then
                state.history.pendingAt = nil;
            end
        end

        --[[
            A CLOSED QUOTES ENVELOPE ANSWERS FOR EVERY ID IT CARRIED (1.6.0).
            The store writes a row per id asked, including a zero row for an
            item nobody has sold -- but a truncated line or an older store
            can drop one, and `quotesAsked` had already spoken for it, so the
            cell read '...' for the rest of the session and no re-ask was
            ever going to come. Whatever the answer did not name is written
            down as the honest 'no sales yet' here.
        ]]
        if (closed == 'quotes' and state.quotesBatch ~= nil) then
            for _, itemId in ipairs(state.quotesBatch.ids) do
                if (state.quotes[itemId] == nil) then
                    state.quotes[itemId] = { single = 0, singles = 0, stack = 0, stacks = 0 };
                end
            end

            state.quotesBatch = nil;
        end

        if (closed == 'page' and state.syncing and state.nextPage == nil) then
            state.syncing = false;

            verifySweep();
        end

        if (closed == 'orders' and state.ordersSyncing and state.ordersNextPage == nil) then
            state.ordersSyncing = false;
        end

        -- The collect that was in flight has landed, refused or not: the
        -- refusal branch has already zeroed collectLeft if it was one.
        if (closed == 'collect') then
            state.collectPending = false;
        end


        -- A SUCCESSFUL mutation patched the model in the same envelope
        -- (r|/l|/o| rode it), so the model is current at the new generation.
        if (MUTATION_VERBS[closed] and not failed) then
            state.syncGen = state.gen;
        end

        -- THE RECONCILE. Any closed envelope whose generation disagrees
        -- with the model's -- a refused buy (the row sold under the click,
        -- 2026-08-19), a hello fired on window-open after a counter sale,
        -- a history ask that happened to carry fresher numbers -- re-sweeps
        -- once per generation value. resyncFor is the loop guard: the sweep
        -- itself closes envelopes, and a sweep that re-triggered on its own
        -- traffic would never land.
        if (not state.syncing and not state.ordersSyncing
                and state.syncGen ~= nil and state.gen ~= state.syncGen
                and state.resyncFor ~= state.gen) then
            state.resyncFor = state.gen;
            setStatus((state.status ~= nil and (state.status .. '  ') or '') .. 'The market moved -- re-syncing.', false, false);

            startSync();
            startOrdersSync();
        end

        return;
    end

    -- An unknown kind from a newer server: ignored, never an error.
end

-----------------------------------
-- Sorting and filtering, all local (the whole point of the full sync)
-----------------------------------

local SORT_LABELS = { 'Level', 'Price', 'Name', 'Newest' };

--[[
* THE REMEMBERED VIEW (1.6.0), the dwwarehouse 1.9.0 shape. Which drawer the
* player was in, how the rows were sorted and whether the Mine tick was on
* are chrome, not world state -- the server hears nothing about any of it --
* and re-picking them through two combos on every login was the one bit of
* this window that felt like paperwork. One level of nesting with scalar
* leaves, which is the shape the settings serializer is known to round-trip
* (dwmacro.lua:270-296).
*
* THE LOAD IS PCALL'd, unlike its siblings': `config\addons\dwah\*.lua` is a
* text file a player can edit, and a settings file that fails to parse must
* cost a remembered drawer, never the whole window.
--]]
local default_settings = T{
    view = T{
        sort   = 1,
        top    = 0,
        sub    = 0,
        onlyMine = false,
    },
};

local okSettings, config = pcall(settings.load, default_settings);

if (not okSettings or type(config) ~= 'table') then
    print(chat.header('dwah'):append(chat.error('settings would not load -- starting from the shipped defaults.')));

    config = default_settings;
end

-- Every field is clamped on the way in: a sort index past the table would
-- index nil sixty times a second, and a drawer index past CATEGORIES would
-- take the whole tab down with it.
local function applyView()
    local view = type(config.view) == 'table' and config.view or {};

    local sort = math.floor(tonumber(view.sort) or 1);
    local top  = math.floor(tonumber(view.top) or 0);
    local sub  = math.floor(tonumber(view.sub) or 0);

    state.sortMode    = (sort >= 1 and sort <= #SORT_LABELS) and sort or 1;
    state.onlyMine[1] = view.onlyMine == true;

    if (top >= 1 and top <= #CATEGORIES) then
        state.catTop = top;

        local subs = CATEGORIES[top].subs;

        if (subs ~= nil and sub >= 1 and sub <= #subs) then
            state.catSub = sub;
        end
    end
end

-- Called on a change, never per frame: settings.save writes a file.
local function saveView()
    if (type(config.view) ~= 'table') then
        config.view = T{};
    end

    config.view.sort     = state.sortMode;
    config.view.top      = state.catTop or 0;
    config.view.sub      = state.catSub or 0;
    config.view.onlyMine = state.onlyMine[1] and true or false;

    pcall(settings.save);
end

applyView();

settings.register('settings', 'dwah_settings_update', function (s)
    if (s ~= nil) then
        config = s;

        applyView();
    end

    pcall(settings.save);
end);

--[[
* THE VIEW CACHE (1.6.0). Everything below -- the scope filter, the search,
* the sort, the row labels and the price summary -- is a pure function of
* the model, the search text, the sort mode, the Mine tick and the scope. It
* was recomputed EVERY FRAME: a walk of the whole drawer with a DAT lookup
* per row for the search, then a table.sort whose comparator asks for two
* names (or two levels and two names) per comparison. A two-thousand-row
* drawer is roughly 22,000 comparisons; at sixty frames a second that is
* over a million DAT lookups a second for a list that had not changed.
*
* Keyed on `modelRev|search|sort|mine|scope` -- so the answer is rebuilt on
* the frame something actually moves and read straight off the shelf on
* every other one. The cached table is HANDED OUT, not copied: nothing
* downstream mutates the list itself (labels are written onto the ROWS, and
* a row object is replaced wholesale by its next upsert).
--]]
local viewCache = { key = nil, rows = nil, summary = nil };

local function listingSummary()
    return viewCache.summary;
end

-- Which find box applies to the scope being drawn: Browse's, or the
-- Activity tab's own (1.6.0).
local function activeNeedle()
    if (state.scope ~= nil and state.scope.mine) then
        return state.mineFind[1] or '';
    end

    return state.search[1] or '';
end

local function buildListings()
    local rows = {};

    local needle = activeNeedle():lower();

    for _, row in pairs(state.listings) do
        -- Scope first: a row a mutation patched in from another drawer is
        -- held for the model's bookkeeping but never drawn off scope.
        local keep = scopeMatches(row);

        if (keep and state.onlyMine[1] and not row.mine) then
            keep = false;
        end

        if (keep and #needle > 0) then
            keep = itemName(row.itemid):lower():find(needle, 1, true) ~= nil;
        end

        if (keep) then
            rows[#rows + 1] = row;
        end
    end

    local mode = state.sortMode;

    table.sort(rows, function(a, b)
        if (mode == 2) then
            if (a.price ~= b.price) then
                return a.price < b.price;
            end
        elseif (mode == 3) then
            local an, bn = itemName(a.itemid), itemName(b.itemid);

            if (an ~= bn) then
                return an < bn;
            end
        elseif (mode == 4) then
            if (a.id ~= b.id) then
                return a.id > b.id;
            end
        else
            -- The server default (D8): item level, descending; ties by name
            -- so the list is stable under the eye.
            local al, bl = levelOf(a.itemid), levelOf(b.itemid);

            if (al ~= bl) then
                return al > bl;
            end

            local an, bn = itemName(a.itemid), itemName(b.itemid);

            if (an ~= bn) then
                return an < bn;
            end
        end

        -- The final tiebreak is the ref, so equal rows never flicker.
        return a.ref < b.ref;
    end);

    -- The row label and the price summary, built HERE rather than in the
    -- table below: three string concatenations per row per frame was the
    -- other half of the same waste, and the summary line the Browse tab
    -- draws (1.6.0) is one pass over a list already in hand.
    local low, high, sum = nil, nil, 0;

    for _, row in ipairs(rows) do
        row.label = itemName(row.itemid)
            .. (row.stack == 1 and ' (stack)' or '')
            .. (bit.band(row.flags, L_EXDATA) ~= 0 and ' (signed)' or '');

        low  = math.min(low or row.price, row.price);
        high = math.max(high or row.price, row.price);
        sum  = sum + row.price;
    end

    return rows, { count = #rows, low = low, high = high, sum = sum };
end

local function sortedListings()
    local key = string.format('%d|%s|%d|%s|%s',
        state.modelRev,
        activeNeedle(),
        state.sortMode,
        state.onlyMine[1] and '1' or '0',
        scopeKey());

    if (viewCache.key ~= key or viewCache.rows == nil) then
        viewCache.rows, viewCache.summary = buildListings();
        viewCache.key = key;
    end

    return viewCache.rows;
end

-- The order board, cached against the same revision: it is short (one page
-- of the server's own list) but the labels below are not free either.
local ordersCache = { key = nil, rows = nil };

local function sortedOrders()
    local key = tostring(state.modelRev);

    if (ordersCache.key == key and ordersCache.rows ~= nil) then
        return ordersCache.rows;
    end

    local rows = {};

    for _, row in pairs(state.orderRows) do
        rows[#rows + 1] = row;
    end

    table.sort(rows, function(a, b)
        if (a.mine ~= b.mine) then
            return a.mine;
        end

        return a.id > b.id;
    end);

    for _, row in ipairs(rows) do
        row.label = itemName(row.itemid) .. (row.stack == 1 and ' (stacks)' or '');
    end

    ordersCache.key  = key;
    ordersCache.rows = rows;

    return rows;
end

-----------------------------------
-- Bag reading (the Sell tab's source of truth is the client's own memory;
-- the server re-reads the slot before anything moves)
-----------------------------------

--[[
* The bag, read straight out of the client's own memory on the frame it is
* wanted. NOT CACHED, and that is a decision rather than an omission (looked
* at again 1.6.0): GetContainerItem is a pointer read into the mapped
* inventory, not a DAT search, and exactly one tab's body runs per frame --
* so a cache would buy a pointer read and pay for it in staleness against
* the one table in this window that is the player's own hand. What WAS worth
* fixing is the order board asking eighty times over (see bagIndex).
--]]
local function bagRows()
    local rows = {};

    -- The memory manager answers nil before the client has a character --
    -- this addon loads from the launcher's boot script, long before the
    -- login screen, and the Sell tab can be rendered from the very first
    -- frame the window is opened (1.6.0). An empty bag is the honest
    -- reading of "there is no character yet".
    local memory = AshitaCore:GetMemoryManager();

    if (memory == nil) then
        return rows;
    end

    local inventory = memory:GetInventory();

    if (inventory == nil) then
        return rows;
    end

    for slot = 1, INVENTORY_SLOTS do
        local entry = inventory:GetContainerItem(INVENTORY_CONTAINER, slot);

        if (entry ~= nil and entry.Id > 0 and entry.Id < 65535 and entry.Count > 0) then
            rows[#rows + 1] = {
                slot   = slot,
                itemid = entry.Id,
                count  = entry.Count,
                -- The raw exdata bytes, kept for the hover card's augment
                -- lines (1.3.0). Nothing else reads them and nothing sends
                -- them anywhere.
                extra  = entry.Extra,
            };
        end
    end

    return rows;
end

--[[
* The bag indexed by item id, ONE WALK (1.6.0). The order board used to call
* slotHolding per row, and slotHolding re-read all eighty inventory cells
* through the memory manager -- so a board of twenty orders was sixteen
* hundred GetContainerItem calls a frame, sixty times a second, to answer a
* question about a bag that had not changed.
*
* It also answers the question the old one got WRONG. A stack order fills
* one FULL stack per call from a cell holding exactly the stack size (the
* native rule, market_store.cpp DwMarketOrderFill), and slotHolding returned
* the FIRST cell holding the item -- so a player with three Copper Ore in
* one cell and a full twelve in another was offered Fill, and the server
* truthfully refused it. `fullSlot` is the cell a stack order can actually
* be filled from, and the board says so when there is none.
--]]
local function bagIndex()
    local index = {};

    for _, row in ipairs(bagRows()) do
        local entry = index[row.itemid];

        if (entry == nil) then
            entry = { slot = row.slot, count = row.count, fullSlot = nil };

            index[row.itemid] = entry;
        elseif (row.count > entry.count) then
            -- The fullest ordinary cell: a fill takes as many units as one
            -- cell holds, so the deepest one is the most useful offer.
            entry.slot  = row.slot;
            entry.count = row.count;
        end

        if (entry.fullSlot == nil) then
            local stackSize = stackSizeOf(row.itemid);

            if (stackSize > 1 and row.count == stackSize) then
                entry.fullSlot = row.slot;
            end
        end
    end

    return index;
end

--[[
* Resolve the order form's text to an item id: a number is an id, anything
* else is asked of the client's own resource manager by name.
*
* MEMOISED (1.6.0), because both callers -- the order form and the History
* tab's lookup box -- run this on EVERY FRAME against text that changes only
* when the player types. The name path is two GetItemByName sweeps of the
* whole item DAT, under pcall, so it was the single most expensive thing
* either tab did per frame. `false` stands in for "no such item" so a miss
* memoises too. Keyed by the text; capped, and dropped on zone-in.
--]]
local RESOLVE_CACHE_MAX = 64;

local resolved      = {};
local resolvedCount = 0;

local function resolveUncached(text)
    local id = tonumber(text);

    -- INTEGRALITY, not just range: `tonumber` reads '2.5' and 'inf' happily,
    -- and an id with a fraction reaches GetItemById and string.format('%d').
    if (id ~= nil and id > 0 and id < 65536 and id == math.floor(id)) then
        return id;
    end

    if (#text < 3) then
        return nil;
    end

    local mgr = AshitaCore:GetResourceManager();

    if (mgr == nil) then
        return nil;
    end

    for _, lang in ipairs({ 0, 2 }) do
        local ok, item = pcall(function()
            return mgr:GetItemByName(text, lang);
        end);

        if (ok and item ~= nil and item.Id ~= nil and item.Id > 0) then
            return item.Id;
        end
    end

    return nil;
end

local function resolveItemText(text)
    local key    = tostring(text);
    local cached = resolved[key];

    if (cached ~= nil) then
        return cached ~= false and cached or nil;
    end

    local id = resolveUncached(key);

    -- The cap: every keystroke of a typed name is its own key, so the table
    -- grows with the typing. Emptied wholesale rather than aged -- the
    -- answers are free to rebuild and nothing here is worth an LRU.
    if (resolvedCount >= RESOLVE_CACHE_MAX) then
        resolved      = {};
        resolvedCount = 0;
    end

    resolved[key] = id or false;
    resolvedCount = resolvedCount + 1;

    return id;
end

-- How long a cached history answer is trusted before a fresh ask goes out:
-- five minutes is well under any price's half-life and well over the time
-- a player spends comparing two rows.
local HISTORY_FRESH = 300.0;

-- How long the History tab waits for an answer before it says the ask was
-- lost rather than that the item has never sold (1.6.0). Longer than the
-- send throttle plus a round trip, shorter than a player's patience.
local HISTORY_WAIT = 6.0;

local function cachedHistory(itemId)
    local entry = state.historyCache[itemId];

    if (entry ~= nil and os.clock() - entry.at <= HISTORY_FRESH) then
        return entry;
    end

    return nil;
end

-- Queue one history line, remembering it as asked (for the routing of the
-- answer). Returns false when the same line already sits in the queue --
-- the queue collapses duplicate queries, so the ask list must not grow a
-- second entry the server will answer only once.
local function queueHistoryAsk(itemId)
    if (not usableItemId(itemId)) then
        return false;
    end

    local command = string.format('!dwa history %d', itemId);

    for _, queued in ipairs(queue) do
        if (queued == command) then
            return false;
        end
    end

    pruneAsks();

    state.asked[#state.asked + 1] = { itemid = itemId, at = os.clock() };

    issue(command);

    return true;
end

-- One history ask, shared by the History tab's lookup box and the History
-- button every listing and order row carries. It is a QUERY on the wire --
-- isQuery already names it -- so the queue collapses duplicate clicks and
-- the silence latch may park it; no gil moves, so no confirm. A fresh
-- cached answer fills the tab at once and asks nothing (1.4.0).
local function askHistory(itemId, focus)
    -- Nothing but a whole item id gets past here (1.6.0): the id reaches
    -- string.format('%d', ...) on the wire and GetItemById in the DAT, and
    -- `/dwah history 2.5` -- an addon or a typist can send anything --
    -- walked into both.
    if (not usableItemId(itemId)) then
        return;
    end

    state.history.itemid = itemId;
    state.history.name   = itemName(itemId);

    -- The recent list: newest first, deduplicated, at most eight. Chips the
    -- History tab redraws, so comparing two items is two clicks, not two
    -- typed names.
    local recent = { itemId };

    for _, known in ipairs(state.history.recent) do
        if (known ~= itemId and #recent < 8) then
            recent[#recent + 1] = known;
        end
    end

    state.history.recent = recent;

    if (focus) then
        -- Three frames of trying: the two spellings of the flagged call and
        -- one plain frame for the tab bar to settle (beginHistoryTab).
        state.historyFocus = 3;
    end

    local cached = cachedHistory(itemId);

    if (cached ~= nil) then
        state.history.rows      = cached.rows;
        state.history.pendingAt = nil;

        return;
    end

    state.history.rows      = {};
    state.history.pendingAt = os.clock();

    queueHistoryAsk(itemId);
end

-- A HOVER ask (1.4.0): the card on a History button wants the sale list
-- without the click. Asked only after the mouse has RESTED on one button
-- for a moment -- a sweep down a column must not fire an ask per row --
-- and only when nothing is cached and no ask for it is in flight. It does
-- not move the tab's own item; the answer lands in the cache alone.
local HOVER_DWELL = 0.35;

local function hoverHistory(itemId)
    local hover = state.hoverAsk;

    --[[
        THE DWELL RESTARTS WHEN THE MOUSE LEAVES (1.6.0). This function runs
        only while the card is on screen, so a gap in the frames it is called
        on IS the mouse having left the button -- and the old code kept the
        first `since` and the `asked` latch across such a gap. Two
        consequences, both wrong in opposite directions: a mouse swept away
        and back onto the same button asked at once (the dwell exists to stop
        exactly that), and once `asked` had latched, resting on the same
        button again -- after the cached answer had aged out -- never asked
        again and the card said "rest here a moment" forever.

        Counted in FRAMES, not seconds: whether the card was drawn on the
        PREVIOUS frame is the exact question, and it does not depend on the
        frame rate the way any time window would.
    ]]
    if (hover ~= nil and hover.itemid == itemId and (hover.seen or 0) < state.frame - 1) then
        hover = nil;
    end

    if (hover == nil or hover.itemid ~= itemId) then
        state.hoverAsk = { itemid = itemId, since = os.clock(), seen = state.frame, asked = false };

        return;
    end

    hover.seen = state.frame;

    if (hover.asked or os.clock() - hover.since < HOVER_DWELL) then
        return;
    end

    hover.asked = true;

    if (cachedHistory(itemId) ~= nil or state.serverSilent) then
        return;
    end

    for _, ask in ipairs(state.asked) do
        if (ask.itemid == itemId) then
            return;
        end
    end

    queueHistoryAsk(itemId);
end

-----------------------------------
-- The window
-----------------------------------

local function gilText(amount)
    -- 1234567 -> 1,234,567: prices are the whole point of this window, and
    -- an ungrouped million is a misread waiting to happen.
    --
    -- FLOORED FIRST (1.6.0, the shape dwwarehouse's copy of this function
    -- already carried): gil is whole, and `tostring` on anything else
    -- produced '2.5' or '1.787e+15' -- a decimal point where the grouping
    -- loop expects digits, so the comma walk grouped the fraction too.
    local text = tostring(math.floor(tonumber(amount) or 0));
    local out  = '';

    while #text > 3 do
        out  = ',' .. text:sub(-3) .. out;
        text = text:sub(1, -4);
    end

    return text .. out;
end

-- 1787180000 -> 'just now' / '2h ago' / '3d ago' / '2026-07-04': sale dates
-- are unix stamps from the server's own clock, and a small skew against the
-- client's is invisible at this grain. A zero -- an ancient row minted
-- before dates were kept -- reads as '?', never as 1970.
local function agoText(epoch)
    if (epoch == nil or epoch <= 0) then
        return '?';
    end

    local delta = os.time() - epoch;

    -- A stamp from the FUTURE is not "just now": it is a row whose date
    -- was written by something other than a sale (the bot's seeds carried
    -- one), and the honest rendering is the date itself. A few minutes of
    -- clock skew between client and server is forgiven.
    if (delta < -300) then
        return os.date('%Y-%m-%d', epoch);
    end

    if (delta < 0) then
        delta = 0;
    end

    if (delta < 60) then
        return 'just now';
    elseif (delta < 3600) then
        return string.format('%dm ago', math.floor(delta / 60));
    elseif (delta < 86400) then
        return string.format('%dh ago', math.floor(delta / 3600));
    elseif (delta < 2592000) then
        return string.format('%dd ago', math.floor(delta / 86400));
    end

    return os.date('%Y-%m-%d', epoch);
end

--[[
* The sale summary over one history list: singles and stacks APART (a
* stack price beside a single price is a twelvefold misread waiting to
* happen), newest first so the first seen of each kind is the latest. A
* list that is ONLY the bot's seeded placeholder says so, because the
* server sends that row exactly when nobody has sold one.
--]]
local function historySummary(rows)
    local singles = { low = nil, high = nil, last = nil };
    local stacks  = { low = nil, high = nil, last = nil };
    local real    = 0;

    for _, row in ipairs(rows) do
        local pot = row.stack == 1 and stacks or singles;

        pot.low  = math.min(pot.low or row.price, row.price);
        pot.high = math.max(pot.high or row.price, row.price);

        if (pot.last == nil) then
            pot.last = row.price;
        end

        if (not row.seeded) then
            real = real + 1;
        end
    end

    return { singles = singles, stacks = stacks, seededOnly = real == 0 and #rows > 0 };
end

--[[
* The history CARD (1.4.0): the sale list as a hover pop-up on every
* History button -- the question "what is this worth" answered without a
* click and without leaving the row. Drawn from the cache; a miss asks
* (after the dwell hoverHistory enforces) and says it is asking. At most
* six rows, because a card is a glance and the tab is the reading.
--]]
local HISTORY_CARD_ROWS = 6;

local function historyCard(itemId)
    hoverHistory(itemId);

    beginTooltip();

    drawIcon(itemId, 24);
    imgui.Text(string.format('Last sales of %s', itemName(itemId)));

    local entry = cachedHistory(itemId);

    if (entry == nil) then
        local pending = false;

        for _, ask in ipairs(state.asked) do
            if (ask.itemid == itemId) then
                pending = true;
            end
        end

        if (pending) then
            imgui.TextDisabled('Asking the server...');
        elseif (state.serverSilent) then
            imgui.TextDisabled('The server is not answering. Click for the tab.');
        else
            imgui.TextDisabled('Rest here a moment, or click for the tab.');
        end

        endTooltip();

        return;
    end

    local rows = entry.rows;

    if (#rows == 0) then
        imgui.TextDisabled('None yet. The first player to sell one earns the pioneer bounty.');
        endTooltip();

        return;
    end

    local summary = historySummary(rows);

    if (summary.seededOnly) then
        imgui.TextColored(theme.colors.warn, 'No player sale yet -- seeded starting price only.');
    end

    if (summary.singles.low ~= nil) then
        imgui.TextDisabled(string.format('Singles: %s to %s, last %s',
            gilText(summary.singles.low), gilText(summary.singles.high), gilText(summary.singles.last)));
    end

    if (summary.stacks.low ~= nil) then
        imgui.TextDisabled(string.format('Stacks: %s to %s, last %s',
            gilText(summary.stacks.low), gilText(summary.stacks.high), gilText(summary.stacks.last)));
    end

    imgui.Separator();

    for index = 1, math.min(#rows, HISTORY_CARD_ROWS) do
        local row = rows[index];

        if (row.seeded) then
            imgui.TextDisabled(string.format('%s%s  seeded', gilText(row.price), row.stack == 1 and ' (stack)' or ''));
        else
            imgui.TextColored(theme.colors.badge, string.format('%s%s', gilText(row.price), row.stack == 1 and ' (stack)' or ''));
            imgui.SameLine();
            imgui.TextDisabled(string.format('%s  %s -> %s', agoText(row.date), row.seller, row.buyer));
        end
    end

    if (#rows > HISTORY_CARD_ROWS) then
        imgui.TextDisabled(string.format('and %d more -- click for the tab', #rows - HISTORY_CARD_ROWS));
    end

    endTooltip();
end

--[[
* Render errors are CONTAINED PER TAB, and imgui.End() runs whatever
* happened. The first live client run threw from inside a tab body (a sol
* signature this file guessed wrong) and the throw skipped End/EndTabBar --
* the DEAR IMGUI assert box over the whole client, sixty times a second.
* Structure, not hope: Begin's End is unconditional, each tab body runs
* under its own pcall inside the BeginTabItem/EndTabItem pair, and a
* repeated error prints once rather than every frame.
--]]
local lastRenderError = nil;

-- One print per DISTINCT message, wherever the throw came from (1.6.0). The
-- outer pcall around renderWindow -- the one that catches a throw from Begin
-- itself, outside every tab's own guard -- printed unconditionally, so a
-- failure there was sixty red chat lines a second: the exact log flood this
-- dedupe exists to prevent, on the one path that was not using it.
local function reportRenderError(err)
    local text = tostring(err);

    if (text ~= lastRenderError) then
        lastRenderError = text;

        print(chat.header('dwah'):append(chat.error(text)));
    end
end

local function guarded(fn)
    local depth   = #openStack;
    local ok, err = pcall(fn);

    if (not ok) then
        -- Back to the depth this body started at, innermost first. Each
        -- closer is itself pcall'd: an End that refuses must not stop the
        -- ones under it from running.
        while (#openStack > depth) do
            local closer = openStack[#openStack];

            openStack[#openStack] = nil;

            pcall(closer);
        end

        reportRenderError(err);
    end
end

--[[
* THE TOOLTIP TABLE (1.6.0). Every control whose meaning is not written on
* its own face gets one short sentence saying what it does -- and, for a
* control that is greyed or missing, why it cannot act now. Kept as a table
* rather than sixty inline literals so the harness can assert the roster and
* so two controls that mean the same thing cannot drift into two sentences.
* The self-evident (Confirm, No) is deliberately absent: a tooltip on a word
* the player just read is noise.
--]]
local TIPS =
{
    listings = 'Listings your ACCOUNT has up, and the cap. Any character on the account can cancel any of them, from anywhere.',
    wallet   = 'What your sales have paid so far. It sits on the account until you claim it, so it survives logging out.',
    claim    = 'Put the wallet on this character now. The server clamps to the gil cap and keeps the rest.',
    box      = 'The market box: what your buy orders were filled with, held for the account because you may have been offline when it happened. A buy goes straight to your bag instead.',
    collect  = 'Empty the market box into your bag, oldest first -- one row every couple of seconds. It stops by itself when the bag is full.',
    refresh  = 'Ask the server again for everything: the account line, this drawer and the order board.',

    category = 'The auction counter\'s own drawers, exactly as the Jeuno menu shelves them. Listings load once you pick a leaf -- loading the whole market at once took minutes.',
    subcat   = 'Which shelf of that drawer. This is the ask the server answers.',
    search   = 'Narrow this drawer to item names containing what you type. Local: the server is not asked again.',
    clear    = 'Clear the find box.',
    sort     = 'How the rows below are ordered. Level is the server\'s own default: item level highest first, ties by name.',
    mine     = 'Show only the listings your account put up in this drawer.',

    buy      = 'Buy at the price shown. Nothing moves until you confirm, and the server is held to that exact price.',
    cancel   = 'Take this listing off the market. It comes back to THIS character\'s bag, wherever it was listed.',
    history  = 'What this item has actually sold for. Free and confirm-less: rest here for the card, click for the whole table.',
    pager    = 'The screen holds fifty rows at a time; this walks the sorted list. The search covers all of it, not just this page.',

    sell     = 'Name a price and list it -- a single, or the whole stack. Listing costs nothing.',
    sellfind = 'Narrow your bag to items whose name contains what you type.',
    minefind = 'Narrow your own listings to names containing what you type. This tab keeps its own box; the Browse tab has a separate one.',
    orderfind = 'Narrow the board to orders for items whose name contains what you type. The board carries everybody\'s orders, so it can be long.',
    noquote  = 'Nobody has sold one of these yet, so there is no average to quick-sell at. Name your own price with Sell -- the first sale of an item pays the pioneer bounty.',

    orderitem  = 'What you want bought for you: an item name the client knows, or its id.',
    orderqty   = 'How many units the order wants, 1 to 99.',
    orderprice = 'What you pay per unit. The whole amount is escrowed when you post, and refunded if you cancel.',
    orderstack = 'Ask for whole stacks: each unit filled is one full stack, and a seller needs a full stack in one bag cell.',
    postorder  = 'Post the order and escrow the gil. It asks once more with the total first.',
    fill       = 'Sell into this order out of your bag at the price it offers. It asks first and names your take after the cut.',
    nonefill   = 'You have none of this in your bag, so there is nothing to fill it with.',
    nostack    = 'This order wants whole stacks, and no single bag cell of yours holds a full one.',
    ownorder   = 'Cancel your order and take the remaining escrow back onto this character.',

    lookup   = 'Look an item up by name or id. Enter does it too.',
    recent   = 'An item you looked up earlier this session. Cached answers redraw with no round trip.',
    seeded   = 'The retired shopkeeper\'s starting price, shown only while nobody has sold one. It is not a sale and nobody paid it.',
};

-- The house tooltip shape: `IsItemHovered` reads the item just drawn, and
-- one short sentence is the whole tooltip (BeginTooltip cards are for items).
local function tip(key)
    local text = TIPS[key];

    if (text ~= nil and imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* CalcTextSize memoised (1.6.0). The measured-column idiom this window uses
* (the dwcraft grid rule: measure exactly what this call renders, so nothing
* can truncate) asks ImGui for the width of every label on the screen, on
* every frame -- fifty rows is a hundred measurements a frame for strings
* that never change. The font is fixed for the life of the window, so the
* answer is asked once. Dropped on zone-in with the other session caches.
*
* THE KEY IS NOT A LABEL, IT IS WIRE DATA (1.8.0). The comment above was
* written for column headings and has been true of none of the callers for a
* while: `textWidth(row.seller)`, `textWidth(row.priceLabel)`,
* `textWidth(row.whenLabel)`, `textWidth(row.buyerLabel)` and the search chips
* all key this table on a string that came off the server -- every seller name,
* every price and every timestamp the player has ever scrolled past. Zone-in was
* the only prune, and a player parked at the auction counter for an hour never
* zones. So it gets the ceiling every other cache in this suite has: dropped
* whole at WIDTH_MAX, which costs one frame of re-measuring and nothing else,
* because CalcTextSize is a pure function of the string and the font.
--]]
local WIDTH_MAX = 4096;

local widths      = {};
local widthsCount = 0;

local function textWidth(text)
    local key    = tostring(text);
    local cached = widths[key];

    if (cached == nil) then
        if (widthsCount >= WIDTH_MAX) then
            widths      = {};
            widthsCount = 0;
        end

        cached = (imgui.CalcTextSize(key));

        widths[key] = cached;
        widthsCount = widthsCount + 1;
    end

    return cached;
end

local function headerStrip()
    --[[
        REFRESH IS FIRST, and that is a position rather than a preference
        (1.6.0). It used to sit at the END of one SameLine chain whose every
        earlier element changes width with the numbers in it -- 'Listings 1 /
        200' against 'Listings 137 / 200', 'Wallet 0 gil' against 'Wallet
        9,500,000 gil', a Claim button that appears with the wallet, a Collect
        that becomes 'Collecting (39 left)  [Stop]' the instant it is pressed.
        The one button in this strip a player reaches for over and over was
        the one that never stood still. At the left it is pinned to the window
        padding and cannot move at all.
    ]]
    if (imgui.Button('Refresh##all')) then
        refreshAll();
    end

    tip('refresh');

    imgui.SameLine();
    imgui.Text(string.format('Listings %d / %d', state.mine, state.cap));
    tip('listings');
    imgui.SameLine();
    imgui.TextDisabled('|');
    imgui.SameLine();
    imgui.TextColored(theme.colors.ok, string.format('Wallet %s gil', gilText(state.wallet)));
    tip('wallet');

    if (state.wallet > 0) then
        imgui.SameLine();

        if (imgui.Button('Claim##wallet')) then
            issue('!dwa claim');
        end

        tip('claim');
    end

    imgui.SameLine();
    imgui.TextDisabled('|');
    imgui.SameLine();
    imgui.Text(string.format('Box %d', state.boxrows));
    tip('box');

    if (state.boxrows > 0) then
        imgui.SameLine();

        --[[
            THE DRAIN, not a burst (1.6.0). This used to queue one
            `!dwa collect` per box row on the press: a box of forty parked
            the shared send queue for forty-eight seconds -- the drawer
            sweep, the history asks and the quotes all waited behind it --
            and every row past the free space in the bag came back a refusal
            that printed its own red chat line. `collectLeft` is the
            ceiling; the driver in d3d_present sends one at a time and the
            refusal branch in handleRecord ends the drain.
        ]]
        if (state.collectLeft > 0) then
            imgui.TextDisabled(string.format('Collecting (%d left)', state.collectLeft));

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Taking the box one row at a time so the rest of the window keeps working. Press Stop to leave the rest.');
            end

            imgui.SameLine();

            if (imgui.Button('Stop##box')) then
                state.collectLeft = 0;
            end
        else
            local pressed = imgui.Button(string.format('Collect (%d)##box', state.boxrows));

            tip('collect');

            if (pressed) then
                state.collectLeft = math.min(state.boxrows, COLLECT_MAX);
                state.collectAt   = 0;
            end
        end
    end

    if (state.syncing) then
        -- The page walk's own progress (1.6.0). `state.pages` is what the
        -- `q|` record has always said and nothing on screen used it -- and
        -- on a deep drawer the row count alone leaves the player watching a
        -- number crawl with no idea how far it has to go. nextPage is the
        -- page about to be ASKED FOR and is zero-based; nil means the sweep
        -- is on its last one.
        local page = state.nextPage ~= nil and (state.nextPage + 1) or state.pages;

        imgui.TextDisabled(string.format('Loading %s -- %d of %d (page %d of %d)...',
            state.scope ~= nil and state.scope.label or 'listings',
            listingCount(), math.max(state.total, listingCount()),
            math.min(math.max(page, 1), state.pages), state.pages));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('The drawer is swept one page at a time, one line every 1.2 seconds -- the whole window shares that budget with every other Driftwood addon.');
        end
    end

    if (state.status ~= nil) then
        -- An event's sentence fades; a condition's stays (see the state
        -- comment). Dropped here rather than on a timer of its own: the
        -- header is the only thing that reads it.
        if (not state.statusSticky and (os.time() - state.statusAt) > STATUS_LINGER) then
            clearStatus();
        else
            imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.hint, state.status);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(state.statusSticky
                    and 'The window is telling you about something that is still true. It clears when it is answered.'
                    or 'The last thing the server said about a market action. It clears itself after half a minute.');
            end
        end
    end

    imgui.Separator();
end

-- Draws the pager strip and returns the slice of the sorted rows the current
-- view page holds. The MODEL may hold a whole drawer; the SCREEN holds at
-- most VIEW_ROWS of it -- thousands of rows in one BeginTable, every frame,
-- was the client's fps sink (2026-08-20).
local VIEW_ROWS = 50;

local function pagedRows(rows, tag, current)
    -- `tag` names the pager so two boards can each keep their own place --
    -- the order board grew one in 1.6.0. It DEFAULTS to 'view', which is
    -- what the listing pager's button ids have always been.
    tag     = tag or 'view';
    current = current or 1;

    if (#rows <= VIEW_ROWS) then
        return rows, 1;
    end

    local pages = math.ceil(#rows / VIEW_ROWS);

    if (current > pages) then
        current = pages;
    end

    -- The two walk buttons are greyed at the ends rather than left live and
    -- inert (1.6.0): a button that does nothing when pressed reads as a
    -- window that has stopped listening. BeginDisabled/EndDisabled always
    -- pair, on every path.
    local atFirst = current <= 1;
    local atLast  = current >= pages;

    imgui.BeginDisabled(atFirst);

    if (imgui.Button('<##dwah_' .. tag .. 'prev') and not atFirst) then
        current = math.max(1, current - 1);
    end

    imgui.EndDisabled();
    tip('pager');

    imgui.SameLine();
    imgui.Text(string.format('Page %d / %d (%d items)', current, pages, #rows));
    tip('pager');
    imgui.SameLine();

    imgui.BeginDisabled(atLast);

    if (imgui.Button('>##dwah_' .. tag .. 'next') and not atLast) then
        current = math.min(pages, current + 1);
    end

    imgui.EndDisabled();
    tip('pager');

    local out   = {};
    local first = (current - 1) * VIEW_ROWS;

    for index = first + 1, math.min(first + VIEW_ROWS, #rows) do
        out[#out + 1] = rows[index];
    end

    return out, current;
end

--[[
* One listings table, shared by Browse and by Activity's "your listings"
* view. THE LAYOUT IS A TABLE, NOT SameLine(offset): the dwcraft grid shape,
* because it is the column idiom every sibling addon has already proven
* against Ashita's sol bindings -- the offset overload of SameLine and the
* BeginChild region this window shipped with on day one are exactly the two
* calls the client refused ("no matching function call"), and neither
* appears anywhere else in the tree. Columns are measured over exactly what
* this call renders (the dwcraft rule), so nothing can truncate.
--]]
local function listingTable(rows, tag, cancelPrefix)
    if (#rows == 0) then
        return;
    end

    if (not beginTable('##dwah_table_' .. tag, 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    local priceW  = textWidth('999,999,999');
    local sellerW = textWidth('Sellername');
    local histW   = textWidth('History');

    for _, row in ipairs(rows) do
        sellerW = math.max(sellerW, textWidth(row.mine and 'yours' or row.seller));
    end

    -- THE NAME COLUMN STRETCHES (1.6.0). It was fixed at the width of the
    -- longest label, and the widest FFXI names plus ' (stack) (signed)' push
    -- the table past the default window: with no horizontal scrollbar the
    -- Buy and History buttons simply fell off the right edge, unreachable
    -- without dragging the window wider. Stretching gives the space back
    -- when names are short and clips one long name instead of the row.
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthStretch, 0, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, priceW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, sellerW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 70, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, histW + 16, 0);

    for _, row in ipairs(rows) do
        imgui.TableNextRow();
        imgui.TableNextColumn();

        drawIcon(row.itemid, 20);

        local hovered = imgui.IsItemHovered();

        imgui.Text(row.label or itemName(row.itemid));
        cardOnHover(row.itemid, hovered);

        imgui.TableNextColumn();
        imgui.TextColored(theme.colors.badge, gilText(row.price));

        if (imgui.IsItemHovered()) then
            -- What the seller actually keeps, said where the price is: the
            -- house cut is the one number a listing does not show (1.6.0).
            imgui.SetTooltip(string.format('%s gil. The seller keeps %s after the %d%% house cut.',
                gilText(row.price), gilText(netOf(row.price)), limits.fee));
        end

        imgui.TableNextColumn();
        imgui.TextDisabled(row.mine and 'yours' or row.seller);

        imgui.TableNextColumn();

        if (row.mine) then
            if (imgui.Button(string.format('Cancel##%s%s', cancelPrefix, row.ref))) then
                issue(string.format('!dwa cancel %s', row.ref));
            end

            tip('cancel');
        else
            if (imgui.Button(string.format('Buy##%s', row.ref))) then
                state.confirmBuy = { ref = row.ref, price = row.price, name = itemName(row.itemid) };
            end

            tip('buy');
        end

        imgui.TableNextColumn();

        -- Free and confirm-less -- a history ask moves no gil -- and it
        -- fronts the History tab (askHistory's focus flag), so the answer
        -- lands where the player is already looking. Resting on it shows
        -- the sale list as a card (1.4.0).
        if (row.itemid > 0) then
            if (imgui.Button(string.format('History##h_%s%s', tag, row.ref))) then
                askHistory(row.itemid, true);
            end

            if (imgui.IsItemHovered()) then
                historyCard(row.itemid);
            end
        end
    end

    endTable();
end

-- The money question, asked twice and answered above the table: the price it
-- repeats is the one the server will be held to (the echo in the buy verb).
local function confirmBuyStrip()
    if (state.confirmBuy == nil) then
        return;
    end

    imgui.TextColored(theme.colors.warn,
        string.format('Buy %s for %s gil?', state.confirmBuy.name, gilText(state.confirmBuy.price)));
    imgui.SameLine();

    if (imgui.Button(string.format('Confirm##buy_%s', state.confirmBuy.ref))) then
        issue(string.format('!dwa buy %s %d', state.confirmBuy.ref, state.confirmBuy.price));

        state.confirmBuy = nil;
    elseif (state.confirmBuy ~= nil) then
        imgui.SameLine();

        if (imgui.Button(string.format('No##buy_%s', state.confirmBuy.ref))) then
            state.confirmBuy = nil;
        end
    end
end

local function browseTab()
    -- The drawer pair, the retail counter's own tree: nine categories every
    -- player already knows, most opening a sub-list. Listings load only once
    -- a leaf is picked -- the drawer IS the fix, for the sweep length and
    -- the frame rate both.
    imgui.SetNextItemWidth(110);

    local comboOpen = imgui.BeginCombo('##dwah_cat', state.catTop ~= nil and CATEGORIES[state.catTop].label or 'Category...');

    tip('category');

    if (comboOpen) then
        for index, entry in ipairs(CATEGORIES) do
            if (imgui.Selectable(entry.label .. '##dwah_cat' .. index, index == state.catTop)) then
                state.catTop = index;
                state.catSub = nil;

                saveView();
            end
        end

        imgui.EndCombo();
    end

    local top = state.catTop ~= nil and CATEGORIES[state.catTop] or nil;

    if (top ~= nil and top.subs ~= nil) then
        imgui.SameLine();
        imgui.SetNextItemWidth(120);

        local subLabel = state.catSub ~= nil and top.subs[state.catSub].label or 'Which...';
        local subOpen  = imgui.BeginCombo('##dwah_subcat', subLabel);

        tip('subcat');

        if (subOpen) then
            for index, entry in ipairs(top.subs) do
                if (imgui.Selectable(entry.label .. '##dwah_sub' .. index, index == state.catSub)) then
                    state.catSub = index;

                    saveView();
                end
            end

            imgui.EndCombo();
        end
    end

    imgui.SameLine();
    imgui.SetNextItemWidth(140);
    imgui.InputText('##dwah_search', state.search, 48);
    tip('search');
    imgui.SameLine();

    -- The find box's own clear, as on the Sell tab (1.6.0): a search that
    -- has to be back-spaced away is a search the player leaves on by
    -- accident and then reads as an empty drawer.
    if (state.search[1] ~= '') then
        if (imgui.SmallButton('x##dwah_search_clear')) then
            state.search[1] = '';
        end

        tip('clear');

        imgui.SameLine();
    end

    imgui.SetNextItemWidth(90);

    local sortOpen = imgui.BeginCombo('##dwah_sort', SORT_LABELS[state.sortMode]);

    tip('sort');

    if (sortOpen) then
        for index, label in ipairs(SORT_LABELS) do
            if (imgui.Selectable(label, index == state.sortMode)) then
                state.sortMode = index;
                state.viewPage = 1;

                saveView();
            end
        end

        imgui.EndCombo();
    end

    imgui.SameLine();

    if (imgui.Checkbox('Mine', state.onlyMine)) then
        state.viewPage = 1;

        saveView();
    end

    tip('mine');

    -- A new search starts the pager over; typing lands on page one.
    if (state.search[1] ~= state.lastSearch) then
        state.lastSearch = state.search[1];
        state.viewPage   = 1;
    end

    -- The selection resolves to a leaf drawer, and the model follows it.
    -- Half a selection (Weapons picked, no sub yet) keeps whatever was
    -- loaded rather than blanking the window under the player.
    if (top ~= nil) then
        if (top.subs == nil) then
            ensureScope({ cat = top.cat, label = top.label });
        elseif (state.catSub ~= nil) then
            local sub = top.subs[state.catSub];

            ensureScope({ cat = sub.cat, label = top.label .. ' > ' .. sub.label });
        end
    end

    confirmBuyStrip();

    if (state.scope == nil or state.scope.mine) then
        imgui.TextDisabled('Pick a category -- the drawers are the auction counter\'s own.');

        return;
    end

    local rows = sortedListings();

    if (#rows == 0) then
        if (state.total == 0 and not state.syncing) then
            imgui.TextDisabled(string.format('Nothing is listed under %s. The Sell tab lists straight from your bag, free.', state.scope.label));
        else
            imgui.TextDisabled('Nothing matches.');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('The drawer has rows, but none of them pass the find box or the Mine tick.');
            end
        end

        return;
    end

    --[[
        The drawer's own summary (1.6.0). "Is this dear?" is the question
        every browse is really asking, and the answer was one row-by-row
        read away. Counted over the FILTERED rows, so it follows the find
        box, and computed in the view build -- one pass over a list already
        in hand, not a walk per frame.
    ]]
    local summary = listingSummary();

    if (summary ~= nil and summary.low ~= nil) then
        imgui.TextDisabled(string.format('%d listing%s  --  %s to %s gil', summary.count,
            summary.count == 1 and '' or 's', gilText(summary.low), gilText(summary.high)));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('Cheapest %s, dearest %s, %s gil on the shelf all told. Over what the find box and the Mine tick leave showing.',
                gilText(summary.low), gilText(summary.high), gilText(summary.sum)));
        end
    end

    local slice;

    slice, state.viewPage = pagedRows(rows, 'view', state.viewPage);

    listingTable(slice, 'browse', '');
end

--[[
* The quotes ask (1.5.0): every bag item's recent average sale price, asked
* ONCE per item per session, one line at a time. The answer is keyed by item
* (the u| record), so no routing; a Refresh forgets and re-asks. Nothing is
* asked once the server has said it has no quotes verb.
*
* THE BATCH IS SIZED IN BYTES, NOT IN IDS (1.6.1). It used to be a flat
* twenty, which is the STORE's ceiling (`kQuoteIdsPerAsk`,
* market_store.cpp:1049) and says nothing about what the client will carry:
* twenty five-digit ids is a 131-character command, and the local echo of it
* blew the client's chat buffer so dwecho could not swallow it -- the
* 2026-09-11 chat spam. Ids are packed until the NEXT one would not fit
* inside COMMAND_MAX (see the send queue's note), and the store's ceiling
* stays as the second bound, so the line is short enough for the client and
* never asks for more than the server will answer.
--]]
local QUOTE_VERB        = '!dwa quotes ';
local QUOTE_IDS_PER_ASK = 20;

-- How long a quotes line waits for its z| before the twenty items it named
-- go back in the pool (1.6.0). Without it a single lost line disarmed those
-- twenty rows for the whole session: `quotesAsked` had spoken for them and
-- nothing ever cleared it, so they read '...' until the next Refresh.
local QUOTE_TIMEOUT = 20.0;

local function requestQuotes(rows)
    if (state.noQuotes or state.serverSilent) then
        return;
    end

    -- A batch that was sent and never answered: forget it was asked, so the
    -- loop below may pick those ids up again. One re-ask at a time, because
    -- the batch record is what holds the next one off.
    if (state.quotesBatch ~= nil and (os.clock() - state.quotesBatch.at) > QUOTE_TIMEOUT) then
        for _, id in ipairs(state.quotesBatch.ids) do
            if (state.quotes[id] == nil) then
                state.quotesAsked[id] = nil;
            end
        end

        state.quotesBatch = nil;
    end

    --[[
        ONE LINE IN FLIGHT, NOT ONE IN THE QUEUE (1.6.1). The queue scan
        below only holds the next batch back until the first is PUMPED, so a
        frame later there was a second batch queued and `state.quotesBatch`
        had been overwritten with it. Two things then went wrong at once: the
        FIRST z| to come back closed the LATEST batch -- writing 'no sales
        yet' over ids whose answer was still in the post -- and every batch
        after that had no record at all, so an id the store did not name (an
        item nobody has sold) read '...' for the rest of the session, because
        `quotesAsked` had spoken for it and the timeout sweep above only ever
        knew about one batch. The batch record IS the in-flight marker.
    ]]
    if (state.quotesBatch ~= nil) then
        return;
    end

    -- Belt to that brace: a batch whose line is still sitting in the queue
    -- when the timeout above fires (a long zone holds the whole queue shut)
    -- would otherwise be asked a second time.
    for _, queued in ipairs(queue) do
        if (queued:match('^!dwa quotes ') ~= nil) then
            return;
        end
    end

    local ids  = {};
    local seen = {};
    local used = #QUOTE_VERB;

    for _, row in ipairs(rows) do
        local id = row.itemid;

        -- `listable` skips what the market would refuse anyway: a bag of EX
        -- gear used to spend the whole send budget asking about items with
        -- no counter to sell at.
        if (not seen[id] and listable(id)
                and state.quotes[id] == nil and state.quotesAsked[id] == nil) then
            local text = tostring(id);
            local cost = #text + (#ids > 0 and 1 or 0);

            -- The line is full. Stop here rather than skipping this id: the
            -- next pass picks it up, and a skip would have reordered the bag
            -- against `quotesAsked` for no gain.
            if (used + cost > COMMAND_MAX) then
                break;
            end

            seen[id] = true;
            used = used + cost;
            ids[#ids + 1] = id;

            if (#ids >= QUOTE_IDS_PER_ASK) then
                break;
            end
        end
    end

    if (#ids == 0) then
        return;
    end

    for _, id in ipairs(ids) do
        state.quotesAsked[id] = os.clock();
    end

    -- What this line asked for, so the z| can answer for every id it named
    -- and a lost line can be noticed.
    state.quotesBatch = { ids = ids, at = os.clock() };

    issue(QUOTE_VERB .. table.concat(ids, ','));
end

-- The quote a row would QuickSell at: the single average for a single, the
-- stack average when the row IS a full stack and stacks have sold. nil when
-- nobody has sold one -- no quote, no QuickSell (the owner's rule).
local function quoteFor(row)
    local quote = state.quotes[row.itemid];

    -- Latched off means no quote, whatever the cache still holds.
    if (quote == nil or state.noQuotes) then
        return nil;
    end

    local stackSize = stackSizeOf(row.itemid);
    local full      = stackSize > 1 and row.count == stackSize;

    return {
        single = quote.singles > 0 and quote.single or nil,
        stack  = (full and quote.stacks > 0) and quote.stack or nil,
        quote  = quote,
        full   = full,
    };
end

local function sellTab()
    imgui.TextDisabled(string.format('Listing is free; the house takes %d%% when it sells. First-ever sale of an item pays %s gil.',
        limits.fee, gilText(limits.bounty)));

    -- THE CAP, SAID BEFORE THE REFUSAL (1.6.0). The account listing cap is
    -- the server's rule and the buttons below stay live -- a greyed button
    -- here would be a courtesy claiming to be the authority -- but a seller
    -- at the cap deserved to hear it from the window rather than from a red
    -- line after pressing List.
    if (state.cap > 0 and state.mine >= state.cap) then
        imgui.TextColored(theme.colors.warn,
            string.format('Your account is at its listing cap (%d of %d). Cancel one on the Activity tab, or wait for a sale.',
                state.mine, state.cap));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('The server refuses a new listing past the cap. Listing still costs nothing -- there is just no room.');
        end
    end

    local rows = bagRows();

    requestQuotes(rows);

    --[[
        The QuickSell confirm strip (1.5.0): the projected list price -- the
        average of the item's recent real sales -- and what the seller keeps
        after the house's cut, said in full BEFORE the line leaves. Confirm
        lists; Edit price hands the number to the ordinary strip below with
        the price pre-filled; No drops it. Nothing is sent by the QuickSell
        button itself.
    ]]
    if (state.quickSell ~= nil) then
        local ask  = state.quickSell;
        local cell = nil;

        for _, row in ipairs(rows) do
            if (row.slot == ask.slot and row.itemid == ask.itemid) then
                cell = row;
            end
        end

        if (cell == nil) then
            -- The bag changed under the question; the slot claim is stale.
            state.quickSell = nil;
        else
            imgui.TextColored(theme.colors.warn,
                string.format('QuickSell %s%s at %s gil? You get %s after the %d%% cut.',
                    ask.name, ask.stack == 1 and ' (the stack)' or '', gilText(ask.price), gilText(netOf(ask.price)), limits.fee));
            imgui.TextDisabled(string.format('The average of the last %d sale%s of this kind.', ask.sales, ask.sales == 1 and '' or 's'));

            if (imgui.Button(string.format('Confirm##quick%d', ask.slot))) then
                issue(string.format('!dwa sell %d %d%s', ask.slot, ask.price, ask.stack == 1 and ' stack' or ''));

                state.quickSell = nil;
            end

            if (state.quickSell ~= nil) then
                imgui.SameLine();

                if (imgui.Button(string.format('Edit price##quick%d', ask.slot))) then
                    state.sellSlot     = ask.slot;
                    state.sellPrice[1] = tostring(ask.price);
                    state.quickSell    = nil;
                end
            end

            if (state.quickSell ~= nil) then
                imgui.SameLine();

                if (imgui.Button(string.format('No##quick%d', ask.slot))) then
                    state.quickSell = nil;
                end
            end
        end
    end

    -- The selected cell's price strip, above the table so it cannot collide
    -- with the row that opened it.
    if (state.sellSlot ~= nil) then
        local cell = nil;

        for _, row in ipairs(rows) do
            if (row.slot == state.sellSlot) then
                cell = row;
            end
        end

        if (cell == nil) then
            -- The bag changed under the strip; the claim would be stale.
            state.sellSlot = nil;
        else
            imgui.Text(string.format('Selling %s:', itemName(cell.itemid)));
            cardOnHover(cell.itemid, false, extraAugments(cell.extra));
            imgui.SameLine();
            imgui.SetNextItemWidth(120);
            imgui.InputText(string.format('##price%d', state.sellSlot), state.sellPrice, 10);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('What you are asking, in whole gil, 1 to %s. The house takes %d%% of it when it sells.',
                    gilText(MAX_PRICE), limits.fee));
            end

            imgui.SameLine();

            -- A WHOLE NUMBER OF GIL OR NOTHING (1.6.0). This used to take
            -- `tonumber(...) or 0` and range-check it, so '2.5' passed and
            -- reached string.format('%d', ...) on the wire -- truncated to 2
            -- under the client's LuaJIT while the strip said 'you get 2.5'.
            local price = wholeGil(state.sellPrice[1]);

            if (price ~= nil) then
                imgui.TextDisabled(string.format('you get %s', gilText(netOf(price))));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('%s less the %d%% house cut. It reaches the account wallet, not this character.',
                        gilText(price), limits.fee));
                end

                imgui.SameLine();

                if (imgui.Button(string.format('List single##%d', state.sellSlot))) then
                    issue(string.format('!dwa sell %d %d', state.sellSlot, price));

                    state.sellSlot = nil;
                end

                if (state.sellSlot ~= nil and imgui.IsItemHovered()) then
                    imgui.SetTooltip('List ONE of these at that price. Free to list.');
                end

                local stackSize = stackSizeOf(cell.itemid);

                if (state.sellSlot ~= nil and stackSize > 1 and cell.count == stackSize) then
                    imgui.SameLine();

                    if (imgui.Button(string.format('List stack##%d', state.sellSlot))) then
                        issue(string.format('!dwa sell %d %d stack', state.sellSlot, price));

                        state.sellSlot = nil;
                    end

                    if (state.sellSlot ~= nil and imgui.IsItemHovered()) then
                        imgui.SetTooltip(string.format('List the whole stack of %d as one listing at that price.', stackSize));
                    end
                end
            else
                imgui.TextDisabled('price?');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('A price is a whole number of gil, 1 to %s. Nothing is listed until there is one.',
                        gilText(MAX_PRICE)));
                end
            end

            if (state.sellSlot ~= nil) then
                -- The recent average, one click from the box (1.5.0).
                local suggestion = quoteFor(cell);

                if (suggestion ~= nil and suggestion.single ~= nil) then
                    imgui.SameLine();

                    if (imgui.SmallButton(string.format('avg %s##dwah_avg%d', gilText(suggestion.single), state.sellSlot))) then
                        state.sellPrice[1] = tostring(suggestion.single);
                    end

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('Put the recent single-sale average in the box.');
                    end
                end

                imgui.SameLine();

                if (imgui.Button('Never mind##sell')) then
                    state.sellSlot = nil;
                end
            end
        end
    end

    if (#rows == 0) then
        imgui.TextDisabled('Your bag is empty.');

        return;
    end

    -- A find box over the bag (1.5.0): eighty rows is a scroll, one name is
    -- a glance. Local; the server hears nothing about it.
    imgui.SetNextItemWidth(160);
    imgui.InputText('##dwah_sellfind', state.sellFind, 48);
    tip('sellfind');
    imgui.SameLine();

    if (state.sellFind[1] ~= '') then
        if (imgui.SmallButton('x##dwah_sellfind_clear')) then
            state.sellFind[1] = '';
        end

        tip('clear');

        imgui.SameLine();
    end

    imgui.TextDisabled('find');
    tip('sellfind');

    local needle = state.sellFind[1]:lower();
    local shown  = {};

    for _, row in ipairs(rows) do
        if (#needle == 0 or itemName(row.itemid):lower():find(needle, 1, true) ~= nil) then
            shown[#shown + 1] = row;
        end
    end

    if (#shown == 0) then
        imgui.TextDisabled('Nothing in your bag matches.');

        return;
    end

    if (not beginTable('##dwah_table_bag', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    --[[
        MEASURED OVER EXACTLY WHAT THIS CALL RENDERS (1.6.0, the dwcraft
        grid rule this window already keeps everywhere else). The action
        column was a flat 300px while its widest row is Sell + QuickSell +
        QuickSell stack + History, and the name column was fixed at the
        longest bag label: together they ran the table well past the default
        620px window, and there is no horizontal scrollbar, so the History
        button on the right simply was not there.

        The quotes are resolved HERE and reused in the draw loop below: the
        buttons a row gets depend on them, so measuring and drawing have to
        agree, and asking twice would be one more DAT-backed lookup per row
        per frame.
    ]]
    local quoteW = textWidth('avg 999,999,999 / stack 999,999,999');
    local countW = textWidth('x99');

    local suggestions = {};
    local actionW     = 0;

    for index, row in ipairs(shown) do
        local suggestion = quoteFor(row);
        local width      = textWidth('Sell') + textWidth('History') + 48;

        suggestions[index] = suggestion;

        if (suggestion ~= nil and suggestion.single ~= nil) then
            width = width + textWidth('QuickSell') + 24;
        end

        if (suggestion ~= nil and suggestion.stack ~= nil) then
            width = width + textWidth('QuickSell stack') + 24;
        end

        actionW = math.max(actionW, width);
    end

    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthStretch, 0, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, countW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, quoteW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, actionW, 0);

    for index, row in ipairs(shown) do
        imgui.TableNextRow();
        imgui.TableNextColumn();

        drawIcon(row.itemid, 20);

        local hovered = imgui.IsItemHovered();

        imgui.Text(itemName(row.itemid));

        -- A bag row is the client's own item: the card gets the decoded
        -- augment slots, values included. (Augmented gear is refused at
        -- the listing counter, so this is the honest last look at why.)
        -- THE DECODE HAPPENS ON HOVER, not per row per frame (1.6.0):
        -- extraAugments walks twelve exdata bytes and builds a table, and
        -- eighty bag rows were paying for a card only one of them shows.
        if (hovered or imgui.IsItemHovered()) then
            itemCard(row.itemid, extraAugments(row.extra));
        end

        imgui.TableNextColumn();
        imgui.TextDisabled(string.format('x%d', row.count));

        -- The recent average beside every row (1.5.0): what it has sold for
        -- lately, before any button is pressed. 'no sales yet' is the honest
        -- answer for an item nobody has sold; nothing at all while the
        -- server has not answered, or has no quotes verb.
        imgui.TableNextColumn();

        local quote = state.quotes[row.itemid];

        if (quote ~= nil) then
            if (quote.singles > 0 or quote.stacks > 0) then
                local parts = {};

                if (quote.singles > 0) then
                    parts[#parts + 1] = 'avg ' .. gilText(quote.single);
                end

                if (quote.stacks > 0) then
                    parts[#parts + 1] = 'stack ' .. gilText(quote.stack);
                end

                imgui.TextColored(theme.colors.badge, table.concat(parts, ' / '));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('The average of the last %d single sale%s%s.',
                        quote.singles, quote.singles == 1 and '' or 's',
                        quote.stacks > 0 and string.format(' and %d stack sale%s', quote.stacks, quote.stacks == 1 and '' or 's') or ''));
                end
            else
                imgui.TextDisabled('no sales yet');
                tip('noquote');
            end
        elseif (not state.noQuotes and state.quotesAsked[row.itemid] ~= nil) then
            imgui.TextDisabled('...');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Waiting for the server to say what this has sold for.');
            end
        elseif (not listable(row.itemid)) then
            -- No quote was ever asked for this one, and the empty cell used
            -- to be the only thing that said so (1.6.1).
            imgui.TextDisabled('cannot be listed');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('The market refuses this item -- exclusive gear and anything the auction counter will not take. Nothing to quote, and List will be refused.');
            end
        else
            imgui.Text('');
        end

        imgui.TableNextColumn();

        -- The quote this row was MEASURED against, so the buttons drawn and
        -- the column they are drawn in cannot disagree. It used to be asked
        -- for three separate times per row per frame (the Sell pre-fill,
        -- the QuickSell gate and the QuickSell-stack gate).
        local suggestion = suggestions[index];

        if (imgui.Button(string.format('Sell##slot%d', row.slot))) then
            state.sellSlot  = row.slot;
            state.quickSell = nil;

            -- Pre-filled with the recent average when there is one: the
            -- number most players type anyway, one glance closer.
            state.sellPrice[1] = (suggestion ~= nil and suggestion.single ~= nil) and tostring(suggestion.single) or '';
        end

        tip('sell');

        --[[
            QuickSell (1.5.0, the owner's request): list at the average of
            the item's recent real sales, after a confirm that says the
            price and the return. Drawn ONLY for an item with a history --
            no sales, no quote, no button. A full stack with stack sales
            gets a second button for the stack average.
        ]]
        if (suggestion ~= nil and suggestion.single ~= nil) then
            imgui.SameLine();

            if (imgui.Button(string.format('QuickSell##q%d', row.slot))) then
                state.quickSell = {
                    slot   = row.slot,
                    itemid = row.itemid,
                    name   = itemName(row.itemid),
                    price  = suggestion.single,
                    stack  = 0,
                    sales  = suggestion.quote.singles,
                };
                state.sellSlot = nil;
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('List one at the recent average, %s gil. Asks first.', gilText(suggestion.single)));
            end
        end

        if (suggestion ~= nil and suggestion.stack ~= nil) then
            imgui.SameLine();

            if (imgui.Button(string.format('QuickSell stack##qs%d', row.slot))) then
                state.quickSell = {
                    slot   = row.slot,
                    itemid = row.itemid,
                    name   = itemName(row.itemid),
                    price  = suggestion.stack,
                    stack  = 1,
                    sales  = suggestion.quote.stacks,
                };
                state.sellSlot = nil;
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('List the whole stack at the recent stack average, %s gil. Asks first.', gilText(suggestion.stack)));
            end
        end

        -- The sale list, one hover or one click away, as on every listing
        -- and order row (1.5.0).
        imgui.SameLine();

        if (imgui.Button(string.format('History##h_bag%d', row.slot))) then
            askHistory(row.itemid, true);
        end

        if (imgui.IsItemHovered()) then
            historyCard(row.itemid);
        end
    end

    endTable();
end

local function confirmFillStrip()
    if (state.confirmFill == nil) then
        return;
    end

    imgui.TextColored(theme.colors.warn,
        string.format('Fill %d unit(s) of %s at %s each (you receive %s)?',
            state.confirmFill.count, state.confirmFill.name,
            gilText(state.confirmFill.price),
            gilText(netOf(state.confirmFill.price) * state.confirmFill.count)));
    imgui.SameLine();

    if (imgui.Button(string.format('Confirm##fill%d', state.confirmFill.id))) then
        issue(string.format('!dwa fill %d %d %d',
            state.confirmFill.id, state.confirmFill.slot, state.confirmFill.count));

        state.confirmFill = nil;
    elseif (state.confirmFill ~= nil) then
        imgui.SameLine();

        if (imgui.Button(string.format('No##fill%d', state.confirmFill.id))) then
            state.confirmFill = nil;
        end
    end
end

local function ordersTab()
    -- The form first: posting demand is the feature (DWAH_PLAN.md: buy
    -- orders CAUSE an economy; sell listings only display one).
    imgui.SetNextItemWidth(180);
    imgui.InputText('##dwah_orderitem', state.orderText, 32);
    tip('orderitem');
    imgui.SameLine();

    state.orderId = resolveItemText(state.orderText[1]);

    if (state.orderId ~= nil) then
        drawIcon(state.orderId, 18);
        imgui.Text(itemName(state.orderId));
        cardOnHover(state.orderId);
    else
        imgui.TextDisabled('item name or id');
        tip('orderitem');
    end

    imgui.SetNextItemWidth(80);
    imgui.InputInt('qty##dwah_orderqty', state.orderQty, 1, 10);
    tip('orderqty');
    imgui.SameLine();
    imgui.SetNextItemWidth(110);
    imgui.InputText('each##dwah_orderprice', state.orderPrice, 10);
    tip('orderprice');
    imgui.SameLine();
    imgui.Checkbox('stacks##dwah_orderstack', state.orderStack);
    tip('orderstack');

    -- The clamp is written BACK into the box (1.6.0): the arrows can walk
    -- the number past either end, and a form that sends 1 while showing 0 --
    -- or 99 while showing 140 -- is a form the player cannot trust.
    local qty = math.max(1, math.min(99, math.floor(tonumber(state.orderQty[1]) or 1)));

    state.orderQty[1] = qty;

    local price = wholeGil(state.orderPrice[1]);

    if (state.orderId ~= nil and price ~= nil) then
        imgui.SameLine();

        if (not state.confirmOrder) then
            if (imgui.Button('Post order##dwah')) then
                state.confirmOrder = true;
            end

            tip('postorder');
        else
            imgui.TextColored(theme.colors.warn, string.format('Escrow %s gil?', gilText(qty * price)));

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('%s gil each times %d. The whole amount leaves you now and comes back if you cancel.',
                    gilText(price), qty));
            end

            imgui.SameLine();

            if (imgui.Button('Confirm##order')) then
                issue(string.format('!dwa order %d %d %d%s', state.orderId, price, qty,
                    state.orderStack[1] and ' stack' or ''));

                state.confirmOrder = false;
            end

            imgui.SameLine();

            if (imgui.Button('No##order')) then
                state.confirmOrder = false;
            end
        end
    elseif (state.orderId ~= nil and #(state.orderPrice[1] or '') > 0) then
        -- A typed price the form will not send, said out loud rather than by
        -- the silent absence of a button (1.6.0).
        imgui.SameLine();
        imgui.TextDisabled('price?');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('A price is a whole number of gil, 1 to %s. Fractions and blanks are not prices.',
                gilText(MAX_PRICE)));
        end
    end

    -- The account's own standing against the server's order cap (1.6.0).
    -- `h|` has carried the number since 1.0.0 and nothing on screen used it,
    -- so the first a player heard of the cap was the refusal.
    local capLine = string.format('%d of %d open orders on your account', state.orders, limits.ordercap);

    -- Coloured at the cap rather than greyed out: the cap is the server's
    -- rule and the Post button stays live -- the window says what it knows,
    -- the store decides (1.6.0).
    if (limits.ordercap > 0 and state.orders >= limits.ordercap) then
        imgui.TextColored(theme.colors.warn, capLine .. ' -- no room for another.');
    else
        imgui.TextDisabled(capLine);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Orders your ACCOUNT has posted, and the server\'s cap on them. Cancel one to make room; the escrow comes back with it.');
    end

    imgui.Separator();

    confirmFillStrip();

    local all = sortedOrders();

    if (#all == 0) then
        imgui.TextDisabled('No open orders. Post one above -- your gil waits in escrow until a seller fills it.');

        return;
    end

    --[[
        A FIND BOX AND A PAGE (1.6.0). The order board is EVERYBODY'S open
        orders and the sweep walks every page of them, so the model here is
        unbounded in a way the drawer-scoped browse model no longer is -- and
        this table drew all of it, every row, every frame. Fifty at a time
        with a find box over the whole list, exactly as Browse does; the
        server-side half (a scope for the orders verb) is a wire change and
        is not this window's to make.
    ]]
    imgui.SetNextItemWidth(160);
    imgui.InputText('##dwah_orderfind', state.orderFind, 48);
    tip('orderfind');
    imgui.SameLine();

    if (state.orderFind[1] ~= '') then
        if (imgui.SmallButton('x##dwah_orderfind_clear')) then
            state.orderFind[1] = '';
        end

        tip('clear');

        imgui.SameLine();
    end

    imgui.TextDisabled('find');
    tip('orderfind');

    local needle = state.orderFind[1]:lower();
    local rows   = all;

    if (#needle > 0) then
        rows = {};

        for _, row in ipairs(all) do
            if (itemName(row.itemid):lower():find(needle, 1, true) ~= nil) then
                rows[#rows + 1] = row;
            end
        end

        if (#rows == 0) then
            imgui.TextDisabled('No open order matches.');

            return;
        end
    end

    rows, state.ordersPage = pagedRows(rows, 'orders', state.ordersPage);

    if (not beginTable('##dwah_table_orders', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    local ownerW = textWidth('Sellername');
    local histW  = textWidth('History');
    local qtyW   = textWidth('x99');
    local priceW = textWidth('999,999,999 each');

    for _, row in ipairs(rows) do
        ownerW = math.max(ownerW, textWidth(row.mine and 'yours' or row.owner));
    end

    -- The NAME column stretches and every other one is measured (1.6.0). A
    -- fixed name column sized to the longest label pushed the fill and
    -- History buttons off the right edge of the default window -- there is
    -- no horizontal scrollbar, so they were simply unreachable. A stretch
    -- column gives the space back when the names are short and clips one
    -- absurd name rather than the whole row (the card still names it).
    local bag = bagIndex();

    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthStretch, 0, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, qtyW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, priceW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, ownerW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, math.max(70, textWidth('no full stack') + 8), 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, histW + 16, 0);

    for _, row in ipairs(rows) do
        imgui.TableNextRow();
        imgui.TableNextColumn();

        drawIcon(row.itemid, 20);

        local hovered = imgui.IsItemHovered();

        imgui.Text(row.label or itemName(row.itemid));
        cardOnHover(row.itemid, hovered);

        imgui.TableNextColumn();
        imgui.Text(string.format('x%d', row.qty));

        imgui.TableNextColumn();
        imgui.TextColored(theme.colors.badge, string.format('%s each', gilText(row.price)));

        imgui.TableNextColumn();
        imgui.TextDisabled(row.mine and 'yours' or row.owner);

        imgui.TableNextColumn();

        if (row.mine) then
            if (imgui.Button(string.format('Cancel##o%d', row.id))) then
                issue(string.format('!dwa cancelorder %d', row.id));
            end

            tip('ownorder');
        else
            -- A STACK ORDER NEEDS A FULL STACK IN ONE CELL (the native rule
            -- the store enforces, market_store.cpp DwMarketOrderFill). The
            -- board used to offer Fill off any cell holding the item, so a
            -- player with a part-stack pressed a button whose only possible
            -- answer was a refusal.
            local held  = bag[row.itemid];
            local slot  = nil;
            local count = 1;

            if (held ~= nil) then
                if (row.stack == 1) then
                    slot = held.fullSlot;
                else
                    slot  = held.slot;
                    count = math.min(held.count, row.qty, MAX_FILL_UNITS);
                end
            end

            if (slot ~= nil) then
                if (imgui.Button(string.format('Fill##o%d', row.id))) then
                    state.confirmFill = {
                        id    = row.id,
                        name  = itemName(row.itemid),
                        price = row.price,
                        count = count,
                        slot  = slot,
                    };
                end

                tip('fill');
            elseif (row.stack == 1 and held ~= nil) then
                imgui.TextDisabled('no full stack');
                tip('nostack');
            else
                imgui.TextDisabled('none held');
                tip('nonefill');
            end
        end

        imgui.TableNextColumn();

        -- What has this item actually sold for? The question every order
        -- price is set against, one click from the row itself -- and one
        -- hover, since 1.4.0.
        if (row.itemid > 0) then
            if (imgui.Button(string.format('History##h_o%d', row.id))) then
                askHistory(row.itemid, true);
            end

            if (imgui.IsItemHovered()) then
                historyCard(row.itemid);
            end
        end
    end

    endTable();
end

--[[
* The History tab (1.2.0): the last sales of one item, straight off the same
* auction_house rows the classic counter's own history window reads.
* Populated by its lookup box, by the recent-lookup chips, or by the History
* button every listing and order row carries; the summary and the dates are
* local arithmetic over what the server sent. The tab asks for nothing on
* its own -- it renders the one ask the player's last click made.
--]]
local function historyTab()
    imgui.SetNextItemWidth(180);

    -- Enter looks up (1.6.0), the suite's find-box idiom
    -- (ImGuiInputTextFlags_EnterReturnsTrue: dwcraft, dwquest, dwgmpanel).
    -- Typing a name and reaching for the mouse was the only step here that
    -- was not already one gesture.
    local entered = imgui.InputText('##dwah_history', state.historyText, 32,
        ImGuiInputTextFlags_EnterReturnsTrue);

    tip('lookup');
    imgui.SameLine();

    local lookupId = resolveItemText(state.historyText[1]);

    if (lookupId ~= nil) then
        if (imgui.Button('Look up##history') or entered) then
            askHistory(lookupId, false);
        end

        tip('lookup');
    else
        imgui.TextDisabled('item name or id');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('No item of that name or id. The client\'s own list is what answers, so spell it as the game does.');
        end
    end

    --[[
        The session's recent lookups, one chip each: comparing two prices is
        two clicks, not two typed names. WRAPPED (1.6.0): eight chips of
        full item names on one SameLine chain ran off the right edge of the
        window and the last of them could not be clicked at all. The
        available width is measured and the row broken by hand -- ImGui has
        no wrapping button row.
    ]]
    if (#state.history.recent > 1) then
        imgui.TextDisabled('Recent:');
        tip('recent');

        local avail = imgui.GetContentRegionAvail();
        local limit = type(avail) == 'number' and avail or 400;
        local used  = textWidth('Recent:') + 8;

        for index, id in ipairs(state.history.recent) do
            local label = itemName(id);
            local width = textWidth(label) + 16;

            if (used + width < limit) then
                imgui.SameLine();

                used = used + width + 8;
            else
                used = width + 8;
            end

            if (imgui.Button(string.format('%s##dwah_recent%d', label, index))) then
                askHistory(id, false);
            end

            tip('recent');
        end
    end

    if (state.history.itemid == nil) then
        imgui.TextDisabled('Look up an item above, or press History beside any listing or order.');

        return;
    end

    imgui.Separator();

    drawIcon(state.history.itemid, 24);

    local hovered = imgui.IsItemHovered();

    imgui.Text(string.format('Last sales of %s', state.history.name or '?'));
    cardOnHover(state.history.itemid, hovered);

    if (state.history.pendingAt ~= nil) then
        if (os.clock() - state.history.pendingAt < HISTORY_WAIT) then
            imgui.TextDisabled('Asking the server...');

            return;
        end

        --[[
            THE ASK AGED OUT WITH NO ANSWER (fixed 1.6.0). This used to fall
            straight through to the empty-list sentence below and tell the
            player that nobody had ever sold one -- about an item the server
            had simply never answered for. `history` is the one verb that
            does not ride the answer clock (no gil moves, so a lost line is
            not worth a retry storm), which is exactly why the tab has to
            say so itself.
        ]]
        imgui.TextColored(theme.colors.warn, 'The server did not answer that lookup -- it says nothing about the price.');
        imgui.SameLine();

        if (imgui.Button('Try again##dwah_history_retry')) then
            local again = state.history.itemid;

            state.history.pendingAt = nil;

            askHistory(again, false);
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Ask for this item\'s sales once more.');
        end

        return;
    end

    local rows = state.history.rows;

    if (#rows == 0) then
        imgui.TextDisabled('None yet. The first player to sell one earns the pioneer bounty.');

        return;
    end

    local summary = historySummary(rows);

    if (summary.seededOnly) then
        -- The server sends the bot's placeholder only when nobody has sold
        -- one -- so this is the whole story, and it must not read as a sale.
        imgui.TextColored(theme.colors.warn, 'No player has sold one yet. The price below is the seeded starting price, not a sale.');
    end

    if (summary.singles.low ~= nil) then
        imgui.TextDisabled(string.format('Singles: %s to %s gil, last sold %s',
            gilText(summary.singles.low), gilText(summary.singles.high), gilText(summary.singles.last)));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Sales of ONE. Cheapest, dearest and the most recent, over the last ten the server keeps.');
        end
    end

    if (summary.stacks.low ~= nil) then
        imgui.TextDisabled(string.format('Stacks: %s to %s gil, last sold %s',
            gilText(summary.stacks.low), gilText(summary.stacks.high), gilText(summary.stacks.last)));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Sales of a WHOLE STACK, kept apart from the single prices on purpose -- a stack price read as a single is a twelvefold mistake.');
        end
    end

    if (not beginTable('##dwah_table_history', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    local priceW  = textWidth('999,999,999 (stack)');
    local whenW   = textWidth('2026-07-04');
    local sellerW = textWidth('Sellername');
    local buyerW  = textWidth('Sellername');

    for _, row in ipairs(rows) do
        -- Measured over exactly what this call renders (the dwcraft rule).
        -- A seeded row has no date and no parties worth naming: it reads
        -- 'seeded' where a date would go and the bot's name once.
        row.priceLabel  = gilText(row.price) .. (row.stack == 1 and ' (stack)' or '');
        row.whenLabel   = row.seeded and 'seeded' or agoText(row.date);
        row.sellerLabel = row.seeded and 'starting price' or row.seller;
        row.buyerLabel  = row.seeded and '-' or row.buyer;

        priceW  = math.max(priceW, textWidth(row.priceLabel));
        whenW   = math.max(whenW, textWidth(row.whenLabel));
        sellerW = math.max(sellerW, textWidth(row.sellerLabel));
        buyerW  = math.max(buyerW, textWidth(row.buyerLabel));
    end

    -- Labeled headers, unlike the listing tables: seller and buyer are both
    -- bare names here, and without the header row there is no telling which
    -- side of the sale a name was on (the dwwarehouse header idiom). The
    -- SELLER column stretches (1.6.0) so the three measured ones keep their
    -- exact widths and the leftovers go somewhere useful.
    imgui.TableSetupColumn('Price', ImGuiTableColumnFlags_WidthFixed, priceW + 8, 0);
    imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, whenW + 8, 0);
    imgui.TableSetupColumn('Seller', ImGuiTableColumnFlags_WidthStretch, 0, 0);
    imgui.TableSetupColumn('Buyer', ImGuiTableColumnFlags_WidthFixed, buyerW + 8, 0);
    imgui.TableHeadersRow();

    for _, row in ipairs(rows) do
        imgui.TableNextRow();
        imgui.TableNextColumn();
        imgui.TextColored(theme.colors.badge, row.priceLabel);

        if (row.seeded) then
            tip('seeded');
        elseif (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('One real sale: %s paid %s gil%s.',
                row.buyer, gilText(row.price), row.stack == 1 and ' for the stack' or ''));
        end

        imgui.TableNextColumn();
        imgui.TextDisabled(row.whenLabel);

        if (row.seeded) then
            tip('seeded');
        elseif (row.date > 0 and imgui.IsItemHovered()) then
            imgui.SetTooltip(os.date('%Y-%m-%d %H:%M', row.date));
        end

        imgui.TableNextColumn();

        if (row.seeded) then
            imgui.TextDisabled(row.sellerLabel);
            tip('seeded');
        else
            imgui.Text(row.sellerLabel);
        end

        imgui.TableNextColumn();

        if (row.seeded) then
            imgui.TextDisabled(row.buyerLabel);
            tip('seeded');
        else
            imgui.Text(row.buyerLabel);
        end
    end

    endTable();
end

local function activityTab()
    -- This tab owns the 'mine' scope: the account's own listings, whatever
    -- drawer they file under, swept as their own (small) page walk. Browse
    -- takes the model back the moment its drawer is looked at again.
    -- (Price history lived here before 1.2.0 gave it a tab of its own.)
    ensureScope({ mine = true, label = 'your listings' });

    imgui.Text('Your listings');

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Every listing your ACCOUNT has up, whatever drawer it files under and whichever character listed it.');
    end

    -- Its own find box (1.6.0), for the reason the state comment gives: this
    -- view was already being filtered by the Browse tab's box, on a tab with
    -- nothing on it to say so or to clear it. Two hundred listings is also
    -- rather a lot to read.
    imgui.SameLine();
    imgui.SetNextItemWidth(160);
    imgui.InputText('##dwah_minefind', state.mineFind, 48);
    tip('minefind');

    if (state.mineFind[1] ~= '') then
        imgui.SameLine();

        if (imgui.SmallButton('x##dwah_minefind_clear')) then
            state.mineFind[1] = '';
        end

        tip('clear');
    end

    confirmBuyStrip();

    local mine = sortedListings();

    if (#mine == 0) then
        if (state.mineFind[1] ~= '') then
            imgui.TextDisabled('None of your listings match that.');
        else
            imgui.TextDisabled('Nothing up. Any character on your account can cancel any of these, wherever it was listed.');
        end

        return;
    end

    --[[
        What the shelf is worth (1.6.0). The one number a seller actually
        wants off this tab -- what comes back if it all sells -- and the
        window already has every price in hand from the view build, so it
        costs nothing to say.
    ]]
    local summary = listingSummary();

    if (summary ~= nil and summary.low ~= nil) then
        imgui.TextDisabled(string.format('%d up  --  %s gil asked, %s after the %d%% cut',
            summary.count, gilText(summary.sum), gilText(summary.sum - math.floor(summary.sum * limits.fee / 100)), limits.fee));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('If every one of these sold at the price shown. The house takes its cut per sale, and the rest reaches the account wallet.');
        end
    end

    local slice;

    slice, state.viewPage = pagedRows(mine, 'view', state.viewPage);

    listingTable(slice, 'mine', 'act_');
end

--[[
* The History tab's Begin, honouring a pending focus request from a History
* button. The three-argument BeginTabItem (label, open table, flags) is in
* Ashita's own annotations, but NO sibling addon has proven it against the
* live sol bindings -- and those same annotations also promise
* SameLine(offset) and two-argument InputInt, both of which the client
* REFUSED on this window's first live run (the 5a lesson: the offline
* harness's permissive stubs cannot see a signature). So the flagged call
* runs under pcall, once per request: refused, tabSelectBroken latches and
* the plain form serves forever -- the tab still populates, the player just
* clicks it themselves.
--]]
local function beginHistoryTab()
    if (state.historyFocus > 0 and not state.tabSelectBroken) then
        local attempt = state.historyFocus;

        state.historyFocus = state.historyFocus - 1;

        -- TWO SPELLINGS, ONE PER FRAME (1.4.0). The annotations write the
        -- open argument as `p_open`, and a sol binding may want a table
        -- there -- `{ true }` is what every other p_open in this suite
        -- passes (imgui.Begin's state.open) -- or accept nil. The first
        -- frame tries nil, the second the table, the third is plain so the
        -- bar settles; a throw on BOTH spellings closes the latch, and a
        -- call that returned true has selected the tab and ends the
        -- request early. (Written as an if, not `cond and nil or x` -- that
        -- idiom can never yield nil.)
        if (attempt >= 2) then
            local openArg = nil;

            if (attempt == 2) then
                openArg = { true };
            end

            local ok, opened = pcall(imgui.BeginTabItem, 'History##dwah', openArg, ImGuiTabItemFlags_SetSelected);

            if (ok) then
                if (opened) then
                    state.historyFocus = 0;
                end

                return opened;
            end

            if (attempt == 2) then
                state.tabSelectBroken = true;
                state.historyFocus    = 0;
            end
        end
    end

    return imgui.BeginTabItem('History##dwah');
end

local function windowBody()
    headerStrip();

    if (beginTabBar('##dwah_tabs')) then
        if (imgui.BeginTabItem('Browse##dwah')) then
            guarded(browseTab);
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Sell##dwah')) then
            guarded(sellTab);
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem(string.format('Orders (%d)###dwah_orders_tab', state.orders))) then
            guarded(ordersTab);
            imgui.EndTabItem();
        end

        if (beginHistoryTab()) then
            guarded(historyTab);
            imgui.EndTabItem();
        end

        -- The count rides the label, as it has on Orders since 1.0.0
        -- (1.6.0): 'have I still got things up?' was a tab click away, and
        -- the number is already on the account line. `###` so the id is the
        -- label's own and the tab does not lose its place when the count
        -- moves.
        if (imgui.BeginTabItem(string.format('Activity (%d)###dwah_activity_tab', state.mine))) then
            guarded(activityTab);
            imgui.EndTabItem();
        end

        endTabBar();
    end
end

--[[
* THE MINIMUM SIZE (1.6.0). ImGui remembers a window's size across sessions
* (that is what ImGuiCond_FirstUseEver means, and why NoSavedSettings is
* refused suite-wide) -- including a size the player dragged down to nothing
* by accident, which then persists forever and hides the tab bar, the header
* strip and every control behind an edge there is no scrollbar to reach.
*
* SIX HUNDRED IS MEASURED, NOT PICKED. The widest fixed row in the window is
* Browse's control strip, and every piece of it is a fixed pixel width this
* file sets: the drawer combo (110), the shelf combo (120), the find box
* (140) and its clear, the sort combo (90) and the Mine tick, plus ImGui's
* item spacing and the window padding -- about 590. The header strip is the
* runner-up at roughly 500. Below that the right-hand controls are simply
* off the edge. The default size is 620, so nothing is forced to resize.
*
* SetNextWindowSizeConstraints is in Ashita's annotations and used by no
* sibling window -- and THIS ADDON is the one that learned in 5a that an
* annotation is not proof (SameLine(offset) and two-argument InputInt are
* both promised there and both refused by the live sol bindings). So it is
* probed under pcall exactly once: refused, the latch closes and the window
* is what it always was.
--]]
local constraintsBroken = false;

local function renderWindow()
    if (not constraintsBroken) then
        if (not pcall(imgui.SetNextWindowSizeConstraints, { 600, 320 }, { 99999, 99999 })) then
            constraintsBroken = true;
        end
    end

    imgui.SetNextWindowSize({ 620, 460 }, ImGuiCond_FirstUseEver);

    if (imgui.Begin('DriftwoodXI Market##dwah', state.open, ImGuiWindowFlags_NoDocking)) then
        guarded(windowBody);
    end

    -- ALWAYS, whatever the body did: a Begin without its End is the DEAR
    -- IMGUI assert box over the whole client, once per frame.
    imgui.End();
end

-----------------------------------
-- Events
-----------------------------------

ashita.events.register('d3d_present', 'dwah_present', function()
    state.frame = state.frame + 1;

    -- The icon cache's ceiling, taken here and nowhere else: last frame's draw
    -- list has already been rendered, and this frame has not asked for a
    -- texture yet (see sweepIcons).
    sweepIcons();

    -- The queue pumps BEFORE the visibility early-out: a sweep or a Buy
    -- issued just before closing the window still completes.
    pumpQueue();

    --[[
        THE ENVELOPE WATCHDOG (1.6.0). An answer that never closed -- a
        dropped 0x017 line, an /addon reload mid-answer, a map that went
        away between `d|` and `z|` -- used to leave `inbound` open for the
        rest of the session: every later record was filed under whatever
        verb had opened last, and because the ask is stamped answered at d|
        the answer clock never re-asked, so the sweep sat on 'Loading...'
        forever. Closed after ENVELOPE_TIMEOUT with its ask put back on the
        clock, which is exactly the state a lost line leaves.
    ]]
    if (state.inbound ~= nil and (os.clock() - state.inboundAt) > ENVELOPE_TIMEOUT) then
        local stale = state.inbound;
        local asked = requested[stale];

        state.inbound        = nil;
        state.envelopeFailed = false;
        state.arriving       = nil;
        state.arrivingItem   = nil;

        if (type(asked) == 'table') then
            asked.answered = false;
            asked.at       = os.clock();
        end
    end

    -- The sweep drivers live here rather than in the record handler, so a
    -- command lost on the way out is re-asked (the answer clock). The page
    -- walk names its drawer ('mine' for the Activity view); the key carries
    -- it too, so a drawer switch is a new ask, never a stale answer's.
    --
    -- ALL OF THEM ARE OFF WHILE THE PROTOCOL LATCH IS UP (1.6.0): a server
    -- speaking a layout this addon cannot read will answer the retry exactly
    -- the same way, and the answer clock's give-up sentence would replace
    -- the one accurate diagnosis on screen ("Update dwah") with the one that
    -- is definitely wrong ("The server is not answering") -- about a server
    -- that had just answered. The mismatch branch stops the sweeps; this
    -- keeps a Refresh from starting them again.
    if (not state.protocolBad) then
        if (state.syncing and state.nextPage ~= nil) then
            local cat     = scopeCat();
            local spelled = cat == -1 and 'mine' or tostring(cat);

            need('page', string.format('%d/%s', state.nextPage, spelled),
                string.format('!dwa page %d %s', state.nextPage, spelled));
        end

        if (state.ordersSyncing and state.ordersNextPage ~= nil) then
            need('orders', state.ordersNextPage, string.format('!dwa orders %d', state.ordersNextPage));
        end

        --[[
            The market-box drain: ONE collect in flight, never a burst.
            `collectLeft` counts DOWN from the press, so the loop terminates
            whatever the server says, and the refusal branch in handleRecord
            zeroes it the moment a row cannot be delivered (a full bag).

            It also stops the moment the box reads empty, whatever the
            countdown still says -- another character on the account can
            take a row while this one drains, and a collect for an empty box
            is a refusal the player never asked for -- and it holds while
            the silence latch is up, because eighty lines into a server that
            is not answering is precisely what that latch exists to prevent.
            The first `d|` revives it.
        ]]
        if (state.collectLeft > 0 and state.boxrows <= 0) then
            state.collectLeft = 0;
        end

        if (state.collectLeft > 0 and not state.serverSilent) then
            local waited = os.clock() - state.collectAt;

            -- ONE IN FLIGHT. The pending flag is cleared by the collect's
            -- own z|, so the next row is asked for only once the last one
            -- has landed -- which is what makes the refusal branch able to
            -- stop the drain before another line is spent on a bag that is
            -- already full. A lost answer is not allowed to wedge it: past
            -- COLLECT_LOST the flag is dropped and the drain resumes.
            if (state.collectPending and waited > COLLECT_LOST) then
                -- THE CLOCK STARTS WHEN THE LINE LEAVES, not when it was
                -- queued -- the 2026-08-20 lesson the answer clock learned
                -- one function up. A collect stuck behind a page sweep's
                -- backlog is not a lost collect.
                local waiting = false;

                for _, queued in ipairs(queue) do
                    if (queued == '!dwa collect') then
                        waiting = true;

                        break;
                    end
                end

                if (waiting) then
                    state.collectAt = os.clock();
                else
                    state.collectPending = false;
                end
            end

            if (not state.collectPending and waited >= COLLECT_GAP) then
                state.collectLeft    = state.collectLeft - 1;
                state.collectPending = true;
                state.collectAt      = os.clock();

                issue('!dwa collect');
            end
        end
    end

    if (not state.open[1]) then
        return;
    end

    -- First open of the session: ask for everything once.
    if (not state.synced) then
        state.synced = true;

        refreshAll();
    end

    local pushed = theme.push();
    local ok, err = pcall(renderWindow);
    theme.pop(pushed);

    if (not ok) then
        reportRenderError(err);
    end
end);

ashita.events.register('packet_in', 'dwah_packet_in', function(e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender == DATA_SENDER) then
            local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

            -- Blocked BEFORE parsing: a record that throws must still never
            -- reach the chat log as line noise.
            e.blocked = true;

            local ok, err = pcall(handleRecord, message);

            if (not ok) then
                print(chat.header('dwah'):append(chat.error(tostring(err))));
            end
        end

        return;
    end

    -- Zone-in wipes all server-derived state: the next open re-syncs once
    -- the client's own zoning flag clears (the queue is already held shut by
    -- echo.canSend until then).
    if (e.id == 0x000A) then
        forget();

        state.synced       = false;
        state.syncing      = false;
        state.nextPage     = nil;
        state.ordersSyncing = false;
        state.ordersNextPage = nil;
        state.inbound      = nil;
        state.serverSilent = false;

        -- The history bookkeeping (1.4.0): the cache is the OLD session's
        -- market, the ask list names lines that will never be answered,
        -- and an envelope building aside belongs to nobody now.
        state.historyCache = {};
        state.asked        = {};
        state.arriving     = nil;
        state.arrivingItem = nil;
        state.hoverAsk     = nil;
        state.tabSelectBroken = false;

        -- And the Sell tab's quotes (1.5.0): a new character's bag, a
        -- server that may have grown the verb since, a question nobody
        -- can answer for a slot that no longer exists.
        state.quotes      = {};
        state.quotesAsked = {};
        state.quotesBatch = nil;
        state.noQuotes    = false;
        state.quickSell   = nil;

        --[[
            AND EVERY PENDING CONFIRM (1.6.0). A Buy confirm names a listing
            REF, a Fill confirm names a bag SLOT and an order id, and the
            price strip names a slot too -- all of them belonging to the
            session that just ended. They survived the zone line and sat on
            screen over the new one, one click from sending a claim about a
            row and a bag cell that are no longer the ones on screen. The
            server re-checks and refuses, so nothing was ever lost; what the
            player saw was a red refusal for a button they had every reason
            to trust.
        ]]
        state.confirmBuy   = nil;
        state.confirmFill  = nil;
        state.confirmOrder = false;
        state.sellSlot     = nil;
        state.sellPrice[1] = '';
        state.collectLeft  = 0;
        state.collectPending = false;

        -- The measurement and resolution caches are the CLIENT's, not the
        -- server's -- but they are the ones that grow with what the player
        -- has looked at, and a zone line is the natural place to let them
        -- go (the name and level caches stay: the DAT does not change).
        widths        = {};
        widthsCount   = 0;
        resolved      = {};
        resolvedCount = 0;

        -- AND THE PROTOCOL LATCH, which the reset above forgot. `protocolBad`
        -- parks the whole queue (pumpQueue empties it outright), and nothing
        -- anywhere cleared it -- so a window that saw one version mismatch
        -- stayed dead for the rest of the client session even after the
        -- server was updated and the player logged back in. Every sibling
        -- capability latch in the suite is re-probed here for exactly that
        -- reason: a map restart logs everyone out, so the server on the other
        -- side of a 0x000A may well be the updated one (dwscan and dwfishing
        -- say so in their own zone handlers). A mismatch that is still real
        -- re-announces itself on the very next d|.
        state.protocolBad  = false;

        -- The status line describes a session that has ended: the wallet and
        -- box counts under it were the OLD character's, and the next hello
        -- replaces them.
        clearStatus();
    end
end);

-- The player's own typing moves the throttle too: a hand-typed !dwa line is
-- a send this addon did not queue, and pacing off it keeps the client's
-- outgoing chat limiter honest (the dwsuite contract).
ashita.events.register('packet_out', 'dwah_packet_out', function(e)
    if (e.id == 0x00B5) then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwah_command', function(e)
    local args = e.command:args();

    -- LOWERCASED, because `:args()` hands back exactly what was typed and the
    -- client never normalises it -- `/Market` reached this comparison as
    -- `/Market`, matched nothing, and fell through to the game as an unknown
    -- command. Every stock Ashita addon tests with `:any()`, which lowercases
    -- both sides; the eight dw addons that already spell it `:lower()` are the
    -- convention this one was missing.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwah' and first ~= '/market') then
        return;
    end

    e.blocked = true;

    if (#args > 1 and args[2]:lower() == 'refresh') then
        refreshAll();

        return;
    end

    -- `/dwah history <itemid>` (1.5.1, 2026-09-04): another window -- the
    -- warehouse's Sell row History button -- asks for an item's full sale
    -- history: open, front the History tab, ask. Its own hover card only
    -- ever showed five; the whole table lives here.
    if (#args > 1 and args[2]:lower() == 'history' and #args < 3) then
        print(chat.header('dwah'):append(chat.error('`/dwah history <itemid>` wants an item id.')));

        return;
    end

    if (#args > 2 and args[2]:lower() == 'history') then
        -- INTEGRALITY IN THE GUARD (fixed 1.6.0), the house rule for every
        -- number that arrives as text. `tonumber` reads '2.5' and 'inf' as
        -- readily as '4096', and the old `> 0` test let both through to
        -- GetItemById and to string.format('%d', ...) on the wire -- and
        -- the caller here is ANOTHER ADDON's button, so the argument is not
        -- even a person's typing.
        local itemId = tonumber(args[3]);

        if (itemId == nil or itemId ~= math.floor(itemId) or itemId < 1 or itemId > 65535) then
            print(chat.header('dwah'):append(chat.error('`/dwah history <itemid>` wants a whole item id.')));

            return;
        end

        state.open[1] = true;
        askHistory(itemId, true);

        return;
    end

    --[[
        A WORD THIS HANDLER DOES NOT KNOW IS NOT A TOGGLE (1.6.0). Anything
        after `/dwah` used to fall through to the open/shut toggle, so a
        typo -- `/dwah histry 4096`, `/dwah refesh` -- silently did the one
        thing the player had not asked for and said nothing about the one
        they had. The command already blocks the line, so the game will
        never explain it either.
    ]]
    if (#args > 1) then
        print(chat.header('dwah'):append(chat.message(
            '/dwah opens or shuts the market. `/dwah refresh` re-asks the server. `/dwah history <itemid>` looks up that item.')));

        return;
    end

    state.open[1] = not state.open[1];

    -- Re-opening asks for a fresh account line: if the market moved while
    -- the window was shut (a counter sale, an alt's fill), the hello's k|
    -- disagrees with the model and the z| reconcile re-sweeps by itself.
    if (state.open[1] and state.synced) then
        issue('!dwa hello');
    end
end);
