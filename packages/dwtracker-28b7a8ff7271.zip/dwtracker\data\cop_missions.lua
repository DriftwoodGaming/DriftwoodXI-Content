-- dwtracker data -- Chains of Promathia missions (Phase 8, 2026-08-28;
-- DWTRACKER_COP_PLAN.md calls itself Phase 7, but the log already had one).
-- Names from the enum (scripts/globals/missions.lua, xi.mission.id.cop);
-- steps HAND-AUTHORED from scripts/missions/cop/*.lua + helpers.lua as
-- ground truth, corroborated against scripts/tests/missions/cop.lua.
-- Pure data: numeric ids and display strings only, no xi.*, no functions
-- (DWTRACKER_FORMAT.md decisions T2/§3-4). Loaded byte-identically by the
-- server module and the dwtracker addon; both hash these bytes, so an edit
-- that reaches only one side makes the addon refuse step rendering for
-- this area until the copies agree again. tools/dwtracker_lint.py must
-- pass before any edit here ships.
--
-- FOUR THINGS ABOUT CoP THAT SHAPE EVERY ENTRY BELOW:
--
-- 1. COMPLETION IS DERIVED. hasCompletedMission(6, id) is `id < current`
--    (lua_base_entity.cpp:8545) -- the complete[] bits are NEVER set for
--    this log. tracker_core SYNTHESIZES the cm| bitmap by walking the ids
--    authored here, so an id that is missing from this file can never be
--    marked complete. That is why the category and sub-line rows are
--    authored (name only) rather than skipped.
--
-- 2. PROGRESS LIVES IN PER-MISSION CHARVARS, not the log status word.
--    `mission:setVar(player, 'Status'|'Option', n)` writes
--    Mission[6][<id>]Status, which is exactly what the DSL's `var` atom
--    reads (FORMAT §4). The log-level missionStatus atom is the WRONG
--    atom here and appears nowhere in this file.
--
-- 3. THE STATUS-WORD NIBBLES ARE UNREADABLE. 3-3 and 5-3 track their
--    parallel paths in getMissionStatus(6, <position>) nibbles, and 7-4
--    and 8-1 track their NM sets the same way. No atom can read a nibble,
--    so those entries carry HONEST WORDING instead of a bright step
--    (FORMAT §6.8.1) -- a wrong bright step is the one forbidden outcome.
--
-- 4. THE AMULET CYCLES. MYSTERIOUS_AMULET is granted at 1-1, stolen at
--    2-1, re-granted at 2-4, lent to Prishe at 3-5 and drained at 5-1, so
--    a `ki` predicate on it is monotone in NO entry and is used in none.
--    The Lights (590-594) are stable until 7-5 strips one; they are
--    described in wording, never depended on across a mission boundary.
return {
    kind = 'missions',
    log = 6,
    area = 'cop_missions',
    label = "Chains of Promathia",
    entries = {
        [101] = { -- ANCIENT_FLAMES_BECKON (1-0)
            name = "Ancient Flames Beckon",
            gated = 'ENABLE_COP',
            steps = {
                {
                    -- The opening chain lives in 1_1_The_Rites_of_Life.lua's
                    -- FIRST section (check: ENABLE_COP == 1 and currentMission
                    -- < 110), and its own progress rides the UNPREFIXED
                    -- charvar [COP]TalesBeginning, which the var atom cannot
                    -- read (FORMAT §6.8.1). One honest step, no sub-states.
                    text = "Walk into Lower Delkfutt's Tower from Qufim Island and let the cutscenes run. They hand you The Rites of Life at the end; nothing else starts this.",
                    pos  = "Qufim Island, tower entrance (!pos -286 -20 320)",
                },
            },
        },
        [110] = { -- THE_RITES_OF_LIFE (1-1)
            name = "The Rites of Life",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Zone into Upper Jeuno for the cutscene that sets the errand.",
                    pos  = "Lower Jeuno, the Upper Jeuno stairs (!pos 2.2 -3.2 58.4)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "See Monberaux in the Infirmary. He sends you off with the Mysterious Amulet.",
                    pos  = "Upper Jeuno (!pos -42 0 -2)",
                },
            },
        },
        [118] = { -- BELOW_THE_ARKS (1-2)
            name = "Below the Arks",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Ask Pherimociel in Ru'Lude Gardens about the spires. High Wind and Rainhard have more to say afterwards, and Monberaux has a word before you go.",
                    pos  = "Ru'Lude Gardens (!pos -31.6 1 68)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- 'Option' is written by the helpers module the script
                    -- requires; it holds the crag you are inside (1 Holla,
                    -- 2 Dem, 3 Mea) and is cleared when you seal memories or
                    -- win the spire. The Status conjunct is what makes the
                    -- chain provable (Option is not monotone on its own).
                    text = "Touch a Shattered Telepoint -- La Theine, Konschtat or Tahrongi -- then take the Large Apparatus in the Hall of Transference down into that Promyvion.",
                    pos  = "La Theine (J-8) (!pos 334 19 -60) / Konschtat (I-7) (!pos 135 19 220) / Tahrongi Canyon (I-6) (!pos 179 35 255)",
                    done = { allOf = { { var = 'Status', gte = 1 }, { var = 'Option', gte = 1 } } },
                },
                {
                    text = "Climb to the Spire at the far end and win the fight there. The Light it leaves ends this mission and opens the other two crags.",
                    pos  = "Promyvion-Holla / -Dem / -Mea, then the Spire",
                },
            },
        },
        [128] = { -- THE_MOTHERCRYSTALS (1-3)
            name = "The Mothercrystals",
            gated = 'ENABLE_COP',
            steps = {
                {
                    -- Status flips to 1 on the Hall of Transference cutscene
                    -- that only fires with TWO Lights held (1_3, event 155),
                    -- i.e. exactly when the second crag is behind you.
                    text = "Two crags are left. Touch either Shattered Telepoint and clear that spire for its Light -- the telepoint sends you straight down once you have been before.",
                    pos  = "La Theine (J-8) (!pos 334 19 -60) / Konschtat (I-7) (!pos 135 19 220) / Tahrongi Canyon (I-6) (!pos 179 35 255)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "One crag to go. The third Light carries you out of the spire and drops you in Lufaise Meadows, on the far side of the world.",
                    pos  = "The last Promyvion, then its Spire",
                },
            },
        },
        [138] = { -- AN_INVITATION_WEST (2-1)
            name = "An Invitation West",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Lufaise Meadows takes the Mysterious Amulet off you on the way in. Nothing you can do about it -- watch the scene.",
                    pos  = "Lufaise Meadows",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Cross the meadows and let yourself into the Tavnazian Safehold. Arriving is the whole mission.",
                    pos  = "Lufaise Meadows to Tavnazian Safehold",
                },
            },
        },
        [218] = { -- THE_LOST_CITY (2-2)
            name = "The Lost City",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Find Despachiaire in the Tavnazian Safehold and hear him out. Liphatte, Justinius and Arquil pick up new lines once he has spoken.",
                    pos  = "Tavnazian Safehold (!pos 108 -40 -83)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Take the sewer entrance under the Safehold.",
                    pos  = "Tavnazian Safehold (!pos 28 -12 44)",
                },
            },
        },
        [228] = { -- DISTANT_BELIEFS (2-3)
            name = "Distant Beliefs",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Hunt the Minotaur down in the Phomiuna Aqueducts. Justinius has directions if you want them first.",
                    pos  = "Phomiuna Aqueducts (!pos 60 0.5 304)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- Status 2 is written by the Wooden Ladder NPC script
                    -- (Phomiuna_Aqueducts/npcs/Wooden_Ladder.lua:86, event
                    -- 35), not by the mission file -- one ladder of the set,
                    -- and only within reach.
                    text = "Climb the wooden ladder past the Minotaur's ground for the scene above it.",
                    pos  = "Phomiuna Aqueducts, the far ladder",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Keep going to the ornate gate below for the second scene.",
                    pos  = "Phomiuna Aqueducts, Ornate Gate (!pos -95 -24 60)",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Report to Justinius back in the Safehold.",
                    pos  = "Tavnazian Safehold (!pos 76 -34 68)",
                },
            },
        },
        [238] = { -- AN_ETERNAL_MELODY (2-4)
            name = "An Eternal Melody",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Open the Walnut Door in the Safehold. The Mysterious Amulet comes back to you here.",
                    pos  = "Tavnazian Safehold (!pos 111 -41 41)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Walk out to the eastern Dilapidated Gate on Misareaux Coast for the next scene.",
                    pos  = "Misareaux Coast (!pos 260 9 -435)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Come back into the Safehold and stand where the scene finds you, near the lower ledge.",
                    pos  = "Tavnazian Safehold (!pos -5 -24 18)",
                },
            },
        },
        [248] = { -- ANCIENT_VOWS (2-5)
            name = "Ancient Vows",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Misareaux Coast, the western Dilapidated Gate. Justinius has a parting word in the Safehold if you want it.",
                    pos  = "Misareaux Coast (!pos -259 -30 276)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Cross into Riverne - Site #A01 and take the cutscene on the way in.",
                    pos  = "Riverne - Site #A01",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Enter Monarch Linn and win Ancient Vows. The victory drops you in South Gustaberg.",
                    pos  = "Monarch Linn",
                },
            },
        },
        [257] = { -- A_TRANSIENT_DREAM (category row)
            -- A journal category, not a playable mission: no script writes
            -- it as `current`, so it can never render active. It is authored
            -- because the CoP completed bitmap is synthesized from THIS
            -- list, and a missing id could never be marked complete.
            name = "A Transient Dream",
            gated = 'ENABLE_COP',
        },
        [258] = { -- THE_CALL_OF_THE_WYRMKING (3-1)
            name = "The Call of the Wyrmking",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Zone into South Gustaberg for the opening scene. You are already standing in it if Monarch Linn just spat you out.",
                    pos  = "South Gustaberg",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Walk into Port Bastok, near the water, for the second scene.",
                    pos  = "Port Bastok (!pos -100 0 -10)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "See Cid at the Metalworks.",
                    pos  = "Metalworks (!pos -12 -12 1)",
                },
            },
        },
        [318] = { -- A_VESSEL_WITHOUT_A_CAPTAIN (3-2)
            name = "A Vessel Without a Captain",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Lower Jeuno: the door to Neptune's Spire. Cid has a line at the Metalworks first if you have not heard it.",
                    pos  = "Lower Jeuno (!pos 35 0 -15)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Go up to Ru'Lude Gardens and stand before the palace; the scene finds you there.",
                    pos  = "Ru'Lude Gardens (!pos 0 3 45)",
                },
            },
        },
        [325] = { -- THE_ROAD_FORKS (3-3)
            -- SPLIT FLOW, DELIBERATELY UNTRACKED (FORMAT §6.8.1). The two
            -- errands run in parallel and each is held in a NIBBLE of the
            -- log status word -- getMissionStatus(6, SANDORIA) and
            -- (6, WINDURST) -- which no atom can read. A linear step list
            -- would send half the players down the wrong half, so this
            -- entry says the truth once and highlights nothing beyond it.
            name = "The Road Forks",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Two errands, both needed. San d'Oria: Arnau, Chasalvige, Guilloud at Carpenters' Landing, then Hinaree. Windurst: Ohbiru-Dohbiru, Yoran-Oran, Kyume-Romeh, Honoi-Gomoi, Attohwa Chasm, Yujuju. Then Cid.",
                    pos  = "Northern San d'Oria (!pos 148 0 139) / Windurst Waters (!pos 23 -5 -193) / Metalworks (!pos -12 -12 1)",
                },
            },
        },
        [335] = { -- DESCENDANTS_OF_A_LINE_LOST (journal row, no script)
            name = "Descendants of a Line Lost",
            gated = 'ENABLE_COP',
        },
        [341] = { -- COMEDY_OF_ERRORS_ACT_I (journal row, no script)
            name = "Comedy of Errors: Act I",
            gated = 'ENABLE_COP',
        },
        [350] = { -- TENDING_AGED_WOUNDS (3-4)
            name = "Tending Aged Wounds",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Zone into Lower Jeuno for the scene. Cid has a line at the Metalworks beforehand.",
                    pos  = "Lower Jeuno",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Try the door to Neptune's Spire again.",
                    pos  = "Lower Jeuno (!pos 35 0 -15)",
                },
            },
        },
        [358] = { -- DARKNESS_NAMED (3-5)
            name = "Darkness Named",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Monberaux in Upper Jeuno borrows the Mysterious Amulet for Prishe. Aldo, Harnek and Sattal-Mansal have their own lines about it.",
                    pos  = "Upper Jeuno (!pos -42 0 -2)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Ghebi Damomohe of the Tenshodo, in Lower Jeuno, names his price.",
                    pos  = "Lower Jeuno, Tenshodo H.Q. (!pos 15.5 0 -7.6)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Trade him a Gray, Carmine or Cyan Chip. He pays for it and hands over the Pso'Xja Pass.",
                    pos  = "Lower Jeuno, Tenshodo H.Q. (!pos 15.5 0 -7.6)",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Take the pass into The Shrouded Maw, off Beaucedine Glacier.",
                    pos  = "Beaucedine Glacier to The Shrouded Maw",
                    done = { var = 'Status', gte = 4 },
                },
                {
                    text = "Win Darkness Named at the bottom of the Maw.",
                    pos  = "The Shrouded Maw",
                    done = { var = 'Status', gte = 5 },
                },
                {
                    text = "Take the news back to Monberaux in Upper Jeuno.",
                    pos  = "Upper Jeuno (!pos -42 0 -2)",
                },
            },
        },
        [368] = { -- SHELTERING_DOUBT (4-1)
            name = "Sheltering Doubt",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Zone into the Tavnazian Safehold for the opening scene.",
                    pos  = "Tavnazian Safehold",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Speak to Despachiaire.",
                    pos  = "Tavnazian Safehold (!pos 108 -40 -83)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Justinius has the rest of it, then head out to the eastern Dilapidated Gate on Misareaux Coast.",
                    pos  = "Tavnazian Safehold (!pos 76 -34 68) / Misareaux Coast (!pos 260 9 -435)",
                },
            },
        },
        [418] = { -- THE_SAVAGE (4-2)
            name = "The Savage",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "The western Dilapidated Gate on Misareaux Coast. Say yes and it puts you into Riverne - Site #B01.",
                    pos  = "Misareaux Coast (!pos -259 -30 276)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Cross Riverne to Monarch Linn and win The Savage.",
                    pos  = "Riverne - Site #B01 to Monarch Linn",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Tell Justinius in the Safehold how it went.",
                    pos  = "Tavnazian Safehold (!pos 76 -34 68)",
                },
            },
        },
        [428] = { -- THE_SECRETS_OF_WORSHIP (4-3)
            name = "The Secrets of Worship",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Open the Walnut Door in the Safehold again. Justinius has a word first.",
                    pos  = "Tavnazian Safehold (!pos 111 -41 41)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Misareaux Coast, the iron gate on the northern shore. Say yes and it drops you into the Sacrarium.",
                    pos  = "Misareaux Coast (H-4) (!pos 52.6 -24.1 740)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Inside the Sacrarium, work east to the wooden gate and open it from the correct side for the scene.",
                    pos  = "Sacrarium (!pos 45.5 -1.5 10)",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    -- The ki atom sits in the step just before the done-less
                    -- final (FORMAT §6.4): the key is not spent, but the
                    -- placement rule is satisfied either way.
                    text = "Search the ??? drawers until Old Professor Mariselle comes out of one. Beat him, then take the Reliquiarium Key from that drawer.",
                    pos  = "Sacrarium drawers, varies (!pos 102.7 -3.1 127.3)",
                    done = { allOf = { { var = 'Status', gte = 3 }, { ki = 582 } } },
                },
                {
                    text = "Open the wooden gate with the key.",
                    pos  = "Sacrarium (!pos 45.5 -1.5 10)",
                },
            },
        },
        [438] = { -- SLANDEROUS_UTTERINGS (4-4)
            name = "Slanderous Utterings",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Walk the lower reach of the Tavnazian Safehold; the scene finds you there. Despachiaire has a line of his own.",
                    pos  = "Tavnazian Safehold (!pos 106 -40 -80)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Go to Sealion's Den and try the Iron Gate there.",
                    pos  = "Sealion's Den (!pos 612 132 774)",
                },
            },
        },
        [448] = { -- THE_ENDURING_TUMULT_OF_WAR (5-1)
            name = "The Enduring Tumult of War",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Zone into Port Bastok for the scene. Despachiaire, Chasalvige and Anoki each have optional lines about what is coming.",
                    pos  = "Port Bastok",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "See Cid at the Metalworks.",
                    pos  = "Metalworks (!pos -12 -12 1)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Beaucedine Glacier: take the iron grate into Pso'Xja and walk in from the western side for the scene.",
                    pos  = "Beaucedine Glacier (F-7) (!pos -340 -93 156.7)",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Trip the trap inside Pso'Xja and put Nunyunuwi down.",
                    pos  = "Pso'Xja",
                    done = { var = 'Status', gte = 4 },
                },
                {
                    text = "Take the second Stone Door to drop into Promyvion-Vahzl. The Light of Vahzl and the drained amulet are waiting on the other side.",
                    pos  = "Pso'Xja to Promyvion-Vahzl",
                },
            },
        },
        [518] = { -- DESIRES_OF_EMPTINESS (5-2)
            name = "Desires of Emptiness",
            gated = 'ENABLE_COP',
            steps = {
                {
                    -- 'Option' is a six-bit field (3 kills, 3 cutscenes) and
                    -- Status flips to 1 only when all three cutscenes are
                    -- viewed, so Status is the honest single marker here.
                    text = "Three Memory Fluxes in Promyvion-Vahzl. Touch each to call its keeper -- Propagator, Solicitor, Ponderer -- put it down, then touch the flux again for the scene.",
                    pos  = "Promyvion-Vahzl (!pos 180 -2.5 -60) / (!pos 420 -2.5 140) / (!pos -340 -2.5 140)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Go up into the Spire of Vahzl. Miss any of the three scenes and the spire sends you back instead.",
                    pos  = "Spire of Vahzl",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Win Desires of Emptiness. The victory throws you out onto Beaucedine Glacier.",
                    pos  = "Spire of Vahzl",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Watch the scene on Beaucedine Glacier. Leigon-Moigon, Potete and Torino-Samarino have lines afterwards.",
                    pos  = "Beaucedine Glacier",
                    done = { var = 'Status', gte = 4 },
                },
                {
                    text = "Bring it to Cid at the Metalworks.",
                    pos  = "Metalworks (!pos -12 -12 1)",
                },
            },
        },
        [530] = { -- THREE_PATHS (5-3)
            -- THE SPLIT FLOW OF THIS PHASE, DELIBERATELY UNTRACKED. All
            -- three sub-lines advance in NIBBLES of the log status word
            -- (LOUVERANCE, TENZEN, ULMIA), which no atom can read, and they
            -- interleave freely: a linear step list cannot describe them and
            -- a bright step would be wrong for two players in three. One
            -- honest step, per FORMAT §6.8.1.
            name = "Three Paths",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Three journeys, any order, all three needed. Louverance: Despachiaire, Perih Vashai, Bibiki Bay, Movalpolos. Tenzen: La Theine, Pso'Xja, Monberaux, Batallia, Delkfutt. Ulmia: Hinaree, Chasalvige, Kerutoto, the gullies.",
                    pos  = "Cid, Metalworks (!pos -12 -12 1) -- he tracks all three and tells you what is left",
                },
            },
        },
        [543] = { -- PARTNERS_WITHOUT_FAME (5-3 sub-line row, no script)
            name = "Partners Without Fame",
            gated = 'ENABLE_COP',
        },
        [552] = { -- SPIRAL (5-3 sub-line row, no script)
            name = "Spiral",
            gated = 'ENABLE_COP',
        },
        [560] = { -- WHERE_MESSENGERS_GATHER (5-3 sub-line row, no script)
            name = "Where Messengers Gather",
            gated = 'ENABLE_COP',
        },
        [568] = { -- FLAMES_FOR_THE_DEAD (5-3 sub-line row, no script)
            name = "Flames for the Dead",
            gated = 'ENABLE_COP',
        },
        [578] = { -- FOR_WHOM_THE_VERSE_IS_SUNG (6-1)
            name = "For Whom the Verse is Sung",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Pherimociel in Ru'Lude Gardens has the summons.",
                    pos  = "Ru'Lude Gardens (!pos -31.6 1 68)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Go down to the Marble Bridge in Upper Jeuno.",
                    pos  = "Upper Jeuno (!pos -96.6 -0.2 92.3)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Return to Ru'Lude Gardens; the closing scene plays on the way in.",
                    pos  = "Ru'Lude Gardens",
                },
            },
        },
        [618] = { -- A_PLACE_TO_RETURN (6-2)
            name = "A Place to Return",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Stand before the palace in Ru'Lude Gardens for the scene.",
                    pos  = "Ru'Lude Gardens (!pos 0 3 45)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- 'Option' is a three-bit kill field; 7 is all three
                    -- Warders down. The Status conjunct keeps the chain
                    -- provable and stops an early bit from skipping step 1.
                    text = "The eastern Dilapidated Gate on Misareaux Coast calls up three Warders -- Aglaia, Euphrosyne and Thalia. Beat all three.",
                    pos  = "Misareaux Coast (!pos 260 9 -435)",
                    done = { allOf = { { var = 'Status', gte = 1 }, { var = 'Option', gte = 7 } } },
                },
                {
                    text = "Touch the gate once more.",
                    pos  = "Misareaux Coast (!pos 260 9 -435)",
                },
            },
        },
        [628] = { -- MORE_QUESTIONS_THAN_ANSWERS (6-3)
            name = "More Questions than Answers",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Pherimociel in Ru'Lude Gardens again.",
                    pos  = "Ru'Lude Gardens (!pos -31.6 1 68)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Try the Audience Chamber door in Ru'Lude Gardens for the next scene. Auchefort has a line about it.",
                    pos  = "Ru'Lude Gardens",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Take a boat or a chocobo to Selbina and speak to Mathilde.",
                    pos  = "Selbina (!pos 12.6 -8.3 -7.6)",
                },
            },
        },
        [638] = { -- ONE_TO_BE_FEARED (6-4)
            name = "One to be Feared",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Cid at the Metalworks. Despachiaire, Justinius and the Ironclad Gorilla in the Safehold have optional lines.",
                    pos  = "Metalworks (!pos -12 -12 1)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Zone into Sealion's Den for the briefing.",
                    pos  = "Sealion's Den",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Try the Iron Gate. Sueleen has something to say first.",
                    pos  = "Sealion's Den (!pos 612 132 774)",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Win One to be Feared: mammets, then Omega, then Ultima, with the door opening the next stage each time.",
                    pos  = "Sealion's Den, the airship",
                    done = { var = 'Status', gte = 4 },
                },
                {
                    text = "Zone back into Sealion's Den for the closing scene; it sends you to Lufaise Meadows.",
                    pos  = "Sealion's Den",
                },
            },
        },
        [648] = { -- CHAINS_AND_BONDS (7-1)
            name = "Chains and Bonds",
            gated = 'ENABLE_COP',
            steps = {
                {
                    -- With a full inventory the CS banks the ring against
                    -- RingStashed instead; the ??? in Lufaise hands it over
                    -- afterwards. Status only reaches 1 once you hold it.
                    text = "Lufaise Meadows: the scene leaves you the Ducal Guard's Ring. Free an inventory slot first, or collect it from the marker there afterwards.",
                    pos  = "Lufaise Meadows",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Zone into the Tavnazian Safehold.",
                    pos  = "Tavnazian Safehold",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Three scenes close it, in any order: the Walnut Door, the sewer entrance, and zoning into Sealion's Den.",
                    pos  = "Tavnazian Safehold: Walnut Door (!pos 111 -41 41) / (!pos 28 -12 44), then Sealion's Den",
                },
            },
        },
        [718] = { -- FLAMES_IN_THE_DARKNESS (7-2)
            name = "Flames in the Darkness",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "The western Dilapidated Gate on Misareaux Coast.",
                    pos  = "Misareaux Coast (!pos -259 -30 276)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Sueleen at Sealion's Den.",
                    pos  = "Sealion's Den (!pos 612 132 774)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Stand before the palace in Ru'Lude Gardens.",
                    pos  = "Ru'Lude Gardens (!pos 0 3 45)",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Finish at the Marble Bridge in Upper Jeuno.",
                    pos  = "Upper Jeuno (!pos -96.6 -0.2 92.3)",
                },
            },
        },
        [728] = { -- FIRE_IN_THE_EYES_OF_MEN (7-3)
            name = "Fire in the Eyes of Men",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Mine Shaft 2716, deep in Movalpolos: the Shaft Entrance.",
                    pos  = "Mine Shaft 2716",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- 'Timer' is set to VanadielUniqueDay() + 1 by the first
                    -- Cid scene, so it is 0 before and a large day number
                    -- after: gte 1 is exactly "the first scene happened".
                    text = "Tell Cid at the Metalworks. He needs the rest of the day to think.",
                    pos  = "Metalworks (!pos -12 -12 1)",
                    done = { allOf = { { var = 'Status', gte = 1 }, { var = 'Timer', gte = 1 } } },
                },
                {
                    text = "Come back to Cid on the next Vana'diel day. He repeats himself until then.",
                    pos  = "Metalworks (!pos -12 -12 1)",
                },
            },
        },
        [738] = { -- CALM_BEFORE_THE_STORM (7-4)
            name = "Calm Before the Storm",
            gated = 'ENABLE_COP',
            steps = {
                {
                    -- The three kills are bits of the CID nibble of the log
                    -- status word -- unreadable (FORMAT §6.8.1) -- so the
                    -- readable marker is the key item Cid hands over once
                    -- all three are done. It is not spent before the
                    -- turn-in, and it sits in the step before the done-less
                    -- final, which is where §6.4 allows it.
                    text = "Three creatures, any order: Boggelmann from the Storage Compartment on Misareaux Coast, the Cryptonberry Executor and its assassins at Carpenters' Landing, Dalham at Bibiki Bay. Then Cid, for the letters.",
                    pos  = "Misareaux Coast (!pos -312 -34 187) / Carpenters' Landing (!pos 120 -5 -390) / Bibiki Bay (!pos 100 -45 940)",
                    done = { ki = 701 },
                },
                {
                    text = "Carry the letters to Sueleen at Sealion's Den.",
                    pos  = "Sealion's Den (!pos 612 132 774)",
                },
            },
        },
        [748] = { -- THE_WARRIORS_PATH (7-5)
            name = "The Warrior's Path",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "The Iron Gate at Sealion's Den.",
                    pos  = "Sealion's Den (!pos 612 132 774)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Win The Warrior's Path.",
                    pos  = "Sealion's Den, the airship",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Zone back into Sealion's Den for the scene that sends you on.",
                    pos  = "Sealion's Den",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Al'Taieu. The scene on arrival takes the drained amulet and one of your Lights, and ends the mission.",
                    pos  = "Al'Taieu",
                },
            },
        },
        [758] = { -- EMPTINESS_BLEEDS (category row, no script)
            name = "Emptiness Bleeds",
            gated = 'ENABLE_COP',
        },
        [800] = { -- GARDEN_OF_ANTIQUITY (8-1)
            name = "Garden of Antiquity",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Touch the Crystalline Field at the centre of Al'Taieu.",
                    pos  = "Al'Taieu (!pos 0.1 -10 -464)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- Which towers are done is held in nibbles of the log
                    -- status word (CID / RUBIOUS), unreadable by any atom,
                    -- so the three towers are one step and Status 2 -- the
                    -- centre crystal's closing scene -- is what ends it.
                    text = "Three outlying Rubious Crystals, south, west and east. Each calls up three Ruaern; clear all three sets, then return to the Crystalline Field.",
                    pos  = "Al'Taieu (!pos 0 -6.25 -737) / (!pos -684 -6.25 -222) / (!pos 684 -6.25 -222)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Cross into the Grand Palace of Hu'Xzoi and use the Gate of the Gods. It leaves you the Tavnazian Ring.",
                    pos  = "Grand Palace of Hu'Xzoi (!pos -20 0.1 -283)",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Use the Particle Gate beyond it.",
                    pos  = "Grand Palace of Hu'Xzoi (!pos 5 0 -320)",
                },
            },
        },
        [818] = { -- A_FATE_DECIDED (8-2)
            name = "A Fate Decided",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "The Cermet Portal at the far end of the Grand Palace of Hu'Xzoi wakes Ixghrah. Put it down.",
                    pos  = "Grand Palace of Hu'Xzoi (!pos 420 0 401)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Touch the Cermet Portal again.",
                    pos  = "Grand Palace of Hu'Xzoi (!pos 420 0 401)",
                },
            },
        },
        [828] = { -- WHEN_ANGELS_FALL (8-3)
            name = "When Angels Fall",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "Zone into The Garden of Ru'Hmet. The scene leaves Prishe's amulet with you.",
                    pos  = "The Garden of Ru'Hmet",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Touch any Ebon Panel for the scene that explains them.",
                    pos  = "The Garden of Ru'Hmet (!pos 422 -5.2 -100)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Find the Ebon Panel that belongs to your own race and stand right against it. It gives your Light back.",
                    pos  = "Ru'Hmet: Hume 422/-100, Elvaan 740/-342, Taru 258/-700, Mithra 100/-338, Galka 578/-700",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Take the Particle Gate in the south-east and win When Angels Fall.",
                    pos  = "The Garden of Ru'Hmet (!pos 420 -2.05 400)",
                    done = { var = 'Status', gte = 5 },
                },
                {
                    text = "Touch the Luminous Convergence beyond it for the scene that follows.",
                    pos  = "The Garden of Ru'Hmet (!pos 420 -2 520)",
                    done = { var = 'Status', gte = 6 },
                },
                {
                    text = "Return to Al'Taieu; the amulet goes back to Prishe there and the mission ends.",
                    pos  = "Al'Taieu",
                },
            },
        },
        [840] = { -- DAWN (8-4)
            name = "Dawn",
            gated = 'ENABLE_COP',
            steps = {
                {
                    text = "The Empyreal Paradox, past Al'Taieu. Touch the Transcendental Radiance for the scene.",
                    pos  = "Empyreal Paradox",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Win Dawn.",
                    pos  = "Empyreal Paradox",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Let the scenes after the fight run to their end. The last of them leaves you the Tear of Altana and sends you back to Al'Taieu.",
                    pos  = "Empyreal Paradox",
                    done = { var = 'Status', gte = 4 },
                },
                {
                    -- Five farewell cutscenes, one per bit of 'Option',
                    -- unlocked at the next JST midnight ('Timer'). Status 5
                    -- is the honest marker: Ru'Lude only fires once all five
                    -- bits are cleared, so reaching 5 proves the set is done.
                    text = "Five farewells open after midnight Japan time (11 AM US Eastern): Hinaree/Uleguerand/Hinaree, Chipmy-Popmy then the Warmachine on Purgonorgo Isle, Mhaura, Oldton Movalpolos, Cid. Then Ru'Lude Gardens.",
                    pos  = "S. San d'Oria / Port Windurst / Mhaura / Oldton Movalpolos / Metalworks",
                    done = { var = 'Status', gte = 5 },
                },
                {
                    text = "The Marble Bridge in Upper Jeuno.",
                    pos  = "Upper Jeuno (!pos -96.6 -0.2 92.3)",
                    done = { var = 'Status', gte = 6 },
                },
                {
                    text = "The Walnut Door in the Tavnazian Safehold.",
                    pos  = "Tavnazian Safehold (!pos 111 -41 41)",
                    done = { var = 'Status', gte = 7 },
                },
                {
                    text = "Lufaise Meadows, one last time.",
                    pos  = "Lufaise Meadows",
                    done = { var = 'Status', gte = 8 },
                },
                {
                    text = "Gilgamesh in Norg closes the book, through the quest Apocalypse Nigh.",
                    pos  = "Norg (!pos 122.5 -9 -12)",
                },
            },
        },
        [850] = { -- THE_LAST_VERSE
            -- The resting id after Dawn: 8_4_Dawn.lua's nextMission grants
            -- it and nothing ever advances past it, so it is the CoP log's
            -- permanent "current" for anyone who has finished the storyline
            -- -- exactly the shape Zilart 31 has, and authored the same way:
            -- a terminal row with NO steps. The linter pins its gate.
            name = "The Last Verse",
            gated = 'ENABLE_COP',
        },
    },
}
