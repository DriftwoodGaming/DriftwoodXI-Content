-- The one list both consumers iterate; a file stem here is also its wire
-- token in h| records. Generated for the quest and mission areas by
-- tools/dwtracker_names.py; hidden_quests was added by hand in Phase 5 and
-- has no generator (see the header of hidden_quests.lua for why it is not
-- shaped like the others).
return {
    'sandoria_quests',
    'bastok_quests',
    'windurst_quests',
    'jeuno_quests',
    'otherareas_quests',
    'outlands_quests',
    'sandoria_missions',
    'bastok_missions',
    'windurst_missions',
    'zilart_missions',
    'cop_missions',
    'hidden_quests',
}
