-- dwtracker data -- hidden quests (Phase 5).
--
-- These are the journal-less mini-quests in scripts/quests/hiddenQuests/.
-- They are NOT quests as the rest of this wire understands the word: every
-- one is a HiddenQuest container with no (log, id) at all, so there is no
-- quest status to read, no journal entry to name them, and no completion
-- bit -- HiddenQuest:complete wipes the container's vars, which is the only
-- trace they ever leave. Consequences, all deliberate:
--
--   * `log` is 255, which is not a quest log and never can be
--     (MAX_QUESTAREA is 11). It is a wire discriminator, nothing more.
--   * `container` names the HQuest[<name>] var prefix the evaluator reads,
--     the way `log`/`id` do for a real quest.
--   * SHOW ONLY ONCE BEGUN: an entry renders only while its FIRST step is
--     already done. Before the player has touched the quest that predicate
--     is false, and after completion the container's vars are wiped so it
--     goes false again -- the entry appears when the player starts and
--     disappears when they finish, and is never advertised. That is why
--     every entry here needs at least two steps and why step 1's predicate
--     must be the "begun" marker and nothing else.
--   * There is no Completed tab for these. There is no completion bit to
--     build one from, and inventing one would be guessing.
--
-- Scripts deliberately NOT authored here are listed with their reason in
-- HIDDEN_EXEMPT in tools/dwtracker_lint.py -- the linter fails if a
-- hiddenQuests script is neither authored nor exempt, so silence is not a
-- possible outcome.
--
-- Pure data: numeric ids and display strings only, no xi.*, no functions
-- (DWTRACKER_FORMAT.md decisions T2/§3-4). Loaded byte-identically by the
-- server module and the dwtracker addon; both hash these bytes.
-- tools/dwtracker_lint.py must pass before edits ship.
return {
    kind = 'hidden',
    log = 255,
    area = 'hidden_quests',
    label = "Hidden",
    entries = {
        [1] = { -- HQuest[CrimsonOrb]
            container = 'CrimsonOrb',
            name = "Crimson Orb",
            steps = {
                {
                    text = "Examine the Wall of Banishing in Davoi. The sealed cave behind it is what starts this off.",
                    pos  = "Davoi (!pos 181 0 -218)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Ask Sedal-Godjal in Davoi about the wall. He parts with the White Orb.",
                    pos  = "Davoi (!pos 185 -3 -116)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Carry the orb to all four ponds in Davoi -- Groaning, Howling, Wailing and Screaming. The fourth one curses you and finishes blackening it.",
                    pos  = "Davoi (Groaning Pond !pos 101 0 60)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Take the cursed orb back to Sedal-Godjal for the Crimson Orb.",
                    pos  = "Davoi (!pos 185 -3 -116)",
                },
            },
        },
        [2] = { -- HQuest[portalCharm]
            container = 'portalCharm',
            name = "Portal Charm",
            steps = {
                {
                    text = "Trade a Rolanberry to Kupipi in Heaven's Tower. Windurstian, rank 3 or better -- she keeps the berry and remembers you.",
                    pos  = "Heaven's Tower (!pos 2 0 30)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Finish the Windurst mission Written in the Stars, then speak to Kupipi again for the Portal Charm. Trading the berry after that mission is already done hands it over on the spot instead.",
                    pos  = "Heaven's Tower (!pos 2 0 30)",
                },
            },
        },
    },
}
