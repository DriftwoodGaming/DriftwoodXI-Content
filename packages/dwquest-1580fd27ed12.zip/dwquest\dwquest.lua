--[[
* DriftwoodXI -- dwquest
*
* The Drift Board in a window: the three daily and three weekly contracts
* offered to your level band, the ones you have signed with their counters
* moving as you fight, what each pays, how long is left, and your Drift Coins.
* Accept and abandon are buttons. `/quests` opens it from anywhere -- there is
* no NPC to walk to, because the window IS the quest giver.
*
* The arrows by the band label page through every level band's board -- a
* read, so a player can see what other jobs would be offered before deciding
* to switch. Accepting stays own-band only (the server resolves accept off
* the real level), and one contract per slot per reset holds ACROSS bands:
* an offer whose slot is already spent renders its sentence, not a button.
*
* Below them sits the server-wide contract: one bar the whole server pushes,
* with no button, because there is no verb that accepts it -- you contribute by
* killing, and the card's job is to say whether this account is on the payout.
*
* The second tab is the Drift Exchange: today's four augment offers, the gear
* they can go on -- yours and your offline alts' -- how many of an item's four
* augment slots are used, and the two-step price-then-buy that spends the
* coins the first tab earns.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It ships no pool, no prices, no progress and no arithmetic. Every contract,
* every count, every reward and every countdown arrives as _DWUDATA records
* answering `!dwu hello` (documentation/dwu_protocol.md), and the server
* re-resolves the contract from its own rotation whichever way the command
* arrived. A click issues a line a player could type (`!dwu accept d1`), and
* THE CLIENT NEVER SENDS A QUEST DEFINITION -- it sends a slot name. There is
* no record on this wire that could tell the server what a contract needs,
* pays, or is worth, so a bug in this window cannot mint a coin.
*
* THE SAME IS TRUE OF THE STOREFRONT, WHERE IT MATTERS MORE. The price is a
* `p|` record; the item is named by the id a `c|` record carried; the eligible
* gear is the server's own screen and not this client's inventory, which
* cannot see an offline alt's bags and knows none of the rules. The Confirm
* button exists only while a quote is armed, a quote is armed only by a `p|`,
* and the click that sends `confirm` disarms it in the same statement -- so
* one quote can buy at most one thing, and a window that never asked can buy
* nothing at all.
*
* THE ONE NUMBER THAT MOVES LOCALLY IS A CLOCK. The board header and every
* contract carry countdowns that were exact when the server built the record;
* the window ticks them down between syncs and re-asks when the rotation one
* reaches zero (dwu_protocol.md, `y|`). Nothing else here is computed --
* not a price, not a payout, not a progress count.
*
* TYPING `!drift` ON ITS OWN OPENS THIS WINDOW. The line is intercepted before
* it leaves the client; every other !drift command passes through.
*
* TURN IT OFF AND NOTHING IS LOST. `!drift`, `!drift accept d1`,
* `!drift abandon a1`, `!drift balance`, `!drift augments`, `!drift gear x1`,
* `!drift augment x1 Bronze Sword` and `!drift confirm` all work typed. This
* is friendlier; it is not required.
--]]

addon.name    = 'dwquest';
addon.author  = 'DriftwoodXI';
addon.version = '1.4.0';
addon.desc    = 'The Drift Board for DriftwoodXI -- daily, weekly and server-wide contracts, live progress, Drift Coins, and the augment Exchange.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. Nine
-- other addons own nine other names; this addon must never contend for any of
-- them, which is why `!dwu` exists at all -- the obvious `!dwq` belongs to
-- alt storage (DWQUEST_PLAN.md F1).
local DATA_SENDER = '_DWUDATA';

-- Bumped only for a breaking change to the record layout.
local PROTOCOL = 1;

--[[
* THE NOTICE TAG -- the literal quest_core.lua puts in front of every
* unsolicited line the Drift Board prints into chat, and the whole reason the
* text_in handler at the bottom of this file exists.
*
* WHY THE SERVER CANNOT JUST SEND IT TO THE RIGHT WINDOW. The client shows two
* chat logs and routes a line between them by the message CATEGORY, mapped to a
* window by the player's own filter config. The 0x017 packet the server writes
* with has a Kind, an Attr, a zone id and 150 bytes of text -- and no window
* field (src/map/packets/s2c/0x017_chat_std.h). Every DriftwoodXI module prints
* on SYSTEM_3, so on the ordinary two-window setup -- battle left, chat right --
* a payout arrives in the same window as a dozen lines a second of somebody
* else's damage numbers. That is the complaint this answers.
*
* WHAT ACTUALLY MOVES IT. An addon's own `print()` does not travel the 0x017
* path at all; it is written into the log directly and lands with the rest of a
* player's addon chatter, which is the window they keep for reading. So the
* server tags, this file blocks the tagged line, and print() puts the same
* sentence back where it can be read. Nothing else in the client is reachable
* from here, and nothing on the server can substitute for it.
*
* KEEP IN SYNC WITH `NOTICE` IN modules/driftwoodxi/quest_core.lua. One literal
* across a server module and a client addon that ship on separate paths is the
* shape that drifts silently -- a mismatch is not an error anywhere, it is just
* every notice quietly back in the battle log. harness_dwquest.py reads both
* real files and fails when they disagree, and the map's boot line prints this
* value verbatim so prod can be asked what it is actually sending.
*
* MATCHED ANYWHERE IN THE LINE, not anchored: the client hands a line to
* text_in with whatever decoration it carries, and a tag that only matches at
* byte one is a tag that silently stops matching the day a prefix appears. The
* cost of the loose match is that a player who types the tag by hand has the
* rest of their sentence re-printed one window over, which is a curiosity
* rather than a bug -- against a payout line that arrives during an AoE pull
* and is never seen, that trade is not close.
--]]
local NOTICE_TAG = '[Drift] ';

--[[
* State.
*
* Everything server-derived is replaced wholesale by a `board` envelope and
* never merged, so a contract that expired between syncs cannot survive as a
* stale card. A `ping` is the deliberate exception: it carries only the rows
* that moved, so it merges (dwu_protocol.md, "The ping").
*
* `actives` and `offerByKey` are PLAIN tables, not T{ }: they are keyed by
* quest keys and slot names, and T{ }'s sugar method names shadow string keys
* -- the collision that cost dwbags a round.
--]]
local state = T{
    open        = T{ false },

    -- The y| header. clockAt is the os.clock() at which the two countdowns
    -- were true, which is the only thing that makes ticking them down honest.
    poolVersion = nil,
    day         = nil,
    band        = nil,     -- the band the board ON SCREEN was resolved for
    playerBand  = nil,     -- the character's own band (y|'s appended field)
    secsToDay   = nil,
    secsToWeek  = nil,
    clockAt     = nil,
    rollAsked   = false,

    -- The band the player asked to LOOK at, nil for their own. Drives which
    -- board is requested; what is RENDERED is always the y| the server
    -- answered with, so the label cannot outrun the data under it.
    viewBand    = nil,

    offers      = { },     -- o| records, in wire order
    actives     = { },     -- [qkey] = a| record
    activeOrder = { },     -- qkeys, in the order the server listed them

    balance     = nil,     -- g|; nil means the server did not say

    -- q| -- the server-wide contract. nil means the server sent no q| record,
    -- which means there is no community contract this week. It is NOT drawn as
    -- an empty bar: a bar at 0/0 is a contract the window invented.
    community   = nil,

    synced      = false,   -- gates the panel: no cards until the first z|board

    -- True once a d| has arrived this session. Auto-syncs (zone-in) stay off
    -- until then: an unknown !command falls through to /say, and an automatic
    -- line against a dead verb is the player saying it in public.
    serverSpoke = false,

    inbound     = nil,     -- the verb whose envelope is currently open

    status      = 'Loading...',
    statusBad   = false,
    reported    = false,   -- a render error is worth saying once, not per frame

    toast       = nil,
    toastAt     = nil,

    now         = 0,       -- os.clock(), read once per frame (see present)
};

--[[
* THE EXCHANGE TAB (DWQUEST_PLAN.md Phase 4).
*
* Everything here arrives on the wire and nothing here is decided locally. The
* four offers and their prices are `u|` records; the list of gear that can take
* one is `c|` records off the server's own eligibility screen -- NOT the
* client's inventory, which cannot see an offline alt's bags and does not know
* a single one of the rules; the "N of 4 slots used" line is `k|`; and the
* price a purchase is confirmed at is the `p|` record's, never a number this
* file worked out.
*
* THE ONE RULE WITH MONEY BEHIND IT: `quote` is created by a `p|` record and by
* nothing else, and the Confirm button does not exist unless one is armed. A
* storefront button that could buy on the line it also uses to ask is the
* incident that produced dwmerc's quote/confirm pair -- an addon that reloaded
* and forgot it had already asked. Clicking Confirm disarms the quote in the
* same statement that queues the line, so one `p|` can be confirmed at most
* once, and a refusal arms nothing.
*
* PLAIN TABLES, not T{ }: `slots` is keyed by index and `gear` by wire order,
* and T{ }'s sugar method names shadow string keys.
--]]
local shop = {
    -- The v| header. clockAt is the os.clock() the countdown was true at.
    poolVersion = nil,
    day         = nil,
    secsToRoll  = nil,
    clockAt     = nil,
    rollAsked   = false,

    offers      = { },     -- u| records, in wire order
    roster      = { },     -- w| records, in wire order
    synced      = false,

    -- The picker.
    picked      = nil,     -- the offer handle chosen: x1..x4
    who         = '',      -- '' is you; otherwise an offline character's name
    filter      = T{ '' }, -- InputText writes into element 1
    gear        = { },     -- c| records, in wire order
    gearShown   = 0,
    gearTotal   = 0,
    gearMax     = 0,
    gearFor     = nil,     -- the request the list on screen answers
    gearSynced  = false,

    -- The item under consideration, off k| and s|.
    item        = nil,
    slots       = { },

    -- The armed quote. ONLY a p| record puts one here.
    quote       = nil,
};

--[[
* Sending: one command per interval, reads deduplicated, WRITES NEVER
* COLLAPSED AND NEVER RETRIED (the dwmerc rule, dwu_protocol.md client
* discipline 4). A lost `accept` that was re-sent could arrive after a
* rotation, which is a contract the player did not click on. Both verbs are
* idempotent server-side; that is not a licence to re-send them.
*
* Writes drain first: an accept stuck behind two queued board reads spends
* three seconds looking broken.
--]]
local SEND_INTERVAL = 1.2;

local readQueue  = { };
local writeQueue = { };
local lastSend   = 0;

local function issueRead(command)
    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

local function issueWrite(command)
    table.insert(writeQueue, command);
end

local function pumpQueue(now)
    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#writeQueue > 0) then
        lastSend = now;
        echo.send(table.remove(writeQueue, 1));

        return;
    end

    if (#readQueue > 0) then
        lastSend = now;
        echo.send(table.remove(readQueue, 1));
    end
end

--[[
* Answer tracking for the board read: ask once, retry once on a 5s silence,
* then stop and say so -- a retry that never terminates is a command loop.
*
* `hello` and `board` are tracked under ONE key because the server answers
* both with a `board` envelope (quest_core.lua's dispatch): keying on the verb
* we sent would leave a `hello` waiting forever for a `z|hello` that the
* protocol does not have.
*
* A PLAIN TABLE, not T{ }, for the reason above.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = { };

-- `hello` is the verb that arms the post-kill ping for the session, and it is
-- the one verb only the addon sends. It goes out when the arming might not be
-- in place: window open, and after a zone line. An in-session re-read is
-- `board`, which is the same records without re-arming.
local wantVerb = 'hello';

local function refresh(verb)
    requested = { };
    wantVerb  = verb or 'board';
end

-- The board read that keeps the current view: `board 3` while looking at
-- band 3, plain `board` for your own. Every re-sync that is not the arming
-- handshake goes through this, so an accept, a rotation roll or a typed
-- command cannot silently snap the window back to the player's own band.
local function boardVerb()
    if (state.viewBand ~= nil) then
        return string.format('board %d', state.viewBand);
    end

    return 'board';
end

local function needBoard(now)
    local asked = requested['board'];

    if (asked ~= nil) then
        if (asked.answered or (now - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp = true;

                if (not state.serverSpoke) then
                    state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
                    state.statusBad = true;
                end
            end

            return;
        end

        asked.at    = now;
        asked.tries = asked.tries + 1;
    else
        requested['board'] = { at = now, answered = false, tries = 1 };
    end

    issueRead('!dwu ' .. wantVerb);
end

--[[
* The same ask-once-retry-once discipline as needBoard, for the reads the
* Exchange tab makes. Keyed separately so a storefront read and a gear read
* cannot answer for each other, and so neither can answer for the board.
*
* Reads only. The three things this window sends that are NOT reads -- accept,
* abandon and confirm -- never come through here, because a write that times
* out is a write that stays sent (client discipline 4).
--]]
local function askOnce(key, command, now)
    local asked = requested[key];

    if (asked ~= nil) then
        if (asked.answered or (now - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp   = true;
                state.status    = 'The server did not answer. Refresh to try again.';
                state.statusBad = true;
            end

            return;
        end

        asked.at    = now;
        asked.tries = asked.tries + 1;
    else
        requested[key] = { at = now, answered = false, tries = 1 };
    end

    issueRead(command);
end

--[[
* A write in flight. Nothing here moves money and the store re-checks the
* account on both verbs, but a button clicked twice while the first click is
* still queued is a second line on the wire for a decision the player made
* once -- so the card says what it is doing instead of accepting the click.
*
* IT COVERS THE PURCHASE PAIR TOO (Phase 4). `augment` and `confirm` are both
* queued as writes and neither is ever re-sent; while one is in flight the
* buttons say what they are doing rather than taking a second click -- which
* for `confirm` is the difference between one purchase and two lines on the
* wire for one decision. The quote is disarmed at the click, so even a window
* that somehow got past this has nothing left to confirm with.
--]]
local WRITE_TIMEOUT = 10.0;

local writePending = nil;

local function beginWrite(what, label, command)
    writePending = { what = what, label = label, at = os.clock() };

    issueWrite(command);
end

--[[
* Record parsing.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function num(text, fallback)
    return tonumber(text or '') or fallback;
end

local TOAST_SECONDS = 8.0;

local function toast(text)
    state.toast   = text;
    state.toastAt = os.clock();
end

--[[
* One a| record -- an accepted contract. It carries its own name and reward
* rather than pointing back at an o|, because a contract inside its grace
* period is not on today's board and this window still has to draw it
* (dwu_protocol.md, `a|`).
*
* KEYED ON qkey, NEVER ON handle: handles are a typed-tier label that
* renumbers between syncs, and a model keyed on one abandons the wrong
* contract exactly once (client discipline 3).
--]]
local function handleContract(parts)
    local qkey = parts[3];

    if (qkey == nil or qkey == '') then
        return;
    end

    local row = {
        handle   = parts[2],
        qkey     = qkey,
        kind     = parts[4],
        period   = parts[5],
        name     = parts[6],
        progress = num(parts[7], 0),
        needed   = num(parts[8], 0),
        reward   = num(parts[9], 0),
        secsLeft = num(parts[10], 0),
        state    = parts[11],
        at       = os.clock(),
    };

    local prev = state.actives[qkey];

    -- The toast fires off the PING only. A board sync is the window catching
    -- up with kills it already celebrated, and re-celebrating them on every
    -- zone line would make the toast mean nothing.
    if (state.inbound == 'ping') then
        if (row.state == 'done' and (prev == nil or prev.state ~= 'done')) then
            toast(string.format('Contract complete: %s   +%d DC', row.name, row.reward));
        elseif (prev == nil or row.progress > prev.progress) then
            toast(string.format('%s   %d / %d', row.name, row.progress, row.needed));

            -- THE COUNTER IS ALWAYS A CHAT LINE TOO, and it is deliberately
            -- NOT conditional on the window being shut any more.
            --
            -- quest_core stops printing the per-kill progress line the moment a
            -- session is armed, because the window animates it instead -- so
            -- this print is the only copy an armed session ever gets. Gating it
            -- on the window being closed made where the line appeared depend on
            -- which of four states the session happened to be in (armed or not,
            -- window up or not), which is exactly the "sometimes over here,
            -- sometimes over there" the notice tag exists to end. One rule now:
            -- every progress step and every payout is a chat line, in the same
            -- window, every time. The toast still fires; a toast is eight
            -- seconds of a window you may not be looking at.
            --
            -- Payouts are not repeated here -- the server announces those to
            -- both tiers, tagged, and the handler at the bottom of this file
            -- moves them to the same place this line goes.
            print(chat.header('dwquest'):append(chat.message(
                string.format('%s: %d/%d', row.name, row.progress, row.needed))));
        end
    end

    if (prev == nil) then
        table.insert(state.activeOrder, qkey);
    end

    state.actives[qkey] = row;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = num(parts[2], 0);

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwquest.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.serverSpoke = true;
        state.inbound     = parts[3];

        -- A board replaces its whole section, and the reset runs FIRST: this
        -- runs under a pcall, and a throw after inbound is set must cost one
        -- record rather than leave old rows for the ones behind it. A ping is
        -- deliberately not reset -- it carries only what moved.
        if (state.inbound == 'board') then
            state.offers      = { };
            state.actives     = { };
            state.activeOrder = { };
            -- Cleared with the rest of the board: a week whose contract has
            -- ended sends no q| at all, and a bar left behind from last week
            -- would keep asking for kills nothing counts.
            state.community   = nil;

            local asked = requested['board'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'augments') then
            shop.offers = { };
            shop.roster = { };

            local asked = requested['augments'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'gear') then
            shop.gear      = { };
            shop.gearShown = 0;
            shop.gearTotal = 0;

            local asked = requested['gear'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'slots' or state.inbound == 'augment') then
            -- A fresh look at an item replaces the old one wholesale, and THE
            -- QUOTE GOES WITH IT. An `augment` that refuses arms nothing --
            -- which is the whole point of clearing here rather than on the way
            -- out: the refusal path never runs a line that could leave one.
            shop.item  = nil;
            shop.slots = { };
            shop.quote = nil;
        end

        -- `confirm` is deliberately absent from that list. Its answer carries
        -- only what changed (the item's new slot view and the purse), the same
        -- way a ping does, and resetting would blank the panel the player is
        -- reading the result on.

        return;
    end

    -- Status lines are accepted whatever the envelope state: the sentence
    -- saying why something was refused is worth more than the response it
    -- happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwquest'):append(chat.error(state.status)));
        end

        -- A write that has answered is a write that is no longer in flight,
        -- whichever way it went. Nothing is re-sent either way.
        if (state.inbound == 'accept' or state.inbound == 'abandon'
            or state.inbound == 'augment' or state.inbound == 'confirm') then
            writePending = nil;
        end

        -- A REFUSED CONFIRM IS A REFUSAL, NOT A RETRY PROMPT (client
        -- discipline 6). Every reason it can fail -- the item moved, the
        -- storefront rotated, the purse was short, the purchase was already
        -- settled -- is fixed by a fresh quote and none of them by sending the
        -- same word again, so the quote is torn up here rather than left armed
        -- for a second click.
        if (kind == 'e' and state.inbound == 'confirm') then
            shop.quote = nil;
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'board') then
            state.synced = true;

            if (state.status == 'Loading...') then
                state.status = '';
            end
        elseif (closing == 'accept' or closing == 'abandon') then
            writePending = nil;

            -- The write answered with a sentence, not with rows: the board it
            -- produced has to be read back before the cards are true. A read,
            -- so it is retried; the write itself never is.
            refresh(boardVerb());
        elseif (closing == 'augments') then
            shop.synced = true;
        elseif (closing == 'gear') then
            shop.gearSynced = true;
        elseif (closing == 'augment' or closing == 'confirm') then
            writePending = nil;

            if (closing == 'confirm') then
                -- Armed or not, this quote is spent. The k| that came with the
                -- answer is already on screen and says what the item is now.
                shop.quote = nil;

                -- The used/free counts in the picker moved under it. A read,
                -- so it may be re-asked; nothing here is re-sent.
                shop.gearFor = nil;
            end
        end

        return;
    end

    if (kind == 'y') then
        state.poolVersion = num(parts[2], nil);
        state.day         = num(parts[3], nil);
        state.band        = num(parts[5], nil);
        state.secsToDay   = num(parts[6], 0);
        state.secsToWeek  = num(parts[7], 0);
        state.playerBand  = num(parts[8], nil);
        state.clockAt     = os.clock();
        state.rollAsked   = false;

        -- A server that predates the band look never sends the appended
        -- field and ignores a band argument -- so stop asking with one, or
        -- the arrows would relabel a board that never changes.
        if (state.playerBand == nil) then
            state.viewBand   = nil;
            state.playerBand = state.band;
        end

        return;
    end

    if (kind == 'o') then
        table.insert(state.offers, {
            slot   = parts[2],
            kind   = parts[3],
            qkey   = parts[4],
            name   = parts[5],
            needed = num(parts[6], 0),
            reward = num(parts[7], 0),
            state  = parts[8],
        });

        return;
    end

    if (kind == 'a') then
        handleContract(parts);

        return;
    end

    if (kind == 'g') then
        state.balance = num(parts[2], nil);

        return;
    end

    -- q| -- the server-wide contract (Phase 5). Every number is the server's;
    -- `mine` and `minKills` are what the card uses to say whether this account
    -- is on the payout roster, and the window never works that out for itself.
    if (kind == 'q') then
        state.community =
        {
            qkey     = parts[2],
            id       = num(parts[3], 0),
            name     = parts[4] or '?',
            progress = num(parts[5], 0),
            needed   = num(parts[6], 0),
            mine     = num(parts[7], 0),
            minKills = num(parts[8], 0),
            reward   = num(parts[9], 0),
            state    = parts[10] or 'open',
        };

        return;
    end

    --[[
    * The Exchange records. Every one of them is rendered as it arrived.
    --]]

    -- v| -- the storefront header and its rotation countdown.
    if (kind == 'v') then
        shop.poolVersion = num(parts[2], nil);
        shop.day         = num(parts[3], nil);
        shop.secsToRoll  = num(parts[4], 0);
        shop.clockAt     = os.clock();
        shop.rollAsked   = false;

        return;
    end

    -- u| -- one augment offer. It also rides the `augment` (quote) answer,
    -- where it is context for the p| rather than a storefront row: appending
    -- it there would grow the storefront by one every time somebody asked a
    -- price.
    if (kind == 'u') then
        if (state.inbound == 'augments') then
            table.insert(shop.offers, {
                slot  = parts[2],
                augid = num(parts[3], 0),
                rank  = num(parts[4], 0),
                price = num(parts[5], 0),
                fits  = parts[6],
                label = parts[7],
            });
        end

        return;
    end

    -- w| -- one character on the account. `state` is the server's word on
    -- whether that character can be augmented, and the reason is worth
    -- showing: "logged in" is a thing the player can fix.
    if (kind == 'w') then
        table.insert(shop.roster, { name = parts[2], state = parts[3] });

        return;
    end

    -- n| -- the gear header. shown < total means the list is TRUNCATED, and
    -- the window says so rather than letting a cap read as an inventory.
    if (kind == 'n') then
        shop.gearShown = num(parts[2], 0);
        shop.gearTotal = num(parts[3], 0);
        shop.gearMax   = num(parts[4], 0);

        return;
    end

    -- c| -- one item that can take an augment. The id is what a purchase
    -- names; used/free are the server's own counts.
    if (kind == 'c') then
        table.insert(shop.gear, {
            itemid = num(parts[2], 0),
            used   = num(parts[3], 0),
            free   = num(parts[4], 0),
            count  = num(parts[5], 1),
            name   = parts[6],
        });

        return;
    end

    -- k| -- an item's slot view. It is the header of a slot list, so it clears
    -- the rows behind it: s| records are emitted only for OCCUPIED slots, and
    -- a slot that emptied would otherwise linger from the previous answer.
    if (kind == 'k') then
        shop.item = {
            used     = num(parts[2], 0),
            free     = num(parts[3], 0),
            maxslots = num(parts[4], 4),
            itemid   = num(parts[5], 0),
            name     = parts[6],
            charname = parts[7],
            stamp    = parts[8],
        };

        shop.slots = { };

        -- The purchase landed. The sentence is the server's own (it prints one
        -- in chat on every tier, because money always says so); this is the
        -- window's acknowledgement that the click did something.
        if (state.inbound == 'confirm') then
            toast(string.format('%s: %d of %d slots used.',
                shop.item.name, shop.item.used, shop.item.maxslots));
        end

        return;
    end

    -- s| -- one occupied augment slot. An absent index is an empty slot.
    if (kind == 's') then
        local index = num(parts[2], 0);

        if (index >= 1 and index <= 4) then
            shop.slots[index] = { augid = num(parts[3], 0), rank = num(parts[4], 0) };
        end

        return;
    end

    -- p| -- A QUOTE, AND THE ONLY THING THAT CAN ARM A CONFIRM. Not a
    -- purchase, and incapable of becoming one on its own.
    if (kind == 'p') then
        shop.quote = {
            price   = num(parts[2], 0),
            augid   = num(parts[3], 0),
            rank    = num(parts[4], 0),
            landing = num(parts[5], 0),
            holds   = num(parts[6], 0),
            label   = parts[7],
            at      = os.clock(),
            armed   = true,
        };

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWUDATA is ours -- consumed and blocked before parsing so a
* malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwquest_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwquest'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Reads over the synced state.
--]]

-- A countdown the server sent, aged by the wall clock since it arrived. Never
-- below zero: `secsLeft` is documented as never negative, and a bar counting
-- backwards past its own expiry is a number nobody can act on.
local function ticked(base, at, now)
    if (base == nil or at == nil) then
        return nil;
    end

    local left = base - (now - at);

    return left > 0 and left or 0;
end

local function fmtClock(secs)
    if (secs == nil) then
        return '--';
    end

    secs = math.floor(secs);

    if (secs <= 0) then
        return 'now';
    end

    if (secs >= 3600) then
        return string.format('%dh %02dm', math.floor(secs / 3600), math.floor((secs % 3600) / 60));
    end

    if (secs >= 60) then
        return string.format('%dm %02ds', math.floor(secs / 60), secs % 60);
    end

    return string.format('%ds', secs);
end

-- The rotation rolled while the window was open: the offers on screen belong
-- to the period that just ended. Asked ONCE per header -- y| clears the flag.
local function checkRotation(now)
    if (state.rollAsked or not state.synced or state.clockAt == nil) then
        return;
    end

    local day  = ticked(state.secsToDay, state.clockAt, now);
    local week = ticked(state.secsToWeek, state.clockAt, now);

    if ((day ~= nil and day <= 0) or (week ~= nil and week <= 0)) then
        state.rollAsked = true;

        refresh(boardVerb());
    end
end

--[[
* Actions. Every one is a line a player could type.
*
* Abandon names the QUEST KEY, not the handle: the server takes either, and
* the key cannot be renumbered out from under a click (client discipline 3).
--]]
local function acceptSlot(offer)
    beginWrite('accept', offer.name, string.format('!dwu accept %s', offer.slot));

    state.status    = string.format('Signing %s...', offer.name);
    state.statusBad = false;
end

local function abandonContract(row)
    beginWrite('abandon', row.name, string.format('!dwu abandon %s', row.qkey));

    state.status    = string.format('Tearing up %s...', row.name);
    state.statusBad = false;
end

--[[
* The Exchange's actions. Every one is a line a player could type, and the
* three that name an item name it BY ID -- which is a thing the typed tier
* takes (`!drift augment x1 17324`) and the one form no item name can be
* ambiguous in.
--]]

-- The filter goes on a command line, so the two markers the server's argument
-- parser reads out of ANY token come off it first. A player typing "@Yakapo"
-- into a search box means it as words, not as a character switch, and a window
-- that let it through would quietly search somebody else's bags. `|` goes for
-- the wire's own reason.
local function safeFilter(text)
    return tostring(text or ''):gsub('[@#|\r\n]', ' '):gsub('%s+', ' '):gsub('^%s+', ''):gsub('%s+$', '');
end

local function gearRequest()
    if (shop.picked == nil) then
        return nil;
    end

    local command = string.format('!dwu gear %s', shop.picked);

    if (shop.who ~= '') then
        command = string.format('%s @%s', command, shop.who);
    end

    local filter = safeFilter(shop.filter[1]);

    if (filter ~= '') then
        command = string.format('%s %s', command, filter);
    end

    return command;
end

-- The list on screen answers exactly one request; when the request changes the
-- list is stale and the tracker has to be re-armed, or the window would sit
-- showing yesterday's bag under today's question.
local function invalidateGear()
    shop.gearFor    = nil;
    shop.gearSynced = false;
    requested['gear'] = nil;
end

local function chooseOffer(offer)
    shop.picked = offer.slot;
    shop.item   = nil;
    shop.slots  = { };
    shop.quote  = nil;

    invalidateGear();

    state.status    = string.format('%s -- pick what it goes on.', offer.label);
    state.statusBad = false;
end

local function chooseCharacter(name)
    shop.who   = name or '';
    shop.item  = nil;
    shop.slots = { };
    shop.quote = nil;

    invalidateGear();
end

-- Ask a price. A quote spends nothing, but it is queued as a write and never
-- retried all the same: it arms a confirmation server-side, and a duplicate
-- arriving late is a second armed quote for one click.
local function quoteItem(row, replaceSlot)
    local command = string.format('!dwu augment %s %s%d', shop.picked,
        shop.who ~= '' and ('@' .. shop.who .. ' ') or '', row.itemid);

    if (replaceSlot ~= nil) then
        command = string.format('%s #%d', command, replaceSlot);
    end

    beginWrite('augment', row.name, command);

    state.status    = string.format('Pricing %s...', row.name);
    state.statusBad = false;
end

-- The slot view on its own, for an item with nothing free: the player has to
-- see what is in the four slots before they can say which one to give up. A
-- read, so it may be re-asked; it quotes nothing and arms nothing.
local function inspectItem(row)
    shop.item  = nil;
    shop.slots = { };
    shop.quote = nil;

    issueRead(string.format('!dwu slots %s%d',
        shop.who ~= '' and ('@' .. shop.who .. ' ') or '', row.itemid));

    state.status    = string.format('Reading %s...', row.name);
    state.statusBad = false;
end

--[[
* THE PURCHASE. The only place this addon can spend anything.
*
* The quote is disarmed in the same statement that queues the line, so the
* record that authorised this purchase cannot authorise another one -- not on a
* double click, not on a frame that renders twice, not on a retry that does not
* exist. A refusal comes back as an `e|` and clears the quote outright; there
* is no path here that re-sends `confirm`.
--]]
local function confirmPurchase()
    if (shop.quote == nil or not shop.quote.armed) then
        return;
    end

    local label = shop.quote.label;

    shop.quote.armed = false;

    beginWrite('confirm', label, '!dwu confirm');

    state.status    = string.format('Buying %s...', label);
    state.statusBad = false;
end

--[[
* Rendering.
--]]

-- The period label comes off the slot handle, which IS the period: `d1`/`d2`
-- are the dailies and `w1`/`w2` the weeklies, fixed by the protocol
-- (dwu_protocol.md, `o|`). Reading a documented handle is not arithmetic over
-- server data -- there is no other number here the window invents.
local function periodLabel(slotOrPeriod)
    return tostring(slotOrPeriod or ''):sub(1, 1) == 'w' and 'Weekly' or 'Daily';
end

-- The level range a band number covers, fixed by the protocol (dwu_protocol.md,
-- `y|`: 1-20, 21-40, 41-60, 61-80, 81-99). Reading a documented mapping, like
-- periodLabel above -- the server prints the same range from the same band.
local BAND_COUNT = 5;

local function bandRange(band)
    return (band - 1) * 20 + 1, band == BAND_COUNT and 99 or band * 20;
end

--[[
* The band look: which band's board is asked for next. Stepping is a READ of a
* different board, never a write -- accept stays own-band only and the server
* enforces it besides. What the label renders is the y| the server answered
* with (state.band), so the arrows can never label a board they merely hoped
* for.
--]]
local function stepBand(delta)
    local current = state.viewBand or state.band or state.playerBand;

    if (current == nil) then
        return;
    end

    local target = current + delta;

    if (target < 1) then target = 1; end
    if (target > BAND_COUNT) then target = BAND_COUNT; end

    if (target == current) then
        return;
    end

    if (state.playerBand ~= nil and target == state.playerBand) then
        state.viewBand = nil;
    else
        state.viewBand = target;
    end

    refresh(boardVerb());
end

-- The objective clause, per kind. This mirrors quest_core.lua's objectiveFor
-- exactly, and the harness asserts the two say the same thing -- a window that
-- describes a contract differently from the server that scores it is a bug
-- report about the wrong half.
--
-- THE WEAPON-SKILL WORDING IS THE SERVER'S, NOT A PARAPHRASE. The flag is a
-- fact about the mob's death and is handed to every alliance member alike, so
-- "finished with a weapon skill" is true and "finish it yourself" is not.
local function objectiveText(kind, needed, name)
    if (kind == 'fam') then
        return string.format('Slay %d of the %s family', needed, name);
    elseif (kind == 'eco') then
        return string.format('Slay %d %s', needed, name);
    elseif (kind == 'ws') then
        return string.format('Slay %d in %s, each finished with a weapon skill', needed, name);
    elseif (kind == 'night') then
        return string.format('Slay %d in %s between dusk and dawn', needed, name);
    elseif (kind == 'wthr') then
        return string.format('Slay %d in %s while the weather is up', needed, name);
    elseif (kind == 'comm') then
        return string.format('The server slays %d %s', needed, name);
    end

    return string.format('Slay %d creatures in %s', needed, name);
end

-- The kind badge. An UNKNOWN kind renders as itself rather than falling back
-- to 'zone': a server newer than this addon can offer a kind that did not
-- exist when it was built, and labelling it with the wrong one is worse than
-- showing a word the player has not seen before (dwu_protocol.md's rule about
-- never guessing at ids you do not recognise).
local KIND_BADGE =
{
    fam = 'family', zone = 'zone', eco = 'ecosystem',
    ws = 'weapon skill', night = 'night', wthr = 'weather', comm = 'server',
};

local function badge(text)
    imgui.TextColored(theme.colors.badge, string.format('[%s]', text));
    imgui.SameLine();
end

local function progressRow(row)
    local fraction = 0;

    if (row.needed > 0) then
        fraction = row.progress / row.needed;

        if (fraction < 0) then fraction = 0; end
        if (fraction > 1) then fraction = 1; end
    end

    imgui.ProgressBar(fraction, { -1, 16 }, string.format('%d / %d', row.progress, row.needed));
end

-- One card: the badge line, the bar, then reward, countdown and the one
-- button the card's state allows. Everything on it came off the wire.
--
-- `note` replaces the Accept button when the offer cannot be accepted from
-- here -- the slot lock, or a board being viewed from outside its band. The
-- sentence is decided by the caller off the o| state; the card only ever
-- draws one of {Accept, Abandon, note}.
local function contractCard(id, period, kind, title, reward, signed, note)
    badge(period);
    badge(KIND_BADGE[kind] or tostring(kind));
    imgui.Text(title);

    if (signed ~= nil) then
        progressRow(signed);
    else
        imgui.ProgressBar(0, { -1, 16 }, 'Not signed');
    end

    imgui.TextDisabled(string.format('%d DC', reward));

    if (signed ~= nil) then
        imgui.SameLine();

        if (signed.state == 'done') then
            imgui.TextColored(theme.colors.ok, 'paid');
        else
            local left = ticked(signed.secsLeft, signed.at, state.now);

            if (left ~= nil and left <= 0) then
                imgui.TextDisabled('expired');
            else
                imgui.TextDisabled(string.format('%s left', fmtClock(left)));
            end
        end
    end

    imgui.SameLine();

    if (writePending ~= nil) then
        imgui.TextDisabled(string.format('%s...',
            writePending.what == 'abandon' and 'Tearing up' or 'Signing'));
    elseif (signed == nil) then
        if (note ~= nil) then
            imgui.TextDisabled(note);
        elseif (imgui.SmallButton(string.format('Accept##dwquest_accept_%s', id))) then
            return 'accept';
        end
    elseif (signed.state ~= 'done') then
        if (imgui.SmallButton(string.format('Abandon##dwquest_abandon_%s', id))) then
            return 'abandon';
        end
    else
        imgui.TextDisabled('done');
    end

    imgui.Separator();

    return nil;
end

--[[
* The band row: arrows either side of "Band N (Lv lo-hi)", near the top so
* every band's board is readable without changing jobs. The label names the
* board actually on screen (the y| the server answered with); the arrows only
* ever ask. Rendered once the first board has landed -- an arrow before the
* server has said which band you are would be paging through a guess.
--]]
local function bandNavRow()
    local shown = state.band;

    if (shown == nil) then
        return;
    end

    if (imgui.SmallButton('<##dwquest_bandprev')) then
        stepBand(-1);
    end

    imgui.SameLine();

    local lo, hi = bandRange(shown);

    if (state.playerBand ~= nil and shown ~= state.playerBand) then
        imgui.Text(string.format('Band %d (Lv %d-%d)', shown, lo, hi));
        imgui.SameLine();

        if (state.viewBand ~= nil and state.viewBand ~= shown) then
            imgui.TextDisabled('loading...');
        else
            imgui.TextDisabled(string.format('-- yours is band %d', state.playerBand));
        end
    else
        imgui.Text(string.format('Band %d (Lv %d-%d)', shown, lo, hi));
        imgui.SameLine();

        if (state.viewBand ~= nil and state.viewBand ~= shown) then
            imgui.TextDisabled('loading...');
        else
            imgui.TextDisabled('-- your jobs');
        end
    end

    imgui.SameLine();

    if (imgui.SmallButton('>##dwquest_bandnext')) then
        stepBand(1);
    end

    imgui.Separator();
end

local function boardPanel()
    if (not imgui.BeginChild('##dwquest_board', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    bandNavRow();

    local offered = { };

    -- A board from outside the player's own band is a look: its open offers
    -- carry a sentence instead of an Accept, because the accept verb resolves
    -- off the real level and would sign the wrong band's slot.
    local foreign = state.playerBand ~= nil and state.band ~= nil
        and state.band ~= state.playerBand;

    for _, offer in ipairs(state.offers) do
        offered[offer.qkey] = true;

        local signed = state.actives[offer.qkey];
        local note   = nil;

        if (signed == nil) then
            if (offer.state == 'locked') then
                -- The slot lock (o| state `locked`): this slot is spent for
                -- the period by a contract signed at some band, so the server
                -- would refuse the accept this card could invite.
                note = string.format('slot spent -- back at the %s reset',
                    periodLabel(offer.slot) == 'Weekly' and 'weekly' or 'daily');
            elseif (foreign) then
                local lo, hi = bandRange(state.band);

                note = string.format('for Lv %d-%d jobs', lo, hi);
            end
        end

        local click = contractCard(offer.slot, periodLabel(offer.slot), offer.kind,
            objectiveText(offer.kind, offer.needed, offer.name), offer.reward, signed, note);

        if (click == 'accept') then
            acceptSlot(offer);
        elseif (click == 'abandon' and signed ~= nil) then
            abandonContract(signed);
        end
    end

    if (#state.offers == 0) then
        imgui.TextDisabled('No contracts offered. The board is not loaded on this server build.');
    end

    -- Contracts inside their grace period: signed under an earlier rotation,
    -- still completable, and NOT on today's board -- which is the whole reason
    -- the a| record carries its own name and reward.
    local extra = { };

    for _, qkey in ipairs(state.activeOrder) do
        if (not offered[qkey] and state.actives[qkey] ~= nil) then
            table.insert(extra, state.actives[qkey]);
        end
    end

    if (#extra > 0) then
        imgui.TextDisabled('Still yours, from an earlier board:');

        for _, row in ipairs(extra) do
            local click = contractCard(row.qkey, periodLabel(row.period), row.kind,
                objectiveText(row.kind, row.needed, row.name), row.reward, row);

            if (click == 'abandon') then
                abandonContract(row);
            end
        end
    end

    --[[
    * The server-wide contract. Drawn last, with NO BUTTON -- there is no verb
    * to accept it and inventing a button that does nothing is worse than
    * having none. What the card has to answer is "am I getting paid for this",
    * and it answers it with the server's own two numbers rather than a rule of
    * its own.
    --]]
    local community = state.community;

    if (community ~= nil) then
        imgui.Separator();

        badge('server');
        badge(KIND_BADGE.comm);
        imgui.Text(objectiveText('comm', community.needed, community.name));

        progressRow(community);

        if (community.state == 'done') then
            if (community.mine >= community.minKills) then
                imgui.TextColored(theme.colors.ok,
                    string.format('Finished. %d DC paid to your account.', community.reward));
            else
                imgui.TextDisabled(string.format(
                    'Finished. Your %d did not reach the %d needed to be paid.',
                    community.mine, community.minKills));
            end
        elseif (community.mine >= community.minKills) then
            imgui.TextColored(theme.colors.ok, string.format(
                'Your part: %d. You are on the payout -- %d DC when the server finishes it.',
                community.mine, community.reward));
        else
            imgui.TextDisabled(string.format(
                'Your part: %d of %d needed to be paid -- %d DC when the server finishes it.',
                community.mine, community.minKills, community.reward));
        end
    end

    imgui.EndChild();
end

--[[
* The Exchange panel.
*
* Reading order is the order the decisions happen in: what is for sale, who it
* is going on, which item, which slot, then the price and the one button that
* pays. Nothing further down the panel exists until the step above it has been
* answered BY THE SERVER -- there is no step here the window can complete on
* its own.
--]]
local function offerCard(offer)
    badge(offer.slot);
    imgui.Text(offer.label);

    -- The price is the server's, rendered. So is `fits`: the window does not
    -- know what `weapon` means for an offer, and the list it asks for is
    -- filtered by the server against that same column.
    imgui.TextDisabled(string.format('%d DC', offer.price));
    imgui.SameLine();
    imgui.TextDisabled(offer.fits == 'any' and 'any gear' or offer.fits);
    imgui.SameLine();

    if (writePending ~= nil) then
        imgui.TextDisabled('busy...');
    elseif (shop.picked == offer.slot) then
        imgui.TextColored(theme.colors.ok, 'chosen');
    elseif (imgui.SmallButton(string.format('Choose##dwquest_offer_%s', offer.slot))) then
        return true;
    end

    return false;
end

local function characterRow()
    local label = shop.who ~= '' and shop.who or 'You';

    imgui.TextDisabled('On:');
    imgui.SameLine();
    imgui.PushItemWidth(160);

    if (imgui.BeginCombo('##dwquest_who', label)) then
        if (imgui.Selectable('You##dwquest_who_self', shop.who == '')) then
            chooseCharacter('');
        end

        for _, member in ipairs(shop.roster) do
            -- `self` is reached by leaving the name off and `online` is a
            -- refusal the server would make, so only offline alts are
            -- selectable -- and the others are still SHOWN, greyed, with the
            -- reason, because "my alt is missing from the list" is a worse
            -- question than "my alt is logged in".
            if (member.state == 'offline') then
                if (imgui.Selectable(string.format('%s##dwquest_who_%s', member.name, member.name),
                        shop.who == member.name)) then
                    chooseCharacter(member.name);
                end
            elseif (member.state == 'online') then
                imgui.TextDisabled(string.format('%s (logged in)', member.name));
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
    imgui.SameLine();
    imgui.PushItemWidth(160);

    if (imgui.InputText('##dwquest_filter', shop.filter, 64, ImGuiInputTextFlags_EnterReturnsTrue)) then
        invalidateGear();
    end

    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.SmallButton('Search##dwquest_gearsearch')) then
        invalidateGear();
    end
end

local function slotView()
    local item = shop.item;

    if (item == nil) then
        return;
    end

    imgui.Text(string.format('%s%s', item.name,
        (item.charname ~= nil and item.charname ~= '' and shop.who ~= '') and (' (' .. item.charname .. ')') or ''));

    -- USED AND FREE COME OFF k| (client discipline 7 and the owner's brief
    -- #8). The window does not count the s| records -- they are only emitted
    -- for occupied slots, so counting them would be the window deriving a
    -- number the player is about to consent against.
    imgui.TextDisabled(string.format('%d of %d augment slots used', item.used, item.maxslots));

    local landing = shop.quote ~= nil and shop.quote.landing or 0;
    local full    = item.free == 0;

    for index = 1, item.maxslots do
        local slot = shop.slots[index];

        if (index == landing) then
            imgui.TextColored(theme.colors.hint, string.format('  slot %d: %s', index,
                slot ~= nil and string.format('augment %d rank %d -- REPLACED', slot.augid, slot.rank) or 'empty -- lands here'));
        elseif (slot ~= nil) then
            imgui.Text(string.format('  slot %d: augment %d rank %d', index, slot.augid, slot.rank));
        else
            imgui.TextDisabled(string.format('  slot %d: empty', index));
        end

        -- A full item can only take a purchase by giving something up, and the
        -- server refuses to guess which. One button per occupied slot, and the
        -- click is a fresh quote naming that slot -- never a confirm.
        if (full and slot ~= nil and shop.quote == nil and writePending == nil) then
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Replace##dwquest_replace_%d', index))) then
                return index;
            end
        end
    end

    return nil;
end

local function quoteRow()
    local quote = shop.quote;

    if (quote == nil) then
        return;
    end

    -- THE PRICE IS THE QUOTE'S. Not the offer card's, not a lookup by handle,
    -- not anything this file could have got wrong: the record the player is
    -- consenting to is the record the purchase is settled against.
    imgui.TextColored(theme.colors.ok, string.format('%s -- %d DC', quote.label, quote.price));
    imgui.TextDisabled(string.format('Lands in slot %d. Once augmented it is bound to your account: no auction house, no trade, no bazaar.',
        quote.landing));

    if (writePending ~= nil) then
        imgui.TextDisabled(string.format('%s...',
            writePending.what == 'confirm' and 'Buying' or 'Pricing'));

        return false;
    end

    -- THE BUTTON DOES NOT EXIST WITHOUT AN ARMED QUOTE. `armed` is set only by
    -- a p| record and cleared by the click itself, so there is no frame in
    -- which a second Confirm is drawable for one quote.
    if (not quote.armed) then
        imgui.TextDisabled('Sent.');

        return false;
    end

    if (imgui.SmallButton('Confirm##dwquest_confirm')) then
        return true;
    end

    imgui.SameLine();

    if (imgui.SmallButton('Cancel##dwquest_cancel')) then
        -- Local only. The server's quote ages out on its own (p| says how
        -- long); there is no verb for "never mind" and inventing one would be
        -- a line the typed tier does not have.
        shop.quote = nil;
        shop.item  = nil;
        shop.slots = { };
    end

    return false;
end

local function gearList()
    if (not shop.gearSynced) then
        imgui.TextDisabled('Looking through the bags...');

        return;
    end

    if (#shop.gear == 0) then
        imgui.TextDisabled('Nothing here can take that augment. Equipment only, not equipped, not enchanted, not priced in a bazaar.');

        return;
    end

    for _, row in ipairs(shop.gear) do
        imgui.Text(string.format('%s%s', row.name, row.count > 1 and string.format('  (x%d)', row.count) or ''));
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d of 4 used', row.used));
        imgui.SameLine();

        if (writePending ~= nil) then
            imgui.TextDisabled('busy...');
        elseif (row.free > 0) then
            if (imgui.SmallButton(string.format('Pick##dwquest_pick_%d', row.itemid))) then
                quoteItem(row, nil);
            end
        elseif (imgui.SmallButton(string.format('Slots##dwquest_slots_%d', row.itemid))) then
            -- Full: there is nothing to quote until the player says what to
            -- give up, so this asks to SEE the slots rather than to price one.
            inspectItem(row);
        end
    end

    -- A CAP THAT DOES NOT SAY SO READS AS AN INVENTORY. Both numbers are the
    -- server's; the window compares them and says which one it drew.
    if (shop.gearShown < shop.gearTotal) then
        imgui.TextDisabled(string.format('Showing %d of %d. Type part of a name to narrow it.',
            shop.gearShown, shop.gearTotal));
    end
end

local function exchangePanel()
    if (not imgui.BeginChild('##dwquest_exchange', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not shop.synced) then
        imgui.TextDisabled('Waiting for the Exchange...');
        imgui.EndChild();

        return;
    end

    if (shop.clockAt ~= nil) then
        imgui.TextDisabled(string.format('New offers in %s',
            fmtClock(ticked(shop.secsToRoll, shop.clockAt, state.now))));
    end

    if (#shop.offers == 0) then
        imgui.TextDisabled('The Exchange has nothing today. The offer pool is not loaded on this server build.');
        imgui.EndChild();

        return;
    end

    imgui.Separator();

    for _, offer in ipairs(shop.offers) do
        if (offerCard(offer)) then
            chooseOffer(offer);
        end
    end

    imgui.Separator();

    if (shop.picked == nil) then
        imgui.TextDisabled('Choose an augment above, then pick the gear it goes on.');
        imgui.EndChild();

        return;
    end

    characterRow();
    imgui.Separator();

    if (shop.item == nil) then
        gearList();
    else
        local replace = slotView();

        if (replace ~= nil) then
            -- A replace click is a NEW QUOTE naming the slot, which is the
            -- only way the price and the landing slot the player consents to
            -- can both be the server's.
            quoteItem({ itemid = shop.item.itemid, name = shop.item.name }, replace);
        end

        imgui.Separator();

        if (quoteRow()) then
            confirmPurchase();
        end

        if (shop.quote == nil and writePending == nil) then
            if (imgui.SmallButton('Back to the list##dwquest_back')) then
                shop.item  = nil;
                shop.slots = { };
            end
        end
    end

    imgui.EndChild();
end

-- The storefront rolled while the tab was open: the four offers on screen
-- belong to the Vana'diel day that just ended, and a quote taken against them
-- is refused (dwu_protocol.md, `v|`). Asked ONCE per header -- v| clears it.
local function checkShopRotation(now)
    if (shop.rollAsked or not shop.synced or shop.clockAt == nil) then
        return;
    end

    local left = ticked(shop.secsToRoll, shop.clockAt, now);

    if (left ~= nil and left <= 0) then
        shop.rollAsked = true;
        shop.synced    = false;
        shop.picked    = nil;
        shop.item      = nil;
        shop.slots     = { };
        shop.quote     = nil;

        invalidateGear();

        requested['augments'] = nil;
    end
end

local function headerRow()
    -- Refresh re-says `hello`, not `board`. It is the player's deliberate
    -- "make this right" click, and the one thing a plain re-read could not fix
    -- is a lost arming -- a map that restarted under the session drops the
    -- local var the ping rides on, and every following board read would come
    -- back correct and silent forever after. Re-arming is a no-op when it was
    -- never lost.
    if (imgui.Button('Refresh##dwquest_refresh')) then
        -- Home first: `hello` answers the player's own board, and a view flag
        -- left set would have the next auto-sync silently steer away again.
        state.viewBand = nil;

        refresh('hello');
    end

    imgui.SameLine();

    if (state.balance ~= nil) then
        imgui.TextColored(theme.colors.ok, string.format('%d DC', state.balance));
    else
        imgui.TextDisabled('-- DC');
    end

    local queued = #readQueue + #writeQueue;

    if (queued > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d queued...', queued));
    end

    if (state.day ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('day %d  band %d  pool v%d',
            state.day, state.band or 0, state.poolVersion or 0));
    end

    if (state.clockAt ~= nil) then
        imgui.TextDisabled(string.format('New dailies in %s   New weeklies in %s',
            fmtClock(ticked(state.secsToDay, state.clockAt, state.now)),
            fmtClock(ticked(state.secsToWeek, state.clockAt, state.now))));
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    if (state.toast ~= nil and state.toastAt ~= nil and (state.now - state.toastAt) <= TOAST_SECONDS) then
        imgui.TextColored(theme.colors.hint, state.toast);
    end

    imgui.Separator();
end

--[[
* The Exchange's reads, issued only while its tab is the one on screen. A
* window sitting on the Board tab has no business asking for a storefront.
--]]
local function needShop(now)
    askOnce('augments', '!dwu augments', now);

    if (shop.picked == nil) then
        return;
    end

    local wanted = gearRequest();

    if (wanted == nil) then
        return;
    end

    -- The signature of the request the list would answer. When it changes --
    -- a different offer, a different character, a different search -- the
    -- tracker is re-armed and the list on screen is stale until the answer
    -- lands.
    if (shop.gearFor ~= wanted) then
        shop.gearFor      = wanted;
        shop.gearSynced   = false;
        requested['gear'] = nil;
    end

    askOnce('gear', wanted, now);
end

local function renderWindow()
    headerRow();

    -- Which tab is on screen decides which reads run, and the flag is set from
    -- what ImGui actually drew rather than from a click handler: a tab
    -- restored from imgui.ini is one nobody clicked this session.
    local onExchange = false;

    if (imgui.BeginTabBar('##dwquest_tabs')) then
        if (imgui.BeginTabItem('Board##dwquest_tab_board')) then
            if (state.synced) then
                boardPanel();
            else
                imgui.TextDisabled('Waiting for the board...');
            end

            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Exchange##dwquest_tab_shop')) then
            onExchange = true;

            exchangePanel();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    -- Inside the pcall, and last: the syncs are the one thing here that can
    -- queue a line, and a throw in them must cost the window rather than the
    -- present handler that draws every other addon after us.
    checkRotation(state.now);
    needBoard(state.now);

    if (onExchange) then
        checkShopRotation(state.now);
        needShop(state.now);
    end
end

--[[
* The render pass: pcall'd body, Begin/End and theme push/pop outside it so
* both stacks stay balanced; an error closes the window once, loudly, and the
* typed commands remain as the fallback.
--]]
ashita.events.register('d3d_present', 'dwquest_present', function ()
    -- Read once per frame. Two reads of the clock inside one frame would let
    -- a countdown and the bar beside it disagree, and the offline harness's
    -- clock strides deliberately to make that visible.
    state.now = os.clock();

    -- A write that was never answered must not hold the card hostage. Nothing
    -- was charged, nothing is re-sent: Refresh shows where the contract
    -- actually stands.
    if (writePending ~= nil and (state.now - writePending.at) > WRITE_TIMEOUT) then
        writePending    = nil;
        state.status    = 'No answer from the server. Nothing was re-sent -- Refresh shows where you stand.';
        state.statusBad = true;
    end

    pumpQueue(state.now);

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 560, 520 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Drift Board##dwquest', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwquest'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwquest'):append(chat.message('Window closed. Everything it does also works as !drift commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening asks `hello`, which is both the board read and
* the handshake that arms the post-kill ping for the session -- the one verb
* only the addon sends (dwu_protocol.md).
--]]
local function openWindow()
    state.open[1]   = true;
    state.reported  = false;
    state.status    = state.synced and '' or 'Loading...';
    state.statusBad = false;
    state.viewBand  = nil;

    refresh('hello');
end

local function toggleWindow()
    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end

--[[
* Watch what the player sends. Bare `!drift` (and ui/window/gui) toggles the
* window and never leaves the client; every other !drift line passes through
* and marks our state stale, because a typed accept changes the board under
* the window. Any other outgoing line stamps the throttle -- the client's rate
* limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwquest_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!drift' or lower == '!drift ui' or lower == '!drift window' or lower == '!drift gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwu') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 6) == '!drift') then
        refresh(boardVerb());
    end
end);

ashita.events.register('command', 'dwquest_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwquest' and args[1] ~= '/quests')) then
        return;
    end

    e.blocked = true;

    toggleWindow();
end);

ashita.events.register('load', 'dwquest_load', function ()
    print(chat.header('dwquest'):append(chat.message('/quests opens the Drift Board and the Drift Exchange. Everything it does also works typed as !drift commands.')));
end);

--[[
* THE NOTICE REROUTE. The one thing in this file that touches a line the player
* did not ask this window for.
*
* A tagged line (see NOTICE_TAG above) is blocked and re-emitted through
* print(), which is the only way anything here can decide WHICH chat log a
* sentence lands in -- the server has no such lever, and every DriftwoodXI
* module prints on the same channel as the battle log's system messages.
*
* IT WORKS WITH THE WINDOW SHUT AND WITH THE SESSION UNARMED, which is the
* point. The addon only sends `!dwu hello` -- the verb that arms the post-kill
* ping -- once the player has opened the window, so most sessions are unarmed
* and every notice in them comes from the server rather than from the ping
* handler above. Those are precisely the sessions the player was losing lines
* in, and a reroute that needed arming would have missed all of them.
*
* THREE GUARDS, EACH FOR A DIFFERENT WAY THIS COULD MISBEHAVE:
*
*   e.blocked   -- dwecho installs first and blocks this addon's own command
*                  echoes. A line somebody already took is not ours to re-print.
*   e.injected  -- our own print() re-enters text_in. Stripping the tag before
*                  re-emitting already breaks the loop (the new line cannot
*                  match), but a guard that does not depend on getting the
*                  strip right is cheaper than the incident.
*   the strip   -- what goes back out carries no tag, for the reason above.
*
* The non-printable strip is dwecho's, for dwecho's reason: the line arrives
* with the packet's padding and any colour bytes still on it, and a match
* against raw bytes is a match that works until the day it does not.
*
* IT READS `message_modified`, NOT `message`. Ashita hands a text_in handler
* both: the line as it arrived, and the line as it will be DRAWN once every
* handler ahead of this one has had it. They are the same string until an addon
* that runs first rewrites one -- and the Ashita bundle ships several that do
* (customcolors recolours SYSTEM_3, changecall rewrites call tags), so this is
* the ordinary case rather than the exotic one. Re-emitting `message` would
* quietly undo their work, because what we put back is what the player reads.
* `message` is the fallback for the same reason dwecho matches on it: a field
* that is not there must not throw inside a chat handler.
*
* (Server SYSTEM_3 does reach text_in -- customcolors.lua matches it by mode
* 121, and NS_SAY by 9. This handler deliberately does NOT gate on the mode:
* the tag is already a far narrower match than any mode is, and a mode test
* would be one more thing to be wrong on the day a notice is sent some other
* way -- printToArea's server-wide contract line being the obvious candidate.
* Missing a notice is the failure that matters here; re-routing a stray line
* is not.)
--]]
ashita.events.register('text_in', 'dwquest_text_in', function (e)
    if (e.blocked or e.injected) then
        return;
    end

    local raw = e.message_modified or e.message;

    if (raw == nil) then
        return;
    end

    local line = tostring(raw):gsub('[^\032-\126]', '');
    local at   = line:find(NOTICE_TAG, 1, true);

    if (at == nil) then
        return;
    end

    -- THE TRIM IS ON THE REMAINDER, NOT ON THE LINE, and the order is the
    -- whole of it. Trimming first would eat the tag's own trailing space, so a
    -- line that is nothing BUT a tag would stop matching -- and a guard that
    -- cannot be reached is not a guard, it is a comment that looks like one.
    -- Trim what is left instead, and refuse when that is nothing: blocking a
    -- bare tag would swallow a line and put an empty one back.
    local said = line:sub(at + #NOTICE_TAG):gsub('%s+$', '');

    if (said == '') then
        return;
    end

    e.blocked = true;

    print(chat.header('dwquest'):append(chat.message(said)));
end);

--[[
* A login is a new character and a new account view; a zone line is a good
* moment to catch up on kills the ping may have missed. Re-sync either way --
* but only once the server has spoken this session (an automatic line against
* a dead verb is the player saying it in public).
*
* The re-ask is `hello`, not `board`: the ping arming is a local var on the
* character the server was talking to, and this is exactly the event after
* which it may no longer be there.
--]]
ashita.events.register('packet_in', 'dwquest_zonein', function (e)
    if (e.id == 0x000A) then
        state.synced      = false;
        state.offers      = { };
        state.actives     = { };
        state.activeOrder = { };
        state.balance     = nil;
        state.clockAt     = nil;
        state.status      = 'Loading...';
        state.statusBad   = false;

        -- A new zone may be a new character; the band look belongs to the
        -- session it was clicked in.
        state.viewBand   = nil;
        state.playerBand = nil;

        -- A write cannot survive the zone line it was in flight across: the
        -- answer, if there was one, went to a session that is gone.
        writePending = nil;

        -- NEITHER CAN A QUOTE. It was priced against an item in a state this
        -- window can no longer vouch for, and the server would refuse it on
        -- the stamp anyway -- so the button goes rather than the refusal.
        shop.synced = false;
        shop.item   = nil;
        shop.slots  = { };
        shop.quote  = nil;

        invalidateGear();

        if (state.serverSpoke) then
            refresh('hello');
        end
    end
end);
