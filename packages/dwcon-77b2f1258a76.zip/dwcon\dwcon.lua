--[[
* DriftwoodXI -- dwcon
*
* Every enemy near you wears its /check answer. A small colored linkpearl bead
* floats beside each mob's name, colored by con difficulty, with its level
* beside it. No more checking a camp one mob at a time to find out which of
* the six identical crabs is the one that kills you.
*
* CON IS SERVER DATA, NOT A CLIENT COMPUTATION. `charutils::CheckMob` walks an
* EXP curve that modules/driftwoodxi/difficulty_curve.lua overrides, so even
* with a mob's level in hand the client cannot reproduce the server's answer.
* And difficulty is PER VIEWER -- it depends on your level, not the mob's --
* so it cannot ride the shared 0x00E entity update either. The server works it
* out and tells this addon, over the per-player `_DWODATA` chat-record channel
* (0x017, blocked here before the chat log ever sees it) that ten other
* Driftwood addons already use.
*
* THE DRIFTWOOD CURVE HAS RETIRED INCREDIBLY EASY PREY (tier 1 is unreachable;
* difficulty_curve.lua sentinels it). Exactly seven tiers occur, plus
* "impossible to gauge" for the mobs the server refuses to gauge at all --
* NMs, Battlefield mobs, CheckAsNm -- which is the same gate the real /check
* applies, so this addon cannot leak a difficulty /check would have withheld.
*
* THE NAMEPLATE RECTANGLE IS NOT EXPOSED TO LUA, so the bead's position is
* re-derived rather than read: the mob's world position is projected through
* the live view and projection matrices (the targetlines worldToScreen
* pattern) with a height offset that puts it where the name floats, and the
* pearl is drawn on `imgui.GetForegroundDrawList()` from `d3d_present`. The
* nameplate's own font colors are untouched -- they still mean NPC / enemy /
* claimed, which is a different question from "can I kill it".
*
* No assets ship with this addon. The pearl is three draw calls: a filled
* circle in the tier color, a rim, and an off-center white specular dot (the
* crosshair precedent).
*
* TURN IT OFF AND NOTHING IS LOST. /check still works, typed, on one mob at a
* time, exactly as it always did. This is faster; it is not required. And OFF
* MEANS OFF ON BOTH SIDES (1.1.0): the master switch sends `!dwo bye`, so the
* server stops walking your visible set every two seconds as well as the addon
* stopping drawing. Turning it back on re-hellos and gets a fresh snapshot.
*
* THE LEGEND IS ALSO A CENSUS (1.1.0). Each legend row carries the number of
* beads of that color ACTUALLY ON SCREEN this frame -- counted by the world
* pass as it draws, not by a second walk of the table, so it cannot disagree
* with what you are looking at. That is the "which of the six identical crabs"
* question answered without counting beads by eye.
*
* AND A FLOOR UNDER IT (1.1.0). "Softest pearl to draw" hides everything below
* a tier, because a level-75 player in a level-20 zone is reading forty green
* beads to find the one that is not. It is a DRAW filter and nothing else --
* the server still sends every mob, the census still counts only what is
* drawn, and your own target keeps its bead whatever the floor says, because a
* filter that blanks the one mob you pointed at is a filter players turn off.
* A mob the server refuses to gauge has no tier for the floor to judge; the
* ungaugeable checkbox is its only switch.
*
* AND THE EFFECT STRIP (1.2.0). Everything your target is wearing, in one row,
* from the server rather than from guesswork.
*
* WHY THAT IS NOT ALREADY SOLVED. Nothing on the wire tells a client what a MOB
* is wearing: 0x063 carries your own icons, 0x076 your party's, and a monster's
* status container is never serialised at all. So every enemy-debuff bar in
* existence INFERS the set by watching action packets -- a handful of message
* ids mapped to effect ids, with the duration invented from a hard-coded table.
* It is a good guess and it is only a guess, which is why a Mandau proc shows
* the graphic and the chat line and never reaches the bar: the status rides the
* action's ADDITIONAL-EFFECT message 164, and the bars read 160 there.
*
* This strip is told. con_data.cpp walks the mob's real CStatusEffectContainer
* and sends every effect the client has an icon for -- which is exactly the
* test the game applies to your own buff bar, so anything you can see on
* yourself you can now see on the mob: additional-effect Poison, TP-move
* debuffs, Sleep, Bind, Stun, and the buffs a mob gave itself.
*
* THE SECONDS ARE COUNTED HERE, NOT SENT REPEATEDLY. The server states an
* effect's remaining time once and says nothing more until it actually moves --
* a re-application, a dispel, an early wear-off. A clock ticking down is not
* news, and sending it as news would be every timed effect in the zone on the
* wire every two seconds forever.
*
* ONE SWITCH, NOT TWO. The strip rides the same handshake the pearls do, so
* `/dwcon off` stops both -- off still means off on the server as well. The
* strip's own checkbox decides whether it is DRAWN, and nothing else.
--]]

addon.name    = 'dwcon';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.0';
addon.desc    = 'Con pearls: every nearby enemy\'s /check difficulty and level, at a glance.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the `!dwo hello` handshake; installed
-- before any other text_in handler in this file (dwecho.lua). Without it the
-- player reads `Blaster : !dwo hello` in their own log on every zone line.
echo.install();

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load.
*
* This addon is loaded from the launcher's boot script, which runs long before
* the client has a rendering device -- and `d3d.get_device()` at file scope
* makes the whole addon fail to load when it answers nothing (the dwbags
* lesson). Nothing here needs a device until the first pearl is drawn, by
* which point there certainly is one.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; the fourteenth `_DW*DATA` name,
-- and nothing else on the server uses it, so matching it exactly is a safe
-- filter.
local DATA_SENDER = '_DWODATA';

-- Protocol version the server announces in its `d|` record. An unknown one is
-- HARD REFUSED (one warning, then silence) rather than guessed at: a pearl
-- drawn from a record layout this addon does not understand is a lie about how
-- dangerous something is, which is worse than no pearl at all.
local PROTOCOL = 1;

--[[
* The tiers, in EMobDifficulty order.
*
* Tier 1 (Incredibly Easy Prey) is absent ON PURPOSE: the DriftwoodXI
* difficulty curve sentinels it out of reach, so a pearl for it would be a
* legend row no player can ever see. A tier this table does not know is drawn
* as the ungaugeable pearl rather than skipped -- a server that grows an
* eighth tier should be VISIBLE here, not invisible.
*
* Colors are the plan's exact RGB triples. `rim` overrides the default dark
* outline; only Too Weak needs it, because a near-black bead with a black
* outline is a smudge.
--]]
local TIERS = {
    [0] = { short = 'TW', name = 'Too Weak',         r = 45,  g = 45,  b = 45,  rim = { 110, 110, 110 } },
    [2] = { short = 'EP', name = 'Easy Prey',        r = 60,  g = 180, b = 75  },
    [3] = { short = 'DC', name = 'Decent Challenge', r = 240, g = 200, b = 40  },
    [4] = { short = 'EM', name = 'Even Match',       r = 245, g = 130, b = 32  },
    [5] = { short = 'T',  name = 'Tough',            r = 220, g = 50,  b = 47  },
    [6] = { short = 'VT', name = 'Very Tough',       r = 230, g = 60,  b = 230 },
    [7] = { short = 'IT', name = 'Incredibly Tough', r = 120, g = 50,  b = 200 },
};

-- The pearl for a mob the server refuses to gauge (NM / Battlefield /
-- CheckAsNm). Silver, and the level is replaced by a question mark: the server
-- withheld the number, so the addon must not appear to know it.
local UNKNOWN = { short = '??', name = 'Impossible to gauge', r = 200, g = 205, b = 215 };

-- Legend order, and the order the tiers are described in anywhere else. It is
-- also the DANGER order, which is what makes the tier floor below a single
-- number rather than seven checkboxes: EMobDifficulty counts upward.
local TIER_ORDER = { 0, 2, 3, 4, 5, 6, 7 };

--[[
* The client's entity array is 0x900 entries and Ashita's GetRenderFlags0 and
* friends index it WITHOUT a bounds check, so a targid off the wire is an
* array subscript this addon has to vouch for. dwparse guards the same array
* at the same bound for the same reason (the zone's overflow-escape targid
* 0x900 is one past the end); dynamic targids walk [0x700, 0x900), and static
* ones stop well below that, so nothing the server can legitimately send is
* refused by this.
--]]
local MAX_ENTITY_INDEX = 0x8FF;

-- The highest level the server can put on the wire: con_data.cpp clamps to
-- 9999 before it formats the pair, so anything past it is a corrupt line.
local MAX_LEVEL = 9999;

--[[
* THE EFFECT WIRE'S OWN CEILINGS, which are con_data.cpp's (kMaxEffectsPerMob,
* kMaxSeconds) written on this side so the harness can compare the two files.
*
* MAX_EFFECTS is not a display choice, it is the LINE BUDGET: one mob's whole
* set is one `f|` line and is never split, because half a list looks exactly
* like a list that lost its other half. Eight effects at fifteen bytes plus the
* targid is 126 of the 130 bytes, which is where the eight comes from.
*
* The icon ceiling is the client's own: status ids run 0..0x3FF and 255 is the
* "no effect" filler the party packet uses, so neither is ever a texture to
* fetch. (dwsquad guards the same array at the same bound for the same reason.)
--]]
local MAX_EFFECTS   = 8;
local MAX_SECONDS   = 9999;
local MAX_POWER     = 9999;
local ICON_MAX      = 0x3FF;
local ICON_FILLER   = 255;

--[[
* Drawing constants. Everything a player can move lives in `config`; these are
* proportions of the pearl rather than sizes, so one size slider keeps the bead
* looking like a bead at every setting.
--]]
local SPECULAR_OFFSET = 0.34;   -- of the radius, up and to the left
local SPECULAR_SIZE   = 0.28;   -- of the radius
local RIM_THICKNESS   = 0.18;   -- of the radius, never below 1px
local PEARL_NUDGE     = 2.0;    -- px of air between the bead and the nameplate
local TARGET_SCALE    = 1.40;   -- your current target's bead draws larger
local FADE_START      = 0.55;   -- fraction of the cap where fading begins
local MIN_ALPHA       = 0.30;   -- alpha at the cap itself

--[[
* How far outside the viewport a projected nameplate may land and still be
* worth drawing. A mob at ninety degrees to the camera is IN FRONT of the
* camera plane -- it survives the w > 0 test -- and projects hundreds or
* thousands of pixels off the side, where five draw calls, a label format and
* a text measurement are all paid for something the clip rectangle throws
* away. At a full camp that is most of the cached set, every frame.
*
* The margin is generous on purpose: the bead sits `radius + PEARL_NUDGE` left
* of the anchor and the label a text width further left again, so a mob whose
* NAME is just off the right edge can still owe a visible bead. 128px covers
* the largest pearl (16 * 1.40) plus the widest label this addon can write.
*
* Written as "must be inside" rather than "must not be outside" so a NaN --
* which fails every comparison -- is culled rather than passed through.
--]]
local SCREEN_MARGIN   = 128;

--[[
* Persisted presentation state, through Ashita's settings library (the dwport
* shape). Flat scalars only -- the settings serializer takes booleans, numbers
* and strings, and a nested table here would be a silent loss on save.
*
* THE SHIPPED VALUES LIVE WHERE NOTHING CAN WRITE OVER THEM. `defaultConfig`
* below is handed to Ashita's settings library, which keeps that reference and
* merges from it on every character switch -- and on the path where the library
* hands the same table back as the live settings, `commit` would be writing the
* player's choices into the defaults themselves. The sanitiser's fallbacks and
* the window's Reset button both need values that provably have not moved, so
* they read this table and never that one.
--]]
local SHIPPED = {
    pearls      = true,     -- the master switch; /dwcon on|off drives it
    levels      = true,     -- "Lv.34" beside the bead
    tiers       = false,    -- "DC" beside the bead
    nm          = true,     -- draw a bead for mobs the server will not gauge
    pearlSize   = 7.0,      -- radius in pixels at 1.0 scale
    heightUp    = 2.2,      -- world units above the mob's origin
    maxDistance = 30.0,     -- yalms; beyond this nothing is drawn
    minTier     = 0,        -- draw nothing softer than this EMobDifficulty

    -- The effect strip (1.2.0). `fx` draws it; the FEED is the pearls' master
    -- switch, because both ride one handshake.
    fx          = true,     -- draw the target's effect strip
    fxIcons     = true,     -- use the client's own status icons when it has one
    fxSecs      = true,     -- write the remaining seconds under each effect
    fxScale     = 1.0,      -- icon size multiplier
    fxX         = 0.50,     -- horizontal anchor, as a FRACTION of the viewport
    fxY         = 0.12,     -- vertical anchor, as a fraction of the viewport
};

local defaultConfig = T{ };

for key, value in pairs(SHIPPED) do
    defaultConfig[key] = value;
end

local config = defaultConfig;

--[[
* SANITISE WHAT CAME OFF DISK, IN PLACE.
*
* The settings file is a Lua file in the player's config folder, so its values
* are whatever the last writer put there -- and this addon compares two of
* them against numbers every frame. `distance > config.maxDistance` against a
* STRING is "attempt to compare number with string", raised inside the world
* pass's pcall sixty times a second: one error line, and then no pearls at all
* for the rest of the session while the window still cheerfully reports how
* many enemies are gauged. One hand-edited quote does that.
*
* In place rather than into a fresh table: Ashita's settings library keeps the
* table it handed back and saves THAT one (settings.lua's own note), so
* replacing it would make every later save a no-op.
--]]
local function sanitize()
    local function number(key, low, high)
        local value = tonumber(config[key]);

        -- NaN fails both comparisons, so this catches it without naming it.
        if (value == nil or not (value >= low and value <= high)) then
            config[key] = SHIPPED[key];
        else
            config[key] = value;
        end
    end

    config.pearls = config.pearls ~= false;
    config.levels = config.levels ~= false;
    config.tiers  = config.tiers  == true;
    config.nm     = config.nm     ~= false;

    config.fx      = config.fx      ~= false;
    config.fxIcons = config.fxIcons ~= false;
    config.fxSecs  = config.fxSecs  ~= false;

    number('pearlSize',   3.0,  16.0);
    number('heightUp',    0.0,  6.0);
    number('maxDistance', 5.0,  50.0);

    -- The anchors are FRACTIONS of the viewport and not pixels, so a player who
    -- changes resolution finds the strip where they left it rather than off the
    -- edge of the screen. The vertical range stops short of the bottom because
    -- the strip grows downward from its anchor.
    number('fxScale',     0.5,  3.0);
    number('fxX',         0.0,  1.0);
    number('fxY',         0.0,  0.9);

    -- The floor is one of the tiers, never an arbitrary number: a value
    -- between two tiers would hide a tier nothing in the window names.
    local floorTier = tonumber(config.minTier);
    local known     = false;

    for _, tier in ipairs(TIER_ORDER) do
        if (floorTier == tier) then
            known = true;
        end
    end

    config.minTier = known and floorTier or 0;
end

-- `type(loaded) == 'table'` rather than `~= nil`: the library answers a
-- corrupt file with the defaults, but a library that ever answered anything
-- else would have every read below indexing a non-table, and the settings file
-- is the one input to this addon a player edits by hand.
local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

pcall(sanitize);

--[[
* ImGui widget holders. Every ImGui input wants a table it can write into, so
* the window edits these and copies back into `config` on the frame the widget
* reports a change. Keeping the two apart is what lets `config` stay flat
* scalars for the serializer.
--]]
local ui = {
    pearls      = T{ true },
    levels      = T{ true },
    tiers       = T{ false },
    nm          = T{ true },
    pearlSize   = T{ 7.0 },
    heightUp    = T{ 2.2 },
    maxDistance = T{ 30.0 },

    fx          = T{ true },
    fxIcons     = T{ true },
    fxSecs      = T{ true },
    fxScale     = T{ 1.0 },
    fxX         = T{ 0.50 },
    fxY         = T{ 0.12 },
};

--[[
* The label mode the world pass caches its label strings against: the two
* settings that decide what a bead's text says, folded into one number so a
* cached label can be invalidated by comparing scalars (see drawOne).
--]]
local labelMode = 0;

local function refreshUi()
    ui.pearls[1]      = config.pearls;
    ui.levels[1]      = config.levels;
    ui.tiers[1]       = config.tiers;
    ui.nm[1]          = config.nm;
    ui.pearlSize[1]   = config.pearlSize;
    ui.heightUp[1]    = config.heightUp;
    ui.maxDistance[1] = config.maxDistance;

    ui.fx[1]      = config.fx;
    ui.fxIcons[1] = config.fxIcons;
    ui.fxSecs[1]  = config.fxSecs;
    ui.fxScale[1] = config.fxScale;
    ui.fxX[1]     = config.fxX;
    ui.fxY[1]     = config.fxY;

    labelMode = (config.tiers and 1 or 0) + (config.levels and 2 or 0);
end

refreshUi();

--[[
* A settings write the window still owes. settings.save WRITES A FILE, and a
* slider answers "changed" on every frame its handle moves -- so a drag from
* 7 to 14 used to rewrite the settings file once per frame for a number the
* player was still choosing. The value applies live (the beads follow the
* handle); only the file waits until no widget is being held (dwraid's shape).
--]]
local saveWhenReleased = false;

local function commit(deferSave)
    config.pearls      = ui.pearls[1];
    config.levels      = ui.levels[1];
    config.tiers       = ui.tiers[1];
    config.nm          = ui.nm[1];
    config.pearlSize   = ui.pearlSize[1];
    config.heightUp    = ui.heightUp[1];
    config.maxDistance = ui.maxDistance[1];

    config.fx      = ui.fx[1];
    config.fxIcons = ui.fxIcons[1];
    config.fxSecs  = ui.fxSecs[1];
    config.fxScale = ui.fxScale[1];
    config.fxX     = ui.fxX[1];
    config.fxY     = ui.fxY[1];

    sanitize();
    refreshUi();

    if (deferSave) then
        saveWhenReleased = true;
    else
        pcall(settings.save);
    end
end

--[[
* A character switch or a settings reload hands back a DIFFERENT table, and
* the widgets are what the window writes through -- so they have to be re-read
* from it or the next click writes the old character's values back over the
* new one's. Registered here rather than beside settings.load because the
* callback needs `sanitize` and `refreshUi`, and `refreshUi` needs `ui` --
* none of which exist that far up the file, so the old registration captured
* `ui` as a nil global and the widgets were never re-read at all.
--]]
pcall(settings.register, 'settings', 'dwcon_settings_update', function (s)
    if (type(s) == 'table') then
        config = s;

        pcall(sanitize);
        refreshUi();
    end
end);

--[[
* Session state.
*
* `cons` is a PLAIN table keyed by targid -- T{}'s sugar method names would
* collide with nothing here, but pairs() over it is the whole draw loop and a
* plain table keeps that honest.
--]]
local state = {
    cons     = {},          -- [targid] = { gauge = bool, tier = n, level = n }
    consArriving = nil,     -- a sync's rows while its envelope is open; swapped in at z| (2026-09-06)

    --[[
    * [targid] = { { icon = n, secs = n, power = n, ends = clock|nil }, ... }
    *
    * A MOB'S SET IS REPLACED WHOLE, never merged: one `f|` line carries the
    * mob's entire list, so an effect that fell off is a shorter line and needs
    * no removal record of its own. `ends` is stamped from the local clock when
    * the line arrives and is what the strip counts down from -- the server
    * states a remaining time once and then says nothing until it really moves.
    --]]
    fx       = {},
    fxArriving = nil,       -- the same staging a sync's cons get
    inbound  = nil,         -- the verb of the envelope currently open
    synced   = false,       -- a full sync has closed at least once
    refused  = false,       -- an unknown protocol version was seen; stay silent
    warned   = false,       -- a malformed pair has already been reported once
    reported = false,       -- a draw error has already been reported once
    badRecord = false,      -- a record that THREW has been reported once

    notice     = nil,       -- the last m|/e| sentence, for the config window
    noticeBad  = false,
    noticeSaid = nil,       -- the last notice ALREADY printed, so it is said once

    -- THE SERVER SPOKE, WHATEVER IT SAID. A build without con_data.cpp answers
    -- every hello with `e|Con pearls are not in this build.`, which is an
    -- answer -- so the zone-in retry loop must stop chasing it. Without this
    -- the six-hello budget bought six identical red lines per zone from a
    -- server that had already said no. Cleared on the zone line, because the
    -- map on the other side of it may be a different build.
    answered  = false,

    syncAt    = nil,        -- os.clock() at which the zone-in hello may be tried
    syncSlot  = nil,        -- the stagger deadline, once zoning has cleared
    syncTries = 0,          -- zone-in hellos sent this zone, for the retry bound

    -- THE SILENT-SERVER BRAKE (1.0.11, the 2026-08-09 review's fourth backlog
    -- item). An unknown ! command falls through to PUBLIC /say on this server,
    -- and the zone-in retry loop above spends up to six hellos per zone -- so
    -- on a server without con_data the pearls were six lines of plumbing said
    -- aloud on every zone line. Once a zone's whole budget has gone unanswered
    -- and the server has never answered this session, every later zone spends
    -- exactly ONE hello (the re-probe a map restart deserves) until one is
    -- answered. A server that has spoken keeps the full budget: the loss the
    -- retry exists for is a dropped line, not a missing module.
    everSynced  = false,    -- a sync has landed at least once this session
    spentBudget = false,    -- a zone's whole retry budget went unanswered
    gaveUp      = false,    -- the budget ran out with nothing to show for it

    -- WALL seconds (os.time), not os.clock's CPU seconds, and the only value
    -- in this file that is. It is read for one purpose -- telling the player
    -- how long ago the last full snapshot landed -- and os.clock counts
    -- processor time, which on a vsynced client runs slower than the clock on
    -- the wall. "Snapshot 3s ago" for something six seconds old is a small lie
    -- that is easy to avoid and impossible to notice. Never compared against
    -- any os.clock value; the throttles and the retry deadlines all stay on
    -- os.clock, where an elapsed CPU interval is exactly what is wanted.
    syncedAt    = nil,

    open     = T{ false },  -- the config window
};

--[[
* HOW MANY BEADS OF EACH COLOR ARE ON SCREEN RIGHT NOW.
*
* Filled by the world pass as it draws and read by the legend in the same
* frame, so the census cannot disagree with what the player is looking at --
* which a second walk of `state.cons` would, because the table holds mobs
* behind walls, past the distance cap and below the tier floor as well.
*
* One table, re-zeroed per frame rather than re-allocated: this is the hottest
* path in the suite and a fresh table sixty times a second is exactly the kind
* of garbage that shows up as a stutter in a crowded camp. Keyed by tier with
* `u` for the ungaugeable bead, which is the same shape the wire uses.
--]]
local census = { u = 0 };

for _, tier in ipairs(TIER_ORDER) do
    census[tier] = 0;
end

local function clearCensus()
    for key in pairs(census) do
        census[key] = 0;
    end
end

--[[
* Outbound: `!dwo hello` and `!dwo bye`, and nothing else, ever. Both are the
* same switch -- arm the feed, disarm the feed -- and dwo.lua has carried both
* since the doorway's first commit.
*
* One line per 1.2s with duplicate collapse -- the client's chat rate limit
* being what it is. The zone-in hello is held out of the queue entirely until
* the client has finished zoning AND this addon's stagger slot has come up
* (see the zone-in handler and dwecho.lua's ZONE_ORDER); a line sent while the
* client is still zoning, or in the same beat as a sibling's zone-in sync, is
* dropped with "A command error occurred." and never reaches the server.
--]]
local SEND_INTERVAL = 1.2;

-- The zone-in hello is RE-TRIED until the server's first sync actually lands
-- (state.synced), not fired once and forgotten (2026-08-15). The client clears
-- GetIsZoning() a moment before it will accept chat again, so a single
-- staggered hello can still fire into that settle window, be dropped with
-- "A command error occurred.", and -- with nothing to retry it -- leave every
-- pearl gone until a hand-typed /con. A healthy zone answers the first hello
-- and disarms; only a lost one costs a retry (and, once, that error line).
-- Bounded so a server that does not speak con is not chatted at forever.
local ZONE_HELLO_RETRY     = 2.5;   -- seconds between re-tries of a lost hello
local ZONE_HELLO_MAX_TRIES = 6;     -- give up after this many attempts, per zone

local queue   = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

--[[
* HELLO AND BYE ARE THE SAME SWITCH, so only the last one asked for matters.
*
* `issue` collapses a repeat of the same line but would happily hold both verbs
* at once, and the queue drains one line per 1.2s. A player who ticks the
* master switch off, on and off again inside that window used to leave
* [bye, hello] queued -- the addon's own idea of the switch says OFF and the
* last line the server actually reads says ARM, so it keeps walking the whole
* visible mob set every two seconds for beads nobody is drawing, until the next
* toggle or zone line. Dropping the countermanded verb makes the queue say what
* the switch says.
--]]
local function dropQueued(command)
    for index = #queue, 1, -1 do
        if (queue[index] == command) then
            table.remove(queue, index);
        end
    end
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* The handshake. No records are ever sent to a session that has not spoken it
* (the tracker_core ping rule -- a vanilla client never sees a stray record),
* so this is the one line the addon sends blind, exactly as dwtracker's own
* hello is. Re-sent after every zone line because the server's per-char state
* dies with the zone.
--]]
local function hello()
    dropQueued('!dwo bye');

    issue('!dwo hello');
end

--[[
* The other half of the handshake, and the reason the pearls being "off" now
* costs the server nothing either.
*
* `!dwo bye` clears the session flag con_data.cpp gates every record on, so the
* 2s walk of your visible mob set stops. Turning the pearls off used to leave
* that walk running forever -- the addon simply stopped drawing what it was
* still being sent -- and unloading the addon was worse: the packet_in handler
* that BLOCKS the records dies with it, so `_DWODATA : c|1042:3:34` lines
* appeared in the player's chat log every two seconds until they next zoned.
*
* ONLY EVER SAID TO A SERVER THAT HAS ANSWERED A HELLO. `bye` has been in
* modules/driftwoodxi/dwo.lua since the doorway's first commit, so any server
* with the module has it -- and `everSynced` is precisely the proof that this
* server has the module. On a server without it an unrecognised `!` command
* falls through to PUBLIC /say, which is the whole reason the silent-server
* brake exists; a goodbye nobody can hear is not worth one of those.
*
* The reply (`d|1|bye`, an `m|`, `z|bye`) is a sentence for the window, not a
* sync, so nothing re-arms from it.
--]]
local function goodbye()
    if (state.refused) then
        return;
    end

    -- The feed is disarmed the moment the server reads this, so the addon must
    -- stop believing it is being fed: the next `on` needs a hello to get a
    -- snapshot, and `synced` is the flag that decides whether it sends one.
    state.synced = false;

    -- And what it is holding stops being true. A table kept across a pause in
    -- the feed is a snapshot of whenever the pause started -- ten minutes old
    -- is as easy as ten seconds -- and drawing it for the second between the
    -- switch coming back on and the fresh sync landing is the addon stating a
    -- difficulty it has no current basis for.
    state.cons     = {};
    state.consArriving = nil;
    state.fx       = {};
    state.fxArriving = nil;
    state.syncedAt = nil;

    -- A hello still in the queue is an arming this switch has just
    -- countermanded, and it is dropped whether or not a bye follows it. It
    -- used to survive: turn the pearls off in the second between the zone-in
    -- hello being queued and the throttle letting it out, and the line went
    -- anyway -- arming the server for a renderer that had just been told to
    -- stop, with no bye to follow because nothing had synced yet.
    dropQueued('!dwo hello');

    if (state.everSynced) then
        issue('!dwo bye');
    end
end

--[[
* MAKE THE WIRE FOLLOW THE SWITCH, whichever of the three doors moved it --
* /dwcon on|off, the window's first checkbox, or the window's Reset button.
* All three have to do the same thing to the server or the addon's idea of the
* switch and the server's stop agreeing about whether it is still walking the
* player's visible set every two seconds.
*
* Answers WHAT IT ACTUALLY DID -- 'hello', 'bye', or nil for "nothing needed
* saying" -- because the callers announce themselves to the player and one that
* assumed a line went out said so in cases where none had: `/dwcon on` when the
* pearls were already on, and the same when the protocol had been refused, both
* used to promise a fresh snapshot nobody had asked for.
--]]
local function syncPearlSwitch(was)
    if (config.pearls == was) then
        return nil;
    end

    if (not config.pearls) then
        goodbye();

        return 'bye';
    end

    -- `goodbye` threw the table away on the way out, so there is nothing to
    -- draw until this is answered -- which is the honest state to be in. A
    -- refused protocol has nothing worth asking.
    if (state.synced or state.refused) then
        return nil;
    end

    hello();

    return 'hello';
end

local function setPearls(on)
    local was = config.pearls;

    ui.pearls[1] = (on == true);

    commit();

    return syncPearlSwitch(was);
end

--[[
* Record parsing.
*
* Every record is pipe-separated with a single-character kind. Anything this
* addon does not recognise falls off the end of the chain rather than being an
* error: a server newer than the addon must not break it, which is the whole
* reason the `d|` record carries a version at all. Additive record kinds
* therefore never bump PROTOCOL.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* WIRE BYTES ARE NOT SAFE TO PRINT AS THEY ARE.
*
* The chat log reads two-byte markup tags -- \30x, \31x, \127x, \239x -- and
* eats the byte after each one. A record this addon could not read is by
* definition a record whose bytes it does not vouch for, so quoting one back
* raw is how a diagnostic line turns the rest of itself (and whatever color
* the log was using) into something else. The same blanket dwecho.lua strips
* on the way in, applied on the way out, plus a length bound: the quote exists
* to be recognisable, not to be complete.
--]]
local function printable(text, limit)
    local clean = tostring(text):gsub('[^\032-\126]', '?');

    limit = limit or 48;

    if (#clean > limit) then
        clean = clean:sub(1, limit - 3) .. '...';
    end

    return clean;
end

--[[
* One malformed pair is a warning, not a traceback and not a wall of red. It
* is latched: a server sending one bad pair is sending it every throttle
* period, and sixty lines a second of the same complaint is worse than the bug.
--]]
local function warnBadPair(entry)
    if (state.warned) then
        return;
    end

    state.warned = true;

    print(chat.header('dwcon'):append(chat.warning(
        string.format('ignoring a con record this addon could not read ("%s"). Pearls for other mobs are unaffected.', printable(entry)))));
end

--[[
* A whole number inside a range, or nil.
*
* EVERY NUMBER OFF THIS WIRE IS AN ARRAY SUBSCRIPT OR A PRINTED VALUE, so
* "tonumber said yes" is not enough on its own:
*
*   * a targid is handed straight to Ashita's GetRenderFlags0, which indexes
*     the client's 0x900-entry array with no bounds check of its own, so an
*     impossible one is a read past the end of that array;
*   * `tonumber` accepts `2.5`, `inf` and `nan` (and `0x20`), and a fractional
*     targid silently truncates to a DIFFERENT mob's index inside the binding;
*   * a level of nan reaches string.format('%d') and prints as
*     `Lv.-9223372036854775808`, a label wider than the screen.
*
* `value ~= math.floor(value)` is true for nan and false for inf, which is why
* the range test is here too rather than left to the caller.
--]]
local function whole(text, low, high)
    local value = tonumber(text);

    if (value == nil or value ~= math.floor(value) or value < low or value > high) then
        return nil;
    end

    return value;
end

--[[
* `<targid>:<tier>:<level>` for a gaugeable mob, `<targid>:u` for one the
* server refuses to gauge. Pairs are comma-separated and a `c|` line is packed
* to the wire budget, so one envelope may carry several of these lines; each
* one is merged as it arrives.
--]]
local function applyPairs(packed, into)
    if (packed == nil or packed == '') then
        return;
    end

    for _, entry in ipairs(split(packed, ',')) do
        if (entry ~= '') then
            local bits   = split(entry, ':');
            local targid = whole(bits[1], 0, MAX_ENTITY_INDEX);

            if (targid == nil) then
                warnBadPair(entry);
            elseif (bits[2] == 'u') then
                into[targid] = { gauge = false };
            else
                -- The tier ceiling is deliberately wide: an eighth tier is a
                -- server this addon is older than, and the TIERS comment says
                -- that must be VISIBLE (as the ungaugeable bead) rather than
                -- refused as malformed.
                local tier  = whole(bits[2], 0, 255);
                local level = whole(bits[3], 0, MAX_LEVEL);

                if (tier == nil or level == nil) then
                    warnBadPair(entry);
                else
                    into[targid] = { gauge = true, tier = tier, level = level };
                end
            end
        end
    end
end

--[[
* `f|<targid>` and then one comma-separated field per effect, each of them
* `<icon>`, `<icon>:<secs>` or `<icon>:<secs>:<power>` -- one mob's whole set.
*
* THE WHOLE SET, WHICH IS WHY THERE IS NO REMOVAL RECORD. The server sends the
* list it sees; a shorter list is a wear-off and an empty one (`f|1042` with
* nothing after it) is a mob that is now clean. Merging instead would need a
* second record kind for removals and a way to be sure none was ever lost.
*
* A pair this addon cannot read is DROPPED WITH ITS MOB rather than skipped
* inside the list: a partial set drawn as if it were whole is the strip saying
* "this is everything on it", which would be a lie. The warning is the same
* latched one a bad con pair gets.
--]]
local function applyEffects(packed, into)
    if (packed == nil or packed == '') then
        return;
    end

    local parts  = split(packed, ',');
    local targid = whole(parts[1], 0, MAX_ENTITY_INDEX);

    if (targid == nil) then
        warnBadPair(packed);

        return;
    end

    local list = {};

    -- WALL seconds (os.time), never os.clock's CPU seconds. The strip counts
    -- this down in front of the player, and on a vsynced client os.clock runs
    -- slower than the clock on the wall -- a countdown from it would drift
    -- visibly slow against the wear-off it is predicting. (The same reason the
    -- snapshot age uses os.time; every throttle in this file still uses
    -- os.clock, where an elapsed CPU interval is what is wanted.)
    local now = os.time();

    for index = 2, #parts do
        local entry = parts[index];

        if (entry ~= '') then
            local bits  = split(entry, ':');
            local icon  = whole(bits[1], 1, ICON_MAX);
            local secs  = (bits[2] == nil or bits[2] == '') and 0 or whole(bits[2], 0, MAX_SECONDS);
            local power = (bits[3] == nil or bits[3] == '') and 0 or whole(bits[3], 0, MAX_POWER);

            if (icon == nil or secs == nil or power == nil) then
                warnBadPair(entry);

                return;
            end

            -- The filler the party packet uses for an empty slot. It is never a
            -- real effect and a texture fetch for it is a fetch for nothing.
            if (icon ~= ICON_FILLER and #list < MAX_EFFECTS) then
                list[#list + 1] = {
                    icon  = icon,
                    secs  = secs,
                    power = power,

                    -- Only a TIMED effect gets a deadline. Zero seconds means
                    -- the server has no clock for it (a permanent effect, or
                    -- one the game itself shows without a timer), and inventing
                    -- one here would draw a countdown that means nothing.
                    ends  = (secs > 0) and (now + secs) or nil,
                };
            end
        end
    end

    into[targid] = list;
end

local function handleRecord(line)
    -- A refusal is silence. The packets are still blocked (that happens before
    -- this function is reached), so a mismatched server cannot spill records
    -- into the chat log either.
    if (state.refused) then
        return;
    end

    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;
            state.cons    = {};
            state.consArriving = nil;
            state.fx      = {};
            state.fxArriving = nil;

            -- AND STOP ASKING. A hello already in the queue would go out at a
            -- server that answers it with the same refusal, and the queue is
            -- the only place an ask can still be pending here. (The zone-in
            -- retry disarms itself on `refused` in the frame loop.)
            queue = T{ };

            print(chat.header('dwcon'):append(chat.error(string.format(
                'server con protocol %d, addon expects %d. Update dwcon through the launcher; no pearls until then.',
                version, PROTOCOL))));

            return;
        end

        state.inbound = parts[3];

        -- A sync replaces the whole table -- but STAGED, not in place
        -- (2026-09-06). This used to reset `state.cons` here and let the c|
        -- records refill it, and every record is its own 0x017 packet with
        -- the world pass running between them, so each zone-in sync drew at
        -- least one frame with no pearls at all. The rows now build in
        -- `consArriving`, which nothing draws, and the close swaps them in
        -- whole. The reason the old reset ran FIRST still holds and is kept:
        -- this function is called under a pcall, and a throw after `inbound`
        -- is set must cost one record rather than leave the old rows in place
        -- for the records behind it to merge into -- a fresh staging table
        -- gives the records behind it nothing old to merge into either.
        if (state.inbound == 'sync') then
            state.consArriving = {};
            state.fxArriving   = {};
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state, the
    -- way every sibling accepts them. The server DOES emit both ("Con pearls
    -- are not in this build." rides a status envelope; `bye` answers with an
    -- m|) -- and dropped on the floor, with the packet already blocked, the
    -- refusal reached neither the chat log nor the window: the player read
    -- "Waiting for the server's first snapshot..." forever instead.
    if (kind == 'm' or kind == 'e') then
        -- Sanitised for the same reason warnBadPair's quote is: this reaches
        -- the chat log and the window, and a markup byte in it would eat the
        -- next character of a sentence the player is being asked to act on.
        -- The server writes plain ASCII, so nothing legitimate changes. The
        -- bound is the wire's own line budget rather than the quote's, because
        -- this one is prose the player is meant to read whole.
        local sentence = printable(line:sub(3), 130);

        -- An empty sentence is not a sentence. Stored as nil so the window
        -- falls through to "waiting for the first snapshot" rather than
        -- painting a blank colored line where an explanation should be.
        state.notice    = (sentence ~= '') and sentence or nil;
        state.noticeBad = (kind == 'e');
        state.answered  = true;

        -- AN `e|` CLOSES WHATEVER WAS OPEN. It is the server saying "not this,
        -- and here is why", so leaving `inbound` set would leave the reader
        -- willing to merge stray records that arrive outside any envelope for
        -- the rest of the session. (`m|` does not: the `bye` envelope carries
        -- one mid-flight and closes itself with a `z|`.)
        if (kind == 'e') then
            state.inbound = nil;
            state.consArriving = nil;
            state.fxArriving   = nil;
        end

        -- SAID ONCE PER SENTENCE, not once per record. The build without
        -- con_data.cpp answers every hello with the same `e|`, and the zone-in
        -- budget is up to six of them: six identical red lines per zone line.
        -- A DIFFERENT sentence is still news and is printed.
        if (kind == 'e' and state.notice ~= nil and state.noticeSaid ~= state.notice) then
            state.noticeSaid = state.notice;

            print(chat.header('dwcon'):append(chat.error(state.notice)));
        end

        return;
    end

    -- Records outside an envelope are not ours to act on.
    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        if (state.inbound == 'sync') then
            -- The staged rows become the table in one assignment, so no frame
            -- ever sees the half-arrived set (see the d| branch, 2026-09-06).
            if (state.consArriving ~= nil) then
                state.cons         = state.consArriving;
                state.consArriving = nil;
            end

            -- The effect table is swapped on the SAME close, for the same
            -- reason: a strip that emptied at the header and refilled a packet
            -- later would blink on every zone-in sync.
            if (state.fxArriving ~= nil) then
                state.fx         = state.fxArriving;
                state.fxArriving = nil;
            end

            state.synced      = true;
            state.everSynced  = true;
            state.spentBudget = false;
            state.answered    = true;
            state.gaveUp      = false;
            state.syncedAt    = os.time();

            -- A SYNC THAT ARRIVES AFTER THE SWITCH WENT OFF STILL ARMS THE
            -- SERVER. `goodbye` only says bye to a server that has answered a
            -- hello, and until this record landed none had -- so a player who
            -- turned the pearls off while the zone-in sync was in flight left
            -- the server walking their whole visible mob set every two seconds
            -- for the rest of the zone, with nothing drawing it. This is the
            -- first moment a bye can be sent honestly, so it is sent here.
            if (not config.pearls) then
                goodbye();
            end
        end

        state.inbound = nil;

        return;
    end

    if (kind == 'c') then
        -- A sync's rows build in the staging table; an `upd` has no stage and
        -- merges into the live one, which is what an update is.
        applyPairs(parts[2], (state.inbound == 'sync' and state.consArriving) or state.cons);

        return;
    end

    -- The effect set for one mob (1.2.0). ADDITIVE: a server that does not send
    -- these is a server whose strips are simply empty, and an addon older than
    -- this one drops the record off the end of this chain exactly as it drops
    -- any other kind it has never heard of -- which is why the `d|` version did
    -- not move for it.
    --
    -- parts[2] is the whole payload: the split above was on `|`, and a `f|`
    -- record's own separators are the comma and the colon.
    if (kind == 'f') then
        applyEffects(parts[2], (state.inbound == 'sync' and state.fxArriving) or state.fx);

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017.
*
* Layout after the 4-byte header: Kind at 0x04, Attr at 0x05, Data at 0x06,
* sName[15] at 0x08, Mes at 0x17. Any line whose sender is _DWODATA is ours.
*
* The addon owns the line WHATEVER happens to be in it, so it is blocked before
* parsing rather than after: a malformed record must not leak into the chat log
* as noise, and a record that throws must not leak either.
--]]
ashita.events.register('packet_in', 'dwcon_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    -- LATCHED, for the reason warnBadPair is latched one shelf over: a record
    -- that throws is a record the SERVER is sending, and the server sends the
    -- same shape every two seconds. Unlatched, one bad record kind was a red
    -- line per record per envelope, for as long as the player stayed in the
    -- zone. Cleared on the zone line, so a real change of server is heard.
    if (not ok and not state.badRecord) then
        state.badRecord = true;

        print(chat.header('dwcon'):append(chat.error('bad record: ' .. tostring(err))));
        print(chat.header('dwcon'):append(chat.message('Said once; the rest are ignored quietly. Other mobs\' pearls are unaffected.')));
    end
end);

--[[
* A zone line is a new entity table and a new server-side cache: every targid
* we hold now means a different mob, or nothing. Clear and re-handshake.
*
* The refusal latch is cleared here too. A map restart logs everyone out, so
* the server on the other side of a zone line may well be the updated one.
--]]
ashita.events.register('packet_in', 'dwcon_zonein', function (e)
    if (e.id ~= 0x000A) then
        return;
    end

    state.cons    = {};
    state.consArriving = nil;
    state.fx      = {};
    state.fxArriving = nil;
    state.inbound = nil;
    state.synced  = false;
    state.refused = false;
    state.warned  = false;
    state.badRecord  = false;
    state.notice  = nil;
    state.noticeBad  = false;
    state.noticeSaid = nil;
    state.answered   = false;
    state.gaveUp     = false;
    state.syncedAt   = nil;

    -- Arm the zone-in hello; the frame loop waits out the client's zoning flag
    -- and this addon's stagger slot before actually queueing it. The `+ 4.0` is
    -- only a first look, re-deferred while the load screen is still up (dwecho's
    -- ZONE_ORDER; 2026-08-14, the login-time command-error spam). The retry
    -- budget resets here: each zone gets its own set of attempts.
    --
    -- NOT ARMED AT ALL WHEN THE PEARLS ARE OFF (1.1.0). A player who turned
    -- them off is not owed a handshake on every zone line, and the server is
    -- not owed the 2s walk of their visible set that the handshake starts.
    -- Turning them back on sends its own hello, so nothing is lost by waiting.
    state.syncAt    = config.pearls and (os.clock() + 4.0) or nil;
    state.syncSlot  = nil;
    state.syncTries = 0;
end);

--[[
* Watch what the player sends, and stamp the throttle from it.
*
* Every sibling with a send queue has this handler and dwcon did not, which
* made it the one addon whose throttle only ever knew about its own sends. The
* client's rate limit is on CHAT, not on any addon, so a hello fired in the
* same beat as a line the player typed is the one the client drops -- and
* dwcon's whole session hangs off that one hello: no reply means no pearls for
* the rest of the zone, with nothing on screen to say why. The zone-in path is
* exactly where this collides, because a player who zones and immediately says
* something is ordinary.
*
* `!dwo` lines are ours and are already stamped by pumpQueue; stamping them
* twice would double the interval on our own traffic.
--]]
ashita.events.register('packet_out', 'dwcon_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower:sub(1, 4) ~= '!dwo') then
        lastSend = os.clock();
    end
end);

--[[
* Colors.
*
* ImGui's ImU32 is packed 0xAABBGGRR (IM_COL32_*_SHIFT in Ashita's imgui.lua).
* This builds it with arithmetic rather than `imgui.col32`, for two reasons:
* that helper takes its arguments in (a, r, g, b) order, which is an easy way
* to ship a blue pearl labelled red; and `bit.lshift(alpha, 24)` answers a
* NEGATIVE 32-bit integer for any alpha over 127, which is a thing to have to
* think about at every call site. Multiplication is unsigned and obvious.
--]]
local function packColor(r, g, b, a)
    return (a * 16777216) + (b * 65536) + (g * 256) + r;
end

local function alphaByte(alpha)
    local value = math.floor(alpha * 255 + 0.5);

    if (value < 0) then
        return 0;
    elseif (value > 255) then
        return 255;
    end

    return value;
end

--[[
* THE RGB HALF OF EVERY COLOR THIS ADDON DRAWS, PACKED ONCE AT LOAD.
*
* Only the alpha changes between frames -- it is the distance fade -- and the
* alpha lives in the top byte, so the other three can be added in once here
* and reused forever. Three of these per bead per frame, plus two for the
* label, over every mob in the camp: the arithmetic was never expensive, but
* it was being done from scratch about a thousand times a second for numbers
* that had not moved since the file loaded.
*
* The default rim is a CONSTANT for the same reason it is worth mentioning at
* all: it used to be written `entry.rim or { 0, 0, 0 }` inside the draw, which
* allocated a fresh three-element table for every bead of every tier except
* Too Weak, sixty times a second, purely to read three zeroes back out of it.
--]]
local DEFAULT_RIM = { 0, 0, 0 };
local WHITE_RGB   = packColor(255, 255, 255, 0);

local function prepare(entry)
    local rim = entry.rim or DEFAULT_RIM;

    entry.rgb    = packColor(entry.r, entry.g, entry.b, 0);
    entry.rimRgb = packColor(rim[1], rim[2], rim[3], 0);

    -- The legend's row text, which is otherwise a string.format per row per
    -- frame for eight rows that never change.
    entry.legend = string.format('%-2s  %s', entry.short, entry.name);
end

for _, entry in pairs(TIERS) do
    prepare(entry);
end

prepare(UNKNOWN);

-- A packed RGB with an alpha applied. The three call sites in drawPearl are
-- the hot ones; `packColor` itself survives for the label, where the color is
-- a literal rather than a tier's.
local function withAlpha(rgb, alpha)
    return rgb + (alphaByte(alpha) * 16777216);
end

--[[
* Projection.
*
* v * view * projection, then the perspective divide and the viewport map --
* the targetlines worldToScreen, done one matrix at a time instead of
* pre-multiplying the pair (same answer, sixteen fewer terms to get wrong).
*
* The matrices are D3DMATRIX cdata with _11.._44 fields, and the row-vector
* convention D3D uses puts the transform's column into the sum, which is why
* the x term reads _11/_21/_31/_41 rather than the first row.
*
* Returns nil for anything at or behind the camera plane: w is the view-space
* depth, and dividing by a negative one folds the point back onto the screen
* mirrored, which is how a mob behind you gets a pearl in front of you.
--]]
local function transform(x, y, z, w, m)
    return m._11 * x + m._21 * y + m._31 * z + m._41 * w,
           m._12 * x + m._22 * y + m._32 * z + m._42 * w,
           m._13 * x + m._23 * y + m._33 * z + m._43 * w,
           m._14 * x + m._24 * y + m._34 * z + m._44 * w;
end

local function worldToScreen(wx, wy, wz, view, projection, width, height)
    local vx, vy, vz, vw = transform(wx, wy, wz, 1, view);
    local cx, cy, _, cw  = transform(vx, vy, vz, vw, projection);

    if (cw <= 0.0001) then
        return nil;
    end

    local rhw = 1 / cw;

    return math.floor((cx * rhw + 1) * 0.5 * width),
           math.floor((1 - cy * rhw) * 0.5 * height);
end

--[[
* One bead, on any draw list -- the world's foreground list from d3d_present,
* and the window's own list for the legend, so the legend cannot drift from
* what the game actually draws.
--]]
local function drawPearl(dl, x, y, radius, entry, alpha)
    dl:AddCircleFilled({ x, y }, radius, withAlpha(entry.rgb, alpha), 16);
    dl:AddCircle({ x, y }, radius, withAlpha(entry.rimRgb, alpha * 0.85),
        16, math.max(1.0, radius * RIM_THICKNESS));

    -- The specular dot is what makes a flat disc read as a bead.
    dl:AddCircleFilled({ x - radius * SPECULAR_OFFSET, y - radius * SPECULAR_OFFSET },
        math.max(1.0, radius * SPECULAR_SIZE), withAlpha(WHITE_RGB, alpha * 0.80), 8);
end

--[[
* The label that rides beside a bead: the tier letters and/or the level, both
* optional. An ungaugeable mob's level is a question mark and never a number --
* the server withheld it, and inventing one here would be the addon claiming
* to know something /check refuses to say.
--]]
local function labelFor(con, entry)
    local pieces = {};

    if (config.tiers) then
        pieces[#pieces + 1] = entry.short;
    end

    if (config.levels) then
        pieces[#pieces + 1] = con.gauge and string.format('Lv.%d', con.level) or '?';
    end

    return table.concat(pieces, ' ');
end

--[[
* THE LABEL, MEASURED, CACHED ON THE RECORD IT DESCRIBES.
*
* A label is a function of exactly two things: the record (`Lv.34`, `DC`, `?`)
* and the two checkboxes that decide which halves of it are drawn. It changes
* when one of those changes and at no other time -- but it was being rebuilt
* from scratch every frame for every mob: a table, two string.formats and a
* table.concat, then an imgui.CalcTextSize to find out how wide the result
* was. Twenty mobs at sixty frames is twelve hundred of each, per second, for
* text that is identical to the frame before.
*
* Cached ON THE RECORD, which is the invalidation: applyPairs builds a NEW
* table for every pair it accepts, so a con that changed cannot carry a stale
* label. The only other input is `labelMode`, stamped alongside and compared.
*
* THE MEASUREMENT IS SEPARATELY GENERATIONAL. CalcTextSize answers in the
* CURRENT font, and the font is a function of the resolution -- so the world
* pass bumps `metricGen` when the viewport changes size and every cached width
* is re-measured on the next frame it is used, rather than the labels quietly
* sitting a few pixels off for as long as a stationary mob keeps its record.
--]]
local metricGen = 0;

local function measuredLabel(con, entry)
    if (con.labelMode ~= labelMode) then
        con.labelMode = labelMode;
        con.label     = labelFor(con, entry);
        con.metricGen = nil;
    end

    if (con.metricGen ~= metricGen) then
        con.metricGen = metricGen;

        if (con.label == '') then
            con.labelW, con.labelH = 0, 0;
        else
            local width, height = imgui.CalcTextSize(con.label);

            con.labelW = width or 0;
            con.labelH = height or 12;
        end
    end

    return con.label;
end

--[[
* Everything the world pass reads that is the same for every mob in the frame:
* the two matrices, the viewport, the target, and the settings that used to be
* looked up out of `config` once per mob per frame.
*
* ONE TABLE, REFILLED, never re-allocated -- a fresh table per frame in the
* suite's hottest path is exactly the garbage the rest of this file goes out of
* its way not to make.
--]]
local frame = { };

--[[
* Draw gating for one targid. Every arm of this is a reason a pearl would be a
* lie: an entity that is not rendered, one the client is hiding, one that is
* not a mob at all, a corpse, one below the tier floor, one off the edge of the
* screen, or something so far away the bead would be shimmer. The cached record
* is deliberately NOT deleted when a mob fails the gate -- the mob may simply
* have walked behind a wall, and the next server sweep is the thing that owns
* the table's contents.
*
* THE GATES ARE IN COST ORDER, cheapest first: two table lookups and a compare
* before any entity read, the entity's own flags before the distance, the
* squared distance before the square root, and the projection before the label
* is built or measured. Every one of them is paid for every cached mob, every
* frame.
--]]
local function drawOne(dl, entity, idx, con)
    local entry = con.gauge and TIERS[con.tier] or nil;
    local key   = con.tier;

    if (entry == nil) then
        key = 'u';

        if (con.gauge) then
            -- GAUGEABLE, but a tier this addon does not know -- a server
            -- that grew an eighth tier. The TIERS comment demands it be
            -- VISIBLE (the ungaugeable checkbox must not hide it: that
            -- setting is about mobs the server refuses to gauge, and this
            -- one it gauged fine), so it wears the unknown pearl and keeps
            -- its real level label.
            entry = UNKNOWN;
        else
            -- Ungaugeable -- the server withheld the gauge -- shown only if
            -- the player asked for those. It has no tier at all, so the floor
            -- below cannot judge it and this checkbox is its only switch.
            if (not frame.nm) then
                return;
            end

            entry = UNKNOWN;
        end
    elseif (con.tier < frame.minTier and idx ~= frame.targetIndex) then
        -- BELOW THE FLOOR. Your own target is exempt: you pointed at it on
        -- purpose, and a filter that blanks the one mob you asked about is a
        -- filter players turn off again.
        return;
    end

    local flags = entity:GetRenderFlags0(idx);

    if (bit.band(flags, 0x200) ~= 0x200 or bit.band(flags, 0x4000) ~= 0) then
        return;
    end

    if (bit.band(entity:GetSpawnFlags(idx), 0x10) == 0) then
        return;
    end

    if (entity:GetHPPercent(idx) <= 0) then
        return;
    end

    -- GetDistance answers the SQUARED distance (it is the client's own cached
    -- square, not a yalm count). The CAP is applied against the square, so a
    -- mob past it costs no sqrt at all; the fade below needs the real distance
    -- and pays for one only on the mobs that are actually drawn.
    local squared = entity:GetDistance(idx);

    if (squared == nil or not (squared >= 0) or squared > frame.maxSquared) then
        return;
    end

    -- World space is (X, Z, Y) in Ashita's names: X and Y are the ground
    -- plane, Z is height, and height runs NEGATIVE UPWARDS -- the server's own
    -- eyeline is `pos.y - ENTITY_HEIGHT` (base_entity.cpp), and the client
    -- carries that float unchanged. So the bead is raised by SUBTRACTING.
    local sx, sy = worldToScreen(
        entity:GetLocalPositionX(idx),
        entity:GetLocalPositionZ(idx) - frame.heightUp,
        entity:GetLocalPositionY(idx),
        frame.view, frame.projection, frame.width, frame.height);

    if (sx == nil) then
        return;
    end

    -- OFF THE EDGE OF THE SCREEN. A mob beside you clears the camera-plane
    -- test and still projects hundreds of pixels past the viewport, where the
    -- five draw calls below would be clipped away unseen. Phrased as "inside",
    -- so a NaN -- which fails every comparison -- is culled here too.
    if (not (sx >= -SCREEN_MARGIN and sx <= frame.width + SCREEN_MARGIN
             and sy >= -SCREEN_MARGIN and sy <= frame.height + SCREEN_MARGIN)) then
        return;
    end

    local radius = frame.pearlSize;

    if (idx == frame.targetIndex) then
        radius = radius * TARGET_SCALE;
    end

    -- Fade with distance so a camp full of far-off mobs is a hint rather than
    -- a wall of confetti.
    local alpha = 1.0;
    local ratio = math.sqrt(squared) / frame.maxDistance;

    if (ratio > FADE_START) then
        alpha = 1.0 - ((ratio - FADE_START) / (1.0 - FADE_START)) * (1.0 - MIN_ALPHA);
    end

    -- The bead sits to the LEFT of the nameplate anchor, which is where the
    -- client centres the name; the label sits further left again, so neither
    -- of them lands on top of the name itself.
    local px = sx - radius - PEARL_NUDGE;

    drawPearl(dl, px, sy, radius, entry, alpha);

    census[key] = (census[key] or 0) + 1;

    local label = measuredLabel(con, entry);

    if (label ~= '') then
        local tx = px - radius - 4 - con.labelW;
        local ty = sy - con.labelH * 0.5;

        -- Drawn twice: a black copy one pixel down-right, then the real one.
        -- Vana'diel is full of pale ground and this is one-line legibility.
        dl:AddText({ tx + 1, ty + 1 }, packColor(0, 0, 0, alphaByte(alpha * 0.75)), label);
        dl:AddText({ tx, ty }, packColor(255, 255, 255, alphaByte(alpha)), label);
    end
end

--[[
* The world pass. Everything is re-read per frame on purpose, the viewport
* included: targetlines caches the viewport at load time and is quietly wrong
* for the rest of the session after a resolution change, which is a bug worth
* not inheriting.
--]]
local function drawPearls()
    -- Zeroed before the early outs, not after them: the legend's census is
    -- read in the same frame, and "the pearls are off" has to read as zero
    -- beads rather than as whatever the last frame that drew any left behind.
    clearCensus();

    if (not config.pearls or next(state.cons) == nil) then
        return;
    end

    local dev = device();

    if (dev == nil) then
        return;
    end

    local okViewport, vp = dev:GetViewport();

    if (okViewport ~= 0 or vp == nil) then
        return;
    end

    local okView, view = dev:GetTransform(C.D3DTS_VIEW);
    local okProj, proj = dev:GetTransform(C.D3DTS_PROJECTION);

    if (okView ~= 0 or okProj ~= 0 or view == nil or proj == nil) then
        return;
    end

    local memory = AshitaCore:GetMemoryManager();
    local entity = memory ~= nil and memory:GetEntity() or nil;

    if (entity == nil) then
        return;
    end

    -- The current target, for the larger bead. A target that is not active is
    -- index 0, which no mob ever is.
    local targetIndex = 0;
    local target      = memory:GetTarget();

    if (target ~= nil and target:GetIsActive(0) ~= 0) then
        targetIndex = target:GetTargetIndex(0);
    end

    local dl = imgui.GetForegroundDrawList();

    if (dl == nil) then
        return;
    end

    local width  = vp.Width;
    local height = vp.Height;

    -- A RESOLUTION CHANGE IS THE ONE THING THAT MOVES A CACHED TEXT WIDTH.
    -- CalcTextSize answers in the current font, the labels below are measured
    -- once and kept, and a record for a mob that never moves can outlive
    -- several minutes -- so the measurements are generational, and this is the
    -- generation. (The viewport itself is re-read per frame on purpose:
    -- targetlines caches it at load and is quietly wrong ever after.)
    if (width ~= frame.width or height ~= frame.height) then
        metricGen = metricGen + 1;
    end

    frame.view        = view;
    frame.projection  = proj;
    frame.width       = width;
    frame.height      = height;
    frame.targetIndex = targetIndex;
    frame.nm          = config.nm;
    frame.minTier     = config.minTier;
    frame.pearlSize   = config.pearlSize;
    frame.heightUp    = config.heightUp;
    frame.maxDistance = config.maxDistance;
    frame.maxSquared  = config.maxDistance * config.maxDistance;

    for targid, con in pairs(state.cons) do
        drawOne(dl, entity, targid, con);
    end
end

--[[
* THE EFFECT STRIP.
*
* Every status effect on your current target, in one row, drawn as the client's
* own icon where the client has one and as the effect's own name where it does
* not.
*
* THE ICONS ARE THE CLIENT'S, NOT OURS. `GetStatusIconByIndex` reads the
* game's own DAT, so no art ships with this addon and the strip looks like the
* rest of the interface on whatever install it is running on. (The bundled
* enemy-bar addons ship PNG theme folders of their own; those are theirs, and
* copying them would be shipping somebody else's assets.) The one that dwsquad
* already loads its member buffs with, for the same reason and by the same
* route.
*
* A TEXTURE IS MADE ONCE AND KEPT. Creating one is a D3D call and a DAT read;
* doing it per frame per effect would be a stutter every time a mob picked one
* up. A FAILURE is remembered too, as `false`, so a bad id is asked about once
* rather than sixty times a second -- except a missing DEVICE, which is the one
* miss that fixes itself.
--]]
local fxTextures = { };
local fxHandles  = { };
local fxNames    = { };

local function statusIconHandle(iconId)
    if (iconId == nil or iconId <= 0 or iconId == ICON_FILLER or iconId > ICON_MAX) then
        return nil;
    end

    if (fxTextures[iconId] ~= nil) then
        return fxTextures[iconId] ~= false and fxHandles[iconId] or nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ok, icon = pcall(function ()
        return AshitaCore:GetResourceManager():GetStatusIconByIndex(iconId);
    end);

    if (not ok or icon == nil or icon.Bitmap == nil or icon.ImageSize == 0) then
        fxTextures[iconId] = false;

        return nil;
    end

    local made, handle = pcall(function ()
        local ptr = ffi.new('IDirect3DTexture8*[1]');

        if (C.D3DXCreateTextureFromFileInMemoryEx(dev, icon.Bitmap, icon.ImageSize,
                0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
                C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
            return nil;
        end

        fxTextures[iconId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

        return tonumber(ffi.cast('uint32_t', fxTextures[iconId]));
    end);

    -- Guarded rather than trusted (dwraid's note, dwsquad's copy): a handle
    -- that came back as anything but a number reaches imgui.Image as a nil and
    -- takes the render pcall down sixty times a second, and falling back to the
    -- effect's NAME costs nothing but a picture.
    if (not made or type(handle) ~= 'number') then
        fxTextures[iconId] = false;
        fxHandles[iconId]  = nil;

        return nil;
    end

    fxHandles[iconId] = handle;

    return handle;
end

-- Every texture this addon made, released. The tables are dropped rather than
-- each entry released by hand: `gc_safe_release` owns the release and it fires
-- when Lua collects the object, so dropping the last reference IS the free.
local function releaseIcons()
    fxTextures = { };
    fxHandles  = { };

    collectgarbage('collect');
end

--[[
* The effect's name, from the client's own strings, cached per id.
*
* This is what the strip draws when the client has no icon for an id -- and
* what a player with the icons turned off reads instead. An id the client has
* never heard of falls back to the number, which is a diagnostic rather than a
* label: it means the server knows about an effect this client does not.
--]]
local function statusName(iconId)
    if (fxNames[iconId] == nil) then
        local ok, name = pcall(function ()
            return AshitaCore:GetResourceManager():GetString('buffs.names', iconId);
        end);

        fxNames[iconId] = (ok and type(name) == 'string' and name ~= '')
            and printable(name, 24) or string.format('#%d', iconId);
    end

    return fxNames[iconId];
end

--[[
* THE RETAIL TIMER SPELLING, which is the client's own on its party list: `2h`
* over an hour, `8m` over a minute, bare seconds under one. An effect with no
* timer draws NOTHING rather than a dash or an infinity sign -- the absence of
* a number under an icon already means "this one is not counting down", and a
* mark invented for it would be one more thing to learn.
--]]
local function fxClock(effect)
    if (effect.ends == nil) then
        return '';
    end

    local remaining = effect.ends - os.time();

    if (remaining <= 0) then
        return '';
    end

    if (remaining >= 3600) then
        return string.format('%dh', math.floor(remaining / 3600));
    end

    if (remaining >= 60) then
        return string.format('%dm', math.floor(remaining / 60));
    end

    return string.format('%ds', math.floor(remaining));
end

-- The icon's edge in pixels at scale 1.0. The client's own status icons are
-- 24x24 in the DAT, so this is one-to-one before the slider touches it.
local FX_ICON_BASE = 24;

--[[
* WHY THE STRIP IS YOUR TARGET AND NOTHING ELSE.
*
* The server does not know what you have targeted -- the client owns heading
* and target, which is a rule of this repo -- so it sends the effects of every
* visible mob that has any, and the CHOICE of which to draw is made here, where
* the target actually lives. That also keeps the strip readable: eight icons
* for one mob is a glance, and eight icons for each of six mobs is a wall.
*
* A mob with nothing on it draws no strip at all rather than an empty frame:
* "clean" and "not being told" look the same in an empty box, and the window's
* status line is where the difference belongs.
--]]
-- The row itself, split out so `End` can always run (see drawEffectStrip).
local function stripBody(list)
    local size = FX_ICON_BASE * config.fxScale;

    for index, effect in ipairs(list) do
        if (index > 1) then
            imgui.SameLine();
        end

        local handle = config.fxIcons and statusIconHandle(effect.icon) or nil;

        if (handle ~= nil) then
            imgui.Image(handle, { size, size });

            -- The name is a HOVER on the icon rather than a label beside it:
            -- eight labelled icons is a paragraph across the middle of the
            -- screen, and the icon is the thing a player learns to read.
            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(statusName(effect.icon));
            end
        else
            -- No icon -- the client has never heard of the id, the DAT read
            -- failed, or the player turned icons off. The NAME is the fallback
            -- and it is a real one: the strip still says what is on the mob.
            imgui.TextColored(theme.colors.warn, statusName(effect.icon));
        end

        local clock = config.fxSecs and fxClock(effect) or '';

        if (clock ~= '') then
            imgui.SameLine();
            imgui.TextColored(theme.colors.dim, clock);
        end
    end
end

local function drawEffectStrip()
    if (not config.fx or not config.pearls) then
        return;
    end

    local memory = AshitaCore:GetMemoryManager();
    local target = memory ~= nil and memory:GetTarget() or nil;

    if (target == nil or target:GetIsActive(0) == 0) then
        return;
    end

    local list = state.fx[target:GetTargetIndex(0)];

    if (list == nil or #list == 0) then
        return;
    end

    local dev = device();

    if (dev == nil) then
        return;
    end

    local okViewport, vp = dev:GetViewport();

    if (okViewport ~= 0 or vp == nil) then
        return;
    end

    -- The anchor is a FRACTION of the viewport and the pivot centres the strip
    -- on it, so the row grows in both directions from where the player put it
    -- rather than spilling to the right as it gets longer.
    imgui.SetNextWindowPos({ vp.Width * config.fxX, vp.Height * config.fxY },
        ImGuiCond_Always, { 0.5, 0.0 });

    -- NoInputs as well as NoMove: this sits over the middle of the screen and a
    -- window that ate a click there would be a window that ate a target.
    local visible = imgui.Begin('##dwcon_fx', nil, bit.bor(
        ImGuiWindowFlags_NoTitleBar, ImGuiWindowFlags_NoResize,
        ImGuiWindowFlags_NoMove, ImGuiWindowFlags_NoScrollbar,
        ImGuiWindowFlags_NoCollapse, ImGuiWindowFlags_NoSavedSettings,
        ImGuiWindowFlags_NoBackground, ImGuiWindowFlags_NoFocusOnAppearing,
        ImGuiWindowFlags_NoNav, ImGuiWindowFlags_NoInputs,
        ImGuiWindowFlags_AlwaysAutoResize, ImGuiWindowFlags_NoDocking));

    -- THE BODY IS ITS OWN PCALL SO `End` ALWAYS RUNS. A throw between Begin and
    -- End leaves ImGui's window stack one deep for every addon drawing after
    -- this one, and a release build asserts none of it. (The config window
    -- below has the identical shape for the identical reason.)
    if (visible) then
        local okBody, bodyErr = pcall(stripBody, list);

        if (not okBody and not state.reported) then
            state.reported = true;

            print(chat.header('dwcon'):append(chat.error('effect strip error: ' .. tostring(bodyErr))));
            print(chat.header('dwcon'):append(chat.message('Said once; the pearls are unaffected. The strip has its own checkbox in /dwcon.')));
        end
    end

    imgui.End();
end

--[[
* The config window.
--]]
--[[
* THE TOOLTIPS, AS DATA.
*
* Kept in one table rather than inline so the harness can assert that every
* control that owes an explanation has one, and read it: a tooltip that has
* drifted from what its control does is worse than none, and the only way to
* notice is to be able to look them all up in one place.
--]]
local TIPS = {
    pearls  = 'The master switch. /dwcon on and /dwcon off do the same thing -- and turning it off also tells the server to stop working your con out every two seconds, so nothing is being computed for a bead nobody is drawing.',
    levels  = 'Write the mob\'s level beside its bead, as "Lv.34". A mob the server will not gauge shows "?" instead -- it withheld the number, so this addon must not appear to know it.',
    tiers   = 'Write the tier\'s two letters beside its bead -- TW, EP, DC, EM, T, VT, IT -- for when the color alone is not enough. The letters are the ones the legend below uses.',
    nm      = 'Notorious monsters, Battlefield mobs and anything else /check refuses to gauge. They wear the silver bead and never a level. Turn this off to leave them unmarked.',
    size    = 'The radius of the bead in pixels. Your current target\'s bead is drawn 40% larger than this whatever you set.',
    height  = 'How far above the mob\'s feet the bead floats, in world units. Raise it if beads sit inside tall models, lower it if they float off the top of short ones.',
    maxDist = 'Nothing further away than this is drawn at all, and everything past a bit over half of it fades out with distance -- so a far-off camp is a hint rather than a wall of confetti.',
    floor   = 'Hide the beads for anything softer than this. Your own target always keeps its bead whatever the floor is set to: you pointed at it on purpose. Mobs the server will not gauge have no tier at all and are governed by the checkbox above, not by this.',
    fx      = 'Draw everything your current target is wearing -- poisons, paralysis, slows, sleeps, and the buffs it gave itself -- in one row. The list comes from the server, which reads the mob\'s real effects, so it does not miss the ones a client can only guess at (a weapon\'s additional effect, for one). Turning the con pearls off stops this as well: both ride the same connection.',
    fxIcons = 'Draw the client\'s own status icon for each effect, with the name on hover. Turn it off to read the names instead -- which is also what happens for an effect this client has no icon for.',
    fxSecs  = 'Write how long each effect has left. The server states the time once and this counts it down, so an effect that is re-applied or dispelled corrects itself within a couple of seconds. An effect with no timer shows no number at all.',
    fxScale = 'How large the effect icons are. The client\'s own icons are 24 pixels, so 1.00 is one-to-one.',
    fxX     = 'Where the strip sits across the screen, as a fraction of its width -- 0.50 is centred. The strip grows both ways from here, so a long list stays put instead of spilling to one side.',
    fxY     = 'How far down the screen the strip sits, as a fraction of its height. Fractions rather than pixels, so changing resolution leaves it where you put it.',
    census  = 'How many beads of that color are on your screen right now -- counted by the draw pass itself as it draws them, so it cannot disagree with what you are looking at. Mobs behind a wall, past the draw distance or under the tier floor are not counted, because they are not drawn.',
    refresh = 'Ask the server for a whole fresh snapshot now. Changes normally arrive on their own within two seconds; this is for when a bead looks wrong and you would rather not wait or zone.',
    reset   = 'Put every setting on this window back to what it shipped as -- pearls on, levels on, tier letters off, no tier floor. If that turns the pearls back on, the server is asked for a fresh snapshot at the same time.',
    snapshot = 'When the last FULL snapshot closed. Changes since then have been arriving as they happen -- the server sends nothing at all when nothing has moved, so a number here is not a sign of staleness.',
};

-- The legend bead's radius, and the width the row reserves for it.
local LEGEND_RADIUS = 6;
local LEGEND_BEAD   = (LEGEND_RADIUS + 2) * 2;

--[[
* Where the census column starts, measured from the widest legend sentence in
* the CURRENT font rather than guessed at -- "Impossible to gauge" is half
* again the length of "Tough", and a hard-coded column that fits one clips the
* other the day the font changes. Re-measured only when the font can have
* moved, which is what `metricGen` tracks.
--]]
local legendOffset    = 0;
local legendOffsetGen = -1;

local function censusColumn()
    if (legendOffsetGen == metricGen) then
        return legendOffset;
    end

    legendOffsetGen = metricGen;

    local widest = 0;

    local function widen(entry)
        local width = imgui.CalcTextSize(entry.legend);

        if ((width or 0) > widest) then
            widest = width;
        end
    end

    for _, tier in ipairs(TIER_ORDER) do
        widen(TIERS[tier]);
    end

    widen(UNKNOWN);

    legendOffset = LEGEND_BEAD + 12 + widest + 16;

    return legendOffset;
end

local function legendRow(dl, entry, key, column)
    local cx, cy = imgui.GetCursorScreenPos();

    -- The legend draws the REAL pearl through the same function the world pass
    -- uses, so a change to the bead cannot leave the legend describing the
    -- old one.
    drawPearl(dl, cx + LEGEND_RADIUS + 2, cy + 8, LEGEND_RADIUS, entry, 1.0);

    imgui.Dummy({ LEGEND_BEAD, 16 });
    imgui.SameLine();
    imgui.Text(entry.legend);

    imgui.SameLine(column);

    local seen = census[key] or 0;

    if (seen > 0) then
        imgui.TextColored(theme.colors.ok, tostring(seen));
    else
        imgui.TextDisabled('0');
    end
end

--[[
* The status line's sentence, rebuilt only when one of the two numbers in it
* moves. It was a string.format every frame the window was open, for a
* sentence that is the same one most of them.
--]]
local statusText  = nil;
local statusKnown = -1;
local statusSeen  = -1;

local function statusLine(known, seen)
    if (known ~= statusKnown or seen ~= statusSeen) then
        statusKnown = known;
        statusSeen  = seen;
        statusText  = string.format('%d enemies gauged, %d on screen.', known, seen);
    end

    return statusText;
end

-- Same shape, for the footer's clock: one format per SECOND rather than one
-- per frame for a sentence that only changes when the second does.
local snapshotText = nil;
local snapshotSecs = -1;

local function snapshotAge(seconds)
    if (seconds ~= snapshotSecs) then
        snapshotSecs = seconds;
        snapshotText = string.format('-- snapshot %ds ago', seconds);
    end

    return snapshotText;
end

local function tierFloorPreview()
    if (config.minTier == 0) then
        return 'Everything';
    end

    local entry = TIERS[config.minTier];

    return (entry ~= nil and entry.name or '?') .. ' and up';
end

local function renderWindow()
    -- THE STATUS SENTENCES ARE SENTENCES, and TextColored does not wrap. Every
    -- arm below is between eighty and a hundred and ten characters -- wider
    -- than the window's own default -- and the window carries NoScrollbar, so
    -- an unwrapped one is simply cut off at the frame with no way to read the
    -- rest. Wrapped at the content edge (`0`), and popped on the one path out
    -- of this block, which has no early return in it.
    imgui.PushTextWrapPos(0);

    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'This server speaks a con protocol this addon does not. Update dwcon through the launcher.');
    elseif (not config.pearls) then
        -- OFF IS A STATE, NOT A FAULT. Without this the window said it was
        -- waiting for a snapshot it had deliberately stopped asking for.
        imgui.TextColored(theme.colors.dim, 'Pearls are off. The server has been told to stop as well; turning them back on asks for a fresh snapshot.');
    elseif (not state.synced and state.notice ~= nil) then
        -- The server said something instead of a snapshot -- typically "Con
        -- pearls are not in this build." Show that, not a wait that will
        -- never end.
        imgui.TextColored(state.noticeBad and theme.colors.err or theme.colors.warn, state.notice);
    elseif (not state.synced and state.gaveUp) then
        -- THE WAIT THAT WILL NOT END, NAMED. The zone-in retries are bounded,
        -- so once they are spent "waiting" is no longer true of anything.
        imgui.TextColored(theme.colors.warn, 'The server has not answered this zone. Refresh below to ask again.');
    elseif (not state.synced) then
        imgui.TextColored(theme.colors.warn, 'Waiting for the server\'s first snapshot...');
    else
        local known = 0;
        local seen  = 0;

        for _ in pairs(state.cons) do
            known = known + 1;
        end

        for _, drawn in pairs(census) do
            seen = seen + drawn;
        end

        imgui.TextColored(theme.colors.ok, statusLine(known, seen));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('"Gauged" is every enemy the server has told you about in this zone. "On screen" is how many of those are actually wearing a bead right now.');
        end
    end

    imgui.PopTextWrapPos();

    imgui.Separator();

    local style   = imgui.GetStyle();
    local spacing = (style ~= nil and style.ItemSpacing ~= nil) and style.ItemSpacing.y or 4;

    -- EVERYTHING DOWN TO THE FOOTER SCROLLS INSIDE THIS. The window carries
    -- NoScrollbar (the suite's shape), so without a child of its own anything
    -- taller than the window was simply unreachable -- and the legend alone is
    -- eight rows. The footer's one row is reserved out of the height so the
    -- buttons stay on screen at any size the player drags the window to.
    imgui.BeginChild('##dwcon_body',
        { 0, -(imgui.GetFrameHeightWithSpacing() + spacing) }, ImGuiChildFlags_None);

    local changed = false;

    if (imgui.Checkbox('Draw con pearls', ui.pearls)) then
        setPearls(ui.pearls[1]);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pearls);
    end

    changed = imgui.Checkbox('Show levels', ui.levels) or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.levels);
    end

    changed = imgui.Checkbox('Show tier letters', ui.tiers) or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.tiers);
    end

    changed = imgui.Checkbox('Show a pearl for mobs the server will not gauge', ui.nm) or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.nm);
    end

    imgui.Separator();

    imgui.PushItemWidth(220);
    changed = imgui.SliderFloat('Pearl size', ui.pearlSize, 3.0, 16.0, '%.1f px') or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.size);
    end

    changed = imgui.SliderFloat('Height above the mob', ui.heightUp, 0.0, 6.0, '%.1f') or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.height);
    end

    changed = imgui.SliderFloat('Max draw distance', ui.maxDistance, 5.0, 50.0, '%.0f yalms') or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.maxDist);
    end

    imgui.PopItemWidth();

    -- SetNextItemWidth, NOT the pushed width, and the pop is above rather than
    -- below: ImGui's item-width stack is PER WINDOW, and an open BeginCombo
    -- makes the popup the current window -- so a PopItemWidth between Begin
    -- and End pops the popup's empty stack instead of this one's and leaves
    -- both unbalanced for the frame.
    imgui.SetNextItemWidth(220);

    -- The combo's own hover is asked BEFORE the popup is drawn: once EndCombo
    -- has run, "the last item" is whatever Selectable the popup submitted last
    -- and the tooltip would follow the list instead of the control.
    local floorOpen = imgui.BeginCombo('Softest pearl to draw', tierFloorPreview());

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.floor);
    end

    if (floorOpen) then
        for _, tier in ipairs(TIER_ORDER) do
            local entry = TIERS[tier];
            local label = (tier == 0) and 'Everything' or (entry.name .. ' and up');

            -- Written into config and committed through the same path every
            -- other control uses. The floor has no `ui` holder of its own --
            -- a combo hands back a choice rather than writing into a table --
            -- but going through commit keeps the sanitise-and-save step in
            -- exactly one place.
            if (imgui.Selectable(label, config.minTier == tier)) then
                config.minTier = tier;

                commit();
            end
        end

        imgui.EndCombo();
    end

    imgui.Separator();

    -- THE EFFECT STRIP'S OWN SECTION (1.2.0). Its switch is a DRAW switch: the
    -- feed is the master switch at the top of this window, because the strip
    -- and the pearls arrive down one handshake.
    imgui.Text('Your target\'s status effects');

    changed = imgui.Checkbox('Draw the effect strip', ui.fx) or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.fx);
    end

    changed = imgui.Checkbox('Use the client\'s status icons', ui.fxIcons) or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.fxIcons);
    end

    changed = imgui.Checkbox('Show remaining time', ui.fxSecs) or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.fxSecs);
    end

    imgui.PushItemWidth(220);

    changed = imgui.SliderFloat('Effect icon size', ui.fxScale, 0.5, 3.0, '%.2fx') or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.fxScale);
    end

    changed = imgui.SliderFloat('Strip position across', ui.fxX, 0.0, 1.0, '%.2f') or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.fxX);
    end

    changed = imgui.SliderFloat('Strip position down', ui.fxY, 0.0, 0.9, '%.2f') or changed;

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.fxY);
    end

    imgui.PopItemWidth();

    if (changed) then
        commit(true);
    end

    -- THE FILE WAITS FOR THE HANDLE. IsAnyItemActive is true for as long as a
    -- slider is being dragged and false the frame it is let go; a checkbox
    -- answers "changed" on the release itself, so its write is not delayed.
    -- Gated on "nothing is held" rather than on a deactivation event so that
    -- a build where the call answered nothing would save on the next frame --
    -- a preference saved too eagerly, never one not saved at all.
    if (saveWhenReleased and not imgui.IsAnyItemActive()) then
        saveWhenReleased = false;

        pcall(settings.save);
    end

    imgui.Separator();

    local column = censusColumn();

    imgui.Text('What the colors mean');
    imgui.SameLine(column);
    imgui.TextDisabled('seen');

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.census);
    end

    local dl = imgui.GetWindowDrawList();

    for _, tier in ipairs(TIER_ORDER) do
        legendRow(dl, TIERS[tier], tier, column);
    end

    legendRow(dl, UNKNOWN, 'u', column);

    -- Wrapped, like the status lines above it: the sentence is wider than the
    -- window's own minimum and this child has no horizontal scroll either.
    imgui.PushTextWrapPos(0);
    imgui.TextDisabled('Incredibly Easy Prey does not exist on this server\'s curve.');
    imgui.PopTextWrapPos();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('The DriftwoodXI difficulty curve sentinels tier 1 out of reach, so no mob in the game can ever con as it. A row for it would be a legend nobody could ever see.');
    end

    imgui.EndChild();

    -- The footer. One row, always on screen, whatever the window is sized to.
    local canAsk = config.pearls and not state.refused;

    if (not canAsk) then imgui.BeginDisabled(); end

    if (imgui.Button('Refresh now')) then
        hello();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.refresh);
    end

    if (not canAsk) then imgui.EndDisabled(); end

    imgui.SameLine();

    if (imgui.Button('Reset settings')) then
        -- The master switch is one of the settings this puts back, and the
        -- switch is a WIRE fact as well as a local one: reset used to turn the
        -- pearls on again without telling the server, so the addon drew from a
        -- table nothing was refilling until the next zone line.
        local was = config.pearls;

        for key, value in pairs(SHIPPED) do
            config[key] = value;
        end

        sanitize();
        refreshUi();
        pcall(settings.save);

        syncPearlSwitch(was);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.reset);
    end

    imgui.SameLine();

    -- WHY THE GREYED BUTTON IS GREY, WRITTEN DOWN. A disabled ImGui item does
    -- not answer IsItemHovered at all, so its own tooltip can never be read --
    -- the reason has to be beside it or it does not exist.
    --
    -- SHORT ON PURPOSE: this shares a row with two buttons and the row does
    -- not wrap, so the full explanation lives in the status line at the top of
    -- the window and this is the pointer to it.
    if (state.refused) then
        imgui.TextDisabled('-- protocol refused');
    elseif (not config.pearls) then
        imgui.TextDisabled('-- pearls are off');
    elseif (state.syncedAt ~= nil) then
        imgui.TextDisabled(snapshotAge(math.floor(os.time() - state.syncedAt)));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.snapshot);
        end
    else
        imgui.TextDisabled('-- no snapshot yet');
    end
end

--[[
* The frame. The queue is pumped first so a handshake goes out whether or not
* anything is being drawn, then the world pass, then the window -- three
* separate pcalls, because a bad frame in one of them must not silence the
* other two. Begin/End and the theme push/pop sit OUTSIDE the window's pcall so
* both stacks stay balanced whatever the render pass does.
--]]
ashita.events.register('d3d_present', 'dwcon_present', function ()
    -- Release the zone-in hello only once the client has finished zoning AND
    -- this addon's stagger slot has come up. A line sent while GetIsZoning() is
    -- set, or in the same beat as a sibling's zone-in sync, is dropped by the
    -- client with "A command error occurred." before the server sees it -- and
    -- dwcon's whole session hangs off this one hello (no reply, no pearls), so
    -- it is re-tried until the server's sync lands rather than fired once.
    if (state.syncAt ~= nil and os.clock() >= state.syncAt) then
        if (state.synced or state.refused or not config.pearls
            or (state.answered and state.syncTries > 0)) then
            -- THE SERVER ANSWERED, WHATEVER IT SAID -- a full sync landed, the
            -- protocol version was refused, or it said something (`e|Con pearls
            -- are not in this build.`) instead. All three are answers, and a
            -- retry only ever earns the same one again: on a build without
            -- con_data.cpp the six-hello budget bought six identical red lines
            -- per zone from a server that had already replied. And a player who
            -- turned the pearls off between the arming and the firing is owed
            -- no handshake at all.
            --
            -- `syncTries > 0` on the ANSWERED arm alone: an answer only cancels
            -- an ask that was actually made. Chat packets arrive in order, so a
            -- reply to something said before the zone line should land ahead of
            -- the 0x000A that clears this flag -- but "should" is doing work
            -- there, and the cost of being wrong is a zone with no pearls at
            -- all and no hello ever sent to explain it.
            state.syncAt   = nil;
            state.syncSlot = nil;
        else
            -- The memory manager is asked for rather than assumed: this block
            -- is the one part of the frame OUTSIDE a pcall, so a nil here
            -- would be a traceback per frame instead of a missing pearl.
            local memory = AshitaCore:GetMemoryManager();
            local player = memory ~= nil and memory:GetPlayer() or nil;

            if (player ~= nil and player:GetIsZoning() ~= 0) then
                state.syncAt   = os.clock() + 1.0;
                state.syncSlot = nil;
            elseif (state.syncSlot == nil) then
                state.syncSlot = os.clock() + echo.zoneSlot('dwcon') * echo.SEND_INTERVAL;
                state.syncAt   = state.syncSlot;
            else
                -- Fire, and re-arm a retry unless the budget is spent. syncSlot
                -- is left set so a retry comes straight back here instead of
                -- re-taking the stagger slot (which only ever mattered for the
                -- login burst, and only dwcon retries). A new zone line resets
                -- both the slot and the retry budget.
                state.syncTries = state.syncTries + 1;

                hello();

                -- One hello per zone on a server that has proven silent (see
                -- the state block); the full budget everywhere else.
                local budget = (state.spentBudget and not state.everSynced) and 1 or ZONE_HELLO_MAX_TRIES;

                if (state.syncTries < budget) then
                    state.syncAt = os.clock() + ZONE_HELLO_RETRY;
                else
                    state.syncAt = nil;

                    -- The window's "waiting for the first snapshot..." is only
                    -- true while something is still going to arrive. Once the
                    -- budget is spent it is a wait with nothing at the end of
                    -- it, and the window says so instead.
                    state.gaveUp = true;

                    if (not state.everSynced) then
                        state.spentBudget = true;
                    end
                end
            end
        end
    end

    pumpQueue();

    local okWorld, worldErr = pcall(drawPearls);

    if (not okWorld and not state.reported) then
        state.reported = true;

        print(chat.header('dwcon'):append(chat.error('draw error: ' .. tostring(worldErr))));
        -- WHAT ACTUALLY HAPPENS, which is not what this line used to claim.
        -- It said "Pearls are off for this frame onward", and nothing turns
        -- them off: the pass is pcall'd afresh every frame and a transient
        -- fault (a device reset, one bad record) heals by itself. Only the
        -- REPORT is latched, so the player is told once instead of sixty
        -- times a second. A sentence describing a latch this addon does not
        -- have is the quiet kind of wrong the suite exists to rule out.
        print(chat.header('dwcon'):append(chat.message('That frame drew no pearls; it keeps trying, and this is said once. /check still works, typed.')));
    end

    -- ITS OWN PCALL, and its own latch shares `reported` with the world pass:
    -- a strip that throws (a texture the device refused, an id the resource
    -- manager does not like) must not take the pearls down with it, and a
    -- strip drawn sixty times a second must not say so sixty times.
    local okStrip, stripErr = pcall(drawEffectStrip);

    if (not okStrip and not state.reported) then
        state.reported = true;

        print(chat.header('dwcon'):append(chat.error('effect strip error: ' .. tostring(stripErr))));
        print(chat.header('dwcon'):append(chat.message('Said once; the pearls are unaffected. /dwcon turns the strip off.')));
    end

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 440, 520 }, ImGuiCond_FirstUseEver);

    -- A FLOOR UNDER THE SIZE. The window carries NoScrollbar, and none of its
    -- rows wrap: a slider is a fixed 220px control plus its label, the widest
    -- checkbox label is forty-six characters, and the footer is two buttons
    -- and a note on one line. Dragged narrower than the widest of those and
    -- the row simply runs off the frame with no scrollbar to reach it. 400 is
    -- the widest row (the combo: 220 + spacing + "Softest pearl to draw")
    -- plus the window's own padding; the body scrolls inside its own child, so
    -- the height floor only has to hold the status line, a few rows and the
    -- footer.
    imgui.SetNextWindowSizeConstraints({ 400, 260 }, { 99999, 99999 });

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads.
    local visible = imgui.Begin('DriftwoodXI Con##dwcon', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local okRender, renderErr = pcall(renderWindow);

        if (not okRender) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwcon'):append(chat.error('render error: ' .. tostring(renderErr))));
                print(chat.header('dwcon'):append(chat.message('Window closed. The pearls themselves are unaffected.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* `/dwcon` (and `/con`) opens the window. `on` and `off` are the quick toggle
* for the pearls without opening anything -- and both move the SERVER's switch
* as well as this one. `refresh` (or `sync`) asks for a fresh snapshot, `help`
* (or `?`) lists all of them. Anything else is a typo and is said so.
--]]
ashita.events.register('command', 'dwcon_command', function (e)
    local args = e.command:args();

    if (#args == 0) then
        return;
    end

    local first = args[1]:lower();

    if (first ~= '/dwcon' and first ~= '/con') then
        return;
    end

    e.blocked = true;

    local verb = (args[2] or ''):lower();

    if (verb == 'on' or verb == 'off') then
        local did = setPearls(verb == 'on');

        -- SAY WHAT ACTUALLY HAPPENED. `/dwcon on` while the pearls were
        -- already on, or while the protocol has been refused, moves nothing
        -- and used to promise a snapshot that was never asked for.
        if (state.refused) then
            -- THE WIRE COULD NOT FOLLOW. The switch moved here and nothing was
            -- asked of the server; "already on", the sentence this used to fall
            -- through to, was true of neither side.
            print(chat.header('dwcon'):append(chat.error(string.format(
                'Con pearls %s here, but this server speaks a con protocol this addon does not, so nothing was asked of it. Update dwcon through the launcher.', verb))));
        elseif (did == 'hello') then
            print(chat.header('dwcon'):append(chat.message('Con pearls on. The server has been asked for a fresh snapshot.')));
        elseif (did == 'bye') then
            print(chat.header('dwcon'):append(chat.message('Con pearls off, on the server as well as here. /dwcon on brings them back.')));
        elseif (config.pearls) then
            print(chat.header('dwcon'):append(chat.message('Con pearls are already on.')));
        else
            print(chat.header('dwcon'):append(chat.message('Con pearls are already off. /dwcon on brings them back.')));
        end

        return;
    end

    -- The one verb that answers rather than does.
    if (verb == 'help' or verb == '?') then
        print(chat.header('dwcon'):append(chat.message('/dwcon (or /con) opens the settings window, with the legend and a live count of what is on your screen.')));
        print(chat.header('dwcon'):append(chat.message('/dwcon on and /dwcon off turn the pearls on and off -- off also tells the server to stop working them out.')));
        print(chat.header('dwcon'):append(chat.message('/dwcon refresh asks for a fresh snapshot now, for when a bead looks wrong.')));
        print(chat.header('dwcon'):append(chat.message('The window also carries the effect strip: everything your target is wearing, straight from the server.')));

        return;
    end

    -- The window's Refresh button, without the window. This is the gesture a
    -- player makes when one bead looks stale, and it is worth not making them
    -- open a window to reach it.
    if (verb == 'refresh' or verb == 'sync') then
        if (state.refused) then
            print(chat.header('dwcon'):append(chat.error('This server\'s con protocol is not one this addon reads. Update dwcon through the launcher.')));
        elseif (not config.pearls) then
            print(chat.header('dwcon'):append(chat.message('Con pearls are off. /dwcon on turns them back on and asks for a snapshot.')));
        else
            hello();

            print(chat.header('dwcon'):append(chat.message('Asked the server for a fresh con snapshot.')));
        end

        return;
    end

    -- A WORD THIS ADDON DOES NOT KNOW IS A TYPO, NOT A REQUEST TO OPEN A
    -- WINDOW. Every word used to fall through to the toggle, which was
    -- harmless while `on` and `off` were the only two -- but `/dwcon of` now
    -- silently does something other than what it was reaching for, and there
    -- are five verbs to mistype. A bare `/dwcon` still toggles.
    if (verb ~= '') then
        print(chat.header('dwcon'):append(chat.warning(string.format(
            'no idea what "%s" means. /dwcon help lists the verbs; plain /dwcon opens the window.', printable(verb, 24)))));

        return;
    end

    state.open[1]  = not state.open[1];
    state.reported = false;

    -- A lost hello has nothing else to retry it (the queue is send-and-
    -- forget, and the next attempt is a zone line away). Opening the
    -- settings window is the natural "why are there no pearls" gesture, so
    -- it earns one more try; issue() collapses duplicates, so this can
    -- never stack.
    if (state.open[1] and config.pearls and not state.synced and not state.refused) then
        hello();
    end
end);

ashita.events.register('load', 'dwcon_load', function ()
    -- Nothing is asked for while the pearls are off: the handshake is what
    -- starts the server's 2s walk of this character's visible set, and a
    -- player who turned the pearls off is not asking for that work to be done.
    if (config.pearls) then
        hello();
    end

    print(chat.header('dwcon'):append(chat.message('Con pearls: every nearby enemy wears its /check difficulty. /dwcon opens the settings.')));
end);

--[[
* GOODBYE ON THE WAY OUT.
*
* The packet_in handler that BLOCKS `_DWODATA` records dies with this addon,
* and the server's session flag does not -- it is a localvar that lives until
* the next zone line. So an unload used to leave the player reading raw records
* ("_DWODATA : c|1042:3:34") in their chat log every two seconds until they
* zoned, from an addon they had just turned off. One `!dwo bye` ends it.
*
* echo.send hands the line to the client's chat manager immediately rather than
* through the frame queue, which is the only shape that can work here: there is
* no next frame for this addon, so a queued line would never be pumped. Its
* cost is the one thing dwecho cannot swallow -- the client's local echo of the
* command renders after the text_in handler has gone with everything else -- so
* the player sees `!dwo bye` once. One line on the way out, against a record
* every two seconds for the rest of the zone.
*
* `config.pearls` is in the gate for that reason: with the pearls already off
* the server has already been told, and a second goodbye would buy the player
* a visible line of plumbing for nothing.
--]]
ashita.events.register('unload', 'dwcon_unload', function ()
    -- A write the window was still holding for a slider handle goes now: there
    -- is no later frame for it to wait for.
    if (saveWhenReleased) then
        pcall(settings.save);
    end

    if (config.pearls and state.everSynced and not state.refused) then
        echo.send('!dwo bye');
    end

    -- The strip's textures are D3D objects this addon made. Released here for
    -- the same reason the goodbye is sent here: there is no next frame.
    pcall(releaseIcons);
end);
