--[[
* DriftwoodXI dwengage -- the client half of the server's widened auto-target.
*
* WHY THIS EXISTS. When your target dies mid-pull, the map server already picks
* the next mob holding enmity on the party (attack_state.cpp, policy
* party-enmity-v2) and keeps your attack state engaged on it. What the server
* cannot do is TURN you: the client owns player heading, and the server refuses
* every swing until you face the target (CCharEntity::CanAttack). Without this
* addon the widened pick is invisible -- you stand there, weapon out, swinging
* at nothing, while the mob behind you works on the healer.
*
* HOW IT WORKS. The server marks its auto-target 0x058 assist packets by
* setting the trailing padding word to 1 -- a field the retail client never
* reads, so an unpatched client is simply unchanged. On a marked packet this
* addon resolves the mob, sets your client target to it, and writes your
* heading to face it. Unmarked 0x058s (a /assist reply, an ordinary target
* change) are deliberately ignored, so /assist behaves exactly as retail.
*
* The work happens a few frames AFTER the packet, not inside the handler: the
* same server tick that sends the marked assist can also send a follow-up
* assist that clears the dead target, and acting after the whole chunk has
* been processed means nothing later in the chunk undoes us. A second pass a
* third of a second later re-checks the target stuck and the heading held,
* then the addon goes back to sleep.
*
* No window, no server traffic of its own. /dwengage toggles it for the
* session; turning it off for good is the launcher's Addons tab, like any
* other addon. The in-client Auto Target config option disables the whole
* feature server-side (no marked packets are ever sent).
--]]

addon.name    = 'dwengage';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.0';
addon.desc    = 'Turns you onto the next enemy your party is fighting when your target dies.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat = require('chat');

-- Lua 5.4 renamed atan2 to the two-argument atan; Ashita's runtime still has
-- the old name. Either way this is atan2.
local atan2 = math.atan2 or math.atan;

-- The one marked assist we have not acted on yet. serverId is the mob the
-- server picked; at is os.clock() at packet time; passes counts how many
-- present-frames have acted on it (two, then it is dropped).
local pending = nil;

-- Session toggle. Deliberately not persisted: the launcher's Addons tab is
-- the durable on/off for every dw addon, and a second saved switch inside
-- the addon would be a state nobody can see from outside.
local enabled = true;

-- Server cone is 64/256 of a circle (+/- 45 degrees). Re-facing on the second
-- pass only happens outside this margin, so a player already steering their
-- camera is not fought over a few degrees.
local FACING_SLACK = 0.60;

-- First pass waits this long after the packet so the rest of the same packet
-- chunk (including the assist that clears the dead target) lands first.
local FIRST_PASS_DELAY  = 0.06;
local SECOND_PASS_DELAY = 0.40;
local GIVE_UP_AFTER     = 3.0;

--[[
* Little-endian readers in the dwcraft style: offsets are 0-based and include
* the 4-byte packet header, string.byte is 1-based, hence the +1.
--]]
local function u16(data, off)
    return (string.byte(data, off + 1) or 0) + (string.byte(data, off + 2) or 0) * 256;
end

local function u32(data, off)
    return u16(data, off) + u16(data, off + 2) * 65536;
end

--[[
* Your own entity index, the dwreport way. nil rather than 0 on any failure so
* callers can bail with one check.
--]]
local function selfIndex()
    local party = AshitaCore:GetMemoryManager():GetParty();
    if (party == nil) then
        return nil;
    end
    local index = party:GetMemberTargetIndex(0);
    return (index ~= nil and index > 0) and index or nil;
end

--[[
* Entity index for a server id, the dwparse way: dynamic ids (mobs, trusts,
* pets; id >= 0x1000000) carry their targid OFFSET BY 0x100
* (`0x01000000 | zone << 12 | (targid + 0x0100)`, zone_entities.cpp), so the
* low twelve bits must be un-offset the way the server does it
* (zoneutils.cpp GetEntity) rather than used as an index directly. They are
* never cached; anything else (a charmed player could in principle be the
* pick) is found by scan.
--]]
local function indexForServerId(sid)
    local entity = AshitaCore:GetMemoryManager():GetEntity();
    if (entity == nil) then
        return nil;
    end

    if (sid >= 0x1000000) then
        local idx = sid % 0x1000;

        -- Dynamic targids start at 0x700, so the stored value lands in
        -- [0x800, 0x9FF] and can never collide with a static one. The upper
        -- bound covers the zone's targid = 0x900 overflow escape.
        if (idx >= 0x800) then
            idx = idx - 0x100;
        end

        if (idx <= 0x8FF and entity:GetServerId(idx) == sid) then
            return idx;
        end
        return nil;
    end

    for idx = 0x400, 0x8FF do
        if (entity:GetServerId(idx) == sid) then
            return idx;
        end
    end
    return nil;
end

--[[
* The heading that faces fromIdx at toIdx. Ashita's entity API exposes the
* ground plane as X and Y (Z is height -- see mobdb's compass math), and the
* client yaw float runs CLOCKWISE while math.atan2 runs counter-clockwise, so
* the angle is negated (MobCompass converts the same float with -heading).
* The server agrees end to end: radianToRotation() maps this yaw straight to
* the rotation byte its facing() check compares.
--]]
local function yawToFace(entity, fromIdx, toIdx)
    local dX = entity:GetLocalPositionX(toIdx) - entity:GetLocalPositionX(fromIdx);
    local dY = entity:GetLocalPositionY(toIdx) - entity:GetLocalPositionY(fromIdx);
    if (dX == 0 and dY == 0) then
        return nil;
    end
    return -atan2(dY, dX);
end

-- Smallest signed difference between two yaw values, in (-pi, pi].
local function yawDifference(a, b)
    local diff = a - b;
    while (diff > math.pi) do
        diff = diff - 2 * math.pi;
    end
    while (diff <= -math.pi) do
        diff = diff + 2 * math.pi;
    end
    return diff;
end

--[[
* One pass over the pending pick: validate everything, then set the target if
* it is not already ours and write the heading if we are not already facing.
* Returns false when the pick is dead/gone/finished and pending should drop.
--]]
local function actOnPending()
    local memory = AshitaCore:GetMemoryManager();
    local entity = memory:GetEntity();
    local target = memory:GetTarget();
    if (entity == nil or target == nil) then
        return false;
    end

    local me = selfIndex();
    if (me == nil) then
        return false;
    end

    -- Status 1 is "engaged" and 0 is passive -- and passive is NOT a reason
    -- to drop the pick: when the old target died the client may have
    -- declared the fight over on its own and dropped to passive stance
    -- locally (the exact state the /attack below exists to recover from --
    -- gating on engaged-only dropped the pick here, before the recovery
    -- could ever run). Anything else -- dead, a cutscene -- means forcing a
    -- target would be rude.
    local status = entity:GetStatus(me);

    if (status ~= 1 and status ~= 0) then
        return false;
    end

    local idx = indexForServerId(pending.serverId);
    if (idx == nil or entity:GetHPPercent(idx) <= 0) then
        return false;
    end

    -- The player may have deliberately targeted something else between our
    -- passes. First pass takes the pick regardless (the packet just told us
    -- the old target is gone); the second pass only refreshes its own work.
    local current   = (target:GetIsActive(0) ~= 0) and target:GetTargetIndex(0) or 0;
    if (pending.passes > 0 and current ~= 0 and current ~= idx) then
        return false;
    end

    if (current ~= idx) then
        target:SetTarget(idx, true);
    end

    local yaw = yawToFace(entity, me, idx);
    if (yaw ~= nil) then
        local off = math.abs(yawDifference(yaw, entity:GetLocalPositionYaw(me)));
        if (pending.passes == 0 or off > FACING_SLACK) then
            -- Both yaw mirrors, or the client interpolates back to the old one.
            entity:SetLocalPositionYaw(me, yaw);
            entity:SetLastPositionYaw(me, yaw);
        end
    end

    -- Snap the client back into attack stance. When its old target died the
    -- client may have declared the fight over on its own (the server swallows
    -- that AttackOff -- see the 0x01A handler -- but the client has already
    -- dropped to passive stance locally). /attack on the pick re-enters
    -- attack mode; if the client never left it, this is "switch target" to
    -- the target it already has, a no-op on both sides.
    if (pending.passes == 0) then
        AshitaCore:GetChatManager():QueueCommand(1, '/attack <t>');
    end

    return true;
end

--[[
* GP_SERV_COMMAND_ASSIST, 0x058. Layout after the 4-byte header: UniqueNo u32
* at 0x04, AssistNo u32 at 0x08 (the entity to hand the player), ActIndex u16
* at 0x0C, and the padding word at 0x0E that the server sets to 1 for its
* auto-target picks. Anything unmarked is not ours to act on.
--]]
ashita.events.register('packet_in', 'dwengage_packet_in', function (e)
    if (e.id ~= 0x058) then
        return;
    end
    if (not enabled) then
        return;
    end
    if (u16(e.data, 0x0E) ~= 1) then
        return;
    end

    local sid = u32(e.data, 0x08);
    if (sid == 0) then
        return;
    end

    pending = { serverId = sid, at = os.clock(), passes = 0 };
end);

-- Zoning or logging in makes any pending pick meaningless.
ashita.events.register('packet_in', 'dwengage_zonein', function (e)
    if (e.id == 0x00A) then
        pending = nil;
    end
end);

ashita.events.register('d3d_present', 'dwengage_present', function ()
    -- `enabled` is re-checked here, not only at packet time: /dwengage off
    -- typed inside the 3-second window is the player saying stop NOW, and
    -- honouring the pick anyway spun them once more.
    if (pending == nil or not enabled) then
        pending = nil;
        return;
    end

    local age = os.clock() - pending.at;
    if (age > GIVE_UP_AFTER) then
        pending = nil;
        return;
    end
    if (pending.passes == 0 and age < FIRST_PASS_DELAY) then
        return;
    end
    if (pending.passes == 1 and age < SECOND_PASS_DELAY) then
        return;
    end
    if (pending.passes >= 2) then
        pending = nil;
        return;
    end

    -- A memory read must never take the frame down (house rule).
    local ok, keep = pcall(actOnPending);
    if (not ok or keep == false) then
        pending = nil;
        return;
    end

    pending.passes = pending.passes + 1;
end);

ashita.events.register('command', 'dwengage_command', function (e)
    local args = e.command:args();
    if (#args == 0 or args[1]:lower() ~= '/dwengage') then
        return;
    end
    e.blocked = true;

    enabled = not enabled;
    if (enabled) then
        print(chat.header(addon.name):append(chat.message('On: when your target dies, you are turned onto the next enemy your party is fighting.')));
    else
        print(chat.header(addon.name):append(chat.message('Off for this session. The launcher\'s Addons tab turns it off for good.')));
    end
end);

ashita.events.register('load', 'dwengage_load', function ()
    print(chat.header(addon.name):append(chat.message('Keeps you fighting when your target dies: the server picks the next enemy on the party, this turns you onto it. /dwengage toggles.')));
end);
