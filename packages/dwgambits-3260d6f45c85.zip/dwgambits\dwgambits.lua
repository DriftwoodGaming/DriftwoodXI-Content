--[[
* DriftwoodXI -- dwgambits
*
* The visual editor for the player gambit system: your squad's rule sets as a
* window instead of a grammar. Pick who a rule watches, when it fires and what
* it does from dropdowns, reorder by priority, keep your posture honest, and
* assign the result to any character on the account -- summoned or at home.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no vocabulary of its own and no way to write a rule the typed
* command surface would refuse. Every read is a `!dwg` line and every write is
* a `!dwg` line -- the same dispatch, parser, validator and C++ store that
* `!squad rules ...` reaches (documentation/dwg_protocol.md is the contract).
* The ownership check, the caps and the whitelist all live server-side and run
* identically whichever way the command arrived, which is what makes shipping
* a UI safe at all: a bug in here cannot save anything the server would have
* refused a typed player.
*
* EVERY DROPDOWN IS BUILT FROM THE WIRE. The vocabulary -- targets, conditions,
* action kinds, pickers, posture options, the caps -- arrives as `v|` records
* at startup and nothing vocabulary-shaped is hardcoded here (ground rule 4).
* The whitelist can grow server-side and this file does not change. What IS
* known locally is the client's own DAT resources (spell and ability names,
* exactly as dwbags uses item names) and the typed tier's *grammar* words --
* grammar is how a renderer speaks, not what it is allowed to say.
*
* HOW SAVING WORKS, AND WHY. The editor edits a local copy of one rule set and
* nothing touches the server until Save. Save diffs the local document against
* the server's copy and issues the smallest `del` / `add` / `move` / `posture`
* sequence that makes the two agree -- each step is a complete, valid command,
* so killing the client mid-save leaves a shorter document, never a corrupt
* one. Mutating commands are sent strictly one at a time, are NEVER retried
* automatically (a lost `add` re-sent is a duplicated rule), and any `e|` from
* the server aborts the rest of the plan on the spot.
*
* TURN IT OFF AND NOTHING IS LOST. `!squad rules` does everything this window
* does, typed, and `!squad menu` covers assignment as client dialogs. This is
* faster; it is not required.
*
* UPGRADE HINTS (1.1) render the `h|` records `!dwg hints` answers: a compact
* strip under each summoned member, and what-it-would-take detail on the hover
* of a greyed inert rule. Both are display only -- every sentence arrives
* finished from the server, and a server too old to know the verb is detected
* once and never asked again, so deployment order cannot matter.
*
* WEAPON-SKILL PICKS (1.2, 2026-08-06) render the posture's two appended
* fields: up to four ordered weapon-skill picks (first is the opener; names
* from the client DATs -- weapon skills are ability ids with NO offset) and
* the tphold amount the amount-reading TP triggers use. Both diff into the
* same `!dwg posture` grammar every other posture field uses, and both parse
* as APPENDED s|/v|h fields, so an older server simply never sends them and
* the block renders as it did in 1.1.
*
* THE TOGGLE ROUND (1.4, 2026-08-18, player requests). Two checkboxes, one
* latch. Each rule row grows an On switch (`!dwg toggle <set> <n> on|off` --
* the rule stays in the document at its ordinal, the member just ignores it)
* and the posture strip grows Allow AoE WS (`!dwg posture <set> aoews`,
* keeping area weapon skills out of the member's TP spending). Both diff
* through the save plan like everything else -- toggles by FINAL ordinal,
* after the moves. The latch is the s| record's appended `aoews` field: a
* server that sends it speaks the whole round, a server that does not gets
* neither checkbox nor either command, so deployment order cannot matter.
*
* SONG BURST (1.5, 2026-08-23, player request). The posture strip grows Allow
* Song Burst (`!dwg posture <set> songburst on|off`): off keeps bard songs out
* of the member's burst-matching pick -- threnodies and requiems outrank every
* nuke by spell id, so a bard-subbed member kept "bursting" with songs -- while
* rules that name a song on purpose still fire. The aoews shape exactly: its
* own appended s| field is its own latch, so deployment order cannot matter.
--]]

addon.name    = 'dwgambits';
addon.author  = 'DriftwoodXI';
addon.version = '1.6.0';
addon.desc    = 'Visual gambit rule editor for the DriftwoodXI squad system.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. This is
-- _DWGDATA and never _DWDATA: dwbags owns that one, and two addons contending
-- to block the same sender is a load-order bug where the loser eats the
-- winner's records (dwg_protocol.md says so at length).
local DATA_SENDER = '_DWGDATA';

-- Protocol version the server announces in every `d|` record.
local PROTOCOL = 1;

-- The store's sentinel for "no second condition", mirrored so the local
-- document and the wire agree about what absent looks like.
local NO_CONDITION = 255;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Client ability DAT ids sit 512 above the server's job ability ids -- the
-- same offset every Ashita addon that names a JA uses (timers, luashitacast).
-- The server speaks its own ids on the wire; the client's resources answer to
-- these.
local ABILITY_CLIENT_OFFSET = 512;

-- The client's trust-call spells occupy this id block. They are real spells
-- with real names, so an unfiltered dropdown would offer "Kupipi" as a thing
-- to cast; the server would take it and report it inert, which is polite but
-- useless. Everything else questionable is left in -- the server's refusals
-- are the authority and they are sentences, not errors.
local TRUST_SPELL_FIRST = 896;
local TRUST_SPELL_LAST  = 1023;

-- All of these live in dwtheme and follow the launcher's Appearance theme.
local COLOR_ERROR  = theme.colors.err;
local COLOR_OK     = theme.colors.ok;
local COLOR_DIRTY  = theme.colors.warn;
local COLOR_INERT  = theme.colors.inert;
local COLOR_BADGE  = theme.colors.badge;
local COLOR_HINT   = theme.colors.hint;

local state = T{
    open      = T{ false },

    -- World state, replaced wholesale by the response that owns it (never
    -- merged across responses of the same verb), so a stale row cannot
    -- survive a refresh.
    members     = {},       -- [charid] = live squad member (c| records)
    memberOrder = {},       -- charids in arrival order
    sets        = {},       -- [setid] = owned set header (s| records)
    assigns     = {},       -- ['charid:job'] = assignment (a| records)
    presets     = {},       -- array of shipped sets (p| records)
    loadouts    = {},       -- array of party presets (y| records)

    -- The last share code exported, as its parts (x| records), and which set it
    -- was for. Kept beside the set rather than in it: a code is a snapshot of a
    -- set at a moment, and one held against a set that has since been edited
    -- would be a wrong code shown with confidence.
    codes       = {},
    codesFor    = nil,

    -- Per-member inert verdicts (k| records): [charid] = { setid, presetid,
    -- list = { [ordinal] = reason } }. Reset whenever a verdict-bearing
    -- response re-describes that member, so a stale reason cannot outlive the
    -- install it was true of.
    verdicts  = {},

    -- Per-member upgrade hints (h| records, `!dwg hints`): [charid] = array of
    -- { kind, ordinal, distance, command, text } in the server's own rank
    -- order. Replaced wholesale by every hints response -- the addon always
    -- asks for the whole squad, so an absent member genuinely has none.
    hints     = {},

    selected  = nil,        -- charid highlighted in the left pane
    assignTo  = nil,        -- 'all' or a character name, for the Assign controls

    -- The envelope being read. Records are buffered between `d|` and `z|` and
    -- processed as one response, so a torn or foreign line can never half-fill
    -- the UI -- and so records can be read with their context (a k| belongs to
    -- the c| or s| above it).
    inbound   = nil,
    buffer    = {},

    status    = 'Fetching...',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame
};

--[[
* The vocabulary.
*
* `vocab` is nil until every page has arrived, and the editor renders a
* fetching notice rather than a window with empty dropdowns. `vocabWork`
* accumulates pages; a `g|` announcing a different version than the one being
* staged (or the one in use) throws the stale copy away and starts over --
* a client that caches the whitelist has to notice a server that changed it.
--]]
local vocab     = nil;
local vocabWork = nil;

local function normalise(text)
    return (string.gsub(string.lower(text or ''), '[^%a%d]', ''));
end

local function split(text, sep)
    local parts = {};

    for piece in string.gmatch((text or '') .. sep, '([^' .. sep .. ']*)' .. sep) do
        table.insert(parts, piece);
    end

    return parts;
end

-- `-` | `action` | `n:<min>:<max>:<unit>` | `p:<picker>`, per the protocol's
-- argument-domain field.
local function parseDomain(text)
    if (text == nil or text == '' or text == '-') then
        return { kind = 'none' };
    end

    if (text == 'action') then
        return { kind = 'action' };
    end

    local min, max, unit = string.match(text, '^n:(%-?%d+):(%-?%d+):(.*)$');

    if (min ~= nil) then
        return { kind = 'number', min = tonumber(min), max = tonumber(max), unit = unit };
    end

    local picker = string.match(text, '^p:(.+)$');

    if (picker ~= nil) then
        return { kind = 'pick', picker = picker };
    end

    return { kind = 'none' };
end

--[[
* Build the working vocabulary out of one complete set of pages.
*
* Everything the UI renders hangs off this table: the dropdown lists in wire
* order, the by-id indexes the parser of incoming rules needs, and the derived
* "action kind" list -- one entry per (reaction, selector) pair the server
* says is legal, plus one per canned pairing. A canned pairing is ONE choice,
* never a free combination; where it carries its own condition the When
* column locks, because the samba ladder without its "no samba up" half
* re-dances every pass (the v|n record is explicit about this).
--]]
local function buildVocab(work)
    local built = {
        version    = work.version,
        caps       = { rulesPerSet = 24, setsPerAccount = 16, conditionsPerRule = 2, nameLength = 24, retryMax = 300, installPerMember = 40,
                       tpSkillPicks = 4, tpHoldMin = 1000, tpHoldMax = 3000 },
        targets    = {},  targetById    = {},
        logic      = {},  logicById     = {},
        conditions = {},  conditionById = {},
        reactions  = {},  reactionById  = {},
        selectors  = {},  selectorById  = {}, selectorByKey = {},
        canned     = {},  cannedByPair  = {},
        posture    = { swing = {}, stance = {}, tpwhen = {}, tpuse = {} },
        pickers    = {},  pickerById    = {},
        familyKeys = {},
        kinds      = {},  kindByPair    = {},
    };

    for page = 1, work.pages do
        for _, parts in ipairs(work.rows[page] or {}) do
            local sub = parts[2];

            if (sub == 'h') then
                built.caps = {
                    rulesPerSet       = tonumber(parts[4]) or 24,
                    setsPerAccount    = tonumber(parts[5]) or 16,
                    conditionsPerRule = tonumber(parts[6]) or 2,
                    nameLength        = tonumber(parts[7]) or 24,
                    retryMax          = tonumber(parts[8]) or 300,
                    installPerMember  = tonumber(parts[9]) or 40,

                    -- Appended 2026-08-06 (dwg_protocol.md): absent from an
                    -- older server, so the defaults are that server's truth.
                    tpSkillPicks      = tonumber(parts[10]) or 4,
                    tpHoldMin         = tonumber(parts[11]) or 1000,
                    tpHoldMax         = tonumber(parts[12]) or 3000,
                };
            elseif (sub == 't') then
                local entry = { id = tonumber(parts[3]) or 0, key = parts[4], label = parts[5], note = parts[6] };

                table.insert(built.targets, entry);
                built.targetById[entry.id] = entry;
            elseif (sub == 'l') then
                local entry = { id = tonumber(parts[3]) or 0, key = parts[4], label = parts[5] };

                table.insert(built.logic, entry);
                built.logicById[entry.id] = entry;
            elseif (sub == 'c') then
                local entry = {
                    id    = tonumber(parts[3]) or 0,
                    key   = parts[4],
                    arg   = parseDomain(parts[5]),
                    solo  = parts[6] == '1',
                    label = parts[7],
                    note  = parts[8],
                };

                table.insert(built.conditions, entry);
                built.conditionById[entry.id] = entry;
            elseif (sub == 'r') then
                local entry = { id = tonumber(parts[3]) or 0, key = parts[4], selectors = split(parts[5], ','), label = parts[6] };

                table.insert(built.reactions, entry);
                built.reactionById[entry.id] = entry;
            elseif (sub == 's') then
                local entry = { id = tonumber(parts[3]) or 0, key = parts[4], arg = parseDomain(parts[5]), label = parts[6] };

                table.insert(built.selectors, entry);
                built.selectorById[entry.id]   = entry;
                built.selectorByKey[entry.key] = entry;
            elseif (sub == 'n') then
                local entry = {
                    key       = parts[3],
                    reaction  = tonumber(parts[4]) or 0,
                    selector  = tonumber(parts[5]) or 0,
                    actionid  = tonumber(parts[6]) or 0,
                    condition = tonumber(parts[7]) or NO_CONDITION,
                    label     = parts[8],
                    note      = parts[9],
                };

                table.insert(built.canned, entry);
                built.cannedByPair[entry.reaction] = built.cannedByPair[entry.reaction] or {};
                built.cannedByPair[entry.reaction][entry.selector] = entry;
            elseif (sub == 'o') then
                local field = parts[3];
                local entry = { id = tonumber(parts[4]) or 0, key = parts[5], label = parts[6], note = parts[7] };

                built.posture[field] = built.posture[field] or {};
                table.insert(built.posture[field], entry);
            elseif (sub == 'p') then
                local name = parts[3];

                built.pickers[name]  = built.pickers[name] or {};
                built.pickerById[name] = built.pickerById[name] or {};

                for _, packed in ipairs(split(parts[4], ',')) do
                    local bits = split(packed, ':');

                    if (#bits >= 3) then
                        local entry = { key = bits[1], id = tonumber(bits[2]) or 0, label = bits[3] };

                        table.insert(built.pickers[name], entry);
                        built.pickerById[name][entry.id] = entry;
                    end
                end
            end
        end
    end

    for _, entry in ipairs(built.pickers.spellfamily or {}) do
        built.familyKeys[entry.key] = true;
    end

    -- The action-kind list: what the [Do ▾] dropdown offers. Derived, never
    -- listed: a reaction that gains a selector server-side gains a dropdown
    -- entry here with no addon release.
    for _, reaction in ipairs(built.reactions) do
        for _, selKey in ipairs(reaction.selectors) do
            local selector = built.selectorByKey[selKey];

            if (selector ~= nil) then
                local kind = {
                    reaction    = reaction.id,
                    selector    = selector.id,
                    reactionKey = reaction.key,
                    selectorKey = selector.key,
                    arg         = selector.arg,
                    label       = #reaction.selectors == 1 and reaction.label
                        or string.format('%s: %s', reaction.label, selector.label),
                };

                -- The ranged attack ignores its selector argument entirely --
                -- the engine hands the target straight to RangedAttack and the
                -- server's own `shoot` sugar stores 0 -- so offering an
                -- argument here would be offering a knob wired to nothing.
                if (reaction.key == 'shoot') then
                    kind.arg = { kind = 'none' };
                end

                table.insert(built.kinds, kind);
                built.kindByPair[reaction.id] = built.kindByPair[reaction.id] or {};
                built.kindByPair[reaction.id][selector.id] = kind;
            end
        end
    end

    for _, canned in ipairs(built.canned) do
        local kind = {
            reaction = canned.reaction,
            selector = canned.selector,
            actionid = canned.actionid,
            canned   = canned,
            pinned   = canned.condition ~= NO_CONDITION and canned.condition or nil,
            arg      = { kind = 'none' },
            label    = canned.label,
        };

        table.insert(built.kinds, kind);
        built.kindByPair[canned.reaction] = built.kindByPair[canned.reaction] or {};
        built.kindByPair[canned.reaction][canned.selector] = kind;
    end

    vocab     = built;
    vocabWork = nil;
end

--[[
* Client resources: spell and ability names out of the DATs.
*
* The server does not send action names and does not need to -- this addon is
* inside the client, which already knows the name of every spell and ability
* it can render a menu for. That is the dwbags rule (item names, same
* reasoning) and it is what keeps an r| record inside the line budget.
*
* Built once, on first use: the resource manager is not guaranteed while the
* addon is loading from the launcher's boot script, and nothing here is
* needed before the first frame that draws an action dropdown.
--]]
local actionLists = { spell = nil, ability = nil };

local function playerCanLearn(spell)
    -- LevelRequired holds one entry per job; a spell no job learns between 1
    -- and 99 is monster-only and just noise in a dropdown. Guarded because the
    -- SDK table's shape is the client's business, not ours: on any surprise,
    -- include the spell and let the server be the judge.
    local ok, usable = pcall(function()
        local levels = spell.LevelRequired;

        for job = 1, 24 do
            local level = levels[job];

            if (type(level) == 'number' and level >= 1 and level <= 99) then
                return true;
            end
        end

        return false;
    end);

    if (not ok) then
        return true;
    end

    return usable;
end

local function buildActionLists()
    local resources = AshitaCore:GetResourceManager();
    local spells    = {};
    local abilities = {};

    for id = 1, 1299 do
        if (id < TRUST_SPELL_FIRST or id > TRUST_SPELL_LAST) then
            local spell = resources:GetSpellById(id);

            if (spell ~= nil) then
                local name = spell.Name[1];

                if (name ~= nil and #name > 1 and name ~= '.' and playerCanLearn(spell)) then
                    table.insert(spells, { id = id, label = name });
                end
            end
        end
    end

    -- Job abilities live at DAT ids 512..1535; the value stored in a rule is
    -- the server id, so it is the DAT id minus the offset.
    for clientId = ABILITY_CLIENT_OFFSET + 1, ABILITY_CLIENT_OFFSET + 1023 do
        local ability = resources:GetAbilityById(clientId);

        if (ability ~= nil) then
            local name = ability.Name[1];

            if (name ~= nil and #name > 1 and name ~= '.') then
                table.insert(abilities, { id = clientId - ABILITY_CLIENT_OFFSET, label = name });
            end
        end
    end

    -- Weapon skills are DAT ability ids 1..255 with NO offset -- the server's
    -- weapon-skill id IS the client ability id (dwg_protocol.md, the s|
    -- tpskills field). The whole list, not this character's: a posture stores
    -- intent, and the set being edited may be for an alt with a different
    -- weapon in its hands. The server reports what a member cannot use.
    local weaponskills = {};

    for clientId = 1, 255 do
        local ability = resources:GetAbilityById(clientId);

        if (ability ~= nil) then
            local name = ability.Name[1];

            if (name ~= nil and #name > 1 and name ~= '.') then
                table.insert(weaponskills, { id = clientId, label = name });
            end
        end
    end

    table.sort(spells, function (a, b) return a.label < b.label; end);
    table.sort(abilities, function (a, b) return a.label < b.label; end);
    table.sort(weaponskills, function (a, b) return a.label < b.label; end);

    actionLists.spell   = spells;
    actionLists.ability = abilities;
    actionLists.ws      = weaponskills;
end

local function actionList(resource)
    if (actionLists[resource] == nil) then
        local ok = pcall(buildActionLists);

        if (not ok) then
            return {};
        end
    end

    return actionLists[resource] or {};
end

local function spellName(id)
    local spell = AshitaCore:GetResourceManager():GetSpellById(id);

    if (spell ~= nil and spell.Name[1] ~= nil and #spell.Name[1] > 0) then
        return spell.Name[1];
    end

    return nil;
end

local function abilityName(serverId)
    local ability = AshitaCore:GetResourceManager():GetAbilityById(serverId + ABILITY_CLIENT_OFFSET);

    if (ability ~= nil and ability.Name[1] ~= nil and #ability.Name[1] > 0) then
        return ability.Name[1];
    end

    return nil;
end

-- Weapon skills: client ability ids with no offset (see buildActionLists).
local function weaponSkillName(id)
    local ability = AshitaCore:GetResourceManager():GetAbilityById(id);

    if (ability ~= nil and ability.Name[1] ~= nil and #ability.Name[1] > 0) then
        return ability.Name[1];
    end

    return string.format('#%d', id);
end

--[[
* Labels for whatever a rule holds, including things the vocabulary no longer
* lists -- a set saved before an entry narrowed still has to render as
* SOMETHING the player can select and delete, so unknown ids show as #n
* rather than taking the row down.
--]]
local function kindOf(rule)
    if (vocab == nil) then
        return nil;
    end

    local byReaction = vocab.kindByPair[rule.reaction];

    return byReaction ~= nil and byReaction[rule.selector] or nil;
end

local function conditionText(cond, arg)
    if (cond == NO_CONDITION) then
        return '';
    end

    local entry = vocab ~= nil and vocab.conditionById[cond] or nil;

    if (entry == nil) then
        return string.format('condition #%d', cond);
    end

    if (entry.arg.kind == 'number') then
        return string.format('%s %d%s', entry.label, arg, entry.arg.unit or '');
    end

    if (entry.arg.kind == 'pick') then
        local pick = vocab.pickerById[entry.arg.picker];
        local hit  = pick ~= nil and pick[arg] or nil;

        return string.format('%s: %s', entry.label, hit ~= nil and hit.label or ('#' .. arg));
    end

    return entry.label;
end

local function actionText(rule)
    local kind = kindOf(rule);

    if (kind == nil) then
        return string.format('engine %d/%d/%d', rule.reaction, rule.selector, rule.actionid);
    end

    if (kind.canned ~= nil) then
        return kind.label;
    end

    if (kind.arg.kind == 'pick') then
        local pick = vocab.pickerById[kind.arg.picker];
        local hit  = pick ~= nil and pick[rule.actionid] or nil;

        return string.format('Best %s', hit ~= nil and hit.label or ('#' .. rule.actionid));
    end

    if (kind.arg.kind == 'action') then
        -- Split for the same reason as the serialiser: the collapsed form
        -- renders a nameless ability id as some unrelated spell.
        local name;

        if (kind.reactionKey == 'ability') then
            name = abilityName(rule.actionid);
        else
            name = spellName(rule.actionid);
        end

        return name or string.format('%s #%d', kind.reactionKey, rule.actionid);
    end

    return kind.label;
end

--[[
* Sending: one command per interval, queued, with the reads deduplicated.
*
* THE CLIENT RATE-LIMITS OUTGOING CHAT AND A !dwg COMMAND IS A CHAT LINE.
* Fire two in one frame and the second is answered "A command error occurred"
* before the server ever sees it -- the dwbags lesson, paid for once, applied
* from day one here.
*
* Two queues, and the difference is the whole design. Reads collapse
* duplicates because asking twice for the same thing is never useful. The
* PLAN queue -- the mutating command sequence a Save builds -- must never
* collapse anything (two identical `add` lines can be two identical rules the
* player genuinely wants) and must run strictly one command at a time, each
* step waiting for its answer, because a plan step landing out of order would
* edit the wrong ordinal.
--]]
local SEND_INTERVAL = 1.2;

local readQueue = {};
local plan      = {};       -- pending mutating commands, in order
local planWait  = nil;      -- { verb, command, at } -- the step in flight
local planTotal = 0;        -- for the progress line
local lastSend  = 0;

-- Forward declaration. pumpQueue's watchdog (below) has to clear the save
-- latch, and the editor table it lives on is not defined until much further
-- down; without this the watchdog would close over a global.
local editor;

-- Answered-question tracking, keyed by envelope verb. A PLAIN TABLE, NOT T{}:
-- string keys on a T{} resolve through the sugar metatable and `find` is both
-- a table method and a plausible verb name -- the collision that cost dwbags
-- a round.
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

-- True once the server has said it has no hints verb -- one from before
-- UPGRADE_HINTS_PLAN.md Phase 2. Detected off the dispatch's own unknown-verb
-- sentence (frozen on any server old enough to say it) and reset on every
-- login/zone line, so a server upgraded underneath a running client gets
-- asked again at the next zone rather than never.
local hintsUnsupported = false;

-- The same latch for the party-preset verb (2026-08-16): `party` is additive
-- to protocol 1, so a server from before it answers with the unknown-verb
-- sentence rather than a version mismatch. Latched off that sentence, reset
-- on every login/zone line -- deployment order must not matter either way.
local partyUnsupported = false;

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

local function issueRead(command)
    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

-- Ask for one verb (optionally about one qualifier -- a set name, a vocab
-- page) at most once, twice if the first ask was never answered. Called from
-- whatever pane needs the data, every frame, so the guard is the entire
-- point.
local function need(verb, qualifier, command)
    local asked = requested[verb];

    if (asked ~= nil and asked.qualifier == qualifier) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested[verb] = { qualifier = qualifier, at = os.clock(), answered = false, tries = 1 };
    end

    issueRead(command);
end

local function planVerbOf(command)
    return string.match(command, '^!dwg%s+(%S+)') or '?';
end

local function abortPlan(reason)
    if (#plan == 0 and planWait == nil) then
        return;
    end

    plan      = {};
    planWait  = nil;
    planTotal = 0;

    state.status    = reason;
    state.statusBad = true;
end

local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    -- A plan step that was never answered is NOT re-sent -- re-sending a
    -- mutating command is how a rule gets added twice. The plan dies, the
    -- editor stays dirty, and the reload below shows what actually landed.
    if (planWait ~= nil) then
        if (now - planWait.at > 8.0) then
            abortPlan('No answer from the server mid-save. Nothing was lost -- press Save to try again.');

            -- AND CLEAR THE SAVE LATCH, exactly as the `e|` refusal path does.
            -- Without this the message above is a lie by omission: Save and
            -- Save as both answer 'A save is already running.' for the rest of
            -- the session, so the button the sentence tells the player to press
            -- is the one this abort just disabled. finishPlanStep cannot rescue
            -- it either -- it returns early on the planWait we just nil'd.
            editor.saving = false;
        end

        return;
    end

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#plan > 0) then
        local command = table.remove(plan, 1);

        planWait = { verb = planVerbOf(command), command = command, at = now };
        lastSend = now;

        echo.send(command);

        return;
    end

    if (#readQueue > 0) then
        lastSend = now;

        echo.send(table.remove(readQueue, 1));
    end
end

--[[
* The editor's document.
*
* `doc` is what the player is editing; `server` is the last complete copy the
* server sent of the same set. `touched` -- not a computed diff -- is the
* unsaved-changes flag, because the server copy can legitimately change
* underneath (a `!squad rules` line typed outside the window) and an edit the
* player did not make must never be reported as theirs. Save diffs doc
* against server; Revert copies server over doc.
--]]
editor = {
    name       = nil,       -- the set being edited, as the server spells it
    setid      = 0,
    shipped    = false,     -- true = read-only view of a preset
    doc        = nil,       -- { posture, rules }
    server     = nil,       -- { posture, rules, verdicts }
    touched    = false,
    pendingRef = nil,       -- a `show` is in flight for this name
    saving     = false,
    armDelete  = 0,         -- setid the Delete button is armed for (two-click)
};

local function copyRule(rule)
    return {
        target = rule.target, logic = rule.logic,
        cond1 = rule.cond1, arg1 = rule.arg1,
        cond2 = rule.cond2, arg2 = rule.arg2,
        reaction = rule.reaction, selector = rule.selector,
        actionid = rule.actionid, retry = rule.retry,
        gate = rule.gate, srv = rule.srv,

        -- nil on a server that predates the toggle round (1.4); the
        -- checkboxes latch off the s| record's aoews field, not this.
        enabled = rule.enabled,
    };
end

local function copyDocOf(source)
    local rules = {};

    for index, rule in ipairs(source.rules) do
        rules[index] = copyRule(rule);
    end

    local posture = {};

    for key, value in pairs(source.posture) do
        if (type(value) == 'table') then
            -- The pick list. Copied by value: a shared reference would make
            -- every editor reorder silently rewrite the server mirror, and
            -- the save diff would then see nothing to save.
            local list = {};

            for index, entry in ipairs(value) do
                list[index] = entry;
            end

            posture[key] = list;
        else
            posture[key] = value;
        end
    end

    return { posture = posture, rules = rules };
end

-- One string per rule, so "the same rule" is one comparison. Everything the
-- store persists is in it; the gate is not, because a gate only ever appears
-- on a shipped set and a shipped set is never diffed.
local function ruleKey(rule)
    return string.format('%d/%d/%d/%d/%d/%d/%d/%d/%d/%d',
        rule.target, rule.logic, rule.cond1, rule.arg1, rule.cond2, rule.arg2,
        rule.reaction, rule.selector, rule.actionid, rule.retry);
end

local function loadIntoEditor(ref)
    editor.armDelete  = 0;
    editor.pendingRef = string.match(string.lower(ref), '^preset:(.+)$') or ref;

    state.status    = string.format('Loading %s...', editor.pendingRef);
    state.statusBad = false;

    requested['show'] = nil;
    need('show', string.lower(editor.pendingRef), string.format('!dwg show "%s"', editor.pendingRef));
end

local function adoptDoc(doc)
    editor.name    = doc.name;
    editor.setid   = doc.setid;
    editor.shipped = doc.setid == 0;
    editor.server  = doc;

    for index, rule in ipairs(doc.rules) do
        rule.srv = index;
    end

    if (not editor.touched) then
        editor.doc = copyDocOf(doc);
    end
end

--[[
* Serialisation: a local rule back into the one line a player could type.
*
* This is the renderer constraint made concrete. The addon does not write
* fields to the store; it says `add "Medic" party hplt:40 cure-family` and the
* server's own grammar, whitelist and validator take it from there. The
* condition uses the key:value shape (`hplt:40`, `status:sleep`) because every
* exposed condition accepts it and the comparison sugar is for people. The
* words below are GRAMMAR -- the typed tier's own documented sugar -- keyed by
* wire keys, so a selector the vocabulary drops stops being emitted too.
--]]
local GRAMMAR_WORDS = {
    ['spell:random']    = 'anything',
    ['spell:mbelement'] = 'burst',
    ['shoot:specific']  = 'shoot',
};

local function conditionToken(cond, arg)
    local entry = vocab.conditionById[cond];

    if (entry == nil) then
        return nil, string.format('a condition (#%d) the vocabulary no longer lists', cond);
    end

    if (entry.arg.kind == 'number') then
        return string.format('%s:%d', entry.key, arg);
    end

    if (entry.arg.kind == 'pick') then
        local pick = vocab.pickerById[entry.arg.picker];
        local hit  = pick ~= nil and pick[arg] or nil;

        if (hit == nil) then
            return nil, string.format('a %s entry (#%d) the vocabulary no longer lists', entry.arg.picker, arg);
        end

        return string.format('%s:%s', entry.key, hit.key);
    end

    return entry.key;
end

local function actionToken(rule)
    local kind = kindOf(rule);

    if (kind == nil) then
        return nil, 'an action the vocabulary no longer lists';
    end

    if (kind.canned ~= nil) then
        return kind.canned.key;
    end

    if (kind.arg.kind == 'pick') then
        local pick = vocab.pickerById[kind.arg.picker];
        local hit  = pick ~= nil and pick[rule.actionid] or nil;

        if (hit == nil) then
            return nil, string.format('a %s entry the vocabulary no longer lists', kind.arg.picker);
        end

        -- An item rule serialises as the explicit `item:` form (2026-08-16)
        -- -- every medicine name is also an ordinary word, so the bare-name
        -- reading stays with spells. Gated by harness_dwsuite's
        -- PAIRED_LITERALS against the parser branch in squad_rules_cmd.lua,
        -- the ja: precedent.
        if (kind.reactionKey == 'item') then
            return 'item:' .. hit.key;
        end

        -- The weapon-skill tier (1.6) needs its own explicit prefix for a
        -- sharper version of the same reason: half the weapon-skill names in
        -- the game are also spell or ability names, and without this branch a
        -- picker-argument rule falls through to the `-family` default below
        -- and the server reads it as a spell family. Gated by
        -- harness_dwsuite's PAIRED_LITERALS against the parser branch.
        if (kind.reactionKey == 'weaponskill') then
            return 'ws:' .. hit.key;
        end

        return hit.key .. '-family';
    end

    if (kind.arg.kind == 'action') then
        -- SPLIT, not the `a and b or c` collapse: when the reaction IS an
        -- ability but abilityName returns nil, that idiom falls through to
        -- spellName and silently borrows an unrelated SPELL's name for an
        -- ability id -- so the refusal below could never be reached for the
        -- case it was written for.
        local name;

        if (kind.reactionKey == 'ability') then
            name = abilityName(rule.actionid);
        else
            name = spellName(rule.actionid);
        end

        if (name == nil) then
            return nil, string.format('a %s id (%d) this client has no name for', kind.reactionKey, rule.actionid);
        end

        -- A tier-one spell whose bare name is also a family key -- Cure,
        -- Stone, Sleep -- would be read as the family ladder, because that is
        -- the documented default reading. The `1` suffix is the grammar's own
        -- way of saying "exactly that one".
        if (kind.reactionKey == 'spell' and vocab.familyKeys[normalise(name)]) then
            name = name .. '1';
        end

        -- EVERY ability rule carries the prefix, not just the names that
        -- happen to collide today. A bare name is resolved as a SPELL first
        -- by the server's grammar, so `Fire II` -- a black-magic spell AND a
        -- Blue Mage ability -- round-tripped an ability rule into a spell
        -- rule, and the Waltzes and Sambas landed on their canned pairings.
        -- Deterministic beats a collision table that drifts with the enums.
        if (kind.reactionKey == 'ability') then
            return 'ja:' .. name;
        end

        return name;
    end

    local word = GRAMMAR_WORDS[kind.reactionKey .. ':' .. kind.selectorKey];

    if (word == nil) then
        return nil, 'an action shape this addon does not know how to type';
    end

    return word;
end

local function serialiseRule(quotedName, rule)
    local action, actionWhy = actionToken(rule);

    if (action == nil) then
        return nil, actionWhy;
    end

    local kind = kindOf(rule);
    local condToken, condWhy;

    if (kind ~= nil and kind.pinned ~= nil) then
        -- The pairing owns its condition, and the grammar's required spelling
        -- for that is the word `always` in the condition slot.
        condToken = 'always';
    else
        condToken, condWhy = conditionToken(rule.cond1, rule.arg1);

        if (condToken == nil) then
            return nil, condWhy;
        end
    end

    local target = vocab.targetById[rule.target];

    if (target == nil) then
        return nil, string.format('a target (#%d) the vocabulary no longer lists', rule.target);
    end

    local parts = { '!dwg add', quotedName, target.key, condToken };

    if (rule.cond2 ~= NO_CONDITION and (kind == nil or kind.pinned == nil)) then
        local logic = vocab.logicById[rule.logic];
        local second, secondWhy = conditionToken(rule.cond2, rule.arg2);

        if (second == nil) then
            return nil, secondWhy;
        end

        table.insert(parts, logic ~= nil and logic.key or 'and');
        table.insert(parts, second);
    end

    table.insert(parts, action);

    if (rule.retry > 0) then
        table.insert(parts, string.format('retry:%d', rule.retry));
    end

    return table.concat(parts, ' ');
end

-- The posture fields as the `posture` verb spells them. The switch fields are
-- booleans; the option fields name a v|o list whose keys are the values the
-- command takes.
local POSTURE_PLAN = {
    { field = 'autoattack', word = 'swing',  list = 'swing'  },
    { field = 'movement',   word = 'stance', list = 'stance' },
    { field = 'tptrigger',  word = 'tpwhen', list = 'tpwhen' },
    { field = 'tpselect',   word = 'tpuse',  list = 'tpuse'  },
    { field = 'spendtp',    word = 'tp'   },
    { field = 'hold',       word = 'hold' },

    -- `latched`: only ever diffed when the server sent the field at all --
    -- an older server refuses `posture X aoews` with a sentence, and a save
    -- plan must never contain a line it knows will refuse.
    { field = 'aoews',      word = 'aoews', latched = true },

    -- Song burst (1.5), the aoews shape one field over: latched on its own
    -- presence, appended at the s| tail, wired to `posture X songburst`.
    { field = 'songburst',  word = 'songburst', latched = true },

    -- The two 2026-08-24 switches, same latched shape one field over each.
    { field = 'runin',      word = 'runin',    latched = true },
    { field = 'manualws',   word = 'manualws', latched = true },
};

local function postureOptionKey(list, id)
    for _, option in ipairs(vocab.posture[list] or {}) do
        if (option.id == id) then
            return option.key;
        end
    end

    return nil;
end

--[[
* The save plan: the shortest command sequence that makes the server's copy of
* the set equal the editor's.
*
* Deletions first (descending, so earlier ordinals stay true), then appends,
* then moves -- `add` only ever appends, so order is restored last. The moves
* are computed against a local mirror that applies each step exactly as the
* server will, which is what makes ordinal arithmetic safe to do at all.
--]]
local function buildSavePlan(name, serverDoc, localDoc, createFirst)
    local commands = {};
    local quoted   = '"' .. name .. '"';

    if (createFirst) then
        -- Unquoted deliberately: `new` reads its name as the raw tail of the
        -- line, so quotes would end up inside the name and cleanName would
        -- refuse them.
        table.insert(commands, '!dwg new ' .. name);
    end

    local mirror = {};

    for index, rule in ipairs(serverDoc.rules) do
        mirror[index] = rule;
    end

    -- Deletions: keep the first server occurrence of every rule the local
    -- document still wants, delete the rest.
    local wanted = {};

    for _, rule in ipairs(localDoc.rules) do
        local key = ruleKey(rule);

        wanted[key] = (wanted[key] or 0) + 1;
    end

    local keep      = {};
    local remaining = {};

    for index, rule in ipairs(mirror) do
        local key = ruleKey(rule);

        if ((wanted[key] or 0) > 0) then
            wanted[key] = wanted[key] - 1;
            keep[index] = true;
            table.insert(remaining, rule);
        end
    end

    for index = #mirror, 1, -1 do
        if (not keep[index]) then
            table.insert(commands, string.format('!dwg del %s %d', quoted, index));
        end
    end

    mirror = remaining;

    -- Appends: whatever the local document holds beyond what survived.
    local have = {};

    for _, rule in ipairs(mirror) do
        local key = ruleKey(rule);

        have[key] = (have[key] or 0) + 1;
    end

    for ordinal, rule in ipairs(localDoc.rules) do
        local key = ruleKey(rule);

        if ((have[key] or 0) > 0) then
            have[key] = have[key] - 1;
        else
            local line, why = serialiseRule(quoted, rule);

            if (line == nil) then
                return nil, string.format('Rule %d cannot be saved: it uses %s.', ordinal, why);
            end

            table.insert(commands, line);

            -- A copy with the switch forced ON, because that is what `add`
            -- creates server-side -- mirroring the local rule (possibly off)
            -- would hide exactly the toggle the pass below must emit.
            local fresh = copyRule(rule);

            fresh.enabled = true;

            table.insert(mirror, fresh);
        end
    end

    -- Moves: selection-sort the mirror into the local order.
    for index = 1, #localDoc.rules do
        if (mirror[index] == nil or ruleKey(mirror[index]) ~= ruleKey(localDoc.rules[index])) then
            for from = index + 1, #mirror do
                if (ruleKey(mirror[from]) == ruleKey(localDoc.rules[index])) then
                    table.insert(commands, string.format('!dwg move %s %d to %d', quoted, from, index));
                    table.insert(mirror, index, table.remove(mirror, from));

                    break;
                end
            end
        end
    end

    -- Toggles (1.4), by FINAL ordinal -- after the moves, because `toggle`
    -- names a position and every earlier phase shuffles them. ruleKey
    -- deliberately excludes the switch (a toggled rule is the same rule),
    -- so this positional pass is the only place the diff can see it.
    -- Latched exactly as the aoews posture field is: a server that never
    -- sent aoews does not speak `toggle` either.
    if (serverDoc.posture ~= nil and serverDoc.posture.aoews ~= nil) then
        for index, rule in ipairs(localDoc.rules) do
            local mine   = rule.enabled ~= false;
            local theirs = mirror[index] == nil or mirror[index].enabled ~= false;

            if (mine ~= theirs) then
                table.insert(commands, string.format('!dwg toggle %s %d %s', quoted, index, mine and 'on' or 'off'));
            end
        end
    end

    -- Posture, field by changed field.
    for _, spec in ipairs(POSTURE_PLAN) do
        local mine   = localDoc.posture[spec.field];
        local theirs = serverDoc.posture[spec.field];

        if (mine ~= theirs and (not spec.latched or (theirs ~= nil and mine ~= nil))) then
            if (spec.list ~= nil) then
                local key = postureOptionKey(spec.list, mine);

                if (key ~= nil) then
                    table.insert(commands, string.format('!dwg posture %s %s %s', quoted, spec.word, key));
                end
            else
                table.insert(commands, string.format('!dwg posture %s %s %s', quoted, spec.word, mine and 'on' or 'off'));
            end
        end
    end

    -- The weapon-skill pair (2026-08-06). tphold is a number, not a key list;
    -- the picks are one command carrying the whole ordered list, because order
    -- is the preference and a per-slot diff could not express a reorder.
    local myHold    = localDoc.posture.tphold or 0;
    local theirHold = serverDoc.posture.tphold;

    if (myHold ~= theirHold) then
        table.insert(commands, string.format('!dwg posture %s tphold %s', quoted, myHold > 0 and tostring(myHold) or 'off'));
    end

    local function picksKey(list)
        return type(list) == 'table' and table.concat(list, ',') or tostring(list);
    end

    local myPicks = localDoc.posture.tpskills or {};

    if (picksKey(myPicks) ~= picksKey(serverDoc.posture.tpskills)) then
        if (#myPicks == 0) then
            table.insert(commands, string.format('!dwg posture %s tpskill any', quoted));
        else
            local names = {};

            for _, id in ipairs(myPicks) do
                table.insert(names, weaponSkillName(id));
            end

            table.insert(commands, string.format('!dwg posture %s tpskill %s', quoted, table.concat(names, ', ')));
        end
    end

    return commands;
end

-- The store's naming rule, checked before a plan is built on it: a refused
-- `new` at the head of a Save As would leave the editor pointed at a set that
-- does not exist, which is a far worse conversation than this sentence.
local function validName(name)
    if (name == nil or #name == 0 or #name > vocab.caps.nameLength) then
        return false;
    end

    return string.match(name, '^[%w][%w %-]*$') ~= nil;
end

local function nameProblem(name)
    if (name == nil or #name == 0) then
        return 'Name it first.';
    end

    return string.format('Names are letters, digits, spaces and dashes -- %d characters at most.', vocab.caps.nameLength);
end

local function startPlan(commands, statusText)
    local running = (#plan > 0 or planWait ~= nil);

    for _, command in ipairs(commands) do
        table.insert(plan, command);
    end

    -- Additive while a plan is already running: `#plan` is the REMAINING
    -- length, and resetting the total mid-save restarted the "Saving -- N of
    -- M" counter for whoever clicked a second button.
    if (running) then
        planTotal = planTotal + #commands;
    else
        planTotal = #plan;
    end

    if (statusText ~= nil) then
        state.status    = statusText;
        state.statusBad = false;
    end
end

local function beginSave(asName)
    if (vocab == nil or editor.doc == nil) then
        return;
    end

    -- Client-side sanity the caps record asks for: an action that still says
    -- "pick one" would be refused server-side with a sentence about grammar,
    -- which is the wrong sentence for what the player actually forgot.
    for ordinal, rule in ipairs(editor.doc.rules) do
        local kind = kindOf(rule);

        if (kind ~= nil and kind.arg.kind ~= 'none' and rule.actionid == 0) then
            state.status    = string.format('Rule %d has no action picked yet.', ordinal);
            state.statusBad = true;

            return;
        end
    end

    local name       = asName or editor.name;
    local serverDoc  = asName ~= nil and { posture = {}, rules = {} } or editor.server;

    -- A brand-new document diffs against silence: posture fields all "changed"
    -- if they differ from what `new` will write. `new` creates the store's
    -- defaults, which the server's own s| record for the created set reports
    -- -- so posture lines are emitted for every field here and the harmless
    -- duplicates cost one command each. Simpler than guessing defaults.
    if (asName ~= nil) then
        serverDoc.posture = { autoattack = -1000, spendtp = 'unset', hold = 'unset', movement = -1000, tptrigger = -1000, tpselect = -1000,
                              tphold = -1000, tpskills = 'unset' };

        -- The aoews sentinel rides only when the live server actually sent
        -- the field: it doubles as the toggle latch inside buildSavePlan,
        -- and a synthetic doc must not promise a verb an older server
        -- refuses. (`unset` diffs against either boolean, like the rest.)
        if (editor.server ~= nil and editor.server.posture ~= nil and editor.server.posture.aoews ~= nil) then
            serverDoc.posture.aoews = 'unset';
        end

        -- The songburst sentinel, same rule, its own latch (1.5).
        if (editor.server ~= nil and editor.server.posture ~= nil and editor.server.posture.songburst ~= nil) then
            serverDoc.posture.songburst = 'unset';
        end

        -- The two 2026-08-24 switches, same rule and same latch each.
        if (editor.server ~= nil and editor.server.posture ~= nil and editor.server.posture.runin ~= nil) then
            serverDoc.posture.runin = 'unset';
        end

        if (editor.server ~= nil and editor.server.posture ~= nil and editor.server.posture.manualws ~= nil) then
            serverDoc.posture.manualws = 'unset';
        end
    end

    local commands, why = buildSavePlan(name, serverDoc, editor.doc, asName ~= nil);

    if (commands == nil) then
        state.status    = why;
        state.statusBad = true;

        return;
    end

    if (#commands == 0) then
        editor.touched = false;
        state.status   = 'Nothing to save.';
        state.statusBad = false;

        return;
    end

    editor.saving = true;

    if (asName ~= nil) then
        -- Kept until the `new` step is confirmed: if `new` is refused
        -- (typically "a set called X already exists"), the abort path rolls
        -- the identity back to this. Without it the editor adopted the
        -- PRE-EXISTING set of that name, and the next Save built a plan that
        -- deleted its rules and replaced them with this document's -- a set
        -- the player never meant to touch, destroyed with no confirmation.
        editor.saveFallback = {
            name    = editor.name,
            setid   = editor.setid,
            shipped = editor.shipped,
            server  = editor.server,
        };

        -- The editor follows the copy: from here on the document being edited
        -- IS the new set, and the `new` response adopts the server's spelling.
        editor.name    = asName;
        editor.setid   = 0;
        editor.shipped = false;
        editor.server  = { name = asName, setid = 0, posture = {}, rules = {}, verdicts = {} };
    else
        editor.saveFallback = nil;
    end

    startPlan(commands, string.format('Saving -- %d step%s...', #commands, #commands == 1 and '' or 's'));
end

local function finishPlanStep()
    if (planWait == nil) then
        return;
    end

    -- Once `new` has been ANSWERED the created set is real, and a refusal of
    -- a later step must keep today's behaviour (re-show the new set): the
    -- rollback below is only for a `new` that never happened.
    if (planWait.verb == 'new') then
        editor.saveFallback = nil;
    end

    planWait = nil;

    if (#plan > 0) then
        if (editor.saving) then
            state.status    = string.format('Saving -- %d of %d...', planTotal - #plan + 1, planTotal);
            state.statusBad = false;
        end

        return;
    end

    planTotal = 0;

    if (editor.saving) then
        editor.saving = false;

        -- The server's read-back of every step has been folded into
        -- editor.server as it arrived; if the two documents now agree the
        -- edit is truly on disk, and if they do not, something was refused
        -- and the difference is exactly what to look at.
        local residue = editor.server ~= nil
            and buildSavePlan(editor.name, editor.server, editor.doc, false) or nil;

        if (residue ~= nil and #residue == 0) then
            -- Re-copied from the server's read-back rather than just marked
            -- clean: the copy re-numbers each row's server ordinal, which is
            -- the key the inert verdicts are reported against.
            editor.doc      = copyDocOf(editor.server);
            editor.touched  = false;
            state.status    = string.format('"%s" saved.', editor.name);
            state.statusBad = false;
        else
            state.status    = 'Saved with differences -- the server refused part of it. Revert shows what held.';
            state.statusBad = true;
        end
    end
end

--[[
* Record parsing.
*
* Lines arrive one per chat packet. `m|` and `e|` are handled the moment they
* arrive -- a refusal is the one thing a player must never lose, and it also
* has to be able to abort a running save plan RIGHT NOW, before the next step
* goes out. Everything else buffers between `d|` and `z|` and is processed as
* one response: records get their context back (a k| belongs to the c| above
* it) and a torn envelope fills nothing.
--]]

-- Which verbs re-describe members thoroughly enough to reset their inert
-- verdicts. The bare listing (`rules`) sends counts of -1 and no verdicts, so
-- it must not wipe what `report` said.
local VERDICT_VERBS = { add = true, del = true, move = true, toggle = true, posture = true, use = true, report = true, show = true };

-- Which verbs answer with a full document (s| followed by its r| rows).
local DOC_VERBS = { show = true, new = true, copy = true, rename = true, add = true, del = true, move = true,
                    toggle = true, posture = true, ['import'] = true };

local function parseSetRecord(parts)
    -- The two weapon-skill fields were appended 2026-08-06; absent from an
    -- older server they read as "engine default, no picks", which is that
    -- server's truth. '-' is the record grammar's "no picks".
    local tpskills = {};

    if (parts[12] ~= nil and parts[12] ~= '-' and parts[12] ~= '') then
        for _, piece in ipairs(split(parts[12], ',')) do
            local id = tonumber(piece);

            if (id ~= nil and id > 0) then
                table.insert(tpskills, id);
            end
        end
    end

    -- `aoews` was appended 2026-08-18. nil -- an older server -- doubles as
    -- THE latch for the whole toggle round: a server that sends it also
    -- speaks the `toggle` verb and the r| record's on/off field, so the
    -- editor only offers its new checkboxes when this field arrived.
    local aoews = nil;

    if (parts[13] ~= nil) then
        aoews = parts[13] ~= '0';
    end

    -- `songburst` was appended 2026-08-23, its own latch for its own round:
    -- a server that sends it speaks `posture X songburst`. Absent reads as
    -- "this server always lets songs burst", which is that server's truth.
    local songburst = nil;

    if (parts[14] ~= nil) then
        songburst = parts[14] ~= '0';
    end

    -- `runin` and `manualws` were appended 2026-08-24 as parts[15] and parts[16], each
    -- its own latch for its own switch. Absent reads as "this server always
    -- walks its bards in" and "this server has no manual weapon-skill mode",
    -- which is that server's truth in both cases.
    local runin = nil;

    if (parts[15] ~= nil) then
        runin = parts[15] ~= '0';
    end

    local manualws = nil;

    if (parts[16] ~= nil) then
        manualws = parts[16] ~= '0';
    end

    return {
        setid   = tonumber(parts[2]) or 0,
        name    = parts[3],
        count   = tonumber(parts[4]) or 0,
        posture = {
            autoattack = tonumber(parts[5]) or 2,
            spendtp    = parts[6] == '1',
            hold       = parts[7] == '1',
            movement   = tonumber(parts[8]) or 127,
            tptrigger  = tonumber(parts[9]) or 0,
            tpselect   = tonumber(parts[10]) or 0,
            tphold     = tonumber(parts[11]) or 0,
            tpskills   = tpskills,
            aoews      = aoews,
            songburst  = songburst,
            runin      = runin,
            manualws   = manualws,
        },
        rules    = {},
        verdicts = {},
    };
end

local function parseRuleRecord(parts)
    -- The on/off field was appended 2026-08-18. Absent -- an older server --
    -- stays nil, which is how the editor knows not to offer the switch.
    local enabled = nil;

    if (parts[14] ~= nil) then
        enabled = parts[14] ~= '0';
    end

    return {
        target   = tonumber(parts[3]) or 0,
        logic    = tonumber(parts[4]) or 0,
        cond1    = tonumber(parts[5]) or 0,
        arg1     = tonumber(parts[6]) or 0,
        cond2    = tonumber(parts[7]) or NO_CONDITION,
        arg2     = tonumber(parts[8]) or 0,
        reaction = tonumber(parts[9]) or 0,
        selector = tonumber(parts[10]) or 0,
        actionid = tonumber(parts[11]) or 0,
        retry    = tonumber(parts[12]) or 0,
        gate     = parts[13] ~= nil and parts[13] ~= '-' and parts[13] or nil,
        enabled  = enabled,
    };
end

local function processEnvelope(verb, records)
    -- Wholesale resets FIRST, before anything can throw: a response replaces
    -- its own section outright, never merges with it.
    if (verb == 'rules') then
        state.members     = {};
        state.memberOrder = {};
    elseif (verb == 'list' or verb == 'menu' or verb == 'delete') then
        state.sets    = {};
        state.assigns = {};
    elseif (verb == 'presets') then
        state.presets = {};
    elseif (verb == 'export') then
        state.codes = {};
    elseif (verb == 'hints') then
        state.hints = {};
    elseif (verb == 'party') then
        -- Only the listing: every party envelope opens with the full y|
        -- stream (dwg_protocol.md), while its a| records cover just the rows
        -- a `use` actually wrote -- resetting assigns here would blank the
        -- characters a load deliberately skipped.
        state.loadouts = {};
    end

    local doc      = nil;
    local lastDoc  = nil;
    local vocabPage = nil;

    for _, parts in ipairs(records) do
        local kind = parts[1];

        if (kind == 's') then
            doc     = parseSetRecord(parts);
            lastDoc = doc;

            if (doc.setid ~= 0) then
                state.sets[doc.setid] = doc;
            end
        elseif (kind == 'r') then
            if (doc ~= nil) then
                table.insert(doc.rules, parseRuleRecord(parts));
            end
        elseif (kind == 'k') then
            local charid  = tonumber(parts[2]) or 0;
            local ordinal = tonumber(parts[3]) or 0;

            if (charid == 0) then
                if (doc ~= nil) then
                    doc.verdicts[ordinal] = parts[4];
                end
            else
                local entry = state.verdicts[charid];

                if (entry ~= nil) then
                    entry.list[ordinal] = parts[4];
                end
            end
        elseif (kind == 'c') then
            local member = {
                charid     = tonumber(parts[2]) or 0,
                name       = parts[3],
                job        = tonumber(parts[4]) or 0,
                lvl        = tonumber(parts[5]) or 0,
                setid      = tonumber(parts[6]) or 0,
                presetid   = tonumber(parts[7]) or 0,
                installed  = tonumber(parts[8]) or -1,
                considered = tonumber(parts[9]) or -1,
                capped     = parts[10] == '1',
            };

            if (state.members[member.charid] == nil) then
                table.insert(state.memberOrder, member.charid);
            end

            state.members[member.charid] = member;

            if (VERDICT_VERBS[verb]) then
                state.verdicts[member.charid] = { setid = member.setid, presetid = member.presetid, list = {} };
            else
                -- The bare listing measured nothing; old verdicts stand
                -- unless the member is visibly on a different set now.
                local entry = state.verdicts[member.charid];

                if (entry ~= nil and (entry.setid ~= member.setid or entry.presetid ~= member.presetid)) then
                    state.verdicts[member.charid] = nil;
                end
            end
        elseif (kind == 'a') then
            local entry = {
                charid = tonumber(parts[2]) or 0,
                name   = parts[3],
                job    = tonumber(parts[4]) or 0,
                kind   = parts[5],
                setid  = tonumber(parts[6]) or 0,
                ref    = parts[7],
            };

            state.assigns[entry.charid .. ':' .. entry.job] = entry;
        elseif (kind == 'p') then
            table.insert(state.presets, {
                name    = parts[2],
                id      = tonumber(parts[3]) or 0,
                count   = tonumber(parts[4]) or 0,
                summary = parts[5],
            });
        elseif (kind == 'y') then
            table.insert(state.loadouts, {
                name    = parts[2],
                members = tonumber(parts[3]) or 0,
                rows    = tonumber(parts[4]) or 0,
            });
        elseif (kind == 'x') then
            -- Stored at its part number rather than appended: parts arrive in
            -- order today and a code assembled out of order would be a code
            -- that looks right and is not.
            state.codes[tonumber(parts[2]) or 1] = parts[4];
        elseif (kind == 'h') then
            -- An upgrade hint (dwg_protocol.md): the finished sentence plus
            -- the fields that let this renderer label it without parsing
            -- prose. Arrival order is the server's rank order and is kept.
            local charid = tonumber(parts[2]) or 0;

            state.hints[charid] = state.hints[charid] or {};

            table.insert(state.hints[charid], {
                kind     = parts[3],
                ordinal  = tonumber(parts[4]) or 0,
                distance = tonumber(parts[5]) or 0,
                command  = (parts[6] ~= nil and parts[6] ~= '-' and parts[6] ~= '') and parts[6] or nil,
                text     = parts[7] or '',
            });
        elseif (kind == 'g') then
            vocabPage = {
                page    = tonumber(parts[2]) or 1,
                pages   = tonumber(parts[3]) or 1,
                version = tonumber(parts[4]) or 0,
                rows    = {},
            };
        elseif (kind == 'v') then
            if (vocabPage ~= nil) then
                table.insert(vocabPage.rows, parts);
            end
        end
    end

    -- The vocabulary pages assemble into one whitelist; a version change mid
    -- flight (or against the copy in use) restarts from nothing, because half
    -- of one vocabulary and half of another is worse than a second of delay.
    if (vocabPage ~= nil) then
        if (vocab ~= nil and vocab.version ~= vocabPage.version) then
            vocab = nil;
        end

        if (vocabWork == nil or vocabWork.version ~= vocabPage.version) then
            vocabWork = { version = vocabPage.version, pages = vocabPage.pages, got = {}, rows = {} };
        end

        vocabWork.pages = vocabPage.pages;

        if (not vocabWork.got[vocabPage.page]) then
            vocabWork.got[vocabPage.page]  = true;
            vocabWork.rows[vocabPage.page] = vocabPage.rows;
        end

        local complete = true;

        for page = 1, vocabWork.pages do
            if (not vocabWork.got[page]) then
                complete = false;

                break;
            end
        end

        -- The render loop drives the next page (needVocab): asking here as
        -- well would race the tracker and re-request pages already staged.
        if (complete) then
            buildVocab(vocabWork);
        end
    end

    -- Document adoption. Three ways a doc can be "the one on screen": it is
    -- the one a click just asked for, it carries the name being edited, or it
    -- carries the setid being edited (which is how a rename typed outside the
    -- window follows into the title).
    if (lastDoc ~= nil and DOC_VERBS[verb]) then
        local docName = string.lower(lastDoc.name or '');

        if (editor.pendingRef ~= nil and docName == string.lower(editor.pendingRef)) then
            editor.pendingRef = nil;
            editor.touched    = false;
            adoptDoc(lastDoc);
        elseif (editor.name ~= nil and docName == string.lower(editor.name)) then
            adoptDoc(lastDoc);
        elseif (editor.setid ~= 0 and lastDoc.setid == editor.setid) then
            adoptDoc(lastDoc);
        end
    end

    -- A deleted set (this UI's own Delete button, or typed outside the
    -- window) must not stay on screen as editable.
    if (verb == 'delete' and editor.setid ~= 0 and state.sets[editor.setid] == nil) then
        editor.name      = nil;
        editor.setid     = 0;
        editor.doc       = nil;
        editor.server    = nil;
        editor.touched   = false;
        editor.armDelete = 0;
    end

    if (planWait ~= nil and planWait.verb == verb) then
        finishPlanStep();
    end

    -- A response that can change what a member is running -- or how well the
    -- set fits it -- makes the hint strip stale, so the next frame re-asks.
    -- `show` is deliberately not here: loading a document changes nothing
    -- about anybody, and hints per set-load would be a command per click.
    if (verb == 'use' or verb == 'add' or verb == 'del' or verb == 'move'
            or verb == 'posture' or verb == 'report') then
        requested['hints'] = nil;
    end

    answered(verb);
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwgambits.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- A d| envelope IS the answer, whatever version it announced, and
            -- re-asking a server that speaks a layout this addon cannot read
            -- cannot help. One shape across the suite (dwfame, 2026-08-15);
            -- gated in harness_dwsuite.py.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.inbound = parts[3];
        state.buffer  = {};

        return;
    end

    -- Status lines land whatever the envelope state -- they are the one thing
    -- a player must never lose -- and a refusal mid-save stops the plan
    -- before the next step can compound it.
    if (kind == 'm' or kind == 'e') then
        -- The one refusal that is not worth a red banner: a server from
        -- before the hint tier answering `!dwg hints` with its unknown-verb
        -- sentence. That means hints do not exist here yet, so the addon
        -- stops asking and renders nothing -- deployment order must not
        -- matter in either direction (UPGRADE_HINTS_PLAN.md Phase 3).
        if (kind == 'e' and not hintsUnsupported
                and string.find(line, 'no rules subcommand called "hints"', 1, true) ~= nil) then
            hintsUnsupported = true;

            return;
        end

        -- Its twin for the party-preset tier: an older server has no `party`
        -- verb, so the Party tab goes quiet instead of red. The tab renders
        -- the explanation itself.
        if (kind == 'e' and not partyUnsupported
                and string.find(line, 'no rules subcommand called "party"', 1, true) ~= nil) then
            partyUnsupported = true;

            return;
        end

        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwgambits'):append(chat.error(state.status)));

            if (#plan > 0 or planWait ~= nil) then
                local refusedNew = (planWait ~= nil and planWait.verb == 'new'
                    and editor.saveFallback ~= nil);

                abortPlan(state.status);

                editor.saving     = false;
                editor.pendingRef = nil;

                -- A refused `new` rolls the Save-as identity change back:
                -- left pointed at the refused name, the re-show below would
                -- adopt the PRE-EXISTING set of that name and the next Save
                -- would overwrite it (see beginSave's fallback comment).
                if (refusedNew) then
                    local fallback = editor.saveFallback;

                    editor.saveFallback = nil;
                    editor.name    = fallback.name;
                    editor.setid   = fallback.setid;
                    editor.shipped = fallback.shipped;
                    editor.server  = fallback.server;
                end

                -- What actually landed is the only trustworthy ground to
                -- retry from, so the server copy is re-fetched -- with
                -- pendingRef left nil, so the arriving document refreshes
                -- editor.server without clobbering the player's unsaved side.
                if (editor.name ~= nil) then
                    requested['show'] = nil;
                    need('show', string.lower(editor.name), string.format('!dwg show "%s"', editor.name));
                end
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local verb    = state.inbound;
        local records = state.buffer;

        state.inbound = nil;
        state.buffer  = {};

        processEnvelope(verb, records);

        return;
    end

    table.insert(state.buffer, parts);
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWGDATA is ours: consumed and blocked before parsing, so a
* malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwgambits_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwgambits'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering.
--]]

-- Per-widget scratch: combo filter text and the pending-name input boxes.
-- PLAIN tables -- these are keyed by strings the code chooses and T{}'s sugar
-- metatable answers unknown string keys with functions.
local filters   = {};
local nameBoxes = {};

local function filterOf(id)
    if (filters[id] == nil) then
        filters[id] = T{ '' };
    end

    return filters[id];
end

local function nameBoxOf(id)
    if (nameBoxes[id] == nil) then
        nameBoxes[id] = T{ '' };
    end

    return nameBoxes[id];
end

local function tooltipOnHover(text)
    if (text ~= nil and text ~= '' and imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

-- A dropdown over { {id/key, label, note} } entries. Returns the newly
-- selected entry or nil. `current` is compared against `value(entry)`.
local function pickCombo(id, width, currentLabel, entries, isCurrent)
    local chosen = nil;

    imgui.PushItemWidth(width);

    if (imgui.BeginCombo(id, currentLabel)) then
        for index, entry in ipairs(entries) do
            if (imgui.Selectable(string.format('%s##%s_%d', entry.label, id, index), isCurrent(entry))) then
                chosen = entry;
            end

            tooltipOnHover(entry.note);
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    return chosen;
end

-- The same, with a filter box on top -- for the spell and ability lists,
-- which run to hundreds of names.
local function pickComboFiltered(id, width, currentLabel, entries, isCurrent)
    local chosen = nil;

    imgui.PushItemWidth(width);

    if (imgui.BeginCombo(id, currentLabel)) then
        local filter = filterOf(id);

        imgui.PushItemWidth(150);
        imgui.InputText('##filter_' .. id, filter, 32);
        imgui.PopItemWidth();

        local needle = string.lower(filter[1] or '');

        for index, entry in ipairs(entries) do
            if (needle == '' or string.find(string.lower(entry.label), needle, 1, true) ~= nil) then
                if (imgui.Selectable(string.format('%s##%s_%d', entry.label, id, index), isCurrent(entry))) then
                    chosen = entry;
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    return chosen;
end

local function markTouched()
    editor.touched = true;
end

-- One page of the whitelist at a time, in order, driven from the render loop
-- so the answer tracker holds exactly one outstanding page and a lost one is
-- re-asked on its own timeout rather than restarting the fetch.
local function needVocab()
    if (vocab ~= nil) then
        return;
    end

    if (vocabWork == nil) then
        need('vocab', 1, '!dwg vocab');

        return;
    end

    for page = 1, vocabWork.pages do
        if (not vocabWork.got[page]) then
            need('vocab', page, page == 1 and '!dwg vocab' or string.format('!dwg vocab %d', page));

            return;
        end
    end
end

-- What a character (live or at home) is running or assigned, as one line.
local function assignedLabel(charid)
    local base   = state.assigns[charid .. ':0'];
    local extras = 0;

    for key, entry in pairs(state.assigns) do
        if (entry.charid == charid and entry.job ~= 0) then
            extras = extras + 1;
        end
    end

    local label;

    if (base ~= nil and base.kind == 'set') then
        label = base.ref;
    elseif (base ~= nil and base.kind == 'preset') then
        label = string.match(base.ref, '^preset:(.+)$') or base.ref;
    else
        label = 'automatic';
    end

    if (extras > 0) then
        label = string.format('%s (+%d per-job)', label, extras);
    end

    return label;
end

local function runningLabel(member)
    if (member.setid ~= 0) then
        local set = state.sets[member.setid];

        return set ~= nil and set.name or string.format('set #%d', member.setid);
    end

    for _, preset in ipairs(state.presets) do
        if (preset.id == member.presetid) then
            return preset.name;
        end
    end

    return 'profile';
end

local function tryLoadFor(charid)
    if (editor.touched) then
        state.status    = 'Save or revert your edits before switching sets.';
        state.statusBad = true;

        return;
    end

    local member = state.members[charid];

    if (member ~= nil and member.setid ~= 0) then
        local set = state.sets[member.setid];

        if (set ~= nil) then
            loadIntoEditor(set.name);
        end

        return;
    end

    if (member ~= nil and member.presetid ~= 0) then
        local label = runningLabel(member);

        if (label ~= 'profile') then
            loadIntoEditor(label);
        end

        return;
    end

    local base = state.assigns[charid .. ':0'];

    if (base ~= nil and base.kind ~= 'none' and base.ref ~= '') then
        loadIntoEditor(base.ref);
    end
end

--[[
* The hints strip: one compact line per summoned member with hints, chips
* derived from the record's FIELDS -- `kind` and `distance` exist on the wire
* precisely so a client can label a hint without parsing its prose
* (dwg_protocol.md) -- and the finished sentences, verbatim, on the hover.
--]]
local HINT_STRIP_CHIPS   = 3;
local HINT_TOOLTIP_LINES = 8;

local function hintChip(hint)
    if (hint.kind == 'learn') then
        return 'scroll';
    elseif (hint.kind == 'fit') then
        return 'set';
    elseif (hint.kind == 'sub') then
        return string.format('sub %dlv', hint.distance);
    elseif (hint.kind == 'tier') then
        return string.format('tier %dlv', hint.distance);
    end

    -- `level` and `abil` are both a number of main-job levels away.
    return string.format('%dlv', hint.distance);
end

local function hintStrip(list)
    local chips = {};

    for index = 1, math.min(#list, HINT_STRIP_CHIPS) do
        table.insert(chips, hintChip(list[index]));
    end

    local text = table.concat(chips, ', ');

    if (#list > HINT_STRIP_CHIPS) then
        text = string.format('%s +%d', text, #list - HINT_STRIP_CHIPS);
    end

    return text;
end

local function hintTooltip(name, list)
    local lines = {};

    for index = 1, math.min(#list, HINT_TOOLTIP_LINES) do
        local hint = list[index];

        table.insert(lines, hint.text);

        if (hint.command ~= nil) then
            table.insert(lines, '  ' .. hint.command);
        end
    end

    if (#list > HINT_TOOLTIP_LINES) then
        table.insert(lines, string.format('...and %d more -- !squad hints %s lists everything.',
            #list - HINT_TOOLTIP_LINES, name));
    end

    return table.concat(lines, '\n');
end

local function leftPane()
    imgui.BeginChild('##dwg_chars', { 205, 0 }, ImGuiChildFlags_Borders);

    imgui.TextDisabled('Squad -- out now');

    if (#state.memberOrder == 0) then
        imgui.Text('  (nobody summoned)');
    end

    -- Asked from the pane that draws the answer, like every other read.
    -- Only with members out: hints are about running sets, and `!dwg hints`
    -- on an empty squad is a refusal nobody needs to see every frame.
    if (not hintsUnsupported and #state.memberOrder > 0) then
        need('hints', 0, '!dwg hints');
    end

    for _, charid in ipairs(state.memberOrder) do
        local member = state.members[charid];

        if (member ~= nil) then
            local label = string.format('%s (%s%d)##m%d', member.name,
                JOB_NAMES[member.job] or '?', member.lvl, charid);

            if (imgui.Selectable(label, state.selected == charid)) then
                state.selected = charid;
                state.assignTo = member.name;

                tryLoadFor(charid);
            end

            local counts = '';

            if (member.installed >= 0) then
                counts = string.format('  %d/%d live', member.installed, member.considered);
            end

            imgui.TextDisabled(string.format('   > %s%s', runningLabel(member), counts));

            local hintList = state.hints[charid];

            if (hintList ~= nil and #hintList > 0) then
                imgui.TextColored(COLOR_HINT, string.format('   ^ %s', hintStrip(hintList)));
                tooltipOnHover(hintTooltip(member.name, hintList));
            end
        end
    end

    imgui.Separator();
    imgui.TextDisabled('At home');

    -- Every account character the a| stream named, minus the ones standing in
    -- the world above.
    local out = {};

    for _, charid in ipairs(state.memberOrder) do
        local member = state.members[charid];

        if (member ~= nil) then
            out[string.lower(member.name)] = true;
        end
    end

    local home = {};
    local seen = {};

    for _, entry in pairs(state.assigns) do
        if (not seen[entry.charid] and not out[string.lower(entry.name)]) then
            seen[entry.charid] = true;

            table.insert(home, entry);
        end
    end

    table.sort(home, function (a, b) return a.name < b.name; end);

    for _, entry in ipairs(home) do
        if (imgui.Selectable(string.format('%s##h%d', entry.name, entry.charid), state.selected == entry.charid)) then
            state.selected = entry.charid;
            state.assignTo = entry.name;

            tryLoadFor(entry.charid);
        end

        imgui.TextDisabled(string.format('   > %s', assignedLabel(entry.charid)));
    end

    imgui.EndChild();
end

-- The Assign target dropdown: live members, then everyone at home, then the
-- whole squad at once.
local function assignTargets()
    local targets = {};
    local seen    = {};

    for _, charid in ipairs(state.memberOrder) do
        local member = state.members[charid];

        if (member ~= nil and not seen[string.lower(member.name)]) then
            seen[string.lower(member.name)] = true;

            table.insert(targets, { key = member.name, label = string.format('%s (out)', member.name) });
        end
    end

    local home = {};

    for _, entry in pairs(state.assigns) do
        if (not seen[string.lower(entry.name)]) then
            seen[string.lower(entry.name)] = true;

            table.insert(home, { key = entry.name, label = entry.name });
        end
    end

    table.sort(home, function (a, b) return a.label < b.label; end);

    for _, entry in ipairs(home) do
        table.insert(targets, entry);
    end

    table.insert(targets, { key = 'all', label = 'the whole squad' });

    return targets;
end

local function assignControls(id, ref)
    local targets = assignTargets();
    local current = state.assignTo or (targets[1] ~= nil and targets[1].key or nil);

    state.assignTo = current;

    local currentLabel = current or '(pick one)';

    for _, entry in ipairs(targets) do
        if (entry.key == current) then
            currentLabel = entry.label;
        end
    end

    local picked = pickCombo('##assign_' .. id, 150, currentLabel, targets,
        function (entry) return entry.key == current; end);

    if (picked ~= nil) then
        state.assignTo = picked.key;
    end

    imgui.SameLine();

    if (imgui.Button('Assign##' .. id)) then
        if (state.assignTo ~= nil and ref ~= nil) then
            startPlan({ string.format('!dwg use %s "%s"', state.assignTo, ref) },
                string.format('Assigning %s...', ref));
        end
    end

    tooltipOnHover('The same thing as: !squad rules use <who> <set>');
end

--[[
* One rule row of the editor table. Everything writes into the local document
* and nothing but Save talks to the server.
--]]
local function conditionCell(rule, row, locked)
    if (locked) then
        -- A canned pairing owns its condition; showing a dropdown would offer
        -- a choice the grammar will refuse.
        imgui.TextDisabled('(built into the pairing)');

        return;
    end

    local entry = vocab.conditionById[rule.cond1];
    local label = entry ~= nil and entry.label or string.format('#%d', rule.cond1);

    local picked = pickCombo(string.format('##cond1_%d', row), 150, label, vocab.conditions,
        function (candidate) return entry ~= nil and candidate.id == entry.id; end);

    if (picked ~= nil and (entry == nil or picked.id ~= entry.id)) then
        rule.cond1 = picked.id;
        rule.arg1  = picked.arg.kind == 'number' and picked.arg.min or 0;

        if (picked.arg.kind == 'pick') then
            local list = vocab.pickers[picked.arg.picker];

            rule.arg1 = list ~= nil and list[1] ~= nil and list[1].id or 0;
        end

        -- A solo condition is a whole rule's worth of When on its own -- the
        -- timer's clock is spent by evaluation, not firing, and the server
        -- would refuse the pair anyway. Dropping the second half here is the
        -- refusal the player never has to read.
        if (picked.solo) then
            rule.cond2 = NO_CONDITION;
        end

        markTouched();
    end

    entry = vocab.conditionById[rule.cond1];

    -- The argument widget, shaped by the condition's declared domain.
    if (entry ~= nil and entry.arg.kind == 'number') then
        imgui.SameLine();

        local buffer = T{ rule.arg1 };

        imgui.PushItemWidth(70);

        if (imgui.InputInt(string.format('##arg1_%d', row), buffer, 0, 0)) then
            local value = math.floor(tonumber(buffer[1]) or entry.arg.min);

            rule.arg1 = math.max(math.min(value, entry.arg.max), entry.arg.min);

            markTouched();
        end

        imgui.PopItemWidth();
        tooltipOnHover(string.format('%d to %d%s', entry.arg.min, entry.arg.max, entry.arg.unit or ''));
    elseif (entry ~= nil and entry.arg.kind == 'pick') then
        imgui.SameLine();

        local list = vocab.pickers[entry.arg.picker] or {};
        local byId = vocab.pickerById[entry.arg.picker] or {};
        local hit  = byId[rule.arg1];

        local picked2 = pickCombo(string.format('##arg1p_%d', row), 120,
            hit ~= nil and hit.label or '(pick)', list,
            function (candidate) return candidate.id == rule.arg1; end);

        if (picked2 ~= nil) then
            rule.arg1 = picked2.id;

            markTouched();
        end
    end

    -- The second condition: present when the sentinel says so, offered when
    -- the first condition may share a rule at all.
    if (rule.cond2 ~= NO_CONDITION) then
        local logic  = vocab.logicById[rule.logic];
        local picked3 = pickCombo(string.format('##logic_%d', row), 55,
            logic ~= nil and logic.key or 'and', vocab.logic,
            function (candidate) return logic ~= nil and candidate.id == logic.id; end);

        if (picked3 ~= nil) then
            rule.logic = picked3.id;

            markTouched();
        end

        imgui.SameLine();

        local second = vocab.conditionById[rule.cond2];

        -- Solo conditions are excluded from the second slot for the same
        -- reason they clear it from the first.
        local eligible = {};

        for _, candidate in ipairs(vocab.conditions) do
            if (not candidate.solo) then
                table.insert(eligible, candidate);
            end
        end

        local picked4 = pickCombo(string.format('##cond2_%d', row), 150,
            second ~= nil and second.label or string.format('#%d', rule.cond2), eligible,
            function (candidate) return second ~= nil and candidate.id == second.id; end);

        if (picked4 ~= nil and (second == nil or picked4.id ~= second.id)) then
            rule.cond2 = picked4.id;
            rule.arg2  = picked4.arg.kind == 'number' and picked4.arg.min or 0;

            if (picked4.arg.kind == 'pick') then
                local list = vocab.pickers[picked4.arg.picker];

                rule.arg2 = list ~= nil and list[1] ~= nil and list[1].id or 0;
            end

            markTouched();
        end

        second = vocab.conditionById[rule.cond2];

        if (second ~= nil and second.arg.kind == 'number') then
            imgui.SameLine();

            local buffer = T{ rule.arg2 };

            imgui.PushItemWidth(70);

            if (imgui.InputInt(string.format('##arg2_%d', row), buffer, 0, 0)) then
                local value = math.floor(tonumber(buffer[1]) or second.arg.min);

                rule.arg2 = math.max(math.min(value, second.arg.max), second.arg.min);

                markTouched();
            end

            imgui.PopItemWidth();
        elseif (second ~= nil and second.arg.kind == 'pick') then
            imgui.SameLine();

            local list = vocab.pickers[second.arg.picker] or {};
            local byId = vocab.pickerById[second.arg.picker] or {};
            local hit  = byId[rule.arg2];

            local picked5 = pickCombo(string.format('##arg2p_%d', row), 120,
                hit ~= nil and hit.label or '(pick)', list,
                function (candidate) return candidate.id == rule.arg2; end);

            if (picked5 ~= nil) then
                rule.arg2 = picked5.id;

                markTouched();
            end
        end

        imgui.SameLine();

        if (imgui.SmallButton(string.format('x##nocond2_%d', row))) then
            rule.cond2 = NO_CONDITION;
            rule.arg2  = 0;

            markTouched();
        end

        tooltipOnHover('Drop the second condition.');
    else
        local first = vocab.conditionById[rule.cond1];

        if (first == nil or not first.solo) then
            imgui.SameLine();

            if (imgui.SmallButton(string.format('+##addcond_%d', row))) then
                rule.logic = vocab.logic[1] ~= nil and vocab.logic[1].id or 0;

                -- The first non-solo condition is the sane blank.
                for _, candidate in ipairs(vocab.conditions) do
                    if (not candidate.solo) then
                        rule.cond2 = candidate.id;
                        rule.arg2  = candidate.arg.kind == 'number' and candidate.arg.min or 0;

                        break;
                    end
                end

                markTouched();
            end

            tooltipOnHover('Add a second condition, joined by and/or.');
        end
    end
end

local function actionCell(rule, row)
    local kind   = kindOf(rule);
    local picked = pickCombo(string.format('##kind_%d', row), 175,
        kind ~= nil and kind.label or string.format('engine %d/%d', rule.reaction, rule.selector),
        vocab.kinds,
        function (candidate) return kind ~= nil and candidate.reaction == kind.reaction and candidate.selector == kind.selector; end);

    if (picked ~= nil and (kind == nil or picked.reaction ~= kind.reaction or picked.selector ~= kind.selector)) then
        rule.reaction = picked.reaction;
        rule.selector = picked.selector;
        rule.actionid = 0;

        if (picked.canned ~= nil) then
            rule.actionid = picked.actionid;

            -- A pairing that carries its own condition takes the rule's When
            -- with it -- stored exactly as the server will store it, so the
            -- diff sees the same rule the read-back will contain.
            if (picked.pinned ~= nil) then
                rule.cond1 = picked.pinned;
                rule.arg1  = 0;
                rule.cond2 = NO_CONDITION;
                rule.arg2  = 0;
                rule.logic = 0;
            end
        elseif (picked.arg.kind == 'pick') then
            local list = vocab.pickers[picked.arg.picker];

            rule.actionid = list ~= nil and list[1] ~= nil and list[1].id or 0;
        end

        markTouched();
    end

    if (kind ~= nil and kind.canned ~= nil) then
        tooltipOnHover(kind.canned.note);
    end

    kind = kindOf(rule);

    if (kind == nil) then
        return;
    end

    if (kind.arg.kind == 'pick') then
        imgui.SameLine();

        local list = vocab.pickers[kind.arg.picker] or {};
        local byId = vocab.pickerById[kind.arg.picker] or {};
        local hit  = byId[rule.actionid];

        local pickedArg = pickCombo(string.format('##act_%d', row), 130,
            hit ~= nil and hit.label or '(pick)', list,
            function (candidate) return candidate.id == rule.actionid; end);

        if (pickedArg ~= nil) then
            rule.actionid = pickedArg.id;

            markTouched();
        end
    elseif (kind.arg.kind == 'action') then
        imgui.SameLine();

        local resource = kind.reactionKey == 'ability' and 'ability' or 'spell';
        local current;

        -- Split for the third time, same reason: an ability id this client
        -- has no name for must read as '(pick)', never as a spell that
        -- happens to share the number.
        if (rule.actionid ~= 0) then
            if (resource == 'ability') then
                current = abilityName(rule.actionid);
            else
                current = spellName(rule.actionid);
            end
        end

        local pickedArg = pickComboFiltered(string.format('##act_%d', row), 150,
            current or '(pick)', actionList(resource),
            function (candidate) return candidate.id == rule.actionid; end);

        if (pickedArg ~= nil) then
            rule.actionid = pickedArg.id;

            markTouched();
        end
    end
end

-- The reason this ordinal is doing nothing, if anybody said so: the set's own
-- verdict (a rule the vocabulary would refuse today), or the selected
-- member's -- filtered by selection, because a verdict about a member the
-- player clicked away from belongs to that member, not to this pane.
local function inertReason(rule)
    if (rule.srv == nil) then
        return nil;
    end

    if (editor.server ~= nil and editor.server.verdicts[rule.srv] ~= nil) then
        return editor.server.verdicts[rule.srv];
    end

    local member = state.selected ~= nil and state.members[state.selected] or nil;

    if (member == nil) then
        return nil;
    end

    local verdicts = state.verdicts[member.charid];

    if (verdicts == nil or verdicts.list[rule.srv] == nil) then
        return nil;
    end

    -- Only if that member is actually running this document.
    if (editor.setid ~= 0 and verdicts.setid == editor.setid) then
        return verdicts.list[rule.srv];
    end

    return nil;
end

-- What the selected member's hints add to an inert rule's hover: the
-- what-it-would-take sentences whose ordinal is this rule's server ordinal.
-- Gated exactly as inertReason gates a member verdict -- the hints describe
-- the member's RUNNING set, so they only belong on this row when that member
-- is running this document.
local function inertHints(rule)
    if (rule.srv == nil) then
        return nil;
    end

    local member = state.selected ~= nil and state.members[state.selected] or nil;

    if (member == nil) then
        return nil;
    end

    local verdicts = state.verdicts[member.charid];

    if (verdicts == nil or editor.setid == 0 or verdicts.setid ~= editor.setid) then
        return nil;
    end

    local hintList = state.hints[member.charid];

    if (hintList == nil) then
        return nil;
    end

    local lines = {};

    for _, hint in ipairs(hintList) do
        if (hint.ordinal == rule.srv) then
            table.insert(lines, hint.text);
        end
    end

    if (#lines == 0) then
        return nil;
    end

    return table.concat(lines, '\n');
end

local function ruleTable()
    local doc = editor.doc;

    -- The toggle latch (1.4): the server that appended aoews to s| also
    -- speaks `toggle` and the r| on/off field, so its presence is the one
    -- honest test for whether the switch column may do anything. Rendered
    -- always (a conditional column count reshuffles ImGui's layout ids);
    -- the cell just stays empty against an older server.
    local speaksToggles = editor.server ~= nil and editor.server.posture ~= nil
        and editor.server.posture.aoews ~= nil;

    if (imgui.BeginTable('##dwg_rules', 7,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -80 })) then
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 26, 0);
        imgui.TableSetupColumn('On', ImGuiTableColumnFlags_WidthFixed, 30, 0);
        imgui.TableSetupColumn('Who', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, 320, 0);
        imgui.TableSetupColumn('Do', ImGuiTableColumnFlags_WidthFixed, 320, 0);
        imgui.TableSetupColumn('Retry', ImGuiTableColumnFlags_WidthFixed, 58, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 76, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        local moveUp, moveDown, remove = nil, nil, nil;

        for row, rule in ipairs(doc.rules) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            local off    = rule.enabled == false;
            local reason = inertReason(rule);

            if (off) then
                -- Off outranks inert in the margin: an inert verdict is
                -- about a rule that is trying, and this one is not.
                imgui.TextColored(COLOR_INERT, string.format('%d.', row));
                tooltipOnHover('Switched off -- the member ignores this rule until it is switched back on.');
            elseif (reason ~= nil) then
                imgui.TextColored(COLOR_INERT, string.format('%d!', row));

                -- The reason says why it is doing nothing; the hint lines say
                -- what it would take and how far away that is.
                local extra = inertHints(rule);

                tooltipOnHover(extra ~= nil and (reason .. '\n\n' .. extra) or reason);
            else
                imgui.Text(string.format('%d', row));

                -- Order is priority: the engine reads top down and an earlier
                -- rule starves a later one.
                tooltipOnHover('Rules are read top down; an earlier rule beats a later one.');
            end

            imgui.TableNextColumn();

            if (speaksToggles) then
                local on = T{ not off };

                if (imgui.Checkbox(string.format('##on_%d', row), on)) then
                    rule.enabled = on[1];

                    markTouched();
                end

                tooltipOnHover('Off keeps the rule in the set without running it -- no more deleting and retyping. Save applies it.');
            end

            imgui.TableNextColumn();

            local target = vocab.targetById[rule.target];
            local pickedTarget = pickCombo(string.format('##target_%d', row), 100,
                target ~= nil and target.label or string.format('#%d', rule.target), vocab.targets,
                function (candidate) return target ~= nil and candidate.id == target.id; end);

            if (pickedTarget ~= nil and (target == nil or pickedTarget.id ~= target.id)) then
                rule.target = pickedTarget.id;

                markTouched();
            end

            imgui.TableNextColumn();

            local kind = kindOf(rule);

            conditionCell(rule, row, kind ~= nil and kind.pinned ~= nil);

            imgui.TableNextColumn();

            actionCell(rule, row);

            imgui.TableNextColumn();

            local buffer = T{ rule.retry };

            imgui.PushItemWidth(48);

            if (imgui.InputInt(string.format('##retry_%d', row), buffer, 0, 0)) then
                local value = math.floor(tonumber(buffer[1]) or 0);

                rule.retry = math.max(math.min(value, vocab.caps.retryMax), 0);

                markTouched();
            end

            imgui.PopItemWidth();
            tooltipOnHover(string.format('Seconds to wait after this rule fires before it may fire again. 0 to %d.', vocab.caps.retryMax));

            imgui.TableNextColumn();

            if (row > 1) then
                if (imgui.SmallButton(string.format('^##up_%d', row))) then
                    moveUp = row;
                end

                imgui.SameLine();
            end

            if (row < #doc.rules) then
                if (imgui.SmallButton(string.format('v##dn_%d', row))) then
                    moveDown = row;
                end

                imgui.SameLine();
            end

            if (imgui.SmallButton(string.format('x##del_%d', row))) then
                remove = row;
            end
        end

        imgui.EndTable();

        -- Applied after the loop: mutating the list mid-iteration renders one
        -- frame from two different documents.
        if (moveUp ~= nil) then
            table.insert(doc.rules, moveUp - 1, table.remove(doc.rules, moveUp));

            markTouched();
        elseif (moveDown ~= nil) then
            table.insert(doc.rules, moveDown + 1, table.remove(doc.rules, moveDown));

            markTouched();
        elseif (remove ~= nil) then
            table.remove(doc.rules, remove);

            markTouched();
        end
    end
end

local function postureBlock()
    local doc = editor.doc;

    local function optionCombo(field, listName, id, width)
        local list    = vocab.posture[listName] or {};
        local current = nil;

        for _, option in ipairs(list) do
            if (option.id == doc.posture[field]) then
                current = option;
            end
        end

        local picked = pickCombo(id, width, current ~= nil and current.label or '(?)', list,
            function (candidate) return current ~= nil and candidate.id == current.id; end);

        if (picked ~= nil and (current == nil or picked.id ~= current.id)) then
            doc.posture[field] = picked.id;

            markTouched();
        end
    end

    imgui.Text('Swing');
    imgui.SameLine();
    optionCombo('autoattack', 'swing', '##po_swing', 170);
    imgui.SameLine();
    imgui.Text('Stance');
    imgui.SameLine();
    optionCombo('movement', 'stance', '##po_stance', 140);
    imgui.SameLine();

    local spendtp = T{ doc.posture.spendtp };

    if (imgui.Checkbox('Spend TP##po_tp', spendtp)) then
        doc.posture.spendtp = spendtp[1];

        markTouched();
    end

    tooltipOnHover('Off is the only honest "do not use weapon skills": the engine spends a full bar before it reads a single rule.');

    imgui.SameLine();

    local hold = T{ doc.posture.hold };

    if (imgui.Checkbox('Hold position##po_hold', hold)) then
        doc.posture.hold = hold[1];

        markTouched();
    end

    tooltipOnHover('On means the member never engages by itself.');

    -- The AoE switch (1.4). Latched on the field's presence: a server that
    -- never sends it does not speak `posture aoews` either, and a checkbox
    -- that saves into a refusal is worse than no checkbox.
    if (doc.posture.aoews ~= nil) then
        imgui.SameLine();

        local aoe = T{ doc.posture.aoews };

        if (imgui.Checkbox('Allow AoE WS##po_aoews', aoe)) then
            doc.posture.aoews = aoe[1];

            markTouched();
        end

        tooltipOnHover('Off keeps every area weapon skill out of this member\'s TP spending, so it stops dragging bystanders into the fight.');
    end

    -- The song-burst switch (1.5), latched the same way on its own field.
    if (doc.posture.songburst ~= nil) then
        imgui.SameLine();

        local songburst = T{ doc.posture.songburst };

        if (imgui.Checkbox('Allow Song Burst##po_songburst', songburst)) then
            doc.posture.songburst = songburst[1];

            markTouched();
        end

        tooltipOnHover('Off keeps bard songs out of this member\'s magic bursts --\n'
            .. 'the burst-matching pick considers real nukes only. Rules that\n'
            .. 'name a song on purpose still fire.');
    end

    -- Bard Runs In (1.6), latched the same way on its own field.
    if (doc.posture.runin ~= nil) then
        imgui.SameLine();

        local runin = T{ doc.posture.runin };

        if (imgui.Checkbox('Bard Runs In##po_runin', runin)) then
            doc.posture.runin = runin[1];

            markTouched();
        end

        tooltipOnHover('On walks a bard to within a yalm of you before it sings, so\n'
            .. 'you are inside the song\'s radius. Off sings from where it stands --\n'
            .. 'this server already widens every party song to four times its\n'
            .. 'retail radius, so a bard that stays put usually still covers you.');
    end

    if (doc.posture.spendtp) then
        imgui.Text('TP when');
        imgui.SameLine();
        optionCombo('tptrigger', 'tpwhen', '##po_tpwhen', 210);
        imgui.SameLine();
        imgui.Text('using');
        imgui.SameLine();
        optionCombo('tpselect', 'tpuse', '##po_tpuse', 210);

        -- Hold amount (2026-08-06). 0 is "engine default" and anything else
        -- clamps into the server's band the moment it is typed -- the caps
        -- are v|h fields, never hardcoded.
        imgui.SameLine();
        imgui.Text('holding to');
        imgui.SameLine();

        local hold = T{ doc.posture.tphold or 0 };

        imgui.PushItemWidth(80);

        if (imgui.InputInt('##po_tphold', hold, 0, 0)) then
            local value = math.floor(tonumber(hold[1]) or 0);

            if (value <= 0) then
                value = 0;
            else
                value = math.max(math.min(value, vocab.caps.tpHoldMax), vocab.caps.tpHoldMin);
            end

            doc.posture.tphold = value;

            markTouched();
        end

        imgui.PopItemWidth();

        tooltipOnHover(string.format('0 uses the engine default. %d-%d is the amount "attp" spends at, "random" rolls from and "opener" waits for.',
            vocab.caps.tpHoldMin, vocab.caps.tpHoldMax));

        -- Manual WS Mode (1.6). It sits HERE, beside the TP amount, because
        -- that is what it is about -- and inside the Spend TP block on
        -- purpose: with Spend TP off there is no automatic weapon skill left
        -- to suppress, so the switch would be a control with nothing to do.
        if (doc.posture.manualws ~= nil) then
            imgui.SameLine();

            local manualws = T{ doc.posture.manualws };

            if (imgui.Checkbox('Manual WS Mode##po_manualws', manualws)) then
                doc.posture.manualws = manualws[1];

                markTouched();
            end

            tooltipOnHover('On empties the automatic weapon-skill list, so this member\n'
                .. 'holds its TP until a rule tells it to spend it. Add rules with\n'
                .. '"Use a weapon skill" to say when. Off is the automatic spender,\n'
                .. 'which fires before any rule is read and leaves a weapon-skill\n'
                .. 'rule no bar to work with.');
        end

        -- The weapon-skill picks (2026-08-06): ordered, first is the opener.
        -- The whole DAT list, not this character's -- a posture stores intent
        -- and the server reports what a member cannot use yet. Slots compact
        -- left on every edit so the order on screen is the order saved.
        imgui.Text('Weapon skills');
        imgui.SameLine();

        local picks   = doc.posture.tpskills or {};
        local edited  = false;
        local wsList  = actionList('ws');
        local slots   = math.min(#picks + 1, vocab.caps.tpSkillPicks);

        doc.posture.tpskills = picks;

        for slot = 1, slots do
            if (slot > 1) then
                imgui.SameLine();
            end

            local current = picks[slot];
            local label   = current ~= nil and weaponSkillName(current) or '(any)';

            -- '(any)' leads the list as the clear entry; picking it empties
            -- the slot and the compact pass below closes the gap.
            local entries = { { id = 0, label = '(any)' } };

            for _, entry in ipairs(wsList) do
                table.insert(entries, entry);
            end

            local picked = pickComboFiltered(string.format('##po_ws_%d', slot), 160, label, entries,
                function (candidate) return current ~= nil and candidate.id == current; end);

            if (picked ~= nil) then
                if (picked.id == 0) then
                    table.remove(picks, slot);
                else
                    -- The same skill twice is a server refusal; close the
                    -- duplicate here instead of after the save.
                    local dupe = nil;

                    for index, id in ipairs(picks) do
                        if (id == picked.id and index ~= slot) then
                            dupe = index;
                        end
                    end

                    if (dupe == nil) then
                        picks[slot] = picked.id;
                    end
                end

                edited = true;
            end
        end

        if (edited) then
            markTouched();
        end

        tooltipOnHover('Up to four, in order -- the first is what a full bar opens with. (any) lets the member choose from everything it knows.');

        -- The server's verdict on the picks (k| ordinal 0), shown only when
        -- the member selected in the left pane is actually running this set.
        local member = state.selected ~= nil and state.members[state.selected] or nil;

        if (member ~= nil and editor.setid ~= 0) then
            local verdicts = state.verdicts[member.charid];

            if (verdicts ~= nil and verdicts.setid == editor.setid and verdicts.list[0] ~= nil) then
                imgui.TextColored(COLOR_INERT, verdicts.list[0]);
            end
        end
    end
end

-- A read-only rendering of a shipped set: the composition as a document, gate
-- and all, with the way forward being a copy rather than an edit.
local function shippedView()
    imgui.TextColored(COLOR_BADGE, string.format('%s -- a shipped set. Copy it to make one you can edit.', editor.name));

    local doc = editor.server;

    if (imgui.BeginTable('##dwg_shipped', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -58 })) then
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 26, 0);
        imgui.TableSetupColumn('For', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Rule', ImGuiTableColumnFlags_WidthFixed, 560, 0);
        imgui.TableSetupColumn('Retry', ImGuiTableColumnFlags_WidthFixed, 50, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for row, rule in ipairs(doc.rules) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(string.format('%d', row));
            imgui.TableNextColumn();

            -- The role gate: which members of the composition receive this
            -- rule at all. Only shipped sets carry one.
            imgui.TextDisabled(rule.gate or 'all');

            imgui.TableNextColumn();

            local target = vocab.targetById[rule.target];
            local when   = conditionText(rule.cond1, rule.arg1);

            if (rule.cond2 ~= NO_CONDITION) then
                local logic = vocab.logicById[rule.logic];

                when = string.format('%s %s %s', when, logic ~= nil and logic.key or 'and', conditionText(rule.cond2, rule.arg2));
            end

            imgui.Text(string.format('%s: %s -> %s',
                target ~= nil and target.label or ('#' .. rule.target), when, actionText(rule)));

            imgui.TableNextColumn();
            imgui.Text(rule.retry > 0 and string.format('%ds', rule.retry) or '');
        end

        imgui.EndTable();
    end

    local nameBox = nameBoxOf('copyname');

    imgui.Text('Copy as');
    imgui.SameLine();
    imgui.PushItemWidth(160);
    imgui.InputText('##copyname', nameBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    imgui.SameLine();

    -- A shipped set is a composition; flattening it needs to know for WHOM.
    -- A summoned member names a role; with nobody out the server falls back
    -- to the player's own job and says so.
    local memberTags = { { key = '', label = '(my own job)' } };

    for _, charid in ipairs(state.memberOrder) do
        local member = state.members[charid];

        if (member ~= nil) then
            table.insert(memberTags, {
                key   = string.lower(JOB_NAMES[member.job] or ''),
                label = string.format('%s (%s)', member.name, JOB_NAMES[member.job] or '?'),
            });
        end
    end

    local flat = nameBoxOf('copyfor');
    local currentLabel = '(my own job)';

    for _, entry in ipairs(memberTags) do
        if (entry.key == flat[1]) then
            currentLabel = entry.label;
        end
    end

    local picked = pickCombo('##copyfor', 150, currentLabel, memberTags,
        function (entry) return entry.key == flat[1]; end);

    if (picked ~= nil) then
        flat[1] = picked.key;
    end

    imgui.SameLine();

    if (imgui.Button('Copy to editable##copybtn')) then
        local name = nameBox[1];

        if (validName(name)) then
            local command = string.format('!dwg copy "%s" %s', editor.name, name);

            if (flat[1] ~= nil and #flat[1] > 0) then
                command = command .. ' ' .. flat[1];
            end

            -- The copy becomes the document on screen the moment it exists.
            editor.pendingRef = name;
            editor.touched    = false;

            startPlan({ command }, string.format('Copying %s...', editor.name));
        else
            state.status    = nameProblem(name);
            state.statusBad = true;
        end
    end

    imgui.SameLine();

    assignControls('shipped', 'preset:' .. editor.name);
end

local function editorTab()
    if (vocab == nil) then
        needVocab();
        imgui.Text('Fetching the rule vocabulary from the server...');

        return;
    end

    need('rules', 0, '!dwg');
    need('list', 0, '!dwg list');
    need('presets', 0, '!dwg presets');

    -- The set picker: everything the account owns, then a way to start fresh.
    local owned = {};

    for _, set in pairs(state.sets) do
        table.insert(owned, { setid = set.setid, name = set.name, label = set.name });
    end

    table.sort(owned, function (a, b) return a.name < b.name; end);

    imgui.Text('Set');
    imgui.SameLine();

    local picked = pickCombo('##setpick', 170, editor.name or '(pick a set)', owned,
        function (set) return editor.setid ~= 0 and set.setid == editor.setid; end);

    if (picked ~= nil) then
        if (editor.touched) then
            state.status    = 'Save or revert your edits before switching sets.';
            state.statusBad = true;
        else
            loadIntoEditor(picked.name);
        end
    end

    imgui.SameLine();

    local newBox = nameBoxOf('newname');

    imgui.PushItemWidth(140);
    imgui.InputText('##newname', newBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    imgui.SameLine();

    local ownedCount = #owned;

    if (imgui.Button('New##newset')) then
        local name = newBox[1];

        if (editor.touched) then
            state.status    = 'Save or revert your edits first.';
            state.statusBad = true;
        elseif (not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        elseif (ownedCount >= vocab.caps.setsPerAccount) then
            -- The cap, enforced here as the v|h record intends: refused in
            -- the UI rather than after the server throws it away.
            state.status    = string.format('An account holds %d sets, and this one is full. Delete one first (the Delete button below, or !squad rules delete).', vocab.caps.setsPerAccount);
            state.statusBad = true;
        else
            editor.pendingRef = name;
            editor.touched    = false;

            startPlan({ '!dwg new ' .. name }, string.format('Creating "%s"...', name));

            newBox[1] = '';
        end
    end

    tooltipOnHover(string.format('%d of %d sets used. Names: letters, digits, spaces and dashes, %d characters at most.',
        ownedCount, vocab.caps.setsPerAccount, vocab.caps.nameLength));

    if (editor.name == nil) then
        imgui.Separator();
        imgui.Text('Pick a set to edit, create a new one, or browse the shipped sets.');
        imgui.Text('Clicking a character on the left opens whatever they are running.');

        return;
    end

    if (editor.shipped) then
        shippedView();

        return;
    end

    if (editor.doc == nil) then
        imgui.Text('Loading...');

        return;
    end

    imgui.Separator();

    postureBlock();

    imgui.Separator();

    ruleTable();

    -- The bottom bar: everything that leaves the local document.
    local doc = editor.doc;

    if (#doc.rules < vocab.caps.rulesPerSet) then
        if (imgui.Button('Add rule##addrule')) then
            -- The blank rule: the first target, the first condition, the
            -- first action kind -- all of them real entries off the wire, so
            -- the new row is already a saveable rule.
            local target = vocab.targets[1];
            local cond   = vocab.conditions[1];
            local kind   = vocab.kinds[1];

            local rule = {
                target   = target ~= nil and target.id or 0,
                logic    = 0,
                cond1    = cond ~= nil and cond.id or 0,
                arg1     = 0,
                cond2    = NO_CONDITION,
                arg2     = 0,
                reaction = kind ~= nil and kind.reaction or 0,
                selector = kind ~= nil and kind.selector or 0,
                actionid = 0,
                retry    = 0,
            };

            if (kind ~= nil and kind.arg.kind == 'pick') then
                local list = vocab.pickers[kind.arg.picker];

                rule.actionid = list ~= nil and list[1] ~= nil and list[1].id or 0;
            end

            table.insert(doc.rules, rule);

            markTouched();
        end
    else
        imgui.TextDisabled(string.format('A set holds %d rules, and this one is full.', vocab.caps.rulesPerSet));
    end

    imgui.SameLine();

    if (editor.touched) then
        imgui.TextColored(COLOR_DIRTY, 'o unsaved changes');
    else
        imgui.TextDisabled('saved');
    end

    imgui.SameLine();

    if (imgui.Button('Save##save')) then
        if (editor.saving) then
            state.status = 'A save is already running.';
        elseif (editor.touched) then
            beginSave(nil);
        end
    end

    imgui.SameLine();

    if (imgui.Button('Revert##revert')) then
        if (editor.server ~= nil) then
            editor.doc     = copyDocOf(editor.server);
            editor.touched = false;
            state.status   = 'Reverted to the saved copy.';
            state.statusBad = false;
        end
    end

    imgui.SameLine();

    local asBox = nameBoxOf('saveas');

    imgui.PushItemWidth(130);
    imgui.InputText('##saveas', asBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.Button('Save as##saveasbtn')) then
        local name = asBox[1];

        if (editor.saving) then
            state.status = 'A save is already running.';
        elseif (not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        elseif (ownedCount >= vocab.caps.setsPerAccount) then
            state.status    = string.format('An account holds %d sets, and this one is full.', vocab.caps.setsPerAccount);
            state.statusBad = true;
        else
            beginSave(name);
            asBox[1] = '';
        end
    end

    imgui.Text('Assign to');
    imgui.SameLine();
    assignControls('editor', editor.name);

    imgui.SameLine();

    if (imgui.Button('Check##report')) then
        requested['report'] = nil;
        need('report', os.clock(), '!dwg report');
    end

    tooltipOnHover('Re-measures every summoned member: which rules are live, which are inert and why.');

    -- The manage row: the two verbs the typed tier has owned since Phase 2,
    -- finally given buttons. Rename is safe mid-edit -- adoptDoc keeps a
    -- touched doc and follows the setid into the new name -- so it only
    -- guards against a running save (whose remaining steps quote the old
    -- name). Delete asks twice, dwjobs' pattern, because there is no undo;
    -- the armed state is keyed on the setid so switching sets disarms it.
    imgui.Text('Rename to');
    imgui.SameLine();

    local renameBox = nameBoxOf('renameset');

    imgui.PushItemWidth(130);
    imgui.InputText('##renameset', renameBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.Button('Rename##renamebtn')) then
        editor.armDelete = 0;

        local name = renameBox[1];

        if (editor.saving) then
            state.status = 'A save is already running.';
        elseif (not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        else
            startPlan({ string.format('!dwg rename "%s" %s', editor.name, name) },
                string.format('Renaming "%s" to "%s"...', editor.name, name));

            renameBox[1] = '';
        end
    end

    tooltipOnHover('Assignments and party presets point at the set itself, so they follow a rename.');

    imgui.SameLine();

    if (editor.armDelete == editor.setid and editor.setid ~= 0) then
        if (imgui.Button('Really delete?##deletebtn')) then
            editor.armDelete = 0;

            if (editor.saving) then
                state.status = 'A save is already running.';
            else
                startPlan({ string.format('!dwg delete "%s"', editor.name) },
                    string.format('Deleting "%s"...', editor.name));
            end
        end

        tooltipOnHover('This cannot be undone. Any character running it goes back to the squad profile; a party preset that names it will skip those members.');
    else
        if (imgui.Button('Delete##deletebtn')) then
            editor.armDelete = editor.setid;
        end

        tooltipOnHover('Deletes this set. Asks once more before anything happens.');
    end
end

--[[
* The Share tab.
*
* Two halves of one idea: turn a set of mine into text, and turn somebody
* else's text into a set of mine.
*
* THE CODE BOXES ARE INPUTS AND NOT LABELS, deliberately. ImGui has no "copy
* this text" affordance and Ashita's chat log is not selectable, so a read-only
* InputText the player can click into, select and Ctrl-C is the only way the
* code leaves the window. Marked read-only rather than merely "please do not
* type in it", because a code with a character changed is a code that will be
* refused on the other end with no clue as to why.
*
* IMPORT SENDS ONE PART PER COMMAND, through the same queue everything else
* uses. A pasted two-line code is split on whitespace here and issued as two
* `!dwg import` lines; the server buffers the parts and answers the last one
* with the set. That is not the client being clever -- it is exactly what a
* player typing both lines does, which is the rule the whole addon is built on.
--]]

-- The paste box holds two full parts and the whitespace between them. Longer
-- than any legal code so that a truncated paste is visibly the player's doing
-- rather than the box's.
local CODE_BOX = 512;

local function shareTab()
    need('list', 0, '!dwg list');
    -- KEEP THE VOCABULARY FETCH ADVANCING. needVocab is called from editorTab
    -- and nowhere else, and it asks for one page at a time -- so a player who
    -- leaves the Editor tab after page 1 lands leaves `vocab` nil forever,
    -- while this tab's Import button needs its name caps.
    needVocab();

    imgui.TextWrapped('A rule set as text. Say it, write it down, paste it into Discord -- anyone on any DriftwoodXI character can put it to work.');
    imgui.Separator();

    -- Export.
    imgui.Text('Share one of yours');

    local owned = {};

    for _, set in pairs(state.sets) do
        table.insert(owned, { setid = set.setid, name = set.name, label = set.name });
    end

    table.sort(owned, function (a, b) return a.name < b.name; end);

    local picked = pickCombo('##sharepick', 170, state.codesFor or '(pick a set)', owned,
        function (set) return state.codesFor ~= nil and set.name == state.codesFor; end);

    if (picked ~= nil) then
        -- The old code goes the moment a different set is chosen: a stale code
        -- sitting under a new name is the one failure mode of this pane that
        -- the player could not possibly diagnose.
        state.codes    = {};
        state.codesFor = picked.name;

        startPlan({ string.format('!dwg export "%s"', picked.name) },
            string.format('Making a code for %s...', picked.name));
    end

    imgui.SameLine();

    if (imgui.Button('Refresh code##sharerefresh') and state.codesFor ~= nil) then
        state.codes = {};

        startPlan({ string.format('!dwg export "%s"', state.codesFor) },
            string.format('Making a code for %s...', state.codesFor));
    end

    tooltipOnHover('A code is a snapshot. Edit the set and make a new one.');

    local total = 0;

    for _ in pairs(state.codes) do
        total = total + 1;
    end

    if (total > 1) then
        imgui.TextColored(COLOR_DIRTY, string.format('%d lines, and all of them are needed.', total));
    end

    for part = 1, total do
        local code = state.codes[part];

        if (code ~= nil) then
            local box = nameBoxOf('code' .. part);

            box[1] = code;

            imgui.PushItemWidth(-1);
            imgui.InputText(string.format('##code%d', part), box, CODE_BOX, ImGuiInputTextFlags_ReadOnly);
            imgui.PopItemWidth();
        end
    end

    if (total == 0 and state.codesFor ~= nil) then
        imgui.TextDisabled('Fetching...');
    end

    imgui.Separator();

    -- Import.
    imgui.Text('Take somebody else\'s');

    local pasteBox = nameBoxOf('paste');
    local nameBox  = nameBoxOf('importname');

    imgui.PushItemWidth(-1);
    imgui.InputTextMultiline('##paste', pasteBox, CODE_BOX, { -1, 54 });
    imgui.PopItemWidth();

    imgui.Text('Call it');
    imgui.SameLine();
    imgui.PushItemWidth(160);
    imgui.InputText('##importname', nameBox, vocab ~= nil and (vocab.caps.nameLength + 1) or 25);
    imgui.PopItemWidth();

    tooltipOnHover('Leave empty to keep the name it was shared under.');

    imgui.SameLine();

    if (imgui.Button('Import##importbtn')) then
        local pasted = pasteBox[1] or '';
        local codes  = {};

        for token in string.gmatch(pasted, '%S+') do
            table.insert(codes, token);
        end

        local name = nameBox[1] or '';

        if (#codes == 0) then
            state.status    = 'Paste a code into the box first.';
            state.statusBad = true;
        elseif (#name > 0 and vocab == nil) then
            -- validName and nameProblem both index vocab.caps unconditionally,
            -- and this is the ONE tab that can run before the vocabulary lands
            -- (its own InputText size already guards for that). Indexing nil
            -- here threw inside renderWindow, and the pcall around it closes
            -- the window on the player with the paste still unsent.
            state.status    = 'Still fetching the rule vocabulary -- try again in a moment.';
            state.statusBad = true;
        elseif (#name > 0 and not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        elseif (#name > 0 and (#codes[#codes] + #name) > 114) then
            -- `!dwg import ` is 12 characters and the space before the name one
            -- more, out of the 127 a chat line holds -- and the client REFUSES
            -- an over-length line rather than truncating it, before the server
            -- ever sees it. Unchecked, the command never left the box and the
            -- plan died eight seconds later reporting a failed SAVE for an
            -- import that was never attempted. squad_rule_codes.lua says the
            -- same thing about its own import command: the code already
            -- carries the name it was exported under, and rename is cheap.
            state.status    = string.format(
                'That name will not fit on the same line as this code -- %d characters at most here. Import it unnamed and rename it.',
                math.max(0, 114 - #codes[#codes]));
            state.statusBad = true;
        else
            local commands = {};

            for index, code in ipairs(codes) do
                -- The name rides on the LAST part only: every part before it is
                -- answered with "still waiting" and a name handed to one of
                -- those would be read and thrown away.
                if (index == #codes and #name > 0) then
                    table.insert(commands, string.format('!dwg import %s %s', code, name));
                else
                    table.insert(commands, string.format('!dwg import %s', code));
                end
            end

            -- The imported set becomes the document on screen the moment it
            -- exists, the same way a copy does.
            if (#name > 0) then
                editor.pendingRef = name;
                editor.touched    = false;
            end

            startPlan(commands, string.format('Importing %d line%s...', #codes, #codes == 1 and '' or 's'));

            -- THE BOXES ARE NOT CLEARED, and that is the point. The plan runs
            -- asynchronously and the commonest refusal is a name already in
            -- use -- so the retry is "type a different name and click again".
            -- Clearing optimistically would throw away the code the player
            -- pasted at the exact moment they need it back.
        end
    end

    tooltipOnHover('Both lines of a two-line code can go in the box at once.');
end

-- Ten shipped sets a page. The roster grew to thirty (one per job and role,
-- 2026-07-27) and a single column of thirty buries the four a new player
-- actually reaches for first. The page number is client-side chrome, not
-- world state: it survives a Refresh, and the clamp below handles a roster
-- that shrank while it was open.
local PRESET_PAGE = 10;
local presetPage  = 1;

local function presetsTab()
    need('presets', 0, '!dwg presets');
    need('rules', 0, '!dwg');
    need('list', 0, '!dwg list');

    imgui.Text('Shipped sets -- always available, never edited. Assign one, or copy it and make it yours.');

    if (#state.presets == 0) then
        imgui.Text('Fetching...');

        return;
    end

    local pages = math.ceil(#state.presets / PRESET_PAGE);

    if (presetPage > pages) then
        presetPage = pages;
    end

    if (presetPage < 1) then
        presetPage = 1;
    end

    if (pages > 1) then
        if (imgui.SmallButton('< Prev##pp_prev') and presetPage > 1) then
            presetPage = presetPage - 1;
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('page %d of %d', presetPage, pages));
        imgui.SameLine();

        if (imgui.SmallButton('Next >##pp_next') and presetPage < pages) then
            presetPage = presetPage + 1;
        end
    end

    for index = (presetPage - 1) * PRESET_PAGE + 1, math.min(presetPage * PRESET_PAGE, #state.presets) do
        local preset = state.presets[index];
        imgui.Separator();
        imgui.TextColored(COLOR_BADGE, preset.name);
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d rules', preset.count));

        imgui.TextWrapped(preset.summary or '');

        if (imgui.SmallButton(string.format('View##pv_%d', index))) then
            if (editor.touched) then
                state.status    = 'Save or revert your edits before opening another set.';
                state.statusBad = true;
            else
                loadIntoEditor(preset.name);
            end
        end

        imgui.SameLine();

        if (imgui.SmallButton(string.format('Assign##pa_%d', index))) then
            if (state.assignTo ~= nil) then
                startPlan({ string.format('!dwg use %s "preset:%s"', state.assignTo, preset.name) },
                    string.format('Assigning %s...', preset.name));
            else
                state.status    = 'Pick who runs it in the Assign box on the Editor tab first.';
                state.statusBad = true;
            end
        end

        tooltipOnHover(string.format('Assign to %s. The member receives only the rules its job can use.',
            state.assignTo or 'a member'));
    end
end

-- The Party tab (2026-08-16): whole-squad snapshots, the gambit twin of
-- dwjobs' presets. Save asks nothing else of the player -- the server
-- snapshots what is assigned RIGHT NOW -- so unlike dwjobs there is no
-- staged-changes guard to need. Delete asks twice, keyed on the name so
-- pressing anything else disarms it.
local partyDeleteArm = nil;

local function partyTab()
    if (partyUnsupported) then
        imgui.TextWrapped('This server does not have party presets yet. Everything else still works.');

        return;
    end

    if (vocab == nil) then
        needVocab();
        imgui.Text('Fetching the rule vocabulary from the server...');

        return;
    end

    need('party', 0, '!dwg party');
    need('list', 0, '!dwg list');

    imgui.TextWrapped('Party presets -- one name for how the whole squad fights. Save remembers every assignment as it stands; Load brings it back.');
    imgui.TextWrapped('A renamed set follows into its presets on its own. A character whose set was deleted since the save is skipped, and keeps running what it was.');

    local saveBox = nameBoxOf('partysave');

    imgui.PushItemWidth(140);
    imgui.InputText('##partysave', saveBox, vocab.caps.nameLength + 1);
    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.Button('Save party preset##party_save')) then
        partyDeleteArm = nil;

        local name = saveBox[1];

        if (not validName(name)) then
            state.status    = nameProblem(name);
            state.statusBad = true;
        else
            startPlan({ string.format('!dwg party save "%s"', name) },
                string.format('Saving party preset "%s"...', name));

            saveBox[1] = '';
        end
    end

    tooltipOnHover('Snapshots every character\'s current assignment under this name. Re-saving a name overwrites it.');

    if (#state.loadouts == 0) then
        imgui.Separator();
        imgui.TextDisabled('No party presets saved yet.');

        return;
    end

    for index, loadout in ipairs(state.loadouts) do
        imgui.Separator();
        imgui.TextColored(COLOR_BADGE, loadout.name);
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d character%s', loadout.members, loadout.members == 1 and '' or 's'));

        if (imgui.SmallButton(string.format('Load##py_use_%d', index))) then
            partyDeleteArm = nil;

            startPlan({ string.format('!dwg party use "%s"', loadout.name) },
                string.format('Loading party preset "%s"...', loadout.name));
        end

        tooltipOnHover('Every character goes back to the set this preset remembers. Skips are reported in the status line.');

        imgui.SameLine();

        if (partyDeleteArm == loadout.name) then
            if (imgui.SmallButton(string.format('Really delete?##py_del_%d', index))) then
                partyDeleteArm = nil;

                startPlan({ string.format('!dwg party delete "%s"', loadout.name) },
                    string.format('Deleting party preset "%s"...', loadout.name));
            end

            tooltipOnHover('This cannot be undone. The rule sets themselves are untouched.');
        else
            if (imgui.SmallButton(string.format('Delete##py_del_%d', index))) then
                partyDeleteArm = loadout.name;
            end

            tooltipOnHover('Forgets the snapshot. Asks once more before anything happens.');
        end
    end
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        forget();
    end

    imgui.SameLine();

    local pending = #readQueue + #plan + (planWait ~= nil and 1 or 0);

    if (pending > 0) then
        imgui.TextDisabled(string.format('%d queued...', pending));
    else
        imgui.TextDisabled('');
    end

    -- The message line gets its own row and errors are red: a refusal's
    -- reason is the only thing telling the player what to do instead.
    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(COLOR_ERROR, state.status);
        else
            imgui.TextColored(COLOR_OK, state.status);
        end
    end

    imgui.Separator();

    leftPane();

    imgui.SameLine();

    imgui.BeginChild('##dwg_right', { 0, 0 }, ImGuiChildFlags_None);

    if (imgui.BeginTabBar('##dwg_tabs')) then
        if (imgui.BeginTabItem('Editor')) then
            editorTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Party')) then
            partyTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Shipped sets')) then
            presetsTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Share')) then
            shareTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    imgui.EndChild();
end

--[[
* The render pass, wrapped so a mistake costs one frame rather than the addon:
* an error thrown inside d3d_present is raised sixty times a second and the
* host answers a long enough run of them by unloading the addon. Begin/End
* stay outside the pcall to keep ImGui's stack balanced; the error is reported
* once; the window closes itself. Everything it does is still reachable as
* !squad rules commands, so closing it is a fallback rather than a dead end.
--]]
ashita.events.register('d3d_present', 'dwgambits_present', function ()
    -- Before the visibility check: a Save issued a moment before closing the
    -- window still has to finish reaching the server.
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    imgui.SetNextWindowSize({ 1120, 620 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Gambits##dwgambits', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwgambits'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwgambits'):append(chat.message('Window closed. Everything it does also works as !squad rules commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Watch what the player types, so the window keeps up with edits made outside
* it. `!squad rules ...` answers in prose this addon never sees, so the only
* way to notice is to notice the question. Every other outgoing line still
* counts against the chat throttle -- the client's rate limit is on chat, not
* on this addon -- so foreign lines stamp the send clock.
--]]
ashita.events.register('packet_out', 'dwgambits_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower();

    -- ON A WORD BOUNDARY. A four-character prefix test also matched `!dwgm`,
    -- so every line dwgmpanel sent looked like one of ours and this addon
    -- skipped its own backoff stamp for it -- the throttle exists to stop us
    -- talking over somebody else's traffic, and it stood down for exactly the
    -- traffic it should have yielded to. The bare form is load-bearing:
    -- need('rules', 0, '!dwg') sends `!dwg` with no argument and no trailing
    -- space, so the space test alone would stamp our own send.
    if (lower ~= '!dwg' and lower:sub(1, 5) ~= '!dwg ') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 6) == '!squad') then
        forget();

        -- A typed edit may have changed the set on screen. An untouched
        -- editor follows along; a touched one is the player's, and the
        -- adoption logic will flag the divergence rather than overwrite it.
        if (editor.name ~= nil and not editor.touched and not editor.shipped) then
            loadIntoEditor(editor.name);
        end
    end
end);

ashita.events.register('command', 'dwgambits_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Gambits`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/gambits' and first ~= '/dwgambits') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        forget();

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported`
        -- exists to stop one bad frame printing sixty lines a second, not to
        -- silence a different error a week later.
        state.reported = false;

        forget();
    end
end);

ashita.events.register('load', 'dwgambits_load', function ()
    print(chat.header('dwgambits'):append(chat.message('/gambits opens the rule editor. Everything it does also works typed as !squad rules.')));
end);

-- A login is a different account view; the world state resets. The editor's
-- unsaved document deliberately survives -- 0x000A also fires on every zone
-- line, and a zone must not eat an hour of rule writing. If the document
-- belongs to the wrong account after a relog, Save is refused server-side
-- with a sentence, which is the correct outcome.
ashita.events.register('packet_in', 'dwgambits_zonein', function (e)
    if (e.id == 0x000A) then
        state.members     = {};
        state.memberOrder = {};
        state.sets        = {};
        state.assigns     = {};
        state.presets     = {};
        state.loadouts    = {};
        state.verdicts    = {};
        state.hints       = {};
        state.codes       = {};
        state.codesFor    = nil;
        state.selected    = nil;
        state.assignTo    = nil;

        -- Asked again on the other side: the server may have grown the hints
        -- or party verbs since the last look (a map restart logs everyone out).
        hintsUnsupported = false;
        partyUnsupported = false;

        forget();
    end
end);
