--[[
* dwchat -- a cleaner chat log (owner request 2026-09-22).
*
* "Clean up our chat windows and make them more readable with color coding and
* combining information spam into less outputs ... an option players can
* choose to enable or disable." This is that option, first slice: it works IN
* the client's own log windows rather than replacing them, so every other
* addon that reads or rewrites chat keeps working, and turning it off puts the
* log back exactly as it was.
*
* IT IS OFF UNTIL THE PLAYER SWITCHES IT ON (`/dwchat on`, or the master
* checkbox in the `/dwchat` window). With the master off every line passes
* through untouched and unblocked -- the harness asserts exactly that.
*
* IT TALKS TO NO SERVER. No `!` line, no sender, no protocol, no packet
* handler: it carries dwtheme.lua (it draws a settings window) and no
* dwecho.lua, the dwhub shape. Everything it does happens to lines the client
* was already going to draw.
*
* THE TWO LEVERS, AND WHICH ONE EACH FEATURE USES (client-owns-the-chat-window):
*
*   1. e.message_modified -- a line's text can be rewritten in flight. COLOUR
*      CODING uses only this: nothing is blocked, nothing is re-printed, the
*      line keeps its mode and so its window, and the timestamp addon's stamp
*      (it runs ahead of us) and the client's end-of-message pair stay where
*      they were.
*   2. block + re-emit -- COMBINING has to use this, because several lines
*      become one. The originals are blocked (`e.blocked = true`) and the
*      combined line is emitted LATER, from the d3d_present tick, through
*      AddChatMessage with the ORIGINAL mode id so the client files it in the
*      same window the originals would have gone to. NEVER from inside
*      text_in: Ashita.h forbids Write/AddChatMessage from inside the handler
*      (the emitted line re-enters text_in, and re-entering from inside is a
*      stack-overflow hazard).
*
* RE-ENTRY. Every line this addon emits starts with MARK, two colour resets in
* a row -- zero width, drawn as nothing. When the emitted line comes back
* through text_in (it always does; the timestamp addon stamps it there), the
* handler finds MARK, takes it out of the line and leaves everything else
* alone. That is the loop guard, and it does not depend on `e.injected` (which
* is ALSO honoured: another addon's print() is never coloured or combined).
*
* WHAT IT NEVER TOUCHES: a line somebody already blocked; a line carrying a
* DriftwoodXI wire sender (`_DW...DATA` -- every sender name in
* modules/driftwoodxi matches SENDER_PATTERN, and the harness greps them to
* prove it); a `[dw...]`-prefixed addon line; and any line whose mode is not
* one of the battle families in MODE_FAMILY. Chat people typed is on none of
* those modes. A line re-moded by dwquest's kill feed (Assist E, 222) is not
* on them either, so the feed and this addon never fight over a line when
* dwquest runs first.
*
* THE PALETTE (colour table 1, `\30\NN`; every code is a colour Ashita's own
* libs/chat.lua names, chosen to read on the stock dark log -- the dark blues
* and dark magentas, 3 / 71 / 72, are deliberately not used). The three point
* colours and the item colour are dwquest's kill-feed tints, so a line reads
* the same whichever addon coloured it.
*
*   category   code  name            what
*   dealt       78   PaleGoldenRod   you / your party / a party pet hitting something
*   taken       76   Tomato          something hitting you / your party / a party pet
*   heal        83   SpringGreen     HP or MP recovered by a party member
*   buff        82   Aqua            a party member gains an effect
*   wear        67   Grey            a party member's effect wears off
*   exp          6   Cyan            experience points, level ups
*   limit       73   Violet          limit points
*   merit       73   Violet          merit points (limit points' payout)
*   capacity     8   Coral           capacity points
*   jobpoint     8   Coral           job points (capacity points' payout)
*   item        69   Yellow          obtains an item or gil
*   skill        5   Magenta         skill-ups
*
* "Your party" is the client's own party and alliance list -- which on this
* server is usually six squad alt-trusts -- plus their pets, read from the
* memory manager and refreshed at most once a second.
*
* COMBINING (each with its own switch; all bucketed for `window` seconds,
* 1.5 by default, measured from the FIRST line of a bucket):
*
*   points  per (actor, kind): "Yukimura gains 1,872 experience points (3)".
*           Kinds: experience, limit, capacity, merit points, job points.
*           Chain lines ("EXP chain #2! ...") and level ups are NOT combined
*           -- the chain number is information -- they are only coloured.
*   skill   per (actor, skill): "Makalov's sword skill rises 0.3 points (3)".
*   melee   per (attacker, target), plain melee only (hits, critical hits,
*           misses; not ranged, not weapon skills, not spells):
*           "Makalov hits the Forest Funguar 3 times for 84 damage (crit x1, miss x1)".
*
* A bucket that caught ONE line re-emits that line's own words, so a lone hit
* reads exactly as it would have. A line arriving after its bucket's window
* has closed opens a new bucket; the old one flushes on its own. Combined
* lines arrive up to `window` seconds after the fight moved on, and after any
* line that was not combined -- that is the trade, and the window is short.
*
* 1.1.0 (2026-09-22) -- THE REST OF THE PLAN'S ROADMAP, seven slices, each
* behind its own switch in a collapsing section of the window (Routing /
* Grouping / Digest / Colours / Names / Filters), so the window is exactly
* 1.0.0's height until a section is opened. Still nothing is re-rendered:
* every slice is one of the two levers, or a third the client also gives --
* re-moding a line in place -- or a block.
*
*   routing   per group, "send to Window 2": the line is re-moded IN PLACE to
*             ROUTE_MODE (222, Assist E -- dwquest's kill-feed lever, extension
*             bits kept); a combined line is emitted on the routed mode. OFF.
*   casts     a spell or ability with several targets -- the head line and
*             the follow-on line per further target -- is one line: "Makalov
*             casts Protectra IV. Makalov, Yukimura, Kagetora gain the effect
*             of Protect." Also recovery (amounts kept) and area damage. A
*             follow-on joins only the cast IMMEDIATELY before it (any other
*             battle line ends the sequence) inside CAST_WINDOW (0.5 s). ON.
*   loot      a kill's "You find", lots and "obtains" as one line; a gil split
*             summed. Keyed by monster, a lot or a winner joins the newest
*             find of that item still inside the window. ON.
*   digest    worn-off effects across the party as one line every
*             `digestWindow` seconds (10): "Worn off: Protect (Makalov,
*             Yukimura); Shell (Makalov)". OFF: it holds lines back.
*   colours   a colour per category (COLOR_CHOICES; 0 = the game's own), with
*             a live preview beside each picker. The palette by default.
*   names     you, party, alliance and the line's monster in their own colours
*             inside any line dwchat colours, whole words only, never inside a
*             tag pair. OFF, because it cannot promise not to colour an
*             ordinary word: a character may be named like a spell or a word
*             ("Fire"), and a pet always is (so pets are never highlighted).
*   filters   BLOCK switches: others' combat, misses, others' buffs, and each
*             group whole. The only feature that removes a line, so all OFF,
*             judged before anything folds; a hidden cast head hides its
*             follow-ons; the master off shows everything.
*
* The grouping switches default ON because they are pure folding -- the
* combine trade 1.0.0 already makes, nothing lost from a folded line; every
* switch that would MOVE, HIDE or HOLD BACK a line the player never asked
* about defaults to 1.0.0's behaviour. Every key is coerced on load (a string
* where a switch goes, a colour that is not a choice, a period out of range).
*
* Harness: tools/dwchat/harness_dwchat.py. Plan: PLANS/DWCHAT_PLAN.md.
* Behaviour, palette and settings keys: documentation/dwchat_protocol.md.
*
* Commands:
*   /dwchat           toggle the settings window
*   /dwchat on|off    the master switch
*   /dwchat status    what is on
*   /dwchat help      this list
--]]

addon.name    = 'dwchat';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.0';
addon.desc    = 'A cleaner chat log: colour-coded battle lines, spam folded into fewer lines (points, skill-ups, melee, spells, loot), Window 2 routing and filters -- off until you switch it on.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');

-- The palette above, as data. A plain table: the keys are category names and
-- a T{ }'s sugar method names would shadow them.
local PALETTE = {
    dealt    = 78,
    taken    = 76,
    heal     = 83,
    buff     = 82,
    wear     = 67,
    exp      = 6,
    limit    = 73,
    merit    = 73,
    capacity = 8,
    jobpoint = 8,
    item     = 69,
    skill    = 5,
};

--[[
* COLOUR CHOICES (1.1.0 slice 5): what a player may pick per category, each
* category defaulting to its PALETTE code. Every table-1 colour Ashita's
* libs/chat.lua names, less the reset (1 -- it is MARK's byte) and the three
* the palette refuses as unreadable on the stock dark log (3, 71, 72); plus 0,
* "the game's own colour", which leaves that category's lines uncoloured.
* The RGB beside each is the web colour of the same NAME and draws only the
* window's live preview; the chat log's own shade of a code can differ a
* little (ONLY THE GAME CAN CONFIRM the exact shade -- the "Preview the
* colours" button prints the real thing into the log).
--]]
local COLOR_CHOICES = {
    { 0,   'Game default (no colour)', nil },
    { 2,   'LawnGreen',            { 0.49, 0.99, 0.00, 1.0 } },
    { 5,   'Magenta',              { 1.00, 0.00, 1.00, 1.0 } },
    { 6,   'Cyan',                 { 0.00, 1.00, 1.00, 1.0 } },
    { 7,   'Moccasin',             { 1.00, 0.89, 0.71, 1.0 } },
    { 8,   'Coral',                { 1.00, 0.50, 0.31, 1.0 } },
    { 65,  'DimGrey',              { 0.41, 0.41, 0.41, 1.0 } },
    { 67,  'Grey',                 { 0.50, 0.50, 0.50, 1.0 } },
    { 68,  'Salmon',               { 0.98, 0.50, 0.45, 1.0 } },
    { 69,  'Yellow',               { 1.00, 1.00, 0.00, 1.0 } },
    { 73,  'Violet',               { 0.93, 0.51, 0.93, 1.0 } },
    { 76,  'Tomato',               { 1.00, 0.39, 0.28, 1.0 } },
    { 77,  'MistyRose',            { 1.00, 0.89, 0.88, 1.0 } },
    { 78,  'PaleGoldenRod',        { 0.93, 0.91, 0.67, 1.0 } },
    { 79,  'Lime',                 { 0.00, 1.00, 0.00, 1.0 } },
    { 80,  'PaleGreen',            { 0.60, 0.98, 0.60, 1.0 } },
    { 81,  'DarkOrchid',           { 0.60, 0.20, 0.80, 1.0 } },
    { 82,  'Aqua',                 { 0.00, 1.00, 1.00, 1.0 } },
    { 83,  'SpringGreen',          { 0.00, 1.00, 0.50, 1.0 } },
    { 85,  'DarkSalmon',           { 0.91, 0.59, 0.48, 1.0 } },
    { 88,  'MediumSpringGreen',    { 0.00, 0.98, 0.60, 1.0 } },
    { 89,  'MediumPurple',         { 0.58, 0.44, 0.86, 1.0 } },
    { 90,  'Azure',                { 0.94, 1.00, 1.00, 1.0 } },
    { 92,  'LightCyan',            { 0.88, 1.00, 1.00, 1.0 } },
    { 96,  'LightGoldenRodYellow', { 0.98, 0.98, 0.82, 1.0 } },
    { 105, 'Plum',                 { 0.87, 0.63, 0.87, 1.0 } },
};

-- code -> its row in COLOR_CHOICES; a code not in it is not a choice.
local COLOR_VALID = { };

for i, choice in ipairs(COLOR_CHOICES) do
    COLOR_VALID[choice[1]] = i;
end

--[[
* NAME HIGHLIGHTING (1.1.0 slice 6): the colour each kind of name takes inside
* a line dwchat colours. Kept apart from PALETTE on purpose -- PALETTE is the
* per-LINE category table the header's palette rows describe.
*
*     role       code  name
*     self         2   LawnGreen      you (party slot 0)
*     party       89   MediumPurple   your party (slots 1-5)
*     alliance   105   Plum           the rest of the alliance (slots 6-17)
*     enemy       68   Salmon         the monster a line is about
--]]
local NAME_PALETTE = {
    self     = 2,
    party    = 89,
    alliance = 105,
    enemy    = 68,
};

local NAME_KEY = {
    self     = 'nameSelf',
    party    = 'nameParty',
    alliance = 'nameAlliance',
    enemy    = 'nameEnemy',
};

-- The settings key holding each category's colour.
local COLOR_KEY = {
    dealt    = 'colorDealt',
    taken    = 'colorTaken',
    heal     = 'colorHeal',
    buff     = 'colorBuff',
    wear     = 'colorWear',
    exp      = 'colorExp',
    limit    = 'colorLimit',
    merit    = 'colorMerit',
    capacity = 'colorCapacity',
    jobpoint = 'colorJobpoint',
    item     = 'colorItem',
    skill    = 'colorSkill',
};

-- The colour reset. `\30\1` ends any table-1 colour and is zero width.
local RESET = '\30\1';

-- Two resets in a row: invisible, and not something the client or any addon
-- in the shipped bundle writes, so a line carrying it is one of ours.
local MARK = RESET .. RESET;

-- Every DriftwoodXI wire sender is `_DW` + capitals + `DATA` (_DWDATA,
-- _DWODATA, _DWTODATA, _DWSPDATA, ...). The harness greps modules/driftwoodxi
-- for the names and holds each to this pattern.
local SENDER_PATTERN = '_DW%u*DATA';

--[[
* MODE FAMILIES: the low byte of a line's mode, mapped to the battle family
* whose patterns may classify it. An ALLOW list, because the harmful failure
* here is rewriting or swallowing somebody's chat; a mode not listed is left
* alone whatever it says. The ids are the client's (DAT-derived), read out of
* the resource tables the shipped bundle's simplelog carries
* (res/action_messages.lua `color`, and its lib/constants.lua block_modes for
* the relation-dependent damage/miss/heal families):
*
*   combat   20-35, 40-43, 104, 109, 114, 162-165, 181, 185-188 -- hits,
*            misses, damage and recovery, every actor/target relation
*   status   56, 57, 60, 61, 64, 65, 81, 191 -- gains / receives an effect,
*            wears off / is no longer
*   item    127 -- obtains an item or gil
*   skill   129 -- skill rises / reaches level
*   points  131 -- experience, limit, capacity, job points, level ups, chains
*
* Deliberately absent: 36 (defeats -- dwquest's kill feed), 121 (server
* SYSTEM_3, which every DriftwoodXI module prints on), every player-chat mode,
* and 222 (where dwquest's feed re-modes the lines it takes).
--]]
local MODE_FAMILY = { };

for _, id in ipairs({ 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
                      40, 41, 42, 43, 104, 109, 114, 162, 163, 164, 165, 181,
                      185, 186, 187, 188 }) do
    MODE_FAMILY[id] = 'combat';
end

for _, id in ipairs({ 56, 57, 60, 61, 64, 65, 81, 191 }) do
    MODE_FAMILY[id] = 'status';
end

--[[
* TWO OF THOSE IDS ARE ASSUMPTIONS, and each lives in exactly one named
* constant so a correction is one edit. ONLY THE GAME CAN CONFIRM (plan,
* "What only the game can confirm"):
*
*   MODE_ITEM   127  "You find a ... on the ...", the treasure pool's lot
*                    line and its "obtains" distribution line. 127 is the
*                    resource tables' colour for Obtains 565 / 582 (gil); that
*                    the pool's DAT-side lines share it is the assumption. If
*                    they do not, loot grouping (1.1.0) never sees them and
*                    they stay exactly as the game drew them -- the failure is
*                    "not folded", never "swallowed".
*   MODE_POINTS 131  merit and job point lines (the resource tables give 131
*                    for exp / limit / capacity; merit 50 and job point 719
*                    are assumed to ride it).
--]]
local MODE_ITEM   = 127;
local MODE_POINTS = 131;

MODE_FAMILY[MODE_ITEM]   = 'item';
MODE_FAMILY[129]         = 'skill';
MODE_FAMILY[MODE_POINTS] = 'points';

--[[
* ROUTING (1.1.0). The mode a routed line is re-moded to: Assist E, the one
* dwquest's kill feed uses (FEED_WINDOW_MODE there) -- a chat-group channel
* nothing on this server ever speaks on, filed in Window 2 on the stock Log
* config. The extension bits above the low byte are kept, exactly as the feed
* keeps them. ONLY THE GAME CAN CONFIRM that the client files a line by its
* MODIFIED mode and that the player's Log config puts Assist E in Window 2;
* the harness proves the mode handed over, not where the client draws it
* (dwquest's feed carries the same caveat). 222 is NOT in MODE_FAMILY, so a
* routed line -- or one dwquest's feed moved -- is never looked at twice.
--]]
local ROUTE_MODE = 222;

-- The routing and hiding groups (1.1.0): the palette's twelve categories as
-- the eight a player thinks in. Every point kind moves or hides together.
local GROUPS = { 'Dealt', 'Taken', 'Heal', 'Buff', 'Wear', 'Points', 'Item', 'Skill' };

local GROUP_OF = {
    dealt    = 'Dealt',
    taken    = 'Taken',
    heal     = 'Heal',
    buff     = 'Buff',
    wear     = 'Wear',
    exp      = 'Points',
    limit    = 'Points',
    merit    = 'Points',
    capacity = 'Points',
    jobpoint = 'Points',
    item     = 'Item',
    skill    = 'Skill',
};

-- What each group is called in the window.
local GROUP_LABEL = {
    Dealt  = 'Your party\'s hits',
    Taken  = 'Damage your party takes',
    Heal   = 'Healing',
    Buff   = 'Buffs gained',
    Wear   = 'Buffs worn off',
    Points = 'Experience, limit, capacity, merit and job points',
    Item   = 'Items, gil and loot',
    Skill  = 'Skill-ups',
};

-- Seconds a combine window may be set to. The slider and the loader both
-- clamp to these, so a hand-edited settings file cannot hold a bucket open
-- for ever or flush it every frame.
local WINDOW_MIN     = 0.5;
local WINDOW_MAX     = 5.0;
local WINDOW_DEFAULT = 1.5;

-- The party-status digest's period (1.1.0 slice 4), in seconds: how long
-- worn-off lines are collected before the one-line digest is said.
local DIGEST_MIN     = 3;
local DIGEST_MAX     = 30;
local DIGEST_DEFAULT = 10;

-- A ceiling on open buckets (bursts need ceilings). A party of six plus pets
-- fighting one mob is a dozen; past this a line is coloured, not captured.
local MAX_BUCKETS = 64;

-- How often the party list is re-read, in seconds.
local PARTY_REFRESH = 1.0;

--[[
* Persisted, through Ashita's settings library, per character. Flat scalars
* only (the serializer drops nested tables). A SUGAR table, and the `T` is
* load-bearing: settings.lua calls defaults:copy(true) and
* settings:merge(defaults), and a plain table raises on the zone-in reload,
* which Ashita answers by unloading the addon (ashita-settings-defaults-must-be-T).
*
* `enabled` is the master switch and it DEFAULTS TO OFF. The 1.0.0 feature
* switches default on, so the master alone turns the whole thing on.
*
* 1.1.0's keys default to 1.0.0's behaviour wherever a switch would MOVE,
* HIDE or DELAY a line the player did not ask about: routing off, the digest
* off, name highlighting off, every filter off. The two grouping switches
* default on -- they are pure folding, the same trade the three combine
* switches already make, and nothing is lost from a folded line.
--]]
local defaultConfig = T{
    enabled       = false,
    colors        = true,
    combinePoints = true,
    combineSkill  = true,
    combineMelee  = true,
    window        = WINDOW_DEFAULT,

    -- Routing (1.1.0 slice 1): "send to Window 2", per group, all off.
    routeDealt    = false,
    routeTaken    = false,
    routeHeal     = false,
    routeBuff     = false,
    routeWear     = false,
    routePoints   = false,
    routeItem     = false,
    routeSkill    = false,

    -- Grouping (1.1.0 slice 2): one line per multi-target cast.
    groupCasts    = true,
    -- (slice 3): a kill's "You find" + lots + "obtains" as one line; gil splits summed.
    groupLoot     = true,

    -- Digest (slice 4): worn-off effects across the party as one periodic line.
    digest        = false,
    digestWindow  = DIGEST_DEFAULT,

    -- Colours (slice 5): one per category, the palette's by default.
    colorDealt    = PALETTE.dealt,
    colorTaken    = PALETTE.taken,
    colorHeal     = PALETTE.heal,
    colorBuff     = PALETTE.buff,
    colorWear     = PALETTE.wear,
    colorExp      = PALETTE.exp,
    colorLimit    = PALETTE.limit,
    colorMerit    = PALETTE.merit,
    colorCapacity = PALETTE.capacity,
    colorJobpoint = PALETTE.jobpoint,
    colorItem     = PALETTE.item,
    colorSkill    = PALETTE.skill,

    -- Names (slice 6): OFF -- see the header on why it cannot default on.
    names         = false,
    nameSelf      = NAME_PALETTE.self,
    nameParty     = NAME_PALETTE.party,
    nameAlliance  = NAME_PALETTE.alliance,
    nameEnemy     = NAME_PALETTE.enemy,

    -- Filters (slice 7): block switches, every one OFF.
    hideOthersCombat = false,
    hideMisses       = false,
    hideOthersBuffs  = false,
    hideDealt        = false,
    hideTaken        = false,
    hideHeal         = false,
    hideBuff         = false,
    hideWear         = false,
    hidePoints       = false,
    hideItem         = false,
    hideSkill        = false,
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

-- The numeric keys and the range each is held to on load and on write.
local RANGES = {
    window       = { WINDOW_MIN, WINDOW_MAX },
    digestWindow = { DIGEST_MIN, DIGEST_MAX },
};

--[[
* LOAD-TIME COERCION (1.1.0). A hand-edited or older settings file can hold a
* string where a switch goes, a colour code the client has no colour for, or
* no key at all; every key is put back to a value of its default's type, in
* range, before anything reads it. rawget, because an absent key on a sugar
* table answers with a METHOD, never nil.
--]]
local VALIDATORS = { };

local function isColorChoice(n)
    return COLOR_VALID[n] ~= nil;
end

for _, key in pairs(COLOR_KEY) do
    VALIDATORS[key] = isColorChoice;
end

for _, key in pairs(NAME_KEY) do
    VALIDATORS[key] = isColorChoice;
end

local function coerce(c)
    if (type(c) ~= 'table') then
        return;
    end

    for key, default in pairs(defaultConfig) do
        local value = rawget(c, key);

        if (type(default) == 'boolean') then
            if (type(value) ~= 'boolean') then
                c[key] = default;
            end
        elseif (type(default) == 'number') then
            local n = tonumber(value);

            if (n == nil or n ~= n) then
                n = default;
            end

            local range = RANGES[key];

            if (range ~= nil) then
                n = math.max(range[1], math.min(range[2], n));
            end

            local valid = VALIDATORS[key];

            if (valid ~= nil and not valid(n)) then
                n = default;
            end

            c[key] = n;
        end
    end
end

local function save()
    pcall(settings.save);
end

pcall(settings.register, 'settings', 'dwchat_settings_update', function (s)
    if (type(s) == 'table') then
        coerce(s);
        config = s;
    end
end);

local function windowSeconds()
    local w = tonumber(config.window) or WINDOW_DEFAULT;

    if (w ~= w) then
        w = WINDOW_DEFAULT;
    end

    return math.max(WINDOW_MIN, math.min(WINDOW_MAX, w));
end

local function featureOn(name)
    return config.enabled == true and config[name] ~= false;
end

local function digestSeconds()
    local w = tonumber(config.digestWindow) or DIGEST_DEFAULT;

    if (w ~= w) then
        w = DIGEST_DEFAULT;
    end

    return math.max(DIGEST_MIN, math.min(DIGEST_MAX, w));
end

-- For the switches that default OFF (1.1.0): on only when the file says true.
local function switchOn(name)
    return config.enabled == true and rawget(config, name) == true;
end

coerce(config);

-- The colour a player chose for a category (0 = the game's own), whatever
-- the colour switch says; the palette's when the file holds no valid choice.
local function chosenCode(cat)
    local code = tonumber(rawget(config, COLOR_KEY[cat] or ''));

    if (code == nil or COLOR_VALID[code] == nil) then
        code = PALETTE[cat] or 0;
    end

    return code;
end

-- A role's name colour, or nil for "leave that kind of name alone" (0).
local function nameCode(role)
    local code = tonumber(rawget(config, NAME_KEY[role] or ''));

    if (code == nil or COLOR_VALID[code] == nil) then
        code = NAME_PALETTE[role] or 0;
    end

    return code ~= 0 and code or nil;
end

-- A name as a whole-word Lua pattern.
local function wordPattern(name)
    return '%f[%w]' .. name:gsub('[%^%$%(%)%%%.%[%]%*%+%-%?]', '%%%0') .. '%f[^%w]';
end

-- The colour a line of `cat` is painted in, or nil for "leave it as the game
-- drew it" (colour coding off, an unknown category, or "Game default").
local function colourOf(cat)
    if (config.colors == false or PALETTE[cat] == nil) then
        return nil;
    end

    local code = chosenCode(cat);

    return code ~= 0 and code or nil;
end

--[[
* ROUTING. The mode a line of category `cat` goes out on: its own, or -- with
* that group's "Window 2" switch on -- the same packed mode with the low byte
* swapped for ROUTE_MODE. Master off means no routing, so a bucket flushed by
* switching the addon off goes back where it came from.
--]]
local function routed(mode, cat)
    local group = GROUP_OF[cat];

    if (group == nil or not switchOn('route' .. group)) then
        return mode;
    end

    return bit.bor(bit.band(mode, 0xFFFFFF00), ROUTE_MODE);
end

--[[
* The bytes of a line a player can read: the two-byte tags WITH their
* argument bytes first (the argument is often a printable letter -- `\30\81`
* is 'Q', `\127\49` is '1'), then line breaks as a seam space, then anything
* else that cannot be drawn, then the timestamp addon's clocks off every seam
* and off the front (chat-tags-are-two-bytes-wide). dwecho.lua's plainText,
* spelled here because this folder carries no dwecho.lua.
--]]
local function plainText(raw)
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    text = text:gsub('[\007\010\013]+', ' ');
    text = text:gsub('[^\032-\126]', '');
    text = text:gsub('%s%[%d%d?:%d%d:%d%d%]%s*', ' ');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return (text:gsub('^%s+', ''):gsub('%s+$', ''));
end

--[[
* Colour a line IN PLACE. The leading stamp (coloured `\30\NN[hh:mm:ss]\30\1`
* or plain `[hh:mm:ss]`) stays in front, untouched; the client's trailing
* end-of-message pair (`\127\49`, and any padding after it) stays at the end;
* the sentence between them is wrapped in the category's colour. A colour
* reset INSIDE the sentence (the client highlights item names, and a
* two-line message carries a second stamp at its seam) re-opens our colour
* rather than dropping the rest of the line back to the default.
--]]
--[[
* NAME HIGHLIGHTING (1.1.0 slice 6), inside the text between tags only: the
* body is walked as runs of drawable text split by the two-byte tag pairs
* (chat-tags-are-two-bytes-wide), so a colour code's argument byte or the
* end marker's '1' is never read as part of a word. In each run every name
* in `marks` (longest first) is matched as a WHOLE word -- %f frontiers, so
* "Makalov" never colours inside "Makalovich" -- and wrapped in its colour,
* re-opening `reopen` (the line's own colour) after it.
--]]
local function highlight(body, reopen, marks)
    local out = { };
    local pos = 1;

    while (pos <= #body) do
        local at  = body:find('[\30\31\127\239]', pos);
        local run = body:sub(pos, (at or (#body + 1)) - 1);

        for _, m in ipairs(marks) do
            run = run:gsub(m.pattern, function (word)
                return m.open .. word .. reopen;
            end);
        end

        out[#out + 1] = run;

        if (at == nil) then
            break;
        end

        out[#out + 1] = body:sub(at, at + 1);
        pos = at + 2;
    end

    return table.concat(out);
end

local function paint(raw, code, marks)
    local stamp = raw:match('^(\30.%[%d%d?:%d%d:%d%d%]\30.%s*)')
               or raw:match('^(%[%d%d?:%d%d:%d%d%]%s*)')
               or '';
    local rest  = raw:sub(#stamp + 1);
    local tail  = rest:match('(\127.[%s%z]*)$') or '';
    local body  = rest:sub(1, #rest - #tail);

    if (body:match('^%s*$') ~= nil) then
        return raw;
    end

    local open = code ~= nil and ('\30' .. string.char(code)) or nil;

    if (open ~= nil) then
        body = body:gsub(RESET, open);
    end

    if (marks ~= nil) then
        body = highlight(body, open or RESET, marks);
    end

    if (open == nil) then
        return stamp .. body .. tail;
    end

    return stamp .. open .. body .. RESET .. tail;
end

-- A whole number with thousands separators: 1872 -> "1,872".
local function commas(n)
    local digits = tostring(math.floor(tonumber(n) or 0));
    local out    = digits:reverse():gsub('(%d%d%d)', '%1,'):reverse();

    return (out:gsub('^,', ''));
end

-- "1,872" or "1872" -> 1872.
local function number(text)
    return tonumber((tostring(text or ''):gsub(',', ''))) or 0;
end

-- The subject of the LAST sentence in `prefix`: "Makalov casts Protect.
-- Yukimura" -> "Yukimura". A two-sentence message is one line here once the
-- seam is a space, and the target is the second sentence's subject.
local function lastSubject(prefix)
    local subject = prefix:match('.*[%.!]%s+(.-)$') or prefix;

    return (subject:gsub('^%s+', ''):gsub('%s+$', ''));
end

----------------------------------------------------------------------------
-- Who is "the party"
----------------------------------------------------------------------------

local party = {
    names = { },
    roles = { },   -- 1.1.0: name -> 'self' | 'party' | 'alliance' (no pets)
    at    = nil,
};

local function readParty()
    local names = { };
    local roles = { };

    pcall(function ()
        local memory = AshitaCore:GetMemoryManager();
        local list   = memory:GetParty();
        local entity = memory:GetEntity();

        for i = 0, 17 do
            local active = list:GetMemberIsActive(i);

            if (active ~= nil and active ~= 0 and active ~= false) then
                local name = list:GetMemberName(i);

                if (type(name) == 'string' and name ~= '') then
                    names[name] = true;

                    if (roles[name] == nil) then
                        roles[name] = (i == 0 and 'self') or (i < 6 and 'party') or 'alliance';
                    end
                end

                -- A member's pet (an avatar, a wyvern, an automaton) fights
                -- for the party, so its hits are the party's hits.
                if (entity ~= nil) then
                    local index = list:GetMemberTargetIndex(i);
                    local pet   = index ~= nil and index > 0 and entity:GetPetTargetIndex(index) or 0;

                    if (pet ~= nil and pet > 0) then
                        local petName = entity:GetName(pet);

                        if (type(petName) == 'string' and petName ~= '') then
                            names[petName] = true;
                        end
                    end
                end
            end
        end
    end);

    return names, roles;
end

local function isParty(name, now)
    if (party.at == nil or now < party.at or (now - party.at) >= PARTY_REFRESH) then
        party.names, party.roles = readParty();
        party.at    = now;
    end

    return name ~= nil and party.names[name] == true;
end

-- dealt / taken / nil for an actor -> target line. A line between two
-- strangers is nobody's business here and is left alone.
--[[
* The names to highlight in one line (1.1.0 slice 6), or nil: every party and
* alliance member by role, plus the line's own monster(s) -- `enemies`, the
* side of a party line that is not the party, with its article dropped.
* Pets are left out on purpose: an avatar is called what its summoning spell
* is called, so "Makalov casts Carbuncle." would colour the spell.
--]]
local function nameMarks(enemies, now)
    if (not switchOn('names')) then
        return nil;
    end

    isParty(nil, now);

    local marks = { };

    for name, role in pairs(party.roles) do
        local code = nameCode(role);

        if (code ~= nil) then
            marks[#marks + 1] = { name = name, code = code };
        end
    end

    local enemyCode = nameCode('enemy');

    for _, enemy in ipairs(enemies or { }) do
        local bare = (enemy:gsub('^[Tt]he ', ''));

        if (enemyCode ~= nil and bare:find('%w') ~= nil and party.names[bare] == nil) then
            marks[#marks + 1] = { name = bare, code = enemyCode };
        end
    end

    if (#marks == 0) then
        return nil;
    end

    -- Longest first, so "Forest Funguar" is taken before a member called
    -- "Forest"; then by name, so the order never depends on pairs().
    table.sort(marks, function (a, b)
        if (#a.name ~= #b.name) then
            return #a.name > #b.name;
        end

        return a.name < b.name;
    end);

    for _, m in ipairs(marks) do
        m.pattern = wordPattern(m.name);
        m.open    = '\30' .. string.char(m.code);
    end

    return marks;
end

local function combatSide(actor, target, now)
    -- The TARGET decides first: a party member hitting a party member (a
    -- charmed friend) is damage the party took, whoever swung.
    if (target ~= nil and isParty(target, now)) then
        return 'taken';
    end

    if (actor ~= nil and isParty(actor, now)) then
        return 'dealt';
    end

    return nil;
end

----------------------------------------------------------------------------
-- Classification
--
-- Every pattern runs on the plain, trimmed text and names the message id it
-- was written against (src/map/enums/msg_basic.h carries the wording; the
-- harness renders those comments and holds the patterns to them).
--
-- Returns nil (leave the line alone) or a verdict:
--   { cat = <palette key>, combine = nil | 'points' | 'skill' | 'melee',
--     key = <bucket key>, ... what the combiner needs }
----------------------------------------------------------------------------

local POINT_LINES = {
    -- ExperiencePointsGained 8, LimitPointsGained 371, CapacityPointsGained 718
    { pattern = '^(.-) gains ([%d,]+) experience points%.$', kind = 'exp' },
    { pattern = '^(.-) gains ([%d,]+) limit points%.$',      kind = 'limit' },
    { pattern = '^(.-) gains ([%d,]+) capacity points%.$',   kind = 'capacity' },
};

local POINT_WORDS = {
    exp      = 'experience points',
    limit    = 'limit points',
    capacity = 'capacity points',
};

local function classifyPoints(text)
    -- Coloured, never combined -- and tested FIRST, because "EXP chain #2!
    -- Yukimura gains 300 experience points." also ends in a plain gain and
    -- would otherwise be bucketed under an actor called "EXP chain #2!
    -- Yukimura": ExpChain 253 / LimitChain 372 / CapacityChain 735 (the chain
    -- number is information) and LevelUp 9.
    if (text:find('^EXP chain') ~= nil or text:find(' attains level %d+!$') ~= nil) then
        return { cat = 'exp' };
    end

    if (text:find('^Limit chain') ~= nil) then
        return { cat = 'limit' };
    end

    if (text:find('^Capacity chain') ~= nil) then
        return { cat = 'capacity' };
    end

    for _, line in ipairs(POINT_LINES) do
        local actor, amount = text:match(line.pattern);

        if (actor ~= nil) then
            return { cat = line.kind, combine = 'points', key = actor .. '\0' .. line.kind,
                     actor = actor, kind = line.kind, amount = number(amount) };
        end
    end

    -- MeritPointGained 50, JobPointGained 719: one point per line, and the
    -- running total the client printed on the last one is kept.
    local actor, total = text:match('^(.-) earns a merit point! %(Total: ([%d,]+)%)$');

    if (actor ~= nil) then
        return { cat = 'merit', combine = 'points', key = actor .. '\0merit',
                 actor = actor, kind = 'merit', amount = 1, total = number(total) };
    end

    actor, total = text:match('^(.-) earns a job point! %(Total: ([%d,]+)%)$');

    if (actor ~= nil) then
        return { cat = 'jobpoint', combine = 'points', key = actor .. '\0jobpoint',
                 actor = actor, kind = 'jobpoint', amount = 1, total = number(total) };
    end

    return nil;
end

local function classifySkill(text)
    -- SkillGain 38: "<target>'s <skill> skill rises 0.X points."
    local actor, skill, tenths = text:match("^(.-)'s (.-) skill rises 0%.(%d) points?%.$");

    if (actor ~= nil) then
        return { cat = 'skill', combine = 'skill', key = actor .. '\0' .. skill,
                 actor = actor, skill = skill, tenths = tonumber(tenths) or 0 };
    end

    -- SkillLevelUp 53, coloured only.
    if (text:find("^.-'s .- skill reaches level %d+%.$") ~= nil) then
        return { cat = 'skill' };
    end

    return nil;
end

--[[
* THE FILTERS' VERDICTS (1.1.0 slice 7). A line between strangers used to be
* nil -- "nobody's business here". It is still left exactly alone unless the
* player turns a filter on, but the classifier now says WHAT it was, so the
* filters can hide it: somebody else's combat, somebody else's buff, a miss.
* No `cat`, so nothing colours, combines or routes it.
--]]
local OTHERS_COMBAT = { others = 'combat' };
local OTHERS_MISS   = { others = 'combat', miss = true };
local OTHERS_BUFF   = { others = 'buff' };

-- The doer of a two-sentence line's first sentence, or nil: "Makalov casts
-- Cure. Stranger" -> "Makalov".
local function doerOf(prefix)
    return prefix:match('^(.-) casts ') or prefix:match('^(.-) uses ');
end

local function classifyCombat(text, now)
    -- Ranged first, so "X's ranged attack" is never read as a melee actor.
    -- RangedAttackHit 352 / RangedAttackCrit 353 / RangedAttackMiss 354:
    -- coloured, not combined (slice 1 combines plain melee only).
    local actor, target = text:match("^(.-)'s ranged attack hits (.-) for [%d,]+ points? of damage%.$");

    if (actor == nil) then
        actor, target = text:match("^(.-)'s ranged attack scores a critical hit! (.-) takes [%d,]+ points? of damage%.$");
    end

    if (actor ~= nil) then
        local side = combatSide(actor, target, now);

        return side ~= nil and { cat = side, enemy = side == 'dealt' and target or actor } or OTHERS_COMBAT;
    end

    actor = text:match("^(.-)'s ranged attack misses%.$");

    if (actor ~= nil) then
        return isParty(actor, now) and { cat = 'dealt', miss = true } or OTHERS_MISS;
    end

    -- AbilityMisses 158 "<user> uses <ability>, but misses.", UsesSkillMisses
    -- 188 "... but misses <target>.", UsesButMisses 324. Never coloured (1.0.0
    -- left them alone and still does); only the miss filter reads them.
    local user, missed = text:match('^([^%.!]-) uses [^%.!]-,? but misses ?([^%.!]-)%.$');

    if (user ~= nil) then
        if (isParty(user, now) or (missed ~= '' and isParty(missed, now))) then
            return { miss = true };
        end

        return OTHERS_MISS;
    end

    -- MELEE. AttackHits 1, AttackCrit 67 (two lines joined at the seam),
    -- AttackMisses 15.
    local swing = nil;
    local amount = 0;

    actor, target, amount = text:match('^(.-) hits (.-) for ([%d,]+) points? of damage%.$');

    if (actor ~= nil) then
        swing = 'hit';
    else
        actor, target, amount = text:match('^(.-) scores a critical hit! (.-) takes ([%d,]+) points? of damage%.$');

        if (actor ~= nil) then
            swing = 'crit';
        else
            actor, target = text:match('^(.-) misses (.-)%.$');

            if (actor ~= nil) then
                swing, amount = 'miss', 0;
            end
        end
    end

    -- A melee-shaped line with a sentence break in the ACTOR is not melee:
    -- "X uses Y. Z hits ..." is some ability's second half.
    if (swing ~= nil and actor:find('[%.!]') == nil) then
        local side = combatSide(actor, target, now);

        if (side == nil) then
            return swing == 'miss' and OTHERS_MISS or OTHERS_COMBAT;
        end

        -- A monster is "the Forest Funguar" mid-sentence and "The Forest
        -- Funguar" at the head of the critical hit's second line. One
        -- monster, one bucket -- and the combined sentence names it
        -- mid-sentence, so the lower-case article is the one it keeps.
        target = target:gsub('^The ', 'the ');

        return { cat = side, combine = 'melee', key = actor .. '\0' .. target,
                 actor = actor, target = target, swing = swing, amount = number(amount),
                 enemy = side == 'dealt' and target or actor, miss = swing == 'miss' };
    end

    -- Everything else that did damage: weapon skills, abilities, spells,
    -- skillchains, additional effects. "... <target> takes N points of damage."
    local before, victim = text:match('^(.-)%s*([^%.!]-) takes [%d,]+ points? of damage%.$');

    if (victim ~= nil and victim ~= '') then
        local doer = before:match('^(.-) uses ') or before:match('^(.-) casts ')
                  or before:match('^(.-) leads the casting of ');

        local side = combatSide(doer, victim, now);

        return side ~= nil and { cat = side, enemy = (side == 'dealt' and victim) or doer } or OTHERS_COMBAT;
    end

    -- Recovery: "<target> recovers N HP." / "... MP." (Cure, Regen, drains,
    -- Chakra, additional effects -- 7, 24, 263, 306, 318, 384 ...).
    local healed = text:match('^(.-) recovers [%d,]+ [HM]P%.$')
                or text:match('^(.-) recovers [%d,]+ hit points!$');

    if (healed ~= nil) then
        if (isParty(lastSubject(healed), now)) then
            return { cat = 'heal' };
        end

        -- A party member healing an outsider is not "somebody else's" line.
        return not isParty(doerOf(healed), now) and OTHERS_COMBAT or nil;
    end

    return nil;
end

local function classifyStatus(text, now)
    -- Gains: TargetGainsEffect 266 / 205, MagicGainsEffect 230,
    -- UsesAbilityGainsEffect 319, UsesSkillGainsEffect 186.
    local who = text:match('^(.-) gains the effect of .-%.$');

    if (who ~= nil and isParty(lastSubject(who), now)) then
        return { cat = 'buff' };
    end

    if (who ~= nil) then
        return not isParty(doerOf(who), now) and OTHERS_BUFF or nil;
    end

    -- Wears off: 206 "<target>'s <status> effect wears off." and 204
    -- "<target> is no longer <status>."
    who = text:match("^(.-)'s .- effect wears off%.$") or text:match('^(.-) is no longer .-%.$');

    if (who ~= nil and isParty(lastSubject(who), now)) then
        -- The digest (1.1.0 slice 4) takes only a plain one-sentence line,
        -- whose owner and effect it can name; a two-sentence one ("X uses
        -- Y. Z's Protect effect wears off.") stays in place, coloured.
        local owner, status = text:match("^([^%.!]-)'s (.-) effect wears off%.$");

        if (owner == nil) then
            owner, status = text:match('^([^%.!]-) is no longer (.-)%.$');
            status = status ~= nil and ('no longer ' .. status) or nil;
        end

        if (owner ~= nil and owner ~= '' and status ~= nil) then
            return { cat = 'wear', combine = 'digest', key = 'digest', who = owner, status = status };
        end

        return { cat = 'wear' };
    end

    if (who ~= nil) then
        return not isParty(doerOf(who), now) and OTHERS_BUFF or nil;
    end

    return nil;
end

-- An item as the treasure pool names it, for matching a find to its lots and
-- its winner: no article. "a bronze sword" / "the Bronze Sword" -> "bronze
-- sword" (the key, lower case) and "bronze sword" / "Bronze Sword" (as said).
local function bareItem(phrase)
    local bare = phrase:gsub('^%s+', ''):gsub('^[Aa]n? ', ''):gsub('^[Tt]he ', '');

    return bare;
end

local function itemKey(phrase)
    return bareItem(phrase):lower();
end

local function classifyItem(text)
    -- 1.1.0 slice 3, loot grouping. Obtains 565 / 582 with gil: one line per
    -- member of a split, summed per bucket.
    local actor, gil = text:match('^([^%.!]-) obtains ([%d,]+) gil%.$');

    if (actor ~= nil and actor ~= '') then
        return { cat = 'item', combine = 'gil', key = 'gil', actor = actor, amount = number(gil) };
    end

    -- "You find a bronze sword on the Forest Funguar." -- a drop entering the
    -- pool. One bucket per monster, so a kill's drops share a line.
    local phrase, mob = text:match('^You find (.-) on (.-)%.$');

    if (phrase ~= nil and phrase ~= '' and mob ~= '') then
        return { cat = 'item', combine = 'loot', key = 'loot\0' .. mob:lower(), item = phrase, mob = mob,
                 enemy = mob };
    end

    -- "<member>'s lot for the bronze sword: 523 points." No colour of its own
    -- (1.0.0 left it alone and still does when it joins nothing); it only
    -- ever joins the find it answers.
    local who, item, points = text:match("^([^%.!]-)'s lot for (.-): ([%d,]+) points?%.$");

    if (who ~= nil and who ~= '') then
        return { loot = 'lot', hideCat = 'item', who = who, item = itemKey(item), points = number(points) };
    end

    -- "<member> obtains a bronze sword." -- the pool's distribution line.
    who, item = text:match('^([^%.!]-) obtains (.-)%.$');

    if (who ~= nil and who ~= '' and item ~= '') then
        return { cat = 'item', loot = 'obtain', who = who, item = itemKey(item) };
    end

    -- Everything else that obtains or finds: coloured only (1.0.0).
    if (text:find(' obtains ') ~= nil or text:find('^You obtain ') ~= nil
        or text:find('^You find ') ~= nil) then
        return { cat = 'item' };
    end

    return nil;
end

local function classify(text, family, now)
    if (family == 'points') then
        return classifyPoints(text);
    elseif (family == 'skill') then
        return classifySkill(text);
    elseif (family == 'combat') then
        return classifyCombat(text, now);
    elseif (family == 'status') then
        return classifyStatus(text, now);
    elseif (family == 'item') then
        return classifyItem(text);
    end

    return nil;
end

--[[
* CASTS (1.1.0 slice 2). One spell or ability with several targets arrives as
* a HEAD line naming the caster and the first target, then one FOLLOW-ON line
* per further target naming only the target:
*
*     MagicGainsEffect 230        Makalov casts Protectra IV. Makalov gains the effect of Protect.
*     TargetGainsEffect 266         Yukimura gains the effect of Protect.
*     MagicRecoversHP 7           Makalov casts Curaga. Yukimura recovers 64 HP.
*     TargetRecoversHP 367 / 263    Kagetora recovers 60 HP.
*     MagicDamage 2               Makalov casts Firaga. The Bat takes 100 points of damage.
*     UsesAbilityTakesDamage 110  Makalov uses Cyclone. The Bat takes 100 points of damage.
*   (and UsesAbilityGainsEffect 319, UsesSkillGainsEffect 186 as heads)
*
* The CLAUSE after the head's first sentence is what a follow-on must repeat
* to belong to it: the same effect, the same recovered pool, or damage. A
* clause returns (effect key, target, amount, status or pool).
--]]
local function castClause(s)
    local target, status = s:match('^([^%.!]-) gains the effect of ([^%.!]-)%.$');

    if (target ~= nil and target ~= '') then
        return 'gain\0' .. status, target, 0, status;
    end

    local amount, pool;

    target, amount, pool = s:match('^([^%.!]-) recovers ([%d,]+) ([HM]P)%.$');

    if (target ~= nil and target ~= '') then
        return 'recover\0' .. pool, target, number(amount), pool;
    end

    target, amount = s:match('^([^%.!]-) takes ([%d,]+) points? of damage%.$');

    if (target ~= nil and target ~= '') then
        return 'take', target, number(amount), nil;
    end

    return nil;
end

-- A head: "<doer> casts|uses <name>. <clause>". Returns the first sentence
-- (without its full stop) and the clause's parts, or nil.
local function castHead(text)
    local head, rest = text:match('^([^%.!]- casts [^%.!]-)%.%s+(.+)$');

    if (head == nil) then
        head, rest = text:match('^([^%.!]- uses [^%.!]-)%.%s+(.+)$');
    end

    if (head == nil) then
        return nil;
    end

    local effect, target, amount, what = castClause(rest);

    if (effect == nil) then
        return nil;
    end

    return head, effect, target, amount, what;
end

----------------------------------------------------------------------------
-- The combiner
----------------------------------------------------------------------------

-- Which switch owns which combine kind.
local COMBINE_SWITCH = {
    points = 'combinePoints',
    skill  = 'combineSkill',
    melee  = 'combineMelee',
    cast   = 'groupCasts',      -- 1.1.0 slice 2
    loot   = 'groupLoot',       -- 1.1.0 slice 3
    gil    = 'groupLoot',
    digest = 'digest',          -- 1.1.0 slice 4 (defaults OFF)
};

-- Whether a combine kind's switch is on (and the master). The 1.0.0 keys and
-- the grouping keys default ON; a key whose default is false is on only when
-- the file says true.
local function kindOn(kind)
    local key = COMBINE_SWITCH[kind];

    if (key == nil) then
        return false;
    end

    if (rawget(defaultConfig, key) == false) then
        return switchOn(key);
    end

    return featureOn(key);
end

--[[
* How long a cast collects its follow-on lines. They arrive with the head --
* one action, one burst of messages -- so this is short, and a lone Cure is
* held no longer than this before it is said. ONLY THE GAME CAN CONFIRM that
* every target's line of one action reaches text_in within it; one that
* arrives later is simply not folded (it stands as its own line).
--]]
local CAST_WINDOW = 0.5;

local buckets = {
    open  = { },   -- key -> bucket, still collecting
    ready = { },   -- closed buckets waiting for the next tick, in close order
    count = 0,     -- #open, kept by hand (open is keyed)
    seq   = 0,     -- open order, so a flush is in the order the fight happened
};

-- "A, B, C": a list as the folded line says it. A target after the first is
-- mid-sentence, so a monster's capital article is lowered ("the Bee").
local function nameList(items)
    local out = { };

    for i, name in ipairs(items) do
        out[i] = i > 1 and (name:gsub('^The ', 'the ')) or name;
    end

    return table.concat(out, ', ');
end

local function describeCast(b)
    local names   = { };
    local amounts = { };

    for i, t in ipairs(b.targets) do
        names[i]   = t.name;
        amounts[i] = commas(t.amount);
    end

    if (b.kind == 'gain') then
        return string.format('%s. %s gain the effect of %s.', b.head, nameList(names), b.what);
    end

    if (b.kind == 'recover') then
        return string.format('%s. %s recover %s %s (%s).', b.head, nameList(names), commas(b.amount), b.what,
            table.concat(amounts, ', '));
    end

    return string.format('%s. %s take %s points of damage (%s).', b.head, nameList(names), commas(b.amount),
        table.concat(amounts, ', '));
end

-- "A, B and C".
local function listAnd(items)
    if (#items <= 1) then
        return items[1] or '';
    end

    return table.concat(items, ', ', 1, #items - 1) .. ' and ' .. items[#items];
end

--[[
* A kill's loot as one line: every drop the monster left, then what became of
* each -- who obtained it (with their winning lot when the lot line was seen)
* or, still in the pool when the window closed, the lots cast so far. A drop
* nobody has claimed yet says nothing more; its later "obtains" line stands
* on its own, coloured, as in 1.0.0.
*
*     You find a bronze sword and a beastcoin on the Forest Funguar. Makalov
*     obtains the bronze sword (lot 523); Yukimura obtains the beastcoin.
--]]
local function describeLoot(b)
    local finds    = { };
    local outcomes = { };

    for i, it in ipairs(b.items or { }) do
        finds[i] = it.phrase;

        if (it.winner ~= nil) then
            local lot = nil;

            for _, l in ipairs(it.lots) do
                if (l.who == it.winner) then
                    lot = l.points;
                end
            end

            outcomes[#outcomes + 1] = string.format('%s obtains the %s%s', it.winner, bareItem(it.phrase),
                lot ~= nil and (' (lot ' .. commas(lot) .. ')') or '');
        elseif (#it.lots > 0) then
            local lots = { };

            for j, l in ipairs(it.lots) do
                lots[j] = l.who .. ' ' .. commas(l.points);
            end

            outcomes[#outcomes + 1] = string.format('lots on the %s: %s', bareItem(it.phrase), table.concat(lots, ', '));
        end
    end

    local text = string.format('You find %s on %s', listAnd(finds), b.mob or '');

    if (#outcomes > 0) then
        text = text .. '. ' .. table.concat(outcomes, '; ');
    end

    return text .. '.';
end

-- A gil split as one line: "Makalov, Yukimura, Kagetora obtain 120 gil each
-- (360 gil)"; unequal shares name each; one member twice is a count.
local function describeGil(b)
    local order = b.order or { };
    local first = order[1];

    if (#order == 1) then
        return string.format('%s obtains %s gil (%d)', first, commas(b.gil[first]), b.lines);
    end

    local same = true;

    for _, who in ipairs(order) do
        if (b.gil[who] ~= b.gil[first]) then
            same = false;
        end
    end

    if (same) then
        return string.format('%s obtain %s gil each (%s gil)', table.concat(order, ', '), commas(b.gil[first]),
            commas(b.amount));
    end

    local parts = { };

    for i, who in ipairs(order) do
        parts[i] = string.format('%s (%s)', who, commas(b.gil[who]));
    end

    return string.format('%s obtain %s gil', table.concat(parts, ', '), commas(b.amount));
end

local function describe(b)
    if (b.lines == 1) then
        return b.first;
    end

    if (b.combine == 'cast') then
        return describeCast(b);
    end

    if (b.combine == 'loot') then
        return describeLoot(b);
    end

    if (b.combine == 'gil') then
        return describeGil(b);
    end

    if (b.combine == 'digest') then
        -- "Worn off: Protect (Makalov, Yukimura, Kagetora); Shell (Makalov)"
        local parts = { };

        for i, w in ipairs(b.worn or { }) do
            parts[i] = string.format('%s (%s)', w.status, table.concat(w.names, ', '));
        end

        return 'Worn off: ' .. table.concat(parts, '; ');
    end

    if (b.combine == 'points') then
        if (b.kind == 'merit' or b.kind == 'jobpoint') then
            return string.format('%s earns %s %s (Total: %s)', b.actor, commas(b.amount),
                b.kind == 'merit' and 'merit points' or 'job points', commas(b.total or 0));
        end

        return string.format('%s gains %s %s (%d)', b.actor, commas(b.amount), POINT_WORDS[b.kind], b.lines);
    end

    if (b.combine == 'skill') then
        return string.format("%s's %s skill rises %d.%d points (%d)", b.actor, b.skill,
            math.floor(b.tenths / 10), b.tenths % 10, b.lines);
    end

    -- melee
    local landed = b.hits + b.crits;
    local extras = { };

    if (b.crits > 0) then
        extras[#extras + 1] = 'crit x' .. b.crits;
    end

    if (landed == 0) then
        return string.format('%s misses %s %d times', b.actor, b.target, b.misses);
    end

    if (b.misses > 0) then
        extras[#extras + 1] = 'miss x' .. b.misses;
    end

    local text = string.format('%s hits %s %s for %s damage', b.actor, b.target,
        landed == 1 and '1 time' or (landed .. ' times'), commas(b.amount));

    if (#extras > 0) then
        text = text .. ' (' .. table.concat(extras, ', ') .. ')';
    end

    return text;
end

-- The finished line, exactly as it goes to AddChatMessage.
local function render(b)
    local text = describe(b);

    local code  = colourOf(b.cat);
    local marks = nameMarks(b.enemies or (b.enemy ~= nil and { b.enemy } or nil), os.clock());

    if (marks ~= nil) then
        text = highlight(text, code ~= nil and ('\30' .. string.char(code)) or RESET, marks);
    end

    if (code ~= nil) then
        text = '\30' .. string.char(code) .. text .. RESET;
    end

    return MARK .. text;
end

-- How long a bucket collects: a cast its short CAST_WINDOW, everything else
-- the player's combine window.
local function bucketWindow(b)
    if (b.combine == 'cast') then
        return math.min(windowSeconds(), CAST_WINDOW);
    end

    if (b.combine == 'digest') then
        return digestSeconds();
    end

    return windowSeconds();
end

local function close(key)
    local b = buckets.open[key];

    if (b ~= nil) then
        buckets.open[key] = nil;
        buckets.count     = buckets.count - 1;
        buckets.ready[#buckets.ready + 1] = b;
    end
end

-- Take a line into its bucket. Returns false when it could not be taken (the
-- ceiling), and the caller then leaves the line in the log.
local function capture(v, text, mode, now)
    local b = buckets.open[v.key];

    -- A bucket whose window has closed is finished even if the tick has not
    -- reached it yet: this line starts the next one.
    if (b ~= nil and (now < b.opened or (now - b.opened) >= bucketWindow(b))) then
        close(v.key);
        b = nil;
    end

    if (b == nil) then
        if (buckets.count >= MAX_BUCKETS) then
            return false;
        end

        buckets.seq = buckets.seq + 1;

        b = {
            key = v.key, combine = v.combine, cat = v.cat, mode = mode,
            opened = now, seq = buckets.seq, first = text, lines = 0,
            actor = v.actor, target = v.target, kind = v.kind, skill = v.skill,
            mob = v.mob, enemy = v.enemy,
            amount = 0, tenths = 0, total = nil, hits = 0, crits = 0, misses = 0,
        };

        buckets.open[v.key] = b;
        buckets.count       = buckets.count + 1;
    end

    b.lines = b.lines + 1;

    if (v.combine == 'points') then
        b.amount = b.amount + v.amount;
        b.total  = v.total or b.total;
    elseif (v.combine == 'skill') then
        b.tenths = b.tenths + v.tenths;
    elseif (v.combine == 'loot') then
        -- One more drop off the same monster.
        b.items = b.items or { };
        b.items[#b.items + 1] = { phrase = v.item, key = itemKey(v.item), lots = { }, winner = nil };
    elseif (v.combine == 'digest') then
        -- One more effect gone: grouped by effect, owners in arrival order.
        b.worn   = b.worn or { };
        b.wornAt = b.wornAt or { };

        local entry = b.wornAt[v.status];

        if (entry == nil) then
            entry = { status = v.status, names = { } };
            b.worn[#b.worn + 1]  = entry;
            b.wornAt[v.status] = entry;
        end

        entry.names[#entry.names + 1] = v.who;
    elseif (v.combine == 'gil') then
        -- One more share of a split: summed per member, in arrival order.
        b.gil   = b.gil or { };
        b.order = b.order or { };

        if (b.gil[v.actor] == nil) then
            b.order[#b.order + 1] = v.actor;
            b.gil[v.actor]        = 0;
        end

        b.gil[v.actor] = b.gil[v.actor] + v.amount;
        b.amount       = b.amount + v.amount;
    else
        b.amount = b.amount + v.amount;

        if (v.swing == 'hit') then
            b.hits = b.hits + 1;
        elseif (v.swing == 'crit') then
            b.crits = b.crits + 1;
        else
            b.misses = b.misses + 1;
        end
    end

    return true;
end

--[[
* A lot or a distribution line joins the find it answers: the newest open
* loot bucket, still inside its window, holding that item unclaimed. Returns
* true when it was taken (the caller blocks it).
--]]
local function joinLoot(v, now)
    if (not kindOn('loot')) then
        return false;
    end

    local best, bestItem = nil, nil;

    for _, b in pairs(buckets.open) do
        if (b.combine == 'loot' and now >= b.opened and (now - b.opened) < bucketWindow(b)
            and (best == nil or b.seq > best.seq)) then
            for _, it in ipairs(b.items or { }) do
                if (it.key == v.item and it.winner == nil) then
                    best, bestItem = b, it;
                    break;
                end
            end
        end
    end

    if (best == nil) then
        return false;
    end

    best.lines = best.lines + 1;

    if (v.loot == 'lot') then
        bestItem.lots[#bestItem.lots + 1] = { who = v.who, points = v.points };
    else
        bestItem.winner = v.who;
    end

    return true;
end

local function emit(b)
    local line = render(b);

    pcall(function ()
        AshitaCore:GetChatManager():AddChatMessage(routed(b.mode, b.cat), false, line);
    end);
end

-- THE FLUSH. Called from d3d_present (and unload), never from text_in. A
-- bucket goes when its window has closed, when the master or its own switch
-- has been turned off since it opened (nothing is ever left blocked and
-- unsaid), or unconditionally when `all` is set.
local function flush(now, all)
    for key, b in pairs(buckets.open) do
        if (all or now < b.opened or (now - b.opened) >= bucketWindow(b) or not kindOn(b.combine)) then
            close(key);
        end
    end

    if (#buckets.ready == 0) then
        return 0;
    end

    local ready = buckets.ready;

    buckets.ready = { };

    table.sort(ready, function (a, b) return a.seq < b.seq; end);

    for _, b in ipairs(ready) do
        emit(b);
    end

    return #ready;
end

----------------------------------------------------------------------------
-- Casts in flight (1.1.0 slice 2)
----------------------------------------------------------------------------

--[[
* THE SEQUENCE. A follow-on line names no caster, so it is only ever joined to
* the cast whose lines came IMMEDIATELY before it: the head, then its
* follow-ons, with no other battle line between them, on the same family and
* inside CAST_WINDOW of the head. Any other battle line ends the sequence (and
* closes the cast's bucket at once -- nothing more can join it). That is what
* keeps "The Bee takes 90 points of damage." from being folded into a cast it
* did not come from.
*
* The sequence is tracked whether or not grouping is on, so a later slice can
* know a follow-on belongs to a party cast even when it is not folded.
--]]
local sequence = {
    effect = nil,   -- the clause key a follow-on must repeat; nil = no sequence
    family = nil,
    cat    = nil,
    at     = 0,
    key    = nil,   -- the cast's open bucket, when grouping took the head
    hidden = false, -- the head was hidden by a filter: so is the rest (slice 7)
};

local function endCast()
    if (sequence.key ~= nil and buckets.open[sequence.key] ~= nil) then
        close(sequence.key);
    end

    sequence.effect = nil;
    sequence.key    = nil;
end

-- Take a head: open the sequence, and -- grouping on, under the ceiling --
-- its bucket. Returns true when the head was captured.
local function startCast(v, text, mode, family, now, hide)
    local head, effect, target, amount, what = castHead(text);

    if (head == nil) then
        return false;
    end

    sequence.effect = effect;
    sequence.family = family;
    sequence.cat    = v.cat;
    sequence.at     = now;
    sequence.key    = nil;
    sequence.hidden = hide == true;

    if (hide or not kindOn('cast') or buckets.count >= MAX_BUCKETS) then
        return false;
    end

    buckets.seq = buckets.seq + 1;

    local key = 'cast\0' .. buckets.seq;

    buckets.open[key] = {
        key = key, combine = 'cast', cat = v.cat, mode = mode, opened = now,
        seq = buckets.seq, first = text, lines = 1, head = head,
        kind = effect:match('^(%a+)'), what = what,
        targets = { { name = target, amount = amount } }, amount = amount,
        enemies = { v.enemy },
    };
    buckets.count = buckets.count + 1;
    sequence.key  = key;

    return true;
end

-- A line that may continue the sequence. Returns 'joined' (folded into the
-- cast: block it), 'follow' (the cast's own line, not folded), or nil (not
-- part of any cast -- and the sequence is over).
local function followCast(text, family, now)
    if (sequence.effect == nil) then
        return nil;
    end

    local effect, target, amount;

    if (family == sequence.family and now >= sequence.at and (now - sequence.at) < math.min(windowSeconds(), CAST_WINDOW)) then
        effect, target, amount = castClause(text);
    end

    if (effect == nil or effect ~= sequence.effect) then
        endCast();

        return nil;
    end

    local b = sequence.key ~= nil and buckets.open[sequence.key] or nil;

    if (b ~= nil and kindOn('cast')) then
        b.lines   = b.lines + 1;
        b.amount  = b.amount + amount;
        b.targets[#b.targets + 1] = { name = target, amount = amount };

        -- A party member's area spell: every further target is a monster.
        if (b.cat == 'dealt') then
            b.enemies[#b.enemies + 1] = target;
        end

        return 'joined';
    end

    return 'follow';
end

----------------------------------------------------------------------------
-- The filters (1.1.0 slice 7)
----------------------------------------------------------------------------

--[[
* Whether a verdict's line is to be hidden: BLOCKED, and never said again --
* the one thing in this addon that removes a line, so every switch is off by
* default, the master switch off shows everything, and a hidden line is never
* folded into anything either (it is judged before any bucket).
--]]
local function hidden(v)
    if (v.others == 'combat' and switchOn('hideOthersCombat')) then
        return true;
    end

    if (v.others == 'buff' and switchOn('hideOthersBuffs')) then
        return true;
    end

    if (v.miss == true and switchOn('hideMisses')) then
        return true;
    end

    local group = GROUP_OF[v.cat or v.hideCat or ''];

    return group ~= nil and switchOn('hide' .. group);
end

----------------------------------------------------------------------------
-- The line handler
----------------------------------------------------------------------------

-- One battle line, already known to be on a watched mode and not ours.
local function handle(e, raw, text, mode, family, now)
    -- The rest of a cast in flight (1.1.0 slice 2) comes first: it names no
    -- caster, so on its own it would be judged a stranger's line.
    local follow = followCast(text, family, now);

    -- Folded into its cast -- or the rest of a cast whose head was hidden.
    if (follow == 'joined' or (follow == 'follow' and sequence.hidden)) then
        e.blocked = true;

        return;
    end

    local verdict = classify(text, family, now);

    -- A follow-on names no party member, but it belongs to a party cast: it
    -- is never "somebody else's" line, and is left as 1.0.0 left it.
    if (verdict == nil or (follow == 'follow' and verdict.cat == nil and verdict.miss ~= true)) then
        return;
    end

    -- THE FILTERS (1.1.0 slice 7), before anything folds or colours. A
    -- hidden head hides its whole cast.
    if (hidden(verdict)) then
        e.blocked = true;

        if (follow == nil and verdict.cat ~= nil) then
            startCast(verdict, text, mode, family, now, true);
        end

        return;
    end

    -- A head (a party member's spell or ability, or one landing on the
    -- party) opens a sequence; with grouping on it is held for its targets.
    if (follow == nil and verdict.cat ~= nil and startCast(verdict, text, mode, family, now)) then
        e.blocked = true;

        return;
    end

    -- A lot or a distribution line joins the find it answers (1.1.0 slice 3).
    if (verdict.loot ~= nil and joinLoot(verdict, now)) then
        e.blocked = true;

        return;
    end

    -- Somebody else's line, a lone miss verdict, a lot that joined nothing:
    -- nothing below is for them (no colour, no names, no routing).
    if (verdict.cat == nil) then
        return;
    end

    -- The bucket keeps the line's WHOLE mode, extension bits and all: the
    -- combined line goes back to the client exactly as the first original
    -- was filed, so it lands in the same window.
    if (verdict.combine ~= nil and kindOn(verdict.combine) and capture(verdict, text, mode, now)) then
        -- Said later, from the present tick, as part of its bucket.
        e.blocked = true;

        return;
    end

    local code  = colourOf(verdict.cat);
    local marks = nameMarks(verdict.enemy ~= nil and { verdict.enemy } or nil, now);

    if (code ~= nil or marks ~= nil) then
        e.message_modified = paint(raw, code, marks);
    end

    -- Window 2 (1.1.0): the same line, re-moded in place -- dwquest's feed
    -- lever. Nothing blocked, nothing re-printed.
    local moved = routed(mode, verdict.cat);

    if (moved ~= mode) then
        e.mode_modified = moved;
    end
end

ashita.events.register('text_in', 'dwchat_text_in', function (e)
    local raw = e.message_modified or e.message;

    if (type(raw) ~= 'string') then
        return;
    end

    -- OUR OWN LINE, back from AddChatMessage: take the mark out and leave it
    -- be. First, and whatever the switches say -- a line emitted just before
    -- the player turned the addon off still comes back through here.
    local at = raw:find(MARK, 1, true);

    if (at ~= nil) then
        e.message_modified = raw:sub(1, at - 1) .. raw:sub(at + #MARK);

        return;
    end

    if (config.enabled ~= true or e.blocked or e.injected) then
        return;
    end

    local mode = e.mode_modified or e.mode;

    if (type(mode) ~= 'number') then
        return;
    end

    local family = MODE_FAMILY[bit.band(mode, 0xFF)];

    if (family == nil) then
        return;
    end

    local text = plainText(raw);

    if (text == '' or text:find(SENDER_PATTERN) ~= nil or text:sub(1, 3) == '[dw') then
        return;
    end

    handle(e, raw, text, mode, family, os.clock());
end);

----------------------------------------------------------------------------
-- The settings window
----------------------------------------------------------------------------

local state = {
    open     = T{ false },
    reported = false,
    master   = T{ false },
    colors   = T{ true },
    points   = T{ true },
    skill    = T{ true },
    melee    = T{ true },
    window   = T{ WINDOW_DEFAULT },
    bufs     = { },   -- 1.1.0: one checkbox buffer per key, made on first draw
};

local SAMPLES = {
    { 'dealt',    'Makalov hits the Forest Funguar for 28 points of damage.' },
    { 'taken',    'The Forest Funguar hits Makalov for 12 points of damage.' },
    { 'heal',     'Makalov recovers 64 HP.' },
    { 'buff',     'Makalov gains the effect of Protect.' },
    { 'wear',     "Makalov's Protect effect wears off." },
    { 'exp',      'Makalov gains 1,872 experience points (3)' },
    { 'limit',    'Makalov gains 600 limit points (2)' },
    { 'capacity', 'Makalov gains 1,029 capacity points (2)' },
    { 'item',     'Makalov obtains a bronze sword.' },
    { 'skill',    "Makalov's sword skill rises 0.3 points (3)" },
};

local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local function say(text)
    print(chat.header('dwchat'):append(chat.message(text)));
end

local function setMaster(on)
    config.enabled = on == true;
    save();
end

local function checkbox(label, buffer, key, hint)
    buffer[1] = config[key] ~= false;

    if (imgui.Checkbox(label, buffer)) then
        config[key] = buffer[1] == true;
        save();
    end

    tip(hint);
end

--[[
* 1.1.0's controls: one buffer per key, made on first draw (the UI mirror),
* read back from config every frame and written back on a change -- the same
* shape as checkbox() above. `on` is the key's default, so a switch that
* defaults OFF reads off until the file says true.
--]]
local function switchBox(label, key, on, hint)
    local buffer = state.bufs[key];

    if (buffer == nil) then
        buffer = T{ on };
        state.bufs[key] = buffer;
    end

    if (on) then
        buffer[1] = config[key] ~= false;
    else
        buffer[1] = rawget(config, key) == true;
    end

    if (imgui.Checkbox(label, buffer)) then
        config[key] = buffer[1] == true;
        save();
    end

    tip(hint);
end

-- A collapsing section. Closed until the player opens it, so the window
-- stays as short as 1.0.0's for anyone who never does.
local function section(title, id, hint)
    local open = imgui.CollapsingHeader(title .. '##dwchat_sec_' .. id);

    tip(hint);

    return open == true;
end

local function renderRouting()
    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled('Moves a kind of line out of the battle log into the chat window (Window 2 on the game\'s stock Log setup), the way /quests feed moves the kill feed. Nothing is hidden.');
    imgui.PopTextWrapPos();

    for _, group in ipairs(GROUPS) do
        switchBox(GROUP_LABEL[group] .. '##dwchat_route_' .. group, 'route' .. group, false,
            'Send these lines to Window 2 instead of the battle log.\nThey keep their colour; combined lines follow them too.');
    end
end

local function renderGrouping()
    switchBox('One line per spell or ability, with its targets##dwchat_group_casts', 'groupCasts', true,
        'A spell or ability that lands on several targets becomes one line:\n"Makalov casts Protectra IV. Makalov, Yukimura, Kagetora gain the effect of Protect."\nAlso healing ("... recover 184 HP (64, 60, 60).") and area damage.\nA single-target cast is held at most half a second, then said as it was.');
end

local function renderLootSwitch()
    switchBox('One line per kill\'s loot, gil splits summed##dwchat_group_loot', 'groupLoot', true,
        'A monster\'s drops, the lots on them and who obtained them become one line:\n"You find a bronze sword on the Forest Funguar. Makalov obtains the bronze sword (lot 523)."\nA gil split to several members becomes "Makalov, Yukimura obtain 120 gil each (240 gil)".');
end

local function renderDigest()
    switchBox('Collect worn-off effects into one line##dwchat_digest', 'digest', false,
        'Instead of one line per effect per party member, a single line every few seconds:\n"Worn off: Protect (Makalov, Yukimura, Kagetora); Shell (Makalov, Yukimura)".\nA lone line is said in its own words. Off by default: it holds these lines back.');

    local buffer = state.bufs.digestWindow;

    if (buffer == nil) then
        buffer = T{ DIGEST_DEFAULT };
        state.bufs.digestWindow = buffer;
    end

    buffer[1] = digestSeconds();
    imgui.SetNextItemWidth(200);

    if (imgui.SliderFloat('Digest every##dwchat_digest_window', buffer, DIGEST_MIN, DIGEST_MAX, '%.0f s')) then
        config.digestWindow = math.max(DIGEST_MIN, math.min(DIGEST_MAX, tonumber(buffer[1]) or DIGEST_DEFAULT));
        save();
    end

    tip('How long worn-off lines are collected before the digest is printed.');
end

-- The twelve categories as the Colours section lists them, each with the
-- sample its live preview draws.
local COLOR_ROWS = {
    { 'dealt',    'Your hits',        'Makalov hits the Forest Funguar for 28 points of damage.' },
    { 'taken',    'Damage taken',     'The Forest Funguar hits Makalov for 12 points of damage.' },
    { 'heal',     'Healing',          'Makalov recovers 64 HP.' },
    { 'buff',     'Buff gained',      'Makalov gains the effect of Protect.' },
    { 'wear',     'Buff worn off',    "Makalov's Protect effect wears off." },
    { 'exp',      'Experience',       'Makalov gains 1,872 experience points (3)' },
    { 'limit',    'Limit points',     'Makalov gains 600 limit points (2)' },
    { 'merit',    'Merit points',     'Makalov earns 2 merit points (Total: 5)' },
    { 'capacity', 'Capacity points',  'Makalov gains 1,029 capacity points (2)' },
    { 'jobpoint', 'Job points',       'Makalov earns 2 job points (Total: 12)' },
    { 'item',     'Items and gil',    'Makalov obtains a bronze sword.' },
    { 'skill',    'Skill-ups',        "Makalov's sword skill rises 0.3 points (3)" },
};

-- One colour picker. `key` is the settings key it writes.
local function colourCombo(label, key, code, hint)
    local row = COLOR_CHOICES[COLOR_VALID[code] or 1];

    imgui.SetNextItemWidth(170);

    if (imgui.BeginCombo(label, row[2])) then
        for _, choice in ipairs(COLOR_CHOICES) do
            if (imgui.Selectable(choice[2] .. '##' .. key .. '_' .. choice[1], choice[1] == code)) then
                config[key] = choice[1];
                save();
            end
        end

        imgui.EndCombo();
    end

    tip(hint);
end

-- The live preview: `text` drawn in the colour `code` stands for.
local function swatch(code, text)
    local row = COLOR_CHOICES[COLOR_VALID[code] or 1];

    if (row[3] == nil) then
        imgui.Text(text);
    else
        imgui.TextColored(row[3], text);
    end
end

local function renderColours()
    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled('Each kind of line\'s colour. The sample beside a picker changes as you pick; "Preview the colours" below prints them into your real chat log.');
    imgui.PopTextWrapPos();

    for _, row in ipairs(COLOR_ROWS) do
        local cat  = row[1];
        local code = chosenCode(cat);

        colourCombo(row[2] .. '##dwchat_color_' .. cat, COLOR_KEY[cat], code,
            'The colour of this kind of line. "Game default" leaves it as the game draws it.');
        imgui.SameLine();
        swatch(code, row[3]);
    end

    if (imgui.Button('Back to the standard colours##dwchat_color_reset')) then
        for cat, key in pairs(COLOR_KEY) do
            config[key] = PALETTE[cat];
        end

        save();
    end

    tip('Puts every colour above back to DWChat\'s own palette.');
end

local NAME_ROWS = {
    { 'self',     'You',          'Makalov (you)' },
    { 'party',    'Your party',   'Yukimura (party)' },
    { 'alliance', 'Alliance',     'Tenzen (alliance)' },
    { 'enemy',    'Enemies',      'Forest Funguar (enemy)' },
};

local function renderNames()
    switchBox('Highlight names inside lines##dwchat_names', 'names', false,
        'Inside every line DWChat colours, you, your party, your alliance and the monster\nthe line is about each get their own colour.\nOff by default: a character can be named like a spell or a word ("Fire"),\nand then that word is coloured too.');

    for _, row in ipairs(NAME_ROWS) do
        local key  = NAME_KEY[row[1]];
        local code = tonumber(rawget(config, key)) or NAME_PALETTE[row[1]];

        colourCombo(row[2] .. '##dwchat_name_' .. row[1], key, code,
            'The colour this kind of name takes. "Game default" leaves it in the line\'s own colour.');
        imgui.SameLine();
        swatch(code, row[3]);
    end
end

local function renderFilters()
    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled('Hidden lines are removed from the log and never shown again while DWChat is on. Switching DWChat off shows everything.');
    imgui.PopTextWrapPos();

    switchBox('Hide combat that is not your party\'s##dwchat_hide_others_combat', 'hideOthersCombat', false,
        'Hits, misses, damage and healing between players and monsters\noutside your party and alliance.');
    switchBox('Hide misses##dwchat_hide_misses', 'hideMisses', false,
        'Every "misses" line -- yours, your party\'s, and monsters missing you.\nA combined melee line then counts only what landed.');
    switchBox('Hide other people\'s buffs##dwchat_hide_others_buffs', 'hideOthersBuffs', false,
        'Effects gained and worn off by anyone outside your party and alliance,\nmonsters included (a monster\'s Stoneskin, too).');

    imgui.TextDisabled('Hide entirely:');

    for _, group in ipairs(GROUPS) do
        switchBox(GROUP_LABEL[group] .. '##dwchat_hide_' .. group, 'hide' .. group, false,
            'Remove every line of this kind from the log.');
    end
end

local function renderSections()
    if (section('Routing', 'routing', 'Send chosen kinds of line to Window 2.')) then
        renderRouting();
    end

    if (section('Grouping', 'grouping', 'Fold a spell\'s or ability\'s targets, and a kill\'s loot, into one line.')) then
        renderGrouping();
        renderLootSwitch();
    end

    if (section('Digest', 'digest', 'One periodic line for everything that wore off across the party.')) then
        renderDigest();
    end

    if (section('Colours', 'colours', 'Choose the colour of each kind of line, with a live preview.')) then
        renderColours();
    end

    if (section('Names', 'names', 'Colour you, your party, your alliance and enemies inside lines.')) then
        renderNames();
    end

    if (section('Filters', 'filters', 'Hide lines you do not want to see.')) then
        renderFilters();
    end
end

local function renderWindow()
    imgui.PushTextWrapPos(0.0);
    imgui.Text('Colour-codes the battle log and folds its spam into fewer lines, inside the game\'s own chat windows. Off until you switch it on; switching it off puts the log back exactly as it was.');
    imgui.PopTextWrapPos();

    imgui.Separator();

    state.master[1] = config.enabled == true;

    if (imgui.Checkbox('DWChat is on##dwchat_master', state.master)) then
        setMaster(state.master[1]);
    end

    tip('The master switch. Off: every chat line is left exactly as the game sent it.\nSame as typing /dwchat on or /dwchat off.');

    if (config.enabled ~= true) then
        imgui.SameLine();
        imgui.TextDisabled('(everything below waits for this)');
    end

    imgui.Separator();

    checkbox('Colour-code battle lines##dwchat_colors', state.colors, 'colors',
        'Your party\'s hits, damage taken, healing, buffs and what wears off, points, items\nand skill-ups each in their own colour. Nothing is moved or removed.');
    checkbox('Combine experience, limit, capacity and merit gains##dwchat_points', state.points, 'combinePoints',
        'Several gains by the same character inside the window become one line:\n"Makalov gains 1,872 experience points (3)".');
    checkbox('Combine skill-ups##dwchat_skill', state.skill, 'combineSkill',
        'Several rises of the same skill inside the window become one line:\n"Makalov\'s sword skill rises 0.3 points (3)".');
    checkbox('Combine melee rounds##dwchat_melee', state.melee, 'combineMelee',
        'Plain melee from one attacker to one target inside the window becomes one line:\n"Makalov hits the Forest Funguar 3 times for 84 damage (crit x1, miss x1)".\nRanged attacks, weapon skills and spells are only coloured.');

    state.window[1] = windowSeconds();
    imgui.SetNextItemWidth(200);

    if (imgui.SliderFloat('Combine window##dwchat_window', state.window, WINDOW_MIN, WINDOW_MAX, '%.1f s')) then
        config.window = math.max(WINDOW_MIN, math.min(WINDOW_MAX, tonumber(state.window[1]) or WINDOW_DEFAULT));
        save();
    end

    tip('How long a combined line waits for more of the same before it is printed.\nLonger folds more lines together; shorter keeps the log closer to real time.');

    renderSections();

    imgui.Separator();

    if (imgui.Button('Preview the colours##dwchat_preview')) then
        for _, sample in ipairs(SAMPLES) do
            local code = chosenCode(sample[1]);

            print(MARK .. (code ~= 0 and ('\30' .. string.char(code) .. sample[2] .. RESET) or sample[2]));
        end
    end

    tip('Prints one sample line per colour into the chat log, so you can see them on your own window.');

    imgui.SameLine();
    imgui.TextDisabled(string.format('%d line(s) waiting to be combined', buckets.count));
end

ashita.events.register('d3d_present', 'dwchat_present', function ()
    flush(os.clock(), false);

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 460, 330 }, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE: the widest checkbox label and its tooltip-bearing row
    -- on one line, and the slider under them.
    imgui.SetNextWindowSizeConstraints({ 420, 280 }, { 99999, 99999 });

    local visible = imgui.Begin('DriftwoodXI Chat##dwchat', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwchat'):append(chat.error('render error: ' .. tostring(err))));
                say('Window closed. /dwchat on and /dwchat off still work.');
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function status()
    if (config.enabled ~= true) then
        say('DWChat is OFF: the chat log is untouched. /dwchat on switches it on; /dwchat opens the settings.');
        return;
    end

    say(string.format('DWChat is ON: colours %s; combining points %s, skill-ups %s, melee %s; window %.1f s.',
        config.colors ~= false and 'on' or 'off',
        config.combinePoints ~= false and 'on' or 'off',
        config.combineSkill ~= false and 'on' or 'off',
        config.combineMelee ~= false and 'on' or 'off',
        windowSeconds()));

    -- 1.1.0: what the sections add, in one line.
    local routedGroups = { };
    local hiddenGroups = { };

    for _, group in ipairs(GROUPS) do
        if (rawget(config, 'route' .. group) == true) then
            routedGroups[#routedGroups + 1] = group:lower();
        end

        if (rawget(config, 'hide' .. group) == true) then
            hiddenGroups[#hiddenGroups + 1] = group:lower();
        end
    end

    local filters = { };

    if (rawget(config, 'hideOthersCombat') == true) then filters[#filters + 1] = "others' combat"; end
    if (rawget(config, 'hideMisses') == true) then filters[#filters + 1] = 'misses'; end
    if (rawget(config, 'hideOthersBuffs') == true) then filters[#filters + 1] = "others' buffs"; end

    for _, group in ipairs(hiddenGroups) do
        filters[#filters + 1] = group;
    end

    say(string.format('Grouping casts %s, loot %s; digest %s; names %s; Window 2: %s; hidden: %s.',
        config.groupCasts ~= false and 'on' or 'off',
        config.groupLoot ~= false and 'on' or 'off',
        rawget(config, 'digest') == true and string.format('every %d s', digestSeconds()) or 'off',
        rawget(config, 'names') == true and 'on' or 'off',
        #routedGroups > 0 and table.concat(routedGroups, ', ') or 'nothing',
        #filters > 0 and table.concat(filters, ', ') or 'nothing'));
end

ashita.events.register('command', 'dwchat_command', function (e)
    local args  = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwchat') then
        return;
    end

    e.blocked = true;

    local verb = #args > 1 and args[2]:lower() or '';

    if (verb == '') then
        state.open[1] = not state.open[1];

        if (state.open[1]) then
            state.reported = false;
        end

        return;
    end

    if (verb == 'on' or verb == 'off') then
        setMaster(verb == 'on');
        status();

        return;
    end

    if (verb == 'status') then
        status();

        return;
    end

    say('/dwchat opens the settings window.');
    say('/dwchat on | off switches the whole thing; /dwchat status says what is on.');
end);

ashita.events.register('load', 'dwchat_load', function ()
    if (config.enabled == true) then
        status();
    else
        say('DWChat is loaded and OFF. /dwchat on colour-codes the battle log and combines its spam; /dwchat opens the settings.');
    end
end);

-- Nothing the addon blocked is left unsaid: whatever is still collecting goes
-- out now, in the order it happened.
ashita.events.register('unload', 'dwchat_unload', function ()
    flush(os.clock(), true);
end);
