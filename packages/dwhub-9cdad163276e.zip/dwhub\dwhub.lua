--[[
* dwhub -- the DriftwoodXI front door (owner request 2026-09-19).
*
* `/dw` opens one window that lists every other DriftwoodXI addon, says what
* each is for, and opens it on a click. It exists because the server's custom
* content lives behind twenty-eight slash commands, and a list of twenty-eight
* slash commands is something a new player reads once, in a chat log, while
* it scrolls away. This is the same list where it can be found again: grouped
* by when you will want it, searchable, and one click from the window itself.
*
* IT TALKS TO NO SERVER. There is no `!` line anywhere in this folder, no
* sender name, no protocol version -- so it needs no dwecho.lua (the library
* that hides an addon's own wire lines from the chat log) and carries only
* dwtheme.lua. Everything it shows is catalog.lua, which is a CHECKED COPY of
* modules/driftwoodxi/addons.lua: tools/dwhub/harness_dwhub.py holds the two
* equal, so this window cannot drift from what `!addons` says the way the
* login hint once did. (It READS one packet since 1.1.0 -- the zone-in, to
* know a login happened -- and sends none.)
*
* WHAT A BUTTON DOES is queue the other addon's OWN slash command through
* Ashita's command parser (mode -1, the way `/addon load` itself is queued by
* every addon that reloads another). It reaches into nobody's state: if the
* other addon is loaded its window toggles, exactly as if the player had typed
* the command, and if it is not, nothing happens at all -- which is the one
* failure every new player hits and the reason each row carries a Load
* button. Loading is `/addon load <name>`; an addon already loaded answers
* that with one harmless line.
*
* These are CLIENT commands and are supposed to be visible as such -- the
* dwengage / dwmacro precedent -- which is why a direct QueueCommand is right
* here and would be wrong in any addon that carries dwecho.
*
* THE RAIL (1.1.0, 2026-09-26). A player asked on Discord for a dock: every
* DW window in one vertical column, in an order they choose, each labelled
* with just its name. Real ImGui docking is BANNED suite-wide -- every window
* passes ImGuiWindowFlags_NoDocking since 2026-08-02, because a fused dock
* lost the theme and imgui.ini kept the fusion across reloads -- so the dock
* is built here instead: a second, slim window of one button per addon, the
* short name on each (catalog.lua's `name`, which is also that window's
* title since the same round), clicking which runs the addon's own toggle.
* The column is either the hub's groups under small captions, or one flat
* list in the player's own order; which addons are on it, and that order,
* are set on the hub's Options tab.
*
* OPENING WINDOWS FOR THE PLAYER. Options also names two sets: windows that
* open when `/dw` opens the hub, and windows that open once per login. Both
* send `<cmd> open` -- never the bare command, which is a TOGGLE and would
* shut a window that happened to be open already; every windowed addon grew
* an idempotent `open` verb in the same round (harness_dwsuite gates it).
* And both go through ONE QUEUE drained a command at a time, OPEN_INTERVAL
* apart: each addon may ask its server for a snapshot as its window opens,
* and the client rate-limits chat -- a burst of eight opens is exactly the
* "A command error occurred" login spam this repo has fought before.
*
* Everything the player sets is per character, through Ashita's settings
* library (the dwchat / dwcon shape: T{} defaults, a coerce pass, a
* registered callback for the character switch).
*
* Commands:
*   /dw            toggle the window (and, opening it, open the "with /dw" set)
*   /dw <words>    open it with the search box already filled ("/dw market")
*   /dw rail       show or hide the rail
*   /dw options    open the window on its Options tab
*   /dwhub         the same as /dw, for anyone who guesses the folder's name
--]]

addon.name    = 'dwhub';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.0';
addon.desc    = 'The DriftwoodXI front door: every server addon in one window -- what it is for, a button that opens it, a button that loads it -- and the rail, a slim column of their names in the order you choose.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local catalog  = require('catalog');

-- Seconds between two commands the hub sends on its own (the "with /dw" and
-- "at login" sets). One and a half is the client's chat pacing with room to
-- spare, and short enough that four windows are up inside five seconds.
local OPEN_INTERVAL = 1.5;

-- Seconds from the login zone-in packet to the first "at login" open. The
-- packet lands on the load screen; the addons being opened need their own
-- zone-in handshakes out of the way first, and dwcon's hello alone waits
-- four seconds. Eight is past all of them.
local LOGIN_DELAY = 8.0;

-- A tooltip line's length, in characters. SetTooltip does not wrap, and a
-- blurb is one long sentence: unwrapped it is a tooltip as wide as the screen.
local TIP_WIDTH = 60;

local state = {
    -- Sugar tables, because that is what Ashita's ImGui binding writes back
    -- into: Begin's open flag, InputText's buffer and Checkbox's value are
    -- all read and written through index 1.
    open     = T{ false },
    find     = T{ '' },
    needle   = '',
    reported = false,

    -- The rail's own Begin flag and render-error latch. Its truth is
    -- config.railShown; this is only the buffer ImGui's close X writes into.
    railOpen     = T{ false },
    railReported = false,

    -- A tab the hub was ASKED to show (`/dw options`, the rail's Options
    -- button). ImGui spends SetSelected at the next BeginTabBar, so the ask
    -- is re-asserted until that tab is the one drawing (the dwparse note).
    wantTab  = nil,

    -- The Options tab's "Show the rail" box.
    showBox  = T{ false },

    -- RadioButton has no caller anywhere else in this suite, and the offline
    -- stubs cannot see a signature (dwah's 5a lesson), so the layout choice
    -- calls it under pcall and falls back to two buttons for good if the
    -- live binding refuses it.
    radioBroken = false,

    -- The rows under each group, and each row's drawing strings, built ONCE
    -- at load: the catalog never changes while the addon runs, and a window
    -- that formats twenty-eight labels sixty times a second is paying for
    -- nothing.
    byGroup  = { },

    -- The rows that draw a window, in catalog order. The only rows the rail,
    -- the Options table and the two open sets ever look at.
    windowed = { },

    -- Derived from the settings, rebuilt on demand after any change:
    -- `ordered` is the windowed rows in the player's order, `rail` the
    -- rail's entries (captions and rows), `railWidth` its button width at
    -- `railFont` (a width measured in one font is wrong in another).
    ordered   = nil,
    rail      = nil,
    railWidth = nil,
    railFont  = nil,

    -- THE OPEN QUEUE: commands waiting their turn, the same commands as a
    -- set (a command already waiting is not queued twice), and the clock
    -- time before which nothing more is sent.
    queue    = { },
    waiting  = { },
    nextAt   = 0,
    lastNow  = 0,

    -- THE LOGIN SET. `loginChar` is the character the set was last armed
    -- for (by server id), so a zone line by the same character never
    -- re-arms it; `loginAt` is when an armed set fires.
    loginChar = nil,
    loginAt   = nil,
};

-- Hard-wrapped at TIP_WIDTH on word boundaries, once, at load.
local function wrap(text, width)
    local lines = { };
    local line  = '';

    for word in string.gmatch(text, '%S+') do
        if (line ~= '' and #line + 1 + #word > width) then
            lines[#lines + 1] = line;
            line = word;
        elseif (line == '') then
            line = word;
        else
            line = line .. ' ' .. word;
        end
    end

    if (line ~= '') then
        lines[#lines + 1] = line;
    end

    return table.concat(lines, '\n');
end

for _, group in ipairs(catalog.groups) do
    state.byGroup[group.key] = { };
    group.tabLabel           = string.format('%s##dwhub_tab_%s', group.label, group.key);
end

for index, row in ipairs(catalog.rows) do
    local windowed = row.window ~= false;

    row.index    = index;
    row.windowed = windowed;

    row.openLabel = string.format('%s##dwhub_open_%s', windowed and 'Open' or 'Help', row.id);
    row.loadLabel = string.format('Load##dwhub_load_%s', row.id);
    row.openTip   = windowed
        and string.format('Runs %s, exactly as if you had typed it.\nNothing happened? The addon is switched off -- press Load.', row.cmd)
        or string.format('%s has no window: it just works once it is loaded.\nThis runs %s, which prints what it can do.', row.id, row.cmd);
    row.loadTip   = string.format('Runs /addon load %s.\nTo keep it on for good, tick it in the DriftwoodXI launcher (Addons tab).', row.id);
    row.typedLine = row.typed ~= nil and string.format('No addon needed: type  !%s  in chat.', row.typed) or nil;
    row.firstLine = row.first ~= nil and ('First time: ' .. row.first) or nil;

    -- What the search box matches: the name, the shortcut and the sentence.
    row.haystack  = string.lower(table.concat({ row.id, row.name or '', row.cmd, row.blurb, row.first or '' }, ' '));

    if (windowed) then
        -- The rail button (unique ##id, the short name as its face), what
        -- the hub sends to OPEN it rather than toggle it, and the Options
        -- table's controls, one checkbox buffer per column.
        row.railLabel  = string.format('%s##dwhub_rail_%s', row.name, row.id);
        row.railTip    = string.format('%s\n%s', row.cmd, wrap(row.blurb, TIP_WIDTH));
        row.openCmd    = row.cmd .. ' open';
        row.boxRail    = T{ false };
        row.boxDw      = T{ false };
        row.boxLogin   = T{ false };
        row.labelRail  = string.format('##dwhub_opt_rail_%s', row.id);
        row.labelDw    = string.format('##dwhub_opt_dw_%s', row.id);
        row.labelLogin = string.format('##dwhub_opt_login_%s', row.id);
        row.labelUp    = string.format('Up##dwhub_opt_up_%s', row.id);
        row.labelDown  = string.format('Down##dwhub_opt_down_%s', row.id);

        table.insert(state.windowed, row);
    end

    if (state.byGroup[row.group] ~= nil) then
        table.insert(state.byGroup[row.group], row);
    end
end

--[[
* Persisted, through Ashita's settings library, PER CHARACTER: a rail left up
* is up at that character's next login, and a main and a mule can open
* different windows.
*
* A SUGAR table, and the `T` is load-bearing: settings.lua calls
* defaults:copy(true) and settings:merge(defaults), and a plain table raises
* on the zone-in reload, which Ashita answers by unloading the addon
* (ashita-settings-defaults-must-be-T; dwfishing 1.2.0 shipped exactly that).
*
* THE FOUR PER-ADDON SETTINGS ARE MAPS KEYED BY ADDON ID, NEVER ARRAYS. The
* library merges a saved file with these defaults key by key, and an array's
* keys are positions: the day the catalog grows a row, every position after
* it would belong to a different addon, and a player's "on the rail" ticks
* would slide one row down. A map keyed by id has no positions to slide. An
* ABSENT key means the default -- on the rail, catalog position, not opened
* -- so a new addon arrives on everybody's rail with nothing to migrate.
--]]
local defaultConfig = T{
    railShown  = false,
    railLayout = 'group',     -- 'group' | 'custom'

    onRail     = T{ },        -- id -> bool   (absent = on the rail)
    order      = T{ },        -- id -> number (absent = catalog position)
    withDw     = T{ },        -- id -> bool   (absent = not opened by /dw)
    atLogin    = T{ },        -- id -> bool   (absent = not opened at login)
};

-- Each map's value type, which the coerce pass holds every entry to.
local MAPS = {
    onRail  = 'boolean',
    order   = 'number',
    withDw  = 'boolean',
    atLogin = 'boolean',
};

local LAYOUTS = { group = true, custom = true };

-- The ids a map may carry: windowed rows only. A windowless row's key in a
-- hand-edited file would otherwise put dwmacro's usage block on a timer.
local KNOWN = { };

for _, row in ipairs(state.windowed) do
    KNOWN[row.id] = true;
end

--[[
* A map, rebuilt as a FRESH table holding only well-typed entries for known
* ids. Fresh on purpose, and on every pass: sugar's `merge` assigns the
* DEFAULTS' OWN TABLE for a key the saved file lacks (libs/sugar/table.lua),
* so without this every character whose file predates a key would write into
* one shared table -- the defaults -- and the next character switch would
* hand one character's ticks to another (dwmacro's `jobs`, the same trap).
--]]
local function cleanMap(value, kind)
    local out = T{ };

    if (type(value) ~= 'table') then
        return out;
    end

    for key, v in pairs(value) do
        if (type(key) == 'string' and KNOWN[key] and type(v) == kind and v == v) then
            out[key] = v;
        end
    end

    return out;
end

--[[
* LOAD-TIME COERCION. A hand-edited or older settings file can hold a string
* where a switch goes, a layout nobody draws, or no key at all; every key is
* put back to a value of its default's type before anything reads it.
* rawget, because an absent key on a sugar table answers with a METHOD,
* never nil.
--]]
local function coerce(c)
    if (type(c) ~= 'table') then
        return;
    end

    if (type(rawget(c, 'railShown')) ~= 'boolean') then
        c.railShown = false;
    end

    if (not LAYOUTS[rawget(c, 'railLayout')]) then
        c.railLayout = 'group';
    end

    for key, kind in pairs(MAPS) do
        c[key] = cleanMap(rawget(c, key), kind);
    end
end

-- A table of its own rather than `config = defaultConfig`, for dwfishing's
-- reason: aliased, a write would land in the constants the library merges
-- over what is on disk. Only the failed-load path keeps it.
local config = T{ };

coerce(config);

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    coerce(loaded);
    config = loaded;
end

-- Everything derived from the settings, dropped so the next reader rebuilds it.
local function invalidate()
    state.ordered   = nil;
    state.rail      = nil;
    state.railWidth = nil;
end

-- Ashita hands the whole table back on a character switch (on the zone-in
-- packet), so `config` is re-pointed rather than merged into.
pcall(settings.register, 'settings', 'dwhub_settings_update', function (s)
    if (type(s) == 'table') then
        coerce(s);
        config = s;
        invalidate();
    end
end);

local function save()
    pcall(settings.save);
end

-- One per-addon switch, with the default an absent key stands for.
local function flag(map, row, absent)
    local value = rawget(config[map], row.id);

    if (value == nil) then
        return absent;
    end

    return value == true;
end

local function onRail(row)
    return row.windowed and flag('onRail', row, true);
end

local function orderOf(row)
    local n = rawget(config.order, row.id);

    if (type(n) == 'number') then
        return n;
    end

    return row.index;
end

-- The windowed rows in the player's order: their numbers first, catalog
-- position breaking a tie (and standing in for a row they never moved).
local function ordered()
    if (state.ordered == nil) then
        local list = { };

        for _, row in ipairs(state.windowed) do
            list[#list + 1] = row;
        end

        table.sort(list, function (a, b)
            local x, y = orderOf(a), orderOf(b);

            if (x ~= y) then
                return x < y;
            end

            return a.index < b.index;
        end);

        state.ordered = list;
    end

    return state.ordered;
end

-- The clock every deadline here is kept on: os.clock, the suite's clock for
-- throttles and deadlines (dwcon's zone-in hello is the same shape).
local function clock()
    return os.clock();
end

-- One client command, through Ashita's own parser. Mode -1 is the mode every
-- addon that loads or reloads another one already uses.
--
-- EVERY SEND STAMPS THE QUEUE'S CLOCK, a click included: the rate limit is on
-- the client's chat, not on this queue, so a queued open fired in the same
-- beat as a rail click is the pair the client drops.
local function run(command)
    AshitaCore:GetChatManager():QueueCommand(-1, command);

    state.nextAt = math.max(state.nextAt, clock() + OPEN_INTERVAL);
end

-- Queued to go out in its turn; a command already waiting is not queued twice.
local function enqueue(command)
    if (state.waiting[command]) then
        return;
    end

    state.waiting[command]      = true;
    state.queue[#state.queue + 1] = command;
end

local function clearQueue()
    state.queue   = { };
    state.waiting = { };
end

-- One of the two open sets ('withDw' or 'atLogin'), read NOW -- never
-- captured earlier, because the settings library swaps in the character's
-- own table on the same zone-in packet that arms the login set -- in the
-- player's order, as `<cmd> open`.
local function queueSet(map)
    for _, row in ipairs(ordered()) do
        if (flag(map, row, false)) then
            enqueue(row.openCmd);
        end
    end
end

local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

-- The search needle: lowercased, outer whitespace gone. Parenthesised because
-- gsub answers two values and only the string is wanted.
local function trimmed(text)
    return (string.lower(tostring(text or '')):gsub('^%s+', ''):gsub('%s+$', ''));
end

local function matches(row)
    return state.needle == '' or string.find(row.haystack, state.needle, 1, true) ~= nil;
end

-------------------------------------------------------------------------------
-- What the player can change, each write saved at once
-------------------------------------------------------------------------------

local function setRail(shown)
    config.railShown = shown == true;

    if (config.railShown) then
        state.railReported = false;
    end

    save();
end

local function setLayout(layout)
    if (LAYOUTS[layout] and config.railLayout ~= layout) then
        config.railLayout = layout;
        invalidate();
        save();
    end
end

local function setFlag(map, row, value)
    config[map][row.id] = value == true;
    invalidate();
    save();
end

--[[
* One step up (-1) or down (+1) in the player's order. The WHOLE order is
* written back as 1..n, not just the two rows that swapped: an order of
* sparse numbers and catalog positions mixed together is one where a later
* move can land between two rows it never meant to. On a COPY of the list,
* because the Options table is iterating the cached one while this runs.
--]]
local function move(row, delta)
    local list = { };
    local at   = nil;

    for i, r in ipairs(ordered()) do
        list[i] = r;

        if (r == row) then
            at = i;
        end
    end

    local to = at ~= nil and (at + delta) or nil;

    if (to == nil or to < 1 or to > #list) then
        return;
    end

    list[at], list[to] = list[to], list[at];

    local order = T{ };

    for i, r in ipairs(list) do
        order[r.id] = i;
    end

    config.order = order;
    invalidate();
    save();
end

local function resetOrder()
    config.order = T{ };
    invalidate();
    save();
end

-------------------------------------------------------------------------------
-- Opening the hub
-------------------------------------------------------------------------------

-- `withSet`: this open came from a bare `/dw` (or the rail's Hub button, which
-- is the clickable `/dw`), so the "with /dw" set comes with it. Only an
-- OPENING does: a hub already open was not opened by this.
local function openHub(withSet)
    local wasOpen = state.open[1];

    state.open[1]  = true;
    state.reported = false;

    if (withSet and not wasOpen) then
        queueSet('withDw');
    end
end

local function toggleHub()
    if (state.open[1]) then
        state.open[1] = false;
    else
        openHub(true);
    end
end

-- The Options tab lives in the tab bar, and a search replaces the tab bar
-- with one flat list, so the search is cleared to get there.
local function openOptions()
    state.find[1] = '';
    state.needle  = '';
    state.wantTab = 'options';

    openHub(false);
end

-------------------------------------------------------------------------------
-- The hub window
-------------------------------------------------------------------------------

local function drawRow(row)
    if (imgui.SmallButton(row.openLabel)) then
        run(row.cmd);
    end

    tip(row.openTip);

    imgui.SameLine();

    if (imgui.SmallButton(row.loadLabel)) then
        run('/addon load ' .. row.id);
    end

    tip(row.loadTip);

    imgui.SameLine();
    imgui.TextColored(theme.colors.ok, row.cmd);
    imgui.SameLine();
    imgui.TextDisabled(row.id);

    -- Wrapped at the window's edge (the dwquest paragraph shape): a blurb is
    -- a sentence, and a sentence clipped at the right border is half of one.
    imgui.PushTextWrapPos(0.0);
    imgui.Text(row.blurb);

    if (row.firstLine ~= nil) then
        imgui.TextColored(theme.colors.hint, row.firstLine);
    end

    if (row.typedLine ~= nil) then
        imgui.TextDisabled(row.typedLine);
    end

    imgui.PopTextWrapPos();
    imgui.Separator();
end

-- One group's rows. `filtered` is the search view: only the matches, under the
-- group's NAME (there are no tabs to say it); unfiltered is a tab body, which
-- opens with the group's note instead. Returns how many rows it drew.
local function drawGroup(group, filtered)
    local drawn = 0;

    for _, row in ipairs(state.byGroup[group.key]) do
        if (not filtered or matches(row)) then
            if (drawn == 0) then
                if (filtered) then
                    imgui.TextColored(theme.colors.badge, group.label);
                else
                    imgui.PushTextWrapPos(0.0);
                    imgui.TextDisabled(group.note);
                    imgui.PopTextWrapPos();
                end

                imgui.Separator();
            end

            drawRow(row);

            drawn = drawn + 1;
        end
    end

    return drawn;
end

-- A radio button, or -- if the live binding ever refuses the call -- a small
-- button that says which is chosen. Returns whether it was pressed.
local function radio(label, active)
    if (not state.radioBroken) then
        local ok, pressed = pcall(imgui.RadioButton, label, active);

        if (ok) then
            return pressed == true;
        end

        state.radioBroken = true;
    end

    return imgui.SmallButton((active and '[x] ' or '[ ] ') .. label);
end

local function checkbox(label, buffer, value)
    buffer[1] = value == true;

    if (imgui.Checkbox(label, buffer)) then
        return true, buffer[1] == true;
    end

    return false, value == true;
end

--[[
* The Options tab: the rail and the two open sets, per character. One line per
* WINDOWED addon, in the player's order -- the order the Up/Down buttons edit
* is the order they are drawn in, so a press moves the line under the mouse.
--]]
local function renderOptions()
    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled('Saved for this character, the moment you change them.');
    imgui.PopTextWrapPos();

    local changed, value = checkbox('Show the rail##dwhub_opt_show', state.showBox, config.railShown);

    if (changed) then
        setRail(value);
    end

    tip('The rail is a slim column of addon names: one click opens each.\nTyping /dw rail does the same.');

    imgui.Text('Rail layout:');
    imgui.SameLine();

    if (radio('By category##dwhub_opt_group', config.railLayout == 'group')) then
        setLayout('group');
    end

    tip('The hub\'s groups, each under a small caption.');

    imgui.SameLine();

    if (radio('My order##dwhub_opt_custom', config.railLayout == 'custom')) then
        setLayout('custom');
    end

    tip('One list, in the order below. Up and Down move a line.');

    imgui.SameLine();

    if (imgui.SmallButton('Reset order##dwhub_opt_reset')) then
        resetOrder();
    end

    tip('Puts "My order" back to the hub\'s own order.');

    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled('With /dw: opened when /dw opens this window. At login: opened once each time this character logs in, a few seconds after arriving, one at a time. An addon that is switched off opens nothing -- Load it from its row, or tick it in the launcher\'s Addons tab. Macro and Engage have no window, so they are not listed.');
    imgui.PopTextWrapPos();

    imgui.Separator();

    if (not imgui.BeginTable('##dwhub_opt_rows', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersInnerH, ImGuiTableFlags_SizingFixedFit))) then
        return;
    end

    imgui.TableSetupColumn('Addon', ImGuiTableColumnFlags_WidthFixed, 0, 0);
    imgui.TableSetupColumn('On rail', ImGuiTableColumnFlags_WidthFixed, 0, 0);
    imgui.TableSetupColumn('With /dw', ImGuiTableColumnFlags_WidthFixed, 0, 0);
    imgui.TableSetupColumn('At login', ImGuiTableColumnFlags_WidthFixed, 0, 0);
    imgui.TableSetupColumn('Order', ImGuiTableColumnFlags_WidthFixed, 0, 0);
    imgui.TableHeadersRow();

    for _, row in ipairs(ordered()) do
        imgui.TableNextRow();

        imgui.TableNextColumn();
        imgui.Text(row.name);
        imgui.SameLine();
        imgui.TextDisabled(row.cmd);

        imgui.TableNextColumn();

        local railChanged, railValue = checkbox(row.labelRail, row.boxRail, onRail(row));

        if (railChanged) then
            setFlag('onRail', row, railValue);
        end

        imgui.TableNextColumn();

        local dwChanged, dwValue = checkbox(row.labelDw, row.boxDw, flag('withDw', row, false));

        if (dwChanged) then
            setFlag('withDw', row, dwValue);
        end

        imgui.TableNextColumn();

        local loginChanged, loginValue = checkbox(row.labelLogin, row.boxLogin, flag('atLogin', row, false));

        if (loginChanged) then
            setFlag('atLogin', row, loginValue);
        end

        imgui.TableNextColumn();

        if (imgui.SmallButton(row.labelUp)) then
            move(row, -1);
        end

        imgui.SameLine();

        if (imgui.SmallButton(row.labelDown)) then
            move(row, 1);
        end
    end

    imgui.EndTable();
end

local function renderWindow()
    imgui.PushTextWrapPos(0.0);
    imgui.Text('Everything custom on DriftwoodXI opens from a window. Open runs the addon\'s own command; if nothing happens, that addon is switched off -- press Load, or tick it in the launcher\'s Addons tab to keep it on. /dw rail keeps them in a slim column; the Options tab sets it up.');
    imgui.PopTextWrapPos();

    imgui.SetNextItemWidth(260);

    if (imgui.InputText('Find##dwhub_find', state.find, 48)) then
        state.needle = trimmed(state.find[1]);
    end

    tip('Filters every group by name, shortcut or description. Empty shows the groups as tabs.');

    imgui.Separator();

    -- The rows scroll; the header above them does not.
    if (not imgui.BeginChild('##dwhub_rows', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (state.needle ~= '') then
        -- A SEARCH IS ONE FLAT LIST. Results filed under tabs the player has
        -- to click through are results nobody finds; every match is drawn
        -- here, under its group's name, in the catalog's own order.
        local shown = 0;

        for _, group in ipairs(catalog.groups) do
            shown = shown + drawGroup(group, true);
        end

        if (shown == 0) then
            imgui.TextDisabled(string.format('Nothing matches "%s". The box searches names, shortcuts and descriptions.', state.needle));
        end
    elseif (imgui.BeginTabBar('##dwhub_tabs')) then
        for _, group in ipairs(catalog.groups) do
            if (imgui.BeginTabItem(group.tabLabel)) then
                drawGroup(group, false);
                imgui.EndTabItem();
            end
        end

        -- Options is the LAST tab: it is about the other tabs' addons, and
        -- a new player's first click belongs on "Start here".
        local flags = ImGuiTabItemFlags_None;

        if (state.wantTab == 'options') then
            flags = ImGuiTabItemFlags_SetSelected;
        end

        if (imgui.BeginTabItem('Options##dwhub_tab_options', nil, flags)) then
            state.wantTab = nil;

            renderOptions();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    imgui.EndChild();
end

local function drawHub()
    local pushed = theme.push();

    imgui.SetNextWindowSize({ 640, 520 }, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE. Nothing in ImGui stops a window being dragged to
    -- nothing; 460 keeps a row's two buttons, its shortcut and its name on
    -- one line, which is the narrowest the row still reads as a row.
    imgui.SetNextWindowSizeConstraints({ 460, 260 }, { 99999, 99999 });

    -- `###dwhub`: the ID is the folder alone, so the visible title can
    -- change without the window losing its saved place (the suite's
    -- '<Short>###<folder>' rule, 2026-09-26).
    local visible = imgui.Begin('DriftwoodXI###dwhub', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwhub'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwhub'):append(chat.message('Window closed. The same list is printed by typing !addons in chat.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end

-------------------------------------------------------------------------------
-- The rail
-------------------------------------------------------------------------------

-- The rail's entries: captions and rows, in drawing order.
local function railEntries()
    if (state.rail ~= nil) then
        return state.rail;
    end

    local entries = { };

    if (config.railLayout == 'custom') then
        for _, row in ipairs(ordered()) do
            if (onRail(row)) then
                entries[#entries + 1] = { row = row };
            end
        end
    else
        for _, group in ipairs(catalog.groups) do
            local captioned = false;

            for _, row in ipairs(state.byGroup[group.key]) do
                if (onRail(row)) then
                    if (not captioned) then
                        captioned = true;
                        entries[#entries + 1] = { caption = group.rail or group.label };
                    end

                    entries[#entries + 1] = { row = row };
                end
            end
        end
    end

    state.rail = entries;

    return entries;
end

--[[
* EVERY BUTTON THE SAME WIDTH: the widest name on the rail plus the frame's
* padding, and never narrower than the Hub / Options pair above them. A
* column of buttons each as wide as its own word is a ragged edge, not a
* column. Measured in the current font and kept until the font or the rail
* changes -- CalcTextSize is a pure function of the two.
--]]
local function railWidth(entries)
    local font = imgui.GetFontSize();

    if (state.railWidth ~= nil and state.railFont == font) then
        return state.railWidth;
    end

    local style   = imgui.GetStyle();
    local pad     = (style ~= nil and style.FramePadding ~= nil) and style.FramePadding.x or 4;
    local spacing = (style ~= nil and style.ItemSpacing ~= nil) and style.ItemSpacing.x or 8;
    local widest  = 0;

    for _, entry in ipairs(entries) do
        if (entry.row ~= nil) then
            local w = (imgui.CalcTextSize(entry.row.name));

            if (type(w) == 'number' and w > widest) then
                widest = w;
            end
        end
    end

    local hub     = (imgui.CalcTextSize('Hub'));
    local options = (imgui.CalcTextSize('Options'));
    local header  = (tonumber(hub) or 0) + (tonumber(options) or 0) + pad * 4 + spacing;

    state.railWidth = math.max(widest + pad * 2, header);
    state.railFont  = font;

    return state.railWidth;
end

local function renderRail()
    if (imgui.SmallButton('Hub##dwhub_rail_hub')) then
        toggleHub();
    end

    tip('The DriftwoodXI window: every addon, what it is for, and a Load button\nfor one that is switched off. (/dw)');

    imgui.SameLine();

    if (imgui.SmallButton('Options##dwhub_rail_options')) then
        openOptions();
    end

    tip('What is on this rail, its order, and which windows open\nwith /dw or at login. (/dw options)');

    imgui.Separator();

    local entries = railEntries();

    if (#entries == 0) then
        imgui.TextDisabled('Empty.');
        tip('Every addon is switched off the rail. Options puts them back.');

        return;
    end

    local width = railWidth(entries);

    for _, entry in ipairs(entries) do
        if (entry.caption ~= nil) then
            imgui.TextDisabled(entry.caption);
        else
            -- The addon's own TOGGLE, not `open`: a rail button is the
            -- player's hand on that window, and a second click shuts it.
            if (imgui.Button(entry.row.railLabel, { width, 0 })) then
                run(entry.row.cmd);
            end

            tip(entry.row.railTip);
        end
    end
end

local function drawRail()
    local pushed = theme.push();

    state.railOpen[1] = true;

    -- Out of the hub's way the first time; where the player puts it after.
    imgui.SetNextWindowPos({ 20, 220 }, ImGuiCond_FirstUseEver);

    -- AlwaysAutoResize, because the column is exactly as tall as its buttons
    -- and as wide as its widest one -- a rail the player has to size by hand
    -- is a rail with a gap at the bottom. It needs no size floor for the
    -- same reason: it can never be dragged smaller than what it draws.
    local visible = imgui.Begin('DW###dwhub_rail', state.railOpen, bit.bor(ImGuiWindowFlags_NoDocking, ImGuiWindowFlags_AlwaysAutoResize, ImGuiWindowFlags_NoScrollbar));

    if (visible) then
        local ok, err = pcall(renderRail);

        if (not ok) then
            state.railOpen[1] = false;

            if (not state.railReported) then
                state.railReported = true;

                print(chat.header('dwhub'):append(chat.error('rail render error: ' .. tostring(err))));
                print(chat.header('dwhub'):append(chat.message('Rail closed. /dw still opens every addon; /dw rail brings the rail back.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);

    -- The close X (or a render error) shuts it, and that is remembered: a
    -- rail the player closed is not back at their next login.
    if (not state.railOpen[1]) then
        setRail(false);
    end
end

-------------------------------------------------------------------------------
-- The queue and the login set
-------------------------------------------------------------------------------

-- The character in the world right now, by server id, or nil when nobody is
-- (the title screen, character select, a load screen before login status).
local function currentCharacter()
    local ok, sid = pcall(function ()
        local memory = AshitaCore:GetMemoryManager();
        local player = memory:GetPlayer();

        if (player == nil or player:GetLoginStatus() ~= 2) then
            return nil;
        end

        local party = memory:GetParty();
        local id    = party ~= nil and party:GetMemberServerId(0) or 0;

        if (id == nil or id == 0) then
            return nil;
        end

        return id;
    end);

    if (ok) then
        return sid;
    end

    return nil;
end

-- Whether a command sent now reaches a world: logged in and not on a load
-- screen (dwmacro's gate -- login status goes live under the load screen).
local function inWorld()
    local ok, yes = pcall(function ()
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        return player ~= nil and player:GetLoginStatus() == 2 and player:GetIsZoning() == 0;
    end);

    return ok and yes == true;
end

--[[
* One frame's worth of the queue: the login set fired when its time comes,
* then at most ONE command sent. Asked of the world only when there is
* something to send -- the steady state is two comparisons.
--]]
local function pump()
    local now = clock();

    -- THE CLOCK CAN GO BACKWARDS (dwmacro's note: os.clock is a 32-bit
    -- millisecond count on Windows and wraps after ~24.8 days of uptime).
    -- A deadline left in the far future would hold the queue for weeks.
    if (now < state.lastNow) then
        state.nextAt = now;

        if (state.loginAt ~= nil) then
            state.loginAt = now + LOGIN_DELAY;
        end
    end

    state.lastNow = now;

    if (state.loginAt ~= nil and now >= state.loginAt and inWorld()) then
        state.loginAt = nil;

        queueSet('atLogin');
    end

    if (#state.queue > 0 and now >= state.nextAt and inWorld()) then
        local command = table.remove(state.queue, 1);

        state.waiting[command] = nil;

        run(command);
    end
end

ashita.events.register('d3d_present', 'dwhub_present', function ()
    -- Before either window: the queue drains with both of them shut.
    pump();

    if (config.railShown) then
        drawRail();
    end

    if (state.open[1]) then
        drawHub();
    end
end);

local function u32(data, off)
    local b1, b2, b3, b4 = string.byte(data, off + 1, off + 4);

    return (b1 or 0) + (b2 or 0) * 256 + (b3 or 0) * 65536 + (b4 or 0) * 16777216;
end

--[[
* THE LOGIN SET ARMS ON THE ZONE-IN PACKET. 0x000A is every zone line AND
* every login; it leads with the character's server id (dwcraft's and
* dwfame's guard), so a zone line by the character the set was last armed
* for is told apart from a login and re-arms nothing. A LOGOUT (0x000B with
* its logout byte set -- the settings library's own test) forgets the
* character, so logging the same one back in is a login again, and drops
* whatever was still queued: nothing sent at a logout screen reaches a
* window. The set itself is read when it FIRES, not here.
--]]
ashita.events.register('packet_in', 'dwhub_packet_in', function (e)
    if (e.id == 0x000A) then
        if (e.data == nil) then
            return;
        end

        local uid = u32(e.data, 0x04);

        if (uid ~= 0 and uid ~= state.loginChar) then
            state.loginChar = uid;
            state.loginAt   = clock() + LOGIN_DELAY;
        end

        return;
    end

    if (e.id == 0x000B) then
        if (e.data ~= nil and string.byte(e.data, 0x04 + 1) == 1) then
            state.loginChar = nil;
            state.loginAt   = nil;

            clearQueue();
        end
    end
end);

ashita.events.register('command', 'dwhub_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, and a player
    -- who capitalises is not making a mistake.
    local first = #args > 0 and args[1]:lower() or '';

    -- EXACT MATCH ON THE FIRST WORD, which is what keeps `/dw` from eating
    -- /dwah, /dwcon, /dwscan, /dwfishing, /dwmacro and /dwengage: a prefix
    -- test here would swallow six other addons' commands.
    if (first ~= '/dw' and first ~= '/dwhub') then
        return;
    end

    e.blocked = true;

    -- TWO RESERVED WORDS, and only as the whole of what follows `/dw`: they
    -- win over a search for the same word (which would find nothing), and
    -- `/dw rail pass` is still a search.
    if (#args == 2) then
        local word = args[2]:lower();

        if (word == 'rail') then
            setRail(not config.railShown);

            return;
        end

        if (word == 'options') then
            openOptions();

            return;
        end
    end

    -- `/dw market` OPENS the window on that search rather than toggling it: a
    -- player who named something has said what they want, and shutting the
    -- window on them because it happened to be open is the wrong answer. It
    -- opens nothing else -- the "with /dw" set belongs to the bare command.
    if (#args > 1) then
        local words = { };

        for index = 2, #args do
            words[#words + 1] = args[index];
        end

        local wanted = string.sub(table.concat(words, ' '), 1, 47);

        state.find[1]  = wanted;
        state.needle   = trimmed(wanted);
        state.open[1]  = true;
        state.reported = false;

        return;
    end

    toggleHub();
end);

ashita.events.register('load', 'dwhub_load', function ()
    -- LOADED MID-SESSION (`/addon load`, `/addon reload`) the character is
    -- already in the world, and its login has already happened: recorded as
    -- fired, so a reload never opens a stack of windows the player did not
    -- just log in for. The next zone line is the same character's and arms
    -- nothing.
    state.loginChar = currentCharacter();

    print(chat.header('dwhub'):append(chat.message('/dw opens the DriftwoodXI front door: every server addon, what it is for, and a button that opens it. /dw <word> searches it; /dw rail shows the rail, a slim column of their names.')));
end);
