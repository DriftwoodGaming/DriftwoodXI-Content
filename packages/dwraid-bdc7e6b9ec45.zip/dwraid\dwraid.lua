--[[
* DriftwoodXI -- dwraid
*
* The raid board: the Horlais Peak trials as a window -- your driftmark
* purse, the fights, the tiers and what they pay, whether the arena is
* free, and the buttons that take you there. No orb, no travel: pick a
* fight, press Enter, and the server gates your whole party where you
* stand (cities and safe zones only, the server's rule) and moves
* everyone. Leave puts you back on the exact tile you left.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no opinion about your purse, the tiers, or whether the arena is
* busy. The server answers `!dwx status` in compact records under the
* sender name _DWXDATA, which this addon parses and blocks before the chat
* log sees them; the payouts and the arena state ride the wire. Every
* button is a `!dwx` verb a player could type -- the server re-checks
* everything, so this window can do nothing a typed command cannot
* (the dwq.lua rule, inherited whole).
*
* TURN IT OFF AND NOTHING IS LOST. `!raid` typed in chat is the same
* answers in prose, and `!raid enter` is the same warp.
*
* WHAT THE WINDOW ADDS ON TOP OF THE WIRE (1.4.0): the fight roster hangs
* under element tabs (the f| tail names each fight's element; only elements
* that hold a fight get a tab, so the row grows with the roster), and every
* shop row draws its item's icon and a hover card -- name, iLvl, jobs,
* slots and the item's own description -- read from the client's OWN
* resources by the item id the s| tail carries. Nothing item-shaped rides
* the wire beyond that one number, and nobody has to alt-tab to a wiki to
* learn what a shelf row is.
--]]

addon.name    = 'dwraid';
addon.author  = 'DriftwoodXI';
addon.version = '1.4.1';
addon.desc    = 'Raid board for DriftwoodXI: the trials, the tiers, your driftmarks.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local d3d   = require('d3d8');
local ffi   = require('ffi');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load: this addon is
* loaded from the launcher's boot script, long before the client has a
* rendering device, and a file-scope d3d.get_device() would make the whole
* addon fail to load (dwbags' lesson, kept verbatim). Nothing here needs a
* device until the first shop icon is drawn.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server
-- uses it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWXDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout -- never for an additive record.
local PROTOCOL = 1;

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged,
    -- so a stale row cannot survive a refresh (dwtracker's rule).
    purse     = nil,          -- { balance, earned, spent }
    arena     = nil,          -- { running, tier, minutes, fight, busy, capacity -- the tail pair nil on an older server }
    runs      = T{ },         -- { fight, tier, minutes }, one per live run -- empty on a pre-multi-arena server
    fights    = T{ },         -- [index] = { word, label, element } -- empty on a pre-fight-roster server; element nil on a pre-element server
    fightSel  = 1,            -- which fight the Enter buttons ask for
    elemSel   = nil,          -- which element tab is open; nil renders the roster flat (a pre-element server)
    tiers     = T{ },         -- [index] = { label, base, daily }
    ledger    = T{ },         -- { delta, age, reason }, newest first
    shop      = T{ },         -- [shelf index] = { label, price, page, itemid } -- indices are sparse; itemid nil on an older server
    pages     = T{ },         -- [index] = { word, label } -- empty on a pre-pages server
    pageSel   = 1,            -- which shop page the shelf table shows
    quote     = nil,          -- { index, price, until } -- the live quote, if any

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its
    -- own cannot half-fill the UI.
    inbound   = nil,
    building  = nil,          -- the next tiers/ledger, committed on z|
    status    = 'Waiting for the first sync.',
    statusBad = false,
    reported  = false,        -- a render error is worth saying once, not per frame

    -- A zone-in sync is deferred: 0x000A arrives while the client is still
    -- on the load screen, and a chat line sent there is a chat line lost.
    syncAt    = nil,
    syncSlot  = nil,
};

--[[
* Item icons, from the client's own resources -- dwbags' iconOf/drawIcon,
* kept verbatim, reasoning and all: cached because the shop is dozens of
* rows redrawn every frame and D3DXCreateTextureFromFileInMemoryEx is not
* free; gc_safe_release hands back a texture that releases itself when Lua
* collects it, which is what keeps this from leaking across a reload.
--]]
local icons = T{ };

local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* The hover card's vocabulary: client DAT bitmasks decoded to the words a
* player reads. The job order is the server's own (dwbags' table); the
* flag bits are the same ones sql/item_basic.sql spells @FLAG_RARE and
* @FLAG_EX. All of it is presentation -- the server re-checks everything
* that matters (the Rare pre-pay refusal lives in raid_core.lua).
--]]
local FLAG_EX   = 0x4000;
local FLAG_RARE = 0x8000;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

local SLOT_LABELS = {
    [0]  = 'Main',  [1]  = 'Sub',   [2]  = 'Ranged', [3]  = 'Ammo',
    [4]  = 'Head',  [5]  = 'Body',  [6]  = 'Hands',  [7]  = 'Legs',
    [8]  = 'Feet',  [9]  = 'Neck',  [10] = 'Waist',  [11] = 'Ear',
    [12] = 'Ear',   [13] = 'Ring',  [14] = 'Ring',   [15] = 'Back',
};

local function jobsText(mask)
    local names = T{ };

    for jobId = 1, #JOB_NAMES do
        if (bit.band(mask, bit.lshift(1, jobId)) ~= 0) then
            names:append(JOB_NAMES[jobId]);
        end
    end

    if (#names == 0) then
        return nil;
    end

    if (#names >= #JOB_NAMES) then
        return 'All jobs';
    end

    return table.concat(names, ' ');
end

local function slotsText(mask)
    local names = T{ };
    local seen  = { };

    for slot = 0, 15 do
        if (bit.band(mask, bit.lshift(1, slot)) ~= 0) then
            local label = SLOT_LABELS[slot];

            if (not seen[label]) then
                seen[label] = true;
                names:append(label);
            end
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, '/');
end

--[[
* The hover card itself: everything a purchase decision needs -- name,
* iLvl, level, Rare/Ex, slots, jobs and the item's own description text --
* read from the client's resources by the id the s| tail carries. The
* point is that nobody should have to alt-tab to a wiki to learn what a
* shelf row is. An older server sends no id; the card then shows only what
* the wire said (label and price), which is exactly what that server means.
--]]
local function itemTooltip(row)
    imgui.BeginTooltip();

    local item = nil;

    if (row.itemid ~= nil and row.itemid ~= 0) then
        item = AshitaCore:GetResourceManager():GetItemById(row.itemid);

        drawIcon(row.itemid, 32);
    end

    imgui.Text(row.label);

    if (item ~= nil) then
        local tags = T{ };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags:append(string.format('iLvl %d', item.ItemLevel));
        end

        if (item.Level ~= nil and item.Level > 0) then
            tags:append(string.format('Lv.%d', item.Level));
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_RARE) ~= 0) then
            tags:append('Rare');
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_EX) ~= 0) then
            tags:append('Ex');
        end

        if (#tags > 0) then
            imgui.TextColored(theme.colors.info, table.concat(tags, '  '));
        end

        local slots = item.Slots ~= nil and slotsText(item.Slots) or nil;
        local jobs  = item.Jobs ~= nil and jobsText(item.Jobs) or nil;

        if (slots ~= nil and jobs ~= nil) then
            imgui.TextDisabled(slots .. '  --  ' .. jobs);
        elseif (slots ~= nil or jobs ~= nil) then
            imgui.TextDisabled(slots or jobs);
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            -- A fixed wrap width, not one derived from imgui state: the
            -- card must render the same whatever window it floats over.
            imgui.PushTextWrapPos(320.0);
            imgui.Text(desc);
            imgui.PopTextWrapPos();
        end
    end

    imgui.Separator();
    imgui.TextColored(theme.colors.hint, string.format('%d driftmarks', row.price));

    imgui.EndTooltip();
end

--[[
* The elemental wheel, in its canonical order, each with the tint its tab
* wears while selected. ONLY ELEMENTS THAT HOLD A FIGHT GET A TAB -- today
* that is Water and Earth, and a new element's tab appears by itself the
* day its first boss ships, because the roster (and each fight's element)
* rides the wire. An element word this addon does not know still gets a
* tab, at the end, under its own name -- a newer server must never file a
* fight where no tab can show it.
--]]
local ELEMENTS = {
    { word = 'fire',      label = 'Fire',      color = { 0.96, 0.48, 0.38, 1.0 } },
    { word = 'ice',       label = 'Ice',       color = { 0.62, 0.86, 0.96, 1.0 } },
    { word = 'wind',      label = 'Wind',      color = { 0.55, 0.90, 0.60, 1.0 } },
    { word = 'earth',     label = 'Earth',     color = { 0.87, 0.72, 0.45, 1.0 } },
    { word = 'lightning', label = 'Lightning', color = { 0.80, 0.62, 0.95, 1.0 } },
    { word = 'water',     label = 'Water',     color = { 0.50, 0.70, 0.95, 1.0 } },
    { word = 'light',     label = 'Light',     color = { 0.95, 0.93, 0.80, 1.0 } },
    { word = 'dark',      label = 'Dark',      color = { 0.68, 0.62, 0.78, 1.0 } },
};

local function elementOf(fight)
    if (fight == nil or fight.element == nil or fight.element == '') then
        return nil;
    end

    return fight.element;
end

-- The tabs to draw: wheel order first, unknown words after, each exactly
-- once. Empty when no fight carries an element (a pre-element server) --
-- the roster then renders flat, which is what that server means.
local function presentElements()
    local seen = { };
    local out  = T{ };

    for index = 1, 9 do
        local element = elementOf(state.fights[index]);

        if (element ~= nil) then
            seen[element] = true;
        end
    end

    for _, entry in ipairs(ELEMENTS) do
        if (seen[entry.word]) then
            out:append(entry);
            seen[entry.word] = nil;
        end
    end

    for index = 1, 9 do
        local element = elementOf(state.fights[index]);

        if (element ~= nil and seen[element]) then
            out:append({ word = element, label = element:gsub('^%l', string.upper) });
            seen[element] = nil;
        end
    end

    return out;
end

-- The lowest-indexed fight on an element (or the lowest of all for nil),
-- for tab clicks and for a selection whose fight vanished in a refresh.
local function firstFightOf(element)
    for index = 1, 9 do
        local fight = state.fights[index];

        if (fight ~= nil and (element == nil or elementOf(fight) == element)) then
            return index;
        end
    end

    return 1;
end

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. The client rate-limits outgoing chat and a !dwx command is a chat
* line; everything queues here and drains at one command per interval, with
* duplicates collapsed (dwbags' lesson, kept verbatim).
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking: a command can be lost on the way out, so an unanswered
* request is asked once more and then left alone. A PLAIN TABLE, NOT T{ }:
* keyed by verb names, and sugar-table method names shadowing a key cost
* dwbags a round once already.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

--[[
* True once this server has shown it does not speak dwraid -- either its
* own refusal arrived ("The raid is not loaded.") or a request went
* unanswered twice. An unknown !command on this server falls through to
* ordinary /say chat, so every auto-sync against a dead verb is the player
* PUBLICLY SAYING "!dwx status". While set, zone-in auto-syncs stop.
* Cleared by anything that proves the server speaks (a d| envelope) and by
* the player acting on purpose (window open, refresh).
--]]
local serverSilent = false;

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

local function ask(verb)
    requested[verb] = { at = os.clock(), answered = false, tries = 1 };

    issue('!dwx ' .. verb);
end

-- Re-ask an unanswered verb once; give up loudly after that. Called every
-- frame, window open or not.
local function checkAnswers()
    -- A held send (zone-in) leaves the line queued; aging the answer clock
    -- against it would be a false timeout, and after ANSWER_TRIES a false
    -- "No answer from the server." (dwecho canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    for verb, asked in pairs(requested) do
        if (not asked.answered and (os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue('!dwx ' .. verb);
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;
                serverSilent = true;

                state.status    = 'No answer from the server. Is DriftwoodXI up to date?';
                state.statusBad = true;
            end
        end
    end
end

local function requestStatus()
    ask('status');
    ask('shop');
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        -- An envelope is the server speaking dwraid, whatever it carries.
        serverSilent = false;

        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwraid through the launcher.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- A d| envelope IS the answer, whatever version it announced.
            -- Returning with the ask still outstanding let checkAnswers
            -- re-send it and then replace the one accurate diagnosis on screen
            -- ("Update dwraid") with "No answer from the server. Is
            -- DriftwoodXI up to date?" -- about a server that had just
            -- answered twice. The same fix the `status` branch below already
            -- carries, and the one dwfame made on 2026-08-15.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright: the lists build in
        -- `building` and commit on z|, so a reply cut off mid-flight can
        -- never leave the window half of one answer and half of another.
        if (state.inbound == 'status') then
            -- `filled` separates a real status reply from the shared writer's
            -- wrapper around an EARLY refusal. A refusal raised before any verb
            -- opened an envelope ships as a bare d|1|status ... z|status with
            -- one e| inside it, so a status-shaped close arrives carrying no
            -- tiers at all -- see the z| handler.
            state.building = { tiers = T{ }, fights = T{ }, ledger = T{ }, runs = T{ }, filled = false };
        elseif (state.inbound == 'shop') then
            state.building = { shop = T{ }, pages = T{ } };
        end

        answered(state.inbound);

        -- A refusal raised before a verb opened its own envelope arrives
        -- wrapped in `d|1|status` (the writer's shape). That IS the answer
        -- to whatever was asked: left unanswered, checkAnswers re-sends the
        -- verb and then replaces the server's precise sentence with a "no
        -- answer" diagnosis that is simply untrue.
        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- sentence saying why something was refused is worth more than the
    -- response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwraid'):append(chat.error(state.status)));

            -- The command exists but raid_core.lua is not loaded (dwx.lua's
            -- own refusal). Asking again cannot help until a map restart --
            -- detect once and go quiet.
            if (string.find(line, 'The raid is not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'status' and state.building ~= nil) then
            -- ONLY COMMIT AN ENVELOPE THAT CARRIED THE LIST. An early refusal
            -- -- one raised before its verb opened an envelope, which is every
            -- refusal `enter` and `leave` produce -- is auto-wrapped by the
            -- shared writer as d|1|status ... z|status. Committing that blanked
            -- the tier table and the ledger the window had, and then overwrote
            -- the server's own sentence with a green 'Synced.', so the player
            -- was told the sync worked and shown an empty board instead of
            -- being told why they could not enter.
            if (state.building.filled) then
                state.tiers    = state.building.tiers;
                state.fights   = state.building.fights or T{ };
                state.ledger   = state.building.ledger;
                state.runs     = state.building.runs or T{ };

                -- The selection survives a refresh unless its fight is gone
                -- (a server rollback, or a pre-fight-roster server that
                -- sends no f| at all). The element tab follows whatever
                -- fight survived; a roster without element words leaves it
                -- nil and the tab row unrendered.
                if (state.fights[state.fightSel] == nil) then
                    state.fightSel = firstFightOf(nil);
                end

                state.elemSel = elementOf(state.fights[state.fightSel]);

                state.status    = 'Synced.';
                state.statusBad = false;
            end

            state.building = nil;
        elseif (closing == 'shop' and state.building ~= nil) then
            state.shop     = state.building.shop;
            state.pages    = state.building.pages or T{ };
            state.building = nil;

            -- The selection survives a refresh unless its page is gone (a
            -- server rollback, or a pre-pages server that sends no p| at
            -- all -- the shelf then renders as the flat list it used to be).
            if (state.pages[state.pageSel] == nil) then
                state.pageSel = 1;
            end
        end

        return;
    end

    if (kind == 'g') then
        state.purse = {
            balance = tonumber(parts[2]) or 0,
            earned  = tonumber(parts[3]) or 0,
            spent   = tonumber(parts[4]) or 0,
        };

        return;
    end

    if (kind == 'a') then
        state.arena = {
            running = (tonumber(parts[2]) or 0) ~= 0,
            tier    = tonumber(parts[3]) or 0,
            minutes = tonumber(parts[4]) or 0,
            -- Appended at the tail 2026-08-11; absent from an older server,
            -- and 0 means "unknown fight" wherever it is read.
            fight   = tonumber(parts[5]) or 0,
            -- Appended at the tail 2026-08-18 (the multi-arena pass): how
            -- many arenas hold a run, out of how many exist. nil -- not 0 --
            -- on an older server, so the renderer can tell "idle" from
            -- "server predates arenas" and fall back to the shipped line.
            busy     = tonumber(parts[6]),
            capacity = tonumber(parts[7]),
        };

        return;
    end

    -- r| -- one live run (additive, 2026-08-18): venue, area, fight index,
    -- tier index, minutes in. Builds with the status lists and commits on
    -- z|, so a mid-flight reply can never show half an occupancy board.
    if (kind == 'r' and state.building ~= nil and state.building.runs ~= nil) then
        state.building.runs:append({
            venue   = tonumber(parts[2]) or 0,
            area    = tonumber(parts[3]) or 0,
            fight   = tonumber(parts[4]) or 0,
            tier    = tonumber(parts[5]) or 0,
            minutes = tonumber(parts[6]) or 0,
        });

        return;
    end

    -- f| -- the fight roster (additive, 2026-08-11). The WORD is what the
    -- enter verb wants on the wire; the label is what people read. A server
    -- that never sends f| leaves the roster empty, and the Enter buttons
    -- fall back to the tier-only verb that server understands.
    if (kind == 'f' and state.building ~= nil and state.building.fights ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            -- The element rides the tail (additive, 2026-08-18); absent or
            -- empty on an older server, and nil means "no element tabs"
            -- wherever it is read.
            local element = parts[5];

            if (element == '') then
                element = nil;
            end

            state.building.fights[index] = {
                word    = parts[3] or '?',
                label   = parts[4] or '?',
                element = element,
            };
        end

        return;
    end

    if (kind == 't' and state.building ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            state.building.tiers[index] = {
                label = parts[3] or '?',
                base  = tonumber(parts[4]) or 0,
                daily = tonumber(parts[5]) or 0,
            };

            -- A genuine status reply always carries every tier (raid_core's
            -- verbStatus emits t| twice before it closes). One tier is enough
            -- to prove this envelope was an answer rather than a wrapper.
            state.building.filled = true;
        end

        return;
    end

    if (kind == 'l' and state.building ~= nil) then
        state.building.ledger:append({
            delta  = tonumber(parts[2]) or 0,
            age    = tonumber(parts[3]) or 0,
            reason = parts[4] or '',
        });

        return;
    end

    -- p| -- the shop page directory (additive, 2026-08-18). A server that
    -- never sends p| leaves the directory empty and the shelf renders flat,
    -- which is exactly what that server's s| records describe.
    if (kind == 'p' and state.building ~= nil and state.building.pages ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            state.building.pages[index] = {
                word  = parts[3] or '?',
                label = parts[4] or '?',
            };
        end

        return;
    end

    if (kind == 's' and state.building ~= nil and state.building.shop ~= nil) then
        local index = tonumber(parts[2]);

        if (index ~= nil) then
            state.building.shop[index] = {
                label = parts[3] or '?',
                price = tonumber(parts[4]) or 0,
                -- Appended at the tail 2026-08-18; absent from an older
                -- server, and 0 means "no page" wherever it is read.
                page  = tonumber(parts[5]) or 0,
                -- The item id, appended the same day: what the icon and
                -- the hover card are drawn from. nil -- not 0 -- on an
                -- older server, so the renderer knows there is no card.
                itemid = tonumber(parts[6]),
            };
        end

        return;
    end

    -- The live quote rides outside the list-building rule: it is one value,
    -- it names its own window, and the Confirm button exists only while it
    -- is fresh (the server holds the same 60 s rule; this is presentation).
    if (kind == 'q') then
        state.quote = {
            index    = tonumber(parts[2]) or 0,
            price    = tonumber(parts[3]) or 0,
            deadline = os.clock() + (tonumber(parts[4]) or 60),
        };

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWXDATA is
* ours: consumed here and blocked so the chat log never sees it -- before
* parsing, so a malformed record cannot leak as noise.
--]]
ashita.events.register('packet_in', 'dwraid_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwraid'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

local function agoText(age)
    if (age < 3600) then
        return string.format('%dm ago', math.floor(age / 60));
    elseif (age < 86400) then
        return string.format('%dh ago', math.floor(age / 3600));
    end

    return string.format('%dd ago', math.floor(age / 86400));
end

local function purseBlock()
    if (state.purse == nil) then
        imgui.TextDisabled('No purse data yet. Refresh, or wait for the first sync.');

        return;
    end

    imgui.TextColored(theme.colors.hint, string.format('%d driftmarks', state.purse.balance));
    imgui.SameLine();
    imgui.TextDisabled(string.format('(%d earned, %d spent, account-wide)', state.purse.earned, state.purse.spent));
end

local function runLabel(run)
    local tier  = state.tiers[run.tier];
    local fight = state.fights[run.fight];
    local label = tier ~= nil and tier.label or 'unknown tier';

    if (fight ~= nil) then
        label = fight.label .. ' ' .. label;
    end

    return label;
end

local function arenaBlock()
    if (state.arena == nil) then
        return;
    end

    -- A server that sends the busy/capacity tail (2026-08-18) gets the
    -- occupancy board; an older server gets the shipped one-arena lines,
    -- driven by the same fields it always sent.
    if (state.arena.busy ~= nil and state.arena.capacity ~= nil) then
        if (state.arena.busy == 0) then
            imgui.TextColored(theme.colors.ok,
                string.format('All %d arenas are idle.', state.arena.capacity));
        else
            local color = state.arena.busy >= state.arena.capacity
                and theme.colors.hint or theme.colors.ok;

            imgui.TextColored(color,
                string.format('%d of %d arenas busy.', state.arena.busy, state.arena.capacity));

            for _, run in ipairs(state.runs) do
                imgui.TextDisabled(string.format('  %s, %d minute(s) in.',
                    runLabel(run), run.minutes));
            end
        end

        return;
    end

    if (state.arena.running) then
        imgui.TextColored(theme.colors.hint,
            string.format('The arena is occupied (%s, %d minute(s) in).',
                runLabel({ tier = state.arena.tier, fight = state.arena.fight }), state.arena.minutes));
    else
        imgui.TextColored(theme.colors.ok, 'The arena is idle.');
    end
end

--[[
* The element tabs: one per element that holds a fight, wheel order, the
* open one drawn as text in its element's tint (the fight picker's shape,
* one level up). Picking a tab moves the fight selection onto that
* element's first fight, so the Enter buttons below always ask for a fight
* the open tab is showing. On a pre-element server this renders nothing
* and the fight row below shows the whole roster, exactly as it used to.
--]]
local function elementsBlock()
    local elements = presentElements();

    if (#elements == 0) then
        return;
    end

    imgui.TextDisabled('Element:');

    for _, entry in ipairs(elements) do
        imgui.SameLine();

        if (entry.word == state.elemSel) then
            imgui.TextColored(entry.color or theme.colors.ok, '[ ' .. entry.label .. ' ]');
        elseif (imgui.Button(string.format('%s##dwraid_elem_%s', entry.label, entry.word))) then
            state.elemSel  = entry.word;
            state.fightSel = firstFightOf(entry.word);
        end
    end
end

--[[
* The fight picker: one button per fight ON THE OPEN ELEMENT TAB, the
* selected one drawn as text -- the tiersBlock Enter buttons ask for
* whichever fight is selected here. With no element data (a pre-element or
* pre-fight-roster server) the filter is off and every fight renders, and
* with no roster at all this block renders nothing and Enter falls back to
* the tier-only verb.
--]]
local function fightsBlock()
    if (next(state.fights) == nil) then
        return;
    end

    imgui.TextDisabled('Fight:');

    for index = 1, 9 do
        local fight = state.fights[index];

        if (fight ~= nil and (state.elemSel == nil or elementOf(fight) == state.elemSel)) then
            imgui.SameLine();

            if (index == state.fightSel) then
                imgui.TextColored(theme.colors.ok, '[ ' .. fight.label .. ' ]');
            elseif (imgui.Button(string.format('%s##dwraid_fight_%d', fight.label, index))) then
                state.fightSel = index;
            end
        end
    end
end

--[[
* One tier as a row: label, payouts, and the Enter button that is the whole
* point of the window. The button only SENDS the verb -- the server gates
* the party, and its refusal sentence lands in the status line above.
--]]
local function tiersBlock()
    if (next(state.tiers) == nil) then
        imgui.TextDisabled('No tier data yet.');

        return;
    end

    if (imgui.BeginTable('##dwraid_tiers', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Tier', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        imgui.TableSetupColumn('A clear', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        imgui.TableSetupColumn('First of the day', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 70, 0);
        imgui.TableHeadersRow();

        for index = 1, 9 do
            local tier = state.tiers[index];

            if (tier ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(tier.label);
                imgui.TableNextColumn();
                imgui.Text(string.format('%d', tier.base));
                imgui.TableNextColumn();
                imgui.TextColored(theme.colors.ok, string.format('+%d', tier.daily));
                imgui.TableNextColumn();

                if (imgui.Button(string.format('Enter##dwraid_enter_%d', index))) then
                    -- The fight rides the verb by its WORD (the f| record's
                    -- second field): labels hold spaces, and a lowercased
                    -- two-word label would be refused by the parser. No
                    -- roster (an older server) means no fight word, which is
                    -- exactly the verb that server understands.
                    local fight = state.fights[state.fightSel];

                    state.status    = string.format('Asking for the %s trial...',
                        fight ~= nil and (fight.label .. ' ' .. tier.label) or tier.label);
                    state.statusBad = false;

                    if (fight ~= nil) then
                        issue(string.format('!dwx enter %s %s', fight.word, tier.label:lower()));
                    else
                        issue(string.format('!dwx enter %s', tier.label:lower()));
                    end
                end
            end
        end

        imgui.EndTable();
    end
end

local function ledgerBlock()
    if (#state.ledger == 0) then
        imgui.TextDisabled('No driftmark movements yet. The trial pays the first ones.');

        return;
    end

    for _, row in ipairs(state.ledger) do
        imgui.TextColored(row.delta >= 0 and theme.colors.ok or theme.colors.err,
            string.format('%+d', row.delta));
        imgui.SameLine();
        imgui.TextDisabled(string.format('%s  (%s)', row.reason, agoText(row.age)));
    end
end

-- A section header: a breath, the title in the dim ink, a rule under it --
-- the same shape every section of the window wears.
local function sectionHeader(text)
    imgui.Spacing();
    imgui.TextColored(theme.colors.dim, text);
    imgui.Separator();
end

--[[
* The shop: shelf rows with a Buy button each, and a Confirm button that
* exists only while a quote is fresh. Buy asks the server for a quote;
* nothing purchases on one click -- the deliberate second press is the
* dwquest storefront's rule, kept whole.
--]]
--[[
* The page picker: one button per shop page, the selected one drawn as text
* (the fightsBlock shape, kept whole). On a server that sent no p| records
* (pre-pages build) this renders nothing and the shelf below shows every
* row it received -- exactly the flat list that server means.
--]]
local function shopPagesBlock()
    if (next(state.pages) == nil) then
        return;
    end

    imgui.TextDisabled('Page:');

    for index = 1, 9 do
        local page = state.pages[index];

        if (page ~= nil) then
            imgui.SameLine();

            if (index == state.pageSel) then
                imgui.TextColored(theme.colors.ok, '[ ' .. page.label .. ' ]');
            elseif (imgui.Button(string.format('%s##dwraid_page_%d', page.label, index))) then
                state.pageSel = index;
            end
        end
    end
end

local function shopBlock()
    if (next(state.shop) == nil) then
        imgui.TextDisabled('No shop data yet.');

        return;
    end

    shopPagesBlock();

    -- Paged when the server sent a directory, flat when it did not. Shelf
    -- indices are sparse and forever (the server's rule), so the walk runs
    -- the whole 1..99 index space, not #shop.
    local paged = next(state.pages) ~= nil;

    if (imgui.BeginTable('##dwraid_shop', 3, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Price', ImGuiTableColumnFlags_WidthFixed, 70, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableHeadersRow();

        for index = 1, 99 do
            local row = state.shop[index];

            if (row ~= nil and ((not paged) or row.page == state.pageSel)) then
                imgui.TableNextRow();
                imgui.TableNextColumn();

                -- The icon, then the label -- and the hover card on either.
                -- drawIcon leaves the cursor on the same line, and
                -- IsItemHovered reads the LAST item, so the icon's hover is
                -- taken before the label is drawn.
                drawIcon(row.itemid, 20);

                local hovered = imgui.IsItemHovered();

                imgui.Text(row.label);

                if (imgui.IsItemHovered() or hovered) then
                    itemTooltip(row);
                end

                imgui.TableNextColumn();
                imgui.Text(string.format('%d', row.price));
                imgui.TableNextColumn();

                if (imgui.Button(string.format('Buy##dwraid_buy_%d', index))) then
                    state.status    = string.format('Asking for a quote on %s...', row.label);
                    state.statusBad = false;

                    issue(string.format('!dwx buy %d', index));
                end
            end
        end

        imgui.EndTable();
    end

    if (state.quote ~= nil and os.clock() < state.quote.deadline) then
        local quoted = state.shop[state.quote.index];

        if (imgui.Button(string.format('Confirm: %s for %d##dwraid_confirm',
                quoted ~= nil and quoted.label or '?', state.quote.price))) then
            state.quote = nil;

            issue('!dwx confirm');
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('%ds left on the quote',
            math.max(0, math.floor(state.quote ~= nil and (state.quote.deadline - os.clock()) or 0))));
    end
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        serverSilent = false;

        forget();
        requestStatus();
    end

    imgui.SameLine();

    if (imgui.Button('Leave the arena')) then
        state.status    = 'Asking to leave...';
        state.statusBad = false;

        issue('!dwx leave');
    end

    imgui.SameLine();

    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    else
        imgui.TextDisabled('');
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Separator();

    purseBlock();
    arenaBlock();

    sectionHeader('The trials -- gather your party in a city and go.');

    elementsBlock();
    fightsBlock();
    tiersBlock();

    sectionHeader('The Driftmark shop -- hover an item for its card.');

    shopBlock();

    sectionHeader('Recent movements');

    ledgerBlock();
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape, and its
* reasoning, kept verbatim).
--]]
ashita.events.register('d3d_present', 'dwraid_present', function ()
    -- Before the visibility check: a sync requested by a zone-in still has
    -- to reach the server with the window shut.
    if (state.syncAt ~= nil and os.clock() >= state.syncAt) then
        -- A typed line handed to a client that is still zoning is not
        -- delayed, it is LOST. The client's own zoning flag is the fact;
        -- wait it out (dwfame's lesson, kept verbatim).
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (player ~= nil and player:GetIsZoning() ~= 0) then
            state.syncAt   = os.clock() + 1.0;
            state.syncSlot = nil;
        elseif (state.syncSlot == nil) then
            -- Zoning done. Every sibling clears its zoning flag on the SAME
            -- frame, so hold this addon's stagger slot before firing or the
            -- zone-in syncs collide at the client's chat throttle and all but
            -- one come back "A command error occurred." (dwecho.lua's ZONE_ORDER
            -- is the shared slot order; 2026-08-14).
            state.syncSlot = os.clock() + echo.zoneSlot('dwraid') * echo.SEND_INTERVAL;
            state.syncAt   = state.syncSlot;
        else
            state.syncAt   = nil;
            state.syncSlot = nil;

            forget();
            requestStatus();
        end
    end

    -- Answer tracking runs whether or not the window is open: it is exactly
    -- the window-closed zone-in auto-syncs that must stop when the server
    -- has gone silent (an unknown !command here is /say chat).
    checkAnswers();

    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 540, 580 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse
    -- them into a single unthemed dock that imgui.ini kept across reloads.
    -- The scrollbar came back in 1.4.0: the tier headers, the shop headers
    -- and the hover-card shelf grew the content taller than the old fixed
    -- fit, and clipping the ledger with no way to reach it is worse than a
    -- scrollbar (the window resizes; the bar is for people who shrink it).
    local visible = imgui.Begin('DriftwoodXI Raid##dwraid', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwraid'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwraid'):append(chat.message('Window closed. `!raid` typed by hand says the same things.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs: a window showing the purse
* as it stood two clears ago is the quiet kind of wrong this project exists
* to rule out, and a sync costs one chat line.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting, and for the
        -- silent-server detection: opening the window is the deliberate
        -- act that earns one more try.
        state.reported = false;
        serverSilent   = false;

        forget();
        requestStatus();
    end
end

ashita.events.register('command', 'dwraid_command', function (e)
    local args = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwraid' and first ~= '/raid' and first ~= '/dwx') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        serverSilent = false;

        forget();
        requestStatus();

        return;
    end

    toggleWindow();
end);

--[[
* Sync on login and zone-in (0x000A serves both) -- and for this addon the
* zone-in IS the payoff moment: entering the arena, leaving it, and the
* return warp are all zone changes, so the window refreshes itself exactly
* when the purse and the arena state just changed. Everything server-derived
* resets first -- a login may be a different character.
--]]
ashita.events.register('packet_in', 'dwraid_zonein', function (e)
    if (e.id == 0x000A) then
        state.purse     = nil;
        state.arena     = nil;
        state.fights    = T{ };
        state.fightSel  = 1;
        state.elemSel   = nil;
        state.tiers     = T{ };
        state.ledger    = T{ };
        state.shop      = T{ };
        state.pages     = T{ };
        state.pageSel   = 1;
        state.quote     = nil;
        state.building  = nil;
        state.inbound   = nil;
        state.status    = 'Syncing...';
        state.statusBad = false;

        forget();

        -- No auto-sync against a server that has shown it does not speak
        -- dwraid: an unknown !command falls through to /say here, so each
        -- retry would be the player chatting "!dwx status" at whoever is
        -- nearby. Opening the window retries deliberately.
        if (not serverSilent) then
            state.syncAt = os.clock() + 4.0;
        else
            state.status = 'Raid board paused (no answer from the server). Open the window to retry.';
        end
    end
end);

--[[
* Watch what the player sends.
*
* Bare `!raid` (and the ui/window/gui spellings of `!dwx`) toggles this
* window instead of going to the server -- the server verb is the name
* players learn, so it has to be a door and not a dead end. `!raid enter`
* and every argumented form still pass through untouched; that is the
* escape hatch this addon's header promises.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped
* (dwbags' lesson, kept verbatim).
--]]
ashita.events.register('packet_out', 'dwraid_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!raid' or lower == '!dwx' or
        lower == '!dwx ui' or lower == '!dwx window' or lower == '!dwx gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwx') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwraid_load', function ()
    print(chat.header('dwraid'):append(chat.message('/raid, /dwraid or !raid opens the raid board.')));
end);
