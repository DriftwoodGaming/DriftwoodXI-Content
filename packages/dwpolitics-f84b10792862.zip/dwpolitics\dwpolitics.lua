--[[
* DriftwoodXI -- dwpolitics
*
* The seats of power in a window: the Crown of Vana'diel, the Mayors of
* Bastok, San d'Oria and Windurst, and the Royal Treasurer, each won by a
* vote of every eligible account on a four-week season clock. The window
* shows the season and its phase, every seat and its holder, every race with
* its candidates, platforms, pledges and endorsements, whether YOU may file
* or vote in each (the server's gates, in the server's words), the Treasury,
* every act in effect, the Wanted list and the Chronicle. A holder's powers
* are buttons.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited
* whole). Everything arrives on the wire as records, and every button is a
* real typed command (`!dwb vote bastok Ayla` reaches exactly the dispatch
* `!politics vote bastok Ayla` reaches). The server holds the ballots, runs
* the count and clamps every power; this window can never do anything a
* player cannot.
*
* TURN IT OFF AND NOTHING IS LOST. `!politics` does all of it typed.
*
* The notice reroute, the answer clock, the latches, the debounces and the
* commit-on-z| discipline are dwnemesis 1.3.1's, inherited whole; the
* comments that explain them live there and are not repeated here.
*
* 1.1.0 (2026-09-14) -- THE WINDOW EXPLAINS ITSELF. It used to open on
* "Season 1, day 1 -- nomination, 6d left." and five tab labels, and a player
* could not learn from it what a phase was, what they could do today, when
* voting opened, what an endorsement or a pledge or the Treasury was, or why
* a seat said "cannot file". Added: a phase line in plain words under the
* season line, a How it works tab walking the whole season, a hover sentence
* on every tab, button and column, and the server's own reason beside every
* refusal.
*
* AND NOT ONE NUMBER OF ITS OWN. Every figure this window quotes -- phase
* lengths, the quorum, the pledge band and its cut and its cooldown, the
* play-hours gate, the Crown's endorsement threshold, the indictment window
* and fine band, the idle-abdication clock, each seat's fee, age and term --
* arrives in the ADDITIVE `f|` and `r|` records and is drawn from there. A
* server too old to send them still works: the sentences that carry numbers
* are replaced by the ones that do not, and a line says why. The protocol
* version did not move.
*
* 1.2.0 (2026-09-15) -- POWERS WITH CHECKS, AND THE OWNER'S TAB. Six seats
* now (the Mayor of Jeuno was APPENDED LAST as seat 6, so every ordinal on
* this wire kept its meaning), and the seats got levers: a canned
* proclamation, the outpost fare in a nation's regions, the tolls into
* Jeuno, the order of the realm, a mercenary holiday and an amnesty. Every
* one of them is drawn here with its clock and its band ALREADY ON IT --
* greyed, with the wait or the cap in words, BEFORE the click -- and every
* one of those figures rides `f|`, `b|`, `o|` field 7 or `s|` field 11. The
* 1.1.0 rule did not bend for a single button.
*
* 1.3.0 (2026-09-15) -- THE LEVY, AND THE LEDGER THAT MAKES IT BEARABLE.
* The office holders' travel levers now run from a fifth of the stock price
* to twenty times it, and every gil charged ABOVE the stock price is split:
* half to the holder personally, half burned out of the game. That is a lot
* of gil moving on one person's say-so, so the whole of it is public -- a
* Revenue tab drawing the seat totals and the realm's burn off `x|`, the
* last payments off `u|` a page at a time, and the rate history off `i|`.
* Anyone can read what any holder took, in this season or ever, and what was
* burned beside it.
*
* NOT ONE GIL FIGURE IN THAT TAB IS THIS WINDOW'S. Takes, burns, counts,
* charges and the bands the levers run between all ride the wire; the ONLY
* thing said here that is not on a record is the halving rule, and it is
* said in words, once, and never used to compute anything.
*
* THE ADMIN TAB IS NOT DRAWN AT ALL unless the SERVER says so on `m|`.
* `BeginTabItem('Admin###dwb_tab_admin')` is not called when `state.admin`
* is false -- not greyed, not a placeholder, not there. The client's own
* idea of its GM level is a number it was told and could be told
* differently, so it is never consulted; every control in the tab sends
* `!dwb admin ...` and the server refuses anything under its own bar.
--]]

addon.name    = 'dwpolitics';
addon.author  = 'DriftwoodXI';
addon.version = '1.3.0';
addon.desc    = 'DriftwoodXI Politics: run for a seat, vote, pledge, govern, read the Chronicle.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

echo.install();

local DATA_SENDER = '_DWBDATA';
local PROTOCOL    = 1;

-- KEEP IN SYNC WITH `NOTICE` IN modules/driftwoodxi/politics_core.lua.
local NOTICE_TAG  = '[Politics] ';
local NOTICE_MODE = 121;

-- KEEP IN SYNC WITH `SEATS` IN politics_core.lua (the harness reads both).
-- JEUNO IS LAST AND STAYS LAST: every o|, r|, c|, y| and v| record carries a
-- seat ORDINAL, so appending is the only edit that leaves the five older
-- seats reading as themselves on a window that has not updated.
local SEAT_KEYS  = { 'crown', 'bastok', 'sandoria', 'windurst', 'treasurer', 'jeuno' };
local SEAT_NAMES = { "Crown of Vana'diel", 'Mayor of Bastok', "Mayor of San d'Oria", 'Mayor of Windurst', 'Royal Treasurer', 'Mayor of Jeuno' };
local SEAT_SHORT = { 'Crown', 'Bastok', "San d'Oria", 'Windurst', 'Treasurer', 'Jeuno' };

-- The three Mayors with a conquest nation behind them: the seats that price
-- an outpost. Jeuno is a Mayor and is not one of these, which is exactly why
-- it has tolls instead.
local TOWN_KEYS  = { 'bastok', 'sandoria', 'windurst' };
local MAYOR_KEYS = { 'bastok', 'sandoria', 'windurst', 'jeuno' };
local IS_TOWN    = { bastok = true, sandoria = true, windurst = true };

local DECREE_WORDS   = { 'exp', 'capacity', 'fame', 'shop', 'chocobo' };
local FESTIVAL_WORDS = { 'shop', 'chocobo', 'fame' };

--[[
* WHAT A LEVY PAYMENT WAS FOR, in words. The keys are the four `source`
* values politics_core.lua's levy() is ever called with (Part C compares the
* two lists and fails if the server grows a fifth). A source this table does
* not know prints ITSELF rather than being dropped or renamed: an unreadable
* word in a public ledger is still evidence; a missing row is not.
--]]
local SOURCE_WORDS =
{
    port_hp = 'home point',
    port_sg = 'survival guide',
    port_op = 'outpost',
    merc    = 'mercenary cut',
};

-- KEEP IN SYNC WITH `FROZEN_SENTENCE` IN politics_core.lua (Part C compares
-- them). It is the banner, and it is the tip on every control the freeze
-- disarms, so the window and the refusal a click would have earned say one
-- sentence.
local FROZEN_LINE = 'Politics is frozen by the owner.';

-- KEEP IN SYNC WITH `PHASE_WHAT` IN politics_core.lua -- byte for byte; the
-- harness compares the two tables. The typed `!politics` and this window say
-- the same sentence about the same day because it IS the same sentence.
local PHASE_WHAT =
{
    preseason  = 'Nothing is open yet.',
    nomination = 'Nomination: candidates file for a seat, set a platform, and pledge gil to the voters. Nobody votes yet.',
    campaign   = 'Campaign: filing is closed. Candidates campaign and may raise a pledge; seated officeholders endorse.',
    poll       = 'The poll: every eligible account casts one secret ranked ballot in each race.',
    governing  = 'Governing: the winners hold their seats and use their powers until the next count.',
};

-- What each seat DOES once it is won. Prose, never a number: the bands and
-- percentages behind these powers are the server's and are not on this wire,
-- so this window describes them and quotes none of them.
local SEAT_DOES =
{
    'decrees a world-wide bonus for a day (experience, capacity, fame, cheaper shops or free chocobos), names a weekly Public Enemy with a bounty, indicts and pardons, knights the deserving, calls a mercenary holiday or an amnesty, and can veto a rate act',
    'runs a week-long festival in Bastok, prices the outposts in every region Bastok holds, calls a town hall, and goes home at will',
    'runs a week-long festival in San d\'Oria, prices the outposts in every region San d\'Oria holds, calls a town hall, and goes home at will',
    'runs a week-long festival in Windurst, prices the outposts in every region Windurst holds, calls a town hall, and goes home at will',
    'sets the mercenary board cut and the travel fee basis, and spends the Treasury on a login stimulus or a Drift Coin bonus',
    'sets the tolls on warps into the city, runs a week-long festival in Jeuno, calls a town hall, and goes home at will',
};

local WIRE_MAX = 2147483647;

local function wireInt(text, default)
    local value = tonumber(text);

    if (value == nil or value ~= value or value < -WIRE_MAX or value > WIRE_MAX or value ~= math.floor(value)) then
        return default or 0;
    end

    return value;
end

local state = T{
    open = T{ false },

    -- The board, committed on z|status from a pending copy.
    season    = nil,   -- { season, phase, phaseEnds, day, crown, serverNow, pollOpen, pollClose, countAt, seasonEnds }
    seats     = {},    -- [idx] = { name, mandate, from, to, mine }
    races     = {},    -- [idx] = { candidates = {}, canFile, fileReason, canVote, voted, bonus, voteReason }
    treasury  = nil,   -- { balance, income, spend }
    owed      = 0,

    -- The server's own numbers (f| / r|), nil against a server too old to
    -- send them. NOTHING in this window hard-codes any of these.
    rules     = nil,
    seatRules = {},
    pledgeAt  = 0,     -- epoch second this character may pledge again; 0 = now

    --[[
    * 1.2.0, and every one of these is the SERVER's word on something this
    * window would otherwise have to decide for itself:
    *   admin/adminLevel -- m|, and the ONLY thing that draws the Admin tab
    *   frozen           -- s| field 11 (m| repeats it)
    *   knobs/knobList   -- b|, one row per rate lever with its own clock
    *   procs            -- l|, the proclamation menu and its templates
    *   knights          -- j|, the order of the realm
    --]]
    admin      = false,
    adminLevel = 0,
    frozen     = false,
    knobs      = {},
    knobList   = {},
    procs      = {},
    knights    = {},

    --[[
    * 1.3.0, the levy. `levy` is the x| summary that rides every status
    * envelope -- one row per seat that has ever levied, plus seat 0, which
    * is not a seat at all but the realm's totals and its burn. A board that
    * has never levied sends NO x| row, which is why `levyAny` is tracked
    * separately: an empty table here means "nothing yet", never "the server
    * did not say".
    --]]
    levy       = {},
    levyAny    = false,

    acts      = {},
    enemy     = nil,
    wanted    = {},
    syncedAt  = nil,
    clockSkew = 0,     -- serverNow - os.time() at commit

    -- The Chronicle, committed on z|chronicle.
    chronicle = { page = 1, per = 12, total = 0, rows = {} },
    chronPending = nil,
    chronAsked   = nil,

    -- The levy ledger, committed on z|revenue. `u|` carries no page count
    -- the way `g|` does for the Chronicle, so the page shown is the page
    -- this window ASKED for, and Older is offered while the last answer
    -- still had rows in it -- never against a page size remembered here.
    revenue    = { page = 1, rows = {}, acts = {}, got = false },
    revPending = nil,
    revAsked   = nil,

    pending   = nil,
    inbound   = nil,
    status    = '',
    statusBad = false,
    reported  = false,

    requested    = nil,
    serverSilent = false,
    refused      = false,
    boardFailed  = false,

    -- One debounce per write verb, PAST the queue's dupe-collapse.
    writeAt = {},

    -- Inputs for the powers that take an argument.
    inName   = T{ '' },
    inNumber = T{ '' },
    inEnemy  = T{ '' },
    inPot    = T{ '' },
    inAct    = T{ '' },
    inText   = T{ '' },
    inVote   = T{ '' },
    inKnight = T{ '' },
    inAdmin  = T{ '' },

    -- One slider buffer per knob, seeded from b| and re-seeded whenever the
    -- server's value moves (never while the player is dragging it).
    knobBuf  = {},

    -- The Freeze toggle's two-click arm. A stray click on the owner's tab
    -- must not stop every power on the server.
    arm      = nil,
};

local TIPS = {
    refresh      = 'Ask the server for the board again. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks -- update dwpolitics through the launcher.',
    claim        = 'Collect every gil payout owed to your account: refunds, pledge shares, bounties, stimulus.',
    file         = 'File for this seat. The filing fee is held until the count and refunded if you win.',
    fileNo       = 'Why you cannot file for this seat right now, in the server\'s words.',
    vote         = 'Cast your ballot for this candidate as first choice. Rank more by typing !politics vote <seat> <a>,<b>,<c>.',
    voteNo       = 'Why you cannot vote in this race right now.',
    voted        = 'Your ballot is in. Voting again replaces it.',
    withdraw     = 'Withdraw your filing. The fee and any pledge come straight back.',
    platform     = 'Up to 86 characters on the ballot beside your name.',
    pledge       = 'Gil held by the server: split among everyone who votes in your race if you win, 90 percent back if you lose.',
    pay          = 'Pay your indictment fine to the Treasury and clear the Wanted mark now.',
    decree       = 'A world buff for 24 hours. One decree a week.',
    indict       = 'Mark a character Wanted for 72 hours with a fine. Two a week; one per account per season.',
    pardon       = 'Clear a Wanted mark. One a week.',
    enemy        = 'Name a Dungeon- or Legend-tier Nemesis the Public Enemy: a Treasury pot, a quarter to each of the first four accounts to kill it this week.',
    veto         = 'Reverse a Treasurer\'s knob act within 24 hours of it (the owner may veto anything).',
    festival     = 'A week-long perk in your town. One festival a week.',
    townhall     = 'A 30-minute window in which anyone standing in your town can !politics attend. One a week.',
    home         = 'Teleport to your town. Ten minutes between uses.',
    attend       = 'Be counted at the town hall in session where you stand. +5 fame there.',
    -- The band for these two has never ridden this wire, so it is not
    -- quoted here either (the 1.1.0 rule); the server names it in the
    -- refusal if a value is outside it.
    merc         = 'The mercenary board\'s cut as a percent, applied to the next contract to settle.',
    port         = 'Travel fees as a percent of the stock price.',
    stimulus     = 'Every account that logs in over the next 48 hours takes this much gil from the Treasury, until twenty times it is spent.',
    drift        = 'Contracts pay this percent more Drift Coins for 48 hours. Costs the Treasury 250,000.',
    resign       = 'Vacate your seat to the Regent. There is no undo.',
    chronPrev    = 'Newer entries.',
    chronNext    = 'Older entries.',
    act          = 'An act in effect, and when it ends.',

    --[[
    * 1.1.0: a sentence on every tab, every column and every control that had
    * none. A player should never have to open a tab to find out what it is
    * for, and "cannot file" should never be the whole story -- the server's
    * own reason is drawn beside it and repeated here.
    --]]
    season       = 'The season number, the day within it, and which phase the season is in right now.',
    phase        = 'What this phase is and what you can do in it today. The How it works tab walks the whole season.',
    tabSeats     = 'Who holds each of the six seats right now, the order of the realm, and the powers of any seat YOU hold.',
    tabElection  = 'This season\'s races: who is running, on what platform, with what pledge, and your File and Vote buttons.',
    tabTreasury  = 'The public purse and everything currently in effect across the world.',
    tabWanted    = 'Accounts the Crown has marked Wanted, and the button that pays your own fine.',
    tabChronicle = 'The public record of every political act, newest first.',
    tabHow       = 'How the whole season works, in plain words, with the server\'s own numbers.',

    colSeat      = 'One of the six elected offices.',
    colHolder    = 'The character who won it, or the Regent when nobody holds it.',
    colMandate   = 'How it was won: full (a contested count), acclaimed (the only candidate), or regent (nobody).',
    colTerm      = 'The seasons this term runs from and to.',
    colAct       = 'The act number. The Crown vetoes a Treasurer act by this number.',
    colActSeat   = 'The seat whose holder did it.',
    colActWhat   = 'What the act does.',
    colActBy     = 'The character who did it.',
    colActEnds   = 'How long the act still has to run.',

    seatPowers   = 'These buttons appear only for a seat you hold, and every one of them is a real typed command.',
    noSeat       = 'Win a seat and its powers appear here. Until then this tab is the scoreboard.',
    candidate    = 'A candidate: their pledge to the voters and how many seated officeholders have endorsed them. Hover the row for their platform.',
    filed        = 'You have already filed this season. One filing per account per season.',
    fileClosed   = 'Filing is only open during the nomination phase, at the start of the season.',
    nobodyFiled  = 'Nobody has filed for this seat yet.',
    pledgeWait   = 'A pledge may be raised once every few hours, and the server says exactly when. The limit exists because every pledge is announced world-wide.',
    treasuryLine = 'Everything the Treasury holds, and what it has taken in and paid out this season.',
    enemyLine    = 'This week\'s Public Enemy, its bounty, and how much of it has already been paid out.',
    wantedRow    = 'A Wanted account: the charge, who laid it, the fine that clears it early, and how long it still has to run.',
    owedLine     = 'Gil the system owes your account. It waits here until you claim it.',
    inputName    = 'A character name, for the Crown\'s Indict and Pardon buttons.',
    inputEnemy   = 'The name of a Dungeon- or Legend-tier Nemesis roster monster.',
    inputPot     = 'A gil amount: the Public Enemy bounty, or your pledge on the Election tab.',
    inputNumber  = 'The number the Treasurer button beside it takes: a percent, or gil for the stimulus.',
    inputAct     = 'The act number to veto. Act numbers are in the Act column on the Treasury tab.',
    inputPlat    = 'Your platform: one line beside your name on every ballot.',

    --[[
    * 1.2.0. The new powers, the order of the realm, the freeze and the
    * owner's tab. Anything here that would carry a figure carries it from
    * the wire instead and is built where it is drawn -- these are the
    * sentences that have no number in them.
    --]]
    frozen       = 'The owner has suspended every power of office: no decrees, no festivals, no rate levers, and every rate is back at stock. Filing, pledging, endorsing, voting and the count all continue as normal.',
    tabAdmin     = 'The owner\'s overrides. This tab exists only because the server told this window you are the owner; nobody else is shown it at all.',
    knightsBlock = 'The Knights of the Realm: an honour in the Crown\'s gift, held by the ACCOUNT for the rest of that reign. The order lapses in full when the Crown changes hands.',
    knightsNone  = 'Nobody is a Knight of the Realm right now. The Crown names them, and the order lapses whenever the Crown changes hands.',
    proclaim     = 'Speak one of the canned lines to the whole world as your seat. The server writes the sentence and fills in your name -- there is no free text at any seat.',
    proclaimWait = 'One proclamation per SEAT, not per holder: resigning and being re-seated does not buy a second voice.',
    outpost      = 'The outpost fare in every region your nation holds right now, as a percent of the stock price. Which regions those are is asked of conquest every time a fare is quoted.',
    tolls        = 'The fare on a home-point warp INTO the Jeuno group, as a percent of the stock fare. A hop between two Jeuno crystals stays free.',
    knight       = 'Name a character a Knight of the Realm. The honour is their ACCOUNT\'s and lasts the rest of your reign.',
    unknight     = 'Revoke this knighthood. No clock holds this up: taking an honour back is never the thing a cooldown should delay.',
    holiday      = 'Send the mercenary board\'s cut to the lowest it will take, for a day. The Treasurer\'s number is untouched and comes straight back.',
    holidayLive  = 'A mercenary holiday is already running. The act and its clock are on the Treasury tab.',
    amnesty      = 'Close every open indictment at once. Once a season.',
    knobLine     = 'A rate lever: what it is set to now, what a veto would put back, and when it may move again.',
    wireless     = 'The server did not send this, so this window will not invent it. Update dwpolitics, or ask a GM whether the server is current.',

    colKnob      = 'The lever: the mercenary cut, travel fees, the Jeuno tolls, and one outpost fare per nation.',
    colKnobSeat  = 'The seat that owns this lever. The owner moves it whenever; its holder waits on the clock.',

    adminFreeze  = 'Suspend every power of office until you lift it. Two clicks, because one stray click should never stop the server.',
    adminArmed   = 'Click again to confirm, or Cancel. Nothing has been sent yet.',
    adminSeat    = 'Every control in this block acts AS this seat: past its cooldown, inside its band, written to the Chronicle as the owner.',
    adminKnob    = 'Set this lever directly. This is the one power that still works while politics is frozen, so a runaway rate can be put back before the thaw.',
    adminEnd     = 'End this act now. Whatever it was arming is re-derived without it.',
    adminRevert  = 'The owner\'s veto: reverse the act, and put a rate lever back to what it was.',
    adminStrike  = 'Strike this Wanted mark.',
    adminVacate  = 'Vacate this seat to the Regent.',
    adminTreas   = 'What the Treasury holds. The server refuses any spend it cannot cover, in its own words.',
    inputKnight  = 'A character name, for Knight and Unknight.',
    inputAdmin   = 'A character name, for the owner\'s Indict, Pardon, Knight and Strike buttons.',

    --[[
    * 1.3.0. The levy is the one power that moves gil into a private pocket,
    * so every sentence about it here says where the gil went and none of
    * them quotes a figure -- the figures are all on x|, u| and i|.
    --]]
    tabRevenue   = 'The levy: what each seat has taken out of the travel fares and the mercenary cut, what was burned beside it, who paid it, and every rate change that priced it.',
    revenueRule  = 'Every gil charged above the stock price is split in half: half to the seat\'s holder personally, half burned out of the game. Discounts cost the holder nothing and pay nobody.',
    revenueNone  = 'No office holder has levied a single gil yet. The moment one does, it appears here and stays here.',
    revenueRealm = 'Not a seat: the whole realm\'s totals, and above all the gil BURNED -- taken out of the game for good.',
    revenuePrev  = 'Newer payments.',
    revenueNext  = 'Older payments.',
    revenuePay   = 'One payment: what the payer was actually charged, what reached the seat\'s holder, and what was burned.',
    revenueRate  = 'Every recent move of a rate lever, newest first. Who turned it is not always who was paid -- the owner can turn any lever and the seated holder still collects.',
    revenueEmpty = 'Nothing on this page. Newer goes back.',

    colRevSeat   = 'The seat that was paid, or the realm for the totals.',
    colRevTake   = 'Gil that reached that seat\'s holder personally this season.',
    colRevBurn   = 'Gil destroyed this season beside it -- the other half of every markup.',
    colRevCount  = 'How many payments this season, not how much gil.',
    colRevLife   = 'The same two figures over every season there has ever been.',
    colRevWhen   = 'How long ago the payment was made.',
    colRevWho    = 'The character who paid it.',
    colRevWhat   = 'What was bought: a home point warp, a survival guide, an outpost warp, or a mercenary contract\'s cut.',
    colRevCharged = 'What the payer actually handed over, the stock price included.',
};

local SEND_INTERVAL  = 1.2;
local WRITE_DEBOUNCE = 3.0;
local INPUT_MAX      = 96;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local function askStatus(force)
    if (state.refused) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    if (state.boardFailed) then
        if (not force) then
            return;
        end

        state.boardFailed = false;
    end

    if (force and state.statusBad) then
        state.status    = '';
        state.statusBad = false;
    end

    state.requested = { at = os.clock(), tries = 1 };

    issue('!dwb status');
end

local function askChronicle(page)
    if (state.refused) then
        return;
    end

    state.chronAsked = { at = os.clock(), page = page };

    issue(string.format('!dwb chronicle %d', page));
end

-- The levy ledger, paged exactly the way the Chronicle is: one read verb,
-- one page number, and the page this window shows is the page it asked for.
local function askRevenue(page)
    if (state.refused) then
        return;
    end

    page = math.max(1, math.floor(page or 1));

    state.revAsked = { at = os.clock(), page = page };

    issue(string.format('!dwb revenue %d', page));
end

local function checkAnswers()
    local asked = state.requested;

    if (asked == nil) then
        return;
    end

    if (not echo.canSend()) then
        asked.at = os.clock();

        return;
    end

    if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
        return;
    end

    if (asked.tries >= ANSWER_TRIES) then
        state.requested    = nil;
        state.serverSilent = true;

        return;
    end

    asked.at    = os.clock();
    asked.tries = asked.tries + 1;

    issue('!dwb status');
end

-- A write: one line, debounced per verb, a status line for feedback.
local function write(verb, command, feedback)
    local at = state.writeAt[verb];

    if (at ~= nil and (os.clock() - at) <= WRITE_DEBOUNCE) then
        return false;
    end

    state.writeAt[verb] = os.clock();
    state.status        = feedback or (verb .. '...');
    state.statusBad     = false;

    issue(command);

    return true;
end

local function writing(verb)
    local at = state.writeAt[verb];

    return at ~= nil and (os.clock() - at) <= WRITE_DEBOUNCE;
end

--[[
* Record parsing (dwb protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function freshBoard()
    return { season = nil, seats = {}, races = {}, treasury = nil, owed = 0, acts = {}, enemy = nil, wanted = {},
        rules = nil, seatRules = {}, pledgeAt = 0,
        admin = false, adminLevel = 0, frozen = false, knobs = {}, knobList = {}, procs = {}, knights = {},
        levy = {}, levyAny = false };
end

-- A wire field that is nothing but digits. The `m|` disambiguation below is
-- the only reader that needs to know the difference between a number and a
-- word, and it needs to know it exactly.
local function allDigits(text)
    return type(text) == 'string' and text ~= '' and text:match('^%d+$') ~= nil;
end

local function race(board, idx)
    board.races[idx] = board.races[idx] or { candidates = {}, canFile = false, fileReason = '', canVote = false, voted = false, bonus = 0, voteReason = '' };

    return board.races[idx];
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], -1);

        if (version ~= PROTOCOL) then
            state.refused      = true;
            state.inbound      = nil;
            state.requested    = nil;
            state.pending      = nil;
            state.chronPending = nil;
            state.revPending   = nil;
            state.serverSilent = false;
            state.boardFailed  = false;

            print(chat.header('dwpolitics'):append(chat.error(string.format(
                'server protocol %d, addon expects %d. Update dwpolitics through the launcher.', version, PROTOCOL))));

            return;
        end

        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.inbound == 'status') then
            state.requested = nil;
            state.pending   = freshBoard();
            state.status    = '';
            state.statusBad = false;
        elseif (state.inbound == 'chronicle') then
            state.chronAsked   = nil;
            state.chronPending = { page = 1, per = 12, total = 0, rows = {} };
        elseif (state.inbound == 'revenue') then
            -- `u|` carries no page field, so the page this envelope belongs
            -- to is the page that was asked for. A `!dwb revenue 3` typed by
            -- hand with the window open lands on the page already shown,
            -- which is honest: this window did not ask for it.
            local asked = state.revAsked;

            state.revAsked   = nil;
            -- `got` LATCHES THE ANSWER, not the rows. A ledger with nothing
            -- in it answers with an empty envelope, and a tab that asked
            -- again every frame because the answer was empty would be a
            -- command every 1.2 seconds for as long as the tab stayed open.
            state.revPending = { page = asked ~= nil and asked.page or state.revenue.page, rows = {}, acts = {}, got = true };
        end

        return;
    end

    --[[
    * `m|` IS TWO RECORDS ON THIS WIRE, AND THE RULE IS THE SHAPE. The shared
    * writer in squad_storage.lua spells a note `m|<text>` and every other
    * protocol riding it uses it that way; 2026-09-15 took `m|` for the admin
    * record here. Nothing under !dwb calls note() today, so the collision is
    * latent -- but a reader disambiguates the way it always should have:
    * `m|` here is EXACTLY THREE FIELDS, every one of them digits. Anything
    * else on an m| line is a note and is shown as one.
    *
    * isAdmin is the SERVER's verdict and the only thing that draws the Admin
    * tab. It is committed with the rest of the board on z|status, like every
    * other record: a tab that appeared halfway through an envelope would be
    * drawn from half a board.
    --]]
    if (kind == 'm' and #parts == 4 and allDigits(parts[2]) and allDigits(parts[3]) and allDigits(parts[4])) then
        if (state.pending ~= nil) then
            state.pending.admin      = wireInt(parts[2]) ~= 0;
            state.pending.frozen     = wireInt(parts[3]) ~= 0;
            state.pending.adminLevel = wireInt(parts[4]);
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        if (kind == 'e') then
            if (state.inbound ~= nil and state.inbound ~= 'status' and state.inbound ~= 'chronicle') then
                state.writeAt[state.inbound] = nil;
            end

            if (state.inbound == 'status') then
                state.pending = nil;
            elseif (state.inbound == 'chronicle') then
                state.chronPending = nil;
            elseif (state.inbound == 'revenue') then
                -- A REFUSAL IS STILL AN ANSWER. Latching it stops the tab
                -- re-asking every frame; the sentence the server refused
                -- with is on the status line, and Newer/Older asks again.
                state.revPending    = nil;
                state.revenue.got   = true;
            end
        end

        if (text == '') then
            return;
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwpolitics'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    local pending = state.pending;

    if (kind == 's' and pending ~= nil) then
        pending.season = {
            season    = wireInt(parts[2]),
            phase     = parts[3] or '',
            phaseEnds = wireInt(parts[4]),
            day       = wireInt(parts[5]),
            crown     = wireInt(parts[6]) ~= 0,
            serverNow = wireInt(parts[7]),

            -- ADDITIVE (server 2026-09-14): an older server sends six fields
            -- and these read 0, which every reader below tests for.
            pollOpen   = wireInt(parts[8]),
            pollClose  = wireInt(parts[9]),
            countAt    = wireInt(parts[10]),
            seasonEnds = wireInt(parts[11]),

            -- ADDITIVE (server 2026-09-15), field 11: the owner's freeze. A
            -- server too old to send it reads 0, which is the unfrozen world
            -- every earlier server was in.
            frozen     = wireInt(parts[12]) ~= 0,
        };

        return;
    end

    -- ADDITIVE: the rules, as the server's own numbers.
    if (kind == 'f' and pending ~= nil) then
        pending.rules = {
            pledgeMin         = wireInt(parts[2]),
            pledgeMax         = wireInt(parts[3]),
            pledgeCut         = wireInt(parts[4]),
            pledgeCooldown    = wireInt(parts[5]),
            quorum            = wireInt(parts[6]),
            platformMax       = wireInt(parts[7]),
            seasonDays        = wireInt(parts[8]),
            nominationEnd     = wireInt(parts[9]),
            campaignEnd       = wireInt(parts[10]),
            pollEnd           = wireInt(parts[11]),
            voteHours         = wireInt(parts[12]),
            crownEndorsements = wireInt(parts[13]),
            indictSeconds     = wireInt(parts[14]),
            fineMin           = wireInt(parts[15]),
            fineMax           = wireInt(parts[16]),
            idleDays          = wireInt(parts[17]),

            -- ADDITIVE (server 2026-09-15), fields 17..26: the cadences, the
            -- caps and the two bands the 2026-09-15 powers refuse on. Every
            -- one of them is a figure this window prints, which is why they
            -- are on the wire at all.
            knobCooldown      = wireInt(parts[18]),
            proclaimCooldown  = wireInt(parts[19]),
            knightMax         = wireInt(parts[20]),
            knightCooldown    = wireInt(parts[21]),
            holidaySeconds    = wireInt(parts[22]),
            holidayCooldown   = wireInt(parts[23]),
            outpostMin        = wireInt(parts[24]),
            outpostMax        = wireInt(parts[25]),
            tollsMin          = wireInt(parts[26]),
            tollsMax          = wireInt(parts[27]),

            -- ADDITIVE (server 2026-09-15b), fields 27..28: the Treasurer's
            -- travel lever finally has its band on the wire, which is what
            -- turns its input into a slider. The three travel bands widened
            -- to 20..2000 in the same round; nothing here knows that, and
            -- that is the point.
            portMin           = wireInt(parts[28]),
            portMax           = wireInt(parts[29]),
        };

        return;
    end

    -- ADDITIVE: one rate lever -- what it is, what it was, when it may move
    -- again, and which seat owns it.
    if (kind == 'b' and pending ~= nil) then
        local name = parts[2] or '';

        if (name ~= '') then
            local row = {
                name    = name,
                value   = wireInt(parts[3]),
                prev    = wireInt(parts[4]),
                readyAt = wireInt(parts[5]),
                seat    = wireInt(parts[6]),
            };

            pending.knobs[name] = row;
            pending.knobList[#pending.knobList + 1] = row;
        end

        return;
    end

    -- ADDITIVE: the proclamation menu. The buttons below are built from this
    -- record and nothing else, so a seventh proclamation on the server grows
    -- a seventh button here without a new addon.
    if (kind == 'l' and pending ~= nil) then
        local word = parts[2] or '';

        if (word ~= '') then
            pending.procs[#pending.procs + 1] = { word = word, template = parts[3] or '' };
        end

        return;
    end

    -- ADDITIVE: one Knight of the Realm.
    if (kind == 'j' and pending ~= nil) then
        pending.knights[#pending.knights + 1] = {
            name  = parts[2] or '?',
            since = wireInt(parts[3]),
            mine  = wireInt(parts[4]) ~= 0,
        };

        return;
    end

    --[[
    * ADDITIVE (server 2026-09-15b): one seat's levy totals. Seat ordinal 0
    * is NOT a seat -- it is the realm, and its burn figures are the ones the
    * whole ledger exists for. A seat that has never levied sends no row, so
    * absence is zero and is drawn as "nothing yet" rather than as a gap.
    --]]
    if (kind == 'x' and pending ~= nil) then
        local idx = wireInt(parts[2], -1);

        if (idx >= 0 and idx <= #SEAT_KEYS) then
            pending.levy[idx] = {
                seat         = idx,
                seasonTake   = wireInt(parts[3]),
                seasonBurn   = wireInt(parts[4]),
                seasonCount  = wireInt(parts[5]),
                lifetimeTake = wireInt(parts[6]),
                lifetimeBurn = wireInt(parts[7]),
            };

            pending.levyAny = true;
        end

        return;
    end

    -- ADDITIVE: one levy payment (the `revenue` answer).
    if (kind == 'u' and state.revPending ~= nil) then
        local rows = state.revPending.rows;

        rows[#rows + 1] = {
            at      = wireInt(parts[2]),
            payer   = parts[3] or '?',
            seat    = wireInt(parts[4]),
            source  = parts[5] or '',
            charged = wireInt(parts[6]),
            take    = wireInt(parts[7]),
            burned  = wireInt(parts[8]),
        };

        return;
    end

    -- ADDITIVE: one rate change (the `revenue` answer), newest first.
    if (kind == 'i' and state.revPending ~= nil) then
        local acts = state.revPending.acts;

        acts[#acts + 1] = {
            at    = wireInt(parts[2]),
            seat  = wireInt(parts[3]),
            who   = parts[4] or '?',
            kind  = parts[5] or '',
            value = wireInt(parts[6]),
            prev  = wireInt(parts[7]),
        };

        return;
    end

    -- ADDITIVE: one seat's fee, minimum account age and term length.
    if (kind == 'r' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx >= 1 and idx <= #SEAT_KEYS) then
            pending.seatRules[idx] = { fee = wireInt(parts[3]), minAge = wireInt(parts[4]), term = wireInt(parts[5]) };
        end

        return;
    end

    -- ADDITIVE: when this character may pledge again (0 = now).
    if (kind == 'q' and pending ~= nil) then
        pending.pledgeAt = wireInt(parts[2]);

        return;
    end

    if (kind == 'o' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx >= 1 and idx <= #SEAT_KEYS) then
            pending.seats[idx] = {
                name    = parts[3] or 'Regent',
                mandate = parts[4] or 'regent',
                from    = wireInt(parts[5]),
                to      = wireInt(parts[6]),
                mine    = wireInt(parts[7]) ~= 0,

                -- ADDITIVE (server 2026-09-15), field 7: when THIS SEAT may
                -- proclaim again. It is a fact about the office and not about
                -- the holder, and it is here so the window never has to time
                -- a proclamation with a clock of its own.
                proclaimAt = wireInt(parts[8]),
            };
        end

        return;
    end

    if (kind == 'c' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx >= 1 and idx <= #SEAT_KEYS) then
            local r = race(pending, idx);

            r.candidates[#r.candidates + 1] = {
                name     = parts[3] or '?',
                fee      = wireInt(parts[4]),
                pledge   = wireInt(parts[5]),
                endorsed = wireInt(parts[6]),
                mine     = wireInt(parts[7]) ~= 0,
                platform = parts[8] or '',
            };
        end

        return;
    end

    if (kind == 'y' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx >= 1 and idx <= #SEAT_KEYS) then
            local r = race(pending, idx);

            r.canFile    = wireInt(parts[3]) ~= 0;
            r.fileReason = parts[4] or '';
        end

        return;
    end

    if (kind == 'v' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx >= 1 and idx <= #SEAT_KEYS) then
            local r = race(pending, idx);

            r.canVote    = wireInt(parts[3]) ~= 0;
            r.voted      = wireInt(parts[4]) ~= 0;
            r.bonus      = wireInt(parts[5]);
            r.voteReason = parts[6] or '';
        end

        return;
    end

    if (kind == 't' and pending ~= nil) then
        pending.treasury = { balance = wireInt(parts[2]), income = wireInt(parts[3]), spend = wireInt(parts[4]) };

        return;
    end

    if (kind == 'p' and pending ~= nil) then
        pending.owed = wireInt(parts[2]);

        return;
    end

    if (kind == 'a' and pending ~= nil) then
        pending.acts[#pending.acts + 1] = {
            actid   = wireInt(parts[2]),
            seat    = wireInt(parts[3]),
            kind    = parts[4] or '',
            arg     = wireInt(parts[5]),
            untilAt = wireInt(parts[6]),
            pot     = wireInt(parts[7]),
            spent   = wireInt(parts[8]),
            by      = parts[9] or '',
        };

        return;
    end

    if (kind == 'n' and pending ~= nil) then
        pending.enemy = {
            actid   = wireInt(parts[2]),
            idx     = wireInt(parts[3]),
            name    = parts[4] or '?',
            pot     = wireInt(parts[5]),
            spent   = wireInt(parts[6]),
            untilAt = wireInt(parts[7]),
        };

        return;
    end

    if (kind == 'w' and pending ~= nil) then
        pending.wanted[#pending.wanted + 1] = {
            name    = parts[2] or '?',
            charge  = parts[3] or '',
            untilAt = wireInt(parts[4]),
            fine    = wireInt(parts[5]),
            by      = parts[6] or '',
        };

        return;
    end

    if (kind == 'g' and state.chronPending ~= nil) then
        state.chronPending.page  = math.max(1, wireInt(parts[2], 1));
        state.chronPending.per   = math.max(1, wireInt(parts[3], 12));
        state.chronPending.total = wireInt(parts[4]);

        return;
    end

    if (kind == 'h' and state.chronPending ~= nil) then
        local rows = state.chronPending.rows;

        rows[#rows + 1] = {
            rowid  = wireInt(parts[2]),
            at     = wireInt(parts[3]),
            season = wireInt(parts[4]),
            seat   = wireInt(parts[5]),
            kind   = parts[6] or '',
            actor  = parts[7] or '',
            text   = parts[8] or '',
        };

        return;
    end

    if (kind == 'k') then
        local verb = parts[2] or '';

        state.writeAt[verb] = nil;

        --[[
        * AN OWNER'S ACT ACKS `k|admin|<verb>|...`, A HOLDER'S ACKS
        * `k|<verb>|...`. The Admin tab and the Seats tab are two controls
        * firing two lines at the same power, so the owner's buttons debounce
        * under `admin:<verb>` and are released by the ack that names it --
        * release the holder's button on the owner's answer and the wrong
        * control comes back.
        --]]
        if (verb == 'admin') then
            state.writeAt['admin:' .. (parts[3] or '')] = nil;
        end

        if (verb == 'claim') then
            state.status = string.format('%s gil collected.', tostring(wireInt(parts[3])));
        else
            state.status = 'Done.';
        end

        state.statusBad = false;

        -- A write changed the board: ask for it again.
        askStatus(true);

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        if (closed == 'chronicle') then
            local cp = state.chronPending;

            state.chronPending = nil;

            if (cp ~= nil) then
                state.chronicle = cp;
            end

            return;
        end

        if (closed == 'revenue') then
            local rp = state.revPending;

            state.revPending = nil;

            if (rp ~= nil) then
                state.revenue = rp;
            end

            return;
        end

        if (closed ~= 'status') then
            return;
        end

        local complete = pending ~= nil and pending.season ~= nil and pending.seats[1] ~= nil;

        state.pending = nil;

        if (not complete) then
            state.boardFailed = true;

            return;
        end

        state.season      = pending.season;
        state.seats       = pending.seats;
        state.races       = pending.races;
        state.treasury    = pending.treasury;
        state.owed        = pending.owed;
        state.acts        = pending.acts;
        state.enemy       = pending.enemy;
        state.wanted      = pending.wanted;
        state.rules       = pending.rules;
        state.seatRules   = pending.seatRules;
        state.pledgeAt    = pending.pledgeAt;

        -- 1.2.0. `s|` field 11 is the freeze; `m|` repeats it so an Admin tab
        -- drawn from that record alone still knows which way its toggle
        -- points. Either saying so is enough.
        state.admin       = pending.admin;
        state.adminLevel  = pending.adminLevel;
        state.frozen      = pending.season.frozen or pending.frozen;
        state.knobs       = pending.knobs;
        state.knobList    = pending.knobList;
        state.procs       = pending.procs;
        state.knights     = pending.knights;

        -- 1.3.0. The x| summary is committed with the rest of the board; the
        -- payments and the rate history are their own envelope and are not
        -- touched here.
        state.levy        = pending.levy;
        state.levyAny     = pending.levyAny;

        state.syncedAt    = os.clock();
        state.clockSkew   = pending.season.serverNow - os.time();
        state.boardFailed = false;

        return;
    end
end

ashita.events.register('packet_in', 'dwpolitics_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwpolitics'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    if (e.id == 0x000A) then
        state.requested    = nil;
        state.serverSilent = false;
        state.refused      = false;
        state.boardFailed  = false;
        state.season       = nil;
        state.syncedAt     = nil;
        state.inbound      = nil;
        state.pending      = nil;
        state.chronPending = nil;
        state.revPending   = nil;
        state.revAsked     = nil;
        state.revenue.got  = false;

        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end
    end
end);

local function plainText(raw)
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    text = text:gsub('[^\032-\126]', '');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return text;
end

ashita.events.register('text_in', 'dwpolitics_text_in', function (e)
    if (e.blocked or e.injected) then
        return;
    end

    local raw = e.message_modified or e.message;

    if (raw == nil) then
        return;
    end

    local mode = e.mode_modified or e.mode;
    local low  = mode ~= nil and bit.band(mode, 0xFF) or nil;

    if (low ~= NOTICE_MODE) then
        return;
    end

    local line = (plainText(raw):gsub('^%s+', ''));
    local at   = line:find(NOTICE_TAG, 1, true);

    if (at ~= 1) then
        return;
    end

    local rest = line:sub(at + #NOTICE_TAG):gsub('^%s+', ''):gsub('%s+$', '');

    if (rest == '') then
        return;
    end

    e.blocked = true;

    print(chat.header('dwpolitics'):append(chat.message(rest)));
end);

--[[
* Rendering.
--]]
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local function fmtGil(amount)
    local text = tostring(math.floor(amount or 0));
    local out  = '';

    while (#text > 3) do
        out  = ',' .. text:sub(-3) .. out;
        text = text:sub(1, -4);
    end

    return text .. out;
end

local function serverNow()
    return os.time() + (state.clockSkew or 0);
end

local function fmtLeft(untilAt)
    local seconds = math.max(0, untilAt - serverNow());

    if (seconds >= 86400) then
        return string.format('%dd', math.floor(seconds / 86400));
    elseif (seconds >= 3600) then
        return string.format('%dh', math.floor(seconds / 3600));
    end

    return string.format('%dm', math.max(1, math.floor(seconds / 60)));
end

-- How long ago something happened, one unit, in a table cell. The ledger is
-- read to answer "what has this holder been taking lately", and a relative
-- age answers that in a way a wall-clock stamp in the reader's own timezone
-- does not.
local function fmtAgo(at)
    local seconds = math.max(0, serverNow() - (at or 0));

    if (seconds >= 86400) then
        return string.format('%dd ago', math.floor(seconds / 86400));
    elseif (seconds >= 3600) then
        return string.format('%dh ago', math.floor(seconds / 3600));
    elseif (seconds >= 60) then
        return string.format('%dm ago', math.floor(seconds / 60));
    end

    return 'just now';
end

--[[
* fmtLeft rounds to ONE unit, which is right in a crowded table cell and
* wrong in a sentence a player is reading to plan their week: "6d" hides
* anything from six days to seven. The phase line says two units.
--]]
local function fmtSpan(untilAt)
    local seconds = math.max(0, untilAt - serverNow());
    local days    = math.floor(seconds / 86400);
    local hours   = math.floor((seconds % 86400) / 3600);
    local mins    = math.floor((seconds % 3600) / 60);

    if (days > 0) then
        return string.format('%dd %dh', days, hours);
    elseif (hours > 0) then
        return string.format('%dh %dm', hours, mins);
    end

    return string.format('%dm', math.max(1, mins));
end

--[[
* The pledge cooldown in the server's own words -- hours and minutes, always
* rounded UP to the next whole minute so the number never runs out early.
* This mirrors politics_core.lua's fmtHoursMinutes deliberately: the typed
* refusal and this window quote the same wait to the same player.
--]]
local function fmtWords(seconds)
    local total = math.max(1, math.ceil(math.max(0, seconds) / 60));
    local hours = math.floor(total / 60);
    local mins  = total % 60;

    local function plural(n, word)
        return string.format('%d %s%s', n, word, n == 1 and '' or 's');
    end

    if (hours > 0 and mins > 0) then
        return plural(hours, 'hour') .. ' ' .. plural(mins, 'minute');
    elseif (hours > 0) then
        return plural(hours, 'hour');
    end

    return plural(mins, 'minute');
end

--[[
* A CADENCE IN WORDS (1.2.0). fmtWords stops at hours, which reads as "168
* hours" for a weekly clock; a cadence a player is being told about wants
* days. The number itself is always the server's -- this only chooses the
* unit it is spoken in.
--]]
local function fmtEvery(seconds)
    seconds = math.max(0, math.floor(seconds or 0));

    if (seconds >= 86400) then
        local days = math.floor(seconds / 86400);

        return string.format('%d day%s', days, days == 1 and '' or 's');
    end

    return fmtWords(seconds);
end

-- Seconds left on a wire clock (0 = now, and 0 on the wire means now too).
local function clockLeft(at)
    if (at == nil or at <= 0) then
        return 0;
    end

    return math.max(0, at - serverNow());
end

-- Seconds until this character may pledge again; 0 when they may now.
local function pledgeWait()
    local at = state.pledgeAt or 0;

    if (at <= 0) then
        return 0;
    end

    return math.max(0, at - serverNow());
end

--[[
* THE PHASE, IN PLAIN WORDS, AND WHEN THE NEXT ONE STARTS (1.1.0). The
* sentence itself is politics_core.lua's PHASE_WHAT, copied byte for byte and
* held there by the harness; the countdown is computed off the s| record's
* own times, so it is the server's clock and not the client's.
--]]
local function phaseNext(s)
    if (s.phase == 'preseason') then
        return string.format('The first season opens in %s.', fmtSpan(s.phaseEnds));
    elseif (s.phase == 'nomination' or s.phase == 'campaign') then
        if ((s.pollOpen or 0) > 0) then
            return string.format('Voting opens in %s.', fmtSpan(s.pollOpen));
        end
    elseif (s.phase == 'poll') then
        if ((s.pollClose or 0) > 0) then
            return string.format('Voting closes in %s, and the count follows at once.', fmtSpan(s.pollClose));
        end
    elseif ((s.seasonEnds or 0) > 0) then
        return string.format('Season %d opens for nominations in %s.', s.season + 1, fmtSpan(s.seasonEnds));
    end

    -- A server too old to send the poll times still knows when the phase ends.
    return string.format('This phase ends in %s.', fmtSpan(s.phaseEnds));
end

local function phaseLine(s)
    return string.format('%s %s', PHASE_WHAT[s.phase] or '', phaseNext(s));
end

local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

-- BeginChild's third argument is the CHILD FLAGS integer on this Ashita
-- (2025 q3): the boolean `border` the older signature took is a sol
-- type-mismatch -- "no matching function call takes this number of
-- arguments and the specified types" -- and it fired the moment the
-- Elections tab drew (Sorroto/Grandfather, 2026-09-13), since the render
-- pcall reports it but the child never opens. dwbags and dwquest already
-- pass the flag; this is the same shape, with the global resolved once.
local CHILD_FLAGS_NONE = ImGuiChildFlags_None or 0;

--[[
* COLUMN HEADERS THAT SAY WHAT THEY MEAN (1.1.0, the dwraid idiom). The stock
* imgui.TableHeadersRow() draws the whole row in one call and leaves nothing
* to hover, so the row is drawn by hand -- but only where the client declares
* every call it needs. A player frozen on an older Ashita gets the stock row
* and the table it always had, never a nil call sixty times a second.
--]]
local function guiHas(name)
    local ok, value = pcall(function ()
        return imgui[name];
    end);

    return ok and type(value) == 'function';
end

local CAN_HEADER_TIPS = guiHas('TableHeader') and guiHas('TableNextRow')
    and guiHas('TableNextColumn') and ImGuiTableRowFlags_Headers ~= nil;

local function tableHead(columns)
    for _, column in ipairs(columns) do
        imgui.TableSetupColumn(column.label, ImGuiTableColumnFlags_WidthStretch, column.weight);
    end

    if (not CAN_HEADER_TIPS) then
        imgui.TableHeadersRow();

        return;
    end

    imgui.TableNextRow(ImGuiTableRowFlags_Headers, 0);

    for _, column in ipairs(columns) do
        imgui.TableNextColumn();
        imgui.TableHeader(column.label);

        if (column.tip ~= nil) then
            tip(column.tip);
        end
    end
end

local function footerReserve()
    return -(metric('GetFrameHeightWithSpacing', 26) + 12);
end

local function mySeats()
    local held = {};

    for idx, seat in pairs(state.seats) do
        if (seat.mine) then
            held[SEAT_KEYS[idx]] = idx;
        end
    end

    return held;
end

local function cleanInput(buffer)
    return (tostring(buffer[1] or ''):gsub('[^\032-\126]', ''):gsub('^%s+', ''):gsub('%s+$', ''));
end

--[[
* THE 2026-09-15 POWERS, DRAWN WITH THEIR CHECKS ON (1.2.0).
*
* Every control below is greyed BEFORE the click when the server would
* refuse it, and the sentence it is greyed with is the sentence the server
* would have answered with: the freeze (s| field 11), the seat's
* proclamation clock (o| field 7), the lever's own clock (b|'s readyAt), the
* order's cap (f|'s knightMax), a live holiday (a|). Not one of those
* figures is this addon's -- that is the 1.1.0 rule, and it did not bend for
* a new tab.
*
* THE SAME CONTROLS ARE DRAWN TWICE: once on the Seats tab for the holder
* and once on the Admin tab for the owner. The difference is exactly two
* things -- the owner's copy skips the COOLDOWN (`live`) and sends the
* `admin` prefix -- so they are one function called twice rather than two
* that can drift apart.
--]]

-- The server's own FROZEN_EXEMPT list (politics_core.lua): the verbs that
-- take something back, plus the knob write that lets a runaway rate be put
-- back before the thaw. A freeze greys everything else on BOTH tabs, because
-- the server refuses it on both.
local FROZEN_EXEMPT =
{
    veto = true, strike = true, vacate = true, unknight = true, knob = true, freeze = true, ['end'] = true,
};

-- The owner's copy of a power debounces under `admin:<verb>` (that is the
-- ack it gets back), so the freeze test looks past the prefix: `admin knob`
-- is exempt for the same reason a bare `knob` write is.
local function frozenOut(verb)
    if (not state.frozen) then
        return false;
    end

    return not FROZEN_EXEMPT[(tostring(verb):gsub('^admin:', ''))];
end

--[[
* A POWER BUTTON WITH THE FREEZE ALREADY ON IT. Greyed with the server's own
* sentence rather than offered and refused in chat a second later --
* everything this window knows before the click, it says before the click.
* `command` is the line, or a function that builds it from the inputs beside
* the button and answers nil when they are empty.
--]]
local function powerButton(label, id, verb, command, feedback, tipText, blocked)
    if (frozenOut(verb)) then
        imgui.TextDisabled(label);
        tip(TIPS.frozen);

        return;
    end

    -- Anything else the wire already says would be refused -- today that is
    -- an empty Treasury, which is the only spend gate `t|` can settle.
    if (blocked ~= nil) then
        imgui.TextDisabled(label);
        tip(blocked);

        return;
    end

    if (imgui.SmallButton(string.format('%s##%s', label, id))) then
        local line = type(command) == 'function' and command() or command;

        if (type(line) == 'string' and line ~= '') then
            write(verb, line, feedback);
        end
    end

    tip(tipText);
end

-- The one spend gate `t|` can settle on its own: a Treasury with nothing in
-- it pays for no bounty, no stimulus and no bonus, whoever asks.
local function treasuryBlock()
    local t = state.treasury;

    if (t == nil or t.balance > 0) then
        return nil;
    end

    return string.format('The Treasury holds %s gil, so it can pay for nothing.', fmtGil(t.balance));
end

local function liveActOf(kind, seatIdx)
    for _, act in ipairs(state.acts) do
        if (act.kind == kind and (seatIdx == nil or act.seat == seatIdx)) then
            return act;
        end
    end

    return nil;
end

--[[
* A LEVER'S BAND, OR NOTHING. f| carries the outpost and tolls band ends and
* has never carried the mercenary cut's or the travel fee's -- so those two
* get an input rather than a slider, and the server's own refusal names
* their band. A slider whose ends this window invented would be exactly the
* remembered constant the 1.1.0 rule exists to forbid.
--]]
local function knobBand(name)
    local r = state.rules;

    if (r == nil) then
        return nil, nil;
    end

    if (name == 'tolls') then
        return r.tollsMin, r.tollsMax;
    end

    if (name:sub(1, 3) == 'op_') then
        return r.outpostMin, r.outpostMax;
    end

    -- 1.3.0: the travel lever's band rides f| now (fields 27..28), so the
    -- Treasurer gets a slider with the server's ends on it instead of a bare
    -- input. A server too old to send them still sends the input -- the ends
    -- are read, never assumed, and `portMin` is 0 against such a server.
    if (name == 'port' and (r.portMin or 0) > 0 and (r.portMax or 0) > 0) then
        return r.portMin, r.portMax;
    end

    return nil, nil;
end

-- One slider buffer per lever, seeded from b| and re-seeded whenever the
-- server's value moves.
local function knobBuffer(knob)
    local cell = state.knobBuf[knob.name];

    if (cell == nil) then
        cell = { buf = T{ knob.value }, wire = knob.value };
        state.knobBuf[knob.name] = cell;
    elseif (cell.wire ~= knob.value) then
        cell.buf[1] = knob.value;
        cell.wire   = knob.value;
    end

    return cell.buf;
end

-- opts: id, verb, label, tip, live, command(value) -> the line to send.
local function rateLever(knob, opts)
    if (knob == nil) then
        imgui.TextDisabled(string.format('%s -- this server did not send the lever.', opts.label));
        tip(TIPS.wireless);

        return;
    end

    local r      = state.rules;
    local lo, hi = knobBand(knob.name);
    local buf    = knobBuffer(knob);

    imgui.Text(string.format('%s %d (was %d)', opts.label, knob.value, knob.prev));
    tip(string.format('%s %s', opts.tip, TIPS.knobLine));
    imgui.SameLine();
    imgui.PushItemWidth(150);

    if (lo ~= nil and hi ~= nil and hi > lo) then
        imgui.SliderInt(string.format('##dwb_lever_%s', opts.id), buf, lo, hi);
    else
        imgui.InputInt(string.format('##dwb_lever_%s', opts.id), buf);
    end

    imgui.PopItemWidth();
    tip(lo ~= nil and hi ~= nil
        and string.format('%s Between %d and %d percent.', opts.tip, lo, hi)
        or string.format('%s The server names the band if this is outside it.', opts.tip));
    imgui.SameLine();

    local wait = opts.live and 0 or clockLeft(knob.readyAt);

    if (frozenOut(opts.verb)) then
        imgui.TextDisabled(FROZEN_LINE);
        tip(TIPS.frozen);
    elseif (wait > 0) then
        imgui.TextDisabled(string.format('may move in %s', fmtWords(wait)));
        tip(r ~= nil and r.knobCooldown > 0
            and string.format('A rate moves once every %s, whoever turns it. This one may move again in %s.', fmtEvery(r.knobCooldown), fmtWords(wait))
            or string.format('This lever may move again in %s.', fmtWords(wait)));
    else
        if (imgui.SmallButton(string.format('Set %s##dwb_set_%s', opts.label, opts.id))) then
            local value = math.floor(tonumber(buf[1]) or 0);

            -- CLAMP TO THE ENDS f| SENT, and to nothing else. A slider is
            -- already bounded by them, but ctrl+click types a number into
            -- one, and the widened 20..2000 band makes an unbounded typed
            -- figure worth real gil. The clamp holds the server's ends, not
            -- ends of this window's own -- when f| sent none there is no
            -- clamp and the server's refusal is the only bound, as before.
            if (lo ~= nil and hi ~= nil and hi > lo) then
                value = math.max(lo, math.min(hi, value));
            end

            if (value > 0) then
                write(opts.verb, opts.command(value), 'Setting...');
            end
        end

        tip(opts.tip);
    end
end

-- A row of buttons, one per l| word. `prefix` keeps the Seats tab's and the
-- Admin tab's widget ids apart.
local function proclaimButtons(seatIdx, live, prefix, verb, command)
    local r = state.rules;

    imgui.Text('Proclaim');
    tip(TIPS.proclaim);

    if (#state.procs == 0) then
        imgui.SameLine();
        imgui.TextDisabled('this server sent no menu');
        tip(TIPS.wireless);

        return;
    end

    if (frozenOut('proclaim')) then
        imgui.SameLine();
        imgui.TextDisabled(FROZEN_LINE);
        tip(TIPS.frozen);

        return;
    end

    local seat = state.seats[seatIdx];
    local wait = live and 0 or clockLeft(seat ~= nil and seat.proclaimAt or 0);

    if (wait > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('again in %s', fmtWords(wait)));
        tip(r ~= nil and r.proclaimCooldown > 0
            and string.format('One proclamation per SEAT every %s. The %s may speak again in %s.',
                fmtEvery(r.proclaimCooldown), SEAT_NAMES[seatIdx] or 'seat', fmtWords(wait))
            or TIPS.proclaimWait);

        return;
    end

    for _, entry in ipairs(state.procs) do
        imgui.SameLine();

        if (imgui.SmallButton(string.format('%s##dwb_%sproclaim_%d_%s', entry.word, prefix, seatIdx, entry.word))) then
            write(verb, command(entry.word), 'Proclaiming...');
        end

        tip(entry.template ~= ''
            and string.format('It will say: %s   The server fills in the seat, your name and the place -- nothing you type reaches the world.', entry.template)
            or TIPS.proclaim);
    end
end

-- The Crown's honours: the cap is f|'s, the roll is j|'s.
local function knightControl(live, prefix, verb, command)
    local r      = state.rules;
    local cap    = r ~= nil and r.knightMax or 0;
    local wearing = #state.knights;

    imgui.PushItemWidth(140);
    imgui.InputTextWithHint(string.format('##dwb_%sknight', prefix), 'character name', state.inKnight, INPUT_MAX + 1);
    imgui.PopItemWidth();
    tip(TIPS.inputKnight);
    imgui.SameLine();

    if (frozenOut('knight') and not live) then
        imgui.TextDisabled(FROZEN_LINE);
        tip(TIPS.frozen);

        return;
    end

    if (cap > 0 and wearing >= cap) then
        imgui.TextDisabled(string.format('the order is %d strong', cap));
        tip(string.format('The order of the realm holds %d at once. Unknight somebody first.', cap));

        return;
    end

    if (imgui.SmallButton(string.format('Knight##dwb_%sknight_btn', prefix))) then
        local name = cleanInput(state.inKnight);

        if (name ~= '') then
            write(verb, command(name), 'Knighting...');
        end
    end

    tip(r ~= nil and cap > 0
        and string.format('%s At most %d at a time, and one every %s.', TIPS.knight, cap, fmtEvery(r.knightCooldown))
        or TIPS.knight);
end

local function renderHeader()
    if (imgui.Button('Refresh##dwb_refresh')) then
        askStatus(true);
    end

    tip(state.refused and TIPS.refreshStale or TIPS.refresh);

    imgui.SameLine();

    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwpolitics through the launcher.');
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server. Refresh to ask again.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or state.requested ~= nil) then
        imgui.TextDisabled('asking...');
    else
        imgui.TextDisabled('Every seat is a vote away.');
    end

    local s = state.season;

    if (s ~= nil) then
        if (s.season == 0) then
            -- The countdown belongs to the phase line below; saying it twice
            -- is exactly the noise 1.1.0 is here to remove.
            imgui.Text('The politics of Vana\'diel have not begun.');
        else
            imgui.Text(string.format('Season %d, day %d -- %s, %s left%s', s.season, s.day + 1, s.phase, fmtLeft(s.phaseEnds),
                s.crown and '. The Crown races this season.' or '.'));
        end

        tip(TIPS.season);

        if (state.owed > 0) then
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Claim %s gil##dwb_claim', fmtGil(state.owed)))) then
                write('claim', '!dwb claim', 'Claiming...');
            end

            tip(TIPS.claim);
        end

        -- WHAT THIS PHASE IS AND WHAT YOU MAY DO IN IT (1.1.0).
        imgui.TextWrapped(phaseLine(s));
        tip(TIPS.phase);
    elseif (state.boardFailed) then
        imgui.TextDisabled('The server answered without a board. Refresh to ask again.');
    else
        imgui.TextDisabled('Waiting for the board...');
    end

    --[[
    * THE FREEZE, IN RED, ABOVE THE TAB BAR (1.2.0) -- so it is on every tab
    * at once rather than six copies of one sentence that could get five of
    * them. It says the same words the server refuses every frozen power
    * with, and every control the freeze disarms repeats it on hover.
    --]]
    if (state.frozen) then
        imgui.TextColored(theme.colors.err, FROZEN_LINE);
        tip(TIPS.frozen);
    end

    imgui.Separator();
end

local function renderSeats()
    if (imgui.BeginTable('dwb_seats', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
        tableHead({
            { label = 'Seat',    weight = 1.2, tip = TIPS.colSeat },
            { label = 'Holder',  weight = 1.0, tip = TIPS.colHolder },
            { label = 'Mandate', weight = 0.7, tip = TIPS.colMandate },
            { label = 'Term',    weight = 0.7, tip = TIPS.colTerm },
        });

        for idx = 1, #SEAT_KEYS do
            local seat = state.seats[idx];

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(SEAT_NAMES[idx]);
            tip(string.format('%s: %s.', SEAT_NAMES[idx], SEAT_DOES[idx]));
            imgui.TableNextColumn();

            if (seat == nil) then
                imgui.TextDisabled('?');
            elseif (seat.mine) then
                imgui.TextColored(theme.colors.ok, seat.name .. ' (you)');
            else
                imgui.Text(seat.name);
            end

            imgui.TableNextColumn();
            imgui.Text(seat and seat.mandate or '');
            imgui.TableNextColumn();
            imgui.Text(seat and seat.from > 0 and string.format('S%d-S%d', seat.from, seat.to) or '');
        end

        imgui.EndTable();
    end

    --[[
    * THE ORDER OF THE REALM (1.2.0), straight off `j|`. It is on the Seats
    * tab and not the Treasury's because it is an office's gift and lapses
    * with the office: an empty list the day after a count is the expected
    * thing, not a loss, and the tip says so.
    --]]
    imgui.Separator();
    imgui.Text(string.format('Knights of the Realm -- %d', #state.knights));
    tip(TIPS.knightsBlock);

    local held = mySeats();

    if (#state.knights == 0) then
        imgui.TextDisabled('  Nobody holds the honour.');
        tip(TIPS.knightsNone);
    end

    for _, knight in ipairs(state.knights) do
        imgui.Text(string.format('  %s%s', knight.name, knight.mine and ' (you)' or ''));
        tip(TIPS.knightsBlock);

        -- Unknight is on the server's frozen-exempt list: taking an honour
        -- back is never what a freeze or a clock should be holding up.
        if (held.crown ~= nil) then
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Unknight##dwb_unknight_%s', knight.name))) then
                write('unknight', '!dwb unknight ' .. knight.name, 'Revoking...');
            end

            tip(TIPS.unknight);
        end
    end

    imgui.Separator();

    if (next(held) == nil) then
        imgui.TextDisabled('Hold a seat and its powers appear here.');
        tip(TIPS.noSeat);

        return;
    end

    if (held.crown ~= nil) then
        imgui.Text('The Crown');
        tip(TIPS.seatPowers);

        for _, word in ipairs(DECREE_WORDS) do
            imgui.SameLine();
            powerButton(string.format('Decree %s', word), string.format('dwb_decree_%s', word), 'decree',
                '!dwb decree ' .. word, 'Decreeing...', TIPS.decree);
        end

        imgui.PushItemWidth(140);
        imgui.InputTextWithHint('##dwb_name', 'character name', state.inName, INPUT_MAX + 1);
        imgui.PopItemWidth();
        tip(TIPS.inputName);
        imgui.SameLine();
        powerButton('Indict', 'dwb_indict', 'indict', function()
            local name = cleanInput(state.inName);

            return name ~= '' and ('!dwb indict ' .. name) or nil;
        end, 'Indicting...', TIPS.indict);
        imgui.SameLine();
        powerButton('Pardon', 'dwb_pardon', 'pardon', function()
            local name = cleanInput(state.inName);

            return name ~= '' and ('!dwb pardon ' .. name) or nil;
        end, 'Pardoning...', TIPS.pardon);

        imgui.PushItemWidth(140);
        imgui.InputTextWithHint('##dwb_enemy', 'nemesis name', state.inEnemy, INPUT_MAX + 1);
        imgui.PopItemWidth();
        tip(TIPS.inputEnemy);
        imgui.SameLine();
        imgui.PushItemWidth(90);
        imgui.InputTextWithHint('##dwb_pot', 'pot gil', state.inPot, 12);
        imgui.PopItemWidth();
        tip(TIPS.inputPot);
        imgui.SameLine();
        powerButton('Public Enemy', 'dwb_enemy_btn', 'enemy', function()
            local name = cleanInput(state.inEnemy);
            local pot  = wireInt(cleanInput(state.inPot));

            return (name ~= '' and pot > 0) and string.format('!dwb enemy %s %d', name, pot) or nil;
        end, 'Naming a Public Enemy...', TIPS.enemy, treasuryBlock());

        -- The honours and the two blunt instruments (1.2.0).
        knightControl(false, '', 'knight', function(name)
            return '!dwb knight ' .. name;
        end);

        imgui.SameLine();

        --[[
        * A holiday is greyed while one is LIVE, off the a| list -- the
        * server refuses a second one and the window should not have to
        * discover that by being told. Its length and its cadence come off
        * f|, and are left out of the sentence on a server that sent neither.
        --]]
        local onHoliday = liveActOf('holiday') ~= nil;
        local r         = state.rules;

        if (onHoliday) then
            imgui.TextDisabled('holiday running');
            tip(TIPS.holidayLive);
        else
            powerButton('Holiday', 'dwb_holiday', 'holiday', '!dwb holiday', 'Declaring a holiday...',
                r ~= nil and r.holidaySeconds > 0
                    and string.format('%s It runs %s, once every %s.', TIPS.holiday, fmtEvery(r.holidaySeconds), fmtEvery(r.holidayCooldown))
                    or TIPS.holiday);
        end

        imgui.SameLine();
        powerButton('Amnesty', 'dwb_amnesty', 'amnesty', '!dwb amnesty', 'Declaring an amnesty...', TIPS.amnesty);

        proclaimButtons(held.crown, false, '', 'proclaim', function(word)
            return '!dwb proclaim ' .. word;
        end);
    end

    for _, key in ipairs(MAYOR_KEYS) do
        local idx = held[key];

        if (idx ~= nil) then
            imgui.Text(SEAT_NAMES[idx]);
            tip(TIPS.seatPowers);

            for _, word in ipairs(FESTIVAL_WORDS) do
                imgui.SameLine();
                powerButton(string.format('Festival %s', word), string.format('dwb_festival_%s', word), 'festival',
                    '!dwb festival ' .. word, 'Declaring a festival...', TIPS.festival);
            end

            imgui.SameLine();
            powerButton('Town hall', 'dwb_townhall', 'townhall', '!dwb townhall', 'Calling a town hall...', TIPS.townhall);
            imgui.SameLine();
            powerButton('Home', 'dwb_home', 'home', '!dwb home', 'Going home...', TIPS.home);

            --[[
            * THE LEVER A MAYOR HOLDS DEPENDS ON THE CITY (E5/E6). The three
            * starting towns command conquest regions and so price outposts;
            * Jeuno commands none and prices the warps into itself instead.
            * Which one this seat gets is asked of the seat table, and which
            * knob row it is comes off b|.
            --]]
            if (IS_TOWN[key]) then
                rateLever(state.knobs['op_' .. key], {
                    id = 'outpost', verb = 'outpost', label = 'Outpost fare', tip = TIPS.outpost,
                    command = function(value)
                        return string.format('!dwb outpost %d', value);
                    end,
                });
            else
                rateLever(state.knobs.tolls, {
                    id = 'tolls', verb = 'tolls', label = 'Tolls into Jeuno', tip = TIPS.tolls,
                    command = function(value)
                        return string.format('!dwb tolls %d', value);
                    end,
                });
            end

            proclaimButtons(idx, false, '', 'proclaim', function(word)
                return '!dwb proclaim ' .. word;
            end);
        end
    end

    if (held.treasurer ~= nil) then
        imgui.Text('The Treasury');
        tip(TIPS.seatPowers);

        -- merc and port are rate levers like the rest since 2026-09-15: same
        -- cadence, same b| row, same clock drawn from it. Since 2026-09-15b
        -- the travel lever's band rides f| too, so `port` draws a slider
        -- between the server's ends; the mercenary cut's band has still
        -- never ridden this wire, so it keeps the bare input and the
        -- server's own refusal rather than a slider with invented ends.
        rateLever(state.knobs.merc, {
            id = 'merc', verb = 'merc', label = 'Mercenary cut', tip = TIPS.merc,
            command = function(value)
                return string.format('!dwb merc %d', value);
            end,
        });

        rateLever(state.knobs.port, {
            id = 'port', verb = 'port', label = 'Travel fees', tip = TIPS.port,
            command = function(value)
                return string.format('!dwb port %d', value);
            end,
        });

        imgui.PushItemWidth(70);
        imgui.InputTextWithHint('##dwb_number', 'number', state.inNumber, 12);
        imgui.PopItemWidth();
        tip(TIPS.inputNumber);

        for _, verb in ipairs({ 'stimulus', 'drift' }) do
            imgui.SameLine();
            powerButton(verb, 'dwb_' .. verb, verb, function()
                local value = wireInt(cleanInput(state.inNumber));

                return value > 0 and string.format('!dwb %s %d', verb, value) or nil;
            end, 'Setting...', TIPS[verb], treasuryBlock());
        end

        proclaimButtons(held.treasurer, false, '', 'proclaim', function(word)
            return '!dwb proclaim ' .. word;
        end);
    end

    imgui.PushItemWidth(70);
    imgui.InputTextWithHint('##dwb_act', 'act #', state.inAct, 12);
    imgui.PopItemWidth();
    tip(TIPS.inputAct);
    imgui.SameLine();

    if (imgui.SmallButton('Veto##dwb_veto')) then
        local actid = wireInt(cleanInput(state.inAct));

        if (actid > 0) then
            write('veto', string.format('!dwb veto %d', actid), 'Vetoing...');
        end
    end

    tip(TIPS.veto);
    imgui.SameLine();

    if (imgui.SmallButton('Resign##dwb_resign')) then
        write('resign', '!dwb resign', 'Resigning...');
    end

    tip(TIPS.resign);
end

local function renderElection()
    local s = state.season;

    if (s == nil or s.season == 0) then
        imgui.TextDisabled('No season is running.');

        return;
    end

    local mine = nil;

    for idx = 1, #SEAT_KEYS do
        local r = state.races[idx];

        if (r ~= nil) then
            for _, c in ipairs(r.candidates) do
                if (c.mine) then
                    mine = idx;
                end
            end
        end
    end

    if (mine ~= nil) then
        imgui.Text(string.format('You are running for the %s.', SEAT_NAMES[mine]));
        imgui.SameLine();

        if (imgui.SmallButton('Withdraw##dwb_withdraw')) then
            write('withdraw', '!dwb withdraw', 'Withdrawing...');
        end

        tip(TIPS.withdraw);

        local r = state.rules;

        imgui.PushItemWidth(300);
        imgui.InputTextWithHint('##dwb_platform',
            r ~= nil and string.format('your platform, up to %d characters', r.platformMax) or 'your platform',
            state.inText, INPUT_MAX + 1);
        imgui.PopItemWidth();
        tip(TIPS.inputPlat);
        imgui.SameLine();

        if (imgui.SmallButton('Set platform##dwb_platform_btn')) then
            local text = cleanInput(state.inText);

            if (text ~= '') then
                write('platform', '!dwb platform ' .. text, 'Setting the platform...');
            end
        end

        tip(TIPS.platform);

        imgui.PushItemWidth(100);
        imgui.InputTextWithHint('##dwb_pledge', 'pledge gil', state.inPot, 12);
        imgui.PopItemWidth();
        tip(TIPS.inputPot);
        imgui.SameLine();

        --[[
        * THE PLEDGE BRAKE, SHOWN RATHER THAN DISCOVERED (1.1.0). Every
        * pledge is announced to the whole world, so the server allows one
        * every few hours and refuses the rest in words. The button is not
        * offered while the clock is running: the wait is drawn where the
        * button was, and both the wait and the length of the cooldown are
        * the server's numbers (q| and f|), never this addon's.
        --]]
        local wait = pledgeWait();

        if (wait > 0) then
            imgui.TextDisabled(string.format('next pledge in %s', fmtWords(wait)));
            tip(r ~= nil
                and string.format('A pledge may be raised once every %s, because every pledge is announced world-wide. You may pledge again in %s.',
                    fmtWords(r.pledgeCooldown), fmtWords(wait))
                or string.format('You may pledge again in %s.', fmtWords(wait)));
        else
            if (imgui.SmallButton('Pledge##dwb_pledge_btn')) then
                local gil = wireInt(cleanInput(state.inPot));

                if (gil > 0) then
                    write('pledge', string.format('!dwb pledge %d', gil), 'Pledging...');
                end
            end

            tip(r ~= nil
                and string.format('Gil held by the server and added to your pledge: split among everyone who votes in your race if you win, %d percent back if you lose. At least %s gil, at most %s, and one pledge or raise every %s.',
                    100 - r.pledgeCut, fmtGil(r.pledgeMin), fmtGil(r.pledgeMax), fmtWords(r.pledgeCooldown))
                or TIPS.pledge);
        end

        imgui.Separator();
    end

    if (imgui.BeginChild('dwb_races', { 0, footerReserve() }, CHILD_FLAGS_NONE)) then
        for idx = 1, #SEAT_KEYS do
            local r = state.races[idx];

            if (r ~= nil) then
                local seatRule = state.seatRules[idx];

                imgui.Text(SEAT_NAMES[idx]);
                tip(seatRule ~= nil
                    and string.format('%s: %s. Filing fee %s gil, account %d days old, a %d-season term.',
                        SEAT_NAMES[idx], SEAT_DOES[idx], fmtGil(seatRule.fee), seatRule.minAge, seatRule.term)
                    or string.format('%s: %s.', SEAT_NAMES[idx], SEAT_DOES[idx]));

                --[[
                * WHY, NEVER JUST "NO" (1.1.0). "cannot file" alone was the
                * whole message, so the three reasons a client already knows
                * (you filed, filing is shut, the season has no such race)
                * are spelled here, and the one only the server knows rides
                * the y| record and is drawn beside the refusal rather than
                * hidden behind a hover.
                --]]
                if (s.phase ~= 'nomination') then
                    imgui.SameLine();
                    imgui.TextDisabled('filing closed');
                    tip(TIPS.fileClosed);
                elseif (mine ~= nil) then
                    imgui.SameLine();
                    imgui.TextDisabled(mine == idx and 'you are the candidate' or 'already filed elsewhere');
                    tip(TIPS.filed);
                elseif (r.canFile) then
                    imgui.SameLine();

                    if (imgui.SmallButton(string.format('File##dwb_file_%d', idx))) then
                        write('file', '!dwb file ' .. SEAT_KEYS[idx], 'Filing...');
                    end

                    tip(seatRule ~= nil
                        and string.format('File for this seat. The %s gil fee is held until the count and refunded if you win.', fmtGil(seatRule.fee))
                        or TIPS.file);
                else
                    imgui.SameLine();
                    imgui.TextDisabled(r.fileReason ~= '' and ('cannot file -- ' .. r.fileReason) or 'cannot file');
                    tip(r.fileReason ~= '' and r.fileReason or TIPS.fileNo);
                end

                if (s.phase == 'poll') then
                    imgui.SameLine();

                    if (r.voted) then
                        imgui.TextColored(theme.colors.ok, 'voted');
                        tip(TIPS.voted);
                    elseif (r.canVote) then
                        imgui.TextDisabled(string.format('you may vote (+%d.%02d)', math.floor(r.bonus / 100), r.bonus % 100));
                        tip(TIPS.vote);
                    else
                        imgui.TextDisabled(r.voteReason ~= '' and ('cannot vote -- ' .. r.voteReason) or 'cannot vote');
                        tip(r.voteReason ~= '' and r.voteReason or TIPS.voteNo);
                    end
                end

                if (#r.candidates == 0) then
                    imgui.TextDisabled('  Nobody has filed.');
                    tip(TIPS.nobodyFiled);
                end

                for _, c in ipairs(r.candidates) do
                    imgui.Text(string.format('  %s%s -- pledge %s, %d endorsement%s', c.name, c.mine and ' (you)' or '',
                        fmtGil(c.pledge), c.endorsed, c.endorsed == 1 and '' or 's'));
                    tip(c.platform ~= '' and ('"' .. c.platform .. '" -- ' .. TIPS.candidate) or TIPS.candidate);

                    if (s.phase == 'poll' and r.canVote and not c.mine) then
                        imgui.SameLine();

                        if (imgui.SmallButton(string.format('Vote##dwb_vote_%d_%s', idx, c.name))) then
                            write('vote', string.format('!dwb vote %s %s', SEAT_KEYS[idx], c.name), 'Casting your ballot...');
                        end

                        tip(TIPS.vote);
                    end
                end

                imgui.Separator();
            end
        end
    end

    imgui.EndChild();
end

local function renderTreasury()
    local t = state.treasury;

    if (t == nil) then
        imgui.TextDisabled('Waiting for the board...');

        return;
    end

    imgui.Text(string.format('Treasury: %s gil (this season +%s / -%s)', fmtGil(t.balance), fmtGil(t.income), fmtGil(t.spend)));
    tip(TIPS.treasuryLine);

    imgui.TextWrapped('The Treasury takes losing filing fees, the cut of refunded pledges and indictment fines; the Treasurer spends it on a login stimulus, a Drift Coin bonus and the Crown\'s Public Enemy bounties.');
    tip(TIPS.treasuryLine);

    -- THE LEVY IS NOT THE TREASURY, and a reader who confuses the two has
    -- the public purse credited with gil that went into somebody's pocket.
    -- One line, and it points at the tab that has the whole record.
    imgui.TextWrapped('The gil office holders take from travel fares and the mercenary cut is NOT the Treasury -- it is theirs personally, and the Revenue tab has every gil of it.');
    tip(TIPS.tabRevenue);

    if (state.enemy ~= nil) then
        imgui.TextColored(theme.colors.warn, string.format('Public Enemy: %s -- %s gil pot, %s paid, %s left',
            state.enemy.name, fmtGil(state.enemy.pot), fmtGil(state.enemy.spent), fmtLeft(state.enemy.untilAt)));
        tip(TIPS.enemyLine);
    end

    imgui.Separator();

    if (#state.acts == 0) then
        imgui.TextDisabled('Nothing is in effect.');
        tip('Decrees, festivals, town halls, stimulus and bonus acts appear here while they are running.');

        return;
    end

    if (imgui.BeginTable('dwb_acts', 5, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp), { 0, footerReserve() })) then
        imgui.TableSetupScrollFreeze(0, 1);
        tableHead({
            { label = 'Act',  weight = 0.4, tip = TIPS.colAct },
            { label = 'Seat', weight = 0.8, tip = TIPS.colActSeat },
            { label = 'What', weight = 1.2, tip = TIPS.colActWhat },
            { label = 'By',   weight = 0.8, tip = TIPS.colActBy },
            { label = 'Ends', weight = 0.5, tip = TIPS.colActEnds },
        });

        for _, a in ipairs(state.acts) do
            local what = a.kind;

            if (a.kind == 'decree') then
                what = 'decree ' .. (DECREE_WORDS[a.arg] or tostring(a.arg));
            elseif (a.kind == 'festival') then
                what = 'festival ' .. (FESTIVAL_WORDS[a.arg] or tostring(a.arg));
            elseif (a.kind == 'stimulus') then
                what = string.format('stimulus %s gil each (%s of %s)', fmtGil(a.arg), fmtGil(a.spent), fmtGil(a.pot));
            elseif (a.kind == 'drift') then
                what = string.format('drift +%d percent', a.arg);
            elseif (a.kind == 'enemy') then
                what = string.format('public enemy, %s of %s paid', fmtGil(a.spent), fmtGil(a.pot));
            elseif (a.kind == 'proclaim') then
                -- `arg` is the l| row's position, so the word comes off the
                -- menu the server sent rather than a second copy of it.
                local entry = state.procs[a.arg];

                what = string.format('proclamation: %s', entry ~= nil and entry.word or tostring(a.arg));
            elseif (a.kind == 'holiday') then
                what = 'mercenary holiday';
            elseif (a.kind == 'amnesty') then
                what = string.format('amnesty, %d pardoned', a.arg);
            elseif (a.kind == 'knight') then
                what = 'a knighthood';
            elseif (a.kind == 'tolls' or a.kind == 'outpost') then
                what = string.format('%s set to %d percent', a.kind, a.arg);
            end

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(tostring(a.actid));
            tip(TIPS.act);
            imgui.TableNextColumn();
            imgui.Text(SEAT_SHORT[a.seat] or '?');
            imgui.TableNextColumn();
            imgui.Text(what);
            imgui.TableNextColumn();
            imgui.Text(a.by);
            imgui.TableNextColumn();
            imgui.Text(fmtLeft(a.untilAt));
        end

        imgui.EndTable();
    end
end

--[[
* THE LEVY, IN PUBLIC (1.3.0, owner decision L3).
*
* A holder can now price a warp at twenty times the stock fare and keep half
* of everything above it. That is only bearable if anybody can read what was
* taken, so this tab is the whole record: the per-seat totals and the
* realm's burn off `x|`, the last payments off `u|`, the rate changes that
* priced them off `i|`.
*
* NOT ONE GIL FIGURE BELOW IS COMPUTED HERE. Take, burn, count and charge
* all arrive as fields; the halving rule is stated once, in words, at the
* top, and is never multiplied by anything. A window that recomputed the
* split would be a second copy of the arithmetic, and the day the server's
* moved this one would be quietly lying about where somebody's gil went.
--]]
local function renderRevenue()
    local rev = state.revenue;

    -- The Chronicle's lazy-ask shape: nothing is asked until the tab is
    -- actually opened, and it is asked exactly once per answer.
    if (state.season ~= nil and state.revAsked == nil and not rev.got) then
        askRevenue(rev.page);
    end

    imgui.TextWrapped(TIPS.revenueRule);
    tip(TIPS.tabRevenue);
    imgui.Separator();

    if (not state.levyAny) then
        imgui.TextDisabled('Nothing has been levied yet.');
        tip(TIPS.revenueNone);
    elseif (imgui.BeginTable('dwb_levy', 6, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
        tableHead({
            { label = 'Seat',          weight = 1.1, tip = TIPS.colRevSeat },
            { label = 'Took',          weight = 0.8, tip = TIPS.colRevTake },
            { label = 'Burned',        weight = 0.8, tip = TIPS.colRevBurn },
            { label = 'Payments',      weight = 0.5, tip = TIPS.colRevCount },
            { label = 'Took ever',     weight = 0.8, tip = TIPS.colRevLife },
            { label = 'Burned ever',   weight = 0.8, tip = TIPS.colRevLife },
        });

        local function levyRow(label, row, rowTip)
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(label);
            tip(rowTip);
            imgui.TableNextColumn();
            imgui.Text(fmtGil(row.seasonTake));
            imgui.TableNextColumn();
            imgui.Text(fmtGil(row.seasonBurn));
            imgui.TableNextColumn();
            imgui.Text(tostring(row.seasonCount));
            imgui.TableNextColumn();
            imgui.Text(fmtGil(row.lifetimeTake));
            imgui.TableNextColumn();
            imgui.Text(fmtGil(row.lifetimeBurn));
        end

        for idx = 1, #SEAT_KEYS do
            local row = state.levy[idx];

            if (row ~= nil) then
                levyRow(SEAT_NAMES[idx], row, TIPS.colRevSeat);
            end
        end

        -- SEAT 0 IS NOT A SEAT. It is the realm's line, and it is drawn last
        -- and named so, because a reader who takes it for a seat reads every
        -- other row as a share of it.
        local realm = state.levy[0];

        if (realm ~= nil) then
            levyRow('The realm', realm, TIPS.revenueRealm);
        end

        imgui.EndTable();
    end

    imgui.Separator();

    if (imgui.SmallButton('Newer##dwb_rev_prev') and rev.page > 1) then
        askRevenue(rev.page - 1);
    end

    tip(TIPS.revenuePrev);
    imgui.SameLine();
    imgui.Text(string.format('payments, page %d', rev.page));
    tip(TIPS.revenuePay);
    imgui.SameLine();

    -- No page count rides `u|`, so Older is offered while the page in hand
    -- still had rows in it rather than against a page size remembered here.
    if (imgui.SmallButton('Older##dwb_rev_next') and #rev.rows > 0) then
        askRevenue(rev.page + 1);
    end

    tip(TIPS.revenueNext);

    if (imgui.BeginChild('dwb_revenue', { 0, footerReserve() }, CHILD_FLAGS_NONE)) then
        if (#rev.rows == 0) then
            imgui.TextDisabled(rev.page > 1 and 'Nothing on this page.' or 'No payments yet.');
            tip(rev.page > 1 and TIPS.revenueEmpty or TIPS.revenueNone);
        elseif (imgui.BeginTable('dwb_rev_rows', 7, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
            tableHead({
                { label = 'When',      weight = 0.6, tip = TIPS.colRevWhen },
                { label = 'Paid by',   weight = 0.9, tip = TIPS.colRevWho },
                { label = 'Seat',      weight = 0.9, tip = TIPS.colRevSeat },
                { label = 'For',       weight = 0.9, tip = TIPS.colRevWhat },
                { label = 'Charged',   weight = 0.7, tip = TIPS.colRevCharged },
                { label = 'To holder', weight = 0.7, tip = TIPS.colRevTake },
                { label = 'Burned',    weight = 0.7, tip = TIPS.colRevBurn },
            });

            for _, row in ipairs(rev.rows) do
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(fmtAgo(row.at));
                tip(TIPS.revenuePay);
                imgui.TableNextColumn();
                imgui.Text(row.payer);
                imgui.TableNextColumn();
                imgui.Text(SEAT_SHORT[row.seat] or 'The realm');
                imgui.TableNextColumn();
                imgui.Text(SOURCE_WORDS[row.source] or row.source);
                imgui.TableNextColumn();
                imgui.Text(fmtGil(row.charged));
                imgui.TableNextColumn();
                imgui.Text(fmtGil(row.take));
                imgui.TableNextColumn();
                imgui.Text(fmtGil(row.burned));
            end

            imgui.EndTable();
        end

        if (#rev.acts > 0) then
            imgui.Separator();
            imgui.Text('The rates, most recently set first');
            tip(TIPS.revenueRate);

            for _, act in ipairs(rev.acts) do
                imgui.TextWrapped(string.format('%s %s set %s to %d percent (was %d)',
                    fmtAgo(act.at), act.who, act.kind, act.value, act.prev));
                tip(string.format('%s Seat: %s.', TIPS.revenueRate, SEAT_SHORT[act.seat] or 'the realm'));
            end
        end
    end

    imgui.EndChild();
end

local function renderWanted()
    local r = state.rules;

    imgui.TextWrapped(r ~= nil
        and string.format('WANTED is the Crown\'s mark on an ACCOUNT: it runs for %d hours, and while it is up that account cannot file for a seat. The fine (%s to %s gil, the Crown\'s choice) clears it early and goes to the Treasury; waiting it out costs nothing but the time. The owner can strike any mark.',
            math.floor(r.indictSeconds / 3600), fmtGil(r.fineMin), fmtGil(r.fineMax))
        or 'WANTED is the Crown\'s mark on an ACCOUNT: while it is up that account cannot file for a seat. Paying the fine clears it early and the gil goes to the Treasury; waiting it out costs nothing but the time.');
    tip(TIPS.tabWanted);
    imgui.Separator();

    if (#state.wanted == 0) then
        imgui.TextDisabled('Nobody is wanted.');
        tip(TIPS.wantedRow);
    end

    for _, w in ipairs(state.wanted) do
        imgui.TextColored(theme.colors.warn, string.format('%s -- %s (by %s), fine %s gil, %s left', w.name, w.charge, w.by, fmtGil(w.fine), fmtLeft(w.untilAt)));
        tip(TIPS.wantedRow);
    end

    imgui.Separator();

    if (imgui.SmallButton('Pay my fine##dwb_pay')) then
        write('pay', '!dwb pay', 'Paying...');
    end

    tip(TIPS.pay);
end

local function renderChronicle()
    local c = state.chronicle;

    if (state.chronAsked == nil and #c.rows == 0 and c.total == 0 and state.season ~= nil) then
        askChronicle(1);
    end

    local pages = math.max(1, math.ceil(c.total / math.max(1, c.per)));

    if (imgui.SmallButton('Newer##dwb_chron_prev') and c.page > 1) then
        askChronicle(c.page - 1);
    end

    tip(TIPS.chronPrev);
    imgui.SameLine();
    imgui.Text(string.format('page %d of %d', c.page, pages));
    imgui.SameLine();

    if (imgui.SmallButton('Older##dwb_chron_next') and c.page < pages) then
        askChronicle(c.page + 1);
    end

    tip(TIPS.chronNext);
    imgui.Separator();

    if (#c.rows == 0) then
        imgui.TextDisabled('Nothing written yet.');
        tip(TIPS.tabChronicle);

        return;
    end

    if (imgui.BeginChild('dwb_chron', { 0, footerReserve() }, CHILD_FLAGS_NONE)) then
        for _, row in ipairs(c.rows) do
            imgui.TextWrapped(string.format('[S%d %s] %s', row.season, row.kind, row.text));
            tip(string.format('Season %d, %s. The Chronicle is public and permanent.', row.season, row.kind));
        end
    end

    imgui.EndChild();
end

--[[
* THE WHOLE SEASON, IN PLAIN WORDS (1.1.0).
*
* Every paragraph that carries a number has two spellings: one for a server
* that sent the f| / r| records and one for a server that did not. The second
* is not a fallback with a guessed number in it -- it is the same sentence
* with the figures left out, because a wrong number here is worse than no
* number, and this window is not allowed to hold a copy of a server constant
* that could drift out from under it.
--]]
local function howParagraphs()
    local r    = state.rules;
    local out  = T{ };

    local function para(head, body)
        out:append({ head = head, body = body });
    end

    para('What this is',
        'Six seats of real power over this server, each won by a vote of every eligible ACCOUNT. Everything in this window also works typed as !politics, and the server holds the ballots, runs the count and clamps every power -- this window only draws what it is told.');

    if (r ~= nil) then
        para('The season',
            string.format('A season is %d days long and runs on one clock for everybody. Days 1-%d are nomination, days %d-%d the campaign, days %d-%d the poll (%d hours), and the rest of the season is governing under the winners.',
                r.seasonDays, r.nominationEnd, r.nominationEnd + 1, r.campaignEnd, r.campaignEnd + 1, r.pollEnd, (r.pollEnd - r.campaignEnd) * 24));
    else
        para('The season',
            'A season runs on one clock for everybody: a nomination phase, a campaign phase, a poll, then governing under the winners until the next count.');
    end

    para('Nomination', PHASE_WHAT.nomination .. ' A filing fee is held by the server until the count, and returned to the winner.');
    para('Campaign', PHASE_WHAT.campaign .. ' A candidate who withdraws gets their fee and their whole pledge straight back.');
    para('The poll', PHASE_WHAT.poll .. ' Ballots are ranked: !politics vote <seat> <first>,<second>,<third>, or the Vote button for a single name. Voting again replaces your ballot.');
    para('The count and governing',
        PHASE_WHAT.governing .. ' The count is an instant runoff: the lowest first choices are eliminated round by round until somebody holds more than half of what is left.');

    if (r ~= nil) then
        para('Who may vote',
            string.format('Your ACCOUNT, not your character: one ballot per race however many characters you own. The account must have existed before the season began and have %d hours played. Staff neither run nor vote. Accounts seen from a single address share ONE base vote between them -- fame and Drift Board contracts still add bonus votes on top, individually. A race with fewer than %d voters is left with the Regent.',
                r.voteHours, r.quorum));
    else
        para('Who may vote',
            'Your ACCOUNT, not your character: one ballot per race however many characters you own. The account must predate the season and have some hours played. Staff neither run nor vote. Accounts seen from a single address share ONE base vote between them, and a race with too few voters is left with the Regent.');
    end

    para('The secret ballot',
        'Nobody -- not the candidates, not the other voters, not staff -- is shown who you voted for. Only the totals and the turnout are ever published. That is the whole point of the pledge rule below.');

    if (r ~= nil) then
        para('Pledges',
            string.format('A candidate can escrow gil for the voters: at least %s, at most %s. If they WIN, the whole pledge is split evenly between every account that voted in that race -- whoever they voted for. If they LOSE, %d percent goes to the Treasury and the rest comes back. So a pledge pays everybody and buys nobody, because the ballot is secret. Every pledge is announced world-wide, so a player may pledge or raise once every %s.',
                fmtGil(r.pledgeMin), fmtGil(r.pledgeMax), r.pledgeCut, fmtWords(r.pledgeCooldown)));
    else
        para('Pledges',
            'A candidate can escrow gil for the voters. If they WIN, the whole pledge is split evenly between every account that voted in that race -- whoever they voted for. If they LOSE, a cut goes to the Treasury and the rest comes back. A pledge pays everybody and buys nobody, because the ballot is secret. Every pledge is announced world-wide, so raises are rate-limited.');
    end

    if (r ~= nil) then
        para('Endorsements',
            string.format('Public, and a seated officeholder\'s only: one per holder per race, changeable until the poll shuts. The Crown is the seat they decide -- its winner must also carry %d of the three Mayors, or the throne stays with the Regent and every Crown filing is refunded whole.',
                r.crownEndorsements));
    else
        para('Endorsements',
            'Public, and a seated officeholder\'s only: one per holder per race, changeable until the poll shuts. The Crown is the seat they decide -- its winner must also carry the seated Mayors, or the throne stays with the Regent.');
    end

    local seats = T{ };

    for idx = 1, #SEAT_KEYS do
        local rule = state.seatRules[idx];

        if (rule ~= nil) then
            seats:append(string.format('%s (fee %s gil, account %d days, %d-season term): %s.',
                SEAT_NAMES[idx], fmtGil(rule.fee), rule.minAge, rule.term, SEAT_DOES[idx]));
        else
            seats:append(string.format('%s: %s.', SEAT_NAMES[idx], SEAT_DOES[idx]));
        end
    end

    para('The six seats', table.concat(seats, '  '));

    --[[
    * THE LADDER AND THE NEW POWERS (1.2.0). Prose for the rule, the wire for
    * every figure in it -- the cadences, the cap and the holiday's length
    * ride f|, and a server that did not send them gets the same sentences
    * with the figures left out rather than a number this window remembered.
    --]]
    para('The ladder to the Crown',
        'The seats are climbed in order. A full term as Mayor of Bastok, San d\'Oria or Windurst is what qualifies a candidate for the Mayor of Jeuno; a full term as Mayor of Jeuno is what qualifies one for the Crown, on top of the Crown\'s own feat, its account age and its fee. The Royal Treasurer\'s terms are service, and are not that.');

    if (r ~= nil and r.proclaimCooldown > 0) then
        para('Speaking to the realm',
            string.format('A seated holder may proclaim: one line from a fixed menu, spoken world-wide, with the seat, the name and the place filled in by the server. There is no free text at any seat, and it is one proclamation per SEAT every %s -- not per holder, so resigning and being re-seated does not buy a second voice.',
                fmtEvery(r.proclaimCooldown)));
    else
        para('Speaking to the realm',
            'A seated holder may proclaim: one line from a fixed menu, spoken world-wide, with the seat, the name and the place filled in by the server. There is no free text at any seat, and the menu is rationed per SEAT rather than per holder.');
    end

    if (r ~= nil and r.knobCooldown > 0) then
        para('The rate levers',
            string.format('The mercenary cut and travel fees are the Treasurer\'s, the tolls into Jeuno are the Mayor of Jeuno\'s, and each starting town\'s Mayor prices the outposts in every region their nation holds that day. Any one of them moves once every %s, whoever turns it, and the Crown may veto a turn within a day of it. Outposts and tolls run between %d and %d percent of the stock price.',
                fmtEvery(r.knobCooldown), r.outpostMin, r.outpostMax));
    else
        para('The rate levers',
            'The mercenary cut and travel fees are the Treasurer\'s, the tolls into Jeuno are the Mayor of Jeuno\'s, and each starting town\'s Mayor prices the outposts in every region their nation holds that day. Each moves on a clock, and the Crown may veto a turn shortly after it.');
    end

    if (r ~= nil and r.knightMax > 0) then
        para('The Crown\'s honours and mercies',
            string.format('The Crown may name up to %d Knights of the Realm at once, one every %s: the honour is the ACCOUNT\'s, it carries a title, and the whole order lapses when the Crown changes hands. The Crown may also call a mercenary holiday -- the board\'s cut goes to the lowest it will take for %s, once every %s -- and an amnesty, which closes every open indictment at once, once a season.',
                r.knightMax, fmtEvery(r.knightCooldown), fmtEvery(r.holidaySeconds), fmtEvery(r.holidayCooldown)));
    else
        para('The Crown\'s honours and mercies',
            'The Crown may name Knights of the Realm: the honour is the ACCOUNT\'s, it carries a title, and the whole order lapses when the Crown changes hands. The Crown may also call a mercenary holiday, which sends the board\'s cut to the lowest it will take for a while, and an amnesty, which closes every open indictment at once.');
    end

    para('When politics is frozen',
        'The owner can suspend every power of office at once. While it is on, a red line says so at the top of this window: no decrees, no festivals, no proclamations, every rate back at stock and every act in effect disarmed -- nothing cancelled and nothing refunded, so lifting it gives an act back whatever time it had left. Filing, pledging, endorsing, voting, claiming and the count are NOT frozen.');

    para('The Treasury',
        'The public purse. It takes the losing filing fees, the cut of refunded pledges and every indictment fine; it pays Public Enemy bounties, the Treasurer\'s login stimulus and the Drift Coin bonus. Its balance and this season\'s flow are on the Treasury tab, beside everything currently in effect.');

    if (r ~= nil) then
        para('Wanted',
            string.format('The Crown may mark an ACCOUNT Wanted for %d hours with a fine of %s to %s gil. A marked account cannot file for a seat. Pay the fine to clear it early (the gil goes to the Treasury) or wait it out. The Crown may pardon, and the owner may strike any mark.',
                math.floor(r.indictSeconds / 3600), fmtGil(r.fineMin), fmtGil(r.fineMax)));
    else
        para('Wanted',
            'The Crown may mark an ACCOUNT Wanted for a few days with a fine. A marked account cannot file for a seat. Pay the fine to clear it early (the gil goes to the Treasury) or wait it out. The Crown may pardon, and the owner may strike any mark.');
    end

    para('Gil owed to you',
        'Nothing is ever pushed at an offline character. Pledge shares, refunds, stimulus payments and bounty quarters wait in your account until you press Claim at the top of this window, or type !politics claim.');

    if (r ~= nil) then
        para('The Chronicle',
            string.format('The public, permanent record: every filing, pledge, endorsement, decree, festival, indictment, veto and result, newest first. It is also where you find out that a holder went quiet -- a seat whose holder has not logged in for %d days is retired to the Regent, and the Chronicle says so.',
                r.idleDays));
    else
        para('The Chronicle',
            'The public, permanent record: every filing, pledge, endorsement, decree, festival, indictment, veto and result, newest first. A holder who goes quiet long enough is retired to the Regent, and the Chronicle says so.');
    end

    return out;
end

local function renderHow()
    if (state.rules == nil) then
        imgui.TextDisabled('This server has not sent its numbers, so the figures are left out below. Update dwpolitics, or ask a GM whether the server is current.');
        tip('The f| and r| records carry the server\'s own constants. An older server does not send them, and this window will not invent them.');
        imgui.Separator();
    end

    if (imgui.BeginChild('dwb_how', { 0, footerReserve() }, CHILD_FLAGS_NONE)) then
        for _, p in ipairs(howParagraphs()) do
            imgui.TextColored(theme.colors.ok, p.head);
            imgui.TextWrapped(p.body);
            tip(p.head);
            imgui.Separator();
        end
    end

    imgui.EndChild();
end

--[[
* THE OWNER'S TAB (1.2.0, owner E2/E3).
*
* IT IS NOT DRAWN AT ALL unless the server said so on `m|`: renderWindow
* does not CALL BeginTabItem for it, so there is no greyed tab, no
* placeholder and nothing to notice. The client's own idea of its GM level
* is a number it was told, so it is never consulted.
*
* Everything in here is the same control the holder gets, with two
* differences and no others: `live` skips the COOLDOWN (E3: the owner acts
* past every clock) and the line carries the `admin` prefix. Bands, Treasury
* checks and the freeze are the server's and are still drawn -- an owner who
* can quietly break a band is an owner who finds out from a player.
--]]
local ARM_WINDOW = 8.0;

local function adminPowers(idx)
    local key = SEAT_KEYS[idx];
    local t   = state.treasury;

    imgui.Text(SEAT_NAMES[idx]);
    tip(TIPS.adminSeat);

    if (key == 'crown') then
        for _, word in ipairs(DECREE_WORDS) do
            imgui.SameLine();
            powerButton(string.format('Decree %s', word), string.format('dwb_adm_decree_%s', word), 'admin:decree',
                '!dwb admin decree ' .. word, 'Decreeing...', TIPS.decree);
        end

        imgui.PushItemWidth(140);
        imgui.InputTextWithHint('##dwb_adm_name', 'character name', state.inAdmin, INPUT_MAX + 1);
        imgui.PopItemWidth();
        tip(TIPS.inputAdmin);
        imgui.SameLine();
        powerButton('Indict', 'dwb_adm_indict', 'admin:indict', function()
            local name = cleanInput(state.inAdmin);

            return name ~= '' and ('!dwb admin indict ' .. name) or nil;
        end, 'Indicting...', TIPS.indict);
        imgui.SameLine();
        powerButton('Pardon', 'dwb_adm_pardon', 'admin:pardon', function()
            local name = cleanInput(state.inAdmin);

            return name ~= '' and ('!dwb admin pardon ' .. name) or nil;
        end, 'Pardoning...', TIPS.pardon);
        imgui.SameLine();
        powerButton('Enemy', 'dwb_adm_enemy', 'admin:enemy', function()
            local name = cleanInput(state.inEnemy);
            local pot  = wireInt(cleanInput(state.inPot));

            return (name ~= '' and pot > 0) and string.format('!dwb admin enemy %s %d', name, pot) or nil;
        end, 'Naming a Public Enemy...', TIPS.enemy, treasuryBlock());

        if (t ~= nil) then
            imgui.SameLine();
            imgui.TextDisabled(string.format('the Treasury holds %s gil', fmtGil(t.balance)));
            tip(TIPS.adminTreas);
        end

        knightControl(true, 'adm_', 'admin:knight', function(name)
            return '!dwb admin knight ' .. name;
        end);

        imgui.SameLine();
        powerButton('Holiday', 'dwb_adm_holiday', 'admin:holiday', '!dwb admin holiday', 'Declaring a holiday...', TIPS.holiday);
        imgui.SameLine();
        powerButton('Amnesty', 'dwb_adm_amnesty', 'admin:amnesty', '!dwb admin amnesty', 'Declaring an amnesty...', TIPS.amnesty);
    elseif (key == 'treasurer') then
        imgui.SameLine();
        imgui.PushItemWidth(70);
        imgui.InputTextWithHint('##dwb_adm_number', 'number', state.inNumber, 12);
        imgui.PopItemWidth();
        tip(TIPS.inputNumber);

        for _, verb in ipairs({ 'merc', 'port', 'stimulus', 'drift' }) do
            imgui.SameLine();
            powerButton(verb, 'dwb_adm_' .. verb, 'admin:' .. verb, function()
                local value = wireInt(cleanInput(state.inNumber));

                return value > 0 and string.format('!dwb admin %s %d', verb, value) or nil;
            end, 'Setting...', TIPS[verb], verb ~= 'merc' and verb ~= 'port' and treasuryBlock() or nil);
        end

        if (t ~= nil) then
            imgui.SameLine();
            imgui.TextDisabled(string.format('the Treasury holds %s gil', fmtGil(t.balance)));
            tip(TIPS.adminTreas);
        end
    else
        -- A Mayor power under the admin prefix names its town first.
        for _, word in ipairs(FESTIVAL_WORDS) do
            imgui.SameLine();
            powerButton(string.format('Festival %s', word), string.format('dwb_adm_festival_%s_%s', key, word), 'admin:festival',
                string.format('!dwb admin festival %s %s', key, word), 'Declaring a festival...', TIPS.festival);
        end

        imgui.SameLine();
        powerButton('Town hall', 'dwb_adm_townhall_' .. key, 'admin:townhall',
            '!dwb admin townhall ' .. key, 'Calling a town hall...', TIPS.townhall);
        imgui.SameLine();
        powerButton('Home', 'dwb_adm_home_' .. key, 'admin:home',
            '!dwb admin home ' .. key, 'Going home...', TIPS.home);

        if (IS_TOWN[key]) then
            rateLever(state.knobs['op_' .. key], {
                id = 'adm_op_' .. key, verb = 'admin:outpost', label = 'Outpost fare', tip = TIPS.outpost, live = true,
                command = function(value)
                    return string.format('!dwb admin outpost %s %d', key, value);
                end,
            });
        else
            rateLever(state.knobs.tolls, {
                id = 'adm_tolls', verb = 'admin:tolls', label = 'Tolls into Jeuno', tip = TIPS.tolls, live = true,
                command = function(value)
                    return string.format('!dwb admin tolls %d', value);
                end,
            });
        end
    end

    proclaimButtons(idx, true, 'adm_', 'admin:proclaim', function(word)
        return string.format('!dwb admin proclaim %s %s', word, key);
    end);
end

local function renderAdmin()
    imgui.TextWrapped(state.adminLevel > 0
        and string.format('The owner\'s overrides. Every control here acts AS the seat it sits under -- past its cooldown, inside its band, in the Chronicle as the owner. The server admits GM level %d to this tab and nothing in this window decides that.', state.adminLevel)
        or 'The owner\'s overrides. Every control here acts AS the seat it sits under -- past its cooldown, inside its band, in the Chronicle as the owner.');
    tip(TIPS.tabAdmin);

    --[[
    * THE FREEZE IS TWO CLICKS. One button arms, a second sends: a stray
    * click on this tab must never be able to stop every power on the
    * server. The arm expires on its own, so an armed toggle left alone is
    * not a trap for the next click either.
    --]]
    local want  = state.frozen and 0 or 1;
    local label = state.frozen and 'Lift the freeze' or 'Freeze politics';

    if (state.arm ~= nil and (os.clock() - state.arm.at) > ARM_WINDOW) then
        state.arm = nil;
    end

    if (state.arm ~= nil and state.arm.to == want) then
        if (imgui.SmallButton(string.format('Confirm: %s##dwb_admin_freeze_go', label))) then
            state.arm = nil;

            write('freeze', string.format('!dwb admin freeze %s', want == 1 and 'on' or 'off'), 'Freezing...');
        end

        tip(TIPS.adminArmed);
        imgui.SameLine();

        if (imgui.SmallButton('Cancel##dwb_admin_freeze_no')) then
            state.arm = nil;
        end

        tip(TIPS.adminArmed);
    else
        if (imgui.SmallButton(string.format('%s##dwb_admin_freeze', label))) then
            state.arm = { at = os.clock(), to = want };
        end

        tip(TIPS.adminFreeze);
    end

    imgui.SameLine();

    if (state.frozen) then
        imgui.TextColored(theme.colors.err, FROZEN_LINE);
        tip(TIPS.frozen);
    else
        imgui.TextDisabled('Every power of office is live.');
        tip(TIPS.adminFreeze);
    end

    imgui.Separator();

    if (imgui.BeginChild('dwb_admin', { 0, footerReserve() }, CHILD_FLAGS_NONE)) then
        for idx = 1, #SEAT_KEYS do
            adminPowers(idx);
            imgui.Separator();
        end

        imgui.Text('The rate levers');
        tip(TIPS.colKnob);

        if (#state.knobList == 0) then
            imgui.TextDisabled('  This server sent no levers.');
            tip(TIPS.wireless);
        end

        for _, knob in ipairs(state.knobList) do
            rateLever(knob, {
                id = 'adm_knob_' .. knob.name, verb = 'admin:knob', label = knob.name, tip = TIPS.adminKnob, live = true,
                command = function(value)
                    return string.format('!dwb admin knob %s %d', knob.name, value);
                end,
            });

            imgui.SameLine();

            local wait = clockLeft(knob.readyAt);

            imgui.TextDisabled(string.format('%s%s', SEAT_SHORT[knob.seat] or '?',
                wait > 0 and string.format(' -- its holder waits %s', fmtWords(wait)) or ''));
            tip(TIPS.colKnobSeat);
        end

        imgui.Separator();
        imgui.Text('Acts in effect');
        tip(TIPS.act);

        if (#state.acts == 0) then
            imgui.TextDisabled('  Nothing is in effect.');
            tip(TIPS.act);
        end

        for _, act in ipairs(state.acts) do
            imgui.Text(string.format('  %d  %s  %s by %s (%s left)', act.actid, SEAT_SHORT[act.seat] or '?', act.kind, act.by, fmtLeft(act.untilAt)));
            tip(TIPS.act);
            imgui.SameLine();

            if (imgui.SmallButton(string.format('End##dwb_admin_end_%d', act.actid))) then
                write('end', string.format('!dwb admin end %d', act.actid), 'Ending the act...');
            end

            tip(TIPS.adminEnd);
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Revert##dwb_admin_revert_%d', act.actid))) then
                write('veto', string.format('!dwb admin revert %d', act.actid), 'Reverting...');
            end

            tip(TIPS.adminRevert);
        end

        imgui.Separator();
        imgui.Text('Wanted');
        tip(TIPS.wantedRow);

        if (#state.wanted == 0) then
            imgui.TextDisabled('  Nobody is wanted.');
            tip(TIPS.wantedRow);
        end

        for _, w in ipairs(state.wanted) do
            imgui.Text(string.format('  %s -- %s, fine %s gil, %s left', w.name, w.charge, fmtGil(w.fine), fmtLeft(w.untilAt)));
            tip(TIPS.wantedRow);
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Strike##dwb_admin_strike_%s', w.name))) then
                write('strike', '!dwb admin strike ' .. w.name, 'Striking...');
            end

            tip(TIPS.adminStrike);
        end

        imgui.Separator();
        imgui.Text('The seats');
        tip(TIPS.adminVacate);

        for idx = 1, #SEAT_KEYS do
            local seat = state.seats[idx];

            imgui.Text(string.format('  %s -- %s', SEAT_NAMES[idx], seat ~= nil and seat.name or '?'));
            tip(TIPS.colHolder);

            if (seat ~= nil and seat.name ~= 'Regent') then
                imgui.SameLine();

                if (imgui.SmallButton(string.format('Vacate##dwb_admin_vacate_%d', idx))) then
                    write('vacate', '!dwb admin vacate ' .. SEAT_KEYS[idx], 'Vacating...');
                end

                tip(TIPS.adminVacate);
            end
        end

        imgui.Separator();
        imgui.Text('The order of the realm');
        tip(TIPS.knightsBlock);

        if (#state.knights == 0) then
            imgui.TextDisabled('  Nobody holds the honour.');
            tip(TIPS.knightsNone);
        end

        for _, knight in ipairs(state.knights) do
            imgui.Text(string.format('  %s', knight.name));
            tip(TIPS.knightsBlock);
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Unknight##dwb_admin_unknight_%s', knight.name))) then
                write('admin:unknight', '!dwb admin unknight ' .. knight.name, 'Revoking...');
            end

            tip(TIPS.unknight);
        end
    end

    imgui.EndChild();
end

--[[
* THE TABS EXPLAIN THEMSELVES ON HOVER. The hover test sits between
* BeginTabItem and the body, not inside the `if`: ImGui submits the tab as an
* item inside BeginTabItem, so IsItemHovered reads the TAB there whether it
* opened or not, and the first widget the body draws would take the "last
* item" away. (The comment that reasons this out lives in dwbags.)
--]]
local function renderWindow()
    renderHeader();

    if (imgui.BeginTabBar('dwb_tabs')) then
        local onSeats = imgui.BeginTabItem('Seats###dwb_tab_seats');

        tip(TIPS.tabSeats);

        if (onSeats) then
            renderSeats();
            imgui.EndTabItem();
        end

        local onElection = imgui.BeginTabItem('Election###dwb_tab_election');

        tip(TIPS.tabElection);

        if (onElection) then
            renderElection();
            imgui.EndTabItem();
        end

        local onTreasury = imgui.BeginTabItem('Treasury###dwb_tab_treasury');

        tip(TIPS.tabTreasury);

        if (onTreasury) then
            renderTreasury();
            imgui.EndTabItem();
        end

        local onRevenue = imgui.BeginTabItem('Revenue###dwb_tab_revenue');

        tip(TIPS.tabRevenue);

        if (onRevenue) then
            renderRevenue();
            imgui.EndTabItem();
        end

        local onWanted = imgui.BeginTabItem(string.format('Wanted %d###dwb_tab_wanted', #state.wanted));

        tip(TIPS.tabWanted);

        if (onWanted) then
            renderWanted();
            imgui.EndTabItem();
        end

        local onChronicle = imgui.BeginTabItem('Chronicle###dwb_tab_chronicle');

        tip(TIPS.tabChronicle);

        if (onChronicle) then
            renderChronicle();
            imgui.EndTabItem();
        end

        local onHow = imgui.BeginTabItem('How it works###dwb_tab_how');

        tip(TIPS.tabHow);

        if (onHow) then
            renderHow();
            imgui.EndTabItem();
        end

        --[[
        * THE ADMIN TAB IS NOT DRAWN AT ALL FOR ANYBODY ELSE (owner E2).
        * BeginTabItem is not CALLED unless state.admin -- which is set by an
        * m| record with exactly three numeric fields whose first is 1, and
        * by nothing else in this file. No m| at all, or m|0, and there is no
        * tab: not greyed, not a placeholder, not a hint that one exists.
        --]]
        if (state.admin) then
            local onAdmin = imgui.BeginTabItem('Admin###dwb_tab_admin');

            tip(TIPS.tabAdmin);

            if (onAdmin) then
                renderAdmin();
                imgui.EndTabItem();
            end
        end

        imgui.EndTabBar();
    end
end

ashita.events.register('d3d_present', 'dwpolitics_present', function ()
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    if (state.season == nil and state.requested == nil and not state.serverSilent and not state.refused and not state.boardFailed) then
        askStatus();
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 760, 480 }, ImGuiCond_FirstUseEver);
    imgui.SetNextWindowSizeConstraints({ 620, 320 }, { 99999, 99999 });

    local visible = imgui.Begin('DriftwoodXI Politics##dwpolitics', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwpolitics'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwpolitics'):append(chat.message('Window closed. Everything it shows also works typed as !politics.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwpolitics_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:sub(1, 4):lower() ~= '!dwb') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwpolitics_command', function (e)
    local args  = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/politics' and first ~= '/dwpolitics') then
        return;
    end

    e.blocked = true;

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwpolitics_load', function ()
    print(chat.header('dwpolitics'):append(chat.message('/politics opens the seats of power -- its How it works tab explains the season, and everything it shows also works typed as !politics (try !politics help).')));
end);
