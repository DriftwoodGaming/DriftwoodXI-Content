--[[
* DriftwoodXI -- dwmerc
*
* The mercenary board as a storefront: browse who is for hire, read the frozen
* snapshot you would be paying for, hire with a quoted price and a deliberate
* second click, call and dismiss what you have under contract, and collect what
* your own listings have earned -- all without typing a command.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* Every read is a `!dwm` line and every write is a `!dwm` line -- the same
* dispatch, the same verbs, the same C++ store that `!merc ...` reaches
* (documentation/dwm_protocol.md is the contract). Ownership, prices, caps and
* contract state all live server-side and are re-checked on every call
* whichever way the command arrived, which is what makes shipping a UI over a
* gil channel safe at all: a bug in here cannot spend anything the server
* would have refused a typed player.
*
* THIS ONE MOVES MONEY, so the one paragraph that matters most: THERE IS NO
* RECORD AND NO COMMAND ON THIS WIRE THAT BOTH QUOTES AND BUYS. `hire` returns
* a quote and arms nothing but a 90-second window in server module state; a
* second, separately issued command spends, with the price re-taken from the
* store on that issue too. The protocol guarantees no one-click hire is
* POSSIBLE; this window owes the player the same honesty anyway, so the
* confirm button appears only after the server's quote has arrived, in its own
* place, quoting the gross and the end time it would be consenting to. The one
* sharp edge the protocol leaves -- the SAME hire line re-issued inside the
* window IS the consent -- is guarded here with a lockout: the quote button
* will not re-issue a line that could still land on an armed quote, whichever
* tier armed it (see matchesArmed).
*
* NEVER RENDER A PRICE THIS FILE COMPUTED. `gross` is on the wire because the
* server worked it out from the listing at the moment it answered; the confirm
* button quotes the h| record's numbers and nothing else.
*
* THE LISTING TAB IS THE SAME BARGAIN ON THE SELLER'S SIDE. `!merc list` takes
* a character, a rate, an hour cap and up to three rule set names, and until the
* server grew `!merc options` there was nowhere on this wire to learn what any
* of those could be -- so the tab is a form over that one read and two writes
* (`list` and `unlist`), with every name in every picker coming off the wire and
* none of it invented here. It spends nothing and earns nothing: listing is free
* and the house takes its cut at settlement.
*
* THE BOARD IS PAGED BY THE SERVER, SIX AT A TIME, and that is the store's
* number rather than this window's (BOARD_PAGE in merc.lua). A shelf of thirty
* is therefore five pages at the client's own 1.2-second chat throttle, which
* is a long way to walk to reach somebody you already know by name -- so the
* Board tab has a find box, and it is `!merc info <name>` with a button on it.
* The store has resolved a name exactly and then by unambiguous prefix since
* v1, so the box needs no new verb, no protocol move and no unknown-verb latch;
* the answer is an ordinary info envelope, and the reader makes the listing it
* described the selection. It reads and it cannot spend.
*
* TURN IT OFF AND NOTHING IS LOST. `!merc board`, `!merc hire`, `!merc call`,
* `!merc list`, `!merc claim` and the rest do everything this window does,
* typed, and `!merc menu` covers the bounded picks as client dialogs. This is
* faster; it is not required, and the Commands button says so with the whole
* list.
--]]

addon.name    = 'dwmerc';
addon.author  = 'DriftwoodXI';
addon.version = '1.5.0';
addon.desc    = 'The mercenary board storefront for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. This is
-- _DWMDATA and never _DWDATA or _DWGDATA: dwbags and dwgambits own those, and
-- two addons contending to block one sender is a load-order bug where the
-- loser eats the winner's records (dwm_protocol.md says so at length).
local DATA_SENDER = '_DWMDATA';

-- Protocol version the server announces in every `d|` record.
local PROTOCOL = 1;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Equip slot ids as the i| record carries them, in the order a player reads
-- them (the dwbags table).
local SLOT_NAMES = {
    [0]  = 'main',  [1]  = 'sub',   [2]  = 'ranged', [3]  = 'ammo',
    [4]  = 'head',  [5]  = 'body',  [6]  = 'hands',  [7]  = 'legs',
    [8]  = 'feet',  [9]  = 'neck',  [10] = 'waist',  [11] = 'ear1',
    [12] = 'ear2',  [13] = 'ring1', [14] = 'ring2',  [15] = 'back',
};

-- b| flags bits, as dwm_protocol.md defines them. Neither WORKING nor OFF
-- means the listing is open; bit 2 is also what says `remaining` is a real
-- countdown rather than a sentinel.
local LISTING_MINE    = 1;
local LISTING_WORKING = 2;
local LISTING_OFF     = 4;

-- n| flags. These describe the CHARACTER rather than a listing against it:
-- whether a fresh photograph can be taken of it this second. Bit 1 is the one
-- that matters most -- M10 refuses listing the character being played, because
-- the snapshot is copied out of saved rows and a live session has not written
-- them -- and it is why the Listing tab explains rather than just disabling.
local CAND_SELF   = 1;
local CAND_ONLINE = 2;
local CAND_BUSY   = 4;

-- The protocol's "this response did not measure that" sentinel. Not zero: a
-- board row that has not counted gear is not a listing with no gear.
local UNMEASURED = -1;

-- How many loadouts one listing may publish. THE SANCTIONED COPY, and the one
-- case in this file where a number is allowed to be hardcoded: c|'s `loadouts`
-- field is deliberately NOT sentinelled, because merc.lua's own MAX_LOADOUTS
-- is the grammar's copy rather than a store cap that could drift (see the c|
-- record in dwm_protocol.md). The two are held equal by harness_dwmerc.py.
local MAX_LOADOUTS = 3;

--[[
* The armed-quote lockout, and why it is 100 seconds.
*
* The server holds one pending quote per player for 90 seconds, and the SAME
* hire line issued again inside that window is the purchase -- that is the
* typed tier's two-word consent working as designed. For a button it is a
* misclick trap: quote, cancel, quote again would buy. So the quote button
* refuses to issue any hire line that could still match an armed quote,
* whichever tier armed it (packet_out watches typed `!merc hire` too), for the
* server's window plus a margin for the send queue. Confirming is always the
* separate `!dwm confirm` line, which can never quote.
--]]
local ARMED_WINDOW = 100;

-- How long a displayed quote is treated as confirmable, held a few seconds
-- inside the server's own window so the button disappears before the server
-- would start refusing it.
local QUOTE_MARGIN = 5;

-- All of these live in dwtheme and follow the launcher's Appearance theme.
local COLOR_ERROR = theme.colors.err;
local COLOR_OK    = theme.colors.ok;
local COLOR_WARN  = theme.colors.warn;
local COLOR_BADGE = theme.colors.badge;
local COLOR_HINT  = theme.colors.hint;

local state = T{
    open      = T{ false },

    --[[
    * World state. `listings` is ONE table keyed by listingid, filled in as
    * better-measured copies arrive -- the protocol sends the same b| shape
    * from board, info, listings and a quote, with -1 wherever that binding
    * did not measure, so a board row and an info row are the same object
    * here rather than two that can disagree. Everything else is replaced
    * wholesale by the response that owns it, never merged across responses.
    --]]
    listings  = {},         -- [listingid] = merged b| + l| fields
    loadouts  = {},         -- [listingid] = { [ordinal] = name }; never cleared
                            -- on t| -- o| records are deduplicated per envelope
                            -- and a client that dropped names on each t| would
                            -- lose them (dwm_protocol.md on o|)
    board     = nil,        -- { page, pages, total, job, rows = { listingid } }
    mine      = {},         -- listingids of the account's own listings, in order
    mineByName = {},        -- lowercased name -> that listing's entry, built by
                            -- the envelope reader rather than walked per
                            -- candidate per frame by the Listing form
    contracts = { active = {}, recent = {} },
    purse     = nil,        -- { balance, lifetime }
    ledger    = nil,        -- array of w|r rows
    claim     = nil,        -- the last w|c outcome

    -- The listing form's three, all from `options` and all replaced wholesale
    -- by it: the account's characters, the rule sets it could publish, and the
    -- bounds a listing has to satisfy. `limits` stays nil until that verb has
    -- answered, and its fields may be -1 on a server whose store predates the
    -- caps binding -- which means an input with no ceiling, never a guess.
    candidates = {},        -- array of n| rows, roster order
    sets       = {},        -- array of s| rows, the account's own first
    setsByName = {},        -- lowercased name -> that s| row; see knownSet
    limits     = nil,       -- the c| record

    -- The Battle tab (1.4.0; dwm_protocol.md, "The Battle tab"). Replaced
    -- wholesale by the envelope that owns each, never merged.
    battle     = nil,       -- { limits = x| fields, live = { k| rows }, recent = { k| rows }, at }
    records    = nil,       -- { page, pages, total, rows = { r| rows } }
    bquote     = nil,       -- the last q| record, stage `quote` or `posted`
    fights     = {},        -- f| rows by battleid, from bstatus
    fightsAt   = nil,       -- os.clock() the fights were last answered

    selected  = nil,        -- listingid the info pane describes

    -- The Board tab's name lookup: what was asked about and when, so the
    -- info envelope that answers it can select the listing it described --
    -- and so an answer that never came stops waiting to capture somebody
    -- else's. `lookupSaid` is the refusal for a name that is not one.
    lookupWant = nil,
    lookupSaid = nil,

    -- A pager correction the envelope reader asked for and the Board tab has
    -- not applied yet. Set when the server answered a page past the end of a
    -- board that shrank; nil the rest of the time. It lives here rather than
    -- being written straight into the page widget because the widget scratch
    -- is declared with the render, hundreds of lines below the reader.
    boardPage = nil,

    -- The envelope being read. Records buffer between `d|` and `z|` and are
    -- processed as one response, so a torn or foreign line can never
    -- half-fill the UI. m| and e| are handled the moment they arrive -- a
    -- refusal is the one thing a player must never lose.
    inbound   = nil,
    buffer    = {},

    status      = 'Fetching...',
    statusBad   = false,
    refreshedAt = nil,      -- os.clock() the Refresh button last fired at
    statusAt  = 0,          -- os.clock() the line landed at; see STATUS_DWELL
    reported  = false,      -- a render error is worth saying once, not per frame
};

-- The hire dialog. One at a time, deliberately: a second dialog would be a
-- second pending quote and the server holds one.
local dialog = nil;

-- The Battle tab's one form (post a dare, or answer one). Same lifecycle as
-- the hire dialog: pick, quoting, quoted, paying, done -- and the only line
-- the quoted stage can send is `!dwm battle confirm`, which cannot quote.
local bform         = nil;
local battlePending = nil;

-- The last hire line seen leaving this client -- OURS OR TYPED. Either tier
-- arms the same server-side window (MERC_PLAN.md proved it in game: a quote
-- armed by `!dwm hire` was confirmed by a typed line 22 seconds later), so the
-- lockout has to watch both.
local armedHire = nil;

-- The last h|quote received, held OUTSIDE the dialog so that closing it does
-- not throw the quote away: reopening the same purchase inside the armed
-- window shows this copy instead of re-issuing a line the server would read
-- as the consent. Display only -- the confirm re-takes the price server-side
-- on its own issue regardless.
local heldQuote = nil;

-- A claim in flight, so the button cannot be double-clicked into a second
-- claim line. Harmless if it were -- the second finds an empty ledger -- but a
-- disabled button is the honest rendering of "already doing that".
--
-- THE os.clock() THE LINE WAS SENT AT, not a boolean (2026-09-06). It was a
-- boolean, cleared only by the w|c record or by any e| record -- so a claim
-- whose answer never arrived left the button reading "claiming..." for the
-- rest of the session, with the gil still on the ledger and no way to ask for
-- it again short of a zone. Every other in-flight write in this file carries
-- its own clock (writePending, and both waiting stages of the hire dialog);
-- this was the one that did not.
local claimPending = nil;

-- True once a claim went unanswered long enough to give the button back, so
-- the pane can say why the spinner went rather than just losing it.
local claimTimedOut = false;

-- How long any one-line write waits for its answer before the button comes
-- back. Nothing is ever re-sent on that timeout: the panes are the ground
-- truth and a re-sent write is a write done twice.
local WRITE_TIMEOUT = 10.0;

--[[
* Seconds since an os.clock() stamp, and INFINITE when the clock has gone
* backwards. On Windows os.clock() is milliseconds in a 32-bit long, so it
* wraps negative after about 24.8 days of client uptime -- and a stamp from
* before the wrap is AHEAD of every reading after it, which would hold every
* gate in this file shut for the rest of the session: a claim reading
* "claiming..." for ever is exactly the bug WRITE_TIMEOUT exists to end. So a
* gate that finds its stamp in the future treats the wait as over. dwecho's
* `elapsed` keeps the same rule; this file keeps its own copy so the harness's
* dwecho stub need not carry it.
--]]
local function elapsed(stamp)
    if (stamp == nil) then
        return math.huge;
    end

    local now = os.clock();

    if (now < stamp) then
        return math.huge;
    end

    return now - stamp;
end

--[[
* How long a refusal stays on the message line before an answer that WORKED is
* allowed to take it down (2026-09-06).
*
* The red line used to be permanent: nothing ever cleared state.statusBad, so a
* sentence about a listing hired out from under somebody ten minutes ago was
* still the loudest thing in the window while every pane behind it was fine.
* Clearing it on the very next envelope is the other extreme -- these panes
* poll, so the sentence would go inside two seconds and a player who looked
* away would never learn why nothing happened.
*
* So it dwells. The chat copy printed beside it is the permanent record either
* way; this is only about when the window stops shouting.
--]]
local STATUS_DWELL = 12.0;

-- How long the Board tab's name lookup waits for the info envelope that
-- answers it before it stops watching for one. Generous on purpose: the line
-- it sends is QUEUED behind whatever else is waiting on the client's chat
-- throttle, so the round trip is the queue's depth plus the server's answer.
local LOOKUP_WINDOW = 20.0;

-- True once the server has said it has no `quote` verb -- one from before the
-- storefront's quote-only line existed. Detected off the dispatch's own
-- unknown-verb sentence and reset on every login line, the dwbags arrangement,
-- so deployment order cannot matter: a current server gets the line that can
-- never spend, an older one gets the guarded hire path below.
local quoteUnsupported = false;

-- The same arrangement for the Listing tab's one read. A server from before
-- `!merc options` existed answers it with the dispatch's unknown-verb sentence,
-- and the tab's honest response is to say so once and print the typed line --
-- not to leave a red banner up and a form full of empty pickers.
local optionsUnsupported = false;

-- The listing form for the character currently picked, rebuilt when the pick
-- changes. Its inputs are the player's; every name in every picker came off the
-- wire, and the command it composes is one a player could type.
local form = nil;

-- A list or unlist line in flight. Neither moves gil, and the store re-checks
-- ownership on both, but a button clicked twice while the first click is still
-- queued would take two photographs of the same character -- so the button says
-- what it is doing instead of accepting the second click.
local writePending = nil;

-- Listings the Contracts tab has already asked `info` about this pass, so a
-- pane drawn sixty times a second asks once per listing rather than looping.
-- Cleared with the answer tracker: Refresh re-asks.
local infoAsked = {};

-- Contracts whose expiry has already triggered the one settlement re-ask,
-- keyed by contractid. Same shape and lifetime as infoAsked, and outside the
-- rows for the same reason: the rows are rebuilt by every answer.
local expiryAsked = {};

--[[
* A call or dismiss in flight, keyed by contractid, holding the os.clock() the
* line was queued at.
*
* WHY A ROW NEEDS ONE (2026-09-06). Call and Dismiss answer with the whole
* contracts list, which takes a send slot and a round trip -- 1.2 seconds at
* best -- and the row does not change in the meantime, so the button still says
* Call and a player who does not see a mercenary appear clicks it again. Every
* click queued another line, and a second `call` on a mercenary already out is
* a RE-PAINT: the guest goes home and comes back at full health, which is a
* free heal out of combat and a refusal in it. dwbags and dwtoau both settled
* this the same way -- one write in flight, and the button says what it is
* doing rather than accepting the next click.
*
* OUTSIDE THE ROWS, like infoAsked and expiryAsked and for the same reason:
* every contracts envelope rebuilds state.contracts wholesale, so a flag on the
* row would be destroyed by the very answer that should clear it.
--]]
local actPending = {};

-- The Release button's first click (2026-09-16). A release is asked twice
-- server-side, and the second word is `!dwm confirm release` -- a line that
-- can never buy anything, which is why it is not the hire dialog's
-- `!dwm confirm`. Held per contract, for a few seconds: a second click
-- outside the hold arms again rather than ending.
local releaseArmed = nil;
local RELEASE_HOLD = 8.0;

--[[
* Sending: one command per interval, queued, reads deduplicated, writes never
* collapsed and never retried.
*
* THE CLIENT RATE-LIMITS OUTGOING CHAT AND A !dwm COMMAND IS A CHAT LINE.
* Fire two in one frame and the second is answered "A command error occurred"
* before the server ever sees it -- the dwbags lesson, applied from day one.
*
* Writes drain first: a purchase confirmation stuck behind three queued board
* reads would spend its quote window waiting in line. A write is queued at
* most once per click and NEVER re-sent on silence -- a lost `confirm` that
* was re-sent could be a purchase made twice, which is exactly the class of
* bug this addon exists to make impossible.
--]]
-- dwecho's number rather than a copy of it (2026-09-06). What it describes is
-- the CLIENT's chat rate limit -- one fact about the client, not one per addon
-- -- and this file was carrying its own 1.2 beside a library that exports the
-- same constant every other addon throttles against.
local SEND_INTERVAL = echo.SEND_INTERVAL;

local readQueue  = {};
local writeQueue = {};
local lastSend   = 0;

local function issueRead(command)
    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

local function issueWrite(command)
    table.insert(writeQueue, command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and both queues are empty in
    -- almost all of them, while echo.canSend() is three calls across the C++
    -- boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it first
    -- spent a hundred and eighty of those a second to decide to do nothing.
    -- An empty queue has no line to hold or to drop, so the order is free.
    if (#writeQueue == 0 and #readQueue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#writeQueue > 0) then
        lastSend = now;

        echo.send(table.remove(writeQueue, 1));

        return;
    end

    if (#readQueue > 0) then
        lastSend = now;

        echo.send(table.remove(readQueue, 1));
    end
end

--[[
* Answered-question tracking, keyed by envelope verb. A PLAIN TABLE, NOT T{}:
* string keys on a T{} resolve through the sugar metatable and `find` is both
* a table method and a plausible verb name -- the collision that cost dwbags a
* round. An unanswered ask is retried once and then left alone; a retry that
* never terminates is a command loop, which is worse than a stale panel.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

local function forget()
    requested   = {};
    infoAsked   = {};
    expiryAsked = {};
    actPending  = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

-- Ask for one verb about one qualifier at most once, twice if never answered.
-- Called from whatever pane needs the data, every frame, so the guard is the
-- entire point.
local function need(verb, qualifier, command)
    local asked = requested[verb];

    if (asked ~= nil and asked.qualifier == qualifier) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested[verb] = { qualifier = qualifier, at = os.clock(), answered = false, tries = 1 };
    end

    issueRead(command);
end

--[[
* Text helpers.
--]]
local function split(text, sep)
    local parts = {};

    for piece in string.gmatch((text or '') .. sep, '([^' .. sep .. ']*)' .. sep) do
        table.insert(parts, piece);
    end

    return parts;
end

--[[
* Gil with thousands separators.
*
* MEMOISED (2026-09-06). It is a gsub LOOP -- three passes for a seven-figure
* rate -- and it runs on every rate on the board, every gross on the contracts
* tab, and three figures on each of twenty ledger rows, EVERY FRAME. The
* answers are a pure function of the number and a page holds very few distinct
* ones, so the second frame's worth is free. Bounded and dropped whole rather
* than pruned: the table only ever holds numbers this window has drawn, and
* the cost of rebuilding it is one frame of what it used to do every frame.
--]]
local gilCache     = {};
local gilCacheSize = 0;

local GIL_CACHE_MAX = 512;

local function gilText(amount)
    local value = tonumber(amount) or 0;

    -- A NaN is the one number a Lua table refuses as a KEY, and `tonumber`
    -- accepts the word off the wire on LuaJIT; an infinity formats as
    -- nonsense. Neither is a price -- both are a corrupt line -- and the
    -- cache write below would otherwise raise "table index is NaN" inside the
    -- render pcall, which closes the window, every frame the row is drawn.
    if (value ~= value or value == math.huge or value == -math.huge) then
        value = 0;
    end

    value = math.floor(value);

    local hit = gilCache[value];

    if (hit ~= nil) then
        return hit;
    end

    local sign  = value < 0 and '-' or '';
    local text  = string.format('%d', math.abs(value));

    while true do
        local replaced;

        text, replaced = string.gsub(text, '^(%d+)(%d%d%d)', '%1,%2');

        if (replaced == 0) then
            break;
        end
    end

    text = sign .. text;

    if (gilCacheSize >= GIL_CACHE_MAX) then
        gilCache     = {};
        gilCacheSize = 0;
    end

    gilCache[value] = text;
    gilCacheSize    = gilCacheSize + 1;

    return text;
end

local function spanText(seconds)
    seconds = math.max(math.floor(tonumber(seconds) or 0), 0);

    if (seconds >= 3600) then
        return string.format('%dh %02dm', math.floor(seconds / 3600), math.floor((seconds % 3600) / 60));
    end

    if (seconds >= 60) then
        return string.format('%dm %02ds', math.floor(seconds / 60), seconds % 60);
    end

    return string.format('%ds', seconds);
end

-- Coarse on purpose, like the server's own `ago`: the useful question about a
-- snapshot is whether it is from today or from a month ago.
local function agoText(seconds)
    seconds = math.floor(tonumber(seconds) or 0);

    if (seconds < 90) then
        return 'just now';
    end

    if (seconds < 5400) then
        return string.format('%d minutes ago', math.floor(seconds / 60));
    end

    if (seconds < 129600) then
        return string.format('%d hours ago', math.floor(seconds / 3600));
    end

    return string.format('%d days ago', math.floor(seconds / 86400));
end

--[[
* Durations off the wire are counts of seconds the server worked out at the
* moment it answered -- no record carries a timestamp and this client never
* subtracts two clocks (dwm_protocol.md, Clocks). Each one is stored with its
* arrival time so display can run it forward or down LOCALLY, for display
* only: every number that gates anything is re-taken from the server by the
* command that needs it.
--]]
local function stamp(value)
    if (value == nil or value < 0) then
        return nil;
    end

    return { value = value, at = os.clock() };
end

local function liveDown(stamped)
    if (stamped == nil) then
        return nil;
    end

    return math.max(stamped.value - (os.clock() - stamped.at), 0);
end

local function liveUp(stamped)
    if (stamped == nil) then
        return nil;
    end

    return stamped.value + (os.clock() - stamped.at);
end

-- How long an `ago` phrase is reused before it is worked out again. agoText is
-- coarse on purpose -- its answer cannot change more often than once a minute
-- -- and it was being formatted afresh for twenty ledger rows and every My
-- mercs row on every frame. Held on the stamp it describes.
local AGO_REFRESH = 5.0;

local function agoOf(stamped)
    if (stamped == nil) then
        return nil;
    end

    local now = os.clock();

    if (stamped.text == nil or elapsed(stamped.textAt or 0) > AGO_REFRESH) then
        stamped.text   = agoText(liveUp(stamped));
        stamped.textAt = now;
    end

    return stamped.text;
end

-- Remembered on the record it describes. Jobs move only when a b| or an n|
-- rewrites them, and mergeListing drops the cached line when it does -- but
-- the string was being rebuilt for every row of every table on every frame.
local function jobsText(entry)
    if (entry.jobsLine ~= nil) then
        return entry.jobsLine;
    end

    local main = string.format('%s%d', JOB_NAMES[entry.mjob] or '?', entry.mlvl or 0);
    local text = main;

    if ((entry.sjob or 0) > 0) then
        text = string.format('%s/%s%d', main, JOB_NAMES[entry.sjob] or '?', entry.slvl or 0);
    end

    entry.jobsLine = text;

    return text;
end

local function loadoutName(listingid, ordinal)
    local names = state.loadouts[listingid];

    if (names ~= nil and names[ordinal] ~= nil) then
        return names[ordinal];
    end

    return string.format('loadout %d', ordinal or 0);
end

-- The item name out of the client's own resources -- names never ride this
-- wire (the dwbags rule; the i| record carries ids only).
local function itemName(itemid)
    local item = AshitaCore:GetResourceManager():GetItemById(itemid);

    if (item == nil or item.Name[1] == nil or #item.Name[1] == 0) then
        return string.format('item %d', itemid);
    end

    return item.Name[1];
end

--[[
* The frozen kit as display lines, slot order, from an i|-filled listing.
*
* CACHED ON THE LISTING (2026-09-06). This walks sixteen slots, asks the
* client's resource manager for a name per piece and formats a line per piece,
* and it was being called once per contract row and once per My mercs row on
* EVERY FRAME -- purely to find out whether a hover card had anything in it.
* Five rows of sixteen pieces at sixty frames a second is nearly five thousand
* resource lookups and as many string.formats a second, for a tooltip nobody
* was pointing at.
*
* A snapshot is frozen by definition (M1) and the only thing that replaces it
* is an i| envelope, which clears this alongside the gear it replaces.
--]]
local function kitLines(entry)
    if (entry == nil or entry.gearlist == nil) then
        return nil;
    end

    if (entry.kit ~= nil) then
        return entry.kit;
    end

    local bySlot = {};

    for _, piece in ipairs(entry.gearlist) do
        bySlot[piece.slot] = piece.itemid;
    end

    local lines = {};
    local ids   = {};

    for slot = 0, 15 do
        if (bySlot[slot] ~= nil) then
            -- Indented HERE rather than at each of the two places these are
            -- drawn: the info pane used to build a fresh concatenation per
            -- piece per frame just to put two spaces in front of it.
            table.insert(lines, string.format('  %-7s %s', SLOT_NAMES[slot], itemName(bySlot[slot])));

            -- The id beside the line it produced, so the info pane can draw
            -- the client's own card for the piece under the cursor.
            table.insert(ids, bySlot[slot]);
        end
    end

    entry.kit    = lines;
    entry.kitIds = ids;

    return lines;
end

--[[
* How many loadouts a listing publishes: THE HIGHEST ORDINAL, not how many
* names arrived (2026-09-06).
*
* o| is joined by ordinal rather than by position -- dwm_protocol.md says so in
* as many words -- and cpp/merc_store.cpp's loadoutNames() keys its table by
* the ordinal column, so ordinals 1 and 3 with nothing at 2 is a shape this
* wire can carry. Counting entries answered 2, which sized the hire dialog's
* picker one short and put the third loadout out of a hirer's reach entirely --
* on a protocol where the loadout IS the product being priced (M7).
*
* The b| record's own `loadouts` field is the floor. It is the store's COUNT(*)
* and it is the only thing on the wire that can say a listing publishes more
* than the names in hand; the unnamed ordinals render as "loadout N", which is
* exactly what `hire` and `call` take as a numeric argument. Clamped to
* MAX_LOADOUTS so a torn record cannot open a thousand-row combo.
--]]
local function loadoutCount(listingid)
    local names   = state.loadouts[listingid];
    local highest = 0;

    for ordinal in pairs(names or {}) do
        if (type(ordinal) == 'number' and ordinal > highest) then
            highest = ordinal;
        end
    end

    local entry = state.listings[listingid];

    if (entry ~= nil and (entry.count or 0) > highest) then
        highest = entry.count;
    end

    return math.max(math.min(highest, MAX_LOADOUTS), 0);
end

--[[
* Record parsing. Field positions are dwm_protocol.md's and the split is the
* parser -- fixed counts per record type is the protocol's one promise.
--]]
local function parseListing(parts)
    return {
        listingid = tonumber(parts[2]) or 0,
        name      = parts[3] or '?',
        mjob      = tonumber(parts[4]) or 0,
        mlvl      = tonumber(parts[5]) or 0,
        sjob      = tonumber(parts[6]) or 0,
        slvl      = tonumber(parts[7]) or 0,
        rate      = tonumber(parts[8]) or 0,
        maxhours  = tonumber(parts[9]) or 0,
        loadouts  = tonumber(parts[10]) or 0,
        flags     = tonumber(parts[11]) or 0,
        gear      = tonumber(parts[12]) or UNMEASURED,
        spells    = tonumber(parts[13]) or UNMEASURED,
        age       = tonumber(parts[14]) or UNMEASURED,
        hires     = tonumber(parts[15]) or UNMEASURED,
        remaining = tonumber(parts[16]) or UNMEASURED,
    };
end

--[[
* Merge a b| into the one listing table. Fields the response did not measure
* arrive as -1 and MUST NOT overwrite a measured copy -- that is the whole
* point of one shape for one thing. `remaining` is gated by flags bit 2 first
* (the protocol's own reading order): with the bit clear there is no contract,
* so any held countdown is cleared rather than left ticking at nothing.
--]]
local function mergeListing(rec)
    local entry = state.listings[rec.listingid];

    if (entry == nil) then
        entry = { listingid = rec.listingid };
        state.listings[rec.listingid] = entry;
    end

    entry.name     = rec.name;
    entry.mjob     = rec.mjob;
    entry.mlvl     = rec.mlvl;
    entry.sjob     = rec.sjob;
    entry.slvl     = rec.slvl;
    entry.rate     = rec.rate;
    entry.maxhours = rec.maxhours;
    entry.count    = rec.loadouts;
    entry.flags    = rec.flags;

    -- The jobs line is remembered on the entry (jobsText) and the four fields
    -- it is made of have just been rewritten, so it goes with them.
    entry.jobsLine = nil;

    if (rec.gear ~= UNMEASURED) then
        entry.gear = rec.gear;
    end

    if (rec.spells ~= UNMEASURED) then
        entry.spells = rec.spells;
    end

    if (rec.age ~= UNMEASURED) then
        entry.age = stamp(rec.age);
    end

    if (rec.hires ~= UNMEASURED) then
        entry.hires = rec.hires;
    end

    if (bit.band(rec.flags, LISTING_WORKING) == 0) then
        entry.remaining = nil;
    elseif (rec.remaining ~= UNMEASURED) then
        entry.remaining = stamp(rec.remaining);
    end

    return entry;
end

-- The l| overlay: the owner's own facts, kept on the same listing entry but
-- rendered only in the My mercs tab -- the split is the privacy line and this
-- client keeps it (dwm_protocol.md on l|).
local function mergeOverlay(parts)
    local listingid = tonumber(parts[2]) or 0;
    local entry     = state.listings[listingid];

    if (entry == nil) then
        return;
    end

    entry.pending = (tonumber(parts[3]) or 0) ~= 0;

    local earned = tonumber(parts[4]) or UNMEASURED;

    if (earned ~= UNMEASURED) then
        entry.earned = earned;
    end

    entry.hirer = (parts[5] ~= nil and parts[5] ~= '-' and parts[5] ~= '') and parts[5] or nil;
end

local function parseContract(parts)
    return {
        contractid = tonumber(parts[2]) or 0,
        listingid  = tonumber(parts[3]) or 0,
        name       = parts[4] or '?',
        hours      = tonumber(parts[5]) or 0,
        gross      = tonumber(parts[6]) or 0,
        bought     = tonumber(parts[7]) or 0,
        running    = tonumber(parts[8]) or UNMEASURED,
        remaining  = stamp(tonumber(parts[9]) or 0),
        state      = parts[10] or 'active',
    };
end

local function parseHire(parts)
    return {
        stage      = parts[2] or '?',
        listingid  = tonumber(parts[3]) or 0,
        name       = parts[4] or '?',
        hours      = tonumber(parts[5]) or 0,
        loadout    = tonumber(parts[6]) or 0,
        gross      = tonumber(parts[7]) or 0,
        gil        = tonumber(parts[8]) or 0,
        ends       = tonumber(parts[9]) or 0,
        expires    = tonumber(parts[10]) or 0,
        contractid = tonumber(parts[11]) or 0,
    };
end

--[[
* The hire dialog's state machine. Stages: pick -> quoting -> quoted ->
* paying -> done, with every failure path landing back on pick and the
* player's inputs intact. The only line `pick` can send is a quote, and the
* only line `quoted` can send is `!dwm confirm` -- the two are different
* buttons in different places, and the second cannot exist until the server
* has answered the first.
--]]
local function dialogKey(listingid, hours, ordinal)
    return string.format('%d|%d|%d', listingid, hours, ordinal);
end

--[[
* `hours` and `ordinal` are OPTIONAL and only ever a starting value for the
* inputs: nothing here is a price and nothing here gates anything, so the
* worst a wrong one can do is make a player change it before they ask for a
* quote. They exist because `Hire again` on the Contracts tab knows what the
* player bought last time, and offering that back is the whole of what "again"
* means (1.3.0). Clamped by the pick stage against the listing's own cap on
* the first frame, like anything typed into the box.
--]]
local function openDialog(listingid, hours, ordinal)
    local entry = state.listings[listingid];

    dialog = {
        listingid = listingid,
        name      = entry ~= nil and entry.name or '?',
        stage     = 'pick',
        stageAt   = os.clock(),
        hours     = T{ math.max(math.floor(tonumber(hours) or 1), 1) },
        ordinal   = math.max(math.floor(tonumber(ordinal) or 1), 1),
        quote     = nil,
        result    = nil,
        error     = nil,
    };

    state.selected = listingid;
end

--[[
* Could this exact purchase still land on an armed quote? True means a hire
* line for it must not be sent, because the server would read it as the
* confirming issue. The armed record comes from packet_out -- typed lines
* included -- and holds the raw typed name, which may be a prefix of the
* resolved one, so the name check matches either direction. A loadout token
* this client cannot resolve is treated as a match: when the lockout cannot
* tell, it locks.
--]]
local function matchesArmed(listingid, name, hours, ordinal)
    if (armedHire == nil or (os.clock() - armedHire.at) > ARMED_WINDOW) then
        return false;
    end

    if (armedHire.hours ~= hours) then
        return false;
    end

    local typed    = armedHire.name;
    local resolved = string.lower(name or '');

    if (typed ~= resolved and string.sub(resolved, 1, #typed) ~= typed) then
        return false;
    end

    local armedOrdinal;

    if (armedHire.loadout == nil) then
        armedOrdinal = 1;
    elseif (tonumber(armedHire.loadout) ~= nil) then
        armedOrdinal = tonumber(armedHire.loadout);
    else
        for index, label in pairs(state.loadouts[listingid] or {}) do
            if (string.lower(label) == armedHire.loadout) then
                armedOrdinal = index;
            end
        end
    end

    if (armedOrdinal == nil) then
        return true;
    end

    return armedOrdinal == ordinal;
end

local function armedSecondsLeft()
    if (armedHire == nil) then
        return 0;
    end

    return math.max(ARMED_WINDOW - (os.clock() - armedHire.at), 0);
end

--[[
* Envelope processing. Wholesale resets happen per verb -- a response replaces
* its own section outright, never merges with it -- with one deliberate
* exception: `call`, `dismiss` and `hire` replace the contracts pane only when
* they actually carried t| records, because a quote envelope carries none and
* must not blank a pane it did not re-describe.
--]]
local function processEnvelope(verb, records)
    local envelopeListings = {};
    local loadoutRows      = {};
    local gearRows         = {};
    local contractRows     = {};
    local boardMeta        = nil;
    local purse            = nil;
    local ledgerRows       = nil;
    local claimResult      = nil;
    local hireRecords      = {};
    local candidateRows    = nil;
    local setRows          = nil;
    local limitsRow        = nil;
    local battleRows       = {};
    local recordRows       = {};
    local battleLimits     = nil;
    local battleQuote      = nil;
    local fightRows        = {};

    for _, parts in ipairs(records) do
        local kind = parts[1];

        if (kind == 'b') then
            local rec = parseListing(parts);

            mergeListing(rec);
            table.insert(envelopeListings, rec.listingid);
        elseif (kind == 'l') then
            mergeOverlay(parts);
        elseif (kind == 'o') then
            local listingid = tonumber(parts[2]) or 0;
            local ordinal   = tonumber(parts[3]) or 0;

            loadoutRows[listingid] = loadoutRows[listingid] or {};
            loadoutRows[listingid][ordinal] = parts[4];
        elseif (kind == 'i') then
            -- A kit spans records, so pairs APPEND per listing within the
            -- envelope (dwm_protocol.md on i|) -- the wholesale replace
            -- happens once below, per listing the envelope described.
            local listingid = tonumber(parts[2]) or 0;

            gearRows[listingid] = gearRows[listingid] or {};

            for pair in string.gmatch(parts[3] or '', '([^,]+)') do
                local slot, itemid = string.match(pair, '^(%d+):(%d+)$');

                if (slot ~= nil) then
                    table.insert(gearRows[listingid], { slot = tonumber(slot), itemid = tonumber(itemid) });
                end
            end
        elseif (kind == 'k') then
            table.insert(battleRows, {
                battleid  = tonumber(parts[2]) or 0,
                state     = parts[3] or 'open',
                wager     = tonumber(parts[4]) or 0,
                a_name    = parts[5] or '-',
                a_listing = tonumber(parts[6]) or 0,
                a_ordinal = tonumber(parts[7]) or 0,
                b_name    = parts[8] or '-',
                b_listing = tonumber(parts[9]) or 0,
                b_ordinal = tonumber(parts[10]) or 0,
                fight_in  = tonumber(parts[11]) or -1,
                mine      = tonumber(parts[12]) or 0,
                online    = (tonumber(parts[13]) or 0) == 1,
                outcome   = parts[14] or 'none',
                reason    = parts[15] or '-',
                at        = os.clock(),
            });
        elseif (kind == 'r') then
            table.insert(recordRows, {
                rank   = tonumber(parts[2]) or 0,
                name   = parts[3] or '-',
                wins   = tonumber(parts[4]) or 0,
                losses = tonumber(parts[5]) or 0,
                draws  = tonumber(parts[6]) or 0,
                points = tonumber(parts[7]) or 0,
                mine   = (tonumber(parts[8]) or 0) == 1,
            });
        elseif (kind == 'x') then
            battleLimits = {
                minwager = tonumber(parts[2]) or -1,
                maxwager = tonumber(parts[3]) or -1,
                cutpct   = tonumber(parts[4]) or -1,
                call     = tonumber(parts[5]) or -1,
                duration = tonumber(parts[6]) or -1,
                purse    = tonumber(parts[7]) or 0,
                level    = tonumber(parts[8]) or 99,
            };
        elseif (kind == 'q') then
            battleQuote = {
                stage     = parts[2] or 'quote',
                kind      = parts[3] or 'register',
                battleid  = tonumber(parts[4]) or 0,
                listingid = tonumber(parts[5]) or 0,
                name      = parts[6] or '-',
                ordinal   = tonumber(parts[7]) or 0,
                wager     = tonumber(parts[8]) or 0,
                gil       = tonumber(parts[9]) or 0,
                expires   = tonumber(parts[10]) or 0,
                at        = os.clock(),
            };
        elseif (kind == 'f') then
            table.insert(fightRows, {
                battleid = tonumber(parts[2]) or 0,
                a_name   = parts[3] or '-',
                a_hpp    = tonumber(parts[4]) or 0,
                a_alive  = (tonumber(parts[5]) or 0) == 1,
                b_name   = parts[6] or '-',
                b_hpp    = tonumber(parts[7]) or 0,
                b_alive  = (tonumber(parts[8]) or 0) == 1,
                elapsed  = tonumber(parts[9]) or 0,
                left     = tonumber(parts[10]) or 0,
            });
        elseif (kind == 'g') then
            boardMeta = {
                page  = tonumber(parts[2]) or 1,
                pages = tonumber(parts[3]) or 1,
                total = tonumber(parts[4]) or 0,
                job   = tonumber(parts[5]) or 0,
            };
        elseif (kind == 't') then
            table.insert(contractRows, parseContract(parts));
        elseif (kind == 'w') then
            local sub = parts[2];

            if (sub == 'h') then
                purse = {
                    balance  = tonumber(parts[3]) or 0,
                    lifetime = tonumber(parts[4]) or 0,
                    rows     = tonumber(parts[5]) or UNMEASURED,
                };
            elseif (sub == 'r') then
                ledgerRows = ledgerRows or {};

                table.insert(ledgerRows, {
                    rowid      = tonumber(parts[3]) or 0,
                    contractid = tonumber(parts[4]) or 0,
                    amount     = tonumber(parts[5]) or 0,
                    gross      = tonumber(parts[6]) or 0,
                    tax        = tonumber(parts[7]) or 0,
                    merc       = (parts[8] ~= '-' and parts[8] ~= '') and parts[8] or nil,
                    hirer      = (parts[9] ~= '-' and parts[9] ~= '') and parts[9] or nil,
                    claimed    = (tonumber(parts[10]) or 0) ~= 0,
                    age        = stamp(tonumber(parts[11]) or 0),
                });
            elseif (sub == 'c') then
                claimResult = {
                    claimed = tonumber(parts[3]) or 0,
                    rows    = tonumber(parts[4]) or 0,
                    held    = tonumber(parts[5]) or 0,
                    capped  = (tonumber(parts[6]) or 0) ~= 0,
                };
            end
        elseif (kind == 'h') then
            table.insert(hireRecords, parseHire(parts));
        elseif (kind == 'n') then
            candidateRows = candidateRows or {};

            table.insert(candidateRows, {
                charid    = tonumber(parts[2]) or 0,
                name      = parts[3] or '?',
                mjob      = tonumber(parts[4]) or 0,
                mlvl      = tonumber(parts[5]) or 0,
                sjob      = tonumber(parts[6]) or 0,
                slvl      = tonumber(parts[7]) or 0,
                flags     = tonumber(parts[8]) or 0,
                listingid = tonumber(parts[9]) or 0,
            });
        elseif (kind == 's') then
            setRows = setRows or {};

            table.insert(setRows, {
                kind    = parts[2] or 'own',
                name    = parts[3] or '?',
                rules   = tonumber(parts[4]) or UNMEASURED,
                summary = (parts[5] ~= nil and parts[5] ~= '-') and parts[5] or nil,
            });
        elseif (kind == 'c') then
            limitsRow = {
                minrate  = tonumber(parts[2]) or UNMEASURED,
                maxrate  = tonumber(parts[3]) or UNMEASURED,
                maxhours = tonumber(parts[4]) or UNMEASURED,
                loadouts = tonumber(parts[5]) or MAX_LOADOUTS,
                tax      = tonumber(parts[6]) or UNMEASURED,
            };
        end
    end

    -- Loadout names replace per listing, and only for listings this envelope
    -- named -- the o| dedup means a t| for a listing already described sends
    -- no group, and clearing on its behalf would lose the names.
    for listingid, names in pairs(loadoutRows) do
        state.loadouts[listingid] = names;
    end

    -- The frozen kit, same arrangement: replaced per listing the envelope
    -- measured, kept for every listing it did not.
    for listingid, pieces in pairs(gearRows) do
        local entry = state.listings[listingid];

        if (entry ~= nil) then
            entry.gearlist = pieces;

            -- The display lines cached off the OLD gear go with them, and the
            -- ids beside them. Nothing else in this file writes gearlist, so
            -- this is the whole of the kit cache's invalidation.
            entry.kit    = nil;
            entry.kitIds = nil;
        end
    end

    if (verb == 'board' and boardMeta ~= nil) then
        -- THE ANSWER MUST BE THE ONE ASKED FOR (the 2026-08-09 review's first
        -- backlog item). The g| record carries the job and page the server
        -- answered; the ask's qualifier is `job:page`. A slow answer to an
        -- OLDER ask -- the filter changed while it was in flight -- used to
        -- land here, replace the board, and leave the pane on "Fetching the
        -- board..." for good: the d| had already marked the current ask
        -- answered, so nothing ever re-asked. Now a board that is not the one
        -- asked for is dropped and the ask is put back to unanswered, so
        -- need() re-asks on its clock (bounded by ANSWER_TRIES as always).
        local asked   = requested['board'];
        local arrived = string.format('%d:%d', boardMeta.job or 0, boardMeta.page or 1);

        if (asked ~= nil and asked.qualifier ~= arrived) then
            asked.answered = false;

            --[[
            * A PAGE PAST THE END OF THE BOARD IS NOT A STALE ANSWER, IT IS
            * THE ANSWER (2026-09-06). cpp/merc_store.cpp clamps -- `current =
            * min(wanted, pages)` -- so asking for page 2 of a board that has
            * shrunk to one page answers `g|1|1|...`, which the guard above
            * correctly reads as "not the page I asked for" and drops. Nothing
            * then moved the pager back, so the ask was re-issued to
            * ANSWER_TRIES and stopped, and the pane sat on "Fetching the
            * board..." for good. Worse after a zone: the board is emptied by
            * the login packet, so the pager is not drawn either and there was
            * nothing on screen to climb back with.
            *
            * The board is still dropped -- it is genuinely not what was asked
            * for -- but the page the server DID serve is recorded, and the
            * pager snaps to it on the next frame and asks again for a page
            * that exists.
            --]]
            local askedJob, askedPage = string.match(asked.qualifier or '', '^(%d+):(%d+)$');

            if (askedJob ~= nil and tonumber(askedJob) == (boardMeta.job or 0)
                    and tonumber(askedPage) > math.max(boardMeta.pages or 1, 1)) then
                state.boardPage = math.max(boardMeta.pages or 1, 1);
            end
        else
            boardMeta.rows = envelopeListings;
            state.board    = boardMeta;
        end
    end

    -- Every b| on these envelopes is one of the account's own listings, and
    -- each of them describes the whole shelf -- so the list is replaced rather
    -- than merged.
    if (verb == 'merc' or verb == 'listings' or verb == 'unlist' or verb == 'options') then
        state.mine = envelopeListings;
    elseif (verb == 'list') then
        -- EXCEPT `list`, WHICH ANSWERS WITH THE ONE LISTING IT JUST FROZE.
        -- Replacing here would empty the My mercs tab down to whichever
        -- character was published last -- harmless while nothing but a typed
        -- line could reach this verb (a typed !merc re-asks everything), and a
        -- real bug the moment the Listing tab's button sends one.
        local seen = {};

        for _, listingid in ipairs(state.mine) do
            seen[listingid] = true;
        end

        for _, listingid in ipairs(envelopeListings) do
            if (not seen[listingid]) then
                table.insert(state.mine, listingid);
            end
        end

        --[[
        * AND `list` IS THE ONE VERB THAT REPLACES A PHOTOGRAPH (2026-09-06).
        * Its answer carries the new counts and the new age but no i| records
        * -- gear is sent by `info` alone -- so the kit held from the previous
        * measurement survived, and the pane read "Frozen just now: 1 piece of
        * gear" over a list of the fourteen pieces that were frozen yesterday.
        * The gear goes with the photograph it belonged to, and the info ask
        * is retired so the pane measures the new one instead of sitting on an
        * answer that is no longer about anything.
        --]]
        for _, listingid in ipairs(envelopeListings) do
            local entry = state.listings[listingid];

            if (entry ~= nil) then
                entry.gearlist = nil;
                entry.kit      = nil;
                entry.kitIds   = nil;
            end

            local asked = requested['info'];

            if (asked ~= nil and asked.qualifier == listingid) then
                requested['info'] = nil;
            end
        end
    end

    -- The listing form's own sections, each replaced outright by the verb that
    -- owns it. Guarded on the verb rather than on "did any arrive", because an
    -- account with no rule sets of its own and no characters left to list is a
    -- real answer and has to be able to empty these.
    if (verb == 'options') then
        state.candidates = candidateRows or {};
        state.sets       = setRows or {};
        state.setsByName = {};

        -- The picker's name lookup, built once with the answer that owns it
        -- rather than scanned per slot per frame (knownSet).
        for _, row in ipairs(state.sets) do
            state.setsByName[string.lower(row.name or '')] = row;
        end

        if (limitsRow ~= nil) then
            state.limits = limitsRow;
        end
    end

    if (verb == 'merc' or verb == 'contracts') then
        state.contracts = { active = {}, recent = {} };
    elseif ((verb == 'call' or verb == 'dismiss' or verb == 'hire' or verb == 'release') and #contractRows > 0) then
        state.contracts = { active = {}, recent = {} };
    end

    if (#contractRows > 0 or verb == 'merc' or verb == 'contracts') then
        for _, entry in ipairs(contractRows) do
            if (entry.state == 'active') then
                table.insert(state.contracts.active, entry);
            else
                table.insert(state.contracts.recent, entry);
            end
        end

        -- A call or dismiss that has answered is no longer in flight, and any
        -- envelope carrying t| records IS that answer -- the verbs answer with
        -- the state they produced rather than with news about it. Cleared
        -- wholesale because the ids in the flight table are exactly the rows
        -- this envelope just rebuilt.
        actPending = {};
    end

    if (purse ~= nil) then
        state.purse = { balance = purse.balance, lifetime = purse.lifetime };
    end

    if (verb == 'earnings') then
        state.ledger = ledgerRows or {};
    end

    -- A write that has answered is a write that is no longer in flight. Both
    -- verbs answer with the state they produced, so the envelope IS the
    -- refresh and the form needs no re-ask of its own.
    if (verb == 'list' or verb == 'unlist') then
        writePending = nil;

        if (form ~= nil) then
            form.confirm = nil;
            form.error   = nil;
        end
    end

    if (claimResult ~= nil) then
        state.claim   = claimResult;
        claimPending  = nil;
        claimTimedOut = false;

        -- What a claim moved changes what listings and earnings show; the
        -- panes re-ask on their next frame.
        if (state.purse ~= nil) then
            state.purse.balance = claimResult.held;
        end

        requested['listings'] = nil;
        requested['earnings'] = nil;
    end

    -- The hire dialog's transitions. The h| record is matched by listing id,
    -- and everything the quoted stage displays comes from it -- never from
    -- this file's own arithmetic.
    for _, rec in ipairs(hireRecords) do
        if (rec.stage == 'quote') then
            -- Held whether or not a dialog is watching: a quote is a fact
            -- about an armed window, and the window outlives a closed dialog.
            rec.key = dialogKey(rec.listingid, rec.hours, rec.loadout);
            rec.at  = os.clock();

            heldQuote = rec;
        elseif (rec.stage == 'hired') then
            -- The listing just left the open market, and the board and info
            -- panes are showing the world from before the purchase -- the
            -- owner's first pass found Mars still listed until a manual
            -- Refresh. Their asks are forgotten so the next frame re-asks.
            requested['board'] = nil;
            requested['info']  = nil;

            -- The quote is spent with the purchase: held past this point, a
            -- re-opened dialog on the same listing/hours inside the quote's
            -- window jumped straight to a live Pay button for a contract the
            -- player already owns.
            heldQuote = nil;
        end

        if (dialog ~= nil and rec.listingid == dialog.listingid) then
            if (rec.stage == 'quote') then
                dialog.quote = rec;

                if (dialog.stage == 'quoting') then
                    dialog.stage   = 'quoted';
                    dialog.stageAt = os.clock();
                    dialog.error   = nil;
                end
            elseif (rec.stage == 'hired') then
                dialog.stage   = 'done';
                dialog.stageAt = os.clock();
                dialog.result  = rec;
                dialog.error   = nil;
            end
        end
    end

    --[[
    * A hire envelope that closed on a waiting dialog without delivering its
    * record: the refusal sentence (if any) arrived as e| and was shown; the
    * stage must not sit on a spinner forever.
    *
    * UNLESS THE ENVELOPE DESCRIBED SOMEBODY ELSE'S PURCHASE (2026-09-06). Two
    * dialogs cannot be open at once but two quote lines can be in the queue --
    * quote one listing, cancel, quote another -- and the answer to the FIRST
    * used to knock the dialog waiting on the second back to `pick` with no
    * error at all. The spinner vanished on an ask that was still perfectly
    * alive, and the player clicked again for nothing. An h| for a listing this
    * dialog is not about is not this dialog's silence; the 8-second stage
    * clock below is what covers real silence.
    --]]
    local foreignHire = false;

    if (dialog ~= nil) then
        for _, rec in ipairs(hireRecords) do
            if (rec.listingid ~= dialog.listingid) then
                foreignHire = true;
            end
        end
    end

    if (verb == 'hire' and dialog ~= nil and not foreignHire) then
        if (dialog.stage == 'quoting' and dialog.quote == nil) then
            dialog.stage   = 'pick';
            dialog.stageAt = os.clock();
        elseif (dialog.stage == 'paying' and dialog.result == nil) then
            dialog.stage   = 'pick';
            dialog.stageAt = os.clock();
            dialog.error   = dialog.error or 'The purchase did not go through. Nothing further was charged.';
        end
    end

    --[[
    * The Board tab's name lookup, resolved. `info` answers for whatever the
    * store matched the typed name to -- exactly, then by unambiguous prefix --
    * so the listing this envelope described becomes the selection and the
    * info pane draws it.
    *
    * MATCHED BY NAME AND NOT JUST BY "an info arrived": the ordinary
    * selection ask uses the same verb, and a routine answer landing while a
    * lookup was outstanding would otherwise capture the wrong listing. The
    * ask is marked answered as it is adopted, so the pane does not turn round
    * and re-ask for a listing it was just handed.
    --]]
    if (verb == 'info' and state.lookupWant ~= nil) then
        local wanted = state.lookupWant.name;

        for _, listingid in ipairs(envelopeListings) do
            local listed = state.listings[listingid];
            local lower  = (listed ~= nil and listed.name ~= nil) and string.lower(listed.name) or '';

            if (string.sub(lower, 1, #wanted) == wanted) then
                state.selected    = listingid;
                state.lookupWant  = nil;
                requested['info'] = { qualifier = listingid, at = os.clock(), answered = true, tries = 1 };

                break;
            end
        end
    end

    -- The Listing tab joins a character to a listing by name where the
    -- protocol's own join (n|'s listingid) has not caught up -- a character
    -- listed since `options` last answered carries 0 there. Rebuilt here,
    -- once per envelope, rather than walked per candidate per frame: it is
    -- cheap at this end (the shelf is one listing per character) and it was
    -- hundreds of string allocations a second at the other.
    -- The Battle tab's envelopes. `battle` owns the board (live and recent),
    -- `records` the ladder, a q| the quote whatever envelope carried it, and
    -- a bstatus the fights. A confirmation or a withdrawal changes what the
    -- board and the ladder show, so their asks are forgotten and the panes
    -- re-ask on their next frame -- the same shape as a hire.
    if (verb == 'battle') then
        local live   = {};
        local recent = {};

        for _, row in ipairs(battleRows) do
            if (row.state == 'settled' or row.state == 'void') then
                table.insert(recent, row);
            else
                table.insert(live, row);
            end
        end

        state.battle = {
            limits = battleLimits or (state.battle ~= nil and state.battle.limits or nil),
            live   = live,
            recent = recent,
            at     = os.clock(),
        };
    end

    if (verb == 'records') then
        state.records = {
            page  = boardMeta ~= nil and boardMeta.page or 1,
            pages = boardMeta ~= nil and boardMeta.pages or 1,
            total = boardMeta ~= nil and boardMeta.total or #recordRows,
            rows  = recordRows,
        };
    end

    if (battleQuote ~= nil) then
        state.bquote = battleQuote;

        if (bform ~= nil and battleQuote.kind == bform.kind) then
            if (battleQuote.stage == 'quote' and bform.stage == 'quoting') then
                bform.stage   = 'quoted';
                bform.stageAt = os.clock();
                bform.error   = nil;
            elseif (battleQuote.stage == 'posted') then
                bform.stage   = 'done';
                bform.stageAt = os.clock();
                bform.error   = nil;
            end
        end
    end

    if (verb == 'bconfirm' or verb == 'bwithdraw') then
        requested['battle']   = nil;
        requested['records']  = nil;
        requested['listings'] = nil;
        battlePending         = nil;
    end

    if (verb == 'bquote' and bform ~= nil and bform.stage == 'quoting' and battleQuote == nil) then
        -- A quote envelope that closed without its record: the refusal came
        -- as e| and is on the form already; the stage must not sit on a
        -- spinner.
        bform.stage   = 'pick';
        bform.stageAt = os.clock();
    end

    if (verb == 'bstatus') then
        state.fights = {};

        for _, row in ipairs(fightRows) do
            state.fights[row.battleid] = row;
        end

        state.fightsAt = os.clock();
    end

    state.mineByName = {};

    for _, listingid in ipairs(state.mine) do
        local listed = state.listings[listingid];

        if (listed ~= nil and listed.name ~= nil) then
            state.mineByName[string.lower(listed.name)] = listed;
        end
    end

    -- An answer that WORKED retires a refusal the player has had time to read.
    -- The `status` envelope is excluded by name because it is never an answer
    -- that worked -- it is the wrapper a bare refusal arrives in.
    if (state.statusBad and verb ~= 'status'
            and elapsed(state.statusAt or 0) > STATUS_DWELL) then
        state.status    = '';
        state.statusBad = false;
        state.statusAt  = os.clock();
    end

    answered(verb);
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwmerc.', version, PROTOCOL);
            state.statusBad = true;
            state.statusAt  = os.clock();
            state.inbound   = nil;

            -- A d| envelope IS the answer, whatever version it announced, and
            -- re-asking a server that speaks a layout this addon cannot read
            -- cannot help. One shape across the suite (dwfame, 2026-08-15);
            -- gated in harness_dwsuite.py.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.inbound = parts[3];
        state.buffer  = {};

        return;
    end

    -- Status lines land whatever the envelope state -- they are the one thing
    -- a player must never lose -- and a refusal also has to reach the dialog
    -- before its next frame renders a spinner over a dead purchase.
    if (kind == 'm' or kind == 'e') then
        -- The one refusal that is not worth a red banner: a server from
        -- before the quote-only verb answering with its unknown-verb
        -- sentence. The dialog falls back to the guarded hire path and asks
        -- once more on the next click -- deployment order must not matter in
        -- either direction (the dwbags arrangement).
        if (kind == 'e' and not quoteUnsupported
                and string.find(line, 'no mercenary command called "quote"', 1, true) ~= nil) then
            quoteUnsupported = true;

            -- The refused line armed nothing, so the lockout it stamped on
            -- the way out is a lock on a window that never opened.
            armedHire = nil;

            if (dialog ~= nil and dialog.stage == 'quoting') then
                dialog.stage   = 'pick';
                dialog.stageAt = os.clock();
                dialog.error   = 'This server is older than this window -- click once more to ask the older way.';
            end

            return;
        end

        -- The Listing tab's own version of the same fallback, and it is not
        -- worth a red banner either: the tab prints the typed line and gets on
        -- with it. Reset on every login line, so deployment order cannot matter
        -- in either direction.
        if (kind == 'e' and not optionsUnsupported
                and string.find(line, 'no mercenary command called "options"', 1, true) ~= nil) then
            optionsUnsupported = true;

            return;
        end

        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');
        state.statusAt  = os.clock();

        if (kind == 'e') then
            print(chat.header('dwmerc'):append(chat.error(state.status)));

            claimPending  = nil;
            claimTimedOut = false;

            -- A refused call or dismiss answers with a sentence and no t|
            -- records, so the row's flight latch has to come off here or the
            -- button reads "calling..." until its own timeout.
            actPending    = {};

            -- The refused line was a list or an unlist: nothing was frozen and
            -- nothing came off the board, the sentence above says which, and
            -- the form keeps every input so it can be fixed and sent again.
            if (writePending ~= nil) then
                writePending = nil;

                if (form ~= nil) then
                    form.error = state.status;
                end
            end

            -- The Battle tab's form: a refusal lands on it and it goes back
            -- to picking, whichever stage it was in. Nothing was spent on a
            -- refused quote; a refused confirm was refunded by the server
            -- before it answered.
            if (bform ~= nil) then
                bform.error = state.status;

                if (bform.stage == 'quoting' or bform.stage == 'paying') then
                    bform.stage   = 'pick';
                    bform.stageAt = os.clock();
                end

                battlePending = nil;
            end

            if (dialog ~= nil) then
                if (dialog.stage == 'quoting') then
                    -- The hire line was refused, so no quote was armed --
                    -- clearing the lockout is what lets the player fix the
                    -- input and ask again without serving out a window that
                    -- never opened.
                    armedHire = nil;

                    dialog.stage   = 'pick';
                    dialog.stageAt = os.clock();
                    dialog.error   = state.status;
                elseif (dialog.stage == 'paying') then
                    dialog.stage   = 'pick';
                    dialog.stageAt = os.clock();
                    dialog.error   = state.status;
                end
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local verb    = state.inbound;
        local records = state.buffer;

        state.inbound = nil;
        state.buffer  = {};

        processEnvelope(verb, records);

        return;
    end

    table.insert(state.buffer, parts);
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWMDATA is ours: consumed and blocked before parsing, so a
* malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwmerc_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwmerc'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering.
--]]

-- Per-widget scratch. PLAIN tables keyed by strings the code chooses -- T{}'s
-- sugar metatable answers unknown string keys with functions.
local buffers = {};

local function bufferOf(id, initial)
    if (buffers[id] == nil) then
        buffers[id] = T{ initial };
    end

    return buffers[id];
end

local function tooltipOnHover(text)
    if (text ~= nil and text ~= '' and imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end


--[[
* Column widths, MEASURED RATHER THAN GUESSED (2026-09-06).
*
* Every table in this window was laid out in round pixel numbers, and the
* numbers were too small for the values the wire can carry. A character name
* is up to 15 characters and the Mercenary column was 110; a published loadout
* name is up to 24 (dw_merc_loadouts.name) and the Fighting by column was 170;
* the rate ceiling is a seven-figure number and Gil / h was 75. The Listing
* tab's own comments record the same lesson being learned twice by hand ("128:
* the widest live pair is a two-digit main and a two-digit sub, which 95
* clipped the sub level off"), which is the tell that it should not have been
* hand arithmetic at all.
*
* dwah's tables settled this: ask the font. `pad` is ImGui's cell padding
* either side plus a little room for a header wider than its content.
--]]
local function columnWidth(sample, pad)
    local width = imgui.CalcTextSize(sample or '');

    return math.ceil(math.max(width, 1) + (pad or 12));
end

-- The widest values this protocol can actually carry, as samples to measure.
-- Named rather than inlined because three tables want the same answer and a
-- fourth would otherwise invent its own.
local WIDEST_NAME    = 'Mmmmmmmmmmmmmmm';               -- 15, the game's ceiling
local WIDEST_LOADOUT = 'Mmmmmmmmmmmmmmmmmmmmmmmm';      -- 24, dw_merc_loadouts.name
local WIDEST_JOBS    = 'WHM99/RDM49';
local WIDEST_GIL     = '10,000,000';
local WIDEST_SPAN    = '~23h 59m';

--[[
* ImGui's own furniture around a table drawn inside a bordered child: the cell
* padding either side of every column, the child's window padding, and room
* for the vertical scroll bar. These are ImGui's defaults; dwtheme pushes only
* rounding and a border size, so nothing in this suite moves them.
*
* This is what the two hand-tuned child widths in this file were groping for --
* the Listing tab's comment says "385 so the three columns below fit inside it:
* at 330 the table was wider than its own child, which clipped the right-hand
* status text mid-word". Same sum, arrived at rather than discovered.
--]]
local CELL_PADDING   = 8;
local CHILD_PADDING  = 16;
local SCROLLBAR_ROOM = 16;

local function childWidthFor(columns, widths)
    local total = CHILD_PADDING + SCROLLBAR_ROOM + (columns * CELL_PADDING);

    for _, width in ipairs(widths) do
        total = total + width;
    end

    return math.ceil(total);
end

-- A scrolling table's height in whole rows, header included, so a long list
-- scrolls inside itself instead of pushing the controls under it off a window
-- that is told not to draw a scroll bar of its own.
local function rowsHeight(rows, cap)
    return ((math.min(rows, cap or 8) + 1) * imgui.GetTextLineHeightWithSpacing()) + CELL_PADDING;
end

--[[
* The fixed tooltips, in one table (2026-09-06).
*
* One short sentence saying what a control DOES, and for anything greyed, why
* it cannot right now -- the suite's shape, and dwcpx's TIPS table is where it
* is written down. The tips that quote a name or a number are built where they
* are drawn and are not in here; everything a player could hover and not
* understand is.
*
* WHAT THEY MAY NOT DO is restate a rule as if this window enforced it. The
* server owns every price, gate and cap and re-checks all of them on every
* call, so a tip explains what the button will ASK for, never what the answer
* will be.
--]]
local TIPS =
{
    tabBattle   = 'The arena: one listed mercenary against another, 1v1, in Ru\'Lude Gardens, for a wager.\nYou watch; the rule set you published does the fighting.',
    dareRow     = 'A dare: this mercenary, at this wager, waiting for a challenger. Challenge it with one of your own\nlisted mercenaries and the fight is five minutes later, in Ru\'Lude Gardens -- both owners must be there.',
    darePost    = 'Post a dare with one of your listed mercenaries. It must be frozen at 99/99 and fight by a rule set\nyou wrote; the wager is taken when you confirm and returned if nobody answers and you withdraw.',
    dareQuote   = 'Asks the server for a quote. Nothing is spent by this button.',
    dareConfirm = 'The same thing as typing: !merc battle confirm. THIS is the button that takes the wager.',
    dareAway    = 'The owner of this mercenary is not online, and a contestant fights only with its owner in the arena.',
    dareWithdraw = 'Take an unanswered dare back. The wager comes back with it.',
    hall        = 'The Hall of Records: every contestant that ever registered, wins, losses, draws and points\n(a win is 3, a draw is 1). Registering writes a 0/0/0 line the moment it happens.',
    fight       = 'A fight under way. HP is a percentage; both standing when the clock runs out is a draw.',
    refresh  = 'Throws away every answer on screen and asks the server again. Reads only -- Refresh cannot spend anything.',
    commands = 'Every !merc command, and what each one does.',
    queued   = 'Lines waiting on the client\'s own chat limit. One goes out every 1.2 seconds, and a purchase jumps the reads.',
    status   = 'The last thing the server said. Red is a refusal, and the same sentence is in your chat log.',

    tabBoard    = 'Who is for hire right now, and the whole of whichever listing you click.',
    tabContract = 'What you are paying for: call them into your party, send them home, or hire one again.',
    tabMine     = 'The lister\'s side -- what you have up, what each has earned, and the ledger it is waiting on.',
    tabListing  = 'Put a character of your own up for hire, change what it asks, or take it off the board.',

    jobFilter = 'Shows only mercenaries whose MAIN job is this one. The board pages either way.',
    prevPage  = 'The page before this one.',
    nextPage  = 'The page after this one.',
    boardRow  = 'Reads the whole listing: the frozen gear piece by piece, the spell count, and how old the photograph is.',
    lookup    = 'Finds a mercenary by name wherever they are on the board, without paging to them.\nThe same thing as: !merc info <name>',
    lookupGo  = 'Asks the server about that name. Reads only, and spends nothing.',

    markYours   = 'One of yours. Hiring your own listing is refused -- it would only pay the house.',
    markWorking = 'Under contract to somebody else. It comes back on the board when that contract settles.',
    markOff     = 'Withdrawn by its owner. The snapshot survives a withdrawal, so it can go back up.',

    frozen  = 'A listing is a photograph of a character taken at the moment it was listed. What is frozen is exactly what you get, and nothing the owner does afterwards changes it.',
    hours   = 'Whole hours, paid in full up front. The contract runs from the moment you pay, whether you summon them or not.',
    loadout = 'Which published rule set they fight by. You pick at the summon and a re-call changes it; you cannot edit any of them.',
    cancel  = 'Closes this and sends nothing. Nothing has been charged.',

    timeLeft = 'What the server said was left when it last answered, run down here for display. The server\'s clock is the one that decides.',
    paid     = 'What this contract cost, in full, when it was bought. Contracts are not refundable.',
    atHome   = 'Bought and not summoned. The hours are running either way.',
    finished = 'The hours you booked are up. Nothing failed -- the contract simply ended.',
    hireAgain = 'Opens the hire dialog again, at the hours and the loadout this contract bought.\nNothing is charged without a quoted price and a second click.',

    purse  = 'What your listings have earned and nobody has collected yet. It waits safely on the ledger until a character on this account claims it.',
    ledger = 'Every settled contract, newest first: what the hirer paid, what the house took and what reached you. The cut is a server setting rather than a fixed figure, which is why all three are shown.',
    totals = 'The rows above, added up. At most twenty rows arrive, so this is the recent picture; the line above it carries the lifetime figure.',
    earned = 'Lifetime net for this listing -- after the house cut, which the Earnings rows show in full.',

    rate      = 'What one hour of this mercenary costs a hirer. The server owns the floor and the ceiling and refuses anything outside them.',
    candidate = 'Pick one of your characters to put up, re-freeze at new numbers, or take off the board.',
    illustration = 'An illustration, not a quote. The settlement does the real sum, at whatever the house cut is on the day the contract ends.',
};

-- The client's own words for an item, read once per id. The wire carries ids
-- only (the dwbags rule), so the name and the description are both ours to
-- find -- and a snapshot is the product, which makes "what is this piece"
-- a question the storefront owes an answer to.
--
-- Bounded by the item table the way dwah's name cache is, and dropped on the
-- login packet with the rest of the session's caches: the DAT does not change
-- under a running client, so this is a bound rather than an invalidation.
local itemDescriptions = {};

local function itemDescription(itemid)
    if (itemDescriptions[itemid] ~= nil) then
        return itemDescriptions[itemid].text;
    end

    local held = { text = nil };

    pcall(function ()
        local item = AshitaCore:GetResourceManager():GetItemById(itemid);

        if (item ~= nil and item.Description ~= nil
                and type(item.Description[1]) == 'string' and #item.Description[1] > 0) then
            held.text = item.Description[1];
        end
    end);

    itemDescriptions[itemid] = held;

    return held.text;
end

-- The hover card for one frozen piece of gear: the client's name for it and
-- the client's own description, the way dwtoau and dwah draw theirs.
local function itemCard(itemid)
    imgui.BeginTooltip();
    imgui.Text(itemName(itemid));

    local desc = itemDescription(itemid);

    if (desc ~= nil) then
        imgui.TextWrapped(desc);
    else
        imgui.TextDisabled('(no description in the client\'s item data)');
    end

    imgui.EndTooltip();
end

local function statusOf(entry)
    if (bit.band(entry.flags or 0, LISTING_MINE) ~= 0) then
        return 'yours';
    end

    if (bit.band(entry.flags or 0, LISTING_OFF) ~= 0) then
        return 'off the board';
    end

    if (bit.band(entry.flags or 0, LISTING_WORKING) ~= 0) then
        return 'working';
    end

    return 'open';
end

--[[
* The hire dialog, drawn in place of the info pane while it is open. See the
* state-machine comment above for the shape; the load-bearing properties are
* that `pick` sends only a quote (and not even that, when the lockout says the
* line could confirm instead), that Pay does not exist until the server's
* quote is on screen, and that Pay is `!dwm confirm` -- a line that can never
* quote, sitting in a different place from the button that did.
--]]
local function hireDialog()
    local entry = state.listings[dialog.listingid];

    imgui.TextColored(COLOR_BADGE, string.format('Hiring %s', dialog.name));

    if (entry ~= nil) then
        imgui.TextDisabled(string.format('%s -- %s gil an hour, contracts up to %dh.',
            jobsText(entry), gilText(entry.rate), entry.maxhours or 0));
    end

    imgui.Separator();

    if (dialog.error ~= nil) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_ERROR, dialog.error);
        imgui.PopTextWrapPos();
    end

    if (dialog.stage == 'pick' or dialog.stage == 'quoting') then
        local cap = entry ~= nil and math.max(entry.maxhours or 1, 1) or 24;

        imgui.Text('Hours');
        tooltipOnHover(TIPS.hours);
        imgui.SameLine();
        imgui.PushItemWidth(90);
        imgui.InputInt('##dwm_hours', dialog.hours, 1, 1);
        imgui.PopItemWidth();
        tooltipOnHover(string.format('%s\n\nThis listing takes up to %dh in one contract.', TIPS.hours, cap));

        -- Clamped every frame AND at send: InputInt takes any integer it is
        -- given, including negative ones (the dwbags quantity lesson).
        local hours = math.floor(tonumber(dialog.hours[1]) or 1);

        hours = math.max(math.min(hours, cap), 1);
        dialog.hours[1] = hours;

        local published = loadoutCount(dialog.listingid);

        if (published > 1) then
            if (dialog.ordinal > published) then
                dialog.ordinal = 1;
            end

            imgui.SameLine();
            imgui.Text('Fights by');
            imgui.SameLine();
            -- Sized from the widest published loadout name the store allows
            -- (24 characters), not from a round number that cut a real one in
            -- half in the picker a hirer chooses the product with.
            imgui.PushItemWidth(columnWidth(WIDEST_LOADOUT, 40));

            if (imgui.BeginCombo('##dwm_loadout', loadoutName(dialog.listingid, dialog.ordinal))) then
                for ordinal = 1, published do
                    if (imgui.Selectable(string.format('%s##dwm_lo_%d', loadoutName(dialog.listingid, ordinal), ordinal),
                            dialog.ordinal == ordinal)) then
                        dialog.ordinal = ordinal;
                    end
                end

                imgui.EndCombo();
            end

            imgui.PopItemWidth();
            tooltipOnHover(TIPS.loadout);
        elseif (published == 1) then
            imgui.SameLine();
            imgui.TextDisabled(string.format('Fights by %s.', loadoutName(dialog.listingid, 1)));
        end

        imgui.Spacing();
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled('The server quotes the price first. Nothing is charged until you press Pay on that quote.');
        imgui.PopTextWrapPos();
        imgui.Spacing();

        if (dialog.stage == 'quoting') then
            imgui.TextDisabled('Asking the server for the price...');

            -- A quote that never answers must not hold the dialog hostage;
            -- nothing was charged either way, and the ask is NOT re-sent.
            if (os.clock() - dialog.stageAt > 8.0) then
                dialog.stage   = 'pick';
                dialog.stageAt = os.clock();
                dialog.error   = 'No answer from the server. Nothing was charged -- ask again.';
            end
        elseif (heldQuote ~= nil and heldQuote.listingid == dialog.listingid
                and heldQuote.key == dialogKey(dialog.listingid, hours, dialog.ordinal)
                and (os.clock() - heldQuote.at) < (heldQuote.expires - QUOTE_MARGIN)) then
            -- This exact purchase was quoted moments ago and the quote is
            -- still good -- show it rather than asking the server again.
            dialog.quote   = heldQuote;
            dialog.stage   = 'quoted';
            dialog.stageAt = os.clock();
        elseif (quoteUnsupported and matchesArmed(dialog.listingid, dialog.name, hours, dialog.ordinal)) then
            -- The fallback path's sharp edge, guarded: on a server without
            -- the quote verb this asks through `hire`, and that line
            -- re-issued into its own armed window IS the purchase -- so with
            -- no fresh quote to show, the button waits the window out.
            imgui.TextDisabled(string.format('That exact quote was just asked for -- again in %ds.',
                math.ceil(armedSecondsLeft())));
            tooltipOnHover('Asking twice for the same quote inside its window would be read as the purchase,\nso the button waits it out. !merc confirm (typed) pays it on purpose.');
        else
            if (imgui.Button('Request quote##dwm_quote')) then
                dialog.quote   = nil;
                dialog.stage   = 'quoting';
                dialog.stageAt = os.clock();
                dialog.error   = nil;

                -- `quote` can never spend, whatever this client has
                -- forgotten -- a reload inside the window made the fallback
                -- line below buy on what looked like a first click, which is
                -- why the verb exists (dwm_protocol.md, No line buys
                -- anything). The guarded `hire` form stays only for servers
                -- from before it.
                issueWrite(string.format('!dwm %s %s %d %d',
                    quoteUnsupported and 'hire' or 'quote', dialog.name, hours, dialog.ordinal));
            end

            tooltipOnHover('Asks the server what this contract costs. Spends nothing.');
        end
    elseif (dialog.stage == 'quoted') then
        local quote = dialog.quote;

        -- Inputs changed under the quote: it no longer describes what the
        -- player is asking for, so back to pick -- the quote itself is kept
        -- for the lockout's reuse check.
        local hours = math.floor(tonumber(dialog.hours[1]) or 1);

        if (quote.key ~= dialogKey(dialog.listingid, hours, dialog.ordinal)) then
            dialog.stage   = 'pick';
            dialog.stageAt = os.clock();
        else
            local left = quote.expires - (os.clock() - quote.at);

            if (left <= QUOTE_MARGIN) then
                dialog.stage   = 'pick';
                dialog.stageAt = os.clock();
                dialog.error   = 'The quote expired -- ask again and the price will be fresh.';
            else
                -- Everything below comes off the h| record: the resolved
                -- name, the server's gross, the server's durations.
                imgui.PushTextWrapPos(0);
                imgui.Text(string.format('%s for %d %s, fighting by %s.',
                    quote.name, quote.hours, quote.hours == 1 and 'hour' or 'hours',
                    loadoutName(quote.listingid, quote.loadout)));
                imgui.TextColored(COLOR_WARN, string.format('%s gil, paid now, not refundable.', gilText(quote.gross)));
                imgui.Text(string.format('Runs %s from the moment you pay -- until about %s, your clock.',
                    spanText(quote.ends), os.date('%H:%M', os.time() + quote.ends)));
                imgui.TextDisabled(string.format('You are carrying %s gil.', gilText(quote.gil)));
                imgui.PopTextWrapPos();
                imgui.Spacing();

                if (quote.gil < quote.gross) then
                    imgui.TextColored(COLOR_ERROR, string.format('That is %s gil short, so this one is not affordable yet.',
                        gilText(quote.gross - quote.gil)));
                else
                    -- The deliberate second click. It cannot exist until the
                    -- server has answered the first, so no double-click can
                    -- reach it -- and the line it sends can only confirm.
                    if (imgui.Button(string.format('Pay %s gil -- hire %s##dwm_pay', gilText(quote.gross), quote.name))) then
                        dialog.stage   = 'paying';
                        dialog.stageAt = os.clock();
                        dialog.error   = nil;

                        issueWrite('!dwm confirm');
                    end

                    tooltipOnHover('The same thing as typing: !merc confirm');
                end

                imgui.TextDisabled(string.format('This quote is good for another %ds.', math.floor(left)));
            end
        end
    elseif (dialog.stage == 'paying') then
        imgui.Text('Paying...');

        -- Silence here is the one outcome that may NOT be retried: a confirm
        -- that was sent and lost could also be a confirm that landed. The
        -- contracts list is the ground truth and the server holds no second
        -- charge -- a second confirm meets an empty pending and refuses.
        if (os.clock() - dialog.stageAt > 10.0) then
            dialog.stage   = 'lost';
            dialog.stageAt = os.clock();
        end
    elseif (dialog.stage == 'lost') then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_WARN,
            'No answer from the server. If the hire landed it is on the Contracts tab; nothing is re-sent automatically.');
        imgui.PopTextWrapPos();

        if (imgui.Button('Check contracts##dwm_lostck')) then
            requested['contracts'] = nil;

            dialog = nil;

            return;
        end
    elseif (dialog.stage == 'done') then
        local result = dialog.result;

        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_OK, string.format('Hired %s for %d %s -- %s gil.',
            result.name, result.hours, result.hours == 1 and 'hour' or 'hours', gilText(result.gross)));
        imgui.Text(string.format('The contract runs %s from now. The Contracts tab calls them into your party.',
            spanText(result.ends)));
        imgui.TextDisabled('Zoning sends a summoned mercenary home; calling again brings them back while the contract runs.');
        imgui.PopTextWrapPos();
    end

    imgui.Spacing();

    if (dialog.stage ~= 'paying') then
        local label = (dialog.stage == 'done' or dialog.stage == 'lost') and 'Close' or 'Cancel -- keep your gil';

        if (imgui.Button(label .. '##dwm_cancel')) then
            dialog = nil;
        end

        tooltipOnHover(TIPS.cancel);
    end
end

--[[
* The info pane: one listing in full. `age` is the single most useful fact a
* hirer cannot see any other way (M1: staleness is a feature), so selecting a
* listing asks for the measured copy.
--]]
local function infoPane()
    local entry = state.selected ~= nil and state.listings[state.selected] or nil;

    if (entry == nil) then
        imgui.TextDisabled('Click a listing for the detail.');

        return;
    end

    need('info', entry.listingid, string.format('!dwm info %s', entry.name));

    imgui.TextColored(COLOR_BADGE, string.format('%s -- %s', entry.name, jobsText(entry)));
    imgui.Text(string.format('%s gil an hour, contracts up to %dh.', gilText(entry.rate), entry.maxhours or 0));

    local published = loadoutCount(entry.listingid);

    if (published > 0) then
        local names = {};

        for ordinal = 1, published do
            table.insert(names, loadoutName(entry.listingid, ordinal));
        end

        imgui.PushTextWrapPos(0);
        imgui.Text(string.format('Fights by: %s -- you pick one when you summon them.', table.concat(names, ', ')));
        imgui.PopTextWrapPos();
    end

    if (entry.gear ~= nil and entry.spells ~= nil) then
        local age = agoOf(entry.age);

        imgui.PushTextWrapPos(0);
        imgui.Text(string.format('Frozen %s: %d pieces of gear and %d spells.',
            age or 'at listing time', entry.gear, entry.spells));
        tooltipOnHover(TIPS.frozen);
        imgui.TextDisabled('The snapshot is what you get -- nothing the owner does afterwards changes it.');
        imgui.PopTextWrapPos();
    else
        imgui.TextDisabled('Measuring the snapshot...');
        tooltipOnHover('The board read knows this listing\'s rate and has not counted its gear.\nSelecting it asks the server for the measured copy; the answer takes a moment.');
    end

    if (entry.hires ~= nil and entry.hires > 0) then
        imgui.Text(string.format('Hired %d %s so far.', entry.hires, entry.hires == 1 and 'time' or 'times'));
        tooltipOnHover('Contracts completed against this listing, lifetime. It says nothing about how good\nthe mercenary is -- only that somebody has paid for it before.');
    end

    -- The kit itself, piece by piece -- what the gear count is counting. Names
    -- come from the client's own resources; the wire carries ids (i|).
    local kit = kitLines(entry);

    if (kit ~= nil and #kit > 0) then
        imgui.Spacing();
        imgui.TextDisabled('Wearing, exactly as frozen:');
        tooltipOnHover(TIPS.frozen);

        -- Each piece carries the client's own card, the way dwtoau and dwah
        -- draw theirs: the snapshot IS the product being priced (M1), so a
        -- hirer should be able to read what a piece of it actually does
        -- without leaving the window.
        local ids = entry.kitIds or {};

        for index, lineText in ipairs(kit) do
            imgui.Text(lineText);

            if (ids[index] ~= nil and imgui.IsItemHovered()) then
                itemCard(ids[index]);
            end
        end
    end

    imgui.Spacing();

    if (bit.band(entry.flags or 0, LISTING_MINE) ~= 0) then
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled('This one is yours. Your own squad summons it free; hiring it would only pay the house.');
        imgui.PopTextWrapPos();
    elseif (bit.band(entry.flags or 0, LISTING_OFF) ~= 0) then
        imgui.TextDisabled('Off the board right now.');
        tooltipOnHover(TIPS.markOff);
    elseif (bit.band(entry.flags or 0, LISTING_WORKING) ~= 0) then
        local left = liveDown(entry.remaining);

        imgui.Text(string.format('Working a contract just now%s.',
            left ~= nil and string.format(' -- about %s left', spanText(left)) or ''));
        tooltipOnHover(TIPS.markWorking);
    else
        if (imgui.Button(string.format('Hire %s...##dwm_hire_%d', entry.name, entry.listingid))) then
            openDialog(entry.listingid);
        end

        tooltipOnHover('Opens the hire dialog. Nothing is charged without a quoted price and a second click.');
    end
end

local function boardTab()
    -- The reader found the board shorter than the page this pager is on and
    -- said which page the server actually has. Applied here, where the widget
    -- scratch lives, and cleared so it is applied once.
    if (state.boardPage ~= nil) then
        bufferOf('boardpage', 1)[1] = state.boardPage;
        state.boardPage = nil;
    end

    -- WHOLE AND IN RANGE BEFORE EITHER IS FORMATTED INTO A LINE. Both come
    -- from widget scratch that only this file writes, so neither is a player's
    -- typing today -- but they are concatenated into a command, and the rule
    -- for a number that reaches a command is the same wherever it came from:
    -- a fractional page would ask the server for `board 2.5`, and a job id
    -- outside the table would index a nil into string.lower.
    local job  = math.floor(tonumber(bufferOf('boardjob', 0)[1]) or 0);
    local page = math.max(math.floor(tonumber(bufferOf('boardpage', 1)[1]) or 1), 1);

    if (job < 1 or job > 22 or JOB_NAMES[job] == nil) then
        job = 0;
    end

    -- The ask carries the filter and the page; the g| record carries them
    -- back, so a response for an older ask is visibly not this one's.
    local command = '!dwm board';

    if (job > 0) then
        command = command .. ' ' .. string.lower(JOB_NAMES[job]);
    end

    if (page > 1) then
        command = string.format('%s %d', command, page);
    end

    need('board', string.format('%d:%d', job, page), command);

    imgui.Text('Job');
    imgui.SameLine();
    imgui.PushItemWidth(90);

    if (imgui.BeginCombo('##dwm_jobfilter', job > 0 and JOB_NAMES[job] or 'All')) then
        if (imgui.Selectable('All##dwm_jf_all', job == 0)) then
            bufferOf('boardjob', 0)[1]  = 0;
            bufferOf('boardpage', 1)[1] = 1;
            requested['board'] = nil;
        end

        for id = 1, 22 do
            if (imgui.Selectable(string.format('%s##dwm_jf_%d', JOB_NAMES[id], id), job == id)) then
                bufferOf('boardjob', 0)[1]  = id;
                bufferOf('boardpage', 1)[1] = 1;
                requested['board'] = nil;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
    tooltipOnHover(TIPS.jobFilter);

    local board = state.board;

    -- Filter by selection: records arrive for whatever was asked about, not
    -- for what is on screen now. A page of white mages must not land in a
    -- pane showing everything (client discipline 3).
    local current = board ~= nil and board.job == job or false;

    if (board ~= nil and current) then
        imgui.SameLine();

        if (board.pages > 1) then
            if (imgui.SmallButton('< Prev##dwm_bprev') and board.page > 1) then
                bufferOf('boardpage', 1)[1] = board.page - 1;
                requested['board'] = nil;
            end

            tooltipOnHover(board.page > 1 and TIPS.prevPage or 'This is the first page.');

            imgui.SameLine();
        end

        imgui.TextDisabled(string.format('page %d of %d -- %d for hire', board.page, board.pages, board.total));
        tooltipOnHover('Every open listing the server has, under the filter above. Your own listings\nand the ones under contract are on the board too, marked in the last column.');

        if (board.pages > 1) then
            imgui.SameLine();

            if (imgui.SmallButton('Next >##dwm_bnext') and board.page < board.pages) then
                bufferOf('boardpage', 1)[1] = board.page + 1;
                requested['board'] = nil;
            end

            tooltipOnHover(board.page < board.pages and TIPS.nextPage or 'This is the last page.');
        end
    end

    --[[
    * FIND A MERCENARY BY NAME (1.3.0).
    *
    * The store pages the board six at a time (BOARD_PAGE in merc.lua), so a
    * shelf of thirty is five pages at the client's 1.2-second throttle, and a
    * player who already knows who they want was paging to them. `info` has
    * taken a name since v1 and resolves it exactly and then by unambiguous
    * prefix, so this needs no new verb, no protocol move and no latch: it is
    * the line a player would type, sent by a button.
    *
    * IT READS AND NOTHING ELSE. The answer is an info envelope, which fills
    * the pane on the right; the selection follows it in the reader.
    *
    * ON ITS OWN ROW, under the filter and the pager rather than beside them:
    * three controls and a page counter already fill that line at the window's
    * minimum width, and a find box that has been pushed off the edge is a find
    * box that does not exist.
    --]]
    local lookup = bufferOf('lookup', '');

    imgui.SetNextItemWidth(columnWidth(WIDEST_NAME, 40));

    local entered = imgui.InputTextWithHint('##dwm_lookup', 'find by name...', lookup, 17,
        ImGuiInputTextFlags_EnterReturnsTrue);

    tooltipOnHover(TIPS.lookup);

    imgui.SameLine();

    local asked = imgui.SmallButton('Look up##dwm_lookup_go');

    tooltipOnHover(TIPS.lookupGo);

    if (entered or asked) then
        -- VALIDATED BEFORE IT IS FORMATTED INTO A LINE. A character name is
        -- letters only and at most fifteen of them, and anything else is a
        -- refusal the player should read here rather than in the chat log.
        local typed = string.match(lookup[1] or '', '^%s*(%a+)%s*$');

        if (typed == nil or #typed > 15) then
            state.lookupSaid = { text = 'A mercenary name is letters only, up to fifteen of them.', at = os.clock() };
            state.lookupWant = nil;
        else
            state.lookupSaid = nil;
            state.lookupWant = { name = string.lower(typed), at = os.clock() };

            issueRead(string.format('!dwm info %s', typed));
        end
    end

    -- A lookup whose answer never came must not sit waiting to capture the
    -- next info envelope, which would be about whatever row was clicked next.
    -- Measured generously rather than off ANSWER_TIMEOUT: the line is QUEUED
    -- here, and a read queue that already holds half a dozen asks spends
    -- several seconds draining before this one is even sent.
    if (state.lookupWant ~= nil and elapsed(state.lookupWant.at) > LOOKUP_WINDOW) then
        state.lookupWant = nil;
    end

    -- And the refusal for a name that was not one goes the same way a refusal
    -- on the message line does: long enough to read, then out of the way.
    if (state.lookupSaid ~= nil) then
        if (elapsed(state.lookupSaid.at) > STATUS_DWELL) then
            state.lookupSaid = nil;
        else
            imgui.SameLine();
            imgui.TextColored(COLOR_WARN, state.lookupSaid.text);
        end
    end

    local nameW = columnWidth(WIDEST_NAME);
    local jobW  = columnWidth(WIDEST_JOBS);
    local gilW  = columnWidth(WIDEST_GIL);
    local capW  = columnWidth('Up to');
    local markW = columnWidth('(yours)');

    imgui.BeginChild('##dwm_boardlist',
        { childWidthFor(5, { nameW, jobW, gilW, capW, markW }), 0 }, ImGuiChildFlags_Borders);

    if (board == nil or not current) then
        imgui.Text('Fetching the board...');
    elseif (#board.rows == 0) then
        imgui.Text(job > 0 and string.format('No %s is for hire right now.', JOB_NAMES[job])
            or 'The mercenary board is empty right now.');
        imgui.TextDisabled('The Listing tab puts a character of your own up for hire.');
    elseif (imgui.BeginTable('##dwm_board', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Mercenary', ImGuiTableColumnFlags_WidthFixed, nameW, 0);
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, jobW, 0);
        imgui.TableSetupColumn('Gil / h', ImGuiTableColumnFlags_WidthFixed, gilW, 0);
        imgui.TableSetupColumn('Up to', ImGuiTableColumnFlags_WidthFixed, capW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, markW, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, listingid in ipairs(board.rows) do
            local entry = state.listings[listingid];

            if (entry ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();

                if (imgui.Selectable(string.format('%s##dwm_row_%d', entry.name, listingid),
                        state.selected == listingid)) then
                    state.selected = listingid;
                end

                tooltipOnHover(TIPS.boardRow);

                imgui.TableNextColumn();
                imgui.Text(jobsText(entry));
                tooltipOnHover('The jobs and levels in the SNAPSHOT. A month-old photograph of a level 75\nis still a level 75; what it may not be is the gear the owner wears today.');

                imgui.TableNextColumn();
                imgui.Text(gilText(entry.rate));
                tooltipOnHover(TIPS.rate);

                imgui.TableNextColumn();
                imgui.Text(string.format('%dh', entry.maxhours or 0));
                tooltipOnHover('The longest single contract this owner will take. You can book fewer hours.');

                imgui.TableNextColumn();

                local mark = statusOf(entry);

                if (mark == 'yours') then
                    imgui.TextColored(COLOR_BADGE, '(yours)');
                    tooltipOnHover(TIPS.markYours);
                elseif (mark == 'working') then
                    imgui.TextDisabled('working');
                    tooltipOnHover(TIPS.markWorking);
                elseif (mark == 'off the board') then
                    imgui.TextDisabled('off');
                    tooltipOnHover(TIPS.markOff);
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();

    imgui.SameLine();

    imgui.BeginChild('##dwm_boardinfo', { 0, 0 }, ImGuiChildFlags_Borders);

    if (dialog ~= nil) then
        hireDialog();
    else
        infoPane();
    end

    imgui.EndChild();
end

--[[
* The Contracts tab: what this account is paying for, live. Every duration on
* screen is the server's own count run down locally for display; the buttons
* emit only lines a player could type, and the server re-checks the contract,
* the fight gate and the party arithmetic on each one regardless.
--]]
local function contractsTab()
    need('contracts', 0, '!dwm contracts');

    local active = state.contracts.active;
    local recent = state.contracts.recent;

    if (#active == 0 and #recent == 0) then
        imgui.Text('You have no mercenaries under contract.');
        imgui.TextDisabled('The Board tab shows who is for hire.');

        -- THE DIALOG IS DRAWN BEFORE THE EARLY RETURN, NOT AFTER IT
        -- (2026-09-06). `Hire again` opens it from the settled list, and a
        -- Refresh that came back with the settled row aged out emptied both
        -- lists under it -- so the dialog was drawn nowhere: not cancellable,
        -- not payable, with a quote possibly armed server-side and a Pay
        -- button the player could no longer reach.
        if (dialog ~= nil) then
            imgui.Separator();
            hireDialog();
        end

        return;
    end

    imgui.TextDisabled('Time is approximate; the server\'s clock decides. A mercenary already out fights on past the');
    imgui.TextDisabled('hour and refuses the next call -- dismissing early refunds nothing, you booked the hours.');

    -- Bounded and scrolling since 1.3.0. The table used to grow with the
    -- contract list and push the finished list, the hire dialog and every
    -- button on them below the bottom of a window that carries NoScrollbar --
    -- reachable only by a wheel gesture with nothing on screen to suggest it.
    local loadoutW = columnWidth(WIDEST_LOADOUT, 40);

    if (#active > 0 and imgui.BeginTable('##dwm_contracts', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, rowsHeight(#active, 8) })) then
        imgui.TableSetupColumn('Mercenary', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_NAME), 0);
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_JOBS), 0);
        imgui.TableSetupColumn('Fighting by', ImGuiTableColumnFlags_WidthFixed, loadoutW, 0);
        imgui.TableSetupColumn('Time left', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_SPAN), 0);
        imgui.TableSetupColumn('Paid', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_GIL), 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, columnWidth('Dismiss  End it -- sure?'), 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, entry in ipairs(active) do
            local listing = state.listings[entry.listingid];

            -- The t| record deliberately carries no jobs -- the listing does.
            -- One info per unknown listing fills jobs AND the kit below, and
            -- a contract from before this session is unknown by definition.
            if ((listing == nil or listing.mjob == nil) and not infoAsked[entry.listingid]) then
                infoAsked[entry.listingid] = true;

                issueRead(string.format('!dwm info %s', entry.name));
            end

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(entry.name);

            -- THE CARD IS BUILT ONLY WHEN SOMEBODY IS POINTING AT IT. The
            -- concat used to be evaluated as the argument, so every frame paid
            -- to join sixteen lines into a five-hundred-byte string for a card
            -- that is drawn on one row at most and usually on none.
            if (imgui.IsItemHovered()) then
                local kit = kitLines(listing);

                if (kit ~= nil and #kit > 0) then
                    imgui.SetTooltip('The frozen kit they arrive in:\n' .. table.concat(kit, '\n'));
                else
                    imgui.SetTooltip('What this contract bought. Selecting the listing on the Board tab measures the kit.');
                end
            end

            imgui.TableNextColumn();

            if (listing ~= nil and listing.mjob ~= nil) then
                imgui.Text(jobsText(listing));
            else
                imgui.TextDisabled('...');
                tooltipOnHover('The contract record carries no jobs -- the listing behind it does.\nThat listing is being read now; this fills in when the answer lands.');
            end

            imgui.TableNextColumn();

            local out       = (entry.running or 0) > 0;
            local published = loadoutCount(entry.listingid);

            if (out and published > 1) then
                -- The switch: a re-call on another loadout (M7 picks at
                -- summon, a re-call is a re-paint). Refused mid-fight
                -- server-side, with the sentence saying so.
                imgui.PushItemWidth(loadoutW - CELL_PADDING);

                if (imgui.BeginCombo(string.format('##dwm_sw_%d', entry.contractid),
                        loadoutName(entry.listingid, entry.running))) then
                    for ordinal = 1, published do
                        if (imgui.Selectable(string.format('%s##dwm_sw_%d_%d',
                                loadoutName(entry.listingid, ordinal), entry.contractid, ordinal),
                                ordinal == entry.running)) then
                            -- The same one-write-in-flight latch the two
                            -- buttons carry: a switch IS a call line.
                            if (ordinal ~= entry.running and actPending[entry.contractid] == nil) then
                                actPending[entry.contractid] = { what = 'call', at = os.clock() };

                                issueWrite(string.format('!dwm call %s %d', entry.name, ordinal));
                            end
                        end
                    end

                    imgui.EndCombo();
                end

                imgui.PopItemWidth();
                tooltipOnHover(string.format('Switch loadouts -- the same thing as: !merc call %s <loadout>', entry.name));
            elseif (out) then
                imgui.Text(loadoutName(entry.listingid, entry.running));
                tooltipOnHover('The rule set they are fighting by right now. This listing publishes only the one,\nso there is nothing to switch to.');
            else
                imgui.TextDisabled(string.format('%s (at home)', loadoutName(entry.listingid, entry.bought)));
                tooltipOnHover(TIPS.atHome);
            end

            imgui.TableNextColumn();

            local left = liveDown(entry.remaining);

            imgui.Text(string.format('~%s', spanText(left or 0)));
            tooltipOnHover(TIPS.timeLeft);

            -- A countdown that hit zero is a contract due to settle; one
            -- re-ask shows it where it now belongs, in the finished list --
            -- and the listing goes back on the open market, so the board's
            -- ask is forgotten with it. The one-shot flag lives OUTSIDE the
            -- row (like infoAsked): every `contracts` envelope rebuilds
            -- state.contracts wholesale, so a flag on the row was destroyed
            -- by the very re-read it triggered -- and a mercenary still
            -- fighting past expiry ("expiry gates the door, not the room")
            -- kept the pane in a contracts+board command loop at 1.2s a line
            -- until the settlement job ran.
            if (left ~= nil and left <= 0 and not expiryAsked[entry.contractid]) then
                expiryAsked[entry.contractid] = true;
                requested['contracts'] = nil;
                requested['board']     = nil;
            end

            imgui.TableNextColumn();
            imgui.Text(gilText(entry.gross));
            tooltipOnHover(TIPS.paid);

            imgui.TableNextColumn();

            -- Neither button re-asks: a verb that writes answers with the
            -- state it produced, so the call/dismiss envelope IS the refresh
            -- (dwm_protocol.md's mutation-answers-with-state rule).
            local pending = actPending[entry.contractid];

            if (pending ~= nil and elapsed(pending.at) > WRITE_TIMEOUT) then
                actPending[entry.contractid] = nil;
                pending = nil;
            end

            if (pending ~= nil) then
                imgui.TextDisabled(pending.what == 'dismiss' and 'sending home...'
                    or (pending.what == 'release' and 'ending...' or 'calling...'));
                tooltipOnHover('The line is on the way. One click is one line: nothing is re-sent, and a\nsecond call on a mercenary already out would send them home and back again.');
            elseif (out) then
                if (imgui.SmallButton(string.format('Dismiss##dwm_dis_%d', entry.contractid))) then
                    actPending[entry.contractid] = { what = 'dismiss', at = os.clock() };

                    issueWrite(string.format('!dwm dismiss %s', entry.name));
                end

                tooltipOnHover(string.format('Send them home -- the clock keeps running.\nThe same thing as: !merc dismiss %s', entry.name));
            else
                if (imgui.SmallButton(string.format('Call##dwm_call_%d', entry.contractid))) then
                    actPending[entry.contractid] = { what = 'call', at = os.clock() };

                    issueWrite(string.format('!dwm call %s', entry.name));
                end

                tooltipOnHover(string.format('Summon them into your party, on the loadout you bought.\nThe same thing as: !merc call %s', entry.name));
            end

            -- Release: end the contract early. Two clicks, the second inside
            -- the hold; the first sends the arming line (the server answers
            -- with what would be forfeited, in chat), the second the one
            -- line that ends it. No refund -- the tip says so before the
            -- first click.
            if (pending == nil) then
                local armed = releaseArmed ~= nil and releaseArmed.contractid == entry.contractid
                    and (os.clock() - releaseArmed.at) < RELEASE_HOLD;

                imgui.SameLine();

                if (imgui.SmallButton(string.format('%s##dwm_rel_%d', armed and 'End it -- sure?' or 'Release', entry.contractid))) then
                    if (armed) then
                        releaseArmed = nil;
                        actPending[entry.contractid] = { what = 'release', at = os.clock() };

                        issueWrite('!dwm confirm release');
                    else
                        releaseArmed = { contractid = entry.contractid, at = os.clock() };

                        issueWrite(string.format('!dwm release %s', entry.name));
                    end
                end

                tooltipOnHover(string.format('End the contract now. NO REFUND: the owner is paid in full for the hours you booked,\nand the time left is simply gone. Asked twice -- click, then click again.\nThe same thing as: !merc release %s (twice)', entry.name));
            end
        end

        imgui.EndTable();
    end

    if (#recent > 0) then
        imgui.Separator();
        imgui.TextDisabled('Recently finished -- the hours you booked are up:');
        tooltipOnHover(TIPS.finished);

        for _, entry in ipairs(recent) do
            imgui.Text(string.format('  %s -- %d %s, %s gil.',
                entry.name, entry.hours, entry.hours == 1 and 'hour' or 'hours', gilText(entry.gross)));
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Hire again...##dwm_re_%d', entry.contractid))) then
                -- The hours and the loadout that were actually bought, offered
                -- back as the starting point -- which is what "again" means.
                -- Both are only input values; the server quotes from the
                -- listing as it stands now, whatever is in the boxes.
                openDialog(entry.listingid, entry.hours, entry.bought);

                -- The dialog draws in the Board tab's info pane; the name may
                -- be all this tab knows about the listing, so the dialog
                -- fetches the rest itself via the info ask.
                dialog.name = entry.name;
            end

            tooltipOnHover(TIPS.hireAgain);
        end
    end

    if (dialog ~= nil) then
        imgui.Separator();
        hireDialog();
    end
end

--[[
* The My mercs tab: the lister's side. Everything here except Claim is a read;
* Claim moves ledger gil to the character standing here, which the server does
* in C++ inside the transaction that marks the rows -- the button just says
* the word.
--]]
local function myMercsTab()
    need('listings', 0, '!dwm listings');
    need('earnings', 0, '!dwm earnings');

    if (#state.mine == 0) then
        imgui.Text('You have nothing on the mercenary board.');
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled('The Listing tab puts one up: pick a character you are NOT playing -- the photograph is taken '
            .. 'from the saved record -- set what it asks an hour, and pick the rule sets it fights by.');
        imgui.PopTextWrapPos();
    elseif (imgui.BeginTable('##dwm_mine', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, rowsHeight(#state.mine, 8) })) then
        imgui.TableSetupColumn('Mercenary', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_NAME), 0);
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_JOBS), 0);
        imgui.TableSetupColumn('Gil / h', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_GIL), 0);
        -- THE ONE STRETCHING COLUMN. Its longest sentence -- "hired by
        -- <15-character name> -- ~23h 59m left" -- is wider than the 230
        -- pixels it used to be given, and it is the column a lister actually
        -- reads; letting it take whatever the window has left is the only
        -- sizing here that cannot be wrong at some window width.
        imgui.TableSetupColumn('Status', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Snapshot', ImGuiTableColumnFlags_WidthFixed, columnWidth('99 gear, 999 spells, frozen 99 days ago'), 0);
        imgui.TableSetupColumn('Earned', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_GIL), 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, listingid in ipairs(state.mine) do
            local entry = state.listings[listingid];

            if (entry ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();

                if (imgui.Selectable(string.format('%s##dwm_my_%d', entry.name, listingid),
                        state.selected == listingid)) then
                    -- Selection asks for the measured copy -- the listings
                    -- read counts the snapshot without reading its timestamp,
                    -- so "frozen N hours ago" needs an info per listing
                    -- (Phase 5's deliberate split).
                    state.selected = listingid;
                end

                tooltipOnHover('Asks the server to measure this listing: how old the photograph is, and\nthe gear a hirer is actually buying. The Snapshot column fills in.');

                imgui.TableNextColumn();
                imgui.Text(jobsText(entry));

                imgui.TableNextColumn();
                imgui.Text(gilText(entry.rate));
                tooltipOnHover(TIPS.rate);

                imgui.TableNextColumn();

                if (entry.pending) then
                    imgui.TextColored(COLOR_WARN, 'withdrawal waits for the contract to settle');
                    tooltipOnHover('You asked for it off the board while a contract was running, so the hirer\nkeeps the hours they paid for and the listing comes off when that settles.\nNobody else can hire it in the meantime.');
                elseif (bit.band(entry.flags or 0, LISTING_OFF) ~= 0) then
                    imgui.TextDisabled('off the board (snapshot kept)');
                    tooltipOnHover(TIPS.markOff);
                elseif (bit.band(entry.flags or 0, LISTING_WORKING) ~= 0) then
                    local left = liveDown(entry.remaining);

                    imgui.TextColored(COLOR_HINT, string.format('hired by %s%s',
                        entry.hirer or 'somebody',
                        left ~= nil and string.format(' -- ~%s left', spanText(left)) or ''));
                    tooltipOnHover('Who is paying for it and roughly how long is left. This is the one thing on\nthe wire that only you can see -- a browser is told a mercenary is working\nand never by whom.');
                else
                    imgui.Text(string.format('on the board, up to %dh', entry.maxhours or 0));
                    tooltipOnHover('Open for hire. Anyone can book up to this many hours in one contract.');
                end

                imgui.TableNextColumn();

                if (state.selected == listingid) then
                    need('info', listingid, string.format('!dwm info %s', entry.name));
                end

                if (entry.gear ~= nil and entry.spells ~= nil) then
                    local age = agoOf(entry.age);

                    imgui.Text(string.format('%d gear, %d spells%s', entry.gear, entry.spells,
                        age ~= nil and (', frozen ' .. age) or ''));

                    if (imgui.IsItemHovered()) then
                        local kit = kitLines(entry);

                        if (kit ~= nil and #kit > 0) then
                            imgui.SetTooltip('The frozen copy hirers get -- re-listing takes a fresh one:\n'
                                .. table.concat(kit, '\n'));
                        else
                            imgui.SetTooltip('The frozen copy hirers get. Re-listing the character takes a fresh one;\nnothing else changes it.');
                        end
                    end
                else
                    imgui.TextDisabled('click the name to measure');
                    tooltipOnHover('The listings read counts the snapshot without reading its timestamp, so\n"frozen N hours ago" costs one more question. Clicking the name asks it.');
                end

                imgui.TableNextColumn();

                if (entry.earned ~= nil) then
                    imgui.Text(gilText(entry.earned));
                    tooltipOnHover(TIPS.earned);
                else
                    imgui.TextDisabled('--');
                    tooltipOnHover('This response did not count it. The listings read does; a board row does not.');
                end
            end
        end

        imgui.EndTable();
    end

    imgui.Separator();

    -- The purse and the claim. The three zero-claim outcomes are told apart
    -- from the w|c fields, because "nothing is waiting" said about gil that
    -- IS waiting tells a player their earnings are gone (dwm_protocol.md).
    local purse = state.purse;

    if (purse ~= nil) then
        imgui.Text(string.format('%s gil waiting on your ledger -- %s earned lifetime.',
            gilText(purse.balance), gilText(purse.lifetime)));
        tooltipOnHover(TIPS.purse);

        -- Only where something follows it. The SameLine used to be
        -- unconditional, so while the ledger was still being read it put
        -- whatever came next on the same line as "Reading the ledger...".
        imgui.SameLine();
    else
        imgui.TextDisabled('Reading the ledger...');
        tooltipOnHover('The purse rides along with the listings read, which is on its way.');
    end

    -- Silence must not hold the button hostage. Nothing is re-sent -- the
    -- ledger rows below are the ground truth about what moved -- but the
    -- button comes back, which is the difference between "still working on
    -- it" and a dead control.
    if (claimPending ~= nil and elapsed(claimPending) > WRITE_TIMEOUT) then
        claimPending  = nil;
        claimTimedOut = true;
    end

    if (claimPending ~= nil) then
        imgui.TextDisabled('claiming...');
        tooltipOnHover('The claim line is on its way. Nothing is ever sent twice for one click.');
    elseif (purse ~= nil and purse.balance == 0) then
        -- A greyed control owes a reason. Nothing to collect is not the same
        -- as nothing earned, and the ledger rows underneath say which.
        imgui.TextDisabled('nothing to collect');
        tooltipOnHover('There is nothing on the ledger waiting. Earnings arrive when a contract\nagainst one of your listings SETTLES, which is when its hours run out --\nnot when it is hired.');
    elseif (purse ~= nil and purse.balance > 0) then
        if (imgui.SmallButton('Claim##dwm_claim')) then
            claimPending  = os.clock();
            claimTimedOut = false;
            state.claim   = nil;

            issueWrite('!dwm claim');
        end

        tooltipOnHover('Collects the balance to the character you are playing.\nThe same thing as: !merc claim');
    end

    if (claimTimedOut) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_WARN, 'No answer from the server. Nothing was re-sent -- the rows below say what moved.');
        imgui.PopTextWrapPos();
    end

    local claim = state.claim;

    if (claim ~= nil) then
        if (claim.claimed > 0) then
            imgui.TextColored(COLOR_OK, string.format('Collected %s gil%s.', gilText(claim.claimed),
                claim.held > 0 and string.format(' -- %s more waits on purse room', gilText(claim.held)) or ''));
        elseif (claim.held > 0 and claim.capped) then
            imgui.TextColored(COLOR_WARN, string.format('Your purse is too full to take it. %s gil waits, and none is lost.', gilText(claim.held)));
        elseif (claim.held > 0) then
            imgui.TextColored(COLOR_ERROR, 'The claim did not go through -- the gil is still safely on the ledger. Try again.');
        else
            imgui.TextDisabled('Nothing has been earned yet.');
        end
    end

    local ledger = state.ledger;

    if (ledger ~= nil and #ledger > 0) then
        imgui.Separator();
        imgui.TextDisabled('Earnings, contract by contract -- gross, the house cut, and yours:');
        tooltipOnHover(TIPS.ledger);

        if (imgui.BeginTable('##dwm_ledger', 6,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                        ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
            imgui.TableSetupColumn('Mercenary', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_NAME), 0);
            imgui.TableSetupColumn('Hirer', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_NAME), 0);
            imgui.TableSetupColumn('Gross', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_GIL), 0);
            imgui.TableSetupColumn('House cut', ImGuiTableColumnFlags_WidthFixed, columnWidth('House cut'), 0);
            imgui.TableSetupColumn('Yours', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_GIL), 0);
            imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthStretch, 0, 0);
            imgui.TableSetupScrollFreeze(0, 1);
            imgui.TableHeadersRow();

            -- Summed as the rows are drawn rather than in a second pass: it is
            -- the same walk, and the totals row is the point of showing all
            -- three figures at all (M3 -- the house cut is checkable rather
            -- than folklore, and one row is hard to check anything against).
            local grossSum = 0;
            local taxSum   = 0;
            local yourSum  = 0;

            for _, row in ipairs(ledger) do
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(row.merc or '?');
                imgui.TableNextColumn();
                imgui.Text(row.hirer or '?');
                imgui.TableNextColumn();
                imgui.Text(gilText(row.gross));
                imgui.TableNextColumn();
                imgui.Text(gilText(row.tax));
                imgui.TableNextColumn();
                imgui.Text(gilText(row.amount));
                imgui.TableNextColumn();

                local when = agoOf(row.age);

                imgui.TextDisabled(string.format('%s%s', row.claimed and 'claimed, ' or '',
                    when or ''));

                grossSum = grossSum + (row.gross or 0);
                taxSum   = taxSum + (row.tax or 0);
                yourSum  = yourSum + (row.amount or 0);
            end

            -- The totals (1.3.0). NOT A LIFETIME FIGURE and labelled so: at
            -- most twenty rows ride the wire, so this adds up what is on
            -- screen. The purse line above carries the lifetime number, which
            -- is the server's own.
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextDisabled(string.format('%d %s', #ledger, #ledger == 1 and 'contract' or 'contracts'));
            imgui.TableNextColumn();
            imgui.TextDisabled('shown');
            imgui.TableNextColumn();
            imgui.TextColored(COLOR_BADGE, gilText(grossSum));
            imgui.TableNextColumn();
            imgui.TextColored(COLOR_BADGE, gilText(taxSum));
            imgui.TableNextColumn();
            imgui.TextColored(COLOR_BADGE, gilText(yourSum));
            imgui.TableNextColumn();
            imgui.TextDisabled('these rows');
            tooltipOnHover(TIPS.totals);

            imgui.EndTable();
        end
    end
end

--[[
* The Listing tab: the seller's side, as a form.
*
* `!merc list <char> <rate> <maxhours> <set> [set] [set]` is the only verb in
* this command whose arguments come from nowhere else on the wire -- a character
* off the account's roster and up to three rule set names off its shelf -- which
* is why listing stayed typed through Phase 6 and why the server grew `options`
* before this tab could exist. EVERY NAME IN EVERY PICKER HERE CAME OFF THE
* WIRE. Nothing is hardcoded: not the roster, not the rule sets, not the caps,
* and not the house cut.
*
* THE TWO WRITES ARE `list` AND `unlist` AND NEITHER IS MONEY. Listing is free,
* withdrawing refunds nothing because nothing was paid, and the house takes its
* cut at settlement out of what a hirer paid -- so this tab has none of the hire
* dialog's two-act machinery. What it does have is a confirm on the two clicks
* that throw something away: re-freezing replaces the photograph hirers are
* being shown, and withdrawing takes a character off the market.
*
* WHAT IT WILL NOT DO IS PREDICT A REFUSAL. The store owns the caps, M10 owns
* "not the character you are playing", and a shipped set that flattens past 24
* rules for a wide job is a refusal no client can work out in advance. Where the
* c| record says what a bound is, the input respects it; where it says -1, the
* input has no ceiling and the server's own sentence is what says so. A guess
* would be the drift the caps were centralised to prevent.
--]]

-- The server's own example numbers, out of the sentence `!merc list` prints
-- when it is typed without a rate ("Try: !merc list Ayame 5000 4 defensive").
-- A starting value for an input box is not a cap and gates nothing.
local LIST_RATE_DEFAULT  = 5000;
local LIST_HOURS_DEFAULT = 4;

-- What the client will carry as one outgoing chat line. A list command with
-- three quoted set names is the longest thing this addon ever sends, and a line
-- the client truncated would be a listing published with a set name cut in
-- half -- so an over-long one is refused here, with the typed form printed.
local COMMAND_BUDGET = 120;

-- How long a confirm button stays armed. Long enough to read what it is about
-- to do, short enough that it is never still armed when somebody comes back.
local CONFIRM_HOLD = 8.0;

--[[
* Which listing, if any, belongs to a character.
*
* `listingid` is the protocol's join and is used whenever it resolves. It is 0
* for a character that had never been listed AT THE MOMENT `options` answered,
* so a character listed since is found by name instead -- exact, because the
* store freezes the roster's own charname and holds one listing per character.
* That fallback is what lets a brand new listing appear on this tab the instant
* the `list` envelope lands, rather than after another round trip.
*
* AND THE NAME HALF IS AN INDEX, NOT A SCAN (2026-09-06). It used to lower the
* candidate's name and then lower every listing on the shelf to compare against
* it -- per candidate, per frame, plus once more for the picked one inside the
* form. On a full account (sixteen characters against the shelf they are joined
* to) that is close to three hundred string allocations a frame for a join that
* changes only when an envelope lands. state.mineByName is built by the
* envelope reader instead, once, at the end of processEnvelope.
--]]
local function candidateListing(cand)
    if (cand.listingid ~= 0 and state.listings[cand.listingid] ~= nil) then
        return state.listings[cand.listingid];
    end

    if (cand.lowerName == nil) then
        cand.lowerName = string.lower(cand.name or '');
    end

    return state.mineByName[cand.lowerName];
end

-- A bound off the c| record, or the fallback when this server did not report
-- one. NEVER a hardcoded cap: the fallback for a ceiling is nil, meaning the
-- input does not clamp and the store refuses what it will not take.
local function limitOf(field, fallback)
    local limits = state.limits;

    if (limits == nil) then
        return fallback;
    end

    local value = limits[field];

    if (value == nil or value == UNMEASURED) then
        return fallback;
    end

    return value;
end

-- The set as the server spelled it, or nil. Matching is case-insensitive only
-- so that a loadout published earlier can be found again in the picker; what
-- goes back out is always the wire's own spelling.
--
-- THROUGH THE INDEX THE READER BUILT (2026-09-06). This used to walk state.sets
-- lowering every name -- once per picker slot, three slots, every frame -- and
-- the machine tier deliberately sends ALL FORTY shipped sets plus the account's
-- own, so a form sitting open cost well over a hundred string allocations a
-- frame to answer a question whose answer changes only when `options` lands.
local function knownSet(name)
    if (name == nil) then
        return nil;
    end

    return state.setsByName[string.lower(name)];
end

local function buildForm(cand)
    local listing = candidateListing(cand);
    local picks   = {};

    -- Prefilled from what this character is already published with, so
    -- re-freezing is one click and changing a rate does not mean retyping the
    -- loadouts. A published name with no matching set left on the shelf -- it
    -- was deleted since it was published -- is deliberately NOT prefilled: the
    -- picker would be offering something `list` is going to refuse.
    if (listing ~= nil) then
        for ordinal = 1, 3 do
            local published = (state.loadouts[listing.listingid] or {})[ordinal];
            local match     = knownSet(published);

            picks[ordinal] = match ~= nil and match.name or nil;
        end
    end

    form = {
        charid  = cand.charid,
        name    = cand.name,
        rate    = T{ listing ~= nil and listing.rate or LIST_RATE_DEFAULT },
        hours   = T{ listing ~= nil and listing.maxhours or LIST_HOURS_DEFAULT },
        picks   = picks,
        confirm = nil,
        error   = nil,
    };
end

-- The line a button sends, built the way a player would type it.
--
-- The server reads a quoted run of tokens as one argument (its takeRef), which
-- is what makes a set called "Chain Crew" one name rather than two. A name
-- carrying a quote of its own cannot be quoted, so it goes bare and the
-- server's longest-run match resolves it -- the same way it would for somebody
-- typing the line.
local function listCommand(name, rate, hours, chosen)
    local parts = { string.format('!dwm list %s %d %d', name, rate, hours) };

    for _, setName in ipairs(chosen) do
        if (string.find(setName, ' ', 1, true) == nil or string.find(setName, '"', 1, true) ~= nil) then
            table.insert(parts, setName);
        else
            table.insert(parts, '"' .. setName .. '"');
        end
    end

    return table.concat(parts, ' ');
end

-- A button that has to be clicked twice, with the second click inside the hold.
-- Returns true on the confirming click and never on the arming one.
local function confirmButton(id, label, armedLabel, what, tip)
    local armed = form.confirm ~= nil and form.confirm.what == what
        and (os.clock() - form.confirm.at) < CONFIRM_HOLD;

    if (imgui.Button(string.format('%s##%s', armed and armedLabel or label, id))) then
        if (armed) then
            form.confirm = nil;

            return true;
        end

        form.confirm = { what = what, at = os.clock() };

        return false;
    end

    tooltipOnHover(tip);

    if (armed) then
        imgui.SameLine();
        imgui.TextDisabled('...click again to confirm');
    end

    return false;
end

-- One rule set picker. `ordinal` is only the slot in this form -- the server
-- assigns the published ordinals from the order the names arrive on the line.
local function loadoutPicker(ordinal)
    local current = form.picks[ordinal];

    imgui.PushItemWidth(230);

    if (imgui.BeginCombo(string.format('##dwm_set_%d', ordinal), current or '(none)')) then
        if (imgui.Selectable(string.format('(none)##dwm_set_%d_none', ordinal), current == nil)) then
            form.picks[ordinal] = nil;
        end

        -- A set already published in another slot is not offered again: two
        -- identical loadouts on one listing is a choice the hirer cannot tell
        -- apart, and it spends one of the three for nothing.
        local taken = {};

        for slot = 1, 3 do
            if (slot ~= ordinal and form.picks[slot] ~= nil) then
                taken[form.picks[slot]] = true;
            end
        end

        local heading = nil;

        for index, entry in ipairs(state.sets) do
            if (not taken[entry.name]) then
                -- The two kinds are not interchangeable and the wire says
                -- which is which, so the picker says so too: a stored set is
                -- published as it stands, a shipped one is flattened against
                -- this character's job first and can come out over the cap.
                if (entry.kind ~= heading) then
                    heading = entry.kind;

                    imgui.Separator();
                    imgui.TextDisabled(heading == 'preset' and 'Shipped sets' or 'Your rule sets');
                end

                if (imgui.Selectable(string.format('%s##dwm_set_%d_%d', entry.name, ordinal, index),
                        current == entry.name)) then
                    form.picks[ordinal] = entry.name;
                end

                if (entry.summary ~= nil) then
                    tooltipOnHover(entry.summary);
                elseif (entry.rules ~= UNMEASURED) then
                    tooltipOnHover(string.format('One of yours -- %d %s.', entry.rules,
                        entry.rules == 1 and 'rule' or 'rules'));
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    local entry = knownSet(current);

    if (entry ~= nil and entry.kind == 'preset') then
        imgui.SameLine();
        imgui.TextDisabled('shipped');
        tooltipOnHover(string.format('%s\n\nA shipped set is trimmed to what this character\'s job can use\nbefore it is published. If that comes out over the limit the\nserver says so and nothing is frozen.',
            entry.summary or 'A shipped rule set.'));
    end
end

local function listingForm(cand)
    local listing = candidateListing(cand);
    local playing = bit.band(cand.flags or 0, CAND_SELF) ~= 0;
    local slots   = math.max(math.min(limitOf('loadouts', MAX_LOADOUTS), MAX_LOADOUTS), 1);

    imgui.TextColored(COLOR_BADGE, string.format('%s -- %s', cand.name, jobsText(cand)));

    if (listing ~= nil) then
        local published = loadoutCount(listing.listingid);

        imgui.TextDisabled(string.format('Up at %s gil an hour, contracts up to %dh, %d %s published.',
            gilText(listing.rate), listing.maxhours or 0, published,
            published == 1 and 'loadout' or 'loadouts'));

        local age = liveUp(listing.age);

        if (age ~= nil) then
            imgui.TextDisabled(string.format('The photograph hirers are buying was taken %s.', agoText(age)));
        end
    else
        imgui.TextDisabled('Not on the board. Listing freezes it exactly as it stands right now.');
    end

    imgui.Separator();

    if (form.error ~= nil) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_ERROR, form.error);
        imgui.PopTextWrapPos();
        imgui.Spacing();
    end

    -- Rate. Clamped every frame AND at send, and only where the server said
    -- what the bounds are.
    local minRate = limitOf('minrate', 1);
    local maxRate = limitOf('maxrate', nil);

    imgui.Text('Gil an hour');
    tooltipOnHover(TIPS.rate);
    imgui.SameLine();
    imgui.PushItemWidth(150);
    imgui.InputInt('##dwm_rate', form.rate, 100, 1000);
    imgui.PopItemWidth();
    tooltipOnHover(TIPS.rate);

    local rate = math.floor(tonumber(form.rate[1]) or minRate);

    rate = math.max(rate, minRate);

    if (maxRate ~= nil) then
        rate = math.min(rate, maxRate);
    end

    form.rate[1] = rate;

    imgui.SameLine();
    imgui.TextDisabled(maxRate ~= nil and string.format('(%s to %s)', gilText(minRate), gilText(maxRate))
        or '(the server sets the ceiling)');
    tooltipOnHover(maxRate ~= nil
        and 'The bounds the store enforces. They are C++ constants on the server and this\nwindow keeps no copy of them -- what you see here came off the wire.'
        or 'This server did not report its rate bounds, so nothing here clamps the box.\nThe store refuses anything it will not take, and says what it will.');

    -- The hour cap, which is the LONGEST single contract this owner will take
    -- rather than how long the listing stands.
    local maxHours = limitOf('maxhours', nil);

    imgui.Text('Longest contract');
    imgui.SameLine();
    imgui.PushItemWidth(150);
    imgui.InputInt('##dwm_maxhours', form.hours, 1, 1);
    imgui.PopItemWidth();

    local hours = math.floor(tonumber(form.hours[1]) or LIST_HOURS_DEFAULT);

    hours = math.max(hours, 1);

    if (maxHours ~= nil) then
        hours = math.min(hours, maxHours);
    end

    form.hours[1] = hours;

    imgui.SameLine();
    imgui.TextDisabled(string.format('hours%s', maxHours ~= nil and string.format(' (up to %d)', maxHours) or ''));
    tooltipOnHover('The most a single hire can book. A hirer pays for whole hours up front,\nand the contract runs from the moment they pay whether they summon or not.');

    local chosen = {};

    for ordinal = 1, slots do
        if (form.picks[ordinal] ~= nil) then
            table.insert(chosen, form.picks[ordinal]);
        end
    end

    imgui.Spacing();
    imgui.Text('Fights by');
    tooltipOnHover('Up to three published rule sets. The hirer picks one when they summon,\nand can edit none of them -- how the mercenary fights is your authorship.');
    imgui.SameLine();
    imgui.TextDisabled(string.format('(%d of %d)', #chosen, slots));
    tooltipOnHover('How many of this listing\'s slots are filled. One is enough to publish;\nthree gives a hirer three ways to use the same mercenary.');

    for ordinal = 1, slots do
        loadoutPicker(ordinal);
    end

    -- What a contract at this rate would come to, and what the house would keep
    -- of it. AN ILLUSTRATION AND LABELLED AS ONE: the cut is the server's own
    -- number off the c| record and the settlement does the real arithmetic, at
    -- whatever the cut is on the day the contract ends. Nothing here gates
    -- anything, and no hirer is ever shown a price this file worked out.
    local tax = limitOf('tax', nil);

    if (tax ~= nil) then
        local gross = rate * hours;
        local yours = gross - math.floor(gross * tax / 100);

        imgui.Spacing();
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled(string.format('A full %dh hire costs %s gil. The house keeps %d percent, so about %s would reach your ledger -- the settlement does the real sum.',
            hours, gilText(gross), tax, gilText(yours)));
        tooltipOnHover(TIPS.illustration);
        imgui.PopTextWrapPos();
    end

    imgui.Spacing();
    imgui.Separator();

    -- Held on the write rather than on the form, so switching characters
    -- mid-flight cannot orphan a spinner on a form that never sent anything.
    if (writePending ~= nil) then
        imgui.TextDisabled(string.format('%s %s...',
            writePending.what == 'unlist' and 'Taking' or 'Freezing',
            writePending.name));

        -- Silence must not hold the form hostage. Nothing was charged either
        -- way and nothing is re-sent: the server answers a write with the state
        -- it produced, so if it landed, the rows say so.
        if (os.clock() - writePending.at > 10.0) then
            writePending = nil;
            form.error   = 'No answer from the server. Nothing was re-sent -- Refresh shows where this character stands.';
        end

        return;
    end

    if (playing) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_WARN, string.format('You are playing %s.', cand.name));
        imgui.TextDisabled('A listing is a photograph of the SAVED character, and a session you are sitting in has not written one yet. Log in as another character on the account and list this one from there.');
        imgui.PopTextWrapPos();
    elseif (#chosen == 0) then
        imgui.TextDisabled('Pick at least one rule set -- how the mercenary fights is what a hirer is paying for.');
    else
        local command = listCommand(cand.name, rate, hours, chosen);

        if (#command > COMMAND_BUDGET) then
            imgui.PushTextWrapPos(0);
            imgui.TextColored(COLOR_ERROR, 'Those set names come to more than one chat line can carry, so this one has to be typed:');
            imgui.TextDisabled((string.gsub(command, '^!dwm', '!merc')));
            imgui.PopTextWrapPos();
        elseif (listing ~= nil and bit.band(listing.flags or 0, LISTING_OFF) == 0) then
            -- Already up. Re-listing takes a FRESH photograph and throws the
            -- one hirers are looking at away, which is worth the second click.
            if (confirmButton('dwm_relist', string.format('Re-freeze %s', cand.name),
                    'Take a new photograph -- the old one goes', 'list',
                    string.format('Freezes %s again as it stands now, at these numbers.\nThe same thing as: %s',
                        cand.name, (string.gsub(command, '^!dwm', '!merc'))))) then
                writePending = { what = 'list', name = cand.name, at = os.clock() };

                issueWrite(command);
            end
        else
            if (imgui.Button(string.format('Put %s on the board##dwm_list', cand.name))) then
                writePending = { what = 'list', name = cand.name, at = os.clock() };

                issueWrite(command);
            end

            tooltipOnHover(string.format('Freezes %s as it stands and puts it up for hire.\nThe same thing as: %s',
                cand.name, (string.gsub(command, '^!dwm', '!merc'))));
        end
    end

    -- Withdrawal, which is a state change rather than a purchase and is
    -- deliberately not offered for a listing already coming off (M4 defers a
    -- withdrawal made during a contract; saying it twice would only be noise).
    if (listing ~= nil and bit.band(listing.flags or 0, LISTING_OFF) == 0 and not listing.pending
            and writePending == nil) then
        imgui.Spacing();

        if (confirmButton('dwm_unlist', 'Take it off the board', 'Take it off -- sure?', 'unlist',
                string.format('Stops new hires. A contract already running is honoured to the hour\nand the listing comes off when it settles.\nThe same thing as: !merc unlist %s', cand.name))) then
            writePending = { what = 'unlist', name = cand.name, at = os.clock() };

            issueWrite(string.format('!dwm unlist %s', cand.name));
        end

        imgui.PushTextWrapPos(0);
        imgui.TextDisabled('The snapshot survives a withdrawal, so putting it back up is one click -- with a fresh photograph.');
        imgui.PopTextWrapPos();
    end
end

--[[
* The Battle tab (1.4.0; MERC_BATTLE_PLAN.md).
*
* Three panes in one tab: the board on the left (dares, matches counting down
* to the bell, fights under way, then the last results), and on the right
* either the Hall of Records, the form, or the explanation. Every button sends
* a line a player could type, and the only line that spends is
* `!dwm battle confirm`, which the form reaches only after the server's quote
* is on screen -- the hire dialog's shape, for the hire dialog's reasons.
--]]
local BATTLE_STAGE_TIMEOUT = 8.0;

local function battleClock(seconds)
    seconds = math.max(math.floor(seconds or 0), 0);

    return string.format('%d:%02d', math.floor(seconds / 60), seconds % 60);
end

local function battleReason(row)
    local reasons = {
        ko          = 'knock-out',
        double_ko   = 'both fell',
        timeout     = 'the clock ran out',
        noshow_a    = 'forfeit, owner absent',
        noshow_b    = 'forfeit, owner absent',
        noshow_both = 'nobody came',
        noseat_a    = 'forfeit, no party seat',
        noseat_b    = 'forfeit, no party seat',
        left_a      = 'forfeit, left the field',
        left_b      = 'forfeit, left the field',
        both_gone   = 'both left the field',
        withdrawn   = 'withdrawn',
        restart     = 'the arena restarted',
        lost        = 'the arena lost the fight',
    };

    return reasons[row.reason or '-'] or (row.reason ~= '-' and row.reason or '');
end

local function battleResultText(row)
    if (row.outcome == 'a') then
        return string.format('%s beat %s', row.a_name, row.b_name);
    elseif (row.outcome == 'b') then
        return string.format('%s beat %s', row.b_name, row.a_name);
    elseif (row.outcome == 'draw') then
        return string.format('%s and %s drew', row.a_name, row.b_name);
    end

    return string.format('%s vs %s, void', row.a_name, row.b_name);
end

local function openBattleForm(kind, row)
    bform = {
        kind      = kind,
        battleid  = row ~= nil and row.battleid or 0,
        against   = row ~= nil and row.a_name or nil,
        wager     = row ~= nil and row.wager or nil,
        listingid = 0,
        ordinal   = 1,
        stage     = 'pick',
        stageAt   = os.clock(),
        error     = nil,
    };

    -- The form's listing pick defaults to the first of the account's
    -- listings; the loadout to its first.
    if (#state.mine > 0) then
        bform.listingid = state.mine[1];
    end
end

local function battleForm()
    local limits = state.battle ~= nil and state.battle.limits or nil;

    if (bform.kind == 'accept') then
        imgui.TextColored(COLOR_BADGE, string.format('Challenging %s', bform.against or '?'));
        imgui.TextDisabled(string.format('The wager is %s gil, matched exactly. The fight is five minutes after you confirm, in Ru\'Lude Gardens.', gilText(bform.wager or 0)));
    else
        imgui.TextColored(COLOR_BADGE, 'Post a dare');
        imgui.TextDisabled('One of your listed mercenaries, frozen at 99/99, fighting by a rule set you wrote.');
    end

    imgui.Separator();

    if (bform.error ~= nil) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_ERROR, bform.error);
        imgui.PopTextWrapPos();
    end

    if (bform.stage == 'done') then
        imgui.PushTextWrapPos(0);

        if (bform.kind == 'accept') then
            imgui.Text(string.format('The fight is set. Be in Ru\'Lude Gardens when the bell rings -- the whole server has been told.'));
        else
            imgui.Text(string.format('Your dare is on the board. When somebody answers it, the whole server hears, and you have five minutes to reach Ru\'Lude Gardens.'));
        end

        imgui.PopTextWrapPos();

        if (imgui.Button('Close##dwm_bclose')) then
            bform = nil;
        end

        return;
    end

    -- The account's listings, asked for once if the My mercs tab never was.
    need('listings', 0, '!dwm listings');

    if (#state.mine == 0) then
        imgui.TextDisabled('You have nothing on the mercenary board. The Listing tab puts a character up; a contestant is one of your listed mercenaries.');
    end

    local chosen = state.listings[bform.listingid];

    imgui.Text('Mercenary');
    imgui.SameLine();
    imgui.PushItemWidth(columnWidth(WIDEST_NAME, 30));

    if (imgui.BeginCombo('##dwm_bmerc', chosen ~= nil and chosen.name or 'pick one')) then
        for _, listingid in ipairs(state.mine) do
            local entry = state.listings[listingid];

            if (entry ~= nil and imgui.Selectable(string.format('%s##dwm_bmerc_%d', entry.name, listingid), bform.listingid == listingid)) then
                bform.listingid = listingid;
                bform.ordinal   = 1;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    if (chosen ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(jobsText(chosen));
    end

    local names = state.loadouts[bform.listingid] or {};

    imgui.Text('Loadout');
    imgui.SameLine();
    imgui.PushItemWidth(columnWidth(WIDEST_LOADOUT, 30));

    if (imgui.BeginCombo('##dwm_bload', names[bform.ordinal] or string.format('loadout %d', bform.ordinal))) then
        for ordinal = 1, 3 do
            if (names[ordinal] ~= nil and imgui.Selectable(string.format('%s##dwm_bload_%d', names[ordinal], ordinal), bform.ordinal == ordinal)) then
                bform.ordinal = ordinal;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    local wager = bform.wager;

    if (bform.kind == 'register') then
        local floor = (limits ~= nil and limits.minwager > 0) and limits.minwager or 10000;
        local buf   = bufferOf('bwager', floor);

        imgui.Text('Wager');
        imgui.SameLine();
        imgui.PushItemWidth(110);
        imgui.InputInt('##dwm_bwager', buf, 1000, 10000);
        imgui.PopItemWidth();

        if (limits ~= nil and limits.minwager > 0) then
            imgui.SameLine();
            imgui.TextDisabled(string.format('%s to %s gil', gilText(limits.minwager), gilText(limits.maxwager)));
        end

        wager = math.floor(tonumber(buf[1]) or 0);
    end

    imgui.Separator();

    if (bform.stage == 'pick') then
        local ready = chosen ~= nil and names[bform.ordinal] ~= nil and wager ~= nil and wager > 0;

        if (not ready) then
            imgui.BeginDisabled();
        end

        if (imgui.Button('Quote##dwm_bquote') and ready) then
            -- WHOLE AND IN RANGE BEFORE IT IS FORMATTED INTO A LINE.
            local line;

            if (bform.kind == 'accept') then
                line = string.format('!dwm battle accept %d %s %d', bform.battleid, chosen.name, bform.ordinal);
            else
                line = string.format('!dwm battle register %s %d %d', chosen.name, bform.ordinal, wager);
            end

            bform.stage   = 'quoting';
            bform.stageAt = os.clock();
            bform.error   = nil;
            state.bquote  = nil;

            issueRead(line);
        end

        if (not ready) then
            imgui.EndDisabled();
        end

        tooltipOnHover(TIPS.dareQuote);
        imgui.SameLine();
        imgui.TextDisabled('The server quotes first. Nothing is taken until you confirm that quote.');
    elseif (bform.stage == 'quoting') then
        imgui.Text('Asking for a quote...');

        if (elapsed(bform.stageAt) > BATTLE_STAGE_TIMEOUT) then
            bform.stage = 'pick';
            bform.error = 'No quote arrived. Try again.';
        end
    elseif (bform.stage == 'quoted') then
        local quote = state.bquote;

        if (quote == nil or quote.stage ~= 'quote' or elapsed(quote.at) > math.max(quote.expires - 3, 5)) then
            bform.stage = 'pick';
            bform.error = 'The quote expired. Ask again.';
        else
            imgui.PushTextWrapPos(0);
            imgui.Text(string.format('%s, fighting by "%s", for %s gil.%s', quote.name, names[quote.ordinal] or ('loadout ' .. quote.ordinal), gilText(quote.wager),
                quote.gil < quote.wager and string.format(' You are carrying %s.', gilText(quote.gil)) or ''));
            imgui.PopTextWrapPos();

            local short = quote.gil < quote.wager;

            if (short) then
                imgui.BeginDisabled();
            end

            local label = bform.kind == 'accept'
                and string.format('Challenge for %s gil##dwm_bconfirm', gilText(quote.wager))
                or string.format('Post for %s gil##dwm_bconfirm', gilText(quote.wager));

            if (imgui.Button(label) and not short) then
                bform.stage   = 'paying';
                bform.stageAt = os.clock();
                battlePending = os.clock();

                issueWrite('!dwm battle confirm');
            end

            if (short) then
                imgui.EndDisabled();
            end

            tooltipOnHover(TIPS.dareConfirm);
        end
    elseif (bform.stage == 'paying') then
        imgui.Text('Posting...');

        -- Silence here is the one outcome that may NOT be retried: a confirm
        -- that was sent and lost could also be a confirm that landed.
        if (elapsed(bform.stageAt) > BATTLE_STAGE_TIMEOUT) then
            bform.stage = 'pick';
            bform.error = 'No answer arrived. Check the board before confirming again -- !merc battle shows what was posted.';
            requested['battle'] = nil;
        end
    end

    imgui.SameLine();

    if (imgui.SmallButton('Cancel##dwm_bcancel')) then
        bform = nil;
    end
end

local function hallPane()
    local page = math.max(math.floor(tonumber(bufferOf('bhallpage', 1)[1]) or 1), 1);

    need('records', page, page > 1 and string.format('!dwm battle records %d', page) or '!dwm battle records');

    imgui.TextColored(COLOR_BADGE, 'Hall of Records');
    tooltipOnHover(TIPS.hall);

    local hall = state.records;

    if (hall == nil) then
        imgui.TextDisabled('Fetching the records...');
        return;
    end

    if (hall.pages > 1) then
        imgui.SameLine();

        if (imgui.SmallButton('< Prev##dwm_bhprev') and hall.page > 1) then
            bufferOf('bhallpage', 1)[1] = hall.page - 1;
            requested['records'] = nil;
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('page %d of %d', hall.page, hall.pages));
        imgui.SameLine();

        if (imgui.SmallButton('Next >##dwm_bhnext') and hall.page < hall.pages) then
            bufferOf('bhallpage', 1)[1] = hall.page + 1;
            requested['records'] = nil;
        end
    end

    if (#hall.rows == 0) then
        imgui.TextDisabled('Nobody has registered yet. Post a dare and your mercenary gets a line.');
        return;
    end

    if (imgui.BeginTable('##dwm_bhall', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, columnWidth('999'), 0);
        imgui.TableSetupColumn('Contestant', ImGuiTableColumnFlags_WidthFixed, columnWidth(WIDEST_NAME), 0);
        imgui.TableSetupColumn('W-L-D', ImGuiTableColumnFlags_WidthFixed, columnWidth('999-999-999'), 0);
        imgui.TableSetupColumn('Points', ImGuiTableColumnFlags_WidthFixed, columnWidth('99999'), 0);
        imgui.TableHeadersRow();

        for _, row in ipairs(hall.rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(string.format('%d', row.rank));
            imgui.TableNextColumn();

            if (row.mine) then
                imgui.TextColored(COLOR_BADGE, row.name);
            else
                imgui.Text(row.name);
            end

            imgui.TableNextColumn();
            imgui.Text(string.format('%d-%d-%d', row.wins, row.losses, row.draws));
            imgui.TableNextColumn();
            imgui.Text(string.format('%d', row.points));
        end

        imgui.EndTable();
    end
end

local function battleTab()
    need('battle', 0, '!dwm battle');

    local board  = state.battle;
    local limits = board ~= nil and board.limits or nil;
    local view   = bufferOf('bview', 'board');

    if (imgui.SmallButton('Refresh##dwm_brefresh')) then
        requested['battle']  = nil;
        requested['records'] = nil;
    end

    imgui.SameLine();

    if (imgui.SmallButton('Post a dare##dwm_bpost')) then
        openBattleForm('register', nil);
        view[1] = 'board';
    end

    tooltipOnHover(TIPS.darePost);
    imgui.SameLine();

    if (imgui.SmallButton((view[1] == 'records' and 'Board' or 'Hall of Records') .. '##dwm_bhall')) then
        view[1] = view[1] == 'records' and 'board' or 'records';
    end

    tooltipOnHover(TIPS.hall);

    if (limits ~= nil and limits.purse > 0) then
        imgui.SameLine();
        imgui.TextColored(COLOR_OK, string.format('%s gil from battles waits on your ledger -- claim it on My mercs.', gilText(limits.purse)));
    end

    -- Fights under way are re-asked every few seconds: HP is news.
    local fighting = false;

    if (board ~= nil) then
        for _, row in ipairs(board.live) do
            if (row.state == 'fighting') then
                fighting = true;
            end
        end
    end

    if (fighting) then
        if (state.fightsAt == nil or elapsed(state.fightsAt) > 5.0) then
            requested['bstatus'] = nil;
            state.fightsAt       = os.clock();
        end

        need('bstatus', 0, '!dwm battle status');
    end

    local numW  = columnWidth('#9999');
    local whoW  = columnWidth(WIDEST_NAME .. ' vs ' .. WIDEST_NAME);
    local gilW  = columnWidth(WIDEST_GIL);
    local whenW = columnWidth('bell in 59:59');
    local actW  = columnWidth('Challenge');

    imgui.BeginChild('##dwm_blist', { childWidthFor(5, { numW, whoW, gilW, whenW, actW }), 0 }, ImGuiChildFlags_Borders);

    if (board == nil) then
        imgui.Text('Fetching the arena...');
    elseif (#board.live == 0 and #board.recent == 0) then
        imgui.Text('No dares on the board.');
        imgui.TextDisabled('Post a dare with one of your listed mercenaries; anyone may answer it.');
    elseif (imgui.BeginTable('##dwm_battles', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, numW, 0);
        imgui.TableSetupColumn('Contestants', ImGuiTableColumnFlags_WidthFixed, whoW, 0);
        imgui.TableSetupColumn('Wager', ImGuiTableColumnFlags_WidthFixed, gilW, 0);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, whenW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, actW, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(board.live) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(string.format('#%d', row.battleid));
            imgui.TableNextColumn();

            if (row.state == 'open') then
                imgui.Text(row.a_name);
                tooltipOnHover(TIPS.dareRow);
            else
                imgui.Text(string.format('%s vs %s', row.a_name, row.b_name));
            end

            imgui.TableNextColumn();
            imgui.Text(gilText(row.wager));
            imgui.TableNextColumn();

            if (row.state == 'open') then
                if (row.online) then
                    imgui.TextDisabled('waiting');
                else
                    imgui.TextDisabled('owner away');
                    tooltipOnHover(TIPS.dareAway);
                end
            elseif (row.state == 'matched') then
                -- The server's count, run down locally for display only.
                local left = math.max((row.fight_in or 0) - elapsed(row.at), 0);
                imgui.TextColored(COLOR_WARN, string.format('bell in %s', battleClock(left)));
            else
                local fight = state.fights[row.battleid];

                if (fight ~= nil) then
                    imgui.TextColored(COLOR_OK, string.format('%d / %d, %s', fight.a_hpp, fight.b_hpp, battleClock(fight.left)));
                else
                    imgui.TextColored(COLOR_OK, 'FIGHTING');
                end

                tooltipOnHover(TIPS.fight);
            end

            imgui.TableNextColumn();

            if (row.state == 'open') then
                if (row.mine == 1) then
                    if (imgui.SmallButton(string.format('Withdraw##dwm_bwd_%d', row.battleid))) then
                        issueWrite(string.format('!dwm battle withdraw %d', row.battleid));
                    end

                    tooltipOnHover(TIPS.dareWithdraw);
                elseif (row.online) then
                    if (imgui.SmallButton(string.format('Challenge##dwm_bchal_%d', row.battleid))) then
                        openBattleForm('accept', row);
                        view[1] = 'board';
                    end

                    tooltipOnHover(TIPS.dareRow);
                end
            elseif (row.mine ~= 0) then
                imgui.TextColored(COLOR_BADGE, '(yours)');
            end
        end

        for _, row in ipairs(board.recent) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.TextDisabled(string.format('#%d', row.battleid));
            imgui.TableNextColumn();
            imgui.TextDisabled(battleResultText(row));
            tooltipOnHover(battleReason(row));
            imgui.TableNextColumn();
            imgui.TextDisabled(gilText(row.wager));
            imgui.TableNextColumn();
            imgui.TextDisabled(row.outcome == 'draw' and 'draw' or (row.outcome == 'void' and 'void' or 'decided'));
            imgui.TableNextColumn();

            if (row.mine ~= 0) then
                imgui.TextDisabled('(yours)');
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();

    imgui.SameLine();

    imgui.BeginChild('##dwm_binfo', { 0, 0 }, ImGuiChildFlags_Borders);

    if (bform ~= nil) then
        battleForm();
    elseif (view[1] == 'records') then
        hallPane();
    else
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_BADGE, 'How the arena works');
        imgui.Text('Post a dare with one of your listed mercenaries and a wager. Anyone may answer it with one of theirs, matching the wager.');
        imgui.Text('Five minutes after a dare is answered, both contestants appear in Ru\'Lude Gardens and fight by the rule sets their owners published. Both owners must be there, or the absent side forfeits.');

        if (limits ~= nil) then
            imgui.Text(string.format('Wagers run %s to %s gil. The winner takes the pot minus a %d percent house cut; a draw refunds both. Fights last up to %s. Contestants must be frozen at %d/%d.',
                gilText(limits.minwager), gilText(limits.maxwager), limits.cutpct, battleClock(limits.duration), limits.level, limits.level));
        end

        imgui.Text('Nobody can target a contestant, no command reaches one, and every hit and cure lands at a fraction of its number so a fight is minutes rather than one weapon skill.');
        imgui.PopTextWrapPos();
    end

    imgui.EndChild();
end

local function listingTab()
    if (optionsUnsupported) then
        imgui.PushTextWrapPos(0);
        imgui.Text('This server is older than the Listing tab -- it has no !merc options to answer with.');
        imgui.TextDisabled('Listing still works typed, from a character you are NOT playing:');
        imgui.TextDisabled('  !merc list <char> <rate> <maxhours> <set> [set] [set]');
        imgui.TextDisabled('  !merc unlist <char>');
        imgui.PopTextWrapPos();

        return;
    end

    need('options', 0, '!dwm options');

    if (#state.candidates == 0) then
        imgui.Text('Reading your characters...');

        return;
    end

    imgui.PushTextWrapPos(0);
    imgui.TextDisabled('Put a character of your own up for hire. It keeps earning while you are logged out, '
        .. 'and what it earns waits on the ledger under My mercs.');
    imgui.PopTextWrapPos();

    -- The three column widths and the child that has to hold them, measured
    -- rather than hand-tuned. The numbers that used to be here (105 / 128 /
    -- 120 inside 385) were arrived at twice by trying them in game, and the
    -- comment recording the second attempt -- "128: the widest live pair is a
    -- two-digit main and a two-digit sub, which 95 clipped the sub level off"
    -- is exactly the arithmetic CalcTextSize does for free.
    local candNameW = columnWidth(WIDEST_NAME);
    local candJobW  = columnWidth(WIDEST_JOBS);
    local candMarkW = columnWidth('off the board');

    imgui.BeginChild('##dwm_candlist',
        { childWidthFor(3, { candNameW, candJobW, candMarkW }), 0 }, ImGuiChildFlags_Borders);

    if (imgui.BeginTable('##dwm_cands', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Character', ImGuiTableColumnFlags_WidthFixed, candNameW, 0);
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, candJobW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, candMarkW, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, cand in ipairs(state.candidates) do
            local listing = candidateListing(cand);

            imgui.TableNextRow();
            imgui.TableNextColumn();

            if (imgui.Selectable(string.format('%s##dwm_cand_%d', cand.name, cand.charid),
                    form ~= nil and form.charid == cand.charid)) then
                buildForm(cand);
            end

            tooltipOnHover(TIPS.candidate);

            imgui.TableNextColumn();

            -- The LIVE jobs, unlike everywhere else in this window: this column
            -- is answering "what would a photograph taken now capture".
            imgui.Text(jobsText(cand));

            imgui.TableNextColumn();

            if (listing == nil) then
                if (bit.band(cand.flags or 0, CAND_SELF) ~= 0) then
                    imgui.TextDisabled('playing this');
                    tooltipOnHover('A listing is a photograph of the SAVED character, and the session you are\nsitting in has not written one. Log in as another character on the account\nand list this one from there.');
                elseif (bit.band(cand.flags or 0, CAND_BUSY) ~= 0) then
                    imgui.TextDisabled('with your squad');
                    tooltipOnHover('Out with your own squad this moment. That does not stop you listing it --\nthe snapshot is taken from the saved record either way.');
                else
                    imgui.TextDisabled('not listed');
                    tooltipOnHover('Never been on the board. Listing is free and takes nothing away from\nthe character: it copies what is saved, and the copy is what a hirer gets.');
                end
            elseif (listing.pending) then
                imgui.TextColored(COLOR_WARN, 'coming off');
                tooltipOnHover('Withdrawn while a contract was running. The hirer keeps the hours they\npaid for and it leaves the board when that contract settles.');
            elseif (bit.band(listing.flags or 0, LISTING_OFF) ~= 0) then
                imgui.TextDisabled('off the board');
                tooltipOnHover(TIPS.markOff);
            elseif (bit.band(listing.flags or 0, LISTING_WORKING) ~= 0) then
                imgui.TextColored(COLOR_HINT, 'hired out');
                tooltipOnHover('Somebody is paying for it right now. It comes back on the board when\nthat contract settles, and the My mercs tab says who and for how long.');
            else
                imgui.TextColored(COLOR_OK, 'on the board');
                tooltipOnHover('Up for hire. Re-freezing replaces the photograph hirers are looking at.');
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();

    imgui.SameLine();

    imgui.BeginChild('##dwm_candform', { 0, 0 }, ImGuiChildFlags_Borders);

    -- The form follows the pick, and a pick that has gone -- a character
    -- renamed or deleted between reads -- drops back to the prompt rather than
    -- to a form describing nobody.
    local picked = nil;

    if (form ~= nil) then
        for _, cand in ipairs(state.candidates) do
            if (cand.charid == form.charid) then
                picked = cand;
            end
        end
    end

    if (picked == nil) then
        imgui.TextDisabled('Click one of your characters to put it up, change what it asks, or take it off.');

        if (#state.sets == 0) then
            imgui.Spacing();
            imgui.PushTextWrapPos(0);
            imgui.TextColored(COLOR_WARN, 'No rule sets have reached this window yet.');
            imgui.TextDisabled('A mercenary is listed by the rules it fights by. !squad rules list shows yours and !squad rules presets the shipped ones.');
            imgui.PopTextWrapPos();
        end
    else
        listingForm(picked);
    end

    imgui.EndChild();
end

--[[
* Every typed verb, in one place. The window covers all of them now, but the
* commands are the tier that keeps working when an addon does not -- and a
* player who knows they exist is a player who can still list a mercenary from a
* client with no addons loaded at all.
--]]
local HELP_LINES =
{
    { '!merc board [job] [page]', 'who is for hire' },
    { '!merc info <name>', 'one mercenary in full' },
    { '!merc quote <name> <hours>', 'what a contract would cost -- spends nothing' },
    { '!merc hire <name> <hours>', 'the same quote; type it again to pay' },
    { '!merc confirm', 'pays the quote you were just shown' },
    { '!merc call <name> [loadout]', 'put a hired mercenary in your party' },
    { '!merc dismiss <name>', 'send one home -- the contract keeps running' },
    { '!merc release <name>', 'end a contract early -- no refund, so it asks twice' },
    { '!merc contracts', 'what you have running' },
    { '!merc options', 'which of yours could be listed, and with what' },
    { '!merc list <char> <rate> <maxhours> <set>', 'put one of yours up for hire' },
    { '!merc unlist <char>', 'take it back off the board' },
    { '!merc listings', 'what you have up, and what each has earned' },
    { '!merc earnings', 'contract by contract, where that gil came from' },
    { '!merc claim', 'collect what you are owed, to the character here' },
    { '!merc menu', 'the same picks as a game menu, no addon needed' },
    { '!merc help', 'all of this, in chat' },
};

local function helpPopup()
    if (not imgui.BeginPopup('##dwm_help')) then
        return;
    end

    imgui.TextColored(COLOR_BADGE, 'Everything this window does, typed');
    imgui.PushTextWrapPos(400);
    imgui.TextDisabled('The commands are the real tier and this window is a renderer over them. '
        .. 'Nothing here can do anything they cannot.');
    imgui.PopTextWrapPos();
    imgui.Separator();

    -- Measured off the longest row rather than the two round numbers that used
    -- to be here: `!merc list <char> <rate> <maxhours> <set>` is 41 characters
    -- and 270 pixels does not hold it.
    local verbW = 0;
    local sayW  = 0;

    for _, row in ipairs(HELP_LINES) do
        verbW = math.max(verbW, columnWidth(row[1]));
        sayW  = math.max(sayW, columnWidth(row[2]));
    end

    if (imgui.BeginTable('##dwm_helptable', 2, ImGuiTableFlags_SizingFixedFit, { 0, 0 })) then
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, verbW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, sayW, 0);

        for _, row in ipairs(HELP_LINES) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row[1]);
            imgui.TableNextColumn();
            imgui.TextDisabled(row[2]);
        end

        imgui.EndTable();
    end

    imgui.Separator();
    imgui.TextDisabled('/merc opens and closes this window. /merc refresh re-reads everything.');

    imgui.EndPopup();
end

--[[
* A tab's label with its count, and its ID PINNED WITH `###` (1.3.0).
*
* ImGui takes a widget's label AS its id. A label that moves from "Contracts"
* to "Contracts (1)" is a new tab as far as the bar is concerned -- the
* selection jumps back to the first one, and the player loses their place the
* instant a purchase lands. `###dwm_tab_x` replaces the whole id with a fixed
* one, which is what makes a changing label safe to use at all.
*
* Zero is drawn as no count rather than as "(0)": an empty tab should read as
* quiet, not as a number. At file scope rather than inside renderWindow so the
* closure is built once instead of sixty times a second.
--]]
local function countLabel(name, id, count)
    if (count == nil or count <= 0) then
        return string.format('%s###%s', name, id);
    end

    return string.format('%s (%d)###%s', name, count, id);
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        forget();

        state.refreshedAt = os.clock();
    end

    tooltipOnHover(TIPS.refresh);

    imgui.SameLine();

    if (imgui.Button('Commands')) then
        imgui.OpenPopup('##dwm_help');
    end

    tooltipOnHover(TIPS.commands);

    helpPopup();

    imgui.SameLine();

    local pending = #readQueue + #writeQueue;

    if (pending > 0) then
        imgui.TextDisabled(string.format('%d queued...', pending));
        tooltipOnHover(TIPS.queued);
    elseif (state.refreshedAt ~= nil) then
        -- WHEN, not just THAT. Refresh throws every answer away and asks
        -- again, and with a fast server the panes redraw with the same numbers
        -- -- which reads exactly like a button that did nothing.
        imgui.TextDisabled(string.format('read %s ago', spanText(math.max(os.clock() - state.refreshedAt, 0))));
        tooltipOnHover('How long ago Refresh last threw everything away and asked again. The panes\nalso re-ask on their own when something they show has changed.');
    else
        imgui.TextDisabled('');
    end

    -- The message line gets its own row and errors are red: a refusal's
    -- reason is the only thing telling the player what to do instead.
    --
    -- THE ROW IS ALWAYS DRAWN, even with nothing in it. It used to be skipped
    -- when the line was empty, which was invisible while every verb answered
    -- with an m| note -- and then STATUS_DWELL gave the line a way to become
    -- empty, and the whole tab bar and both panes jumped up a line for the
    -- second or two until the next answer refilled it.
    --
    -- WRAPPED, too: the wire trims a sentence to 130 bytes and the longest
    -- refusals in merc.lua run the whole of it, which at this font is wider
    -- than the window's default and was cut off at the frame edge -- a
    -- shortened sentence a player could not tell had been shortened, which is
    -- the exact failure the server's own ellipsis exists to name.
    imgui.PushTextWrapPos(0);

    if (state.status == nil or state.status == '') then
        imgui.Text('');
    elseif (state.statusBad) then
        imgui.TextColored(COLOR_ERROR, state.status);
        tooltipOnHover(TIPS.status);
    else
        imgui.TextColored(COLOR_OK, state.status);
        tooltipOnHover(TIPS.status);
    end

    imgui.PopTextWrapPos();

    imgui.Separator();

    if (imgui.BeginTabBar('##dwm_tabs')) then
        local openBoard = imgui.BeginTabItem(countLabel('Board', 'dwm_tab_board',
            state.board ~= nil and state.board.total or 0));

        tooltipOnHover(TIPS.tabBoard);

        if (openBoard) then
            boardTab();
            imgui.EndTabItem();
        end

        local openContracts = imgui.BeginTabItem(countLabel('Contracts', 'dwm_tab_contracts',
            #state.contracts.active));

        tooltipOnHover(TIPS.tabContract);

        if (openContracts) then
            contractsTab();
            imgui.EndTabItem();
        end

        local openMine = imgui.BeginTabItem(countLabel('My mercs', 'dwm_tab_mine', #state.mine));

        -- The COUNT is the listings, which is a fact; the gil is news, and news
        -- belongs in the sentence rather than in a number that would then be
        -- lying about how many listings there are.
        tooltipOnHover((state.purse ~= nil and state.purse.balance > 0)
            and string.format('%s gil is waiting on your ledger. %s', gilText(state.purse.balance), TIPS.tabMine)
            or TIPS.tabMine);

        if (openMine) then
            myMercsTab();
            imgui.EndTabItem();
        end

        local liveCount  = state.battle ~= nil and #state.battle.live or 0;
        local openBattle = imgui.BeginTabItem(countLabel('Battle', 'dwm_tab_battle', liveCount));

        tooltipOnHover(TIPS.tabBattle);

        if (openBattle) then
            battleTab();
            imgui.EndTabItem();
        end

        local openListing = imgui.BeginTabItem('Listing###dwm_tab_listing');

        tooltipOnHover(TIPS.tabListing);

        if (openListing) then
            listingTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake costs one frame rather than the addon:
* an error thrown inside d3d_present is raised sixty times a second and the
* host answers a long enough run of them by unloading the addon. Begin/End
* stay outside the pcall to keep ImGui's stack balanced; the theme wraps
* Begin/End the same way; the error is reported once; the window closes
* itself. Everything it does is still reachable as !merc commands, so closing
* it is a fallback rather than a dead end.
--]]
ashita.events.register('d3d_present', 'dwmerc_present', function ()
    -- Before the visibility check: a confirm issued a moment before closing
    -- the window still has to reach the server.
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 900, 520 }, ImGuiCond_FirstUseEver);

    --[[
    * A FLOOR UNDER THE WINDOW (2026-09-06). Two of the four tabs are a fixed
    * list beside a pane that takes what is left -- the board and its info
    * pane, the roster and the listing form -- and the list side is sized from
    * the widest values the wire can carry, so it does not shrink. Dragged
    * narrow enough, the right-hand pane went to nothing and the hire dialog
    * with it: the Pay button, the quote, the countdown, all off the edge, on a
    * window carrying NoScrollbar. FirstUseEver means the size is the player's
    * once they have touched it, so the only thing that can stop that is a
    * minimum, and nothing in this suite had one.
    *
    * The height matters for the same reason on the tab that has no list: the
    * Listing form's rate, hours and three pickers stack, and the two buttons
    * that publish are underneath them.
    --]]
    imgui.SetNextWindowSizeConstraints({ 700, 400 }, { 99999, 99999 });

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Mercenaries##dwmerc', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwmerc'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwmerc'):append(chat.message('Window closed. Everything it does also works typed as !merc commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Watch what the player sends, for two money-shaped reasons beyond the usual
* throttle bookkeeping. A typed `!merc` line can change everything this window
* shows, so the asks are forgotten and re-made. And a typed HIRE line arms the
* same server-side quote window this addon's own quote button does -- the
* proof is in MERC_PLAN.md's phase log, where a `!dwm` quote was confirmed by
* a typed line -- so it feeds the same lockout, whichever tier it came from.
* Every other outgoing line still counts against the chat throttle: the
* client's rate limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwmerc_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = string.lower(message);

    if (lower:sub(1, 4) ~= '!dwm') then
        lastSend = os.clock();
    end

    if (lower:match('^!merc%s') ~= nil or lower:match('^!dwm%s') ~= nil) then
        local tokens = {};

        for token in string.gmatch(lower, '%S+') do
            table.insert(tokens, token);
        end

        local verb = tokens[2];

        if (verb == 'buy' or verb == 'rent') then
            verb = 'hire';
        elseif (verb == 'price' or verb == 'cost') then
            verb = 'quote';
        end

        -- `hire <name>` with no hours falls through to info server-side and
        -- arms nothing, which is why the hours token has to be numeric here.
        -- A quote line arms the same window a hire line does (that is what
        -- makes `confirm` able to pay it), so both feed the lockout -- and
        -- both REPLACE the server's one pending slot, so a quote this window
        -- is still showing no longer describes what confirm would buy. The
        -- held copy goes, and a dialog sitting on it drops back to ask again.
        if ((verb == 'hire' or verb == 'quote') and tokens[3] ~= nil and tonumber(tokens[4]) ~= nil) then
            armedHire = {
                name    = tokens[3],
                hours   = tonumber(tokens[4]),
                loadout = tokens[5] ~= nil and table.concat(tokens, ' ', 5) or nil,
                at      = os.clock(),
            };

            heldQuote = nil;

            if (dialog ~= nil and dialog.stage == 'quoted') then
                dialog.stage   = 'pick';
                dialog.stageAt = os.clock();
                dialog.quote   = nil;
                dialog.error   = 'A newer quote was asked for outside this dialog -- ask again to see the price.';
            end
        end
    end

    if (lower:sub(1, 5) == '!merc') then
        forget();
    end
end);

ashita.events.register('command', 'dwmerc_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Merc`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/merc' and first ~= '/dwmerc') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        forget();

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported`
        -- exists to stop one bad frame printing sixty lines a second, not to
        -- silence a different error a week later.
        state.reported = false;

        forget();
    end
end);

ashita.events.register('load', 'dwmerc_load', function ()
    print(chat.header('dwmerc'):append(chat.message('/merc opens the mercenary board. Everything it does also works typed as !merc.')));
end);

-- A login is a different account view; the world state resets. The armed-hire
-- lockout deliberately survives -- it is time-bounded and keyed to the last
-- hire line sent, and a server-side quote window does not care that the
-- client zoned.
ashita.events.register('packet_in', 'dwmerc_zonein', function (e)
    if (e.id == 0x000A) then
        state.listings  = {};
        state.loadouts  = {};
        state.board     = nil;
        state.mine       = {};
        state.mineByName = {};
        state.contracts = { active = {}, recent = {} };
        state.purse      = nil;
        state.ledger     = nil;
        state.claim      = nil;
        state.selected   = nil;
        state.lookupWant = nil;
        state.lookupSaid = nil;
        state.inbound    = nil;
        state.buffer     = {};
        state.status      = 'Fetching...';
        state.statusBad   = false;
        state.statusAt    = 0;
        state.refreshedAt = nil;
        state.candidates = {};
        state.sets       = {};
        state.setsByName = {};
        state.limits     = nil;
        state.boardPage  = nil;
        state.battle     = nil;
        state.records    = nil;
        state.bquote     = nil;
        state.fights     = {};
        state.fightsAt   = nil;

        -- THE PAGER GOES WITH THE BOARD IT WAS PAGING. Page 2 of the board
        -- this session was reading is not a page of the board the next one
        -- gets, and the store clamps a page past the end -- which the answer
        -- guard reads as a stale answer and drops, leaving the pane fetching
        -- forever with no pager drawn to escape with (2026-09-06).
        bufferOf('boardpage', 1)[1] = 1;

        -- READS QUEUED FOR THE OTHER SIDE OF THE ZONE GO WITH IT. Nothing is
        -- lost: forget() below re-arms every ask, and the panes re-issue on
        -- their next frame with the qualifiers they have NOW -- where a
        -- carried-over line asks about the page, the filter or the listing
        -- that was on screen before the load screen. Writes are deliberately
        -- untouched: a queued write left the player's own finger and this
        -- addon never silently drops one.
        readQueue = {};

        itemDescriptions = {};

        dialog        = nil;
        heldQuote     = nil;
        claimPending  = nil;
        claimTimedOut = false;
        actPending    = {};

        -- The listing form describes an account, and this is a different one
        -- until the reads say otherwise. A write in flight goes with it: its
        -- answer was addressed to a session that no longer exists, and the
        -- Listing tab's own rows are what say whether it landed.
        form         = nil;
        writePending = nil;

        -- Asked again on the other side: the server may have grown the quote
        -- verb, or the options verb, since the last look (a map restart logs
        -- everyone out).
        quoteUnsupported   = false;
        optionsUnsupported = false;

        forget();
    end
end);
