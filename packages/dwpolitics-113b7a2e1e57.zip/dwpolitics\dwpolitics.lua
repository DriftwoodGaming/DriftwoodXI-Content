--[[
* DriftwoodXI -- dwpolitics
*
* The seats of power in a window: the Crown of Vana'diel, the Mayors of
* Bastok, San d'Oria and Windurst, and the Royal Treasurer, each won by a
* vote of every eligible account on a four-week season clock. The window
* shows the season and its phase, every seat and its holder, every race with
* its candidates, platforms, pledges and endorsements, whether YOU may file
* or vote in each (the server's gates, in the server's words), the Treasury,
* every act in effect, the Wanted list and the Chronicle. A holder's powers
* are buttons.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited
* whole). Everything arrives on the wire as records, and every button is a
* real typed command (`!dwb vote bastok Ayla` reaches exactly the dispatch
* `!politics vote bastok Ayla` reaches). The server holds the ballots, runs
* the count and clamps every power; this window can never do anything a
* player cannot.
*
* TURN IT OFF AND NOTHING IS LOST. `!politics` does all of it typed.
*
* The notice reroute, the answer clock, the latches, the debounces and the
* commit-on-z| discipline are dwnemesis 1.3.1's, inherited whole; the
* comments that explain them live there and are not repeated here.
--]]

addon.name    = 'dwpolitics';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.1';
addon.desc    = 'DriftwoodXI Politics: run for a seat, vote, pledge, govern, read the Chronicle.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

echo.install();

local DATA_SENDER = '_DWBDATA';
local PROTOCOL    = 1;

-- KEEP IN SYNC WITH `NOTICE` IN modules/driftwoodxi/politics_core.lua.
local NOTICE_TAG  = '[Politics] ';
local NOTICE_MODE = 121;

-- KEEP IN SYNC WITH `SEATS` IN politics_core.lua (the harness reads both).
local SEAT_KEYS  = { 'crown', 'bastok', 'sandoria', 'windurst', 'treasurer' };
local SEAT_NAMES = { "Crown of Vana'diel", 'Mayor of Bastok', "Mayor of San d'Oria", 'Mayor of Windurst', 'Royal Treasurer' };
local SEAT_SHORT = { 'Crown', 'Bastok', "San d'Oria", 'Windurst', 'Treasurer' };

local DECREE_WORDS   = { 'exp', 'capacity', 'fame', 'shop', 'chocobo' };
local FESTIVAL_WORDS = { 'shop', 'chocobo', 'fame' };

local WIRE_MAX = 2147483647;

local function wireInt(text, default)
    local value = tonumber(text);

    if (value == nil or value ~= value or value < -WIRE_MAX or value > WIRE_MAX or value ~= math.floor(value)) then
        return default or 0;
    end

    return value;
end

local state = T{
    open = T{ false },

    -- The board, committed on z|status from a pending copy.
    season    = nil,   -- { season, phase, phaseEnds, day, crown, serverNow }
    seats     = {},    -- [idx] = { name, mandate, from, to, mine }
    races     = {},    -- [idx] = { candidates = {}, canFile, fileReason, canVote, voted, bonus, voteReason }
    treasury  = nil,   -- { balance, income, spend }
    owed      = 0,
    acts      = {},
    enemy     = nil,
    wanted    = {},
    syncedAt  = nil,
    clockSkew = 0,     -- serverNow - os.time() at commit

    -- The Chronicle, committed on z|chronicle.
    chronicle = { page = 1, per = 12, total = 0, rows = {} },
    chronPending = nil,
    chronAsked   = nil,

    pending   = nil,
    inbound   = nil,
    status    = '',
    statusBad = false,
    reported  = false,

    requested    = nil,
    serverSilent = false,
    refused      = false,
    boardFailed  = false,

    -- One debounce per write verb, PAST the queue's dupe-collapse.
    writeAt = {},

    -- Inputs for the powers that take an argument.
    inName   = T{ '' },
    inNumber = T{ '' },
    inEnemy  = T{ '' },
    inPot    = T{ '' },
    inAct    = T{ '' },
    inText   = T{ '' },
    inVote   = T{ '' },
};

local TIPS = {
    refresh      = 'Ask the server for the board again. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks -- update dwpolitics through the launcher.',
    claim        = 'Collect every gil payout owed to your account: refunds, pledge shares, bounties, stimulus.',
    file         = 'File for this seat. The filing fee is held until the count and refunded if you win.',
    fileNo       = 'Why you cannot file for this seat right now, in the server\'s words.',
    vote         = 'Cast your ballot for this candidate as first choice. Rank more by typing !politics vote <seat> <a>,<b>,<c>.',
    voteNo       = 'Why you cannot vote in this race right now.',
    voted        = 'Your ballot is in. Voting again replaces it.',
    withdraw     = 'Withdraw your filing. The fee and any pledge come straight back.',
    platform     = 'Up to 86 characters on the ballot beside your name.',
    pledge       = 'Gil held by the server: split among everyone who votes in your race if you win, 90 percent back if you lose.',
    pay          = 'Pay your indictment fine to the Treasury and clear the Wanted mark now.',
    decree       = 'A world buff for 24 hours. One decree a week.',
    indict       = 'Mark a character Wanted for 72 hours with a fine. Two a week; one per account per season.',
    pardon       = 'Clear a Wanted mark. One a week.',
    enemy        = 'Name a Dungeon- or Legend-tier Nemesis the Public Enemy: a Treasury pot, a quarter to each of the first four accounts to kill it this week.',
    veto         = 'Reverse a Treasurer\'s knob act within 24 hours of it (the owner may veto anything).',
    festival     = 'A week-long perk in your town. One festival a week.',
    townhall     = 'A 30-minute window in which anyone standing in your town can !politics attend. One a week.',
    home         = 'Teleport to your town. Ten minutes between uses.',
    attend       = 'Be counted at the town hall in session where you stand. +5 fame there.',
    merc         = 'The mercenary board\'s cut, 20..50 percent, applied to the next contract to settle.',
    port         = 'Travel fees as a percent of the stock price, 50..200.',
    stimulus     = 'Every account that logs in over the next 48 hours takes this much gil from the Treasury, until twenty times it is spent.',
    drift        = 'Contracts pay this percent more Drift Coins for 48 hours. Costs the Treasury 250,000.',
    resign       = 'Vacate your seat to the Regent. There is no undo.',
    chronPrev    = 'Newer entries.',
    chronNext    = 'Older entries.',
    act          = 'An act in effect, and when it ends.',
};

local SEND_INTERVAL  = 1.2;
local WRITE_DEBOUNCE = 3.0;
local INPUT_MAX      = 96;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local function askStatus(force)
    if (state.refused) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    if (state.boardFailed) then
        if (not force) then
            return;
        end

        state.boardFailed = false;
    end

    if (force and state.statusBad) then
        state.status    = '';
        state.statusBad = false;
    end

    state.requested = { at = os.clock(), tries = 1 };

    issue('!dwb status');
end

local function askChronicle(page)
    if (state.refused) then
        return;
    end

    state.chronAsked = { at = os.clock(), page = page };

    issue(string.format('!dwb chronicle %d', page));
end

local function checkAnswers()
    local asked = state.requested;

    if (asked == nil) then
        return;
    end

    if (not echo.canSend()) then
        asked.at = os.clock();

        return;
    end

    if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
        return;
    end

    if (asked.tries >= ANSWER_TRIES) then
        state.requested    = nil;
        state.serverSilent = true;

        return;
    end

    asked.at    = os.clock();
    asked.tries = asked.tries + 1;

    issue('!dwb status');
end

-- A write: one line, debounced per verb, a status line for feedback.
local function write(verb, command, feedback)
    local at = state.writeAt[verb];

    if (at ~= nil and (os.clock() - at) <= WRITE_DEBOUNCE) then
        return false;
    end

    state.writeAt[verb] = os.clock();
    state.status        = feedback or (verb .. '...');
    state.statusBad     = false;

    issue(command);

    return true;
end

local function writing(verb)
    local at = state.writeAt[verb];

    return at ~= nil and (os.clock() - at) <= WRITE_DEBOUNCE;
end

--[[
* Record parsing (dwb protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function freshBoard()
    return { season = nil, seats = {}, races = {}, treasury = nil, owed = 0, acts = {}, enemy = nil, wanted = {} };
end

local function race(board, idx)
    board.races[idx] = board.races[idx] or { candidates = {}, canFile = false, fileReason = '', canVote = false, voted = false, bonus = 0, voteReason = '' };

    return board.races[idx];
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], -1);

        if (version ~= PROTOCOL) then
            state.refused      = true;
            state.inbound      = nil;
            state.requested    = nil;
            state.pending      = nil;
            state.chronPending = nil;
            state.serverSilent = false;
            state.boardFailed  = false;

            print(chat.header('dwpolitics'):append(chat.error(string.format(
                'server protocol %d, addon expects %d. Update dwpolitics through the launcher.', version, PROTOCOL))));

            return;
        end

        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.inbound == 'status') then
            state.requested = nil;
            state.pending   = freshBoard();
            state.status    = '';
            state.statusBad = false;
        elseif (state.inbound == 'chronicle') then
            state.chronAsked   = nil;
            state.chronPending = { page = 1, per = 12, total = 0, rows = {} };
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        if (kind == 'e') then
            if (state.inbound ~= nil and state.inbound ~= 'status' and state.inbound ~= 'chronicle') then
                state.writeAt[state.inbound] = nil;
            end

            if (state.inbound == 'status') then
                state.pending = nil;
            elseif (state.inbound == 'chronicle') then
                state.chronPending = nil;
            end
        end

        if (text == '') then
            return;
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwpolitics'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    local pending = state.pending;

    if (kind == 's' and pending ~= nil) then
        pending.season = {
            season    = wireInt(parts[2]),
            phase     = parts[3] or '',
            phaseEnds = wireInt(parts[4]),
            day       = wireInt(parts[5]),
            crown     = wireInt(parts[6]) ~= 0,
            serverNow = wireInt(parts[7]),
        };

        return;
    end

    if (kind == 'o' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx >= 1 and idx <= #SEAT_KEYS) then
            pending.seats[idx] = {
                name    = parts[3] or 'Regent',
                mandate = parts[4] or 'regent',
                from    = wireInt(parts[5]),
                to      = wireInt(parts[6]),
                mine    = wireInt(parts[7]) ~= 0,
            };
        end

        return;
    end

    if (kind == 'c' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx >= 1 and idx <= #SEAT_KEYS) then
            local r = race(pending, idx);

            r.candidates[#r.candidates + 1] = {
                name     = parts[3] or '?',
                fee      = wireInt(parts[4]),
                pledge   = wireInt(parts[5]),
                endorsed = wireInt(parts[6]),
                mine     = wireInt(parts[7]) ~= 0,
                platform = parts[8] or '',
            };
        end

        return;
    end

    if (kind == 'y' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx >= 1 and idx <= #SEAT_KEYS) then
            local r = race(pending, idx);

            r.canFile    = wireInt(parts[3]) ~= 0;
            r.fileReason = parts[4] or '';
        end

        return;
    end

    if (kind == 'v' and pending ~= nil) then
        local idx = wireInt(parts[2]);

        if (idx >= 1 and idx <= #SEAT_KEYS) then
            local r = race(pending, idx);

            r.canVote    = wireInt(parts[3]) ~= 0;
            r.voted      = wireInt(parts[4]) ~= 0;
            r.bonus      = wireInt(parts[5]);
            r.voteReason = parts[6] or '';
        end

        return;
    end

    if (kind == 't' and pending ~= nil) then
        pending.treasury = { balance = wireInt(parts[2]), income = wireInt(parts[3]), spend = wireInt(parts[4]) };

        return;
    end

    if (kind == 'p' and pending ~= nil) then
        pending.owed = wireInt(parts[2]);

        return;
    end

    if (kind == 'a' and pending ~= nil) then
        pending.acts[#pending.acts + 1] = {
            actid   = wireInt(parts[2]),
            seat    = wireInt(parts[3]),
            kind    = parts[4] or '',
            arg     = wireInt(parts[5]),
            untilAt = wireInt(parts[6]),
            pot     = wireInt(parts[7]),
            spent   = wireInt(parts[8]),
            by      = parts[9] or '',
        };

        return;
    end

    if (kind == 'n' and pending ~= nil) then
        pending.enemy = {
            actid   = wireInt(parts[2]),
            idx     = wireInt(parts[3]),
            name    = parts[4] or '?',
            pot     = wireInt(parts[5]),
            spent   = wireInt(parts[6]),
            untilAt = wireInt(parts[7]),
        };

        return;
    end

    if (kind == 'w' and pending ~= nil) then
        pending.wanted[#pending.wanted + 1] = {
            name    = parts[2] or '?',
            charge  = parts[3] or '',
            untilAt = wireInt(parts[4]),
            fine    = wireInt(parts[5]),
            by      = parts[6] or '',
        };

        return;
    end

    if (kind == 'g' and state.chronPending ~= nil) then
        state.chronPending.page  = math.max(1, wireInt(parts[2], 1));
        state.chronPending.per   = math.max(1, wireInt(parts[3], 12));
        state.chronPending.total = wireInt(parts[4]);

        return;
    end

    if (kind == 'h' and state.chronPending ~= nil) then
        local rows = state.chronPending.rows;

        rows[#rows + 1] = {
            rowid  = wireInt(parts[2]),
            at     = wireInt(parts[3]),
            season = wireInt(parts[4]),
            seat   = wireInt(parts[5]),
            kind   = parts[6] or '',
            actor  = parts[7] or '',
            text   = parts[8] or '',
        };

        return;
    end

    if (kind == 'k') then
        local verb = parts[2] or '';

        state.writeAt[verb] = nil;

        if (verb == 'claim') then
            state.status = string.format('%s gil collected.', tostring(wireInt(parts[3])));
        else
            state.status = 'Done.';
        end

        state.statusBad = false;

        -- A write changed the board: ask for it again.
        askStatus(true);

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        if (closed == 'chronicle') then
            local cp = state.chronPending;

            state.chronPending = nil;

            if (cp ~= nil) then
                state.chronicle = cp;
            end

            return;
        end

        if (closed ~= 'status') then
            return;
        end

        local complete = pending ~= nil and pending.season ~= nil and pending.seats[1] ~= nil;

        state.pending = nil;

        if (not complete) then
            state.boardFailed = true;

            return;
        end

        state.season      = pending.season;
        state.seats       = pending.seats;
        state.races       = pending.races;
        state.treasury    = pending.treasury;
        state.owed        = pending.owed;
        state.acts        = pending.acts;
        state.enemy       = pending.enemy;
        state.wanted      = pending.wanted;
        state.syncedAt    = os.clock();
        state.clockSkew   = pending.season.serverNow - os.time();
        state.boardFailed = false;

        return;
    end
end

ashita.events.register('packet_in', 'dwpolitics_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwpolitics'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    if (e.id == 0x000A) then
        state.requested    = nil;
        state.serverSilent = false;
        state.refused      = false;
        state.boardFailed  = false;
        state.season       = nil;
        state.syncedAt     = nil;
        state.inbound      = nil;
        state.pending      = nil;
        state.chronPending = nil;

        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end
    end
end);

local function plainText(raw)
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    text = text:gsub('[^\032-\126]', '');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return text;
end

ashita.events.register('text_in', 'dwpolitics_text_in', function (e)
    if (e.blocked or e.injected) then
        return;
    end

    local raw = e.message_modified or e.message;

    if (raw == nil) then
        return;
    end

    local mode = e.mode_modified or e.mode;
    local low  = mode ~= nil and bit.band(mode, 0xFF) or nil;

    if (low ~= NOTICE_MODE) then
        return;
    end

    local line = (plainText(raw):gsub('^%s+', ''));
    local at   = line:find(NOTICE_TAG, 1, true);

    if (at ~= 1) then
        return;
    end

    local rest = line:sub(at + #NOTICE_TAG):gsub('^%s+', ''):gsub('%s+$', '');

    if (rest == '') then
        return;
    end

    e.blocked = true;

    print(chat.header('dwpolitics'):append(chat.message(rest)));
end);

--[[
* Rendering.
--]]
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local function fmtGil(amount)
    local text = tostring(math.floor(amount or 0));
    local out  = '';

    while (#text > 3) do
        out  = ',' .. text:sub(-3) .. out;
        text = text:sub(1, -4);
    end

    return text .. out;
end

local function serverNow()
    return os.time() + (state.clockSkew or 0);
end

local function fmtLeft(untilAt)
    local seconds = math.max(0, untilAt - serverNow());

    if (seconds >= 86400) then
        return string.format('%dd', math.floor(seconds / 86400));
    elseif (seconds >= 3600) then
        return string.format('%dh', math.floor(seconds / 3600));
    end

    return string.format('%dm', math.max(1, math.floor(seconds / 60)));
end

local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

-- BeginChild's third argument is the CHILD FLAGS integer on this Ashita
-- (2025 q3): the boolean `border` the older signature took is a sol
-- type-mismatch -- "no matching function call takes this number of
-- arguments and the specified types" -- and it fired the moment the
-- Elections tab drew (Sorroto/Grandfather, 2026-09-13), since the render
-- pcall reports it but the child never opens. dwbags and dwquest already
-- pass the flag; this is the same shape, with the global resolved once.
local CHILD_FLAGS_NONE = ImGuiChildFlags_None or 0;

local function footerReserve()
    return -(metric('GetFrameHeightWithSpacing', 26) + 12);
end

local function mySeats()
    local held = {};

    for idx, seat in pairs(state.seats) do
        if (seat.mine) then
            held[SEAT_KEYS[idx]] = idx;
        end
    end

    return held;
end

local function cleanInput(buffer)
    return (tostring(buffer[1] or ''):gsub('[^\032-\126]', ''):gsub('^%s+', ''):gsub('%s+$', ''));
end

local function renderHeader()
    if (imgui.Button('Refresh##dwb_refresh')) then
        askStatus(true);
    end

    tip(state.refused and TIPS.refreshStale or TIPS.refresh);

    imgui.SameLine();

    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwpolitics through the launcher.');
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server. Refresh to ask again.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or state.requested ~= nil) then
        imgui.TextDisabled('asking...');
    else
        imgui.TextDisabled('Every seat is a vote away.');
    end

    local s = state.season;

    if (s ~= nil) then
        if (s.season == 0) then
            imgui.Text(string.format('The first season opens in %s.', fmtLeft(s.phaseEnds)));
        else
            imgui.Text(string.format('Season %d, day %d -- %s, %s left%s', s.season, s.day + 1, s.phase, fmtLeft(s.phaseEnds),
                s.crown and '. The Crown races this season.' or '.'));
        end

        if (state.owed > 0) then
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Claim %s gil##dwb_claim', fmtGil(state.owed)))) then
                write('claim', '!dwb claim', 'Claiming...');
            end

            tip(TIPS.claim);
        end
    elseif (state.boardFailed) then
        imgui.TextDisabled('The server answered without a board. Refresh to ask again.');
    else
        imgui.TextDisabled('Waiting for the board...');
    end

    imgui.Separator();
end

local function renderSeats()
    if (imgui.BeginTable('dwb_seats', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchProp))) then
        imgui.TableSetupColumn('Seat', ImGuiTableColumnFlags_WidthStretch, 1.2);
        imgui.TableSetupColumn('Holder', ImGuiTableColumnFlags_WidthStretch, 1.0);
        imgui.TableSetupColumn('Mandate', ImGuiTableColumnFlags_WidthStretch, 0.7);
        imgui.TableSetupColumn('Term', ImGuiTableColumnFlags_WidthStretch, 0.7);
        imgui.TableHeadersRow();

        for idx = 1, #SEAT_KEYS do
            local seat = state.seats[idx];

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(SEAT_NAMES[idx]);
            imgui.TableNextColumn();

            if (seat == nil) then
                imgui.TextDisabled('?');
            elseif (seat.mine) then
                imgui.TextColored(theme.colors.ok, seat.name .. ' (you)');
            else
                imgui.Text(seat.name);
            end

            imgui.TableNextColumn();
            imgui.Text(seat and seat.mandate or '');
            imgui.TableNextColumn();
            imgui.Text(seat and seat.from > 0 and string.format('S%d-S%d', seat.from, seat.to) or '');
        end

        imgui.EndTable();
    end

    imgui.Separator();

    local held = mySeats();

    if (next(held) == nil) then
        imgui.TextDisabled('Hold a seat and its powers appear here.');

        return;
    end

    if (held.crown ~= nil) then
        imgui.Text('The Crown');

        for _, word in ipairs(DECREE_WORDS) do
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Decree %s##dwb_decree_%s', word, word))) then
                write('decree', '!dwb decree ' .. word, 'Decreeing...');
            end

            tip(TIPS.decree);
        end

        imgui.PushItemWidth(140);
        imgui.InputTextWithHint('##dwb_name', 'character name', state.inName, INPUT_MAX + 1);
        imgui.PopItemWidth();
        imgui.SameLine();

        if (imgui.SmallButton('Indict##dwb_indict')) then
            local name = cleanInput(state.inName);

            if (name ~= '') then
                write('indict', '!dwb indict ' .. name, 'Indicting...');
            end
        end

        tip(TIPS.indict);
        imgui.SameLine();

        if (imgui.SmallButton('Pardon##dwb_pardon')) then
            local name = cleanInput(state.inName);

            if (name ~= '') then
                write('pardon', '!dwb pardon ' .. name, 'Pardoning...');
            end
        end

        tip(TIPS.pardon);

        imgui.PushItemWidth(140);
        imgui.InputTextWithHint('##dwb_enemy', 'nemesis name', state.inEnemy, INPUT_MAX + 1);
        imgui.PopItemWidth();
        imgui.SameLine();
        imgui.PushItemWidth(90);
        imgui.InputTextWithHint('##dwb_pot', 'pot gil', state.inPot, 12);
        imgui.PopItemWidth();
        imgui.SameLine();

        if (imgui.SmallButton('Public Enemy##dwb_enemy_btn')) then
            local name = cleanInput(state.inEnemy);
            local pot  = wireInt(cleanInput(state.inPot));

            if (name ~= '' and pot > 0) then
                write('enemy', string.format('!dwb enemy %s %d', name, pot), 'Naming a Public Enemy...');
            end
        end

        tip(TIPS.enemy);
    end

    for _, key in ipairs({ 'bastok', 'sandoria', 'windurst' }) do
        if (held[key] ~= nil) then
            imgui.Text(SEAT_NAMES[held[key]]);

            for _, word in ipairs(FESTIVAL_WORDS) do
                imgui.SameLine();

                if (imgui.SmallButton(string.format('Festival %s##dwb_festival_%s', word, word))) then
                    write('festival', '!dwb festival ' .. word, 'Declaring a festival...');
                end

                tip(TIPS.festival);
            end

            imgui.SameLine();

            if (imgui.SmallButton('Town hall##dwb_townhall')) then
                write('townhall', '!dwb townhall', 'Calling a town hall...');
            end

            tip(TIPS.townhall);
            imgui.SameLine();

            if (imgui.SmallButton('Home##dwb_home')) then
                write('home', '!dwb home', 'Going home...');
            end

            tip(TIPS.home);
        end
    end

    if (held.treasurer ~= nil) then
        imgui.Text('The Treasury');
        imgui.SameLine();
        imgui.PushItemWidth(70);
        imgui.InputTextWithHint('##dwb_number', 'number', state.inNumber, 12);
        imgui.PopItemWidth();

        for _, verb in ipairs({ 'merc', 'port', 'stimulus', 'drift' }) do
            imgui.SameLine();

            if (imgui.SmallButton(string.format('%s##dwb_%s', verb, verb))) then
                local value = wireInt(cleanInput(state.inNumber));

                if (value > 0) then
                    write(verb, string.format('!dwb %s %d', verb, value), 'Setting...');
                end
            end

            tip(TIPS[verb]);
        end
    end

    imgui.PushItemWidth(70);
    imgui.InputTextWithHint('##dwb_act', 'act #', state.inAct, 12);
    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.SmallButton('Veto##dwb_veto')) then
        local actid = wireInt(cleanInput(state.inAct));

        if (actid > 0) then
            write('veto', string.format('!dwb veto %d', actid), 'Vetoing...');
        end
    end

    tip(TIPS.veto);
    imgui.SameLine();

    if (imgui.SmallButton('Resign##dwb_resign')) then
        write('resign', '!dwb resign', 'Resigning...');
    end

    tip(TIPS.resign);
end

local function renderElection()
    local s = state.season;

    if (s == nil or s.season == 0) then
        imgui.TextDisabled('No season is running.');

        return;
    end

    local mine = nil;

    for idx = 1, #SEAT_KEYS do
        local r = state.races[idx];

        if (r ~= nil) then
            for _, c in ipairs(r.candidates) do
                if (c.mine) then
                    mine = idx;
                end
            end
        end
    end

    if (mine ~= nil) then
        imgui.Text(string.format('You are running for the %s.', SEAT_NAMES[mine]));
        imgui.SameLine();

        if (imgui.SmallButton('Withdraw##dwb_withdraw')) then
            write('withdraw', '!dwb withdraw', 'Withdrawing...');
        end

        tip(TIPS.withdraw);

        imgui.PushItemWidth(300);
        imgui.InputTextWithHint('##dwb_platform', 'your platform, up to 86 characters', state.inText, INPUT_MAX + 1);
        imgui.PopItemWidth();
        imgui.SameLine();

        if (imgui.SmallButton('Set platform##dwb_platform_btn')) then
            local text = cleanInput(state.inText);

            if (text ~= '') then
                write('platform', '!dwb platform ' .. text, 'Setting the platform...');
            end
        end

        tip(TIPS.platform);

        imgui.PushItemWidth(100);
        imgui.InputTextWithHint('##dwb_pledge', 'pledge gil', state.inPot, 12);
        imgui.PopItemWidth();
        imgui.SameLine();

        if (imgui.SmallButton('Pledge##dwb_pledge_btn')) then
            local gil = wireInt(cleanInput(state.inPot));

            if (gil > 0) then
                write('pledge', string.format('!dwb pledge %d', gil), 'Pledging...');
            end
        end

        tip(TIPS.pledge);
        imgui.Separator();
    end

    if (imgui.BeginChild('dwb_races', { 0, footerReserve() }, CHILD_FLAGS_NONE)) then
        for idx = 1, #SEAT_KEYS do
            local r = state.races[idx];

            if (r ~= nil) then
                imgui.Text(SEAT_NAMES[idx]);

                if (s.phase == 'nomination' and mine == nil) then
                    imgui.SameLine();

                    if (r.canFile) then
                        if (imgui.SmallButton(string.format('File##dwb_file_%d', idx))) then
                            write('file', '!dwb file ' .. SEAT_KEYS[idx], 'Filing...');
                        end

                        tip(TIPS.file);
                    else
                        imgui.TextDisabled('cannot file');
                        tip(r.fileReason ~= '' and r.fileReason or TIPS.fileNo);
                    end
                end

                if (s.phase == 'poll') then
                    imgui.SameLine();

                    if (r.voted) then
                        imgui.TextColored(theme.colors.ok, 'voted');
                        tip(TIPS.voted);
                    elseif (r.canVote) then
                        imgui.TextDisabled(string.format('you may vote (+%d.%02d)', math.floor(r.bonus / 100), r.bonus % 100));
                    else
                        imgui.TextDisabled('cannot vote');
                        tip(r.voteReason ~= '' and r.voteReason or TIPS.voteNo);
                    end
                end

                if (#r.candidates == 0) then
                    imgui.TextDisabled('  Nobody has filed.');
                end

                for _, c in ipairs(r.candidates) do
                    imgui.Text(string.format('  %s%s -- pledge %s, %d endorsement%s', c.name, c.mine and ' (you)' or '',
                        fmtGil(c.pledge), c.endorsed, c.endorsed == 1 and '' or 's'));

                    if (c.platform ~= '') then
                        tip(c.platform);
                    end

                    if (s.phase == 'poll' and r.canVote and not c.mine) then
                        imgui.SameLine();

                        if (imgui.SmallButton(string.format('Vote##dwb_vote_%d_%s', idx, c.name))) then
                            write('vote', string.format('!dwb vote %s %s', SEAT_KEYS[idx], c.name), 'Casting your ballot...');
                        end

                        tip(TIPS.vote);
                    end
                end

                imgui.Separator();
            end
        end
    end

    imgui.EndChild();
end

local function renderTreasury()
    local t = state.treasury;

    if (t == nil) then
        imgui.TextDisabled('Waiting for the board...');

        return;
    end

    imgui.Text(string.format('Treasury: %s gil (this season +%s / -%s)', fmtGil(t.balance), fmtGil(t.income), fmtGil(t.spend)));

    if (state.enemy ~= nil) then
        imgui.TextColored(theme.colors.warn, string.format('Public Enemy: %s -- %s gil pot, %s paid, %s left',
            state.enemy.name, fmtGil(state.enemy.pot), fmtGil(state.enemy.spent), fmtLeft(state.enemy.untilAt)));
    end

    imgui.Separator();

    if (#state.acts == 0) then
        imgui.TextDisabled('Nothing is in effect.');

        return;
    end

    if (imgui.BeginTable('dwb_acts', 5, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp), { 0, footerReserve() })) then
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Act', ImGuiTableColumnFlags_WidthStretch, 0.4);
        imgui.TableSetupColumn('Seat', ImGuiTableColumnFlags_WidthStretch, 0.8);
        imgui.TableSetupColumn('What', ImGuiTableColumnFlags_WidthStretch, 1.2);
        imgui.TableSetupColumn('By', ImGuiTableColumnFlags_WidthStretch, 0.8);
        imgui.TableSetupColumn('Ends', ImGuiTableColumnFlags_WidthStretch, 0.5);
        imgui.TableHeadersRow();

        for _, a in ipairs(state.acts) do
            local what = a.kind;

            if (a.kind == 'decree') then
                what = 'decree ' .. (DECREE_WORDS[a.arg] or tostring(a.arg));
            elseif (a.kind == 'festival') then
                what = 'festival ' .. (FESTIVAL_WORDS[a.arg] or tostring(a.arg));
            elseif (a.kind == 'stimulus') then
                what = string.format('stimulus %s gil each (%s of %s)', fmtGil(a.arg), fmtGil(a.spent), fmtGil(a.pot));
            elseif (a.kind == 'drift') then
                what = string.format('drift +%d percent', a.arg);
            elseif (a.kind == 'enemy') then
                what = string.format('public enemy, %s of %s paid', fmtGil(a.spent), fmtGil(a.pot));
            end

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(tostring(a.actid));
            tip(TIPS.act);
            imgui.TableNextColumn();
            imgui.Text(SEAT_SHORT[a.seat] or '?');
            imgui.TableNextColumn();
            imgui.Text(what);
            imgui.TableNextColumn();
            imgui.Text(a.by);
            imgui.TableNextColumn();
            imgui.Text(fmtLeft(a.untilAt));
        end

        imgui.EndTable();
    end
end

local function renderWanted()
    if (#state.wanted == 0) then
        imgui.TextDisabled('Nobody is wanted.');
    end

    for _, w in ipairs(state.wanted) do
        imgui.TextColored(theme.colors.warn, string.format('%s -- %s (by %s), fine %s gil, %s left', w.name, w.charge, w.by, fmtGil(w.fine), fmtLeft(w.untilAt)));
    end

    imgui.Separator();

    if (imgui.SmallButton('Pay my fine##dwb_pay')) then
        write('pay', '!dwb pay', 'Paying...');
    end

    tip(TIPS.pay);
end

local function renderChronicle()
    local c = state.chronicle;

    if (state.chronAsked == nil and #c.rows == 0 and c.total == 0 and state.season ~= nil) then
        askChronicle(1);
    end

    local pages = math.max(1, math.ceil(c.total / math.max(1, c.per)));

    if (imgui.SmallButton('Newer##dwb_chron_prev') and c.page > 1) then
        askChronicle(c.page - 1);
    end

    tip(TIPS.chronPrev);
    imgui.SameLine();
    imgui.Text(string.format('page %d of %d', c.page, pages));
    imgui.SameLine();

    if (imgui.SmallButton('Older##dwb_chron_next') and c.page < pages) then
        askChronicle(c.page + 1);
    end

    tip(TIPS.chronNext);
    imgui.Separator();

    if (#c.rows == 0) then
        imgui.TextDisabled('Nothing written yet.');

        return;
    end

    if (imgui.BeginChild('dwb_chron', { 0, footerReserve() }, CHILD_FLAGS_NONE)) then
        for _, row in ipairs(c.rows) do
            imgui.TextWrapped(string.format('[S%d %s] %s', row.season, row.kind, row.text));
        end
    end

    imgui.EndChild();
end

local function renderWindow()
    renderHeader();

    if (imgui.BeginTabBar('dwb_tabs')) then
        if (imgui.BeginTabItem('Seats###dwb_tab_seats')) then
            renderSeats();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Election###dwb_tab_election')) then
            renderElection();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Treasury###dwb_tab_treasury')) then
            renderTreasury();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem(string.format('Wanted %d###dwb_tab_wanted', #state.wanted))) then
            renderWanted();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Chronicle###dwb_tab_chronicle')) then
            renderChronicle();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

ashita.events.register('d3d_present', 'dwpolitics_present', function ()
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    if (state.season == nil and state.requested == nil and not state.serverSilent and not state.refused and not state.boardFailed) then
        askStatus();
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 760, 480 }, ImGuiCond_FirstUseEver);
    imgui.SetNextWindowSizeConstraints({ 620, 320 }, { 99999, 99999 });

    local visible = imgui.Begin('DriftwoodXI Politics##dwpolitics', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwpolitics'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwpolitics'):append(chat.message('Window closed. Everything it shows also works typed as !politics.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwpolitics_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:sub(1, 4):lower() ~= '!dwb') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwpolitics_command', function (e)
    local args  = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/politics' and first ~= '/dwpolitics') then
        return;
    end

    e.blocked = true;

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwpolitics_load', function ()
    print(chat.header('dwpolitics'):append(chat.message('/politics opens the seats of power. Everything it shows also works typed as !politics.')));
end);
