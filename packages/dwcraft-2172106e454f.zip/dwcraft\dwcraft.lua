--[[
* DriftwoodXI -- dwcraft
*
* The crafting ledger: every craft's level, rank and next rank test; the
* specialization budget -- how many points you have spent past the free cap,
* how many are left, and which craft pays first when the budget runs dry --
* and the house rules crafting actually runs under on this server, stated
* from live settings rather than folklore.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It computes no skill, no cap and no arithmetic of its own. The server reads
* your real rows and answers `!dwc sync` in compact records under the sender
* name _DWCDATA (documentation/dwc_protocol.md), which this addon parses and
* blocks before the chat log sees them. The specialization numbers arrive
* computed by the same formula the skill-up code enforces; if the window
* shows a number, the server said that number. The one derivation permitted
* is display sugar the protocol doc explicitly grants: "next rank test at
* cap - 2", below Expert only.
*
* THE RECIPE BOOK (Phase 2) RIDES THE SAME RULES. The catalog under
* data/recipes.lua is generated from the server's own synth_recipes dump and
* shipped byte-identically to both sides; this addon and the server each
* hash what they loaded and compare over the wire, so a stale copy refuses
* the book tab ("update me") instead of showing a recipe the server would
* refuse. Whether YOU can make a recipe -- skill, key item, Rare block,
* what your bags hold -- arrives per-row in y| records, computed by the
* same arithmetic the trade window enforces. The catalog supplies names
* and requirements; the server supplies every fact about you.
*
* THE LADDER (Phase 3) IS THE STRICTEST CASE OF THE SAME RULE. How many
* synths a rung takes, how many points each one is worth, how many survive
* and what the materials cost are all server arithmetic -- mirrors of
* synthutils.cpp's skill-up and break formulas and of a price table compiled
* from this server's own shop scripts and AH catalog. This addon renders
* l|/g|/u| records and multiplies nothing. It never reads the auction house;
* it could not, and the plan says it must not.
*
* THE TALLY (Phase 4) IS THE ONE SANCTIONED CARVE-OUT, AND IT IS NARROW.
* Attempts, breaks, NQ/HQ, items made and materials consumed are counted
* here, from the 0x06F synthesis-result packets this client already
* receives -- the dwparse precedent: a parse is a record of packets you
* received. Skill gained and gil are NOT counted here: they arrive
* server-anchored in t|/h| records, because this server never fills the
* packet's skill-up fields and adding up chat lines would be client
* arithmetic about the game. The sitting resets on the Reset button and on
* logout, never on a zone line -- the panel says so.
*
* THE WAREHOUSE RIDES THE SAME PILE (Phase 8). DWWarehouse's account pool
* (dw_warehouse rows, not client containers) is materials you own as surely
* as an alt's bags are, so the book's Warehouse checkbox asks the server to
* fold it in: mode bit 4 on the same bags verb, counted server-side by
* DwWhCounts from every row on the ACCOUNT, which since the bound lane was
* retired on 2026-08-08 is every row THIS character could pull. The y|
* truths still never change.
* The one write this addon ever sends is the detail pane's pull button:
* a typed `!warehouse pull id:qty,...` line for exactly what the local bag
* is short, which is a line a player could type and whose rules live
* entirely in warehouse_store.cpp. On a build without the binding the hello
* record says so and neither control renders.
*
* THE ACCOUNT MATRIX (Phase 5) IS READ-ONLY FOREVER, AND IT HAS NO BUTTONS
* AT ALL -- that is the cheapest way to keep the promise through later edits.
* Every character on your account with every craft's level and rank, read
* server-side out of the same char_skills rows the Ledger tab reads, through
* a C++ binding because an alt at its Mog House is not an entity anywhere.
* The free cap the grid colours against arrives in the header rather than
* being a constant here, so the colouring cannot drift from live settings.
*
* THE ACCOUNT BAG CHECK (Phase 7) EXTENDS THE BOOK THE SAME WAY. Materials
* mailed to alts are still yours, so the book can count them: the server
* aggregates every browsable container on the account (the same C++ tier
* dwbags rides) and sends the pile per recipe in b| records beside the y|
* rows, plus an n| frame saying how many characters were counted. The y|
* truths never change -- "can make" still means THIS character's inventory
* bag, because that is the one bag a synth can draw on -- the account column
* is the server saying what you could move over. 'Craftable only' asks the
* server to filter to recipes the pile completes; the same question typed is
* !craft craftable. On a build without the binding the hello record says so
* and the controls do not render -- never a question nothing will answer.
*
* TURN IT OFF AND NOTHING IS LOST. Everything here works typed: !craft
* skills, !craft points, !craft rules, !craft find, !craft book,
* !craft recipe, !craft shopping, !craft ladder, !craft tally, !craft alts.
* This window is the same answers with a table around them -- minus the
* client-side counts, which exist only while something is listening to the
* packets.
--]]

addon.name    = 'dwcraft';
addon.author  = 'DriftwoodXI';
addon.version = '1.6.4';
addon.desc    = 'Crafting ledger for DriftwoodXI -- skills, ranks, the specialization budget, a recipe book that checks bags across your whole account and your DWWarehouse, a skill-up ladder that knows what a point costs, a session tally, and every character on your account craft by craft.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. Nine
-- other addons own nine other senders; this addon must never contend for any
-- of them, which is why !dwc exists at all.
local DATA_SENDER = '_DWCDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

-- Names for the ids the wire carries (dwc_protocol.md: ids only, names are
-- the addon's). Same order the server emits: Fishing first, then the eight
-- crafts the specialization budget counts.
local CRAFT_ORDER = { 48, 49, 50, 51, 52, 53, 54, 55, 56 };

local CRAFT_NAMES = {
    [48] = 'Fishing',
    [49] = 'Woodworking',
    [50] = 'Smithing',
    [51] = 'Goldsmithing',
    [52] = 'Clothcraft',
    [53] = 'Leathercraft',
    [54] = 'Bonecraft',
    [55] = 'Alchemy',
    [56] = 'Cooking',
};

-- xi.craftRank ordinals, server-side scripts/enum/craft_rank.lua.
local RANK_NAMES = {
    [0]  = 'Amateur',    [1]  = 'Recruit',  [2]  = 'Initiate',    [3]  = 'Novice',
    [4]  = 'Apprentice', [5]  = 'Journeyman', [6] = 'Craftsman',  [7]  = 'Artisan',
    [8]  = 'Adept',      [9]  = 'Veteran',  [10] = 'Expert',      [11] = 'Authority',
    [12] = 'Luminary',   [13] = 'Master',   [14] = 'Grandmaster', [15] = 'Legend',
};

-- The guild masters' ladder stops at Expert; the server derives the same
-- bound (dwc_protocol.md `k|`).
local LAST_TESTED_RANK = 10;

--[[
* The recipe catalog: data/recipes.lua, generated by tools/dwcraft/
* gen_recipes.py and loaded by the server module and this addon from the
* same bytes. Both sides hash what they loaded; the server's hash arrives in
* the hello f| record and a mismatch closes the book tab. io.read then
* loadstring, not require: the hash must cover the bytes that produced the
* table, and git may check the copies out with different line endings, so
* \r is stripped before both hashing and loading (the dwtracker pattern).
--]]

-- MUST MATCH tracker_core.lua / dwtracker.lua / craft_core.lua and the
-- Python reference in tools/dwcraft/gen_recipes.py -- one hash, four
-- implementations. The 16-bit multiply split keeps every product inside a
-- double's exact-integer range.
local function fnv1a(text)
    local hash = 2166136261;

    for i = 1, #text do
        hash = bit.bxor(hash, string.byte(text, i)) % 4294967296;

        local lo = hash % 65536;
        hash = (((hash - lo) / 65536) * 16777619 % 65536) * 65536 + lo * 16777619;
        hash = hash % 4294967296;
    end

    return bit.tohex(hash);
end

local catalog = nil;                -- { hash, count, items, keyItems, byId }
local catalogState = 'missing';     -- 'ok' | 'missing' | 'broken'

local function loadCatalog()
    local path = string.format('%s\\addons\\dwcraft\\data\\recipes.lua',
        AshitaCore:GetInstallPath():gsub('[\\/]+$', ''));

    local file = io.open(path, 'rb');

    if (file == nil) then
        catalogState = 'missing';
        return;
    end

    local raw = file:read('*a');
    file:close();

    local normalized = string.gsub(raw, '\r', '');
    local chunk      = loadstring(normalized, 'dwcraft-recipes');

    if (chunk == nil) then
        catalogState = 'broken';
        return;
    end

    local ok, data = pcall(chunk);

    if (not ok or type(data) ~= 'table' or data.version ~= 1 or
            type(data.items) ~= 'table' or type(data.recipes) ~= 'table') then
        catalogState = 'broken';
        return;
    end

    local built = {
        hash     = fnv1a(normalized),
        count    = #data.recipes,
        items    = data.items,
        keyItems = data.keyItems or { },
        -- { gil, source } per spendable item id. Catalog data, like names and
        -- required quantities -- a fact about the world, not about the
        -- player. The addon uses it for the SOURCE LABEL only; every gil
        -- figure it prints came off the wire in a u| record.
        prices   = data.prices or { },
        byId     = { },     -- PLAIN table: ids are sparse keys (the T{} rule)
        byInputs = { },     -- crystal + sorted material units -> recipe (the tally's NQ/HQ resolver)
    };

    for _, row in ipairs(data.recipes) do
        -- Positional row -> named record; the generator's header documents
        -- the positions and the offline harness locks them.
        local recipe = {
            id      = row[1],
            craft   = row[2],
            lvl     = row[3],
            crystal = row[4],
            ki      = row[5],
            rare    = row[6] % 2 == 1,
            result  = row[8],
            qty     = row[9],
            subs    = row[10],
            ings    = row[11],
            hq      = row[12],
        };

        built.byId[recipe.id] = recipe;

        -- The tally classifies NQ vs HQ by resolving the 0x06F packet's
        -- crystal + material list back to its recipe -- the same resolution
        -- the trade window performs, so the key is what the window holds:
        -- one unit per slot, an ingredient needing 2 occupying 2 slots.
        -- The server's Grade field is never filled (dwc_protocol.md), so
        -- this hash-verified lookup is the only honest classifier.
        local units = { };

        for i = 1, #recipe.ings, 2 do
            for _ = 1, recipe.ings[i + 1] do
                table.insert(units, recipe.ings[i]);
            end
        end

        table.sort(units);

        -- EVERY claimant is kept: the shipped catalog holds a handful of
        -- colliding input sets (Phase 6 counted four -- e.g. two cardinal-
        -- direction recipes over the same crystal and material), so "first
        -- writer wins" silently misfiled one recipe's HQ as another's NQ.
        -- classifyResult lets the claimants vote and refuses a split.
        local key = recipe.crystal .. ':' .. table.concat(units, ',');

        if (built.byInputs[key] == nil) then
            built.byInputs[key] = { };
        end

        table.insert(built.byInputs[key], recipe);
    end

    catalog      = built;
    catalogState = 'ok';
end

-- A broken data file must cost the book tab, never the addon.
pcall(loadCatalog);

local function itemName(itemId)
    if (catalog ~= nil and catalog.items[itemId] ~= nil) then
        return catalog.items[itemId];
    end

    return string.format('item %d', itemId);
end

-- flags/mask bits arrive as plain integers; the meanings are
-- dwc_protocol.md's, decoded here and nowhere else.
local function hasBit(value, bitValue)
    return math.floor((value or 0) / bitValue) % 2 == 1;
end

-- Free text headed for a ! command: pipes and newlines would break the wire
-- records that quote it back (the dwgmpanel rule).
local function cleanSend(text)
    return tostring(text or ''):gsub('[|\r\n]', ' '):gsub('^%s+', ''):gsub('%s+$', '');
end

-- The craft filter the book tab offers. Fishing has no synthesis recipes;
-- id 0 is "everything".
local BOOK_CRAFTS = {
    { id = 0,  name = 'All crafts' },
    { id = 49, name = 'Woodworking' },
    { id = 50, name = 'Smithing' },
    { id = 51, name = 'Goldsmithing' },
    { id = 52, name = 'Clothcraft' },
    { id = 53, name = 'Leathercraft' },
    { id = 54, name = 'Bonecraft' },
    { id = 55, name = 'Alchemy' },
    { id = 56, name = 'Cooking' },
};

local BOOK_COMBO = (function ()
    local parts = { };

    for _, entry in ipairs(BOOK_CRAFTS) do
        table.insert(parts, entry.name);
    end

    return table.concat(parts, '\0') .. '\0\0';
end)();

-- The ladder plans ONE craft, so "All crafts" is not a choice here.
local LADDER_CRAFTS = { };

for index, entry in ipairs(BOOK_CRAFTS) do
    if (index > 1) then
        table.insert(LADDER_CRAFTS, entry);
    end
end

local LADDER_COMBO = (function ()
    local parts = { };

    for _, entry in ipairs(LADDER_CRAFTS) do
        table.insert(parts, entry.name);
    end

    return table.concat(parts, '\0') .. '\0\0';
end)();

-- Where a price came from, so a gil figure is never an unattributed number
-- (dwc_protocol.md: the catalog's price provenance).
local PRICE_SOURCES = {
    [1] = 'guild',
    [2] = 'vendor',
    [3] = 'AH',
};

local state = T{
    open      = T{ false },

    -- skillid -> { raw, rank, cap, bonus }. A PLAIN TABLE keyed by id, not
    -- `T{ }` -- unknown keys on a T{} resolve through its metatable to the
    -- sugar methods, which is the dwbags round-7 bug, paid for once already.
    crafts    = { },

    -- The `p|` ledger record, parsed. nil until the first sync lands.
    ledger    = nil,

    -- rule key -> parts, from `r|` records. Only keys the server sent exist,
    -- so the panel cannot state a rule the server did not assert.
    rules     = { },

    -- The recipe book tab. serverHash/serverCount arrive in hello's f|;
    -- header is the q| echo (which page of what these rows answer); rows
    -- are the y| records in book order; shop is the w|/s| expansion for
    -- the selected recipe.
    book      = {
        serverHash  = nil,      -- nil until hello answers; '' = server has no book
        serverCount = 0,
        header      = nil,      -- { page, pages, total, craft, needle, mode }
        rows        = { },
        selected    = nil,      -- recipe id the detail pane is showing
        shop        = nil,      -- { id, missing, rows = { { item, qty, depth }, ... } }
        search      = T{ '' },
        craftIdx    = T{ 0 },   -- index into BOOK_CRAFTS, 0-based for Combo

        -- The account bag check (Phase 7). `acctSupported` is hello f|'s
        -- seventh field -- whether this server BUILD carries the DwCraftBags
        -- binding; nil until hello answers, false renders no account
        -- controls at all (a checkbox the server cannot honour is a
        -- question nothing will answer). The two checkboxes are the mode
        -- bits the bags verb takes; acctRows holds the b| records keyed by
        -- recipe id and acctInfo the n| frame, both cleared with the rows
        -- they describe.
        acctSupported = nil,
        acct          = T{ true },   -- 'All characters': ask for the account pile
        acctOnly      = T{ false },  -- 'Craftable only': filter to what the pile completes
        acctRows      = { },         -- recipe id -> { have, mask, crystalHave, held }
        acctInfo      = nil,         -- { chars, age }

        -- The warehouse (Phase 8). `whSupported` is hello f|'s eighth field
        -- -- whether this build carries DwWhCounts -- on exactly the
        -- acctSupported rules: nil until hello answers, false renders no
        -- checkbox and no pull button. `wh` is mode bit 4, default off so
        -- the book means what it always meant until the player asks wider.
        whSupported   = nil,
        wh            = T{ false },  -- 'Warehouse': fold the warehouse into the pile
    },

    -- The ladder tab. `head` is the l| record, `rungs` the g| records in
    -- order, each carrying its own u| shopping rows. Nothing here is
    -- computed: the addon asked a question and this is the answer.
    ladder    = {
        head     = nil,         -- { craft, raw, target, cap, gate, rungs, needPts, leftPts }
        rungs    = { },
        selected = nil,         -- rung index whose shopping list is open
        craftIdx = T{ 0 },      -- index into LADDER_CRAFTS, 0-based for Combo
        target   = T{ '' },     -- blank means "the rank cap", as the typed tier reads it
        asked    = nil,         -- the question the rows on screen answer
    },

    -- The session tally (Phase 4). `server` is the t| frame and `moved` its
    -- h| rows -- truths the server anchored at the sitting's start. `count`
    -- is this addon's own record of the 0x06F packets it watched: attempts,
    -- breaks, results, materials -- the dwparse carve-out. The two halves
    -- reset together (Reset button, logout, char switch) and never on a
    -- zone line.
    tally     = {
        server = nil,        -- { age, gil, gild, n }
        moved  = { },        -- { { id, from, gain }, ... } in server order
        count  = {
            attempts = 0,
            breaks   = 0,
            nq       = 0,
            hq       = 0,    -- all tiers; tiers[1..3] carries the split
            tiers    = { 0, 0, 0 },
            other    = 0,    -- successes the catalog could not classify
            made     = { },  -- itemId -> qty produced (rendered sorted by id)
            used     = { },  -- itemId -> units consumed, crystals included
        },
        owner  = nil,        -- UniqueNo the counts belong to (0x00A guard)
    },

    -- The account matrix (Phase 5). Read-only, and every number in it was
    -- said by the server: the addon renders the a|/c|/v| records and does not
    -- so much as decide whether a craft counts as specialized -- freeCap
    -- arrives in the header and the comparison is against that.
    --
    -- `supported` is the hello f| record's last field: whether this server
    -- BUILD carries the DwCraftAlts binding at all. nil until hello answers;
    -- false closes the tab with a reason rather than leaving it asking a
    -- question nothing will ever answer.
    alts      = {
        supported = nil,
        head      = nil,     -- { accid, count, freeCap, budget, truncated }
        rows      = { },     -- { { flags, used, left, name, raw = {}, rank = {} }, ... }
    },

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its
    -- own cannot half-fill the UI.
    inbound   = nil,

    status    = 'Loading...',
    statusBad = false,
    reported  = false,     -- a render error is worth saying once, not per frame
};

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A
* TIME. The client rate-limits outgoing chat, and a !dwc command is a chat
* line; anything over the limit is answered with "A command error occurred"
* before the server ever sees it. So everything queues here and drains at one
* command per SEND_INTERVAL.
*
* DUPLICATES COLLAPSE ONLY WHEN THE CALLER SAYS SO, and only reads ever do.
* Asking twice for the same recipe page is never useful; the write verbs on
* this queue -- `!warehouse pull ...` and `!dwc tally reset` -- are things the
* player clicked for, and issue() has no way to report a refusal, so a second
* identical click inside the 1.2s drain window just disappeared.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command, collapse)
    if (collapse) then
        for _, queued in ipairs(queue) do
            if (queued == command) then
                return;
            end
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a window drawn sixty times a second
* asks once. The answer is tracked, not just the question: one lost command
* must not leave the panel stale for ever, and a retry that never terminates
* is a command loop, which is worse than a stale panel.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

local function refresh()
    requested = {};
end

local function needSync()
    local asked = requested['sync'];

    if (asked ~= nil) then
        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['sync'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dwc sync', true);
end

local function needHello()
    local asked = requested['hello'];

    if (asked ~= nil) then
        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['hello'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dwc hello', true);
end

--[[
* Ask for one verb about one qualifier at most once, twice if never answered
* -- the dwmerc pattern. The ask carries the page, the filter and the search
* text; the q| record carries them back, so a response for an older ask is
* visibly not this one's.
--]]
local function needQualified(verb, qualifier, command)
    local asked = requested[verb];

    if (asked ~= nil and asked.qualifier == qualifier) then
        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested[verb] = { qualifier = qualifier, at = os.clock(), answered = false, tries = 1 };
    end

    issue(command, true);
end

local function askRecipes(page, force)
    local book   = state.book;
    local needle = cleanSend(book.search[1]);
    local craft  = (BOOK_CRAFTS[book.craftIdx[1] + 1] or BOOK_CRAFTS[1]).id;

    -- The account mode the checkboxes read (Phase 7): bit 1 asks for the
    -- pile, bit 2 filters to what it completes (which needs the pile, so
    -- Craftable-only implies both). Nonzero ONLY when the server's hello
    -- said this build can answer -- the audit's promise that an old server
    -- is never sent a spelling it does not know.
    local mode = 0;

    if (book.acctSupported == true) then
        if (book.acctOnly[1]) then
            mode = 3;
        elseif (book.acct[1]) then
            mode = 1;
        end
    end

    -- Bit 4 (Phase 8): the warehouse rides the pile. Gated on ITS OWN hello
    -- field, so a server that grew the bags binding but not the warehouse
    -- one is never asked a mode it would clamp into a different question.
    -- With every account box unchecked the warehouse is still a pile all by
    -- itself (mode 4) -- the server reads bit 4 as its own source.
    if (book.whSupported == true and book.wh[1]) then
        mode = mode + 4;
    end

    if (force) then
        -- The bags may have changed under an identical question; the
        -- qualifier dedup must not eat the re-ask.
        requested['recipes'] = nil;
    end

    if (mode > 0) then
        needQualified('recipes',
            string.format('%i:%i:%i:%s', page, craft, mode, needle:lower()),
            string.format('!dwc bags %i %i %i %s', page, craft, mode, needle));
    else
        needQualified('recipes',
            string.format('%i:%i:%i:%s', page, craft, mode, needle:lower()),
            string.format('!dwc recipes %i %i %s', page, craft, needle));
    end
end

local function askShop(recipeId)
    needQualified('shop', recipeId, string.format('!dwc shop %i', recipeId));
end

-- The account matrix is asked for only while its tab is open: it is two SQL
-- statements on the server and nothing else in the window depends on it, so
-- there is no reason for a player who never opens the tab to pay for it.
local function askAlts()
    local asked = requested['alts'];

    if (asked ~= nil) then
        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['alts'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dwc alts', true);
end

-- The ladder's craft and target as the combo and the box currently read them.
-- A blank target means the rank cap, which is what the typed tier does with a
-- missing one -- but the wire spelling takes two numbers, so the cap is
-- filled in from the k| row the server already sent. If sync has not landed
-- yet there is no cap to fill in and the ask waits.
local function ladderQuestion()
    local entry = LADDER_CRAFTS[state.ladder.craftIdx[1] + 1] or LADDER_CRAFTS[1];
    local typed = tonumber((tostring(state.ladder.target[1] or ''):gsub('[^%d]', '')));

    if (typed == nil) then
        local row = state.crafts[entry.id];

        if (row == nil) then
            return nil;
        end

        typed = row.cap;
    end

    return entry.id, math.max(1, math.min(typed, 160));
end

local function askLadder(force)
    local craft, target = ladderQuestion();

    if (craft == nil) then
        return false;
    end

    if (force) then
        -- The bags may have changed under an identical question, and the
        -- shopping rows are counted against them.
        requested['ladder'] = nil;
    end

    state.ladder.asked = string.format('%i:%i', craft, target);

    needQualified('ladder', state.ladder.asked,
        string.format('!dwc ladder %i %i', craft, target));

    return true;
end

--[[
* Record parsing. Every record is pipe-separated with a single-character
* type. Anything this addon does not recognise is ignored rather than being
* an error: a server newer than the addon must not break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwcraft.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright, and the reset runs
        -- FIRST: handleRecord is called under a pcall, and anything that
        -- throws after `state.inbound` is set must cost one record, not
        -- leave old rows for the records behind it to append to.
        if (state.inbound == 'sync') then
            state.crafts = { };
            state.ledger = nil;
            state.rules  = { };

            -- The tally's SERVER half rides every sync; the client-counted
            -- half is not the server's to replace and stays put.
            state.tally.server = nil;
            state.tally.moved  = { };
        elseif (state.inbound == 'tally') then
            state.tally.server = nil;
            state.tally.moved  = { };
        elseif (state.inbound == 'recipes') then
            state.book.header   = nil;
            state.book.rows     = { };

            -- The account records describe the rows they arrived with; rows
            -- replaced means pile replaced, or the b| of a page you left
            -- decorates the page you are on.
            state.book.acctRows = { };
            state.book.acctInfo = nil;
        elseif (state.inbound == 'shop') then
            state.book.shop = nil;
        elseif (state.inbound == 'ladder') then
            state.ladder.head     = nil;
            state.ladder.rungs    = { };
            state.ladder.selected = nil;
        elseif (state.inbound == 'alts') then
            state.alts.head = nil;
            state.alts.rows = { };
        end

        local asked = requested[state.inbound];

        if (type(asked) == 'table') then
            asked.answered = true;
        end

        -- A refusal raised before a verb opened its own envelope arrives
        -- wrapped in `d|1|status` (dwc.lua's shape). That IS the answer to
        -- whatever was asked: left unanswered, the sync/hello pumps re-send
        -- their verbs in five seconds and pay double the chat for the same
        -- refusal.
        if (state.inbound == 'status') then
            for _, pending in pairs(requested) do
                if (type(pending) == 'table') then
                    pending.answered = true;
                end
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- message saying why something was refused is worth more than the
    -- response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- Everything after the first pipe, not parts[2]: these carry prose.
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        -- Errors also go to the chat log: the window may already be closed,
        -- and "nothing happened" is the worst possible feedback.
        if (kind == 'e') then
            print(chat.header('dwcraft'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        if (state.inbound == 'sync' and state.status == 'Loading...') then
            state.status = '';
        end

        state.inbound = nil;

        return;
    end

    if (kind == 'k' and state.inbound == 'sync') then
        local id = tonumber(parts[2]) or 0;

        state.crafts[id] = {
            raw   = tonumber(parts[3]) or 0,
            rank  = tonumber(parts[4]) or 0,
            cap   = tonumber(parts[5]) or 0,
            bonus = tonumber(parts[6]) or 0,
        };

        return;
    end

    if (kind == 'p' and state.inbound == 'sync') then
        state.ledger = {
            used    = tonumber(parts[2]) or 0,
            left    = tonumber(parts[3]) or 0,
            budget  = tonumber(parts[4]) or 0,
            freeCap = tonumber(parts[5]) or 0,
            payer   = tonumber(parts[6]) or 0,
        };

        return;
    end

    if (kind == 'r' and state.inbound == 'sync') then
        local key = parts[2];

        if (key ~= nil and key ~= '') then
            state.rules[key] = { parts[3], parts[4], parts[5] };
        end

        return;
    end

    -- The tally frame and its moved-craft rows arrive with every sync and
    -- with a tally answer (the reset's acknowledgement) alike.
    if (kind == 't' and (state.inbound == 'sync' or state.inbound == 'tally')) then
        state.tally.server = {
            age  = tonumber(parts[2]) or 0,
            gil  = tonumber(parts[3]) or 0,
            gild = tonumber(parts[4]) or 0,
            n    = tonumber(parts[5]) or 0,

            -- Wall-clock at arrival, so the sitting's age can keep ticking
            -- between syncs. Clock sugar, not game arithmetic: the game
            -- numbers stay exactly as the server said them.
            receivedAt = os.clock(),
        };
        state.tally.moved = { };

        return;
    end

    if (kind == 'h' and (state.inbound == 'sync' or state.inbound == 'tally')) then
        table.insert(state.tally.moved, {
            id   = tonumber(parts[2]) or 0,
            from = tonumber(parts[3]) or 0,
            gain = tonumber(parts[4]) or 0,
        });

        return;
    end

    if (kind == 'f' and state.inbound == 'hello') then
        -- A Phase 0 server sends only krows|hasLedger; a server whose catalog
        -- failed to load sends the two hash fields empty. Either way an empty
        -- hash is real information ("no recipe book here"), kept as ''.
        state.book.serverHash  = parts[4] or '';
        state.book.serverCount = tonumber(parts[5]) or 0;

        -- Field 6 (Phase 5) is whether this server BUILD can answer `alts`.
        -- Absent on any server older than Phase 5, which is the same answer
        -- as 0 and is read that way -- never as "assume yes and hang".
        state.alts.supported = (tonumber(parts[6]) or 0) == 1;

        -- Field 7 (Phase 7): whether this build can answer the account bag
        -- check (the `bags` verb). Same rule: absent reads as 0, and 0
        -- renders no account controls rather than controls that hang.
        state.book.acctSupported = (tonumber(parts[7]) or 0) == 1;

        -- Field 8 (Phase 8): whether this build can fold the warehouse into
        -- the pile (DwWhCounts). Same rule again: absent reads as 0, and 0
        -- renders neither the Warehouse checkbox nor the pull button.
        state.book.whSupported = (tonumber(parts[8]) or 0) == 1;

        return;
    end

    if (kind == 'q' and state.inbound == 'recipes') then
        state.book.header = {
            page   = tonumber(parts[2]) or 1,
            pages  = tonumber(parts[3]) or 1,
            total  = tonumber(parts[4]) or 0,
            craft  = tonumber(parts[5]) or 0,
            needle = parts[6] or '',

            -- Field 7 (Phase 7): the account mode this answer actually took.
            -- An asked-for pile the server could not read echoes 0 here (its
            -- m| note says why), so the rows below honestly carry no b|.
            mode   = tonumber(parts[7]) or 0,
        };

        return;
    end

    -- The account pile's frame (Phase 7): how many characters were counted
    -- and how old the count is. Rides only answers whose q| mode is nonzero.
    if (kind == 'n' and state.inbound == 'recipes') then
        state.book.acctInfo = {
            chars = tonumber(parts[2]) or 0,
            age   = tonumber(parts[3]) or 0,
        };

        return;
    end

    if (kind == 'y' and state.inbound == 'recipes') then
        local held = { };

        for count in string.gmatch(parts[10] or '', '([^,]+)') do
            table.insert(held, tonumber(count) or 0);
        end

        table.insert(state.book.rows, {
            id          = tonumber(parts[2]) or 0,
            flags       = tonumber(parts[3]) or 0,
            gapCraft    = tonumber(parts[4]) or 0,
            gapLvls     = tonumber(parts[5]) or 0,
            have        = tonumber(parts[6]) or 0,
            need        = tonumber(parts[7]) or 0,
            mask        = tonumber(parts[8]) or 0,
            crystalHave = tonumber(parts[9]) or 0,
            held        = held,
        });

        return;
    end

    -- One b| per y| (Phase 7): the same material fields counted across the
    -- whole account. Keyed by recipe id rather than appended, so a b| whose
    -- y| never arrived decorates nothing (the v|-to-c| rule).
    if (kind == 'b' and state.inbound == 'recipes') then
        local held = { };

        for count in string.gmatch(parts[6] or '', '([^,]+)') do
            table.insert(held, tonumber(count) or 0);
        end

        state.book.acctRows[tonumber(parts[2]) or 0] = {
            have        = tonumber(parts[3]) or 0,
            mask        = tonumber(parts[4]) or 0,
            crystalHave = tonumber(parts[5]) or 0,
            held        = held,
        };

        return;
    end

    if (kind == 'w' and state.inbound == 'shop') then
        state.book.shop = {
            id      = tonumber(parts[2]) or 0,
            missing = tonumber(parts[3]) or 0,
            rows    = { },
        };

        return;
    end

    if (kind == 's' and state.inbound == 'shop') then
        if (state.book.shop ~= nil) then
            table.insert(state.book.shop.rows, {
                item  = tonumber(parts[2]) or 0,
                qty   = tonumber(parts[3]) or 0,
                depth = tonumber(parts[4]) or 0,
            });
        end

        return;
    end

    if (kind == 'l' and state.inbound == 'ladder') then
        state.ladder.head = {
            craft   = tonumber(parts[2]) or 0,
            raw     = tonumber(parts[3]) or 0,
            target  = tonumber(parts[4]) or 0,
            cap     = tonumber(parts[5]) or 0,
            gate    = tonumber(parts[6]) or 0,
            rungs   = tonumber(parts[7]) or 0,
            needPts = tonumber(parts[8]) or 0,
            leftPts = tonumber(parts[9]) or 0,
        };

        return;
    end

    if (kind == 'g' and state.inbound == 'ladder') then
        table.insert(state.ladder.rungs, {
            idx     = tonumber(parts[2]) or 0,
            recipe  = tonumber(parts[3]) or 0,
            synths  = tonumber(parts[4]) or 0,
            fromRaw = tonumber(parts[5]) or 0,
            toRaw   = tonumber(parts[6]) or 0,
            -- Expected points per synth arrives ×1000 so the wire stays
            -- integer; dividing is display, not arithmetic about the game.
            per     = (tonumber(parts[7]) or 0) / 1000,
            rate    = tonumber(parts[8]) or 0,
            gil     = tonumber(parts[9]) or 0,
            buy     = { },
        });

        return;
    end

    if (kind == 'a' and state.inbound == 'alts') then
        state.alts.head = {
            accid     = tonumber(parts[2]) or 0,
            -- Clamped because this number is a per-frame render-loop bound
            -- (altsPanel), and LuaJIT's tonumber accepts 'inf' -- one corrupt
            -- record must cost rows, never the frame loop (Phase 6 finding).
            -- The server's roster cap is 32; 99 leaves additive headroom.
            count     = math.min(tonumber(parts[3]) or 0, 99),
            freeCap   = tonumber(parts[4]) or 0,
            budget    = tonumber(parts[5]) or 0,
            truncated = tonumber(parts[6]) or 0,
        };

        return;
    end

    if (kind == 'c' and state.inbound == 'alts') then
        -- The name is the LAST field by protocol, so it is taken as
        -- everything after the fourth pipe rather than as parts[6]: that is
        -- what makes a name the parser could otherwise split harmless.
        local name = line:match('^c|[^|]*|[^|]*|[^|]*|[^|]*|(.*)$') or '';

        state.alts.rows[tonumber(parts[2]) or 0] = {
            flags = tonumber(parts[3]) or 0,
            used  = tonumber(parts[4]) or 0,
            left  = tonumber(parts[5]) or 0,
            name  = name,
            raw   = { },
            rank  = { },
        };

        return;
    end

    if (kind == 'v' and state.inbound == 'alts') then
        -- v| rows key back to their c| by index, the u|-to-g| rule: an
        -- orphaned row is dropped rather than landing on the wrong character.
        local row = state.alts.rows[tonumber(parts[2]) or 0];

        if (row == nil) then
            return;
        end

        -- Both lists are in CRAFT_ORDER, which is the order the server emits
        -- and the order this file renders. Position IS the craft id here --
        -- the one place the wire is positional, and it is the reason the
        -- order is a shared constant rather than a loop bound. Values past
        -- the constant's end are skipped, not an error: a future server
        -- widening the list is the additive case the parser rules promise
        -- to survive (Phase 6 finding -- indexing raw[nil] threw instead).
        local slot = 0;

        for value in string.gmatch(parts[3] or '', '([^,]+)') do
            slot = slot + 1;

            if (CRAFT_ORDER[slot] == nil) then
                break;
            end

            row.raw[CRAFT_ORDER[slot]] = tonumber(value) or 0;
        end

        slot = 0;

        for value in string.gmatch(parts[4] or '', '([^,]+)') do
            slot = slot + 1;

            if (CRAFT_ORDER[slot] == nil) then
                break;
            end

            row.rank[CRAFT_ORDER[slot]] = tonumber(value) or 0;
        end

        return;
    end

    if (kind == 'u' and state.inbound == 'ladder') then
        local idx = tonumber(parts[2]) or 0;

        -- u| rows key back to their rung by index, so an out-of-order or
        -- orphaned row is dropped rather than landing on the wrong rung.
        for _, rung in ipairs(state.ladder.rungs) do
            if (rung.idx == idx) then
                table.insert(rung.buy, {
                    item = tonumber(parts[3]) or 0,
                    qty  = tonumber(parts[4]) or 0,
                    gil  = tonumber(parts[5]) or 0,
                });

                return;
            end
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Layout after the 4-byte header: sName[15]
* at 0x08, Mes at 0x17. Any line whose sender is _DWCDATA is ours: it is
* consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwcraft_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is
    -- blocked before parsing rather than after: a malformed record must not
    -- leak into the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwcraft'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* The tally's packet watcher (Phase 4) -- the dwparse carve-out. GP_SERV
* 0x06F COMBINE_ANS is the server telling THIS client its own synthesis
* result; counting those packets is recording what was already received,
* not deriving game state. Layout after the 4-byte header
* (src/map/packets/s2c/0x06f_combine_ans.h): Result u8 @0x04, Grade i8
* @0x05, Count u8 @0x06, ItemNo u16 @0x08, BreakNo[8] u16 @0x0A, UpKind[4]
* @0x1A, UpLevel[4] @0x1E, CrystalNo u16 @0x22, MaterialNo[8] u16 @0x24.
* Grade/UpKind/UpLevel are never filled by this server and are never read.
--]]

-- Plain little-endian byte reads; offsets are packet offsets (0-based), the
-- +1 is Lua's string indexing.
local function u8(data, off)
    return string.byte(data, off + 1) or 0;
end

local function u16(data, off)
    return (string.byte(data, off + 1) or 0) + (string.byte(data, off + 2) or 0) * 256;
end

local function u32(data, off)
    return u16(data, off) + u16(data, off + 2) * 65536;
end

-- The client-counted half starts over. The server half is only cleared when
-- the sitting itself ended (logout, char switch) -- a mid-sitting zero (the
-- Reset button) is immediately followed by `!dwc tally reset`, whose answer
-- replaces the frame anyway.
local function zeroTally(alsoServer)
    state.tally.count = {
        attempts = 0,
        breaks   = 0,
        nq       = 0,
        hq       = 0,
        tiers    = { 0, 0, 0 },
        other    = 0,
        made     = { },
        used     = { },
    };

    if (alsoServer) then
        state.tally.server = nil;
        state.tally.moved  = { };
    end
end

-- Which recipe do these inputs resolve to, and which tier is this result?
-- Returns 'nq', 1..3, or nil when the catalog cannot say (handshake failed,
-- desynth, or an unknown combination) -- unclassified is counted, not
-- guessed at.
--
-- MANY RECIPES' HQ IS THE SAME ITEM AT A BIGGER YIELD (lumber: NQ x1, HQ
-- x2/x3/x4), so the item id alone cannot name the tier: the (item, count)
-- pair is matched first, and the id alone only as a fallback for a count
-- the catalog does not know.
local function classifyResult(crystalNo, materialNos, itemNo, count)
    if (catalog == nil) then
        return nil;
    end

    local units = { };

    for _, id in ipairs(materialNos) do
        if (id ~= 0) then
            table.insert(units, id);
        end
    end

    table.sort(units);

    local candidates = catalog.byInputs[crystalNo .. ':' .. table.concat(units, ',')];

    if (candidates == nil) then
        return nil;
    end

    -- The same inputs can start more than one recipe (four such sets ship in
    -- the catalog), so every claimant offers its own verdict -- per recipe,
    -- NQ before the tiers, the original precedence -- and the answer only
    -- stands when they agree. A result that is one claimant's NQ and
    -- another's HQ tier is honestly unclassifiable and lands in `other`:
    -- counted, never guessed (Phase 6 finding).
    local function vote(match)
        local verdict = nil;
        local split   = false;

        for _, recipe in ipairs(candidates) do
            -- hq is the generator's flat { item1, qty1, item2, qty2, item3, qty3 }.
            local own = nil;

            if (match(itemNo == recipe.result, count == recipe.qty)) then
                own = 'nq';
            else
                for tier = 1, 3 do
                    if (own == nil and match(recipe.hq[tier * 2 - 1] == itemNo, recipe.hq[tier * 2] == count)) then
                        own = tier;
                    end
                end
            end

            if (own ~= nil) then
                if (verdict == nil) then
                    verdict = own;
                elseif (verdict ~= own) then
                    split = true;
                end
            end
        end

        return verdict, split;
    end

    -- (item, count) exactly first; the id alone only as a fallback for a
    -- count the catalog does not know -- the original two passes, each now
    -- run across every claimant.
    local verdict, split = vote(function(itemOk, countOk)
        return itemOk and countOk;
    end);

    if (verdict ~= nil or split) then
        return (not split) and verdict or nil;
    end

    verdict, split = vote(function(itemOk, _)
        return itemOk;
    end);

    return (not split) and verdict or nil;
end

-- Results by synthutils.cpp's own push sites: Success (handleSynthSuccess),
-- SuccessDesynth (same, desynth mode), Failed (handleSynthFail, materials
-- lost per BreakNo), InterruptedCritical (doSynthCriticalFail, every slot
-- broken). Cancels never had a transaction: their material fields are zero
-- and they count as nothing. Plain Interrupted (0x02) is not pushed by this
-- server today; treated as a break so a future core change degrades to
-- honesty rather than to silence.
local RESULT_SUCCESS       = 0x00;
local RESULT_FAILED        = 0x01;
local RESULT_INTERRUPTED   = 0x02;
local RESULT_SUCCESS_DESYN = 0x0C;
local RESULT_INTERRUPT_HARD = 0x0E;

ashita.events.register('packet_in', 'dwcraft_synth', function (e)
    if (e.id ~= 0x006F) then
        return;
    end

    local ok, err = pcall(function ()
        local data   = e.data;
        local result = u8(data, 0x04);

        local success = result == RESULT_SUCCESS or result == RESULT_SUCCESS_DESYN;
        local broke   = result == RESULT_FAILED or result == RESULT_INTERRUPTED or result == RESULT_INTERRUPT_HARD;

        if (not success and not broke) then
            return;
        end

        local count = state.tally.count;

        count.attempts = count.attempts + 1;

        local crystalNo = u16(data, 0x22);

        -- The crystal is spent the moment the synth starts (startSynth's
        -- consumeCrystal), so every counted attempt consumed it.
        if (crystalNo ~= 0) then
            count.used[crystalNo] = (count.used[crystalNo] or 0) + 1;
        end

        if (broke) then
            count.breaks = count.breaks + 1;

            -- BreakNo lists the units actually lost; the rest came back.
            for i = 0, 7 do
                local id = u16(data, 0x0A + i * 2);

                if (id ~= 0) then
                    count.used[id] = (count.used[id] or 0) + 1;
                end
            end

            return;
        end

        -- Success: every slot's unit is consumed, and the result lands in
        -- the bags. One unit per window slot -- MaterialNo repeats an id
        -- that a recipe needs twice.
        local materials = { };

        for i = 0, 7 do
            local id = u16(data, 0x24 + i * 2);

            table.insert(materials, id);

            if (id ~= 0) then
                count.used[id] = (count.used[id] or 0) + 1;
            end
        end

        local itemNo = u16(data, 0x08);
        local qty    = u8(data, 0x06);

        if (itemNo ~= 0) then
            count.made[itemNo] = (count.made[itemNo] or 0) + math.max(qty, 1);
        end

        local tier = classifyResult(crystalNo, materials, itemNo, math.max(qty, 1));

        if (tier == 'nq') then
            count.nq = count.nq + 1;
        elseif (tier ~= nil) then
            count.hq          = count.hq + 1;
            count.tiers[tier] = count.tiers[tier] + 1;
        else
            count.other = count.other + 1;
        end
    end);

    if (not ok) then
        print(chat.header('dwcraft'):append(chat.error('tally packet: ' .. tostring(err))));
    end
end);

--[[
* The sitting's client-side boundary. The server's anchor dies on logout
* (craft_session.lua); these are the same two deaths, seen from the client:
* 0x00B with a LogoutState that is not a zone change means this character is
* leaving the world, and a 0x00A whose UniqueNo is not the character the
* counts belong to means somebody else logged in under the same addon
* instance. Zone changes match neither and keep the sitting -- the panel's
* promise.
--]]
local LOGOUT_ZONECHANGE = 2;
local LOGOUT_CANCEL     = 4;

ashita.events.register('packet_in', 'dwcraft_logout', function (e)
    if (e.id ~= 0x000B) then
        return;
    end

    local logoutState = u8(e.data or '', 0x04);

    if (logoutState ~= LOGOUT_ZONECHANGE and logoutState ~= LOGOUT_CANCEL and logoutState ~= 0) then
        zeroTally(true);
    end
end);

--[[
* Rendering.
--]]

local function fmtLevel(raw)
    return string.format('%.1f', raw / 10);
end

--[[
* Layout is measured, not guessed. Hand-tuned pixel widths are how "next rank
* test at 8" shipped cut off at "next rank te": the column was sized to a
* different font than the one players run. Everything below is computed from
* the live font each frame (a handful of CalcTextSize calls), so a font or
* scale change re-fits the window instead of quietly truncating it again.
* CalcTextSize / GetTextLineHeight(WithSpacing) / GetStyle are all proven in
* this Ashita build -- statustimers, petinfo, itemwatch and XIUI ship on them.
--]]
local function widestOf(texts)
    local widest = 0;

    for _, text in pairs(texts) do
        local w = imgui.CalcTextSize(text);

        if (w > widest) then
            widest = w;
        end
    end

    return widest;
end

-- Every string the "wall" column can ever say, at its widest values: the
-- rank ladder tops out at cap 160 (Legend), the last testable cap is 100.
local WALL_TEMPLATES = {
    'cap 100, next rank test at 98',
    'at cap 100 -- see your guild',
    'at cap 160',
};

local function columnWidths()
    return {
        name  = widestOf(CRAFT_NAMES),
        level = imgui.CalcTextSize('160.0'),
        rank  = widestOf(RANK_NAMES),
        wall  = widestOf(WALL_TEMPLATES),
    };
end

-- Title line + separator + the child's own padding: what every panel spends
-- before its first content line.
local function panelChrome(style)
    return imgui.GetTextLineHeightWithSpacing()
         + style.ItemSpacing.y + 1
         + style.WindowPadding.y * 2
         + 4;
end

local function skillsHeight(style)
    -- A table row is one text line plus the cell padding above and below it.
    local row = imgui.GetTextLineHeight() + style.CellPadding.y * 2;

    return panelChrome(style) + #CRAFT_ORDER * row;
end

local function ledgerHeight(style)
    local lines = 2;

    if (state.ledger ~= nil and state.ledger.payer ~= 0) then
        lines = 3;
    end

    return panelChrome(style) + imgui.GetTextLineHeightWithSpacing() * lines;
end

local function rulesHeight(style)
    -- hq, skill, and the two modern-system lines.
    return panelChrome(style) + imgui.GetTextLineHeightWithSpacing() * 4;
end

-- The detail pane under the results: sized for a full recipe (header, key
-- item, crystal, the longest ingredient list, verdict, buttons) and allowed
-- to scroll when a shopping expansion runs past it.
local function detailHeight(style)
    return panelChrome(style)
         + imgui.GetTextLineHeightWithSpacing() * 12
         + imgui.GetFrameHeightWithSpacing();
end

local function bookHeight(style)
    local row = imgui.GetTextLineHeight() + style.CellPadding.y * 2;

    return imgui.GetFrameHeightWithSpacing()                -- the search row
         + imgui.GetTextLineHeightWithSpacing()             -- the pager line
         + panelChrome(style) + row * 12                    -- twelve result rows
         + detailHeight(style)
         + style.ItemSpacing.y * 3;
end

-- The ladder never sends more than eight rungs (dwc_protocol.md g|), and its
-- header runs to four lines at worst: the aim, the rank-test refusal, the
-- refusal's detail, and the specialization warning.
local LADDER_MAX_RUNGS = 8;

local function ladderHeight(style)
    local row = imgui.GetTextLineHeight() + style.CellPadding.y * 2;

    return imgui.GetFrameHeightWithSpacing()                -- the ask row
         + imgui.GetTextLineHeightWithSpacing() * 4         -- the header block
         + panelChrome(style) + row * LADDER_MAX_RUNGS
         + detailHeight(style)
         + style.ItemSpacing.y * 3;
end

-- The widest each ladder column can be asked to hold. Measured, not guessed
-- -- the same rule that stopped the skills grid truncating in Phase 2.
local LADDER_TEMPLATES = {
    'Craft 9999 of Chunk Of Orichalcum Ore',
    'Goldsmithing 100',
    '100.0 to 110.0',
    '9.99/synth, 100% live',
    '999999999 gil',
};

-- The account matrix's column labels. The full craft names do not fit nine
-- abreast at any sane window width, and abbreviating is a rendering decision,
-- so it lives here with the other rendering decisions rather than on the wire.
local ALTS_SHORT = {
    [48] = 'Fish',
    [49] = 'Wood',
    [50] = 'Smith',
    [51] = 'Gold',
    [52] = 'Cloth',
    [53] = 'Leather',
    [54] = 'Bone',
    [55] = 'Alch',
    [56] = 'Cook',
};

-- The widest the name column can be asked to hold: chars.charname is 15
-- bytes, and the "(you)" marker rides in the same cell.
local ALTS_NAME_TEMPLATE = 'WWWWWWWWWWWWWWW (you)';

local function altsColumnWidths()
    -- A craft column holds either its header or a level; whichever is wider
    -- wins, measured rather than assumed, like every other column here.
    local craft = imgui.CalcTextSize('160.0');

    for _, label in pairs(ALTS_SHORT) do
        local w = imgui.CalcTextSize(label);

        if (w > craft) then
            craft = w;
        end
    end

    return {
        name  = imgui.CalcTextSize(ALTS_NAME_TEMPLATE),
        craft = craft,
        pts   = imgui.CalcTextSize('1200 / 1200'),
    };
end

local function altsWidth(style)
    local columns = altsColumnWidths();

    return columns.name + columns.pts + columns.craft * #CRAFT_ORDER
         + style.CellPadding.x * 2 * (#CRAFT_ORDER + 2)
         + style.WindowPadding.x * 4
         + 12;
end

-- A roster somebody plausibly has. The server's cap is higher, so the table
-- scrolls past this rather than the window growing to an account nobody owns.
local ALTS_SHOWN_ROWS = 8;

local function altsHeight(style)
    local row = imgui.GetTextLineHeight() + style.CellPadding.y * 2;

    return panelChrome(style)
         + row * (ALTS_SHOWN_ROWS + 1)              -- the header row plus the roster
         + imgui.GetTextLineHeightWithSpacing() * 2 -- the footnote and the truncation line
         + style.ItemSpacing.y * 2;
end

-- The tally tab at its default size: the server frame with every craft
-- moved, a counted block tall enough for a real sitting's lists, and the
-- reset row. First-use sizing only, like everything else here.
local function tallyDefaultHeight(style)
    return panelChrome(style) + imgui.GetTextLineHeightWithSpacing() * 11    -- the server frame
         + panelChrome(style) + imgui.GetTextLineHeightWithSpacing() * 12    -- the counted block
         + imgui.GetFrameHeightWithSpacing()                                 -- the reset row
         + style.ItemSpacing.y * 3;
end

-- The default window size: wide enough that no skills column truncates, tall
-- enough that neither tab grows a scrollbar. First-use only -- the player's
-- own resize always wins after that.
local function defaultWindowSize(style, columns)
    local width = columns.name + columns.level + columns.rank + columns.wall
                + style.CellPadding.x * 8       -- four columns, both sides
                + style.WindowPadding.x * 4     -- the window's and the child's
                + 12;                           -- child borders and grace

    -- The ladder's five columns are wider than the skills grid's four, and a
    -- window sized to the narrower tab would clip the other one.
    local ladderWidth = style.CellPadding.x * 10
                      + style.WindowPadding.x * 4
                      + 12;

    for _, template in ipairs(LADDER_TEMPLATES) do
        ladderWidth = ladderWidth + imgui.CalcTextSize(template);
    end

    width = math.max(width, ladderWidth);

    -- The Alts tab is nine craft columns abreast and is the widest thing this
    -- window ever draws; sizing to a narrower tab would open it clipped.
    width = math.max(width, altsWidth(style));

    local ledgerTab = skillsHeight(style)
                    + panelChrome(style) + imgui.GetTextLineHeightWithSpacing() * 3
                    + rulesHeight(style)
                    + style.ItemSpacing.y * 2;

    local height = imgui.GetFrameHeightWithSpacing()        -- the title bar
                 + imgui.GetFrameHeightWithSpacing()        -- the tab bar
                 + math.max(math.max(math.max(ledgerTab, tallyDefaultHeight(style)),
                                     math.max(bookHeight(style), ladderHeight(style))),
                            altsHeight(style))
                 + style.WindowPadding.y * 2
                 + 8;

    return { width, height };
end

local function skillsPanel()
    local style   = imgui.GetStyle();
    local columns = columnWidths();

    -- NOTE: the third argument is ImGuiChildFlags, not a bool -- Ashita
    -- ships ImGui 1.90+, and a bool here raises a Lua error on every frame.
    imgui.BeginChild('##dwcraft_skills', { 0, skillsHeight(style) }, ImGuiChildFlags_Borders);

    imgui.Text('Your crafts');
    imgui.SameLine();
    imgui.TextDisabled('-- level, rank, and where the next wall is');
    imgui.Separator();

    if (imgui.BeginTable('##dwcraft_skills_table', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        -- WidthFixed throughout, like the other Driftwood addons: only the
        -- flags they already use are proven to exist in this environment's
        -- ImGui bindings, and a nil flag global is a Lua error per frame.
        -- The widths themselves are measured from the font (columnWidths).
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, columns.name, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, columns.level, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, columns.rank, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, columns.wall, 0);

        for _, id in ipairs(CRAFT_ORDER) do
            local row = state.crafts[id];

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(CRAFT_NAMES[id]);

            if (row == nil) then
                imgui.TableNextColumn();
                imgui.TextDisabled('-');
                imgui.TableNextColumn();
                imgui.TableNextColumn();
            else
                local specialized = state.ledger ~= nil and id ~= 48 and row.raw > state.ledger.freeCap;

                imgui.TableNextColumn();

                if (specialized) then
                    -- Past the free cap: these are the levels the shared
                    -- budget is paying for.
                    imgui.TextColored(theme.colors.pin, fmtLevel(row.raw));
                else
                    imgui.Text(fmtLevel(row.raw));
                end

                if (row.bonus ~= 0 and imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('+%d from gear or guild image support', row.bonus));
                end

                imgui.TableNextColumn();
                imgui.Text(RANK_NAMES[row.rank] or string.format('rank %d', row.rank));

                imgui.TableNextColumn();

                if (row.raw >= row.cap * 10) then
                    -- At this rank's cap: skill-ups have stopped until the
                    -- guild test (synthutils hard-stops there). Wording is in
                    -- WALL_TEMPLATES; the column is sized to those strings.
                    if (row.rank < LAST_TESTED_RANK) then
                        imgui.TextColored(theme.colors.warn, string.format('at cap %d -- see your guild', row.cap));
                    else
                        imgui.TextColored(theme.colors.ok, string.format('at cap %d', row.cap));
                    end
                elseif (row.rank < LAST_TESTED_RANK) then
                    -- The derivation the protocol doc grants: the guild
                    -- offers the next test from cap - 2.
                    imgui.TextDisabled(string.format('cap %d, next rank test at %d', row.cap, row.cap - 2));
                else
                    imgui.TextDisabled(string.format('cap %d', row.cap));
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

local function ledgerPanel()
    imgui.BeginChild('##dwcraft_ledger', { 0, ledgerHeight(imgui.GetStyle()) }, ImGuiChildFlags_Borders);

    imgui.Text('Specialization');
    imgui.SameLine();
    imgui.TextDisabled('-- the budget past the free cap, shared by all crafts');
    imgui.Separator();

    local led = state.ledger;

    if (led == nil) then
        imgui.TextDisabled('Waiting for the server...');
    else
        imgui.Text(string.format('%d of %d points used, %d free.', led.used, led.budget, led.left));
        imgui.SameLine();
        imgui.TextDisabled('(a point is 0.1 craft levels)');

        -- The three-crafts illustration is the p| record's second granted
        -- derivation (dwc_protocol.md): freeCap + budget/3, both wire-fed.
        -- With 110 baked in as copy, a settings change server-side would
        -- leave this sentence false beside numbers that are true.
        imgui.TextDisabled(string.format('Every craft levels freely to %s -- enough budget for three crafts at %g. Fishing never counts.',
            fmtLevel(led.freeCap), (led.freeCap + led.budget / 3) / 10));

        if (led.payer ~= 0) then
            imgui.TextColored(theme.colors.hint, string.format('%s is your highest specialized craft -- it pays first if the budget runs dry.',
                CRAFT_NAMES[led.payer] or ('craft ' .. led.payer)));
        end
    end

    imgui.EndChild();
end

local function rulesPanel()
    imgui.BeginChild('##dwcraft_rules', { 0, 0 }, ImGuiChildFlags_Borders);

    imgui.Text('House rules');
    imgui.SameLine();
    imgui.TextDisabled('-- from the server\'s live settings, not folklore');
    imgui.Separator();

    -- Only rules the server asserted exist here (dwc_protocol.md r|): a line
    -- the server did not send is not rendered, so this panel cannot claim a
    -- tuning the box is not running.
    local said = false;

    if (state.rules.hq ~= nil) then
        imgui.Text(string.format('HQ chance: %sx retail, skill-based only.', state.rules.hq[1] or '?'));
        said = true;
    end

    if (state.rules.skill ~= nil) then
        imgui.Text(string.format('Skill-ups: %sx chance, %sx amount.', state.rules.skill[1] or '?', state.rules.skill[2] or '?'));
        said = true;
    end

    if (state.rules.modern ~= nil and state.rules.modern[1] == '1') then
        -- TEN, not eleven. doSynthSkillUp skips on `baseDiff <= minDiff` with
        -- minDiff -11, so -10 is the last difference that teaches. The Ladder
        -- tab plans to this exact bound and sits in the same window; the two
        -- cannot be allowed to disagree.
        imgui.Text('Modern skill-up rules: recipes up to 10 levels below you still teach.');
        imgui.TextColored(theme.colors.hint, 'Day and moon folklore does nothing here. Craft when you like.');
        said = true;
    end

    if (not said) then
        imgui.TextDisabled('Waiting for the server...');
    end

    imgui.EndChild();
end

--[[
* The recipe book tab. Renders only what the server said (y|, w|, s|) plus
* names and requirements from the hash-verified catalog; the one thing it
* decides for itself is which words to hang on which server-said bit.
--]]

-- Status text and color from the y| flags, in the same precedence the
-- typed tier speaks (craft_core describeState). The one Phase 7 addition:
-- when the LOCAL bag is the only blocker and the server's b| record says the
-- account pile completes it, the row says so -- the same sentence the typed
-- tier prints, decided by the same server-said numbers.
local function rowStatus(row)
    if (hasBit(row.flags, 1)) then
        return 'can make', theme.colors.ok;
    elseif (not hasBit(row.flags, 2)) then
        return string.format('%s %d below', CRAFT_NAMES[row.gapCraft] or '?', row.gapLvls), theme.colors.inert;
    elseif (not hasBit(row.flags, 4)) then
        return 'outside the 15-level rule', theme.colors.inert;
    elseif (hasBit(row.flags, 32)) then
        return 'Rare: already held', theme.colors.warn;
    elseif (not hasBit(row.flags, 16)) then
        return 'key item missing', theme.colors.warn;
    else
        local acct = state.book.acctRows[row.id];

        if (acct ~= nil and acct.have >= row.need) then
            return 'mats on your account', theme.colors.hint;
        end

        return 'missing materials', theme.colors.warn;
    end
end

local function bookBanner()
    local book = state.book;

    if (catalogState ~= 'ok') then
        imgui.PushStyleColor(ImGuiCol_Text, theme.colors.err);
        imgui.TextWrapped(catalogState == 'missing'
            and 'The recipe catalog (data/recipes.lua) is missing from this addon install.'
            or 'The recipe catalog shipped with this addon failed to load.');
        imgui.TextWrapped('Reinstall dwcraft through the launcher. The Ledger tab still works.');
        imgui.PopStyleColor();

        return false;
    end

    if (book.serverHash == nil) then
        imgui.TextDisabled('Checking recipe data with the server...');

        return false;
    end

    if (book.serverHash == '') then
        imgui.TextColored(theme.colors.warn, 'This server does not offer the recipe book yet.');
        imgui.TextDisabled('The Ledger tab is unaffected.');

        return false;
    end

    if (book.serverHash ~= catalog.hash) then
        -- The whole point of the handshake: refuse, never render a recipe
        -- the server would refuse. The ledger keeps working (plan C5).
        imgui.TextColored(theme.colors.warn, 'Recipe data out of date -- update dwcraft through the launcher.');
        imgui.TextDisabled(string.format('Server catalog %s (%d recipes); this addon carries %s (%d).',
            book.serverHash, book.serverCount, catalog.hash, catalog.count));
        imgui.TextDisabled('The Ledger tab is unaffected.');

        return false;
    end

    return true;
end

local function bookSearchRow()
    local book = state.book;

    imgui.PushItemWidth(imgui.CalcTextSize('Goldsmithing') + 40);

    if (imgui.Combo('##dwcraft_bookcraft', book.craftIdx, BOOK_COMBO)) then
        askRecipes(1);
    end

    imgui.PopItemWidth();
    imgui.SameLine();
    imgui.PushItemWidth(imgui.CalcTextSize('wwwwwwwwwwwwwwwwww'));

    local entered = imgui.InputText('##dwcraft_booksearch', book.search, 64, ImGuiInputTextFlags_EnterReturnsTrue);

    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.Button('Search##dwcraft') or entered) then
        askRecipes(1);
    end

    imgui.SameLine();

    if (imgui.Button('Check bags##dwcraft')) then
        -- Same question, fresh counts: the server re-reads the inventory
        -- (and, in account mode, the account pile), and a stack emptied
        -- mid-window moves its rows.
        askRecipes(book.header ~= nil and book.header.page or 1, true);

        if (book.selected ~= nil and book.shop ~= nil) then
            requested['shop'] = nil;
            askShop(book.selected);
        end
    end

    -- The account controls exist only when the server's hello said the
    -- build can answer them (f| field 7). On an older server or a Lua-only
    -- build this row looks exactly as it always did -- no checkbox that
    -- asks a question nothing will answer.
    if (book.acctSupported == true) then
        imgui.SameLine();

        if (imgui.Checkbox('All chars##dwcraft_acct', book.acct)) then
            askRecipes(1, true);
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Count materials across every bag of every character on your account.');
        end

        imgui.SameLine();

        if (imgui.Checkbox('Craftable only##dwcraft_acctonly', book.acctOnly)) then
            askRecipes(1, true);
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Only recipes your account holds every material for, within your skill range.');
        end
    end

    -- The warehouse control (Phase 8) renders on ITS OWN hello field, the
    -- acctSupported rule again: a checkbox the server cannot honour is a
    -- question nothing will answer.
    if (book.whSupported == true) then
        imgui.SameLine();

        if (imgui.Checkbox('Warehouse##dwcraft_wh', book.wh)) then
            askRecipes(1, true);
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Also count materials stored in your DWWarehouse (only rows you could pull).');
        end
    end
end

local function bookRows()
    local book  = state.book;
    local style = imgui.GetStyle();

    if (book.header ~= nil) then
        imgui.Text(string.format('%d recipes -- page %d/%d', book.header.total, book.header.page, book.header.pages));

        if (book.header.pages > 1) then
            imgui.SameLine();

            if (imgui.Button('<##dwcraft_prev') and book.header.page > 1) then
                askRecipes(book.header.page - 1);
            end

            imgui.SameLine();

            if (imgui.Button('>##dwcraft_next') and book.header.page < book.header.pages) then
                askRecipes(book.header.page + 1);
            end
        end
    else
        imgui.TextDisabled('Search by name or material, or pick a craft to browse its book.');
    end

    imgui.BeginChild('##dwcraft_bookrows', { 0, -detailHeight(style) }, ImGuiChildFlags_Borders);

    if (book.header ~= nil and #book.rows == 0) then
        -- `mode` is a BITMASK, not a level: 2 is the craftable filter and 4 is
        -- "the warehouse is riding too". `>= 2` therefore also caught mode 4
        -- and mode 5 -- the warehouse on with the craftable filter OFF -- and
        -- told the player no recipe had its materials when in truth their
        -- SEARCH matched nothing. Mask the warehouse bit off before asking.
        local mode = book.header.mode or 0;

        imgui.TextDisabled((mode % 4) >= 2
            and string.format('Nothing here: no recipe has all its materials in %s.',
                mode >= 4 and 'your account\'s bags and warehouse' or 'your account\'s bags')
            or 'No recipe matches that. Search covers names and materials.');
    end

    if (#book.rows > 0 and imgui.BeginTable('##dwcraft_book_table', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        -- Columns measured over exactly what this page renders, so nothing
        -- can truncate (the same rule the skills grid follows). The mats
        -- cell may carry the account pile beside the bag count; measured
        -- with it, plus the SameLine gap.
        local nameW, craftW, statusW = 0, 0, 0;
        local matsW = imgui.CalcTextSize('99/9');

        for _, row in ipairs(book.rows) do
            local recipe = catalog.byId[row.id];

            if (recipe ~= nil) then
                local acct = book.acctRows[row.id];

                nameW   = math.max(nameW, (imgui.CalcTextSize(itemName(recipe.result))));
                craftW  = math.max(craftW, (imgui.CalcTextSize(string.format('%s %d', CRAFT_NAMES[recipe.craft] or '?', recipe.lvl))));
                statusW = math.max(statusW, (imgui.CalcTextSize((rowStatus(row)))));

                if (acct ~= nil) then
                    matsW = math.max(matsW, (imgui.CalcTextSize(string.format('%d/%d (%d/%d)',
                        row.have, row.need, acct.have, row.need))) + style.ItemSpacing.x);
                end
            end
        end

        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, nameW + 8, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, craftW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, matsW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, statusW, 0);

        for _, row in ipairs(book.rows) do
            local recipe = catalog.byId[row.id];

            if (recipe ~= nil) then
                local text, color = rowStatus(row);
                local greyed      = not hasBit(row.flags, 2);

                imgui.TableNextRow();
                imgui.TableNextColumn();

                if (greyed) then
                    imgui.PushStyleColor(ImGuiCol_Text, theme.colors.inert);
                end

                if (imgui.Selectable(string.format('%s##dwcraft_row%d', itemName(recipe.result), row.id),
                        book.selected == row.id, ImGuiSelectableFlags_SpanAllColumns)) then
                    book.selected = row.id;
                    book.shop     = nil;
                    requested['shop'] = nil;
                end

                if (greyed) then
                    imgui.PopStyleColor();
                end

                imgui.TableNextColumn();
                imgui.TextDisabled(string.format('%s %d', CRAFT_NAMES[recipe.craft] or '?', recipe.lvl));
                imgui.TableNextColumn();

                if (row.have >= row.need) then
                    imgui.TextColored(theme.colors.ok, string.format('%d/%d', row.have, row.need));
                else
                    imgui.TextColored(theme.colors.warn, string.format('%d/%d', row.have, row.need));
                end

                -- The account pile beside the bag count (Phase 7): the b|
                -- record's numbers, hint-coloured when the pile completes
                -- the set, inert when even the whole account is short.
                local acct = book.acctRows[row.id];

                if (acct ~= nil) then
                    imgui.SameLine();
                    imgui.TextColored(acct.have >= row.need and theme.colors.hint or theme.colors.inert,
                        string.format('(%d/%d)', acct.have, row.need));
                end

                imgui.TableNextColumn();
                imgui.TextColored(color, text);
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

local function bookDetail()
    local book = state.book;

    imgui.BeginChild('##dwcraft_bookdetail', { 0, 0 }, ImGuiChildFlags_Borders);

    local row = nil;

    for _, candidate in ipairs(book.rows) do
        if (candidate.id == book.selected) then
            row = candidate;
            break;
        end
    end

    local recipe = row ~= nil and catalog.byId[row.id] or nil;

    if (recipe == nil) then
        imgui.TextDisabled('Select a recipe to see its materials.');
        imgui.EndChild();

        return;
    end

    imgui.Text(string.format('%s x%d', itemName(recipe.result), recipe.qty));
    imgui.SameLine();
    imgui.TextDisabled(string.format('-- %s %d', CRAFT_NAMES[recipe.craft] or '?', recipe.lvl));

    for i = 1, #recipe.subs, 2 do
        imgui.SameLine();
        imgui.TextDisabled(string.format('+ %s %d', CRAFT_NAMES[recipe.subs[i]] or '?', recipe.subs[i + 1]));
    end

    if (recipe.hq[1] ~= 0 or recipe.hq[3] ~= 0 or recipe.hq[5] ~= 0) then
        -- Name each tier, not just its yield: many recipes HQ into the same
        -- item at a bigger stack, but plenty do not (a Bronze Sword's HQ
        -- tiers are different swords), and 'x1 / x1 / x1' read as "the same
        -- item, once" for all of them. A tier that matches the NQ result
        -- stays terse; a different item is named.
        local tiers = {};

        for i = 1, 5, 2 do
            local id  = recipe.hq[i];
            local qty = recipe.hq[i + 1];

            if (id == 0) then
                -- No result at this tier; 'x0' would read as a zero yield.
                tiers[#tiers + 1] = '-';
            elseif (id == recipe.result) then
                tiers[#tiers + 1] = string.format('x%d', qty);
            else
                tiers[#tiers + 1] = string.format('%s x%d', itemName(id), qty);
            end
        end

        imgui.TextDisabled('HQ: ' .. table.concat(tiers, ' / '));
    end

    if (recipe.ki ~= 0) then
        local held = hasBit(row.flags, 16);

        imgui.TextColored(held and theme.colors.dim or theme.colors.warn,
            string.format('Key item: %s%s', catalog.keyItems[recipe.ki] or ('#' .. recipe.ki),
                held and '' or ' -- not held'));
    end

    imgui.Separator();

    -- The account pile for this recipe (Phase 7): the b| record when one
    -- arrived. `short` keeps meaning the LOCAL bag -- the warn colour is the
    -- enforcement's truth -- while the pile rides beside it in hint.
    local acct = book.acctRows[recipe.id];

    local function materialLine(name, needQty, holding, short, pile)
        if (short) then
            imgui.TextColored(theme.colors.warn, string.format('%s x%d -- you hold %d', name, needQty, holding));
        else
            imgui.Text(string.format('%s x%d -- you hold %d', name, needQty, holding));
        end

        if (pile ~= nil) then
            imgui.SameLine();
            imgui.TextColored(theme.colors.hint, string.format('(account %d)', pile));
        end
    end

    materialLine(itemName(recipe.crystal), 1, row.crystalHave, hasBit(row.mask, 1),
        acct ~= nil and acct.crystalHave or nil);

    for i = 1, #recipe.ings, 2 do
        local slot = (i + 1) / 2;

        materialLine(itemName(recipe.ings[i]), recipe.ings[i + 1], row.held[slot] or 0, hasBit(row.mask, 2 ^ slot),
            acct ~= nil and (acct.held[slot] or 0) or nil);
    end

    local text, color = rowStatus(row);

    imgui.TextColored(color, 'Verdict: ' .. text .. '.');

    if (acct ~= nil and book.acctInfo ~= nil) then
        -- The n| frame: whose bags these numbers cover and how old the
        -- count is. Age is a server-said number, not a client clock. The
        -- warehouse mention reads the q| echo -- what the answer actually
        -- took, never what the checkbox asked (Phase 8).
        local withWh = book.header ~= nil and (book.header.mode or 0) >= 4;
        local covers;

        if (book.acctInfo.chars > 0) then
            covers = string.format('%d character(s)%s', book.acctInfo.chars, withWh and ' and your warehouse' or '');
        else
            covers = 'your warehouse';
        end

        imgui.TextDisabled(string.format('Account counts cover %s%s.',
            covers,
            book.acctInfo.age > 0 and string.format(', from %ds ago', book.acctInfo.age) or ''));
    end

    if (imgui.Button('Shopping list##dwcraft')) then
        requested['shop'] = nil;
        askShop(recipe.id);
    end

    imgui.SameLine();

    if (imgui.Button('Send list to chat##dwcraft')) then
        -- The typed tier prints the same list into the chat log, where it
        -- can be read back after the window closes.
        issue(string.format('!craft shopping %d', recipe.id));
    end

    -- The pull button (Phase 8): what the LOCAL bag is short for one synth,
    -- asked back out of the warehouse in one typed line -- the follow-up
    -- DWWAREHOUSE_PLAN.md's v1 list deferred. `!warehouse pull` is a line a
    -- player could type; every rule about what actually moves lives in
    -- warehouse_store.cpp, and its answer (including any shortfall) prints
    -- to the chat log. The re-ask behind it refreshes the window's counts
    -- once the pull has landed: the queue drains in order, one line at a
    -- time, so the server sees the pull first.
    if (book.whSupported == true) then
        local pulls = T{ };

        if ((row.crystalHave or 0) < 1) then
            pulls:append(string.format('%d:%d', recipe.crystal, 1));
        end

        for i = 1, #recipe.ings, 2 do
            local slot    = (i + 1) / 2;
            local shortBy = recipe.ings[i + 1] - (row.held[slot] or 0);

            if (shortBy > 0) then
                pulls:append(string.format('%d:%d', recipe.ings[i], shortBy));
            end
        end

        if (#pulls > 0) then
            imgui.SameLine();

            if (imgui.Button('Pull from warehouse##dwcraft')) then
                issue('!warehouse pull ' .. table.concat(pulls, ','));
                askRecipes(book.header ~= nil and book.header.page or 1, true);
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Pull what this synth is short from your DWWarehouse (one synth\'s worth).');
            end
        end
    end

    local shop = book.shop;

    if (shop ~= nil and shop.id == recipe.id) then
        if (shop.missing == 0) then
            imgui.TextColored(theme.colors.ok, 'You hold everything one synth needs.');
        else
            imgui.TextDisabled('To buy for one synth (indented lines make the item above them):');

            for _, entry in ipairs(shop.rows) do
                imgui.Text(string.format('%s%dx %s', string.rep('    ', entry.depth), entry.qty, itemName(entry.item)));
            end
        end
    end

    imgui.EndChild();
end

local function bookPanel()
    if (not bookBanner()) then
        return;
    end

    bookSearchRow();
    bookRows();
    bookDetail();
end

--[[
* The ladder tab. Every figure here -- synths, points per synth, survival
* rate, gil -- arrives in a g|/u| record computed by the same formulas
* synthutils.cpp enforces. The addon picks which words to hang on them and
* does no arithmetic beyond dividing the wire's ×1000 points for display.
--]]

local function ladderAskRow()
    local plan = state.ladder;

    imgui.PushItemWidth(imgui.CalcTextSize('Goldsmithing') + 40);

    if (imgui.Combo('##dwcraft_laddercraft', plan.craftIdx, LADDER_COMBO)) then
        -- A different craft has a different cap, so the old target and the
        -- old rows are answers to a question nobody asked.
        plan.head     = nil;
        plan.rungs    = { };
        plan.selected = nil;
    end

    imgui.PopItemWidth();
    imgui.SameLine();
    imgui.Text('to');
    imgui.SameLine();
    imgui.PushItemWidth(imgui.CalcTextSize('wwwww'));

    local entered = imgui.InputText('##dwcraft_laddertarget', plan.target, 4, ImGuiInputTextFlags_EnterReturnsTrue);

    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Leave blank to aim at your current rank cap.');
    end

    imgui.SameLine();

    if (imgui.Button('Plan##dwcraft') or entered) then
        askLadder(true);
    end

    imgui.SameLine();

    if (imgui.Button('Send to chat##dwcraft_ladder')) then
        local craft, target = ladderQuestion();

        if (craft ~= nil) then
            -- The typed tier prints the whole plan into the chat log, where
            -- it survives the window being closed.
            issue(string.format('!craft ladder %d %d', craft, target));
        end
    end
end

local function ladderHeader()
    local head = state.ladder.head;

    if (head == nil) then
        imgui.TextDisabled('Pick a craft and a target, then Plan.');

        return;
    end

    local name = CRAFT_NAMES[head.craft] or ('craft ' .. head.craft);

    imgui.Text(string.format('%s %s now, aiming at %d', name, fmtLevel(head.raw), head.target));
    imgui.SameLine();
    imgui.TextDisabled(string.format('(rank cap %d)', head.cap));

    if (head.gate == 1) then
        -- The server refused to invent a rung above the cap; say why, in the
        -- words the typed tier uses.
        imgui.TextColored(theme.colors.warn,
            string.format('Rank test first -- %d is above your cap of %d.', head.target, head.cap));

        if (head.cap >= 110) then
            imgui.TextDisabled('Expert is the last rank the guilds test for.');
        elseif (head.raw >= (head.cap - 2) * 10) then
            imgui.TextDisabled(string.format('You are past %d: the test is waiting at your guild now.', head.cap - 2));
        else
            imgui.TextDisabled(string.format('The guild offers the test at %d. Skill-ups stop dead at %d.', head.cap - 2, head.cap));
        end
    elseif (head.gate == 2) then
        imgui.TextColored(theme.colors.ok, 'Already there -- nothing to climb.');
    end

    if (head.needPts > 0) then
        if (head.needPts > head.leftPts) then
            imgui.TextColored(theme.colors.warn,
                string.format('This needs %d specialization points past the free cap and you have %d.',
                    head.needPts, head.leftPts));
        else
            imgui.TextDisabled(string.format('Specialization: spends %d of your %d remaining points.',
                head.needPts, head.leftPts));
        end
    end
end

local function ladderRows()
    local plan  = state.ladder;
    local style = imgui.GetStyle();

    imgui.BeginChild('##dwcraft_ladderrows', { 0, -detailHeight(style) }, ImGuiChildFlags_Borders);

    if (plan.head ~= nil and #plan.rungs == 0 and plan.head.gate == 0) then
        imgui.TextDisabled('No recipe on this server both teaches you and lets you attempt it right now.');
    end

    if (#plan.rungs > 0 and imgui.BeginTable('##dwcraft_ladder_table', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        -- Measured over exactly the rows on screen, the rule the other two
        -- tables follow: nothing truncates at any font scale.
        local craftW, bandW, perW = 0, 0, 0;
        local makeW  = imgui.CalcTextSize('Craft 9999 of ');
        local gilW   = imgui.CalcTextSize('cost unknown');

        for _, rung in ipairs(plan.rungs) do
            local recipe = catalog.byId[rung.recipe];

            if (recipe ~= nil) then
                makeW  = math.max(makeW, (imgui.CalcTextSize(string.format('Craft %d of %s', rung.synths, itemName(recipe.result)))));
                craftW = math.max(craftW, (imgui.CalcTextSize(string.format('%s %d', CRAFT_NAMES[recipe.craft] or '?', recipe.lvl))));
            end

            bandW = math.max(bandW, (imgui.CalcTextSize(string.format('%s to %s', fmtLevel(rung.fromRaw), fmtLevel(rung.toRaw)))));
            perW  = math.max(perW, (imgui.CalcTextSize(string.format('%.2f/synth, %d%% live', rung.per, rung.rate))));
            gilW  = math.max(gilW, (imgui.CalcTextSize(string.format('%d gil', rung.gil))));
        end

        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, makeW + 8, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, craftW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, bandW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, perW, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, gilW, 0);

        for _, rung in ipairs(plan.rungs) do
            local recipe = catalog.byId[rung.recipe];
            local label  = recipe ~= nil and itemName(recipe.result) or string.format('recipe %d', rung.recipe);

            imgui.TableNextRow();
            imgui.TableNextColumn();

            if (imgui.Selectable(string.format('Craft %d of %s##dwcraft_rung%d', rung.synths, label, rung.idx),
                    plan.selected == rung.idx, ImGuiSelectableFlags_SpanAllColumns)) then
                plan.selected = rung.idx;
            end

            imgui.TableNextColumn();

            if (recipe ~= nil) then
                imgui.TextDisabled(string.format('%s %d', CRAFT_NAMES[recipe.craft] or '?', recipe.lvl));
            end

            imgui.TableNextColumn();
            imgui.TextDisabled(string.format('%s to %s', fmtLevel(rung.fromRaw), fmtLevel(rung.toRaw)));
            imgui.TableNextColumn();
            imgui.Text(string.format('%.2f/synth, %d%% live', rung.per, rung.rate));
            imgui.TableNextColumn();

            if (rung.gil > 0) then
                imgui.Text(string.format('%d gil', rung.gil));
            else
                -- Zero gil with something still to buy is "no counter sells
                -- it", never "free" -- the server draws that line and the
                -- window must not blur it.
                imgui.TextColored(theme.colors.inert, #rung.buy > 0 and 'cost unknown' or 'nothing to buy');
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

local function ladderDetail()
    local plan = state.ladder;

    imgui.BeginChild('##dwcraft_ladderdetail', { 0, 0 }, ImGuiChildFlags_Borders);

    local rung = nil;

    for _, candidate in ipairs(plan.rungs) do
        if (candidate.idx == plan.selected) then
            rung = candidate;
            break;
        end
    end

    if (rung == nil) then
        if (#plan.rungs > 0) then
            local synths, gil, unpriced = 0, 0, false;

            for _, entry in ipairs(plan.rungs) do
                synths = synths + entry.synths;
                gil    = gil + entry.gil;
                unpriced = unpriced or (entry.gil == 0 and #entry.buy > 0);
            end

            imgui.Text(string.format('%d rungs, %d synths in all.', #plan.rungs, synths));

            if (unpriced) then
                imgui.TextDisabled('Some materials have no counter selling them, so there is no total.');
            else
                imgui.Text(string.format('About %d gil of materials to buy.', gil));
            end

            imgui.TextDisabled('Select a rung to see its shopping list.');
        else
            imgui.TextDisabled('A plan\'s rungs and their shopping lists appear here.');
        end

        imgui.EndChild();

        return;
    end

    local recipe = catalog.byId[rung.recipe];

    imgui.Text(string.format('Rung %d: craft %d of %s', rung.idx, rung.synths,
        recipe ~= nil and itemName(recipe.result) or string.format('recipe %d', rung.recipe)));
    imgui.SameLine();
    imgui.TextDisabled(string.format('-- %s to %s', fmtLevel(rung.fromRaw), fmtLevel(rung.toRaw)));

    imgui.TextDisabled(string.format('About %.2f points a synth, %d%% of them survive.', rung.per, rung.rate));
    imgui.Separator();

    if (#rung.buy == 0) then
        imgui.TextColored(theme.colors.ok, 'Your bags already hold everything this rung needs.');
    else
        imgui.TextDisabled('To buy for this rung:');

        for _, entry in ipairs(rung.buy) do
            local priced = catalog.prices[entry.item];
            local source = priced ~= nil and PRICE_SOURCES[priced[2]] or nil;

            if (entry.gil > 0) then
                imgui.Text(string.format('%dx %s', entry.qty, itemName(entry.item)));
                imgui.SameLine();
                imgui.TextDisabled(string.format('-- %d gil%s', entry.gil,
                    source ~= nil and (' (' .. source .. ')') or ''));
            else
                imgui.Text(string.format('%dx %s', entry.qty, itemName(entry.item)));
                imgui.SameLine();
                imgui.TextColored(theme.colors.warn, '-- no counter sells this');
            end
        end
    end

    imgui.EndChild();
end

local function ladderPanel()
    -- The ladder names recipes out of the catalog, so it lives or dies by the
    -- same handshake the book does.
    if (not bookBanner()) then
        return;
    end

    ladderAskRow();
    ladderHeader();
    ladderRows();
    ladderDetail();
end

--[[
* The tally tab (Phase 4). Two halves, two owners: the top child renders the
* server's t|/h| frame (skill and gil since the anchor -- current values from
* the same sync's k| rows, so all three numbers in a row are server-said);
* the bottom child renders what this addon counted from its own 0x06F
* packets. The reset resets both: counters here, anchor there.
--]]

local function fmtAge(seconds)
    if (seconds >= 3600) then
        return string.format('%ih %02im', math.floor(seconds / 3600), math.floor(seconds / 60) % 60);
    elseif (seconds >= 60) then
        return string.format('%im', math.floor(seconds / 60));
    end

    return string.format('%is', seconds);
end

local function sortedIds(map)
    local ids = { };

    for id in pairs(map) do
        table.insert(ids, id);
    end

    table.sort(ids);

    return ids;
end

local function tallyServerHeight(style)
    -- The sitting line, the gil line, and a row per moved craft (or the
    -- one "nothing moved" line).
    return panelChrome(style)
         + imgui.GetTextLineHeightWithSpacing() * (2 + math.max(1, #state.tally.moved));
end

local function tallyServerPanel()
    local style = imgui.GetStyle();

    imgui.BeginChild('##dwcraft_tally_server', { 0, tallyServerHeight(style) }, ImGuiChildFlags_Borders);

    imgui.Text('This sitting');
    imgui.SameLine();
    imgui.TextDisabled('-- skill and gil, anchored by the server');
    imgui.Separator();

    local srv = state.tally.server;

    if (srv == nil) then
        imgui.TextDisabled('Waiting for the server...');
    else
        -- Server-said age plus the wall-clock since it was said: the game
        -- numbers below never tick, but a sitting that stopped aging while
        -- the window sat open would read as a frozen panel.
        imgui.Text(string.format('Sitting: %s.', fmtAge(srv.age + math.max(0, math.floor(os.clock() - srv.receivedAt)))));

        if (#state.tally.moved == 0) then
            imgui.TextDisabled('No craft has moved this sitting.');
        else
            for _, row in ipairs(state.tally.moved) do
                local now = state.crafts[row.id];

                -- A negative gain is the specialization claw-back, and it
                -- renders as the loss it is.
                imgui.TextColored(row.gain >= 0 and theme.colors.ok or theme.colors.warn,
                    string.format('%s: %s -> %s  (%+.1f)',
                        CRAFT_NAMES[row.id] or ('craft ' .. row.id),
                        fmtLevel(row.from),
                        now ~= nil and fmtLevel(now.raw) or fmtLevel(row.from + row.gain),
                        row.gain / 10));
            end
        end

        if (srv.gild ~= 0) then
            imgui.Text(string.format('Gil: %i now, %+i this sitting.', srv.gil, srv.gild));
        else
            imgui.TextDisabled(string.format('Gil: %i now, unchanged this sitting.', srv.gil));
        end
    end

    imgui.EndChild();
end

local function tallyCountsPanel()
    local style = imgui.GetStyle();

    -- Everything down to the footer row; the made/used lists scroll inside.
    imgui.BeginChild('##dwcraft_tally_counts',
        { 0, -(imgui.GetFrameHeightWithSpacing() + style.ItemSpacing.y) }, ImGuiChildFlags_Borders);

    imgui.Text('Counted here');
    imgui.SameLine();
    imgui.TextDisabled('-- from your own synthesis results, as they arrive');
    imgui.Separator();

    local c = state.tally.count;

    if (c.attempts == 0) then
        imgui.TextDisabled('No synths counted yet -- results land here as you craft.');
    else
        imgui.Text(string.format('Attempts %i', c.attempts));
        imgui.SameLine();

        if (c.breaks > 0) then
            imgui.TextColored(theme.colors.warn, string.format('Breaks %i', c.breaks));
        else
            imgui.TextDisabled('Breaks 0');
        end

        imgui.SameLine();
        imgui.Text(string.format('NQ %i', c.nq));
        imgui.SameLine();

        if (c.hq > 0) then
            imgui.TextColored(theme.colors.ok, string.format('HQ %i', c.hq));
            imgui.SameLine();
            imgui.TextDisabled(string.format('(%i/%i/%i)', c.tiers[1], c.tiers[2], c.tiers[3]));
        else
            imgui.Text('HQ 0');
        end

        if (c.other > 0) then
            -- Desynths and handshake-less sessions land here: counted,
            -- never guessed into a tier.
            imgui.TextDisabled(string.format('+%i result(s) the catalog could not place as NQ or HQ.', c.other));
        end

        local made = sortedIds(c.made);

        if (#made > 0) then
            imgui.Text('Made:');

            for _, id in ipairs(made) do
                imgui.Text(string.format('  %ix %s', c.made[id], itemName(id)));
            end
        end

        local used = sortedIds(c.used);

        if (#used > 0) then
            imgui.TextDisabled('Consumed (crystals included):');

            for _, id in ipairs(used) do
                imgui.TextDisabled(string.format('  %ix %s', c.used[id], itemName(id)));
            end
        end
    end

    imgui.EndChild();
end

local function tallyPanel()
    tallyServerPanel();
    tallyCountsPanel();

    if (imgui.Button('Reset##dwcraft_tally')) then
        -- The click is the reset; the server's answer re-frames the top
        -- half. Both halves zero together or the tab tells two stories.
        zeroTally(true);
        issue('!dwc tally reset');
    end

    imgui.SameLine();
    imgui.TextDisabled('Resets on this button or on logout. Zoning keeps it.');
end

--[[
* The account matrix (Phase 5) -- rows are characters, columns are crafts.
*
* READ-ONLY, AND NOT ONLY BY CONVENTION: there is no button on this tab and no
* outgoing line but the `!dwc alts` that asks the question. The plan says
* "read-only forever", and a tab with nothing to click is the cheapest way to
* keep that true through later edits.
*
* EVERY NUMBER IS SERVER-SAID, INCLUDING THE ONES THAT LOOK LIKE OPINIONS.
* Whether a craft counts as specialized is `raw > freeCap` against the freeCap
* the SERVER put in the a| header -- not a constant here, because the free cap
* is a live setting and a copy of it would be exactly the drift the rules
* panel exists to prevent.
--]]

local function altsPanel()
    local style = imgui.GetStyle();

    imgui.BeginChild('##dwcraft_alts', { 0, 0 }, ImGuiChildFlags_Borders);

    imgui.Text('Your account');
    imgui.SameLine();
    imgui.TextDisabled('-- every character, every craft. Read-only.');
    imgui.Separator();

    if (state.alts.supported == false) then
        -- The server answered hello and said its build has no binding. Saying
        -- so is the whole point: an empty grid would read as "you have no
        -- alts", which is a different and false statement.
        imgui.TextColored(theme.colors.warn, 'This server build has no account matrix.');
        imgui.TextDisabled('The rest of the window is unaffected. Ask the server owner to rebuild.');
        imgui.EndChild();

        return;
    end

    askAlts();

    local head = state.alts.head;

    if (head == nil) then
        -- Deliberately NOT the generic "Waiting for the server..." three other
        -- panels use: this is the only tab whose answer is about the account
        -- rather than the character, and telling the two waits apart matters
        -- both to a player watching and to the harness asserting on them.
        imgui.TextDisabled('Reading your account...');
        imgui.EndChild();

        return;
    end

    local columns = altsColumnWidths();

    if (imgui.BeginTable('##dwcraft_alts_table', 2 + #CRAFT_ORDER,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingFixedFit),
            { -1, math.max(0, altsHeight(style) - panelChrome(style)) })) then
        imgui.TableSetupColumn('Character', ImGuiTableColumnFlags_WidthFixed, columns.name, 0);

        for _, id in ipairs(CRAFT_ORDER) do
            imgui.TableSetupColumn(ALTS_SHORT[id], ImGuiTableColumnFlags_WidthFixed, columns.craft, 0);
        end

        imgui.TableSetupColumn('Points', ImGuiTableColumnFlags_WidthFixed, columns.pts, 0);

        -- Proven in this build: dwbags ships on both calls.
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for idx = 1, head.count do
            local row = state.alts.rows[idx];

            if (row ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();

                if (hasBit(row.flags, 1)) then
                    imgui.TextColored(theme.colors.ok, row.name .. ' (you)');
                elseif (hasBit(row.flags, 2)) then
                    imgui.TextColored(theme.colors.hint, row.name);

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip('Logged in on another window right now.');
                    end
                else
                    imgui.Text(row.name);
                end

                for _, id in ipairs(CRAFT_ORDER) do
                    local raw = row.raw[id] or 0;

                    imgui.TableNextColumn();

                    if (raw == 0) then
                        -- A zero is a real answer -- "this character has not
                        -- started this craft" -- and the plan's verification
                        -- list asks for a row of zeros rather than a gap. The
                        -- dash IS the zero, dimmed so a started craft stands
                        -- out; the tooltip says which it is.
                        imgui.TextDisabled('-');

                        if (imgui.IsItemHovered()) then
                            imgui.SetTooltip(string.format('%s 0.0 -- not started', CRAFT_NAMES[id]));
                        end
                    else
                        -- Specialized against the SERVER's free cap; Fishing
                        -- is never specialized (it sits outside the budget).
                        if (id ~= 48 and raw > head.freeCap) then
                            imgui.TextColored(theme.colors.pin, fmtLevel(raw));
                        else
                            imgui.Text(fmtLevel(raw));
                        end

                        if (imgui.IsItemHovered()) then
                            imgui.SetTooltip(string.format('%s %s -- %s',
                                CRAFT_NAMES[id], fmtLevel(raw),
                                RANK_NAMES[row.rank[id] or 0] or ('rank ' .. tostring(row.rank[id]))));
                        end
                    end
                end

                imgui.TableNextColumn();
                imgui.Text(string.format('%d / %d', row.used, head.budget));
            end
        end

        imgui.EndTable();
    end

    imgui.TextDisabled(string.format('Specialization is per character: each one levels freely to %s and shares its own %d points.',
        fmtLevel(head.freeCap), head.budget));

    if (head.truncated > 0) then
        imgui.TextColored(theme.colors.warn,
            string.format('%d more character(s) on the account are not listed.', head.truncated));
    end

    imgui.EndChild();
end

local function renderWindow()
    if (state.status ~= '') then
        if (state.statusBad) then
            imgui.PushStyleColor(ImGuiCol_Text, theme.colors.err);
            imgui.TextWrapped(state.status);
            imgui.PopStyleColor();
        else
            imgui.TextDisabled(state.status);
        end
    end

    if (imgui.BeginTabBar('##dwcraft_tabs')) then
        if (imgui.BeginTabItem('Ledger##dwcraft')) then
            skillsPanel();
            ledgerPanel();
            rulesPanel();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Recipe Book##dwcraft')) then
            bookPanel();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Ladder##dwcraft')) then
            ladderPanel();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Tally##dwcraft')) then
            tallyPanel();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Alts##dwcraft')) then
            altsPanel();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    needSync();
    needHello();
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather
* than the addon: an error thrown inside d3d_present is raised sixty times a
* second and the addon host answers a long enough run by unloading the addon.
* Begin and End stay outside the pcall to keep ImGui's window stack balanced;
* the error is reported once and the window closes itself. Everything it does
* is still reachable as !craft commands, so closing it is a real fallback.
--]]
ashita.events.register('d3d_present', 'dwcraft_present', function ()
    -- Before the visibility check: a request issued a moment before the
    -- window was closed still has to reach the server.
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    imgui.SetNextWindowSize(defaultWindowSize(imgui.GetStyle(), columnWidths()), ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Crafting##dwcraft', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwcraft'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwcraft'):append(chat.message('Window closed. Everything it does also works as !craft commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1] = true;

    -- Reopening is a fresh start for error reporting too: `reported` only
    -- exists to stop one bad frame printing sixty lines a second.
    state.reported  = false;
    state.status    = 'Loading...';
    state.statusBad = false;

    refresh();
end

--[[
* Watch what the player sends.
*
* Bare `!craft` (and `!craft ui`) is intercepted and opens this window
* instead of printing the server's summary -- that line is blocked and never
* leaves the client. Every other `!craft` command passes through untouched:
* they are read-only prose and the window has nothing to learn from them.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped. Stamping
* the player's own line as a send makes the follow-up wait its interval.
--]]
ashita.events.register('packet_out', 'dwcraft_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!craft' or lower == '!craft ui' or lower == '!craft window' or lower == '!craft gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwc') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwcraft_command', function (e)
    local args = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwcraft' and first ~= '/craft') then
        return;
    end

    e.blocked = true;

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

ashita.events.register('load', 'dwcraft_load', function ()
    print(chat.header('dwcraft'):append(chat.message('!craft (or /craft) opens the crafting ledger. Everything it shows also works typed: !craft skills | points | rules | ladder | tally | alts.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new ledger -- and a synth mid-session moves the
-- numbers too, which is why reopening the window always re-asks.
ashita.events.register('packet_in', 'dwcraft_zonein', function (e)
    if (e.id == 0x000A) then
        -- The tally's counts belong to ONE character: 0x00A leads with the
        -- PosHead's UniqueNo, and a different one means a different person
        -- logged in under this addon instance -- their sitting is not ours
        -- to continue. Same character zoning matches and keeps everything
        -- (the 0x00B handler already ate the true logouts).
        local uid = e.data ~= nil and u32(e.data, 0x04) or 0;

        if (uid ~= 0) then
            if (state.tally.owner ~= nil and uid ~= state.tally.owner) then
                zeroTally(true);
            end

            state.tally.owner = uid;
        end

        state.crafts    = { };
        state.ledger    = nil;
        state.rules     = { };
        state.status    = 'Loading...';
        state.statusBad = false;

        -- The server half of the tally re-arrives with the sync this zone
        -- line triggers; holding the old frame for those two seconds would
        -- render a sitting age that stopped ticking. The counts stay -- the
        -- panel's "zoning keeps it" promise.
        state.tally.server = nil;
        state.tally.moved  = { };

        -- Bag truth moved with the zone line; results and the expansion are
        -- answers to a question about the old bags. The search text and the
        -- selection survive -- re-searching is one click, retyping is not.
        state.book.header = nil;
        state.book.rows   = { };
        state.book.shop   = nil;

        -- The ladder's shopping rows are counted against the bags too, so the
        -- plan goes with them. The craft and target boxes stay filled in.
        state.ladder.head     = nil;
        state.ladder.rungs    = { };
        state.ladder.selected = nil;
        state.ladder.asked    = nil;

        -- A 0x00A can be a zone line OR a different character logging in
        -- under this addon instance, and the account matrix is the one panel
        -- whose contents belong to an ACCOUNT rather than to the window. It
        -- is dropped either way: re-asking costs one line and rendering
        -- somebody else's roster for two seconds is not a trade worth making.
        -- `supported` is a fact about the SERVER BUILD, not about the
        -- character, so it survives -- it re-arrives with hello regardless.
        state.alts.head = nil;
        state.alts.rows = { };

        refresh();
    end
end);
