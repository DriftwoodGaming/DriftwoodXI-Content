--[[
* DriftwoodXI -- dwport
*
* All of Vana'diel you have earned, in one window: a tab per travel system --
* home points, survival guides, outposts, the teleport spells, Unity warps,
* Voidwatch rifts, the Aht Urhgan Runic Portals -- every destination you have
* already unlocked one click
* away, every one you have not sitting greyed beside it with the reason. A
* Home button for the free !home warp, a find box over every tab (with each
* tab's hit count on its own label), a switch that hides what you have not
* earned yet, favorites and a recent list. Each tab's hover card says how much
* of it you have earned, and the window comes back on the tab you left it on.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no truth of its own: the shipped catalog.lua is names and ids,
* and everything that varies per character -- the unlock masks, spell
* readiness, the purse -- arrives as _DWPDATA records answering `!dwp sync`
* (documentation/dwp_protocol.md). Every click issues a line a player could
* type (`!dwp go hp 12`), and the server re-checks the unlock, the travel
* gates and the fee at execution time whichever way the command arrived. A
* bug in this window cannot move a body anywhere `!port` would refuse.
*
* TYPING `!port` ON ITS OWN OPENS THIS WINDOW. The line is intercepted
* before it leaves the client; every other !port command passes through.
* `/port` does the same, and `/port sp` opens it on the Teleport tab.
*
* TURN IT OFF AND NOTHING IS LOST. `!port list hp`, `!port go sg 42`,
* `!port home` all work typed. This is friendlier; it is not required.
--]]

addon.name    = 'dwport';
addon.author  = 'DriftwoodXI';
addon.version = '1.6.1';
addon.desc    = 'Travel window for DriftwoodXI -- every teleport you have unlocked, one click away.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local theme    = require('dwtheme');
local echo     = require('dwecho');
local catalog  = require('catalog');
local settings = require('settings');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. Eight
-- other addons own eight other names; this addon must never contend for any
-- of them, which is why !dwp exists at all.
local DATA_SENDER = '_DWPDATA';

-- Bumped only for a breaking change to the record layout.
local PROTOCOL = 1;

local TAB_ORDER = { 'hp', 'sg', 'op', 'sp', 'un', 'vw', 'rp' };

local TAB_LABEL =
{
    hp = 'Home points',
    sg = 'Survival guides',
    op = 'Outposts',
    sp = 'Teleport',
    un = 'Unity',
    vw = 'Voidwatch',
    rp = 'Runic portals',
};

-- The mask block, in its cleared state. Written once because three places
-- reset it -- the sync envelope, the zone-in handler and the initial state --
-- and a tab added to one of the three and not the others is a tab whose rows
-- all read locked until the next sync lands.
--
-- un/vw carry a SECOND mask each: which dark rows are dark for the story
-- reason rather than the expansion one. See the l| record.
local function EMPTY_MASKS()
    return {
        hp = { 0, 0, 0, 0 },
        sg = { 0, 0, 0, 0 },
        op = 0,
        un = { 0, 0 },
        vw = { 0, 0, 0 },
        unStory = { 0, 0 },
        vwStory = { 0, 0, 0 },
    };
end

-- catalog rows indexed by id, per tab, so records and clicks join in O(1).
local byId = { hp = {}, sg = {}, op = {}, sp = {}, un = {}, vw = {}, rp = {} };

-- The one ImGui id per tab's table, built once rather than concatenated on
-- every frame of every tab.
local tableIdOf = { };

for _, tab in ipairs(TAB_ORDER) do
    tableIdOf[tab] = '##dwport_' .. tab;

    for _, entry in ipairs(catalog[tab]) do
        byId[tab][entry.id] = entry;
    end
end

-- zone id -> home point group, for the fee preview's "free within your own
-- city" arm. Derived from the catalog so it cannot drift from it.
local zoneGroup = {};

for _, entry in ipairs(catalog.hp) do
    if entry.group ~= 0 then
        zoneGroup[entry.zone] = entry.group;
    end
end

--[[
* Persisted presentation state (plan decision P6): starred destinations and
* the "only what I can use" switch, per character, through Ashita's settings
* library. Guarded throughout -- losing favorites must never cost the window.
*
* A key added here must leave the old file readable: settings.load merges the
* defaults over whatever is on disk, so a config written by 1.2.0 comes back
* with `unlockedOnly` false rather than nil, and a corrupt one never gets past
* the pcall above the defaults.
--]]
local defaultConfig = T{
    favorites    = T{ },     -- ['hp:12'] = true

    -- 1.3.0. Off by default, and deliberately: a window that opens showing
    -- only what you already have can never tell you what you are missing,
    -- which is half of what this addon is for. The switch is for the
    -- character with forty crystals and 121 rows to scroll past.
    unlockedOnly = false,

    -- 1.3.0. Which tab this character was last looking at. A player who lives
    -- in the Teleport tab reopened onto Home points every single time; the tab
    -- strip is the one piece of this window's state ImGui does NOT keep for
    -- itself (a tab bar's selection is not written to imgui.ini).
    lastTab      = 'hp',
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

--[[
* The shape check the pcall above cannot make (1.3.0).
*
* settings.load merges the defaults over what is on disk, and what is on disk
* is a text file a player can open: a `favorites` that comes back a NUMBER
* survives that merge, and the first isFavorite of the first frame then
* indexes it -- a Lua error inside the render pcall, so the window closes on
* open and the file that did it is still there the next session. A key of the
* wrong type is treated as a key that is not there, which is what the defaults
* are for. Called again from the settings callback, because a character change
* re-reads a different file with the same hazard in it.
--]]
local function settleConfig()
    if (type(config) ~= 'table') then
        config = defaultConfig;
    end

    if (type(config.favorites) ~= 'table') then
        config.favorites = T{ };
    end

    if (TAB_LABEL[config.lastTab] == nil) then
        config.lastTab = 'hp';
    end
end

settleConfig();

--[[
* The presentation revision. The row list is filtered and sorted once and then
* re-used until something it is built from moves, and this counter is that
* "something": a star, the filter switch, the text in the find box, or a
* settings file reloaded under us. See the view cache in rowsFor.
--]]
local presentRev = 0;

-- ImGui's Checkbox writes through a holder table and the persisted value is a
-- plain boolean, so the two are synced at each of the three places either can
-- change: this load, the settings callback, and the click.
local unlockedOnly = T{ config.unlockedOnly == true };

local function favKey(tab, id)
    return string.format('%s:%d', tab, id);
end

local function toggleFavorite(key)
    if (config.favorites == nil) then
        config.favorites = T{ };
    end

    config.favorites[key] = (not config.favorites[key]) or nil;

    presentRev = presentRev + 1;

    pcall(settings.save);
end

-- The one place the switch moves. Writes BOTH the holder ImGui reads and the
-- key the settings file keeps, so the two cannot drift apart no matter which
-- of them the caller was looking at.
local function setUnlockedOnly(value)
    value = (value == true);

    unlockedOnly[1]     = value;
    config.unlockedOnly = value;
    presentRev          = presentRev + 1;

    pcall(settings.save);
end

--[[
* Per-row constants, built once at load (1.3.0). Every one of these used to be
* computed inside the render loop, for every row, on every frame: the
* lowercased search text, the two ImGui id suffixes, the favourites key and
* the outpost's fee label. Not one of them can change while the client runs --
* they are the shipped catalog -- and 121 home points at 60 fps is a great
* many identical strings built and thrown away.
*
* The search blob joins name, destination and key item with a NEWLINE, which a
* player cannot type into the find box: a needle can therefore never match
* across the seam between two fields ("holla la" must not find Teleport-Holla
* -> La Theine Plateau).
*
* The SECOND blob is the same text with everything that is not a letter or a
* digit taken out, and it exists because half the destinations in this game are
* spelled with punctuation nobody types: "Ru'Lude Gardens #1", "Southern San
* d'Oria #3". The typed tier has normalised names this way since it shipped
* (port_core's norm(), which is what makes `!port go hp UpperJeuno2` work), and
* the window's own find box was the one place that still demanded the
* apostrophe. The newline stays in, so the seam above holds for this blob too.
--]]
local searchBlob = { };
local searchTight = { };
local favKeyOf   = { };
local favOnOf    = { };
local favOffOf   = { };
local goIdOf     = { };
local goVerbOf   = { };
local recentLabelOf = { };
local opFeeOf    = { };
local spDestOf   = { };

--[[
* The BUTTON LABELS are built here too, and that is the point of this pass's
* second look (1.3.0). An ImGui button label carries its own id after the
* `##`, so every button in this window was a string concatenation -- and the
* home point tab draws 121 star buttons and up to 121 Go buttons, sixty times
* a second, for labels that differ only by a character the catalog fixed
* years ago. The star has exactly two spellings, so both are built once; the
* Go button's price is not knowable here and is memoised at the call site
* instead (goLabel).
--]]
for _, tab in ipairs(TAB_ORDER) do
    for _, entry in ipairs(catalog[tab]) do
        local pieces = { entry.name };

        if (type(entry.dest) == 'string') then
            pieces[#pieces + 1] = entry.dest;
        end

        if (type(entry.ki) == 'string') then
            pieces[#pieces + 1] = entry.ki;
        end

        local favId = string.format('##fav_%s_%d', tab, entry.id);

        searchBlob[entry]  = table.concat(pieces, '\n'):lower();
        searchTight[entry] = (searchBlob[entry]:gsub('[^%a%d\n]', ''));
        favKeyOf[entry]   = favKey(tab, entry.id);
        favOnOf[entry]    = '*' .. favId;
        favOffOf[entry]   = '-' .. favId;
        goIdOf[entry]     = string.format('##go_%s_%d', tab, entry.id);
        -- What the action button says before its price. Five tabs move a body
        -- and read "Go  100g"; the Teleport tab casts a spell, and 'Go  ' in
        -- front of "Cast" put two verbs on one button. Per ENTRY rather than
        -- per tab so the label memo below never has to look it up.
        goVerbOf[entry]   = (tab == 'sp') and '' or 'Go  ';
        -- Keyed by destination, not by position in the list: the recent list
        -- reorders on every journey, and an ImGui id that moved with it handed
        -- one button's click state to whichever destination inherited its slot.
        recentLabelOf[entry] = string.format('%s##recent_%s_%d', entry.name, tab, entry.id);

        if (tab == 'op') then
            opFeeOf[entry] = string.format('%dg', entry.fee);
        elseif (tab == 'sp') then
            -- The book requirement a dark spell row carries beside its name.
            -- Every term is a catalog constant, so the sentence is one string
            -- for the life of the client rather than one per frame.
            spDestOf[entry] = string.format('-> %s (WHM %d, %d MP)', entry.dest, entry.lvl, entry.mp);
        end
    end
end

local function isFavorite(entry)
    local favorites = config.favorites;

    return favorites ~= nil and favorites[favKeyOf[entry]] == true;
end

--[[
* The two sentences an outstanding ask puts on the status line. Named because
* five places write or test them -- the initial state, the zone line, the
* window opening, the Refresh button, and the two sets beside `requested` that
* decide what an answer may take back down -- and a spelling that drifted at
* one of them would be a line nothing could ever clear again.
--]]
local ASK_FIRST = 'Loading...';
local ASK_AGAIN = 'Refreshing...';

local state = T{
    open      = T{ false },

    -- The tab an open is asking the tab strip to select, set by openWindow
    -- from the persisted lastTab and cleared by the tab that takes it. nil
    -- every other frame: ImGuiTabItemFlags_SetSelected left standing fights
    -- every click the player then makes (dwgmpanel's note, same shape).
    wantTab   = nil,

    -- The truth as of the last sync. masks are the u| words; spells is keyed
    -- by spell id from s| records. `synced` says whether any of it has
    -- arrived: until it has, EVERY mask bit is zero, so every row is dark and
    -- lockHint answers "waiting for the first sync" rather than making a
    -- confident claim about a character the server has not described yet.
    masks     = EMPTY_MASKS(),
    spells    = { },     -- PLAIN table keyed by spell id (the T{} sugar trap)

    -- The r| records, keyed by Runic Portal id. A PLAIN table for the reason
    -- spells is one, and empty until a server that sends them has: an id with
    -- no record renders as waiting rather than as a confident "not attuned".
    runic     = { },

    -- The t| records, keyed by region (2026-09-15b): what each outpost run
    -- costs after the owning nation's Mayor's lever. A PLAIN table for the
    -- reason `spells` is one, and SPARSE on purpose -- a region with no record
    -- (an older server, or a row withdrawn from the outpost catalog) falls back
    -- to the catalog's flat fee rather than reading as free. `opFeeRev` is what
    -- the per-frame fold keys on, because eighteen numbers cannot be compared
    -- in one `~=`.
    opFees    = { },
    opFeeRev  = 0,

    -- The w| record (D13): which ONE destination a live Unleashed rally is
    -- waiving the fare to, as { tab = 'hp'|'op', id = <catalog id> }, or nil
    -- when nothing stands. `waivedRev` is what the outpost fold keys on
    -- alongside opFeeRev -- the label and the hover on that tab change with
    -- either, and neither one alone is enough to redraw them.
    waived    = nil,
    waivedRev = 0,
    gil       = -1,

    -- Imperial standing, the Runic Portals' fare (g|'s second field, 2026-09-15).
    -- -1 is "no reading", exactly as it is for gil, and then nothing is greyed
    -- for it at all -- an old server that sends one field must never grey a
    -- button it would have honoured.
    standing  = -1,

    -- When that purse reading was taken, in WALL seconds (os.time). It is the
    -- only wall clock in this file and it is deliberate: every other clock
    -- here is os.clock (process CPU seconds), which is the right thing for a
    -- send throttle and the wrong thing for a sentence that tells a person
    -- their purse was read four minutes ago. The two are never compared.
    --
    -- Written in the same breath as the gil it dates (the g| record is the one
    -- writer of either), which is what makes `gil >= 0` a sufficient guard for
    -- the reading: a purse with no date cannot exist.
    gilAt     = 0,
    -- The f| record: this PLAYER's fee basis (hp = one fee tier's price, sg =
    -- the guide charge), so the buttons quote the number the charge will be.
    -- nil until a server that sends it has -- the fallbacks are the
    -- undiscounted book prices this window always showed.
    fees      = nil,
    synced    = false,

    -- The server's catalog version from y|; higher than ours = say so.
    serverCatalog = nil,

    -- Bumped by every record that changes what a row says about itself: the
    -- unlock masks, the story masks and the spell readiness. The view cache
    -- keys on it, so a sync rebuilds the row lists and a frame that changed
    -- nothing rebuilds nothing.
    modelRev  = 0,

    -- Latched by a d| whose protocol is not ours, cleared by the first d|
    -- that agrees. While it is set no record may write the status line: the
    -- "Update dwport" banner is the only accurate thing on screen, and a
    -- stranger's m|/e| sentences would paint straight over it -- the same
    -- hole the answer clock had, closed in the same place.
    protoBad  = false,

    -- True once a d| has arrived this session. Auto-syncs (zone-in) stay off
    -- until then: an unknown !command falls through to /say, and an automatic
    -- line against a dead verb is the player saying it in public.
    serverSpoke = false,

    inbound   = nil,

    -- When that envelope opened, in frame clock seconds. See ageEnvelope: an
    -- envelope whose z| never arrives has to be closed by somebody.
    inboundAt = 0,

    --[[
    * The sync envelope's answer, built beside the live one and committed whole
    * at z| (1.3.0). nil except while a sync is open.
    *
    * The reset used to run at d|, on the live state, and that is wrong for a
    * reason this suite keeps rediscovering: the records that refill it are
    * separate 0x017 packets, and the client is free to deliver them over more
    * than one frame. Every frame in that gap drew all 121 rows dark with
    * `synced` still true -- so each of them claimed "Not attuned" about a
    * crystal the player has had for years -- and with the unlocked-only switch
    * on it emptied the tab outright, which clamps the table's scroll back to
    * the top of a list the player was half way down. dwbags' SECTIONS shape.
    *
    * A `go` answers with a fresh mask for the ONE tab it touched. That is a
    * merge into what is already on screen with no reset to hide behind, so it
    * writes live and this table stays nil for it.
    --]]
    staging   = nil,

    -- `go`s issued and not yet answered, oldest first, each promoted to the
    -- recent list when its m| lands. A queue, not a slot: two Go clicks
    -- inside one send interval both go out, and a single slot recorded the
    -- SECOND destination against the FIRST answer (and then nothing at all
    -- for the second). An entry with no `tab` is the Home button's -- it
    -- keeps the answers aligned without ever reaching the recent list, since
    -- Home is already a button of its own two rows above. Every entry carries
    -- the clock it was queued at; see ageGoQueue.
    goQueue   = T{ },
    recents   = T{ },    -- newest first, at most 5, session-only

    search    = T{ '' },

    status    = ASK_FIRST,
    statusBad = false,
    reported  = false,
};

--[[
* Registered HERE, below `state`, and that placement is the whole point: this
* callback clears the recent list, which lives in `state`, and a closure
* written above it would have captured a global that is nil -- an error raised
* inside Ashita's own settings machinery rather than inside this addon.
*
* Ashita re-reads this file when the CHARACTER changes, which is also the
* moment the recent list stopped being about the person at the keyboard: five
* one-click journeys to somebody else's crystals, offered to a character who
* may have attuned none of them. They are session-only either way, so dropping
* them costs nothing and keeping them says something untrue.
--]]
pcall(settings.register, 'settings', 'dwport_settings_update', function (s)
    if (s ~= nil) then
        config          = s;

        -- The same shape check the load does, for the same reason: this is a
        -- different character's file, opened by the same hands.
        settleConfig();

        unlockedOnly[1] = (config.unlockedOnly == true);
        presentRev      = presentRev + 1;
        state.recents   = T{ };
    end
end);

--[[
* Send queue: one command per 1.2s with duplicate collapse, the client's
* chat rate limit being what it is. Same shape as dwjobs.
*
* QUEUE_MAX is the ceiling every extend-on-activity list in this suite owes
* (1.3.0): one click is one line, a player leaning on the Go buttons out-runs
* a 1.2s throttle by a wide margin, and eight lines is 9.6 seconds of backlog.
* Nothing a person does deliberately reaches eight.
*
* That arithmetic used to be the whole argument for "an entry can never age out
* as ignored while its line is still waiting to be sent", and it was wrong: the
* packet_out handler at the foot of this file pushes the throttle forward on
* every line the PLAYER types, so a backlog of eight has no upper bound in
* seconds at all. stillQueued below is the guarantee now; the ceiling is just a
* ceiling.
--]]
local SEND_INTERVAL = 1.2;
local QUEUE_MAX     = 8;

local queue    = T{ };
local lastSend = 0;

--[[
* One clock reading per frame, stamped by the render pass before anything
* reads it. The queue pump, the sync answer clock and the travel answer clock
* each used to call os.clock() for themselves -- three readings of one instant
* that then disagreed by a hair, on a path that runs sixty times a second.
--]]
local frameNow = 0;

--[[
* Is this exact line still waiting its turn in the send queue (1.3.0)?
*
* Two callers, and the second is why this is a function rather than the loop
* issue() used to carry inline. NEITHER ANSWER CLOCK MAY AGE AGAINST A LINE
* THAT HAS NOT LEFT THE CLIENT: nothing has ignored it yet, so a timeout is a
* lie about the server. The queue is normally 1.2 seconds deep, but the
* throttle is stamped by every chat line the player types (the packet_out
* handler at the foot of this file), so a party talking holds it shut for as
* long as the talking lasts -- comfortably past the thirty seconds the travel
* clock allows and the five the sync clock does. This is the same false "The
* server did not answer." that the canSend guard prevents while zoning,
* arriving through a third door.
--]]
local function stillQueued(command)
    for _, waiting in ipairs(queue) do
        if (waiting == command) then
            return true;
        end
    end

    return false;
end

--[[
* Returns TWO answers, because the two callers ask different questions.
*
* `queued` is whether a NEW line went into the queue. goQueue pairs one entry
* with one ANSWER, so a click collapsed into a line already waiting must not
* add a second entry: two fast clicks on one Go used to send once and enqueue
* twice, and the spare was then handed to the NEXT journey's answer -- the
* exact mis-pairing goQueue was built to prevent.
*
* `answering` is whether an answer is coming at all, which is a different
* thing: a collapsed line is still on its way and will still be answered, so
* an answer clock may start against it, while a line the ceiling refused will
* never be answered and must not start one. Timing a request nobody sent is
* the false "The server did not answer." that the canSend guard in needSync
* exists to prevent, and it has a second door.
--]]
local function issue(command)
    if (stillQueued(command)) then
        return false, true;
    end

    if (#queue >= QUEUE_MAX) then
        return false, false;
    end

    queue:append(command);

    return true, true;
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (frameNow - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = frameNow;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking for `sync`: ask once, retry once on a 5s silence, then
* stop and say so -- a retry that never terminates is a command loop.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

--[[
* The two sentences a cut-short answer leaves behind. ageEnvelope writes them
* and the ANSWERABLE set below has to recognise them, and the two are three
* screens apart -- which is exactly the distance a spelling drifts over.
--]]
local CUT_RETRY = 'That answer was cut short. Asking again.';
local CUT_STUCK = 'That answer was cut short. Press Refresh to ask again.';

-- The line an outstanding ask puts up while it waits. Only these two may be
-- replaced by "the server did not answer": a refusal or a travel note that
-- landed in the meantime came from the server and has already said something
-- truer, and the two above are already about a failure.
local ASKING =
{
    [ASK_FIRST] = true,
    [ASK_AGAIN] = true,
};

-- ...and everything an ANSWER is entitled to take back down, which is the
-- waiting line plus whatever a previous failure to get one left in its place.
local ANSWERABLE =
{
    [ASK_FIRST] = true,
    [ASK_AGAIN] = true,
    [CUT_RETRY] = true,
    [CUT_STUCK] = true,
};

local function refresh()
    requested = {};
end

local function needSync()
    local asked = requested['sync'];

    if (asked ~= nil) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout, and a false "The server did not
        -- answer." (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        -- Held by the send throttle, not ignored (see stillQueued). Hold the
        -- clock at the present instant so the five seconds are measured from
        -- the moment the line actually goes out rather than from the click.
        if (stillQueued('!dwp sync')) then
            asked.at = frameNow;

            return;
        end

        if (asked.answered or asked.tries >= ANSWER_TRIES or (frameNow - asked.at) < ANSWER_TIMEOUT) then
            -- One-shot (dwquest's gaveUp latch): this runs inside the render
            -- loop, and re-asserted every frame it overwrote every other
            -- status the window tried to show -- including the refusal that
            -- would explain what is actually wrong.
            if (not asked.answered and not asked.gaveUp
                    and asked.tries >= ANSWER_TRIES and (frameNow - asked.at) >= ANSWER_TIMEOUT) then
                asked.gaveUp = true;

                if (not state.serverSpoke) then
                    state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
                    state.statusBad = true;
                elseif (ASKING[state.status]) then
                    -- A server that HAS answered this session and then went
                    -- quiet is a different sentence: the diagnosis above would
                    -- send a player off to check an install that is
                    -- demonstrably fine (1.3.0). And only the line THIS ask put
                    -- there is replaced -- a refusal or a travel note that
                    -- landed in the meantime has already said something truer,
                    -- which is the rule ageGoQueue keeps two screens down.
                    state.status    = 'The server did not answer. Press Refresh to try again.';
                    state.statusBad = true;
                end
            end

            return;
        end

        -- The clock only starts when an answer is actually coming. A line the
        -- send ceiling refused will never be answered, and aging a request
        -- nobody sent is the false timeout the canSend guard above exists to
        -- prevent, arriving through the other door.
        local _, answering = issue('!dwp sync');

        if (not answering) then
            return;
        end

        asked.at    = frameNow;
        asked.tries = asked.tries + 1;

        return;
    end

    local _, answering = issue('!dwp sync');

    if (not answering) then
        return;
    end

    requested['sync'] = { at = frameNow, answered = false, tries = 1 };
end

-- The one place a sync ask is closed from the wire. Called by the d| that
-- opens a sync envelope AND by an e| raised while answering one -- a refusal
-- IS an answer, and leaving the ask open re-sent the same doomed line five
-- seconds later and printed the same refusal a second time.
local function answeredSync()
    local asked = requested['sync'];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

--[[
* Record parsing.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function word(hexText)
    return tonumber(hexText or '', 16) or 0;
end

--[[
* A wire field that must be a whole number, or the fallback (1.3.0).
*
* tonumber() will happily hand back 2.5, inf or nan from a field that should
* have been an integer, and every one of these numbers goes on to a
* string.format '%d' or an arithmetic comparison: LuaJIT truncates 2.5 in
* silence and prints nan as a 19-digit number, a stricter Lua raises, and
* either way the window says something that is not true. The records arrive on
* the 0x017 chat stream, which other addons are free to rewrite before this
* one sees it, so the parse is where the shape is settled rather than the
* render. The range bound is what catches inf: math.floor(inf) IS inf, so the
* integrality test alone lets it straight through.
--]]
local function whole(text, fallback)
    local value = tonumber(text);

    if (value == nil or value ~= value
            or value >= 2147483647 or value <= -2147483647
            or value ~= math.floor(value)) then
        return fallback;
    end

    return value;
end

--[[
* 1234567 -> 1,234,567 (1.3.0), the same walk dwah and dwwarehouse have
* carried since they shipped. The purse this window quotes every price against
* runs to nine digits, and nine digits in a row is a misread waiting to happen.
*
* THE BUTTON PRICES DELIBERATELY STAY UNGROUPED. Every fee in the shipped
* catalog is three or four digits, they sit in a column measured from the
* widest of them, and a comma inside "Go  1000g" buys the reader nothing while
* costing the column a glyph.
*
* Floored first: every number that reaches here has already been through
* whole(), but a home point price is a PRODUCT of two of them, and the
* grouping loop wants digits rather than a decimal point.
--]]
local function grouped(amount)
    local text = tostring(math.floor(tonumber(amount) or 0));
    local out  = '';

    while (#text > 3) do
        out  = ',' .. text:sub(-3) .. out;
        text = text:sub(1, -4);
    end

    return text .. out;
end

local function rememberRecent(go)
    -- The Home button's queue entry carries no destination: it keeps the
    -- answers aligned and never reaches the recent list, because Home is
    -- already a button of its own two rows above.
    if (go == nil or go.tab == nil) then
        return;
    end

    for at = #state.recents, 1, -1 do
        if (state.recents[at].tab == go.tab and state.recents[at].id == go.id) then
            table.remove(state.recents, at);
        end
    end

    table.insert(state.recents, 1, go);

    while (#state.recents > 5) do
        table.remove(state.recents);
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = whole(parts[2], -1);

        if (version ~= PROTOCOL) then
            -- The latch, 1.3.0. `state.inbound = nil` already stopped the
            -- ordinary records of a foreign envelope, but m|/e| are handled
            -- ABOVE that guard (they are legal anywhere), so the stranger's
            -- own sentences went on painting over the one accurate line on
            -- screen. Cleared by the first d| that agrees with us, which is
            -- how a server that gets updated under a running client recovers
            -- without a reload.
            state.protoBad  = true;
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwport.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;
            state.inboundAt = 0;
            state.staging   = nil;

            -- A d| envelope IS the answer, whatever version it announced.
            -- Returning with the ask still outstanding let needSync re-send it
            -- and then replace the one accurate diagnosis on screen ("Update
            -- dwport") with "The server did not answer. Is this DriftwoodXI?"
            -- -- about a server that had just answered twice. `serverSpoke`
            -- deliberately stays false: this server does not speak a dwport
            -- this addon understands, and the zone-in auto-sync should not
            -- start. dwfame closed the same hole on 2026-08-15.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        -- The banner stops being true the moment a server answers in a
        -- protocol this addon reads, and nothing else could ever clear it: a
        -- sync answers with records and no m|, so an updated server left
        -- "Update dwport" sitting over a window that was working perfectly.
        if (state.protoBad) then
            state.protoBad  = false;
            state.status    = '';
            state.statusBad = false;
        end

        state.serverSpoke = true;
        state.inbound     = parts[3];
        state.inboundAt   = frameNow;

        -- Any d| ends whatever staging was open. A sync envelope cut short --
        -- a dropped 0x017, a server restarted between two of its records --
        -- must not leave a half-built table for the NEXT envelope's records to
        -- fall into, where nothing would ever commit them.
        state.staging     = nil;

        -- A sync replaces its whole section, and it is STAGED rather than
        -- wiped in place: see state.staging. The window goes on drawing the
        -- previous answer -- the last thing about this character that was
        -- true -- until z| swaps the whole picture at once.
        if (state.inbound == 'sync') then
            state.staging = { masks = EMPTY_MASKS(), spells = { }, runic = { } };

            answeredSync();
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        -- A server speaking a protocol this addon does not understand is
        -- allowed to say nothing at all here: "Update dwport" is the whole
        -- diagnosis, and its own status sentences are about records we cannot
        -- read anyway.
        if (state.protoBad) then
            return;
        end

        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwport'):append(chat.error(state.status)));
        end

        -- goQueue pairs one entry with one answer BY POSITION, so only the
        -- envelope that answers a journey may consume one. An e| raised inside
        -- a sync -- or inside the status envelope dwp.lua hand-writes when the
        -- travel module is not loaded at all -- used to eat the entry
        -- belonging to a go still in flight, and every answer after it landed
        -- on the wrong destination.
        if (state.inbound == 'go' or state.inbound == 'home') then
            local go = table.remove(state.goQueue, 1);

            if (kind == 'm') then
                rememberRecent(go);
            end
        elseif (kind == 'e' and (state.inbound == 'sync' or state.inbound == 'status')) then
            -- A refused sync has no answer inside it. Drop the half-built
            -- staging rather than committing part of one over the last good
            -- picture: the previous answer is stale, a fragment is wrong.
            state.staging = nil;

            answeredSync();
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        -- The commit. Everything the envelope carried lands in one assignment,
        -- so no frame is ever drawn against half an answer -- and a sync whose
        -- staging was dropped (a refusal inside it) commits nothing at all
        -- rather than blanking a picture it never replaced.
        if (state.inbound == 'sync' and state.staging ~= nil) then
            state.masks    = state.staging.masks;
            state.spells   = state.staging.spells;
            state.runic    = state.staging.runic;
            state.synced   = true;
            state.modelRev = state.modelRev + 1;

            -- Only the sentences an ask put there: a refusal or a note from a
            -- journey that landed mid-sync has said something truer.
            if (ANSWERABLE[state.status]) then
                state.status = '';
            end
        end

        state.staging   = nil;
        state.inbound   = nil;
        state.inboundAt = 0;

        return;
    end

    if (kind == 'y') then
        state.serverCatalog = whole(parts[2], nil);

        return;
    end

    if (kind == 'u') then
        -- Into the sync's staging table while one is open, straight onto the
        -- live state otherwise (a `go`'s one-tab refresh). The revision only
        -- moves for a live write: a staged one changes nothing on screen until
        -- z| commits it, and bumping it here would rebuild every view for a
        -- picture that had not moved.
        local into = state.staging or state;
        local set  = parts[2];

        if (set == 'hp' or set == 'sg') then
            into.masks[set] = { word(parts[3]), word(parts[4]), word(parts[5]), word(parts[6]) };
        elseif (set == 'op') then
            into.masks.op = word(parts[3]);
        elseif (set == 'un') then
            into.masks.un = { word(parts[3]), word(parts[4]) };
        elseif (set == 'vw') then
            into.masks.vw = { word(parts[3]), word(parts[4]), word(parts[5]) };
        else
            return;
        end

        if (state.staging == nil) then
            state.modelRev = state.modelRev + 1;
        end

        return;
    end

    -- l| -- which DARK rows are dark for the story reason rather than the
    -- expansion one (1.2.0). Additive, protocol unchanged: an older addon
    -- never sees it, and an older server never sends it, in which case every
    -- locked Unity/Voidwatch row falls back to naming its expansion -- wrong
    -- for the handful that are also story-gated, and never wrong in a
    -- direction that offers a warp.
    --
    -- The SERVER decides which reason applies because only it reads the
    -- ENABLE_ flags; this side just picks a string. See port_core's
    -- warpStoryMask.
    if (kind == 'l') then
        local into = state.staging or state;
        local set  = parts[2];

        if (set == 'un') then
            into.masks.unStory = { word(parts[3]), word(parts[4]) };
        elseif (set == 'vw') then
            into.masks.vwStory = { word(parts[3]), word(parts[4]), word(parts[5]) };
        else
            return;
        end

        if (state.staging == nil) then
            state.modelRev = state.modelRev + 1;
        end

        return;
    end

    if (kind == 's') then
        local spellId = whole(parts[2], nil);

        -- No id, no join key: the record would land under spell 0, where no
        -- catalog row will ever look for it, and the tab would keep showing
        -- "Waiting for the first sync." for the spell it was about.
        if (spellId == nil) then
            return;
        end

        local entry = byId.sp[spellId];

        -- A spell this catalog does not carry has no row to be about, and no
        -- reader: every lookup of state.spells is keyed by a catalog entry's
        -- own id. Keeping it would be an unbounded table fed by the wire, plus
        -- a modelRev bump -- a rebuild of all six row lists -- for a record
        -- nothing can draw. A newer server's tenth teleport spell lands here,
        -- and the y| banner is already telling the player to update (1.3.0).
        if (entry == nil) then
            return;
        end

        local live = {
            ki         = (parts[3] == '1'),
            casterKind = whole(parts[4], 0),
            -- '-' is what the server sends when nobody qualifies. A field
            -- missing outright would otherwise reach a '%s' as nil, and one
            -- left EMPTY -- which is what a chat line rewritten by an addon
            -- loaded before this one can arrive as -- would render as a hole
            -- in the middle of the sentence ("cast by  (100 MP)").
            casterName = (parts[5] ~= nil and parts[5] ~= '') and parts[5] or '-',
            mp         = whole(parts[6], -1),
            mpCost     = whole(parts[7], 0),
            ready      = (parts[8] == '1'),
        };

        -- The line a ready spell shows beside its name, built HERE rather than
        -- in the render: it changes when this record changes, which is once a
        -- sync, not sixty times a second.
        if (live.casterKind == 2) then
            live.line = string.format('-> %s, cast by %s (%d MP)', entry.dest, live.casterName, live.mpCost);
        else
            live.line = string.format('-> %s (%d MP)', entry.dest, live.mpCost);
        end

        local into = state.staging or state;

        into.spells[spellId] = live;

        if (state.staging == nil) then
            state.modelRev = state.modelRev + 1;
        end

        return;
    end

    -- r| -- one Runic Portal's three gates and the verdict (2026-09-15).
    -- The s| arrangement rather than a mask, and for the s| reason: this tab
    -- has three quite different ways to be dark -- the expansion, the Boarding
    -- Permit, the staging point you have never stood at -- and a mask can only
    -- say "dark". `ready` is the server's own refusal verdict; the other three
    -- flags exist to pick the sentence.
    if (kind == 'r') then
        local id = whole(parts[2], nil);

        if (id == nil) then
            return;
        end

        local entry = byId.rp[id];

        -- A portal this catalog does not carry has no row to be about, and no
        -- reader -- the s| rule, and the y| banner is already saying the
        -- catalog is behind.
        if (entry == nil) then
            return;
        end

        local into = state.staging or state;

        into.runic[id] = {
            open    = (parts[3] == '1'),
            story   = (parts[4] == '1'),
            attuned = (parts[5] == '1'),
            ready   = (parts[6] == '1'),
        };

        if (state.staging == nil) then
            state.modelRev = state.modelRev + 1;
        end

        return;
    end

    if (kind == 'g') then
        state.gil   = whole(parts[2], -1);
        state.gilAt = os.time();

        -- Imperial standing (2026-09-15), the Runic Portals' fare. ADDITIVE:
        -- a server that has never heard of this field sends two terms and the
        -- fallback is -1, which is "no reading" and greys nothing -- the same
        -- direction the gil courtesy already fails in.
        state.standing = whole(parts[3], -1);

        return;
    end

    -- f| -- the player's own fee basis (2026-08-19). Everyone on this server
    -- is granted Rhapsody in White, so the old catalog-quoted 500g button
    -- overstated what the server then charged (100). These two numbers are
    -- computed by the same functions the charge reads.
    if (kind == 'f') then
        state.fees = {
            hp = whole(parts[2], 500),
            sg = whole(parts[3], 1000),

            -- The Runic Portal fare and which of the NPC's three arms this
            -- character is on (2026-09-15): 0 pay the standing, 1 a Runic
            -- Portal Use Permit is held and will be spent instead, 2 free on
            -- a Captain's Wildcat Badge. Fallbacks are the book price and the
            -- arm every character without either key item is on, so an older
            -- server quotes what it would in fact charge.
            rp     = whole(parts[4], 200),
            rpMode = whole(parts[5], 0),

            -- The Jeuno home-point unit (2026-09-15b). Group 4's rows carry
            -- the Mayor of Jeuno's toll on top of the Treasurer's port lever,
            -- so the unit is no longer one number. ADDITIVE: a server that
            -- sends four fields falls back to field 1, which is what it would
            -- itself have charged before the second lever existed.
            hpJeuno = whole(parts[6], whole(parts[2], 500)),
        };

        return;
    end

    --[[
    * t| -- one outpost's fare (2026-09-15b). The outpost lever belongs to the
    * Mayor of whichever nation HOLDS the region, so eighteen regions can sit at
    * eighteen prices at once and no per-player record can carry them. The flat
    * catalog fee was the honest price only while the band was 50..200; at
    * 20..2000 it is a button saying 100g over a bill of 2000.
    *
    * ADDITIVE: an older server sends none of these and every row falls back to
    * its catalog fee, which is what that server would in fact charge. A row the
    * server stops sending (a region withdrawn from the outpost catalog) must
    * fall back the same way rather than read as free, which is why this keeps a
    * sparse table and never a default of zero.
    --]]
    if (kind == 't') then
        local region = whole(parts[2], -1);
        local fee    = whole(parts[3], -1);

        if (region >= 0 and fee >= 0) then
            state.opFees[region] = fee;
            state.opFeeRev       = state.opFeeRev + 1;
        end

        return;
    end

    --[[
    * w| -- the destination a live Unleashed rally is waiving the fare to
    * (DWUNLEASHED_PLAN.md D13). `w|hp|<index>`, `w|op|<region>`, or `w|-|0`
    * when nothing stands.
    *
    * THE OUTPOST TAB WOULD HAVE BEEN RIGHT WITHOUT IT -- a waived region rides
    * t| as a zero, computed by the same opFee the charge reads. The HOME POINT
    * tab would not: its price is f|'s unit times the catalog row's fee tier,
    * the one fare this window multiplies for itself, and four of the rally
    * sites are anchored to a crystal. So this record is what stops the window
    * quoting 500g over a bill of nothing -- and it lets the outpost row say WHY
    * it is free instead of leaving the player to infer it from a zero.
    *
    * THE `w|-|0` FORM IS NOT NOISE. A go's records are a merge with no reset
    * behind them, so a waiver that merely stopped being sent when the monster
    * died would sit here quoting free until the next zone line.
    *
    * Straight onto the live state rather than into a sync's staging table, for
    * the reason t|/f|/g| go there: it is a per-answer reading and not part of
    * the mask picture that has to commit whole at z|.
    --]]
    if (kind == 'w') then
        local tab = parts[2];
        local id  = whole(parts[3], -1);

        if ((tab == 'hp' or tab == 'op') and id >= 0) then
            state.waived = { tab = tab, id = id };
        else
            state.waived = nil;
        end

        state.waivedRev = state.waivedRev + 1;

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWPDATA is ours -- consumed and blocked before parsing so
* a malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwport_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwport'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Reads over the synced state.
--]]
local function maskBit(words, index)
    return bit.band(words[math.floor(index / 32) + 1] or 0, bit.lshift(1, index % 32)) ~= 0;
end

local function hpUnlocked(entry)
    return maskBit(state.masks.hp, entry.id);
end

local function sgUnlocked(entry)
    return bit.band(state.masks.sg[entry.group] or 0, bit.lshift(1, entry.bit)) ~= 0;
end

local function opUnlocked(entry)
    return bit.band(state.masks.op, bit.lshift(1, entry.id)) ~= 0;
end

local function warpUnlocked(tab, entry)
    return maskBit(state.masks[tab] or { }, entry.id);
end

-- What a dark Unity/Voidwatch row says. The two halves are shipped in the
-- catalog and the SERVER picks between them with the l| mask, so this function
-- chooses a string and decides nothing -- which is the whole reason the mask
-- exists (port_core's warpStoryMask).
local function warpLockText(tab, entry)
    local storyMask = state.masks[tab .. 'Story'] or { };

    if (entry.story ~= nil and maskBit(storyMask, entry.id)) then
        return string.format('Reached %s -- a warp would skip that.', entry.story);
    end

    if (entry.exp ~= nil) then
        return string.format('%s is not open on DriftwoodXI yet.', entry.exp);
    end

    -- A row with neither field and no unlock bit means the server knows
    -- something this catalog does not -- almost always a catalog older than
    -- the server, which the version banner is already shouting about.
    return 'Not available on DriftwoodXI yet.';
end

-- One unlock test, so the filter, the tab counts and the row body can never
-- disagree about whether a destination is yours. Each arm is the mask read the
-- server's own emitMasks/emitSpells fills in.
local function isUnlocked(tab, entry)
    if (tab == 'hp') then
        return hpUnlocked(entry);
    elseif (tab == 'sg') then
        return sgUnlocked(entry);
    elseif (tab == 'op') then
        return opUnlocked(entry);
    elseif (tab == 'un' or tab == 'vw') then
        return warpUnlocked(tab, entry);
    elseif (tab == 'rp') then
        local portal = state.runic[entry.id];

        return portal ~= nil and portal.ready;
    end

    local live = state.spells[entry.id];

    return live ~= nil and live.ready;
end

--[[
* How much of each tab is already yours, counted once per answer (1.3.0).
*
* The tab strip says how many rows a SEARCH matched; nothing anywhere said how
* much of a tab you have actually earned, which is the reading this window
* exists to give -- and the tabs you have not opened are exactly the ones you
* never click, so a number that only appears once you are already inside is a
* number nobody sees. It rides in the tab's own hover card instead, which is
* free until the cursor is on it.
*
* 362 unlock tests, once per sync, against 362 per frame if the tips built
* themselves where they are read.
--]]
local ownedRev   = -1;
local ownedCount = { };

local function ownedIn(tab)
    if (ownedRev ~= state.modelRev) then
        ownedRev = state.modelRev;

        for _, name in ipairs(TAB_ORDER) do
            local have = 0;

            for _, entry in ipairs(catalog[name]) do
                if (isUnlocked(name, entry)) then
                    have = have + 1;
                end
            end

            ownedCount[name] = have;
        end
    end

    return ownedCount[tab] or 0;
end

--[[
* The zone, read once per frame (1.3.0). This is a pcall around two
* memory-manager hops, and both the (here) marker and the home point fee
* preview called it PER ROW: on the home point tab that is 121 pcalls and 242
* pointer walks a frame, sixty times a second, to answer a question that
* cannot change between two rows of one table.
--]]
local frameZone = -1;

-- Hoisted out of the pcall below rather than written inline: a `function`
-- expression evaluated inside a per-frame call is a closure built and thrown
-- away sixty times a second, and this one captures nothing at all.
local function zoneOfMe()
    return AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0);
end

local function readZone()
    local ok, zone = pcall(zoneOfMe);

    if (ok and type(zone) == 'number') then
        return zone;
    end

    return -1;
end

--[[
* The fee preview (protocol discipline 2, rewritten 2026-08-19: the fee basis
* rides the wire as f|, so the button quotes the price the server will
* actually charge). The same-group free case stays a client-side zone check,
* mirroring hpFee's own; the undiscounted 500 is only the fallback for a
* server that has not sent f| this session.
*
* Both terms are folded once per frame (1.3.0) rather than per row: the fee
* tier is 1 or 2 across the whole catalog, so two labels cover every home
* point, and the survival charge is one number for the whole tab.
--]]
local frameFreeGroup = nil;
local frameHpUnit    = 500;
local frameHpLabel   = { };
local frameSgFee     = 1000;
local frameSgLabel   = '1000g';

--[[
* THE LEVY (2026-09-15b). The office holders' levers band 20..2000 percent of
* the stock fare, and every gil above the stock fare is split -- half to the
* holder of the owning seat, half burned. Two things follow for this window.
*
* 1. JEUNO'S HOME POINTS HAVE THEIR OWN UNIT. Group 4 is the only group two
*    levers reach (the Treasurer's port and the Mayor of Jeuno's tolls), so the
*    server sends a second unit in f| field 5 and the row picks by its group.
*
* 2. A LEVERED ROW SAYS SO, IN WORDS. The addon knows the charged price (it is
*    on the wire) and can recover the BASE, but it must not compute anybody's
*    cut: the split is the ledger's arithmetic and /politics is where it is
*    published, seat by seat. So the hover states the halving once, in one
*    string, with no percentage and no seat name in it -- this window does not
*    know who holds what, and a stale name would be worse than no name.
*
* RECOVERING THE BASE takes no new wire field and no guess. There are exactly
* two stock pairs -- 500 unit / 1000 guide without Rhapsody in White, 100 / 100
* with it -- and BOTH ride the same `port` lever, so the pair scales together
* and `sgfee == hpunit` is true for a Rhapsody holder at every rate and false
* for everyone else at every rate. (Exactly, not approximately: the stock units
* are multiples of 100, so the server's floor never bites.) Field 5 is left out
* of that reading deliberately -- it carries a second lever the guide fare does
* not.
--]]
local JEUNO_GROUP = 4;

local frameHpUnitJeuno  = 500;
local frameHpLabelJeuno = { };

-- The one place the halving is stated. Not computed anywhere in this file.
local LEVY_LINE = 'Base %s. Half of the rest goes to the office, half is burned.';

--[[
* THE UNLEASHED FARE WAIVER (DWUNLEASHED_PLAN.md D13). While a rally stands,
* the one stock destination its site is anchored to costs nothing -- for the
* characters who had already earned it; the attunement, the supply run and the
* level floor are untouched, and a dark row stays dark.
*
* The server names that destination in w| and this window renders it, exactly
* as it renders the levy: the waiver is the server's to decide, and a window
* that inferred one from a zero could not tell a waived fare from a Mayor who
* had set a lever to nothing.
--]]
local WAIVED_LINE = 'Free while the Unleashed stands there. The fare, not the attunement.';

local function waivedIs(tab, id)
    return state.waived ~= nil and state.waived.tab == tab and state.waived.id == id;
end

local frameHpLevy      = { };
local frameHpLevyJeuno = { };
local frameSgLevy      = nil;
local frameLevyKey     = nil;

-- One unit's worth of labels, and the levy line for each fee tier the catalog
-- carries. `stock` is the 100-percent unit; a tier whose price is the stock one
-- is not levered and gets no line at all.
local function feeLabels(unit, stock)
    local labels = { };
    local levy   = { };

    for tier = 1, 4 do
        labels[tier] = string.format('%dg', unit * tier);

        if (unit ~= stock) then
            levy[tier] = string.format(LEVY_LINE, grouped(stock * tier));
        end
    end

    return labels, levy;
end

local function foldFees()
    frameFreeGroup = zoneGroup[frameZone];

    local unit  = (state.fees ~= nil and state.fees.hp) or 500;
    local sg    = (state.fees ~= nil and state.fees.sg) or 1000;
    local jeuno = (state.fees ~= nil and state.fees.hpJeuno) or unit;

    -- Keyed on all three terms rather than on `unit` alone: a Jeuno toll can
    -- move with the port lever standing still, and the old single-term guard
    -- would have kept quoting the previous one.
    local key = string.format('%d/%d/%d', unit, sg, jeuno);

    if (key ~= frameLevyKey) then
        frameLevyKey = key;

        local stockUnit = (sg == unit) and 100 or 500;
        local stockSg   = (sg == unit) and 100 or 1000;

        frameHpUnit      = unit;
        frameHpUnitJeuno = jeuno;
        frameSgFee       = sg;
        frameSgLabel     = string.format('%dg', sg);
        frameSgLevy      = (sg ~= stockSg) and string.format(LEVY_LINE, grouped(stockSg)) or nil;

        frameHpLabel, frameHpLevy           = feeLabels(unit, stockUnit);
        frameHpLabelJeuno, frameHpLevyJeuno = feeLabels(jeuno, stockUnit);
    end
end

--[[
* The Runic Portal fare (2026-09-15). Three arms, and every term comes off the
* f| record rather than out of a literal here: the server sends what one trip
* costs in imperial standing and which arm this character is on, both read from
* the same RUNIC_FEE / runicFeeMode the charge itself reads. With no f| this
* session the fallbacks are the NPC's book price and the ordinary paying arm,
* which is what the server would in fact charge.
*
* Folded once per frame beside the gil terms: the arm changes when a key item
* does, which is not sixty times a second.
--]]
local RP_PAY    = 0;
local RP_PERMIT = 1;
local RP_FREE   = 2;

local frameRpFee   = 200;
local frameRpMode  = RP_PAY;
local frameRpLabel = '200 IS';

local function foldRunicFee()
    local fee  = (state.fees ~= nil and state.fees.rp) or 200;
    local mode = (state.fees ~= nil and state.fees.rpMode) or RP_PAY;

    if (fee ~= frameRpFee or mode ~= frameRpMode) then
        frameRpFee  = fee;
        frameRpMode = mode;

        if (mode == RP_FREE) then
            frameRpLabel = 'Free';
        elseif (mode == RP_PERMIT) then
            frameRpLabel = 'Permit';
        else
            frameRpLabel = string.format('%d IS', fee);
        end
    end
end

--[[
* THE OUTPOST FARES (2026-09-15b), and this tab is the one that could not ride
* f|. The outpost lever belongs to the Mayor of whichever nation HOLDS the
* region, so eighteen regions can sit at eighteen prices at once; the server
* sends one `t|<region>|<fee>` per row, computed by the same opFee the charge
* reads, and the button quotes it.
*
* THE CATALOG'S FLAT FEE IS THE BASE, which makes this tab the easy one: an
* outpost fare has no per-player term at all (no Rhapsody arm, no group), so a
* wire figure that differs from the shipped fee IS the markup, and the base to
* name in the hover is the number already on disk.
*
* A row with no t| this session -- an older server, or a region withdrawn from
* the outpost catalog -- falls back to that flat fee, which is what such a
* server would in fact charge, and carries no levy line because nothing is
* known to have been levered.
*
* Folded once per frame against state.opFeeRev rather than compared per row:
* eighteen numbers do not fit in one `~=`, and the fares move when a Mayor
* turns a knob, which is not sixty times a second.
--]]
local frameOpFee   = { };
local frameOpLabel = { };
local frameOpLevy  = { };
local frameOpRev   = nil;

local function foldOutpostFees()
    local rev = string.format('%d/%d', state.opFeeRev, state.waivedRev);

    if (frameOpRev == rev) then
        return;
    end

    frameOpRev   = rev;
    frameOpFee   = { };
    frameOpLabel = { };
    frameOpLevy  = { };

    for _, entry in ipairs(catalog.op) do
        local wire = state.opFees[entry.id];
        local fee  = wire or entry.fee;

        frameOpFee[entry] = fee;

        -- A WAIVED ROW IS NOT A LEVERED ONE, and the difference has to be
        -- visible: the wire figure is zero either way, and "Base 100. Half of
        -- the rest goes to the office" over a free ride is the levy line
        -- describing a split that did not happen. The server names the waived
        -- destination in w|, so the row says what it is instead of guessing
        -- from a number.
        if (waivedIs('op', entry.id)) then
            frameOpLabel[entry] = 'Free';
            frameOpLevy[entry]  = WAIVED_LINE;
        else
            frameOpLabel[entry] = (fee == entry.fee) and opFeeOf[entry] or string.format('%dg', fee);

            if (wire ~= nil and wire ~= entry.fee) then
                frameOpLevy[entry] = string.format(LEVY_LINE, grouped(entry.fee));
            end
        end
    end
end

-- What the trip will actually take out of the standing purse: nothing at all
-- on the permit and badge arms, so only the paying arm can ever be greyed.
local function rpFeeCost()
    return (frameRpMode == RP_PAY) and frameRpFee or 0;
end

-- The same courtesy cannotAfford gives gil, on the other purse. The f| guard
-- is the load-bearing term for the same reason it is there: without a basis
-- this session the quoted number is a fallback, and greying a trip the server
-- would have made is the one direction this must never fail in.
local function cannotAffordStanding(cost)
    return cost > 0
        and state.fees ~= nil
        and state.standing >= 0
        and state.standing < cost;
end

-- Cost first, label second: the cost is what the purse is measured against
-- (see cannotAfford), the label is what the button says.
--
-- WHICH unit a row is quoted from is the row's GROUP (2026-09-15b): Jeuno's
-- rows are the only ones two levers reach, and the server prices them in f|
-- field 5 rather than leaving the window to multiply two percentages it was
-- never sent.
local function hpFeeCost(entry)
    -- The waiver first: it is the one arm that is free for a reason the row's
    -- own group cannot express, and the server has already zeroed the base the
    -- charge will use (D13).
    if (waivedIs('hp', entry.id)) then
        return 0;
    end

    if (entry.group ~= 0 and entry.group == frameFreeGroup) then
        return 0;
    end

    return ((entry.group == JEUNO_GROUP) and frameHpUnitJeuno or frameHpUnit) * entry.fee;
end

local function hpFeeText(cost, entry)
    if (cost == 0) then
        return 'free';
    end

    local labels = (entry.group == JEUNO_GROUP) and frameHpLabelJeuno or frameHpLabel;

    return labels[entry.fee] or string.format('%dg', cost);
end

-- The levy line for one home-point row, or nil when nothing was levered. A
-- free hop is never levered: the base of nothing is nothing.
local function hpLevyText(cost, entry)
    -- ...with one free row that DOES have something to say: a waived crystal is
    -- free for a reason that will end, and a price that changes under the
    -- player owes an explanation.
    if (waivedIs('hp', entry.id)) then
        return WAIVED_LINE;
    end

    if (cost == 0) then
        return nil;
    end

    return ((entry.group == JEUNO_GROUP) and frameHpLevyJeuno or frameHpLevy)[entry.fee];
end

--[[
* The purse the server sent (g|) is what greys a fee this character cannot pay
* -- which is exactly what documentation/dwp_protocol.md says that record is
* FOR, and what this window has never done with it since the day it shipped.
*
* A courtesy and never the authority: the fee, the purse and the refusal are
* all still the server's at execution time, and this reading is only as fresh
* as the last sync -- which is why the tooltip on a greyed price names Refresh.
* -1 is "no g| this session", and then nothing is greyed for money at all.
--]]
local function cannotAfford(cost)
    -- `state.fees ~= nil` is the load-bearing term, and it is here because
    -- greying a row the server would have ALLOWED is the one direction this
    -- courtesy must never fail in. Without an f| this session the prices above
    -- are the undiscounted book ones, which overstate what a Rhapsody holder
    -- is charged by a factor of five -- exactly the disagreement the f| record
    -- was added to end -- so a purse between the two numbers would have had
    -- every button greyed against a trip the server was happy to make.
    return cost > 0
        and state.fees ~= nil
        and state.gil >= 0
        and state.gil < cost;
end

--[[
* The row view, cached (1.3.0). This function lowercased, filtered and SORTED
* the whole tab on EVERY FRAME: 121 home points is 121 :lower() allocations
* plus some seven hundred comparator calls, each of which built two favourite
* keys with string.format -- a couple of thousand throwaway strings a frame,
* for a list that changes when the player types in the box or clicks a star.
*
* Keyed on everything the list is built from: presentRev covers the find box,
* the stars and the filter switch, modelRev covers the unlock masks the filter
* reads. A miss rebuilds exactly one tab.
--]]
local viewCache = { };

-- The needle, and the one place typing in the box invalidates the view. Kept
-- against the RAW box text so a change of case or of surrounding space is
-- still a change of key rather than a rebuild that produces the same list.
local needleRaw   = nil;
local needleText  = '';
local needleTight = '';

local function currentNeedle()
    local raw = tostring(state.search[1] or '');

    if (raw ~= needleRaw) then
        needleRaw   = raw;
        needleText  = raw:lower():gsub('^%s+', ''):gsub('%s+$', '');
        -- Empty when the player typed nothing but punctuation, and then the
        -- tight arm is skipped entirely: a needle of '' matches every row, so
        -- searching for '#' would have quietly turned the filter off.
        needleTight = (needleText:gsub('[^%a%d]', ''));
        presentRev  = presentRev + 1;
    end

    return needleText;
end

local function rowsFor(tab)
    local cached = viewCache[tab];

    if (cached ~= nil and cached.present == presentRev and cached.model == state.modelRev) then
        return cached.rows;
    end

    local needle = currentNeedle();
    local only   = unlockedOnly[1] == true;
    local rows   = T{ };

    for _, entry in ipairs(catalog[tab]) do
        -- Destination and key item count too: a teleport is looked for by
        -- where it goes ("La Theine") at least as often as by its spell name,
        -- and the box promises to search every tab. The punctuation-free arm
        -- is what makes "rulude" and "sandoria" find their crystals.
        local hit = needle == ''
            or searchBlob[entry]:find(needle, 1, true) ~= nil
            or (needleTight ~= '' and searchTight[entry]:find(needleTight, 1, true) ~= nil);

        if (hit and (not only or isUnlocked(tab, entry))) then
            rows:append(entry);
        end
    end

    -- Favorites float, catalog order otherwise (table.sort is unstable in
    -- LuaJIT, so the order key includes the ordinal to keep it steady).
    --
    -- Both keys are read ONCE per row rather than inside the comparator: a
    -- 121-row sort is some seven hundred comparisons and each of them asked
    -- isFavorite twice, so a rebuild -- which is what a keystroke in the find
    -- box costs, six tabs over -- walked the favourites table fourteen hundred
    -- times to answer 121 questions.
    local ordinal = {};
    local rank    = {};

    for at, entry in ipairs(rows) do
        ordinal[entry] = at;
        rank[entry]    = isFavorite(entry) and 0 or 1;
    end

    table.sort(rows, function (a, b)
        if (rank[a] ~= rank[b]) then
            return rank[a] < rank[b];
        end

        return ordinal[a] < ordinal[b];
    end);

    viewCache[tab] = { present = presentRev, model = state.modelRev, rows = rows };

    return rows;
end

--[[
* Actions. Every one is a line a player could type.
*
* A queue entry is appended only when the LINE was actually queued: goQueue
* pairs one entry with one answer by position, and a click collapsed into a
* line already waiting will never get an answer of its own. Enqueuing anyway
* handed the spare entry to the next journey's answer, so the recent list
* recorded the wrong destination and the one after that recorded nothing.
--]]
local QUEUE_FULL = 'Too many trips waiting to go out -- give the last few a moment.';

-- What a journey in flight says, named for the reason ASK_FIRST is: the click
-- writes it and the answer clock two screens down tests it before replacing
-- it, and a spelling that drifted between the two would be a "Travelling..."
-- nothing ever took back down.
local GOING      = 'Travelling...';
local GOING_HOME = 'Off home...';

local function goTravel(tab, id)
    if (#queue >= QUEUE_MAX) then
        state.status    = QUEUE_FULL;
        state.statusBad = true;

        return;
    end

    local command = string.format('!dwp go %s %d', tab, id);

    if (not issue(command)) then
        return;
    end

    -- The line rides along on the entry so the answer clock can ask whether it
    -- has actually gone out yet (ageGoQueue). issue() collapses duplicates and
    -- an entry is appended only when a NEW line was queued, so one entry names
    -- one line and the two lists stay in step.
    state.goQueue:append({ tab = tab, id = id, at = frameNow, line = command });
    state.status    = GOING;
    state.statusBad = false;
end

local function goHome()
    if (#queue >= QUEUE_MAX) then
        state.status    = QUEUE_FULL;
        state.statusBad = true;

        return;
    end

    if (not issue('!dwp home')) then
        return;
    end

    -- No tab: the entry consumes home's own answer rather than the next go's,
    -- and rememberRecent skips it.
    state.goQueue:append({ at = frameNow, line = '!dwp home' });

    state.status    = GOING_HOME;
    state.statusBad = false;
end

--[[
* The travel answer clock (1.3.0). A journey's answer normally lands within a
* frame or two of the line going out. A server that restarts between the click
* and the reply used to leave "Travelling..." on the header for the rest of the
* session and one orphaned entry in the queue for every later click -- an
* extend-on-activity list with no ceiling, which is the shape this suite keeps
* finding.
*
* The clock is measured from the CLICK, and held at the present instant for as
* long as the line is still in the send queue -- see stillQueued. That second
* half is not decoration: the arithmetic that used to stand in for it (eight
* lines at 1.2 seconds is under ten) assumed a queue that drains, and every
* chat line the player types pushes the throttle forward.
--]]
local GO_TIMEOUT = 30.0;

local function ageGoQueue()
    local head = state.goQueue[1];

    while (head ~= nil and (frameNow - (head.at or frameNow)) >= GO_TIMEOUT) do
        -- Still waiting its turn: nothing has ignored it, so hold its clock at
        -- the present instant and measure the thirty seconds from the moment
        -- the line actually leaves. Entries are appended in click order and
        -- lines go out in that same order, so a head still queued means every
        -- entry behind it is queued too and none of them may age either.
        if (head.line ~= nil and stillQueued(head.line)) then
            head.at = frameNow;

            return;
        end

        table.remove(state.goQueue, 1);

        -- Only replace the sentence this journey put there: a refusal or a
        -- later note has already said something truer.
        if (#state.goQueue == 0 and (state.status == GOING or state.status == GOING_HOME)) then
            state.status    = 'No answer to that trip. Press Refresh to see where you stand.';
            state.statusBad = true;
        end

        head = state.goQueue[1];
    end
end

--[[
* The envelope watchdog (1.3.0). An answer cut short -- a dropped 0x017, a
* server restarted between two of its records -- leaves `inbound` open with no
* z| ever coming, and the ask was stamped answered at d|, so nothing asks
* again.
*
* STAGING MADE THAT QUIETER RATHER THAN BETTER, which is why this is here in
* the same pass. Before it, the wipe at d| had already happened, so a
* cut-short sync at least LOOKED wrong; now the window goes on drawing the
* previous answer, and a picture that is merely stale is indistinguishable
* from one that is current. Close the envelope, drop the fragment, say what
* happened once, and put the ask back on the clock -- which allows exactly one
* more try, because `tries` is untouched and needSync stops at ANSWER_TRIES.
* A retry that never terminates is a command loop. (dwah's watchdog.)
*
* Ten seconds: the server emits a whole envelope inside one command execution,
* so its records leave together and cross the wire in a handful of frames.
--]]
local ENVELOPE_TIMEOUT = 10.0;

local function ageEnvelope()
    if (state.inbound == nil or state.inboundAt == 0
            or (frameNow - state.inboundAt) < ENVELOPE_TIMEOUT) then
        return;
    end

    local wasSync = (state.inbound == 'sync');

    state.inbound   = nil;
    state.inboundAt = 0;
    state.staging   = nil;

    if (wasSync) then
        local asked    = requested['sync'];
        local retrying = false;

        if (type(asked) == 'table') then
            asked.answered = false;
            asked.at       = frameNow;

            -- The budget is READ, not reset. ANSWER_TRIES is the whole guard
            -- against this watchdog and a server that cuts every envelope
            -- short taking turns forever, which is a command loop with a
            -- fifteen-second period.
            retrying = (asked.tries < ANSWER_TRIES);
        end

        -- Two sentences because there are two situations. "Asking again" about
        -- an ask that will not be made is the sort of small lie this window
        -- keeps finding in itself, and the second one names the button that
        -- WILL ask, which is the only thing left that can.
        state.status    = retrying and CUT_RETRY or CUT_STUCK;
        state.statusBad = true;
    end
end

--[[
* Rendering.
*
* TIPS: one short sentence per control, in the suite's voice -- say what it
* does, and for anything greyed say why it cannot right now; never repeat the
* label, never tooltip the self-evident. Held as a table so the harness can
* assert the strings instead of re-typing them, and so a sentence cannot drift
* call site by call site. Tips carrying a NUMBER are formatted at the call
* site, and only inside the IsItemHovered arm: a tip built every frame for
* every row is a per-frame string for something nobody is looking at.
--]]
local TIPS = {
    home         = 'Warp to your home nation, free. The same trip as typing !home.',
    refresh      = 'Ask the server for your unlocks, spell readiness and purse again, and clear whatever the last answer left on this line.',
    refreshStale = 'This addon is not the version this server speaks, and Refresh cannot fix that -- update dwport through the launcher.',
    find         = 'Filters every tab by destination name, by where a teleport spell sends you, and by the gate crystal it needs. Punctuation and spaces do not matter -- "sandoria" finds Southern San d\'Oria.',
    clear        = 'Empty the find box and turn the unlocked-only switch off.',
    only         = 'Hide every destination you have not unlocked yet. Remembered for this character.',
    gil          = 'What the server said you were carrying at the last answer. Every price in this window is quoted against it.',
    queued       = 'Lines waiting on the client\'s chat rate limit -- one goes out every 1.2 seconds.',
    recents      = 'The last five places this window sent you, newest first. Not saved between sessions.',
    recentGo     = 'Go there again, at today\'s price.',
    star         = 'Pin to the top of this tab. Kept for this character.',
    unstar       = 'Unpin from the top of this tab.',
    here         = 'You are standing in this zone.',
    hereGuide    = 'You are standing in this zone -- the survival guide would refuse the trip too.',
    hereWarp     = 'You are standing in this zone, so this warp has nowhere to take you.',
    newerServer  = 'This server offers destinations this copy of the catalog cannot list. Nothing shown is wrong; there is simply more of it.',
    olderServer  = 'This addon ships a newer catalog than this server has. A row the server does not know is refused with a bare sentence and no explanation.',
    hpLocked     = 'Not attuned. Touch this crystal once and it is yours for good.',
    sgLocked     = 'Not registered. Read the survival guide in this zone once.',
    waiting      = 'Waiting for the first sync -- nothing on this row is known yet.',
    emptyFind    = 'Nothing in this tab matches the find box.',
    emptyOnly    = 'Nothing in this tab is unlocked yet. Turn the switch off to see what you are missing and why.',
    emptyBoth    = 'Nothing here is both unlocked and a match for the find box.',
};

-- What the Go button does, per tab. Split because the three that charge gil,
-- the two that are free and the one that spends MP are genuinely different
-- promises, and one sentence covering all three would be true of none.
local GO_TIPS = {
    hp = 'Travel to this crystal. The price on the button is what the server takes.',
    sg = 'Travel to this survival guide. The price on the button is what the server takes.',
    op = 'Travel to this outpost. The price on the button is what the server takes.',
    un = 'A Unity Concord warp. Free, and it costs nothing but the trip.',
    vw = 'A warp to this zone\'s Planar Rift. Free, and it costs nothing but the trip.',
    sp = 'Cast the teleport now. The MP comes out of whoever the row names, and the server re-checks the crystal, the caster and the MP before it moves anyone.',
    rp = 'Ride the Runic Portal to this staging point. The fare is the Whitegate portal\'s own -- a Runic Portal Use Permit if you hold one, 200 Imperial Standing if you do not -- and the server takes it at execution, not here.',
};

local TAB_TIPS = {
    hp = 'Home point crystals. Attune one by touching it, then come back here.',
    sg = 'Survival guides. Read one in its zone to register it.',
    op = 'Conquest outposts. A region opens with its supply run and a level floor.',
    sp = 'The teleport spells. You cast them, or a summoned squad member does.',
    un = 'Unity Concord warps. Every character has these; what is dark is what this server has not opened.',
    vw = 'Voidwatch Planar Rifts. Every character has these; what is dark is what this server has not opened.',
    rp = 'The Aht Urhgan Runic Portals. A staging point opens once you have stood at its own portal -- and the whole tab waits on Aht Urhgan opening here and on the Boarding Permit.',
};

--[[
* A tab's hover card: what the tab is, and how much of it you have (1.3.0).
* Built inside the hover arm only -- six tab items are submitted every frame
* and at most one of them is ever under the cursor.
*
* The count is withheld until the first answer lands. Before it every mask
* word is zero, so "You have 0 of 121 here" would be a confident falsehood on
* every tab at once -- the same trap lockHint's first arm exists for.
--]]
local function tabTip(tab)
    local base = TAB_TIPS[tab];

    -- nil for a seventh tab added without a sentence: the same omission the
    -- tip() helper below turns into a missing tooltip rather than a dead
    -- window, and returning early here keeps the count out of that path too.
    if (base == nil or not state.synced) then
        return base;
    end

    -- "can use", not "have": the count is isUnlocked's answer, the same one the
    -- filter and the row body give, and on the Teleport tab that folds in the
    -- caster's MP. A spell you own and cannot cast this minute is not one you
    -- "have" fewer of -- but it is one you cannot use right now, which is what
    -- the number is actually counting on every tab.
    return string.format('%s You can use %d of these %d right now.', base, ownedIn(tab), #catalog[tab]);
end

-- One short tip on the item just drawn. Every constant tooltip in this file
-- goes through here so the pattern cannot drift call site by call site.
--
-- The nil guard is not decoration: the tables above are keyed by tab, and a
-- seventh tab added to TAB_ORDER without a sentence in both of them would put
-- a nil through SetTooltip -- which is a Lua error sixty times a second on the
-- player's machine for a missing comment. The harness asserts the coverage; the
-- guard makes the omission a missing tooltip rather than a dead window.
local function tip(text)
    if (text ~= nil and imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local function starButton(entry)
    local starred = isFavorite(entry);

    if (imgui.SmallButton(starred and favOnOf[entry] or favOffOf[entry])) then
        toggleFavorite(favKeyOf[entry]);
    end

    tip(starred and TIPS.unstar or TIPS.star);
end

--[[
* The action button's label, memoised per row against the price it was built
* from (1.3.0). Composing verb, price and ImGui id is two concatenations per
* visible row per frame -- a couple of hundred throwaway strings a second on
* the home point tab -- for a label that moves when the zone changes or the
* server sends a new fee basis, which is a handful of times an hour.
*
* One slot per row rather than a table per row: the fee text a row can carry
* is one of about five strings, but a memo that never forgets is a memo that
* grows, and the only reading that matters is the current one.
--]]
local goLabelText = { };
local goLabelFee  = { };

local function goLabel(entry, feeText)
    if (goLabelFee[entry] ~= feeText) then
        goLabelFee[entry]  = feeText;
        goLabelText[entry] = goVerbOf[entry] .. feeText .. goIdOf[entry];
    end

    return goLabelText[entry];
end

--[[
* The action cell. `cost` is what the server will take in gil, and when the
* purse cannot cover it the price is drawn greyed where the button would be --
* the same reading every locked row above it gets, and exactly what
* documentation/dwp_protocol.md says the g| record is for.
*
* A courtesy and never the authority: the click is still re-checked server
* side, and this purse is only as fresh as the last answer, which is why the
* greyed tooltip names Refresh.
--]]
local function goButton(tab, entry, feeText, cost)
    if (cannotAfford(cost)) then
        imgui.TextDisabled(feeText);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                '%s costs %s gil and you were carrying %s at the last answer. Refresh re-reads the purse.',
                entry.name, grouped(cost), grouped(state.gil)));
        end

        return;
    end

    if (imgui.SmallButton(goLabel(entry, feeText))) then
        goTravel(tab, entry.id);
    end

    tip(GO_TIPS[tab]);
end

--[[
* The Teleport tab's rows are SPELL rows, and every sibling that draws one --
* dwtoau, dwbags, dwah -- gives it the client's own description card. These had
* no card at all, and an unlocked one had no tooltip whatever (1.3.0).
*
* The description is read out of the client's DAT tables ONCE per spell and
* kept: there are nine of them and the answer cannot change while the client
* runs. Every hop is pcall'd, because the shape of a resource object is the
* client's business and a card missing a line has to beat a window that throws
* on hover -- which is dwtoau's rule for the same lookup.
--]]
local spellDescs = { };

local function spellDesc(id)
    local cached = spellDescs[id];

    if (cached ~= nil) then
        return cached;
    end

    cached = '';

    pcall(function()
        local spell = AshitaCore:GetResourceManager():GetSpellById(id);

        if (spell ~= nil and spell.Description ~= nil
                and spell.Description[1] ~= nil and #spell.Description[1] > 0) then
            cached = spell.Description[1];
        end
    end);

    spellDescs[id] = cached;

    return cached;
end

--[[
* One teleport's card: the game's own words, then this catalog's terms, then
* whatever this window knows on top (the reason a dark row is dark).
*
* BeginTooltip/EndTooltip rather than SetTooltip because the card is several
* lines, and the pair is unconditional: an unbalanced tooltip stack corrupts
* the frame for every window drawn after this one.
--]]
local function spellCard(entry, note)
    local desc = spellDesc(entry.id);

    imgui.BeginTooltip();
    imgui.Text(entry.name);

    if (desc ~= '') then
        imgui.TextWrapped(desc);
    end

    imgui.TextDisabled(string.format('WHM %d  --  %d MP  --  %s', entry.lvl, entry.mp, entry.dest));

    if (note ~= nil) then
        imgui.Text(note);
    end

    imgui.EndTooltip();
end

-- Draws a dark row's name and answers whether the cursor is on it. The HINT is
-- built by the caller and only when this returns true: half the Unity and
-- Voidwatch tabs are dark on this server, and formatting sixty-odd refusal
-- sentences a frame for the one nobody is pointing at is sixty-odd strings a
-- frame thrown away.
local function lockedRow(entry)
    imgui.TextDisabled(entry.name);

    return imgui.IsItemHovered();
end

-- What a dark Runic Portal row says. Three flags, three sentences, and the
-- ORDER is the server's own refusal order (port_core's runicRefusal): the
-- expansion first -- "not yet on this server" is a different wait from "not
-- yet for you" -- then the Boarding Permit, then the staging point itself.
--
-- Telling a player to go stand at Ilrusi Atoll while Aht Urhgan is shut is
-- true, useless and impossible to act on, which is the same failure the l|
-- mask exists to prevent one tab over.
local function runicLockText(entry)
    local portal = state.runic[entry.id];

    -- No record for this row: an older server that has never sent one. Say so
    -- rather than making a claim about a character it has not described.
    if (portal == nil) then
        return TIPS.waiting;
    end

    if (not portal.open) then
        return string.format('%s is not open on DriftwoodXI yet.', entry.exp or 'This expansion');
    end

    if (not portal.story and entry.story ~= nil) then
        return string.format('Reached %s -- a warp would skip that.', entry.story);
    end

    if (not portal.attuned) then
        return 'Never visited. Stand at the Runic Portal AT this staging point once -- the one offering the ride back to Whitegate -- and it is yours for good.';
    end

    return TIPS.waiting;
end

--[[
* Why one dark row is dark. One function so the six tabs cannot drift apart,
* and every sentence in it is built on demand -- see lockedRow.
*
* THE FIRST ARM IS THE ONE THAT MATTERS. Before the first envelope of the
* session every mask word is zero, so every row in the window is dark, and the
* tab-specific sentences below would each be a confident claim about a
* character the server has not described yet: "Not attuned", to somebody who
* attuned that crystal years ago. This file's header comment has always said
* rows read as waiting until the first sync lands; the code did not, and this
* is where it started to (1.3.0).
--]]
local function lockHint(tab, entry)
    if (not state.synced) then
        return TIPS.waiting;
    end

    if (tab == 'hp') then
        return TIPS.hpLocked;
    elseif (tab == 'sg') then
        return TIPS.sgLocked;
    elseif (tab == 'op') then
        return string.format('Locked. Level %d, and this region\'s supply run opens it.', entry.lvl);
    elseif (tab == 'un' or tab == 'vw') then
        return warpLockText(tab, entry);
    elseif (tab == 'rp') then
        return runicLockText(entry);
    end

    local live = state.spells[entry.id];

    if (live == nil) then
        return TIPS.waiting;
    end

    if (not live.ki) then
        return string.format('Attune the telepoint: %s.', entry.ki);
    end

    if (live.casterKind == 0) then
        return string.format('Nobody in your party can cast this yet -- WHM %d, spell learned.', entry.lvl);
    end

    return string.format('%s needs %d MP and has %d. Rest first.', live.casterName, live.mpCost, live.mp);
end

local function hereMarker(entry)
    if (entry.zone ~= nil and entry.zone == frameZone) then
        imgui.SameLine();
        imgui.TextDisabled('(here)');
        tip(TIPS.here);
    end
end

--[[
* Column widths measured from the text they must hold (1.3.0), replacing the
* three magic numbers this table used to carry. The name column is now a
* STRETCH column: pinned at 268 (470 on the Teleport tab) it bought empty
* space on the right of a widened window while a long name went on being
* clipped, and clipped everything when the window was narrowed. CalcTextSize's
* answer cannot change while the font does not, so it is asked once.
--]]
local widths = { };

local function textWidth(text)
    local cached = widths[text];

    if (cached == nil) then
        cached = (imgui.CalcTextSize(text));

        widths[text] = cached;
    end

    return cached;
end

--[[
* ImGui's own frame padding and item spacing, read once a frame (1.3.0). A
* button is its label plus FramePadding on each side, and two of them are
* ItemSpacing apart; both scale with the font, so a constant guessed here is
* exactly what makes a button clip on somebody else's font size. dwcraft and
* dwcon read the style the same way.
*
* The defaults are ImGui's own, and stand in only if the binding hands back
* something this addon cannot read -- the window is not worth losing over a
* column two pixels narrow.
--]]
local framePad = 4;
local itemGap  = 8;

-- Hoisted for the same reason readZone's is: one fewer closure per frame.
local function styleGaps()
    local style = imgui.GetStyle();

    return style.FramePadding.x, style.ItemSpacing.x;
end

local function foldStyle()
    local ok, pad, gap = pcall(styleGaps);

    if (ok and type(pad) == 'number' and pad > 0) then
        framePad = pad;
    end

    if (ok and type(gap) == 'number' and gap > 0) then
        itemGap = gap;
    end
end

-- A button's width above its label: the padding on both sides, plus two
-- pixels of slack so a measured column never lands one pixel short of the
-- glyph it was measured from.
local function buttonPad()
    return framePad * 2 + 2;
end

local function destinationTable(tab, rows)
    -- An empty table clamps its scroll to nothing and reads as a broken tab.
    -- Say which of the two switches emptied it instead, because both of them
    -- are two clicks away in the header.
    if (#rows == 0) then
        imgui.Spacing();

        if (currentNeedle() ~= '' and unlockedOnly[1]) then
            imgui.TextDisabled(TIPS.emptyBoth);
        elseif (unlockedOnly[1]) then
            imgui.TextDisabled(TIPS.emptyOnly);
        else
            imgui.TextDisabled(TIPS.emptyFind);
        end

        return;
    end

    -- WidthFixed/WidthStretch and the flag set the other Driftwood addons
    -- already use: only those are proven to exist in this environment's ImGui
    -- bindings.
    if (not imgui.BeginTable(tableIdOf[tab], 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY), { -1, -1 })) then
        return;
    end

    -- The Teleport tab is the widest case by a long way: its name column also
    -- carries the destination, the caster and the MP cost on one line
    -- ('Teleport-Altep -> Eastern Altepa Desert, cast by Bigholder (100 MP)').
    -- It used to be given 470 fixed pixels and the other tabs 268, which meant
    -- a window widened to read that line gained empty space instead, and a
    -- window narrowed below 650 clipped every tab. The column stretches now:
    -- it is the only text column, and the two beside it are measured.
    -- The action cell holds either the "(you are here)" marker or a Go button
    -- with a price on it, so it is measured from the wider of the two -- and
    -- from a price with room for a fee basis several times today's, because a
    -- column measured to the exact current number clips the day the owner
    -- retunes one. "(you are here)" is the wider of the two as things stand,
    -- so the headroom costs nothing at all.
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, textWidth('*') + buttonPad(), 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthStretch, 0, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed,
        math.max(textWidth('(you are here)'), textWidth('Go  100000g') + buttonPad()), 0);

    for _, entry in ipairs(rows) do
        local unlocked = isUnlocked(tab, entry);

        imgui.TableNextRow();
        imgui.TableNextColumn();
        starButton(entry);
        imgui.TableNextColumn();

        if (not unlocked) then
            -- Every dark row reads the same way on every tab: the name in the
            -- disabled colour, and the reason on hover. The Teleport tab is
            -- the one that also states its book requirement in the open,
            -- because "WHM 44, 100 MP" is what you plan around rather than
            -- something you check once.
            local hovered = lockedRow(entry);

            if (tab == 'sp') then
                imgui.SameLine();
                imgui.TextDisabled(spDestOf[entry]);

                -- The requirement line answers to the cursor too (1.3.0). It
                -- is the WIDER half of the row and the half a reader's eye
                -- lands on, and hovering it used to give nothing at all while
                -- the name two pixels to the left explained itself.
                if (hovered or imgui.IsItemHovered()) then
                    spellCard(entry, lockHint(tab, entry));
                end
            elseif (hovered) then
                imgui.SetTooltip(lockHint(tab, entry));
            end

            imgui.TableNextColumn();
        elseif (tab == 'hp') then
            local cost = hpFeeCost(entry);

            imgui.Text(entry.name);

            -- The levy, on the name rather than on the button: the button
            -- already answers with what the click does, and this sentence is
            -- about the PRICE, which is the other half of the row.
            tip(hpLevyText(cost, entry));
            hereMarker(entry);
            imgui.TableNextColumn();
            goButton(tab, entry, hpFeeText(cost, entry), cost);
        elseif (tab == 'sg') then
            imgui.Text(entry.name);
            tip(frameSgLevy);
            -- No hereMarker: this tab says "(you are here)" in the button
            -- column instead (a guide cannot teleport you to itself), and both
            -- at once said the same thing twice on one row.
            imgui.TableNextColumn();

            if (entry.zone == frameZone) then
                imgui.TextDisabled('(you are here)');
                tip(TIPS.hereGuide);
            else
                goButton(tab, entry, frameSgLabel, frameSgFee);
            end
        elseif (tab == 'op') then
            imgui.Text(entry.name);

            -- The levy, on the name for the same reason the home point tab
            -- puts it there: the button says what the click does, this says
            -- what the price is made of.
            tip(frameOpLevy[entry]);
            imgui.TableNextColumn();
            goButton(tab, entry, frameOpLabel[entry], frameOpFee[entry]);
        elseif (tab == 'un' or tab == 'vw') then
            -- Unity and Voidwatch (1.2.0). Every character has these; what
            -- decides a row is which expansions this server has opened, and
            -- whether the destination sits behind a story gate a warp would
            -- skip. Both answers arrive as masks -- see warpLockText.
            imgui.Text(entry.name);
            imgui.TableNextColumn();

            if (entry.zone == frameZone) then
                -- The same reading the survival tab gives: a warp to the zone
                -- you are standing in is a reposition nobody asked for, and
                -- saying so beats a button that looks broken.
                imgui.TextDisabled('(you are here)');
                tip(TIPS.hereWarp);
            else
                goButton(tab, entry, 'Free', 0);
            end
        elseif (tab == 'rp') then
            -- The Runic Portals (1.5.0). The fare is imperial standing rather
            -- than gil, so the greying is against the OTHER purse -- and no
            -- (you are here) arm: both Caedarva staging points share a zone
            -- and the server repositions between them, so a trip inside your
            -- own zone is a real journey here and not a no-op.
            local cost = rpFeeCost();

            imgui.Text(entry.name);
            imgui.TableNextColumn();

            if (cannotAffordStanding(cost)) then
                imgui.TextDisabled(frameRpLabel);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format(
                        '%s costs %s Imperial Standing and you had %s at the last answer. Refresh re-reads it.',
                        entry.name, grouped(cost), grouped(state.standing)));
                end
            else
                -- cost 0 into goButton: the gil courtesy must not grey a fare
                -- it is not measuring. The standing arm above is this row's.
                goButton(tab, entry, frameRpLabel, 0);
            end
        else
            imgui.Text(entry.name);

            -- Asked before the SameLine, because after it the last item is the
            -- detail rather than the name, and the card belongs to both.
            local onName = imgui.IsItemHovered();

            imgui.SameLine();
            imgui.TextDisabled(state.spells[entry.id].line or spDestOf[entry]);

            if (onName or imgui.IsItemHovered()) then
                spellCard(entry, nil);
            end

            imgui.TableNextColumn();
            goButton(tab, entry, 'Cast', 0);
        end
    end

    imgui.EndTable();
end

-- The purse and the backlog, formatted when they move rather than sixty times
-- a second for numbers that change a handful of times an hour and once a
-- second respectively.
local gilShown = -2;
local gilLabel = '';

local queuedShown = -1;
local queuedLabel = '';

local function queuedText()
    if (#queue ~= queuedShown) then
        queuedShown = #queue;
        queuedLabel = string.format('%d queued...', queuedShown);
    end

    return queuedLabel;
end

local function gilText()
    if (state.gil ~= gilShown) then
        gilShown = state.gil;
        gilLabel = grouped(state.gil) .. ' gil';
    end

    return gilLabel;
end

--[[
* How old a reading is, in the shortest words that are true. Built only inside
* a hover arm, so the cost is one string for the one card being looked at.
*
* The singular is spelled out because "1 seconds ago" is the sort of seam a
* player notices and nothing else in this window has one, and the first few
* seconds read as "just now" because a number that says 0 invites the reader
* to wonder what it is counting.
--]]
local function agoText(seconds)
    seconds = math.max(0, math.floor(seconds or 0));

    if (seconds < 5) then
        return 'just now';
    end

    if (seconds < 60) then
        return string.format('%d seconds ago', seconds);
    end

    local minutes = math.floor(seconds / 60);

    if (minutes == 1) then
        return 'a minute ago';
    end

    return string.format('%d minutes ago', minutes);
end

--[[
* The tab strip's labels. The find box promises to search EVERY tab, but only
* the open one shows its hits -- so a needle that matched nothing here and
* four things two tabs over read as a needle that matched nothing at all
* (1.3.0). The count is drawn ONLY while the box has text or the filter is on:
* an always-on count is a number that never moves and a tab strip that never
* sits still.
*
* Built for all six at once and cached on the same two revisions the row views
* use, so a keystroke costs six filtered lists and a frame costs nothing.
--]]
local labelPresent = -1;
local labelModel   = -1;
local labelText    = { };

local function tabLabel(tab)
    -- The needle is settled BEFORE the cache revision is stamped: currentNeedle
    -- is the one read in this file that can move presentRev, and stamping a
    -- revision it then walks past marks a freshly built label stale in the
    -- same breath that built it.
    local counting = (currentNeedle() ~= '') or (unlockedOnly[1] == true);

    if (labelPresent ~= presentRev or labelModel ~= state.modelRev) then
        labelPresent = presentRev;
        labelModel   = state.modelRev;

        for _, name in ipairs(TAB_ORDER) do
            if (counting) then
                labelText[name] = string.format('%s (%d)##dwport_tab_%s', TAB_LABEL[name], #rowsFor(name), name);
            else
                labelText[name] = TAB_LABEL[name] .. '##dwport_tab_' .. name;
            end
        end
    end

    return labelText[tab];
end

local function headerRow()
    if (imgui.Button('Home##dwport_home')) then
        goHome();
    end

    tip(TIPS.home);

    imgui.SameLine();

    if (imgui.Button('Refresh##dwport_refresh')) then
        refresh();

        -- ...and clear what the last answer left on this line. A refusal
        -- ("You cannot travel while engaged.") used to sit here in red right
        -- through a successful re-sync, because a sync answers with records
        -- and no m|, so the only thing that could ever clear it was another
        -- journey. Except while the protocol banner is up, which is still the
        -- truth and is not the last answer's doing.
        --
        -- AND IT SAYS SO (1.3.0). Clearing the line to the empty string left
        -- the one button in this window that looks like it should help with no
        -- visible effect whatever: the rows do not move on a re-sync that
        -- agrees with the last one, and a sync answers with records and no m|,
        -- so nothing was drawn between the press and the answer. z| takes this
        -- sentence back down, and needSync replaces it if nothing comes back.
        -- The window OPENING does not say it, because the window appearing is
        -- already the feedback and a line that flashes on every open is noise.
        if (not state.protoBad) then
            state.status    = state.synced and ASK_AGAIN or ASK_FIRST;
            state.statusBad = false;
        end
    end

    tip(state.protoBad and TIPS.refreshStale or TIPS.refresh);

    imgui.SameLine();
    imgui.PushItemWidth(180);
    imgui.InputTextWithHint('##dwport_search', 'search every tab', state.search, 48);
    imgui.PopItemWidth();

    tip(TIPS.find);

    if (currentNeedle() ~= '' or unlockedOnly[1]) then
        imgui.SameLine();

        if (imgui.SmallButton('Clear##dwport_clear')) then
            state.search[1] = '';

            setUnlockedOnly(false);
        end

        tip(TIPS.clear);
    end

    -- Second line: the two readings and the switch. Kept off the first so the
    -- header still fits when the window is dragged down to its minimum width.
    --
    -- The second arm guards the mirror where it is CONSUMED: ImGui writes the
    -- holder directly, and if a click ever moved it without the call reporting
    -- a change, the view cache would go on serving the list built for the old
    -- setting and the switch would look broken rather than slow.
    if (imgui.Checkbox('Only what I can use##dwport_only', unlockedOnly)
            or (unlockedOnly[1] == true) ~= (config.unlockedOnly == true)) then
        setUnlockedOnly(unlockedOnly[1]);
    end

    tip(TIPS.only);

    if (state.gil >= 0) then
        imgui.SameLine();
        imgui.TextDisabled(gilText());

        -- ...and HOW OLD the reading is (1.3.0). This number is what greys a
        -- price the purse cannot cover, and a courtesy that greys a button is
        -- owed a word about its own freshness: a player who has been killing
        -- things with the window open has more gil than this says.
        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('%s Read %s.', TIPS.gil, agoText(os.time() - state.gilAt)));
        end
    end

    if (#queue > 0) then
        imgui.SameLine();
        imgui.TextDisabled(queuedText());
        tip(TIPS.queued);
    end

    --[[
    * The recent list: the five last journeys as one-click buttons. They WRAP
    * (1.3.0). Five zone names chained on SameLine ran straight off the right
    * edge of the window, and past the edge is not merely untidy -- it is
    * unclickable, so on a narrow window the two oldest entries were decoration.
    *
    * The running width is tracked here rather than read back from ImGui: by
    * the time a button has been submitted the cursor is already on the next
    * line, so the reading that would answer "does the next one fit" is not the
    * one GetCursorPosX gives.
    --]]
    if (#state.recents > 0) then
        local room = (imgui.GetContentRegionAvail());
        local used = textWidth('Recent:');

        imgui.Text('Recent:');
        tip(TIPS.recents);

        for _, recent in ipairs(state.recents) do
            local entry = byId[recent.tab] ~= nil and byId[recent.tab][recent.id] or nil;

            if (entry ~= nil) then
                local width = textWidth(entry.name) + buttonPad();

                if (used + itemGap + width <= room) then
                    imgui.SameLine();

                    used = used + itemGap + width;
                else
                    used = width;
                end

                if (imgui.SmallButton(recentLabelOf[entry])) then
                    goTravel(recent.tab, recent.id);
                end

                -- The card names the TAB, and that is not decoration: three
                -- systems reach "La Theine Plateau" -- a survival guide, a
                -- Unity warp and a Voidwatch rift -- so two recent buttons can
                -- read identically and charge two different prices. Built in
                -- the hover arm, so it is one string for the one being pointed
                -- at rather than five a frame.
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('%s (%s). %s',
                        entry.name, TAB_LABEL[recent.tab] or recent.tab, TIPS.recentGo));
                end
            end
        end
    end

    -- The drift banners and the status line WRAP: a refusal off the wire runs
    -- to 127 characters and the window is 650 wide, so an unwrapped line was
    -- a sentence cut off exactly where it started to matter.
    imgui.PushTextWrapPos(0);

    if (state.serverCatalog ~= nil and state.serverCatalog > catalog.version) then
        imgui.TextColored(theme.colors.warn, 'The server knows destinations this addon does not. Update through the launcher.');
        tip(TIPS.newerServer);
    elseif (state.serverCatalog ~= nil and state.serverCatalog < catalog.version) then
        -- The other direction of the same drift: an addon shipped ahead of a
        -- server deploy. Without this arm every destination the newer catalog
        -- added renders as an ordinary row whose go the server refuses with a
        -- bare sentence and no explanation.
        imgui.TextColored(theme.colors.warn, 'This server is older than this addon -- some listed destinations may not exist here yet.');
        tip(TIPS.olderServer);
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.PopTextWrapPos();

    imgui.Separator();
end

local function renderWindow()
    -- Settle the frame's inputs first, in this order: the zone every (here)
    -- marker and every home point price is measured against, the find box
    -- (the one input that can bump presentRev mid-frame, so nothing may read
    -- a revision before it), and the fee terms folded from the zone.
    frameZone = readZone();

    currentNeedle();
    foldFees();
    foldRunicFee();
    foldOutpostFees();
    foldStyle();

    headerRow();

    --[[
    * Whether THIS frame is the one carrying the remembered-tab request.
    *
    * ImGui's SetSelected sets the bar's NextSelectedTabId, which lands on the
    * following frame -- so on this one the bar still reports the PREVIOUS
    * selection as the open tab. A write-back taken here would record the tab
    * the player is leaving rather than the one they asked for, and would spend
    * a file write to do it. Read before the loop, because the loop clears it.
    --]]
    local asking = (state.wantTab ~= nil);

    if (imgui.BeginTabBar('##dwport_tabs')) then
        for _, tab in ipairs(TAB_ORDER) do
            --[[
            * The remembered tab is asked for once and the request is spent
            * here, on the frame it applies to (1.3.0). A SetSelected left
            * standing fights every click the player then makes -- dwgmpanel
            * records the same rule for the same flag -- and the three-argument
            * BeginTabItem is the form dwfishing, dwgmpanel and dwparse already
            * ship unguarded against this client's bindings.
            --]]
            local flags = ImGuiTabItemFlags_None;

            if (state.wantTab == tab) then
                flags         = ImGuiTabItemFlags_SetSelected;
                state.wantTab = nil;
            end

            local open = imgui.BeginTabItem(tabLabel(tab), nil, flags);

            -- Hover reads the TAB, and it has to be asked here: after the
            -- first widget of the tab body the last item is that widget. The
            -- card is built inside the arm because it carries a count.
            if (imgui.IsItemHovered()) then
                local card = tabTip(tab);

                if (card ~= nil) then
                    imgui.SetTooltip(card);
                end
            end

            if (open) then
                -- Which tab this character was on, written back the moment it
                -- changes and never otherwise: settings.save writes a file,
                -- and a file written sixty times a second is a file written
                -- while the disk is being asked for something else.
                if (not asking and config.lastTab ~= tab) then
                    config.lastTab = tab;

                    pcall(settings.save);
                end

                destinationTable(tab, rowsFor(tab));
                imgui.EndTabItem();
            end
        end

        imgui.EndTabBar();
    end

    -- Spent whether the bar took it or not. A tab strip that did not draw this
    -- frame must not leave a SetSelected standing for a later frame to apply
    -- against a click the player has made since -- which is the one thing this
    -- flag must never do.
    state.wantTab = nil;

    needSync();
end

--[[
* The render pass: pcall'd body, Begin/End and theme push/pop outside it so
* both stacks stay balanced; an error closes the window once, loudly, and
* the typed commands remain as the fallback.
--]]
-- Closed the first time SetNextWindowSizeConstraints refuses; see the call.
local constraintsBroken = false;

ashita.events.register('d3d_present', 'dwport_present', function ()
    -- The frame's one clock reading, taken before anything that ages against
    -- it: the send throttle, the sync answer clock and the travel answer
    -- clock all read this, and all three used to call os.clock() themselves.
    frameNow = os.clock();

    -- Both of these run whether the window is open or shut. A journey clicked
    -- and then abandoned by closing the window must still stop being "in
    -- flight", or it stays queued against the next one's answer.
    pumpQueue();
    ageGoQueue();
    ageEnvelope();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    -- 650 wide: the Teleport tab's row carries a name, its destination, the
    -- caster and the MP cost on one line, and the point of widening it was
    -- never to trade a clipped line for a horizontal scrollbar.
    imgui.SetNextWindowSize({ 650, 480 }, ImGuiCond_FirstUseEver);

    -- ...and a floor under it (1.3.0). Nothing stopped this window being
    -- dragged down to a title bar: the tab strip collapses to a scroll arrow,
    -- the header buttons wrap onto each other and the table has no room for a
    -- row. 460 x 320 keeps the six tabs, the header and a few rows reachable,
    -- which is the least this window can be and still be usable.
    --
    -- 460 is the six tab LABELS measured: 56 characters plus a frame padding
    -- each and the window's own, which lands a few pixels under it. With the
    -- find box or the switch on, the labels grow by their hit counts and ImGui
    -- shrinks them (its default mixed fitting policy) rather than hiding any --
    -- which is the right degradation and the reason no fitting flag is passed.
    --
    -- PCALL'D AND LATCHED (2026-09-06, review). This call sits OUTSIDE the
    -- render pcall, and a player's Ashita is whatever they installed first: a
    -- binding that is not there is a raise in d3d_present sixty times a second
    -- with no window to close, which the host answers by unloading the addon.
    -- Refused once, never asked again, and the window simply has no floor --
    -- which is 1.2.0. dwmerits' shape.
    if (not constraintsBroken) then
        if (not pcall(imgui.SetNextWindowSizeConstraints, { 460, 320 }, { 99999, 99999 })) then
            constraintsBroken = true;
        end
    end

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Travel##dwport', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwport'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwport'):append(chat.message('Window closed. Everything it does also works as !port commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1]  = true;
    state.reported = false;

    -- The tab this character was last looking at, asked for on the first frame
    -- and spent there (see the tab strip). Re-read from config each time
    -- rather than cached: a character change swaps the whole file under us.
    state.wantTab  = TAB_LABEL[config.lastTab] ~= nil and config.lastTab or 'hp';

    -- ...and the same protoBad guard the Refresh button carries. Clearing the
    -- status here blanked the "Update dwport" banner, and protoBad then gagged
    -- every m|/e| that might have written another line -- so the window sat
    -- with no status at all until the next d| happened to arrive.
    if (not state.protoBad) then
        state.status    = state.synced and '' or ASK_FIRST;
        state.statusBad = false;
    end

    refresh();
end

--[[
* Watch what the player sends. Bare `!port` (and ui/window/gui) toggles the
* window and never leaves the client; every other !port line passes through
* and marks our state stale, because a typed go changes the purse under the
* window. Any other outgoing line stamps the throttle -- the client's rate
* limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwport_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!port' or lower == '!port ui' or lower == '!port window' or lower == '!port gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwp') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 5) == '!port') then
        refresh();
    end
end);

ashita.events.register('command', 'dwport_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Port`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwport' and first ~= '/port') then
        return;
    end

    e.blocked = true;

    --[[
    * `/port sp` opens the window ON the Teleport tab (1.3.0). Which tab to
    * open on is the one thing an argument to this command can usefully mean:
    * everything else about travelling is a click away once the window is up,
    * and `!port` already takes the whole typed grammar (`!port go sp 122`,
    * `!port kazham`).
    *
    * A word the tab strip does not know says so rather than toggling the
    * window at somebody who had asked for something quite specific -- which is
    * what `/port hp 3` used to do, silently.
    --]]
    local wanted = #args > 1 and args[2]:lower() or nil;

    if (wanted ~= nil) then
        if (TAB_LABEL[wanted] == nil) then
            print(chat.header('dwport'):append(chat.message(
                '/port opens the window; /port hp|sg|op|sp|un|vw|rp opens it on that tab. To travel by typing, use !port.')));

            return;
        end

        if (not state.open[1]) then
            openWindow();
        end

        -- After openWindow, which sets its own request from the remembered
        -- tab: the one the player just named wins.
        state.wantTab = wanted;

        return;
    end

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

ashita.events.register('load', 'dwport_load', function ()
    print(chat.header('dwport'):append(chat.message('/port opens the travel window; /port hp|sg|op|sp|un|vw|rp opens it on that tab. Everything it does also works typed as !port commands.')));
end);

-- A login is a new character and a new account view; a zone line changes the
-- purse and the (here) markers. Re-sync either way -- but only once the
-- server has spoken this session (protocol discipline 1: an automatic line
-- against a dead verb is the player saying it in public).
ashita.events.register('packet_in', 'dwport_zonein', function (e)
    if (e.id == 0x000A) then
        state.synced = false;
        state.masks  = EMPTY_MASKS();
        state.spells = { };
        state.runic  = { };
        state.opFees = { };
        state.opFeeRev = state.opFeeRev + 1;
        state.waived   = nil;
        state.waivedRev = state.waivedRev + 1;
        state.gil    = -1;
        state.standing = -1;
        state.fees   = nil;
        state.goQueue   = T{ };

        -- ...except while the protocol banner is up (1.3.0). "Update dwport"
        -- is the only accurate line this window has against a server it cannot
        -- read, protoBad also gags every m|/e| that could write another one,
        -- and a mismatched server deliberately never sets serverSpoke -- so no
        -- zone-in re-ask goes out to bring the banner back either. Replacing
        -- it here left "Loading..." on screen over 121 dark rows for the rest
        -- of the session. Same guard the Refresh button carries.
        if (not state.protoBad) then
            state.status    = ASK_FIRST;
            state.statusBad = false;
        end

        -- Drop any half-read envelope with it. Without this, records still in
        -- flight from before the line -- and 0x000A is a LOGIN as well as a
        -- zone change -- landed on the state that had just been cleared, for a
        -- character who may not even be the same one. An answer to an ask this
        -- reset threw away must not resurrect it.
        state.inbound   = nil;
        state.inboundAt = 0;
        state.staging   = nil;
        state.modelRev  = state.modelRev + 1;

        if (state.serverSpoke) then
            refresh();
        end
    end
end);
