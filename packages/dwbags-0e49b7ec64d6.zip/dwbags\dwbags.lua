--[[
* DriftwoodXI -- dwbags
*
* Every bag on your account, from whichever character you are logged in on.
* Search across all of them, move items between them, and see what each of your
* squad members will be wearing the next time you call them.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no item data of its own, caches nothing to disk, and has no way to
* move an item that the typed command surface does not already have. Every read
* is `!dwq <verb>` and every write is `!dwq send|fetch|equip|use`, which are
* the same server-side functions `!squad send|fetch|equip|use` reach -- the
* only difference is that they answer in compact records under the sender name
* _DWDATA, which this addon parses and blocks before the chat log sees them.
*
* That constraint is deliberate and it is the reason a UI could be shipped at
* all: a bug in here cannot move an item the server would have refused, because
* it is not doing anything the typed command does not do. The ownership check,
* the transaction and the Rare/Ex rules all live in the server's C++ and run
* identically whichever way the command arrived.
*
* WHY THE SERVER DOES NOT SEND ITEM NAMES. It does not need to: this addon is
* inside the client, and the client already has the name, the icon, the level,
* the job mask and the flags of every item in its own DAT resources. Sending
* them would be paying twice, and it is what keeps a packed record inside the
* 150-byte chat buffer the whole protocol has to fit through.
*
* TURN IT OFF AND NOTHING IS LOST. `!squad who`, `!squad bag`, `!squad find`,
* `!squad send`, `!squad fetch`, `!squad gear`, `!squad equip` and `!squad menu`
* all work typed, and `!squad menu` gives you the same operations as
* client-rendered dialogs. This is faster; it is not required.
*
* UPGRADE MARKERS (1.8) render the `h|` records `!dwq hints` answers: a mark
* on any gear slot where something in another of your characters' bags beats
* what this one wears, with the fetch/send recipe one click away. The click
* issues the same typed lines a player would -- never retried -- and a server
* too old to know the verb is detected once and never asked again, so
* deployment order cannot matter.
*
* THE STORAGE TAB (1.9) renders the `y|` and `p|` records `!dwq bagpref`
* answers: which bag each kind of item is put away in when it arrives, a
* wardrobe layout in one click, and the `!dwq tidy` that applies it to what a
* character already holds. Gear now defaults into the mog wardrobes, which are
* the only containers that can hold nothing else -- so it stops competing with
* everything else for the four bags a player actually carries.
*
* The seventeen `p|` rows are per EQUIP SLOT and the groups this draws --
* Weapons, Off-hand, Armour, Trinkets, Jewellery -- are assembled here, from
* those rows. That is on purpose: a group is a way of talking about a layout,
* not a thing the server stores, and a layout whose groups cut across these
* (the owner's own does) has to stay drawable rather than being rounded off to
* the nearest lie. A group whose slots disagree says so and offers the slots.
*
* PLACED FURNITURE (1.9.3) renders item flag bit 16: furniture standing in a
* Mog House layout shows a greyed 'placed' tag where Send/Fetch would be, the
* way a worn item shows 'worn'. The server refuses the transfer either way --
* this only says why BEFORE the click, and what to do about it. A server too
* old to send the bit simply never sets it, and the row keeps its buttons.
*
* THE STACK BUTTON (1.10) is one click over the `!dwq stack` verb: every item
* split across more than one part-stack -- three fire crystals here, four in
* the satchel, two in the safe -- is combined into as few stacks as it can
* be, into the inventory when there is room. Which rows may merge is decided
* entirely in the server's C++ (worn, bazaared, signed and augmented copies
* stay put), so this button, like every other, cannot move anything the typed
* command would not. A server too old to know the verb is detected once off
* its own unknown-verb sentence and the button is not drawn, so deployment
* order cannot matter.
*
* SEND FROM AN ALT (1.11) is the Gear tab's Get-button recipe put on every alt
* row: a Send button beside Fetch that queues the same two typed lines a
* player would send -- fetch into your own inventory, then send on to whoever
* the header's "Send to" names -- one per interval, in order, NEVER retried.
* The item passes through your inventory because that is the only route the
* typed commands have; there is no alt-to-alt verb on the server, and growing
* one for a button would be the moment this addon stopped being a renderer.
* If the fetch is refused the send then refuses on its own terms -- two red
* sentences is noisy, but nothing moves that the typed pair would not have
* moved. The button is not drawn when "Send to" names the character the row
* belongs to (that transfer is a no-op with extra steps) or when it names
* nobody.
*
* QUICKER AUTO-REFRESH (1.11.1). After a transfer click, the visible tab's
* re-ask now enters the throttled queue BEFORE the `who`/`find` refresh
* instead of after it, so the rows on screen update one send interval after
* the action's last line rather than up to three. The commands and the 1.2s
* throttle are unchanged -- only the order moved; see refetchVisible.
*
* USE YOUR OWN ITEMS (1.12) closes the window's oldest asymmetry: every alt's
* potion had a Use button and your own did not. Only scrolls did, because the
* server refused everything else on a self row with "use it from your own
* inventory" -- correct about where the work belongs and useless to the player
* holding the mouse. The server now hands a self use to the engine's own item
* state machine, the same one the game's item menu drives, so the button opens
* the same door from the window already on screen: real cast time, real
* interruption, the item's own refusal when it would do nothing. The only rule
* this side keeps is WHICH BAG -- the engine uses items out of the inventory
* and the wardrobes and nowhere else, so a potion in a satchel draws no button
* rather than a refusal. See useButton.
*
* MANUAL GEAR MODE (1.16) is the Gear tab's second face, for the player who
* found the automatic 'Instead' column confusing: pick a slot on the left,
* and the right pane lists EVERYTHING that character's own bags hold that
* fits the slot -- never another character's bags, never a transfer -- with
* the same hover card every other item row has. Clicking a piece issues the
* same `!dwq equip` a click in Automatic does, so a manual pick IS a pin and
* Auto undoes it; the two modes are two renderings of one server-side fact,
* not two features. The full per-slot list rides the slot argument `!dwq
* gear <who> <slot>` grew for it -- same k| record, deduped by itemid, cap
* lifted to 60 -- and a server too old to know the argument simply answers
* the plain capped listing, so the pane degrades to the best four rather
* than breaking (deployment order cannot matter, the h|/p| rule).
*
* OPTIMIZE FROM WAREHOUSE (1.21) is the Gear tab's third face and the answer
* to the one store nothing gearing a member had ever read. The other two read
* that character's own bags and the upgrade markers read the account's other
* CHARACTERS; between them sat a thousand-row warehouse full of exactly the
* spare gear this is about, so a player who keeps spares where spares belong
* was told, correctly and uselessly, that nothing on the account beat what the
* member wore.
*
* It renders the `u|` records `!dwq restock` answers: the best stored piece for
* each slot, scored by the same scorer the other two faces use, with what it
* would replace and by how much. IT IS A PLAN AND NOT A BUTTON THAT FIRES --
* Apply is a separate press, `!optimizegear preview`'s precedent, and the right
* call here because one click can move a dozen irreplaceable things out of
* storage at once.
*
* THE RECORD CARRIES A ROW ID RATHER THAN AN ITEM ID, and that is the whole
* reason the server grew a verb for this instead of reusing take-then-send: two
* stored copies of one item can differ by their augments, and `send` resolves by
* item id, so a player holding a plain copy of what the warehouse holds
* augmented would have had their own plain one delivered under the augmented
* one's name. Both buttons here name the row.
*
* DELIVERING IS EQUIPPING, which is why there is no third step: an alt-trust
* dresses itself out of its bags every time it is called, and a piece this pane
* names is by construction the best thing in the bag for its slot the moment it
* lands. Pinning it would be strictly worse -- a pin freezes the slot against
* the next upgrade. The status line says when to call the member again.
*
* A server too old to know the verb is detected once off its own unknown-verb
* sentence (or off the Lua tier's "planner is not in this build", for a map
* whose scripts are newer than its binary) and the face says so instead of
* asking again, so deployment order cannot matter in either direction.
*
* ANSWERS BUILD ASIDE AND COMMIT WHOLE (1.24, the owner's "the window resets
* and scrolls to the top on every click" report). Every per-character
* section used to be WIPED at the answer's d| and refilled record by record
* -- so for the frames between the wipe and the refill the table drew zero
* rows, ImGui clamped its scroll to the top of an empty list, and every
* Send, Fetch, Use or Stash (each of which re-asks the tab) threw the player
* back to the top of a thousand-row bag. The rows now build in a staging
* table and replace the section at z|, so the list on screen is never empty
* between two answers and the scroll position survives the refresh. Names
* and DAT flags are cached per item id (the resource manager was asked three
* times per row per frame), and the Bags tab grew a container filter, a
* find-as-you-type box and a 300-row draw page -- the find still searches
* every page; only what is submitted to ImGui is bounded.
*
* `who` IS NOT THIS ADDON'S ENVELOPE ALONE (1.25). squad_storage.lua's
* roster answers `!dwq who` -- read here, on _DWDATA -- and `!dws who` --
* read by dwsquad, on _DWSDATA -- out of ONE function, and the records
* dwsquad needed were added to it additively: `t|` the trust engage mode,
* `f|` the follow distance, `g|` the alliance and pending-invite state. Two
* of those letters were already spoken for here, `f|` as a find hit and `g|`
* as a worn gear piece, and the gear one is not theoretical: the group
* record opens with 0 or 1, the gear record opens with a charid, and a
* charid is a MySQL auto-increment -- so the first character ever created on
* the server IS charid 1. Select that character, stand in an alliance, and a
* roster read wrote a phantom `main` slot into the Gear tab. Records are now
* accepted only inside an envelope known to carry them (RECORD_ENVELOPES),
* one-sidedly: a verb this addon has no section for keeps exactly today's
* permissive behaviour, so a newer server can still grow a record under one.
*
* THE VIEW IS BUILT ONCE PER ANSWER (1.25). `modelRev` moves when -- and only
* when -- an answer commits, a different character is selected or a login
* empties everything; the Bags tab's filter, sort and totals, the roster's
* sorted copy and the container list all key their cache on it. Row-level
* work went the same way: the widget ids, the name cell and the count cell
* are built once per row per answer instead of six string.formats per row
* per frame, and the augment argument for a card is worked out for the row
* under the mouse rather than for all three hundred.
*
* AND THE QUEUE HAS A CEILING (1.25). Reads collapse, so its growth is all
* clicks; the drain is one line per 1.2 seconds and is held shut entirely
* while the client is zoning. Clicking through a zone line built a queue that
* went on acting for minutes against rows that had since moved. Sixty lines,
* and past that the click is refused AND SAID -- a transfer that silently
* does not happen is the one failure this window must never have. The
* fetch-then-send pair is admitted or refused as a unit, for issueChained's
* reason arriving through the other door.
*
* THE CATEGORY FILTER (1.26) is the owner's ask of 2026-09-07 -- "have all
* scrolls grouped together, all ingredients, all gear" -- and it is a fourth
* narrowing on the Bags tab rather than a grouping of the list: a player
* hunting for gear wants the other nine hundred rows GONE, not sorted after.
* Four buckets, decided entirely on this side out of the client's own item
* resource (the server is not asked and has nothing to add), applied in order:
* a scroll is the DAT flag FLAG_SCROLL and not a name match; gear is DAT type
* 4 or 5; materials are DAT types 1, 3 and 8, the three a synth draws from;
* and Etc. is everything the first three do not claim. The middle two are
* dwwarehouse's own Weapons/Armor and Materials chips, deliberately -- two
* windows onto one account must not disagree about what a piece of gear is.
* The rule is written out in full above categoryOf.
*
* AND IT IS THE ONE THING THIS ADDON REMEMBERS. The container filter and the
* find box are questions about one character's bags and die with the login;
* a category is a habit, and re-picking it every session is the tax that
* makes a filter go unused. It is the only field in the settings file.
*
* THE AUTOMATON (1.27) is the owner's ask of 2026-09-10 and it is two halves
* of one thing: what an alt's puppet is made of, and what it is called.
*
* UNLOCK is a button on any automaton part sitting in an ALT's bag -- a frame,
* a head or an attachment, the 8192..8703 family. It issues `!dwq unlock`,
* which does exactly what trading the part to Tateeya in Aht Urhgan Whitegate
* does: the part is used up and the bit lands on that character's automaton
* record. It matters more than it sounds, because the squad's automaton editor
* reads unlocks ACCOUNT-WIDE -- one part unlocked on one alt is a part every
* squad puppetmaster can build with. On your OWN row there is no button and a
* greyed "Tateeya" instead: yours is the game's to fit, and it has the real
* cutscene behind it.
*
* THE NAME is a combo and an Apply in the Gear tab, for the selected alt.
* Retail asks for an automaton's name once, in the "No Strings Attached"
* cutscene, so an alt you have never played PUP on has no name at all and
* never will -- there is no second time to be asked. The names in the combo
* are the SERVER's, arriving as `r|` records off its own pet_name table; this
* file holds none of them, which is why a name added there is offered without
* the addon being re-packaged. It is also the one place this window asks the
* server for a string instead of resolving an id against the client's DATs,
* and that is because the client has no resource for these at all. Your own
* automaton is not renameable here, for the reason it is not fittable here.
*
* Both are latched off the server's own unknown-verb sentence and simply not
* drawn against a server that does not have them, the rule every control added
* since 1.8 follows: deployment order must not matter in either direction.
*
* SEND ALL TO WH (1.28) is the owner's ask of 2026-09-11: the per-row Stash
* button, applied to a whole container. A combo picks the bag -- a pick of its
* own, NOT the view filter above it, because that one has an "All bags" answer
* and this one must not -- and the button empties it into the account
* warehouse for whichever character is selected, the alt arm included.
*
* THREE THINGS MAKE IT SAFE TO CLICK, and none of them is decided here:
*
*   1. THE CLICK NEVER MOVES ANYTHING. It types a DRY RUN, `!dwq stashall
*      <who> <bag#> count`, and the server answers with a `q|` verdict: how
*      many of that bag's items its own eligibility screen would accept, how
*      many it would leave, how many slots that needs and how many are free.
*      The confirmation is built from those numbers. A count worked out on
*      this side would be a different number -- worn, bazaared and linkshell
*      rows are invisible to a row list -- and a confirmation that names the
*      wrong count is worse than no confirmation.
*   2. ALL OF IT OR NONE OF IT. The server refuses the whole sweep when it
*      does not fit, so this window never has to explain a bag that is half
*      empty. When the verdict says it does not fit, the popup says how many
*      slots short it is and offers no send button at all.
*   3. THE MOVE IS TYPED BY THE POPUP, never by the button -- the Trash rule,
*      ported with its window for the same reasons: a popup owned by a tab
*      cannot open for another one, and BeginTable pushes an ID scope a popup
*      cannot straddle.
*
* Its unsupported latch is its OWN and not the per-row Stash's: two verbs, two
* bindings, and a binary carrying one without the other must lose one button
* rather than both.
*
* THE TICK, THE BATCH AND THE MERCHANT (1.30) answer the owner's Discord
* thread of 2026-09-14 -- "Can we get a way to trash multiple items at once in
* the warehouse and bags?" -- and the half of it nobody had asked for out loud:
* most of what a player wants gone is worth gil.
*
* THE TICK IS A CELL, NOT AN ITEM ID, and that is the difference between this
* selection and dwwarehouse's Deposit ticks. A shelf row is one pile of one
* item; a bag row is a CELL, and two cells of the same crystal are two things
* a player may want to treat differently. So the key is `<charid>:<loc>:<slot>`
* and the tick follows the row, not the name. It is per character and is
* dropped whole when the selection moves, when a batch is sent, and on a login
* -- a tick that outlived the bag it was pointing at would be a click aimed at
* whatever moved into that cell.
*
* A BATCH IS ONE QUESTION AND MANY CELLS. `Trash Selected (N)` and `Vendor
* Selected (N)` ask ONCE, with the count and (for a sale) the gil in the
* sentence, and then type `!dwq trashmany <who> <cells>` / `!dwq vendor
* <cells>` -- packed to the client's own 128-byte chat line, so forty ticked
* rows are six lines rather than forty, and every cell is answered by the
* server with a `b|` verdict of its own. The single-row Trash button and its
* confirmation are untouched to the byte; the single-row Sell button types the
* same batch verb with one cell in it, so there is no second sale path to
* disagree with the first.
*
* NOTHING HERE DECIDES WHAT ANYTHING IS WORTH. The price beside a row is the
* server's `v|` record -- item id to gil, the merchant price off the same item
* template `0x084_shop_sell_req.cpp` quotes from -- and 0 in that record means
* no merchant will buy it. An item id the server has never priced is not
* claimed to be worthless: it is simply not sellable from here, and a server
* that has never sent a price at all draws no Vendor controls whatsoever.
* A price is a property of the item and not of the copy, so what arrives is
* kept for the session and a re-read costs nothing.
*
* SELLING IS THE CALLER'S OWN BAGS ONLY, because gil is credited into the
* caller's own inventory and an offline alt has no inventory to be paid into.
* The button is simply not drawn on an alt's row, with the reason on hover --
* the same before-the-click courtesy `worn`, `placed` and `priced` get.
--]]

addon.name    = 'dwbags';
addon.author  = 'DriftwoodXI';
addon.version = '1.32.1';
addon.desc    = 'Account-wide bag browser, item transfer and squad gearing for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load.
*
* This addon is loaded from the launcher's boot script, which runs long before
* the client has a rendering device -- and `d3d.get_device()` at file scope
* makes the whole addon fail to load when it answers nothing. That is the
* difference between `/addon load dwbags` working by hand and the same line in
* driftwood-default.txt appearing to do nothing at all. Nothing here needs a
* device until the first icon is drawn, by which point there certainly is one.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server uses
-- it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

-- Equip slot ids, in the order a player reads them.
local SLOT_NAMES = {
    [0]  = 'main',  [1]  = 'sub',   [2]  = 'ranged', [3]  = 'ammo',
    [4]  = 'head',  [5]  = 'body',  [6]  = 'hands',  [7]  = 'legs',
    [8]  = 'feet',  [9]  = 'neck',  [10] = 'waist',  [11] = 'ear1',
    [12] = 'ear2',  [13] = 'ring1', [14] = 'ring2',  [15] = 'back',
};

--[[
* The per-slot widget ids, built once at load (1.25).
*
* Sixteen slots and five buttons apiece, every one of them a string.format
* inside the render pass -- for labels that are a pure function of the slot
* number and cannot change for the life of the addon. ImGui needs the same
* bytes every frame for a click to stay attached to the same widget, which
* is the other half of why building them fresh was pointless work.
--]]
local SLOT_IDS = { };

for slotId = 0, 15 do
    SLOT_IDS[slotId] = {
        empty   = string.format('%s: --##mslot_%d', SLOT_NAMES[slotId], slotId),
        auto    = string.format('Auto##auto_%d', slotId),
        mauto   = string.format('Auto##mauto_%d', slotId),
        mnone   = string.format('Leave empty##mnone_%d', slotId),
        restock = string.format('Send##restock_%d', slotId),
    };
end

-- Container ids, matching CONTAINER_ID in the server's item_container.h.
local LOC_NAMES = {
    [0]  = 'Inventory', [1]  = 'Mog Safe',  [2]  = 'Storage',   [3]  = 'Temp',
    [4]  = 'Locker',    [5]  = 'Satchel',   [6]  = 'Sack',      [7]  = 'Case',
    [8]  = 'Wardrobe',  [9]  = 'Mog Safe 2',[10] = 'Wardrobe 2',[11] = 'Wardrobe 3',
    [12] = 'Wardrobe 4',[13] = 'Wardrobe 5',[14] = 'Wardrobe 6',[15] = 'Wardrobe 7',
    [16] = 'Wardrobe 8',[17] = 'Recycle Bin',
};

--[[
* Bag routing (`p|` and `y|`).
*
* A class is one destination the server stores: class 0 is "not equipment" and
* class N is equip slot N - 1. `loc` is a container id, or ANY_WARDROBE for
* "any of them, filling in order".
--]]
local ANY_WARDROBE = 254;

local function classOfSlot(slot)
    return slot + 1;
end

-- The groups the tab draws. Assembled here rather than sent, because a group is
-- a way of TALKING about a layout and the server stores slots -- see the header.
local BAG_GROUPS = {
    { name = 'weapons',   label = 'Weapons',           slots = { 0 } },
    { name = 'offhand',   label = 'Off-hand & ranged', slots = { 1, 2, 3 } },
    { name = 'armour',    label = 'Armour',            slots = { 4, 5, 6, 7, 8 } },
    { name = 'trinkets',  label = 'Trinkets',          slots = { 9, 10, 15 } },
    { name = 'jewellery', label = 'Jewellery',         slots = { 11, 12, 13, 14 } },
    { name = 'items',     label = 'Everything else',   slots = { }, other = true },
};

-- The combo id per group, built once (1.25): it was a string.format per
-- group per frame for a label fixed at load.
for _, group in ipairs(BAG_GROUPS) do
    group.combo = string.format('##dest_%s', group.name);
end

-- Destination names exactly as `!dwq bagpref` parses them, in the order a
-- player reads them. `wardrobes` is the pseudo-target.
local BAG_DESTINATIONS = {
    { name = 'wardrobes', loc = ANY_WARDROBE, label = 'Any wardrobe' },
    { name = 'wardrobe',  loc = 8,  label = 'Wardrobe' },
    { name = 'wardrobe2', loc = 10, label = 'Wardrobe 2' },
    { name = 'wardrobe3', loc = 11, label = 'Wardrobe 3' },
    { name = 'wardrobe4', loc = 12, label = 'Wardrobe 4' },
    { name = 'wardrobe5', loc = 13, label = 'Wardrobe 5' },
    { name = 'wardrobe6', loc = 14, label = 'Wardrobe 6' },
    { name = 'wardrobe7', loc = 15, label = 'Wardrobe 7' },
    { name = 'wardrobe8', loc = 16, label = 'Wardrobe 8' },
    { name = 'inventory', loc = 0,  label = 'Inventory' },
    { name = 'satchel',   loc = 5,  label = 'Satchel' },
    { name = 'sack',      loc = 6,  label = 'Sack' },
    { name = 'case',      loc = 7,  label = 'Case' },
    { name = 'safe',      loc = 1,  label = 'Mog Safe' },
    { name = 'safe2',     loc = 9,  label = 'Mog Safe 2' },
    { name = 'locker',    loc = 4,  label = 'Locker' },
};

-- Layout ids, matching kLayout* in the server's alt_storage.cpp.
local BAG_LAYOUTS = {
    { id = 0, name = 'category', label = 'By category',
      blurb = 'Weapons, off-hand, armour, trinkets and jewellery each get a wardrobe.' },
    { id = 1, name = 'slot',     label = 'By slot',
      blurb = 'Main / head+neck+ears / body+hands+rings / back+waist+legs+feet / sub+ranged+ammo.' },
    { id = 2, name = 'simple',   label = 'Any wardrobe',
      blurb = 'All gear into the wardrobes, filling them in order.' },
    { id = 3, name = 'off',      label = 'No wardrobes',
      blurb = 'Everything into inventory, satchel, sack and case, as it was before.' },
};

-- The button id per layout, built once, for BAG_GROUPS' reason.
for _, layout in ipairs(BAG_LAYOUTS) do
    layout.button = string.format('%s##layout_%d', layout.label, layout.id);
end

-- Wardrobe container ids are 8 and 10..16 -- 9 is the second mog safe, sitting
-- in the middle of the run.
local function isWardrobeLoc(loc)
    return loc == ANY_WARDROBE or loc == 8 or (loc >= 10 and loc <= 16);
end

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Item flag bits, as the server packs them.
local ITEM_EQUIPPED  = 1;
local ITEM_AUGMENTED = 2;
local ITEM_BAZAARED  = 4;
local ITEM_PLACED    = 16;  -- furniture standing in a Mog House layout

-- Client DAT item flags, the same bits the server's item_basic carries. Read
-- from the client's own resources (like names and icons are), so the wire
-- format did not have to change to grow a Use button. The server re-checks
-- usability on `!dwq use` regardless -- this only decides whether the button
-- is worth drawing.
--
-- FLAG_SCROLL (0x0080) was named here too until 1.12, when the self row stopped
-- singling scrolls out: every scroll in item_basic.sql carries @FLAG_SCROLL and
-- @FLAG_CANUSE together, so the Use test covered both and there was no second
-- rule to keep in step with the server's. It is named again in 1.26 because the
-- category filter asks a different question of the same bit -- "is this a
-- scroll", not "can this be used" -- and only this bit answers that one.
local FLAG_CANUSE = 0x0200;
local FLAG_SCROLL = 0x0080;

-- Cached per item id (1.24): the DAT never changes under a running client,
-- and every row asked this once per frame for each of its buttons.
local datFlagCache = { };

local function datFlagsOf(itemId)
    local cached = datFlagCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item  = AshitaCore:GetResourceManager():GetItemById(itemId);
    local flags = item ~= nil and item.Flags or 0;

    datFlagCache[itemId] = flags;

    return flags;
end

--[[
* THE CATEGORY RULE (1.26), WRITTEN OUT ONCE.
*
* Four buckets over a thousand rows, decided ENTIRELY on this side: every row
* carries an item id, the client already holds that item's DAT resource, and
* that resource carries both the flag bits item_basic.sql packs and the DAT's
* own `Type`. The server is neither asked nor told.
*
* THE ORDER MATTERS, and it is an order rather than a set because the first
* test overlaps the last:
*
*   Scrolls   -- the DAT flag FLAG_SCROLL (0x0080). NOT a name match: "Scroll
*                of Cure" is a name, a name is a language, and the bit is what
*                item_basic.sql sets on every scroll it ships. A Scroll of
*                Instant Reraise carries it too, which is right -- the bucket
*                is scrolls, not spells. Tested FIRST because a scroll is also
*                a usable item and would otherwise fall through to Etc.
*   Gear      -- DAT type 4 (weapon) or 5 (armour): dwwarehouse's Weapons and
*                Armor chips exactly, so the account's two item windows cannot
*                disagree about what gear is. Ranged weapons and ammunition
*                are type 4 and are gear here.
*   Materials -- DAT type 1 (general item), 3 (fish) or 8 (crystal), which is
*                dwwarehouse's Materials chip: the three types a synth draws
*                from. Ores, logs, hides, meat, fish, crystals and clusters
*                land here, and so does anything else the client files as a
*                plain item.
*   Etc.      -- everything the three above do not claim: food and medicine
*                (the client has ONE usable type for both, so a Food bucket
*                would invent a distinction the DAT does not make), key items,
*                furnishings, currency, linkshells, and anything typed in a
*                way this window does not name.
*
* Four and not the client's whole type table on purpose: a filter that needs a
* legend is a filter nobody uses. The combo says which bucket is on, and every
* row outside it is simply not drawn.
--]]
local GEAR_TYPES     = { [4] = true, [5] = true };
local MATERIAL_TYPES = { [1] = true, [3] = true, [8] = true };

-- Cached per item id for datFlagCache's reason: the DAT cannot change under a
-- running client, and the filter asks this once per row per rebuild.
local datTypeCache = { };

local function datTypeOf(itemId)
    local cached = datTypeCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);

    -- tonumber and not a bare read: these are table keys below, and a numeric
    -- string silently matches no integer key at all.
    local kind = item ~= nil and (tonumber(item.Type) or 0) or 0;

    datTypeCache[itemId] = kind;

    return kind;
end

-- The whole rule, in one pure function -- an item id in, one of the four
-- bucket names out -- so the harness drives it directly instead of inferring
-- it from a drawn list.
local function categoryOf(itemId)
    if (bit.band(datFlagsOf(itemId), FLAG_SCROLL) ~= 0) then
        return 'scrolls';
    end

    local kind = datTypeOf(itemId);

    if (GEAR_TYPES[kind]) then
        return 'gear';
    end

    if (MATERIAL_TYPES[kind]) then
        return 'materials';
    end

    return 'etc';
end

--[[
* The five choices, in the order the combo lists them.
*
* `all` is not a bucket an item can BE -- categoryOf never returns it -- it is
* the absence of the filter, which is why the places that read the setting test
* for it by name and never by asking categoryOf about a row.
--]]
local BAG_CATEGORIES = {
    { name = 'all',       label = 'All' },
    { name = 'scrolls',   label = 'Scrolls' },
    { name = 'gear',      label = 'Gear' },
    { name = 'materials', label = 'Materials' },
    { name = 'etc',       label = 'Etc.' },
};

-- The widget id per choice, and the lookup by name, built once at load: the
-- BAG_GROUPS hoist (1.25), for labels fixed at load in a combo that rebuilds
-- every frame it is open.
local BAG_CATEGORY_BY_NAME = { };

for _, entry in ipairs(BAG_CATEGORIES) do
    entry.id = string.format('%s##dwbags_cat_%s', entry.label, entry.name);

    BAG_CATEGORY_BY_NAME[entry.name] = entry;
end

-- The stored name, or 'all' for anything this build does not know. The
-- settings file is a text file a player can edit, and an unknown bucket would
-- filter every row away with no way back but the combo.
local function bagCategoryName(name)
    return BAG_CATEGORY_BY_NAME[tostring(name)] ~= nil and tostring(name) or 'all';
end

-- Character flag bits.
local CHAR_ONLINE = 1;
local CHAR_LOCKED = 2;
local CHAR_SELF   = 4;

-- The upgrade-marker colour, distinct from the pin's amber and the error red.
-- All of these live in dwtheme and follow the launcher's Appearance theme.
local COLOR_HINT = theme.colors.hint;

--[[
* THE STATIC TOOLTIPS, IN ONE TABLE (1.25).
*
* Every hover sentence whose text does not depend on a row, a name or a
* count lives here rather than inline. Two reasons, and the second is the
* one that mattered: they can be read as a set -- which is how you notice
* that 'placed' and 'priced' explained themselves and 'worn', the commonest
* of the three by far, did not -- and the harness can assert a tip exists
* for a control by name instead of by hunting for a string literal in the
* render body. Anything carrying an item, a character or a quantity is
* still formatted where it is drawn, because it is not static.
--]]
local TIPS = {
    refresh    = 'Ask the server for all of it again -- the character list, the tab\n'
              .. 'you are looking at, and any search results still on screen.',
    queued     = 'Commands waiting to go out. The client rate-limits chat, so this\n'
              .. 'window sends one line every 1.2 seconds and holds the rest --\n'
              .. 'nothing is dropped, it just arrives in order.',
    status     = 'The last thing the server said about a transfer. Red is a refusal\n'
              .. 'and it names the rule; it stays until something replaces it.',
    sendTo     = 'Where the Send buttons send. This is NOT the character whose bags\n'
              .. 'you are reading -- that is the list on the left.',
    wholeStack = 'On: a Send, Fetch, Stash or Trash moves the entire stack in that\n'
              .. 'cell. Off: it moves the number in the box beside this.',
    sendQty    = 'How many to move when "Whole stack" is off. A row holding fewer\n'
              .. 'than this moves what it has; the floor is 1.',
    bagLoc     = 'Show one container instead of all of them. Local to this window --\n'
              .. 'the server is not asked again.',
    bagFind    = 'Narrow the list by name. Searches every page.',
    stashAllBag = 'Which container "Send All to WH" would empty. This is a separate\n'
              .. 'pick from the filter beside it on purpose -- one decides what you\n'
              .. 'are looking at, the other decides what moves.',
    stashAll   = 'Send EVERY item in the container on the left into the account\n'
              .. 'warehouse, in one go. It asks first, and the question carries\n'
              .. 'the count the SERVER worked out.\n\n'
              .. 'All of it or none of it: if the warehouse has not got room for\n'
              .. 'every item, nothing moves at all and you are told how many\n'
              .. 'slots it would have needed.\n\n'
              .. 'Left where it is: anything worn, priced in a bazaar, placed in\n'
              .. 'a Mog House, in use, gil, and linkshell pearls.',
    bagClear   = 'Clear the name filter.',
    bagSort    = 'The order of the rows below. Local to this window.',
    bagCat     = 'Show one kind of item instead of all of them: scrolls, gear\n'
              .. '(weapons and armour), materials (crafting stock, crystals and\n'
              .. 'plain items) or Etc. (food, medicine, furnishings, key items --\n'
              .. 'everything the other three do not claim). The server is not\n'
              .. 'asked, and this is the one control here that is remembered\n'
              .. 'between sessions.',
    bagTotals  = 'Every container this character owns, added up: cells used, cells\n'
              .. 'they have, and what is free across all of them.',
    -- 1.30, the tick and the two batches.
    tick       = 'Tick this bag cell. Ticked rows can be thrown away or sold all\n'
              .. 'at once with the buttons above the list. A tick follows the\n'
              .. 'CELL, not the item, so two stacks of the same thing are two\n'
              .. 'separate ticks -- and every tick is dropped when you look at\n'
              .. 'another character.',
    pickAll    = 'Tick every row the filters above are currently showing.',
    pickNone   = 'Untick everything, on this character.',
    pickInvert = 'Tick what is not ticked and untick what is, over the rows the\n'
              .. 'filters are currently showing.',
    pickSame   = 'Widen the ticks to every row of the same item: tick one stack\n'
              .. 'of fire crystals and this ticks the rest of them, wherever\n'
              .. 'they are in the bags being shown.',
    pickCount  = 'What is ticked right now, across every container of this\n'
              .. 'character -- not just the rows the filters are showing -- and\n'
              .. 'what a merchant would pay for the sellable part of it.',
    trashMany  = 'Throw away every ticked row, whole stacks, in one go. Asks once\n'
              .. 'with the count. The server answers for every row separately,\n'
              .. 'so a row it refuses (worn, priced, in use) stays where it is\n'
              .. 'and says why in the chat log -- nothing is lost quietly.',
    vendorMany = 'Sell every ticked row a merchant will buy, whole stacks, for the\n'
              .. 'price the shops pay. Asks once with the gil. Rows no merchant\n'
              .. 'buys, and rows in an alt\'s bags, are skipped and counted in\n'
              .. 'the question.',
    sellFilter = 'Show only what a merchant will buy, or only what none will.\n'
              .. 'The prices are the server\'s -- the same ones the shops pay.',
    value      = 'What a merchant pays for this whole row. "--" means it cannot\n'
              .. 'be sold from here; hover it for the reason.',
    pagePrev   = 'The previous 300 rows.',
    pageNext   = 'The next 300 rows.',
    -- THE REASON A GREYED ARROW IS GREY LIVES HERE, on the counter between
    -- them, and not on the arrow itself: ImGui reports no hover at all for a
    -- disabled item unless the hover test is asked to allow it, and that
    -- flag is the newest-generation API this suite deliberately does not use
    -- -- so a SetTooltip written after the EndDisabled of a greyed control
    -- is dead code that reads exactly like the courtesy the house asks for.
    -- The harness walks its flow log and refuses that shape.
    pager      = 'Each page is 300 rows. The arrow for the end you are already\n'
              .. 'at is greyed; the filter above still searches every page.',
    showing    = 'Only this many rows are handed to the drawing code at once --\n'
              .. 'the filter above still searches every page.',
    findBox    = 'Type at least two letters and press Enter. Searches every\n'
              .. 'container on every character on the account, including ones\n'
              .. 'that have never been logged in on this PC.',
    findCopy   = 'Copy the results below to the clipboard, one line each --\n'
              .. 'ready to paste into a tell, a note or a bug report.',
    wornSelf   = 'You are wearing this. Take it off in the game\'s own equipment\n'
              .. 'menu, and it can be sent, stashed or thrown away like any\n'
              .. 'other row.',
    wornAlt    = 'This character is wearing it, and gearing is automatic -- so it\n'
              .. 'cannot be moved while it is the best thing they own for the\n'
              .. 'slot. Pin something else in the Gear tab to free it.',
    pinned     = 'Pinned by hand: the scorer is not choosing this slot. The Auto\n'
              .. 'button beside it hands the slot back to the scorer.',
    gearAuto   = 'Forget the pin on this slot and let the scorer choose again.',
    noOwner    = 'The character list has not caught up with this row yet -- every\n'
              .. 'command here names a character, and this one has no name to use.\n'
              .. 'Press Refresh if it does not clear on its own.',
    tabBags    = 'Every container the selected character owns, with a Send, Fetch,\n'
              .. 'Use, Stash or Trash on each row.',
    tabGear    = 'What this character will be wearing the next time you call it,\n'
              .. 'and everything it could wear instead.',
    tabFind    = 'One search across every container on every character on the\n'
              .. 'account -- including characters that have never been logged in\n'
              .. 'on this computer.',
    tabBox     = 'Things that could not be written straight into the bag -- the\n'
              .. 'character was logged in, or every bag was full. They arrive the\n'
              .. 'next time you call that character.',
    tabStorage = 'Which bag each kind of item is put away in when it arrives, and\n'
              .. 'the one button that applies that layout to what is already held.',
    puppetSelf = 'An automaton part. Yours is fitted by trading it to Tateeya in\n'
              .. 'Aht Urhgan Whitegate -- the game does that one, with the real\n'
              .. 'cutscene. Send it to an alt and their row has an Unlock button.',
    puppetAlt  = 'Fit it to this character\'s automaton, exactly as trading it to\n'
              .. 'Tateeya would: the part is used up and the bit is theirs.\n'
              .. 'Unlocks are read account-wide, so every squad puppetmaster\n'
              .. 'can then build with it. They must not be logged in.',
    autoName   = 'What this character\'s automaton is called. Retail asks once, in\n'
              .. 'a cutscene, so an alt you have never played PUP on has no name\n'
              .. 'at all. The squad picks it up the next time their automaton is\n'
              .. 'activated.',
    autoApply  = 'Write the chosen name to this character. They must not be\n'
              .. 'logged in.',
    autoSelf   = 'The game\'s own quest names yours. This one only renames an\n'
              .. 'alt\'s automaton.',
};

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged, so a
    -- stale row cannot survive a refresh.
    chars     = T{ },
    selected  = nil,        -- charid
    bags      = T{ },       -- [loc] = { size, used, items = {} }
    gear      = T{ },       -- [equipslot] = record
    options   = T{ },       -- [equipslot] = { record, ... }
    refused   = T{ },       -- [equipslot] = { { itemid, reason }, ... } -- owned, but the door said no (w|)
    hints     = T{ },       -- [equipslot] = the best upgrade found account-wide
    box       = T{ },
    finds     = T{ },
    findQuery = '',

    -- The query the rows in `finds` are an answer TO (1.25), so the Find tab
    -- can tell "still searching" from "searched, and nothing matched". Set
    -- only where a find envelope commits.
    findAnswered = '',

    -- Bag routing. `prefs` is [class] = { loc, isdefault, free } and `layout` is
    -- the named layout id, or 255 for one the player has edited by hand.
    prefs     = T{ },
    layout    = 255,

    -- The verb whose response is currently arriving. Records are only accepted
    -- between a `d|` and its `z|`, so a line that arrives on its own -- a
    -- response to something typed by hand, say -- cannot half-fill the UI.
    inbound   = nil,
    status    = 'Press Refresh.',
    statusBad = false,      -- draw the banner as an error rather than a note
    -- (`tab` lived here until 1.25 and was read by nothing: the tab bar has
    -- always been ImGui's own state, and a second copy of it that nobody
    -- consults reads like a setting the window remembers and does not.)
    reported  = false,      -- a render error is worth saying once, not per frame

    search    = T{ '' },
    sendQty   = T{ 1 },
    sendAll   = T{ true },  -- move the whole stack unless told otherwise
    sendTo    = nil,        -- charid a Send goes to; see the header combo

    -- The Gear tab's three faces (1.16, 1.21). 'auto' is the scorer's column
    -- exactly as it has always been; 'manual' is the per-slot picker;
    -- 'warehouse' is the restock plan. manualSlot is an equip slot id, or nil
    -- until one is chosen. Session state only -- the server stores pins, not
    -- which rendering the player prefers.
    gearMode   = 'auto',
    manualSlot = nil,

    -- The restock plan (1.21): [equipslot] = one `u|` record, the best thing in
    -- the ACCOUNT WAREHOUSE for that slot. Keyed by slot for the same reason
    -- `hints` is -- one answer per slot is what the table draws -- and replaced
    -- wholesale by its own envelope like every other section.
    --
    -- `restockRow` is the ROW ID, and it is the field that makes this section
    -- different from every other one here: two stored copies of one item id can
    -- differ by their augments, so the click has to name the row rather than
    -- the item. The server refuses to be addressed any other way.
    restock    = T{ },

    -- The Bags tab's own narrowing (1.24): one container, or nil for every
    -- bag; and a find-as-you-type box over the names. Both local -- the
    -- server is never asked about either -- and both reset the draw page.
    bagLoc     = nil,
    bagFind    = T{ '' },

    -- THE BULK STASH'S OWN PICK (1.28), and it is deliberately NOT `bagLoc`.
    -- The narrowing above is a question about what to LOOK at and has an
    -- "All bags" answer; this one names a container to EMPTY and has no such
    -- answer -- "send every bag" is a different, much larger promise than
    -- the one the owner asked for, and reading a view filter as a destructive
    -- target is exactly the kind of overlap a mis-click turns into a mistake.
    -- nil means "nothing picked yet"; the tab defaults it to the character's
    -- first container the first time it draws one.
    --
    -- `stashAllAsk` is the pending confirmation, filled by the server's dry
    -- run (the q| record) and nil the rest of the time -- the trashAsk shape,
    -- with the numbers coming from the server rather than from a row.
    stashAllBag = nil,
    stashAllAsk = nil,

    -- And the row order (1.25): 'bag' is the wire's own order (container,
    -- then cell), 'name' is alphabetical, 'count' puts the biggest stacks
    -- first. Local like the two above -- the server sorts nothing for this
    -- -- and changing it resets the draw page for the same reason they do.
    --
    -- IT SURVIVES A LOGIN AND THEY DO NOT, deliberately: a container filter
    -- and a name filter are questions about ONE character's bags and mean
    -- nothing on the next one, while an order is a preference about how
    -- this player likes to read a list.
    bagSort    = 'bag',

    -- THE ALT'S AUTOMATON (1.27). `autoNames` is every name the server will
    -- accept -- `{ id, name }` pairs read out of its pet_name table, never a
    -- list held here -- and `autoName` is what the selected character's
    -- automaton is called right now (`id = 0`, empty name: never named, which
    -- is every alt, because the naming cutscene is asked once in a quest a
    -- player runs on one character). Both are replaced wholesale by an
    -- `autoname` answer like every other section.
    --
    -- `autoPick` is the combo's own state and is NOT the server's: it is what
    -- the player has highlighted but not yet applied, so it is cleared when
    -- the selection moves and when an answer lands.
    autoNames = T{ },
    autoName  = T{ },
    autoPick  = nil,

    -- And which KIND of thing (1.26): one of the BAG_CATEGORIES names above,
    -- 'all' for no narrowing at all. Local like the three above -- the server
    -- neither sorts nor filters for any of this.
    --
    -- IT SURVIVES A LOGIN *AND* THE CLIENT, which none of the others do: a
    -- container and a name are questions about one character's bags, while
    -- "I am looking for gear" is a habit, and re-picking it every session is
    -- the small tax that makes a filter go unused. It is the only field this
    -- addon writes to disk (default_settings, below).
    bagCat     = 'all',

    --[[
        THE MERCHANT PRICE (1.30). [itemid] = what a merchant pays for ONE,
        0 meaning nobody will buy it at all. It arrives as the server's `v|`
        record, keyed by item id because a price belongs to the item template
        and never to the copy.

        NOT A SECTION, AND NOT STAGED, deliberately. Every other table here is
        replaced wholesale by the answer that owns it, because every other
        table describes a bag that changes. A price does not: the same id is
        worth the same gil in every container of every character for the whole
        session, so what arrives is MERGED and kept, and a `bag` read of a
        second character costs nothing to price. Cleared only on a login, with
        the rest of the account view.

        `priced` is the third state a lookup can be in, and it is the one that
        keeps this honest: a server that has never sent a price is not a
        server whose items are worthless. Until one arrives, no Vendor control
        is drawn at all.
    --]]
    prices     = T{ },
    priced     = false,

    --[[
        THE TICK (1.30). A SET of `<charid>:<loc>:<slot>` keys, not a list of
        rows: the rows are rebuilt by every answer and a held row would be a
        stale (id, qty) pair pointed at a cell that has moved on. The live row
        is looked up again at click time, and the server compares the id
        against the cell anyway.

        `pickedFor` is whose ticks these are. The Bags tab shows one character
        at a time and a batch names one character, so a tick that survived a
        selection change would be a click aimed at somebody else's bag.
    --]]
    picked     = T{ },
    pickedFor  = nil,

    -- The pending batch question (1.30), filled by the button and emptied by
    -- the popup -- the trashAsk shape, for a set of cells instead of one.
    batchAsk   = nil,

    -- And the sellable narrowing (1.30): 'any', 'yes' or 'no'. Local like the
    -- other three filters, and drawn only once the server has priced
    -- something -- a filter over a fact nobody has stated is a control that
    -- can only mislead.
    sellFilter = 'any',
};

--[[
* THE ONE REMEMBERED SETTING (1.26).
*
* dwbags kept nothing on disk for twenty-five versions and that was right --
* every control it had was a question whose answer was already on screen. The
* Bags tab's category is the first that is not.
*
* T{ } AND NOT { }, with one level of nesting and a scalar leaf. Ashita's
* settings library calls `defaults:copy(true)` (settings.lua:180) and
* `settings:merge(defaults)` (:338) on what it is handed, and both are sugar
* table methods -- a plain table raises inside the library's own UNGUARDED
* zone-in handler and Ashita unloads the addon on the next zone line, which is
* exactly how dwfishing 1.2.0 shipped broken. harness_dwsuite.py gates the
* shape for every addon here; this comment is why.
--]]
local default_settings = T{
    view = T{
        category = 'all',
    },
};

local config = default_settings;

local okLoad, loaded = pcall(settings.load, default_settings);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

-- The stored view onto the live control, validated on the way in.
local function applyView()
    local view = type(config.view) == 'table' and config.view or { };

    state.bagCat = bagCategoryName(view.category);
end

-- Called on a CHANGE and never per frame: settings.save writes a file, and
-- sixty of those a second is the mistake dwwarehouse's own comment records.
local function saveView()
    if (type(config.view) ~= 'table') then
        config.view = T{ };
    end

    config.view.category = state.bagCat;

    pcall(settings.save);
end

applyView();

pcall(settings.register, 'settings', 'dwbags_settings_update', function (s)
    if (s ~= nil) then
        config = s;

        applyView();
    end
end);

--[[
* THE STAGING TABLE (1.24). An answer's records build in here and replace
* their section at z|, instead of wiping the section at d| and refilling it
* record by record. The wipe-then-refill was the scroll reset the owner
* reported: between the wipe and the first row the table drew nothing,
* ImGui clamped its scroll to the top of an empty list, and every click
* that re-asks the tab (Send, Fetch, Use, Stash, Trash, Stack, Apply) threw
* the player to the top of a thousand-row bag. With the commit at z| the
* rows on screen are replaced in one frame by rows of the same shape, and
* the scroll stays where the player left it. It is also the protocol's own
* discipline -- "lists build aside and commit on z|, so a half-arrived reply
* can never half-fill the window" -- which this addon documented and did not
* do. SECTIONS names what each verb replaces; a record that arrives under a
* verb with no section of its own still writes to the live section, as it
* always did (RECORD_ENVELOPES below is what decides that it may).
--]]
local SECTIONS = {
    who     = { 'chars' },
    bag     = { 'bags' },
    gear    = { 'gear', 'options', 'refused' },
    box     = { 'box' },
    find    = { 'finds' },
    hints   = { 'hints' },
    restock = { 'restock' },
    bagpref = { 'prefs', 'layout' },
    -- 1.27. A WRITE re-states the whole read, so this staging pair is always
    -- refilled before it commits -- unlike bagpref, whose write path opens a
    -- bare envelope and emits nothing but notes, and therefore needed the
    -- `envChar == nil` exemption in the `d|` handler. Keeping the server's
    -- write chatty is what buys this section out of that special case.
    autoname = { 'autoNames', 'autoName' },
};

--[[
* WHICH ENVELOPE MAY CARRY WHICH RECORD (2026-09-06).
*
* `who` IS NOT THIS ADDON'S ALONE. squad_storage.lua's roster answers both
* `!dwq who` (here, on _DWDATA) and `!dws who` (dwsquad, on _DWSDATA) out of
* one function, and the records dwsquad needed were added to it additively --
* `t|` for the trust engage mode, `f|` for the follow distance, `g|` for the
* alliance and pending-invite state. Two of those letters are already spoken
* for here: `f|` is a find hit and `g|` is a worn gear piece.
*
* The gear collision is not theoretical. `g|<in an alliance>|<invite kind>|
* <inviter>` opens with 0 or 1; the gear record opens with a charid; and a
* charid is a MySQL auto-increment, so the first character ever created on the
* server is charid 1. Select that character, stand in an alliance, and the
* roster read writes a phantom `main` slot holding item 0 into the Gear tab --
* from a read that has nothing to do with gear.
*
* So a record is accepted only inside an envelope known to carry it. The test
* is deliberately ONE-SIDED: a verb this addon has no section for (`send`,
* `use`, `stack`, `status` and the rest) keeps exactly today's permissive
* behaviour, so a server newer than this addon may grow a record under one of
* them without this dropping it -- the same deployment-order rule the
* unknown-verb latches exist for.
--]]
local RECORD_ENVELOPES = {
    c = { who     = true },
    n = { bag     = true },
    i = { bag     = true },
    a = { bag     = true, find = true },  -- emitPacked decorates both
    f = { find    = true },
    g = { gear    = true },
    k = { gear    = true },
    w = { gear    = true },
    h = { hints   = true },
    u = { restock = true },
    x = { box     = true },
    y = { bagpref = true },
    p = { bagpref = true },
    -- 1.27. Two letters this wire had never spoken, under a verb that did not
    -- exist either -- so nothing deployed can be confused by them, and they
    -- are gated here anyway because the gate is the rule and not the risk.
    r = { autoname = true },
    s = { autoname = true },
    -- 1.28. A letter this wire had never spoken, under a verb that did not
    -- exist either, so nothing deployed can be confused by it -- and gated
    -- here anyway because the gate is the rule and not the risk.
    q = { stashall = true },
    -- 1.30. `v|` is the price list and rides the two EXISTING list verbs, so
    -- it is the one of the three that this gate really has to hold: an
    -- ungated `v` would be accepted under `who`, whose roster records this
    -- addon shares with dwsquad. `b|` and `l|` ride verbs that did not exist
    -- before 1.30 and are gated for the rule rather than the risk.
    v = { bag      = true, find   = true },
    b = { trashmany = true, vendor = true },
    l = { trashmany = true, vendor = true },
};

local arriving = nil;

--[[
* THE MODEL REVISION (1.25). Bumped by every committed answer, and by nothing
* else -- a `z|` is the only moment any section on screen can change. Views
* that would otherwise be rebuilt sixty times a second (the Bags tab's filter
* and sort over a thousand rows; the roster's sorted copy) key their cache on
* it, so the work happens once per answer instead of once per frame. Wrapped
* rather than left to grow: it is only ever compared for equality.
--]]
local modelRev = 0;

local function bumpModel()
    modelRev = (modelRev + 1) % 1000000;
end

-- Where a record for `section` is written right now: the staging table
-- while its verb's envelope is open, the live section otherwise.
local function target(section)
    if (arriving ~= nil and arriving[section] ~= nil) then
        return arriving[section];
    end

    -- A LIVE write moves the model too. The views are built once per revision
    -- now rather than once per frame, so a record landing straight in the
    -- live section (the permissive path: a verb with no section of its own)
    -- would otherwise sit in the model unseen until some unrelated answer
    -- committed. The staging branch above needs nothing: its `z|` bumps.
    bumpModel();

    return state[section];
end

--[[
* THE CEILING ON THE ICON CACHE (1.31.0).
*
* Every entry below is a live D3DPOOL_MANAGED texture and the key is an item
* id -- sixty-five thousand of them. FFXI is a 32-bit process that runs out of
* ADDRESSES long before it runs out of memory (the black-screen-after-zoning
* class), and an allocation that fails inside a client which does not check
* the result becomes a write through a null pointer. A cache keyed by
* something with that cardinality owes a bound like every other table in this
* suite, and this one had none: paging a mule's whole inventory materialised a
* texture per row and never gave one back.
*
* THE COUNT LIVES IN THE TABLE, not beside it, and the sweep is written out at
* the top of d3d_present rather than wrapped in a function of its own. This
* file is AT LuaJIT's ceiling of 200 locals in a main chunk -- three more of
* them is the harness failing with `main function has more than 200 local
* variables`, which is how this was found. Every key in `icons` is an item id,
* so the string key `n` cannot collide with one, and nothing iterates the
* table.
*
* Dropped WHOLE rather than evicted one at a time: `gc_safe_release` owns the
* release, so letting go of the last reference IS the free. dwcon's
* releaseIcons and dwmerc's gilCache are the same recipe.
*
* And dropped at the TOP OF A FRAME, never from inside iconOf. ImGui keeps the
* raw texture pointer in its draw list until Ashita renders that list at the
* end of the present hook, so a texture released in the middle of a pass is a
* dangling pointer inside the pass still using it. By the time the next present
* handler runs, the previous frame is already on the screen.
--]]
local icons = T{ };

--[[
* The numeric texture handle per item id, and the {w,h} vector per size
* (1.25). Every drawn row used to pay an ffi.cast plus a tonumber plus a
* fresh two-element table, sixty times a second, for two values that never
* change: the texture is cached above and this file only ever draws icons at
* 20 and 32 pixels. ImGui reads the size vector and never writes to it, so
* one table per size is safe to share.
--]]
local iconHandles = { };
local iconSizes   = { };

local function iconSize(size)
    local vec = iconSizes[size];

    if (vec == nil) then
        vec = { size, size };
        iconSizes[size] = vec;
    end

    return vec;
end

--[[
* The item icon out of the client's own resources.
*
* Cached because a bag is eighty rows redrawn every frame and
* D3DXCreateTextureFromFileInMemoryEx is not free. gc_safe_release hands back a
* texture that releases itself when Lua collects it, which is what keeps this
* from leaking across a reload.
--]]
local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));
    icons.n       = (icons.n or 0) + 1;

    return icons[itemId];
end

-- Names cached per item id (1.24), and the lowercased form the Bags tab's
-- find box compares against -- lowered once, not once per row per frame.
local nameCache  = { };
local lowerCache = { };

local function itemName(itemId)
    -- A nil id never reaches here from the wire (every field is `wireInt(..)
    -- or 0`), but every caller of the card passes one through and a nil key
    -- would throw on the cache WRITE rather than the read -- inside the
    -- render pcall, which closes the window. One line, and the failure mode
    -- it removes is the loudest one this file has.
    if (itemId == nil) then
        return '(nothing)';
    end

    local cached = nameCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    local name;

    if (item == nil or item.Name[1] == nil or item.Name[1]:len() == 0) then
        name = string.format('item %d', itemId);
    else
        name = item.Name[1];
    end

    nameCache[itemId] = name;

    return name;
end

local function lowerName(itemId)
    local cached = lowerCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local lowered = itemName(itemId):lower();

    lowerCache[itemId] = lowered;

    return lowered;
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        local handle = iconHandles[itemId];

        if (handle == nil) then
            handle = tonumber(ffi.cast('uint32_t', texture));
            iconHandles[itemId] = handle;
        end

        imgui.Image(handle, iconSize(size));
    else
        imgui.Dummy(iconSize(size));
    end

    imgui.SameLine();
end

--[[
* The item card (1.17.0): the hover pop-up on every item row -- name, iLvl,
* level, Rare/Ex, slots, jobs, augments where the bytes are readable, and
* the item's own description text with the elemental-resist icons folded to
* readable tags, all read from the client's OWN resources by id, so nobody
* has to alt-tab to a wiki to learn what a row in their own bags is.
* Mirrored BY HAND from dwraid's shop card (an addon folder is the unit of
* distribution, the dwtheme rule, so the lines are duplicated rather than
* shared) -- edit one, revisit the others (dwwarehouse, dwah, dwraid,
* dwquest carry siblings). The DAT flag bits are the same ones
* sql/item_basic.sql spells @FLAG_RARE and @FLAG_EX; everything here is
* presentation, and the server re-checks anything that matters.
--]]
local FLAG_EX   = 0x4000;
local FLAG_RARE = 0x8000;

--[[
* The eight elemental-resist icons in the client's item descriptions are
* FFXI-private Shift-JIS pairs -- 0xEF then 0x1F..0x26, in wheel order
* fire ice wind earth lightning water light dark (read straight out of
* ROM/118/107.DAT: item 6272 carries fire as EF 1F, item 4488 dark as
* EF 26, and the JP DAT spells the same slots 耐火/耐風/耐土). ImGui wants
* UTF-8, so the raw pair renders as the '?' players reported. Each icon
* (and the '+' that usually follows it) folds to a three-letter tag:
* '<fire>+20' reads FiR:20, '<dark>-10' reads DkR:-10.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function(b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

--[[
* Augment names -- augcatalog.lua beside this file, the same GENERATED
* catalog dwquest carries (tools/dwquest/gen_augment_catalog.py;
* Check-QuestAugments.ps1 keeps every copy byte-identical to dwquest's).
* pcall'd because a half-synced folder is a real deployment state: without
* the catalog the card still lists augments, as the raw ids they are.
--]]
local haveAugCatalog, augcatalog = pcall(require, 'augcatalog');

if (not haveAugCatalog or type(augcatalog) ~= 'table' or type(augcatalog.augments) ~= 'table') then
    augcatalog = { augments = { } };
end

--[[
* The Weapon Burst shelf's ten augments (weapon_burst.sql ids 2030..2039)
* are DriftwoodXI's own, so the generated catalog never learns them --
* overlaid here rather than hand-edited into the generated file, which a
* catalog rebuild would silently drop. dwquest.lua:163 carries the same
* overlay for the same reason (edit one, revisit the other); without it a
* burst weapon's card here read 'augment 2030 rank 1' (1.22).
--]]
for offset, element in ipairs({
    'Fire', 'Ice', 'Wind', 'Earth', 'Thunder',
    'Water', 'Light', 'Dark', 'Shield', 'Enfeeble',
}) do
    local augid = 2029 + offset;

    if (augcatalog.augments[augid] == nil) then
        augcatalog.augments[augid] = { l = string.format('Weapon Burst: %s', element) };
    end
end

--[[
* The X-Magic shelf's six augments (xmagic.sql ids 2040..2045 -- FIVE when
* this comment was written; Song joined on 2026-09-08 and the loop below grew
* with it while the sentence did not): the same
* overlay for the same reason, missed when X-Magic shipped (2026-09-06), so
* an X-Magic ring's card here read 'augment 2040 rank 1'. dwquest.lua carries
* the twin (edit one, revisit the other) and tools/dwquest/check_xmagic.py
* asserts both against quest_xmagic.lua's own labels.
--]]
for offset, kind in ipairs({
    'Elements', 'Grace', 'Ruin', 'Siphon', 'Veil', 'Song',
}) do
    local augid = 2039 + offset;

    if (augcatalog.augments[augid] == nil) then
        augcatalog.augments[augid] = { l = string.format('X-Magic: %s', kind) };
    end
end

--[[
* ONE AUGMENT'S MAGNITUDE AT A GIVEN RANK -- dwquest's `augmentWords`
* (dwquest.lua, the catalog block) character for character. `rank` is the
* HUMAN rank: the stored five-bit exdata value plus one, which is what
* extraAugments below adds and what the server's own records carry
* (alt_storage.cpp augsOf, quest_store.cpp:2346).
*
* A substitutable entry has its digit runs recomputed for this rank -- term k
* applies to the k-th digit run, a bare number n means n + stored, a pair
* { b, s } means b + stored * s. The generator emits a term ONLY where it
* verified that against the engine's own formula (item_equipment.cpp
* SetAugmentMod: `(value > 0 ? value + stored : value - stored) * max(mult, 1)`),
* so this never invents a magnitude.
*
* THE SECOND RETURN IS THE HONESTY BIT: an entry with no terms cannot be
* recomputed, so the words are rank 1's whatever rank was asked for, and
* `exact` is false. A caller that prints those beside a rank is the 2026-09-11
* defect -- a reader multiplies and expects five times the number.
--]]
local function augmentWords(augid, rank)
    local entry = augcatalog.augments[augid];

    if (entry == nil) then
        return string.format('augment %d', augid), false;
    end

    local label  = entry.l;
    local stored = rank - 1;

    if (entry.m == nil) then
        return label, stored == 0;
    end

    if (stored > 0) then
        local k = 0;

        label = string.gsub(label, '%d+', function(digits)
            k = k + 1;

            local term = entry.m[k];

            if (term == nil) then
                return digits;
            end

            if (type(term) == 'table') then
                return tostring(term[1] + stored * term[2]);
            end

            return tostring(term + stored);
        end);
    end

    return label, true;
end

--[[
* One augment, as a hover card names it: the magnitude AT THIS RANK, and the
* rank itself whenever it is not 1. dwquest's augmentText without the
* exchange id suffix -- a card names the augment, the Exchange window is
* where ids matter.
*
* THE RANK IS STATED ALONGSIDE THE MAGNITUDE (owner report, 2026-09-11). The
* card used to print a bare `Mag. Evasion +7` for a rank-5 augment while the
* SeeAugs reference printed the catalog's rank-1 `+3` with "rank 5" beside
* it, and a player holding both read the +7 as the window hiding eight
* points. +7 IS what rank 5 grants -- the engine adds the stored value ONCE,
* it does not multiply -- so every line that shows a magnitude now shows the
* rank it belongs to, and the two windows stop looking like two answers.
--]]
local function augmentText(augid, rank)
    if (augcatalog.augments[augid] == nil) then
        return string.format('augment %d rank %d', augid, rank);
    end

    local label = augmentWords(augid, rank);

    if (rank > 1) then
        return string.format('%s (rank %d)', label, rank);
    end

    return label;
end

--[[
* The four augment slots out of an item's exdata bytes, decoded the way
* quest_store.cpp augmentsOf does: byte one is the kind (0x02 = carries
* augments), byte two the sub-kind (any special bit 0x08..0x80 --
* escutcheon, serialized, mezzotint, trial, evolith -- is a DIFFERENT byte
* layout and is refused, quest_store.cpp extraIsAugmentable), then four
* packed uint16s -- id in the low 11 bits, stored value in the high 5, and
* the rank a player reads is stored + 1. Returns nil when there is nothing
* honest to say.
--]]
local function extraAugments(extra)
    if (type(extra) ~= 'string' or #extra < 12) then
        return nil;
    end

    if (extra:byte(1) ~= 0x02 or bit.band(extra:byte(2), 0xF8) ~= 0) then
        return nil;
    end

    local augs = T{ };

    for slot = 0, 3 do
        local packed = extra:byte(3 + slot * 2) + extra:byte(4 + slot * 2) * 256;
        local augid  = bit.band(packed, 0x07FF);

        if (augid ~= 0) then
            augs:append({ id = augid, rank = bit.band(bit.rshift(packed, 11), 0x1F) + 1 });
        end
    end

    if (#augs == 0) then
        return nil;
    end

    return augs;
end

-- Display names for the card's slot line: ear and ring pairs fold into one
-- word each, unlike SLOT_NAMES above, whose job is naming a slot exactly.
local CARD_SLOTS = {
    [0]  = 'Main',  [1]  = 'Sub',   [2]  = 'Ranged', [3]  = 'Ammo',
    [4]  = 'Head',  [5]  = 'Body',  [6]  = 'Hands',  [7]  = 'Legs',
    [8]  = 'Feet',  [9]  = 'Neck',  [10] = 'Waist',  [11] = 'Ear',
    [12] = 'Ear',   [13] = 'Ring',  [14] = 'Ring',   [15] = 'Back',
};

local function jobsText(mask)
    local names = T{ };

    for jobId = 1, #JOB_NAMES do
        if (bit.band(mask, bit.lshift(1, jobId)) ~= 0) then
            names:append(JOB_NAMES[jobId]);
        end
    end

    if (#names == 0) then
        return nil;
    end

    if (#names >= #JOB_NAMES) then
        return 'All jobs';
    end

    return table.concat(names, ' ');
end

local function slotsText(mask)
    local names = T{ };
    local seen  = { };

    for slot = 0, 15 do
        if (bit.band(mask, bit.lshift(1, slot)) ~= 0) then
            local label = CARD_SLOTS[slot];

            if (not seen[label]) then
                seen[label] = true;
                names:append(label);
            end
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, '/');
end

--[[
* Whether the player already knows the spell a scroll teaches (1.24, the
* owner's request): true, false, or nil when the item is not a scroll or
* the client cannot say. A scroll is recognised by its own description --
* every spell scroll's opens "Teaches the ..." -- and the spell is looked
* up by the scroll's DAT name (which IS the spell's name: the item is
* "Auspice", the log name "scroll of Auspice"), falling back to the last
* words of the description. The player's spell list is the client's own
* memory (IPlayer:HasSpell), read under pcall: the sol bindings for it are
* promised by Ashita's annotations and proven by no sibling, so a refusal
* costs one missing line rather than a card that throws. Mirrored BY HAND
* from dwah (edit one, revisit dwwarehouse and this one). The answer is
* about the character being PLAYED -- a scroll teaches the whole account,
* so that is the one that matters.
--]]
local function scrollStatus(item)
    if (item == nil) then
        return nil;
    end

    local desc = item.Description ~= nil and item.Description[1] or nil;

    if (type(desc) ~= 'string' or desc:sub(1, 12) ~= 'Teaches the ') then
        return nil;
    end

    local ok, known = pcall(function()
        local mgr    = AshitaCore:GetResourceManager();
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (mgr == nil or player == nil) then
            return nil;
        end

        local names = { item.Name ~= nil and item.Name[1] or nil };
        local tail  = desc:match('^Teaches the [%a%-]+ [%a%-]+ (.-)%.') or desc:match('^Teaches the [%a%-]+ (.-)%.');

        if (tail ~= nil and tail ~= names[1]) then
            names[#names + 1] = tail;
        end

        for _, name in ipairs(names) do
            local spell = mgr:GetSpellByName(name, 0);

            if (spell ~= nil and spell.Index ~= nil) then
                return player:HasSpell(spell.Index) == true;
            end
        end

        return nil;
    end);

    if (not ok) then
        return nil;
    end

    return known;
end

--[[
* Whether the player already knows the phantom roll a Corsair die teaches
* (1.32.0, the owner's request): 'known', 'unlearned', 'offjob', or nil when
* the item is not a die or the client cannot say. Mirrored BY HAND beside
* scrollStatus (edit one, revisit dwah and dwwarehouse).
*
* A die is recognised by its own description -- all 31 of them (item ids
* 5477..5505 plus 6368/6369, kDiceRolls in alt_storage.cpp) open "Teaches
* the job ability <Roll>.", and they are the only items in the game whose
* use teaches an ability -- and the roll is looked up BY THAT NAME in the
* client's own ability DATs, where a job ability sits at 512 + the server's
* ability id (dwgambits' ABILITY_CLIENT_OFFSET). The resource's own Id is
* already in that space, so it is what IPlayer:HasAbility wants; an id below
* the offset is a weapon skill and not our answer.
*
* THE CAVEAT, and it is why this answers three ways and not two: the
* client's job-ability list is packet 0x0AC, which the server fills from the
* CURRENT main and support job ONLY (charutils::BuildingCharAbilityTable
* walks GetMJob() then GetSJob(), each arm gated on that job's level). So an
* absent roll means "not learned" only while the character is on Corsair,
* and even then only up to the Corsair level being played -- the rolls run
* level 20..97 and a support job is capped at half the main level. Off
* Corsair the card says WHEN it could answer instead of answering, and on
* Corsair the negative names its own second reading. A false "not learned"
* would read as permission to spend a die the account has already eaten --
* and the learn is account-wide (alt_storage.cpp teaches every character on
* the account), so there is no second copy to spend.
--]]
local function rollStatus(item)
    -- Inside the function, not at file scope: this chunk is close enough to
    -- Lua's 200-locals-per-function ceiling (the raid_core lesson) that two
    -- more constants are not worth spending there, and a value read once per
    -- hovered card costs nothing where it is used.
    local COR_JOB_ID        = 17;  -- the client's job ids, WAR 1 .. RUN 22
    local ABILITY_DAT_FIRST = 512; -- DAT ids below this are weapon skills

    if (item == nil) then
        return nil;
    end

    local desc = item.Description ~= nil and item.Description[1] or nil;

    if (type(desc) ~= 'string') then
        return nil;
    end

    local roll = desc:match('^Teaches the job ability (.-)%.');

    if (roll == nil or #roll == 0) then
        return nil;
    end

    local ok, state = pcall(function()
        local mgr    = AshitaCore:GetResourceManager();
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (mgr == nil or player == nil) then
            return nil;
        end

        local ability = mgr:GetAbilityByName(roll, 0);

        if (ability == nil or ability.Id == nil or ability.Id < ABILITY_DAT_FIRST) then
            return nil;
        end

        if (player:HasAbility(ability.Id) == true) then
            return 'known';
        end

        -- A miss is only an answer once the list has arrived and once one of
        -- the jobs it was built from is the one that owns the roll. The data
        -- flag is asked in its own pcall: an install whose bindings lack it
        -- keeps the rest of the answer rather than losing all of it.
        local okData, hasData = pcall(function()
            return player:HasAbilityData();
        end);

        if (okData and hasData == false) then
            return nil;
        end

        if (player:GetMainJob() ~= COR_JOB_ID and player:GetSubJob() ~= COR_JOB_ID) then
            return 'offjob';
        end

        return 'unlearned';
    end);

    if (not ok) then
        return nil;
    end

    return state;
end

local function drawScrollStatus(item)
    local roll = rollStatus(item);

    if (roll ~= nil) then
        if (roll == 'known') then
            imgui.TextColored(theme.colors.ok, 'You already know this roll.');
        elseif (roll == 'unlearned') then
            imgui.TextColored(theme.colors.warn, 'Not learned yet, or above your Corsair level.');
        else
            imgui.TextDisabled('Learned status shows while on Corsair.');
        end

        return;
    end

    local known = scrollStatus(item);

    if (known == true) then
        imgui.TextColored(theme.colors.ok, 'You already know this spell.');
    elseif (known == false) then
        imgui.TextColored(theme.colors.warn, 'Not learned yet.');
    end
end

-- `aug` is one of three honest states: a list of { id, rank } (the bytes
-- were readable and decoded), `true` (the server said "augmented" about an
-- item whose bytes live on another character -- say so without inventing
-- values), or nil.
local function itemCard(itemId, aug)
    imgui.BeginTooltip();

    local item = nil;

    if (itemId ~= nil and itemId ~= 0 and itemId ~= 65535) then
        item = AshitaCore:GetResourceManager():GetItemById(itemId);

        drawIcon(itemId, 32);
    end

    imgui.Text(itemName(itemId));

    if (item ~= nil) then
        local tags = T{ };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags:append(string.format('iLvl %d', item.ItemLevel));
        end

        if (item.Level ~= nil and item.Level > 0) then
            tags:append(string.format('Lv.%d', item.Level));
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_RARE) ~= 0) then
            tags:append('Rare');
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_EX) ~= 0) then
            tags:append('Ex');
        end

        if (#tags > 0) then
            imgui.TextColored(theme.colors.info, table.concat(tags, '  '));
        end

        local slots = item.Slots ~= nil and slotsText(item.Slots) or nil;
        local jobs  = item.Jobs ~= nil and jobsText(item.Jobs) or nil;

        if (slots ~= nil and jobs ~= nil) then
            imgui.TextDisabled(slots .. '  --  ' .. jobs);
        elseif (slots ~= nil or jobs ~= nil) then
            imgui.TextDisabled(slots or jobs);
        end

        drawScrollStatus(item);

        if (type(aug) == 'table') then
            imgui.Separator();
            imgui.TextColored(theme.colors.info, 'Augments');

            for _, a in ipairs(aug) do
                imgui.Text('  ' .. augmentText(a.id, a.rank));
            end
        elseif (aug == true) then
            imgui.Separator();
            imgui.TextColored(theme.colors.info, 'Augmented');
            imgui.TextDisabled('Values are readable where the item sits -- hover it there.');
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            -- A fixed wrap width, not one derived from imgui state: the
            -- card must render the same whatever window it floats over.
            imgui.PushTextWrapPos(320.0);
            imgui.Text(cleanDescription(desc));
            imgui.PopTextWrapPos();
        end
    end

    imgui.EndTooltip();
end

-- Call after an icon-and-name pair: `hoveredIcon` is IsItemHovered read
-- between the two draws (drawIcon leaves the cursor on the same line, and
-- IsItemHovered reads the LAST item, so the icon's hover must be taken
-- before the name is drawn). `aug` passes through to the card.
local function cardOnHover(itemId, hoveredIcon, aug)
    if (imgui.IsItemHovered() or hoveredIcon == true) then
        itemCard(itemId, aug);
    end
end

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A TIME.
*
* THE CLIENT RATE-LIMITS OUTGOING CHAT, AND A !dwq COMMAND IS A CHAT LINE.
* Firing four of them in a single frame -- which is what a naive "refresh
* everything" does -- gets the first one sent and the rest answered with
* "A command error occurred" by the client, before the server ever sees them.
* The symptom is maddening precisely because it is not deterministic: whichever
* command happens to go first works, so the character list fills in while the
* gear panel stays empty and Send silently does nothing.
*
* So everything queues here and drains at one command per SEND_INTERVAL.
*
* DUPLICATES COLLAPSE ONLY WHEN THE CALLER SAYS SO, and only reads ever do.
* Asking twice for the same page is never useful; SENDING twice is two things
* the player clicked for. `!dwq fetch <alt> <itemid> <count>` carries no slot,
* so the same stackable held in two containers at the same count produces two
* byte-identical lines from two different rows -- and issue() has no way to
* report a refusal, so the second one just disappeared.
--]]
local SEND_INTERVAL = 1.2;

--[[
* AND A CEILING ON IT (1.25).
*
* Reads collapse, so the queue's growth comes entirely from clicks -- and
* every click appends unconditionally, on purpose (see above: sending twice
* is two things the player asked for). The drain is one line per 1.2 seconds
* AND is held shut entirely while the client is zoning, so a player who
* clicks through a zone line, or who runs a mouse down a bagful of Stash
* buttons, builds a queue that goes on acting for minutes after they have
* stopped looking at it -- against rows that have since moved.
*
* Sixty lines is seventy-two seconds of drain, which is already longer than
* anybody means. Past that the click is refused AND SAID: a transfer that
* silently does not happen is the one failure this window must never have,
* and the sentence names the queue rather than the item so it cannot be read
* as a refusal from the server.
--]]
local QUEUE_MAX  = 60;
local QUEUE_FULL = 'Too much is queued already, so that click was not sent. Let it drain and try again.';

local queue    = T{ };
local lastSend = 0;

local function queueFull(extra)
    if (#queue + extra <= QUEUE_MAX) then
        return false;
    end

    state.status    = QUEUE_FULL;
    state.statusBad = true;

    return true;
end

local function issue(command, collapse)
    if (collapse) then
        for _, queued in ipairs(queue) do
            if (type(queued) == 'string' and queued == command) then
                return;
            end
        end
    end

    if (queueFull(1)) then
        return;
    end

    queue:append(command);
end

--[[
* A SECOND LINE THAT MUST NOT GO OUT IF THE FIRST ONE WAS REFUSED (1.20.0).
*
* Three buttons queue two typed lines as one gesture -- fetch from an alt into
* your own bags, then send on to somebody else. The old comment on the Get
* button claimed this was safe: "If the fetch is refused the send then refuses
* on its own terms; two red sentences is noisy, but nothing moves that the
* typed commands would not have moved."
*
* THAT WAS FALSE WHENEVER YOU ALREADY OWN A COPY OF THAT ITEM ID, and for the
* Get button that is the COMMON case rather than the exotic one. `send`
* resolves its item by walking every browsable container the caller owns. It
* has no idea a fetch was supposed to have put one there. So:
*
*   Betta holds a Rare ring. You are wearing the same Rare ring. The Gear tab
*   offers "Get Ring". You click. Line one is refused BECAUSE YOU OWN ONE --
*   "You already have a Ring, and it is Rare." Line two then finds your ring,
*   the very one the refusal named, and sends it to Alta. You have lost the
*   ring you were wearing and Betta still has hers.
*
* Same shape without Rare: click Send on an alt's seven crystals with a full
* inventory, the fetch refuses, and the send ships five of YOUR crystals.
*
* The fix is a monotonic error counter and a queue entry that remembers what
* it was. A chained line is dropped -- and SAID -- if any refusal arrived
* between queueing it and draining it. Dropping on an unrelated error is the
* safe direction to be wrong in: the worst case is a line the player re-clicks,
* against a worst case of an item leaving the account's control silently.
--]]
local errorSeq = 0;

local function issueChained(command)
    queue:append({ cmd = command, after = errorSeq });
end

--[[
* The two-line gesture, admitted or refused AS ONE (1.25).
*
* A ceiling that let the fetch through and turned the send away would leave
* the item sitting in the caller's own inventory with nothing on screen
* saying why it stopped half way -- which is the same shape issueChained
* exists to prevent, arriving through the other door. Both callers of the
* fetch-then-send pair go through here so the room for both is checked once,
* before either is queued.
--]]
local function issuePair(fetchLine, sendLine)
    if (queueFull(2)) then
        return;
    end

    queue:append(fetchLine);
    issueChained(sendLine);
end

--[[
* Drains one queued command. Called every frame from d3d_present, including
* while the window is shut: a Send issued just before closing it still has to
* reach the server.
--]]
local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    local entry = table.remove(queue, 1);

    if (type(entry) == 'table') then
        -- A chained line: only goes out if nothing was refused since it was
        -- queued. `after` is the error count at queue time, so this compares
        -- counters rather than trying to match a refusal to a command -- the
        -- server's refusals are prose and matching them by text would be a
        -- parser that breaks on a reworded sentence.
        if (errorSeq ~= entry.after) then
            state.status    = 'The first half of that was refused, so the rest was not sent: ' .. entry.cmd;
            state.statusBad = true;

            print(chat.header('dwbags'):append(chat.error(state.status)));

            return;
        end

        echo.send(entry.cmd);

        return;
    end

    echo.send(entry);
end

--[[
* What has already been asked for, so a tab drawn sixty times a second asks
* once. Keyed by verb, holding the charid the answer is about, when it was
* asked, whether it was answered and how many times it has been sent.
*
* THE ANSWER IS TRACKED, NOT JUST THE QUESTION, because a command can be lost on
* the way out. The client rate-limits outgoing chat and answers anything over
* the limit with "A command error occurred" before the server ever sees it, and
* a !dwq command is a chat line like any other -- so a query issued in the same
* instant as something the player typed can simply evaporate. That used to leave
* the panel showing pre-command data until the player clicked to another
* character and back, which is the worst shape a bug can have: the number is
* wrong and nothing on screen says so. It is exactly how the In transit tab went
* on listing an item that `!squad call` had already delivered.
*
* So an unanswered request is asked once more, and then left alone -- a retry
* that never terminates would be a command loop, which is worse than a stale
* panel.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

--[[
* A PLAIN TABLE, NOT `T{ }`, AND THIS ONE COST A ROUND.
*
* This table is keyed by VERB -- 'bag', 'gear', 'box', 'find' -- and a `T{ }`
* resolves unknown keys through its metatable to the sugar table methods
* (`libs/sugar/table.lua:372`). So `requested['find']` did not answer nil, it
* answered `table_mt.find`, **a function**, and writing a field to it threw.
*
* The blast radius was much wider than the error line, because the throw
* happened after `state.inbound` had been set and before the section reset that
* follows it: every `find` response then appended to the previous one instead of
* replacing it, which is what made the results list appear to duplicate itself
* on every search. A table indexed by names the caller chooses must not be one
* that already has names of its own.
--]]
local requested = {};

-- True once the server has said it has no hints verb -- one from before
-- UPGRADE_HINTS_PLAN.md Phase 2. Detected off the dispatch's own unknown-verb
-- sentence (frozen on any server old enough to say it) and reset on every
-- login line, so a server upgraded underneath a running client gets asked
-- again rather than never.
local hintsUnsupported = false;

-- The same detection for `bagpref` and `tidy`, and for the same reason: a
-- server from before bag routing answers them with its unknown-verb sentence,
-- and the honest response to that is to draw the tab as unavailable rather than
-- to ask again every time it is opened. Reset on login with the hints flag.
local prefsUnsupported = false;

-- And again for `stack`, so the Stack button simply is not drawn against a
-- server from before the combiner existed. Reset on login with the others.
local stackUnsupported = false;

-- And again for `restock` (1.21). A server from before the warehouse planner
-- answers with its unknown-verb sentence, and the honest response is to say the
-- face is unavailable rather than to ask on every frame the tab is open.
-- Deployment order must not matter in either direction, which is the same rule
-- the hints, bagpref and stack flags exist for. Reset on login with them.
local restockUnsupported = false;

-- And again for the two per-row destructive verbs (1.22): Trash destroys the
-- exact cell, Stash moves it into the account warehouse. Two flags rather than
-- one because the two server halves live in different translation units
-- (DwAltTrash in alt_storage.cpp, DwWhStash in warehouse_store.cpp) and a
-- half-updated binary can carry one without the other. Reset on login.
local trashUnsupported = false;
local stashUnsupported = false;

-- And again for the two BATCH verbs (1.30). Flags of their OWN for the bulk
-- stash's reason: `trashmany` and `vendor` are two more verbs on top of two
-- more bindings, and a tree carrying `trash` without `trashmany` -- which is
-- every server between this addon shipping and the next map restart -- must
-- lose the batch button and keep the per-row one. `vendorUnsupported` is
-- doubly load-bearing: it hides the Sell buttons, the Vendor batch and the
-- sellable filter together, so a server with no merchant half shows no trace
-- of one. Reset on login.
local trashManyUnsupported = false;
local vendorUnsupported    = false;

-- And again for the BULK stash (1.28) -- "Send All to WH", one whole
-- container at a time. A flag of its OWN rather than a second reading of
-- `stashUnsupported`: the two are two bindings (DwWhStash and DwWhStashBag)
-- and a binary that predates only the newer one answers `stash` perfectly
-- while refusing this by name, so hiding the per-row button because the bulk
-- one is missing would take away the verb that still works. Reset on login.
local stashAllUnsupported = false;

-- And again for the automaton pair (1.27). Two flags rather than one: the two
-- verbs are two bindings (DwAltPuppetUnlock and DwAltAutomaton /
-- DwAltAutomatonName), and though they live in one translation unit today the
-- honest reading of "the server said it does not know `unlock`" is not "it
-- does not know `autoname`". `puppetUnsupported` hides the Unlock button on a
-- puppet row; `autonameUnsupported` hides the name combo. Reset on login with
-- the others, so a server upgraded underneath a running client is asked again.
local puppetUnsupported   = false;
local autonameUnsupported = false;

--[[
* THE BATCH REASON WORDS (1.30), the server's `b|` record turned into English.
*
* The wire carries ONE WORD per refused cell -- `data.reason` straight off the
* binding, never parsed out of its sentence -- because a record is a chat
* packet and a sentence per cell would be forty of them. The prose lives here
* for the reason every other string in this file lives here: the wire carries
* facts and the window carries the language.
*
* An unrecognised word is not an error and is not silence either: the fallback
* below still says the cell was refused, which is the part a player must never
* lose. A server that grows a new reason therefore degrades to a vaguer
* sentence rather than to a missing one.
--]]
local BATCH_REASONS = {
    empty     = 'that bag slot is empty now',
    changed   = 'something else is in that slot now -- press Refresh',
    locked    = 'it is being worn or is in use',
    priced    = 'it is priced in a bazaar',
    reserved  = 'it is in use right now',
    placed    = 'it is placed in a Mog House',
    currency  = 'currency cannot go this way',
    nosale    = 'no merchant will buy it',
    gilcap    = 'you are carrying too much gil to be paid for it',
    gil       = 'your gil row is not where the game keeps it',
    quantity  = 'that is not a quantity it can be sold in',
    online    = 'that character is logged in',
    failed    = 'the server could not complete it',
    container = 'that bag cannot be reached this way',
    slot      = 'that is not a bag slot',
    item      = 'the order did not name an item',
    who       = 'that character is not on your account',
    -- 1.32.1: the game's own throw-away refuses a storage slip that still
    -- holds gear (the gear lives on the slip), and so does the server now.
    slip      = 'it is a storage slip with gear still stored on it',
    refused   = 'the server refused it',
};

--[[
* THE RUNNING TALLY OF ONE PRESS (1.30).
*
* A ticked selection is packed into as many command lines as the client's own
* 128-byte chat line needs, and each of those is its own envelope with its own
* `l|` ledger -- so the status bar has to add them up or it would report the
* last sixth of what the player asked for. `cells` is the number they agreed to
* in the popup, which is the number the sentence is measured against.
*
* A plain table and not `T{ }`: `count` and `size` are sugar table methods, and
* this table's fields are named for what they mean (the `bagView` rule).
--]]
local batchTally = nil;

-- Gil with thousands separators, for a sentence a person reads. Bounded by the
-- string it is given rather than by a loop over the number: gsub's repeat is
-- what makes this one line instead of five, and the anchor keeps it off the
-- leading minus a gil total can never have anyway.
local function commaGil(amount)
    local text = tostring(math.floor(tonumber(amount) or 0));

    while (true) do
        local replaced, count = string.gsub(text, '^(%d+)(%d%d%d)', '%1,%2');

        text = replaced;

        if (count == 0) then
            break;
        end
    end

    return text;
end

local function forget()
    requested = {};
end

-- Called from the `d|` record: whatever response is arriving answers the
-- outstanding question for that verb.
local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

--[[
* Ask for one verb about one character, at most once -- twice if the first one
* was never answered.
*
* Called from the tab that needs it rather than all at once on selection: the
* Bags tab does not need the gear list and the Gear tab does not need the
* delivery box, and with a throttled queue every command not sent is a second
* the player is not waiting.
--]]
local function need(verb, charid)
    local member = state.chars[charid];

    if (member == nil) then
        return;
    end

    local asked = requested[verb];

    if (asked ~= nil and asked.charid == charid) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested[verb] = T{ charid = charid, at = os.clock(), answered = false, tries = 1 };
    end

    issue(string.format('!dwq %s %s', verb, member.name), true);
end

--[[
* The gear verb's own `need` (1.16), because it is the one read with two
* spellings: plain for the Automatic column, slot-suffixed for the Manual
* picker's full per-slot list. The bookkeeping is need()'s exactly -- same
* 'gear' key, because both replies arrive under a d|..|gear envelope and
* answered('gear') must clear whichever was outstanding -- but the SLOT RIDES
* THE COMPARISON: switching mode or slot is a different question, and a plain
* answer must not satisfy a slot-scoped want. `slot` nil means plain.
*
* Against a server too old to know the slot argument the ask is answered with
* the plain capped listing -- right shape, best four -- so the picker degrades
* rather than retrying forever: the envelope marks the request answered
* whichever flavour the server understood.
--]]
local function needGear(charid, slot)
    local member = state.chars[charid];

    if (member == nil) then
        return;
    end

    local asked = requested['gear'];

    if (asked ~= nil and asked.charid == charid and asked.slot == slot) then
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['gear'] = T{ charid = charid, slot = slot, at = os.clock(), answered = false, tries = 1 };
    end

    if (slot ~= nil) then
        issue(string.format('!dwq gear %s %s', member.name, SLOT_NAMES[slot]), true);
    else
        issue(string.format('!dwq gear %s', member.name), true);
    end
end

--[[
* THE ROSTER READ, TRACKED LIKE EVERY OTHER READ (1.20.0).
*
* This was the one read exempt from need()'s own doctrine -- "the answer is
* tracked, not just the question, because a command can be lost on the way
* out... that used to leave the panel showing pre-command data until the player
* clicked to another character and back, which is the worst shape a bug can
* have". A `!dwq who` dropped by the client's chat rate limit left the roster
* -- names, jobs, online and [out] flags, used/size -- frozen with nothing to
* notice it and nothing to retry it, and `who` is precisely the read
* pumpRefetch exists to fire after a transfer.
*
* need() itself cannot serve this one: it looks the character up by charid and
* appends that character's name to the command, and `who` is about the ACCOUNT
* and takes no argument. So this is need()'s bookkeeping without the member
* lookup -- same answer clock, same try count, same held-queue exemption --
* and answered('who') already fires for it from the envelope handler.
--]]
local function needWho()
    local asked = requested['who'];

    if (asked ~= nil) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout, exactly as in need().
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['who'] = T{ charid = 0, at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dwq who', true);
end

local function refreshChars()
    -- Dropped rather than aged: a refresh is a NEW question, and leaving the
    -- old record in place would make the first ask read as a retry and count
    -- against ANSWER_TRIES.
    requested['who'] = nil;

    needWho();
end

--[[
* Record parsing.
*
* Every record is pipe-separated with a single-character type. Anything this
* addon does not recognise is ignored rather than being an error: a server
* newer than the addon must not break it, which is the whole reason the `d|`
* record carries a protocol version.
--]]
--[[
* A WHOLE NUMBER OFF THE WIRE, OR THE FALLBACK (1.25).
*
* Nearly every field parsed below is handed straight back to
* `string.format('%d', ...)` in a command line, or used as a container
* index. LuaJIT's `tonumber` accepts "2.5", "inf" and "nan" -- and
* `string.format('%d', 2.5)` RAISES, inside the render pcall, which closes
* the window for the rest of the session and says only "render error".
*
* The server cannot emit one (its own emitters use `%i`, which would raise
* on the server first), so this is the belt rather than the braces. It is
* the same rule squad_storage.lua keeps on everything a player types, and
* the reason to keep it on BOTH sides is that only one of them is deployed
* at a time. `nan` fails the first test (it compares false against itself);
* the infinities fail the range test.
--]]
local function wireInt(text, fallback)
    local value = tonumber(text);

    if (value == nil or value ~= value
            or value <= -2147483648 or value >= 2147483648) then
        return fallback;
    end

    return math.floor(value);
end

local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* The g|/k| records' augment tail (1.19.0, server 2026-08-26; ADDITIVE,
* protocol still 1): flat <augid>:<rank> pairs, the a| record's pair format
* without its leading bag slot. An old server sends no tail and the gear
* row then simply carries no values; the same bounded loop and the same
* torn-pair rule as the a| parser below.
--]]
local function augsFromTail(text)
    if (type(text) ~= 'string' or #text == 0) then
        return nil;
    end

    local bits = split(text, ':');
    local augs = T{ };

    for index = 1, #bits - 1, 2 do
        local id   = wireInt(bits[index], 0);
        local rank = wireInt(bits[index + 1], 0);

        if (id > 0 and rank > 0 and #augs < 4) then
            augs:append({ id = id, rank = rank });
        end
    end

    if (#augs == 0) then
        return nil;
    end

    return augs;
end

-- `<slot>:<itemid>:<qty>:<flags>,...`
local function parsePacked(charid, loc, packed)
    local rows = T{ };

    for _, entry in ipairs(split(packed, ',')) do
        local bits = split(entry, ':');

        if (#bits >= 4) then
            local row = T{
                charid = charid,
                loc    = loc,
                slot   = wireInt(bits[1], 0),
                itemid = wireInt(bits[2], 0),
                qty    = wireInt(bits[3], 0),
                flags  = wireInt(bits[4], 0),
            };

            -- The count cell, formatted ONCE (1.25). It is a pure function of
            -- a field that never changes after the row is parsed, and it was
            -- being rebuilt for every drawn row on every frame.
            row.qtytext = row.qty > 1 and string.format('x%d', row.qty) or '';

            rows:append(row);
        end
    end

    return rows;
end

--[[
* What a committed answer settles besides its own rows (2026-09-06).
*
* `who` is the only read that can invalidate the two charids this window
* holds OUTSIDE any section -- the roster selection and the Send target. A
* character deleted between two rosters left `selected` pointing at a row
* that no longer existed, and the window then drew "Pick a character." over a
* full character list, with no click able to clear it except the one nobody
* would think to make. Same for `sendTo`, whose dangling value shows every
* row of your own bag a "no target" hint instead of a Send button.
*
* It is also where the opening placeholder retires. `Press Refresh.` stood
* from load until the first m|/e| line arrived, and a session that is never
* refused anything never gets one -- so the window's own status bar spent its
* whole life telling the player to press a button the window had already
* pressed for itself, above rows that had plainly arrived.
--]]
local function afterCommit(verb)
    -- The rows just committed answer whatever was last asked for; the Find
    -- tab reads this to tell a search still in flight from one that came
    -- back with nothing (1.25).
    if (verb == 'find') then
        state.findAnswered = state.findQuery;

        return;
    end

    -- The combo goes back to showing what the SERVER says (1.27). `autoPick`
    -- is an unapplied intention, and after an answer the thing on screen is
    -- the answer -- so an Apply that was refused leaves the combo on the real
    -- name rather than on a pick the server declined, and one that succeeded
    -- leaves it on the new one without a second source of truth.
    if (verb == 'autoname') then
        state.autoPick = nil;

        return;
    end

    if (verb ~= 'who') then
        return;
    end

    local mine  = nil;
    local other = nil;

    for charid, member in pairs(state.chars) do
        if (bit.band(member.flags, CHAR_SELF) ~= 0) then
            mine = charid;
        elseif (other == nil or charid < other) then
            other = charid;
        end
    end

    if (state.selected == nil or state.chars[state.selected] == nil) then
        state.selected = mine;
    end

    if (state.sendTo ~= nil and state.chars[state.sendTo] == nil) then
        state.sendTo = other;
    end

    if (state.status == 'Press Refresh.' or state.status == 'Loading...') then
        state.status    = '';
        state.statusBad = false;
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], 0);

        if (version ~= PROTOCOL) then
            -- statusBad too, or the loudest message this addon can produce is
            -- drawn in whatever colour the LAST message happened to leave
            -- behind -- so "update dwbags" reads as an ordinary note, and if
            -- the previous line was a success it reads as a green one.
            -- dwwarehouse sets both here; this copy of the template did not.
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwbags.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- The staging table goes with it (2026-09-06). Refusing the
            -- envelope closes `inbound`, so the `z|` that would have
            -- committed the PREVIOUS answer is dropped by the guard below --
            -- leaving `arriving` set, and every record of the next verb
            -- writing into a staging table nothing will ever swap in.
            arriving = nil;

            -- A d| envelope IS the answer, whatever version it announced, and
            -- re-asking a server that speaks a layout this addon cannot read
            -- cannot help. Left outstanding, every tab's `need` spends its
            -- second try on a doomed line -- and in the siblings that print a
            -- give-up sentence it also replaces "Update dwbags" with "no
            -- answer from the server", about a server that just answered.
            -- One shape across the suite (dwfame, 2026-08-15); gated in
            -- harness_dwsuite.py.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        --[[
            A STALE ENVELOPE IS DROPPED WHOLE, BEFORE THE RESET BELOW.

            Selecting a different character fires a fresh read, but a reply
            already in flight for the PREVIOUS one still arrives -- and the
            reset below is keyed on the verb, not on whose data it is. The
            per-record filters further down correctly ignored the foreign
            rows, which is precisely what made this visible: the section was
            cleared and then nothing refilled it, so the panel of the
            character on screen went blank until the next read landed.

            The server stamps every per-character read envelope with the
            charid (squad_storage.lua open()): bag, gear, box, bagpref and
            hints. It is absent for who/find/send/fetch/use/status and from
            any older server, and those keep exactly today's behaviour.
            Status lines are unaffected: the m|/e| branch sits above the
            `state.inbound == nil` guard, so a refusal riding a foreign
            envelope still reaches the status bar.
        --]]
        local envChar = wireInt(parts[4], nil);

        if (envChar ~= nil and state.selected ~= nil and envChar ~= state.selected) then
            state.inbound = nil;

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright -- STAGED (1.24): the
        -- records build in `arriving` and the swap happens at z|, so the
        -- section on screen is never empty between two answers (the scroll
        -- reset). THIS RUNS BEFORE ANYTHING ELSE THE `d|` RECORD DOES,
        -- because handleRecord is called under a pcall: anything that
        -- throws above this line leaves the old rows in place and the
        -- records behind it append to them, which turns a one-line bug into
        -- a duplicated list.
        --
        -- bagpref: `envChar ~= nil` IS THE FIX, not a tidy-up (1.20.0). Only
        -- the bagpref READ stamps its envelope with a charid; both WRITE
        -- paths open a bare `bagpref` envelope and then emit nothing but m|
        -- notes. So every write reply used to wipe this table and leave
        -- nothing to refill it -- and the Storage tab renders an empty prefs
        -- table as "Mixed" for every group and "a layout of your own" for
        -- the layout, which is not a "loading" state, it is a specific false
        -- claim that the group is split across bags. A write's reply leaves
        -- the rows alone; the read that follows it replaces them. The
        -- layout resets WITH the rows: a response whose `y|` was dropped
        -- would otherwise go on claiming the layout the last one named.
        --
        -- restock: both faces of the verb open this envelope -- the preview
        -- and the apply -- and both re-state the whole plan, so replacing
        -- the section outright is right for either.
        local sections = SECTIONS[state.inbound];

        if (sections ~= nil and not (state.inbound == 'bagpref' and envChar == nil)) then
            arriving = { verb = state.inbound };

            for _, section in ipairs(sections) do
                arriving[section] = section == 'layout' and 255 or T{ };
            end
        else
            arriving = nil;
        end

        answered(state.inbound);

        return;
    end

    -- Status and error lines are accepted whatever the envelope state.
    --
    -- They are the one thing a player must never lose, and they were being lost
    -- twice over: the server emitted them outside any `d|` (so this guard threw
    -- them away), and a dropped `d|` would have swallowed them regardless. The
    -- server now wraps them properly; this is the belt to that pair of braces,
    -- because the message saying why a transfer was refused is worth more than
    -- the response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- The one refusal that is not worth a red banner: a server from
        -- before the hint tier answering `!dwq hints` with its unknown-verb
        -- sentence. That means upgrade markers do not exist here yet, so the
        -- addon stops asking and draws nothing -- deployment order must not
        -- matter in either direction (UPGRADE_HINTS_PLAN.md Phase 3).
        if (kind == 'e' and not hintsUnsupported
                and string.find(line, 'unknown verb "hints"', 1, true) ~= nil) then
            hintsUnsupported = true;

            return;
        end

        -- Same again for bag routing, on a server from before it existed.
        if (kind == 'e' and not prefsUnsupported
                and (string.find(line, 'unknown verb "bagpref"', 1, true) ~= nil
                     or string.find(line, 'unknown verb "tidy"', 1, true) ~= nil)) then
            prefsUnsupported = true;

            return;
        end

        -- And again for the warehouse planner (1.21). BOTH spellings, for the
        -- reason the stack flag gives below: a map whose squad_storage.lua
        -- knows `restock` but whose binary predates DwSquadWarehouseUpgrades
        -- answers with a sentence of its own, and both mean the same thing to
        -- this face -- there is no warehouse planning on this server yet.
        if (kind == 'e' and not restockUnsupported
                and (string.find(line, 'unknown verb "restock"', 1, true) ~= nil
                     or string.find(line, 'warehouse gear planner is not', 1, true) ~= nil)) then
            restockUnsupported = true;

            return;
        end

        -- And again for the stack combiner. The stale-binary spelling is
        -- matched as well as the stale-Lua one: a map whose squad_storage.lua
        -- knows the verb but whose binary predates DwBagStack answers with a
        -- sentence of its own, and both mean the same thing to this button.
        if (kind == 'e' and not stackUnsupported
                and (string.find(line, 'unknown verb "stack"', 1, true) ~= nil
                     or string.find(line, 'does not have bag stacking', 1, true) ~= nil)) then
            stackUnsupported = true;

            return;
        end

        -- And again for the destructive pair (1.22). Both spellings each, for
        -- the stack flag's reason: stale Lua answers unknown-verb, a stale
        -- BINARY behind current Lua answers with its own sentence.
        if (kind == 'e' and not trashUnsupported
                and (string.find(line, 'unknown verb "trash"', 1, true) ~= nil
                     or string.find(line, 'does not have the trash verb', 1, true) ~= nil)) then
            trashUnsupported = true;

            return;
        end

        if (kind == 'e' and not stashUnsupported
                and (string.find(line, 'unknown verb "stash"', 1, true) ~= nil
                     or string.find(line, 'does not have the stash verb', 1, true) ~= nil)) then
            stashUnsupported = true;

            return;
        end

        -- And again for the batch pair (1.30). ONLY the unknown-verb spelling
        -- for `trashmany`: a binary that predates DwAltTrash answers BOTH the
        -- single and the batch verb with "does not have the trash verb", and
        -- that sentence is already the single flag's -- matching it here too
        -- would be correct and would also be the second latch catching the
        -- first one's message, which is exactly the confusion the closing
        -- quote below exists to avoid. The single flag hides both controls in
        -- that case anyway, because a bag with no trash verb has no batch
        -- trash either.
        --
        -- THE CLOSING QUOTE IS WHAT KEEPS THESE APART, the stashall rule:
        -- `unknown verb "trashmany"` does not contain `unknown verb "trash"`.
        if (kind == 'e' and not trashManyUnsupported
                and string.find(line, 'unknown verb "trashmany"', 1, true) ~= nil) then
            trashManyUnsupported = true;
            state.batchAsk       = nil;

            return;
        end

        -- Vendor gets both spellings, the stack flag's reason: stale Lua
        -- answers with the dispatch's unknown-verb sentence, a stale BINARY
        -- behind current Lua answers with its own.
        if (kind == 'e' and not vendorUnsupported
                and (string.find(line, 'unknown verb "vendor"', 1, true) ~= nil
                     or string.find(line, 'does not have the vendor verb', 1, true) ~= nil)) then
            vendorUnsupported = true;
            state.batchAsk    = nil;

            return;
        end

        -- And again for the bulk stash (1.28). BOTH spellings, the stack
        -- flag's reason: stale Lua answers with the dispatch's unknown-verb
        -- sentence, a stale BINARY behind current Lua answers with its own.
        --
        -- THE CLOSING QUOTE IS WHAT KEEPS THESE TWO LATCHES APART. `unknown
        -- verb "stashall"` does not contain `unknown verb "stash"` -- the
        -- test above looks for the quote as well as the word -- so a server
        -- without the bulk verb hides this button alone and leaves the
        -- per-row Stash exactly where it was.
        if (kind == 'e' and not stashAllUnsupported
                and (string.find(line, 'unknown verb "stashall"', 1, true) ~= nil
                     or string.find(line, 'does not have the bulk stash verb', 1, true) ~= nil)) then
            stashAllUnsupported = true;
            state.stashAllAsk   = nil;

            return;
        end

        -- And again for the automaton pair (1.27). Both spellings each, for
        -- the stack flag's reason: a server whose squad_storage.lua predates
        -- the verb answers with the dispatch's own unknown-verb sentence, and
        -- a map whose Lua knows the verb but whose BINARY predates the
        -- binding answers with a sentence of its own. Both mean the same
        -- thing to the control -- there is no automaton editing here yet.
        if (kind == 'e' and not puppetUnsupported
                and (string.find(line, 'unknown verb "unlock"', 1, true) ~= nil
                     or string.find(line, 'Fitting an automaton part', 1, true) ~= nil)) then
            puppetUnsupported = true;

            return;
        end

        if (kind == 'e' and not autonameUnsupported
                and (string.find(line, 'unknown verb "autoname"', 1, true) ~= nil
                     or string.find(line, 'Automaton names are not available', 1, true) ~= nil)) then
            autonameUnsupported = true;

            return;
        end

        -- Everything after the first pipe, not parts[2]: these carry prose and
        -- an item name may contain anything.
        state.status  = line:sub(3);
        state.statusBad = (kind == 'e');

        -- Also to the chat log: the window may not be open, and "nothing
        -- happened" is the worst possible feedback for a refused transfer.
        if (kind == 'e') then
            -- AND it invalidates every chained line still in the queue. See
            -- issueChained: a `send` queued behind a `fetch` that was just
            -- refused would otherwise ship the caller's own copy.
            errorSeq = errorSeq + 1;

            print(chat.header('dwbags'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        state.inbound = nil;

        -- THE COMMIT (1.24): the staged sections replace the live ones in
        -- one frame. A verb whose envelope carried no rows commits an empty
        -- section, which is the honest answer and exactly what the wipe
        -- used to produce -- only now the old rows stood until this moment.
        if (arriving ~= nil) then
            local verb = arriving.verb;

            for _, section in ipairs(SECTIONS[verb] or { }) do
                if (arriving[section] ~= nil) then
                    state[section] = arriving[section];
                end
            end

            -- A fresh list re-reads its rows' DAT flags once: the cache is
            -- per answer, not per session, so the cost is a lookup per row
            -- per answer instead of three per row per frame.
            if (verb == 'bag' or verb == 'find') then
                datFlagCache = { };
            end

            arriving = nil;

            -- The one place a server answer changes the model; every
            -- per-frame view keys on this (see modelRev).
            bumpModel();

            afterCommit(verb);
        end

        return;
    end

    -- The envelope gate (2026-09-06). See RECORD_ENVELOPES: `f|` and `g|`
    -- mean something else inside the roster envelope, which dwsquad shares
    -- with this addon, and one of those two writes a phantom gear row.
    local carriedBy = RECORD_ENVELOPES[kind];

    if (carriedBy ~= nil and SECTIONS[state.inbound] ~= nil
            and not carriedBy[state.inbound]) then
        return;
    end

    if (kind == 'c') then
        local charid = wireInt(parts[2], 0);
        local chars  = target('chars');

        --[[
            The experience tail (exp, next, xflags) has ridden this record
            since the roster grew it for dwsquad, and this addon parsed
            ten fields and stopped -- so the one window that draws a
            character list threw away the only numbers on the wire that say
            how far along that character is. Read now and rendered in the
            roster's hover card (1.25). `or 0` on every one of them, exactly
            as the emitter writes them: a server from before the tail sends
            nine fields and the card simply has nothing to say about levels.
            xflags: 1 the character is at the level cap, 2 it is earning
            merit points.
        --]]
        chars[charid] = T{
            charid = charid,
            -- `or '?'` for the wireInt reason one field over: the name is
            -- concatenated into a label and formatted into every command
            -- this window sends, and `string.format('%s', nil)` raises --
            -- inside the render pcall, which closes the window. A record
            -- with no name is a record the server cannot have sent; the
            -- fallback costs one refused command instead of the session.
            name   = parts[3] or '?',
            mjob   = wireInt(parts[4], 0),
            mlvl   = wireInt(parts[5], 0),
            sjob   = wireInt(parts[6], 0),
            slvl   = wireInt(parts[7], 0),
            flags  = wireInt(parts[8], 0),
            used   = wireInt(parts[9], 0),
            size   = wireInt(parts[10], 0),
            slot   = wireInt(parts[11], 0),
            exp    = wireInt(parts[12], 0),
            next   = wireInt(parts[13], 0),
            xflags = wireInt(parts[14], 0),
            order  = charid,
        };

        -- Default the selection to the character being played, and the Send
        -- target to the first character that is not them, so the window is
        -- usable on the frame it opens rather than after two clicks.
        if (state.selected == nil and bit.band(chars[charid].flags, CHAR_SELF) ~= 0) then
            state.selected = charid;
        end

        if (state.sendTo == nil and bit.band(chars[charid].flags, CHAR_SELF) == 0) then
            state.sendTo = charid;
        end

        return;
    end

    -- THE PER-CHARACTER RECORDS ARE FILTERED AGAINST THE SELECTION. Click
    -- character A, then B inside the queue's 1.2s interval, and A's response
    -- arrives while B is selected -- without this check A's bags filled B's
    -- panel for a second or two before B's response corrected it. Records for
    -- anybody but the character on screen are simply not ours to render; the
    -- request for the right one is already in the queue.
    if (kind == 'n') then
        local charid = wireInt(parts[2], 0);
        local loc    = wireInt(parts[3], 0);

        if (charid ~= state.selected) then
            return;
        end

        local bags = target('bags');

        bags[loc] = bags[loc] or T{ items = T{ } };
        bags[loc].used = wireInt(parts[4], 0);
        bags[loc].size = wireInt(parts[5], 0);

        return;
    end

    if (kind == 'i') then
        local charid = wireInt(parts[2], 0);
        local loc    = wireInt(parts[3], 0);

        if (charid ~= state.selected) then
            return;
        end

        local bags = target('bags');

        bags[loc] = bags[loc] or T{ items = T{ }, used = 0, size = 0 };

        for _, row in ipairs(parsePacked(charid, loc, parts[4])) do
            bags[loc].items:append(row);
        end

        return;
    end

    if (kind == 'f') then
        local charid = wireInt(parts[2], 0);
        local loc    = wireInt(parts[3], 0);
        local finds  = target('finds');

        for _, row in ipairs(parsePacked(charid, loc, parts[4])) do
            finds:append(row);
        end

        return;
    end

    -- a| -- augment values for rows already sent (1.18.0, server 2026-08-25;
    -- ADDITIVE, protocol still 1 -- an older server never sends it and the
    -- card keeps its flag-2 "Augmented" note). Emitted AFTER the i|/f|
    -- lines it decorates, so the rows exist by the time this runs; a record
    -- that matches no row decorates nothing, the v|-to-c| rule. Bag rows
    -- are filtered by the selected character exactly as i| is; find rows
    -- are not, exactly as f| is not.
    if (kind == 'a') then
        local charid = wireInt(parts[2], 0);
        local loc    = wireInt(parts[3], 0);

        for _, entry in ipairs(split(parts[4] or '', ',')) do
            local bits = split(entry, ':');
            local slot = wireInt(bits[1], -1);
            local augs = T{ };

            -- The tail is flat id:rank pairs; the loop is bounded by the
            -- entry itself (at most four slots server-side), and a torn
            -- pair at the end is dropped rather than half-read.
            for index = 2, #bits - 1, 2 do
                local id   = wireInt(bits[index], 0);
                local rank = wireInt(bits[index + 1], 0);

                if (id > 0 and rank > 0 and #augs < 4) then
                    augs:append({ id = id, rank = rank });
                end
            end

            if (#augs > 0) then
                local bags  = target('bags');
                local finds = target('finds');

                if (charid == state.selected and bags[loc] ~= nil) then
                    for _, row in ipairs(bags[loc].items) do
                        if (row.slot == slot) then
                            row.augs = augs;
                        end
                    end
                end

                for _, row in ipairs(finds) do
                    if (row.charid == charid and row.loc == loc and row.slot == slot) then
                        row.augs = augs;
                    end
                end
            end
        end

        return;
    end

    --[[
        v| -- what a merchant pays for one of each item id in this answer
        (1.30, server 2026-09-14; ADDITIVE, protocol still 1). Emitted after
        the rows it prices, like a|, and keyed by ITEM ID rather than by cell
        because a price is a property of the item template.

        MERGED AND KEPT, not staged and not replaced. Every other table here
        describes a bag, which changes; this one describes the game's own
        price list, which does not -- so a `bag` read of a second character
        costs nothing to price, and a Find hit on a character whose bags have
        never been opened still knows what its rows are worth. A login clears
        it with the rest of the account view.

        A price of 0 is an answer: no merchant will buy it. An id that never
        arrives is NOT an answer, and the window says nothing about it rather
        than calling it worthless -- see `priced`.
    --]]
    if (kind == 'v') then
        for _, entry in ipairs(split(parts[2] or '', ',')) do
            local bits  = split(entry, ':');
            local id    = wireInt(bits[1], 0);
            local price = wireInt(bits[2], -1);

            if (id > 0 and price >= 0) then
                state.prices[id] = price;
                state.priced     = true;
            end
        end

        return;
    end

    --[[
        b| -- one cell's verdict inside a batch (1.30). EVERY cell the batch
        was given gets one, in order, whether it worked or not, and every one
        of them is printed: a bulk destructive verb that reported only its
        successes would leave an item silently un-destroyed, which is the one
        outcome worse than a refusal. This is the same volume of chat the
        one-command-per-row shape would have produced, which is the standard
        it has to meet.

        THE SENTENCE IS BUILT HERE FROM THE SERVER'S ONE-WORD REASON, not
        shipped as prose: names never ride this wire, and a refusal sentence
        per cell would be a chat packet per cell.
    --]]
    if (kind == 'b') then
        local loc    = wireInt(parts[2], 0);
        local slot   = wireInt(parts[3], 0);
        local itemid = wireInt(parts[4], 0);
        local qty    = wireInt(parts[5], 0);
        local ok     = wireInt(parts[6], 0) ~= 0;
        local sale   = state.inbound == 'vendor';

        local what = string.format('%s%s (%s slot %d)',
            itemName(itemid), qty > 1 and string.format(' x%d', qty) or '',
            LOC_NAMES[loc] or tostring(loc), slot);

        if (ok) then
            print(chat.header('dwbags'):append(chat.message(
                string.format('%s %s.', sale and 'Sold' or 'Threw away', what))));
        else
            print(chat.header('dwbags'):append(chat.error(
                string.format('%s %s -- %s.', sale and 'Did not sell' or 'Did not throw away',
                    what, BATCH_REASONS[parts[7] or ''] or 'the server refused it'))));
        end

        return;
    end

    --[[
        l| -- the batch ledger (1.30), the last record of a batch envelope.

        A SELECTION IS USUALLY MORE THAN ONE LINE, because a packed command
        has to fit the client's 128-byte chat line -- so the running tally
        lives here and the status bar reads the WHOLE press, not its last
        sixth. `batchTally.cells` is what the player agreed to in the popup,
        so the sentence compares against that rather than against the number
        of lines that happen to have come back.
    --]]
    if (kind == 'l') then
        local done   = wireInt(parts[2], 0);
        local failed = wireInt(parts[3], 0);
        local gil    = wireInt(parts[4], 0);

        if (batchTally == nil) then
            -- A batch typed by hand, or one whose tally a login cleared. The
            -- verdict is still worth saying; it just cannot be totalled.
            batchTally = { sale = state.inbound == 'vendor', cells = done + failed,
                           lines = 1, done = 0, failed = 0, gil = 0 };
        end

        batchTally.done   = batchTally.done + done;
        batchTally.failed = batchTally.failed + failed;
        batchTally.gil    = batchTally.gil + gil;
        batchTally.lines  = batchTally.lines - 1;

        local seen = batchTally.done + batchTally.failed;

        if (batchTally.sale) then
            state.status = string.format('Sold %d of %d for %s gil%s.',
                batchTally.done, math.max(batchTally.cells, seen), commaGil(batchTally.gil),
                batchTally.failed > 0
                    and string.format('; %d refused (see the chat log)', batchTally.failed)
                    or '');
        else
            state.status = string.format('Threw away %d of %d%s.',
                batchTally.done, math.max(batchTally.cells, seen),
                batchTally.failed > 0
                    and string.format('; %d refused (see the chat log)', batchTally.failed)
                    or '');
        end

        state.statusBad = batchTally.failed > 0;

        if (batchTally.lines <= 0) then
            batchTally = nil;
        end

        return;
    end

    if (kind == 'g') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if (wireInt(parts[2], 0) ~= state.selected) then
            return;
        end

        local slot = wireInt(parts[3], 0);

        target('gear')[slot] = T{
            slot   = slot,
            itemid = wireInt(parts[4], 0),
            loc    = wireInt(parts[5], 0),
            score  = wireInt(parts[7], 0),
            pinned = wireInt(parts[8], 0) ~= 0,
            augs   = augsFromTail(parts[9]),
        };

        return;
    end

    if (kind == 'k') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if (wireInt(parts[2], 0) ~= state.selected) then
            return;
        end

        local slot    = wireInt(parts[3], 0);
        local options = target('options');

        options[slot] = options[slot] or T{ };
        options[slot]:append(T{
            slot   = slot,
            itemid = wireInt(parts[4], 0),
            loc    = wireInt(parts[5], 0),
            score  = wireInt(parts[7], 0),
            augs   = augsFromTail(parts[8]),
        });

        -- Sorted HERE rather than at draw time, and with a tiebreak.
        --
        -- Lua's table.sort is not stable, so two items on an equal score can
        -- swap places on every sort. Sorting inside the render pass therefore
        -- re-ordered the column sixty times a second and the names appeared to
        -- alternate -- which is the flicker that made the Gear tab unreadable.
        -- Item id breaks the tie so that "equal score" still has one true order.
        table.sort(options[slot], function (a, b)
            if (a.score == b.score) then
                return a.itemid < b.itemid;
            end

            return a.score > b.score;
        end);

        return;
    end

    -- w| -- owned but not wearable, with the server's reason (1.23). Arrives
    -- only on the slot-scoped ask the Manual picker sends, so it renders
    -- there and nowhere else. `w|<charid>|<slot>|<itemid>|<reason>` -- the
    -- reason is the last field and may contain spaces.
    if (kind == 'w') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if (wireInt(parts[2], 0) ~= state.selected) then
            return;
        end

        local slot    = wireInt(parts[3], 0);
        local refused = target('refused');

        refused[slot] = refused[slot] or T{ };
        refused[slot]:append(T{
            slot   = slot,
            itemid = wireInt(parts[4], 0),
            reason = parts[5] or '',
        });

        return;
    end

    if (kind == 'h') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if (wireInt(parts[2], 0) ~= state.selected) then
            return;
        end

        local slot = wireInt(parts[3], 0);

        -- One upgrade per slot: records arrive biggest-improvement first, so
        -- the first to land for a slot is the one worth drawing.
        local hints = target('hints');

        if (hints[slot] == nil) then
            hints[slot] = T{
                slot       = slot,
                itemid     = wireInt(parts[4], 0),
                fromcharid = wireInt(parts[5], 0),
                loc        = wireInt(parts[6], 0),
                bagslot    = wireInt(parts[7], 0),
                score      = wireInt(parts[8], 0),
                worn       = wireInt(parts[9], 0),
            };
        end

        return;
    end

    -- u| -- one warehouse restock line (1.21).
    --
    -- `u|<charid>|<slot>|<itemid>|<rowid>|<score>|<wornscore>|<augs>`, and the
    -- ROW ID is the field that matters: two stored copies of one item id can
    -- differ by their augments, so a click that named the item could deliver
    -- the wrong one. The apply button hands this number straight back.
    if (kind == 'u') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if (wireInt(parts[2], 0) ~= state.selected) then
            return;
        end

        local slot = wireInt(parts[3], 0);

        -- One upgrade per slot, first record wins -- the h| rule, and for the
        -- same reason: the server emits at most one per slot already, so a
        -- second would be a duplicate rather than a runner-up.
        local restock = target('restock');

        if (restock[slot] == nil) then
            local score     = wireInt(parts[6], 0);
            local wornscore = wireInt(parts[7], 0);

            restock[slot] = T{
                slot      = slot,
                itemid    = wireInt(parts[4], 0),
                rowid     = wireInt(parts[5], 0),
                score     = score,
                wornscore = wornscore,
                -- Formatted once (1.25): the pane redrew it sixteen times a
                -- frame out of two fields that cannot change after this line.
                deltatext = string.format('+%d', score - wornscore),
                augs      = augsFromTail(parts[8]),
            };
        end

        return;
    end

    if (kind == 'y') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if (wireInt(parts[2], 0) ~= state.selected) then
            return;
        end

        -- The layout is a scalar: staged as a field when a bagpref read is
        -- open, live otherwise.
        if (arriving ~= nil and arriving.verb == 'bagpref') then
            arriving.layout = wireInt(parts[3], 255);
        else
            state.layout = wireInt(parts[3], 255);
        end

        return;
    end

    if (kind == 'p') then
        -- Same selection filter as `n`/`i` above, for the same race.
        if (wireInt(parts[2], 0) ~= state.selected) then
            return;
        end

        local prefs = target('prefs');

        -- `<class>:<loc>:<isdefault>:<free>,...`
        for _, entry in ipairs(split(parts[3], ',')) do
            local bits = split(entry, ':');

            if (#bits >= 4) then
                prefs[wireInt(bits[1], 0)] = T{
                    loc       = wireInt(bits[2], 0),
                    isdefault = wireInt(bits[3], 0) ~= 0,
                    free      = wireInt(bits[4], 0),
                };
            end
        end

        return;
    end

    if (kind == 'x') then
        local charid = wireInt(parts[2], 0);

        -- Foreign rows are dropped the way every other per-character record
        -- drops them: an older server's box envelope carries no charid stamp,
        -- so a stale reply would otherwise fill this section with the
        -- previously selected character's deliveries.
        if (state.selected ~= nil and charid ~= state.selected) then
            return;
        end

        local qty = wireInt(parts[4], 0);

        target('box'):append(T{
            charid  = charid,
            itemid  = wireInt(parts[3], 0),
            qty     = qty,
            qtytext = qty > 1 and string.format('x%d', qty) or '',
            sender  = parts[5],
        });

        return;
    end

    --[[
        r| -- the names an automaton may be given (1.27), packed the way i|
        and f| pack items: `r|<id>:<name>,<id>:<name>,...`.

        THE NAMES ARE THE SERVER'S AND NOT THIS FILE'S. Every other list this
        window draws is resolved out of the client's own DAT by id -- which is
        exactly why the wire carries no item names -- and an automaton name is
        the one thing the client has no resource for: it lives in the server's
        pet_name table, which is also the table the squad reads when it paints
        the puppet. So it comes down the wire, and a name added to that table
        is offered here without this file being touched.
    --]]
    if (kind == 'r') then
        local names = target('autoNames');

        for _, entry in ipairs(split(parts[2] or '', ',')) do
            -- Comma first, then colon: the pair is `<id>:<name>` and a torn
            -- tail is dropped rather than half-read, the a| record's rule.
            local bits = split(entry, ':');
            local id   = wireInt(bits[1], 0);
            local text = bits[2];

            if (id > 0 and text ~= nil and text ~= '') then
                names:append(T{ id = id, name = text });
            end
        end

        return;
    end

    -- s| -- what the selected character's automaton is called right now.
    -- Filtered against the selection like every other per-character record,
    -- for the same race: click A then B inside the send interval and A's
    -- answer arrives while B is on screen.
    if (kind == 's') then
        if (wireInt(parts[2], 0) ~= state.selected) then
            return;
        end

        local current = target('autoName');

        current.id   = wireInt(parts[3], 0);
        current.name = parts[4] or '';

        return;
    end

    --[[
        q| -- the bulk stash's verdict (1.28), the only record the `stashall`
        envelope carries:

          q|<charid>|<loc>|<moved>|<skipped>|<needed>|<free>|<fits>|<dry>|<used>|<cap>

        A DRY RUN IS WHAT OPENS THE CONFIRMATION, and that is the whole point
        of the field: the question a player is asked ("Send 47 items ...")
        has to carry the number the SERVER counted under its own eligibility
        screen, not a number this side guessed by counting rows it can see.
        The two disagree for good reasons -- a worn piece, a bazaared price,
        a linkshell -- and a confirmation that names the wrong count is worse
        than none.

        A real answer (dry = 0) closes the question whatever it says: the
        move either happened or was refused for room, and the m| note beside
        this record is already in the status bar saying which.

        Filtered against the selection like every other per-character record,
        for the race the s| record names: click Alta, click Betta, and Alta's
        answer lands while Betta is on screen.
    --]]
    if (kind == 'q') then
        local charid = wireInt(parts[2], 0);

        if (state.selected ~= nil and charid ~= state.selected) then
            return;
        end

        if (wireInt(parts[9], 0) == 0) then
            state.stashAllAsk = nil;

            return;
        end

        local entry = state.chars[charid];

        state.stashAllAsk = {
            charid   = charid,
            charname = entry ~= nil and entry.name or nil,
            loc      = wireInt(parts[3], 0),
            count    = wireInt(parts[4], 0),
            skipped  = wireInt(parts[5], 0),
            needed   = wireInt(parts[6], 0),
            free     = wireInt(parts[7], 0),
            fits     = wireInt(parts[8], 0) ~= 0,
        };

        return;
    end

end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017.
*
* Layout after the 4-byte header: Kind at 0x04, Attr at 0x05, Data at 0x06,
* sName[15] at 0x08, Mes at 0x17. Any line whose sender is _DWDATA is ours: it
* is consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwbags_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwbags'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

-- Characters in charid order, which is creation order and is stable.
--
-- Built once per model revision (1.25): this allocated a table and sorted it
-- TWICE a frame -- once for the character list, once for the "Send to" combo
-- -- for a list that only changes when a roster answer commits.
local orderedCache = nil;
local orderedRev   = -1;

local function orderedChars()
    if (orderedCache ~= nil and orderedRev == modelRev) then
        return orderedCache;
    end

    local ordered = T{ };

    for _, member in pairs(state.chars) do
        ordered:append(member);
    end

    table.sort(ordered, function (a, b) return a.order < b.order; end);

    orderedCache = ordered;
    orderedRev   = modelRev;

    return ordered;
end

--[[
* The roster row's two lines, cached on the member record (1.25). The roster
* is replaced wholesale by its own answer, so these are built once per read
* instead of twice a frame per character -- the character list draws them and
* the "Send to" combo walks the same list.
--]]
local function charRowLabel(member)
    if (member.rowlabel == nil) then
        local tag = '';

        if (bit.band(member.flags, CHAR_SELF) ~= 0) then
            tag = ' (you)';
        elseif (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
            tag = ' [out]';
        elseif (bit.band(member.flags, CHAR_ONLINE) ~= 0) then
            tag = ' [on]';
        end

        member.rowlabel = member.name .. tag;
    end

    return member.rowlabel;
end

-- Both jobs as a player says them -- `WAR75 / THF37`, or the main job and a
-- plain statement that there is no support job, which is a fact about a
-- squad member worth saying rather than leaving to be inferred.
local function charJobText(member)
    if (member.jobtext == nil) then
        if (member.sjob > 0 and member.slvl > 0) then
            member.jobtext = string.format('%s%d / %s%d',
                JOB_NAMES[member.mjob] or '?', member.mlvl,
                JOB_NAMES[member.sjob] or '?', member.slvl);
        else
            member.jobtext = string.format('%s%d, no support job',
                JOB_NAMES[member.mjob] or '?', member.mlvl);
        end
    end

    return member.jobtext;
end

-- Which job the Gear tab's whole column is an opinion ABOUT (1.25). The
-- scorer picks for the role the member's MAIN job plays, and the tab never
-- said which job that was -- so a column that had quietly re-scored itself
-- after a job change read as a column that had changed its mind.
local function charScoredFor(member)
    if (member.scoredfor == nil) then
        member.scoredfor = string.format('-- scored for %s', charJobText(member));
    end

    return member.scoredfor;
end

local function charRowJobs(member)
    if (member.rowjobs == nil) then
        if (member.sjob > 0 and member.slvl > 0) then
            member.rowjobs = string.format('  %s%d/%s%d  %d/%d',
                JOB_NAMES[member.mjob] or '?', member.mlvl,
                JOB_NAMES[member.sjob] or '?', member.slvl,
                member.used, member.size);
        else
            member.rowjobs = string.format('  %s%d  %d/%d',
                JOB_NAMES[member.mjob] or '?', member.mlvl, member.used, member.size);
        end
    end

    return member.rowjobs;
end

--[[
* WHERE A SEND TO THIS CHARACTER LANDS (1.25), said at the moment of
* choosing rather than after the transfer.
*
* The row's own button reads "Send 7 to Alta" whichever of the three states
* Alta is in, and the difference between them is the whole question: written
* straight into the bag, or parked in the delivery box until the next time
* she is called. The rule is the server's (alt_storage.cpp writes the row
* unless the recipient is logged in or every bag it could reach is full);
* this only says it before the click. Cached on the member record, which is
* replaced by every roster answer.
--]]
local function sendLandsText(member)
    if (member.sendlands == nil) then
        if (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
            member.sendlands = 'Out with you now: a send is written into their bag, and they are\n'
                .. 'wearing it the next time you call them.';
        elseif (bit.band(member.flags, CHAR_ONLINE) ~= 0) then
            member.sendlands = 'Logged in on another client: a send goes to their delivery box and\n'
                .. 'arrives the next time you call them.';
        else
            member.sendlands = 'Offline: a send is written straight into their bag.';
        end
    end

    return member.sendlands;
end

-- The character flags in words, for the card: what being (you), [out] or
-- [on] actually means for a Send, which is the half of the tag a player
-- cannot work out from the tag.
local function charStateText(member)
    if (bit.band(member.flags, CHAR_SELF) ~= 0) then
        return 'This is you.';
    end

    if (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
        return 'Out with you right now as a squad member.';
    end

    if (bit.band(member.flags, CHAR_ONLINE) ~= 0) then
        return 'Logged in on another client. Sends land in the delivery box.';
    end

    return 'Offline. Sends land straight in the bag.';
end

--[[
* The roster hover card (1.25).
*
* Every number here was already on the `c|` record and none of it was drawn:
* the sub job, how far the character is from its next level, whether it is at
* the cap or earning merits, and what the used/size pair on the row actually
* counts. The row itself stays two short lines -- the pane is 190 pixels
* wide and a name plus a tag already fills it -- so the detail goes where
* every other detail in this window goes.
--]]
local function charCard(member)
    imgui.BeginTooltip();

    imgui.Text(member.name);

    imgui.TextColored(theme.colors.info, charJobText(member));

    if (bit.band(member.xflags, 2) ~= 0) then
        imgui.TextDisabled('Earning merit points.');
    elseif (bit.band(member.xflags, 1) ~= 0) then
        imgui.TextDisabled('At the level cap.');
    elseif (member.next > 0) then
        imgui.TextDisabled(string.format('%d of %d experience to the next level.',
            member.exp, member.next));
    end

    imgui.Separator();
    imgui.Text(string.format('%d of %d cells used, %d free.',
        member.used, member.size, math.max(member.size - member.used, 0)));
    imgui.TextDisabled(charStateText(member));

    if (member.slot > 0) then
        imgui.TextDisabled(string.format('Squad slot %d.', member.slot));
    end

    imgui.EndTooltip();
end

local function charList()
    -- NOTE: the third argument is ImGuiChildFlags, not a bool. Ashita ships an
    -- ImGui new enough to have made that change (1.90), and passing `true` here
    -- raises a Lua error on every single frame -- which the addon host answers
    -- by unloading the addon after enough of them.
    imgui.BeginChild('##dwbags_chars', { 190, 0 }, ImGuiChildFlags_Borders);

    for _, member in ipairs(orderedChars()) do
        if (imgui.Selectable(charRowLabel(member), state.selected == member.charid)) then
            state.selected = member.charid;

            -- Nothing is fetched here: whichever tab is on screen asks for its
            -- own data on the next frame, so switching characters costs one
            -- command rather than three.
            forget();

            -- EVERY per-character section, and `refused`/`restock` were the
            -- two this list forgot (2026-09-06). The Manual picker went on
            -- naming the last character's un-wearable pieces, and -- worse --
            -- the Warehouse face went on drawing the last character's plan
            -- under the new character's name, with a per-row Send that would
            -- have delivered that warehouse row to whoever is selected NOW.
            -- The plan is keyed by slot and says nothing about whose it is,
            -- so nothing on screen distinguished it from a fresh answer.
            state.bags    = T{ };
            state.gear    = T{ };
            state.options = T{ };
            state.refused = T{ };
            state.hints   = T{ };
            state.restock = T{ };
            state.box     = T{ };
            state.prefs   = T{ };
            state.layout  = 255;
            -- The automaton pair with the rest (1.27). `autoName` is per
            -- character and would otherwise go on naming the last one's
            -- automaton under this one's name -- the `restock` mistake. The
            -- unapplied pick goes too: it is an intention about a character
            -- that is no longer selected.
            state.autoName  = T{ };
            state.autoNames = T{ };
            state.autoPick  = nil;

            -- The bulk stash's pair goes with them (1.28), and the pending
            -- QUESTION matters more than the pick: it names a character and
            -- a container, and a popup left standing across a selection
            -- change would be asking about one character's bag with another
            -- character's name at the top of the window. `state.bags` has
            -- just been emptied, so the pick is re-defaulted on the next
            -- frame from the new character's own containers.
            state.stashAllAsk = nil;
            state.stashAllBag = nil;

            -- The sections just changed without a server answer, so every
            -- view cached against the model has to be rebuilt -- including
            -- when the click lands on the character ALREADY selected, where
            -- the filter key by itself would not have moved (1.25).
            bumpModel();
        end

        -- The card on the row, where the sub job, the experience tail and
        -- what the two numbers below actually count all live (1.25).
        if (imgui.IsItemHovered()) then
            charCard(member);
        end

        -- The support job on the row itself: two more words in a line that
        -- had four, in a pane that is 190 pixels wide -- and "WAR75" alone
        -- never said whether the character had a support job at all.
        imgui.TextDisabled(charRowJobs(member));
    end

    imgui.EndChild();
end

local function selectedName()
    local member = state.selected ~= nil and state.chars[state.selected] or nil;

    return member ~= nil and member.name or nil;
end

local function isSelf(charid)
    local member = state.chars[charid];

    return member ~= nil and bit.band(member.flags, CHAR_SELF) ~= 0;
end

--[[
* The card's augment argument for a wire row (1.18.0). Values come from
* wherever the bytes are readable, freshest first: the viewing character's
* OWN rows read Extra straight off the container (guarded by an id match,
* because the wire row can be a frame stale -- the same staleness R3
* catches server-side); any row the server decorated with an a| record
* renders those values; an augmented row with neither gets `true` and the
* card says "Augmented" without inventing anything (an old server, or a
* signed/charged blob with no standard slots to say).
--]]
local function augArgFor(row)
    if (row == nil or bit.band(row.flags or 0, ITEM_AUGMENTED) == 0) then
        return nil;
    end

    if (isSelf(row.charid)) then
        local memory    = AshitaCore:GetMemoryManager();
        local inventory = memory ~= nil and memory:GetInventory() or nil;
        local item      = inventory ~= nil and inventory:GetContainerItem(row.loc, row.slot) or nil;

        if (item ~= nil and item.Id == row.itemid) then
            local augs = extraAugments(item.Extra);

            if (augs ~= nil) then
                return augs;
            end
        end
    end

    if (type(row.augs) == 'table' and #row.augs > 0) then
        return row.augs;
    end

    return true;
end

--[[
* The card for a WIRE ROW, whose augment argument is worked out only for the
* row actually under the mouse (1.25).
*
* `augArgFor` is not free: on the viewing character's own augmented rows it
* asks the memory manager for the container cell and decodes twenty-eight
* bytes of exdata. Passing it to cardOnHover as an ARGUMENT ran it for every
* drawn row on every frame -- three hundred of them on a full page -- to
* answer a question about the one row being hovered, if any.
--]]
local function rowCardOnHover(row, hoveredIcon)
    if (imgui.IsItemHovered() or hoveredIcon == true) then
        itemCard(row.itemid, augArgFor(row));
    end
end

--[[
* The widget ids for one row, built once and kept ON the row (1.25).
*
* Six string.formats per row per frame is what this replaces: the id itself,
* plus one per button, over a three-hundred-row page, sixty times a second.
* The labels are a pure function of (charid, loc, slot) -- and ImGui needs
* the same bytes every frame for a click to stay attached to the same widget
* -- while the row table is replaced wholesale by the next answer, so the
* cache lives and dies with the row it names.
--]]
local function rowIds(row)
    local ids = row.ids;

    if (ids == nil) then
        local id = string.format('%d_%d_%d', row.charid, row.loc, row.slot);

        ids = {
            use    = 'Use##u'    .. id,
            fetch  = 'Fetch##f'  .. id,
            send   = 'Send##s'   .. id,
            stash  = 'Stash##w'  .. id,
            trash  = 'Trash##x'  .. id,
            unlock = 'Unlock##p' .. id,
            -- 1.30. `sell` is the merchant button, `tick` the selection box
            -- and `same` the "select every row of this item" button beside
            -- it; the key is the tick's own, built here so the table draw
            -- formats nothing per frame like everything else on this row.
            sell   = 'Sell##v'   .. id,
            tick   = '##t'       .. id,
            same   = '+##a'      .. id,
            key    = id,
        };

        row.ids = ids;
    end

    return ids;
end

-- The name cell with its augment mark, cached on the row for the same
-- reason (1.25): the concatenation built a fresh string for every augmented
-- row on every frame. Also used by the Find tab, which drew the bare name
-- and so was the one list where an augmented copy looked ordinary.
local function rowName(row)
    local text = row.nametext;

    if (text == nil) then
        text = itemName(row.itemid);

        if (bit.band(row.flags or 0, ITEM_AUGMENTED) ~= 0) then
            text = text .. ' +';
        end

        row.nametext = text;
    end

    return text;
end

--[[
* The Gear tab's per-record button labels, cached on the record (1.25).
*
* rowIds' argument one tab over: the Automatic column formatted a label per
* alternative per frame, the Manual picker up to sixty of them, and the slot
* list sixteen more -- all a pure function of an item id and a position that
* cannot move once the answer has committed, because the `k|` records are
* sorted by the record handler and the whole section is replaced at `z|`.
--]]
local function pinLabel(option, slot, index)
    if (option.pinlabel == nil) then
        option.pinlabel = string.format('%s##pin_%d_%d', itemName(option.itemid), slot, index);
    end

    return option.pinlabel;
end

local function pickLabel(option, slot, index)
    if (option.picklabel == nil) then
        option.picklabel = string.format('%s##mpick_%d_%d', itemName(option.itemid), slot, index);
    end

    return option.picklabel;
end

local function getLabel(hint, slot)
    if (hint.getlabel == nil) then
        hint.getlabel = string.format('Get %s##up_%d', itemName(hint.itemid), slot);
    end

    return hint.getlabel;
end

-- The Manual face's slot-list row -- `main: Bronze Sword *` -- cached on the
-- worn record. An empty slot's label is fixed at load (SLOT_IDS.empty).
local function slotListLabel(slot, worn)
    if (worn == nil) then
        return SLOT_IDS[slot].empty;
    end

    if (worn.slotlabel == nil) then
        worn.slotlabel = string.format('%s: %s%s##mslot_%d',
            SLOT_NAMES[slot], itemName(worn.itemid), worn.pinned and ' *' or '', slot);
    end

    return worn.slotlabel;
end

--[[
* Re-ask for whatever is on screen after a transfer.
*
* forget() covers the per-character verbs, but a Find result set is not keyed by
* character and so was left showing pre-transfer quantities -- the owner sent
* the same stack twice because it still read x7 after the first send. A find is
* re-issued only when one is actually on screen.
--]]
--[[
* THE WHO AND FIND RE-ASKS ARE DEFERRED TWO PUMPED FRAMES, NOT QUEUED HERE
* (1.11.1). The queue drains one line per SEND_INTERVAL, so a command's
* position in it is latency the player watches. Queueing `who` from inside the
* click put it ahead of the visible tab's own re-ask -- which only lands on the
* NEXT frame, when the tab's need() runs and finds forget() has cleared it --
* so the rows being stared at refreshed LAST, up to two intervals behind the
* left pane's counts. Two frames, not one, because the click itself happens
* mid-render, after this frame's need() has already run: the first counted
* frame is the one where the visible tab re-asks, the second is where the
* flush lands behind it. Same commands, same throttle, new order.
--]]
local refetchWait = 0;

local function refetchVisible()
    forget();

    refetchWait = 2;
end

local function pumpRefetch()
    if (refetchWait == 0) then
        return;
    end

    refetchWait = refetchWait - 1;

    if (refetchWait > 0) then
        return;
    end

    -- Find results before `who`: when a find is on screen it is content the
    -- player searched for, and the Find tab has no need() of its own to have
    -- jumped the queue with.
    if (state.findQuery ~= '' and state.findQuery ~= nil) then
        issue(string.format('!dwq find %s', state.findQuery), true);
    end

    -- The character list's used/size counts came from `who` and change with
    -- every transfer, and nothing else ever re-asks for them -- so without this
    -- the left pane read 79/80 long after the bag stopped being that full.
    refreshChars();
end

--[[
* How many of this row to move: the whole stack by default, or the spin box.
*
* THE FLOOR IS 1 AND IT IS APPLIED HERE AS WELL AS AT THE WIDGET. `InputInt`
* takes any integer it is given, including negative ones, and a negative
* quantity has no meaning in either direction -- it is not "move backwards", it
* is a number that lands in a `uint32` on the server as four billion. The widget
* clamps what the player can see and this clamps what the command can carry, so
* the two would both have to fail for a nonsense number to be sent.
--]]
local function moveCount(row)
    local held = math.max(row.qty, 1);

    if (state.sendAll[1]) then
        return held;
    end

    local wanted = math.floor(tonumber(state.sendQty[1]) or 1);

    return math.max(math.min(wanted, held), 1);
end

--[[
* The row action: pull an item out of another character's bag, or push one of
* your own across. Both go through the same server command a player would type.
*
* EVERY WIDGET ID CARRIES THE CHARACTER ID. Two characters holding the same item
* in the same container slot -- which is the normal outcome of sending one thing
* to two alts, since the collect drops it in the first free cell of each -- gave
* two buttons the identical `##loc_slot` suffix, and ImGui answered with a
* "conflicting ID" diagnostic and merged their click handling.
--]]
--[[
* The Use button, beside Send/Fetch on any row the client's own item flags say
* is usable. The server decides what a use MEANS -- a scroll teaches the spell
* to the whole account, food sticks to that character across calls, a potion or
* an ether lands on them while they are OUT, and anything else is refused with
* a sentence in the status line -- so this only decides that the button is
* worth drawing.
*
* YOUR OWN ROWS GET IT TOO, and until 1.12 they did not -- only scrolls did.
* That was the window's oldest piece of nonsense: it listed your own potions
* above every alt's, drew Use on theirs, and answered the same click on yours
* with a sentence telling you to go and find the item again in the game's item
* menu. The reasoning was that the game's own use path has the real checks, the
* cast time and the interruption, which is true and is now how it WORKS rather
* than a reason to refuse: the server hands a self use straight to the engine's
* item state machine (alt_storage.cpp), so this button opens the same door the
* item menu does, from the window the player is already looking at.
*
* WHICH CONTAINER MATTERS ON A SELF ROW, and only on a self row. The engine
* accepts an item use out of the inventory and the wardrobes and nothing else
* (packets/c2s/0x037_item_use.cpp's validContainers), while this window browses
* ten more. A potion in a satchel is a real row with a real id that the server
* refuses with advice -- so the button is simply not drawn there, the same
* before-the-click courtesy 'worn' and 'placed' get. Alt rows are unaffected:
* nothing about an alt's use goes through the client's containers.
*
* THE TOOLTIP FOLLOWS THE CHARACTER, NOT THE ITEM, because that is the half the
* player cannot see for themselves. Whether an ether does anything turns on
* whether that character is standing in the world right now -- a member is
* rebuilt at full HP and MP at every call -- and the roster already knows,
* through the same CHAR_LOCKED bit that puts [out] beside their name. The
* server refuses either way with a sentence; saying it BEFORE the click is what
* stops the click. On your own row none of that applies -- you ARE standing in
* the world -- so it says what a self use actually costs instead.
--]]

-- The containers the engine will use an item out of, keyed by container id
-- (LOC_NAMES above names them all). Inventory and the eight wardrobes, exactly
-- the set 0x037_item_use.cpp's validContainers accepts, minus LOC_TEMPITEMS
-- which this window does not browse.
local USABLE_FROM = {
    [0] = true,
    [8] = true, [10] = true, [11] = true, [12] = true,
    [13] = true, [14] = true, [15] = true, [16] = true,
};

--[[
* AUTOMATON PARTS (1.27).
*
* Frames and heads live at 0x2000 + id and attachments at 0x2100 + id, so the
* whole family is 8192..8703 -- the same range the server's own
* alt_storage.cpp bounds its unlock with and addallpupattachments.lua walks,
* and every row in it is a puppet part. The range and not a DAT type, because
* the range is the thing both sides already agree on and the server re-asks
* ITEM_PUPPET of the item template on every unlock regardless: this only
* decides whether a button is worth drawing, exactly as FLAG_CANUSE does for
* Use.
*
* A puppet part carries NO flags at all in item_basic -- no CanUse -- so it
* has never had a Use button and never will. That is right: it is not used,
* it is fitted, by trading it to Tateeya in Aht Urhgan Whitegate. What was
* missing is that an ALT cannot make that trade without being logged in, and
* the part is sitting in a bag this window is already looking at.
--]]
local FIRST_PUPPET_ITEM = 8192;
local LAST_PUPPET_ITEM  = 8703;

local function isPuppetPart(itemId)
    return itemId >= FIRST_PUPPET_ITEM and itemId <= LAST_PUPPET_ITEM;
end

-- `label` is the row's cached `Use##u<charid>_<loc>_<slot>` (see rowIds).
local function useButton(row, label, name, mine)
    if (imgui.SmallButton(label)) then
        issue(string.format('!dwq use %s %d', name, row.itemid));

        refetchVisible();
    end

    if (imgui.IsItemHovered()) then
        if (mine) then
            imgui.SetTooltip(
                'Use it yourself, right here -- the same as using it from the\n'
                .. 'game\'s item menu, with the same cast time and interruption.\n'
                .. 'A scroll teaches the spell to your WHOLE account.\n'
                .. 'The count in this window updates on the next Refresh.');
        else
            local member = state.chars[row.charid];
            local out    = member ~= nil and bit.band(member.flags, CHAR_LOCKED) ~= 0;

            imgui.SetTooltip(string.format(
                'Use as %s. A scroll teaches the spell to your WHOLE account;\n'
                .. 'food stays on them across calls until it wears off.\n'
                .. 'Potions, ethers, remedies and drinks land on them %s.',
                name,
                out and 'right now -- they are out' or 'only while they are out'));
        end
    end

    imgui.SameLine();
end

--[[
* THE MERCHANT HALF (1.30).
*
* `priceOf` is a LOOKUP AND NOT A CALCULATION, and it has three answers, not
* two: a number is what a merchant pays for one, 0 is "no merchant will buy
* it", and nil is "this server has never said". The third is the one that
* matters -- a window that read a missing price as zero would tell a player
* their gear is worthless on any server whose map predates the price record.
*
* `sellRefusal` is the reason a row may NOT be sold, as a sentence, or nil when
* it may. Every clause in it is something the server would refuse anyway
* (DwBagsVendor), said BEFORE the click the way `worn`, `placed` and `priced`
* already are -- and the batch uses the same function, so a greyed row and a
* skipped row can never disagree about why.
*
* WHAT IT DOES NOT KNOW is on the wire nowhere: a reserved or busy item looks
* ordinary to a row list. That one is refused by the server, reported per cell,
* and is exactly what the `b|` verdicts are for.
--]]
local function priceOf(itemid)
    return state.prices[itemid];
end

-- The sellable filter AS IT ACTUALLY APPLIES. The control is hidden on a
-- server that has never priced anything, and a hidden control must not go on
-- narrowing the list behind the player -- a filter nobody can see and nobody
-- can clear is indistinguishable from rows that have gone missing.
local function sellNarrowing()
    if (not state.priced or vendorUnsupported) then
        return 'any';
    end

    return state.sellFilter;
end

local function sellRefusal(row)
    if (not isSelf(row.charid)) then
        return 'Only your own bags can be sold from here -- gil is paid into\n'
            .. 'your own inventory, and an alt has no inventory to be paid into.\n'
            .. 'Fetch it first, or log in as them.';
    end

    if (bit.band(row.flags or 0, ITEM_EQUIPPED) ~= 0) then
        return 'It is being worn. Take it off first.';
    end

    if (bit.band(row.flags or 0, ITEM_PLACED) ~= 0) then
        return 'It is placed in your Mog House. Remove it from the layout first.';
    end

    if (bit.band(row.flags or 0, ITEM_BAZAARED) ~= 0) then
        return 'It is priced in a bazaar. Clear the price first.';
    end

    local price = priceOf(row.itemid);

    if (price == nil) then
        return 'This server has not said what a merchant would pay for this.';
    end

    if (price <= 0) then
        return 'No merchant will buy this.';
    end

    return nil;
end

-- What the whole of one row is worth to a merchant: 0 for anything that may
-- not be sold, so a total can simply add every row up and the greyed ones
-- contribute nothing.
local function rowValue(row)
    if (sellRefusal(row) ~= nil) then
        return 0;
    end

    return (priceOf(row.itemid) or 0) * math.max(row.qty or 0, 0);
end

--[[
* THE ONE PLACE A DESTRUCTIVE PRESS IS TURNED INTO A QUESTION (1.30).
*
* Every batch -- one ticked row or forty, a trash or a sale -- is built here,
* so the count, the gil and the warnings in the popup are produced by one
* function over the same live rows the command will name. A second builder for
* the single-row case is exactly how a confirmation ends up describing
* something other than what the button does.
*
* A SALE SKIPS WHAT IT CANNOT SELL, AND SAYS SO. `sellRefusal` decides, the
* same function that greys the row's Value cell, so a skipped row and a greyed
* row can never disagree. A TRASH SKIPS NOTHING: the server refuses a worn or
* bazaared row per cell and reports it, which is the honest answer -- a window
* that quietly dropped ticked rows before sending would be deciding for the
* player which of their ticks counted.
*
* `whole` is the quantity rule: a TICK is "this row", so a batch takes the
* whole cell whatever the header's spin box says (dwwarehouse's Stash-ticked
* rule, and the same reasoning -- a partial move of five rows is five
* refusals to read). A single-row button follows its neighbours and uses the
* spin box.
--]]
local function askBatch(sale, rows, whole, charname)
    local cells     = T{ };
    local gil       = 0;
    local items     = 0;
    local skipped   = 0;
    local rare      = 0;
    local exclusive = 0;
    local augmented = 0;

    for _, row in ipairs(rows) do
        if (sale and sellRefusal(row) ~= nil) then
            skipped = skipped + 1;
        else
            local count = whole and math.max(row.qty or 1, 1) or moveCount(row);
            local flags = datFlagsOf(row.itemid);

            cells:append({ loc = row.loc, slot = row.slot, itemid = row.itemid, qty = count });

            items = items + count;

            if (sale) then
                gil = gil + (priceOf(row.itemid) or 0) * count;
            end

            if (bit.band(flags, FLAG_RARE) ~= 0) then
                rare = rare + 1;
            end

            if (bit.band(flags, FLAG_EX) ~= 0) then
                exclusive = exclusive + 1;
            end

            if (bit.band(row.flags or 0, ITEM_AUGMENTED) ~= 0) then
                augmented = augmented + 1;
            end
        end
    end

    -- Nothing to ask about is still an answer, and it is said rather than
    -- swallowed: a button that opens no popup and prints nothing is the one
    -- failure shape this window must never have.
    if (#cells == 0) then
        state.status = sale
            and 'None of the ticked rows can be sold from here.'
            or 'Nothing is ticked.';
        state.statusBad = true;

        return;
    end

    state.batchAsk = {
        sale      = sale,
        charname  = charname,
        cells     = cells,
        items     = items,
        gil       = gil,
        skipped   = skipped,
        rare      = rare,
        exclusive = exclusive,
        augmented = augmented,
    };
end

--[[
* The Sell button, beside Stash and Trash on any row of the player's OWN bags
* the server has priced above zero (1.30).
*
* IT TYPES THE BATCH VERB WITH ONE CELL IN IT. There is no single-sale path of
* its own, deliberately: one row and forty rows go through the same command,
* the same parser and the same binding, so the two cannot drift apart -- which
* is what happened the last three times a family grew a bulk face beside its
* single one.
*
* AND IT ASKS FIRST, like Trash. A sale is not reversible in any sense a player
* would accept -- re-buying from a merchant costs several times the sale price,
* and most of what the window lists is not sold by any merchant at all -- so it
* goes through the same confirmation the batch does, with the gil in the
* sentence. The button only records what was pointed at; the popup types it.
--]]
local function sellButton(row, ids, price)
    imgui.SameLine();

    if (imgui.SmallButton(ids.sell)) then
        askBatch(true, T{ row }, false,
            state.chars[row.charid] ~= nil and state.chars[row.charid].name or nil);
    end

    if (imgui.IsItemHovered()) then
        local count = moveCount(row);

        imgui.SetTooltip(string.format(
            'Sell %d to a merchant for %s gil (%s each).\n'
            .. 'The same price the shops pay, without the walk.\n'
            .. 'Asks first -- a merchant will not sell it back at this price.',
            count, commaGil(price * count), commaGil(price)));
    end
end

-- Stash and Trash, side by side on every free row, self and alt alike (1.22).
-- Stash puts the exact cell into the account warehouse; Trash destroys it.
-- Neither resolves by item name -- the wire is `<who> <loc> <slot> <itemid>
-- <qty>`, and the server compares the claimed id against the live cell, so a
-- stale window fails closed with "your bag has changed" instead of acting on
-- the wrong item. Trash NEVER SENDS ON ITS OWN: the click only records what
-- the player pointed at, and the confirmation popup in bagsTab issues the
-- command -- the dwwarehouse rule, ported with its window.
local function stashTrashButtons(row, ids, name)
    if (not stashUnsupported) then
        imgui.SameLine();

        if (imgui.SmallButton(ids.stash)) then
            issue(string.format('!dwq stash %s %d %d %d %d', name, row.loc, row.slot, row.itemid, moveCount(row)));

            refetchVisible();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Put %d straight into the account warehouse -- no inventory\n'
                .. 'round trip. Take it back out any time with /warehouse.', moveCount(row)));
        end
    end

    if (not trashUnsupported) then
        imgui.SameLine();

        if (imgui.SmallButton(ids.trash)) then
            state.trashAsk = {
                charname = name,
                loc      = row.loc,
                slot     = row.slot,
                itemid   = row.itemid,
                qty      = moveCount(row),
                flags    = row.flags,
                augArg   = augArgFor(row),
            };
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('Throw %d away, straight out of the bag.\n'
                .. 'Asks first -- this cannot be undone.', moveCount(row)));
        end
    end
end

local function transferButton(row)
    local name = state.chars[row.charid] ~= nil and state.chars[row.charid].name or nil;

    if (name == nil) then
        -- A find is account-wide and the roster is a separate read, so a
        -- result can land for a character the character list has not
        -- described yet -- and every command here names a character. The
        -- cell used to be left blank (2026-09-06), which reads as a row
        -- whose buttons failed to draw rather than as a row that is waiting.
        imgui.TextDisabled('...');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.noOwner);
        end

        return;
    end

    if (bit.band(row.flags, ITEM_EQUIPPED) ~= 0) then
        -- A WORN row can still be USED, on your own character: enchanted gear
        -- is used from the slot it is worn in, and the server's self-use path
        -- exempts equipped equipment from the lock the same way the game's own
        -- item menu does (0x037_item_use.cpp). Without this button the feature
        -- was a closed loop -- the unequipped ring said "equip it first", and
        -- the equipped ring had no button at all.
        --
        -- AND ON AN ALT (1.20.0). The self clause above was the whole test
        -- until now, and it left the alt half of the same loop closed: `!squad
        -- use Alta ring` works typed -- DwAltUse's alt branch has no equipped
        -- refusal at all, only bazaar and CanUse, and its item picker merely
        -- DEPRIORITISES a worn copy so it still resolves when there is no free
        -- one -- while the window drew `worn` and no button for it. The 1.12
        -- round closed this loop for the player's own row and did not carry it
        -- across.
        --
        -- USABLE_FROM stays a SELF-ONLY condition, deliberately: it is the
        -- container rule for using an item out of the CALLER's own bags, and
        -- an alt row never touches the caller's containers.
        local usable = bit.band(datFlagsOf(row.itemid), FLAG_CANUSE) ~= 0;

        if (usable and (not isSelf(row.charid) or USABLE_FROM[row.loc])) then
            -- `mine` is the ROW's owner, not a constant. Passing `true` here
            -- was the bug this line existed to avoid: an alt's worn ring would
            -- have drawn the caller's own tooltip -- "use it yourself, right
            -- here, with the same cast time" -- over a button that actually
            -- issues `!dwq use <alt> <item>`, and it would have dropped the
            -- warning the alt tooltip carries about a summoned member.
            useButton(row, rowIds(row).use, name, isSelf(row.charid));
        end

        imgui.TextDisabled('worn');

        -- The third greyed tag to say WHY (2026-09-06). 'placed' and 'priced'
        -- have carried their fix since 1.9.3 and this one -- much the
        -- commonest of the three -- carried nothing, so the row read as a
        -- button that had simply failed to draw. What to do about it differs
        -- by owner, which is exactly what makes it worth a sentence.
        if (imgui.IsItemHovered()) then
            if (isSelf(row.charid)) then
                imgui.SetTooltip(TIPS.wornSelf);
            else
                imgui.SetTooltip(TIPS.wornAlt);
            end
        end

        return;
    end

    -- Furniture standing in the Mog House layout. The server refuses the
    -- transfer regardless (and says so in the red status line); this tag says
    -- why BEFORE the click, the way 'worn' does, with the fix in the tooltip.
    if (bit.band(row.flags, ITEM_PLACED) ~= 0) then
        imgui.TextDisabled('placed');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Placed in the Mog House. Remove it from the layout\n'
                .. '(Mog House menu, on that character) to send or fetch it.');
        end

        return;
    end

    -- Priced in a bazaar. Same treatment as 'placed': the server refuses the
    -- transfer (alt_storage.cpp), so say why before the click instead of after.
    if (bit.band(row.flags, ITEM_BAZAARED) ~= 0) then
        imgui.TextDisabled('priced');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Priced in a bazaar. Clear the price\n'
                .. '(on that character) to send or fetch it.');
        end

        return;
    end

    local ids      = rowIds(row);
    local datFlags = datFlagsOf(row.itemid);

    if (isSelf(row.charid)) then
        -- Anything the client's own DATs call usable, out of a container the
        -- engine will use it from. FLAG_SCROLL is a subset of FLAG_CANUSE, so
        -- the scroll case that was here alone since 1.09 is covered by the same
        -- test rather than by a second one beside it.
        if (bit.band(datFlags, FLAG_CANUSE) ~= 0 and USABLE_FROM[row.loc]) then
            useButton(row, ids.use, name, true);
        end

        -- An automaton part on your own row (1.27). No button: your automaton
        -- is fitted by trading the part to Tateeya, which is the retail door
        -- and the one with the cutscene behind it -- the server refuses a self
        -- unlock with exactly that sentence. Said HERE, where the Use button
        -- would have been, because a puppet item has no CanUse flag and so has
        -- always drawn nothing at all -- which reads as a row whose buttons
        -- failed rather than as a row with a rule. Send is untouched: sending
        -- one to an alt is what the Unlock button on THEIR row is for.
        if (isPuppetPart(row.itemid)) then
            imgui.TextDisabled('Tateeya');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.puppetSelf);
            end

            imgui.SameLine();
        end

        -- Push, to whoever the header's "Send to" names. That is deliberately
        -- not the left-hand selection: the left pane answers "whose bags am I
        -- looking at", and conflating the two left every row of your own bag
        -- showing a hint instead of a button.
        local target = state.sendTo ~= nil and state.chars[state.sendTo] or nil;

        if (target == nil) then
            -- No early return any more (1.22): Stash and Trash below need no
            -- send target, so the hint stands where Send would and the row
            -- keeps its other two buttons.
            imgui.TextDisabled('no target');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Choose a character in "Send to" at the top of the window.');
            end
        else
            if (imgui.SmallButton(ids.send)) then
                issue(string.format('!dwq send %s %d %d', target.name, row.itemid, moveCount(row)));

                refetchVisible();
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Send %d to %s', moveCount(row), target.name));
            end
        end

        -- Sell (1.30), on your own rows only and only where the server has
        -- said a merchant would pay something. A row this branch can reach is
        -- already not worn, not placed and not bazaared -- those three return
        -- above with their own greyed tag -- so the only refusals left here
        -- are "never priced" and "worth nothing", and both mean the same
        -- thing to a button: there is nothing to draw. The Bags tab's Value
        -- column is where those two are told apart, in words.
        if (not vendorUnsupported) then
            local price = priceOf(row.itemid);

            if (price ~= nil and price > 0) then
                sellButton(row, ids, price);
            end
        end

        stashTrashButtons(row, ids, name);

        return;
    end

    if (bit.band(datFlags, FLAG_CANUSE) ~= 0) then
        useButton(row, ids.use, name, false);
    end

    -- Unlock (1.27): fit an automaton part to THIS character's automaton, the
    -- arithmetic of the Tateeya trade without the login -- one part gone, one
    -- bit set on their char_pet row. Not drawn against a server that does not
    -- know the verb (puppetUnsupported, latched off its own unknown-verb
    -- sentence), so deployment order cannot matter.
    if (not puppetUnsupported and isPuppetPart(row.itemid)) then
        if (imgui.SmallButton(ids.unlock)) then
            issue(string.format('!dwq unlock %s %d', name, row.itemid));

            refetchVisible();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.puppetAlt);
        end

        imgui.SameLine();
    end

    if (imgui.SmallButton(ids.fetch)) then
        issue(string.format('!dwq fetch %s %d %d', name, row.itemid, moveCount(row)));

        refetchVisible();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(string.format('Take %d from %s', moveCount(row), name));
    end

    -- Send, from an alt's row straight to whoever the header's "Send to"
    -- names: the Get-button recipe (see the header, 1.11). Two typed lines,
    -- fetch then send, queued in order and never retried -- the item rides
    -- through your inventory because that is the only route the typed
    -- commands have. Not drawn when the target IS this row's character (a
    -- round trip to nowhere), and not drawn with no target at all -- Fetch
    -- stands alone then, exactly as it did before this button existed.
    local target = state.sendTo ~= nil and state.chars[state.sendTo] or nil;

    if (target ~= nil and target.charid ~= row.charid) then
        imgui.SameLine();

        if (imgui.SmallButton(ids.send)) then
            -- One count for both lines: they describe one movement, and
            -- reading the spin box twice would let a mid-queue edit send a
            -- different number than was fetched.
            local count = moveCount(row);

            issuePair(string.format('!dwq fetch %s %d %d', name, row.itemid, count),
                      string.format('!dwq send %s %d %d', target.name, row.itemid, count));

            refetchVisible();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Send %d to %s -- fetched from %s into your inventory first,\n'
                .. 'then sent on. Needs a free slot in your bags on the way.',
                moveCount(row), target.name, name));
        end
    end

    stashTrashButtons(row, ids, name);
end

--[[
* THE SELECTION'S OWN REVISION (1.30), the modelRev trick applied to the ticks.
*
* The toolbar has to say how many rows are ticked, how many items that is and
* what they are worth, and it draws sixty times a second over a list that can
* be a thousand rows long. None of those three numbers can change without a
* tick moving or an answer committing, and both are in the key -- so the walk
* happens on a click instead of on a frame, exactly as the bag view's own
* filter does.
--]]
local pickRev = 0;

local function setPicked(key, on)
    if ((state.picked[key] == true) == (on and true or false)) then
        return;
    end

    -- `nil` and not `false`: `state.picked` is a SET, and a table of explicit
    -- falses is a table that grows for the life of the session.
    state.picked[key] = on and true or nil;
    pickRev           = (pickRev + 1) % 1000000;
end

local function clearPicked()
    if (next(state.picked) == nil) then
        return;
    end

    state.picked    = T{ };
    state.pickedFor = nil;
    pickRev         = (pickRev + 1) % 1000000;
end

--[[
* One row of the Bags tab. `valued` says whether the Value column is being
* drawn at all -- it is not, on a server that has never sent a price, because a
* column of "--" over a fact nobody has stated reads as a broken feature rather
* than as an absent one.
*
* THE CHECKBOX BUFFER IS CACHED ON THE ROW, like its widget ids and its name
* cell and for the same reason: ImGui wants a one-element table per checkbox
* and a three-hundred-row page redrawn sixty times a second would otherwise
* allocate eighteen thousand of them a second. The row is replaced wholesale by
* the next answer, so the buffer lives and dies with the cell it belongs to;
* `state.picked` is the truth and this is only the widget's scratch.
--]]
local function itemRow(row, valued)
    imgui.TableNextRow();
    imgui.TableNextColumn();

    local ids = rowIds(row);
    local box = row.tickbox;

    if (box == nil) then
        box = T{ false };

        row.tickbox = box;
    end

    box[1] = state.picked[ids.key] == true;

    if (imgui.Checkbox(ids.tick, box)) then
        setPicked(ids.key, box[1]);

        state.pickedFor = row.charid;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.tick);
    end

    imgui.TableNextColumn();

    drawIcon(row.itemid, 20);

    local hovered = imgui.IsItemHovered();

    imgui.Text(rowName(row));
    rowCardOnHover(row, hovered);

    imgui.TableNextColumn();
    imgui.Text(row.qtytext or '');

    -- The merchant value of this row, which is the server's price times what
    -- is in the cell -- never a number this file decides (1.30). A row that
    -- cannot be sold reads "--" and says why on hover, which is where the two
    -- different reasons for a missing Sell button are told apart.
    if (valued) then
        imgui.TableNextColumn();

        local refusal = sellRefusal(row);

        if (refusal == nil) then
            imgui.Text(commaGil(rowValue(row)));

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('%s gil each to a merchant.', commaGil(priceOf(row.itemid) or 0)));
            end
        else
            imgui.TextDisabled('--');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(refusal);
            end
        end
    end

    imgui.TableNextColumn();
    imgui.Text(LOC_NAMES[row.loc] or tostring(row.loc));

    imgui.TableNextColumn();
    transferButton(row);
end

-- The Bags tab's draw page (1.24): 300 rows a page, the dwwarehouse
-- number, and the page is chrome -- a plain local, never in `state`.
local BAG_PAGE   = 300;
local bagPage    = 1;
local lastBagKey = '';

-- The containers this character owns, in id order. One walk per model
-- revision (1.25) rather than one per frame: the combo below reads it, and
-- so does the view builder under it.
local bagLocs    = T{ };
local bagLocsRev = -1;

local function containerList()
    if (bagLocsRev == modelRev) then
        return bagLocs;
    end

    local locs = T{ };

    for loc, _ in pairs(state.bags) do
        locs:append(loc);
    end

    table.sort(locs);

    bagLocs    = locs;
    bagLocsRev = modelRev;

    return locs;
end

--[[
* The row orders this tab offers (1.25).
*
* EVERY COMPARATOR ENDS IN (container, cell), which is unique among one
* character's rows -- so each of these is a strict total order, LuaJIT's
* "invalid order function" cannot be reached, and two equal rows cannot swap
* places between frames the way an unstable sort lets them. `bag` is the
* wire's own order and is therefore no sort at all.
--]]
local BAG_SORTS = {
    { name = 'bag',   label = 'Bag order' },
    { name = 'name',  label = 'Name' },
    { name = 'count', label = 'Count' },
};

local function bagCellLess(a, b)
    if (a.loc ~= b.loc) then
        return a.loc < b.loc;
    end

    return a.slot < b.slot;
end

local function bagNameLess(a, b)
    local an = lowerName(a.itemid);
    local bn = lowerName(b.itemid);

    if (an ~= bn) then
        return an < bn;
    end

    return bagCellLess(a, b);
end

local function bagCountLess(a, b)
    if (a.qty ~= b.qty) then
        return a.qty > b.qty;
    end

    return bagNameLess(a, b);
end

local BAG_SORT_LESS = {
    name  = bagNameLess,
    count = bagCountLess,
};

-- The sellable narrowing (1.30). Three answers and not a checkbox, because
-- "only the things nobody will buy" is a real question -- it is the list a
-- player clearing out a bag actually wants to look at -- and a two-state
-- control cannot ask it.
local SELL_FILTERS = {
    { name = 'any', id = 'Any value##dwbags_sell_any' },
    { name = 'yes', id = 'Sellable##dwbags_sell_yes' },
    { name = 'no',  id = 'Unsellable##dwbags_sell_no' },
};

--[[
* THE BAGS VIEW, BUILT ONCE PER ANSWER (1.25).
*
* The filter used to run inside the render pass: every frame walked every
* container of a character carrying well over a thousand rows, appended a
* table, lowercased-and-searched a name per row and re-counted the totals --
* sixty times a second, to produce a list identical to the one it produced
* the frame before. Nothing in it can change without either a committed
* answer (modelRev) or a control on this tab moving, and both are in the key.
*
* THE PAGE IS RESET BY THE FILTER KEY AND NOT BY THE VIEW KEY, and that
* difference is the whole of the 1.24 scroll report: a Send re-asks the tab,
* which commits a new answer and moves modelRev, and resetting the page there
* would throw a player working on page two back to page one on every click.
* A narrowing is a new question and does reset it.
--]]
-- A PLAIN TABLE, NOT `T{ }`, and for the reason the `requested` table above
-- gives at length: a T{} resolves an unknown key through the sugar table
-- methods, and `size` and `count` are two of them. Every field here is
-- always assigned, so the trap is not sprung today -- but this is a table
-- whose field names were chosen for what they mean, which is exactly the
-- kind that must not carry names of its own.
local bagView = { rows = T{ }, total = 0, used = 0, size = 0, bags = 0, totals = '',
                  counts = { }, sellable = 0 };
local bagKey  = nil;

local function refreshBagView()
    local needle    = tostring(state.bagFind[1] or ''):lower();

    -- Re-validated here rather than trusted: applyView clamps what the file
    -- held and the combo can only set a known name, but this is the one place
    -- the value decides whether a row is drawn at all.
    local category  = bagCategoryName(state.bagCat);
    -- `sellFilter` joins the key (1.30) because it narrows which rows are
    -- drawn, exactly as the other four do. The PRICES need no key of their
    -- own: `v|` rides the same `bag` and `find` envelopes as the rows it
    -- prices and is committed by the same `z|`, so modelRev already moves
    -- with them -- which is the whole reason the record was put inside those
    -- envelopes rather than given one of its own.
    local filterKey = string.format('%s|%s|%s|%s|%s|%s', tostring(state.bagLoc), needle,
        tostring(state.bagSort), tostring(state.selected), category, sellNarrowing());

    if (filterKey ~= lastBagKey) then
        lastBagKey = filterKey;
        bagPage    = 1;
    end

    local viewKey = string.format('%d|%s', modelRev, filterKey);

    if (viewKey == bagKey) then
        return;
    end

    bagKey = viewKey;

    local rows      = T{ };
    local total     = 0;
    local used      = 0;
    local size      = 0;
    local bags      = 0;
    local narrowing = sellNarrowing();

    for _, loc in ipairs(containerList()) do
        local bag = state.bags[loc];

        -- `tonumber(...) or 0` and not `... or 0`: `bag` is a T{} and `size`
        -- is one of the sugar table methods, so a container record that had
        -- somehow not set it would answer a FUNCTION here rather than nil,
        -- and `0 + function` throws inside the render pcall.
        local bagSize = tonumber(bag.size) or 0;

        -- Only containers the character actually HAS are counted as bags:
        -- the roster reports every container id it knows about, and a mog
        -- safe nobody has bought is a row of zeroes, not a bag.
        if (bagSize > 0) then
            bags = bags + 1;
            used = used + (tonumber(bag.used) or 0);
            size = size + bagSize;
        end

        for _, row in ipairs(bag.items) do
            total = total + 1;

            -- The category test sits BEFORE the name test on purpose: it is
            -- two cached table lookups, the name test is a substring search
            -- over a lowercased string, and Lua's `and` short-circuits.
            -- The sellable test sits LAST of the four on purpose: it is the
            -- only one that can reach a second table (the price list) and
            -- walk the row's flags, and Lua's `and` short-circuits.
            if ((state.bagLoc == nil or state.bagLoc == loc)
                    and (category == 'all' or categoryOf(row.itemid) == category)
                    and (needle == '' or lowerName(row.itemid):find(needle, 1, true) ~= nil)
                    and (narrowing == 'any'
                         or (narrowing == 'yes') == (sellRefusal(row) == nil))) then
                rows:append(row);
            end
        end
    end

    local less = BAG_SORT_LESS[state.bagSort];

    if (less ~= nil) then
        table.sort(rows, less);
    end

    -- HOW MANY ROWS OF EACH ITEM ID THE VIEW HOLDS (1.30), counted in the one
    -- walk that is already happening rather than in a second one: it is what
    -- "tick every row of this item" is made of, and doing it per frame over a
    -- thousand rows is exactly what this whole cache exists to stop.
    --
    -- A PLAIN TABLE, the bagView rule: its keys are item ids and its lookups
    -- must not resolve through the sugar table methods.
    local counts   = { };
    local sellable = 0;

    for _, row in ipairs(rows) do
        counts[row.itemid] = (counts[row.itemid] or 0) + 1;

        if (sellRefusal(row) == nil) then
            sellable = sellable + 1;
        end
    end

    -- Plain, like the declaration above and for the same reason.
    bagView = {
        rows     = rows,
        total    = total,
        used     = used,
        size     = size,
        bags     = bags,
        counts   = counts,
        sellable = sellable,
        totals = size > 0
            and string.format('%d of %d cells used across %d bag%s -- %d free.',
                used, size, bags, bags == 1 and '' or 's', math.max(size - used, 0))
            or '',
    };
end

--[[
* WHAT IS TICKED, ACROSS EVERY CONTAINER, COUNTED ONCE PER CHANGE (1.30).
*
* IT IS NOT THE FILTERED VIEW, and that is the decision this cache exists to
* make explicit. `All`, `None` and `Invert` act on what is SHOWN -- that is
* what those words mean over a filtered list -- but "Trash Selected (7)" has
* to mean all seven, or narrowing the list after ticking would quietly shrink
* what the button does without the number ever saying so. So the ticks are
* resolved against every container of the selected character, and a tick whose
* row no longer exists (it was sent, used or trashed) simply drops out.
*
* Keyed on modelRev and pickRev together: nothing here can change without an
* answer committing or a tick moving, which is the bag view's own rule.
--]]
local pickView = { key = nil, rows = T{ }, sellable = T{ }, kinds = 0, gil = 0 };

local function refreshPickView()
    local key = string.format('%d|%d|%s', modelRev, pickRev, tostring(state.selected));

    if (key == pickView.key) then
        return pickView;
    end

    local rows     = T{ };
    local sellRows = T{ };
    local kinds    = { };
    local gil      = 0;
    local seen     = 0;

    for _, loc in ipairs(containerList()) do
        for _, row in ipairs(state.bags[loc].items) do
            if (state.picked[rowIds(row).key] == true) then
                rows:append(row);

                if (kinds[row.itemid] == nil) then
                    kinds[row.itemid] = true;
                    seen              = seen + 1;
                end

                if (sellRefusal(row) == nil) then
                    sellRows:append(row);
                    gil = gil + rowValue(row);
                end
            end
        end
    end

    pickView = { key = key, rows = rows, sellable = sellRows, kinds = seen, gil = gil };

    return pickView;
end

--[[
* ONE PRESS, AS FEW TYPED LINES AS THE CLIENT ALLOWS (1.30).
*
* The client's outgoing chat packet carries 128 bytes (0x0b5_chat_std.h), so a
* packed cell list is cut at 118 to leave the prefix and the terminator room,
* and at twelve cells because that is the server's own per-line ceiling
* (squad_storage.lua's BATCH_CELLS -- a hand-typed line must not be able to
* turn one command into an unbounded loop, and this side must not send a line
* that ceiling would refuse whole).
*
* ADMITTED OR REFUSED AS ONE, issuePair's rule applied to a whole press: the
* queue has room for every line of the batch or none of them is queued. Half a
* batch is a bag in a state nobody asked for, with nothing on screen saying
* which half went.
*
* THE TICKS ARE SPENT ON THE PRESS. They named cells that are about to stop
* being what they were, and a tick left standing over a cell the server has
* just emptied is the next click aimed at whatever moves into it.
--]]
local BATCH_LINE  = 118;
local BATCH_CELLS = 12;

local function issueBatch(sale, name, cells)
    local prefix = sale and '!dwq vendor ' or string.format('!dwq trashmany %s ', name);
    local lines  = T{ };
    local buffer = '';
    local held   = 0;

    for _, cell in ipairs(cells) do
        local entry = string.format('%d:%d:%d:%d', cell.loc, cell.slot, cell.itemid, cell.qty);

        if (buffer ~= '' and (held >= BATCH_CELLS
                or #prefix + #buffer + 1 + #entry > BATCH_LINE)) then
            lines:append(prefix .. buffer);

            buffer = '';
            held   = 0;
        end

        buffer = buffer == '' and entry or (buffer .. ',' .. entry);
        held   = held + 1;
    end

    if (buffer ~= '') then
        lines:append(prefix .. buffer);
    end

    if (#lines == 0 or queueFull(#lines)) then
        return;
    end

    for _, line in ipairs(lines) do
        queue:append(line);
    end

    batchTally = { sale = sale, cells = #cells, lines = #lines, done = 0, failed = 0, gil = 0 };

    state.status = string.format('%s %d row%s...', sale and 'Selling' or 'Throwing away',
        #cells, #cells == 1 and '' or 's');
    state.statusBad = false;

    clearPicked();
    refetchVisible();
end

local function bagsTab()
    local name = selectedName();

    if (name == nil) then
        imgui.Text('Pick a character.');

        return;
    end

    need('bag', state.selected);

    -- THE TICKS BELONG TO ONE CHARACTER (1.30). A key is `<charid>:<loc>:<slot>`
    -- and could not collide across characters, but leaving them standing would
    -- mean a batch pressed after switching back acted on rows chosen before a
    -- dozen transfers -- and the count on the button would have been describing
    -- somebody else's bag the whole time it was hidden.
    if (state.pickedFor ~= nil and state.pickedFor ~= state.selected) then
        clearPicked();
    end

    --[[
        THE CATEGORY ROW (1.26), and it is a row of its own above the Stack
        button rather than a fifth control on the crowded line below it. Two
        reasons: it is the only narrowing here that PERSISTS, and it is the
        only one that answers "what kind of thing am I after" rather than
        "which bag" or "what is it called" -- a control that outlives the
        session should not be buried in the row a player clears every time.

        The label is drawn first and the combo continues its line, which is
        the one direction of SameLine that is always safe (something has been
        drawn on this line already). See the narrowing row below for the
        direction that is not.
    ]]
    imgui.Text('Category');
    imgui.SameLine();
    imgui.PushItemWidth(120);

    local catEntry = BAG_CATEGORY_BY_NAME[state.bagCat] or BAG_CATEGORIES[1];

    if (imgui.BeginCombo('##dwbags_bagcat', catEntry.label)) then
        for _, entry in ipairs(BAG_CATEGORIES) do
            if (imgui.Selectable(entry.id, state.bagCat == entry.name)
                    and state.bagCat ~= entry.name) then
                state.bagCat = entry.name;

                -- On the change only. settings.save writes a file, and this
                -- is a click rather than a frame.
                saveView();
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.bagCat);
    end

    --[[
        AND THE SELLABLE NARROWING (1.30), beside the category because it is
        the same kind of question -- what sort of thing am I after -- rather
        than "which bag" or "what is it called".

        DRAWN ONLY ONCE THE SERVER HAS PRICED SOMETHING. A filter over a fact
        nobody has stated can only mislead: on a map that predates the price
        record every row would answer "unsellable", which is a confident
        claim this window has no business making. `state.priced` is the same
        gate the Value column and every Sell button ride.
    --]]
    local vendoring = state.priced and not vendorUnsupported;

    if (vendoring) then
        imgui.SameLine();
        imgui.PushItemWidth(110);

        local sellLabel = state.sellFilter == 'yes' and 'Sellable'
            or (state.sellFilter == 'no' and 'Unsellable' or 'Any value');

        if (imgui.BeginCombo('##dwbags_sellfilter', sellLabel)) then
            for _, entry in ipairs(SELL_FILTERS) do
                if (imgui.Selectable(entry.id, state.sellFilter == entry.name)) then
                    state.sellFilter = entry.name;
                end
            end

            imgui.EndCombo();
        end

        imgui.PopItemWidth();

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.sellFilter);
        end
    end

    -- One click over `!dwq stack`: works for the character being played AND
    -- for any alt (the server has a live path and an offline path). Which
    -- rows may merge is the server's decision alone -- see the header.
    if (not stackUnsupported) then
        if (imgui.SmallButton('Stack all##dwbags_stack')) then
            issue(string.format('!dwq stack %s', name));

            refetchVisible();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Combine every item %s holds in more than one part-stack into as few\n'
                .. 'stacks as possible, into the inventory when there is room. Worn,\n'
                .. 'bazaared, signed and augmented copies stay where they are.', name));
        end

        imgui.SameLine();
        imgui.TextDisabled('Combines split stacks across every bag.');
    end

    --[[
        The narrowing (1.24): a container, a name, both -- local, and the
        server is never asked about either -- and the draw sliced to
        BAG_PAGE rows. A character's every bag is well over a thousand rows,
        each of them seven widgets a frame, and that was the "slow and
        clunky" half of the owner's report. The find still searches every
        page: the filter runs over the whole model, only the draw is
        bounded (the dwwarehouse rule).

        THE ROW ONLY CONTINUES A LINE THAT EXISTS (2026-09-06). This
        SameLine was unconditional, and against a server with no `stack`
        verb the block above draws nothing at all -- so it put the cursor
        back on the last line drawn, which in an empty tab body is the tab
        bar itself, and the container combo and the find box landed across
        the tabs.
    ]]
    if (not stackUnsupported) then
        imgui.SameLine();
    end

    imgui.PushItemWidth(120);

    local locLabel = state.bagLoc ~= nil and (LOC_NAMES[state.bagLoc] or tostring(state.bagLoc)) or 'All bags';

    if (imgui.BeginCombo('##dwbags_bagloc', locLabel)) then
        if (imgui.Selectable('All bags##dwbags_loc_all', state.bagLoc == nil)) then
            state.bagLoc = nil;
        end

        for _, loc in ipairs(containerList()) do
            local bag = state.bags[loc];

            -- tonumber for the reason refreshBagView gives: `%d` on a sugar
            -- table method is a raise, and this label is built every frame
            -- the combo is open.
            if (imgui.Selectable(string.format('%s (%d/%d)##dwbags_loc_%d',
                    LOC_NAMES[loc] or tostring(loc), tonumber(bag.used) or #bag.items,
                    tonumber(bag.size) or 0, loc), state.bagLoc == loc)) then
                state.bagLoc = loc;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.bagLoc);
    end

    imgui.SameLine();
    imgui.PushItemWidth(160);
    imgui.InputText('##dwbags_bagfind', state.bagFind, 48);
    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.bagFind);
    end

    if (state.bagFind[1] ~= '') then
        imgui.SameLine();

        if (imgui.SmallButton('x##dwbags_bagfind_clear')) then
            state.bagFind[1] = '';
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.bagClear);
        end
    end

    -- The row order (1.25). A thousand rows in container order answers
    -- "what is in my satchel"; it does not answer "have I got two of these
    -- somewhere" or "what is taking up the most room", which are the other
    -- two questions a bag browser gets opened for.
    imgui.SameLine();
    imgui.PushItemWidth(110);

    local sortLabel = 'Bag order';

    for _, entry in ipairs(BAG_SORTS) do
        if (entry.name == state.bagSort) then
            sortLabel = entry.label;
        end
    end

    if (imgui.BeginCombo('##dwbags_bagsort', sortLabel)) then
        for _, entry in ipairs(BAG_SORTS) do
            if (imgui.Selectable(string.format('%s##dwbags_sort_%s', entry.label, entry.name),
                    state.bagSort == entry.name)) then
                state.bagSort = entry.name;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.bagSort);
    end

    --[[
        THE BULK STASH ROW (1.28) -- "Send All to WH" and the container it
        would empty.

        A ROW OF ITS OWN, below the narrowing row and not on it. The four
        controls above are all questions about what to LOOK at and are free
        to be wrong; this pair moves a bag. Putting a destructive-ish control
        on the same line as a view filter is how a player ends up clicking it
        because they were reaching for the sort.

        AND THE COMBO IS NOT `bagLoc`. The filter has an "All bags" answer
        and this has none -- see state.stashAllBag. It lists exactly the
        containers the Bags tab enumerates for this character, which is the
        same set the server's stash path will accept, because both come from
        the bags the server described in its `n|` records.

        THE CLICK ASKS AND DOES NOT MOVE. It types the DRY RUN
        (`!dwq stashall <who> <bag#> count`); the server's q| answer fills
        state.stashAllAsk and the window-level popup below the tab bar puts
        the real number to the player. The move is typed only by that
        popup's button -- the Trash rule, ported, for the same reason.
    ]]
    if (not stashAllUnsupported) then
        local locs = containerList();

        -- Default to whatever container the tab is already narrowed to, and
        -- otherwise to the first one this character owns. Re-checked every
        -- frame because the pick has to follow the CHARACTER: Alta's satchel
        -- is not a container Betta necessarily has, and a stale id would name
        -- a bag the button then emptied on the wrong person.
        if (state.stashAllBag == nil or state.bags[state.stashAllBag] == nil) then
            state.stashAllBag = state.bagLoc ~= nil and state.bags[state.bagLoc] ~= nil
                and state.bagLoc
                or locs[1];
        end

        if (state.stashAllBag ~= nil) then
            imgui.PushItemWidth(130);

            local target = state.stashAllBag;

            if (imgui.BeginCombo('##dwbags_stashall_bag',
                    LOC_NAMES[target] or tostring(target))) then
                for _, loc in ipairs(locs) do
                    local bag = state.bags[loc];

                    -- tonumber for refreshBagView's reason: `%d` on a sugar
                    -- table method raises, and this label is rebuilt every
                    -- frame the combo is open.
                    if (imgui.Selectable(string.format('%s (%d/%d)##dwbags_stashall_loc_%d',
                            LOC_NAMES[loc] or tostring(loc), tonumber(bag.used) or #bag.items,
                            tonumber(bag.size) or 0, loc), target == loc)) then
                        state.stashAllBag = loc;
                    end
                end

                imgui.EndCombo();
            end

            imgui.PopItemWidth();

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.stashAllBag);
            end

            imgui.SameLine();

            if (imgui.SmallButton('Send All to WH##dwbags_stashall')) then
                issue(string.format('!dwq stashall %s %d count', name, state.stashAllBag));
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.stashAll);
            end

            imgui.SameLine();
            imgui.TextDisabled('Asks first, and moves all of it or none of it.');
        end
    end

    refreshBagView();

    local rows  = bagView.rows;
    local total = bagView.total;

    -- Nothing has arrived yet, or nothing matches: either way the table
    -- below drew a header row over blank space and said nothing about which
    -- of the two it was (2026-09-06). The answer clock already knows.
    if (#rows == 0) then
        local asked = requested['bag'];

        if (total == 0 and (asked == nil or asked.charid ~= state.selected or not asked.answered)) then
            imgui.TextDisabled(string.format('Reading %s\'s bags...', name));
        elseif (total == 0) then
            imgui.TextDisabled(string.format('%s is carrying nothing at all.', name));
        else
            imgui.TextDisabled(string.format('None of %s\'s %d items match. Clear the filters above to see them.',
                name, total));
        end

        return;
    end

    local pages = math.max(1, math.ceil(#rows / BAG_PAGE));

    if (bagPage > pages) then
        bagPage = pages;
    end

    if (bagPage < 1) then
        bagPage = 1;
    end

    local first = (bagPage - 1) * BAG_PAGE + 1;
    local last  = math.min(#rows, first + BAG_PAGE - 1);

    if (#rows < total or pages > 1) then
        if (pages > 1) then
            imgui.TextDisabled(string.format('Showing %d-%d of %d%s.', first, last, #rows,
                #rows < total and ' matching (filtered)' or ' items'));
        else
            imgui.TextDisabled(string.format('Showing %d of %d items (filtered).', #rows, total));
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.showing);
        end
    end

    if (pages > 1) then
        imgui.SameLine();

        -- Greyed at the ends rather than dead (2026-09-06): a button that
        -- draws normally and does nothing reads as a broken button, and the
        -- tooltip on the greyed one says which end you are already at.
        local atStart = bagPage <= 1;
        local atEnd   = bagPage >= pages;

        imgui.BeginDisabled(atStart);

        if (imgui.SmallButton('<##dwbags_page_prev') and not atStart) then
            bagPage = bagPage - 1;
        end

        imgui.EndDisabled();

        -- Only while it is live: a disabled item reports no hover, so the
        -- greyed arrow's reason lives on the counter below (TIPS.pager).
        if (not atStart and imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.pagePrev);
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('page %d of %d', bagPage, pages));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.pager);
        end

        imgui.SameLine();

        imgui.BeginDisabled(atEnd);

        if (imgui.SmallButton('>##dwbags_page_next') and not atEnd) then
            bagPage = bagPage + 1;
        end

        imgui.EndDisabled();

        if (not atEnd and imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.pageNext);
        end
    end

    -- How full this character is, across every bag at once (1.25). The left
    -- pane's used/size is the pair the roster sends and is one number for
    -- the whole character; this is the sum of the containers actually
    -- listed, so the two agree and neither had to be asked for.
    if (bagView.totals ~= '') then
        imgui.SameLine();
        imgui.TextDisabled(bagView.totals);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.bagTotals);
        end
    end

    --[[
        THE SELECTION ROW (1.30), between the counters and the list.

        A ROW OF ITS OWN, below everything that narrows the view and above the
        rows it acts on -- the "Send All to WH" placement rule, for the same
        reason: the controls above are questions about what to LOOK at and are
        free to be wrong, while these two destroy and sell.

        ALL / NONE / INVERT ACT ON WHAT IS SHOWN. That is what those words mean
        over a filtered list, and it is the whole of the "select all of this
        item" workflow when combined with the find box. `Same item` widens the
        other way: it ticks every row sharing an item id with something already
        ticked, wherever it is in the rows being shown.

        THE COUNT ON THE BUTTONS IS NOT THE COUNT ON THIS ROW'S LEFT. The left
        side counts what is ticked ACROSS EVERY CONTAINER, which is what the
        buttons act on; a filter narrowed after ticking does not shrink the
        press behind the player's back. See refreshPickView.
    ]]
    local picked = refreshPickView();

    imgui.TextDisabled('Tick:');
    imgui.SameLine();

    if (imgui.SmallButton('All##dwbags_pick_all')) then
        for _, row in ipairs(rows) do
            setPicked(rowIds(row).key, true);
        end

        state.pickedFor = state.selected;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pickAll);
    end

    imgui.SameLine();

    if (imgui.SmallButton('None##dwbags_pick_none')) then
        clearPicked();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pickNone);
    end

    imgui.SameLine();

    if (imgui.SmallButton('Invert##dwbags_pick_invert')) then
        for _, row in ipairs(rows) do
            local key = rowIds(row).key;

            setPicked(key, state.picked[key] ~= true);
        end

        state.pickedFor = state.selected;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pickInvert);
    end

    -- "Select all of this item", said as a WIDENING of what is already ticked
    -- rather than as a button on every row: a per-row control would be three
    -- hundred more widgets a frame for a question a player asks once, and this
    -- shape answers it for several items at once.
    imgui.SameLine();

    imgui.BeginDisabled(picked.kinds == 0);

    if (imgui.SmallButton('Same item##dwbags_pick_same') and picked.kinds > 0) then
        local wanted = { };

        for _, row in ipairs(picked.rows) do
            wanted[row.itemid] = true;
        end

        for _, row in ipairs(rows) do
            if (wanted[row.itemid]) then
                setPicked(rowIds(row).key, true);
            end
        end

        state.pickedFor = state.selected;
    end

    imgui.EndDisabled();

    -- Only while it is live: a disabled item reports no hover, so the greyed
    -- button's reason rides the count beside it (TIPS.pickCount).
    if (picked.kinds > 0 and imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pickSame);
    end

    imgui.SameLine();

    if (#picked.rows == 0) then
        imgui.TextDisabled('nothing ticked');
    elseif (vendoring and picked.gil > 0) then
        imgui.TextDisabled(string.format('%d row%s ticked -- %s gil to a merchant.',
            #picked.rows, #picked.rows == 1 and '' or 's', commaGil(picked.gil)));
    else
        imgui.TextDisabled(string.format('%d row%s ticked.',
            #picked.rows, #picked.rows == 1 and '' or 's'));
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.pickCount);
    end

    -- The two batch presses. Each is drawn only where its server half exists,
    -- and greyed rather than absent when nothing is ticked -- a button that
    -- appears and disappears as ticks come and go is a moving target.
    if (not trashUnsupported and not trashManyUnsupported) then
        imgui.SameLine();

        local none = #picked.rows == 0;

        imgui.BeginDisabled(none);

        if (imgui.SmallButton(string.format('Trash Selected (%d)##dwbags_trash_many', #picked.rows))
                and not none) then
            askBatch(false, picked.rows, true, name);
        end

        imgui.EndDisabled();

        if (not none and imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.trashMany);
        end
    end

    if (vendoring) then
        imgui.SameLine();

        -- Counted in SELLABLE rows, not in ticked ones: the number on a button
        -- has to be the number the press acts on, and a sale skips what no
        -- merchant will buy. The question that follows says how many were
        -- skipped and why.
        local sellable = #picked.sellable;

        imgui.BeginDisabled(sellable == 0);

        if (imgui.SmallButton(string.format('Vendor Selected (%d)##dwbags_vendor_many', sellable))
                and sellable > 0) then
            askBatch(true, picked.rows, true, name);
        end

        imgui.EndDisabled();

        if (sellable > 0 and imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.vendorMany);
        end
    end

    if (imgui.BeginTable('##dwbags_items', vendoring and 6 or 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        -- The tick column is narrow on purpose (1.30): it holds one checkbox
        -- and nothing else, and every pixel it takes comes off the name.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 24, 0);
        -- The name column STRETCHES and the rest stay fixed (2026-09-06). It
        -- holds an icon and a name and no buttons, so it cannot feed its own
        -- width back into its own measurement the way the Gear tab's
        -- "Instead" column can -- and 250 pixels minus the icon clipped a
        -- good many of this game's longer item names, in a window the player
        -- had widened precisely in order to read them.
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 40, 0);

        -- Only on a server that prices things: see the sellable filter above.
        if (vendoring) then
            imgui.TableSetupColumn('Value', ImGuiTableColumnFlags_WidthFixed, 72, 0);
        end

        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        -- Wide enough for Use + Fetch + Send + Stash + Trash side by side.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 265, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for index = first, last do
            itemRow(rows[index], vendoring);
        end

        imgui.EndTable();
    end
end

--[[
* The upgrade sentence, assembled from the h| record's ids through the client's
* own resources -- names never ride this wire (the dwbags rule). The worn
* piece's name comes from the g| record already on screen for the same slot.
--]]
local function upgradeTooltip(hint)
    local donor     = state.chars[hint.fromcharid];
    local donorName = donor ~= nil and donor.name or 'another character';
    local where     = LOC_NAMES[hint.loc] or tostring(hint.loc);
    local worn      = state.gear[hint.slot];
    local against   = worn ~= nil
        and string.format('the worn %s scores %d', itemName(worn.itemid), hint.worn)
        or 'the slot is empty';

    if (isSelf(hint.fromcharid)) then
        return string.format('Your %s (%s) scores %d here; %s.\nClick to send it over.',
            itemName(hint.itemid), where, hint.score, against);
    end

    return string.format('%s\'s %s (%s) scores %d here; %s.\nClick to fetch it and send it over.',
        donorName, itemName(hint.itemid), where, hint.score, against);
end

--[[
* The Manual face of the Gear tab (1.16): a slot list on the left, and on the
* right EVERYTHING the selected character's own bags hold that fits the chosen
* slot. Nothing here transfers -- every click is the same `!dwq equip` the
* Automatic column issues, so a manual pick is a pin and the server's
* wearability rules still decide what is actually worn at summon time. The
* full list is the slot-scoped `!dwq gear <who> <slot>` ask; the rows land in
* state.options exactly like the capped ones, so this draws whatever the
* server of the day can say.
--]]
local function manualGearBody(name)
    imgui.TextDisabled('Pick a slot, then click a piece from ' .. name .. '\'s own bags to wear it.');
    imgui.TextDisabled('A manual pick is a pin: it holds until you click Auto. Nothing moves between characters here.');

    imgui.BeginChild('##dwbags_manual_slots', { 190, 0 }, ImGuiChildFlags_Borders);

    for slot = 0, 15 do
        local worn = state.gear[slot];

        if (imgui.Selectable(slotListLabel(slot, worn), state.manualSlot == slot)) then
            state.manualSlot = slot;
        end

        -- The card on the slot list too: the label truncates a long name,
        -- and "what is that" is the same question everywhere else answers
        -- on hover.
        if (worn ~= nil and imgui.IsItemHovered()) then
            itemCard(worn.itemid, worn.augs);
        end
    end

    imgui.EndChild();
    imgui.SameLine();
    imgui.BeginChild('##dwbags_manual_list', { 0, 0 }, ImGuiChildFlags_None);

    if (state.manualSlot == nil) then
        imgui.Text('Pick a slot on the left.');
        imgui.EndChild();

        return;
    end

    local slot = state.manualSlot;
    local worn = state.gear[slot];

    if (worn ~= nil) then
        drawIcon(worn.itemid, 20);

        local hovered = imgui.IsItemHovered();

        imgui.Text(string.format('Wearing %s (scores %d)', itemName(worn.itemid), worn.score));
        cardOnHover(worn.itemid, hovered, worn.augs);

        if (worn.pinned) then
            imgui.SameLine();
            imgui.TextColored(theme.colors.pin, '[pin]');
        end
    else
        imgui.TextDisabled('Wearing nothing here.');
    end

    if (imgui.SmallButton(SLOT_IDS[slot].mauto)) then
        issue(string.format('!dwq equip %s %s auto', name, SLOT_NAMES[slot]));

        requested['gear'] = nil;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Forget the pin and let the scorer choose for this slot again.');
    end

    imgui.SameLine();

    if (imgui.SmallButton(SLOT_IDS[slot].mnone)) then
        issue(string.format('!dwq equip %s %s none', name, SLOT_NAMES[slot]));

        requested['gear'] = nil;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Pin the slot shut -- nothing will be worn in it.');
    end

    imgui.Separator();

    -- The refused list renders in BOTH branches below: a slot whose only
    -- owned piece failed the wearability door has no options at all, and
    -- that is exactly the case where the reason matters most (1.23, the
    -- Voay Staff report).
    local function drawRefused()
        local refused = state.refused[slot];

        if (refused == nil or #refused == 0) then
            return;
        end

        imgui.Separator();
        imgui.TextDisabled('Owned, but cannot be worn right now:');

        for _, row in ipairs(refused) do
            drawIcon(row.itemid, 20);

            local hovered = imgui.IsItemHovered();

            -- Built once per row per answer, the rowIds rule: the reason
            -- comes off the wire and the name out of the DAT, so neither
            -- half of this line can change while the row exists.
            if (row.reasontext == nil) then
                row.reasontext = string.format('%s -- %s', itemName(row.itemid), row.reason);
            end

            imgui.TextDisabled(row.reasontext);
            cardOnHover(row.itemid, hovered, nil);
        end
    end

    local options = state.options[slot];

    if (options == nil or #options == 0) then
        imgui.TextDisabled(string.format('Nothing else in %s\'s own bags fits this slot.', name));
        drawRefused();
        imgui.EndChild();

        return;
    end

    --[[
        THE TABLE LEAVES ROOM FOR THE LIST UNDER IT (2026-09-06).

        `{ -1, -1 }` on a ScrollY table means "all the remaining height",
        so with alternatives present the refused list -- the whole point of
        the 1.23 round, and the answer to "why can this character not wear
        the staff it owns" -- was laid out entirely below the visible area.
        The child scrolls, so it was reachable; it was also invisible until
        somebody thought to scroll a pane whose table already filled it.

        Reserved from the list's own length and capped at six rows: the
        picker is what the pane is for, and a character with thirty refused
        pieces must not squeeze it out.
    ]]
    local refusedNow  = state.refused[slot];
    local refusedRows = refusedNow ~= nil and #refusedNow or 0;
    local tableHeight = -1;

    if (refusedRows > 0) then
        tableHeight = -(imgui.GetTextLineHeightWithSpacing() * (math.min(refusedRows, 6) + 2));
    end

    if (imgui.BeginTable('##dwbags_manual_items', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, tableHeight })) then
        -- STRETCHED, not the old fixed 260 (2026-09-06). The cell holds a
        -- 20-pixel icon and a button labelled with the item name, so it is
        -- the column most likely to clip exactly the name being compared --
        -- and this pane loses 190 pixels to the slot list beside it before
        -- the table starts. The oscillation the Gear tab's comment warns
        -- about is StretchPROP, which measures content to decide a width;
        -- an explicit stretch weight measures nothing but the space left
        -- over, and a SmallButton sizes itself from its own label either
        -- way, so there is no loop to enter.
        imgui.TableSetupColumn('Piece', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Score', ImGuiTableColumnFlags_WidthFixed, 50, 0);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for index, option in ipairs(options) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            drawIcon(option.itemid, 20);

            if (imgui.SmallButton(pickLabel(option, slot, index))) then
                issue(string.format('!dwq equip %s %s %d', name, SLOT_NAMES[slot], option.itemid));

                requested['gear'] = nil;
            end

            -- The card is the point, exactly as on the Automatic column:
            -- comparing two rings here is the wiki trip it replaces.
            if (imgui.IsItemHovered()) then
                itemCard(option.itemid, option.augs);
            end

            imgui.TableNextColumn();
            imgui.Text(tostring(option.score));

            imgui.TableNextColumn();
            imgui.Text(LOC_NAMES[option.loc] or tostring(option.loc));
        end

        imgui.EndTable();
    end

    drawRefused();

    imgui.EndChild();
end

--[[
* THE WAREHOUSE FACE (1.21) -- "Optimize from Warehouse".
*
* The Gear tab's other two faces read the character's OWN bags. Between them
* and the account-wide upgrade markers sat the warehouse -- a thousand rows of
* exactly the spare gear this is about -- which nothing gearing a member had
* ever read. A player whose spares live where spares belong was told, correctly
* and uselessly, that nothing on the account beat what the member wore.
*
* IT IS A PLAN, NOT A BUTTON THAT FIRES. `!squad restock <who>` previews and
* `!squad restock <who> apply` moves, and this pane is those two typed lines: it
* draws the preview and offers Apply. That split is `!optimizegear preview`'s
* precedent and it is the right one here for a sharper reason -- one press can
* move a dozen irreplaceable items out of storage at once, and a player is
* entitled to read the list first.
*
* ONE LINE PER PRESS, NEVER A CHAIN. Every other transfer in this addon queues
* the typed lines a player would send, one per interval. This one sends a single
* `!dwq restock <who> apply` and lets the server walk the plan, because the
* three-step version -- take, send, equip, per slot -- is wrong in ways a
* renderer cannot fix: `send` resolves by item id and can ship the player's own
* copy instead of the stored one, a refused step strands an item in the caller's
* inventory with nothing saying so, and sixteen slots is forty-eight throttled
* lines. The server's verb is one transaction per row and re-checks every rule.
*
* THE PER-ROW BUTTON IS THE SAME VERB'S OTHER HALF: `!dww sendto` addresses ONE
* warehouse row, which is why the record carries a row id rather than an item
* id -- two stored copies of one item can differ by their augments.
--]]
local function warehouseGearBody(name)
    if (restockUnsupported) then
        imgui.TextColored(theme.colors.warn, 'This server does not have warehouse gearing yet.');
        imgui.TextDisabled('Everything else on this tab still works.');

        return;
    end

    need('restock', state.selected);

    imgui.TextDisabled('The best thing in your account warehouse for each of ' .. name .. '\'s slots.');
    imgui.TextDisabled('Delivering it IS equipping it: a member dresses out of its bags every time you call it.');

    -- Counted before the table so the Apply button can say how many, and so
    -- "nothing to do" is a sentence rather than an empty grid.
    local planned = 0;

    for slot = 0, 15 do
        if (state.restock[slot] ~= nil) then
            planned = planned + 1;
        end
    end

    if (planned == 0) then
        -- "Nothing beats it" IS AN ANSWER, so it must not be said before one
        -- has arrived. An empty section is the state this pane opens in, and
        -- for the ~1.2s the throttled ask takes it is indistinguishable from a
        -- real empty plan -- so the player reads a confident, wrong sentence
        -- and clicks away. The ask's own answer clock already knows which one
        -- this is: `answered` is set from the `d|` envelope.
        local asked = requested['restock'];

        if (asked == nil or asked.charid ~= state.selected or not asked.answered) then
            imgui.TextDisabled('Reading your warehouse...');
        else
            imgui.TextColored(theme.colors.ok,
                string.format('Nothing in the warehouse beats what %s already wears.', name));
        end

        return;
    end

    if (imgui.Button(string.format('Apply all %d##restock_apply', planned))) then
        issue(string.format('!dwq restock %s apply', name));

        -- Both sections move: the plan is re-read (what is LEFT to do) and the
        -- gear list is re-read (the member's bags just changed).
        requested['restock'] = nil;
        requested['gear']    = nil;

        refetchVisible();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Sends every piece below out of the warehouse and into ' .. name .. '\'s bags.\n'
            .. 'Each one re-checks its own rules; anything refused is named and nothing else stops.\n'
            .. 'Call ' .. name .. ' again afterwards to see it wearing them.');
    end

    imgui.SameLine();
    imgui.TextDisabled(string.format('%d slot%s', planned, planned == 1 and '' or 's'));

    if (imgui.BeginTable('##dwbags_restock', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Slot', ImGuiTableColumnFlags_WidthFixed, 55, 0);
        imgui.TableSetupColumn('Wearing', ImGuiTableColumnFlags_WidthFixed, 240, 0);
        -- The stored piece's cell also carries the +N delta and a Send
        -- button, so it is the widest thing on the row and was the tightest
        -- column (2026-09-06).
        imgui.TableSetupColumn('From the warehouse', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for slot = 0, 15 do
            local plan = state.restock[slot];

            if (plan ~= nil) then
                local worn = state.gear[slot];

                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(SLOT_NAMES[slot]);

                imgui.TableNextColumn();

                if (worn ~= nil) then
                    drawIcon(worn.itemid, 20);

                    local hovered = imgui.IsItemHovered();

                    imgui.Text(itemName(worn.itemid));
                    cardOnHover(worn.itemid, hovered, worn.augs);
                else
                    imgui.TextDisabled('empty');
                end

                imgui.TableNextColumn();

                drawIcon(plan.itemid, 20);

                local overHovered = imgui.IsItemHovered();

                imgui.Text(itemName(plan.itemid));
                cardOnHover(plan.itemid, overHovered, plan.augs);

                -- The improvement, in the scorer's own units. Not a percentage:
                -- the score is not a percentage of anything, and dressing it up
                -- as one would be inventing a number the server never sent.
                imgui.SameLine();
                imgui.TextColored(COLOR_HINT, plan.deltatext);

                -- The number's unit, which is nobody's but the scorer's
                -- (2026-09-06). Every other number in this window is a
                -- count or a level and reads as one; this one is neither.
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format(
                        'How much better the stored piece scores: %d against %d.\n'
                        .. 'The scorer\'s own units -- not a percentage of anything.',
                        plan.score, plan.wornscore));
                end

                if (imgui.SmallButton(SLOT_IDS[slot].restock)) then
                    -- The ROW, not the item -- see the header above -- and
                    -- through `!dwq restock` rather than `!dww sendto`, which
                    -- is the verb that actually moves it. The warehouse verb
                    -- answers on ITS OWN sender, which this addon does not
                    -- parse, so its reply would arrive as raw records in the
                    -- chat log. Every line this addon sends is a !dwq line.
                    issue(string.format('!dwq restock %s %d', name, plan.rowid));

                    requested['restock'] = nil;
                    requested['gear']    = nil;

                    refetchVisible();
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('%s scores %d here; %s.\nClick to send just this one.',
                        itemName(plan.itemid), plan.score,
                        worn ~= nil
                            and string.format('the worn %s scores %d', itemName(worn.itemid), plan.wornscore)
                            or 'the slot is empty'));
                end
            end
        end

        imgui.EndTable();
    end
end

--[[
* THE AUTOMATON NAME ROW (1.27, the owner's ask of 2026-09-10).
*
* One line under the mode buttons, drawn in all three faces of the Gear tab
* because it belongs to the same question they answer: what this character
* brings the next time you call it. squad_pets.cpp reads the name off
* char_pet at the moment the puppet is painted, so a name written here shows
* up on the next activation -- no relog, no quest.
*
* IT IS ONLY EVER AN ALT'S. Retail asks for the name once, in the "No Strings
* Attached" cutscene, and the game does that one; the played character's row
* says so instead of drawing a control it would refuse. The server refuses it
* too, in the same words.
*
* THE NAMES ARE THE SERVER'S. `state.autoNames` arrives as `r|` records read
* out of its pet_name table -- this file holds no name of its own, so a name
* added to that table is offered without the addon being re-packaged. That is
* the one place this window asks the server for a STRING rather than resolving
* an id against the client's DATs, and it is because the client has no
* resource for these at all.
*
* Apply is a separate press from the pick, the warehouse face's rule: the
* combo says what would happen and the button is what makes it happen.
--]]
local function automatonRow(name)
    if (autonameUnsupported) then
        return;
    end

    if (isSelf(state.selected)) then
        imgui.TextDisabled('Automaton name: the game\'s own quest names yours.');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.autoSelf);
        end

        return;
    end

    need('autoname', state.selected);

    local current = state.autoName.name;
    local shown   = (current ~= nil and current ~= '') and current or '(unnamed)';

    imgui.Text('Automaton name:');

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.autoName);
    end

    imgui.SameLine();
    imgui.PushItemWidth(150);

    -- What the combo SHOWS is the pick when there is one and the server's
    -- answer otherwise, so the control reads as the thing that is about to
    -- happen -- and afterCommit clears the pick, so an answer always wins.
    local picked = nil;

    if (state.autoPick ~= nil) then
        for _, entry in ipairs(state.autoNames) do
            if (entry.id == state.autoPick) then
                picked = entry;
            end
        end
    end

    if (imgui.BeginCombo('##dwbags_autoname', picked ~= nil and picked.name or shown)) then
        for _, entry in ipairs(state.autoNames) do
            -- The label carries a `##` id because two rows may share a name
            -- one day and ImGui keys a Selectable on its whole label: two
            -- identical labels are ONE widget, and clicking either would
            -- select the first.
            if (imgui.Selectable(string.format('%s##dwbags_autoname_%d', entry.name, entry.id),
                    state.autoPick == entry.id or (state.autoPick == nil and state.autoName.id == entry.id))) then
                state.autoPick = entry.id;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
    imgui.SameLine();

    if (#state.autoNames == 0) then
        imgui.TextDisabled(string.format('Reading %s\'s automaton...', name));

        return;
    end

    if (state.autoPick == nil or state.autoPick == state.autoName.id) then
        imgui.TextDisabled('Pick a name to change it.');

        return;
    end

    if (imgui.SmallButton('Apply##dwbags_autoname_apply')) then
        issue(string.format('!dwq autoname %s %d', name, state.autoPick));

        -- The read is re-asked rather than assumed: the server's write
        -- re-states the whole answer, so the section on screen is replaced by
        -- what it actually wrote and never by what was clicked.
        requested['autoname'] = nil;
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.autoApply);
    end
end

local function gearTab()
    local name = selectedName();

    if (name == nil) then
        imgui.Text('Pick a character.');

        return;
    end

    -- One ask, two spellings: plain in Automatic, slot-scoped in Manual once
    -- a slot is chosen (before that the plain answer fills the slot list).
    needGear(state.selected, (state.gearMode == 'manual' and state.manualSlot ~= nil) and state.manualSlot or nil);

    -- The two faces (1.16). SmallButtons rather than a disabled pair, the
    -- Storage tab's layout-row rule: the current one is said in words beside
    -- them, where it cannot be mistaken for a dead control.
    imgui.Text('Mode:');
    imgui.SameLine();

    if (imgui.SmallButton('Automatic##gearmode_auto')) then
        state.gearMode = 'auto';
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('The scorer dresses them from their own bags; click an alternative to pin it.');
    end

    imgui.SameLine();

    if (imgui.SmallButton('Manual##gearmode_manual')) then
        state.gearMode = 'manual';
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Pick a slot and choose from everything they own that fits it.\nOnly their own bags -- nothing is moved between characters.');
    end

    imgui.SameLine();

    -- The third face (1.21). A button beside the other two rather than a
    -- control of its own, because it answers the same question they do -- what
    -- should this character be wearing -- out of a store neither of them reads.
    if (imgui.SmallButton('Optimize from Warehouse##gearmode_warehouse')) then
        state.gearMode = 'warehouse';
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('What your account WAREHOUSE holds that would upgrade this character.\nShows the plan first; nothing moves until you press Apply.');
    end

    imgui.SameLine();
    imgui.TextColored(theme.colors.ok,
        state.gearMode == 'manual' and 'Manual'
            or (state.gearMode == 'warehouse' and 'Warehouse' or 'Automatic'));

    -- And which job the scoring is FOR (1.25). Every number in this tab is
    -- an opinion about a role, the role comes from the member's main job,
    -- and the tab named neither -- so a column that had re-scored itself
    -- after a job change read as a column that had changed its mind.
    local scoredFor = state.chars[state.selected];

    if (scoredFor ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(charScoredFor(scoredFor));
    end

    automatonRow(name);

    if (state.gearMode == 'manual') then
        manualGearBody(name);

        return;
    end

    -- The plan is drawn against the character's WORN gear, so the gear read has
    -- to happen either way -- needGear above already asked for it.
    if (state.gearMode == 'warehouse') then
        warehouseGearBody(name);

        return;
    end

    -- The gear scan deliberately refuses the character being played -- a real
    -- player's gear is their own business -- so their tab is never asked.
    if (not hintsUnsupported and not isSelf(state.selected)) then
        need('hints', state.selected);
    end

    imgui.TextDisabled('Gearing is automatic. Click an alternative to pin it; Auto undoes the pin.');

    -- SizingFixedFit with explicit widths, not StretchProp: the "Instead" cells
    -- hold a variable stack of buttons whose width depends on item names, so a
    -- stretched column feeds its own width back into its content measurement and
    -- oscillates by a pixel or two every frame as the scrollbar comes and goes.
    -- Fixed columns cannot enter that loop.
    -- Nothing has arrived yet: the table below drew a header over blank
    -- space and left "gearing is automatic" reading as the whole answer
    -- (2026-09-06). The warehouse face's rule, and its answer clock.
    if (next(state.gear) == nil and next(state.options) == nil) then
        local asked = requested['gear'];

        if (asked == nil or asked.charid ~= state.selected or not asked.answered) then
            imgui.TextDisabled(string.format('Reading what %s is wearing...', name));

            return;
        end
    end

    -- 190 -> 240 on both columns (2026-09-06). Both hold an item name (the
    -- second holds a BUTTON labelled with one) and this game's longer names
    -- ran off the end of each -- so the two columns whose whole job is
    -- comparing two pieces were the two that would not show either name.
    -- Still fixed rather than stretched, for the reason below.
    if (imgui.BeginTable('##dwbags_gear', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Slot', ImGuiTableColumnFlags_WidthFixed, 55, 0);
        imgui.TableSetupColumn('Wearing', ImGuiTableColumnFlags_WidthFixed, 240, 0);
        imgui.TableSetupColumn('Instead', ImGuiTableColumnFlags_WidthFixed, 240, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for slot = 0, 15 do
            local worn    = state.gear[slot];
            local options = state.options[slot];
            local hint    = state.hints[slot];

            if (worn ~= nil or (options ~= nil and #options > 0) or hint ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(SLOT_NAMES[slot]);

                if (hint ~= nil) then
                    imgui.SameLine();
                    imgui.TextColored(COLOR_HINT, '+');

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(upgradeTooltip(hint));
                    end
                end

                imgui.TableNextColumn();

                if (worn ~= nil) then
                    drawIcon(worn.itemid, 20);

                    local hovered = imgui.IsItemHovered();

                    imgui.Text(itemName(worn.itemid));
                    cardOnHover(worn.itemid, hovered, worn.augs);

                    if (worn.pinned) then
                        imgui.SameLine();
                        imgui.TextColored(theme.colors.pin, '[pin]');

                        -- The one marker in this window that changes what
                        -- the scorer does and never said so (2026-09-06).
                        if (imgui.IsItemHovered()) then
                            imgui.SetTooltip(TIPS.pinned);
                        end
                    end
                else
                    imgui.TextDisabled('empty');
                end

                imgui.TableNextColumn();

                if (options ~= nil) then
                    for index = 1, math.min(#options, 4) do
                        local option = options[index];

                        if (imgui.SmallButton(pinLabel(option, slot, index))) then
                            issue(string.format('!dwq equip %s %s %d', name, SLOT_NAMES[slot], option.itemid));

                            requested['gear'] = nil;
                        end

                        -- The card on the equip options is the whole point
                        -- of having it in this tab: comparing two rings is
                        -- exactly the wiki trip the card replaces.
                        if (imgui.IsItemHovered()) then
                            itemCard(option.itemid, option.augs);
                        end
                    end
                end

                -- The upgrade recipe, one click away (UPGRADE_HINTS_PLAN.md
                -- Phase 3): the same typed lines a player would send -- fetch
                -- into your own inventory, then send to this character --
                -- queued one per interval, in order, NEVER retried.
                --
                -- THE SEND IS CHAINED TO THE FETCH (1.20.0). The claim that
                -- used to stand here -- "if the fetch is refused the send then
                -- refuses on its own terms; nothing moves that the typed
                -- commands would not have moved" -- was wrong in exactly the
                -- case this button is for. See issueChained: `send` resolves
                -- by item id across all of the caller's own containers, so a
                -- refused fetch is followed by a send that finds the caller's
                -- OWN copy and ships it. Rare items make it worse, because
                -- owning one is itself the reason the fetch was refused.
                if (hint ~= nil) then
                    local donor = state.chars[hint.fromcharid];

                    if (donor ~= nil) then
                        if (imgui.SmallButton(getLabel(hint, slot))) then
                            -- Chained only when there IS a first line to
                            -- depend on. The piece already being in the
                            -- caller's own bags makes this a plain send, and a
                            -- plain send must not be droppable by somebody
                            -- else's unrelated refusal.
                            if (bit.band(donor.flags, CHAR_SELF) == 0) then
                                issuePair(string.format('!dwq fetch %s %d 1', donor.name, hint.itemid),
                                          string.format('!dwq send %s %d 1', name, hint.itemid));
                            else
                                issue(string.format('!dwq send %s %d 1', name, hint.itemid));
                            end

                            refetchVisible();
                        end

                        if (imgui.IsItemHovered()) then
                            imgui.SetTooltip(upgradeTooltip(hint));
                        end
                    end
                end

                if (worn ~= nil and worn.pinned) then
                    if (imgui.SmallButton(SLOT_IDS[slot].auto)) then
                        issue(string.format('!dwq equip %s %s auto', name, SLOT_NAMES[slot]));

                        requested['gear'] = nil;
                    end

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(TIPS.gearAuto);
                    end
                end
            end
        end

        imgui.EndTable();
    end
end

--[[
* THE FIND TAB (1.25 pass).
*
* A find is not keyed by a character and so has no need() of its own -- which
* is exactly why it also had no state to show for itself. Typing one letter
* and pressing Search did nothing, silently; a search whose line was dropped
* on the way out left the previous result set on screen with nothing to say
* it was old; and a search that legitimately matched nothing drew an empty
* grid under a caption promising every container on the account.
*
* `findAnswered` is that missing state, and it is the QUERY rather than a
* flag on purpose: a boolean set at the click would be cleared by any
* unrelated refusal arriving in between -- a Send being turned down, say --
* and the tab would flash "nothing matches" about a search still in flight.
* Comparing the answered query against the asked one cannot do that, and it
* needs no clock: a find envelope commits, or it does not.
--]]
local function runSearch()
    if (#state.search[1] < 2) then
        return;
    end

    state.findQuery = state.search[1];

    issue(string.format('!dwq find %s', state.search[1]), true);
end

local function findTab()
    imgui.PushItemWidth(240);

    if (imgui.InputText('##dwbags_search', state.search, 64,
            ImGuiInputTextFlags_EnterReturnsTrue)) then
        runSearch();
    end

    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.findBox);
    end

    imgui.SameLine();

    -- Greyed under two letters rather than dead (2026-09-06). The server
    -- sets the floor and would refuse a one-letter search anyway; what the
    -- old button did was accept the click and do nothing at all.
    local tooShort = #state.search[1] < 2;

    imgui.BeginDisabled(tooShort);

    if (imgui.Button('Search##dwbags_search_go')) then
        runSearch();
    end

    imgui.EndDisabled();

    -- Only while it is live: a disabled item reports no hover at all, so the
    -- reason it is grey has to be a SENTENCE beside it rather than a tooltip
    -- on it (see TIPS.pager).
    if (not tooShort and imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.findBox);
    end

    imgui.SameLine();

    if (tooShort and #state.search[1] > 0) then
        imgui.TextColored(theme.colors.warn, 'Type at least two letters.');
    else
        imgui.TextDisabled('Every container on every character on your account.');
    end

    -- What the tab is actually doing, which it never said (2026-09-06).
    if (state.findQuery ~= '' and state.findAnswered ~= state.findQuery) then
        imgui.TextDisabled(string.format('Searching every character for "%s"...', state.findQuery));
    elseif (state.findQuery ~= '' and #state.finds == 0) then
        imgui.TextDisabled(string.format('Nothing on your account matches "%s".', state.findQuery));
    elseif (#state.finds > 0) then
        imgui.TextDisabled(string.format('%d row%s matching "%s".',
            #state.finds, #state.finds == 1 and '' or 's', state.findQuery));

        -- The one list in this window worth handing to somebody else: "where
        -- is my Ranger's ammo" is a question players ask each other, and the
        -- answer is four columns of text they would otherwise retype (1.25).
        imgui.SameLine();

        if (imgui.SmallButton('Copy##dwbags_find_copy')) then
            local lines = T{ string.format('dwbags -- "%s"', state.findQuery) };

            for _, row in ipairs(state.finds) do
                local who = state.chars[row.charid] ~= nil and state.chars[row.charid].name or '?';

                lines:append(string.format('%s  %s  %s%s',
                    who, LOC_NAMES[row.loc] or tostring(row.loc), rowName(row),
                    row.qty > 1 and string.format(' x%d', row.qty) or ''));
            end

            imgui.SetClipboardText(table.concat(lines, '\n'));

            state.status    = string.format('Copied %d rows to the clipboard.', #state.finds);
            state.statusBad = false;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.findCopy);
        end
    end

    if (imgui.BeginTable('##dwbags_finds', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        -- The name column stretches here for the Bags tab's reason: it holds
        -- an icon and a name, and 230 pixels minus the icon clipped exactly
        -- the long names a search is most often run for.
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 40, 0);
        imgui.TableSetupColumn('Who', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        -- Wide enough for Use + Fetch + Send + Stash + Trash side by side.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 265, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(state.finds) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(rowName(row));
            rowCardOnHover(row, hovered);

            imgui.TableNextColumn();
            imgui.Text(row.qtytext or '');

            imgui.TableNextColumn();
            imgui.Text(state.chars[row.charid] ~= nil and state.chars[row.charid].name or '?');

            imgui.TableNextColumn();
            imgui.Text(LOC_NAMES[row.loc] or tostring(row.loc));

            imgui.TableNextColumn();
            transferButton(row);
        end

        imgui.EndTable();
    end
end

--[[
* What one group reads as: the destination its slots agree on, or nil when they
* do not.
*
* A GROUP THAT DISAGREES MUST SAY SO RATHER THAN PICK A WINNER. The server
* stores one destination per slot precisely so a layout can cut across these
* groups -- the owner's own puts head, neck and both earrings together, which is
* three of them -- and a renderer that showed the first slot's answer as the
* group's would be quietly wrong for exactly the layouts the storage exists to
* support.
--]]
local function groupDestination(group)
    if (group.other) then
        return state.prefs[0];
    end

    local agreed = nil;

    for _, slot in ipairs(group.slots) do
        local row = state.prefs[classOfSlot(slot)];

        if (row == nil) then
            return nil;
        end

        if (agreed == nil) then
            agreed = row;
        elseif (agreed.loc ~= row.loc) then
            return nil;
        end
    end

    return agreed;
end

local function destinationLabel(loc)
    for _, dest in ipairs(BAG_DESTINATIONS) do
        if (dest.loc == loc) then
            return dest.label;
        end
    end

    return LOC_NAMES[loc] or tostring(loc);
end

--[[
* Set every slot in a group to one destination: ONE command (1.20.0).
*
* The claim that used to stand here -- "the server has no group verb because a
* group is not a thing it stores" -- was disproved two lines below it, by the
* `items` branch, which used the group verb. `!dwq bagpref <who> <category>
* <dest>` has always taken a CATEGORY NAME: squad_storage.lua's classesFrom
* matches a category before it tries a slot, and the six category names it
* knows -- weapons, offhand, armour, trinkets, jewellery, items -- are
* byte-identical to BAG_GROUPS' own names above, with the same slot sets.
*
* WHAT THE OLD SHAPE COST. Armour was five chat lines at 1.2 seconds apiece:
* six seconds of queue, six seconds of the Storage tab reading `Mixed` (see
* the bagpref envelope note in the record handler), and -- worse -- a genuinely
* half-applied group if the drain was interrupted by a zone line, at which
* point `Mixed` stopped being a lie and became the truth, indistinguishable
* from the lie.
*
* THE RENDERING SIDE STAYS CLIENT-SIDE, and that is not an inconsistency: the
* header's reason for defining groups here is that a LAYOUT may cut across
* them, which is a fact about reading seventeen p| rows back. Only the WRITE
* moves to the server's word, and a group name the server does not know is
* refused with a sentence rather than silently mis-applied.
--]]
local function setGroup(name, group, destName)
    issue(string.format('!dwq bagpref %s %s %s', name, group.name, destName));

    requested['bagpref'] = nil;
end

local function prefsTab()
    local name = selectedName();

    if (name == nil) then
        imgui.Text('Pick a character.');

        return;
    end

    if (prefsUnsupported) then
        imgui.TextColored(theme.colors.err, 'This server does not have bag routing yet.');
        imgui.TextDisabled('Everything else in this window still works.');

        return;
    end

    need('bagpref', state.selected);

    imgui.TextDisabled('Where an item lands in ' .. name .. '\'s bags when you send it, or when they collect a');
    imgui.TextDisabled('delivery. Gear defaults into the wardrobes -- they hold nothing else, so it keeps');
    imgui.TextDisabled('the four bags they actually carry free for everything else.');

    imgui.Separator();

    -- The layout row: seventeen slots in one command.
    --
    -- NONE OF THESE IS DISABLED WHEN IT IS THE CURRENT ONE. Re-applying the
    -- layout you are already on is the fastest way back from a hand-edit, and
    -- disabling the button would hide the one control that does it. Which one
    -- is current is said in words on the line below instead, where it cannot be
    -- mistaken for a disabled control.
    imgui.Text('Layout:');

    for _, layout in ipairs(BAG_LAYOUTS) do
        imgui.SameLine();

        if (imgui.SmallButton(layout.button)) then
            issue(string.format('!dwq bagpref %s layout %s', name, layout.name));

            requested['bagpref'] = nil;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(layout.blurb);
        end
    end

    local current = nil;

    for _, layout in ipairs(BAG_LAYOUTS) do
        if (state.layout == layout.id) then
            current = layout;
        end
    end

    if (current ~= nil) then
        imgui.TextColored(theme.colors.ok, string.format('Currently: %s -- %s', current.label, current.blurb));
    else
        imgui.TextDisabled('Currently: a layout of your own. Any button above replaces it.');
    end

    -- The table stops short of the footer, and by the footer's OWN height
    -- (2026-09-06). `-80` was a guess that survives one font size: the
    -- footer is a separator, a button and a line of text, so ask ImGui what
    -- a framed row costs and leave three of them. At the window's smallest
    -- allowed height this is the difference between a reachable "Tidy bags
    -- now" and a button under the bottom edge.
    local prefsFooter = imgui.GetFrameHeightWithSpacing() * 3;

    if (imgui.BeginTable('##dwbags_prefs', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -prefsFooter })) then
        imgui.TableSetupColumn('Group', ImGuiTableColumnFlags_WidthFixed, 140, 0);
        imgui.TableSetupColumn('Goes to', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('Free', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, group in ipairs(BAG_GROUPS) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(group.label);

            local dest = groupDestination(group);

            imgui.TableNextColumn();
            imgui.PushItemWidth(180);

            local shown = dest ~= nil and destinationLabel(dest.loc) or 'Mixed';

            if (imgui.BeginCombo(group.combo, shown)) then
                for _, option in ipairs(BAG_DESTINATIONS) do
                    -- A wardrobe holds nothing but equipment, so it is not
                    -- offered for the group that is not equipment. The server
                    -- refuses it too; this only keeps it off the list.
                    if (not (group.other and isWardrobeLoc(option.loc))) then
                        if (imgui.Selectable(option.label, dest ~= nil and dest.loc == option.loc)) then
                            setGroup(name, group, option.name);
                        end
                    end
                end

                if (imgui.Selectable('Default', dest ~= nil and dest.isdefault)) then
                    setGroup(name, group, 'auto');
                end

                imgui.EndCombo();
            end

            imgui.PopItemWidth();

            if (dest == nil) then
                -- Split across containers: name the slots, because that is the
                -- only honest rendering and it is also how you fix it.
                --
                -- Assembled INSIDE the hover test (1.25). It was built for
                -- every mixed group on every frame -- five string.formats
                -- and a table.concat apiece -- to produce a sentence only
                -- ever read for the one group under the mouse.
                if (imgui.IsItemHovered()) then
                    local parts = T{ };

                    for _, slot in ipairs(group.slots) do
                        local row = state.prefs[classOfSlot(slot)];

                        if (row ~= nil) then
                            parts:append(string.format('%s %s', SLOT_NAMES[slot], destinationLabel(row.loc)));
                        end
                    end

                    imgui.SetTooltip('Split across bags:\n' .. table.concat(parts, '\n')
                        .. '\nChoosing one here puts the whole group in it.');
                end
            elseif (not dest.isdefault) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.pin, '*');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Changed from the default.');
                end
            end

            imgui.TableNextColumn();

            if (dest ~= nil) then
                imgui.Text(tostring(dest.free));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Free cells there right now. Full is not a problem -- an item that\n'
                        .. 'does not fit falls through to the spare wardrobes, then to the\n'
                        .. 'ordinary bags, and only then to the delivery box.');
                end
            else
                imgui.TextDisabled('-');
            end
        end

        imgui.EndTable();
    end

    imgui.Separator();

    -- Tidy. Its own row at the bottom, because it is the one control here that
    -- moves items rather than recording a preference.
    if (isSelf(state.selected)) then
        imgui.TextDisabled('Sort this character\'s own bags in the game\'s own menu -- this only sorts alts.');
    else
        if (imgui.Button('Tidy bags now')) then
            issue(string.format('!dwq tidy %s', name));

            refetchVisible();
            requested['bagpref'] = nil;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Re-file everything %s is already holding to match the layout above.\n'
                .. 'Sorts the wardrobes, inventory, satchel, sack and case; leaves the mog\n'
                .. 'safe, locker and storage alone. Never moves what they are wearing.\n'
                .. 'They must not be logged in.', name));
        end

        imgui.SameLine();
        imgui.TextDisabled('Applies the layout to what they already have.');
    end
end

local function boxTab()
    if (state.selected ~= nil) then
        need('box', state.selected);
    end

    -- A send lands in the alt's bags outright now, so this tab is the exception
    -- shelf rather than the route: it holds what could not be written straight
    -- in -- a character who was logged in, a character whose bags were full --
    -- along with real deliveries and auction house payouts. All of it is
    -- collected the next time that character is called.
    imgui.TextDisabled('Waiting to be collected. Sends normally land in the bag at once; these could not,');
    imgui.TextDisabled('so they arrive the next time you call that character.');

    if (#state.box == 0) then
        -- "Nothing waiting" IS AN ANSWER and must not be given before one
        -- has arrived (2026-09-06) -- the warehouse face's rule, which this
        -- tab needed for the same reason: an empty section is also what a
        -- tab looks like for the second the throttled ask takes.
        local asked = requested['box'];

        if (state.selected ~= nil
                and (asked == nil or asked.charid ~= state.selected or not asked.answered)) then
            imgui.TextDisabled('Reading the delivery box...');
        else
            imgui.Text('Nothing waiting.');
        end

        return;
    end

    local member = state.selected ~= nil and state.chars[state.selected] or nil;

    imgui.TextColored(theme.colors.info, string.format('%d item%s waiting for %s.',
        #state.box, #state.box == 1 and '' or 's',
        member ~= nil and member.name or 'this character'));

    if (imgui.BeginTable('##dwbags_box', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 40, 0);
        imgui.TableSetupColumn('For', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('From', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(state.box) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(itemName(row.itemid));
            cardOnHover(row.itemid, hovered);

            imgui.TableNextColumn();
            imgui.Text(row.qtytext or '');

            imgui.TableNextColumn();
            imgui.Text(state.chars[row.charid] ~= nil and state.chars[row.charid].name or '?');

            imgui.TableNextColumn();
            imgui.Text(row.sender or '');
        end

        imgui.EndTable();
    end
end

local function renderWindow()
    -- The roster's retry, once a frame, the way every tab drives its own
    -- need(). Without a caller the answer clock in needWho would have nothing
    -- to fire it -- refreshChars is called from events, not from a loop -- and
    -- a tracked read nobody re-asks is the same frozen panel as an untracked
    -- one, only with more code.
    needWho();

    if (imgui.Button('Refresh')) then
        -- refetchVisible, not refreshChars + forget (1.20.0). `forget()` only
        -- clears the answer clock for the reads a tab re-asks through need(),
        -- and the FIND tab has no need() of its own -- a find is not keyed by
        -- character, which is why it was written that way. So the one button
        -- whose entire job is "make this current" updated the left pane and
        -- left the find rows exactly as they were, with nothing on screen to
        -- distinguish a fresh result from a ten-minute-old one. That is also
        -- the likeliest place the stale `worn` tag was seen.
        --
        -- refetchVisible is forget() plus the deferred find-then-who flush,
        -- in the order pumpRefetch already argues for.
        refetchVisible();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.refresh);
    end

    imgui.SameLine();

    -- A throttled queue has to look like progress rather than like nothing
    -- happening, which is exactly how the unthrottled version failed.
    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.queued);
        end
    else
        imgui.TextDisabled('');
    end

    -- THE MESSAGE LINE GETS ITS OWN ROW, AND ERRORS ARE RED.
    --
    -- Every refusal is a rule with a reason -- Rare/Ex, worn, logged in, bag
    -- full -- and that reason is the only thing telling a player what to do
    -- instead. It used to share a line with the queue counter, in the same grey
    -- as everything else, which in a busy chat log made it read as decoration.
    -- It is now hard to miss and persists until something replaces it.
    --
    -- AND IT WRAPS (2026-09-06). The server trims a refusal to 130 bytes,
    -- which is a good deal wider than this window's default, and the window
    -- passes NoScrollbar -- so the tail of the longest and most useful
    -- sentences ran off the right edge with no way to reach it. Wrapped at
    -- the content edge rather than at a pixel count, so a player who has
    -- widened the window gets the whole line back on one row.
    if (state.status ~= nil and state.status ~= '') then
        imgui.PushTextWrapPos(0.0);

        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end

        imgui.PopTextWrapPos();

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.status);
        end
    end

    -- The transfer controls live here rather than in a tab, because they apply
    -- to every tab that has a Send or Fetch button on it and the owner hit the
    -- gap immediately: the Find tab had rows to move and no way to say how many.
    imgui.Text('Send to:');
    imgui.SameLine();
    imgui.PushItemWidth(140);

    local targetName = (state.sendTo ~= nil and state.chars[state.sendTo] ~= nil)
        and state.chars[state.sendTo].name or '(pick one)';

    if (imgui.BeginCombo('##dwbags_target', targetName)) then
        for _, member in ipairs(orderedChars()) do
            if (bit.band(member.flags, CHAR_SELF) == 0) then
                if (imgui.Selectable(member.name, state.sendTo == member.charid)) then
                    state.sendTo = member.charid;
                end

                -- WHERE A SEND TO THIS ONE ACTUALLY LANDS (2026-09-06), at
                -- the moment of choosing rather than after the transfer.
                -- The bag row's Send says "Send 7 to Alta" whichever of the
                -- three states Alta is in, and the difference between them
                -- -- straight into the bag, or into the delivery box until
                -- the next time you call her -- is the whole question.
                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(sendLandsText(member));
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.sendTo);
    end

    imgui.SameLine();
    imgui.Checkbox('Whole stack', state.sendAll);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.wholeStack);
    end

    if (not state.sendAll[1]) then
        imgui.SameLine();
        imgui.PushItemWidth(90);
        imgui.InputInt('##dwbags_qty', state.sendQty, 1, 10);
        imgui.PopItemWidth();

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.sendQty);
        end

        -- ImGui's InputInt has no lower bound of its own -- the minus button and
        -- the keyboard will both take it below zero and leave it there -- so the
        -- bound is applied to the buffer every frame. Done here rather than only
        -- inside moveCount so the player never sees a number the window would
        -- not act on.
        if ((tonumber(state.sendQty[1]) or 1) < 1) then
            state.sendQty[1] = 1;
        end
    end

    imgui.Separator();

    charList();

    imgui.SameLine();

    imgui.BeginChild('##dwbags_right', { 0, 0 }, ImGuiChildFlags_None);

    --[[
        THE TABS EXPLAIN THEMSELVES ON HOVER (2026-09-06).

        Five one-word labels, two of which ("In transit", "Storage") name
        things nothing else in the game does -- and a player has to open a
        tab to find out what it is for, which for the Storage tab means
        opening the one that writes preferences.

        The hover test sits between BeginTabItem and the body, not inside
        the `if`: ImGui submits the tab as an item inside BeginTabItem, so
        IsItemHovered reads the TAB there whether it opened or not, and the
        first widget the body draws would take the "last item" away.
    --]]
    if (imgui.BeginTabBar('##dwbags_tabs')) then
        local onBags = imgui.BeginTabItem('Bags');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabBags);
        end

        if (onBags) then
            bagsTab();
            imgui.EndTabItem();
        end

        local onGear = imgui.BeginTabItem('Gear');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabGear);
        end

        if (onGear) then
            gearTab();
            imgui.EndTabItem();
        end

        local onFind = imgui.BeginTabItem('Find');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabFind);
        end

        if (onFind) then
            findTab();
            imgui.EndTabItem();
        end

        local onBox = imgui.BeginTabItem('In transit');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabBox);
        end

        if (onBox) then
            boxTab();
            imgui.EndTabItem();
        end

        local onStorage = imgui.BeginTabItem('Storage');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.tabStorage);
        end

        if (onStorage) then
            prefsTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    imgui.EndChild();

    --[[
        The trash confirmation (1.22) -- dwwarehouse's window, ported with its
        rules (edit one, revisit the other). OPENED EVERY FRAME THE QUESTION IS
        PENDING: ImGui closes a popup on any outside click, and silently
        dropping the question would leave the player unsure whether the item is
        gone. While `trashAsk` is set the popup re-opens, so the only ways out
        are the two buttons. Opened HERE, at window level after the tab bar,
        because Trash buttons live on the Bags AND Find tabs -- a popup owned
        by one tab would never open for the other -- and because BeginTable
        pushes an ID scope a popup cannot straddle.
    ]]
    if (state.trashAsk ~= nil) then
        imgui.OpenPopup('##dwbags_confirm_trash');
    end

    if (imgui.BeginPopup('##dwbags_confirm_trash')) then
        local ask = state.trashAsk;

        if (ask == nil) then
            imgui.CloseCurrentPopup();
        else
            drawIcon(ask.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(string.format('Throw away %s x%d from %s\'s bag?', itemName(ask.itemid), ask.qty, ask.charname));

            -- The card is the last look at what is about to be deleted --
            -- exactly where it earns itself, augment values included.
            cardOnHover(ask.itemid, hovered, ask.augArg);

            -- The tags are the last chance to notice this is the irreplaceable
            -- copy. Red, because 'rare' next to a delete button is a warning,
            -- not a fact. Rare/Ex come from the client's own DATs; augmented
            -- from the row's server flag.
            local datFlags = datFlagsOf(ask.itemid);
            local tags     = T{ };

            if (bit.band(datFlags, FLAG_RARE) ~= 0) then tags:append('rare'); end
            if (bit.band(datFlags, FLAG_EX) ~= 0) then tags:append('ex'); end
            if (bit.band(ask.flags or 0, ITEM_AUGMENTED) ~= 0) then tags:append('augmented'); end

            if (#tags > 0) then
                imgui.TextColored(theme.colors.err,
                    string.format('This item is %s. It may be hard or impossible to replace.',
                        table.concat(tags, ', ')));
            end

            imgui.TextDisabled('It is destroyed for good. Nothing can bring it back.');

            if (imgui.Button('Throw away##dwbags_trash_yes')) then
                issue(string.format('!dwq trash %s %d %d %d %d', ask.charname, ask.loc, ask.slot, ask.itemid, ask.qty));

                state.trashAsk = nil;
                imgui.CloseCurrentPopup();
                refetchVisible();
            end

            imgui.SameLine();

            if (imgui.Button('Cancel##dwbags_trash_no')) then
                state.trashAsk = nil;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end

    --[[
        The bulk stash confirmation (1.28) -- the trash window's rules, and
        it is here beside it for the same two: a popup opened inside a tab
        would never open for anything else, and BeginTable pushes an ID
        scope a popup cannot straddle. Re-opened every frame the question is
        pending, so the only ways out are its own buttons.

        EVERY NUMBER IN IT CAME FROM THE SERVER'S DRY RUN. This side never
        counts the rows itself: the count is what the server's own
        eligibility screen accepted, and the verdict is the server's own
        comparison against the free slots. A confirmation that named a count
        this window worked out would be asking the player to agree to
        something else.

        A SWEEP THAT DOES NOT FIT IS NEVER OFFERED A BUTTON. The server would
        refuse it and move nothing -- that is the whole promise -- so the
        window says how many slots short it is and closes. Offering "Send
        them" for an answer already known to be no is a click that exists
        only to produce a red sentence.
    ]]
    if (state.stashAllAsk ~= nil) then
        imgui.OpenPopup('##dwbags_confirm_stashall');
    end

    if (imgui.BeginPopup('##dwbags_confirm_stashall')) then
        local ask = state.stashAllAsk;

        if (ask == nil) then
            imgui.CloseCurrentPopup();
        else
            local bagName = LOC_NAMES[ask.loc] or tostring(ask.loc);
            local whose   = string.format('%s\'s %s', ask.charname or 'that character', bagName);

            if (ask.count <= 0) then
                imgui.Text(string.format('Nothing in %s can be stored.', whose));
            elseif (not ask.fits) then
                imgui.Text(string.format('Send %d item%s from %s to the warehouse?',
                    ask.count, ask.count == 1 and '' or 's', whose));
                imgui.TextColored(theme.colors.err,
                    string.format('There is not room: %d slot%s needed, %d free.',
                        ask.needed, ask.needed == 1 and '' or 's', ask.free));
                imgui.TextDisabled('Nothing will be moved. Take something out of the');
                imgui.TextDisabled('warehouse, or stash a smaller bag.');
            else
                imgui.Text(string.format('Send %d item%s from %s to the warehouse?',
                    ask.count, ask.count == 1 and '' or 's', whose));
                imgui.TextDisabled(string.format('%d of %d free slots would be used.', ask.needed, ask.free));
            end

            if (ask.skipped > 0) then
                imgui.TextDisabled(string.format('%d item%s stay%s where %s are:',
                    ask.skipped, ask.skipped == 1 and '' or 's',
                    ask.skipped == 1 and 's' or '', ask.skipped == 1 and 'it' or 'they'));
                imgui.TextDisabled('  worn, priced, placed in a Mog House or in use');
                imgui.TextDisabled('  gil, and linkshell pearls');
            end

            -- `charname` is read off the roster, which is a separate answer:
            -- no name, no command, because every line this window types
            -- names a character and `%s` on a nil raises inside the render
            -- pcall -- one frame lost and the window closed.
            if (ask.fits and ask.count > 0 and ask.charname ~= nil) then
                if (imgui.Button('Send them##dwbags_stashall_yes')) then
                    issue(string.format('!dwq stashall %s %d', ask.charname, ask.loc));

                    state.stashAllAsk = nil;
                    imgui.CloseCurrentPopup();
                    refetchVisible();
                end

                imgui.SameLine();
            end

            if (imgui.Button('Cancel##dwbags_stashall_no')) then
                state.stashAllAsk = nil;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end

    --[[
        The batch confirmation (1.30) -- one question for a whole press, trash
        or sale, one row or forty. Here beside its two siblings for their two
        reasons: a popup owned by a tab cannot open for another one, and
        BeginTable pushes an ID scope a popup cannot straddle. Re-opened every
        frame the question is pending, so the only ways out are its buttons.

        THE SINGLE-ROW TRASH BUTTON AND ITS OWN POPUP ARE UNTOUCHED. This one
        is additive: a Trash click still fills `trashAsk` and is still answered
        by the popup above, word for word. Merging the two would have meant
        rewriting the one confirmation in this window that players already
        know by sight.

        EVERY NUMBER IN IT IS COUNTED FROM THE LIVE ROWS THE COMMAND WILL NAME
        (askBatch), and the gil is the SERVER's price times what is in the
        cell. Nothing here is a number this file decided.
    ]]
    if (state.batchAsk ~= nil) then
        imgui.OpenPopup('##dwbags_confirm_batch');
    end

    if (imgui.BeginPopup('##dwbags_confirm_batch')) then
        local ask = state.batchAsk;

        if (ask == nil) then
            imgui.CloseCurrentPopup();
        else
            local whose = ask.charname ~= nil
                and string.format('%s\'s bags', ask.charname)
                or 'your bags';

            if (ask.sale) then
                imgui.Text(string.format('Sell %d row%s from %s for %s gil?',
                    #ask.cells, #ask.cells == 1 and '' or 's', whose, commaGil(ask.gil)));
                imgui.TextDisabled(string.format('%d item%s in all, at the price the shops pay.',
                    ask.items, ask.items == 1 and '' or 's'));
            else
                imgui.Text(string.format('Throw away %d row%s from %s?',
                    #ask.cells, #ask.cells == 1 and '' or 's', whose));
                imgui.TextDisabled(string.format('%d item%s in all.',
                    ask.items, ask.items == 1 and '' or 's'));
            end

            -- What the press will NOT touch, and why -- said before the click
            -- rather than discovered in the chat log afterwards. Only a sale
            -- skips anything: a trash sends every ticked row and lets the
            -- server refuse the ones it will not destroy, per row, in words.
            if (ask.skipped > 0) then
                imgui.TextDisabled(string.format('%d ticked row%s skipped: no merchant buys %s,',
                    ask.skipped, ask.skipped == 1 and ' is' or 's are',
                    ask.skipped == 1 and 'it' or 'them'));
                imgui.TextDisabled('  or it is worn, priced, placed, or in an alt\'s bags.');
            end

            -- The last chance to notice this is the irreplaceable copy. Red,
            -- because "rare" beside a destroy button is a warning and not a
            -- fact -- the single-row popup's rule, counted over a set.
            local tags = T{ };

            if (ask.rare > 0) then tags:append(string.format('%d rare', ask.rare)); end
            if (ask.exclusive > 0) then tags:append(string.format('%d exclusive', ask.exclusive)); end
            if (ask.augmented > 0) then tags:append(string.format('%d augmented', ask.augmented)); end

            if (#tags > 0) then
                imgui.TextColored(theme.colors.err,
                    string.format('This includes %s. They may be hard or impossible to replace.',
                        table.concat(tags, ', ')));
            end

            if (ask.sale) then
                imgui.TextDisabled('No merchant will sell them back at this price.');
            else
                imgui.TextDisabled('They are destroyed for good. Nothing can bring them back.');
            end

            -- The server answers for every row separately, so the one thing
            -- this question must promise is that a refusal is never silence.
            imgui.TextDisabled('Every row is answered in the chat log, refused ones included.');

            -- `charname` is read off the roster, which is a separate answer: no
            -- name, no command, because a trash line names a character and
            -- `%s` on a nil raises inside the render pcall. A SALE needs no
            -- name at all -- it is always the caller's own bags -- so it is
            -- offered either way.
            if (ask.sale or ask.charname ~= nil) then
                local label = ask.sale and 'Sell them##dwbags_batch_sell_yes'
                    or 'Throw them away##dwbags_batch_trash_yes';

                if (imgui.Button(label)) then
                    issueBatch(ask.sale, ask.charname, ask.cells);

                    state.batchAsk = nil;
                    imgui.CloseCurrentPopup();
                end

                imgui.SameLine();
            end

            if (imgui.Button('Cancel##dwbags_batch_no')) then
                state.batchAsk = nil;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather than
* the addon.
*
* An error thrown inside a d3d_present handler is raised on EVERY frame -- sixty
* times a second -- and the addon host answers a long enough run of them by
* unloading the addon. The failure mode is therefore "the console fills with the
* same line and the window disappears", which tells a player nothing and loses
* the one copy of the message worth reading.
*
* So: Begin and End stay outside the pcall, which is what keeps ImGui's window
* stack balanced whatever happens in between; the error is reported once; and
* the window closes itself. Everything the window does is still reachable as
* !squad commands, so closing it is a real fallback rather than a dead end.
--]]
ashita.events.register('d3d_present', 'dwbags_present', function ()
    -- The icon cache's ceiling, taken here and nowhere else: last frame's draw
    -- list has already been rendered and this frame has not asked for a
    -- texture yet, which is the only moment a texture is safe to release
    -- (see the note above `local icons`).
    if ((icons.n or 0) >= 1024) then
        icons       = T{ };
        iconHandles = { };

        collectgarbage('collect');
    end

    -- Before the visibility check: a Send issued a moment before the window was
    -- closed still has to reach the server -- and a refetch armed by a click
    -- that then closed the window still has to flush its who/find.
    pumpQueue();
    pumpRefetch();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    --[[
        980, NOT THE OLD 860, AND THIS ONE IS ARITHMETIC (2026-09-06).

        860 was chosen when the action column grew a Send button (1.11) and
        was never re-checked when it grew Stash and Trash (1.22). The Find
        tab is the widest thing here: 40 for the count, 110 for the owner,
        90 for the container and 265 for five side-by-side buttons is 505
        pixels of FIXED column before a single character of the item name --
        and an 860-wide window leaves the right-hand pane about 616 usable
        after the 190-pixel character list, the window padding, the child
        padding and the scrollbar. The name column was set to 230, the sum
        overflowed by more than a hundred pixels, and a table without
        ScrollX does not scroll: it clips. What it clipped was the right-
        hand end of the action column, which is where Trash and Stash are.

        980 leaves the name column about 230 pixels at the default size, and
        the name columns now STRETCH (see the tables), so the name is what
        gives when a player makes the window smaller rather than the buttons
        being pushed out of reach.

        FirstUseEver means a player who has already sized the window keeps
        their size; this is only the fresh install's opening shape.
    --]]
    imgui.SetNextWindowSize({ 980, 520 }, ImGuiCond_FirstUseEver);

    --[[
        AND A FLOOR UNDER IT (2026-09-06).
        FirstUseEver only sets the OPENING size; nothing stopped a player
        dragging the corner past the point where the window still works, and
        imgui.ini then remembers that size across every reload. This window
        has more fixed furniture than any other in the suite -- a 190-pixel
        character list, a five-tab bar, a header row of transfer controls and
        a per-row action column 265 wide -- so below roughly this size the
        tab bar starts collapsing tabs into a scroll arrow and the action
        buttons leave the visible area with no scrollbar to reach them
        (NoScrollbar, above). 820 is the width at which the Find tab's 505
        pixels of fixed column still fit with a name column left over; the
        maximum is left effectively unbounded.
    --]]
    imgui.SetNextWindowSizeConstraints({ 820, 400 }, { 99999, 99999 });

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Bags##dwbags', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwbags'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwbags'):append(chat.message('Window closed. Everything it does also works as !squad commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Watch what the player sends, so the window keeps up with commands typed
* outside it.
*
* `!squad call` collects everything waiting in the delivery box, which empties
* the In transit tab -- and the window had no way of knowing, so it went on
* showing items that had already arrived. The same goes for a dismiss, or a send
* or fetch typed by hand. Matching our own outgoing chat is exact and costs
* nothing: 0x00B5 is Kind at 0x04, a pad byte, then the message at 0x06.
*
* Only `!squad` is matched for invalidation, not `!dwq`: the addon's own
* commands already know what they invalidated.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE, though. The
* client's rate limit is on chat, not on this addon, so a query fired in the
* same frame as something the player typed is the one that gets dropped -- and
* the invalidation above is precisely what fires a query in that frame. Stamping
* the player's own line as a send makes the follow-up wait its interval instead
* of racing it.
--]]
ashita.events.register('packet_out', 'dwbags_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dwq') then
        lastSend = os.clock();
    end

    if (message:lower():sub(1, 6) == '!squad') then
        forget();

        if (state.findQuery ~= nil and state.findQuery ~= '') then
            issue(string.format('!dwq find %s', state.findQuery), true);
        end
    end
end);

ashita.events.register('command', 'dwbags_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Bags`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwbags' and first ~= '/bags') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        refreshChars();
        forget();

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported` only
        -- exists to stop one bad frame printing sixty lines a second, not to
        -- silence a different error a week later in the same session.
        state.reported = false;

        -- And the banner says what is actually happening (2026-09-06). The
        -- window asks for the roster on this very line, so opening it with
        -- "Press Refresh." on the status bar was an instruction to press a
        -- button that had already been pressed. afterCommit retires it when
        -- the roster lands.
        if (state.status == '' or state.status == 'Press Refresh.') then
            state.status    = 'Loading...';
            state.statusBad = false;
        end

        refreshChars();
        forget();
    end
end);

ashita.events.register('load', 'dwbags_load', function ()
    print(chat.header('dwbags'):append(chat.message('/dwbags opens the account bag browser. Everything it does also works typed as !squad.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new account view.
ashita.events.register('packet_in', 'dwbags_zonein', function (e)
    if (e.id == 0x000A) then
        state.chars    = T{ };
        state.selected = nil;
        state.bags     = T{ };
        state.gear     = T{ };
        state.options  = T{ };
        -- `refused` with the rest (2026-09-06): it is per character and per
        -- slot like `options`, and it was the one section a login left
        -- standing -- so the Manual picker's "owned, but cannot be worn"
        -- list survived a relog onto a different character.
        state.refused  = T{ };
        state.hints    = T{ };
        state.restock  = T{ };
        state.box      = T{ };
        state.finds    = T{ };
        state.prefs    = T{ };
        state.layout   = 255;
        state.autoName  = T{ };
        state.autoNames = T{ };
        state.autoPick  = nil;
        state.sendTo   = nil;
        state.findQuery = '';
        state.findAnswered = '';
        state.statusBad = false;
        state.bagLoc    = nil;
        state.bagFind[1] = '';
        -- `bagCat` is NOT cleared here, with `bagSort`, and for the same
        -- reason: a container and a name are questions about the character
        -- that just logged out, while an order and a kind are how this player
        -- reads a bag. The category goes further and survives the client --
        -- clearing it here would quietly undo the settings file every login.
        arriving        = nil;

        -- A login empties every section without a `z|` to say so, so the
        -- views cached against the model have to be told (1.25).
        bumpModel();

        -- An open window re-fetches on its own, the way dwsquad and dwjobs
        -- do in this same handler; a closed one waits for the open transition
        -- (which calls refreshChars) rather than spending a chat line nobody
        -- is looking at.
        if (state.open[1]) then
            state.status = 'Loading...';

            refreshChars();
            forget();
        else
            state.status = 'Press Refresh.';
        end

        -- Asked again on the other side: the server may have grown the hints
        -- verb since the last look (a map restart logs everyone out).
        hintsUnsupported   = false;
        prefsUnsupported   = false;
        stackUnsupported   = false;
        restockUnsupported = false;
        trashUnsupported   = false;
        stashUnsupported   = false;
        stashAllUnsupported = false;
        puppetUnsupported   = false;
        autonameUnsupported = false;
        trashManyUnsupported = false;
        vendorUnsupported    = false;
        state.trashAsk     = nil;

        -- 1.30. THE TICKS AND THE PENDING BATCH GO; THE PRICES STAY. A tick
        -- names a cell of a character that has just logged out and a pending
        -- question is about rows nobody is looking at any more -- but the
        -- price list is the GAME's, not this account's: the same item is worth
        -- the same gil to the same merchants on the next character, so
        -- clearing it would only buy a screenful of "--" until the next bag
        -- read repeated a fact that had not changed. `sellFilter` stays with
        -- it, and with `bagSort`, for the reason given there: an order and a
        -- kind are how this player reads a list.
        state.picked    = T{ };
        state.pickedFor = nil;
        state.batchAsk  = nil;
        batchTally      = nil;
        -- Both halves of the bulk stash: the pending question is about a
        -- character that has just logged out, and the container pick is an id
        -- on a roster that is about to be re-read.
        state.stashAllAsk  = nil;
        state.stashAllBag  = nil;
    end
end);
