--[[
* DriftwoodXI -- dwjobs
*
* The party's jobs in a window: the character you are playing and every
* squad slot beside it, each with a main and support job dropdown -- change
* the whole lineup and click Apply once, or save it as a preset and bring it
* back in one click. Members out as trusts are dismissed and re-called on
* the new jobs by the server; members at home just change.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no roster of its own, caches nothing to disk, and has no way to
* change a job the typed command surface could not. Every read is `!dwj who`
* and every write is `!dwj apply|save|use|delete`, which reach exactly the
* same server dispatch `!jobs` reaches -- the only difference is that they
* answer in compact records under the sender name _DWJDATA, which this addon
* parses and blocks before the chat log sees them. Ownership and job unlocks
* are re-checked in the server's C++ and run identically whichever way the
* command arrived; a job a character has not unlocked is not even offered,
* but the server would refuse it regardless.
*
* TYPING `!jobs` ON ITS OWN OPENS THIS WINDOW. The line is intercepted
* before it leaves the client, so the server never sees it; every other
* !jobs command passes through untouched. With the addon off, `!jobs`
* prints everyone's jobs exactly as before.
*
* TURN IT OFF AND NOTHING IS LOST. `!jobs set <char> <main> [sub]`,
* `!jobs save|use|list|delete <name>` all work typed. This is friendlier;
* it is not required.
--]]

addon.name    = 'dwjobs';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.0';
addon.desc    = 'Party job window for DriftwoodXI -- change everyone\'s main and sub jobs by clicking.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. dwbags
-- owns _DWDATA, dwgambits owns _DWGDATA, dwsquad owns _DWSDATA; this addon
-- must never contend for any of them, which is why !dwj exists at all.
local DATA_SENDER = '_DWJDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

local MAX_SLOTS = 5;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

local JOB_COUNT = 22;

-- Character flag bits, as the server packs them.
local CHAR_ONLINE = 1;
local CHAR_LOCKED = 2;
local CHAR_SELF   = 4;

-- The longest a preset name may be, matching the server's cap.
local PRESET_NAME_MAX = 24;

local state = T{
    open      = T{ false },

    -- Replaced wholesale by a `who` response, never merged, so a stale row
    -- cannot survive a refresh.
    chars     = T{ },

    -- { name, members } in server order. Replaced when a response that
    -- carries `p|` records opens (`who` and `list` both do).
    presets   = T{ },

    -- charid -> { mjob, sjob }: what the player has clicked but not yet
    -- applied. A PLAIN TABLE keyed by charid, not `T{ }` -- unknown keys on a
    -- T{} resolve through its metatable to the sugar methods, which is the
    -- dwbags round-7 bug, paid for once already.
    staged    = { },

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its own
    -- cannot half-fill the UI.
    inbound   = nil,

    -- Preset delete asks twice; this is whose first click is pending.
    pendingDelete = nil,

    -- The Save box's buffer. ImGui writes into index 1.
    saveName  = T{ '' },

    status    = 'Loading...',
    statusBad = false,
    reported  = false,     -- a render error is worth saying once, not per frame
};

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A
* TIME. The client rate-limits outgoing chat, and a !dwj command is a chat
* line; anything over the limit is answered with "A command error occurred"
* before the server ever sees it. So everything queues here and drains at one
* command per SEND_INTERVAL, and duplicates collapse.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a window drawn sixty times a second asks
* once. The answer is tracked, not just the question: one lost command must
* not leave the panel stale for ever, and a retry that never terminates is a
* command loop, which is worse than a stale panel. Same shape as dwsquad's.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

local function refresh()
    requested = {};
end

-- A write's response carries the fresh roster, so the roster question is
-- registered as pending without being asked: if the write's answer is lost,
-- needRoster's retry covers it.
local function expectRoster()
    requested['who'] = { at = os.clock(), answered = false, tries = 1 };
end

local function needRoster()
    local asked = requested['who'];

    if (asked ~= nil) then
        if (asked.answered or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        -- Out of retries and still nothing back. The retry stops here on
        -- purpose -- a command loop is worse than a stale panel -- but a panel
        -- that sits on 'Loading...' for ever without saying why is the worst
        -- available feedback, and the fix is one button away. Said ONCE:
        -- this runs sixty times a second.
        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp    = true;
                state.status    = 'No answer from the server. Press Refresh to ask again.';
                state.statusBad = true;
            end

            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['who'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dwj who');
end

--[[
* Record parsing. Every record is pipe-separated with a single-character
* type. Anything this addon does not recognise is ignored rather than being
* an error: a server newer than the addon must not break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

-- Staged entries that now say what the server says are finished business:
-- dropping them here is what clears the yellow highlights the moment an
-- Apply's response lands, with no bookkeeping anywhere else.
local function pruneStaged()
    for charid, pick in pairs(state.staged) do
        local member = state.chars[charid];

        if (member == nil) or (member.mjob == pick.mjob and member.sjob == pick.sjob) then
            state.staged[charid] = nil;
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwjobs.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright, and the reset runs
        -- FIRST: handleRecord is called under a pcall, and anything that
        -- throws after `state.inbound` is set must cost one record, not leave
        -- old rows for the records behind it to append to.
        if (state.inbound == 'who') then
            state.chars   = T{ };
            state.presets = T{ };

            local asked = requested['who'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'list') then
            state.presets = T{ };
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- message saying why a change was refused is worth more than the response
    -- it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- Everything after the first pipe, not parts[2]: these carry prose.
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        -- Errors also go to the chat log: the window may already be closed,
        -- and "nothing happened" is the worst possible feedback.
        if (kind == 'e') then
            print(chat.header('dwjobs'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        if (state.inbound == 'who') then
            pruneStaged();

            if (state.status == 'Loading...') then
                state.status = '';
            end
        end

        state.inbound = nil;

        return;
    end

    if (kind == 'c' and state.inbound == 'who') then
        local charid = tonumber(parts[2]) or 0;

        state.chars[charid] = T{
            charid   = charid,
            name     = parts[3],
            mjob     = tonumber(parts[4]) or 0,
            mlvl     = tonumber(parts[5]) or 0,
            sjob     = tonumber(parts[6]) or 0,
            slvl     = tonumber(parts[7]) or 0,
            flags    = tonumber(parts[8]) or 0,
            slot     = tonumber(parts[9]) or 0,
            unlocked = tonumber(parts[10]) or 0,

            -- Filled by the `j|` record that follows; zeroed here so a lost
            -- one renders as level 0 rather than a Lua error.
            levels   = {},
        };

        return;
    end

    if (kind == 'j' and state.inbound == 'who') then
        local charid = tonumber(parts[2]) or 0;
        local member = state.chars[charid];

        if (member == nil) then
            return;
        end

        local levels = {};
        local jobId  = 1;

        for level in string.gmatch(parts[3] or '', '([^,]*),?') do
            if (jobId > JOB_COUNT) then
                break;
            end

            levels[jobId] = tonumber(level) or 0;
            jobId = jobId + 1;
        end

        member.levels = levels;

        return;
    end

    if (kind == 'p' and (state.inbound == 'who' or state.inbound == 'list')) then
        state.presets:append(T{
            name    = parts[2],
            members = tonumber(parts[3]) or 0,
        });

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Layout after the 4-byte header: sName[15]
* at 0x08, Mes at 0x17. Any line whose sender is _DWJDATA is ours: it is
* consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwjobs_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwjobs'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Helpers over the roster.
--]]

local function isSelf(member)
    return bit.band(member.flags, CHAR_SELF) ~= 0;
end

local function selfMember()
    for _, member in pairs(state.chars) do
        if (isSelf(member)) then
            return member;
        end
    end

    return nil;
end

-- [slot] = member, from the flat character list.
--
-- THE CHARACTER BEING PLAYED IS LEFT OUT EVEN WHEN IT HOLDS A SLOT, and that
-- is reachable: `!squad set` refuses to register the character you are playing,
-- but nothing stops you registering an alt and then logging in AS that alt,
-- which the squad supports on purpose. Its row then answered both selfMember()
-- and this, so the window drew the same charid twice -- and both rows built
-- their dropdowns from `##dwjobs_m_<charid>`, which is ONE ImGui id used twice
-- in one window. That is the merged-click bug the id scheme exists to prevent,
-- and the panel says which slot it is in below instead.
local function slotView()
    local slots = T{ };

    for _, member in pairs(state.chars) do
        if (not isSelf(member) and member.slot >= 1 and member.slot <= MAX_SLOTS) then
            slots[member.slot] = member;
        end
    end

    return slots;
end

local function unlockedHas(member, jobId)
    return bit.band(member.unlocked, bit.lshift(1, jobId)) ~= 0;
end

local function levelOf(member, jobId)
    if (jobId == 0) then
        return 0;
    end

    return member.levels[jobId] or 0;
end

-- What this member's pair currently reads as in the window: the staged pick
-- if there is one, the server truth otherwise.
local function effective(member)
    local pick = state.staged[member.charid];

    if (pick ~= nil) then
        return pick.mjob, pick.sjob, true;
    end

    return member.mjob, member.sjob, false;
end

local function jobsLabel(member)
    local mjob, sjob = effective(member);
    local text = string.format('%s%d', JOB_NAMES[mjob] or '?', levelOf(member, mjob));

    if (sjob ~= 0) then
        text = text .. string.format('/%s%d', JOB_NAMES[sjob] or '?', levelOf(member, sjob));
    end

    return text;
end

-- The changes Apply would send: staged picks that still differ from the
-- server truth, as ready-made wire tokens.
local function stagedDiffs()
    local diffs = T{ };

    for charid, pick in pairs(state.staged) do
        local member = state.chars[charid];

        if (member ~= nil and (member.mjob ~= pick.mjob or member.sjob ~= pick.sjob)) then
            diffs:append(string.format('%d:%d:%d', charid, pick.mjob, pick.sjob));
        end
    end

    return diffs;
end

--[[
* Staging. A click never talks to the server: it edits the staged pair for
* that character, and only Apply turns the lot into one !dwj apply line.
--]]
local function stage(member, mjob, sjob)
    state.staged[member.charid] = { mjob = mjob, sjob = sjob };
end

local function stageMain(member, jobId)
    local _, sjob = effective(member);

    -- Picking your current support as the new main swaps the two, which is
    -- what that click means ("trade BLM/WHM for WHM/BLM") and is exactly what
    -- the retail Mog House menu does with the same input.
    if (jobId == sjob) then
        local mjob = effective(member);

        stage(member, jobId, mjob);
        return;
    end

    stage(member, jobId, sjob);
end

local function stageSub(member, jobId)
    local mjob = effective(member);

    stage(member, mjob, jobId);
end

--[[
* Writes. Every one is a server command a player could type, queued through
* the throttle, with the roster registered as an expected answer so a lost
* response is re-asked rather than trusted.
--]]
local function applyStaged()
    local diffs = stagedDiffs();

    if (#diffs == 0) then
        state.status    = 'Nothing to apply.';
        state.statusBad = false;
        return;
    end

    issue('!dwj apply ' .. table.concat(diffs, ' '));
    expectRoster();

    state.status    = 'Applying...';
    state.statusBad = false;
end

local function usePreset(name)
    -- Picks not yet applied are abandoned by choosing a preset: the preset is
    -- the new statement of intent, and stale yellow rows over its result
    -- would read as the preset having half-worked.
    state.staged = { };

    issue('!dwj use ' .. name);
    expectRoster();

    state.status    = string.format('Applying "%s"...', name);
    state.statusBad = false;
end

local function savePreset(name)
    issue('!dwj save ' .. name);
    expectRoster();

    state.status    = string.format('Saving "%s"...', name);
    state.statusBad = false;
end

local function deletePreset(name)
    issue('!dwj delete ' .. name);
    expectRoster();

    state.status    = string.format('Deleting "%s"...', name);
    state.statusBad = false;
end

--[[
* Rendering.
--]]

-- One job dropdown. `current` is what it shows; onPick(jobId) stages the
-- choice. The support flavour offers "(none)" and hides the main job; both
-- flavours offer only jobs the character has unlocked, because a locked job
-- is a content gate and the server would refuse it anyway. EVERY WIDGET ID
-- CARRIES THE CHARACTER ID: two Selectables with the same label in one
-- window would merge their click handling.
local function jobCombo(member, current, excluded, allowNone, tag, onPick)
    local label = current ~= 0
        and string.format('%s %d', JOB_NAMES[current] or '?', levelOf(member, current))
        or '(none)';

    imgui.PushItemWidth(92);

    if (imgui.BeginCombo(string.format('##dwjobs_%s_%d', tag, member.charid), label)) then
        if (allowNone) then
            if (imgui.Selectable(string.format('(none)##%s_%d_none', tag, member.charid), current == 0)) then
                onPick(0);
            end
        end

        for jobId = 1, JOB_COUNT do
            if (jobId ~= excluded and unlockedHas(member, jobId)) then
                if (imgui.Selectable(string.format('%s %d##%s_%d_%d',
                        JOB_NAMES[jobId], levelOf(member, jobId), tag, member.charid, jobId),
                        jobId == current)) then
                    onPick(jobId);
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
end

local function memberRow(rowLabel, member)
    local mjob, sjob, isStaged = effective(member);

    imgui.TableNextRow();
    imgui.TableNextColumn();
    imgui.Text(rowLabel);

    imgui.TableNextColumn();

    if (isStaged) then
        -- The theme's caution colour marks "picked but not applied", cleared
        -- the moment the apply's response confirms it.
        imgui.TextColored(theme.colors.warn, member.name);
    else
        imgui.Text(member.name);
    end

    imgui.TableNextColumn();
    -- The support dropdown never offers the main job, so the swap gesture --
    -- picking the current support AS the main -- lives on the main dropdown,
    -- where stageMain turns it into the BLM/WHM -> WHM/BLM trade it means.
    jobCombo(member, mjob, 0, false, 'm', function (jobId)
        stageMain(member, jobId);
    end);

    imgui.TableNextColumn();
    jobCombo(member, sjob, mjob, true, 's', function (jobId)
        stageSub(member, jobId);
    end);

    imgui.TableNextColumn();

    if (isStaged) then
        imgui.TextColored(theme.colors.warn, jobsLabel(member) .. ' *');
    else
        imgui.TextDisabled(jobsLabel(member));
    end
end

local function partyPanel()
    -- NOTE: the third argument is ImGuiChildFlags, not a bool -- Ashita ships
    -- ImGui 1.90+, and a bool here raises a Lua error on every frame.
    imgui.BeginChild('##dwjobs_party', { 0, 208 }, ImGuiChildFlags_Borders);

    imgui.Text('Your party');
    imgui.SameLine();
    imgui.TextDisabled('-- you and the five squad slots');
    imgui.Separator();

    if (imgui.BeginTable('##dwjobs_party_table', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        -- WidthFixed throughout, like the other Driftwood addons: only the
        -- flags they already use are proven to exist in this environment's
        -- ImGui bindings, and a nil flag global is a Lua error per frame.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 30, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 116, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 100, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 100, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 120, 0);

        local me = selfMember();

        if (me ~= nil) then
            memberRow('You', me);
        end

        local slots = slotView();

        for slot = 1, MAX_SLOTS do
            local member = slots[slot];

            if (member ~= nil) then
                memberRow(string.format('%d.', slot), member);
            else
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.TextDisabled(string.format('%d.', slot));
                imgui.TableNextColumn();

                if (me ~= nil and me.slot == slot) then
                    -- Registered here, and it is the character you are playing:
                    -- drawn once as "You" above rather than twice with the same
                    -- widget ids. Saying so beats an "(empty)" that is a lie.
                    imgui.TextDisabled('(you -- shown above)');
                else
                    imgui.TextDisabled('(empty -- /squad to register)');
                end

                imgui.TableNextColumn();
                imgui.TableNextColumn();
                imgui.TableNextColumn();
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

local function presetsPanel()
    imgui.BeginChild('##dwjobs_presets', { 0, 0 }, ImGuiChildFlags_Borders);

    imgui.Text('Presets');
    imgui.SameLine();
    imgui.TextDisabled('-- whole lineups, one click to bring back');
    imgui.Separator();

    if (#state.presets == 0) then
        imgui.TextDisabled('None yet. Set the party up, apply it, then save it here.');
    end

    for index, preset in ipairs(state.presets) do
        if (imgui.SmallButton(string.format('Use##p_%d', index))) then
            state.pendingDelete = nil;
            usePreset(preset.name);
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format('Put everyone on their "%s" jobs', preset.name));
        end

        imgui.SameLine();

        -- Delete asks twice: the first click arms it, the second within the
        -- same window session fires it. A preset is cheap to remake, but an
        -- accidental single click should still not cost one.
        if (state.pendingDelete == preset.name) then
            if (imgui.SmallButton(string.format('Really delete?##pd_%d', index))) then
                state.pendingDelete = nil;
                deletePreset(preset.name);
            end
        else
            if (imgui.SmallButton(string.format('X##pd_%d', index))) then
                state.pendingDelete = preset.name;
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Delete "%s"', preset.name));
            end
        end

        imgui.SameLine();
        imgui.Text(preset.name);
        imgui.SameLine();
        imgui.TextDisabled(string.format('(%d member%s)', preset.members, preset.members == 1 and '' or 's'));
    end

    imgui.Separator();

    imgui.Text('Save current as');
    imgui.SameLine();
    imgui.PushItemWidth(160);
    imgui.InputText('##dwjobs_savename', state.saveName, PRESET_NAME_MAX + 1);
    imgui.PopItemWidth();
    imgui.SameLine();

    if (imgui.SmallButton('Save##preset_save')) then
        local name = tostring(state.saveName[1] or ''):gsub('^%s+', ''):gsub('%s+$', '');

        if (name == '') then
            state.status    = 'A preset needs a name.';
            state.statusBad = true;
        elseif (#stagedDiffs() > 0) then
            -- Saving snapshots the SERVER's lineup, and the window is showing
            -- picks the server has not heard about yet. Saving now would
            -- remember the wrong thing and read as a bug later.
            state.status    = 'Apply your changes first, then save.';
            state.statusBad = true;
        else
            savePreset(name);
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Remember everyone\'s current jobs under this name');
    end

    imgui.EndChild();
end

local function renderWindow()
    local diffs = stagedDiffs();

    if (imgui.Button(#diffs > 0 and string.format('Apply changes (%d)', #diffs) or 'Apply changes')) then
        state.pendingDelete = nil;
        applyStaged();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Members out as trusts are dismissed and re-called on the new jobs.');
    end

    imgui.SameLine();

    if (imgui.Button('Revert')) then
        state.staged        = { };
        state.pendingDelete = nil;
        state.status        = '';
        state.statusBad     = false;
    end

    imgui.SameLine();

    if (imgui.Button('Refresh')) then
        state.pendingDelete = nil;
        refresh();
    end

    imgui.SameLine();

    -- A throttled queue has to look like progress rather than like nothing
    -- happening.
    if (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    else
        imgui.TextDisabled('');
    end

    -- The message line gets its own row, and errors are red: the reason a
    -- change was refused is the only thing telling a player what to do
    -- instead.
    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Separator();

    partyPanel();
    presetsPanel();

    needRoster();
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather
* than the addon: an error thrown inside d3d_present is raised sixty times a
* second and the addon host answers a long enough run by unloading the addon.
* Begin and End stay outside the pcall to keep ImGui's window stack balanced;
* the error is reported once and the window closes itself. Everything it does
* is still reachable as !jobs commands, so closing it is a real fallback.
--]]
ashita.events.register('d3d_present', 'dwjobs_present', function ()
    -- Before the visibility check: a click issued a moment before the window
    -- was closed still has to reach the server.
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    imgui.SetNextWindowSize({ 500, 430 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Jobs##dwjobs', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwjobs'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwjobs'):append(chat.message('Window closed. Everything it does also works as !jobs commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1] = true;

    -- Reopening is a fresh start for error reporting too: `reported` only
    -- exists to stop one bad frame printing sixty lines a second.
    state.reported      = false;
    state.staged        = { };
    state.pendingDelete = nil;
    state.status        = 'Loading...';
    state.statusBad     = false;

    refresh();
end

--[[
* Watch what the player sends.
*
* Bare `!jobs` (and `!jobs ui`) is intercepted and opens this window instead
* of printing the server's listing -- that line is blocked and never leaves
* the client. Every other `!jobs` command passes through and invalidates the
* roster behind it, so `!jobs set` typed by hand keeps the window honest --
* and so do `!squad` commands, because set/clear/call/dismiss all change what
* this window is showing.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped. Stamping
* the player's own line as a send makes the follow-up wait its interval.
--]]
ashita.events.register('packet_out', 'dwjobs_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!jobs' or lower == '!jobs ui' or lower == '!jobs window' or lower == '!jobs gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwj') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 5) == '!jobs' or lower:sub(1, 6) == '!squad') then
        refresh();
    end
end);

ashita.events.register('command', 'dwjobs_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwjobs' and args[1] ~= '/jobs')) then
        return;
    end

    e.blocked = true;

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

ashita.events.register('load', 'dwjobs_load', function ()
    print(chat.header('dwjobs'):append(chat.message('!jobs (or /jobs) opens the job window. Everything it does also works typed as !jobs commands.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new account view.
ashita.events.register('packet_in', 'dwjobs_zonein', function (e)
    if (e.id == 0x000A) then
        state.chars     = T{ };
        state.presets   = T{ };
        state.staged    = { };
        state.status    = 'Loading...';
        state.statusBad = false;

        refresh();
    end
end);
