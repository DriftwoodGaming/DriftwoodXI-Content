--[[
* DriftwoodXI -- dwunleashed
*
* The world boss, in a window. Every three to six hours a famous notorious
* monster breaks loose at an authored outdoor site in a live zone, stands
* passive and unclaimed for ten minutes while people travel to it, and then
* wakes. Anyone there may hit it, heal the people hitting it, or buff them --
* no claim, no alliance, no party. This window draws the one that is standing
* right now: which monster, where, how long until it wakes, how much health is
* left, how many are on it, whether the four-account gate has opened, and how
* many Unleashed kills your account has already been paid for today. A second
* tab holds the last five events with their callouts.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited
* whole). It carries no roster, no site table and no clock of its own:
* everything it draws arrived on the wire as records, and the only two lines
* it ever sends are `!dwy status` and `!dwy history`, which reach exactly the
* dispatch `!unleashed` and `!unleashed history` reach. It has no button that
* moves your character, spends anything, or touches the fight. It cannot: the
* wire has no verb for any of that.
*
* TURN IT OFF AND NOTHING IS LOST. `!unleashed` (or `!unl`) says all of it
* typed, the server-wide `[Unleashed]` broadcasts announce every spawn, wake,
* milestone and callout in system chat whether this is loaded or not, and
* `/port` is how you travel either way.
*
* IT NEVER SAYS WHEN THE NEXT ONE IS DUE, because the server never tells it
* (owner answer 3, 2026-09-17): not the epoch, not the hour, not "soon". The
* surprise is the feature, the spawn broadcast is the only telling, and there
* is no field on this wire a future version of this window could read it out
* of by accident.
*
* IT TAKES NO ZONE-IN SLOT. The first ask is LAZY -- the first frame the
* window is actually shown in a zone -- so a player who never opens it never
* handshakes and the login burst is exactly as long as it was before this
* addon existed (the dwparse decision; see dwecho.lua's ZONE_ORDER, which
* this addon is deliberately absent from). While the window is open it polls:
* every fifteen seconds when something is standing, every sixty when nothing
* is, one line at a time, never a burst, and not at all once a latch is set.
*
* Over `!dwy` (`documentation/dwy_protocol.md`).
--]]

addon.name    = 'dwunleashed';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.0';
addon.desc    = 'DriftwoodXI Unleashed: the wandering world boss -- where it stands, how long until it wakes, and who answered the last five.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. `y` was
-- the last free letter in modules/driftwoodxi/dww.lua's registry.
local DATA_SENDER = '_DWYDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

--[[
* THE ONE LITERAL THIS ADDON SHARES WITH THE SERVER AND THE WIRE DOES NOT
* CARRY. `s|`'s `open` field says whether the damage gate has opened; it does
* not say how many accounts opening it takes, and the sentence under a closed
* gate has to name a number. Part D of tools/dwunleashed/harness_dwunleashed.py
* reads BOTH real files and fails when this and unleashed_core.lua's
* OPEN_MIN_ACCOUNTS disagree. Adding a literal here means adding its check
* there.
--]]
local OPEN_MIN_ACCOUNTS = 4;

--[[
* EVERY NUMBER OFF THE WIRE COMES THROUGH HERE (the dwnemesis shape). LuaJIT
* -- which is what Ashita runs -- answers `tonumber` for 'inf', 'nan', '0x10'
* and '2.5' as readily as for '7', and everything downstream is a pile of
* string.format('%d'). A field that is not a plain integer inside the wire's
* own range is not a number this window can draw, so it reads as the record's
* default and the rest of the record still lands.
--]]
local WIRE_MAX = 2147483647;

local function wireInt(text, default)
    local value = tonumber(text);

    if (value == nil
            or value ~= value                            -- nan
            or value < -WIRE_MAX or value > WIRE_MAX     -- inf, and anything absurd
            or value ~= math.floor(value)) then
        return default or 0;
    end

    return value;
end

--[[
* Persisted presentation state, through Ashita's settings library (the
* dwleaderboard shape). ONE flat scalar: which tab this character was last
* looking at. Nothing the server said is ever written to disk -- a cached
* board is a board that can be wrong, and this one is cheap to ask for again.
*
* THE DEFAULTS ARE A SUGAR TABLE, and that `T` is load-bearing rather than
* decorative: settings.lua calls `defaults:copy(true)` (:180) and
* `settings:merge(defaults)` (:338), both sugar-table methods, so a plain
* table raises 'attempt to call a nil value'. The pcall below hides it at
* load; the library's own UNGUARDED packet_in handler re-loads on the
* zone-enter packet (:538) and Ashita answers a raise inside an event
* callback by UNLOADING THE ADDON -- so a missing `T` works at the desk and
* then the window disappears on the player's next zone line.
--]]
local defaultConfig = T{
    tab = 'rally',
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

local TABS = { 'rally', 'history' };

local function rememberedTab(cfg)
    if (type(cfg) ~= 'table' or type(cfg.tab) ~= 'string') then
        return 'rally';
    end

    for _, key in ipairs(TABS) do
        if (cfg.tab == key) then
            return key;
        end
    end

    return 'rally';
end

--[[
* Outbound: `!dwy` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat.
--]]
local SEND_INTERVAL = 1.2;

-- The answer clock, per read (the dwfame shape): one retry after five
-- seconds, then the silent latch. An unknown `!` command falls through to
-- PUBLIC /say on a server without dwy.lua, and the latch is what contains
-- that to two lines rather than one every send interval, forever.
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- How often an OPEN window re-asks for the card. Fifteen seconds while
-- something stands, because the health bar, the engaged count and the gate
-- are all moving; sixty while nothing does, because the only thing that can
-- change is that something started -- and the spawn broadcast tells everybody
-- that in system chat anyway, so the window is never the way a player finds
-- out. One timer, one line: never a burst.
local POLL_STANDING = 15.0;
local POLL_IDLE     = 60.0;

--[[
* THE TWO LINES THIS ADDON EVER SENDS, SPELLED OUT IN FULL.
*
* Written as whole literals rather than built with `'!dwy ' .. verb`, and the
* reason is a gate rather than taste: harness_dwsuite.py discovers every verb
* every addon sends by reading its `'!dwX <verb>'` literals and proving some
* module under modules/driftwoodxi spells that word. A concatenated verb is
* invisible to that scan -- so the addon would be exempt from the one check
* that catches an addon newer than its server sending a verb the doorway has
* never heard of, whose refusal is a PUBLIC line in chat on every window open.
* An exemption nobody asked for is worse than the typing it saves.
--]]
local LINES = {
    status  = '!dwy status',
    history = '!dwy history',
};

local state = T{
    open = T{ false },

    -- The standing card and the history rows, COMMITTED ON z| from pending
    -- copies so a half-arrived reply can never half-fill the window.
    card     = nil,      -- the s|/n| pair, as one table
    cardAt   = nil,      -- os.clock() when it committed, so `now` can be aged
    events   = nil,      -- the e|/c| rows, newest first
    eventsAt = nil,

    pendingCard   = nil,
    pendingEvents = nil,

    inbound   = nil,     -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,   -- a render error is worth saying once, not per frame

    -- The answer clock, keyed by verb: { [verb] = { at, tries } }. Keyed
    -- rather than single because the two reads are independent -- a history
    -- answer arriving while a status is outstanding must not mark the status
    -- answered, or a lost card is never re-asked.
    requested    = T{ },
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until a zone
    -- line re-probes it. A click does NOT lift this one -- an addon that is
    -- the wrong version stays the wrong version.
    refused = false,

    -- A status envelope closed WITHOUT a card (a refusal inside it, or a
    -- reply that ended before its s| arrived). The third latch, and it exists
    -- for the same reason as the other two: a server whose Unleashed half did
    -- not load answers every ask the same way, forever. A Refresh click lifts
    -- it -- a click is the player asking -- and so does a zone line.
    cardFailed = false,

    -- The lazy hello has fired in THIS zone. Not "the card is nil": a server
    -- that answers the ask with a refusal leaves it nil forever, and re-arming
    -- on emptiness asks once per throttle window for as long as the window
    -- stays open (the dwleaderboard lesson).
    helloSent  = false,
    polledAt   = nil,
    historySent = false,

    -- Which tab is drawn, restored from the settings file; `wantTab` is a tab
    -- the player named on the command line and is spent the frame it is taken
    -- (the dwparse shape: SetSelected left standing fights the player's own
    -- clicks every other frame).
    tab     = rememberedTab(config),
    wantTab = nil,
};

-- The settings profile changes when the CHARACTER does, and the library hands
-- the new one over here.
pcall(settings.register, 'settings', 'dwunleashed_settings_update', function (s)
    if (type(s) ~= 'table') then
        return;
    end

    config    = s;
    state.tab = rememberedTab(config);
end);

local function saveConfig()
    config.tab = state.tab;

    pcall(settings.save);
end

--[[
* THE TOOLTIPS, in one table rather than one literal per call site, so two
* controls that mean the same thing cannot drift into two sentences. The
* house rule: say what the control DOES, and for a greyed one say why it
* cannot right now; never repeat the label, never tooltip the self-evident.
--]]
local TIPS = {
    refresh      = 'Ask the server again, now. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks, and Refresh cannot fix that -- update dwunleashed through the launcher.',
    phase        = 'Rallying means it is standing there and cannot be hurt yet. Awake means the fight is on.',
    health       = 'What is left of a health pool the server sized from how many people were online when it spawned.',
    engaged      = 'Characters the server saw on its hate list at the last ten-second sample -- everyone who hit it, healed a fighter or buffed one.',
    gateShut     = 'It takes almost nothing until four different ACCOUNTS are on it. Six characters of your own count once.',
    gateOpen     = 'Enough different accounts turned up. The gate stays open now, even if people die or leave.',
    paid         = 'Unleashed kills your account has been paid for since Japanese midnight. The first of the day pays in full; every one after it pays half.',
    paidUnknown  = 'The server could not read your coin ledger just now. Refresh to ask again.',
    travel       = 'Travel there with /port. The fare to that anchor is waived for as long as it stands -- for destinations you have already attuned to.',
    rows         = 'The last five Unleashed the server recorded, newest first.',
    callouts     = 'Who did the most damage, who held its attention, who landed the killing blow and who struck first. A name the server could no longer resolve reads "someone".',
    turnout      = 'Accounts that took part for long enough and were paid.',
    coins        = 'Drift Coins the server actually granted across everybody who answered.',
};

--[[
* Record parsing (dwy protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST. This runs on every rendered frame for
    -- the life of the session and the queue is empty in almost all of them,
    -- while echo.canSend() is three calls across the C++ boundary
    -- (GetMemoryManager, GetPlayer, GetIsZoning). Asking it first spends a
    -- hundred and eighty of those a second to decide to do nothing.
    if (#queue == 0) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

-- Is anything outstanding? Deliberately NOT a render helper: the suite's
-- `d|`-wipe gate judges a name by whether some imgui-drawing function reads
-- it, and the ask table is bookkeeping rather than a pane.
local function asking()
    return next(state.requested) ~= nil;
end

local function latched()
    return state.refused or state.serverSilent or state.cardFailed;
end

-- `force` is the Refresh button: a click is the player asking, and the silent
-- latch exists to contain AUTOMATIC re-asks, not to ignore the player. The
-- PROTOCOL refusal is not lifted by a click.
local function ask(verb, force)
    if (state.refused) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    if (state.cardFailed) then
        if (not force) then
            return;
        end

        state.cardFailed = false;
    end

    -- A CLICK REPLACES THE OLD ANSWER. Lifting a latch without clearing the
    -- sentence that set it leaves the last refusal red in the header while the
    -- window is actively asking again. Only a REFUSAL is dropped; a note is
    -- still true.
    if (force and state.statusBad) then
        state.status    = '';
        state.statusBad = false;
    end

    state.requested[verb] = { at = os.clock(), tries = 1 };

    if (verb == 'status') then
        state.polledAt = os.clock();
    end

    issue(LINES[verb]);
end

local function checkAnswers()
    for verb, asked in pairs(state.requested) do
        -- THE CLOCK DOES NOT AGE WHILE THE CLIENT IS ZONING -- it is
        -- RE-STAMPED, not merely skipped. A line still sitting in the queue
        -- behind echo.canSend() had already burned its timeout by the time it
        -- went out, so the retry fired 1.2 s behind the first send: both
        -- inside the client's chat settle window, both dropped, and the latch
        -- set with the server never asked.
        if (not echo.canSend()) then
            asked.at = os.clock();
        elseif ((os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries >= ANSWER_TRIES) then
                -- NO SENTENCE IS WRITTEN HERE: the header draws the silent
                -- latch in preference to state.status, so a line set here is
                -- never read and outlives the latch that hid it.
                state.requested[verb] = nil;
                state.serverSilent    = true;
            else
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue(LINES[verb]);
            end
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], -1);

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            --[[
            * THE REFUSAL RETIRES THE ASKS. A mismatched `d|` IS an answer --
            * the server spoke, in a dialect this addon does not read -- and
            * leaving the clock running against it costs twice: five seconds
            * later the retry goes out against the protocol document's own
            * promise to stop asking, and five after that the silent latch
            * paints "No answer from the server" over the accurate "Update
            * dwunleashed" banner, which points the player at the server when
            * the addon is the problem.
            * The staging copies go too: they belong to an envelope that can
            * no longer be trusted to mean what this addon thinks it means.
            --]]
            state.requested     = T{ };
            state.pendingCard   = nil;
            state.pendingEvents = nil;
            state.serverSilent  = false;
            state.cardFailed    = false;

            print(chat.header('dwunleashed'):append(chat.error(string.format(
                'Server protocol %d, addon expects %d. Update dwunleashed.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope proves the server is there (the silent
        -- latch lifts), but only a STATUS envelope answers a status ask.
        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.inbound == 'status') then
            state.requested['status'] = nil;
            state.pendingCard         = { seen = false, phase = 0 };

            -- A NEW ANSWER CLEARS THE OLD BANNER. Whatever the server wants to
            -- say about THIS answer rides inside this envelope as m| or e|,
            -- after this line.
            state.status    = '';
            state.statusBad = false;
        elseif (state.inbound == 'history') then
            state.requested['history'] = nil;
            state.pendingEvents        = T{ };
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        if (kind == 'e') then
            --[[
            * A REFUSAL INSIDE AN OPEN ENVELOPE KILLS THAT ANSWER. This is not
            * a rare shape: dwy.lua emits exactly `d|1|status`, `e|Unleashed is
            * not loaded on this build.`, `z|status` when the core did not
            * load, and squad_storage's writer wraps ANY bare fail in the same
            * three lines. Committing that staging copy at z| would leave the
            * Rally tab drawing "Nothing is loose right now" -- a confident
            * false sentence about a server that answered nothing at all.
            --]]
            state.pendingCard   = nil;
            state.pendingEvents = nil;
        end

        -- A NOTE WITH NO SENTENCE IN IT SAYS NOTHING. `out:fail(nil)` writes a
        -- bare `e|`, and blanking the header with it is worse than ignoring
        -- it. The bookkeeping above still ran: a refusal with nothing to say
        -- is still a refusal.
        if (text == '') then
            return;
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwunleashed'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    local card = state.pendingCard;

    -- s| -- the standing card, all numbers.
    if (kind == 's' and card ~= nil) then
        card.seen       = true;
        card.phase      = wireInt(parts[2]);
        card.site       = wireInt(parts[3]);
        card.zone       = wireInt(parts[4]);
        card.boss       = wireInt(parts[5]);
        card.hp         = wireInt(parts[6]);
        card.maxhp      = wireInt(parts[7]);
        card.engaged    = wireInt(parts[8]);
        card.gateOpen   = wireInt(parts[9]) ~= 0;
        card.spawnedAt  = wireInt(parts[10]);
        card.wokeAt     = wireInt(parts[11]);
        card.now        = wireInt(parts[12]);
        -- -1 is "the coin ledger could not be read", never 0.
        card.paidToday  = wireInt(parts[13], -1);
        card.siteCount  = wireInt(parts[14]);

        return;
    end

    -- n| -- the three authored names, which ride their own record because
    -- three strings and three epochs do not fit one 130-byte line.
    if (kind == 'n' and card ~= nil) then
        card.zoneName = parts[2] or '';
        card.landmark = parts[3] or '';
        card.bossName = parts[4] or '';

        return;
    end

    --[[
    * h| -- one past event, newest first.
    *
    * `h` AND NOT `e`, AND THAT IS NOT A STYLE CHOICE: `e|` is the shared
    * writer's own refusal record (squad_storage.lua) and the branch above
    * claims it before anything down here is reached, so an event row spelled
    * `e|` would be read as an error message and printed into the player's
    * chat log verbatim. The first cut of this wire did exactly that; Part C
    * of the harness caught it on its first run. `h` is for history.
    --]]
    if (kind == 'h' and state.pendingEvents ~= nil) then
        state.pendingEvents:append({
            eventid  = wireInt(parts[2]),
            outcome  = parts[3] or '',
            bossName = parts[4] or '',
            zoneName = parts[5] or '',
            turnout  = wireInt(parts[6]),
            coins    = wireInt(parts[7]),
            ended    = wireInt(parts[8]),
        });

        return;
    end

    -- c| -- that event's four callouts, ATTACHED BY EVENT ID rather than by
    -- position: a row that has none sends no c| at all, so counting would
    -- put one event's names under another's.
    if (kind == 'c' and state.pendingEvents ~= nil) then
        local eventid = wireInt(parts[2]);

        for _, row in ipairs(state.pendingEvents) do
            if (row.eventid == eventid) then
                row.callouts = {
                    top   = parts[3] or '',
                    hate  = parts[4] or '',
                    final = parts[5] or '',
                    first = parts[6] or '',
                };
            end
        end

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        if (closed == 'status') then
            --[[
            * ONLY A COMPLETE CARD COMMITS. `pendingCard` is nil when a refusal
            * killed the envelope; it is present but hollow when the reply
            * ended before its `s|` arrived -- the client's chat rate limit
            * drops lines, which is the whole reason this addon carries an
            * answer clock. A HOLLOW CARD IS WORSE THAN NONE: phase would read
            * 0 and the Rally tab would say "Nothing is loose right now" about
            * a server that never told it anything.
            --]]
            local complete = card ~= nil and card.seen;

            state.pendingCard = nil;

            if (not complete) then
                state.cardFailed = true;

                return;
            end

            state.card       = card;
            state.cardAt     = os.clock();
            state.cardFailed = false;

            return;
        end

        if (closed == 'history') then
            -- An EMPTY history is a legitimate answer and commits: the server
            -- has recorded nothing yet, and the tab says so in its own words.
            -- A refusal set pendingEvents to nil, which does not.
            if (state.pendingEvents ~= nil) then
                state.events   = state.pendingEvents;
                state.eventsAt = os.clock();
            end

            state.pendingEvents = nil;
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwunleashed_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        -- BLOCKED BEFORE IT IS PARSED (the dwbags rule). A record that throws
        -- inside handleRecord must still not reach the chat log: the player's
        -- window would fill with `s|2|7|103|...` for as long as the bug lived,
        -- and a parse error is exactly when that is most likely.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwunleashed'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line invalidates the whole picture and re-probes every latch. The
    -- lazy hello re-arms with it: the window is per-zone, and a player who
    -- zoned into the rally's own zone is exactly the one who wants the card
    -- again. A half-arrived envelope dies with the zone too, or its stray tail
    -- would be accepted into a stale pending copy on the far side.
    if (e.id == 0x000A) then
        state.requested     = T{ };
        state.serverSilent  = false;
        state.refused       = false;
        state.cardFailed    = false;
        state.inbound       = nil;
        state.pendingCard   = nil;
        state.pendingEvents = nil;
        state.helloSent     = false;
        state.historySent   = false;
        state.polledAt      = nil;

        -- A RED REFUSAL DOES NOT OUTLIVE THE PLACE IT WAS ABOUT. A note is
        -- still true after a zone and stays.
        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end
    end
end);

--[[
* Rendering.
*
* MEASURED LAYOUT, NOT GUESSED (dwcraft's rule, reached here through
* dwnemesis's copy of it). Both helpers read the LIVE font each frame and fall
* back to a conservative constant when a binding does not answer; the asymmetry
* is deliberate, because a fallback that is too big spends a few pixels of list
* and one that is too small hides a control the player needs to click.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

-- What a scrolling table must leave below itself: a table carrying
-- ScrollY owns a child window, and a child window given a ZERO outer height
-- takes the whole remaining content region -- so anything drawn after it lands
-- below the window's bottom edge. A NEGATIVE outer height reads as "available
-- minus this" (the dwnemesis footerReserve shape).
local function footerReserve()
    return -(metric('GetFrameHeightWithSpacing', 26) + 12);
end

-- One short tip on the item just drawn. Every plain tooltip in this file goes
-- through here so the pattern cannot drift call site by call site.
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local PHASE_WORD = { [0] = 'Idle', [1] = 'Rallying', [2] = 'Awake' };

-- The server's clock at the moment the card was built, advanced by however
-- long the card has been on screen. THE CLIENT'S CLOCK IS ONLY EVER USED FOR
-- THE DELTA: a machine whose clock is minutes out still draws the right
-- countdown, because the base is the server's own `now`.
local function serverNow()
    if (state.card == nil) then
        return 0;
    end

    local aged = state.cardAt ~= nil and math.max(0, os.clock() - state.cardAt) or 0;

    return state.card.now + math.floor(aged);
end

-- "4m 12s", or "any moment now" once the countdown has run out and the next
-- card has not arrived yet. Never negative: a clock that has passed is a clock
-- that has passed, and "-3s" is the window arguing with the server.
local function countdown(seconds)
    if (seconds <= 0) then
        return 'any moment now';
    end

    if (seconds < 60) then
        return string.format('%ds', seconds);
    end

    return string.format('%dm %02ds', math.floor(seconds / 60), seconds % 60);
end

-- "12 Sep 21:14"-ish is not available without a date library the client does
-- not ship, so an event is aged instead: how long ago it ended, in the
-- server's own clock.
local function ago(ended)
    local seconds = serverNow() - ended;

    if (ended <= 0 or seconds < 0) then
        return 'just now';
    end

    if (seconds < 3600) then
        return string.format('%dm ago', math.floor(seconds / 60));
    end

    if (seconds < 86400) then
        return string.format('%dh ago', math.floor(seconds / 3600));
    end

    return string.format('%dd ago', math.floor(seconds / 86400));
end

local function healthColour(fraction)
    if (fraction <= 0.25) then
        return theme.colors.err;
    end

    if (fraction <= 0.5) then
        return theme.colors.warn;
    end

    return theme.colors.ok;
end

local function refreshTip()
    if (state.refused) then
        return TIPS.refreshStale;
    end

    if (state.cardAt == nil) then
        return TIPS.refresh;
    end

    return string.format('%s\nWhat is on screen arrived about %d second(s) ago.',
        TIPS.refresh, math.max(0, math.floor(os.clock() - state.cardAt)));
end

local function renderHeader()
    if (imgui.Button('Refresh##dwy_refresh')) then
        -- A click is the player asking: it lifts both liftable latches, clears
        -- a stale refusal, and re-asks whichever tab is on screen as well as
        -- the card.
        ask('status', true);

        if (state.tab == 'history') then
            ask('history', true);
        end
    end

    -- Built only when it is going to be read: refreshTip formats a sentence
    -- and reads the clock, and tip() would evaluate it every frame.
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(refreshTip());
    end

    imgui.SameLine();

    -- REFUSED OUTRANKS SILENT. A protocol mismatch is the one state here with
    -- an action attached to it, and the mismatch branch retires the answer
    -- clock precisely so the silent latch cannot paint over the sentence that
    -- is true.
    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwunleashed through the launcher.');
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server. Refresh to ask again.');
    elseif (state.cardFailed) then
        imgui.TextColored(theme.colors.err, 'The server answered without a card. Refresh to ask again.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or asking()) then
        imgui.TextDisabled('asking...');
    else
        imgui.TextDisabled('Something is always about to get loose.');
    end

    imgui.Separator();
end

local function renderRally()
    local card = state.card;

    if (card == nil) then
        imgui.TextDisabled('Waiting for the server...');

        return;
    end

    if (card.phase == 0) then
        -- THE ONE SENTENCE, and it is the typed door's own. It says nothing
        -- about when: the next spawn is not on this wire and never will be.
        imgui.Text('Nothing is loose right now. You will hear about it.');

        return;
    end

    -- The monster, given the whole line to itself and the theme's strongest
    -- colour. (There is no font-scale binding this addon may rely on --
    -- SetWindowFontScale is absent from Ashita's own SDK annotations -- so
    -- "large" here is prominence rather than point size.)
    imgui.TextColored(theme.colors.hint, card.bossName ~= '' and card.bossName or 'Something');
    imgui.Text(string.format('%s -- %s',
        card.zoneName ~= '' and card.zoneName or string.format('zone %d', card.zone),
        card.landmark ~= '' and card.landmark or 'somewhere out there'));

    imgui.Separator();

    local word = PHASE_WORD[card.phase] or 'Unknown';

    if (card.phase == 1) then
        imgui.TextColored(theme.colors.warn, string.format('%s -- it wakes in %s',
            word, countdown(card.wokeAt - serverNow())));
    else
        imgui.TextColored(theme.colors.ok, word);
    end

    tip(TIPS.phase);

    -- The health bar. A maxhp of 0 is a server that did not say, never a
    -- monster with no health: the bar is skipped rather than drawn empty.
    if (card.maxhp > 0) then
        local fraction = math.max(0, math.min(1, card.hp / card.maxhp));

        imgui.PushStyleColor(ImGuiCol_PlotHistogram, healthColour(fraction));
        imgui.ProgressBar(fraction, { -1, 18 },
            string.format('%d%%   %d / %d', math.floor(fraction * 100), card.hp, card.maxhp));
        imgui.PopStyleColor(1);
        tip(TIPS.health);
    end

    imgui.Text(string.format('%d engaged', card.engaged));
    tip(TIPS.engaged);

    imgui.SameLine();

    if (card.gateOpen) then
        imgui.TextColored(theme.colors.ok, '   Open to all');
        tip(TIPS.gateOpen);
    else
        imgui.TextColored(theme.colors.warn, string.format('   Waiting for %d accounts', OPEN_MIN_ACCOUNTS));
        tip(TIPS.gateShut);
    end

    imgui.Separator();

    if (card.paidToday < 0) then
        imgui.TextDisabled('Paid today: unknown');
        tip(TIPS.paidUnknown);
    elseif (card.paidToday == 0) then
        imgui.Text('Paid today: 0 -- this one pays you in full.');
        tip(TIPS.paid);
    else
        imgui.Text(string.format('Paid today: %d -- this one pays you half.', card.paidToday));
        tip(TIPS.paid);
    end

    -- THE TRAVEL HINT IS A HINT AND NOT A BUTTON. This addon never moves the
    -- player: /port is a window of its own, it owns the attunement rules, and
    -- a warp fired from here would be a second path into a thing that has one.
    imgui.TextDisabled(string.format('The fare to %s is free while it stands -- /port.',
        card.landmark ~= '' and card.landmark or 'that anchor'));
    tip(TIPS.travel);
end

local function renderHistory()
    local rows = state.events;

    if (rows == nil) then
        imgui.TextDisabled('Waiting for the server...');

        return;
    end

    if (#rows == 0) then
        imgui.TextDisabled('Nothing yet. The first one the server records will show up here.');

        return;
    end

    imgui.Text(string.format('The last %d:', #rows));
    tip(TIPS.rows);
    imgui.Separator();

    if (imgui.BeginTable('dwy_history', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad = textWidth('nn', 14);

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, textWidth('999d ago', 66) + pad);
        imgui.TableSetupColumn('Monster', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('Where', ImGuiTableColumnFlags_WidthStretch, 2.4);
        imgui.TableSetupColumn('Outcome', ImGuiTableColumnFlags_WidthFixed, textWidth('withdrawn', 72) + pad);
        imgui.TableSetupColumn('Answered', ImGuiTableColumnFlags_WidthFixed, textWidth('Answered', 66) + pad);
        imgui.TableSetupColumn('Coins', ImGuiTableColumnFlags_WidthFixed, textWidth('Coins', 48) + pad);
        imgui.TableHeadersRow();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.Text(ago(row.ended));

            imgui.TableNextColumn();
            imgui.Text(row.bossName ~= '' and row.bossName or 'Unknown');

            imgui.TableNextColumn();
            imgui.Text(row.zoneName ~= '' and row.zoneName or 'somewhere');

            imgui.TableNextColumn();

            if (row.outcome == 'killed') then
                imgui.TextColored(theme.colors.ok, row.outcome);
            else
                imgui.TextColored(theme.colors.dim, row.outcome ~= '' and row.outcome or 'unknown');
            end

            imgui.TableNextColumn();
            imgui.Text(tostring(row.turnout));
            tip(TIPS.turnout);

            imgui.TableNextColumn();
            imgui.Text(tostring(row.coins));
            tip(TIPS.coins);

            -- The four callouts, under the row they belong to and only for a
            -- row that HAS them: a withdrawn event has no fight to name
            -- anybody from, and four "someone"s under it would be this window
            -- inventing one.
            if (row.callouts ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.TableNextColumn();
                imgui.TextDisabled(string.format('top damage %s   held by %s   last blow %s   first blood %s',
                    row.callouts.top, row.callouts.hate, row.callouts.final, row.callouts.first));
                tip(TIPS.callouts);
            end
        end

        imgui.EndTable();
    end
end

--[[
* One tab. The remembered choice is written back only when the PLAYER moves,
* never when a `wantTab` from the command line takes the window somewhere for
* one frame -- and SetSelected is spent the frame it lands, because leaving it
* standing fights the player's own clicks on every other frame (the dwparse
* note).
--]]
local function tabItem(key, label, body)
    local flags = ImGuiTabItemFlags_None;

    if (state.wantTab == key) then
        flags = ImGuiTabItemFlags_SetSelected;
    end

    if (imgui.BeginTabItem(label, nil, flags)) then
        if (state.wantTab == key) then
            state.wantTab = nil;
        end

        if (state.wantTab == nil and state.tab ~= key) then
            state.tab = key;

            saveConfig();
        end

        body();
        imgui.EndTabItem();
    end
end

local function renderWindow()
    renderHeader();

    if (imgui.BeginTabBar('dwy_tabs')) then
        tabItem('rally', 'Rally###dwy_tab_rally', renderRally);
        tabItem('history', string.format('History %d###dwy_tab_history',
            state.events ~= nil and #state.events or 0), renderHistory);

        imgui.EndTabBar();
    end
end

ashita.events.register('d3d_present', 'dwunleashed_present', function ()
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    -- THE FIRST ASK IS LAZY AND IT IS ASKED HERE, the first frame the window
    -- is actually shown in this zone -- never on the zone line, never at load.
    -- That is what keeps this addon out of dwecho's ZONE_ORDER entirely: it
    -- adds nothing to the login burst, because a closed window says nothing.
    -- Every latch is consulted here as well as inside ask(): this test runs
    -- sixty times a second and the call it saves is not free.
    if (not state.helloSent and not latched() and not asking()) then
        state.helloSent = true;

        ask('status');
    elseif (state.card ~= nil and not latched() and state.requested['status'] == nil) then
        -- The poll. Fifteen seconds while something stands, sixty while
        -- nothing does; one line, and only ever one outstanding.
        local wait = (state.card.phase == 1 or state.card.phase == 2) and POLL_STANDING or POLL_IDLE;

        if (state.polledAt == nil or (os.clock() - state.polledAt) >= wait) then
            ask('status');
        end
    end

    -- The history is asked once per zone, and only while its own tab is the
    -- one on screen: a player who never opens it never pays for it.
    if (state.tab == 'history' and not state.historySent and not latched()
            and state.requested['history'] == nil) then
        state.historySent = true;

        ask('history');
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 580, 420 }, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE. Nothing in ImGui stops a window being dragged to
    -- nothing, and this one carries a two-tab bar, a health bar and a
    -- six-column table. 520 IS MEASURED, NOT ROUND: the widest line the window
    -- ever draws is the travel hint at the longest authored landmark ("The
    -- fare to by the Tavnazian Archipelago outpost is free while it stands --
    -- /port.", seventy-eight characters). A player whose saved size is under
    -- this is clamped up to it once.
    imgui.SetNextWindowSizeConstraints({ 520, 300 }, { 99999, 99999 });

    local visible = imgui.Begin('DriftwoodXI Unleashed##dwunleashed', state.open, ImGuiWindowFlags_NoDocking);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwunleashed'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwunleashed'):append(chat.message('Window closed. Everything it shows also works typed as !unleashed.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwunleashed_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    -- THE THROTTLE IS STAMPED BY WHAT THE PLAYER SENDS, NOT ONLY BY US. The
    -- limit it exists to respect is the CLIENT's, on chat, and that counts the
    -- player's own typing -- so an addon that stamps only from its own pump
    -- believes the channel is idle when it is not and fires into the same beat
    -- as a line the player typed. The client then drops one of them.
    if (message:sub(1, 4):lower() ~= '!dwy') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwunleashed_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, and a player
    -- who capitalises is not making a mistake.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/unleashed' and first ~= '/dwunleashed') then
        return;
    end

    e.blocked = true;

    -- `/unleashed history` OPENS the window on that tab rather than toggling
    -- it: a player who named a tab has already said what they want, and
    -- toggling the window shut on them because it happened to be open is the
    -- wrong answer to the only thing they said.
    if (#args > 1) then
        local word = args[2]:lower();

        if (word == 'history' or word == 'rally') then
            state.wantTab  = word;
            state.open[1]  = true;
            state.reported = false;

            return;
        end

        print(chat.header('dwunleashed'):append(chat.message('/unleashed opens the window; /unleashed history opens it on the History tab.')));

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwunleashed_load', function ()
    print(chat.header('dwunleashed'):append(chat.message('/unleashed opens the Unleashed window, /unleashed history opens it on the last five. Everything it shows also works typed as !unleashed or !unl.')));
end);
