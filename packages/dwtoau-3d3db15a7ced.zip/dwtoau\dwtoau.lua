--[[
* DriftwoodXI -- dwtoau
*
* The ToAU job kit: the three Treasures of Aht Urhgan jobs need a hand a
* squad alt-trust cannot give itself. A BLUE MAGE casts only what it has
* SET; a PUPPETMASTER fights with the automaton it BUILT; a CORSAIR's rolls
* are pressed by hand when the moment calls for them. A logged-in character
* does all three from the client's own menus; a squad member is never logged
* in. This window is the door the master uses instead.
*
*   Blue Mage tab     pick a squad blue mage, tick spells from everything
*                     the account knows (level, set points and kind on every
*                     row), watch the slot and point budget, Apply.
*   Puppetmaster tab  frame, head, twelve attachment slots, the per-element
*                     capacity bars, everything the account has unlocked;
*                     Apply writes the build, Deactivate puts an active
*                     automaton away so it can be re-equipped.
*   Corsair tab       every corsair out, the rolls it can press as buttons,
*                     its Double-Up window while one is open, and the rolls
*                     sitting on you right now with their numbers and clocks.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no budget arithmetic and no unlock table: slots, points, levels,
* capacities and unlocks all ride the wire (`!dwk`, sender _DWKDATA,
* documentation/dwk_protocol.md), and an Apply clicked here reaches exactly
* the xi.dwToau.writeBlue / writeAutomaton that `!toau blu Yakapo set
* head_butt` typed reaches -- the account check, the online rule, the
* budget, the level gate, the unlocks and the capacity are the server's to
* enforce (cpp/squad_toau.cpp), and this window's greyed buttons are a
* courtesy, not the authority. Names are the client's own: spells and
* attachments are drawn from the resource manager by id, so the wire carries
* numbers and the window says words.
*
* EDITS ARE LOCAL UNTIL APPLY, and Apply sends the WHOLE list -- a lost line
* costs a click, never a slot. ONE WRITE IN FLIGHT: Apply, Deactivate and a
* roll press disarm the buttons until the server's w| lands (or five seconds
* pass); writes are never collapsed, never retried.
*
* TURN IT OFF AND NOTHING IS LOST. `!toau` typed in chat does the same jobs
* in prose, and `!dwk sync` shows exactly what this window is told.
--]]

addon.name    = 'dwtoau';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.0';
addon.desc    = 'ToAU job kit for DriftwoodXI squads: set a blue mage\'s spells, build a puppetmaster\'s automaton, press a corsair\'s rolls.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

local DATA_SENDER = '_DWKDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

-- Job ids as the engine numbers them (xi.job). Navigation, not data: the
-- wire says which job each character is on; these only pick the tab's rows.
local JOB_BLU = 16;
local JOB_COR = 17;
local JOB_PUP = 18;

local BLUE_SLOTS       = 20;
local ATTACHMENT_SLOTS = 12;

-- Element order of every capacity/cost list on the wire: the maneuver
-- order (fire, ice, wind, earth, thunder, water, light, dark).
local ELEMENTS = T{ 'Fire', 'Ice', 'Wind', 'Earth', 'Thunder', 'Water', 'Light', 'Dark' };

-- Item ids of the automaton parts: the client's resource manager names
-- them (puppetutils' own 0x2000 / 0x2100 bases).
local PART_BASE       = 0x2000;
local ATTACHMENT_BASE = 0x2100;

-- Kind letters the wire puts on a blue spell (cpp/squad_toau.cpp blueKind).
local KINDS = T{
    p = 'Physical',
    m = 'Magical',
    d = 'Debuff',
    h = 'Healing',
    b = 'Buff',
};

local state = T{
    open      = T{ false },

    -- Everything below is replaced wholesale by a response, never merged,
    -- so a stale row cannot survive a refresh (dwtracker's rule).
    chars     = T{ },        -- c| rows, in wire order
    charById  = T{ },

    -- Blue Mage tab: the picked character, the server's last answer, and the
    -- working copy that Apply sends.
    bluPick   = nil,         -- charid
    blu       = nil,         -- { header, set = {ids}, known = {rows}, byId }
    bluWork   = T{ },        -- ordered ids
    bluDirty  = false,
    bluFilter = T{ '' },
    bluKind   = T{ 1 },      -- 1 = all, then KINDS in KIND_ORDER

    -- Puppetmaster tab.
    pupPick   = nil,
    pup       = nil,         -- { header, attachments, capacity, frames, heads, unlocked, unlockedById }
    pupWork   = nil,         -- { frame, head, attachments = {12} }
    pupDirty  = false,
    pupFilter = T{ '' },

    -- Corsair tab: members out with their rolls, the double-up windows,
    -- the rolls on the player; each stamped with the clock it arrived on.
    cor       = T{ members = T{ }, windows = T{ }, active = T{ }, at = 0 },
    corAsked  = 0,

    -- Response assembly: records are accepted only between d| and z|.
    inbound   = nil,
    inboundId = nil,
    staging   = nil,

    -- The one write in flight: { verb, charid, at }. Buttons disarm while set.
    pending   = nil,

    status    = 'Waiting for the first sync.',
    statusBad = false,
    reported  = false,
};

local KIND_ORDER = T{ 'p', 'm', 'd', 'h', 'b' };

--[[
* Send a command to the server, exactly as if it had been typed -- one at a
* time. Reads are deduplicated; WRITES ARE NOT QUEUED HERE AT ALL -- they go
* through sendWrite below, one in flight, never collapsed, never retried.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- Held shut while zoning: a line handed to a zoning client is not
    -- delayed, it is LOST (dwecho.lua's canSend).
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking for READS: an unanswered request is asked once more and
* then left alone. A PLAIN TABLE, NOT T{ } (dwbags' shadowed-key lesson).
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

-- True once this server has shown it does not speak dwtoau -- an unknown
-- !command falls through to /say, so retrying against a dead verb is the
-- player publicly chatting "!dwk sync". Cleared by any d| envelope and by
-- the player acting on purpose (window open, refresh).
local serverSilent = false;

local function forget()
    requested = {};
end

-- Requests are keyed by the whole line ('blu 1234'); the envelope names the
-- verb and, for the per-character verbs, the charid.
local function answered(verb, charid)
    for key, asked in pairs(requested) do
        if (type(asked) == 'table') then
            local first, rest = key:match('^(%S+)%s*(.*)$');

            if (first == verb and (charid == nil or rest == '' or rest == tostring(charid))) then
                asked.answered = true;
            end
        end
    end
end

local function ask(verb)
    requested[verb] = { at = os.clock(), answered = false, tries = 1 };

    issue('!dwk ' .. verb);
end

local function checkAnswers()
    if (not echo.canSend()) then
        return;
    end

    for verb, asked in pairs(requested) do
        if (not asked.answered and (os.clock() - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries < ANSWER_TRIES) then
                asked.at    = os.clock();
                asked.tries = asked.tries + 1;

                issue('!dwk ' .. verb);
            elseif (not asked.gaveUp) then
                asked.gaveUp = true;
                serverSilent = true;

                state.status    = 'No answer from the server. Is DriftwoodXI up to date?';
                state.statusBad = true;
            end
        end
    end

    -- The write's own clock: no retry, just the buttons back. The next
    -- sync shows whatever really happened.
    if (state.pending ~= nil and (os.clock() - state.pending.at) >= ANSWER_TIMEOUT) then
        state.pending   = nil;
        state.status    = 'No answer to that write -- nothing retried. Refresh to see where things stand.';
        state.statusBad = true;
    end
end

local function requestSync()
    ask('sync');
end

local function requestBlue()
    if (state.bluPick ~= nil) then
        ask('blu ' .. tostring(state.bluPick));
    end
end

local function requestPup()
    if (state.pupPick ~= nil) then
        ask('pup ' .. tostring(state.pupPick));
    end
end

local function requestCor()
    state.corAsked = os.clock();

    ask('cor');
end

--[[
* The one write path. Never queued with the reads, never deduplicated,
* never retried: one write in flight, buttons disarmed until its w| lands.
--]]
local function sendWrite(verb, charid, line)
    if (state.pending ~= nil) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    state.pending = { verb = verb, charid = charid, at = os.clock() };
    lastSend      = os.clock();

    echo.send('!dwk ' .. line);
end

--[[
* Names from the client's own resources. The wire carries ids; a name the
* client cannot draw falls back to a number so a row is never blank.
--]]
local spellNames = {};
local itemNames  = {};

local function spellName(id)
    if (spellNames[id] ~= nil) then
        return spellNames[id];
    end

    local name  = nil;
    local spell = AshitaCore:GetResourceManager():GetSpellById(id);

    if (spell ~= nil and spell.Name ~= nil and spell.Name[1] ~= nil and #spell.Name[1] > 0) then
        name = spell.Name[1];
    end

    spellNames[id] = name or string.format('spell #%d', id);

    return spellNames[id];
end

local function itemName(itemId, fallback)
    if (itemNames[itemId] ~= nil) then
        return itemNames[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    local name = nil;

    if (item ~= nil and item.Name ~= nil and item.Name[1] ~= nil and #item.Name[1] > 0) then
        name = item.Name[1];
    end

    itemNames[itemId] = name or fallback or string.format('item #%d', itemId);

    return itemNames[itemId];
end

--[[
* The blue magic catalog -- bluecatalog.lua beside this file, GENERATED by
* tools/dwtoau/gen_blue_catalog.py from the server's blue magic dumps and
* gated by PLANS/Check-BlueCatalog.ps1 plus the dwtoau harness. It is what
* the hover cards (owner request 2026-09-03) read for the two things the
* client's own Set Spells card shows that neither the wire nor the resource
* manager carries: the stat bonuses a spell grants while set and the job
* trait it counts toward. The description and the MP cost come from the
* client's resources; the level and the blue magic points ride the k| record.
* Missing catalog = cards without the trait and stat lines, plus a line
* saying so; nothing else degrades (the dwquest augcatalog rule).
--]]
local haveCatalog, bluecatalog = pcall(require, 'bluecatalog');

if (not haveCatalog or type(bluecatalog) ~= 'table'
        or type(bluecatalog.spells) ~= 'table' or type(bluecatalog.traits) ~= 'table') then
    haveCatalog = false;
    bluecatalog = { spells = { }, traits = { } };
end

-- The client's own words for a spell: the description text and the mana cost,
-- read once per id. Guarded like every resource read here -- the SDK table's
-- shape is the client's business, and a card missing a line beats a window
-- that throws on hover.
local spellInfos = {};

local function spellInfo(id)
    if (spellInfos[id] ~= nil) then
        return spellInfos[id];
    end

    local info = { desc = nil, mp = nil };

    pcall(function()
        local spell = AshitaCore:GetResourceManager():GetSpellById(id);

        if (spell ~= nil) then
            if (spell.Description ~= nil and spell.Description[1] ~= nil and #spell.Description[1] > 0) then
                info.desc = spell.Description[1];
            end

            if (type(spell.ManaCost) == 'number') then
                info.mp = spell.ManaCost;
            end
        end
    end);

    spellInfos[id] = info;

    return info;
end

-- The tier table a catalog category names, or nil (category 0, or a
-- category the server defines no tier for).
local function traitTiers(category)
    if (category == nil or category == 0) then
        return nil;
    end

    local tiers = bluecatalog.traits[category];

    if (type(tiers) ~= 'table' or #tiers == 0) then
        return nil;
    end

    return tiers;
end

-- "2/4/6" -- the points each tier needs, the server's own thresholds.
local function tierLadder(tiers)
    local steps = T{ };

    for _, tier in ipairs(tiers) do
        steps:append(tostring(tier[2]) .. (tier.jp and '*' or ''));
    end

    return table.concat(steps, '/');
end

--[[
* The hover card (owner request 2026-09-03): what the client's own Set Spells
* menu shows for a blue spell -- the description, the stat bonuses it grants
* while set, the job trait it counts toward, its level, MP cost and blue
* magic point cost -- so a player building a squad blue mage's set can see
* which spells feed which trait. The numbers are the SERVER's: the trait
* weight is what blueutils::CalculateTraits sums and the tier ladder is
* what it compares against, which is why the catalog carries them rather
* than retail's.
--]]
local function spellCard(row)
    local info  = spellInfo(row.id);
    local entry = bluecatalog.spells[row.id];

    imgui.BeginTooltip();
    imgui.Text(string.format('%s  (%s)', spellName(row.id), KINDS[row.kind] or row.kind));

    if (info.desc ~= nil) then
        imgui.TextWrapped(info.desc);
    end

    if (entry ~= nil) then
        if (#entry.m > 0) then
            imgui.Text(table.concat(entry.m, '  '));
        end

        local tiers = traitTiers(entry.t);

        if (tiers ~= nil) then
            imgui.Text(string.format('Job Trait: %s (+%d pt, tiers at %s)', tiers[1][3], entry.w, tierLadder(tiers)));

            if (#tiers > 1 and tiers[#tiers][3] ~= tiers[1][3]) then
                imgui.TextDisabled(string.format('becomes %s at the top tier', tiers[#tiers][3]));
            end
        elseif (entry.t ~= 0) then
            imgui.TextDisabled('Job Trait: none this server defines');
        end
    elseif (not haveCatalog) then
        imgui.TextDisabled('(bluecatalog.lua missing: no trait or stat lines)');
    end

    imgui.Text(string.format('Lv.%d  MP cost %s  Blue Magic Points %d',
        row.level, info.mp ~= nil and tostring(info.mp) or '?', row.points));
    imgui.EndTooltip();
end

--[[
* The set's trait progress: points per category over the working set, so a
* player sees "Lizard Killer 1/2" while choosing, not after applying. Same
* catalog, same server thresholds; a tier marked * needs job points the
* summoner may not have.
--]]
local function traitProgress(setIds)
    local points = { };
    local order  = T{ };

    for _, id in ipairs(setIds) do
        local entry = bluecatalog.spells[id];

        if (entry ~= nil and traitTiers(entry.t) ~= nil) then
            if (points[entry.t] == nil) then
                points[entry.t] = 0;
                order:append(entry.t);
            end

            points[entry.t] = points[entry.t] + entry.w;
        end
    end

    table.sort(order);

    local lines = T{ };

    for _, category in ipairs(order) do
        local tiers   = traitTiers(category);
        local have    = points[category];
        local reached = nil;
        local nextUp  = nil;

        for _, tier in ipairs(tiers) do
            if (have >= tier[2]) then
                reached = tier;
            elseif (nextUp == nil) then
                nextUp = tier;
            end
        end

        lines:append({
            text = string.format('%s: %d pt%s%s', reached ~= nil and reached[3] or tiers[1][3], have,
                reached ~= nil and string.format(' -- tier %d%s', reached[1], reached.jp and ' (job points)' or '') or '',
                nextUp ~= nil and string.format(', next tier at %d', nextUp[2]) or ''),
            reached = reached ~= nil,
        });
    end

    return lines;
end

-- `harlequin_frame` -> `Harlequin Frame`: the wire's raw names, for the
-- parts the client's resources might not name.
local function prettify(raw)
    local words = T{ };

    for word in string.gmatch(tostring(raw or ''), '[^_]+') do
        words:append(word:sub(1, 1):upper() .. word:sub(2));
    end

    return table.concat(words, ' ');
end

local function attachmentName(id)
    return itemName(ATTACHMENT_BASE + id, string.format('attachment #%d', id));
end

--[[
* Record parsing. Pipe-separated with a single-character type; anything
* unrecognised is ignored rather than being an error, so a server newer
* than this addon cannot break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function numbers(text)
    local out = T{ };

    for piece in string.gmatch(tostring(text or ''), '[^,]+') do
        out:append(tonumber(piece) or 0);
    end

    return out;
end

local function charOf(charid)
    return state.charById[charid];
end

local function onJob(row, jobId)
    return row ~= nil and (row.mjob == jobId or row.sjob == jobId);
end

-- The per-character staging for blu/bluset and pup/pupset responses.
local function newBlueStaging()
    return T{ header = nil, set = T{ }, known = T{ } };
end

local function newPupStaging()
    return T{ header = nil, attachments = T{ }, capacity = T{ }, frames = T{ }, heads = T{ }, unlocked = T{ } };
end

local function newCorStaging()
    return T{ members = T{ }, windows = T{ }, active = T{ } };
end

-- Commit a blue response: the cache and the working copy both reset to
-- what the server said (a write's own refresh rides its envelope).
local function commitBlue(staging)
    if (staging == nil or staging.header == nil) then
        return;
    end

    local byId = T{ };

    for _, row in ipairs(staging.known) do
        byId[row.id] = row;
    end

    state.blu = T{
        header = staging.header,
        set    = staging.set,
        known  = staging.known,
        byId   = byId,
    };

    state.bluWork = T{ };

    for _, id in ipairs(staging.set) do
        state.bluWork:append(id);
    end

    state.bluDirty = false;
end

local function commitPup(staging)
    if (staging == nil or staging.header == nil) then
        return;
    end

    local unlockedById = T{ };

    for _, row in ipairs(staging.unlocked) do
        unlockedById[row.id] = row;
    end

    state.pup = T{
        header       = staging.header,
        attachments  = staging.attachments,
        capacity     = staging.capacity,
        frames       = staging.frames,
        heads        = staging.heads,
        unlocked     = staging.unlocked,
        unlockedById = unlockedById,
    };

    state.pupWork = T{
        frame       = staging.header.frame,
        head        = staging.header.head,
        attachments = T{ },
    };

    for slot = 1, ATTACHMENT_SLOTS do
        state.pupWork.attachments[slot] = staging.attachments[slot] or 0;
    end

    state.pupDirty = false;
end

local function commitCor(staging)
    if (staging == nil) then
        return;
    end

    state.cor = T{
        members = staging.members,
        windows = staging.windows,
        active  = staging.active,
        at      = os.clock(),
    };
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        serverSilent = false;

        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwtoau.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- The envelope IS the answer, whatever version it announced.
            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            state.pending = nil;

            return;
        end

        state.inbound   = parts[3];
        state.inboundId = tonumber(parts[4]);

        if (state.inbound == 'sync') then
            state.staging = T{ chars = T{ } };
        elseif (state.inbound == 'blu' or state.inbound == 'bluset') then
            state.staging = newBlueStaging();
        elseif (state.inbound == 'pup' or state.inbound == 'pupset' or state.inbound == 'pupoff') then
            state.staging = newPupStaging();
        elseif (state.inbound == 'cor') then
            state.staging = newCorStaging();
        else
            state.staging = nil;
        end

        answered(state.inbound, state.inboundId);

        if (state.inbound == 'status') then
            for _, asked in pairs(requested) do
                asked.answered = true;
            end

            state.pending = nil;
        end

        return;
    end

    -- Notes and refusals are accepted whatever the envelope state: the
    -- sentence saying why something was refused outranks the response it
    -- happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwtoau'):append(chat.error(state.status)));

            if (string.find(line, 'not loaded', 1, true) ~= nil) then
                serverSilent = true;
            end

            -- A refusal that came instead of a write's outcome frees the
            -- buttons: the server has said its piece.
            state.pending = nil;
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;
        local staging = state.staging;

        state.inbound   = nil;
        state.inboundId = nil;
        state.staging   = nil;

        if (closing == 'sync' and staging ~= nil) then
            state.chars    = staging.chars;
            state.charById = T{ };

            for _, row in ipairs(state.chars) do
                state.charById[row.charid] = row;
            end

            state.status    = 'Synced.';
            state.statusBad = false;
        elseif ((closing == 'blu' or closing == 'bluset') and staging ~= nil) then
            -- Commit under the character the envelope NAMED, so a pick
            -- change mid-flight can never file one alt's set under another.
            if (staging.header ~= nil and staging.header.charid == state.bluPick) then
                commitBlue(staging);
            end

            if (closing == 'blu') then
                state.status    = 'Synced.';
                state.statusBad = false;
            end
        elseif ((closing == 'pup' or closing == 'pupset') and staging ~= nil) then
            if (staging.header ~= nil and staging.header.charid == state.pupPick) then
                commitPup(staging);
            end

            if (closing == 'pup') then
                state.status    = 'Synced.';
                state.statusBad = false;
            end
        elseif (closing == 'pupoff') then
            -- The automaton is gone; the next pup read says so.
            requestPup();
        elseif (closing == 'cor' and staging ~= nil) then
            commitCor(staging);
        elseif (closing == 'roll') then
            requestCor();
        end

        return;
    end

    local staging = state.staging;

    -- A write's outcome, in words.
    if (kind == 'w') then
        state.pending   = nil;
        state.statusBad = (tonumber(parts[2]) or 0) == 0;
        state.status    = parts[5] or '';

        return;
    end

    if (kind == 'c' and staging ~= nil and staging.chars ~= nil) then
        local flags = tonumber(parts[12]) or 0;

        staging.chars:append({
            charid = tonumber(parts[2]) or 0,
            name   = parts[3] or '?',
            slot   = tonumber(parts[4]) or 0,
            mjob   = tonumber(parts[5]) or 0,
            mlvl   = tonumber(parts[6]) or 0,
            sjob   = tonumber(parts[7]) or 0,
            slvl   = tonumber(parts[8]) or 0,
            blu    = tonumber(parts[9]) or 0,
            pup    = tonumber(parts[10]) or 0,
            cor    = tonumber(parts[11]) or 0,
            online = bit.band(flags, 1) ~= 0,
            out    = bit.band(flags, 2) ~= 0,
            self   = bit.band(flags, 4) ~= 0,
            active = bit.band(flags, 8) ~= 0,
            tag    = parts[13] or '',
        });

        return;
    end

    -- Blue magic: header, the set, the known list (packed).
    if (kind == 'b' and staging ~= nil and staging.known ~= nil) then
        staging.header = {
            charid     = tonumber(parts[2]) or 0,
            name       = parts[3] or '?',
            job        = tonumber(parts[4]) or 0,
            level      = tonumber(parts[5]) or 0,
            slots      = tonumber(parts[6]) or 0,
            points     = tonumber(parts[7]) or 0,
            used       = tonumber(parts[8]) or 0,
            usedPoints = tonumber(parts[9]) or 0,
            out        = (tonumber(parts[10]) or 0) == 1,
        };

        return;
    end

    if (kind == 's' and staging ~= nil and staging.set ~= nil) then
        for _, id in ipairs(numbers(parts[2])) do
            if (id > 0) then
                staging.set:append(id);
            end
        end

        return;
    end

    if (kind == 'k' and staging ~= nil and staging.known ~= nil) then
        for entry in string.gmatch(parts[2] or '', '[^,]+') do
            local id, level, points, kindLetter = entry:match('^(%d+):(%d+):(%d+):(%a)$');

            if (id ~= nil) then
                staging.known:append({
                    id     = tonumber(id),
                    level  = tonumber(level),
                    points = tonumber(points),
                    kind   = kindLetter,
                });
            end
        end

        return;
    end

    -- Automaton: header, equipped, capacity, frames, heads, unlocked (packed).
    if (kind == 'p' and staging ~= nil and staging.frames ~= nil) then
        staging.header = {
            charid  = tonumber(parts[2]) or 0,
            name    = parts[3] or '?',
            job     = tonumber(parts[4]) or 0,
            level   = tonumber(parts[5]) or 0,
            frame   = tonumber(parts[6]) or 0x20,
            head    = tonumber(parts[7]) or 0x01,
            active  = (tonumber(parts[8]) or 0) == 1,
            out     = (tonumber(parts[9]) or 0) == 1,
            petname = parts[10] or '',
        };

        return;
    end

    -- The equipped list is l| (loadout): e| is the family's refusal record.
    if (kind == 'l' and staging ~= nil and staging.attachments ~= nil) then
        staging.attachments = numbers(parts[2]);

        return;
    end

    if (kind == 'q' and staging ~= nil and staging.capacity ~= nil) then
        staging.capacity = numbers(parts[2]);

        return;
    end

    if ((kind == 'f' or kind == 'h') and staging ~= nil and staging.frames ~= nil) then
        local row = {
            id       = tonumber(parts[2]) or 0,
            unlocked = (tonumber(parts[3]) or 0) == 1,
            name     = parts[4] or '',
            elements = numbers(parts[5]),
        };

        if (kind == 'f') then
            staging.frames:append(row);
        else
            staging.heads:append(row);
        end

        return;
    end

    if (kind == 'a' and staging ~= nil and staging.unlocked ~= nil) then
        for entry in string.gmatch(parts[2] or '', '[^,]+') do
            local id, hex = entry:match('^(%d+):(%x+)$');

            if (id ~= nil) then
                local slots    = tonumber(hex, 16) or 0;
                local elements = T{ };

                for element = 1, 8 do
                    elements[element] = bit.band(bit.rshift(slots, (element - 1) * 4), 0xF);
                end

                staging.unlocked:append({ id = tonumber(id), slots = slots, elements = elements });
            end
        end

        return;
    end

    -- Corsairs: a roll a member can press, a double-up window, a roll on
    -- the player.
    if (kind == 'r' and staging ~= nil and staging.members ~= nil) then
        local charid = tonumber(parts[2]) or 0;

        if (staging.members[charid] == nil) then
            staging.members[charid] = T{ rolls = T{ }, tricks = T{ } };
        end

        local row = { id = tonumber(parts[3]) or 0, name = prettify(parts[4] or ''), raw = parts[4] or '' };

        if ((parts[5] or 'r') == 'r') then
            staging.members[charid].rolls:append(row);
        else
            staging.members[charid].tricks:append(row);
        end

        return;
    end

    if (kind == 'u' and staging ~= nil and staging.windows ~= nil) then
        staging.windows[tonumber(parts[2]) or 0] = {
            effect    = tonumber(parts[3]) or 0,
            total     = tonumber(parts[4]) or 0,
            remaining = tonumber(parts[5]) or 0,
        };

        return;
    end

    if (kind == 'o' and staging ~= nil and staging.active ~= nil) then
        staging.active:append({
            effect    = tonumber(parts[2]) or 0,
            name      = parts[3] or '?',
            total     = tonumber(parts[4]) or 0,
            remaining = tonumber(parts[5]) or 0,
            caster    = parts[6] or '',
        });

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Any line whose sender is _DWKDATA is
* ours: consumed and blocked before parsing, so a malformed record cannot
* leak as chat noise.
--]]
ashita.events.register('packet_in', 'dwtoau_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwtoau'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering
--]]

local function jobLabel(row)
    local names = { [JOB_BLU] = 'BLU', [JOB_COR] = 'COR', [JOB_PUP] = 'PUP' };
    local main  = names[row.mjob] or string.format('job %d', row.mjob);

    if (row.sjob == 0 or row.slvl == 0) then
        return string.format('%s%d', main, row.mlvl);
    end

    local sub = names[row.sjob] or string.format('job %d', row.sjob);

    return string.format('%s%d/%s%d', main, row.mlvl, sub, row.slvl);
end

-- The character combo shared by the two builder tabs: characters ON the
-- job first, the rest greyed with the reason.
local function characterPicker(id, jobId, picked, onPick)
    local current = picked ~= nil and charOf(picked) or nil;
    local label   = current ~= nil and string.format('%s (%s)', current.name, jobLabel(current)) or 'Pick a character...';

    imgui.SetNextItemWidth(240);

    if (imgui.BeginCombo('##dwtoau_pick_' .. id, label)) then
        for _, row in ipairs(state.chars) do
            local eligible = onJob(row, jobId) and not row.self;
            local text     = string.format('%s  %s%s', row.name, jobLabel(row),
                row.self and '  (you -- use the game menu)' or (eligible and '' or '  (not on this job -- /jobs)'));

            if (not eligible) then imgui.BeginDisabled(); end

            if (imgui.Selectable(string.format('%s##dwtoau_pick_%s_%d', text, id, row.charid), picked == row.charid)) then
                onPick(row.charid);
            end

            if (not eligible) then imgui.EndDisabled(); end
        end

        imgui.EndCombo();
    end
end

local function statusLine()
    if (state.pending ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled('applying...');
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end
end

--[[
* Blue Mage tab.
--]]
local function bluePointsUsed()
    local points = 0;

    for _, id in ipairs(state.bluWork) do
        local row = state.blu and state.blu.byId[id] or nil;

        points = points + (row and row.points or 0);
    end

    return points;
end

local function blueHas(id)
    for _, existing in ipairs(state.bluWork) do
        if (existing == id) then
            return true;
        end
    end

    return false;
end

local function blueRemove(id)
    for index, existing in ipairs(state.bluWork) do
        if (existing == id) then
            table.remove(state.bluWork, index);
            state.bluDirty = true;

            return;
        end
    end
end

local function blueAdd(id)
    if (blueHas(id)) then
        return;
    end

    state.bluWork:append(id);
    state.bluDirty = true;
end

local function applyBlue()
    if (state.bluPick == nil) then
        return;
    end

    local ids = T{ };

    for _, id in ipairs(state.bluWork) do
        ids:append(tostring(id));
    end

    sendWrite('bluset', state.bluPick, string.format('bluset %d %s', state.bluPick, #ids > 0 and table.concat(ids, ',') or '0'));
end

local function blueTab()
    characterPicker('blu', JOB_BLU, state.bluPick, function (charid)
        if (state.bluPick ~= charid) then
            state.bluPick  = charid;
            state.blu      = nil;
            state.bluWork  = T{ };
            state.bluDirty = false;

            requestBlue();
        end
    end);

    imgui.SameLine();
    imgui.TextDisabled('Spells anyone on your account has learned are known to every squad member.');

    if (state.bluPick == nil) then
        imgui.TextDisabled('Pick a squad blue mage. A character not on BLU is set from /jobs first.');

        return;
    end

    if (state.blu == nil) then
        imgui.TextDisabled('Fetching the blue magic list from the server...');

        return;
    end

    local header = state.blu.header;
    local used   = bluePointsUsed();
    local slots  = #state.bluWork;

    imgui.Text(string.format('%s -- BLU%d (%s job)', header.name, header.level, header.job == 1 and 'main' or (header.job == 2 and 'support' or 'not set')));
    imgui.SameLine();

    if (header.out) then
        imgui.TextColored(theme.colors.info, '[out in your party: an Apply re-arms it on the spot]');
    end

    local slotFraction  = header.slots > 0 and (slots / header.slots) or 0;
    local pointFraction = header.points > 0 and (used / header.points) or 0;

    imgui.ProgressBar(math.min(slotFraction, 1), { 220, 16 }, string.format('Slots  %d / %d', slots, header.slots));
    imgui.SameLine();
    imgui.ProgressBar(math.min(pointFraction, 1), { 220, 16 }, string.format('Set points  %d / %d', used, header.points));
    imgui.SameLine();

    local canApply = state.pending == nil and state.bluDirty and slots <= header.slots and used <= header.points;

    if (not canApply) then imgui.BeginDisabled(); end

    if (imgui.Button('Apply##dwtoau_blu_apply', { 70, 0 })) then
        applyBlue();
    end

    if (not canApply) then imgui.EndDisabled(); end

    imgui.SameLine();

    if (not state.bluDirty) then imgui.BeginDisabled(); end

    if (imgui.Button('Revert##dwtoau_blu_revert', { 70, 0 })) then
        state.bluWork = T{ };

        for _, id in ipairs(state.blu.set) do
            state.bluWork:append(id);
        end

        state.bluDirty = false;
    end

    if (not state.bluDirty) then imgui.EndDisabled(); end

    if (state.bluDirty) then
        imgui.SameLine();
        imgui.TextColored(theme.colors.warn, 'unsaved');
    end

    if (slots > header.slots or used > header.points) then
        imgui.TextColored(theme.colors.err, 'Over budget -- the server would refuse this set. Remove something.');
    end

    imgui.Separator();

    -- Left: the set. Right: everything known, filtered.
    if (imgui.BeginChild('##dwtoau_blu_set', { 250, -1 }, ImGuiChildFlags_None)) then
        imgui.TextDisabled(string.format('Set (%d):', slots));

        if (#state.bluWork == 0) then
            imgui.TextDisabled('Nothing set. Add spells from the right.');
        end

        for _, id in ipairs(state.bluWork) do
            local row = state.blu.byId[id];

            if (imgui.SmallButton(string.format('x##dwtoau_blu_rm_%d', id))) then
                blueRemove(id);
            end

            imgui.SameLine();
            imgui.Text(string.format('%s  (%d)', spellName(id), row and row.points or 0));

            if (imgui.IsItemHovered() and row ~= nil) then
                spellCard(row);
            end
        end

        -- What the working set earns, trait by trait (the catalog's numbers).
        local progress = traitProgress(state.bluWork);

        if (#progress > 0) then
            imgui.Separator();
            imgui.TextDisabled('Job traits from this set:');

            for _, line in ipairs(progress) do
                if (line.reached) then
                    imgui.TextColored(theme.colors.ok, line.text);
                else
                    imgui.TextDisabled(line.text);
                end
            end
        elseif (#state.bluWork > 0 and not haveCatalog) then
            imgui.Separator();
            imgui.TextDisabled('(bluecatalog.lua missing: trait progress unavailable)');
        end
    end

    imgui.EndChild();
    imgui.SameLine();

    if (imgui.BeginChild('##dwtoau_blu_known', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.SetNextItemWidth(160);
        imgui.InputTextWithHint('##dwtoau_blu_filter', 'filter...', state.bluFilter, 48);
        imgui.SameLine();
        imgui.SetNextItemWidth(110);

        local kindLabel = state.bluKind[1] == 1 and 'All kinds' or KINDS[KIND_ORDER[state.bluKind[1] - 1]];

        if (imgui.BeginCombo('##dwtoau_blu_kind', kindLabel)) then
            if (imgui.Selectable('All kinds##dwtoau_blu_kind_0', state.bluKind[1] == 1)) then
                state.bluKind[1] = 1;
            end

            for i, letter in ipairs(KIND_ORDER) do
                if (imgui.Selectable(string.format('%s##dwtoau_blu_kind_%d', KINDS[letter], i), state.bluKind[1] == i + 1)) then
                    state.bluKind[1] = i + 1;
                end
            end

            imgui.EndCombo();
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('%d known', #state.blu.known));

        local filter = state.bluFilter[1]:lower();
        local wanted = state.bluKind[1] > 1 and KIND_ORDER[state.bluKind[1] - 1] or nil;

        if (imgui.BeginTable('##dwtoau_blu_table', 5, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
            imgui.TableSetupColumn('Spell', ImGuiTableColumnFlags_WidthStretch, 0, 0);
            imgui.TableSetupColumn('Lv', ImGuiTableColumnFlags_WidthFixed, 34, 0);
            imgui.TableSetupColumn('Pts', ImGuiTableColumnFlags_WidthFixed, 34, 0);
            imgui.TableSetupColumn('Kind', ImGuiTableColumnFlags_WidthFixed, 64, 0);
            imgui.TableSetupColumn('Set', ImGuiTableColumnFlags_WidthFixed, 44, 0);
            imgui.TableHeadersRow();

            for _, row in ipairs(state.blu.known) do
                local name = spellName(row.id);
                local show = (filter == '' or name:lower():find(filter, 1, true) ~= nil)
                    and (wanted == nil or row.kind == wanted);

                if (show) then
                    imgui.TableNextRow();
                    imgui.TableNextColumn();

                    local tooHigh = row.level > header.level;

                    if (tooHigh) then
                        imgui.TextDisabled(name);
                    else
                        imgui.Text(name);
                    end

                    -- The hover card on the name (owner request 2026-09-03):
                    -- description, stat bonuses, job trait, level, MP, points.
                    if (imgui.IsItemHovered()) then
                        spellCard(row);
                    end

                    imgui.TableNextColumn();
                    imgui.Text(tostring(row.level));
                    imgui.TableNextColumn();
                    imgui.Text(tostring(row.points));
                    imgui.TableNextColumn();
                    imgui.Text(KINDS[row.kind] or row.kind);
                    imgui.TableNextColumn();

                    if (blueHas(row.id)) then
                        if (imgui.SmallButton(string.format('Unset##dwtoau_blu_u_%d', row.id))) then
                            blueRemove(row.id);
                        end
                    else
                        local canAdd = not tooHigh and slots < header.slots and used + row.points <= header.points;

                        if (not canAdd) then imgui.BeginDisabled(); end

                        if (imgui.SmallButton(string.format('Set##dwtoau_blu_a_%d', row.id))) then
                            blueAdd(row.id);
                        end

                        if (not canAdd) then imgui.EndDisabled(); end
                    end
                end
            end

            imgui.EndTable();
        end
    end

    imgui.EndChild();
end

--[[
* Puppetmaster tab.
--]]
local function partRow(list, id)
    for _, row in ipairs(list) do
        if (row.id == id) then
            return row;
        end
    end

    return nil;
end

-- The working build's capacity (frame + head nibbles) and load (the
-- attachments' nibbles), per element.
local function pupBudget()
    local capacity = T{ };
    local load     = T{ };

    local frame = partRow(state.pup.frames, state.pupWork.frame);
    local head  = partRow(state.pup.heads, state.pupWork.head);

    for element = 1, 8 do
        capacity[element] = ((frame and frame.elements[element]) or 0) + ((head and head.elements[element]) or 0);
        load[element]     = 0;
    end

    for slot = 1, ATTACHMENT_SLOTS do
        local id = state.pupWork.attachments[slot];

        if (id ~= 0) then
            local row = state.pup.unlockedById[id];

            if (row ~= nil) then
                for element = 1, 8 do
                    load[element] = load[element] + (row.elements[element] or 0);
                end
            end
        end
    end

    return capacity, load;
end

local function pupHas(id)
    for slot = 1, ATTACHMENT_SLOTS do
        if (state.pupWork.attachments[slot] == id) then
            return slot;
        end
    end

    return nil;
end

local function pupFits(row, capacity, load)
    for element = 1, 8 do
        if (load[element] + (row.elements[element] or 0) > capacity[element]) then
            return false;
        end
    end

    return true;
end

local function pupOverloaded(capacity, load)
    for element = 1, 8 do
        if (load[element] > capacity[element]) then
            return true;
        end
    end

    return false;
end

local function pupFreeSlot()
    for slot = 1, ATTACHMENT_SLOTS do
        if (state.pupWork.attachments[slot] == 0) then
            return slot;
        end
    end

    return nil;
end

local function applyPup()
    if (state.pupPick == nil or state.pupWork == nil) then
        return;
    end

    local ids = T{ };

    for slot = 1, ATTACHMENT_SLOTS do
        ids:append(tostring(state.pupWork.attachments[slot] or 0));
    end

    sendWrite('pupset', state.pupPick, string.format('pupset %d %d %d %s', state.pupPick, state.pupWork.frame, state.pupWork.head, table.concat(ids, ',')));
end

local function partPicker(id, list, picked, onPick)
    local current = partRow(list, picked);
    local label   = current ~= nil and itemName(PART_BASE + current.id, prettify(current.name)) or '?';

    imgui.SetNextItemWidth(190);

    if (imgui.BeginCombo('##dwtoau_pup_' .. id, label)) then
        for _, row in ipairs(list) do
            local name = itemName(PART_BASE + row.id, prettify(row.name));

            if (not row.unlocked) then imgui.BeginDisabled(); end

            if (imgui.Selectable(string.format('%s%s##dwtoau_pup_%s_%d', name, row.unlocked and '' or '  (not unlocked)', id, row.id), picked == row.id)) then
                onPick(row.id);
            end

            if (not row.unlocked) then imgui.EndDisabled(); end
        end

        imgui.EndCombo();
    end
end

local function pupTab()
    characterPicker('pup', JOB_PUP, state.pupPick, function (charid)
        if (state.pupPick ~= charid) then
            state.pupPick  = charid;
            state.pup      = nil;
            state.pupWork  = nil;
            state.pupDirty = false;

            requestPup();
        end
    end);

    imgui.SameLine();
    imgui.TextDisabled('Parts anyone on your account has unlocked equip every squad member.');

    if (state.pupPick == nil) then
        imgui.TextDisabled('Pick a squad puppetmaster. A character not on PUP is set from /jobs first.');

        return;
    end

    if (state.pup == nil or state.pupWork == nil) then
        imgui.TextDisabled('Fetching the automaton from the server...');

        return;
    end

    local header = state.pup.header;

    imgui.Text(string.format('%s -- PUP%d%s', header.name, header.level, header.petname ~= '' and ('  --  ' .. header.petname) or ''));
    imgui.SameLine();

    if (header.active) then
        imgui.TextColored(theme.colors.warn, '[automaton ACTIVE -- deactivate to equip]');
        imgui.SameLine();

        local canOff = state.pending == nil;

        if (not canOff) then imgui.BeginDisabled(); end

        if (imgui.Button('Deactivate##dwtoau_pup_off', { 90, 0 })) then
            sendWrite('pupoff', state.pupPick, string.format('pupoff %d', state.pupPick));
        end

        if (not canOff) then imgui.EndDisabled(); end
    elseif (header.out) then
        imgui.TextColored(theme.colors.info, '[out in your party: the squad activates the new build on its own]');
    end

    partPicker('frame', state.pup.frames, state.pupWork.frame, function (id)
        state.pupWork.frame = id;
        state.pupDirty      = true;
    end);

    imgui.SameLine();

    partPicker('head', state.pup.heads, state.pupWork.head, function (id)
        state.pupWork.head = id;
        state.pupDirty     = true;
    end);

    local capacity, load = pupBudget();
    local overloaded     = pupOverloaded(capacity, load);

    imgui.SameLine();

    local canApply = state.pending == nil and state.pupDirty and not overloaded and not header.active;

    if (not canApply) then imgui.BeginDisabled(); end

    if (imgui.Button('Apply##dwtoau_pup_apply', { 70, 0 })) then
        applyPup();
    end

    if (not canApply) then imgui.EndDisabled(); end

    imgui.SameLine();

    if (not state.pupDirty) then imgui.BeginDisabled(); end

    if (imgui.Button('Revert##dwtoau_pup_revert', { 70, 0 })) then
        commitPup(T{
            header      = state.pup.header,
            attachments = state.pup.attachments,
            capacity    = state.pup.capacity,
            frames      = state.pup.frames,
            heads       = state.pup.heads,
            unlocked    = state.pup.unlocked,
        });
    end

    if (not state.pupDirty) then imgui.EndDisabled(); end

    if (state.pupDirty) then
        imgui.SameLine();
        imgui.TextColored(theme.colors.warn, 'unsaved');
    end

    -- The eight capacity bars, two rows of four.
    for element = 1, 8 do
        local fraction = capacity[element] > 0 and (load[element] / capacity[element]) or (load[element] > 0 and 1 or 0);

        imgui.ProgressBar(math.min(fraction, 1), { 118, 14 }, string.format('%s %d/%d', ELEMENTS[element], load[element], capacity[element]));

        if (element % 4 ~= 0) then
            imgui.SameLine();
        end
    end

    if (overloaded) then
        imgui.TextColored(theme.colors.err, 'Over capacity -- the server would refuse this build. Change the frame or head, or remove a part.');
    end

    imgui.Separator();

    if (imgui.BeginChild('##dwtoau_pup_slots', { 260, -1 }, ImGuiChildFlags_None)) then
        imgui.TextDisabled('Attachments (12 slots):');

        for slot = 1, ATTACHMENT_SLOTS do
            local id = state.pupWork.attachments[slot];

            if (id == 0) then
                imgui.TextDisabled(string.format('%2d  --', slot));
            else
                if (imgui.SmallButton(string.format('x##dwtoau_pup_rm_%d', slot))) then
                    state.pupWork.attachments[slot] = 0;
                    state.pupDirty = true;
                end

                imgui.SameLine();
                imgui.Text(string.format('%2d  %s', slot, attachmentName(id)));

                local row = state.pup.unlockedById[id];

                if (imgui.IsItemHovered() and row ~= nil) then
                    local costs = T{ };

                    for element = 1, 8 do
                        if ((row.elements[element] or 0) > 0) then
                            costs:append(string.format('%s %d', ELEMENTS[element], row.elements[element]));
                        end
                    end

                    imgui.SetTooltip(#costs > 0 and table.concat(costs, ', ') or 'no element cost');
                end
            end
        end
    end

    imgui.EndChild();
    imgui.SameLine();

    if (imgui.BeginChild('##dwtoau_pup_unlocked', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.SetNextItemWidth(160);
        imgui.InputTextWithHint('##dwtoau_pup_filter', 'filter...', state.pupFilter, 48);
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d unlocked on the account', #state.pup.unlocked));

        local filter = state.pupFilter[1]:lower();
        local free   = pupFreeSlot();

        if (imgui.BeginTable('##dwtoau_pup_table', 3, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
            imgui.TableSetupColumn('Attachment', ImGuiTableColumnFlags_WidthStretch, 0, 0);
            imgui.TableSetupColumn('Cost', ImGuiTableColumnFlags_WidthFixed, 110, 0);
            imgui.TableSetupColumn('Equip', ImGuiTableColumnFlags_WidthFixed, 54, 0);
            imgui.TableHeadersRow();

            for _, row in ipairs(state.pup.unlocked) do
                local name = attachmentName(row.id);

                if (filter == '' or name:lower():find(filter, 1, true) ~= nil) then
                    imgui.TableNextRow();
                    imgui.TableNextColumn();
                    imgui.Text(name);
                    imgui.TableNextColumn();

                    local costs = T{ };

                    for element = 1, 8 do
                        if ((row.elements[element] or 0) > 0) then
                            costs:append(string.format('%s %d', ELEMENTS[element]:sub(1, 3), row.elements[element]));
                        end
                    end

                    imgui.Text(#costs > 0 and table.concat(costs, ' ') or '-');
                    imgui.TableNextColumn();

                    local held = pupHas(row.id);

                    if (held ~= nil) then
                        if (imgui.SmallButton(string.format('Off##dwtoau_pup_u_%d', row.id))) then
                            state.pupWork.attachments[held] = 0;
                            state.pupDirty = true;
                        end
                    else
                        local canAdd = free ~= nil and pupFits(row, capacity, load);

                        if (not canAdd) then imgui.BeginDisabled(); end

                        if (imgui.SmallButton(string.format('On##dwtoau_pup_a_%d', row.id))) then
                            state.pupWork.attachments[free] = row.id;
                            state.pupDirty = true;
                        end

                        if (not canAdd) then imgui.EndDisabled(); end
                    end
                end
            end

            imgui.EndTable();
        end
    end

    imgui.EndChild();
end

--[[
* Corsair tab: every corsair out, its rolls as buttons, the rolls on you.
* Re-asked every few seconds while the tab is showing -- a roll has a
* clock, and the numbers on it move.
--]]
local COR_REFRESH = 8.0;

local function secondsLeft(remaining)
    return math.max(remaining - math.floor(os.clock() - state.cor.at), 0);
end

local function corTab()
    if (os.clock() - state.corAsked >= COR_REFRESH and not serverSilent) then
        requestCor();
    end

    local any = false;

    for _, row in ipairs(state.chars) do
        local member = state.cor.members[row.charid];

        if (member ~= nil) then
            any = true;

            imgui.Text(string.format('%s  (!%s)', row.name, row.tag));

            local window = state.cor.windows[row.charid];

            if (window ~= nil) then
                imgui.SameLine();
                imgui.TextColored(theme.colors.info, string.format('Double-Up open: %d, %ds left', window.total, secondsLeft(window.remaining)));
            end

            local canPress = state.pending == nil;

            if (not canPress) then imgui.BeginDisabled(); end

            local column = 0;

            for _, roll in ipairs(member.rolls) do
                if (column > 0) then
                    imgui.SameLine();
                end

                if (imgui.Button(string.format('%s##dwtoau_roll_%d_%d', roll.name, row.charid, roll.id), { 130, 0 })) then
                    sendWrite('roll', row.charid, string.format('roll %d %d', row.charid, roll.id));
                end

                column = (column + 1) % 4;
            end

            if (#member.rolls == 0) then
                imgui.TextDisabled('  no rolls learned yet');
            end

            if (#member.tricks > 0) then
                column = 0;

                for _, trick in ipairs(member.tricks) do
                    if (column > 0) then
                        imgui.SameLine();
                    end

                    if (imgui.SmallButton(string.format('%s##dwtoau_trick_%d_%d', trick.name, row.charid, trick.id))) then
                        sendWrite('roll', row.charid, string.format('roll %d %d', row.charid, trick.id));
                    end

                    column = (column + 1) % 6;
                end
            end

            if (not canPress) then imgui.EndDisabled(); end

            imgui.Separator();
        end
    end

    if (not any) then
        imgui.TextDisabled('No corsair is out in your squad. Call one from /squad, then look here.');
        imgui.Separator();
    end

    imgui.TextDisabled('On you right now:');

    if (#state.cor.active == 0) then
        imgui.TextDisabled('  no rolls');
    end

    for _, roll in ipairs(state.cor.active) do
        local left = secondsLeft(roll.remaining);
        local line = string.format('  %s %d  --  %d:%02d left%s', roll.name, roll.total, math.floor(left / 60), left % 60,
            roll.caster ~= '' and ('  (' .. roll.caster .. ')') or '');

        if (roll.name:lower():find('bust', 1, true) ~= nil) then
            imgui.TextColored(theme.colors.err, line);
        elseif (roll.total == 11) then
            imgui.TextColored(theme.colors.ok, line);
        else
            imgui.Text(line);
        end
    end
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        serverSilent = false;

        forget();
        requestSync();
        requestBlue();
        requestPup();
        requestCor();
    end

    imgui.SameLine();
    imgui.TextDisabled('The ToAU job kit: what a squad member cannot set for itself.');

    statusLine();
    imgui.Separator();

    if (imgui.BeginTabBar('##dwtoau_tabs')) then
        if (imgui.BeginTabItem('Blue Mage')) then
            blueTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Puppetmaster')) then
            pupTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Corsair')) then
            corTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake in it costs one frame rather than
* the addon; Begin/End and theme push/pop stay outside the pcall so both
* stacks stay balanced whatever happens in between (dwbags' shape).
--]]
ashita.events.register('d3d_present', 'dwtoau_present', function ()
    checkAnswers();
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 720, 540 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dw windows fused into an unthemed dock once; never again.
    local visible = imgui.Begin('DriftwoodXI ToAU Job Kit##dwtoau', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwtoau'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwtoau'):append(chat.message('Window closed. `!toau` typed by hand does the same jobs.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening always resyncs: a set as it stood before the
* last Apply is the quiet kind of wrong this project exists to rule out.
--]]
local function toggleWindow()
    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
        serverSilent   = false;

        forget();
        requestSync();
        requestBlue();
        requestPup();
        requestCor();
    end
end

ashita.events.register('command', 'dwtoau_command', function (e)
    local args  = e.command:args();
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwtoau' and first ~= '/toau' and first ~= '/dwk') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        serverSilent = false;

        forget();
        requestSync();
        requestBlue();
        requestPup();
        requestCor();

        return;
    end

    toggleWindow();
end);

--[[
* Zoning invalidates who is out and what is active; the working copies are
* kept (an unsaved set survives a zone line), the pending write is not.
--]]
ashita.events.register('packet_in', 'dwtoau_zonein', function (e)
    if (e.id == 0x000A) then
        state.pending = nil;

        forget();

        if (state.open[1] and not serverSilent) then
            requestSync();
            requestCor();
        end
    end
end);

--[[
* Watch what the player sends. Bare `!toau` toggles this window instead of
* going to the server -- the typed verb is a door, not a dead end; any
* `!toau <verb>` line still passes through untouched. Every other outgoing
* line stamps the throttle so a queued query never races something the
* player typed.
--]]
ashita.events.register('packet_out', 'dwtoau_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!toau' or lower == '!toau ui' or lower == '!toau window' or lower == '!toau gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwk') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwtoau_load', function ()
    print(chat.header('dwtoau'):append(chat.message('/toau or /dwtoau opens the ToAU job kit -- set a squad blue mage\'s spells, build a puppetmaster\'s automaton, press a corsair\'s rolls.')));
end);
