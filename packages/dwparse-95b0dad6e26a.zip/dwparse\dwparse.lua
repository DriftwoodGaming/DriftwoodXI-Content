--[[
* DriftwoodXI -- dwparse
*
* A damage and healing parser for the party on screen: every action the server
* announces, broken down per actor, with the numbers a player tunes a setup by
* -- DPS, accuracy, crit rate, max hit, healing output -- and an Export button
* that speaks the result into chat for the rest of the party.
*
* THE PARSE ONLY LISTENS. It decodes GP_SERV_COMMAND_BATTLE2 (0x0028), the
* packet the client itself renders the combat log from, and never blocks or
* rewrites anything -- the Export text goes out as ordinary typed chat through
* the same throttled queue dwbags uses. Turn it off and the game is exactly as
* it was.
*
* THE THREAT TAB IS THE ONE EXCEPTION (1.1.0), because it has to be: enmity
* does not exist client-side in any form -- no packet has ever described CE or
* VE -- so no amount of listening can produce a threat meter, and a simulated
* one drifts within a fight. The server states the real numbers instead:
* `!dwe hello` (sent lazily, the first time the Threat tab is looked at in a
* zone -- never on zone-in, so this addon takes no ZONE_ORDER slot) arms a
* per-session feed, and modules/driftwoodxi/cpp/threat_data.cpp pushes the
* top enmity holders of the current target as _DWEDATA records this addon
* parses and blocks. Protocol 1, hard-refused if unknown, re-probed on the
* zone line -- the whole dw-suite discipline, inherited in one tab.
*
* THE WIRE FORMAT IS THE SERVER'S OWN. The bit layout below mirrors
* GP_SERV_COMMAND_BATTLE2::pack in src/map/packets/s2c/0x028_battle2.cpp and
* the message ids come from src/map/enums/msg_basic.h -- this addon runs
* against DriftwoodXI and nothing else, so the server source is ground truth
* and no guessing against retail captures was involved. If the pack order ever
* changes, change it here in the same commit.
*
* ROWS ARE KEYED BY NAME, NOT BY ENTITY ID, and that is the feature. A squad
* member dismissed and re-called comes back as a brand new entity with a brand
* new id; a zone line renumbers everybody. The name survives both, so the
* parse does too: it accumulates until the Reset button (or /parse reset)
* clears it, across zones and across recalls. Pets ride under their own name
* tagged with their owner's -- "Carbuncle (Ayla)" -- so a summoner's output
* reads as two honest rows rather than one muddled one.
*
* WHAT COUNTS AS WHAT. Damage is anything the server said dealt points of
* damage, skillchains included (they arrive as an additional-effect block on
* the closing weaponskill and are credited to its actor). Drains count as
* damage only -- the self-heal half is not added to healing, so the Healing
* tab stays an honest measure of restorative output. Healing is what the
* server said was recovered; overcure is invisible on the wire (the server
* already reports the capped number), so what you see is HP that landed.
*
* WHO IS TRACKED. By default only the party and its pets earn rows -- on this
* server that means you, your squad, and anything you summon. Untick "Party
* only" and every actor in range is tracked, mobs included. The Taken tab is
* always about party members, whoever was hitting them.
*
* NOTHING DERIVED IS COMPUTED TWICE (1.2.0). The tallies move when a packet
* arrives -- a few times a second in a busy fight -- and the window redraws
* sixty times a second, so everything between the two is cached against a
* model revision that only a credit can move: the sorted rows, the totals, the
* formatted numbers, the row labels, the breakdown pane, the action names, the
* threat meter's names. The ONE deliberate exception is the "30s" column,
* which slides with the wall clock and would be a lie about right now if it
* were held.
*
* WHAT PERSISTS, AND WHAT DOES NOT (1.2.0). The settings file per PC holds the
* three choices about how the window is USED -- the Export channel, the "Party
* only" tick, the tab last open. It deliberately does NOT hold Pause (a parser
* that came back paused after a relog would silently miss the fight the player
* logged in for) or the find box (a filter from a session ago reads as an
* empty parse). The tallies themselves have never been persisted and are not
* now: a parse is about a fight, and the fight is over.
--]]

addon.name    = 'dwparse';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.0';
addon.desc    = 'Damage and healing parser for DriftwoodXI. /parse or /dwparse.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local theme    = require('dwtheme');
local echo     = require('dwecho');
local settings = require('settings');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

--[[
* Message ids, from the server's msg_basic.h. Only the ones that carry (or
* deny) an amount matter to a parser; anything not listed is ignored, which is
* also what keeps a server newer than the addon from breaking it -- an unknown
* message is simply not counted rather than being an error.
--]]

-- Main-result damage: the value field is points dealt by the actor.
local DMG = {
    [1]   = true,   -- melee hit
    [67]  = true,   -- melee critical
    [77]  = true,   -- Sange
    [157] = true,   -- Barrage
    [352] = true,   -- ranged hit
    [353] = true,   -- ranged critical
    [576] = true,   -- ranged, squarely
    [577] = true,   -- ranged, strikes true
    [185] = true,   -- skill damage (weaponskills, mob TP moves)
    [187] = true,   -- skill HP drain
    [110] = true,   -- ability damage
    [317] = true,   -- ability damage (Swipe/Lunge family)
    [197] = true,   -- ability damage, resisted
    [2]   = true,   -- magic damage
    [252] = true,   -- magic burst
    [227] = true,   -- magic HP drain
    [274] = true,   -- magic burst HP drain
    [264] = true,   -- <target> takes damage (AoE secondary lines)
};

local CRIT = { [67] = true, [353] = true };

-- The swing happened and connected with nothing: misses, dodges, evades.
local MISS = {
    [15]  = true,   -- melee miss
    [30]  = true,   -- anticipates
    [32]  = true,   -- dodges
    [282] = true,   -- evades
    [354] = true,   -- ranged miss
    [188] = true,   -- skill misses
    [158] = true,   -- ability misses
    [324] = true,   -- ability misses (named target)
};

-- The action landed but was refused: full resists and "no effect". Counted as
-- attempts so a resisted nuke drags the average the way it dragged the fight.
local RESIST = {
    [85]  = true,   -- resists the spell
    [284] = true,   -- resists the effects
    [655] = true,   -- completely resists
    [75]  = true,   -- magic no effect
    [189] = true,   -- skill no effect
    [323] = true,   -- ability no effect
    [355] = true,   -- ranged no effect
};

-- Absorbed by shadows: not a miss (the aim was true) and not damage. Its own
-- count, because eating shadows is exactly what some setups are for.
local SHADOW = { [31] = true };

-- Main-result countering: the TARGET dealt this damage to the actor, so the
-- attribution is inverted relative to every other damage message.
local COUNTER = { [33] = true };

-- Main-result HP healing: the value is HP recovered by the target.
local HEAL = {
    [7]   = true,   -- magic recovers HP (cures)
    [24]  = true,   -- recovers HP (AoE cure secondary lines)
    [102] = true,   -- ability recovers HP
    [103] = true,   -- skill recovers HP (waltzes, chakra family)
    [238] = true,   -- skill recovers HP, AoE
    [263] = true,   -- recovers HP
    [306] = true,   -- item recovers HP
    [318] = true,   -- item recovers HP
    [367] = true,   -- recovers HP
    [587] = true,   -- regains HP
    [382] = true,   -- ranged attack absorbed as HP
};

-- Main-result MP restoration -- a sideline stat, but the one a Ballad or
-- Evoker's setup is judged by.
local HEAL_MP = {
    [224] = true,   -- skill recovers MP
    [225] = true,   -- skill MP drain
    [276] = true,   -- recovers MP
    [366] = true,   -- MP drained
    [588] = true,   -- regains MP
};

-- Additional-effect block: en-spells, drains, and skillchains. Skillchain
-- damage is message 287 + chain id (action.cpp recordSkillchain), so 288-303
-- name the chain that closed.
local PROC_DMG = { [163] = true, [229] = true, [161] = true };
local PROC_HEAL = { [384] = true };
local PROC_MP = { [162] = true };

local SC_NAMES = {
    [288] = 'Light',         [289] = 'Darkness',      [290] = 'Gravitation',
    [291] = 'Fragmentation', [292] = 'Distortion',    [293] = 'Fusion',
    [294] = 'Compression',   [295] = 'Liquefaction',  [296] = 'Induration',
    [297] = 'Reverberation', [298] = 'Transfixion',   [299] = 'Scission',
    [300] = 'Detonation',    [301] = 'Impaction',     [302] = 'Radiance',
    [303] = 'Umbra',
};

-- Reaction block: the target's spikes, counters and retaliations, dealt back
-- onto the actor.
local REACT_DMG = { [44] = true, [132] = true, [33] = true, [536] = true };

--[[
* Parse state. Everything cumulative lives in `parse` and only reset() ever
* replaces it -- deliberately NOT touched by the zone-in packet, which is the
* whole reason this addon exists over /p "what did that hit for?".
*
* `actors` is a PLAIN table keyed by display name. Not T{}: sugar tables
* resolve unknown keys through their method table, and a row keyed by a name
* the player chose must never collide with a method (the dwbags `find` lesson,
* learned so this addon does not have to learn it again).
--]]
local function freshActor(name)
    return {
        name    = name,
        dmg     = { total = 0, max = 0, maxLabel = '' },
        heal    = { total = 0, max = 0, maxLabel = '', mp = 0 },
        taken   = { total = 0, hits = 0, max = 0, maxLabel = '', evades = 0, shadows = 0, healed = 0 },
        actions = {},   -- [label] = { count, landed, total, max, crits, misses, resists, shadows }
        heals   = {},   -- [label] = { count, total, max }
        sources = {},   -- [attacker] = { count, total, max }  (Taken tab detail)
        recent  = {},   -- ring of { t, amount } for the sliding-window DPS
        recentSum = 0,
    };
end

local function freshParse()
    return {
        actors    = {},
        startedAt = nil,    -- os.clock() of the first combat event
        lastAt    = nil,    -- os.clock() of the most recent one
    };
end

local parse = freshParse();

-- The sliding window the "Recent" column reads: long enough to smooth a slow
-- weaponskill cycle, short enough to answer "what am I doing right now".
local RECENT_WINDOW = 30.0;

local state = T{
    open      = T{ false },
    paused    = T{ false },
    partyOnly = T{ true },
    tab       = 'dmg',      -- which tab is on screen; Export exports it
    wantTab   = nil,        -- a tab to select for the player (restored, typed)
    channel   = 1,          -- index into CHANNELS
    selected  = nil,        -- actor name whose breakdown is open
    search    = T{ '' },    -- the find box, shared by the three parse tabs
    status    = 'Parsing. Fight something.',
    statusBad = false,
    statusUntil = nil,      -- os.clock() a transient sentence expires at
    reported  = false,      -- a render error is worth saying once, not per frame
    charName  = nil,        -- who is logged in; a new name resets the parse
    charCheckAt = nil,

    --[[
        The threat wire (1.1.0). `threat` is the committed model the tab
        draws; `threatPending` builds aside between a `d|` and its `z|` so a
        half-arrived reply can never half-fill the meter. `helloed` is "some
        envelope answered this zone", which is what retires the hello clock.
    ]]
    threat        = { mob = nil, rows = {}, events = {} },
    threatRev     = 0,      -- bumped whenever `threat` is REPLACED; the tab's
                            -- view cache keys on it the way the parse tabs key
                            -- on the model revision
    threatIn      = nil,    -- verb of the open _DWEDATA envelope
    threatPending = nil,
    threatAsk     = nil,    -- { at, tries } -- the hello answer clock
    helloed       = false,

    -- An unknown `d|` version was seen: one warning, then silence until the
    -- zone line re-probes it (a map restart is also a login).
    refused       = false,

    -- The hello went unanswered twice, or the server refused the verb: stop
    -- asking for the rest of the zone. An unknown ! command falls through to
    -- PUBLIC /say on a server without dwe.lua, so every un-latched retry is
    -- the player saying `!dwe hello` out loud (the dwfame serverSilent rule).
    threatSilent  = false,
};

--[[
* The status line is one row above the tab bar and it used to be written once
* and never rewritten: "Exporting 5 lines to Party..." was still the headline
* an hour after the export landed, and "Parse cleared." outlived the next
* fight. A sentence about something that HAPPENED expires back to the idle
* line; a sentence about a state that still holds (a server refusal) does not,
* and passes no expiry (the error-banner rule, from the other side).
--]]
local STATUS_LINGER = 12.0;
local IDLE_STATUS   = 'Parsing. Fight something.';

-- The find box's buffer length. A character name is 15 characters and a pet
-- row is its name plus its owner's in brackets, so a name that needs more
-- than this to be told apart does not exist.
local FIND_MAX = 47;

local function setStatus(text, bad, transient)
    state.status      = text;
    state.statusBad   = bad == true;
    state.statusUntil = transient and (os.clock() + STATUS_LINGER) or nil;
end

--[[
* Seconds since a stamp, with a stamp from the FUTURE reading as very old
* rather than very fresh (Phase 2, 2026-09-06). os.clock() on Windows is a
* 32-bit clock_t and goes negative after about 24.8 days of client uptime;
* every one-second cache in this file and the status line's expiry were
* written as `now - stamp`, so one wrap pinned a transient sentence on the
* status line and froze the entity-miss and threat-name caches -- a holder
* who walked back into range stayed "#id" until the next zone line. Erring
* expired is the safe side for every gate here.
--]]
local function elapsed(stamp)
    local now = os.clock();

    if (now < stamp) then
        return math.huge;
    end

    return now - stamp;
end

local CHANNELS = {
    { label = 'Party',     prefix = '/p '    },
    { label = 'Say',       prefix = '/say '  },
    { label = 'Linkshell', prefix = '/l '    },
    { label = 'Echo',      prefix = '/echo ' },
};

--[[
* Settings, per PC (1.2.0). Three choices, and all three are about how the
* window is USED rather than about the fight: which channel Export speaks
* into, whether untracked actors earn rows, and which tab was last open. A
* player who exports to their linkshell exports to their linkshell tomorrow.
*
* DELIBERATELY NOT PERSISTED: Pause -- a parser that came back paused after a
* relog would silently miss exactly the fight the player logged in for -- and
* the find box, because a filter left over from a session ago reads as an
* empty parse rather than as a filter.
*
* KEYS ARE ADDED, NEVER REPURPOSED: a settings file written by an older
* dwparse must still load, and the library fills a missing key from the
* defaults below, so an old file simply gains the new fields at their
* defaults. The load is pcall'd and every field re-checked afterwards: a
* corrupt or hand-edited file must cost the preferences, never the addon.
--]]
local TAB_KEYS = { dmg = true, heal = true, taken = true, threat = true };

local defaultConfig = T{
    channel   = 1,
    partyOnly = true,
    tab       = 'dmg',
};

local config = defaultConfig;

local function sanitiseConfig()
    local repaired = false;

    if (type(config.channel) ~= 'number' or config.channel ~= math.floor(config.channel)
            or config.channel < 1 or config.channel > #CHANNELS) then
        repaired       = repaired or config.channel ~= nil;
        config.channel = 1;
    end

    if (type(config.partyOnly) ~= 'boolean') then
        repaired         = repaired or config.partyOnly ~= nil;
        config.partyOnly = true;
    end

    if (type(config.tab) ~= 'string' or not TAB_KEYS[config.tab]) then
        repaired   = repaired or config.tab ~= nil;
        config.tab = 'dmg';
    end

    return repaired;
end

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

local configRepaired = sanitiseConfig();

local function adoptConfig()
    state.channel      = config.channel;
    state.partyOnly[1] = config.partyOnly;
    state.tab          = config.tab;

    -- Asked for, not asserted: ImGui consumes the "select this tab" flag at
    -- the NEXT BeginTabBar, so the wanted tab is re-asked until it is the one
    -- actually drawing (the dwfishing note).
    state.wantTab      = config.tab;
end

adoptConfig();

-- A character switch hands the library a different file; the window follows
-- it rather than keeping the last character's choices.
pcall(settings.register, 'settings', 'dwparse_settings_update', function (s)
    if (s ~= nil) then
        config = s;

        sanitiseConfig();
        adoptConfig();
    end
end);

local function saveConfig()
    config.channel   = state.channel;
    config.partyOnly = state.partyOnly[1];
    config.tab       = state.tab;

    pcall(settings.save);
end

--[[
* Outgoing chat, one line per interval -- the same queue-and-pump dwbags runs,
* for the same reason: the client rate-limits outgoing chat and answers a
* burst with "A command error occurred" before the server ever sees it. An
* export is up to nine lines and they all have to arrive.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Who earns a row: the party and its pets.
*
* Rebuilt at most once a second rather than per packet -- a melee round from a
* full squad is a stream of 0x0028s and the answer does not change inside a
* second. Keyed by server id, valued with the display name the row should
* carry; a pet's name is tagged with its owner so "Carbuncle" from two
* different summoners stays two rows.
--]]
local trackedCache = { at = 0, ids = {} };

local function trackedSet()
    local now = os.clock();

    if (now - trackedCache.at < 1.0) then
        return trackedCache.ids;
    end

    local ids    = {};
    local party  = AshitaCore:GetMemoryManager():GetParty();
    local entity = AshitaCore:GetMemoryManager():GetEntity();

    if (party ~= nil) then
        for i = 0, 17 do
            if (party:GetMemberIsActive(i) == 1) then
                local sid  = party:GetMemberServerId(i);
                local name = party:GetMemberName(i);

                if (sid ~= nil and sid ~= 0 and name ~= nil and name ~= '') then
                    ids[sid] = name;

                    -- The member's pet, read out of the entity array. Wrapped
                    -- because an index can go stale between the party list and
                    -- the entity read on a zone line.
                    local ok, petIdx = pcall(function ()
                        return entity:GetPetTargetIndex(party:GetMemberTargetIndex(i));
                    end);

                    if (ok and petIdx ~= nil and petIdx > 0) then
                        local petSid  = entity:GetServerId(petIdx);
                        local petName = entity:GetName(petIdx);

                        if (petSid ~= nil and petSid ~= 0 and petName ~= nil and petName ~= '') then
                            ids[petSid] = string.format('%s (%s)', petName, name);
                        end
                    end
                end
            end
        end
    end

    trackedCache.at  = now;
    trackedCache.ids = ids;

    return ids;
end

--[[
* A name for any entity id, party or not -- what the "Party only" untick and
* the Taken tab's attacker column run on.
*
* Dynamic entities (mobs, trusts, pets; id >= 0x1000000) carry their targid
* OFFSET BY 0x100 -- zone_entities.cpp builds the id as
* `0x01000000 | zone << 12 | (targid + 0x0100)` -- so the low twelve bits are
* NOT the index and have to be un-offset the way the server itself does it
* (zoneutils.cpp GetEntity). This comment used to say they "encode their own
* index", and the code below believed it. The lookup is still direct and NEVER
* cached: a dismissed trust's index is reused by the next spawn under the same
* id, and the current occupant's name is the correct answer at event time.
* Player-range ids carry no index, so those are found by scan and cached,
* verified before reuse.
*
* THE SCAN THAT FINDS NOTHING IS THE EXPENSIVE ONE (1.2.0). A hit is cached
* and never walked again; a MISS -- a player-range id whose entity is not in
* the client's array, which is what an actor out of range looks like -- read
* 1280 entity slots and cached nothing, so the next packet from the same
* stranger walked all 1280 again. The misses are remembered for a second, the
* same window trackedSet rebuilds on, and the whole table is dropped rather
* than aged per key so it cannot grow past one second's worth of strangers.
--]]
local playerIdCache = {};
local playerMiss    = { at = 0, ids = {} };
local MISS_WINDOW   = 1.0;

local function entityName(sid)
    if (sid == nil or sid == 0) then
        return nil;
    end

    local entity = AshitaCore:GetMemoryManager():GetEntity();

    if (sid >= 0x1000000) then
        local idx = sid % 0x1000;

        -- Un-offset exactly as zoneutils.cpp does. Dynamic targids start at
        -- 0x700, so the stored value lands in [0x800, 0x9FF] and static ids
        -- stop below 0x700 -- the ranges cannot overlap, so the test is
        -- unambiguous. The upper bound covers the zone's overflow escape
        -- (targid = 0x900), which would otherwise index one past the end of
        -- the client's 0x900-entry array.
        if (idx >= 0x800) then
            idx = idx - 0x100;
        end

        if (idx <= 0x8FF and entity:GetServerId(idx) == sid) then
            local name = entity:GetName(idx);

            return (name ~= nil and name ~= '') and name or nil;
        end

        return nil;
    end

    local cached = playerIdCache[sid];

    if (cached ~= nil and entity:GetServerId(cached) == sid) then
        local name = entity:GetName(cached);

        return (name ~= nil and name ~= '') and name or nil;
    end

    if (elapsed(playerMiss.at) >= MISS_WINDOW) then
        playerMiss.at  = os.clock();
        playerMiss.ids = {};
    elseif (playerMiss.ids[sid]) then
        return nil;
    end

    for idx = 0x400, 0x8FF do
        if (entity:GetServerId(idx) == sid) then
            playerIdCache[sid] = idx;

            local name = entity:GetName(idx);

            return (name ~= nil and name ~= '') and name or nil;
        end
    end

    playerMiss.ids[sid] = true;

    return nil;
end

--[[
* The threat wire (1.1.0). Sender _DWEDATA, protocol 1, records one per 0x017
* line: `d|1|threat`, `t|<targid>` naming the mob (0 = nothing to show),
* `n|<serverid>:<ce+ve>,...` rows ranked by the server, `z|threat`. Names are
* DELIBERATELY NOT ON THE WIRE -- the ids resolve through the same party
* memory and entity array the parse rows already use, so the meter and the
* parse can never disagree about who somebody is.
--]]
local DATA_SENDER = '_DWEDATA';

-- Protocol version the server announces in its `d|` record. An unknown one is
-- HARD REFUSED (one warning, then silence until the zone line): a bar drawn
-- from a layout this addon does not understand is a lie about who has aggro.
local PROTOCOL = 1;

-- The hello answer clock: one retry, then the silent latch. The same numbers
-- every asking sibling uses (dwfame's ANSWER_TIMEOUT/ANSWER_TRIES).
local HELLO_TIMEOUT = 5.0;
local HELLO_TRIES   = 2;

local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* Ask for the feed, lazily: called every frame the Threat tab is ON SCREEN and
* nothing else, so a player who never opens the tab never handshakes and the
* server never walks their enmity. One ask, one retry on a five-second clock,
* then the silent latch -- and the clock never ages while the client is
* zoning, because a held queue is not an unanswered server.
--]]
local function needThreat()
    if (state.refused or state.threatSilent or state.helloed) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local ask = state.threatAsk;

    if (ask == nil) then
        state.threatAsk = { at = os.clock(), tries = 1 };

        issue('!dwe hello');

        return;
    end

    if (os.clock() - ask.at < HELLO_TIMEOUT) then
        return;
    end

    if (ask.tries >= HELLO_TRIES) then
        state.threatSilent = true;

        setStatus('No answer to the threat handshake. Is DriftwoodXI up to date?', true, false);

        return;
    end

    ask.at    = os.clock();
    ask.tries = ask.tries + 1;

    issue('!dwe hello');
end

--[[
* The ceiling on one reply (1.2.0). The wire says at most eight rows and eight
* changes across a reply (dwe_protocol.md), but rows accumulate across every
* `n|` line of one envelope and nothing on this side said how many is too
* many: a server that grew a bug -- or a future one that raised its own cap
* past anything this build can draw usefully -- would have been walked in full
* on every frame. Four times the documented maximum, so the server can still
* grow without a client update, and no further (the burst-ceiling rule).
--]]
local MAX_THREAT_ROWS   = 32;
local MAX_THREAT_EVENTS = 32;

local function handleThreatRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.refused   = true;
            state.threatIn  = nil;
            state.threat    = { mob = nil, rows = {}, events = {} };
            state.threatRev = state.threatRev + 1;

            print(chat.header('dwparse'):append(chat.error(string.format(
                'server threat protocol %d, addon expects %d. Update dwparse through the launcher; no threat meter until then.',
                version, PROTOCOL))));

            return;
        end

        state.threatIn = parts[3];

        --[[
            ONLY A `threat` ENVELOPE ANSWERS THE HELLO (1.2.0). Any
            well-versioned envelope used to retire the clock, `bye` included
            -- and `!dwe bye` is a documented diagnostic a human types, which
            disarms the server's feed. The addon then believed itself armed,
            never re-helloed, and the meter simply stopped moving for the rest
            of the zone with nothing on screen saying why. A `bye` or a
            refusal envelope now leaves the clock where it was, so the next
            look at the tab asks again; a refusal's own `e|` line is what
            stops that, below.
        ]]
        if (state.threatIn == 'threat') then
            -- A give-up sentence about a feed that is answering RIGHT NOW is
            -- a banner outliving the thing it described (the same rule the
            -- protocol gate keeps from the other side). The latch clears
            -- below; the sentence about it has to clear with it.
            if (state.statusBad and state.threatSilent) then
                setStatus(IDLE_STATUS, false, false);
            end

            state.helloed       = true;
            state.threatAsk     = nil;
            state.threatSilent  = false;
            state.threatPending = { mob = nil, rows = {}, events = {} };
        elseif (state.threatIn == 'bye') then
            -- The far side has just DISARMED the feed. The addon has to know
            -- that rather than believe its hello still holds: the next look
            -- at the tab re-arms it, which is the same rule the tab has
            -- always run on (asked for only while it is being looked at).
            state.helloed   = false;
            state.threatAsk = nil;
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state; the
    -- refusal sentence from a build without the binding is the one thing that
    -- must not be lost. Either refusal latches the asking off for the zone.
    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        if (kind == 'e') then
            state.threatSilent = true;

            -- A refusal with no sentence in it is still a refusal, and the
            -- status line is where the player looks for why: an empty `e|`
            -- used to latch the feed off and say nothing at all.
            setStatus(text ~= '' and text or 'The server refused the threat feed.', true, false);

            -- A refusal may arrive MID-ENVELOPE (dwe_protocol.md says `e|`
            -- appears anywhere), and the reply it interrupts is wrong by
            -- definition. Dropping it here is what stops the `z|` behind it
            -- from committing rows the server has just disowned; the last
            -- complete answer stays on screen instead.
            state.threatIn      = nil;
            state.threatPending = nil;
        elseif (text ~= '') then
            -- `m|` is a sentence the player is owed -- `!dwe bye` answers with
            -- one, and it is the only thing that explains why the meter just
            -- went quiet. It used to be parsed and thrown away.
            setStatus(text, false, true);
        end

        return;
    end

    if (kind == 'z') then
        -- Commit on close, never before: the model swaps whole, so a reply
        -- cut off mid-flight leaves the last complete answer on screen. A
        -- `z|` for anything but `threat` (a `bye` or a `status` envelope)
        -- commits nothing, but still closes the envelope -- it used to return
        -- at the guard below and leave `threatIn` naming a verb for good.
        if (state.threatIn == 'threat' and state.threatPending ~= nil) then
            state.threat    = state.threatPending;
            state.threatRev = state.threatRev + 1;
        end

        state.threatPending = nil;
        state.threatIn      = nil;

        return;
    end

    if (state.threatIn ~= 'threat' or state.threatPending == nil or parts[2] == nil) then
        return;
    end

    if (kind == 't') then
        local targid = tonumber(parts[2]) or 0;

        state.threatPending.mob = targid > 0 and targid or nil;

        return;
    end

    if (kind == 'n') then
        local rows = state.threatPending.rows;

        for _, entry in ipairs(split(parts[2], ',')) do
            if (#rows >= MAX_THREAT_ROWS) then
                break;
            end

            local id, total = entry:match('^(%d+):(%d+)$');

            if (id ~= nil) then
                rows[#rows + 1] = {
                    id    = tonumber(id),
                    total = tonumber(total),
                };
            end
        end

        return;
    end

    -- c| -- the recent changes (1.1.2, dwe_protocol.md): `<id>:<kind>:<dCE>:<dVE>`
    -- newest first, the kind one letter. An entry this addon cannot read is
    -- skipped, never an error: the server may grow kinds after this shipped.
    if (kind == 'c') then
        local events = state.threatPending.events;

        for _, entry in ipairs(split(parts[2], ',')) do
            if (#events >= MAX_THREAT_EVENTS) then
                break;
            end

            local id, what, ce, ve = entry:match('^(%d+):(%a):(%-?%d+):(%-?%d+)$');

            if (id ~= nil) then
                events[#events + 1] = {
                    id   = tonumber(id),
                    kind = what,
                    ce   = tonumber(ce),
                    ve   = tonumber(ve),
                };
            end
        end

        return;
    end
end

--[[
* Resource names for the breakdown labels. Job abilities arrive under their
* small id and live at id + 512 in the client's ability DAT; weaponskills use
* their raw id. Mob and pet TP moves have no client-side name table worth
* trusting, so they fall through to a numbered label rather than a wrong one.
--]]
local function abilityName(id, offset)
    local ability = AshitaCore:GetResourceManager():GetAbilityById(id + offset);

    if (ability ~= nil and ability.Name[1] ~= nil and ability.Name[1]:len() > 0) then
        return ability.Name[1];
    end

    return nil;
end

--[[
* The label cache (1.2.0). A melee round from a full squad is a stream of
* 0x0028s and every one of them used to walk the resource manager for a name
* that cannot change: GetAbilityById / GetSpellById / GetItemById are DAT
* reads, and a weaponskill cost two of them per packet. Keyed by category and
* param, which is exactly what the answer depends on.
*
* A PLAIN table, and bounded by construction: the key space is the set of
* actions the player has actually seen, which is a few dozen in a session and
* a few hundred in a very long one -- small next to the parse rows beside it.
--]]
local labelCache = {};

local function actionLabelUncached(category, param)
    if (category == 1) then
        return 'Melee';
    elseif (category == 2) then
        return 'Ranged';
    elseif (category == 3) then
        return abilityName(param, 0) or string.format('Weaponskill #%d', param);
    elseif (category == 4) then
        local spell = AshitaCore:GetResourceManager():GetSpellById(param);

        if (spell ~= nil and spell.Name[1] ~= nil and spell.Name[1]:len() > 0) then
            return spell.Name[1];
        end

        return string.format('Spell #%d', param);
    elseif (category == 5) then
        local item = AshitaCore:GetResourceManager():GetItemById(param);

        if (item ~= nil and item.Name[1] ~= nil and item.Name[1]:len() > 0) then
            return item.Name[1];
        end

        return string.format('Item #%d', param);
    elseif (category == 6 or category == 14 or category == 15) then
        return abilityName(param, 512) or abilityName(param, 0) or string.format('Ability #%d', param);
    elseif (category == 11 or category == 13) then
        return abilityName(param, 512) or string.format('TP move #%d', param);
    end

    return string.format('Action #%d', param);
end

local function actionLabel(category, param)
    local bucketed = labelCache[category];

    if (bucketed == nil) then
        bucketed = {};
        labelCache[category] = bucketed;
    end

    local label = bucketed[param];

    if (label == nil) then
        label = actionLabelUncached(category, param);

        -- A NUMBERED FALLBACK IS NEVER CACHED. 'Weaponskill #123' is what the
        -- resource manager says when it could not answer, and a DAT that was
        -- not ready for one packet is ready for the next -- caching the
        -- failure would pin the number on that action for the session.
        if (label:find('#%d+$') == nil) then
            bucketed[param] = label;
        end
    end

    return label;
end

--[[
* Accumulation. Rows appear on first credit; the clock starts on the first
* combat event and advances on every one after it, so DPS is measured over
* time actually spent fighting rather than time spent running back.
--]]
local function actorRow(name)
    local row = parse.actors[name];

    if (row == nil) then
        row = freshActor(name);
        parse.actors[name] = row;
    end

    return row;
end

--[[
* THE MODEL REVISION (1.2.0). Every write to the tallies goes through
* touchClock -- that is what made it the right place to stamp one -- and the
* render side keys its view caches on it. Nothing derived from the model is
* rebuilt while this number stands still, which is most frames: a fight is a
* few packets a second against sixty rendered frames.
--]]
local modelRev = 0;

local function touchClock()
    local now = os.clock();

    if (parse.startedAt == nil) then
        parse.startedAt = now;
    end

    parse.lastAt = now;
    modelRev     = modelRev + 1;
end

local function pruneRecent(row, now)
    local list = row.recent;

    while (#list > 0 and now - list[1].t > RECENT_WINDOW) do
        row.recentSum = row.recentSum - list[1].amount;
        table.remove(list, 1);
    end
end

local function bucket(map, label)
    local b = map[label];

    if (b == nil) then
        b = { count = 0, landed = 0, total = 0, max = 0, crits = 0, misses = 0, resists = 0, shadows = 0 };
        map[label] = b;
    end

    return b;
end

local function creditDamage(name, label, amount, isCrit)
    local row = actorRow(name);
    local now = os.clock();

    row.dmg.total = row.dmg.total + amount;

    if (amount > row.dmg.max) then
        row.dmg.max      = amount;
        row.dmg.maxLabel = label;
    end

    local b = bucket(row.actions, label);

    b.count  = b.count + 1;
    b.landed = b.landed + 1;
    b.total  = b.total + amount;

    if (amount > b.max) then
        b.max = amount;
    end

    if (isCrit) then
        b.crits = b.crits + 1;
    end

    pruneRecent(row, now);
    table.insert(row.recent, { t = now, amount = amount });
    row.recentSum = row.recentSum + amount;

    touchClock();
end

local function creditAttempt(name, label, kind)
    local row = actorRow(name);
    local b   = bucket(row.actions, label);

    b.count = b.count + 1;
    b[kind] = b[kind] + 1;

    touchClock();
end

local function creditHeal(name, label, amount)
    local row = actorRow(name);

    row.heal.total = row.heal.total + amount;

    if (amount > row.heal.max) then
        row.heal.max      = amount;
        row.heal.maxLabel = label;
    end

    local b = row.heals[label];

    if (b == nil) then
        b = { count = 0, total = 0, max = 0 };
        row.heals[label] = b;
    end

    b.count = b.count + 1;
    b.total = b.total + amount;

    if (amount > b.max) then
        b.max = amount;
    end

    touchClock();
end

local function creditMP(name, amount)
    local row = actorRow(name);

    row.heal.mp = row.heal.mp + amount;

    touchClock();
end

local function creditTaken(name, attacker, amount)
    local row = actorRow(name);

    row.taken.total = row.taken.total + amount;
    row.taken.hits  = row.taken.hits + 1;

    if (amount > row.taken.max) then
        row.taken.max      = amount;
        row.taken.maxLabel = attacker or '?';
    end

    if (attacker ~= nil) then
        local b = row.sources[attacker];

        if (b == nil) then
            b = { count = 0, total = 0, max = 0 };
            row.sources[attacker] = b;
        end

        b.count = b.count + 1;
        b.total = b.total + amount;

        if (amount > b.max) then
            b.max = amount;
        end
    end

    touchClock();
end

--[[
* The bit reader, matching the server's unpackBitsBE: bytes assembled
* little-endian from the byte the offset lands in, shifted down by the
* in-byte remainder, masked to length. Pure arithmetic rather than the bit
* library, because a 32-bit field at a 7-bit offset spans 39 bits and LuaJIT's
* bit ops truncate at 32; doubles carry 53 cleanly.
--]]
local function readBits(data, bitOffset, length)
    local byteStart = math.floor(bitOffset / 8);
    local shift     = bitOffset % 8;
    local nBytes    = math.floor((shift + length + 7) / 8);
    local value     = 0;

    for i = nBytes, 1, -1 do
        value = value * 256 + (data:byte(byteStart + i) or 0);
    end

    return math.floor(value / (2 ^ shift)) % (2 ^ length);
end

--[[
* GP_SERV_COMMAND_BATTLE2, field for field in the server's pack() order.
* Categories that only announce a start (7-10, 12) carry no amounts and are
* skipped before any bit is read.
--]]
local function parseActionPacket(data)
    local pos = 40;     -- skip the 4-byte header and WorkSize

    --[[
        EVERY READ IS BOUNDED BY THE PACKET (1.2.0). readBits substitutes a
        zero for a byte that is not there, so a short or malformed 0x0028 used
        to be decoded as though the server had sent fifteen targets of eight
        results each, all of them zeros -- a hundred and twenty invented
        result blocks, fifteen thousand bit reads, for a packet with nothing
        in it. Nothing was ever COUNTED from them (message 0 is in no table),
        which is why this was only ever waste; the guard stops the walk at the
        first field that would run off the end.
    ]]
    local bitLimit = #data * 8;
    local short    = false;

    local function read(length)
        if (pos + length > bitLimit) then
            short = true;
            pos   = pos + length;

            return 0;
        end

        local value = readBits(data, pos, length);

        pos = pos + length;

        return value;
    end

    local act = {};

    act.actor    = read(32);
    local trgSum = read(6);
    read(4);                    -- res_sum, always 0
    act.category = read(4);
    act.param    = read(32);
    read(32);                   -- recast / action info
    act.targets  = {};

    if (act.category == 7 or act.category == 8 or act.category == 9
            or act.category == 10 or act.category == 12 or act.category == 0) then
        return nil;
    end

    for t = 1, math.min(trgSum, 15) do
        if (short) then
            break;
        end

        local target = { id = read(32), results = {} };
        local resSum = read(4);

        for r = 1, math.min(resSum, 8) do
            if (short) then
                break;
            end

            local res = {};

            res.miss = read(3);
            read(2);            -- kind
            read(12);           -- animation
            read(5);            -- info
            read(5);            -- hit distortion + knockback
            res.value   = read(17);
            res.message = read(10);
            read(31);           -- modifier

            if (read(1) == 1) then
                read(6);        -- proc kind
                read(4);        -- proc info
                res.procValue   = read(17);
                res.procMessage = read(10);
            end

            if (read(1) == 1) then
                read(6);        -- react kind
                read(4);        -- react info
                res.reactValue   = read(14);
                res.reactMessage = read(10);
            end

            -- The last result of a truncated packet is invented, not read:
            -- everything after the cut came back as a zero.
            if (not short) then
                target.results[#target.results + 1] = res;
            end
        end

        act.targets[#act.targets + 1] = target;
    end

    return act;
end

--[[
* One decoded action against the tallies.
*
* Attribution runs per result: the actor's side needs the actor to be worth a
* row (party, or anyone when "Party only" is off, and nameless actors out of
* range are dropped rather than invented); the target's side only ever cares
* whether the target is a party member. Both halves of one result can count --
* a mob's TP move is the mob's damage dealt and the tank's damage taken.
--]]
local function handleAction(act)
    local tracked   = trackedSet();
    local partyOnly = state.partyOnly[1];
    local actorName = tracked[act.actor];
    local actorIsUs = actorName ~= nil;

    if (actorName == nil and not partyOnly) then
        actorName = entityName(act.actor);
    end

    -- The name to PRINT for the actor when it is somebody's attacker. Always
    -- resolved, party or not -- a Taken row whose "From" column is blank says
    -- nothing -- but resolved LAZILY and at most once per action: for a
    -- player-range id that is not in the entity array, entityName scans 1280
    -- slots, and it used to run once per RESULT (a fifteen-target AoE with
    -- eight results each is a hundred and twenty of them for one packet).
    local actorLabel = false;

    local label = actionLabel(act.category, act.param);

    for _, target in ipairs(act.targets) do
        local targetName = tracked[target.id];

        -- The same lazy resolution for the target side, once per target.
        local targetLabel = false;

        for _, res in ipairs(target.results) do
            local msg = res.message;

            if (COUNTER[msg]) then
                -- The target countered: their damage, dealt to the actor.
                local counterer = targetName;

                if (counterer == nil and not partyOnly) then
                    if (targetLabel == false) then
                        targetLabel = entityName(target.id);
                    end

                    counterer = targetLabel;
                end

                if (counterer ~= nil) then
                    creditDamage(counterer, 'Counter', res.value, false);
                end

                if (actorIsUs) then
                    if (targetLabel == false) then
                        targetLabel = entityName(target.id);
                    end

                    creditTaken(actorName, targetName or targetLabel, res.value);
                end
            elseif (DMG[msg]) then
                if (actorName ~= nil) then
                    creditDamage(actorName, label, res.value, CRIT[msg] == true);
                end

                if (targetName ~= nil) then
                    if (actorLabel == false) then
                        actorLabel = entityName(act.actor);
                    end

                    creditTaken(targetName, actorName or actorLabel, res.value);
                end
            elseif (MISS[msg]) then
                if (actorName ~= nil) then
                    creditAttempt(actorName, label, 'misses');
                end

                if (targetName ~= nil) then
                    local hit = actorRow(targetName);

                    hit.taken.evades = hit.taken.evades + 1;
                    touchClock();
                end
            elseif (RESIST[msg]) then
                if (actorName ~= nil) then
                    creditAttempt(actorName, label, 'resists');
                end
            elseif (SHADOW[msg]) then
                if (actorName ~= nil) then
                    creditAttempt(actorName, label, 'shadows');
                end

                if (targetName ~= nil) then
                    local hit = actorRow(targetName);

                    hit.taken.shadows = hit.taken.shadows + 1;
                    touchClock();
                end
            elseif (HEAL[msg]) then
                if (actorName ~= nil) then
                    creditHeal(actorName, label, res.value);
                end

                if (targetName ~= nil) then
                    local cured = actorRow(targetName);

                    cured.taken.healed = cured.taken.healed + res.value;

                    -- Like every other target-side counter: without this, a
                    -- cure from an untracked healer (Party only on) creates
                    -- rows while the combat clock still reads "waiting".
                    touchClock();
                end
            elseif (HEAL_MP[msg]) then
                if (actorName ~= nil) then
                    creditMP(actorName, res.value);
                end
            end

            -- Additional effects: en-spells, drains, and the skillchain the
            -- weaponskill closed, all credited to the weaponskill's actor.
            if (res.procMessage ~= nil and res.procMessage ~= 0 and actorName ~= nil) then
                local pm = res.procMessage;

                if (SC_NAMES[pm] ~= nil) then
                    creditDamage(actorName, 'Skillchain: ' .. SC_NAMES[pm], res.procValue, false);
                elseif (pm > 384 and pm <= 400 and SC_NAMES[pm - 384 + 287] ~= nil) then
                    -- 384 + effect is a skillchain ABSORBED by the target
                    -- (action.cpp emits it when the chain damage goes
                    -- negative), exactly parallel to 287 + effect for the
                    -- damage case: an undead eating a Light chain heals for
                    -- it, and dropping the row reported nothing at all.
                    creditHeal(actorName, 'Skillchain: ' .. SC_NAMES[pm - 384 + 287], res.procValue);
                elseif (PROC_DMG[pm]) then
                    creditDamage(actorName, 'Add. effect', res.procValue, false);
                elseif (PROC_HEAL[pm]) then
                    creditHeal(actorName, 'Add. effect', res.procValue);
                elseif (PROC_MP[pm]) then
                    creditMP(actorName, res.procValue);
                end
            end

            -- Reactions: the target's spikes or retaliation, dealt back onto
            -- the actor -- the one block where roles swap.
            if (res.reactMessage ~= nil and REACT_DMG[res.reactMessage]) then
                local spiker = targetName;

                if (spiker == nil and not partyOnly) then
                    if (targetLabel == false) then
                        targetLabel = entityName(target.id);
                    end

                    spiker = targetLabel;
                end

                if (spiker ~= nil) then
                    creditDamage(spiker, 'Spikes', res.reactValue, false);
                end

                if (actorIsUs) then
                    if (targetLabel == false) then
                        targetLabel = entityName(target.id);
                    end

                    creditTaken(tracked[act.actor], targetName or targetLabel, res.reactValue);
                end
            end
        end
    end
end

ashita.events.register('packet_in', 'dwparse_packet_in', function (e)
    -- The threat wire: any 0x017 line whose sender is _DWEDATA is ours -- it
    -- is consumed here and the packet is blocked so the chat log never sees
    -- it. Blocked BEFORE parsing: a malformed record must not leak as noise.
    if (e.id == 0x0017) then
        -- EVERY line of chat in the zone arrives here -- party, say, shout,
        -- linkshell, every NPC -- and the sender field used to be cut out and
        -- scrubbed for all of them, two fresh strings per line of somebody
        -- else's conversation. Every _DW*DATA name begins with an underscore
        -- and no player name can, so one byte answers "not ours" for the
        -- whole of normal chat before anything is allocated.
        if (e.data_modified:byte(0x09) ~= 0x5F) then
            return;
        end

        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        e.blocked = true;

        local ok, err = pcall(handleThreatRecord, message);

        if (not ok) then
            print(chat.header('dwparse'):append(chat.error('bad threat record: ' .. tostring(err))));
        end

        return;
    end

    if (e.id == 0x0028) then
        if (state.paused[1]) then
            return;
        end

        -- Decoding is pcall'd per packet: one malformed action must cost that
        -- action, not the addon. Nothing is ever blocked from here.
        local ok, act = pcall(parseActionPacket, e.data);

        if (ok and act ~= nil) then
            pcall(handleAction, act);
        end

        return;
    end

    -- A zone line deliberately clears NOTHING -- surviving it is the point.
    -- But a login can be a different character, whose parse this is not, so
    -- the name is checked once the party list has had a moment to fill in.
    if (e.id == 0x000A) then
        trackedCache.at = 0;
        playerIdCache   = {};
        playerMiss      = { at = 0, ids = {} };

        state.charCheckAt = os.clock() + 3.0;

        -- The threat model is per-zone (targids renumber, the server's
        -- handshake localvar died on the line) and both latches are re-probed
        -- -- 0x000A is also a login, and the server on the far side of a map
        -- restart may well be the updated one (the dwwarehouse noTrash rule).
        -- All three fields, the way every other construction of this table
        -- spells it: `events` was missing here, and a reader that reached it
        -- before the empty-rows guard would have indexed nil.
        state.threat        = { mob = nil, rows = {}, events = {} };
        state.threatRev     = state.threatRev + 1;
        state.threatIn      = nil;
        state.threatPending = nil;
        state.threatAsk     = nil;
        state.helloed       = false;
        state.refused       = false;
        state.threatSilent  = false;

        -- Every bad sentence on screen was about one of the latches just
        -- cleared, or about a send that a zone line has made moot. Leaving it
        -- up would be a banner describing a state the addon has stopped
        -- being in -- and the Threat tab says all of it again anyway, from
        -- the state rather than from a remembered string.
        if (state.statusBad) then
            setStatus(IDLE_STATUS, false, false);
        end
    end
end);

--[[
* Formatting.
*
* Thousands separators.
*
* THE SIGN IS SPLIT OFF FIRST (1.2.0). The old loop grouped from the right
* over the whole string, minus sign and all, so once the digits ran out it
* prepended a comma to whatever was left -- and for a negative whose digit
* count is a multiple of three that is the sign on its own: -250 came out as
* "-,250" and -123456 as "-,123,456". The Threat tab's recent changes are
* where a negative actually reaches this: `h` (a hit the holder took) and `l`
* (a lowering) are always negative on the wire.
*
* One pass over the digits rather than a fresh string per group: this runs for
* every number in every row of every table.
--]]
local function comma(n)
    local value = math.floor(n);
    local sign  = '';

    if (value < 0) then
        sign  = '-';
        value = -value;
    end

    local text = tostring(value);
    local head = #text % 3;
    local out  = { };

    if (head > 0) then
        out[1] = text:sub(1, head);
    end

    for i = head + 1, #text, 3 do
        out[#out + 1] = text:sub(i, i + 2);
    end

    return sign .. table.concat(out, ',');
end

local function clockText(seconds)
    seconds = math.max(math.floor(seconds), 0);

    if (seconds >= 3600) then
        return string.format('%d:%02d:%02d', math.floor(seconds / 3600), math.floor(seconds / 60) % 60, seconds % 60);
    end

    return string.format('%02d:%02d', math.floor(seconds / 60), seconds % 60);
end

-- Combat time: first event to last event, never less than a second so an
-- opening round does not divide by nothing.
local function combatSeconds()
    if (parse.startedAt == nil) then
        return 0;
    end

    return math.max(parse.lastAt - parse.startedAt, 1);
end

local function dps(total)
    local seconds = combatSeconds();

    if (seconds == 0) then
        return 0;
    end

    return total / seconds;
end

local function recentDps(row)
    pruneRecent(row, os.clock());

    if (row.recentSum <= 0) then
        return 0;
    end

    local span = RECENT_WINDOW;

    if (parse.startedAt ~= nil) then
        span = math.min(span, math.max(os.clock() - parse.startedAt, 1));
    end

    return row.recentSum / span;
end

-- Melee + ranged accuracy, the number the Accuracy column shows. Shadows
-- count as connected -- the swing was true, the mob just had Utsusemi up.
--
-- The key list is a module constant rather than a table literal in the loop:
-- it used to be allocated once per row per frame, for a list of two strings
-- that has never changed.
local ACCURACY_KEYS = { 'Melee', 'Ranged' };

local function accuracy(row)
    local attempts = 0;
    local landed   = 0;

    for _, key in ipairs(ACCURACY_KEYS) do
        local b = row.actions[key];

        if (b ~= nil) then
            attempts = attempts + b.count;
            landed   = landed + b.landed + b.shadows;
        end
    end

    if (attempts == 0) then
        return nil;
    end

    return 100 * landed / attempts;
end

--[[
* `metric` decides who APPEARS; `sortKey` decides the order. They are the same
* thing for every caller but one, so sortKey defaults to metric and nothing
* else changes.
*
* The exception is the Taken tab. metricTaken deliberately counts evades,
* shadows and HP healed so a tank who avoided everything still shows up --
* which is right for INCLUSION and wrong for RANK, because that tab prints
* row.taken.total and nothing else. A row that took 200 damage and evaded
* forty swings outranked one that took 2,000, and the list read as though the
* numbers beside it were out of order.
--]]
local function sortedBy(metric, sortKey)
    sortKey = sortKey or metric;

    local rows = {};

    for _, row in pairs(parse.actors) do
        if (metric(row) > 0) then
            rows[#rows + 1] = row;
        end
    end

    table.sort(rows, function (a, b)
        local am, bm = sortKey(a), sortKey(b);

        if (am == bm) then
            return a.name < b.name;
        end

        return am > bm;
    end);

    return rows;
end

local metricDmg   = function (row) return row.dmg.total; end
local metricHeal  = function (row) return row.heal.total + row.heal.mp; end
local metricTaken = function (row) return row.taken.total + row.taken.evades + row.taken.shadows + row.taken.healed; end

-- The Taken tab's RANKING key: the one number that tab actually prints.
local metricTakenDmg = function (row) return row.taken.total; end

local function grandTotal(rows, metric)
    local total = 0;

    for _, row in ipairs(rows) do
        total = total + metric(row);
    end

    return total;
end

--[[
* THE COLUMNS, AS DATA (1.2.0). The label, the width policy and the sentence
* the header says on hover live in one place -- so nothing is rebuilt sixty
* times a second, the wording is auditable beside its neighbours, and the
* harness can read the tips rather than guess at them (the dwfishing shape).
*
* THE NAME COLUMN STRETCHES and every number stays fixed (the dwleaderboard
* rule): narrowing the window then shortens a NAME, which is recoverable,
* instead of clipping a number, which is the thing the tab exists to show.
* 150 fixed pixels was the old width, and a pet's row is its own name tagged
* with its owner's -- "Carbuncle (Ayla)" is already at that edge and any
* longer owner name ran off it.
--]]
local DMG_COLUMNS = {
    { label = '#',      width = 26,
      tip = 'Rank by total damage dealt.' },
    { label = 'Name',   stretch = 1.0,
      tip = 'The actor. Rows are keyed by NAME, so a squad recall or a zone line keeps the same row -- entity ids survive neither. A pet rides under its own name tagged with its owner\'s. Click a name for its breakdown.' },
    { label = 'Damage', width = 84,
      tip = 'Every point this actor has dealt since the last Reset -- skillchains and additional effects included, drains counted here and not as healing.' },
    { label = 'DPS',    width = 62,
      tip = 'Damage over COMBAT time: first event to last, not wall clock, so the walk back to camp does not dilute it.' },
    { label = '30s',    width = 62,
      tip = 'Damage over the last thirty seconds only -- what this actor is doing now rather than what they have done. A dash means nothing in the window.' },
    { label = 'Share',  width = 104,
      tip = 'The bar is this actor measured against the top row; the number on it is their share of the whole party\'s damage.' },
    { label = 'Acc',    width = 52,
      tip = 'Melee and ranged swings that connected, over swings taken. Shadows count as connected -- the swing was true, the target just had Utsusemi up. Spells and abilities are not in it, so a caster shows a dash.' },
    { label = 'Max',    width = 76,
      tip = 'The single biggest hit. Hover the number itself for what it was.' },
};

local HEAL_COLUMNS = {
    { label = '#',       width = 26,
      tip = 'Rank by HP restored plus MP restored.' },
    { label = 'Name',    stretch = 1.0,
      tip = 'The healer. Click a name for the breakdown of what they cast.' },
    { label = 'Healing', width = 84,
      tip = 'HP that actually landed. Overcure is invisible on the wire -- the server already reports the capped number -- so this is HP the target kept.' },
    { label = 'HPS',     width = 62,
      tip = 'HP restored over combat time, the healing twin of DPS.' },
    { label = 'Share',   width = 104,
      tip = 'The bar is this healer against the biggest healer; the number on it is their share of all HP restored.' },
    { label = 'MP',      width = 76,
      tip = 'MP restored to others (Ballads, Refresh ticks, drains handed on). Ranked with the HP but never mixed into it.' },
    { label = 'Max',     width = 76,
      tip = 'The single biggest heal. Hover the number itself for what it was.' },
};

local TAKEN_COLUMNS = {
    { label = '#',            width = 26,
      tip = 'Rank by damage taken.' },
    { label = 'Name',         stretch = 1.0,
      tip = 'The party member who was hit. This tab is always about the party, whoever was hitting them. Click a name for who it was.' },
    { label = 'Taken',        width = 84,
      tip = 'Damage this member has taken since the last Reset.' },
    { label = 'Hits',         width = 52,
      tip = 'How many separate blows landed. Evades and shadows are not in it.' },
    { label = 'Avg',          width = 70,
      tip = 'Damage taken divided by hits landed -- how hard the average blow was.' },
    { label = 'Max',          width = 76,
      tip = 'The biggest single blow. Hover the number itself for who dealt it.' },
    { label = 'Evade/Shadow', width = 96,
      tip = 'Swings that missed entirely, then swings a shadow ate. Both are blows this member did not take.' },
    { label = 'Healed for',   width = 84,
      tip = 'HP restored TO this member by anyone, which is what the damage beside it actually cost the party.' },
};

-- Every table in this window is the same kind of table, and the flags for it
-- were rebuilt on every BeginTable call on every frame. The ImGui constants
-- are globals by the time this file is read, so the fold happens once.
local TABLE_FLAGS = bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH,
                            ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingFixedFit);

local function setupColumns(columns)
    for _, column in ipairs(columns) do
        if (column.stretch) then
            -- A weight, not a width: two stretching columns in one table
            -- share what the fixed ones left in proportion (the dwfishing
            -- shape), so the wider window a player drags out goes where the
            -- long text is rather than into padding.
            imgui.TableSetupColumn(column.label, ImGuiTableColumnFlags_WidthStretch,
                column.stretch, 0);
        else
            imgui.TableSetupColumn(column.label, ImGuiTableColumnFlags_WidthFixed, column.width, 0);
        end
    end
end

--[[
* The header row, drawn by hand so each column can say what it means on hover:
* TableHeadersRow() draws them all as one item and leaves nothing for
* IsItemHovered to be about (the dwleaderboard note, one addon over).
--]]
local function headerRow(columns)
    imgui.TableNextRow(ImGuiTableRowFlags_Headers, 0);

    for _, column in ipairs(columns) do
        imgui.TableNextColumn();
        imgui.TableHeader(column.label);

        if (column.tip ~= nil and imgui.IsItemHovered()) then
            imgui.SetTooltip(column.tip);
        end
    end
end

--[[
* THE VIEW CACHE (1.2.0).
*
* Everything a table draws except the sliding 30-second column is a function
* of the tallies and the find box, and both change on the server's schedule
* rather than the frame rate -- a busy fight is a handful of packets a second
* against sixty rendered frames. What used to happen on every one of those
* frames, per tab: a fresh array of every actor, a table.sort over it, a
* grandTotal walk, and then per row a `##sel_` concatenation, four or five
* comma() calls, an accuracy() walk with a table literal in it, and two
* string.format calls. With "Party only" unticked in a crowded zone that is
* thousands of allocations a second for numbers that did not move.
*
* So the model carries a revision (touchClock stamps it) and each tab keeps
* its built rows until that revision or the find text changes. The `30s`
* column is deliberately NOT cached: it slides with the wall clock, and a
* stale one would be a lie about right now.
--]]
local views = {
    dmg   = { rev = -1, search = false, rows = { }, count = 0, total = 0, footer = '' },
    heal  = { rev = -1, search = false, rows = { }, count = 0, total = 0, footer = '' },
    taken = { rev = -1, search = false, rows = { }, count = 0, total = 0, footer = '' },
};

local function searchNeedle()
    local text = state.search[1];

    if (text == nil or text == '') then
        return '';
    end

    return (text:match('^%s*(.-)%s*$') or ''):lower();
end

local function buildView(key)
    local view   = views[key];
    local needle = searchNeedle();

    if (view.rev == modelRev and view.search == needle) then
        return view;
    end

    view.rev    = modelRev;
    view.search = needle;
    view.rows   = { };

    local ranked, total, top;

    if (key == 'heal') then
        ranked = sortedBy(metricHeal);
        total  = grandTotal(ranked, function (r) return r.heal.total; end);

        -- The LARGEST heal.total, not the first row's: rows are ordered by
        -- HP + MP restored, so an MP restorer with zero cures can sit first --
        -- and a `top` of its 0 (clamped to 1) drew every healer below it as a
        -- full-width bar with a mismatched percentage beside it.
        top = 1;

        for _, row in ipairs(ranked) do
            if (row.heal.total > top) then
                top = row.heal.total;
            end
        end
    elseif (key == 'taken') then
        -- Ranked by the number the table prints: metricTaken decides who
        -- appears (a tank who evaded everything still has a row) and
        -- metricTakenDmg decides the order.
        ranked = sortedBy(metricTaken, metricTakenDmg);
        total  = grandTotal(ranked, metricTakenDmg);
        top    = 1;
    else
        ranked = sortedBy(metricDmg);
        total  = grandTotal(ranked, metricDmg);
        top    = #ranked > 0 and math.max(ranked[1].dmg.total, 1) or 1;
    end

    view.count   = #ranked;
    view.total   = total;
    view.seconds = combatSeconds();

    for rank, row in ipairs(ranked) do
        -- The share and the percentage are measured against EVERY row, never
        -- against what the find box left on screen: a filter narrows the
        -- list, it does not rewrite the fight.
        if (needle == '' or row.name:lower():find(needle, 1, true) ~= nil) then
            local cell = {
                row   = row,
                name  = row.name,
                -- The Selectable's id used to be `name .. '##sel_' .. name`,
                -- built fresh for every row on every frame.
                label = row.name .. '##sel_' .. row.name,
                rank  = tostring(rank),
            };

            if (key == 'heal') then
                cell.value     = comma(row.heal.total);
                cell.rate      = comma(dps(row.heal.total));
                cell.share     = row.heal.total / top;
                cell.shareText = string.format('%.1f%%',
                    total > 0 and (100 * row.heal.total / total) or 0);
                cell.mp        = row.heal.mp > 0 and comma(row.heal.mp) or nil;
                cell.max       = comma(row.heal.max);
                cell.maxLabel  = row.heal.maxLabel;
            elseif (key == 'taken') then
                cell.value    = comma(row.taken.total);
                cell.hits     = tostring(row.taken.hits);
                cell.avg      = comma(row.taken.total / math.max(row.taken.hits, 1));
                cell.max      = comma(row.taken.max);
                cell.maxLabel = row.taken.maxLabel;
                cell.avoided  = string.format('%d / %d', row.taken.evades, row.taken.shadows);
                cell.healed   = comma(row.taken.healed);
            else
                local acc = accuracy(row);

                cell.value     = comma(row.dmg.total);
                cell.rate      = comma(dps(row.dmg.total));
                cell.share     = row.dmg.total / top;
                cell.shareText = string.format('%.1f%%',
                    total > 0 and (100 * row.dmg.total / total) or 0);
                cell.acc       = acc ~= nil and string.format('%.0f%%', acc) or nil;
                cell.max       = comma(row.dmg.max);
                cell.maxLabel  = row.dmg.maxLabel;
            end

            view.rows[#view.rows + 1] = cell;
        end
    end

    --[[
        The totals line under the table (1.2.0): the number a party actually
        asks for -- "what are we putting out?" -- which every tab could
        compute and none of them said out loud. It also states how many rows
        the find box is showing, so a filtered list never reads as the whole
        fight.
    ]]
    if (key == 'taken') then
        view.footer = string.format('%d shown  --  %s taken between them over %s',
            #view.rows, comma(total), clockText(view.seconds));
        view.tabLabel = string.format('Taken (%d)###dwparse_tab_taken', view.count);
    elseif (key == 'heal') then
        view.footer = string.format('%d shown  --  %s HP between them over %s, %s HPS',
            #view.rows, comma(total), clockText(view.seconds), comma(dps(total)));
        view.tabLabel = string.format('Healing (%d)###dwparse_tab_heal', view.count);
    else
        view.footer = string.format('%d shown  --  %s damage between them over %s, %s DPS',
            #view.rows, comma(total), clockText(view.seconds), comma(dps(total)));
        view.tabLabel = string.format('Damage (%d)###dwparse_tab_dmg', view.count);
    end

    return view;
end

--[[
* Export: the current tab, spoken into the chosen channel one throttled line
* at a time. Short lines on purpose -- chat has a byte budget and a nine-line
* wall of numbers is already pushing hospitality.
*
* The line BUILDING is separate from the sending (1.2.0) because Copy wants
* exactly the same sentences and a clipboard has neither a channel nor a
* throttle: one shape, two doors.
--]]

-- Forward-declared: the Threat branch below resolves its row names exactly
-- the way the Threat TAB does, and that helper carries a cache which lives
-- with the tab, several hundred lines further on. One name, one answer.
local threatName;

--[[
    `depth` is how many ranked rows the answer carries. Chat gets eight -- a
    heading and eight lines is already nine throttled sends and about as much
    of somebody else's numbers as a party wants. The CLIPBOARD has no line
    budget and no audience, so Copy asks for more; the ceiling is still a
    ceiling, because an unbounded paste is its own kind of rude.
]]
local EXPORT_DEPTH = 8;
local COPY_DEPTH   = 32;

local function exportLines(depth)
    local lines = T{ };

    if (state.tab == 'heal') then
        local rows  = sortedBy(metricHeal);
        local total = grandTotal(rows, function (r) return r.heal.total; end);

        lines:append(string.format('Healing %s: %s HP total', clockText(combatSeconds()), comma(total)));

        for rank = 1, math.min(#rows, depth) do
            local row = rows[rank];
            local pct = total > 0 and (100 * row.heal.total / total) or 0;

            lines:append(string.format('%d. %s %s (%.1f%%) max %s%s',
                rank, row.name, comma(row.heal.total), pct, comma(row.heal.max),
                row.heal.mp > 0 and string.format(', %s MP', comma(row.heal.mp)) or ''));
        end
    elseif (state.tab == 'threat') then
        local mob = state.threat.mob;

        if (mob ~= nil and #state.threat.rows > 0) then
            local entity  = AshitaCore:GetMemoryManager():GetEntity();
            local mobName = entity ~= nil and entity:GetName(mob) or nil;
            local top     = math.max(state.threat.rows[1].total, 1);

            lines:append(string.format('Threat on %s:',
                (mobName ~= nil and mobName ~= '') and mobName or string.format('target #%d', mob)));

            -- The same depth the other branches cap at. The wire ranks eight
            -- rows today, but nothing about a chat export should be able to
            -- grow into a forty-second wall of throttled lines because a
            -- future server raised its own cap.
            for rank = 1, math.min(#state.threat.rows, depth) do
                local row = state.threat.rows[rank];

                lines:append(string.format('%d. %s %s (%.0f%% of top)%s',
                    rank, threatName(row.id), comma(row.total), 100 * row.total / top,
                    rank == 1 and ' <- aggro' or ''));
            end
        end
    elseif (state.tab == 'taken') then
        local rows = sortedBy(metricTaken, metricTakenDmg);

        lines:append(string.format('Damage taken %s:', clockText(combatSeconds())));

        for rank = 1, math.min(#rows, depth) do
            local row = rows[rank];

            lines:append(string.format('%d. %s %s over %d hits, max %s (%s)',
                rank, row.name, comma(row.taken.total), row.taken.hits,
                comma(row.taken.max), row.taken.maxLabel));
        end
    else
        local rows  = sortedBy(metricDmg);
        local total = grandTotal(rows, metricDmg);

        lines:append(string.format('Parse %s: %s damage total', clockText(combatSeconds()), comma(total)));

        for rank = 1, math.min(#rows, depth) do
            local row = rows[rank];
            local pct = total > 0 and (100 * row.dmg.total / total) or 0;

            lines:append(string.format('%d. %s %s (%.1f%%) %s DPS, max %s',
                rank, row.name, comma(row.dmg.total), pct,
                comma(dps(row.dmg.total)), comma(row.dmg.max)));
        end
    end

    return lines;
end

local function exportTab()
    local lines = exportLines(EXPORT_DEPTH);

    if (#lines <= 1) then
        setStatus('Nothing to export yet.', true, true);

        return;
    end

    local prefix = CHANNELS[state.channel].prefix;

    for _, line in ipairs(lines) do
        issue(prefix .. line);
    end

    setStatus(string.format('Exporting %d lines to %s...', #lines, CHANNELS[state.channel].label), false, true);
end

--[[
* Copy (1.2.0): the same sentences Export speaks, onto the clipboard instead.
* A parse is something people paste outside the game as often as they say it
* in party, and the throttled chat queue is the wrong shape for that -- nine
* lines take nine seconds to leave and land in somebody's log either way.
*
* Probed under pcall the once: SetClipboardText is in Ashita's annotations,
* and this suite has learned twice that an annotation is not proof (dwah 5a).
* Refused, the button says so and stops being offered as though it worked.
--]]
local clipboardBroken = false;

local function copyTab()
    local lines = exportLines(COPY_DEPTH);

    if (#lines <= 1) then
        setStatus('Nothing to copy yet.', true, true);

        return;
    end

    if (clipboardBroken or type(imgui.SetClipboardText) ~= 'function'
            or not pcall(imgui.SetClipboardText, lines:concat('\n'))) then
        clipboardBroken = true;

        setStatus('This client will not let an addon reach the clipboard.', true, true);

        return;
    end

    setStatus(string.format('%d lines copied to the clipboard.', #lines), false, true);
end

local function resetParse(reason)
    parse           = freshParse();
    state.selected  = nil;

    -- The view caches key on this: without the bump they would keep drawing
    -- the rows of a parse that no longer exists until the next combat event.
    modelRev        = modelRev + 1;
    setStatus(reason or 'Parse cleared.', false, true);
end

--[[
* Rendering. The shell -- theme push/pop and Begin/End outside a pcall'd
* body, one reported error, window closes itself -- is the dwbags shell,
* because it is the shape that survives a bad frame.
--]]
-- 22 tall rather than 14: the overlay percentage is drawn at the font's full
-- line height, so a shorter bar clipped it top and bottom. The overlay TEXT is
-- passed in already spelled (1.2.0) -- it used to be formatted here, once per
-- row per frame, from a number that only moves when the model does.
local function drawShareBar(fraction, text)
    imgui.ProgressBar(fraction, { 96, 22 }, text);
end

--[[
* A live ImGui measurement, or a conservative constant when the binding does
* not expose the call (the dwcpx shape). A fallback that is too big spends a
* few pixels; one that is too small hides a control.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

--[[
* The two font metrics every region here is sized from, read once a second
* rather than four or five times a frame: they change only when the player
* changes the client's font scale, and each read is a pcall through a
* protected binding. The table is reused, never rebuilt.
--]]
local metrics = { at = -1, line = 20, frame = 26 };

local function fontMetrics()
    local now = os.clock();

    if (now - metrics.at >= 1.0) then
        metrics.at    = now;
        metrics.line  = metric('GetTextLineHeightWithSpacing', 20);
        metrics.frame = metric('GetFrameHeightWithSpacing', 26);
    end

    return metrics;
end

--[[
* The breakdown pane's columns and its own cache. Same rule as the tables
* above it: the label list was rebuilt and re-sorted every frame for a
* selection that only changes on a click.
--]]
local DMG_DETAIL_COLUMNS = {
    -- Two stretching columns in this one table, and the action name is the
    -- half worth the wider share of what is left over.
    { label = 'Action', stretch = 1.6,
      tip = 'What was used. Weaponskills, spells, items and abilities are named from the client\'s own tables; a mob TP move with no client-side name shows its number rather than a wrong word.' },
    { label = 'Tries',  width = 52,
      tip = 'Every attempt: hits, misses, resists and shadowed swings together.' },
    { label = 'Hits',   width = 52,
      tip = 'Attempts that dealt damage.' },
    { label = 'Total',  width = 90,
      tip = 'Damage this action has dealt in total.' },
    { label = 'Avg',    width = 70,
      tip = 'Total divided by hits -- the average of the ones that landed, not of every attempt.' },
    { label = 'Max',    width = 70,
      tip = 'The biggest single result from this action.' },
    -- Stretching rather than 130 fixed pixels: the widest note this can
    -- carry is three phrases -- "100% crit, 12 shadowed, 8 resisted" -- and
    -- 130 pixels cut it in half.
    { label = 'Notes',  stretch = 1.0,
      tip = 'Crit rate over the hits that landed, then how many attempts a shadow ate and how many were resisted.' },
};

local HEAL_DETAIL_COLUMNS = {
    { label = 'Action', stretch = 1.0,
      tip = 'The cure, waltz, ability or item that restored the HP.' },
    { label = 'Casts',  width = 60,
      tip = 'How many times it landed on somebody.' },
    { label = 'Total',  width = 90,
      tip = 'HP this action has restored in total.' },
    { label = 'Avg',    width = 70,
      tip = 'Total divided by casts.' },
    { label = 'Max',    width = 70,
      tip = 'The biggest single heal from this action.' },
};

local TAKEN_DETAIL_COLUMNS = {
    { label = 'From',  stretch = 1.0,
      tip = 'Who dealt it. A monster out of range when the blow landed cannot be named and is left out of this list, though its damage is still in the total above.' },
    { label = 'Hits',  width = 60,
      tip = 'Blows from this attacker that landed.' },
    { label = 'Total', width = 90,
      tip = 'Damage this attacker has dealt to the selected member.' },
    { label = 'Avg',   width = 70,
      tip = 'Total divided by hits.' },
    { label = 'Max',   width = 70,
      tip = 'The biggest single blow from this attacker.' },
};


local detailCache = { rev = -1, name = false, kind = false, rows = { }, header = '', sub = '' };

local function buildDetail(kind, row)
    if (detailCache.rev == modelRev and detailCache.name == row.name
            and detailCache.kind == kind) then
        return detailCache;
    end

    detailCache.rev  = modelRev;
    detailCache.name = row.name;
    detailCache.kind = kind;
    detailCache.rows = { };

    local source, labels = nil, { };

    if (kind == 'heal') then
        source = row.heals;

        detailCache.header = string.format('%s - %s HP healed', row.name, comma(row.heal.total));
        detailCache.sub    = row.heal.mp > 0 and string.format('  %s MP restored', comma(row.heal.mp)) or nil;
    elseif (kind == 'taken') then
        source = row.sources;

        detailCache.header = string.format('%s - %s taken over %d hits',
            row.name, comma(row.taken.total), row.taken.hits);
        detailCache.sub    = string.format('  evaded %d, shadows %d, healed for %s',
            row.taken.evades, row.taken.shadows, comma(row.taken.healed));
    else
        source = row.actions;

        detailCache.header = string.format('%s - %s damage', row.name, comma(row.dmg.total));
        detailCache.sub    = string.format('  max %s (%s)', comma(row.dmg.max), row.dmg.maxLabel);
    end

    for label in pairs(source) do
        labels[#labels + 1] = label;
    end

    table.sort(labels, function (a, b)
        local at, bt = source[a].total, source[b].total;

        -- Name as the tie-break, so two actions on the same total do not
        -- swap places every time `pairs` walks the table in a new order.
        if (at == bt) then
            return a < b;
        end

        return at > bt;
    end);

    for _, label in ipairs(labels) do
        local b    = source[label];
        local cell = { label = label, total = comma(b.total), max = comma(b.max) };

        if (kind == 'dmg') then
            local notes = T{ };

            if (b.crits > 0) then
                notes:append(string.format('%.0f%% crit', 100 * b.crits / math.max(b.landed, 1)));
            end

            if (b.shadows > 0) then
                notes:append(string.format('%d shadowed', b.shadows));
            end

            if (b.resists > 0) then
                notes:append(string.format('%d resisted', b.resists));
            end

            cell.tries  = tostring(b.count);
            cell.hits   = tostring(b.landed);
            cell.avg    = comma(b.total / math.max(b.landed, 1));
            cell.notes  = notes:concat(', ');
        else
            cell.count = tostring(b.count);
            cell.avg   = comma(b.total / math.max(b.count, 1));
        end

        detailCache.rows[#detailCache.rows + 1] = cell;
    end

    return detailCache;
end

local function detailPane()
    local row = state.selected ~= nil and parse.actors[state.selected] or nil;

    if (row == nil) then
        imgui.TextDisabled('Click a name for its breakdown.');

        return;
    end

    local kind = (state.tab == 'heal' or state.tab == 'taken') and state.tab or 'dmg';
    local view = buildDetail(kind, row);

    imgui.Text(view.header);

    if (view.sub ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled(view.sub);
    end

    local columns = DMG_DETAIL_COLUMNS;

    if (kind == 'heal') then
        columns = HEAL_DETAIL_COLUMNS;
    elseif (kind == 'taken') then
        columns = TAKEN_DETAIL_COLUMNS;
    end

    if (imgui.BeginTable('##dwparse_detail_' .. kind, #columns, TABLE_FLAGS, { -1, -1 })) then
        setupColumns(columns);
        imgui.TableSetupScrollFreeze(0, 1);
        headerRow(columns);

        for _, cell in ipairs(view.rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(cell.label);

            if (kind == 'dmg') then
                imgui.TableNextColumn();
                imgui.Text(cell.tries);
                imgui.TableNextColumn();
                imgui.Text(cell.hits);
                imgui.TableNextColumn();
                imgui.Text(cell.total);
                imgui.TableNextColumn();
                imgui.Text(cell.avg);
                imgui.TableNextColumn();
                imgui.Text(cell.max);
                imgui.TableNextColumn();
                imgui.Text(cell.notes);
            else
                imgui.TableNextColumn();
                imgui.Text(cell.count);
                imgui.TableNextColumn();
                imgui.Text(cell.total);
                imgui.TableNextColumn();
                imgui.Text(cell.avg);
                imgui.TableNextColumn();
                imgui.Text(cell.max);
            end
        end

        imgui.EndTable();
    end
end

local function nameCell(cell)
    if (imgui.Selectable(cell.label, state.selected == cell.name)) then
        state.selected = (state.selected == cell.name) and nil or cell.name;
    end
end

--[[
* How much of the tab the breakdown pane takes. 160 pixels of empty bordered
* box for the sentence "Click a name for its breakdown." was a third of the
* window at the default size and most of it at the minimum, so the pane is
* one line tall until there is something in it.
--]]
local function detailHeight()
    if (state.selected ~= nil and parse.actors[state.selected] ~= nil) then
        return 160;
    end

    return math.floor(fontMetrics().line + 14);
end

-- The row of numbers under every table: what the party is doing between them,
-- and how many rows the find box is showing.
local function footerLine(view)
    imgui.TextDisabled(view.footer);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Everything on this tab added up, over combat time -- first event to last, not wall clock. "Shown" counts the rows the find box left on screen; the totals are always the whole fight.');
    end
end

local function damageTab()
    local view   = buildView('dmg');
    local detail = detailHeight();

    if (imgui.BeginTable('##dwparse_dmg', #DMG_COLUMNS, TABLE_FLAGS,
            { -1, -(detail + fontMetrics().line + 6) })) then
        setupColumns(DMG_COLUMNS);
        imgui.TableSetupScrollFreeze(0, 1);
        headerRow(DMG_COLUMNS);

        for _, cell in ipairs(view.rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(cell.rank);

            imgui.TableNextColumn();
            nameCell(cell);

            imgui.TableNextColumn();
            imgui.Text(cell.value);

            imgui.TableNextColumn();
            imgui.Text(cell.rate);

            imgui.TableNextColumn();

            -- The one live column: the window slides with the wall clock, so
            -- it is read fresh rather than out of the view cache.
            local recent = recentDps(cell.row);

            if (recent > 0) then
                imgui.Text(comma(recent));
            else
                imgui.TextDisabled('-');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Nothing from this actor in the last thirty seconds.');
                end
            end

            imgui.TableNextColumn();
            drawShareBar(cell.share, cell.shareText);

            imgui.TableNextColumn();

            if (cell.acc ~= nil) then
                imgui.Text(cell.acc);
            else
                imgui.TextDisabled('-');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('No melee or ranged swings yet -- accuracy is only about those, so a pure caster never grows one.');
                end
            end

            imgui.TableNextColumn();
            imgui.Text(cell.max);

            if (imgui.IsItemHovered() and cell.maxLabel ~= '') then
                imgui.SetTooltip(cell.maxLabel);
            end
        end

        imgui.EndTable();
    end

    footerLine(view);

    imgui.BeginChild('##dwparse_dmgdetailpane', { 0, 0 }, ImGuiChildFlags_Borders);
    detailPane();
    imgui.EndChild();
end

local function healingTab()
    local view   = buildView('heal');
    local detail = detailHeight();

    if (imgui.BeginTable('##dwparse_heal', #HEAL_COLUMNS, TABLE_FLAGS,
            { -1, -(detail + fontMetrics().line + 6) })) then
        setupColumns(HEAL_COLUMNS);
        imgui.TableSetupScrollFreeze(0, 1);
        headerRow(HEAL_COLUMNS);

        for _, cell in ipairs(view.rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(cell.rank);

            imgui.TableNextColumn();
            nameCell(cell);

            imgui.TableNextColumn();
            imgui.Text(cell.value);

            imgui.TableNextColumn();
            imgui.Text(cell.rate);

            imgui.TableNextColumn();
            drawShareBar(cell.share, cell.shareText);

            imgui.TableNextColumn();

            if (cell.mp ~= nil) then
                imgui.Text(cell.mp);
            else
                imgui.TextDisabled('-');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('This actor has restored no MP to anybody.');
                end
            end

            imgui.TableNextColumn();
            imgui.Text(cell.max);

            if (imgui.IsItemHovered() and cell.maxLabel ~= '') then
                imgui.SetTooltip(cell.maxLabel);
            end
        end

        imgui.EndTable();
    end

    footerLine(view);

    imgui.BeginChild('##dwparse_healdetailpane', { 0, 0 }, ImGuiChildFlags_Borders);
    detailPane();
    imgui.EndChild();
end

local function takenTab()
    local view   = buildView('taken');
    local detail = detailHeight();

    if (imgui.BeginTable('##dwparse_taken', #TAKEN_COLUMNS, TABLE_FLAGS,
            { -1, -(detail + fontMetrics().line + 6) })) then
        setupColumns(TAKEN_COLUMNS);
        imgui.TableSetupScrollFreeze(0, 1);
        headerRow(TAKEN_COLUMNS);

        for _, cell in ipairs(view.rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(cell.rank);

            imgui.TableNextColumn();
            nameCell(cell);

            imgui.TableNextColumn();
            imgui.Text(cell.value);

            imgui.TableNextColumn();
            imgui.Text(cell.hits);

            imgui.TableNextColumn();
            imgui.Text(cell.avg);

            imgui.TableNextColumn();
            imgui.Text(cell.max);

            if (imgui.IsItemHovered() and cell.maxLabel ~= '') then
                imgui.SetTooltip('From ' .. cell.maxLabel);
            end

            imgui.TableNextColumn();
            imgui.Text(cell.avoided);

            imgui.TableNextColumn();
            imgui.Text(cell.healed);
        end

        imgui.EndTable();
    end

    footerLine(view);

    imgui.BeginChild('##dwparse_takendetailpane', { 0, 0 }, ImGuiChildFlags_Borders);
    detailPane();
    imgui.EndChild();
end

--[[
* The Threat tab (1.1.0): who the current target swings at next, from the
* server's real enmity numbers. The hello is asked from HERE -- the first
* frame the tab is looked at in a zone -- so a player who never opens it
* never handshakes and the server never walks their target's list.
--]]
--[[
* Threat row names, cached for a second (1.2.0). This ran trackedSet() AND
* entityName() for every row and every recent change, on every frame -- and
* entityName for a player-range id that is not in the entity array scans 1280
* entity slots, so one holder who had walked out of range cost 1280 reads per
* row per frame. One second is the window trackedSet already rebuilds on, so
* a name that comes back into range still appears just as fast as it did.
--]]
local threatNameCache = { at = 0, names = { } };

function threatName(id)
    if (elapsed(threatNameCache.at) >= 1.0) then
        threatNameCache.at    = os.clock();
        threatNameCache.names = { };
    end

    local name = threatNameCache.names[id];

    if (name == nil) then
        local tracked = trackedSet();

        name = tracked[id] or entityName(id) or string.format('#%d', id);
        threatNameCache.names[id] = name;
    end

    return name;
end

-- The kinds the server's enmity hooks name (dwe_protocol.md, the c| record).
local THREAT_KINDS = {
    d = 'damage',
    c = 'cure',
    o = 'action',
    h = 'hit taken',
    l = 'lowered',
    t = 'transferred',
};

-- One sentence per kind, for the hover on the word itself. The blanket
-- sentence over the whole section could only ever describe all six at once.
local THREAT_KIND_TIPS = {
    d = 'Damage dealt to this monster. The largest single source of hate in almost every fight.',
    c = 'A cure cast anywhere in the party: the monster resents healing whether or not it was the one hit.',
    o = 'An action with its own enmity: a spell or ability\'s base hate, an Enmity+ effect, the grant for pulling it in the first place.',
    h = 'A blow this holder took FROM the monster. Being hit spends hate, which is why a tank losing aggro is often a tank who has not been hit.',
    l = 'An ability that drained hate away -- and it comes off CE and VE at once.',
    t = 'Hate handed between two players. This is the receiving side of the transfer.',
};

local THREAT_COLUMNS = {
    { label = '#',      width = 26,
      tip = 'The monster\'s own ranking. Row one is who its next swing belongs to.' },
    { label = 'Name',   stretch = 1.0,
      tip = 'Who holds the hate. Names are resolved on this side from the same party memory and entity array the parse rows use -- the server sends only ids, so the meter and the parse can never disagree about who somebody is.' },
    { label = 'Enmity', width = 96,
      tip = 'CE + VE added together: the exact sum the monster\'s own AI ranks its targets by. Cumulative enmity is the slow half and volatile enmity the half that decays.' },
    { label = 'vs top', width = 104,
      tip = 'This holder measured against row one. A bar near full is somebody one weaponskill away from taking the monster off the tank.' },
};

local CHANGE_COLUMNS = {
    { label = 'Who',    stretch = 1.0,
      tip = 'Whose action moved the hate.' },
    { label = 'What',   width = 96,
      tip = 'What kind of change it was. Hover the word itself for what that kind means.' },
    { label = 'Moved',  width = 190,
      tip = 'How much CE and VE the change actually applied, AFTER the server\'s own caps -- not what the action was worth on paper.' },
};

local CHANGES_TIP = 'The last changes to this monster\'s hate list, newest first: who, what caused it, and how much CE and VE moved.\nDamage and cures build hate; a hit you take costs you some; Lowered is an ability draining it; Transferred is hate handed to someone else.';

--[[
* THE METER'S OWN VIEW CACHE (1.2.0). Same rule as the parse tabs one shelf
* up: the rows and the changes are spelled once per COMMITTED reply -- the
* server sends at most one every two seconds, and only when something moved --
* rather than once per frame. Names are the deliberate exception and stay
* live: an id resolves as soon as its entity comes into range, and threatName
* carries its own one-second cache for that.
--]]
local threatView = { rev = -1, rows = { }, events = { } };

local function buildThreatView()
    if (threatView.rev == state.threatRev) then
        return threatView;
    end

    threatView.rev    = state.threatRev;
    threatView.rows   = { };
    threatView.events = { };

    local rows = state.threat.rows;
    local top  = #rows > 0 and math.max(rows[1].total, 1) or 1;

    for rank, row in ipairs(rows) do
        threatView.rows[rank] = {
            id        = row.id,
            rank      = tostring(rank),
            total     = comma(row.total),
            share     = row.total / top,
            shareText = string.format('%.1f%%', 100 * row.total / top),
        };
    end

    for index, event in ipairs(state.threat.events or { }) do
        threatView.events[index] = {
            id   = event.id,
            kind = event.kind,
            -- The words are the kinds the server names; a letter this addon
            -- does not know renders as itself rather than as somebody else's
            -- word, and says so on hover.
            word = THREAT_KINDS[event.kind] or event.kind,

            -- Signed per VALUE, not per pair: a change can build cumulative
            -- enmity while spending volatile, and a "+" in front of a negative
            -- number is the one thing a meter must never print.
            text = string.format('%s%s CE   %s%s VE',
                event.ce >= 0 and '+' or '', comma(event.ce),
                event.ve >= 0 and '+' or '', comma(event.ve)),
            good = (event.ce + event.ve) >= 0,
        };
    end

    return threatView;
end

local function threatTab()
    needThreat();

    if (state.refused) then
        imgui.TextDisabled('The server speaks a newer threat protocol.');
        imgui.TextDisabled('Update dwparse through the launcher.');

        return;
    end

    if (state.threatSilent) then
        imgui.TextDisabled('The server did not answer the threat handshake.');
        imgui.TextDisabled('It returns on the next zone. Is DriftwoodXI up to date?');

        return;
    end

    local mob = state.threat.mob;

    if (mob == nil or #state.threat.rows == 0) then
        imgui.TextDisabled('No enmity yet. Select or fight a monster --');
        imgui.TextDisabled('the meter shows who its next swing belongs to.');

        return;
    end

    local entity  = AshitaCore:GetMemoryManager():GetEntity();
    local mobName = entity ~= nil and entity:GetName(mob) or nil;

    imgui.Text(string.format('Enmity on %s',
        (mobName ~= nil and mobName ~= '') and mobName or string.format('target #%d', mob)));

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('The monster you are fighting, or the one under your cursor when you are not engaged. The server picks it; the meter follows.');
    end

    local view = buildThreatView();

    --[[
        THE RANKING AND THE CHANGES ARE TWO TABLES (1.2.0). They used to share
        one, and the changes borrowed its columns: the kind went under the
        "Enmity" header and the whole "+2,400 CE  +12,000 VE" string under a
        104-pixel "vs top" column, which cut it in half. Two tables cost one
        Separator and let each say what its own columns mean.
    ]]
    local rankHeight = -1;

    if (#view.events > 0) then
        -- The ranking is at most eight rows (dwe_protocol.md) and does not
        -- need the rest of the tab; the changes are the half that grows.
        local rowH  = fontMetrics().frame;
        local _, av = imgui.GetContentRegionAvail();

        rankHeight = (#view.rows + 1) * rowH + 8;

        if (type(av) == 'number' and av > 0) then
            rankHeight = math.min(rankHeight, math.max(av * 0.55, rowH * 2));
        end
    end

    if (imgui.BeginTable('##dwparse_threat', #THREAT_COLUMNS, TABLE_FLAGS, { -1, rankHeight })) then
        setupColumns(THREAT_COLUMNS);
        imgui.TableSetupScrollFreeze(0, 1);
        headerRow(THREAT_COLUMNS);

        for rank, row in ipairs(view.rows) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row.rank);

            imgui.TableNextColumn();

            -- The top row is the mob's next target (modulo the engine's
            -- battle-target tie-break), so it is the one row worth a colour.
            if (rank == 1) then
                imgui.TextColored(theme.colors.warn, threatName(row.id));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Holding aggro: the next swing is theirs to eat.');
                end
            else
                imgui.Text(threatName(row.id));
            end

            imgui.TableNextColumn();
            imgui.Text(row.total);

            imgui.TableNextColumn();
            drawShareBar(row.share, row.shareText);
        end

        imgui.EndTable();
    end

    if (#view.events == 0) then
        return;
    end

    imgui.Spacing();
    imgui.TextDisabled('Recent changes');

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(CHANGES_TIP);
    end

    if (imgui.BeginTable('##dwparse_threat_changes', #CHANGE_COLUMNS, TABLE_FLAGS, { -1, -1 })) then
        setupColumns(CHANGE_COLUMNS);
        imgui.TableSetupScrollFreeze(0, 1);
        headerRow(CHANGE_COLUMNS);

        for _, event in ipairs(view.events) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(threatName(event.id));

            imgui.TableNextColumn();
            imgui.TextDisabled(event.word);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(THREAT_KIND_TIPS[event.kind]
                    or 'A kind of enmity change this build of dwparse does not have a word for. Update through the launcher.');
            end

            imgui.TableNextColumn();

            if (event.good) then
                imgui.TextColored(theme.colors.ok, event.text);
            else
                imgui.TextColored(theme.colors.err, event.text);
            end
        end

        imgui.EndTable();
    end
end

--[[
* THE CONTROL-ROW TIPS, AS DATA (1.2.0). Kept in one table for the reason the
* column tips are: the wording of the whole strip can be read at once, and the
* harness can assert it rather than guess where a sentence went.
--]]
local TIPS = {
    reset     = 'Clear the parse back to zero. Zoning and squad recalls never clear it; only this does.',
    pause     = 'Stop counting new events. Everything already collected stays exactly as it is, and unticking picks the same parse back up. The Threat tab is live either way -- it is the server\'s number, not a tally.',
    partyOnly = 'Track only the party and its pets. Untick to track every actor in range, mobs included.\nRows already earned stay either way.',
    channel   = 'Which chat channel Export speaks into. Echo is local -- nobody else sees it -- and is the one to use while you are still deciding.',
    export    = 'Speak the tab on screen into the chosen channel, one line at a time: a heading and the top eight rows.',
    copy      = 'Put the same parse on the clipboard instead of into chat -- for a post outside the game, or for one worth keeping. The clipboard has no line budget, so it takes up to thirty-two rows rather than the eight a chat channel is owed.',
    find      = 'Show only the rows whose name contains what you type. It filters Damage, Healing and Taken; the Threat tab is the server\'s own ranking and is never filtered.\nIt is a view and nothing more: the totals underneath, and everything Export and Copy say, always describe the whole fight.',
    clock     = 'Time spent in combat -- the first event to the most recent one, never wall clock, so the walk back to camp is not in it. Every rate on every tab is measured over this. A count of queued lines means an Export is still waiting on the client\'s chat throttle.',
    idle      = 'Nothing has been counted yet. The parse reads the same battle packets the client draws its own combat log from, so anything that happens on screen lands here.',
};

local TAB_TIPS = {
    dmg    = 'Damage dealt, per actor: total, DPS, the last thirty seconds, share of the party, accuracy and the biggest hit.',
    heal   = 'HP restored, per actor, with MP restored ranked alongside it. Drains count as damage and not as healing, so this tab is restorative output only.',
    taken  = 'Damage the PARTY took, whoever dealt it, with what was evaded, what a shadow ate, and what was healed back.',
    threat = 'Real enmity from the server for the monster you are fighting or targeting -- the addon\'s one server conversation. Nothing on the client can compute enmity, so these are the numbers the monster itself ranks its next swing by.',
};

-- One short tip on the item just drawn. Every plain tooltip in the strip goes
-- through here so the pattern cannot drift call site by call site.
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* THE MINIMUM SIZE (1.2.0). ImGui remembers a window's size across sessions
* -- that is what ImGuiCond_FirstUseEver means, and why NoSavedSettings is
* refused suite-wide -- INCLUDING a size dragged down to nothing by accident,
* which then persists forever with the tab bar and the totals line off the
* bottom and NoScrollbar leaving nothing to scroll back to them.
*
* Measured rather than picked, so it cannot drift when a column does: the
* WIDEST of the three tabs' fixed columns add up to their own widths, and the
* stretching Name column still needs room for a pet's "Carbuncle (Ayla)".
--]]
local MIN_NAME_WIDTH = 120;

-- Reused rather than rebuilt: ImGui reads the pair immediately and the
-- window is constrained on every frame it is open.
local minSize   = { 626, 250 };
local minSizeAt = -1;

local function minimumSize()
    local now = os.clock();

    if (now - minSizeAt >= 1.0) then
        minSizeAt = now;

        local width = 0;

        for _, columns in ipairs({ DMG_COLUMNS, HEAL_COLUMNS, TAKEN_COLUMNS }) do
            local wide = 40;

            for _, column in ipairs(columns) do
                wide = wide + (column.width or MIN_NAME_WIDTH);
            end

            if (wide > width) then
                width = wide;
            end
        end

        -- Two control rows, the status line, the tab bar, a few table rows,
        -- the totals line and the breakdown pane's own line.
        local m = fontMetrics();

        minSize[1] = math.floor(width);
        minSize[2] = math.floor(m.frame * 5 + m.line * 6);
    end

    return minSize;
end

local NO_MAX_SIZE = { 99999, 99999 };

--[[
* One tab. `key` is what the rest of the addon calls this tab, and what a
* restored or typed selection asks for -- ImGui consumes the SetSelected flag
* at the NEXT BeginTabBar, so the ask is re-asserted until this tab is the one
* actually drawing, and the remembered choice is not overwritten in the
* meantime by the tab the window happened to open on (the dwfishing note).
*
* The three-argument BeginTabItem is the form dwfishing and dwgmpanel both
* ship unguarded, so it is used the same way here.
--]]
local function tabItem(key, label, tipText, body)
    local flags = ImGuiTabItemFlags_None;

    if (state.wantTab == key) then
        flags = ImGuiTabItemFlags_SetSelected;
    end

    local open = imgui.BeginTabItem(label, nil, flags);
    local over = imgui.IsItemHovered();

    if (open) then
        if (state.wantTab == key) then
            state.wantTab = nil;
        end

        if (state.wantTab == nil and state.tab ~= key) then
            state.tab = key;

            saveConfig();
        end

        body();
        imgui.EndTabItem();
    end

    if (over) then
        imgui.SetTooltip(tipText);
    end
end

local function renderWindow()
    if (imgui.Button('Reset')) then
        resetParse();
    end

    tip(TIPS.reset);

    imgui.SameLine();
    imgui.Checkbox('Pause', state.paused);
    tip(TIPS.pause);

    imgui.SameLine();

    if (imgui.Checkbox('Party only', state.partyOnly)) then
        saveConfig();
    end

    tip(TIPS.partyOnly);

    imgui.SameLine();

    if (parse.startedAt ~= nil) then
        imgui.TextDisabled(string.format('%s combat%s%s',
            clockText(combatSeconds()),
            state.paused[1] and '  [paused]' or '',
            #queue > 0 and string.format('  %d queued...', #queue) or ''));
        tip(TIPS.clock);
    else
        imgui.TextDisabled(state.paused[1] and '[paused]' or 'waiting for combat');
        tip(TIPS.idle);
    end

    --[[
        The second control row (1.2.0). The strip used to be one SameLine
        chain of six controls and a clock -- about six hundred pixels that
        wrapped into itself the moment the window was narrowed -- and the find
        box the sibling addons all have had nowhere to go. Split: what the
        parse IS on the first row, what to DO with it on the second.
    ]]
    imgui.PushItemWidth(200);
    imgui.InputTextWithHint('##dwparse_find', 'find a name...', state.search, FIND_MAX + 1);
    imgui.PopItemWidth();
    tip(TIPS.find);

    imgui.SameLine();
    imgui.PushItemWidth(90);

    if (imgui.BeginCombo('##dwparse_channel', CHANNELS[state.channel].label)) then
        for index, channel in ipairs(CHANNELS) do
            if (imgui.Selectable(channel.label, state.channel == index)) then
                state.channel = index;

                saveConfig();
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
    tip(TIPS.channel);

    imgui.SameLine();

    if (imgui.Button('Export')) then
        exportTab();
    end

    tip(TIPS.export);

    imgui.SameLine();

    if (imgui.Button('Copy')) then
        copyTab();
    end

    tip(TIPS.copy);

    -- A sentence about something that happened goes back to the idle line
    -- once it has been on screen long enough to read; one about a state that
    -- still holds carries no expiry and stays.
    -- Through elapsed() so a wrapped clock expires the sentence rather than
    -- pinning it: the stamp is the moment it was SET, and the linger is the
    -- distance from there.
    if (state.statusUntil ~= nil and elapsed(state.statusUntil - STATUS_LINGER) >= STATUS_LINGER) then
        setStatus(IDLE_STATUS, false, false);
    end

    if (state.status ~= nil and state.status ~= '') then
        -- Wrapped rather than clipped: a server sentence (`m|`, `e|`) is as
        -- long as the server made it, and NoScrollbar means an over-wide line
        -- is simply cut off at the frame edge with no way to see the rest.
        imgui.PushTextWrapPos(0);

        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end

        imgui.PopTextWrapPos();
    end

    imgui.Separator();

    -- Built before the tab bar because the tab LABELS carry their counts, and
    -- cached, so building all three costs a revision compare on a frame where
    -- nothing has happened.
    local dmgView   = buildView('dmg');
    local healView  = buildView('heal');
    local takenView = buildView('taken');

    if (imgui.BeginTabBar('##dwparse_tabs')) then
        --[[
            `###` on every label so the tab's IDENTITY is the fixed half: the
            counts move as rows appear, and a tab whose id moved with its
            label would lose the player's place every time somebody new landed
            a hit (the dwah note on its Activity tab).
        ]]
        tabItem('dmg', dmgView.tabLabel, TAB_TIPS.dmg, damageTab);
        tabItem('heal', healView.tabLabel, TAB_TIPS.heal, healingTab);
        tabItem('taken', takenView.tabLabel, TAB_TIPS.taken, takenTab);
        tabItem('threat', 'Threat###dwparse_tab_threat', TAB_TIPS.threat, threatTab);

        imgui.EndTabBar();
    end
end

ashita.events.register('d3d_present', 'dwparse_present', function ()
    -- Before the visibility check: an export issued a moment before the
    -- window was closed still has to reach the party.
    pumpQueue();

    -- The character check armed by the last zone-in: a different name on
    -- party slot 0 means a different account view, and their parse should
    -- not inherit this one.
    if (state.charCheckAt ~= nil and os.clock() >= state.charCheckAt) then
        local party = AshitaCore:GetMemoryManager():GetParty();
        local name  = party ~= nil and party:GetMemberName(0) or '';

        if (name ~= nil and name ~= '') then
            if (state.charName ~= nil and name ~= state.charName) then
                resetParse('New character - parse cleared.');
            end

            state.charName    = name;
            state.charCheckAt = nil;
        else
            state.charCheckAt = os.clock() + 2.0;
        end
    end

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSizeConstraints(minimumSize(), NO_MAX_SIZE);
    imgui.SetNextWindowSize({ 660, 480 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Parse##dwparse', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwparse'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwparse'):append(chat.message('Window closed. The parse itself is intact; /parse reopens it.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

-- Anything the player types counts against the client's chat rate limit, so
-- an export queued behind a typed line waits its interval instead of racing
-- it and being the one that gets dropped.
ashita.events.register('packet_out', 'dwparse_packet_out', function (e)
    if (e.id == 0x00B5) then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwparse_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Parse`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwparse' and first ~= '/parse' and first ~= '/dwp') then
        return;
    end

    e.blocked = true;

    local verb = (#args > 1) and args[2]:lower() or '';

    if (verb == 'reset' or verb == 'clear') then
        resetParse();
        print(chat.header('dwparse'):append(chat.message('Parse cleared.')));

        return;
    end

    if (verb == 'pause') then
        state.paused[1] = not state.paused[1];
        print(chat.header('dwparse'):append(chat.message('Parsing is now ')):append(chat.success(state.paused[1] and 'paused' or 'running')):append(chat.message('.')));

        return;
    end

    if (verb == 'export' or verb == 'copy') then
        if (#args > 2) then
            local wanted = args[3]:lower();
            local found  = nil;

            -- AN EMPTY ARGUMENT MATCHES NOTHING, not everything: `sub(1, 0)`
            -- is the empty string and compared equal to every channel, so the
            -- LAST one silently won and the export went to /echo.
            if (wanted ~= '') then
                for index, channel in ipairs(CHANNELS) do
                    if (channel.label:lower():sub(1, #wanted) == wanted) then
                        found = index;
                    end
                end
            end

            if (found == nil) then
                print(chat.header('dwparse'):append(chat.error(string.format(
                    'no channel called "%s". Try party, say, linkshell or echo.', args[3]))));

                return;
            end

            state.channel = found;

            saveConfig();
        end

        if (verb == 'copy') then
            copyTab();
        else
            exportTab();
        end

        return;
    end

    if (verb == 'find') then
        -- Everything after the verb, as typed: a name is one word, but this
        -- way `/parse find` on its own is how the box is cleared.
        local wanted = '';

        for index = 3, #args do
            wanted = (wanted == '') and args[index] or (wanted .. ' ' .. args[index]);
        end

        state.search[1] = wanted:sub(1, FIND_MAX);

        print(chat.header('dwparse'):append(chat.message(wanted == ''
            and 'Find box cleared.'
            or ('Showing rows matching "' .. state.search[1] .. '".'))));

        return;
    end

    if (verb == 'help') then
        print(chat.header('dwparse'):append(chat.message('/parse toggles the window. Subcommands: reset, pause, find [name], export [party|say|linkshell|echo], copy.')));

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too.
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwparse_load', function ()
    state.charCheckAt = os.clock() + 3.0;

    print(chat.header('dwparse'):append(chat.message('/parse (or /dwparse) opens the parser. It keeps counting across zones and squad recalls; Reset starts it over.')));

    -- Said ONCE, at load, and only when a field actually had to be replaced:
    -- a settings file that a hand edit or an older build left unreadable
    -- costs the preferences in it and nothing else, but the player is owed
    -- the sentence rather than a window that quietly forgot their channel.
    if (configRepaired) then
        print(chat.header('dwparse'):append(chat.error('some saved settings could not be read and went back to their defaults.')));
    end
end);
