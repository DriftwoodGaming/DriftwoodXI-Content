--[[
* DriftwoodXI -- dwquest
*
* The Drift Board in a window: the eight daily and six weekly contracts
* offered to your level band, the ones you have signed with their counters
* moving as you fight, what each pays, how long is left, and your Drift Coins.
* Accept and abandon are buttons, and the header line sells Drift Coins for
* gil at the rate the server sends. `/quests` opens it from anywhere -- there is
* no NPC to walk to, because the window IS the quest giver.
*
* The arrows by the band label page through every level band's board, and
* SINCE 1.26.0 a band at or below your own can be signed from where you are
* standing (owner request 2026-09-07: a level 99 farming band 1 should not
* have to equip a level-20 job to sign band 1's daily). The Accept button on
* a lower band's card sends the band it is displaying -- `!dwu accept d1 2`
* -- so the contract is written for the board on screen; a band ABOVE yours is
* still a read, and its cards carry a sentence instead of a button. One
* contract per slot per reset holds ACROSS bands either way: an offer whose
* slot is already spent renders its sentence, not a button.
*
* Below them sits the server-wide contract: one bar the whole server pushes,
* with no button, because there is no verb that accepts it -- you contribute by
* killing, and the card's job is to say whether this account is on the payout.
*
* THE SECOND TAB IS ACCEPTED, AND IT EXISTS BECAUSE THE BOARD OUTGREW ITSELF
* (1.25.0, owner request 2026-09-07: "as we've added more and more quest rows
* players are being spammed with more options and the Board tab is long and
* overwhelming"). Two lists had been living in one panel and they answer two
* different questions -- "what could I sign" and "what am I holding" -- so the
* Board now draws the `o|` offers ONLY and every `a|` row moves here: the
* counters, the reward, the time left, and the Abandon button that tears one
* up. Nothing about the model moved. The records are parsed exactly as they
* were, the same one list keyed on qkey, and a contract inside its grace
* period still carries its own name and reward because it is not on any
* board -- this is where the window DRAWS them, not what it knows.
*
* The Board keeps the cue, though. An offer this account already holds still
* shows its counter and reads `signed` rather than `Accept`, because "which
* of today's fourteen do I already have" is a question about the BOARD; only
* the tracked list itself, and the one button that can destroy progress,
* went one tab over.
*
* BOTH TABS CARRY THE TWO EIGHTS, and only when the server sent them. The
* `y|` header grew four counters (dwu_protocol.md, positions 10-13):
* accepted-now, accepted-max, completed-today, completed-max, always all four
* or none. Present, they draw as one line on Board and Accepted alike and the
* Accept buttons on open offers become a sentence once the slots are full;
* absent -- an older server -- this window says NOTHING about a cap it has
* not been told about, the gil exchange's rule for the same reason.
*
* AND A ROW THE DAILY CAP IS HOLDING SAYS SO. A contract whose progress has
* reached its needed count while its state is still `active` is finished and
* unpaid: the server's completion budget for this Vana'diel day is spent, and
* it settles on the next day's first read. That row draws as complete, says
* when it pays, and offers NO Abandon -- the server refuses it, and a button
* that can only be refused is worse than no button.
*
* The third tab is the Enchanter -- the Drift Exchange under the name the tab
* bar wears since 1.25.0: today's four augment offers, the gear
* they can go on -- yours and your offline alts' -- how many of an item's four
* augment slots are used, and the two-step price-then-buy that spends the
* coins the first tab earns.
*
* The fourth tab is SeeAugs, the augment reference (2026-08-19; the tab wore
* the word `Augments` until 1.25.0): every augment id the
* server's engine implements, with the label a player can read beside the
* number the exdata actually stores -- because the Enchanter shows occupied
* slots by id, and "which augment do I give up" is unanswerable in raw
* numbers. Rows the Enchanter sells are marked with their tier price, and the
* four on offer TODAY are marked off the same u| records the Enchanter tab
* renders, with a Choose button that feeds the same picker. The catalog
* itself is augcatalog.lua beside this file -- GENERATED from sql/augments.sql
* by tools/dwquest/gen_augment_catalog.py, never edited by hand, and gated
* byte-for-byte by the same checkers that gate the storefront -- because ~700
* labeled rows can never ride a 130-byte-per-line chat wire. The same catalog
* decodes the Enchanter tab's slot views in place ("Dbl.Atk.+3%" instead of
* "augment 143 rank 3"), computing each rank's real magnitude only where the
* generator could VERIFY the arithmetic against the engine's own formula.
* Missing catalog file = the raw numbers this window always showed, plus a
* line saying so; nothing else degrades.
*
* The fifth tab is the Outfitter (Phase 7; the relic tier joined 2026-08-22,
* the job capes 2026-08-26, the Empyrean +2 and AF +1 tiers 2026-09-03): the
* level 50-60 artifact sets, the level-74 AF +1 sets, the relic sets, the
* level 81-89 Empyrean +2 sets, the job capes at levels 1/40/75/99 and the
* level 27-33 race gear, each row priced off the wire
* (the tiers differ), paged by job, every row drawn with the
* client's own item icon
* and hover card off the id the f| record carries. Static stock, no rotation
* -- and every piece but the race gear is Rare/Ex, so what this shop sells
* can reach your own characters through the dwbags lane and can never leave
* your account.
*
* The ArmsDealer (2026-08-20) and the Pop-Items shelf (2026-08-30) follow it,
* and the Jeweler (2026-09-03) sits last: the CoP-era earrings and rings --
* the Wyrmking five, the Sea three, the Apocalypse Nigh rings -- priced per
* case off the wire, the whole shelf on one read under its case headers, the
* same Buy-quotes / Confirm-spends dance and the same Rare/Ex rule.
*
* THE POP-ITEMS SHELF CARRIES A FIND BOX (1.23.0) and none of the others do,
* because it is the only list long enough to need one: twenty-five keys under
* five tier headings, and what a player arrives knowing is the NAME OF THE
* MONSTER, not which tier it is filed under. It is entirely local -- the whole
* shelf travels on one read, so nothing about typing in it reaches the wire --
* and it searches the words the row already draws: the monster, its zone, and
* the item names the client's own DATs answered with.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It ships no pool, no prices, no progress and no arithmetic. Every contract,
* every count, every reward and every countdown arrives as _DWUDATA records
* answering `!dwu hello` (documentation/dwu_protocol.md), and the server
* re-resolves the contract from its own rotation whichever way the command
* arrived. A click issues a line a player could type (`!dwu accept d1`), and
* THE CLIENT NEVER SENDS A QUEST DEFINITION -- it sends a slot name. There is
* no record on this wire that could tell the server what a contract needs,
* pays, or is worth, so a bug in this window cannot mint a coin.
*
* THE SAME IS TRUE OF THE STOREFRONT, WHERE IT MATTERS MORE. The price is a
* `p|` record; the item is named by the id a `c|` record carried; the eligible
* gear is the server's own screen and not this client's inventory, which
* cannot see an offline alt's bags and knows none of the rules. The Confirm
* button exists only while a quote is armed, a quote is armed only by a `p|`,
* and the click that sends `confirm` disarms it in the same statement -- so
* one quote can buy at most one thing, and a window that never asked can buy
* nothing at all.
*
* THE HEADER LINE ALSO BUYS AND ACCOUNTS. The gil exchange (2026-09-04) sells
* Drift Coins for gil at the rate and ceiling the `y|` header carries -- drawn
* only when a server sends them, because a Buy that can only ever answer
* "unknown verb" is worse than no Buy -- and the coin ledger (1.22.0, the
* `Ledger` button) answers the question a balance provokes: the lifetime
* earned and spent totals and the last five movements on the account, off the
* `balance` verb that has carried them since Phase 1. Beside it the options
* drawer (1.23.0, the `Options` button) is where the two switches at the
* bottom of this comment finally have a control: they PERSIST, and until then
* the only way to reach either was a command the login banner mentions once.
*
* NO ANSWER EVER HALF-FILLS A PANEL (1.23.0). A reply's records build in a
* staging table and replace their section whole at the `z|` -- dwbags' SECTIONS
* shape, and this protocol's own client discipline. Wiping at `d|` and
* refilling record by record made every panel state, for the frames in
* between, that the server was not stocked; and it clamped each pane's scroll
* to the top of an empty list, so a player reading the bottom of the board was
* thrown back up by their own Accept.
*
* THE ONE NUMBER THAT MOVES LOCALLY IS A CLOCK. The board header and every
* contract carry countdowns that were exact when the server built the record;
* the window ticks them down between syncs and re-asks when the rotation one
* reaches zero (dwu_protocol.md, `y|`). Nothing else here is computed --
* not a price, not a payout, not a progress count. The one exception proves
* the rule: the ledger says how long ago a database timestamp was, which is
* arithmetic over a CLOCK and not over a coin.
*
* TYPING `!drift` ON ITS OWN OPENS THIS WINDOW. The line is intercepted before
* it leaves the client; every other !drift command passes through.
*
* IT ALSO MOVES REWARD TEXT OUT OF THE BATTLE LOG. Fields of Valor, Grounds of
* Valor and Records of Eminence payouts are drawn by the CLIENT from message
* ids, so the server cannot tag them the way it tags a Drift Board notice --
* and they land in the same window as a dozen damage lines a second. This addon
* blocks them and re-prints them where the rest of its output goes.
* `/quests rewards off` turns that off and it stays off -- and since 1.23.0
* the Options drawer on the header line is the same switch, clicked.
*
* AND IT FILES THE KILL FEED UNDER CHAT (2026-08-30). The defeat line, the
* exp, limit and capacity chains with their payouts, and the gil line are
* re-moded into a chat-group channel -- Window 2 on the stock log config --
* and colour-coded per family, so a payout is not drowned by the spam in
* Window 1. `/quests feed off` turns that off and it stays off too, and the
* Options drawer carries it beside the other one.
*
* TURN IT ALL OFF AND NOTHING IS LOST. `!drift`, `!drift accept d1`,
* `!drift abandon a1`, `!drift balance`, `!drift gil 10`, `!drift augments`,
* `!drift gear x1`, `!drift augment x1 Bronze Sword`, `!drift shelf war`,
* `!drift buy 21`, `!drift arms dynamis`, `!drift armsbuy 1101`,
* `!drift pops`, `!drift popbuy 2401`, `!drift jeweler`,
* `!drift jewelbuy 3101` and `!drift confirm` all work typed. This is
* friendlier; it is not required.
--]]

addon.name    = 'dwquest';
addon.author  = 'DriftwoodXI';
addon.version = '1.26.0';
addon.desc    = 'The Drift Board for DriftwoodXI -- daily, weekly and server-wide contracts, live progress, Drift Coins, the coin ledger, the Accepted tab, the augment Enchanter with a full augment reference, the Outfitter, the ArmsDealer, the Pop-Items shelf, and the Jeweler.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local theme    = require('dwtheme');
local echo     = require('dwecho');
local settings = require('settings');

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load: this addon is
* loaded from the launcher's boot script, long before the client has a
* rendering device, and a file-scope d3d.get_device() would make the whole
* addon fail to load (dwbags' lesson, kept verbatim via dwraid). Nothing
* here needs a device until the first Outfitter icon is drawn.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. Nine
-- other addons own nine other names; this addon must never contend for any of
-- them, which is why `!dwu` exists at all -- the obvious `!dwq` belongs to
-- alt storage (DWQUEST_PLAN.md F1).
local DATA_SENDER = '_DWUDATA';

-- Bumped only for a breaking change to the record layout.
local PROTOCOL = 1;

--[[
* The augment catalog -- augcatalog.lua beside this file, GENERATED by
* tools/dwquest/gen_augment_catalog.py (see the header). pcall'd because a
* half-synced addon folder is a real deployment state (the 2026-08-16 stamped
* bundle closed the common case, not every case), and a missing reference
* file must cost exactly the reference: the window falls back to the raw
* numbers it always showed, and the SeeAugs tab says what is missing.
--]]
local haveCatalog, augcatalog = pcall(require, 'augcatalog');

if (not haveCatalog or type(augcatalog) ~= 'table'
        or type(augcatalog.augments) ~= 'table' or type(augcatalog.pool) ~= 'table') then
    haveCatalog = false;
    augcatalog  = { augments = { }, pool = { } };
end

--[[
* The Weapon Burst shelf's ten augments (weapon_burst.sql ids 2030..2039)
* are DriftwoodXI's own, so the generated catalog never learns them --
* overlaid here rather than hand-edited into the generated file, which a
* catalog rebuild would silently drop. Without a name the slot renders as
* 'augment 2030 rank 1' (owner report, 2026-08-25).
--]]
for offset, element in ipairs({
    'Fire', 'Ice', 'Wind', 'Earth', 'Thunder',
    'Water', 'Light', 'Dark', 'Shield', 'Enfeeble',
}) do
    local augid = 2029 + offset;

    if (augcatalog.augments[augid] == nil) then
        augcatalog.augments[augid] = { l = string.format('Weapon Burst: %s', element) };
    end
end

--[[
* The X-Magic shelf's five augments (xmagic.sql ids 2040..2044) are the same
* case one shelf over, and they were MISSED when X-Magic shipped: the
* SeeAugs tab listed the ten Weapon Burst rows and not one X-Magic row, so
* the feature's own reference tab denied it existed and a ring that carried
* one read 'augment 2040 rank 1' (owner report, 2026-09-06).
*
* The labels are quest_xmagic.lua's ROWS labels, character for character --
* tools/dwquest/check_xmagic.py asserts that here and in dwbags.lua, so the
* shelf renaming a type cannot leave either window saying the old name.
--]]
for offset, kind in ipairs({
    'Elements', 'Grace', 'Ruin', 'Siphon', 'Veil',
}) do
    local augid = 2039 + offset;

    if (augcatalog.augments[augid] == nil) then
        augcatalog.augments[augid] = { l = string.format('X-Magic: %s', kind) };
    end
end

--[[
* One augment slot, in words. `rank` is the wire's human rank (the stored
* exdata value plus one -- quest_store.cpp:2110).
*
* An entry with substitution terms gets its digit runs recomputed for this
* rank: term k applies to the k-th digit run, a bare number n means
* n + stored, a pair { b, s } means b + stored * s -- the generator emits a
* term ONLY where it verified that arithmetic against the engine's own
* formula, so this function never invents a magnitude. An entry without
* terms keeps its rank-1 label and says the rank instead; an id the catalog
* does not know renders as the raw number it always was.
--]]
local function augmentText(augid, rank)
    local entry = augcatalog.augments[augid];

    if (entry == nil) then
        return string.format('augment %d rank %d', augid, rank);
    end

    local label  = entry.l;
    local stored = rank - 1;

    if (entry.m ~= nil) then
        if (stored > 0) then
            local k = 0;

            label = string.gsub(label, '%d+', function(digits)
                k = k + 1;

                local term = entry.m[k];

                if (term == nil) then
                    return digits;
                end

                if (type(term) == 'table') then
                    return tostring(term[1] + stored * term[2]);
                end

                return tostring(term + stored);
            end);
        end
    elseif (rank > 1) then
        label = string.format('%s (rank %d)', label, rank);
    end

    return string.format('%s  [%d]', label, augid);
end

--[[
* THE NOTICE TAG -- the literal quest_core.lua puts in front of every
* unsolicited line the Drift Board prints into chat, and the whole reason the
* text_in handler at the bottom of this file exists.
*
* WHY THE SERVER CANNOT JUST SEND IT TO THE RIGHT WINDOW. The client shows two
* chat logs and routes a line between them by the message CATEGORY, mapped to a
* window by the player's own filter config. The 0x017 packet the server writes
* with has a Kind, an Attr, a zone id and 150 bytes of text -- and no window
* field (src/map/packets/s2c/0x017_chat_std.h). Every DriftwoodXI module prints
* on SYSTEM_3, so on the ordinary two-window setup -- battle left, chat right --
* a payout arrives in the same window as a dozen lines a second of somebody
* else's damage numbers. That is the complaint this answers.
*
* WHAT ACTUALLY MOVES IT. An addon's own `print()` does not travel the 0x017
* path at all; it is written into the log directly and lands with the rest of a
* player's addon chatter, which is the window they keep for reading. So the
* server tags, this file blocks the tagged line, and print() puts the same
* sentence back where it can be read. Nothing else in the client is reachable
* from here, and nothing on the server can substitute for it.
*
* KEEP IN SYNC WITH `NOTICE` IN modules/driftwoodxi/quest_core.lua. One literal
* across a server module and a client addon that ship on separate paths is the
* shape that drifts silently -- a mismatch is not an error anywhere, it is just
* every notice quietly back in the battle log. harness_dwquest.py reads both
* real files and fails when they disagree, and the map's boot line prints this
* value verbatim so prod can be asked what it is actually sending.
*
* MATCHED ANYWHERE IN THE LINE, not anchored: the client hands a line to
* text_in with whatever decoration it carries, and a tag that only matches at
* byte one is a tag that silently stops matching the day a prefix appears. The
* cost of the loose match is that a player who types the tag by hand has the
* rest of their sentence re-printed one window over, which is a curiosity
* rather than a bug -- against a payout line that arrives during an AoE pull
* and is never seen, that trade is not close.
--]]
local NOTICE_TAG = '[Drift] ';

--[[
* THE REWARD REROUTE -- the same lever as the notice tag, pointed at lines the
* server cannot tag at all.
*
* Fields of Valor, Grounds of Valor and Records of Eminence do not print
* sentences. They send message ids -- `player:messageBasic(xi.msg.basic.
* FOV_OBTAINS_TABS, ...)` in scripts/globals/regimes.lua, ROE_COMPLETE and
* friends in scripts/globals/roe.lua -- and the CLIENT draws the words out of
* its own dat files. There is no string on the server to put `[Drift] ` in
* front of, and 0x0029 (GP_SERV_COMMAND_BATTLE_MESSAGE) has no window field any
* more than 0x0017 does. So a payout of 426 tabs lands in the battle log beside
* a dozen damage lines a second, which is the complaint this answers, and the
* ONLY place it can be answered is here: text_in sees the line after the client
* has rendered it, print() can put it somewhere else.
*
* (That text_in sees client-rendered battle messages at all is not an
* assumption: the bundled LootScope reads `X defeats MobName.` from it, and
* customcolors recolours the whole venture/trial family the same way.)
*
* MATCHING IS ON THE RENDERED ENGLISH, which is the part that can rot. A dat
* file wording that moves is a pattern that silently stops matching -- so the
* patterns are deliberately the SHORTEST distinctive fragment of each line
* rather than the whole sentence, and every one of them is asserted against the
* xi.msg.basic comment for its own message id in harness_dwquest.py. That
* harness reads scripts/enum/msg.lua, so a server that renumbers or reworders a
* message is a red gate rather than a feature that quietly stopped working.
*
* TWO LISTS, BECAUSE HALF THESE LINES ARE NOT EXCLUSIVE TO A REWARD.
*
*   FAMILY  -- fragments that can only come from a regime or a record. `obtains
*              426 tabs.` is one: tabs exist nowhere else on this server.
*              Rerouted whenever they arrive.
*
*   BURST   -- fragments that are ordinary battle-log traffic on their own.
*              `gains 2140 experience points.` is the same message id on a
*              regime completion and on every mob you kill, so rerouting it by
*              pattern would empty the battle log of exp. These move ONLY
*              inside a reward burst: a short window opened by one of the
*              ANCHOR lines below, which are the sentences a payout always
*              follows (`...completed the training regime.`, `...Records of
*              Eminence objective: ...`).
*
* THE PER-KILL PROGRESS LINE IS NOT AN ANCHOR, deliberately. `You defeated a
* designated target. (Progress: 2/2)` fires on every credited kill, so opening
* a burst on it would reroute the exp line of every kill a player makes while
* a regime is up -- which is not "the reward text", it is the battle log.
*
* THE BURST REFRESHES ON EVERY LINE IT TAKES rather than counting from the
* anchor. A completion is seven lines that arrive together and the window only
* has to outlive the gap between two of them; a fixed deadline from the anchor
* would have to be long enough for the whole burst and would therefore be long
* enough to catch an unrelated kill at the end of it.
--]]
local REWARD_FAMILY = T{
    -- Fields of Valor / Grounds of Valor (scripts/globals/regimes.lua).
    'You defeated a designated target',              -- FOV_DEFEATED_TARGET 558
    'successfully completed the training regime',    -- FOV_COMPLETED_REGIME 559
    'training regime will begin anew',               -- FOV_REGIME_BEGINS_ANEW 643
    'obtains [%d,]+ tabs?%.',                        -- FOV_OBTAINS_TABS 566
    'Prowess attained',                              -- the GoV prowess effects

    -- Records of Eminence (scripts/globals/roe.lua).
    'completed the following Records of Eminence objective', -- ROE_COMPLETE 690
    'This objective may be repeated',                -- ROE_REPEAT_OR_CANCEL 691
    'sparks of eminence',                            -- ROE_RECEIVE_SPARKS 692, FIRST_TIME 707
    'As a special bonus for your valiant efforts',   -- ROE_BONUS_ITEM 693/694/709
    'Records of Eminence: ',                         -- ROE_RECORD 697
    'A new objective has been added',                -- ROE_NEW_OBJECTIVE 699
    'as a special reward',                           -- ROE_OBTAINED_KEY_ITEM 706
    'cleared to fulfill this objective once again',  -- ROE_TIMED_CLEAR 710
    'Unity accolade',                                -- ROE_RECEIVED_ACCOLADES 741
};

local REWARD_BURST = T{
    'obtains [%d,]+ gil',                            -- FOV_OBTAINS_GIL 565
    'gains [%d,]+ experience points',                -- and the record's exp
    'gains [%d,]+ limit points',
    'Progress: %d+/%d+%.',                           -- ROE_PROGRESS 698
};

local REWARD_ANCHORS = T{
    'successfully completed the training regime',
    'completed the following Records of Eminence objective',
    'Records of Eminence: ',
};

--[[
* WHAT COLOUR A MOVED LINE IS PRINTED IN.
*
* Seven lines arrive together on a page completion and they are not seven of
* the same thing: one says a regime finished, three say what it paid, one is a
* counter. Printed in a single colour they read as a wall -- which is what the
* battle log did to them, and moving the wall one window over only makes it a
* quieter wall. Four buckets, so the eye can find the payout without reading.
*
* THE CODES ARE COLOUR TABLE 1, and every one of them is a colour the Ashita
* chat library names, so a reader can look it up rather than trust a number:
* LawnGreen 2, Cyan 6, Moccasin 7 and Yellow 69 (libs/chat.lua, chat.colors).
* `chat.message`'s own cream 106 is deliberately NOT one of them -- it stays the
* colour of everything else this addon prints, so a rerouted reward line is
* visibly a different kind of line from a Drift Board notice.
*
* KEYED BY THE ADDON'S OWN PATTERN TEXT, and every pattern in REWARD_FAMILY and
* REWARD_BURST must appear here -- harness_dwquest.py fails when one does not.
* That is the same shape as the harness's REWARD_SOURCES map and it is there
* for the same reason: the cost of a missing entry is not a crash, it is one
* line that quietly goes back to looking like all the others, which nobody
* would notice for months. A plain table, not T{ }: the keys are arbitrary
* pattern text and T{ }'s sugar method names shadow string keys.
--]]
local TINT_MILESTONE = 2;   -- LawnGreen: the thing that completed.
local TINT_CURRENCY  = 69;  -- Yellow:    gil, tabs, sparks, accolades, items.
local TINT_POINTS    = 6;   -- Cyan:      experience and limit points.
local TINT_PROGRESS  = 7;   -- Moccasin:  counters and bookkeeping.
local TINT_LIMIT     = 73;  -- Violet:    limit points and limit chains (the feed).
local TINT_CAPACITY  = 8;   -- Coral:     capacity points and capacity chains (the feed).

local REWARD_TINTS = {
    ['You defeated a designated target']                      = TINT_PROGRESS,
    ['successfully completed the training regime']             = TINT_MILESTONE,
    ['training regime will begin anew']                        = TINT_PROGRESS,
    ['obtains [%d,]+ tabs?%.']                                 = TINT_CURRENCY,
    ['Prowess attained']                                       = TINT_MILESTONE,
    ['completed the following Records of Eminence objective']  = TINT_MILESTONE,
    ['This objective may be repeated']                         = TINT_PROGRESS,
    ['sparks of eminence']                                     = TINT_CURRENCY,
    ['As a special bonus for your valiant efforts']            = TINT_CURRENCY,
    ['Records of Eminence: ']                                  = TINT_MILESTONE,
    ['A new objective has been added']                         = TINT_PROGRESS,
    ['as a special reward']                                    = TINT_CURRENCY,
    ['cleared to fulfill this objective once again']           = TINT_PROGRESS,
    ['Unity accolade']                                         = TINT_CURRENCY,
    ['obtains [%d,]+ gil']                                     = TINT_CURRENCY,
    ['gains [%d,]+ experience points']                         = TINT_POINTS,
    ['gains [%d,]+ limit points']                              = TINT_POINTS,
    ['Progress: %d+/%d+%.']                                    = TINT_PROGRESS,
};

--[[
* THE KILL FEED (2026-08-30) -- the owner's report, verbatim shape: the defeat
* line, the limit and capacity chains and their payouts, and the gil line "get
* drowned out quickly during the spam that's sent to Window #1".
*
* THIS ONE DOES NOT print(). The client draws two chat logs and files a line
* between them by its CATEGORY; the player's Log config maps categories to
* windows, and on the STOCK config (config addon README, ids 185-188) Window 1
* is all battle/system and Window 2 is all chat. So the lever is the line's
* MODE: text_in hands it to us writable as e.mode_modified (the bundled
* timestamp addon rewrites it the same way), and a line re-moded into the CHAT
* group is a line the client files in Window 2. Mode 222 is Assist E
* (server Kind NA_ASSIST) -- a chat-group channel nothing on this server ever
* speaks on, so hijacking it collides with nobody. The line itself is
* re-written as its cleaned text wrapped in a colour tag, so the feed is
* colour-coded per family at a glance.
*
* WHAT THE HARNESS CANNOT PROVE, stated rather than hidden: that the client
* files a line by its MODIFIED mode, and which Log-config bit maps Assist E to
* which window, are facts about the running client -- the harness proves what
* this handler emits, not where the client draws it (DWQUEST_PLAN.md said the
* same of the reward reroute). If the feed still lands left, the fallback is
* the reward reroute's block-and-print shape. `/quests feed off` either way.
*
* POLARITY, OPPOSITE OF THE REWARD REROUTE'S, on purpose. The reroute is a
* refusal list because a missed notice is the failure that matters there. The
* feed MOVES lines out of the battle log wholesale, so here the harmful
* failure is taking a line that was not ours -- it matches only on an exact
* battle-message mode AND a pattern, and an event with no mode is refused.
* The mode numbers are the client's, read out of the DAT-extracted resource
* tables shipped with both Windower and simplelog (res/action_messages), not
* guessed: 36 carries the defeat family, 127 the obtains family, 131 the
* exp/limit/capacity family.
*
* EVERY PATTERN NAMES ITS MESSAGE ID -- harness_dwquest.py reads them out of
* this table and holds each against the wording recorded beside that id in
* src/map/enums/msg_basic.h, the same contract the reward patterns keep with
* scripts/enum/msg.lua. The chain messages carry their payout sentence in the
* same message (a <br> seam), so 'Limit chain' and 'gains ... limit points'
* both match one rendered event; the chain patterns sit first so the tint of
* a chain line is the chain family's.
--]]
local FEED_MODE_DEFEATS = 36;   -- DefeatsTarget 6
local FEED_MODE_OBTAINS = 127;  -- Obtains 565 (and 582, the actor form)
local FEED_MODE_POINTS  = 131;  -- exp 8/253, limit 371/372, capacity 718/735

-- Assist E: chat-group, Window 2 on the stock config, dead on this server.
local FEED_WINDOW_MODE = 222;

local FEED_LINES = T{
    ' defeats ',                          -- DefeatsTarget 6
    'EXP chain',                          -- ExpChain 253
    'gains [%d,]+ experience points',     -- ExperiencePointsGained 8
    'Limit chain',                        -- LimitChain 372
    'gains [%d,]+ limit points',          -- LimitPointsGained 371
    'Capacity chain',                     -- CapacityChain 735
    'gains [%d,]+ capacity points',       -- CapacityPointsGained 718
    'obtains [%d,]+ gil',                 -- Obtains 565
};

-- Which of the three battle modes each pattern is allowed to take a line on.
-- Keyed by the addon's own pattern text, same as REWARD_TINTS; a pattern
-- listed without a mode here never fires (the harness holds both directions).
local FEED_MODES = {
    [' defeats ']                      = FEED_MODE_DEFEATS,
    ['EXP chain']                      = FEED_MODE_POINTS,
    ['gains [%d,]+ experience points'] = FEED_MODE_POINTS,
    ['Limit chain']                    = FEED_MODE_POINTS,
    ['gains [%d,]+ limit points']      = FEED_MODE_POINTS,
    ['Capacity chain']                 = FEED_MODE_POINTS,
    ['gains [%d,]+ capacity points']   = FEED_MODE_POINTS,
    ['obtains [%d,]+ gil']             = FEED_MODE_OBTAINS,
};

-- One colour per family, so the feed reads at a glance: kills green, gil
-- yellow, experience cyan, limit violet, capacity coral.
local FEED_TINTS = {
    [' defeats ']                      = TINT_MILESTONE,
    ['EXP chain']                      = TINT_POINTS,
    ['gains [%d,]+ experience points'] = TINT_POINTS,
    ['Limit chain']                    = TINT_LIMIT,
    ['gains [%d,]+ limit points']      = TINT_LIMIT,
    ['Capacity chain']                 = TINT_CAPACITY,
    ['gains [%d,]+ capacity points']   = TINT_CAPACITY,
    ['obtains [%d,]+ gil']             = TINT_CURRENCY,
};

--[[
* Modes the UNTAGGED reward reroute refuses to look at.
*
* The tagged reroute below is deliberately mode-blind and stays that way: the
* tag is a far narrower match than any mode is. This list guards the OTHER
* branch, which has no tag to match on and therefore matches plain English --
* 'Records of Eminence: ', 'sparks of eminence', 'Prowess attained'. All three
* are sentences a player can type, and the first is also a burst ANCHOR, so a
* single shout reading "Records of Eminence: anyone want to duo?" was blocked
* AND opened a five-second window that pulled the next exp and gil lines out of
* the battle log with it.
*
* Written as a REFUSAL LIST rather than an allow list, on purpose and for this
* file's stated priority: missing a notice is the failure that matters, so a
* mode nobody has enumerated must still reroute. Only what is known to carry
* text a person typed is excluded.
*
* What is known here: the mode arrives packed and the id is its low byte
* (customcolors.lua in the shipped bundle: `bit.band(e.mode_modified, 0xFF)`).
* That file names the two anchors this boundary sits between -- NS_SAY is 9,
* another player's say; SYSTEM_3, the channel every DriftwoodXI module and
* every server reward message speaks on, is 121. The client's chat modes are
* the low block and its system and battle-log modes are far above it, so 32 is
* a boundary with room on both sides rather than a measured edge. If a reward
* line ever turns up below it, narrow this to the exact ids instead of raising
* it -- that direction fails safe and this one does not.
--]]
local PLAYER_CHAT_MODE_MAX = 31;

-- Seconds a burst stays open past the last line it took. Long enough to cross
-- the gap inside one payout, short enough that the next mob's exp is not in it.
local REWARD_BURST_SECS = 5.0;

-- The ceiling on one burst's WHOLE life, measured from the anchor that opened
-- it. Extension alone never closes: the per-kill progress line is family, so
-- with kills under five seconds apart every extension bought another window,
-- the exp line it dragged out extended it again, and one page completion moved
-- every subsequent kill's exp and gil out of the battle log for as long as the
-- pace held. A payout's own lines arrive inside a second or two; ten is
-- generous to the payout and nothing else.
local REWARD_BURST_MAX_SECS = 10.0;

--[[
* The one thing in this addon a player can turn off and have it stay off.
*
* Flat scalars only -- Ashita's settings serializer takes booleans, numbers and
* strings, and a nested table here is a silent loss on save (dwcon's note).
*
* The notice tag is NOT on this switch. That reroute is the Drift Board's own
* output and a player who did not want it would uninstall the addon; this one
* moves lines that belong to systems the addon does not own, so it is the one
* that owes an off switch.
--]]
local defaultConfig = T{
    rewards = true,
    feed    = true,
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

pcall(settings.register, 'settings', 'dwquest_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end
end);

-- os.clock() at which the open reward burst lapses. Nil means no burst.
local rewardBurstUntil = nil;

-- os.clock() at which the open burst was ANCHORED -- the fixed point the
-- REWARD_BURST_MAX_SECS ceiling is measured from. Set and cleared with
-- rewardBurstUntil, never separately.
local rewardBurstOpened = nil;

--[[
* A chat line with the client's and the other addons' decoration taken off.
*
* WHY THE OLD ONE-LINER WAS NOT ENOUGH (2026-08-11). This used to be a single
* `gsub('[^\032-\126]', '')` inline in the handler, which deletes every byte
* outside printable ASCII. That is right about which bytes are decoration and
* wrong about how wide a piece of decoration is: the client and Ashita both
* mark text up with TWO-byte tags -- a control byte and an ARGUMENT byte that
* is very often an ordinary letter or digit. Strip only the control byte and
* the argument is left sitting in the sentence. Three of them were, in every
* rerouted line, and the screenshot that reported it reads:
*
*     [22:05:12] [dwquest] Q[22:05:12] Realtester obtains 315 tabs. (...)1
*                          ^ ^^^^^^^^^                                    ^
*
*   Q   is `\30\81` -- DarkOrchid, opened by the bundled `timestamp` addon
*       (addons/timestamp/timestamp.lua, format '\30\81[%H:%M:%S]\30\01').
*       81 is 'Q'. The closing `\30\01` loses both bytes because 1 is not
*       printable either, which is why only the OPENING tag left a scar.
*   [22:05:12] is that addon's stamp. It runs on text_in ahead of this handler,
*       so what we read is already stamped -- and our own print() goes back
*       through text_in and is stamped AGAIN. Re-emitting the first stamp is
*       how one line ends up wearing two.
*   1   is `\127\49`, the client's own end-of-message marker. The bundled
*       `enternity` addon strips exactly this pair (`string.char(0x7F, 0x31)`),
*       which is where the identification comes from rather than a guess.
*
* SO THE TAG AND ITS ARGUMENT GO TOGETHER -- the colour tags, the client's
* end-of-message pair, AND the auto-translate brackets, whose argument bytes
* (\39, \40) are printable and would otherwise be left as a stray quote and
* parenthesis -- and the blanket strip stays behind them for everything else:
* the packet's NUL padding, anything a future addon decorates with. A lone tag
* byte at the very end of a string has no argument to eat and is caught by the
* blanket pass.
*
* THE STAMP IS TAKEN OFF THE FRONT AND OFF EVERY SEAM. Anchored-only was the
* first fix, and it survived exactly until a message with a `<br>` in its dat
* text: the timestamp addon stamps every RENDERED line, so a two-line message
* arrives wearing two clocks, and the second sits mid-string where an anchored
* pattern never looks. The seam form requires leading whitespace (which the
* line-break replacement guarantees) and a full bracketed clock; a player who
* has typed `/ts format` into something else keeps their own prefix, and that
* is the right failure -- a looser match would start eating the front of
* sentences that merely open with a bracket.
--]]
local function plainText(raw)
    -- Two-byte tags first, BOTH bytes: `\30`/`\31` are the colour tags Ashita's
    -- own chat library writes, `\127` is the client's, and `\239` leads the
    -- auto-translate brackets (\239\39 opens, \239\40 closes) -- whose argument
    -- bytes are a printable quote and parenthesis, exactly the kind of scar the
    -- blanket pass below cannot see.
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    -- The line-break bytes become a seam SPACE, not nothing: the dat files
    -- break several reward messages across two lines (`<br>` renders as \7,
    -- and the timestamp addon rewrites it to a real newline), and deleting the
    -- byte glued the halves together -- "...target.(Progress: 2/2)".
    text = text:gsub('[\007\010\013]+', ' ');

    -- Then everything else that cannot be drawn: NUL padding, a tag byte that
    -- had no argument left to take.
    text = text:gsub('[^\032-\126]', '');

    -- And the stamps, which we are about to be given a fresh one of. The
    -- timestamp addon stamps every RENDERED line, so a message the dat file
    -- breaks with <br> carries two clocks and only the first is at the front.
    -- The seam form goes FIRST and must follow whitespace (the seam space
    -- above guarantees one), so a sentence that merely contains a bracketed
    -- clock hard against a word keeps it; then the anchored form takes the
    -- leading stamp. This order, because the anchored strip eats the
    -- whitespace after itself -- run first, it would leave a second
    -- consecutive stamp sitting at the front with nothing for the seam form
    -- to match on.
    text = text:gsub('%s%[%d%d?:%d%d:%d%d%]%s*', ' ');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return text;
end

--[[
* Does this line belong to a reward payout, and may it be moved?
*
* Returns THE PATTERN THAT TOOK IT when the caller should block and re-print,
* and nil when it should not. A pattern is truthy, so every `if isRewardLine`
* written against the old boolean still reads correctly -- and the caller needs
* the identity, not the verdict, to pick the line's colour (REWARD_TINTS). A
* second lookup in the caller would have been a second copy of this loop, and
* two copies of a match is two copies to disagree.
*
* `now` is passed in rather than read here so one text_in call reads the clock
* exactly once: a handler that asked twice could open a burst against one
* reading and test it against another, which is the kind of thing that works on
* every machine except somebody's.
--]]
local function isRewardLine(line, now)
    if (config.rewards == false) then
        return nil;
    end

    for _, pattern in ipairs(REWARD_FAMILY) do
        if (line:find(pattern) ~= nil) then
            local opens = false;

            for _, anchor in ipairs(REWARD_ANCHORS) do
                if (line:find(anchor) ~= nil) then
                    opens = true;
                    break;
                end
            end

            -- An anchor OPENS a burst; any other family line only EXTENDS one
            -- that is already open. The distinction is the per-kill progress
            -- line: it is family (nothing else says it) but it must not drag
            -- an ordinary kill's exp out of the battle log with it.
            if (opens) then
                rewardBurstOpened = now;
                rewardBurstUntil  = now + REWARD_BURST_SECS;
            elseif (rewardBurstUntil ~= nil and now <= rewardBurstUntil) then
                -- An extension never outlives the ceiling: without it, kills
                -- under five seconds apart renewed each other forever (see
                -- REWARD_BURST_MAX_SECS).
                rewardBurstUntil = math.min(now + REWARD_BURST_SECS, rewardBurstOpened + REWARD_BURST_MAX_SECS);
            end

            return pattern;
        end
    end

    if (rewardBurstUntil == nil or now > rewardBurstUntil) then
        return nil;
    end

    for _, pattern in ipairs(REWARD_BURST) do
        if (line:find(pattern) ~= nil) then
            -- Refreshed, not merely tested -- but never past the ceiling: a
            -- taken exp line renewing the window that took it is exactly the
            -- loop REWARD_BURST_MAX_SECS exists to close.
            rewardBurstUntil = math.min(now + REWARD_BURST_SECS, rewardBurstOpened + REWARD_BURST_MAX_SECS);
            return pattern;
        end
    end

    return nil;
end

--[[
* The colour a moved line is printed in, by the pattern that took it.
*
* Falls back to `chat.message`'s cream rather than throwing or printing
* colourless, because the one thing this must not do is lose the line: a
* pattern added to REWARD_FAMILY without an entry in REWARD_TINTS is a harness
* failure at the desk, not a swallowed payout in somebody's chat log.
--]]
local function tintFor(pattern)
    local tint = REWARD_TINTS[pattern];

    if (tint == nil) then
        return 106;
    end

    return tint;
end

--[[
* State.
*
* Everything server-derived is replaced wholesale by a `board` envelope and
* never merged, so a contract that expired between syncs cannot survive as a
* stale card. A `ping` is the deliberate exception: it carries only the rows
* that moved, so it merges (dwu_protocol.md, "The ping").
*
* `actives` and `offerByKey` are PLAIN tables, not T{ }: they are keyed by
* quest keys and slot names, and T{ }'s sugar method names shadow string keys
* -- the collision that cost dwbags a round.
--]]
local state = T{
    open        = T{ false },

    -- The y| header. clockAt is the os.clock() at which the two countdowns
    -- were true, which is the only thing that makes ticking them down honest.
    poolVersion = nil,
    day         = nil,
    band        = nil,     -- the band the board ON SCREEN was resolved for
    playerBand  = nil,     -- the character's own band (y|'s appended field)
    secsToDay   = nil,
    secsToWeek  = nil,
    clockAt     = nil,
    rollAsked   = false,

    -- The gil exchange's rate and ceiling, APPENDED to y| on 2026-09-04 and
    -- absent on a server that predates it -- which is why nil draws no
    -- control at all rather than a Buy that could only answer "unknown
    -- verb". Listed here rather than only assigned in the y| handler,
    -- because this table is the file's inventory of what the window knows
    -- and a field that appears out of a handler is one nobody can find.
    gilPerCoin  = nil,
    gilMaxCoins = nil,

    -- The two eights, APPENDED to y| on 2026-09-07 (positions 10-13) and
    -- absent on a server that predates them -- same rule, same reason, one
    -- field further along: nil says nothing about a cap rather than
    -- inventing one. `capsLine` and `fullNote` are the two sentences these
    -- numbers make, composed once where the header lands rather than by two
    -- panels every frame.
    acceptedCount = nil,   -- contracts this account is holding right now
    acceptedMax   = nil,   -- how many it may hold at once
    doneToday     = nil,   -- contracts it has completed this Vana'diel day
    doneMax       = nil,   -- how many it may complete in one
    capsLine      = nil,
    fullNote      = nil,

    -- The Burst Token purse, part 3 of the storefront `g|` (append-only
    -- growth, 2026-08-25). nil until a server that knows the currency
    -- answers: an invented zero would read as "you have none" on a server
    -- that simply predates the arena.
    burstBalance = nil,

    -- The band the player asked to LOOK at, nil for their own. Drives which
    -- board is requested; what is RENDERED is always the y| the server
    -- answered with, so the label cannot outrun the data under it.
    viewBand    = nil,

    offers      = { },     -- o| records, in wire order
    actives     = { },     -- [qkey] = a| record
    activeOrder = { },     -- qkeys, in the order the server listed them

    balance     = nil,     -- g|; nil means the server did not say

    -- The coin ledger (1.22.0), read only while the player asks for it: the
    -- lifetime totals off the three-part g| and up to five l| lines, newest
    -- first. `ledgerOpen` is the player's toggle and gates BOTH the read and
    -- the block -- a window that asked for a ledger nobody wanted would pay
    -- a wire line per session for a panel nobody is looking at.
    ledgerOpen  = false,
    ledger      = { },     -- l| records, in wire order
    earned      = nil,
    spent       = nil,

    -- The options drawer (1.23.0), the ledger's own shape: shut by default,
    -- costs nothing while it is, and it is where the two switches that
    -- PERSIST live. They had no control anywhere in the window until then --
    -- `/quests rewards off` and `/quests feed off` were the only way to reach
    -- a feature the load banner mentions once and nothing repeats.
    optionsOpen = false,

    -- q| -- the server-wide contract. nil means the server sent no q| record,
    -- which means there is no community contract this week. It is NOT drawn as
    -- an empty bar: a bar at 0/0 is a contract the window invented.
    community   = nil,

    synced      = false,   -- gates the panel: no cards until the first z|board

    -- True once a d| has arrived this session. Auto-syncs (zone-in) stay off
    -- until then: an unknown !command falls through to /say, and an automatic
    -- line against a dead verb is the player saying it in public.
    serverSpoke = false,

    inbound     = nil,     -- the verb whose envelope is currently open

    status      = 'Loading...',
    statusBad   = false,
    reported    = false,   -- a render error is worth saying once, not per frame

    toast       = nil,
    toastAt     = nil,

    now         = 0,       -- os.clock(), read once per frame (see present)
};

--[[
* THE EXCHANGE TAB (DWQUEST_PLAN.md Phase 4).
*
* Everything here arrives on the wire and nothing here is decided locally. The
* four offers and their prices are `u|` records; the list of gear that can take
* one is `c|` records off the server's own eligibility screen -- NOT the
* client's inventory, which cannot see an offline alt's bags and does not know
* a single one of the rules; the "N of 4 slots used" line is `k|`; and the
* price a purchase is confirmed at is the `p|` record's, never a number this
* file worked out.
*
* THE ONE RULE WITH MONEY BEHIND IT: `quote` is created by a `p|` record and by
* nothing else, and the Confirm button does not exist unless one is armed. A
* storefront button that could buy on the line it also uses to ask is the
* incident that produced dwmerc's quote/confirm pair -- an addon that reloaded
* and forgot it had already asked. Clicking Confirm disarms the quote in the
* same statement that queues the line, so one `p|` can be confirmed at most
* once, and a refusal arms nothing.
*
* PLAIN TABLES, not T{ }: `slots` is keyed by index and `gear` by wire order,
* and T{ }'s sugar method names shadow string keys.
--]]
local shop = {
    -- The v| header. clockAt is the os.clock() the countdown was true at.
    poolVersion = nil,
    day         = nil,
    secsToRoll  = nil,
    clockAt     = nil,
    rollAsked   = false,

    offers      = { },     -- u| records, in wire order
    -- The same four offers keyed by augment id, built once at the `z|` that
    -- commits them. The Augments reference tab marks its [today] rows off
    -- this: rebuilding the map inside the render was a table allocated and
    -- four inserts EVERY FRAME for an answer that changes once a Vana'diel
    -- day. Built where the offers are committed, so the markers and the
    -- Exchange's cards can still never disagree about what is on sale.
    byAugid     = { },
    burst       = { },     -- b| records, the static Weapon Burst shelf (2026-08-25)
    roster      = { },     -- w| records, in wire order
    synced      = false,

    -- The picker.
    picked      = nil,     -- the offer handle chosen: x1..x4
    who         = '',      -- '' is you; otherwise an offline character's name
    filter      = T{ '' }, -- InputText writes into element 1, EVERY keystroke
    -- The last COMMITTED search -- what gearRequest reads. The live buffer
    -- above changes on every character typed, and the request is built from
    -- whatever it holds, so reading it there made the command line change
    -- under the request de-dup and fired one `!dwu gear` per keystroke.
    filterApplied = '',
    gearStale     = false, -- the open gear envelope answers a different search (n|)
    gear        = { },     -- c| records, in wire order
    gearShown   = 0,
    gearTotal   = 0,
    gearMax     = 0,
    gearFor     = nil,     -- the request the list on screen answers
    gearSynced  = false,

    -- The item under consideration, off k| and s|.
    item        = nil,
    slots       = { },

    -- The armed quote. ONLY a p| record puts one here.
    quote       = nil,
};

--[[
* THE OUTFITTER TAB (DWQUEST_PLAN.md Phase 7).
*
* The same renderer-only contract as the Exchange, with a simpler shape:
* static stock, no rotation, no countdown. The job directory is `j|` records
* (sent whole on every shelf read), the rows are `f|` records for the ONE job
* that was asked -- the window fetches per selected job, because the whole
* catalog through the paced writer is a flood -- and the armed quote is a
* `t|` record and nothing else.
*
* ONE PENDING PURCHASE ACROSS BOTH STOREFRONTS, mirrored client-side: a `t|`
* clears the Exchange's p| quote and a `p|` clears this one, exactly as the
* server disarms them (D14) -- so this window can never draw two Confirm
* buttons for one `confirm` verb.
*
* PLAIN TABLES, not T{ }: rows keyed by wire order, jobs by wire order.
--]]
local outfit = {
    jobs    = { },     -- j| records, in wire order
    rows    = { },     -- f| records for the selected job, in wire order
    rowsFor = nil,     -- the request the rows on screen answer
    job     = nil,     -- the selected three-letter job word, nil for none
    synced  = false,

    -- The armed quote. ONLY a t| record puts one here.
    quote   = nil,
};

-- The ArmsDealer tab, the Outfitter's twin one storefront over: the dropdown
-- pages by CATEGORY where the Outfitter pages by job. Its own state so the two
-- panels never share a row list or a quote; the server enforces one pending
-- purchase across both.
--
-- `category` opens on 'dynamis' -- deliberately NOT "whatever the wire lists
-- first". The 2026-08-21 round put 'artifact' at the top of the dropdown, and
-- re-pointing the default at it would have silently changed which case an
-- existing player's window opened on. A default that follows the wire is a
-- default that moves whenever the shelf is restocked.
local arms = {
    categories = { },        -- j| records for the arms envelope, in wire order
    rows       = { },        -- f| records for the selected category
    rowsFor    = nil,        -- the request the rows on screen answer
    category   = 'dynamis',  -- selected category key; 'dynamis' by default
    synced     = false,

    -- The armed quote. ONLY a t| record in the armsbuy envelope puts one here.
    quote      = nil,
};

-- The Jeweler tab (owner request 2026-09-03): the CoP-era earrings and rings
-- for Drift Coins, the ArmsDealer's money path with the Pop-Items' shape --
-- the whole shelf travels on one read (eleven rows, no per-case fetch),
-- grouped under the case headers the j| directory names, each row priced
-- off the wire. Its own state so no panel shares a row list or a quote; the
-- server enforces one pending purchase across all of them.
local jewel = {
    cases  = { },            -- j| records for the jeweler envelope, in wire order
    rows   = { },            -- f| records, every case, in wire order
    -- The rows bucketed under the case they belong to, built ONCE at the `z|`
    -- that commits them (shop.byAugid's rule). The panel used to walk every
    -- row for every case header to draw eleven lines, and a row whose case
    -- band names no header in the directory was drawn by nobody at all.
    byCase    = { },
    ungrouped = { },
    synced = false,

    -- The armed quote. ONLY a t| record in the jewelbuy envelope puts one here.
    quote  = nil,
};

-- The Pop-Items tab (owner request 2026-08-30, the Huntboard round): NM pop
-- items priced in ITEMS -- Dynamis hundred-pieces plus DIFFERENT Job
-- Testimonies -- charged from the bag, no Drift Coins involved. The whole
-- shelf travels on one read (twenty-odd rows, no per-tier fetch), grouped
-- under the tier headers the j| directory names; `hundreds`/`types` are the
-- h| bag-side purse, nil until the server says (the state.balance rule).
--[[
* The gil exchange (2026-09-04): the one control on this window that spends
* gil. `count` is the InputInt buffer; `quote` is the armed t| from the `gil`
* envelope and the ONLY thing that can draw its Confirm. The rate and the
* ceiling are never client constants -- they ride the y| header, appended --
* so a server that predates the exchange draws no control at all.
--]]
local gil = {
    count = T{ 10 },
    quote = nil,
};

-- What the gil box will hold whatever the header says. See the clamp in
-- headerRow: `gilmaxcoins` is a wire field and the box beneath it is an
-- int32 in Ashita's binding.
local GIL_BOX_MAX = 9999;

local pop = {
    tiers    = { },          -- j| records for the pops envelope, in wire order
    rows     = { },          -- r| records, in wire order (server groups by tier)
    -- The rows bucketed under their tier and keyed by their shelf number,
    -- both built ONCE at the `z|` that commits them (shop.byAugid's rule).
    -- The panel used to walk every row for every tier header -- five tiers
    -- times twenty-five rows, sixty times a second, to draw twenty-five
    -- lines -- and the quote line under it re-scanned the whole shelf every
    -- frame to name the row it had already been given the number of.
    byTier    = { },
    byIndex   = { },
    ungrouped = { },
    -- Bumped by every answer that commits a shelf. The find box's view is
    -- keyed on it, so a re-read cannot leave a filtered list describing the
    -- rows before it.
    rev       = 0,
    synced   = false,
    hundreds = nil,          -- h|: hundred-pieces in the bag
    types    = nil,          -- h|: DIFFERENT testimony types in the bag

    -- The armed quote. ONLY an x| record in the popbuy envelope puts one here.
    quote    = nil,
};

--[[
* THE STAGING TABLE (1.23.0) -- dwbags' SECTIONS shape, arrived at the same
* week for the same reason.
*
* An answer's records used to WIPE their section at `d|` and refill it record
* by record, and dwu_protocol.md's own client discipline says not to: "lists
* build aside and commit on z|, so a half-arrived reply can never half-fill
* the window". Two things go wrong with the wipe:
*
*   THE PANEL LIES FOR A FRAME. Between the wipe and the first row, every
*   panel here draws its EMPTY-SHELF sentence -- "The Outfitter is not
*   stocked on this server build", "No contracts offered", "The Exchange has
*   nothing today". Those are specific claims about the server, not loading
*   states, and the window makes all of them on every ordinary re-read.
*
*   AND THE SCROLL GOES TO THE TOP. ImGui clamps a child's scroll to its
*   content, so a frame of no content clamps to zero and the next frame's
*   rows arrive under a scrollbar at the top. The board re-reads on every
*   Accept, every Abandon, every rotation, every zone line and every typed
*   `!drift` -- so a player reading the bottom of a fourteen-card board was
*   thrown back to the top by their own click.
*
* SECTIONS names what each verb replaces. A verb with no entry replaces
* nothing and its records write to the live model (a `ping` MERGES -- that is
* the whole difference between it and a `board`), and so does a record that
* arrives with no envelope open at all, exactly as before.
--]]
local SECTIONS = {
    board    = { 'offers', 'actives', 'activeOrder' },
    augments = { 'offers', 'burst', 'roster' },
    gear     = { 'gear' },
    shelf    = { 'jobs', 'rows' },
    arms     = { 'categories', 'rows' },
    pops     = { 'tiers', 'rows' },
    jeweler  = { 'cases', 'rows' },
    balance  = { 'ledger' },
};

-- The sections of the envelope currently open, or nil when the open envelope
-- replaces nothing. The names are per-verb, so `offers` means the board's
-- under `board` and the Exchange's under `augments` -- one envelope is open
-- at a time and every record handler already branches on `state.inbound`.
local arriving = nil;

-- Where a record for `name` is written right now: the staging list while its
-- verb's envelope is open, the live list otherwise.
local function into(name, live)
    if (arriving ~= nil and arriving[name] ~= nil) then
        return arriving[name];
    end

    return live;
end

--[[
* Item icons, from the client's own resources -- dwbags' iconOf/drawIcon by
* way of dwraid, kept verbatim, reasoning and all: cached because the shelf
* is rows redrawn every frame and D3DXCreateTextureFromFileInMemoryEx is not
* free; gc_safe_release hands back a texture that releases itself when Lua
* collects it, which is what keeps this from leaking across a reload.
--]]
local icons = T{ };

local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* The hover card's vocabulary and the card itself -- dwraid's, kept verbatim:
* client DAT bitmasks decoded to the words a player reads. All of it is
* presentation; the server re-checks everything that matters (the Rare
* pre-pay refusal lives in quest_core.lua).
--]]
local FLAG_EX   = 0x4000;
local FLAG_RARE = 0x8000;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

local SLOT_LABELS = {
    [0]  = 'Main',  [1]  = 'Sub',   [2]  = 'Ranged', [3]  = 'Ammo',
    [4]  = 'Head',  [5]  = 'Body',  [6]  = 'Hands',  [7]  = 'Legs',
    [8]  = 'Feet',  [9]  = 'Neck',  [10] = 'Waist',  [11] = 'Ear',
    [12] = 'Ear',   [13] = 'Ring',  [14] = 'Ring',   [15] = 'Back',
};

local function jobsText(mask)
    local names = T{ };

    for jobId = 1, #JOB_NAMES do
        if (bit.band(mask, bit.lshift(1, jobId)) ~= 0) then
            names:append(JOB_NAMES[jobId]);
        end
    end

    if (#names == 0) then
        return nil;
    end

    if (#names >= #JOB_NAMES) then
        return 'All jobs';
    end

    return table.concat(names, ' ');
end

local function slotsText(mask)
    local names = T{ };
    local seen  = { };

    for slot = 0, 15 do
        if (bit.band(mask, bit.lshift(1, slot)) ~= 0) then
            local label = SLOT_LABELS[slot];

            if (not seen[label]) then
                seen[label] = true;
                names:append(label);
            end
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, '/');
end

--[[
* The eight elemental-resist icons in the client's item descriptions are
* FFXI-private Shift-JIS pairs -- 0xEF then 0x1F..0x26, in wheel order
* fire ice wind earth lightning water light dark (read straight out of
* ROM/118/107.DAT: item 6272 carries fire as EF 1F, item 4488 dark as
* EF 26, and the JP DAT spells the same slots 耐火/耐風/耐土). ImGui wants
* UTF-8, so the raw pair renders as the '?' players reported. Each icon
* (and the '+' that usually follows it) folds to a three-letter tag:
* '<fire>+20' reads FiR:20, '<dark>-10' reads DkR:-10. Mirrored BY HAND
* from dwbags 1.17.0 -- edit one, revisit the others.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function(b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

--[[
* THE HOVER CARD'S BODY, WORKED OUT ONCE PER ITEM (2026-09-06).
*
* A tooltip is submitted EVERY FRAME the pointer sits on the row it belongs
* to, and this card was rebuilt from nothing on each one: a resource-manager
* call (a DAT read), a walk of all 22 job bits, a walk of all 16 equipment
* slots, up to four string.formats, two table.concats and a gsub with a
* FUNCTION CALLBACK over the whole description -- sixty times a second, for
* three strings every ingredient of which is fixed by the item id. An item's
* level, flags, slots, jobs and description cannot change while the client is
* running; that is the same fact iconOf and popItemName already cache on.
*
* Bounded the same way they are: by the number of distinct ids this window
* has drawn a card for, which is the shelf in front of the player.
--]]
local itemCards = { };

local function itemCard(itemId)
    local cached = itemCards[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local card = { };
    local item = AshitaCore:GetResourceManager():GetItemById(itemId);

    if (item ~= nil) then
        local tags = T{ };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags:append(string.format('iLvl %d', item.ItemLevel));
        end

        if (item.Level ~= nil and item.Level > 0) then
            tags:append(string.format('Lv.%d', item.Level));
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_RARE) ~= 0) then
            tags:append('Rare');
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_EX) ~= 0) then
            tags:append('Ex');
        end

        if (#tags > 0) then
            card.tags = table.concat(tags, '  ');
        end

        local slots = item.Slots ~= nil and slotsText(item.Slots) or nil;
        local jobs  = item.Jobs ~= nil and jobsText(item.Jobs) or nil;

        if (slots ~= nil and jobs ~= nil) then
            card.fit = slots .. '  --  ' .. jobs;
        elseif (slots ~= nil or jobs ~= nil) then
            card.fit = slots or jobs;
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            card.desc = cleanDescription(desc);
        end
    end

    itemCards[itemId] = card;

    return card;
end

local function itemTooltip(row)
    imgui.BeginTooltip();

    local card = nil;

    if (row.itemid ~= nil and row.itemid ~= 0) then
        card = itemCard(row.itemid);

        drawIcon(row.itemid, 32);
    end

    imgui.Text(row.label);

    if (card ~= nil) then
        if (card.tags ~= nil) then
            imgui.TextColored(theme.colors.info, card.tags);
        end

        if (card.fit ~= nil) then
            imgui.TextDisabled(card.fit);
        end

        if (card.desc ~= nil) then
            imgui.Separator();
            -- A fixed wrap width, not one derived from imgui state: the
            -- card must render the same whatever window it floats over.
            imgui.PushTextWrapPos(320.0);
            imgui.Text(card.desc);
            imgui.PopTextWrapPos();
        end
    end

    imgui.EndTooltip();
end

--[[
* Sending: one command per interval, reads deduplicated, WRITES NEVER
* COLLAPSED AND NEVER RETRIED (the dwmerc rule, dwu_protocol.md client
* discipline 4). A lost `accept` that was re-sent could arrive after a
* rotation, which is a contract the player did not click on. Both verbs are
* idempotent server-side; that is not a licence to re-send them.
*
* Writes drain first: an accept stuck behind two queued board reads spends
* three seconds looking broken.
--]]
local SEND_INTERVAL = 1.2;

local readQueue  = { };
local writeQueue = { };
local lastSend   = 0;

--[[
* WHICH TRACKER THE LINE ON THE WIRE BELONGS TO.
*
* A read is queued as a command string and tracked under a short key
* (`shelf`, `arms`, `balance`, ...), and until 2026-09-06 the two were never
* connected: the queue knew the line and `requested` knew the key, and nothing
* knew which line had answered which key. That was fine while every answer
* arrived wrapped in its own verb's envelope -- the `d|<proto>|<verb>` retires
* the ask by name -- and wrong for the one case that does not.
*
* A REFUSAL RAISED BEFORE THE VERB OPENS ITS ENVELOPE ARRIVES AS `d|1|status`
* (squad_storage.lua's `wrapped`, and every verb in quest_core.lua validates
* and returns BEFORE it opens). So "The Outfitter is not stocked on this
* build" answered `!dwu shelf` under a verb word the ask table has never
* heard of, the ask stayed outstanding, askOnce re-sent the same refused line
* five seconds later, and five seconds after that the answer clock replaced
* the server's accurate sentence with "The server did not answer" -- about a
* server that had just answered twice. That is the same hole the write clock
* had until this morning, one tier down.
*
* TWO STRUCTURES, AND THE SECOND IS A QUEUE RATHER THAN A LAST-SENT SLOT.
* `readKeyOf` carries a key from the moment a line is queued to the moment it
* is sent; `inFlight` then holds the keys of the reads ON THE WIRE, oldest
* first. One server answers one connection in the order it was asked, so the
* ask a bare `status` envelope belongs to is the OLDEST one still outstanding
* -- not merely the last line sent, which is a different ask whenever two
* reads are in flight (the Exchange tab asks for the storefront and the gear
* list together, and the storefront is the one a build without the augment
* engine refuses).
*
* A read queued with no key -- `slots`, the one untracked read -- puts nothing
* in either structure and so retires nothing, which is correct: it has no
* tracker to retire.
--]]
local readKeyOf = { };
local inFlight  = { };

-- The `requested` table has eight keys, so a healthy queue never holds more
-- than eight. The cap is here for the unhealthy case -- a server that takes
-- lines and never answers -- because a list that grows once per send and is
-- drained only by an answer is a list an unanswered session grows forever.
local IN_FLIGHT_MAX = 16;

local function issueRead(command, key)
    if (key ~= nil) then
        readKeyOf[command] = key;
    end

    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

local function issueWrite(command)
    table.insert(writeQueue, command);
end

local function pumpQueue(now)
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and both queues are empty in
    -- almost all of them, while echo.canSend() is three calls across the C++
    -- boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it first
    -- spent a hundred and eighty of those a second to decide to do nothing.
    -- An empty queue has no line to hold or to drop, so the order is free.
    if (#writeQueue == 0 and #readQueue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#writeQueue > 0) then
        lastSend = now;
        echo.send(table.remove(writeQueue, 1));

        return;
    end

    if (#readQueue > 0) then
        lastSend = now;

        local command = table.remove(readQueue, 1);

        -- Whose ask this line is, for the `d|1|status` branch (see readKeyOf).
        -- Taken OUT of the map rather than left in it: the map's only job is
        -- to carry a key from the queue to the wire, and a map that kept
        -- every command a session ever queued would grow on every distinct
        -- gear search.
        local key = readKeyOf[command];

        readKeyOf[command] = nil;

        if (key ~= nil) then
            table.insert(inFlight, key);

            while (#inFlight > IN_FLIGHT_MAX) do
                table.remove(inFlight, 1);
            end
        end

        echo.send(command);
    end
end

--[[
* Answer tracking for the board read: ask once, retry once on a 5s silence,
* then stop and say so -- a retry that never terminates is a command loop.
*
* `hello` and `board` are tracked under ONE key because the server answers
* both with a `board` envelope (quest_core.lua's dispatch): keying on the verb
* we sent would leave a `hello` waiting forever for a `z|hello` that the
* protocol does not have.
*
* A PLAIN TABLE, not T{ }, for the reason above.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = { };

-- `hello` is the verb that arms the post-kill ping for the session, and it is
-- the one verb only the addon sends. It goes out when the arming might not be
-- in place: window open, and after a zone line. An in-session re-read is
-- `board`, which is the same records without re-arming.
local wantVerb = 'hello';

local function refresh(verb)
    requested = { };
    wantVerb  = verb or 'board';

    -- The in-flight queue names asks in the table that was just thrown away,
    -- so every key in it now points at nothing. The scan that reads it skips
    -- those anyway; emptying it here keeps the queue meaning what it says.
    inFlight = { };
end

-- The board read that keeps the current view: `board 3` while looking at
-- band 3, plain `board` for your own. Every re-sync that is not the arming
-- handshake goes through this, so an accept, a rotation roll or a typed
-- command cannot silently snap the window back to the player's own band.
local function boardVerb()
    if (state.viewBand ~= nil) then
        return string.format('board %d', state.viewBand);
    end

    return 'board';
end

local function needBoard(now)
    local asked = requested['board'];

    if (asked ~= nil) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout, and a false "The server did not
        -- answer." (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or (now - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp = true;

                if (not state.serverSpoke) then
                    state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
                    state.statusBad = true;
                end
            end

            return;
        end

        asked.at    = now;
        asked.tries = asked.tries + 1;
    else
        requested['board'] = { at = now, answered = false, tries = 1 };
    end

    issueRead('!dwu ' .. wantVerb, 'board');
end

--[[
* The same ask-once-retry-once discipline as needBoard, for the reads the
* Exchange tab makes. Keyed separately so a storefront read and a gear read
* cannot answer for each other, and so neither can answer for the board.
*
* Reads only. The three things this window sends that are NOT reads -- accept,
* abandon and confirm -- never come through here, because a write that times
* out is a write that stays sent (client discipline 4).
--]]
local function askOnce(key, command, now)
    local asked = requested[key];

    if (asked ~= nil) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout, and a false "The server did not
        -- answer." (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or (now - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp   = true;
                state.status    = 'The server did not answer. Refresh to try again.';
                state.statusBad = true;
            end

            return;
        end

        asked.at    = now;
        asked.tries = asked.tries + 1;
    else
        requested[key] = { at = now, answered = false, tries = 1 };
    end

    issueRead(command, key);
end

--[[
* A write in flight. Nothing here moves money and the store re-checks the
* account on both verbs, but a button clicked twice while the first click is
* still queued is a second line on the wire for a decision the player made
* once -- so the card says what it is doing instead of accepting the click.
*
* IT COVERS THE PURCHASE PAIR TOO (Phase 4). `augment` and `confirm` are both
* queued as writes and neither is ever re-sent; while one is in flight the
* buttons say what they are doing rather than taking a second click -- which
* for `confirm` is the difference between one purchase and two lines on the
* wire for one decision. The quote is disarmed at the click, so even a window
* that somehow got past this has nothing left to confirm with.
--]]
local WRITE_TIMEOUT = 10.0;

local writePending = nil;

--[[
* WHICH CONFIRM IS IN FLIGHT, for the one shelf whose answer cannot say.
*
* Every Confirm in this file disarms its own quote in the same statement that
* queues the line -- that is the rule money hangs on, and it is not moving.
* The consequence nobody had noticed is that by the time `z|confirm` arrives,
* every `*.quote` is already nil, so an answer cannot be told apart by which
* side still held one.
*
* That cost the Pop-Items shelf its re-read for the whole time it has
* shipped. Its purse is the BAG -- hundred-pieces and testimony types out of
* LOC_INVENTORY -- and a settled purchase spends both, so the `h|` line on
* screen and every row's cost are a frame of the past the moment one lands.
* The re-read was guarded on `pop.quote ~= nil` at the answer, which the
* click had already cleared, so it never once ran: a player who bought a pop
* item saw the bag they had BEFORE it, for the rest of the session.
*
* One flag, set where the knowledge is and cleared where it is used. The
* other five shelves need nothing like it: their purse is the coin balance
* and the answer re-states that itself (client discipline 9).
--]]
local popConfirmSent = false;

local function beginWrite(what, label, command)
    writePending = { what = what, label = label, at = os.clock() };

    issueWrite(command);
end

--[[
* Record parsing.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* A number off the wire, or the value the protocol documents as absent.
*
* EVERY EMITTER ON THIS WIRE FORMATS WITH `%i` (quest_core.lua), so a field
* that is not a whole number is a field that was corrupted, truncated or
* forged -- and each of the three ways that can land is a different kind of
* wrong on screen:
*
*   a fraction  -- `string.format('%d', 2.5)` RAISES on the Lua the offline
*                  harness runs and silently truncates on the LuaJIT the
*                  client runs, so the same record is a closed window on one
*                  and a quietly wrong kill count on the other;
*   'inf'/'nan' -- LuaJIT's tonumber reads both, and `%d` then prints
*                  -9223372036854775808. A reward, a price or a slot count
*                  rendered as a 64-bit sentinel is not a display bug, it is
*                  a number a player might act on;
*   a huge one  -- the same sentinel by the other door.
*
* The k| slot count already carried a clamp for the half of this that bounds
* a render loop (see `maxslots`). This is that lesson applied where the value
* is read rather than where one of its readers happens to be dangerous: a
* corrupt field costs the FIELD, and the caller's fallback is exactly the
* "the server did not say" value it already had to handle.
--]]
local NUM_LIMIT = 1e15;

local function num(text, fallback)
    local value = tonumber(text or '');

    -- NaN first: it compares false against everything below, including
    -- itself, so the ordinary tests would let it through.
    if (value == nil or value ~= value) then
        return fallback;
    end

    if (value < -NUM_LIMIT or value > NUM_LIMIT or value ~= math.floor(value)) then
        return fallback;
    end

    return value;
end

--[[
* A text field off the wire, or a placeholder.
*
* `imgui.Text(row.label)` hands a wire field straight to a binding that wants
* a string, so a record that lost its last field -- to the 130-byte budget,
* to a truncated packet, to a server one version behind -- was a Lua error
* inside the render pcall, which closes the whole window and tells the player
* to fall back to the typed commands. A row with a placeholder label is a row
* a player can still see, price and buy; a shut window is neither.
*
* Only for fields that reach a text call DIRECTLY. Fields that go through
* string.format('%s') already render 'nil' rather than throwing, and a field
* whose emptiness is meaningful (the o| tag) is read raw on purpose.
--]]
local function word(text)
    if (text == nil or text == '') then
        return '?';
    end

    return tostring(text);
end

-- 1234567 -> "1,234,567". Gil is the one number this window shows that is
-- big enough to need it.
local function fmtGil(n)
    local digits = tostring(math.floor(n or 0));
    local packed = digits:reverse():gsub('(%d%d%d)', '%1,'):reverse();

    return (packed:gsub('^,', ''));
end

--[[
* The gil rate as the header draws it, built once per rate rather than once
* per frame.
*
* fmtGil is five string allocations -- a tostring, two reverses and two gsubs
* -- and this one is on the header line, which is drawn whichever tab is
* open. The rate itself only moves when a `y|` lands (it is a server
* constant), so the window was rebuilding the same eight characters sixty
* times a second for the whole time it was up.
*
* Keyed on the rate rather than invalidated by the y| handler on purpose: a
* cache that a second write site has to remember to clear is a cache that
* goes stale the day somebody adds one.
--]]
local gilRate = { of = nil, text = '' };

local function gilRateText()
    if (gilRate.of ~= state.gilPerCoin) then
        gilRate.of   = state.gilPerCoin;
        gilRate.text = string.format('%s gil each', fmtGil(state.gilPerCoin));
    end

    return gilRate.text;
end

--[[
* The board stamp as the header draws it, built once per board rather than
* once per frame -- gilRateText's rule, on the three numbers beside it.
*
* All three move only when a `y|` lands, and a `y|` lands at most once per
* board read; the window was rebuilding the same twenty-seven characters
* sixty times a second whichever tab was open. Keyed on the numbers rather
* than invalidated by the y| handler, for gilRateText's reason: a cache a
* second write site has to remember to clear goes stale the day somebody
* adds one.
--]]
local stamp = { day = nil, band = nil, pool = nil, text = '' };

local function stampText()
    if (stamp.day ~= state.day or stamp.band ~= state.band
            or stamp.pool ~= state.poolVersion) then
        stamp.day  = state.day;
        stamp.band = state.band;
        stamp.pool = state.poolVersion;
        stamp.text = string.format('day %d  band %d  pool v%d',
            state.day or 0, state.band or 0, state.poolVersion or 0);
    end

    return stamp.text;
end

-- The server sends at most five ledger lines (dwu_protocol.md, `l|`). The cap
-- is the addon's own all the same: a table that grows on records needs a
-- bound that does not depend on the sender being the one documented.
local LEDGER_MAX = 5;

--[[
* How long ago a ledger line was written, in the server's own idiom -- the
* same four bands quest_core.lua's fmtAgo prints to the typed tier, so the
* window and `!drift balance` never describe one movement two ways.
*
* `at` is the wall clock passed in rather than read here: the caller reads it
* ONCE per answer (see the `z|balance` close), because os.time() is a syscall
* and five rows redrawn sixty times a second is not the place for one.
*
* A `created` in the future -- a database clock ahead of this PC's -- falls
* into the first band and reads "just now", which is the honest answer to a
* question the two clocks cannot settle.
--]]
local function fmtAgo(created, at)
    if (created == nil or created <= 0 or at == nil) then
        return '';
    end

    local secs = at - created;

    if (secs < 120) then
        return 'just now';
    elseif (secs < 7200) then
        return string.format('%d min ago', math.floor(secs / 60));
    elseif (secs < 172800) then
        return string.format('%d h ago', math.floor(secs / 3600));
    end

    return string.format('%d days ago', math.floor(secs / 86400));
end

-- How many accepted contracts the model will hold between board syncs. See
-- the prune in handleContract: a ping merges, and only a board read clears.
local ACTIVE_MAX = 64;

local TOAST_SECONDS = 8.0;

local function toast(text)
    state.toast   = text;
    state.toastAt = os.clock();
end

--[[
* THE TWO SENTENCE-BUILDERS THE RECORD HANDLERS NEED.
*
* Both used to sit down in the rendering section, which was right while the
* render composed a card's text every frame and wrong the moment the records
* started composing it once (2026-09-06): a `local function` declared after
* the handler that calls it is a GLOBAL lookup at the call site, which is nil.
--]]
-- The period label comes off the slot handle, which IS the period: `d1`/`d2`
-- are the dailies and `w1`/`w2` the weeklies, fixed by the protocol
-- (dwu_protocol.md, `o|`). Reading a documented handle is not arithmetic over
-- server data -- there is no other number here the window invents.
local function periodLabel(slotOrPeriod)
    return tostring(slotOrPeriod or ''):sub(1, 1) == 'w' and 'Weekly' or 'Daily';
end

-- The objective clause, per kind. This mirrors quest_core.lua's objectiveFor
-- exactly, and the harness asserts the two say the same thing -- a window that
-- describes a contract differently from the server that scores it is a bug
-- report about the wrong half.
--
-- THE WEAPON-SKILL WORDING IS THE SERVER'S, NOT A PARAPHRASE. The flag is a
-- fact about the mob's death and is handed to every alliance member alike, so
-- "finished with a weapon skill" is true and "finish it yourself" is not.
local function objectiveText(kind, needed, name)
    if (kind == 'fam') then
        return string.format('Slay %d of the %s family', needed, name);
    elseif (kind == 'eco') then
        return string.format('Slay %d %s', needed, name);
    elseif (kind == 'ws') then
        return string.format('Slay %d in %s, each finished with a weapon skill', needed, name);
    elseif (kind == 'night') then
        return string.format('Slay %d in %s between dusk and dawn', needed, name);
    elseif (kind == 'wthr') then
        return string.format('Slay %d in %s while the weather is up', needed, name);
    elseif (kind == 'comm') then
        return string.format('The server slays %d %s', needed, name);
    elseif (kind == 'clear') then
        -- The instanced sources (2026-09-05): the name is the unit --
        -- "Gauntlet floors", "Raid encounters" -- so no second noun.
        return string.format('Clear %d %s', needed, name);
    elseif (kind == 'zone') then
        return string.format('Slay %d creatures in %s', needed, name);
    elseif (kind == 'craft') then
        -- THE ONLY CONTRACT ON THIS BOARD THAT IS NOT A KILL (2026-09-07).
        -- The `name` is the CRYSTAL the synthesis must burn -- the server
        -- rolls one of the eight per period -- so the sentence names it
        -- rather than saying "craft 12 things": a player who reads the
        -- wrong crystal spends a stack proving it.
        return string.format('Craft %d items using a %s', needed, name);
    elseif (kind == 'fish') then
        -- Fish OR item: the server credits both, and monsters and losses
        -- neither, so "items" is the honest noun and "fish" would be a
        -- narrower promise than the one being scored.
        return string.format('Fish up %d items', needed);
    elseif (kind == 'gather') then
        -- All four HELM verbs count as one objective (harvesting,
        -- excavation, logging, mining), which is why this sentence names
        -- none of them: naming one would be the window inventing a rule
        -- narrower than the server's.
        return string.format('Harvest %d times', needed);
    end

    -- An unknown kind is one the server added after this addon shipped.
    -- Rendered as its own wire word, never as another kind's sentence
    -- (dwu_protocol.md: "the objective text a window composes for `zone` is
    -- not true of `night`, and showing it is the window telling the player
    -- something the server never said"). The KIND_BADGE table below already
    -- follows this rule; the sentence the player acts on must too.
    return string.format('[%s] %d x %s', kind, needed, name);
end

--[[
* One a| record -- an accepted contract. It carries its own name and reward
* rather than pointing back at an o|, because a contract inside its grace
* period is not on today's board and this window still has to draw it
* (dwu_protocol.md, `a|`).
*
* KEYED ON qkey, NEVER ON handle: handles are a typed-tier label that
* renumbers between syncs, and a model keyed on one abandons the wrong
* contract exactly once (client discipline 3).
--]]
local function handleContract(parts)
    local qkey = parts[3];

    if (qkey == nil or qkey == '') then
        return;
    end

    -- A `board` answer STAGES its contracts and swaps them in at the `z|`; a
    -- `ping` merges into the model on screen, which is the whole difference
    -- between the two verbs (see SECTIONS).
    local actives = into('actives', state.actives);
    local order   = into('activeOrder', state.activeOrder);

    local kind   = parts[4];
    local name   = word(parts[6]);
    local needed = num(parts[8], 0);
    local reward = num(parts[9], 0);

    local row = {
        handle   = parts[2],
        qkey     = qkey,
        kind     = kind,
        period   = parts[5],
        name     = name,
        progress = num(parts[7], 0),
        needed   = needed,
        reward   = reward,
        secsLeft = num(parts[10], 0),
        state    = parts[11],
        at       = os.clock(),

        -- The card's own fixed strings, for the o| record's reason one
        -- handler down: a grace-period contract is drawn as a card of its
        -- own, and a signed offer's card reads its counter off this row.
        periodWord = periodLabel(parts[5]),
        objective  = objectiveText(kind, needed, name),
        rewardText = string.format('%d DC', reward),
        abandonBtn = string.format('Abandon##dwquest_abandon_%s', qkey),
    };

    local prev = actives[qkey];

    -- The toast fires off the PING only. A board sync is the window catching
    -- up with kills it already celebrated, and re-celebrating them on every
    -- zone line would make the toast mean nothing.
    if (state.inbound == 'ping') then
        if (row.state == 'done' and (prev == nil or prev.state ~= 'done')) then
            toast(string.format('Contract complete: %s   +%d DC', row.name, row.reward));
        elseif (prev == nil or row.progress > prev.progress) then
            toast(string.format('%s   %d / %d', row.name, row.progress, row.needed));

            -- THE COUNTER IS ALWAYS A CHAT LINE TOO, and it is deliberately
            -- NOT conditional on the window being shut any more.
            --
            -- quest_core stops printing the per-kill progress line the moment a
            -- session is armed, because the window animates it instead -- so
            -- this print is the only copy an armed session ever gets. Gating it
            -- on the window being closed made where the line appeared depend on
            -- which of four states the session happened to be in (armed or not,
            -- window up or not), which is exactly the "sometimes over here,
            -- sometimes over there" the notice tag exists to end. One rule now:
            -- every progress step and every payout is a chat line, in the same
            -- window, every time. The toast still fires; a toast is eight
            -- seconds of a window you may not be looking at.
            --
            -- Payouts are not repeated here -- the server announces those to
            -- both tiers, tagged, and the handler at the bottom of this file
            -- moves them to the same place this line goes.
            print(chat.header('dwquest'):append(chat.message(
                string.format('%s: %d/%d', row.name, row.progress, row.needed))));
        end
    end

    if (prev == nil) then
        table.insert(order, qkey);

        --[[
        * A BOUND ON THE ONE LIST A PING GROWS.
        *
        * A `board` answer replaces this whole section, but a PING MERGES --
        * it carries only the rows that moved -- and the only thing that ever
        * reads a board back is the render loop, which does not run while the
        * window is shut. Opening the window once is what ARMS the ping, so
        * the ordinary shape of a long session is: open, arm, close, and then
        * take pings for hours with nothing clearing anything. Every contract
        * key the session has not seen before adds a row here and to
        * `state.actives`, and the board panel walks this list every frame.
        *
        * The next open re-reads the board and replaces the lot, so the cap
        * only has to stop an unbounded walk in a window nobody is looking at.
        * The OLDEST key goes, and the oldest is always from an earlier period
        * than the one arriving -- 64 is ten periods of a six-slot board.
        --]]
        while (#order > ACTIVE_MAX) do
            actives[table.remove(order, 1)] = nil;
        end
    end

    actives[qkey] = row;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = num(parts[2], 0);

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwquest.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;
            -- And the staging table with it: a section half-built by an
            -- envelope this addon refused must never reach a `z|` that
            -- swaps it in (see SECTIONS).
            arriving        = nil;

            -- A d| envelope IS the answer, whatever version it announced.
            -- Returning with the asks still outstanding let needBoard and
            -- askOnce re-send them and then replace the one accurate diagnosis
            -- on screen ("Update dwquest") with "The server did not answer" --
            -- about a server that had just answered twice. `serverSpoke`
            -- deliberately stays false: this server does not speak a dwquest
            -- this addon understands. dwfame closed the same hole 2026-08-15.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            -- AND THE WRITE IN FLIGHT, for the same reason one record up.
            -- Retiring only the READS left the write clock running, and its
            -- own ten-second timeout wrote the same wrong sentence a few
            -- seconds later -- "No answer from the server", about a server
            -- that had just answered. Nothing is re-sent either way; the
            -- accurate banner is the whole point of this branch.
            writePending = nil;

            return;
        end

        state.serverSpoke = true;
        state.inbound     = parts[3];

        --[[
        * WHAT THIS ANSWER REPLACES, STAGED RATHER THAN WIPED (1.23.0). The
        * lists build in `arriving` and swap in whole at the `z|`; the live
        * model is untouched until then, so no panel ever draws a frame of an
        * empty section (see SECTIONS). A `ping` is deliberately absent from
        * that table -- it carries only what moved, so its records merge into
        * the model on screen.
        *
        * The staging table is built FIRST, before anything else in this
        * branch: this runs under a pcall, and a throw after `inbound` is set
        * must cost one record rather than leave the records behind it
        * writing into the section they were supposed to replace.
        --]]
        local sections = SECTIONS[state.inbound];

        arriving = nil;

        if (sections ~= nil) then
            arriving = { };

            for _, name in ipairs(sections) do
                arriving[name] = { };
            end
        end

        local asked = requested[state.inbound];

        if (type(asked) == 'table') then
            asked.answered = true;
        end

        if (state.inbound == 'gear') then
            -- The rows are NOT cleared here, staged or otherwise: the n|
            -- record that follows says which search this answer is for, and a
            -- stale one must leave the list on screen alone (see the n|
            -- handler, and the `z|gear` close that only commits what a
            -- header vouched for).
            shop.gearStale = false;
        elseif (state.inbound == 'slots' or state.inbound == 'augment') then
            -- A fresh look at an item replaces the old one wholesale, and THE
            -- QUOTE GOES WITH IT. An `augment` that refuses arms nothing --
            -- which is the whole point of clearing here rather than on the way
            -- out: the refusal path never runs a line that could leave one.
            --
            -- Not staged: this is one record's worth of state, not a list, so
            -- there is no empty frame to draw and the slot view is gated on
            -- `shop.item` being there at all.
            shop.item  = nil;
            shop.slots = { };
            shop.quote = nil;
        elseif (state.inbound == 'balance') then
            -- The two lifetime totals go with the ledger they head, and they
            -- are scalars rather than a list: nil is "not said yet", which is
            -- what the block already draws as "Reading the ledger...".
            state.earned = nil;
            state.spent  = nil;
        end

        -- `buy` is deliberately absent from that list too: its answer is a
        -- t| quote (or a refusal), and there is nothing behind it to reset.

        -- `confirm` is deliberately absent from that list. Its answer carries
        -- only what changed (the item's new slot view and the purse), the same
        -- way a ping does, and resetting would blank the panel the player is
        -- reading the result on.

        return;
    end

    -- Status lines are accepted whatever the envelope state: the sentence
    -- saying why something was refused is worth more than the response it
    -- happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- A STATUS LINE WITH NO SENTENCE IS NOT A STATUS LINE. A truncated
        -- packet can deliver a bare `e` -- the record without its text -- and
        -- that used to blank the sentence already on screen AND print an
        -- empty line into chat under this addon's header. Everything below
        -- still runs: the envelope answered, whatever it managed to say.
        local said = line:sub(3);

        if (said ~= '') then
            state.status    = said;
            state.statusBad = (kind == 'e');

            if (kind == 'e') then
                print(chat.header('dwquest'):append(chat.error(said)));
            end
        end

        -- A write that has answered is a write that is no longer in flight,
        -- whichever way it went. Nothing is re-sent either way. A refusal
        -- raised BEFORE the verb opened its own envelope arrives wrapped in
        -- `d|1|status` (dwu_protocol.md inherits dwg's envelope rules), and
        -- that ends the write too: left in flight, every board card read
        -- "Signing..." for ten seconds and the timeout then replaced the
        -- server's real sentence with a false "no answer" diagnosis.
        -- `gil` joined this list on 2026-09-06. It had been missing since the
        -- exchange shipped, and a refusal inside the `gil` envelope is the
        -- ordinary case, not the corner -- a purse that cannot cover the
        -- quote is answered `e|` at the quote as well as at the confirm. The
        -- envelope's own `z|` cleared the write a record later, so the cost
        -- was invisible while nothing was lost; a truncated or dropped tail
        -- left every storefront button reading "busy..." for ten seconds and
        -- then replaced the server's real sentence with "No answer from the
        -- server", which is the exact failure this list exists to prevent.
        local endsWrite = state.inbound == 'accept' or state.inbound == 'abandon'
            or state.inbound == 'augment' or state.inbound == 'confirm'
            or state.inbound == 'buy' or state.inbound == 'armsbuy'
            or state.inbound == 'popbuy' or state.inbound == 'jewelbuy'
            or state.inbound == 'gil'
            or (state.inbound == 'status' and writePending ~= nil);

        -- A REFUSED CONFIRM IS A REFUSAL, NOT A RETRY PROMPT (client
        -- discipline 6). Every reason it can fail -- the item moved, the
        -- storefront rotated, the purse was short, the purchase was already
        -- settled -- is fixed by a fresh quote and none of them by sending the
        -- same word again, so the quote is torn up here rather than left armed
        -- (or worse: left spent-but-visible, wedging the slot view whose Back
        -- button is gated on the quote being gone).
        if (kind == 'e' and (state.inbound == 'confirm'
                or (state.inbound == 'status' and writePending ~= nil
                    and writePending.what == 'confirm'))) then
            shop.quote   = nil;
            -- All storefronts: whichever quote the refused confirm was
            -- spending, none survives it (the same reasons, one tab over).
            outfit.quote = nil;
            arms.quote   = nil;
            pop.quote    = nil;
            jewel.quote  = nil;
            gil.quote    = nil;

            -- A refusal charged nothing, so the bag did not move and the
            -- shelf on screen is still true.
            popConfirmSent = false;
        end

        if (endsWrite) then
            writePending = nil;
        end

        --[[
        * AND A READ REFUSED BEFORE ITS ENVELOPE OPENED IS ALSO AN ANSWER
        * (2026-09-06). This is the write clock's fix, one tier down and for
        * the same reason: a `status` envelope is the server's WHOLE answer
        * to the line it just received, so an ask left outstanding under it
        * is an ask the server has already refused.
        *
        * Left outstanding, askOnce re-sent the same refused line five
        * seconds later and then wrote "The server did not answer. Refresh to
        * try again." over the top of the server's own sentence -- so a
        * player on a build with no Outfitter read "not stocked on this
        * build" (true, actionable) for ten seconds and "the server did not
        * answer" (false) for the rest of the session.
        *
        * ATTRIBUTED TO THE OLDEST READ STILL OUTSTANDING, and only when no
        * write is waiting: a write in flight owns this envelope (the
        * endsWrite list above), and one server answers one connection in the
        * order it was asked, so the ask a bare status envelope belongs to is
        * the front of the in-flight queue. Keys ahead of it that their own
        * envelope already retired are dropped on the way past.
        *
        * The cost of being wrong -- a player typing `!dwu shelf` by hand
        * while a different read is in flight -- is one read not retried,
        * which Refresh fixes; the cost of not doing it is the wrong sentence
        * on screen for the rest of the session.
        --]]
        if (state.inbound == 'status' and writePending == nil) then
            while (#inFlight > 0) do
                local asked = requested[table.remove(inFlight, 1)];

                if (type(asked) == 'table' and not asked.answered) then
                    asked.answered = true;
                    -- Told apart from a silence: the panel behind this read
                    -- says the server refused it rather than sitting on
                    -- "Waiting for..." forever (see waitingLine).
                    asked.refused  = true;

                    break;
                end
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;
        local staged  = arriving;

        state.inbound = nil;
        arriving      = nil;

        if (closing == 'board') then
            --[[
            * THE WHOLE SECTION SWAPS IN HERE, in one statement, so the panel
            * never draws a frame between an empty list and a full one (see
            * SECTIONS). `community` rides with it and is nil when the answer
            * carried no q| -- a week whose contract has ended sends none, and
            * a bar left behind from last week would keep asking for kills
            * nothing counts.
            *
            * THE `staged ~= nil` TEST IS INSURANCE, NOT A LIVE PATH, and it
            * is written as insurance on purpose. `arriving` and
            * `state.inbound` are set and cleared together everywhere today --
            * the `d|`, the zone line, the protocol-mismatch branch -- and a
            * `z|` with no envelope open returns above this. So it cannot fire
            * now; what it buys is that a future path clearing one without the
            * other costs the commit rather than throwing on a nil index
            * inside the packet handler.
            --]]
            if (staged ~= nil) then
                state.offers      = staged.offers;
                state.actives     = staged.actives;
                state.activeOrder = staged.activeOrder;
                state.community   = staged.community;
            end

            state.synced = true;

            if (state.status == 'Loading...') then
                state.status = '';
            end
        elseif (closing == 'accept' or closing == 'abandon') then
            writePending = nil;

            -- The write answered with a sentence, not with rows: the board it
            -- produced has to be read back before the cards are true. A read,
            -- so it is retried; the write itself never is.
            refresh(boardVerb());
        elseif (closing == 'augments') then
            if (staged ~= nil) then
                shop.offers = staged.offers;
                shop.burst  = staged.burst;
                shop.roster = staged.roster;
            end

            shop.synced = true;

            shop.byAugid = { };

            for _, offer in ipairs(shop.offers) do
                shop.byAugid[offer.augid] = offer;
            end
        elseif (closing == 'gear') then
            -- A stale answer closes without committing anything (n| above).
            if (shop.gearStale) then
                shop.gearStale = false;
            else
                -- COMMITTED ONLY BEHIND A HEADER. An answer whose `n|` never
                -- arrived says nothing about what the bags hold, so the rows
                -- on screen stay -- which is what this branch did before the
                -- staging table, when a missing n| simply left the live list
                -- alone. A header that DID arrive replaces the lot in one
                -- statement.
                if (staged ~= nil and staged.shown ~= nil) then
                    shop.gear      = staged.gear;
                    shop.gearShown = staged.shown;
                    shop.gearTotal = staged.total;
                    shop.gearMax   = staged.max;
                end

                shop.gearSynced = true;
            end
        elseif (closing == 'shelf') then
            if (staged ~= nil) then
                outfit.jobs = staged.jobs;
                outfit.rows = staged.rows;
            end

            outfit.synced = true;
        elseif (closing == 'arms') then
            if (staged ~= nil) then
                arms.categories = staged.categories;
                arms.rows       = staged.rows;
            end

            arms.synced = true;
        elseif (closing == 'pops') then
            if (staged ~= nil) then
                pop.tiers = staged.tiers;
                pop.rows  = staged.rows;
            end

            pop.byTier    = { };
            pop.byIndex   = { };
            pop.ungrouped = { };

            pop.synced = true;
            pop.rev    = pop.rev + 1;

            --[[
            * GROUPED ONCE, WHERE THE ROWS ARE COMMITTED. The panel drew its
            * shelf by walking every row for every tier header and the quote
            * line under it re-scanned the whole shelf every frame to name a
            * row it already had the number of -- a quadratic redraw of a
            * shape the answer fixes. Building it here also gives a row whose
            * tier names no header somewhere to be drawn: the loop that
            * matched on the directory silently dropped those.
            --]]
            local tierOf = { };

            for _, tier in ipairs(pop.tiers) do
                pop.byTier[tier.key] = { };
                tierOf[tier.key]     = tier;
            end

            for _, row in ipairs(pop.rows) do
                pop.byIndex[row.index] = row;

                local bucket = pop.byTier[row.tier];

                if (bucket ~= nil) then
                    if (#bucket == 0) then
                        -- The tier header states the cost every key under it
                        -- charges, off the FIRST row the server put in the
                        -- tier -- its own numbers, never a constant here.
                        tierOf[row.tier].head = string.format('%s -- %d hundred-piece(s) + %d testimon%s',
                            tierOf[row.tier].label, row.hundreds, row.testimonies,
                            row.testimonies == 1 and 'y' or 'ies');
                    end

                    table.insert(bucket, row);
                else
                    table.insert(pop.ungrouped, row);
                end
            end
        elseif (closing == 'jeweler') then
            if (staged ~= nil) then
                jewel.cases = staged.cases;
                jewel.rows  = staged.rows;
            end

            jewel.byCase    = { };
            jewel.ungrouped = { };

            jewel.synced = true;

            -- Bucketed under the case the index band names, the Pop-Items'
            -- rule one shelf over -- and a row whose band names no case in
            -- the directory now has somewhere to be drawn instead of being
            -- silently dropped by the loop that matched on it.
            local caseOf = { };

            for _, case in ipairs(jewel.cases) do
                jewel.byCase[case.catId] = { };
                caseOf[case.catId]       = case;
            end

            for _, row in ipairs(jewel.rows) do
                local bucket = jewel.byCase[row.catId];

                if (bucket ~= nil) then
                    if (#bucket == 0) then
                        -- The case header's price is the FIRST ROW'S, off the
                        -- wire -- never a constant of this file's own (the
                        -- ArmsDealer's rule: a hardcoded number here would be
                        -- a second source of truth for MONEY).
                        caseOf[row.catId].head = string.format('%s -- %d DC each',
                            caseOf[row.catId].label, row.price);
                    end

                    table.insert(bucket, row);
                else
                    table.insert(jewel.ungrouped, row);
                end
            end
        elseif (closing == 'balance') then
            if (staged ~= nil) then
                state.ledger = staged.ledger;
            end

            -- THE "AGO" COLUMN IS RENDERED HERE, ONCE PER ANSWER, not per
            -- row per frame. `created` is a UNIX timestamp the database
            -- wrote, so saying how long ago it was needs the WALL clock --
            -- and os.time() is the one clock this file must not read sixty
            -- times a second beside five rows. One read per answer also
            -- means every line in an answer is aged from the same instant
            -- instead of straddling a second boundary between two of them.
            -- The read is re-armed whenever the block is opened, so the
            -- column is accurate at the moment a player looks at it.
            local at = os.time();

            for _, row in ipairs(state.ledger) do
                row.ago = fmtAgo(row.created, at);
            end
        elseif (closing == 'augment' or closing == 'confirm' or closing == 'buy'
                or closing == 'armsbuy' or closing == 'popbuy' or closing == 'jewelbuy'
                or closing == 'gil') then
            writePending = nil;

            if (closing == 'confirm') then
                -- Armed or not, this quote is spent. The k| that came with the
                -- answer is already on screen and says what the item is now.
                shop.quote   = nil;
                outfit.quote = nil;
                arms.quote   = nil;
                jewel.quote  = nil;
                gil.quote    = nil;

                -- A settled pop confirm took hundred-pieces and testimonies
                -- out of the bag; the h| purse on screen and every row's cost
                -- are now a frame of the past. A read, so it may be re-asked;
                -- nothing here is re-sent.
                --
                -- KEYED ON THE FLAG, NOT ON `pop.quote`: the click that sent
                -- this line cleared the quote in the same statement, so the
                -- test this used to make was against a value the caller had
                -- guaranteed was nil (see popConfirmSent).
                pop.quote = nil;

                if (popConfirmSent) then
                    popConfirmSent    = false;
                    pop.synced        = false;
                    requested['pops'] = nil;
                end

                -- The used/free counts in the picker moved under it. A read,
                -- so it may be re-asked; nothing here is re-sent.
                shop.gearFor = nil;
            end
        end

        return;
    end

    if (kind == 'y') then
        state.poolVersion = num(parts[2], nil);
        state.day         = num(parts[3], nil);
        state.band        = num(parts[5], nil);
        state.secsToDay   = num(parts[6], 0);
        state.secsToWeek  = num(parts[7], 0);
        state.playerBand  = num(parts[8], nil);
        -- The gil exchange's rate and ceiling (appended 2026-09-04). nil on
        -- a server that predates it, and nil draws no control: a Buy that
        -- only ever answers "unknown verb" is worse than no Buy.
        state.gilPerCoin  = num(parts[9], nil);
        state.gilMaxCoins = num(parts[10], nil);

        --[[
        * THE TWO EIGHTS (appended 2026-09-07, dwu_protocol.md positions
        * 10-13): how many contracts this account holds and how many it may,
        * how many it has completed this Vana'diel day and how many it may.
        *
        * ALL FOUR OR NONE, and the window enforces that rather than trusting
        * it: a header that carried two of them would otherwise draw
        * "Accepted 3/nil" through string.format, and a half-known cap is a
        * claim this window has no business making. Nil is the older server,
        * and nil draws NOTHING about a cap -- the gil exchange's rule
        * (parts 9 and 10, one line up) for the gil exchange's reason: a
        * ceiling invented by a client is a ceiling the server never agreed
        * to, and a window that says "8 of 8, abandon one" at a server with
        * no cap has locked a player out of a verb that would have worked.
        *
        * The line itself is composed HERE, once per header, and not in the
        * two panels that draw it: a `y|` is the only thing that can move
        * these numbers, and two panels formatting the same sentence sixty
        * times a second is the per-frame cost every card on this window was
        * rebuilt to stop paying.
        --]]
        local acceptedCount = num(parts[11], nil);
        local acceptedMax   = num(parts[12], nil);
        local doneToday     = num(parts[13], nil);
        local doneMax       = num(parts[14], nil);

        if (acceptedCount == nil or acceptedMax == nil
                or doneToday == nil or doneMax == nil) then
            state.acceptedCount = nil;
            state.acceptedMax   = nil;
            state.doneToday     = nil;
            state.doneMax       = nil;
            state.capsLine      = nil;
            state.fullNote      = nil;
        else
            state.acceptedCount = acceptedCount;
            state.acceptedMax   = acceptedMax;
            state.doneToday     = doneToday;
            state.doneMax       = doneMax;

            -- THE NUMBERS ARE THE SERVER'S, both of them. "8" is written
            -- nowhere in this sentence: the day the owner moves either cap,
            -- a window carrying a literal would go on telling players the
            -- old rule with the new one already enforced under it.
            state.capsLine = string.format(
                'Accepted %d/%d -- Completed today %d/%d',
                acceptedCount, acceptedMax, doneToday, doneMax);

            -- The sentence that replaces an Accept button once the slots are
            -- full, composed on the same rule and for the same reason.
            state.fullNote = string.format(
                'all %d contract slots are full -- abandon one to free it',
                acceptedMax);
        end

        state.clockAt     = os.clock();
        state.rollAsked   = false;

        -- A server that predates the band look never sends the appended
        -- field and ignores a band argument -- so stop asking with one, or
        -- the arrows would relabel a board that never changes.
        if (state.playerBand == nil) then
            state.viewBand   = nil;
            state.playerBand = state.band;
        end

        return;
    end

    if (kind == 'o') then
        -- ENVELOPE-GUARDED like u|, b| and w| (2026-09-06). quest_core.lua
        -- emits an offer only from emitBoardRecords, and `board` is the only
        -- envelope that replaces this section -- so an o| arriving anywhere
        -- else was an append to a list nothing would ever clear. The guard is
        -- what makes the section's own replacement a bound rather than a
        -- coincidence about where the server happens to emit today.
        if (state.inbound ~= 'board') then
            return;
        end

        -- parts[9] is the expansion tag ('COP'), APPENDED in 2026-08-21 and
        -- present only on a gated slot. nil when absent, never '' -- a card
        -- must be able to tell "no tag" from "a tag whose text is empty", and
        -- the badge below is drawn on the nil test.
        local tag = parts[9];

        if (tag ~= nil and tag == '') then
            tag = nil;
        end

        local slot = parts[2];
        local qkey = parts[4];

        --[[
        * A CARD WITHOUT ITS TWO KEYS IS NOT A CARD (2026-09-06). The slot
        * handle IS the accept argument and the quest key is what the board
        * matches an accepted contract by -- and the panel writes
        * `offered[offer.qkey] = true`, which on a nil key is not a missing
        * card but `table index is nil`: a throw inside the render pcall,
        * which SHUTS THE WHOLE WINDOW and tells the player to fall back to
        * typed commands. One truncated record on a 130-byte wire cost the
        * board. A board is replaced wholesale, so refusing the record costs
        * exactly the row it was.
        --]]
        if (slot == nil or slot == '' or qkey == nil or qkey == '') then
            return;
        end

        local kind   = parts[3];
        local name   = word(parts[5]);
        local needed = num(parts[6], 0);
        local reward = num(parts[7], 0);

        table.insert(into('offers', state.offers), {
            slot   = slot,
            kind   = kind,
            qkey   = qkey,
            name   = name,
            needed = needed,
            reward = reward,
            state  = parts[8],
            tag    = tag,

            -- EVERY FIXED STRING THE CARD DRAWS, composed here. The board
            -- draws up to fourteen cards EVERY FRAME and each was rebuilding
            -- its period word, its objective sentence, its reward and its
            -- button label -- four allocations a card, sixty times a second,
            -- for text the record settled. A board answer replaces this whole
            -- section (it never merges), so a fresh record composes fresh text
            -- and there is nothing to invalidate.
            periodWord = periodLabel(slot),
            objective  = objectiveText(kind, needed, name),
            rewardText = string.format('%d DC', reward),
            acceptBtn  = string.format('Accept##dwquest_accept_%s', slot),
            abandonBtn = string.format('Abandon##dwquest_abandon_%s', slot),
        });

        return;
    end

    if (kind == 'a') then
        handleContract(parts);

        return;
    end

    if (kind == 'g') then
        state.balance = num(parts[2], nil);

        --[[
        * THE THREE-PART FORM IS TOLD APART BY ITS ENVELOPE, and it has to be.
        * `g|<balance>|<bt>` in a board or storefront answer is the Burst
        * Token purse; `g|<balance>|<earned>|<spent>` in a `balance` answer is
        * the lifetime ledger, and its part 3 is a career total that can run
        * to five figures. dwu_protocol.md says the two forms are separated
        * by the envelope and this read was not doing it, so a player who
        * typed `!dwu balance` by hand -- permission 0, anyone can, and the
        * addon does not intercept the line -- had their header report their
        * lifetime EARNINGS as a token balance until the next board sync.
        --]]
        if (state.inbound == 'balance') then
            state.earned = num(parts[3], nil);
            state.spent  = num(parts[4], nil);

            return;
        end

        -- Part 3 joined 2026-08-25 (append-only growth): the Burst Token
        -- balance, the arena's currency. Absent on an older server, so the
        -- previous number is KEPT rather than replaced with an invented
        -- zero -- nil until the first server that knows about it answers.
        state.burstBalance = num(parts[3], state.burstBalance);

        return;
    end

    --[[
    * l| -- one ledger line, newest first, at most five, `balance` only.
    * `created` is a UNIX timestamp the database wrote, so the "ago" beside it
    * is the one piece of arithmetic this window does over a server number --
    * and it is display over a CLOCK, not over a coin (client discipline 2 is
    * about prices, payouts and progress). The delta and the reason are the
    * server's own words, rendered.
    --]]
    if (kind == 'l' and state.inbound == 'balance') then
        local ledger = into('ledger', state.ledger);

        if (#ledger < LEDGER_MAX) then
            local delta = num(parts[2], 0);

            table.insert(ledger, {
                delta   = delta,
                -- Formatted once, here, rather than per row per frame: the
                -- ledger is five lines that never change between answers.
                amount  = string.format('  %+d DC', delta),
                reason  = word(parts[3]),
                created = num(parts[4], 0),
            });
        end

        return;
    end

    -- q| -- the server-wide contract (Phase 5). Every number is the server's;
    -- `mine` and `minKills` are what the card uses to say whether this account
    -- is on the payout roster, and the window never works that out for itself.
    if (kind == 'q') then
        local commName   = word(parts[4]);
        local commNeeded = num(parts[6], 0);

        local community =
        {
            qkey     = parts[2],
            id       = num(parts[3], 0),
            name     = commName,
            progress = num(parts[5], 0),
            needed   = commNeeded,
            mine     = num(parts[7], 0),
            minKills = num(parts[8], 0),
            reward   = num(parts[9], 0),
            state    = parts[10] or 'open',

            -- The bar's sentence, composed here with the cards' (one q| per
            -- board answer, and this card is drawn every frame the Board tab
            -- is open).
            objective = objectiveText('comm', commNeeded, commName),
        };

        -- Staged with the board it belongs to (SECTIONS): the bar swaps in
        -- with the cards above it, and a board that carries no q| commits a
        -- nil, which is what "no community contract this week" is.
        if (arriving ~= nil) then
            arriving.community = community;
        else
            state.community = community;
        end

        return;
    end

    --[[
    * The Exchange records. Every one of them is rendered as it arrived.
    --]]

    -- v| -- the storefront header and its rotation countdown.
    if (kind == 'v') then
        shop.poolVersion = num(parts[2], nil);
        shop.day         = num(parts[3], nil);
        shop.secsToRoll  = num(parts[4], 0);
        shop.clockAt     = os.clock();
        shop.rollAsked   = false;

        return;
    end

    -- u| -- one augment offer. It also rides the `augment` (quote) answer,
    -- where it is context for the p| rather than a storefront row: appending
    -- it there would grow the storefront by one every time somebody asked a
    -- price.
    if (kind == 'u') then
        if (state.inbound == 'augments') then
            local slot  = word(parts[2]);
            local price = num(parts[5], 0);

            table.insert(into('offers', shop.offers), {
                slot  = slot,
                augid = num(parts[3], 0),
                rank  = num(parts[4], 0),
                price = price,
                fits  = parts[6],
                -- word(), not the raw field: this label is handed to
                -- imgui.Text directly, and a truncated record must cost the
                -- label rather than the window (see `word`).
                label = word(parts[7]),
                -- The card's price line and its button label, composed here
                -- for the f| rows' reason: the Exchange redraws the whole
                -- shelf every frame and both are fixed by this record.
                costText  = string.format('%d DC', price),
                chooseBtn = string.format('Choose##dwquest_offer_%s', slot),
            });
        end

        return;
    end

    -- w| -- one character on the account. `state` is the server's word on
    -- whether that character can be augmented, and the reason is worth
    -- showing: "logged in" is a thing the player can fix.
    --
    -- ENVELOPE-GUARDED like u| and b| beside it (2026-09-06). quest_core.lua
    -- emits the roster only inside `augments`, which is also the only
    -- envelope that resets this table -- so a w| arriving anywhere else was
    -- an append with nothing behind it to clear, and the guard is what makes
    -- the reset a bound rather than a coincidence.
    if (kind == 'w') then
        if (state.inbound == 'augments') then
            table.insert(into('roster', shop.roster), { name = parts[2], state = parts[3] });
        end

        return;
    end

    -- b| -- one STATIC shelf offer (Weapon Burst 2026-08-25, X-Magic
    -- 2026-08-30). Never rotating, priced in Burst Tokens AND DC -- its own
    -- record kind so a window that cannot state both prices never renders
    -- the offer at all.
    --
    -- fits ARRIVES ON THE WIRE (field 7) and is not stamped here. It used to
    -- be the constant 'wield', which was true while Weapon Burst was the only
    -- static shelf and became a lie the moment X-Magic arrived: rings only,
    -- and the card would have told the player to augment a weapon that the
    -- server was about to refuse. The default below is that same constant, so
    -- a window talking to a server too old to send the field behaves exactly
    -- as it did before -- which is what lets the field be APPENDED rather
    -- than versioned.
    if (kind == 'b') then
        if (state.inbound == 'augments') then
            local fits = parts[7];

            local slot    = word(parts[2]);
            local btPrice = num(parts[4], 0);
            local price   = num(parts[5], 0);

            table.insert(into('burst', shop.burst), {
                slot    = slot,
                augid   = num(parts[3], 0),
                btPrice = btPrice,
                price   = price,
                fits    = (type(fits) == 'string' and fits ~= '') and fits or 'wield',
                label   = word(parts[6]),
                -- A static shelf offer states BOTH currencies (understating
                -- one is the reason this record kind exists), composed here
                -- with the rotating offers' price line.
                costText  = btPrice > 0
                    and string.format('%d Burst Tokens + %d DC', btPrice, price)
                    or string.format('%d DC', price),
                chooseBtn = string.format('Choose##dwquest_offer_%s', slot),
            });
        end

        return;
    end

    -- n| -- the gear header. shown < total means the list is TRUNCATED, and
    -- the window says so rather than letting a cap read as an inventory.
    --
    -- SINCE 1.20.2 THE HEADER CARRIES THE QUESTION (fields 7-9: the offer
    -- handle, the character, the search, each lowercase alphanumerics, the
    -- search capped at 24). A gear answer used to carry no identity, so a
    -- slow answer to search A landed after search B was asked, filled the
    -- pane with A's bag, marked B answered, and a lost B never re-asked (the
    -- 2026-08-09 review's second backlog item). An answer that is not the
    -- one on screen is now dropped whole -- rows ignored, nothing committed
    -- -- and the ask goes back to unanswered so askOnce re-asks on its
    -- clock. A server too old to send the fields is trusted as before.
    if (kind == 'n') then
        if (parts[7] ~= nil) then
            local function ident(text)
                return string.sub((tostring(text or ''):lower():gsub('[^%w]', '')), 1, 24);
            end

            local wantOffer  = tostring(shop.picked or '');
            local wantWho    = ident(shop.who);
            local wantFilter = ident(shop.filterApplied);

            if (parts[7] ~= wantOffer or (parts[8] or '') ~= wantWho or (parts[9] or '') ~= wantFilter) then
                shop.gearStale = true;

                local asked = requested['gear'];

                if (type(asked) == 'table') then
                    asked.answered = false;
                end

                return;
            end
        end

        --[[
        * THE HEADER'S THREE COUNTS STAGE WITH THE ROWS THEY DESCRIBE. This
        * used to blank `shop.gear` in the middle of the envelope and refill
        * it record by record, which is the wipe SECTIONS exists to end: the
        * gear list drew "Nothing here can take that augment" -- a specific
        * claim, not a loading state -- for every frame between this record
        * and the first `c|`, and ImGui clamped the pane's scroll to the top
        * of the empty list on the way past.
        *
        * The counts are what the `z|` commits ON: an answer whose header
        * never arrived says nothing about the bags, and leaves the rows on
        * screen exactly as it did before.
        --]]
        if (arriving ~= nil) then
            arriving.gear  = { };
            arriving.shown = num(parts[2], 0);
            arriving.total = num(parts[3], 0);
            arriving.max   = num(parts[4], 0);
        else
            shop.gear      = { };
            shop.gearShown = num(parts[2], 0);
            shop.gearTotal = num(parts[3], 0);
            shop.gearMax   = num(parts[4], 0);
        end

        return;
    end

    -- c| -- one item that can take an augment. The id is what a purchase
    -- names; used/free are the server's own counts.
    if (kind == 'c') then
        -- ENVELOPE-GUARDED for the o| record's reason: `gear` is the only
        -- verb that emits one and the only section that replaces this list.
        -- `gearStale` is the second half of the same idea one level down --
        -- an answer for a question the window is no longer asking commits
        -- nothing at all (see the n| handler).
        if (state.inbound ~= 'gear' or shop.gearStale) then
            return;
        end

        local itemid = num(parts[2], 0);
        local used   = num(parts[3], 0);
        local count  = num(parts[5], 1);
        local name   = word(parts[6]);

        table.insert(into('gear', shop.gear), {
            itemid = itemid,
            used   = used,
            free   = num(parts[4], 0),
            count  = count,
            name   = name,
            -- The row's own strings and its hover card, composed here for the
            -- f| rows' reason: the gear list redraws all of them every frame
            -- and every one is fixed by this record.
            title    = string.format('%s%s', name, count > 1 and string.format('  (x%d)', count) or ''),
            usedText = string.format('%d of 4 used', used),
            pick     = string.format('Pick##dwquest_pick_%d', itemid),
            slotsBtn = string.format('Slots##dwquest_slots_%d', itemid),
            card     = { itemid = itemid, label = name },
        });

        return;
    end

    -- k| -- an item's slot view. It is the header of a slot list, so it clears
    -- the rows behind it: s| records are emitted only for OCCUPIED slots, and
    -- a slot that emptied would otherwise linger from the previous answer.
    if (kind == 'k') then
        local itemName = word(parts[6]);
        local itemId   = num(parts[5], 0);
        local used     = num(parts[2], 0);

        -- CLAMPED, because this one number is a per-frame RENDER-LOOP
        -- BOUND (`for index = 1, item.maxslots` in the slot view) and
        -- LuaJIT's tonumber accepts 'inf' as readily as it accepts 4 --
        -- so a corrupt or truncated record does not cost a row, it costs
        -- the frame loop, and the client with it. The server's own
        -- xi.dwQuestAugments.MAX_SLOTS is 4; 16 leaves additive headroom
        -- and still terminates. (dwcraft.lua's `a|` count carries the
        -- same clamp for the same reason, its Phase 6 finding.)
        --
        -- A LOCAL, not repeated in the sentence below it: the heading line
        -- states this same number, and a clamp written twice is a clamp that
        -- disagrees with itself the day one copy is tuned.
        local maxSlots = math.max(math.min(num(parts[4], 4), 16), 0);

        shop.item = {
            used     = used,
            free     = num(parts[3], 0),
            maxslots = maxSlots,
            itemid   = itemId,
            name     = parts[6],
            charname = parts[7],
            stamp    = parts[8],

            -- The slot view's heading line and its hover card, composed
            -- here. `shop.who` cannot move under an item on screen (picking
            -- a different character tears the item down), so the charname
            -- suffix is as fixed by this record as the name is.
            title    = string.format('%s%s', itemName,
                (parts[7] ~= nil and parts[7] ~= '' and shop.who ~= '') and (' (' .. parts[7] .. ')') or ''),
            slotsUsed = string.format('%d of %d augment slots used', used, maxSlots),
            card     = { itemid = itemId, label = itemName },
        };

        shop.slots = { };

        -- The purchase landed. The sentence is the server's own (it prints one
        -- in chat on every tier, because money always says so); this is the
        -- window's acknowledgement that the click did something.
        if (state.inbound == 'confirm') then
            toast(string.format('%s: %d of %d slots used.',
                shop.item.name, shop.item.used, shop.item.maxslots));
        end

        return;
    end

    -- s| -- one occupied augment slot. An absent index is an empty slot.
    if (kind == 's') then
        local index = num(parts[2], 0);

        if (index >= 1 and index <= 4) then
            local augid = num(parts[3], 0);
            local rank  = num(parts[4], 0);

            -- DECODED HERE, NOT IN THE RENDER. augmentText runs a gsub with a
            -- FUNCTION CALLBACK over the label to recompute its magnitudes,
            -- and the slot view drew all four slots -- twice on the landing
            -- one -- every frame. The pair is fixed by this record.
            shop.slots[index] = {
                augid = augid,
                rank  = rank,
                text  = augmentText(augid, rank),
            };
        end

        return;
    end

    -- p| -- A QUOTE, AND THE ONLY THING THAT CAN ARM AN EXCHANGE CONFIRM.
    -- Not a purchase, and incapable of becoming one on its own. It disarms
    -- the Outfitter's quote the way the server does (D14): one pending
    -- purchase per character, both storefronts.
    if (kind == 'p') then
        shop.quote = {
            price   = num(parts[2], 0),
            augid   = num(parts[3], 0),
            rank    = num(parts[4], 0),
            landing = num(parts[5], 0),
            holds   = num(parts[6], 0),
            label   = parts[7],

            -- Part 8 joined 2026-08-25 (append-only): the Burst Token half
            -- of a Weapon Burst quote. 0 for the rotating offers.
            btPrice = num(parts[8], 0),
            at      = os.clock(),
            armed   = true,
        };

        outfit.quote = nil;
        -- All four storefronts (D14): the server disarmed every other side
        -- when it quoted this one, so no other Confirm may stay on screen.
        -- arms.quote joined this teardown with pop.quote on 2026-08-30 -- it
        -- had been missing since the ArmsDealer shipped, a stale-Confirm
        -- window the server's own router made harmless but the screen showed.
        arms.quote  = nil;
        pop.quote   = nil;
        jewel.quote = nil;

        return;
    end

    --[[
    * The Outfitter records (Phase 7). Every one rendered as it arrived.
    --]]

    -- j| -- one job in the shelf directory.
    if (kind == 'j') then
        --[[
        * A DIRECTORY ENTRY WITHOUT ITS KEY NAMES NOTHING (2026-09-06). All
        * four panels select and group by this field, and the Pop-Items shelf
        * uses it as a TABLE INDEX when it buckets the rows -- so a truncated
        * `j|` was not one missing heading, it was `table index is nil` inside
        * the answer's own handler, which loses the record that raised it AND
        * the grouping the rest of the shelf needed: the panel drew nothing at
        * all and the log said "bad record". The label is already defended by
        * word(); this defends the half a panel keys on.
        --]]
        local key = parts[3];

        if (key == nil or key == '') then
            return;
        end

        if (state.inbound == 'shelf') then
            table.insert(into('jobs', outfit.jobs), {
                jobId = num(parts[2], 0),
                word  = key,
                -- The directory label is handed to BeginCombo directly.
                label = word(parts[4]),
            });
        elseif (state.inbound == 'arms') then
            -- The ArmsDealer's category directory rides the same letter, told
            -- apart by the envelope: catId | key | label.
            table.insert(into('categories', arms.categories), {
                catId = num(parts[2], 0),
                key   = key,
                label = word(parts[4]),
            });
        elseif (state.inbound == 'pops') then
            -- The Pop-Items tier directory, same letter, same rule:
            -- tierId | key | label.
            table.insert(into('tiers', pop.tiers), {
                tierId = num(parts[2], 0),
                key    = key,
                label  = word(parts[4]),
            });
        elseif (state.inbound == 'jeweler') then
            -- The Jeweler's case directory, same letter, same rule:
            -- catId | key | label. The rows are grouped under these.
            table.insert(into('cases', jewel.cases), {
                catId = num(parts[2], 0),
                key   = key,
                label = word(parts[4]),
            });
        end

        return;
    end

    -- r| -- one pop row (the pops envelope only). The two item ids at the
    -- middle are what the icons and hover cards draw from -- the second is 0
    -- outside the sky pairs; the item NAMES resolve from the client's own
    -- DATs, never the wire (the dwbags rule).
    if (kind == 'r' and state.inbound == 'pops') then
        local index = num(parts[2], 0);
        local label = word(parts[9]);

        table.insert(into('rows', pop.rows), {
            index       = index,
            tier        = parts[3],
            hundreds    = num(parts[4], 0),
            testimonies = num(parts[5], 0),
            itemid      = num(parts[6], 0),
            itemid2     = num(parts[7], 0),
            where       = parts[8],
            label       = label,
            -- Composed here for the f| rows' reason one record up: the shelf
            -- draws both of these every frame and both are fixed by this
            -- record.
            pops        = string.format('pops %s (%s)', label, word(parts[8])),
            buy         = string.format('Buy##dwquest_pop_buy_%d', index),
        });

        return;
    end

    -- h| -- the bag-side purse: hundred-pieces held, DIFFERENT testimony
    -- types held. Counted server-side by the exact walk the confirm charges
    -- with, so this line and the refusal sentences can never disagree.
    if (kind == 'h' and state.inbound == 'pops') then
        pop.hundreds = num(parts[2], 0);
        pop.types    = num(parts[3], 0);

        return;
    end

    -- x| -- THE ONLY THING THAT CAN ARM A POP-ITEMS CONFIRM (the t| rule,
    -- one storefront over). Carries no label -- the r| row the index names
    -- is already on screen.
    if (kind == 'x') then
        pop.quote = {
            index       = num(parts[2], 0),
            hundreds    = num(parts[3], 0),
            testimonies = num(parts[4], 0),
            holds       = num(parts[5], 0),
            at          = os.clock(),
        };

        shop.quote   = nil;
        outfit.quote = nil;
        arms.quote   = nil;
        jewel.quote  = nil;

        return;
    end

    -- f| -- one row for the job/category that was asked. The id at the tail is
    -- what the icon and the hover card are drawn from. The middle fields differ
    -- by envelope: level|slot for the shelf, wtype|jobs for the ArmsDealer,
    -- slot|jobs for the Jeweler (whose rows carry their case key from the
    -- index band, 3000 + catId*100, so the panel can group them).
    --[[
    * THE ROW'S OWN THREE STRINGS ARE COMPOSED HERE, NOT IN THE RENDER
    * (2026-09-06). A shelf row draws its detail line, its price and its
    * button label every frame, and all three are fixed by the record: three
    * `string.format` calls per row per frame, sixty times a second, on
    * shelves of twenty-five rows. Rows are replaced wholesale by their own
    * `d|` reset, so a fresh record composes fresh text and there is nothing
    * to invalidate -- the board card's objective sentence, on the panels that
    * draw the most rows. (The `##` id has to be in the button label ImGui
    * sees, so it is built once here rather than concatenated per frame.)
    --]]
    if (kind == 'f') then
        if (state.inbound == 'shelf') then
            local index = num(parts[2], 0);
            local price = num(parts[3], 0);
            local level = num(parts[5], 0);

            table.insert(into('rows', outfit.rows), {
                index  = index,
                price  = price,
                itemid = num(parts[4], 0),
                level  = level,
                slot   = parts[6],
                label  = word(parts[7]),
                detail = string.format('lv%d %s', level, word(parts[6])),
                cost   = string.format('%d DC', price),
                buy    = string.format('Buy##dwquest_outfit_buy_%d', index),
            });
        elseif (state.inbound == 'arms') then
            local index = num(parts[2], 0);
            local price = num(parts[3], 0);

            table.insert(into('rows', arms.rows), {
                index  = index,
                price  = price,
                itemid = num(parts[4], 0),
                wtype  = parts[5],
                jobs   = parts[6],
                label  = word(parts[7]),
                detail = string.format('%s, %s', word(parts[5]), word(parts[6])),
                cost   = string.format('%d DC', price),
                buy    = string.format('Buy##dwquest_arms_buy_%d', index),
            });
        elseif (state.inbound == 'jeweler') then
            local index = num(parts[2], 0);
            local price = num(parts[3], 0);

            table.insert(into('rows', jewel.rows), {
                index  = index,
                -- The case is the index band (3000 + catId*100 + ordinal),
                -- the server's own numbering: nothing here invents one.
                catId  = math.floor((index - 3000) / 100),
                price  = price,
                itemid = num(parts[4], 0),
                slot   = parts[5],
                jobs   = parts[6],
                label  = word(parts[7]),
                detail = string.format('%s, %s', word(parts[5]), word(parts[6])),
                cost   = string.format('%d DC', price),
                buy    = string.format('Buy##dwquest_jewel_buy_%d', index),
            });
        end

        return;
    end

    -- t| -- THE ONLY THING THAT CAN ARM A STOREFRONT CONFIRM. Not a purchase,
    -- and incapable of becoming one on its own. Routed by the envelope it
    -- arrived in: the ArmsDealer's armsbuy answer arms the ArmsDealer, the
    -- Outfitter's buy answer arms the Outfitter, and each disarms the others
    -- for the same reason p| disarms the Exchange's.
    if (kind == 't') then
        local quote = {
            index = num(parts[2], 0),
            price = num(parts[3], 0),
            holds = num(parts[4], 0),
            label = parts[5],
            at    = os.clock(),
        };

        if (state.inbound == 'armsbuy') then
            arms.quote   = quote;
            outfit.quote = nil;
            jewel.quote  = nil;
            gil.quote    = nil;
        elseif (state.inbound == 'jewelbuy') then
            jewel.quote  = quote;
            arms.quote   = nil;
            outfit.quote = nil;
            gil.quote    = nil;
        elseif (state.inbound == 'gil') then
            -- The gil exchange (2026-09-04): the same letter, its own
            -- envelope. <index> is the coin count and <price> is GIL.
            gil.quote    = quote;
            arms.quote   = nil;
            outfit.quote = nil;
            jewel.quote  = nil;
        else
            outfit.quote = quote;
            arms.quote   = nil;
            jewel.quote  = nil;
            gil.quote    = nil;
        end

        shop.quote = nil;
        pop.quote  = nil;

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWUDATA is ours -- consumed and blocked before parsing so a
* malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwquest_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwquest'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Reads over the synced state.
--]]

-- A countdown the server sent, aged by the wall clock since it arrived. Never
-- below zero: `secsLeft` is documented as never negative, and a bar counting
-- backwards past its own expiry is a number nobody can act on.
local function ticked(base, at, now)
    if (base == nil or at == nil) then
        return nil;
    end

    local left = base - (now - at);

    return left > 0 and left or 0;
end

local function fmtClock(secs)
    if (secs == nil) then
        return '--';
    end

    secs = math.floor(secs);

    if (secs <= 0) then
        return 'now';
    end

    if (secs >= 3600) then
        return string.format('%dh %02dm', math.floor(secs / 3600), math.floor((secs % 3600) / 60));
    end

    if (secs >= 60) then
        return string.format('%dm %02ds', math.floor(secs / 60), secs % 60);
    end

    return string.format('%ds', secs);
end

-- The rotation rolled while the window was open: the offers on screen belong
-- to the period that just ended. Asked ONCE per header -- y| clears the flag.
local function checkRotation(now)
    if (state.rollAsked or not state.synced or state.clockAt == nil) then
        return;
    end

    local day  = ticked(state.secsToDay, state.clockAt, now);
    local week = ticked(state.secsToWeek, state.clockAt, now);

    if ((day ~= nil and day <= 0) or (week ~= nil and week <= 0)) then
        state.rollAsked = true;

        refresh(boardVerb());
    end
end

--[[
* Actions. Every one is a line a player could type.
*
* Abandon names the QUEST KEY, not the handle: the server takes either, and
* the key cannot be renumbered out from under a click (client discipline 3).
--]]
--[[
* ACCEPT NAMES THE BAND THE CARD WAS DRAWN FOR (1.26.0). The server takes an
* optional band on the accept verb and signs the contract for that board, so a
* click on a lower band's card sends the band it is LOOKING at rather than
* relying on the server to guess -- state.band is the number the `y|` answered
* with, never the arrows' hope (state.viewBand), so the line can only ever name
* a board this window has actually been sent.
*
* The band is omitted when the server never said one, which is the only state
* in which this window does not know: an accept with no band falls back on the
* server's own remembered look and then on the player's band, both of which are
* what the pre-1.26.0 line already got.
--]]
local function acceptSlot(offer)
    local line = state.band ~= nil
        and string.format('!dwu accept %s %d', offer.slot, state.band)
        or  string.format('!dwu accept %s', offer.slot);

    beginWrite('accept', offer.name, line);

    state.status    = string.format('Signing %s...', offer.name);
    state.statusBad = false;
end

local function abandonContract(row)
    beginWrite('abandon', row.name, string.format('!dwu abandon %s', row.qkey));

    state.status    = string.format('Tearing up %s...', row.name);
    state.statusBad = false;
end

--[[
* The Exchange's actions. Every one is a line a player could type, and the
* three that name an item name it BY ID -- which is a thing the typed tier
* takes (`!drift augment x1 17324`) and the one form no item name can be
* ambiguous in.
--]]

-- The filter goes on a command line, so the two markers the server's argument
-- parser reads out of ANY token come off it first. A player typing "@Yakapo"
-- into a search box means it as words, not as a character switch, and a window
-- that let it through would quietly search somebody else's bags. `|` goes for
-- the wire's own reason.
local function safeFilter(text)
    return tostring(text or ''):gsub('[@#|\r\n]', ' '):gsub('%s+', ' '):gsub('^%s+', ''):gsub('%s+$', '');
end

local function gearRequest()
    if (shop.picked == nil) then
        return nil;
    end

    local command = string.format('!dwu gear %s', shop.picked);

    if (shop.who ~= '') then
        command = string.format('%s @%s', command, shop.who);
    end

    -- The committed search, never the live buffer. safeFilter already ran at
    -- the commit, which is where the marker scrub belongs.
    local filter = shop.filterApplied or '';

    if (filter ~= '') then
        command = string.format('%s %s', command, filter);
    end

    return command;
end

-- The list on screen answers exactly one request; when the request changes the
-- list is stale and the tracker has to be re-armed, or the window would sit
-- showing yesterday's bag under today's question.
local function invalidateGear()
    shop.gearFor    = nil;
    shop.gearSynced = false;
    requested['gear'] = nil;
end

local function chooseOffer(offer)
    shop.picked = offer.slot;
    shop.item   = nil;
    shop.slots  = { };
    shop.quote  = nil;

    invalidateGear();

    state.status    = string.format('%s -- pick what it goes on.', offer.label);
    state.statusBad = false;
end

local function chooseCharacter(name)
    shop.who   = name or '';
    shop.item  = nil;
    shop.slots = { };
    shop.quote = nil;

    invalidateGear();
end

-- Ask a price. A quote spends nothing, but it is queued as a write and never
-- retried all the same: it arms a confirmation server-side, and a duplicate
-- arriving late is a second armed quote for one click.
local function quoteItem(row, replaceSlot)
    local command = string.format('!dwu augment %s %s%d', shop.picked,
        shop.who ~= '' and ('@' .. shop.who .. ' ') or '', row.itemid);

    if (replaceSlot ~= nil) then
        command = string.format('%s #%d', command, replaceSlot);
    end

    beginWrite('augment', row.name, command);

    state.status    = string.format('Pricing %s...', row.name);
    state.statusBad = false;
end

-- The slot view on its own, for an item with nothing free: the player has to
-- see what is in the four slots before they can say which one to give up. A
-- read, so it may be re-asked; it quotes nothing and arms nothing.
local function inspectItem(row)
    shop.item  = nil;
    shop.slots = { };
    shop.quote = nil;

    issueRead(string.format('!dwu slots %s%d',
        shop.who ~= '' and ('@' .. shop.who .. ' ') or '', row.itemid));

    state.status    = string.format('Reading %s...', row.name);
    state.statusBad = false;
end

--[[
* THE PURCHASE. The only place this addon can spend anything.
*
* The quote is disarmed in the same statement that queues the line, so the
* record that authorised this purchase cannot authorise another one -- not on a
* double click, not on a frame that renders twice, not on a retry that does not
* exist. A refusal comes back as an `e|` and clears the quote outright; there
* is no path here that re-sends `confirm`.
--]]
local function confirmPurchase()
    if (shop.quote == nil or not shop.quote.armed) then
        return;
    end

    local label = shop.quote.label;

    shop.quote.armed = false;

    beginWrite('confirm', label, '!dwu confirm');

    state.status    = string.format('Buying %s...', label);
    state.statusBad = false;
end

--[[
* Rendering.
--]]

-- The level range a band number covers, fixed by the protocol (dwu_protocol.md,
-- `y|`: 1-20, 21-40, 41-60, 61-80, 81-99). Reading a documented mapping, like
-- periodLabel up beside the record handlers -- the server prints the same
-- range from the same band.
local BAND_COUNT = 5;

local function bandRange(band)
    return (band - 1) * 20 + 1, band == BAND_COUNT and 99 or band * 20;
end

--[[
* The band look: which band's board is asked for next. Stepping is a READ of a
* different board, never a write -- accept stays own-band only and the server
* enforces it besides. What the label renders is the y| the server answered
* with (state.band), so the arrows can never label a board they merely hoped
* for.
--]]
local function stepBand(delta)
    local current = state.viewBand or state.band or state.playerBand;

    if (current == nil) then
        return;
    end

    local target = current + delta;

    if (target < 1) then target = 1; end
    if (target > BAND_COUNT) then target = BAND_COUNT; end

    if (target == current) then
        return;
    end

    if (state.playerBand ~= nil and target == state.playerBand) then
        state.viewBand = nil;
    else
        state.viewBand = target;
    end

    refresh(boardVerb());
end


-- The kind badge. An UNKNOWN kind renders as itself rather than falling back
-- to 'zone': a server newer than this addon can offer a kind that did not
-- exist when it was built, and labelling it with the wrong one is worse than
-- showing a word the player has not seen before (dwu_protocol.md's rule about
-- never guessing at ids you do not recognise).
local KIND_BADGE =
{
    fam = 'family', zone = 'zone', eco = 'ecosystem',
    ws = 'weapon skill', night = 'night', wthr = 'weather', comm = 'server',
    clear = 'clear', -- the instanced sources (2026-09-05)

    -- The trade-skill slots (2026-09-07): d9/w7 craft, d10 fish, w8 gather.
    -- The badge is the word a player would use, not the wire's abbreviation.
    craft = 'craft', fish = 'fishing', gather = 'gathering',
};

--[[
* What a badge MEANS, on hover (1.20.3, owner request). Every badge the card
* draws came off the wire -- the period, the kind word, the tag -- and this
* table only explains the words the server already chose; a word it does not
* know draws with no tooltip rather than a borrowed one.
--]]
local BADGE_TIPS =
{
    Daily  = 'A daily offer: it changes with each Vana\'diel day. The countdown on the header line says when.',
    Weekly = 'A weekly offer: it changes with each Vana\'diel week. The countdown on the header line says when.',

    ['family']       = 'Slay the named monster family, wherever they stand. Kills the server credits you with advance it.',
    ['zone']         = 'Slay creatures in the named zone, whatever they are.',
    ['ecosystem']    = 'Slay creatures of the named ecosystem -- any family that belongs to it counts.',
    ['weapon skill'] = 'Only kills FINISHED with a weapon skill count: the blow that drops the target must be one.',
    ['night']        = 'Only kills between dusk and dawn, Vana\'diel time, count.',
    ['weather']      = 'Only kills made while the named zone\'s weather is up count -- clear skies pause the contract.',
    ['server']       = 'The server-wide contract: everyone\'s kills fill one bar. Read the payout line under it for your part.',
    ['clear']        = 'Not a hunt: floors cleared in the Gauntlet (/arena) or encounters won in a Raid (/raid). Everyone inside at the clear is credited one, whatever their level.',
    -- The trade-skill kinds (2026-09-07). Each says what DOES NOT count,
    -- because that is the half a player finds out by wasting materials.
    ['craft']        = 'Not a hunt: successful syntheses that burned the named crystal. NQ and HQ count the same, one per synthesis whatever it stacked, and a break counts nothing.',
    ['fishing']      = 'Not a hunt: every fish or item you land. A monster on the line and a lost catch count nothing.',
    ['gathering']    = 'Not a hunt: every harvesting, excavation, logging or mining attempt that hands you an item. All four count as one objective; an attempt that yields nothing counts nothing.',

    WILD   = 'The wildcard slot. Its shape changes every period -- a weapon-skill, night or weather contract at the period\'s own count and pay -- and the kind badge beside this one is what it landed on this time.',
    BOUNTY = 'The bounty: three times the count of an ordinary daily, and it pays like it.',
    COP    = 'Offered only while Chains of Promathia content is open, and its targets stand in those zones.',
    -- The 2026-09-05 slots. ROAM is a zone contract wearing a badge; the two
    -- instanced badges ride kind `clear`, whose own hint (above) says how a
    -- clear is counted.
    ROAM     = 'The roaming slot: a zone borrowed from another level band, rolled for your band each day and priced for the trip. The level range shown is the zone\'s; kills of any level count.',
    GAUNTLET = 'Gauntlet floors: every floor cleared in /arena counts one, for every real player inside when it falls.',
    RAID     = 'Raid encounters: every encounter won in /raid counts one, for every player inside at the kill.',
    -- The 2026-09-07 trade-skill slots. The tag says WHICH board slot this
    -- is; the kind badge beside it says how it is scored.
    CRAFT    = 'The synthesis slot: the crystal is rolled for the period, so the daily and the weekly can want different ones. Read the crystal on the card before you buy materials.',
    FISH     = 'The fishing slot: cast anywhere, with any rod and bait. Every fish or item landed counts one.',
    GATHER   = 'The gathering slot: harvesting, excavation, logging and mining all count towards the same number.',
};

--[[
* WHAT EVERY OTHER CONTROL DOES, on hover (1.22.0).
*
* The board card grew its tooltips on 2026-09-05 and nothing else did, so six
* of the seven tabs had a window full of buttons that explain themselves only
* by being clicked -- on a screen where two of the buttons spend money and a
* third spends items out of the bag.
*
* ONE TABLE, not sentences scattered through seven panels, for BADGE_TIPS'
* reason one step up: a tip is a claim about what a control does, and a claim
* that lives beside the control it describes is one nobody can audit without
* reading every panel. harness_dwquest.py hovers each control by name and
* holds the sentence it gets against the entry here.
*
* GREYED AND ABSENT CONTROLS SAY WHY. "busy..." is not an explanation, and a
* Buy button that has vanished because a quote is armed elsewhere is worse
* than one that says so -- the tips on those read as the reason, not the
* state. (ImGui reports no hover for a BeginDisabled item unless the hover
* test is asked to allow it, and that flag is newest-generation API this
* suite does not use -- so every one of these hangs on a piece of TEXT that
* replaced the control, never on a disabled control itself.)
*
* WRAPPED BY HAND at about seventy columns with '\n': ImGui draws a tooltip
* as wide as its widest line, and a sixty-word sentence on one line is a
* tooltip wider than the window it floats over.
--]]
local TIPS = {
    -- The header line.
    refresh   = 'Read the board again, and re-arm the kill ping for this session.\n'
             .. 'Use it if a counter looks stale -- a map that restarted under you\n'
             .. 'drops the arming, and only this re-takes it.',
    balance   = 'Drift Coins on your ACCOUNT, not this character: every character\n'
             .. 'you own earns into and spends out of the same purse.',
    noBalance = 'The server has not said your balance yet. It arrives with the\n'
             .. 'board -- Refresh asks again.',
    burst     = 'Burst Tokens, the Gauntlet\'s currency (/arena): a floor cleared is\n'
             .. 'tokens earned. The Weapon Burst and X-Magic shelves on the\n'
             .. 'Enchanter tab spend them beside coins.',
    ledger    = 'Where the coins went: your lifetime totals and the last five\n'
             .. 'movements on the account. Opening it asks the server again, so\n'
             .. 'the times beside the lines are right when you look at them.',
    lifetime  = 'Everything this account has ever earned and ever spent. The\n'
             .. 'difference is not the balance -- coins bought with gil are\n'
             .. 'earnings too.',
    options   = 'The two switches this addon keeps between sessions -- what it\n'
             .. 'moves out of the battle log, and what it files under chat. The\n'
             .. 'same pair as /quests rewards and /quests feed.',
    optRewards = 'Fields of Valor, Grounds of Valor and Records of Eminence pay in\n'
             .. 'message ids the CLIENT draws, so the server cannot tag them --\n'
             .. 'this addon blocks them and prints them where its own lines go.\n'
             .. 'Off leaves them in the battle log. Saved on this PC.',
    optFeed   = 'The kill line, the gil line and the experience, limit and\n'
             .. 'capacity chains, re-filed into the chat group (Window 2 on the\n'
             .. 'stock log config) and colour-coded per family. Off leaves them\n'
             .. 'in the battle log. Saved on this PC.',
    ledgerRow = 'One movement on the account\'s purse: what it was worth and the\n'
             .. 'server\'s own word for what caused it. Green earned, red spent.',
    ledgerAgo = 'How long ago the vault wrote this line, against your PC\'s clock.\n'
             .. 'It is worked out once when the answer lands, so re-opening the\n'
             .. 'ledger is what makes it current.',
    gilCount  = 'How many Drift Coins to buy with gil. The ceiling is the server\'s\n'
             .. 'and the box clamps to it.',
    gilBuy    = 'Ask what that many coins cost. It spends nothing: a Confirm\n'
             .. 'appears only when the server answers with the price.',
    gilRate   = 'The gil price of one Drift Coin, exactly as the server sent it.\n'
             .. 'Nothing on this window works a price out for itself.',
    gilQuote  = 'The server\'s price for the coins you asked for, and how long it\n'
             .. 'will honour it. The gil leaves first and the coins land second.',
    queued    = 'Lines waiting their turn. The client rate-limits chat, so this\n'
             .. 'window sends one every 1.2 seconds and holds the rest -- nothing\n'
             .. 'is dropped, it just arrives in order.',
    stamp     = 'The Vana\'diel day this board was rolled for, the level band it\n'
             .. 'was resolved for, and the version of the contract pool it came\n'
             .. 'out of. Useful in a bug report; nothing to act on.',
    clocks    = 'Earth time to the next daily and weekly roll. Both were exact when\n'
             .. 'the server sent them; the window counts down from there and reads\n'
             .. 'the board again when one reaches zero.',
    confirm   = 'Buy at the quoted price. One quote buys at most one thing, and a\n'
             .. 'refusal tears it up rather than asking again.',
    cancel    = 'Forget the quote here. The server\'s own copy ages out on its own\n'
             .. 'clock -- there is no verb for "never mind".',
    busy      = 'A line for this window is already on the wire. Nothing here is ever\n'
             .. 'sent twice, so the buttons wait for the answer rather than taking\n'
             .. 'a second click.',

    -- The Board tab.
    bandPrev  = 'Look at the level band below this one -- and sign from it: any\n'
             .. 'band at or below your own can be accepted without changing jobs,\n'
             .. 'and the contract is written for the board you are looking at.',
    bandNext  = 'Look at the level band above this one. A read only: a band above\n'
             .. 'yours cannot be signed, so its cards carry a sentence instead of\n'
             .. 'an Accept button.',
    bandLabel = 'The band this board was resolved for, and the levels it covers.\n'
             .. 'Everyone in a band is offered the same contracts -- the board is a\n'
             .. 'shared topic, not a private roll.',
    yourBand  = 'This is YOUR band, so everything below can be signed from here.\n'
             .. 'So can every band under it -- step back with the left arrow and\n'
             .. 'the Accept buttons come with you.',
    lowerBand = 'A band below yours, and you can sign it from here: Accept sends\n'
             .. 'this board\'s band with it, so the contract is the one on screen.\n'
             .. 'Kills count at any level, so a lower band\'s contract still pays.',
    otherBand = 'You are looking at a band ABOVE yours. Its open offers carry a\n'
             .. 'sentence instead of an Accept -- the server refuses a signature\n'
             .. 'above your own band, and only your own band and below can sign.',
    bandLoading = 'The arrows asked for that band and the server has not answered\n'
             .. 'yet. The label beside this still names the board actually on\n'
             .. 'screen -- it never runs ahead of the data under it.',

    -- The Exchange tab.
    shopClock = 'The four offers above rotate with the Vana\'diel day. A price taken\n'
             .. 'against today\'s offers is refused after the roll, so the window\n'
             .. 'reads the shelf again when this reaches zero.',
    choose    = 'Pick this augment, then ask the server which of your gear it can\n'
             .. 'go on. Nothing is spent and nothing is promised.',
    chosen    = 'Chosen. The list below is the server\'s own screen of what this can\n'
             .. 'go on -- not this client\'s reading of your bags.',
    fits      = 'What the server will let this augment go on. The gear list is\n'
             .. 'filtered by that same rule, so everything it shows can be bought.',
    offerHandle = 'The offer\'s handle -- what the typed tier calls it.\n'
             .. '`!drift gear x1` lists what it fits and\n'
             .. '`!drift augment x1 <item>` prices one, and the buttons here send\n'
             .. 'exactly those lines.',
    burstShelf = 'Always on the shelf, never in the rotation, and priced in BOTH\n'
             .. 'currencies. The card states both because understating one is how a\n'
             .. 'player agrees to a cost they were not shown.',
    who       = 'Whose bags to look in. Only OFFLINE characters on your account can\n'
             .. 'be augmented -- a logged-in character owns its own containers -- so\n'
             .. 'the others are shown greyed rather than hidden.',
    filter    = 'Part of an item name, then Enter. It narrows the SERVER\'s list; it\n'
             .. 'never searches this client\'s bags, which cannot see an alt\'s.',
    search    = 'Send the search. An empty box clears it.',
    usedSlots = 'How many of this item\'s four augment slots the server says are\n'
             .. 'already filled. The window never counts them itself.',
    pick      = 'Ask the price for putting the chosen augment on this item. It\n'
             .. 'spends nothing.',
    slotsBtn  = 'This item has no free slot. Show what is in all four, so you can\n'
             .. 'say which one to give up.',
    replace   = 'Ask a fresh price that names this slot. What is in it now is\n'
             .. 'destroyed by the purchase.',
    landing   = 'Which of the four slots the augment lands in, and the one rule\n'
             .. 'that outlives the purchase: an augmented item is bound to your\n'
             .. 'account for good.',
    back      = 'Back to the gear list. Nothing was asked for and nothing spent.',
    truncated = 'The server capped the list. Type part of a name above to narrow\n'
             .. 'it -- what you are looking for may be the row that did not fit.',

    -- The Augments reference tab.
    augSearch = 'Part of a label, or an augment id, then Enter.',
    augScope  = 'Every augment the engine implements, or only the ones the Exchange\n'
             .. 'sells. Local to this tab; the server is not asked again.',
    augCount  = 'How many catalog rows match, and which page of them you are on.\n'
             .. 'The search and the scope switch are local to this tab -- nothing\n'
             .. 'here asks the server anything.',
    augPrev   = 'The previous page of the reference.',
    augNext   = 'The next page of the reference.',
    augChoose = 'Pick this offer. It feeds the SAME picker the Enchanter tab uses,\n'
             .. 'so there is one chosen offer whichever tab chose it.',
    augIds    = 'The number in brackets is what a gear slot actually stores. The\n'
             .. 'Enchanter tab decodes the same numbers where it shows your slots.',

    markToday = 'One of the four augments the Exchange is offering TODAY. The four\n'
             .. 'rotate with the Vana\'diel day -- the Enchanter tab\'s clock says when.',
    markSold  = 'The Exchange sells this augment, though not today: it is in the pool\n'
             .. 'the daily roll draws from. A row with neither marker is one the\n'
             .. 'engine implements and nothing sells.',

    -- The storefront tabs.
    jobPick   = 'Whose shelf to fetch. The rows travel per job, so the window asks\n'
             .. 'the server as you pick rather than pulling the whole catalogue.',
    casePick  = 'Which case to fetch. The cases are priced apart, and every row\n'
             .. 'states its own price off the wire.',
    armsCase  = 'The case on screen, how many weapons are in it and what each one\n'
             .. 'costs -- all three off the rows the server sent. A case whose rows\n'
             .. 'are not all one price shows its band instead of "each"; every row\n'
             .. 'still states its own. Every piece here is Rare/Ex: it reaches your\n'
             .. 'own characters through the dwbags lane and can never leave your\n'
             .. 'account.',
    price     = 'What the server charges. The quote carries this same number and\n'
             .. 'the purchase spends that -- no price on this window is worked out\n'
             .. 'here.',
    buy       = 'Ask the price for this piece. It spends nothing: a Confirm appears\n'
             .. 'only when the server answers with the quote.',
    hold      = 'How long the server will honour this quote. Let it lapse and ask\n'
             .. 'again; nothing is charged either way.',
    quoteGone = 'One pending purchase per character, across every shelf here -- so\n'
             .. 'while a quote is armed the other Buy buttons stand down. Confirm\n'
             .. 'it or Cancel it and they come back.',
    popPurse  = 'Counted out of your INVENTORY only, by the same walk the purchase\n'
             .. 'charges with -- so this line and a refusal can never disagree.\n'
             .. 'Warehouse and satchel stock does not pay.',
    popTier   = 'What every key under this header costs: that many Dynamis\n'
             .. 'hundred-pieces, plus that many Job Testimonies of DIFFERENT jobs.',
    popBuy    = 'Ask what this key costs out of your bag. It spends nothing until\n'
             .. 'you confirm.',
    popWhere  = 'The notorious monster this key forces, and the zone its ??? stands\n'
             .. 'in. Item names come from your own client, never the wire.',
    popFind   = 'Part of a monster name, a zone or an item name, then Enter. It\n'
             .. 'narrows the shelf already on screen -- the whole thing arrived on\n'
             .. 'one read, so nothing here asks the server anything.',
    popFound  = 'How many of the shelf\'s keys the search kept. Clear the box and\n'
             .. 'press Find to see all of them again.',

    caps      = 'The two limits, both the server\'s own numbers. The first is how\n'
             .. 'many contracts this ACCOUNT may hold at once -- abandoning one\n'
             .. 'frees a slot at once. The second is how many it may complete in\n'
             .. 'one Vana\'diel day: past it, a filled contract waits, keeps its\n'
             .. 'progress and pays when the next day begins.',

    -- The tab bar.
    tabBoard  = 'Today\'s contracts for your level band -- what you could sign,\n'
             .. 'with Accept on each -- and the server-wide bar. What you have\n'
             .. 'ALREADY signed is on the Accepted tab beside this one.',
    tabAccepted = 'Every contract you are holding: its counter, what it pays, how\n'
             .. 'long is left, and the button that tears it up. Daily and weekly\n'
             .. 'alike, and the ones signed off an earlier board too.',
    tabShop   = 'Today\'s four augment offers, the always-open Weapon Burst and\n'
             .. 'X-Magic shelves, and the gear each can go on. (This tab was\n'
             .. 'called Exchange before 1.25.0.)',
    tabAugref = 'Every augment the engine implements: the label a player can read\n'
             .. 'beside the number a gear slot stores. (This tab was called\n'
             .. 'Augments before 1.25.0.)',
    tabOutfit = 'Artifact, AF +1, relic and Empyrean +2 sets, the job capes and the\n'
             .. 'race gear, a job at a time.',
    tabArms   = 'Artifact and relic weapons for Drift Coins, a case at a time.',
    tabPops   = 'Forced-spawn keys, priced out of your bag in Dynamis\n'
             .. 'hundred-pieces and Job Testimonies. No coins move here.',
    tabJewel  = 'The Chains of Promathia earrings and rings, for Drift Coins.',
};

--[[
* A STANDALONE SENTENCE, WRAPPED TO THE PANEL rather than off its right edge.
*
* Nine of this window's explanatory lines run past seventy characters and the
* Outfitter's shelf note runs past two hundred; ImGui does not wrap text
* unless it is told to, so on any window narrower than the sentence they were
* cut off mid-word with nothing on screen to say they had been. The worst of
* them is the line that tells a player which of the Outfitter's tiers are
* account-bound.
*
* `PushTextWrapPos(0.0)` wraps at the CONTENT REGION's own right edge, which
* inside a panel is the panel's -- so this follows the window when it is
* resized instead of pinning a width of its own. (The hover card at the top
* of this file pins 320 deliberately, because a floating card must render the
* same whatever it floats over; a panel line must not.)
*
* ONLY FOR LINES THAT STAND ALONE. A line followed by SameLine is part of a
* row, and wrapping one of those breaks the row rather than the sentence.
--]]
--[[
* One short tip on the item just drawn.
*
* Every fixed tooltip added in 1.22.0 goes through here so the pattern cannot
* drift call site by call site, and so a tip is one line under the control it
* belongs to rather than three lines of plumbing after every button. The
* board card's own tips are still written out longhand where they are
* composed from wire numbers -- those are sentences, not table entries.
--]]
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local function paragraph(text)
    imgui.PushTextWrapPos(0.0);
    imgui.TextDisabled(text);
    imgui.PopTextWrapPos();
end

local function paragraphColored(color, text)
    imgui.PushTextWrapPos(0.0);
    imgui.TextColored(color, text);
    imgui.PopTextWrapPos();
end

--[[
* WHAT A PANEL SAYS WHILE ITS READ IS STILL OUT -- and what it says instead
* once the server has ANSWERED that read by refusing it.
*
* Every storefront opened on "Waiting for the Outfitter..." and stayed there
* for the rest of the session whatever happened, because the only thing that
* clears the line is the answer's own `z|`. A read the server refused (a shelf
* that is not stocked on this build, a coin vault that did not answer) never
* gets one -- so the panel promised an answer that was never coming while the
* header line above it carried the server's actual sentence.
*
* Three states, and the two that are not "still waiting" are told apart: a
* REFUSAL points at the header, where the server's own sentence is already
* drawn, and a SILENCE says so on its own -- pointing at a header line that
* silence never wrote would be this window inventing a diagnosis.
--]]
local function waitingLine(key, waiting)
    local asked = requested[key];

    if (type(asked) == 'table') then
        if (asked.refused) then
            paragraph('The server refused this read -- the line at the top of the window is its answer. Refresh asks again.');

            return;
        end

        if (asked.gaveUp) then
            paragraph('The server did not answer this read. Nothing was re-sent; Refresh asks again.');

            return;
        end
    end

    imgui.TextDisabled(waiting);
end

--[[
* A badge, and the sentence it says on hover.
*
* BADGE_TIPS keys on the word the WIRE carried, which is right for the badges
* whose word is a server concept (the period, the kind, the tag). The offer
* handles the Exchange badges -- x1..x4, and the static shelves' own keys --
* are not concepts, they are labels the typed tier takes as arguments, so
* they get an explicit sentence from the caller instead: keying them in
* BADGE_TIPS would mean listing every handle the shelves ever grow.
--]]
local function badge(text, hint)
    imgui.TextColored(theme.colors.badge, string.format('[%s]', text));

    local says = hint or BADGE_TIPS[text];

    if (says ~= nil and imgui.IsItemHovered()) then
        imgui.SetTooltip(says);
    end

    imgui.SameLine();
end

--[[
* A ROW THE DAILY COMPLETION CAP IS HOLDING (2026-09-07).
*
* The server finalizes at most a fixed number of contracts per Vana'diel day.
* Past that, a filled contract is NOT paid: it stays `active` with its
* progress at or over what it needed, and settles on the first read after the
* day turns. So this shape -- active, and full -- is not "nearly done", it is
* DONE AND UNPAID, and it is the one state on this window that a bar alone
* describes wrongly.
*
* DERIVED FROM THE RECORD, NEVER FROM THE CAP. `doneToday >= doneMax` would
* be the window guessing at the server's own budget from two counters that
* were true when the header was built; the row's own two numbers are the
* server's answer about THIS row, and they are what the server settles on.
* `needed > 0` guards the degenerate record -- a truncated a| whose needed
* field arrived as nothing is not a completed contract.
--]]
local function heldByCap(row)
    return row ~= nil and row.state == 'active'
        and row.needed ~= nil and row.needed > 0
        and row.progress ~= nil and row.progress >= row.needed;
end

-- What a held row says instead of a countdown and instead of Abandon. The
-- number is the server's `doneMax` when it sent one; the literal 8 is the
-- rule as it shipped, and it is only ever reached on a server too old to
-- have said anything -- which is exactly the server whose rule it was.
local function heldWords()
    return string.format('pays when the next game day begins (%d completions a day)',
        state.doneMax or 8);
end

local function progressRow(row)
    -- BOTH NUMBERS ARE FIXED BY THE RECORD, so the fraction and the overlay
    -- are worked out once and kept on it rather than rebuilt for every bar on
    -- every frame. A record is replaced wholesale by its own answer, so a
    -- fresh one recomputes and there is nothing to invalidate (the objective
    -- sentence's rule, on the number beside it).
    if (row.barText == nil) then
        local fraction = 0;

        if (row.needed > 0) then
            fraction = row.progress / row.needed;

            if (fraction < 0) then fraction = 0; end
            if (fraction > 1) then fraction = 1; end
        end

        row.fraction = fraction;
        row.barText  = string.format('%d / %d', row.progress, row.needed);
    end

    imgui.ProgressBar(row.fraction, { -1, 16 }, row.barText);

    if (imgui.IsItemHovered()) then
        if (heldByCap(row)) then
            -- A full-but-active row has NOT been paid, and the old sentence
            -- said it had. Two different states drew the same tooltip the
            -- day the completion cap shipped.
            imgui.SetTooltip('Complete, and waiting on the day. ' .. heldWords()
                .. ' -- it settles the moment the next one begins.');
        elseif (row.needed > 0 and row.progress >= row.needed) then
            imgui.SetTooltip('Complete. The payout arrived as a notice the moment the last kill was credited.');
        else
            imgui.SetTooltip(string.format('%d of %d. Every credited kill moves this bar and toasts in the window (or narrates in chat when it is shut).', row.progress, row.needed));
        end
    end
end

-- One card: the badge line, the bar, then reward, countdown and the one
-- button the card's state allows. Everything on it came off the wire.
--
-- `note` replaces the Accept button when the offer cannot be accepted from
-- here -- the slot lock, or a board being viewed from outside its band. The
-- sentence is decided by the caller off the o| state; the card only ever
-- draws one of {Accept, Abandon, note}.
--[[
* `card` is the RECORD the card is drawn from -- an o| offer or an a| contract
* -- rather than the seven scalars this used to take. Every fixed string on a
* card (the period word, the objective sentence, the reward, the button label
* with its ImGui id) is composed once on the record and read here, because the
* board draws up to fourteen of these EVERY FRAME and every one of them was
* re-formatting four strings the answer had already settled.
*
* `signed` is the a| record whose counter this card shows -- the same table as
* `card` for a grace-period contract, a different one for a signed offer, and
* nil for an unsigned one.
*
* `tracked` says WHICH TAB IS DRAWING THIS CARD (1.25.0), and it decides one
* thing only: who owns the Abandon button. The Accepted tab is the tracked
* list, so it draws the control that can destroy progress; the Board draws
* the same card with the same counter and the word `signed` in its place,
* because "which of today's offers do I already hold" is a question about the
* board and "tear this one up" is not. One button, one place -- two Abandons
* for one contract is two ways to lose the same progress.
--]]
local function contractCard(card, signed, note, tracked)
    local held = heldByCap(signed);

    badge(card.periodWord);
    badge(KIND_BADGE[card.kind] or tostring(card.kind));

    -- The expansion tag, WHEN THE SERVER SENT ONE. Never derived from the slot
    -- handle: which slots are gated is the server's decision and a window that
    -- guessed would be wrong the day the gating moves (dwu_protocol.md's rule
    -- about never inventing what the wire did not say).
    if (card.tag ~= nil) then
        badge(card.tag);
    end

    imgui.Text(card.objective);

    if (signed ~= nil) then
        progressRow(signed);
    else
        imgui.ProgressBar(0, { -1, 16 }, 'Not signed');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Not signed. Accept it and the count starts from your next credited kill.');
        end
    end

    imgui.TextDisabled(card.rewardText);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Drift Coins paid into your account\'s wallet when the contract completes -- spend them on the Enchanter, Outfitter, Jeweler and Pop-Items tabs.');
    end

    if (signed ~= nil) then
        imgui.SameLine();

        if (signed.state == 'done') then
            imgui.TextColored(theme.colors.ok, 'paid');
        elseif (held) then
            -- COMPLETE, AND UNPAID. The countdown that would sit here is the
            -- contract's expiry, and an expiry is the wrong clock for a row
            -- that has already been filled: what a player wants to know is
            -- when it PAYS, and the sentence below the bar says so.
            imgui.TextColored(theme.colors.ok, 'complete');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Filled. ' .. heldWords()
                    .. ' -- the server settles it on the first read after the day turns, online or not.');
            end
        else
            local left = ticked(signed.secsLeft, signed.at, state.now);

            if (left ~= nil and left <= 0) then
                imgui.TextDisabled('expired');
            else
                imgui.TextDisabled(string.format('%s left', fmtClock(left)));
            end
        end
    end

    imgui.SameLine();

    if (writePending ~= nil
            and (writePending.what == 'accept' or writePending.what == 'abandon')) then
        -- Only a BOARD write locks the cards: an augment or confirm in
        -- flight on the Exchange tab has nothing to do with these buttons,
        -- and labelled every card "Signing..." while it ran.
        imgui.TextDisabled(string.format('%s...',
            writePending.what == 'abandon' and 'Tearing up' or 'Signing'));
    elseif (signed == nil) then
        if (note ~= nil) then
            imgui.TextDisabled(note);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Why this card has no Accept button -- the slot is spent for this period, or you are looking at another band\'s board.');
            end
        else
            local clicked = imgui.SmallButton(card.acceptBtn);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Signs this contract into your account\'s slot for the period. Same as typing !drift accept.');
            end

            if (clicked) then
                return 'accept';
            end
        end
    elseif (signed.state == 'done') then
        imgui.TextDisabled('done');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Paid. A fresh offer takes this slot when the period turns.');
        end
    elseif (held) then
        -- NO ABANDON ON A HELD ROW, and not because it would look wrong: the
        -- server REFUSES to abandon a filled contract, so the button could
        -- only ever answer with a refusal -- and it would be inviting a
        -- player to throw away a payout that is already earned.
        imgui.TextDisabled(heldWords());

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('This contract is finished and waiting on the day\'s completion budget.\n'
                .. 'It cannot be abandoned -- the payout is already yours; the day is what is left.');
        end
    elseif (not tracked) then
        -- THE BOARD'S SIGNED CUE (1.25.0). The counter above already says
        -- how far along it is; this says the slot is spent by YOU and points
        -- at the tab that carries the rest.
        imgui.TextDisabled('signed');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('You hold this contract. The Accepted tab carries its clock and its Abandon button.');
        end
    else
        local clicked = imgui.SmallButton(card.abandonBtn);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Tears the contract up: the progress is lost and the slot stays spent until the period turns.');
        end

        if (clicked) then
            return 'abandon';
        end
    end

    imgui.Separator();

    return nil;
end

--[[
* The band row: arrows either side of "Band N (Lv lo-hi)", near the top so
* every band's board is readable without changing jobs. The label names the
* board actually on screen (the y| the server answered with); the arrows only
* ever ask. Rendered once the first board has landed -- an arrow before the
* server has said which band you are would be paging through a guess.
--]]
local function bandNavRow()
    local shown = state.band;

    if (shown == nil) then
        return;
    end

    local prev = imgui.SmallButton('<##dwquest_bandprev');

    tip(TIPS.bandPrev);

    if (prev) then
        stepBand(-1);
    end

    imgui.SameLine();

    local lo, hi = bandRange(shown);

    imgui.Text(string.format('Band %d (Lv %d-%d)', shown, lo, hi));
    tip(TIPS.bandLabel);
    imgui.SameLine();

    -- The words after the label are the only thing on this row that says
    -- whether the board can be SIGNED from here, so each explains itself:
    -- "loading..." is an answer still in flight for a band the arrows asked
    -- for, and the rest are the yes, the other yes and the no. Since 1.26.0
    -- there are TWO yeses -- a lower band reads as signable and says so, which
    -- is the whole point of the change and would be invisible if it wore the
    -- old "yours is band N" the refusal used to mean.
    if (state.viewBand ~= nil and state.viewBand ~= shown) then
        imgui.TextDisabled('loading...');
        tip(TIPS.bandLoading);
    elseif (state.playerBand ~= nil and shown > state.playerBand) then
        imgui.TextDisabled(string.format('-- above yours (band %d); a look only', state.playerBand));
        tip(TIPS.otherBand);
    elseif (state.playerBand ~= nil and shown < state.playerBand) then
        imgui.TextDisabled(string.format('-- below yours (band %d); you can sign these', state.playerBand));
        tip(TIPS.lowerBand);
    else
        imgui.TextDisabled('-- your jobs');
        tip(TIPS.yourBand);
    end

    imgui.SameLine();

    local next_ = imgui.SmallButton('>##dwquest_bandnext');

    tip(TIPS.bandNext);

    if (next_) then
        stepBand(1);
    end

    imgui.Separator();
end

--[[
* THE TWO EIGHTS, ONE LINE, ON BOTH TABS (1.25.0).
*
* Drawn only when the server sent all four counters -- an older server draws
* nothing here at all, because a cap this window invented is a cap the server
* never agreed to and every number in it would be a guess.
*
* The sentence itself was composed when the `y|` landed (see the header
* handler): these numbers move exactly once per answer, and two panels
* rebuilding the same string sixty times a second is the per-frame cost every
* card on this window was rewritten to stop paying.
--]]
local function capsRow()
    if (state.capsLine == nil) then
        return;
    end

    imgui.TextDisabled(state.capsLine);
    tip(TIPS.caps);
    imgui.Separator();
end

local function boardPanel()
    if (not imgui.BeginChild('##dwquest_board', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    capsRow();
    bandNavRow();

    -- A board ABOVE the player's own band is a look and nothing more: its open
    -- offers carry a sentence instead of an Accept, because the server refuses
    -- a signature above the character's band and a button that can only ever
    -- answer `e|` is worse than no button.
    --
    -- A board AT OR BELOW it is signable from here (1.26.0) -- the click sends
    -- the displayed band and the contract is written for this board. The test
    -- is `>` and not `~=` for exactly that reason, and it is asked of the band
    -- the server ANSWERED with, so a board still in flight is judged by the
    -- one on screen.
    local foreign = state.playerBand ~= nil and state.band ~= nil
        and state.band > state.playerBand;

    -- EVERY SLOT IS SPENT WHEN THE ACCOUNT IS FULL, and the card says so
    -- rather than offering an Accept the server will refuse. Off the wire's
    -- own two numbers, never a count of the rows on screen: a board is one
    -- band's worth of offers and the cap is the ACCOUNT's, so counting what
    -- is drawn would be a smaller number than the one being enforced.
    local full = state.acceptedCount ~= nil and state.acceptedMax ~= nil
        and state.acceptedCount >= state.acceptedMax;

    for _, offer in ipairs(state.offers) do
        local signed = state.actives[offer.qkey];
        local note   = nil;

        if (signed == nil) then
            if (offer.state == 'locked') then
                -- The slot lock (o| state `locked`): this slot is spent for
                -- the period by a contract signed at some band, so the server
                -- would refuse the accept this card could invite.
                note = string.format('slot spent -- back at the %s reset',
                    offer.periodWord == 'Weekly' and 'weekly' or 'daily');
            elseif (foreign) then
                local lo, hi = bandRange(state.band);

                note = string.format('for Lv %d-%d jobs', lo, hi);
            elseif (full) then
                note = state.fullNote;
            end
        end

        -- `tracked` is deliberately absent: the Board draws the cue, the
        -- Accepted tab draws the button (see contractCard).
        local click = contractCard(offer, signed, note);

        if (click == 'accept') then
            acceptSlot(offer);
        end
    end

    if (#state.offers == 0) then
        paragraph('No contracts offered. The board is not loaded on this server build.');
    end

    --[[
    * The server-wide contract. Drawn last, with NO BUTTON -- there is no verb
    * to accept it and inventing a button that does nothing is worse than
    * having none. What the card has to answer is "am I getting paid for this",
    * and it answers it with the server's own two numbers rather than a rule of
    * its own.
    --]]
    local community = state.community;

    if (community ~= nil) then
        imgui.Separator();

        badge('server');
        badge(KIND_BADGE.comm);

        imgui.Text(community.objective);

        progressRow(community);

        if (community.state == 'done') then
            if (community.mine >= community.minKills) then
                imgui.TextColored(theme.colors.ok,
                    string.format('Finished. %d DC paid to your account.', community.reward));
            else
                paragraph(string.format(
                    'Finished. Your %d did not reach the %d needed to be paid.',
                    community.mine, community.minKills));
            end
        elseif (community.mine >= community.minKills) then
            paragraphColored(theme.colors.ok, string.format(
                'Your part: %d. You are on the payout -- %d DC when the server finishes it.',
                community.mine, community.reward));
        else
            paragraph(string.format(
                'Your part: %d of %d needed to be paid -- %d DC when the server finishes it.',
                community.mine, community.minKills, community.reward));
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'The community bar. Every player\'s credited kills of the target fill it -- nobody signs it, there is no button.\n' ..
                'When it fills, every account that contributed at least %d kills is paid %d DC, online or not (a receipt waits at your next login).\n' ..
                'Your part is counted from your own kills; the bar is everyone\'s.', community.minKills, community.reward));
        end
    end

    imgui.EndChild();
end

--[[
* THE ACCEPTED PANEL (1.25.0, owner request 2026-09-07).
*
* Everything on this tab was drawn by the Board until today, and NOTHING
* about it changed on the way over. The same one model -- `state.actives`
* keyed on qkey, `state.activeOrder` for the order the server listed them in
* -- the same records, parsed by the same handler, replaced whole by the same
* `z|board`. This is a rendering split: the Board answers "what could I
* sign", this answers "what am I holding", and they had been sharing one
* scrolling panel that grew every time a slot was added.
*
* NO SECTION HEADING PER GROUP, deliberately. The old panel separated a
* grace-period contract under "Still yours, from an earlier board:" because
* it was an interruption in a list of offers; here every row is a contract
* this account holds, and which board it came off is not a difference a
* player is acting on. The card already carries its period, its kind and its
* clock.
*
* THE ORDER IS THE SERVER'S. `activeOrder` is the order the a| records
* arrived in, and a window that sorted them would be inventing a priority --
* and would reshuffle the list under a player's cursor on every ping.
--]]
local function acceptedPanel()
    if (not imgui.BeginChild('##dwquest_accepted', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    capsRow();

    local drawn = 0;

    for _, qkey in ipairs(state.activeOrder) do
        local row = state.actives[qkey];

        if (row ~= nil) then
            drawn = drawn + 1;

            -- `tracked` is true: THIS tab owns the Abandon button.
            local click = contractCard(row, row, nil, true);

            if (click == 'abandon') then
                abandonContract(row);
            end
        end
    end

    if (drawn == 0) then
        -- TOLD APART FROM A BOARD THAT NEVER LANDED. `synced` is what the
        -- tab bar already gated on, so by the time this draws the server HAS
        -- answered -- an empty list here is an account holding nothing, and
        -- saying "waiting..." over it would be a diagnosis of a problem that
        -- does not exist.
        paragraph('No contracts signed. Accept one on the Board tab and it appears here with its counter.');
    end

    imgui.EndChild();
end

--[[
* The Enchanter panel.
*
* Reading order is the order the decisions happen in: what is for sale, who it
* is going on, which item, which slot, then the price and the one button that
* pays. Nothing further down the panel exists until the step above it has been
* answered BY THE SERVER -- there is no step here the window can complete on
* its own.
--]]
-- The fits class in words. ONE function rather than the two divergent inline
-- ternaries this used to be: the Exchange card said 'wielded weapons' and the
-- augment browser said nothing at all for the same class, so a new class had
-- to be remembered in two places to be shown in both. The fallthrough returns
-- the raw class, so an unknown one from a newer server reads as itself instead
-- of vanishing.
local function fitsWords(fits)
    if (fits == 'any') then
        return 'any gear';
    elseif (fits == 'weapon') then
        -- THE SERVER'S OWN WORDS, not a paraphrase: its refusal for this
        -- class is "only goes on a weapon" (quest_core.lua fitsRefusal), and
        -- a card that described the rule differently from the sentence the
        -- refusal uses would be two answers to one question.
        return 'weapons only';
    elseif (fits == 'armor') then
        -- 'armour' with the u, because that is the spelling the refusal
        -- prints. The wire word keeps the American spelling and the pool
        -- column with it; the prose is the server's.
        return 'armour only';
    elseif (fits == 'wield') then
        return 'wielded weapons';
    elseif (fits == 'ring') then
        return 'rings only';
    end

    return tostring(fits);
end

local function offerCard(offer)
    badge(offer.slot, TIPS.offerHandle);
    imgui.Text(offer.label);

    -- The price is the server's, rendered. So is `fits`: the window does not
    -- know what `weapon` means for an offer, and the list it asks for is
    -- filtered by the server against that same column. A Weapon Burst row
    -- carries a second currency, and the card states BOTH -- understating a
    -- burst offer's cost is the reason the shelf has its own record kind.
    imgui.TextDisabled(offer.costText);
    tip(TIPS.price);

    -- BRACKETED, because the price and the fit are SameLine'd and read as one
    -- sentence otherwise. `5000 Burst Tokens + 1000 DC` beside `rings only`
    -- came back from the owner quoted as "5000 Burst Tokens + 1000 DC rings
    -- only" -- a price in a currency called "DC rings" (2026-09-06). The
    -- brackets cost nothing and end the ambiguity; the augment browser's own
    -- line (`rank 3, 40 DC, weapons only`) was already comma-separated and is
    -- left alone.
    imgui.SameLine();
    imgui.TextDisabled(string.format('(%s)', fitsWords(offer.fits)));
    tip(TIPS.fits);
    imgui.SameLine();

    if (writePending ~= nil) then
        imgui.TextDisabled('busy...');
        tip(TIPS.busy);

        return false;
    end

    if (shop.picked == offer.slot) then
        imgui.TextColored(theme.colors.ok, 'chosen');
        tip(TIPS.chosen);

        return false;
    end

    local chose = imgui.SmallButton(offer.chooseBtn);

    tip(TIPS.choose);

    return chose;
end

local function characterRow()
    local label = shop.who ~= '' and shop.who or 'You';

    imgui.TextDisabled('On:');
    imgui.SameLine();
    imgui.PushItemWidth(160);

    local whoOpen = imgui.BeginCombo('##dwquest_who', label);

    -- Right after BeginCombo and outside the `if`: ImGui submits the combo as
    -- an item inside the call, so IsItemHovered reads the COMBO there whether
    -- it opened or not, and the first widget the popup draws would take the
    -- "last item" away (dwtoau's picker, same shape).
    tip(TIPS.who);

    if (whoOpen) then
        if (imgui.Selectable('You##dwquest_who_self', shop.who == '')) then
            chooseCharacter('');
        end

        for _, member in ipairs(shop.roster) do
            -- `self` is reached by leaving the name off and `online` is a
            -- refusal the server would make, so only offline alts are
            -- selectable -- and the others are still SHOWN, greyed, with the
            -- reason, because "my alt is missing from the list" is a worse
            -- question than "my alt is logged in".
            if (member.state == 'offline') then
                if (imgui.Selectable(string.format('%s##dwquest_who_%s', member.name, member.name),
                        shop.who == member.name)) then
                    chooseCharacter(member.name);
                end
            elseif (member.state == 'online') then
                imgui.TextDisabled(string.format('%s (logged in)', member.name));
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
    imgui.SameLine();
    imgui.PushItemWidth(160);

    -- EnterReturnsTrue, so this fires on Enter and not on each character --
    -- the commit, and the only place the live buffer is read.
    local entered = imgui.InputText('##dwquest_filter', shop.filter, 64,
        ImGuiInputTextFlags_EnterReturnsTrue);

    tip(TIPS.filter);

    if (entered) then
        shop.filterApplied = safeFilter(shop.filter[1]);
        invalidateGear();
    end

    imgui.PopItemWidth();
    imgui.SameLine();

    local searched = imgui.SmallButton('Search##dwquest_gearsearch');

    tip(TIPS.search);

    if (searched) then
        shop.filterApplied = safeFilter(shop.filter[1]);
        invalidateGear();
    end
end

local function slotView()
    local item = shop.item;

    if (item == nil) then
        return;
    end

    -- THE ICON AND THE CLIENT'S OWN HOVER CARD (2026-09-06). This is the
    -- screen a player is about to spend coins against, sometimes on an
    -- offline alt's gear they cannot otherwise look at, and it named the
    -- piece in words and nothing else -- while every storefront one tab over
    -- drew the card off the same kind of id.
    drawIcon(item.itemid, 20);

    if (imgui.IsItemHovered()) then
        itemTooltip(item.card);
    end

    imgui.Text(item.title);

    if (imgui.IsItemHovered()) then
        itemTooltip(item.card);
    end

    -- USED AND FREE COME OFF k| (client discipline 7 and the owner's brief
    -- #8). The window does not count the s| records -- they are only emitted
    -- for occupied slots, so counting them would be the window deriving a
    -- number the player is about to consent against.
    imgui.TextDisabled(item.slotsUsed);
    tip(TIPS.usedSlots);

    local landing = shop.quote ~= nil and shop.quote.landing or 0;
    local full    = item.free == 0;

    for index = 1, item.maxslots do
        local slot = shop.slots[index];

        -- Decoded through the catalog ("Dbl.Atk.+3%  [143]"), because "which
        -- augment do I give up" is the question this view exists to answer
        -- and raw ids cannot. Falls back to the raw pair when the catalog is
        -- missing or the id is not in it.
        if (index == landing) then
            imgui.TextColored(theme.colors.hint, string.format('  slot %d: %s', index,
                slot ~= nil and (slot.text .. ' -- REPLACED') or 'empty -- lands here'));
        elseif (slot ~= nil) then
            imgui.Text(string.format('  slot %d: %s', index, slot.text));
        else
            imgui.TextDisabled(string.format('  slot %d: empty', index));
        end

        -- A full item can only take a purchase by giving something up, and the
        -- server refuses to guess which. One button per occupied slot, and the
        -- click is a fresh quote naming that slot -- never a confirm.
        if (full and slot ~= nil and shop.quote == nil and writePending == nil) then
            imgui.SameLine();

            local replacing = imgui.SmallButton(string.format('Replace##dwquest_replace_%d', index));

            tip(TIPS.replace);

            if (replacing) then
                return index;
            end
        end
    end

    return nil;
end

local function quoteRow()
    local quote = shop.quote;

    if (quote == nil) then
        return;
    end

    -- THE PRICE IS THE QUOTE'S. Not the offer card's, not a lookup by handle,
    -- not anything this file could have got wrong: the record the player is
    -- consenting to is the record the purchase is settled against. A Weapon
    -- Burst quote carries a second currency in the same record (p| part 8).
    if (quote.btPrice ~= nil and quote.btPrice > 0) then
        imgui.TextColored(theme.colors.ok, string.format('%s -- %d Burst Tokens + %d DC', quote.label, quote.btPrice, quote.price));
    else
        imgui.TextColored(theme.colors.ok, string.format('%s -- %d DC', quote.label, quote.price));
    end
    paragraph(string.format('Lands in slot %d. Once augmented it is bound to your account: no auction house, no trade, no bazaar.',
        quote.landing));
    tip(TIPS.landing);

    if (writePending ~= nil) then
        imgui.TextDisabled(string.format('%s...',
            writePending.what == 'confirm' and 'Buying' or 'Pricing'));
        tip(TIPS.busy);

        return false;
    end

    -- THE BUTTON DOES NOT EXIST WITHOUT AN ARMED QUOTE. `armed` is set only by
    -- a p| record and cleared by the click itself, so there is no frame in
    -- which a second Confirm is drawable for one quote.
    if (not quote.armed) then
        imgui.TextDisabled('Sent.');

        return false;
    end

    local confirmed = imgui.SmallButton('Confirm##dwquest_confirm');

    tip(TIPS.confirm);

    if (confirmed) then
        return true;
    end

    imgui.SameLine();

    local cancelled = imgui.SmallButton('Cancel##dwquest_cancel');

    tip(TIPS.cancel);

    if (cancelled) then
        -- Local only. The server's quote ages out on its own (p| says how
        -- long); there is no verb for "never mind" and inventing one would be
        -- a line the typed tier does not have.
        shop.quote = nil;
        shop.item  = nil;
        shop.slots = { };
    end

    return false;
end

local function gearList()
    if (not shop.gearSynced) then
        imgui.TextDisabled('Looking through the bags...');

        return;
    end

    if (#shop.gear == 0) then
        -- A committed search filter is invisible once the box is cleared,
        -- and an old term reads exactly like 'no valid targets' (the
        -- 2026-08-25 'snoll' hunt) -- so an empty list NAMES it.
        if (shop.filterApplied ~= nil and shop.filterApplied ~= '') then
            paragraph(string.format('Nothing matches the search "%s". Clear it with Search on an empty box.', shop.filterApplied));

            return;
        end

        paragraph('Nothing here can take that augment. Equipment only, not equipped, not enchanted, not priced in a bazaar.');

        return;
    end

    for _, row in ipairs(shop.gear) do
        -- THE ICON AND THE CLIENT'S OWN HOVER CARD (2026-09-06). Every other
        -- shelf in this window draws them and this list -- the one where the
        -- player is choosing WHICH of several similar pieces to spend coins
        -- on, sometimes out of an alt's bag they cannot open -- had neither.
        -- The c| record carries the id, which is all the card needs.
        drawIcon(row.itemid, 20);

        if (imgui.IsItemHovered()) then
            itemTooltip(row.card);
        end

        imgui.Text(row.title);

        if (imgui.IsItemHovered()) then
            itemTooltip(row.card);
        end

        imgui.SameLine();
        imgui.TextDisabled(row.usedText);
        tip(TIPS.usedSlots);
        imgui.SameLine();

        if (writePending ~= nil) then
            imgui.TextDisabled('busy...');
            tip(TIPS.busy);
        elseif (row.free > 0) then
            local picking = imgui.SmallButton(row.pick);

            tip(TIPS.pick);

            if (picking) then
                quoteItem(row, nil);
            end
        else
            local seeing = imgui.SmallButton(row.slotsBtn);

            tip(TIPS.slotsBtn);

            if (seeing) then
                -- Full: there is nothing to quote until the player says what
                -- to give up, so this asks to SEE the slots rather than to
                -- price one.
                inspectItem(row);
            end
        end
    end

    -- A CAP THAT DOES NOT SAY SO READS AS AN INVENTORY. Both numbers are the
    -- server's; the window compares them and says which one it drew.
    if (shop.gearShown < shop.gearTotal) then
        paragraph(string.format('Showing %d of %d. Type part of a name to narrow it.',
            shop.gearShown, shop.gearTotal));
        tip(TIPS.truncated);
    end
end

local function exchangePanel()
    if (not imgui.BeginChild('##dwquest_exchange', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not shop.synced) then
        waitingLine('augments', 'Waiting for the Exchange...');
        imgui.EndChild();

        return;
    end

    if (shop.clockAt ~= nil) then
        imgui.TextDisabled(string.format('New offers in %s',
            fmtClock(ticked(shop.secsToRoll, shop.clockAt, state.now))));
        tip(TIPS.shopClock);
    end

    if (#shop.offers == 0) then
        paragraph('The Exchange has nothing today. The offer pool is not loaded on this server build.');
        imgui.EndChild();

        return;
    end

    imgui.Separator();

    for _, offer in ipairs(shop.offers) do
        if (offerCard(offer)) then
            chooseOffer(offer);
        end
    end

    -- The Weapon Burst shelf (2026-08-25): always available, never part of
    -- the rotation above, priced in the arena's currency AND coins. Rendered
    -- as it arrived, the same contract as everything else in this window.
    if (#shop.burst > 0) then
        imgui.Separator();
        paragraph('Weapon Burst -- always available. The arena pays the tokens: floor cleared = tokens earned.');
        tip(TIPS.burstShelf);

        for _, offer in ipairs(shop.burst) do
            if (offerCard(offer)) then
                chooseOffer(offer);
            end
        end
    end

    imgui.Separator();

    if (shop.picked == nil) then
        paragraph('Choose an augment above, then pick the gear it goes on.');
        imgui.EndChild();

        return;
    end

    characterRow();
    imgui.Separator();

    if (shop.item == nil) then
        gearList();
    else
        local replace = slotView();

        if (replace ~= nil) then
            -- A replace click is a NEW QUOTE naming the slot, which is the
            -- only way the price and the landing slot the player consents to
            -- can both be the server's.
            quoteItem({ itemid = shop.item.itemid, name = shop.item.name }, replace);
        end

        imgui.Separator();

        if (quoteRow()) then
            confirmPurchase();
        end

        if (shop.quote == nil and writePending == nil) then
            local backed = imgui.SmallButton('Back to the list##dwquest_back');

            tip(TIPS.back);

            if (backed) then
                shop.item  = nil;
                shop.slots = { };
            end
        end
    end

    imgui.EndChild();
end

-- The storefront rolled while the tab was open: the four offers on screen
-- belong to the Vana'diel day that just ended, and a quote taken against them
-- is refused (dwu_protocol.md, `v|`). Asked ONCE per header -- v| clears it.
local function checkShopRotation(now)
    if (shop.rollAsked or not shop.synced or shop.clockAt == nil) then
        return;
    end

    local left = ticked(shop.secsToRoll, shop.clockAt, now);

    if (left ~= nil and left <= 0) then
        shop.rollAsked = true;
        shop.synced    = false;
        shop.picked    = nil;
        shop.item      = nil;
        shop.slots     = { };
        shop.quote     = nil;

        --[[
        * AND THE ROTATING OFFERS THEMSELVES (2026-09-06). The Exchange panel
        * is gated on `synced` and stopped drawing its cards here, but the
        * Augments reference tab is not: it marks its rows [today] off
        * `shop.byAugid` and hangs a Choose on every marked row, so after a
        * roll it went on advertising the ended period's four augments and
        * would hand the Exchange a picked handle off a shelf the server had
        * already replaced. The static Weapon Burst and X-Magic shelves are
        * deliberately NOT cleared -- they never rotate, and blanking them
        * would make the reference tab flicker once a Vana'diel day for no
        * reason.
        --]]
        shop.offers  = { };
        shop.byAugid = { };

        invalidateGear();

        requested['augments'] = nil;
    end
end

--[[
* The Outfitter tab (Phase 7). Static stock: no rotation clock, no re-ask on
* a roll -- the only reads are the directory-plus-rows fetch for the selected
* job, through the same ask-once-retry-once tracker as every other read.
--]]
local function outfitterPanel()
    if (not imgui.BeginChild('##dwquest_outfit', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not outfit.synced) then
        waitingLine('shelf', 'Waiting for the Outfitter...');
        imgui.EndChild();

        return;
    end

    if (#outfit.jobs == 0) then
        imgui.TextDisabled('The Outfitter is not stocked on this server build.');
        imgui.EndChild();

        return;
    end

    -- No price in this line ON PURPOSE: the shelf carries two tiers now
    -- (AF and relic) and each row states its own price off the wire -- a
    -- single number here would be a second source of truth for MONEY.
    paragraph('Artifact and AF+1, relic and Empyrean +2 sets, the job capes (lv1/40/75/99), and the lv27-33 race gear.\nAF, AF+1, relic, Empyrean and capes are Rare/Ex (account-bound); the race gear is plain and tradeable.');

    -- The job picker: the directory the server sent, never a local list. The
    -- selection change invalidates the rows (needOutfit re-arms the read).
    local current = nil;

    for _, job in ipairs(outfit.jobs) do
        if (job.word == outfit.job) then
            current = job;
        end
    end

    imgui.SetNextItemWidth(180);

    local jobOpen = imgui.BeginCombo('##dwquest_outfit_job',
        current ~= nil and current.label or 'Pick a job...');

    tip(TIPS.jobPick);

    if (jobOpen) then
        for _, job in ipairs(outfit.jobs) do
            if (imgui.Selectable(string.format('%s##dwquest_outfit_job_%s', job.label, job.word),
                    outfit.job == job.word)) then
                if (outfit.job ~= job.word) then
                    outfit.job  = job.word;
                    outfit.rows = { };
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.Separator();

    if (outfit.job == nil) then
        imgui.TextDisabled('Pick a job to see its shelf.');
        imgui.EndChild();

        return;
    end

    if (#outfit.rows == 0) then
        imgui.TextDisabled('Fetching the shelf...');
        imgui.EndChild();

        return;
    end

    for _, row in ipairs(outfit.rows) do
        -- The icon, then the label -- and the hover card on either (the
        -- dwraid row shape: drawIcon leaves the cursor on the same line, and
        -- IsItemHovered reads the LAST item, so both get their own check).
        drawIcon(row.itemid, 20);

        if (imgui.IsItemHovered()) then
            itemTooltip(row);
        end

        imgui.Text(row.label);

        if (imgui.IsItemHovered()) then
            itemTooltip(row);
        end

        imgui.SameLine();
        imgui.TextDisabled(row.detail);
        imgui.SameLine();
        imgui.TextColored(theme.colors.ok, row.cost);
        tip(TIPS.price);
        imgui.SameLine();

        if (writePending ~= nil) then
            imgui.TextDisabled('busy...');
            tip(TIPS.busy);
        elseif (outfit.quote == nil) then
            -- A buy is a QUOTE (the t| that answers is the only thing that
            -- can arm Confirm), but it is queued as a WRITE: never collapsed,
            -- never re-sent, and the buttons wait while it is in flight.
            local buying = imgui.SmallButton(row.buy);

            tip(TIPS.buy);

            if (buying) then
                beginWrite('buy', row.label, string.format('!dwu buy %d', row.index));
            end
        else
            -- The Buy is gone because a quote is armed somewhere, and a
            -- control that simply vanishes explains nothing. Something to
            -- hover, with the rule on it.
            imgui.TextDisabled('quoted');
            tip(TIPS.quoteGone);
        end
    end

    -- The armed quote, and the ONLY place Confirm exists. The click disarms
    -- it in the same statement that queues the line (the Exchange's rule,
    -- money behind it): one t| confirms at most once.
    if (outfit.quote ~= nil) then
        imgui.Separator();

        local left = ticked(outfit.quote.holds, outfit.quote.at, state.now);

        if (left ~= nil and left <= 0) then
            outfit.quote = nil;
        else
            imgui.TextColored(theme.colors.hint, string.format('%s -- %d DC   (%ds to confirm)',
                outfit.quote.label, outfit.quote.price, left or 0));
            tip(TIPS.hold);

            if (writePending ~= nil) then
                imgui.TextDisabled('buying...');
                tip(TIPS.busy);
            else
                local confirmed = imgui.SmallButton('Confirm##dwquest_outfit_confirm');

                tip(TIPS.confirm);

                if (confirmed) then
                    local line = '!dwu confirm';

                    outfit.quote = nil;
                    beginWrite('confirm', line, line);
                end

                imgui.SameLine();

                local cancelled = imgui.SmallButton('Cancel##dwquest_outfit_cancel');

                tip(TIPS.cancel);

                if (cancelled) then
                    -- Local teardown only: the server's quote ages out on its
                    -- own clock, and nothing un-asks a price.
                    outfit.quote = nil;
                end
            end
        end
    end

    imgui.EndChild();
end

--[[
* The Outfitter's read, issued only while its tab is on screen. The request
* names the selected job (rows travel per job); a selection change re-arms
* the tracker the way the gear list's signature does.
--]]
local function needOutfit(now)
    local wanted = '!dwu shelf';

    if (outfit.job ~= nil) then
        wanted = string.format('!dwu shelf %s', outfit.job);
    end

    if (outfit.rowsFor ~= wanted) then
        outfit.rowsFor      = wanted;
        outfit.synced       = false;
        requested['shelf']  = nil;
    end

    askOnce('shelf', wanted, now);
end

--[[
* The ArmsDealer tab (owner request 2026-08-20; the Artifact Weapons case
* added 2026-08-21). The Outfitter's panel one storefront over: a category
* dropdown and that case's weapons under it, each a Buy that quotes and a
* Confirm that spends -- the same ask-once tracker, the same quote-then-confirm
* dance, its own state.
*
* THE CASES ARE PRICED SEPARATELY and this file never says how much anything
* costs: the price on every row and on the quote comes off the wire. The
* dropdown's ORDER is the wire's order too, so which case sits on top is the
* server's decision, not a sort here.
--]]
local function armsdealerPanel()
    if (not imgui.BeginChild('##dwquest_arms', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not arms.synced) then
        waitingLine('arms', 'Waiting for the ArmsDealer...');
        imgui.EndChild();

        return;
    end

    if (#arms.categories == 0) then
        imgui.TextDisabled('The ArmsDealer is not stocked on this server build.');
        imgui.EndChild();

        return;
    end

    -- The selected case, from the directory the server sent -- never a local
    -- list. The selection change invalidates the rows (needArms re-arms the
    -- read).
    local current = nil;

    for _, cat in ipairs(arms.categories) do
        if (cat.key == arms.category) then
            current = cat;
        end
    end

    -- The header names the SELECTED case and takes its price off the rows the
    -- server sent, never a constant of this file's own: the cases are priced an
    -- order of magnitude apart (25 DC vs 250 DC vs 1000 DC) and a hardcoded
    -- number here would be a second source of truth for MONEY. The server
    -- carries the resolved price onto the quote and spends exactly that, so a
    -- window that disagreed would be charged, not refused.
    --
    -- A CASE IS NOT ALWAYS UNIFORM (2026-09-06): the server may price a single
    -- row apart from its case (the Empyrean Daurdabla and Ochain at 1500 in a
    -- 1000-DC case), so reading row 1 and saying "each" was a sentence that
    -- would be wrong for two rows on screen. The band is taken across the rows
    -- actually sent, and "each" is only said when they agree.
    if (current ~= nil and #arms.rows > 0) then
        local low  = arms.rows[1].price;
        local high = arms.rows[1].price;

        for _, row in ipairs(arms.rows) do
            if (row.price < low) then
                low = row.price;
            end

            if (row.price > high) then
                high = row.price;
            end
        end

        local priced = (low == high)
            and string.format('%d DC each', low)
            or string.format('%d-%d DC', low, high);

        paragraph(string.format('%s -- %d pieces, %s. Rare/Ex: yours, and your account\'s.',
            current.label, #arms.rows, priced));
        tip(TIPS.armsCase);
    else
        paragraph('Weapons for Drift Coins. Rare/Ex: yours, and your account\'s.');
        tip(TIPS.armsCase);
    end

    imgui.SetNextItemWidth(180);

    local caseOpen = imgui.BeginCombo('##dwquest_arms_cat',
        current ~= nil and current.label or 'Pick a case...');

    tip(TIPS.casePick);

    if (caseOpen) then
        for _, cat in ipairs(arms.categories) do
            if (imgui.Selectable(string.format('%s##dwquest_arms_cat_%s', cat.label, cat.key),
                    arms.category == cat.key)) then
                if (arms.category ~= cat.key) then
                    arms.category = cat.key;
                    arms.rows     = { };
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.Separator();

    if (arms.category == nil) then
        imgui.TextDisabled('Pick a case to see its weapons.');
        imgui.EndChild();

        return;
    end

    if (#arms.rows == 0) then
        imgui.TextDisabled('Fetching the case...');
        imgui.EndChild();

        return;
    end

    for _, row in ipairs(arms.rows) do
        -- The icon, then the label -- and the hover card on either (the
        -- Outfitter's row shape: drawIcon leaves the cursor on the same line,
        -- and IsItemHovered reads the LAST item, so both get their own check).
        drawIcon(row.itemid, 20);

        if (imgui.IsItemHovered()) then
            itemTooltip(row);
        end

        imgui.Text(row.label);

        if (imgui.IsItemHovered()) then
            itemTooltip(row);
        end

        imgui.SameLine();
        imgui.TextDisabled(row.detail);
        imgui.SameLine();
        imgui.TextColored(theme.colors.ok, row.cost);
        tip(TIPS.price);
        imgui.SameLine();

        if (writePending ~= nil) then
            imgui.TextDisabled('busy...');
            tip(TIPS.busy);
        elseif (arms.quote == nil) then
            -- A buy is a QUOTE (the t| that answers is the only thing that can
            -- arm Confirm), queued as a WRITE: never collapsed, never re-sent,
            -- and the buttons wait while it is in flight.
            local buying = imgui.SmallButton(row.buy);

            tip(TIPS.buy);

            if (buying) then
                beginWrite('armsbuy', row.label, string.format('!dwu armsbuy %d', row.index));
            end
        else
            imgui.TextDisabled('quoted');
            tip(TIPS.quoteGone);
        end
    end

    -- The armed quote, and the ONLY place Confirm exists for this tab.
    if (arms.quote ~= nil) then
        imgui.Separator();

        local left = ticked(arms.quote.holds, arms.quote.at, state.now);

        if (left ~= nil and left <= 0) then
            arms.quote = nil;
        else
            imgui.TextColored(theme.colors.hint, string.format('%s -- %d DC   (%ds to confirm)',
                arms.quote.label, arms.quote.price, left or 0));
            tip(TIPS.hold);

            if (writePending ~= nil) then
                imgui.TextDisabled('buying...');
                tip(TIPS.busy);
            else
                local confirmed = imgui.SmallButton('Confirm##dwquest_arms_confirm');

                tip(TIPS.confirm);

                if (confirmed) then
                    local line = '!dwu confirm';

                    arms.quote = nil;
                    beginWrite('confirm', line, line);
                end

                imgui.SameLine();

                local cancelled = imgui.SmallButton('Cancel##dwquest_arms_cancel');

                tip(TIPS.cancel);

                if (cancelled) then
                    -- Local teardown only: the server's quote ages out on its
                    -- own clock, and nothing un-asks a price.
                    arms.quote = nil;
                end
            end
        end
    end

    imgui.EndChild();
end

--[[
* The ArmsDealer's read, issued only while its tab is on screen. The request
* names the selected category (rows travel per category); a selection change
* re-arms the tracker the way the Outfitter's does.
--]]
local function needArms(now)
    local wanted = '!dwu arms';

    if (arms.category ~= nil) then
        wanted = string.format('!dwu arms %s', arms.category);
    end

    if (arms.rowsFor ~= wanted) then
        arms.rowsFor      = wanted;
        arms.synced       = false;
        requested['arms'] = nil;
    end

    askOnce('arms', wanted, now);
end

--[[
* The client's own name for an item id (the dwbags/dwraid shape). The other
* storefronts never need this -- their labels ride the wire -- but the pop
* rows carry only ids, and the ids are the point: names resolve from the DATs
* the player is actually running.
*
* CACHED (2026-09-06), for iconOf's reason one line up. This was a call into
* the resource manager PER ROW PER FRAME -- twice per row on the sky pairs,
* which carry two ids -- on a shelf of twenty-odd rows redrawn sixty times a
* second. An item's name cannot change while the client is up, so the cache
* never needs invalidating, and it is bounded by the number of ids one shelf
* names.
--]]
local popNames = { };

local function popItemName(itemId)
    local id     = itemId or 0;
    local cached = popNames[id];

    if (cached ~= nil) then
        return cached;
    end

    local item = AshitaCore:GetResourceManager():GetItemById(id);
    local name = string.format('item %d', id);

    if (item ~= nil and item.Name ~= nil and item.Name[1] ~= nil and #item.Name[1] > 0) then
        name = item.Name[1];
    end

    popNames[id] = name;

    return name;
end

--[[
* The Pop-Items tab (owner request 2026-08-30, the Huntboard round). The
* ArmsDealer's dance -- Buy quotes, Confirm settles, one pending purchase
* per character -- with the bag for a purse: every price is Dynamis
* hundred-pieces plus DIFFERENT Job Testimonies, charged from the inventory
* cell by cell, and the h| line under the header shows the same two numbers
* the confirm will read. This file never says what anything costs: every
* number on every row and on the quote comes off the wire.
--]]
--[[
* THE POP-ITEMS FIND BOX (1.23.0).
*
* This is the longest list in the window -- twenty-five keys under five tier
* headers, and the thing a player arrives knowing is the NAME OF THE MONSTER
* they want to pop, not which tier it is filed under. Both reference tabs
* beside it have had a search since they shipped and this shelf had none, so
* finding the Fafnir key meant reading five headings.
*
* ENTIRELY LOCAL. The whole shelf travels on one read, so there is nothing to
* ask the server for: no verb, no latch, no line on the wire. The haystack is
* the words the row already draws -- the NM, its zone, and the item names the
* client's own DATs answered with -- so what a player can see is what they
* can search.
*
* THE VIEW IS CACHED against the search and the shelf's own revision, rather
* than filtered every frame: a list re-derived sixty times a second for an
* answer that changes when somebody types is the shape this suite keeps
* finding (dwwarehouse's lesson, by way of the Augments tab above).
--]]
local popFind = {
    filter  = T{ '' },   -- InputText live buffer; committed on Enter/Find
    applied = '',        -- the committed search, lowercased

    -- The search and the shelf revision the view below answers. Two fields
    -- rather than one formatted key: the comparison runs every frame.
    keySearch = nil,
    keyRev    = nil,

    byTier    = { },
    ungrouped = { },
    shown     = 0,
};

local function popHaystack(row)
    if (row.haystack == nil) then
        row.haystack = string.lower(string.format('%s %s %s %s',
            row.label or '', row.where or '',
            popItemName(row.itemid),
            row.itemid2 ~= 0 and popItemName(row.itemid2) or ''));
    end

    return row.haystack;
end

local function popView()
    -- COMPARED FIELD BY FIELD, not against a formatted key: this runs every
    -- frame the tab is open, and a key built with string.format is an
    -- allocation a frame to discover that nothing changed (gilRateText's
    -- rule, on the cheaper half of the same idea).
    if (popFind.keySearch == popFind.applied and popFind.keyRev == pop.rev) then
        return;
    end

    popFind.keySearch = popFind.applied;
    popFind.keyRev    = pop.rev;
    popFind.byTier    = { };
    popFind.ungrouped = { };
    popFind.shown     = 0;

    local wanted = popFind.applied;

    for tierKey, rows in pairs(pop.byTier) do
        local kept = { };

        for _, row in ipairs(rows) do
            if (wanted == '' or string.find(popHaystack(row), wanted, 1, true) ~= nil) then
                table.insert(kept, row);
                popFind.shown = popFind.shown + 1;
            end
        end

        popFind.byTier[tierKey] = kept;
    end

    for _, row in ipairs(pop.ungrouped) do
        if (wanted == '' or string.find(popHaystack(row), wanted, 1, true) ~= nil) then
            table.insert(popFind.ungrouped, row);
            popFind.shown = popFind.shown + 1;
        end
    end
end

--[[
* ONE POP-ITEMS ROW: the icon(s), the item name(s) the client's own DATs
* answer with, the NM and its zone, and the one button the shelf's state
* allows. Hoisted out of the tier loop so the ungrouped rows below it draw
* exactly the same line rather than a second copy of this one.
*
* The two hover-card tables are built ONCE per row and kept on it: they used
* to be table literals allocated four times per row per frame (twice for the
* pair rows), each carrying a popItemName lookup, for a card the pointer is
* over at most one of.
--]]
local function popRow(row)
    if (row.card1 == nil) then
        row.card1 = { itemid = row.itemid, label = popItemName(row.itemid) };

        if (row.itemid2 ~= 0) then
            row.card2 = { itemid = row.itemid2, label = popItemName(row.itemid2) };
        end
    end

    drawIcon(row.itemid, 20);

    if (imgui.IsItemHovered()) then
        itemTooltip(row.card1);
    end

    imgui.Text(row.card1.label);

    if (imgui.IsItemHovered()) then
        itemTooltip(row.card1);
    end

    if (row.card2 ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled('+');
        imgui.SameLine();

        drawIcon(row.itemid2, 20);

        if (imgui.IsItemHovered()) then
            itemTooltip(row.card2);
        end

        imgui.Text(row.card2.label);

        if (imgui.IsItemHovered()) then
            itemTooltip(row.card2);
        end
    end

    imgui.SameLine();
    imgui.TextDisabled(row.pops);
    tip(TIPS.popWhere);
    imgui.SameLine();

    if (writePending ~= nil) then
        imgui.TextDisabled('busy...');
        tip(TIPS.busy);
    elseif (pop.quote == nil) then
        local buying = imgui.SmallButton(row.buy);

        tip(TIPS.popBuy);

        if (buying) then
            beginWrite('popbuy', row.label, string.format('!dwu popbuy %d', row.index));
        end
    else
        imgui.TextDisabled('quoted');
        tip(TIPS.quoteGone);
    end
end

local function popitemsPanel()
    if (not imgui.BeginChild('##dwquest_pops', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not pop.synced) then
        waitingLine('pops', 'Waiting for the Pop-Items shelf...');
        imgui.EndChild();

        return;
    end

    if (#pop.rows == 0) then
        imgui.TextDisabled('The Pop-Items shelf is not stocked on this server build.');
        imgui.EndChild();

        return;
    end

    paragraph('Forced-spawn keys for Dynamis hundred-pieces + Job Testimonies, from your bag.');
    paragraph('Testimonies must each be a DIFFERENT job\'s. Any mix of the three coin families pays.');

    if (pop.hundreds ~= nil) then
        imgui.TextColored(theme.colors.ok, string.format('Your bag: %d hundred-piece(s), %d testimony type(s).',
            pop.hundreds, pop.types or 0));
        tip(TIPS.popPurse);
        imgui.SameLine();
        imgui.TextDisabled('The warehouse does not pay.');
        tip(TIPS.popPurse);
    end

    -- The find box (1.23.0). Local to this panel: the whole shelf is already
    -- here, so nothing about typing in it reaches the wire.
    imgui.PushItemWidth(180);

    local entered = imgui.InputText('##dwquest_pop_find', popFind.filter, 64,
        ImGuiInputTextFlags_EnterReturnsTrue);

    tip(TIPS.popFind);

    if (entered) then
        popFind.applied = string.lower(popFind.filter[1] or '');
    end

    imgui.PopItemWidth();
    imgui.SameLine();

    local finding = imgui.SmallButton('Find##dwquest_pop_find_go');

    tip(TIPS.popFind);

    if (finding) then
        popFind.applied = string.lower(popFind.filter[1] or '');
    end

    popView();

    if (popFind.applied ~= '') then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d of %d keys match "%s"',
            popFind.shown, #pop.rows, popFind.applied));
        tip(TIPS.popFound);
    end

    for _, tier in ipairs(pop.tiers) do
        local rows = popFind.byTier[tier.key];

        if (rows ~= nil and #rows > 0) then
            imgui.Separator();
            imgui.TextColored(theme.colors.hint, tier.head or tier.label);
            tip(TIPS.popTier);

            for _, row in ipairs(rows) do
                popRow(row);
            end
        end
    end

    -- ROWS THE DIRECTORY DOES NOT NAME still get drawn. The loop that matched
    -- each row against each tier header dropped them in silence, so a shelf
    -- whose j| directory lost a line to the wire budget would have sold
    -- nothing under it and said nothing about why.
    if (#popFind.ungrouped > 0) then
        imgui.Separator();
        paragraph('Keys the shelf sent without a tier header:');

        for _, row in ipairs(popFind.ungrouped) do
            popRow(row);
        end
    end

    -- A search that matched nothing must say so: an empty shelf under a
    -- filter reads exactly like a shelf the server did not stock.
    if (popFind.shown == 0) then
        imgui.Separator();
        paragraph(string.format('No key matches "%s". Clear the box and press Find to see the whole shelf again.',
            popFind.applied));
    end

    -- The armed quote, and the ONLY place Confirm exists for this tab.
    if (pop.quote ~= nil) then
        imgui.Separator();

        local left = ticked(pop.quote.holds, pop.quote.at, state.now);

        if (left ~= nil and left <= 0) then
            pop.quote = nil;
        else
            -- The row the quote names, off the index map built with the
            -- shelf: this used to be a walk of every row on the shelf,
            -- without even a break, on every frame a quote was armed.
            local quoted = pop.byIndex[pop.quote.index];

            imgui.TextColored(theme.colors.hint, string.format('%s -- %d hundred-piece(s) + %d different testimon%s, from your bag   (%ds to confirm)',
                quoted ~= nil and quoted.label or '?', pop.quote.hundreds,
                pop.quote.testimonies, pop.quote.testimonies == 1 and 'y' or 'ies', left or 0));
            tip(TIPS.hold);

            if (writePending ~= nil) then
                imgui.TextDisabled('buying...');
                tip(TIPS.busy);
            else
                local confirmed = imgui.SmallButton('Confirm##dwquest_pop_confirm');

                tip(TIPS.confirm);

                if (confirmed) then
                    local line = '!dwu confirm';

                    pop.quote      = nil;
                    -- What the answer cannot work out for itself: this
                    -- confirm spends the BAG (see popConfirmSent).
                    popConfirmSent = true;

                    beginWrite('confirm', line, line);
                end

                imgui.SameLine();

                local cancelled = imgui.SmallButton('Cancel##dwquest_pop_cancel');

                tip(TIPS.cancel);

                if (cancelled) then
                    -- Local teardown only: the server's quote ages out on its
                    -- own clock, and nothing un-asks a price.
                    pop.quote = nil;
                end
            end
        end
    end

    imgui.EndChild();
end

-- The Pop-Items read, issued only while its tab is on screen. One request,
-- whole shelf -- there is no per-tier fetch to re-arm for.
local function needPops(now)
    askOnce('pops', '!dwu pops', now);
end

--[[
* The Jeweler tab (owner request 2026-09-03). The ArmsDealer's dance -- Buy
* quotes, Confirm settles, one pending purchase per character -- over the
* Pop-Items' shape: the whole shelf on one read, grouped under the case
* headers the j| directory names, no dropdown. THE CASES ARE PRICED
* SEPARATELY and this file never says how much anything costs: the price on
* every row, on every header and on the quote comes off the wire.
--]]
-- ONE JEWELER ROW: the icon, the label, what it fits, the price and the one
-- button the shelf's state allows. Hoisted out of the case loop so the
-- ungrouped rows below it draw exactly the same line (the Pop-Items shape).
local function jewelRow(row)
    drawIcon(row.itemid, 20);

    if (imgui.IsItemHovered()) then
        itemTooltip(row);
    end

    imgui.Text(row.label);

    if (imgui.IsItemHovered()) then
        itemTooltip(row);
    end

    imgui.SameLine();
    imgui.TextDisabled(row.detail);
    imgui.SameLine();
    imgui.TextColored(theme.colors.ok, row.cost);
    tip(TIPS.price);
    imgui.SameLine();

    if (writePending ~= nil) then
        imgui.TextDisabled('busy...');
        tip(TIPS.busy);
    elseif (jewel.quote == nil) then
        -- A buy is a QUOTE (the t| that answers is the only thing that can
        -- arm Confirm), queued as a WRITE: never collapsed, never re-sent,
        -- and the buttons wait while it is in flight.
        local buying = imgui.SmallButton(row.buy);

        tip(TIPS.buy);

        if (buying) then
            beginWrite('jewelbuy', row.label, string.format('!dwu jewelbuy %d', row.index));
        end
    else
        imgui.TextDisabled('quoted');
        tip(TIPS.quoteGone);
    end
end

local function jewelerPanel()
    if (not imgui.BeginChild('##dwquest_jewel', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not jewel.synced) then
        waitingLine('jeweler', 'Waiting for the Jeweler...');
        imgui.EndChild();

        return;
    end

    if (#jewel.cases == 0 or #jewel.rows == 0) then
        imgui.TextDisabled('The Jeweler is not stocked on this server build.');
        imgui.EndChild();

        return;
    end

    paragraph('Earrings and rings for Drift Coins. Rare/Ex: yours, and your account\'s.');

    for _, case in ipairs(jewel.cases) do
        local rows = jewel.byCase[case.catId];

        if (rows ~= nil and #rows > 0) then
            imgui.Separator();
            -- The header's price is the FIRST ROW'S, off the wire -- never a
            -- constant of this file's own (the ArmsDealer's rule: a hardcoded
            -- number here would be a second source of truth for MONEY).
            imgui.TextColored(theme.colors.hint, case.head or case.label);
            tip(TIPS.price);

            for _, row in ipairs(rows) do
                jewelRow(row);
            end
        end
    end

    -- ROWS THE DIRECTORY DOES NOT NAME still get drawn. A row's case comes
    -- off its index band, so a shelf whose j| directory lost a line -- or an
    -- index the server renumbers out of the 3000 band -- used to be dropped
    -- by the loop that matched on it, in silence.
    if (#jewel.ungrouped > 0) then
        imgui.Separator();
        paragraph('Pieces the shelf sent without a case header:');

        for _, row in ipairs(jewel.ungrouped) do
            jewelRow(row);
        end
    end

    -- The armed quote, and the ONLY place Confirm exists for this tab.
    if (jewel.quote ~= nil) then
        imgui.Separator();

        local left = ticked(jewel.quote.holds, jewel.quote.at, state.now);

        if (left ~= nil and left <= 0) then
            jewel.quote = nil;
        else
            imgui.TextColored(theme.colors.hint, string.format('%s -- %d DC   (%ds to confirm)',
                jewel.quote.label, jewel.quote.price, left or 0));
            tip(TIPS.hold);

            if (writePending ~= nil) then
                imgui.TextDisabled('buying...');
                tip(TIPS.busy);
            else
                local confirmed = imgui.SmallButton('Confirm##dwquest_jewel_confirm');

                tip(TIPS.confirm);

                if (confirmed) then
                    local line = '!dwu confirm';

                    jewel.quote = nil;
                    beginWrite('confirm', line, line);
                end

                imgui.SameLine();

                local cancelled = imgui.SmallButton('Cancel##dwquest_jewel_cancel');

                tip(TIPS.cancel);

                if (cancelled) then
                    -- Local teardown only: the server's quote ages out on its
                    -- own clock, and nothing un-asks a price.
                    jewel.quote = nil;
                end
            end
        end
    end

    imgui.EndChild();
end

-- The Jeweler's read, issued only while its tab is on screen. One request,
-- whole shelf -- there is no per-case fetch to re-arm for.
local function needJewel(now)
    askOnce('jeweler', '!dwu jeweler', now);
end

--[[
* THE COIN LEDGER (1.22.0) -- where the coins went.
*
* The header line has shown a balance since Phase 2 and nothing that could
* answer "why is it that number". The `balance` verb has carried the lifetime
* totals and the last five movements since Phase 1 (dwu_protocol.md, `g|` and
* `l|`) and only the typed tier ever read them, so the one question a purse
* provokes had a typed answer and no clicked one.
*
* EVERY NUMBER HERE IS THE SERVER'S, RENDERED. The deltas, the reasons and the
* two lifetime totals are wire fields; the only thing this file works out is
* how long ago a database timestamp was, and it does that once per answer
* rather than per row per frame (see the `z|balance` close).
*
* NO UNSUPPORTED LATCH, and that is a deliberate reading rather than an
* omission: `balance` is in dwu_protocol.md's verb table under protocol 1, so
* every server that answers the `d|1` this addon requires has it. A latch is
* owed by a verb an addon starts asking for that its server may predate, and
* there is no such server for this one.
--]]
local function ledgerBlock()
    if (state.earned == nil) then
        local asked = requested['balance'];

        if (type(asked) == 'table' and asked.gaveUp) then
            paragraph('The server did not send the ledger. Refresh to ask again.');
        else
            imgui.TextDisabled('Reading the ledger...');
        end

        return;
    end

    imgui.TextDisabled(string.format('Lifetime: %d DC earned, %d DC spent.',
        state.earned, state.spent or 0));

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.lifetime);
    end

    if (#state.ledger == 0) then
        imgui.TextDisabled('  Nothing has moved on this account yet.');

        return;
    end

    for _, row in ipairs(state.ledger) do
        -- Spent red, earned green: five lines of "+8 DC" and "-125 DC" in one
        -- colour is a list a player has to read rather than see.
        imgui.TextColored(row.delta < 0 and theme.colors.err or theme.colors.ok, row.amount);
        tip(TIPS.ledgerRow);
        imgui.SameLine();
        imgui.Text(row.reason);
        tip(TIPS.ledgerRow);
        imgui.SameLine();
        imgui.TextDisabled(row.ago or '');
        tip(TIPS.ledgerAgo);
    end
end

--[[
* THE OPTIONS DRAWER (1.23.0) -- the two switches that stay off.
*
* `/quests rewards off` and `/quests feed off` have been the ONLY way to
* reach either since each shipped: the load banner says so once, the lines
* scroll away, and a player who wants the kill feed back has to remember a
* command for a feature they turned off. Both are persisted per PC, so a
* switch nobody can find is a switch nobody can undo.
*
* THE LEDGER'S SHAPE, deliberately: a two-state button on the header opens a
* block, the block costs nothing while it is shut, and nothing here is an
* ImGui surface this addon does not already use. The state word sits BESIDE
* the button rather than in its label, so neither button changes width when
* it is clicked and the row under it does not move.
*
* Each click saves. `settings.save` is pcall'd for the reason the load is:
* a settings file this addon cannot write must cost the setting, never the
* window.
--]]
local function optionsBlock()
    local rewards = (config.rewards ~= false);
    local feed    = (config.feed ~= false);

    if (imgui.SmallButton('Rewards##dwquest_opt_rewards')) then
        config.rewards = not rewards;
        pcall(settings.save);
        toast(config.rewards
            and 'Reward lines are moved here from the battle log.'
            or 'Reward lines are left where the client puts them.');
    end

    tip(TIPS.optRewards);
    imgui.SameLine();

    -- The LIVE value, not the one read at the top of this function: a click
    -- flips it above, and showing the pre-click word for a frame would have
    -- the state disagree with the toast that announced it.
    if (config.rewards ~= false) then
        imgui.TextColored(theme.colors.ok, 'on');
    else
        imgui.TextDisabled('off');
    end

    tip(TIPS.optRewards);

    if (imgui.SmallButton('Feed##dwquest_opt_feed')) then
        config.feed = not feed;
        pcall(settings.save);
        toast(config.feed
            and 'The kill feed is filed under chat.'
            or 'The kill feed is off; those lines stay in the battle log.');
    end

    tip(TIPS.optFeed);
    imgui.SameLine();

    -- The live value, for the switch above it's reason.
    if (config.feed ~= false) then
        imgui.TextColored(theme.colors.ok, 'on');
    else
        imgui.TextDisabled('off');
    end

    tip(TIPS.optFeed);

    paragraph('Both stay as you leave them, on this PC. They are the same two switches as /quests rewards and /quests feed.');
end

local function headerRow()
    -- Refresh re-says `hello`, not `board`. It is the player's deliberate
    -- "make this right" click, and the one thing a plain re-read could not fix
    -- is a lost arming -- a map that restarted under the session drops the
    -- local var the ping rides on, and every following board read would come
    -- back correct and silent forever after. Re-arming is a no-op when it was
    -- never lost.
    local refreshed = imgui.Button('Refresh##dwquest_refresh');

    tip(TIPS.refresh);

    if (refreshed) then
        -- Home first: `hello` answers the player's own board, and a view flag
        -- left set would have the next auto-sync silently steer away again.
        state.viewBand = nil;

        refresh('hello');
    end

    imgui.SameLine();

    if (state.balance ~= nil) then
        imgui.TextColored(theme.colors.ok, string.format('%d DC', state.balance));
        tip(TIPS.balance);
    else
        imgui.TextDisabled('-- DC');
        tip(TIPS.noBalance);
    end

    -- The Burst Token purse (2026-08-25), shown only once a server that
    -- knows the currency has answered -- an invented zero would read as
    -- "you have none" on a server that simply predates the arena.
    if (state.burstBalance ~= nil) then
        imgui.SameLine();
        imgui.TextColored(theme.colors.ok, string.format('%d BT', state.burstBalance));
        tip(TIPS.burst);
    end

    -- The ledger's door (1.22.0). A two-state button rather than a checkbox,
    -- the Augments tab's shape: no ImGui surface this addon does not already
    -- use. Both labels are the same width in the client's font, so the gil
    -- controls beside it do not shift when it is toggled.
    imgui.SameLine();

    local ledgerClicked = imgui.SmallButton(state.ledgerOpen
        and 'Ledger -##dwquest_ledger' or 'Ledger +##dwquest_ledger');

    tip(TIPS.ledger);

    if (ledgerClicked) then
        state.ledgerOpen = not state.ledgerOpen;

        -- Opening RE-ARMS the read rather than showing whatever was last
        -- fetched: the times beside the lines are rendered once per answer,
        -- so a stale answer is a stale "just now".
        if (state.ledgerOpen) then
            requested['balance'] = nil;
        end
    end

    -- The options drawer's door, the Ledger's shape one button over. Purely
    -- local: nothing behind it touches the wire, so there is no read to arm.
    imgui.SameLine();

    local optionsClicked = imgui.SmallButton(state.optionsOpen
        and 'Options -##dwquest_options' or 'Options +##dwquest_options');

    tip(TIPS.options);

    if (optionsClicked) then
        state.optionsOpen = not state.optionsOpen;
    end

    local queued = #readQueue + #writeQueue;

    if (queued > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d queued...', queued));
        tip(TIPS.queued);
    end

    --[[
    * THE GIL EXCHANGE (2026-09-04) GETS ITS OWN LINE (2026-09-06).
    *
    * It used to be SameLine'd onto the end of the header, and with the
    * purse, the token purse, the Ledger door, the queue counter and the
    * rotation stamp all on that one row the line ran past 900 pixels -- so
    * on the window's own default width the rate a player is buying AT sat on
    * the clipped side of the right edge, and the queue counter and the
    * day/band/pool stamp were never visible at all. Nothing here is
    * scrollable sideways (the window carries NoScrollbar and the header sits
    * outside every child), so what does not fit is not merely awkward: it is
    * gone.
    *
    * Quote then confirm like every other purchase: Buy is a WRITE that arms
    * nothing by itself, the t| in the `gil` envelope is the only thing that
    * arms Confirm, and the click disarms it in the same statement that
    * queues the line. Every number on this row is the server's.
    --]]
    if (state.gilPerCoin ~= nil) then
        imgui.TextDisabled('Buy coins:');
        tip(TIPS.gilCount);
        imgui.SameLine();
        -- 128, not 64 (owner, 2026-09-04): InputInt spends two frame-height
        -- step buttons out of its width, so 64 left room for one digit and
        -- the count being bought was invisible. Three digits (the ceiling
        -- is 100) plus the buttons need this much.
        imgui.SetNextItemWidth(128);
        imgui.InputInt('##dwquest_gil_count', gil.count);
        tip(TIPS.gilCount);

        --[[
        * THE PLAYER'S OWN NUMBER, NORMALISED BEFORE ANYTHING COMPARES OR
        * FORMATS IT (2026-09-06). This is the one number on this window a
        * person types rather than reads, and it goes straight onto a line
        * that spends gil -- so it gets the treatment every typed number in
        * this suite gets: nil, nan, an infinity and a fraction all resolve
        * to the floor rather than reaching `string.format('%d', ...)`, which
        * RAISES on a fraction under the Lua the harness runs and prints
        * -9223372036854775808 for an infinity under the LuaJIT the client
        * runs. `nan ~= nan` is why the test is written that way round: it
        * compares false against every bound, so the ordinary tests below
        * would let it straight through.
        --]]
        local want = tonumber(gil.count[1]);

        if (want == nil or want ~= want or want ~= math.floor(want) or want < 1) then
            want = 1;
        end

        --[[
        * THE CEILING IS THE SERVER'S, BOUNDED BY WHAT THE BOX CAN HOLD.
        *
        * The ceiling is only a ceiling when it is one: a `gilmaxcoins` of
        * zero -- a truncated field, a server mid-configuration -- used to
        * clamp the box to 0 and send `!dwu gil 0`, a line whose only
        * possible answer is a refusal.
        *
        * And it is a WIRE FIELD reaching an ImGui InputInt, which is an
        * int32 in the binding underneath. num() refuses a fraction, an
        * infinity and a nan but passes a whole number up to 1e15, and
        * handing one of those to the box is a value the C++ side cannot
        * hold. GIL_BOX_MAX is far above anything the server has ever sent
        * (its own ceiling is 100) and far below where an int32 stops
        * counting.
        --]]
        local ceiling = state.gilMaxCoins;

        if (ceiling == nil or ceiling < 1) then
            ceiling = GIL_BOX_MAX;
        elseif (ceiling > GIL_BOX_MAX) then
            ceiling = GIL_BOX_MAX;
        end

        if (want > ceiling) then
            want = ceiling;
        end

        gil.count[1] = want;

        imgui.SameLine();

        if (writePending ~= nil) then
            imgui.TextDisabled('busy...');
            tip(TIPS.busy);
        elseif (gil.quote == nil) then
            local buying = imgui.SmallButton('Buy DC with gil##dwquest_gil_buy');

            tip(TIPS.gilBuy);

            if (buying) then
                beginWrite('gil', string.format('%d Drift Coins', gil.count[1]),
                    string.format('!dwu gil %d', gil.count[1]));
            end
        else
            -- The Buy is gone because a quote is armed, and a control that
            -- vanishes explains nothing. Something to hover, and a sentence
            -- on it that names the rule.
            imgui.TextDisabled('quoted');
            tip(TIPS.quoteGone);
        end

        imgui.SameLine();
        imgui.TextDisabled(gilRateText());
        tip(TIPS.gilRate);
    end

    -- The armed gil quote, and the ONLY place its Confirm exists.
    if (gil.quote ~= nil) then
        local left = ticked(gil.quote.holds, gil.quote.at, state.now);

        if (left ~= nil and left <= 0) then
            gil.quote = nil;
        else
            imgui.TextColored(theme.colors.hint, string.format('%s for %s gil   (%ds to confirm)',
                gil.quote.label, fmtGil(gil.quote.price), left or 0));
            tip(TIPS.gilQuote);

            if (writePending ~= nil) then
                imgui.TextDisabled('buying...');
                tip(TIPS.busy);
            else
                imgui.SameLine();

                local confirmed = imgui.SmallButton('Confirm##dwquest_gil_confirm');

                tip(TIPS.confirm);

                if (confirmed) then
                    local line = '!dwu confirm';

                    gil.quote = nil;
                    beginWrite('confirm', line, line);
                end

                imgui.SameLine();

                local cancelled = imgui.SmallButton('Cancel##dwquest_gil_cancel');

                tip(TIPS.cancel);

                if (cancelled) then
                    -- Local teardown only: the server's quote ages out on its
                    -- own clock, and nothing un-asks a price.
                    gil.quote = nil;
                end
            end
        end
    end

    -- THE STAMP AND THE CLOCKS SHARE THE LAST HEADER LINE, and the stamp no
    -- longer rides the end of the first one: at the window's default width it
    -- was clipped off the right edge entirely, which is a bug report's most
    -- useful three numbers invisible.
    if (state.day ~= nil) then
        imgui.TextDisabled(stampText());
        tip(TIPS.stamp);
    end

    if (state.clockAt ~= nil) then
        if (state.day ~= nil) then
            imgui.SameLine();
        end

        imgui.TextDisabled(string.format('New dailies in %s   New weeklies in %s',
            fmtClock(ticked(state.secsToDay, state.clockAt, state.now)),
            fmtClock(ticked(state.secsToWeek, state.clockAt, state.now))));
        tip(TIPS.clocks);
    end

    if (state.status ~= nil and state.status ~= '') then
        -- Wrapped: a refusal is a whole sentence the server wrote, and the
        -- longest of them run past ninety characters.
        if (state.statusBad) then
            paragraphColored(theme.colors.err, state.status);
        else
            paragraphColored(theme.colors.ok, state.status);
        end
    end

    if (state.toast ~= nil and state.toastAt ~= nil and (state.now - state.toastAt) <= TOAST_SECONDS) then
        imgui.TextColored(theme.colors.hint, state.toast);
    end

    if (state.ledgerOpen) then
        ledgerBlock();
    end

    if (state.optionsOpen) then
        optionsBlock();
    end

    imgui.Separator();
end

--[[
* The Exchange's reads, issued only while its tab is the one on screen. A
* window sitting on the Board tab has no business asking for a storefront.
--]]
local function needShop(now)
    askOnce('augments', '!dwu augments', now);

    --[[
    * NOTHING BELOW THE STOREFRONT IS ASKED FOR UNTIL THE STOREFRONT HAS
    * ANSWERED (2026-09-06). `shop.picked` is an offer HANDLE -- `x1` -- and
    * a handle only means an augment while the shelf it came off is the shelf
    * on the wire. A zone line drops `shop.synced` and leaves the handle and
    * the chosen character behind it, so the window's first act in the new
    * session was a gear read for `x1` (which may now be a different augment)
    * on `@Yakapo` (who may not be on this account) -- a line whose only
    * possible answer is a refusal, sent before the panel had drawn a single
    * card. The panel is gated on `synced` and draws nothing here either way;
    * this stops the wire saying what the screen does not.
    --]]
    if (not shop.synced or shop.picked == nil) then
        return;
    end

    local wanted = gearRequest();

    if (wanted == nil) then
        return;
    end

    -- The signature of the request the list would answer. When it changes --
    -- a different offer, a different character, a different search -- the
    -- tracker is re-armed and the list on screen is stale until the answer
    -- lands.
    if (shop.gearFor ~= wanted) then
        shop.gearFor      = wanted;
        shop.gearSynced   = false;
        requested['gear'] = nil;
    end

    askOnce('gear', wanted, now);
end

--[[
* The Augments reference tab (2026-08-19).
*
* Everything static here comes off augcatalog.lua (generated, see the header);
* the only live ingredient is TODAY's four offers, read off the same
* shop.offers the Exchange tab renders -- so the [today] markers and the
* Exchange's cards can never disagree about what is on sale. The tab issues
* the same `!dwu augments` read under the same ask-once tracker, so whichever
* tab is opened first pays for the one fetch.
*
* The view is CACHED against the search-and-scope key rather than filtered
* every frame: ~700 rows through string.find per frame is work a window
* redraws sixty times a second for no new answer (dwwarehouse's caching
* lesson, one tab over). Paged locally because a filtered-down list is the
* normal way to use a reference; the pager exists for the browse case.
--]]
local AUGREF_PAGE = 200;

local augref = {
    filter   = T{ '' },  -- InputText live buffer; committed on Enter/Search
    applied  = '',       -- the committed search, lowercased
    poolOnly = false,    -- scope: everything, or only what the Exchange sells
    page     = 1,
    ids      = nil,      -- every catalog id, sorted once on first draw
    view     = nil,      -- the filtered id list the pager walks
    -- The search and the scope the view answers, compared as fields rather
    -- than as one formatted key (see augrefView).
    viewSearch = nil,
    viewScope  = nil,
};

--[[
* THE REFERENCE ROW'S TWO FIXED STRINGS, BUILT ONCE PER ID (2026-09-06).
*
* The panel draws up to AUGREF_PAGE rows and composed both of each row's
* strings inside the loop: two hundred `string.format` calls, sixty times a
* second, plus a `fitsWords` call per sold row -- for text whose every
* ingredient is a constant of augcatalog.lua, a generated file required once
* and never written to again. This is the same memo the board card's
* objective sentence already carries, on the panel that draws thirty times as
* many rows.
*
* A TABLE OF ITS OWN rather than a field on the catalog entry: augcatalog.lua
* is generated data, and a renderer that writes into it makes the next
* reader wonder which fields the generator emits. Bounded by the catalog,
* which is bounded by the engine.
--]]
local augrefRows = { };

local function augrefRow(id)
    local row = augrefRows[id];

    if (row ~= nil) then
        return row;
    end

    local sold = augcatalog.pool[id];

    row = { label = string.format('%4d  %s', id, augcatalog.augments[id].l) };

    if (sold ~= nil) then
        row.sold = string.format('rank %d, %d DC, %s', sold.rank, sold.price, fitsWords(sold.fits));
    end

    augrefRows[id] = row;

    return row;
end

local function augrefView()
    if (augref.ids == nil) then
        augref.ids = { };

        for id in pairs(augcatalog.augments) do
            table.insert(augref.ids, id);
        end

        table.sort(augref.ids);
    end

    -- The view is keyed on the search and the scope as FIELDS, not as a
    -- formatted string: this comparison runs on every frame the tab is
    -- drawn, and building a key to find out nothing changed is an allocation
    -- a frame for no answer.
    if (augref.view == nil or augref.viewSearch ~= augref.applied
            or augref.viewScope ~= augref.poolOnly) then
        augref.viewSearch = augref.applied;
        augref.viewScope  = augref.poolOnly;
        augref.view       = { };

        for _, id in ipairs(augref.ids) do
            if (not augref.poolOnly or augcatalog.pool[id] ~= nil) then
                if (augref.applied == ''
                        or string.find(string.lower(augcatalog.augments[id].l), augref.applied, 1, true) ~= nil
                        or string.find(tostring(id), augref.applied, 1, true) ~= nil) then
                    table.insert(augref.view, id);
                end
            end
        end
    end

    return augref.view;
end

local function augrefPanel()
    if (not imgui.BeginChild('##dwquest_augref', { -1, -1 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not haveCatalog) then
        paragraph('The augment catalog (augcatalog.lua) is missing from this addon folder.');
        paragraph('Slot views fall back to raw augment numbers. Re-syncing the addon restores the reference.');
        imgui.EndChild();

        return;
    end

    -- Today's offers, by augment id -- built at the `z|` that commits them
    -- (see shop.byAugid), so a rotation that lands mid-session moves these
    -- markers on the same answer that moves the Exchange's cards, and no
    -- frame pays for a map that changes once a Vana'diel day.
    local today = shop.byAugid;

    --[[
    * THE KEY, ON TWO ROWS (2026-09-06). All four of these used to be
    * SameLine'd into one run of about 120 characters -- eight hundred pixels
    * on a window whose floor is 560 -- so the half that says what [sold]
    * means was cut off the right edge with nothing on screen to say it had
    * been. One marker and its sentence per row, and each marker explains
    * itself on hover as well.
    --]]
    imgui.TextColored(theme.colors.ok, '[today]');
    tip(TIPS.markToday);
    imgui.SameLine();
    imgui.TextDisabled('on the Exchange right now -- Choose starts the purchase.');
    tip(TIPS.markToday);

    imgui.TextColored(theme.colors.hint, '[sold]');
    tip(TIPS.markSold);
    imgui.SameLine();
    imgui.TextDisabled('the Exchange sells it; rank, price and fit are beside the row.');
    tip(TIPS.markSold);

    paragraph('Numbers in brackets are what gear slots store; the Enchanter tab shows the same numbers decoded.');
    tip(TIPS.augIds);

    imgui.PushItemWidth(180);

    -- EnterReturnsTrue: the commit, and the only read of the live buffer --
    -- the Exchange search's rule, for the Exchange search's reason.
    local augEntered = imgui.InputText('##dwquest_augref_search', augref.filter, 64,
        ImGuiInputTextFlags_EnterReturnsTrue);

    tip(TIPS.augSearch);

    if (augEntered) then
        augref.applied = string.lower(augref.filter[1] or '');
        augref.page    = 1;
    end

    imgui.PopItemWidth();
    imgui.SameLine();

    local augSearched = imgui.SmallButton('Search##dwquest_augref_go');

    tip(TIPS.search);

    if (augSearched) then
        augref.applied = string.lower(augref.filter[1] or '');
        augref.page    = 1;
    end

    imgui.SameLine();

    -- A two-state button rather than a checkbox: no ImGui surface this addon
    -- does not already use.
    local scoped = imgui.SmallButton(augref.poolOnly
        and 'Showing: Exchange only##dwquest_augref_scope'
        or 'Showing: everything##dwquest_augref_scope');

    tip(TIPS.augScope);

    if (scoped) then
        augref.poolOnly = not augref.poolOnly;
        augref.page     = 1;
    end

    local view  = augrefView();
    local total = #view;
    local pages = math.max(1, math.ceil(total / AUGREF_PAGE));

    if (augref.page > pages) then
        augref.page = pages;
    end

    local first = (augref.page - 1) * AUGREF_PAGE + 1;
    local last  = math.min(total, first + AUGREF_PAGE - 1);

    imgui.TextDisabled(string.format('%d augment(s)%s%s', total,
        augref.applied ~= '' and string.format(' matching "%s"', augref.applied) or '',
        pages > 1 and string.format(' -- page %d of %d', augref.page, pages) or ''));
    tip(TIPS.augCount);

    if (pages > 1) then
        imgui.SameLine();

        local back = imgui.SmallButton('<##dwquest_augref_prev');

        tip(TIPS.augPrev);

        if (back) then
            augref.page = math.max(1, augref.page - 1);
        end

        imgui.SameLine();

        local onward = imgui.SmallButton('>##dwquest_augref_next');

        tip(TIPS.augNext);

        if (onward) then
            augref.page = math.min(pages, augref.page + 1);
        end
    end

    imgui.Separator();

    for index = first, last do
        local id    = view[index];
        local entry = augrefRow(id);
        local offer = today[id];

        if (offer ~= nil) then
            imgui.TextColored(theme.colors.ok, '[today]');
            imgui.SameLine();
        elseif (entry.sold ~= nil) then
            imgui.TextColored(theme.colors.hint, '[sold]');
            imgui.SameLine();
        end

        imgui.Text(entry.label);

        if (entry.sold ~= nil) then
            imgui.SameLine();
            imgui.TextDisabled(entry.sold);
        end

        -- A [today] row can start the purchase from here: the SAME picker the
        -- Exchange's cards feed, so there is one chosen offer whichever tab
        -- chose it. Blocked while a write is in flight, like the cards.
        if (offer ~= nil) then
            imgui.SameLine();

            if (writePending ~= nil) then
                imgui.TextDisabled('busy...');
                tip(TIPS.busy);
            elseif (shop.picked == offer.slot) then
                imgui.TextColored(theme.colors.ok, 'chosen -- the Enchanter tab picks the gear');
                tip(TIPS.chosen);
            else
                local choosing = imgui.SmallButton(string.format('Choose##dwquest_augref_%d', id));

                tip(TIPS.augChoose);

                if (choosing) then
                    chooseOffer(offer);
                    toast('Chosen. Open the Enchanter tab to pick the gear it goes on.');
                end
            end
        end
    end

    imgui.EndChild();
end

local function renderWindow()
    headerRow();

    -- Which tab is on screen decides which reads run, and the flag is set from
    -- what ImGui actually drew rather than from a click handler: a tab
    -- restored from imgui.ini is one nobody clicked this session.
    local onExchange = false;
    local onAugref   = false;
    local onOutfit   = false;
    local onArms     = false;
    local onPops     = false;
    local onJewel    = false;

    if (imgui.BeginTabBar('##dwquest_tabs')) then
        --[[
        * THE TAB TIPS HANG OUTSIDE THE `if`, and they have to. ImGui submits
        * the tab as an item inside BeginTabItem, so IsItemHovered reads the
        * TAB there whether it opened or not -- and the first widget the body
        * draws would take the "last item" away. Written inside the branch,
        * six of these seven would only ever be reachable on the tab already
        * open, which is the one that needs no explaining. (dwbags' tab bar,
        * same shape, same reason.)
        --]]
        local onBoard = imgui.BeginTabItem('Board##dwquest_tab_board');

        tip(TIPS.tabBoard);

        if (onBoard) then
            if (state.synced) then
                boardPanel();
            else
                waitingLine('board', 'Waiting for the board...');
            end

            imgui.EndTabItem();
        end

        --[[
        * ACCEPTED SITS SECOND, immediately right of the Board (1.25.0), and
        * its ImGui id is its own. The two tabs read the SAME answer -- one
        * `board` envelope carries both the o| offers and the a| contracts --
        * so nothing here asks the server for anything and there is no read
        * to gate on the tab being open. `synced` is the same gate the Board
        * uses, for the same reason: a card before the first z|board is a
        * card drawn from nothing.
        --]]
        local onAccepted = imgui.BeginTabItem('Accepted##dwquest_tab_accepted');

        tip(TIPS.tabAccepted);

        if (onAccepted) then
            if (state.synced) then
                acceptedPanel();
            else
                waitingLine('board', 'Waiting for the board...');
            end

            imgui.EndTabItem();
        end

        -- THE LABEL MOVED, THE ID DID NOT (1.25.0). `##dwquest_tab_shop` is
        -- the widget's identity -- it is what imgui.ini remembers a player's
        -- open tab by -- and renaming it would throw every window back to
        -- the Board on the first launch after the update. The word in front
        -- of it is presentation, and presentation is all the owner asked to
        -- change.
        onExchange = imgui.BeginTabItem('Enchanter##dwquest_tab_shop');

        tip(TIPS.tabShop);

        if (onExchange) then
            exchangePanel();
            imgui.EndTabItem();
        end

        onAugref = imgui.BeginTabItem('SeeAugs##dwquest_tab_augref');

        tip(TIPS.tabAugref);

        if (onAugref) then
            augrefPanel();
            imgui.EndTabItem();
        end

        onOutfit = imgui.BeginTabItem('Outfitter##dwquest_tab_outfit');

        tip(TIPS.tabOutfit);

        if (onOutfit) then
            outfitterPanel();
            imgui.EndTabItem();
        end

        onArms = imgui.BeginTabItem('ArmsDealer##dwquest_tab_arms');

        tip(TIPS.tabArms);

        if (onArms) then
            armsdealerPanel();
            imgui.EndTabItem();
        end

        onPops = imgui.BeginTabItem('Pop-Items##dwquest_tab_pops');

        tip(TIPS.tabPops);

        if (onPops) then
            popitemsPanel();
            imgui.EndTabItem();
        end

        onJewel = imgui.BeginTabItem('Jeweler##dwquest_tab_jewel');

        tip(TIPS.tabJewel);

        if (onJewel) then
            jewelerPanel();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    -- Inside the pcall, and last: the syncs are the one thing here that can
    -- queue a line, and a throw in them must cost the window rather than the
    -- present handler that draws every other addon after us.
    checkRotation(state.now);
    needBoard(state.now);

    -- The ledger's read is on the same rule as every panel's: issued only
    -- while the thing it feeds is on screen. A window whose owner never
    -- opened the block never spends a line on it.
    if (state.ledgerOpen) then
        askOnce('balance', '!dwu balance', state.now);
    end

    if (onExchange) then
        checkShopRotation(state.now);
        needShop(state.now);
    end

    -- The reference tab's [today] markers ride the same storefront read and
    -- the same rotation clock as the Exchange -- same tracker key, so
    -- whichever tab asks first answers for both.
    if (onAugref) then
        checkShopRotation(state.now);
        askOnce('augments', '!dwu augments', state.now);
    end

    if (onOutfit) then
        needOutfit(state.now);
    end

    if (onArms) then
        needArms(state.now);
    end

    if (onPops) then
        needPops(state.now);
    end

    if (onJewel) then
        needJewel(state.now);
    end
end

-- The size floor, and the latch that turns a missing binding into one dead
-- frame rather than sixty a second (see the call site).
local WINDOW_MIN   = { 600, 360 };
local WINDOW_MAX   = { 99999, 99999 };
local canConstrain = true;

--[[
* The render pass: pcall'd body, Begin/End and theme push/pop outside it so
* both stacks stay balanced; an error closes the window once, loudly, and the
* typed commands remain as the fallback.
--]]
ashita.events.register('d3d_present', 'dwquest_present', function ()
    -- Read once per frame. Two reads of the clock inside one frame would let
    -- a countdown and the bar beside it disagree, and the offline harness's
    -- clock strides deliberately to make that visible.
    state.now = os.clock();

    -- A write that was never answered must not hold the card hostage. Nothing
    -- was charged, nothing is re-sent: Refresh shows where the contract
    -- actually stands.
    if (writePending ~= nil and (state.now - writePending.at) > WRITE_TIMEOUT) then
        writePending    = nil;
        state.status    = 'No answer from the server. Nothing was re-sent -- Refresh shows where you stand.';
        state.statusBad = true;
    end

    pumpQueue(state.now);

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    --[[
    * 900, up from 640 this morning and 560 before that, and the number is
    * measured rather than chosen.
    *
    * The widest thing this window draws is a Pop-Items PAIR row: two item
    * icons, two item names the client's own DATs answer with, the notorious
    * monster and its zone, and the Buy button. At the field widths
    * quest_core.lua's own WIDEST fixture budgets -- 24 for the monster, 24
    * for the zone, and item names the client can make just as long -- that
    * row is about 860 pixels at the client's font. The other three shelves'
    * widest rows (a 32-character label, a 12-character type and a
    * 20-character job list) come to about 600.
    *
    * NOTHING HERE SCROLLS SIDEWAYS: the window carries NoScrollbar and every
    * panel is a child that fills its width, so a row wider than the window
    * does not wrap and does not scroll -- it loses its Buy button off the
    * right edge, which is a piece the server will sell that the player
    * cannot buy. That is why the default is sized to the widest ROW rather
    * than to the tab bar. harness_dwquest.py drives each shelf at its
    * documented ceiling and fails if one no longer fits.
    *
    * 900 is squarely inside what this suite's windows already open at
    * (dwarena 900, dwmerc 880, dwgmpanel 980, dwbags 1320). FirstUseEver, so
    * nobody who has already placed this window is moved -- it is the size a
    * new player's first open gets.
    --]]
    imgui.SetNextWindowSize({ 900, 560 }, ImGuiCond_FirstUseEver);

    --[[
    * A FLOOR UNDER THE SIZE (2026-09-06). Nothing stopped this window being
    * dragged narrower than its own tab bar, and at that width the seven tabs
    * collapse into scroll arrows and the storefront rows lose their Buy
    * buttons off the right edge -- a window a player can make useless by
    * accident and cannot tell why.
    *
    * 600 is what the header's own widest ROW needs -- the board stamp beside
    * the two rotation clocks, which is 565 pixels at a seven-digit Vana'diel
    * day -- and it comfortably clears the seven tab labels' 504. 360 is the
    * header's three lines plus the tab bar plus two cards. (Both moved up
    * from 560x340 on the evening of 2026-09-06, when the harness learned to
    * measure a row rather than be told about one.)
    *
    * pcall'd AND LATCHED, and that is not superstition: this call sits
    * outside the render pcall because it has to run before Begin, so an
    * Ashita whose binding predates it would throw in the present handler and
    * take down every addon drawn after this one. The latch means a refusal
    * costs one frame rather than one every frame forever.
    --]]
    if (canConstrain and not pcall(imgui.SetNextWindowSizeConstraints,
            WINDOW_MIN, WINDOW_MAX)) then
        canConstrain = false;
    end

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Drift Board##dwquest', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwquest'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwquest'):append(chat.message('Window closed. Everything it does also works as !drift commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle. Opening asks `hello`, which is both the board read and
* the handshake that arms the post-kill ping for the session -- the one verb
* only the addon sends (dwu_protocol.md).
--]]
local function openWindow()
    state.open[1]   = true;
    state.reported  = false;
    state.status    = state.synced and '' or 'Loading...';
    state.statusBad = false;
    state.viewBand  = nil;

    refresh('hello');
end

local function toggleWindow()
    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end

--[[
* Watch what the player sends. Bare `!drift` (and ui/window/gui) toggles the
* window and never leaves the client; every other !drift line passes through
* and marks our state stale, because a typed accept changes the board under
* the window. Any other outgoing line stamps the throttle -- the client's rate
* limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwquest_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!drift' or lower == '!drift ui' or lower == '!drift window' or lower == '!drift gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwu') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 6) == '!drift') then
        refresh(boardVerb());
    end
end);

ashita.events.register('command', 'dwquest_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Quests`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwquest' and first ~= '/quests') then
        return;
    end

    e.blocked = true;

    --[[
    * `/quests help` -- what the two switches are, since the load banner
    * scrolls away and nothing else in the client remembers it. Named
    * explicitly rather than folded into the fall-through, because the
    * fall-through OPENS THE WINDOW: a player who typed `/quests help`
    * expecting a list got a board instead, and had no way to find out that
    * `feed` and `rewards` exist at all after the login lines were gone.
    --]]
    if (#args >= 2 and args[2]:lower() == 'help') then
        print(chat.header('dwquest'):append(chat.message('/quests                 open or close the Drift Board')));
        print(chat.header('dwquest'):append(chat.message(string.format(
            '/quests rewards on|off  Fields of Valor, Grounds of Valor and Records of Eminence payouts printed here instead of the battle log (now: %s)',
            config.rewards == false and 'off' or 'on'))));
        print(chat.header('dwquest'):append(chat.message(string.format(
            '/quests feed on|off     kills, gil, experience, limit and capacity filed under chat and colour-coded (now: %s)',
            config.feed == false and 'off' or 'on'))));
        print(chat.header('dwquest'):append(chat.message('Both switches persist, and the window carries them too: the Options button on its header line.')));
        print(chat.header('dwquest'):append(chat.message('Everything the window does also works typed: !drift help lists it.')));

        return;
    end

    --[[
    * `/quests rewards [on|off]` -- the switch on the reward reroute.
    *
    * Anything else after /quests still opens the window rather than erroring:
    * the command has always taken its arguments as noise and a player who
    * typed a typo wanted the board. A bare `rewards` reports and toggles,
    * which is what a switch with no argument means everywhere else in the
    * suite.
    --]]
    if (#args >= 2 and args[2]:lower() == 'rewards') then
        local want = nil;

        if (#args >= 3) then
            local arg = args[3]:lower();

            if (arg == 'on' or arg == 'true' or arg == '1') then
                want = true;
            elseif (arg == 'off' or arg == 'false' or arg == '0') then
                want = false;
            end
        end

        if (want == nil) then
            want = (config.rewards == false);
        end

        config.rewards = want;
        pcall(settings.save);

        if (want) then
            print(chat.header('dwquest'):append(chat.message('Fields of Valor, Grounds of Valor and Records of Eminence reward lines are moved out of the battle log.')));
        else
            print(chat.header('dwquest'):append(chat.message('Reward lines are left where the client puts them. `/quests rewards on` puts them back here.')));
        end

        return;
    end

    -- `/quests feed [on|off]` -- the switch on the kill feed, same shape as
    -- `rewards` above: a bare `feed` reports and toggles.
    if (#args >= 2 and args[2]:lower() == 'feed') then
        local want = nil;

        if (#args >= 3) then
            local arg = args[3]:lower();

            if (arg == 'on' or arg == 'true' or arg == '1') then
                want = true;
            elseif (arg == 'off' or arg == 'false' or arg == '0') then
                want = false;
            end
        end

        if (want == nil) then
            want = (config.feed == false);
        end

        config.feed = want;
        pcall(settings.save);

        if (want) then
            print(chat.header('dwquest'):append(chat.message('Kill, gil, experience, limit and capacity lines are colour-coded and filed under chat (Window 2 on the stock log config).')));
        else
            print(chat.header('dwquest'):append(chat.message('The kill feed is off; those lines stay in the battle log. `/quests feed on` moves them back.')));
        end

        return;
    end

    toggleWindow();
end);

ashita.events.register('load', 'dwquest_load', function ()
    print(chat.header('dwquest'):append(chat.message('/quests opens the Drift Board and the Drift Exchange. Everything it does also works typed as !drift commands.')));
    print(chat.header('dwquest'):append(chat.message('Fields of Valor, Grounds of Valor and Records of Eminence reward lines are printed here instead of the battle log. `/quests rewards off` stops that.')));
    print(chat.header('dwquest'):append(chat.message('Kills, gil, experience, limit and capacity lines are colour-coded and filed under chat -- Window 2 on the stock log config. `/quests feed off` stops that.')));
end);

--[[
* THE NOTICE REROUTE. The one thing in this file that touches a line the player
* did not ask this window for.
*
* A tagged line (see NOTICE_TAG above) is blocked and re-emitted through
* print(), which is the only way anything here can decide WHICH chat log a
* sentence lands in -- the server has no such lever, and every DriftwoodXI
* module prints on the same channel as the battle log's system messages.
*
* IT WORKS WITH THE WINDOW SHUT AND WITH THE SESSION UNARMED, which is the
* point. The addon only sends `!dwu hello` -- the verb that arms the post-kill
* ping -- once the player has opened the window, so most sessions are unarmed
* and every notice in them comes from the server rather than from the ping
* handler above. Those are precisely the sessions the player was losing lines
* in, and a reroute that needed arming would have missed all of them.
*
* THREE GUARDS, EACH FOR A DIFFERENT WAY THIS COULD MISBEHAVE:
*
*   e.blocked   -- dwecho installs first and blocks this addon's own command
*                  echoes. A line somebody already took is not ours to re-print.
*   e.injected  -- our own print() re-enters text_in. Stripping the tag before
*                  re-emitting already breaks the loop (the new line cannot
*                  match), but a guard that does not depend on getting the
*                  strip right is cheaper than the incident.
*   the strip   -- what goes back out carries no tag, for the reason above.
*
* The non-printable strip is dwecho's, for dwecho's reason: the line arrives
* with the packet's padding and any colour bytes still on it, and a match
* against raw bytes is a match that works until the day it does not.
*
* IT READS `message_modified`, NOT `message`. Ashita hands a text_in handler
* both: the line as it arrived, and the line as it will be DRAWN once every
* handler ahead of this one has had it. They are the same string until an addon
* that runs first rewrites one -- and the Ashita bundle ships several that do
* (customcolors recolours SYSTEM_3, changecall rewrites call tags), so this is
* the ordinary case rather than the exotic one. Re-emitting `message` would
* quietly undo their work, because what we put back is what the player reads.
* `message` is the fallback for the same reason dwecho matches on it: a field
* that is not there must not throw inside a chat handler.
*
* (Server SYSTEM_3 does reach text_in -- customcolors.lua matches it by mode
* 121, and NS_SAY by 9. The TAGGED branch deliberately does NOT gate on the
* mode: the tag is already a far narrower match than any mode is, and a mode
* test would be one more thing to be wrong on the day a notice is sent some
* other way -- printToArea's server-wide contract line being the obvious
* candidate. Missing a notice is the failure that matters here; re-routing a
* stray line is not.
*
* The UNTAGGED reward branch below is the exception, and it earned it: it has
* no tag to be narrow with, so it matches plain English a player can type, and
* one of those phrases opens a burst. See PLAYER_CHAT_MODE_MAX above -- the
* exclusion is a refusal list rather than an allow list precisely so this
* paragraph's rule still holds everywhere else.)
--]]
ashita.events.register('text_in', 'dwquest_text_in', function (e)
    if (e.blocked or e.injected) then
        return;
    end

    local raw = e.message_modified or e.message;

    if (raw == nil) then
        return;
    end

    local line = plainText(raw);
    local at   = line:find(NOTICE_TAG, 1, true);

    if (at == nil) then
        -- Not one of ours to re-print, but it may still be a payout the client
        -- drew from its own dat files (see THE REWARD REROUTE above). That
        -- line is moved WHOLE: there is no tag on it to strip, and rewriting a
        -- sentence the client wrote is how a reroute becomes a rewrite.
        -- BUT NOT OFF A LINE SOMEBODY TYPED. See PLAYER_CHAT_MODE_MAX: this
        -- branch matches plain English, one phrase of which opens a burst, so
        -- a player-chat mode must never be tested against it.
        -- ABSENT IS NOT PLAYER CHAT. Only a mode actually present refuses --
        -- an event without one still reroutes, because this is a refusal list
        -- and missing a notice is the failure that matters (see the header).
        local mode = e.mode_modified or e.mode;
        local low  = mode ~= nil and bit.band(mode, 0xFF) or nil;

        -- NPC DIALOGUE REFUSES TOO. 150 and 151 are the client's NPC-speech
        -- modes (the bundled timestamp addon special-cases exactly those), and
        -- an RoE or Field Manual NPC can say "Records of Eminence:" in
        -- dialogue -- which this branch would block out of the conversation,
        -- re-print under our header, AND treat as a burst anchor that drags
        -- the next exp line out of the battle log. Same defect the player-chat
        -- band was excluded for, one band up. Still a refusal list: only what
        -- is KNOWN to carry speech is named.
        if (low ~= nil and (low <= PLAYER_CHAT_MODE_MAX or low == 150 or low == 151)) then
            return;
        end

        local trimmed = line:gsub('^%s+', ''):gsub('%s+$', '');

        if (trimmed == '') then
            return;
        end

        -- The PATTERN, not a yes/no: it is also what says what colour the line
        -- is printed in. Asking twice would be two copies of the same match.
        local took = isRewardLine(trimmed, os.clock());

        if (took ~= nil) then
            e.blocked = true;
            print(chat.header('dwquest'):append(chat.color1(tintFor(took), trimmed)));
            return;
        end

        -- THE KILL FEED (see FEED_LINES above). Reached only when the reward
        -- reroute left the line alone, so a payout's own gil and exp still
        -- arrive grouped under the completion notice rather than split across
        -- two windows. No block, no print: the line is re-moded into the chat
        -- group (Window 2 on the stock config) and re-written as its cleaned
        -- text in the family's colour. Allow-list polarity, both halves: an
        -- event with no mode, or a mode that is not the pattern's own battle
        -- mode, is refused -- moving somebody else's line out of the battle
        -- log is this feature's harmful failure, not missing one.
        if (config.feed ~= false and low ~= nil) then
            for _, pattern in ipairs(FEED_LINES) do
                if (FEED_MODES[pattern] == low and trimmed:find(pattern) ~= nil) then
                    -- KEEP A LEADING CLOCK SOMEBODY ELSE PUT THERE. plainText
                    -- strips the bundled timestamp addon's stamp (it has to --
                    -- the stamp would otherwise sit inside our colour and a
                    -- two-line message wears two of them), but this branch
                    -- REWRITES rather than re-prints, so nothing puts the
                    -- stamp back the way the reward reroute's print() does.
                    -- Take it off the RAW line, with its own colour bytes, and
                    -- re-attach it in front: the clock stays the timestamp
                    -- addon's colour and the sentence gets the feed's.
                    -- (`timestamp` is not a default addon here, so this is the
                    -- narrow case -- and it is the case where the loss would
                    -- show up on feed lines only, which reads as a bug.)
                    local stamp = raw:match('^(\30.%[%d%d?:%d%d:%d%d%]\30.%s*)')
                               or raw:match('^(%[%d%d?:%d%d:%d%d%]%s*)')
                               or '';

                    e.mode_modified    = bit.bor(bit.band(mode, 0xFFFFFF00), FEED_WINDOW_MODE);
                    e.message_modified = stamp .. chat.color1(FEED_TINTS[pattern] or 106, trimmed);
                    break;
                end
            end
        end

        return;
    end

    -- THE TRIM IS ON THE REMAINDER, NOT ON THE LINE, and the order is the
    -- whole of it. Trimming first would eat the tag's own trailing space, so a
    -- line that is nothing BUT a tag would stop matching -- and a guard that
    -- cannot be reached is not a guard, it is a comment that looks like one.
    -- Trim what is left instead, and refuse when that is nothing: blocking a
    -- bare tag would swallow a line and put an empty one back.
    local said = line:sub(at + #NOTICE_TAG):gsub('%s+$', '');

    if (said == '') then
        return;
    end

    e.blocked = true;

    print(chat.header('dwquest'):append(chat.message(said)));
end);

--[[
* A login is a new character and a new account view; a zone line is a good
* moment to catch up on kills the ping may have missed. Re-sync either way --
* but only once the server has spoken this session (an automatic line against
* a dead verb is the player saying it in public).
*
* The re-ask is `hello`, not `board`: the ping arming is a local var on the
* character the server was talking to, and this is exactly the event after
* which it may no longer be there.
--]]
ashita.events.register('packet_in', 'dwquest_zonein', function (e)
    if (e.id == 0x000A) then
        state.synced      = false;
        state.offers      = { };
        state.actives     = { };
        state.activeOrder = { };
        state.balance     = nil;
        state.clockAt     = nil;
        state.status      = 'Loading...';
        state.statusBad   = false;

        -- A new zone may be a new character; the band look belongs to the
        -- session it was clicked in.
        state.viewBand   = nil;
        state.playerBand = nil;

        -- A write cannot survive the zone line it was in flight across: the
        -- answer, if there was one, went to a session that is gone.
        writePending = nil;

        -- NEITHER CAN A QUOTE, AND THAT MEANS ALL SIX OF THEM. It was priced
        -- against a character and a purse this window can no longer vouch
        -- for, and the server would refuse it anyway -- so the button goes
        -- rather than the refusal.
        --
        -- Four of the six were missing until 2026-09-06: the Exchange's and
        -- the Pop-Items' were torn up here from the day each shipped and the
        -- Outfitter's, the ArmsDealer's, the Jeweler's and the gil
        -- exchange's were not, so a player who zoned with a Confirm on
        -- screen kept it -- a live-looking button for a quote nobody was
        -- holding any more, on a storefront whose "one pending purchase per
        -- character" the window was now lying about.
        shop.synced  = false;
        shop.item    = nil;
        shop.slots   = { };
        shop.quote   = nil;

        -- AND THE PICKER'S OWN TWO CHOICES, which are about a shelf and an
        -- account this session can no longer vouch for. `picked` is an offer
        -- HANDLE off the storefront that is about to be re-read, and `who` is
        -- a character on the account that may not be this one -- the pair the
        -- gear read is built from, so leaving them was the window asking what
        -- fits an augment it had not been told about, in a bag it might not
        -- own. The typed search below them is the player's own and stays: it
        -- reaches the wire only once an offer is picked again.
        shop.picked  = nil;
        shop.who     = '';
        outfit.quote = nil;
        arms.quote   = nil;
        jewel.quote  = nil;
        gil.quote    = nil;

        -- An envelope that was open when the zone line arrived never gets
        -- its `z|`, and a verb left in `inbound` files the next stray record
        -- under a section it does not belong to -- an a| under `ping` toasts
        -- a contract nobody just advanced. The staging table goes with it:
        -- rows half-built for the character that just left must not be
        -- swapped in by a `z|` that arrives after the zone line.
        state.inbound = nil;
        arriving      = nil;

        -- The header's own numbers go with the board they described. They
        -- are re-sent by the next y|, and until then a day, a band and a
        -- pool version from the character that just left are three numbers
        -- on screen under a line that says "Loading...". The token purse is
        -- account state like the coin purse beside it and is cleared for the
        -- same reason: a new zone may be a new account.
        state.day          = nil;
        state.band         = nil;
        state.poolVersion  = nil;
        state.burstBalance = nil;

        -- The ledger describes an account too. Kept OPEN if the player had
        -- it open -- that is a preference, not data -- but emptied, so the
        -- block re-reads rather than showing the last character's lines.
        state.ledger = { };
        state.earned = nil;
        state.spent  = nil;

        -- The toast is a sentence about a contract on the board that just
        -- went away, and it outlives the zone line by up to eight seconds --
        -- so "Contract complete: Goblin +8 DC" sat over a window that said
        -- "Loading..." on a character that may not even hold it.
        state.toast   = nil;
        state.toastAt = nil;

        -- The Pop-Items shelf is static stock like the Outfitter's, but its
        -- h| purse and its quote are BAG state -- and a new zone may be a new
        -- character with a different bag. Re-read on the next look.
        pop.synced        = false;
        pop.quote         = nil;
        pop.hundreds      = nil;
        pop.types         = nil;
        popConfirmSent    = false;
        requested['pops'] = nil;

        invalidateGear();

        if (state.serverSpoke) then
            refresh('hello');
        end
    end
end);
