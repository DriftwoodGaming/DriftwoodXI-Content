--[[
* DriftwoodXI -- dwport
*
* All of Vana'diel you have earned, in one window: a tab per travel system
* -- home points, survival guides, outposts, the teleport spells -- every
* destination you have already unlocked one click away, every one you have
* not sitting greyed beside it with the reason. A Home button for the free
* !home warp, a search box over every tab, favorites and a recent list.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no truth of its own: the shipped catalog.lua is names and ids,
* and everything that varies per character -- the unlock masks, spell
* readiness, the purse -- arrives as _DWPDATA records answering `!dwp sync`
* (documentation/dwp_protocol.md). Every click issues a line a player could
* type (`!dwp go hp 12`), and the server re-checks the unlock, the travel
* gates and the fee at execution time whichever way the command arrived. A
* bug in this window cannot move a body anywhere `!port` would refuse.
*
* TYPING `!port` ON ITS OWN OPENS THIS WINDOW. The line is intercepted
* before it leaves the client; every other !port command passes through.
*
* TURN IT OFF AND NOTHING IS LOST. `!port list hp`, `!port go sg 42`,
* `!port home` all work typed. This is friendlier; it is not required.
--]]

addon.name    = 'dwport';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.4';
addon.desc    = 'Travel window for DriftwoodXI -- every teleport you have unlocked, one click away.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local theme    = require('dwtheme');
local echo     = require('dwecho');
local catalog  = require('catalog');
local settings = require('settings');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. Eight
-- other addons own eight other names; this addon must never contend for any
-- of them, which is why !dwp exists at all.
local DATA_SENDER = '_DWPDATA';

-- Bumped only for a breaking change to the record layout.
local PROTOCOL = 1;

local TAB_ORDER = { 'hp', 'sg', 'op', 'sp' };

local TAB_LABEL =
{
    hp = 'Home points',
    sg = 'Survival guides',
    op = 'Outposts',
    sp = 'Teleport',
};

-- catalog rows indexed by id, per tab, so records and clicks join in O(1).
local byId = { hp = {}, sg = {}, op = {}, sp = {} };

for _, tab in ipairs(TAB_ORDER) do
    for _, entry in ipairs(catalog[tab]) do
        byId[tab][entry.id] = entry;
    end
end

-- zone id -> home point group, for the fee preview's "free within your own
-- city" arm. Derived from the catalog so it cannot drift from it.
local zoneGroup = {};

for _, entry in ipairs(catalog.hp) do
    if entry.group ~= 0 then
        zoneGroup[entry.zone] = entry.group;
    end
end

--[[
* Persisted presentation state (plan decision P6): starred destinations,
* per character, through Ashita's settings library. Guarded throughout --
* losing favorites must never cost the window.
--]]
local defaultConfig = T{
    favorites = T{ },     -- ['hp:12'] = true
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

pcall(settings.register, 'settings', 'dwport_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end
end);

local function favKey(tab, id)
    return string.format('%s:%d', tab, id);
end

local function isFavorite(tab, id)
    return config.favorites ~= nil and config.favorites[favKey(tab, id)] == true;
end

local function toggleFavorite(tab, id)
    if (config.favorites == nil) then
        config.favorites = T{ };
    end

    local key = favKey(tab, id);

    config.favorites[key] = (not config.favorites[key]) or nil;

    pcall(settings.save);
end

local state = T{
    open      = T{ false },

    -- The truth as of the last sync. masks are the u| words; spells is
    -- keyed by spell id from s| records. `synced` gates the whole panel:
    -- rows render greyed-with-"Loading" until the first envelope lands.
    masks     = { hp = { 0, 0, 0, 0 }, sg = { 0, 0, 0, 0 }, op = 0 },
    spells    = { },     -- PLAIN table keyed by spell id (the T{} sugar trap)
    gil       = -1,
    synced    = false,

    -- The server's catalog version from y|; higher than ours = say so.
    serverCatalog = nil,

    -- True once a d| has arrived this session. Auto-syncs (zone-in) stay off
    -- until then: an unknown !command falls through to /say, and an automatic
    -- line against a dead verb is the player saying it in public.
    serverSpoke = false,

    inbound   = nil,

    -- `go`s issued and not yet answered, oldest first, each promoted to the
    -- recent list when its m| lands. A queue, not a slot: two Go clicks
    -- inside one send interval both go out, and a single slot recorded the
    -- SECOND destination against the FIRST answer (and then nothing at all
    -- for the second). `false` entries are goHome's placeholders -- they
    -- keep the answers aligned without ever reaching the recent list.
    goQueue   = T{ },
    recents   = T{ },    -- newest first, at most 5, session-only

    search    = T{ '' },

    status    = 'Loading...',
    statusBad = false,
    reported  = false,
};

--[[
* Send queue: one command per 1.2s with duplicate collapse, the client's
* chat rate limit being what it is. Same shape as dwjobs.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* Answer tracking for `sync`: ask once, retry once on a 5s silence, then
* stop and say so -- a retry that never terminates is a command loop.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

local function refresh()
    requested = {};
end

local function needSync()
    local asked = requested['sync'];

    if (asked ~= nil) then
        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            -- One-shot (dwquest's gaveUp latch): this runs inside the render
            -- loop, and re-asserted every frame it overwrote every other
            -- status the window tried to show -- including the refusal that
            -- would explain what is actually wrong.
            if (not asked.answered and not asked.gaveUp
                    and asked.tries >= ANSWER_TRIES and (os.clock() - asked.at) >= ANSWER_TIMEOUT
                    and not state.serverSpoke) then
                asked.gaveUp    = true;
                state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
                state.statusBad = true;
            end

            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['sync'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dwp sync');
end

--[[
* Record parsing.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function word(hexText)
    return tonumber(hexText or '', 16) or 0;
end

local function rememberRecent(go)
    if (go == nil) then
        return;
    end

    for at = #state.recents, 1, -1 do
        if (state.recents[at].tab == go.tab and state.recents[at].id == go.id) then
            table.remove(state.recents, at);
        end
    end

    table.insert(state.recents, 1, go);

    while (#state.recents > 5) do
        table.remove(state.recents);
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwport.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.serverSpoke = true;
        state.inbound     = parts[3];

        -- A sync replaces its whole section, and the reset runs FIRST: this
        -- runs under a pcall, and a throw after inbound is set must cost one
        -- record, not leave old rows for the ones behind it.
        if (state.inbound == 'sync') then
            state.masks  = { hp = { 0, 0, 0, 0 }, sg = { 0, 0, 0, 0 }, op = 0 };
            state.spells = { };

            local asked = requested['sync'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwport'):append(chat.error(state.status)));
            table.remove(state.goQueue, 1);
        elseif (state.inbound == 'go' or state.inbound == 'home') then
            local go = table.remove(state.goQueue, 1);

            if (go) then
                rememberRecent(go);
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        if (state.inbound == 'sync') then
            state.synced = true;

            if (state.status == 'Loading...') then
                state.status = '';
            end
        end

        state.inbound = nil;

        return;
    end

    if (kind == 'y') then
        state.serverCatalog = tonumber(parts[2]) or nil;

        return;
    end

    if (kind == 'u') then
        local set = parts[2];

        if (set == 'hp' or set == 'sg') then
            state.masks[set] = { word(parts[3]), word(parts[4]), word(parts[5]), word(parts[6]) };
        elseif (set == 'op') then
            state.masks.op = word(parts[3]);
        end

        return;
    end

    if (kind == 's') then
        local spellId = tonumber(parts[2]) or 0;

        state.spells[spellId] = {
            ki         = (parts[3] == '1'),
            casterKind = tonumber(parts[4]) or 0,
            casterName = parts[5],
            mp         = tonumber(parts[6]) or -1,
            mpCost     = tonumber(parts[7]) or 0,
            ready      = (parts[8] == '1'),
        };

        return;
    end

    if (kind == 'g') then
        state.gil = tonumber(parts[2]) or -1;

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWPDATA is ours -- consumed and blocked before parsing so
* a malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwport_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwport'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Reads over the synced state.
--]]
local function maskBit(words, index)
    return bit.band(words[math.floor(index / 32) + 1] or 0, bit.lshift(1, index % 32)) ~= 0;
end

local function hpUnlocked(entry)
    return maskBit(state.masks.hp, entry.id);
end

local function sgUnlocked(entry)
    return bit.band(state.masks.sg[entry.group] or 0, bit.lshift(1, entry.bit)) ~= 0;
end

local function opUnlocked(entry)
    return bit.band(state.masks.op, bit.lshift(1, entry.id)) ~= 0;
end

local function currentZone()
    local ok, zone = pcall(function()
        return AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0);
    end);

    if (ok and type(zone) == 'number') then
        return zone;
    end

    return -1;
end

-- The fee preview (protocol discipline 2: the catalog quotes, the server
-- recomputes; Rhapsody makes the real charge smaller, never larger).
local function hpFeeText(entry)
    local group = zoneGroup[currentZone()];

    if (group ~= nil and group == entry.group and entry.group ~= 0) then
        return 'free';
    end

    return string.format('%dg', 500 * entry.fee);
end

local function rowsFor(tab)
    local needle = tostring(state.search[1] or ''):lower():gsub('^%s+', ''):gsub('%s+$', '');
    local rows   = T{ };

    for _, entry in ipairs(catalog[tab]) do
        -- Destination and key item count too: a teleport is looked for by
        -- where it goes ("La Theine") at least as often as by its spell
        -- name, and the box promises to search every tab.
        if (needle == ''
                or entry.name:lower():find(needle, 1, true) ~= nil
                or (entry.dest ~= nil and entry.dest:lower():find(needle, 1, true) ~= nil)
                or (entry.ki ~= nil and type(entry.ki) == 'string' and entry.ki:lower():find(needle, 1, true) ~= nil)) then
            rows:append(entry);
        end
    end

    -- Favorites float, catalog order otherwise (table.sort is unstable in
    -- LuaJIT, so the order key includes the ordinal to keep it steady).
    local ordinal = {};

    for at, entry in ipairs(rows) do
        ordinal[entry] = at;
    end

    table.sort(rows, function (a, b)
        local favA = isFavorite(tab, a.id) and 0 or 1;
        local favB = isFavorite(tab, b.id) and 0 or 1;

        if (favA ~= favB) then
            return favA < favB;
        end

        return ordinal[a] < ordinal[b];
    end);

    return rows;
end

--[[
* Actions. Every one is a line a player could type.
--]]
local function goTravel(tab, id)
    issue(string.format('!dwp go %s %d', tab, id));

    state.goQueue:append({ tab = tab, id = id });
    state.status    = 'Travelling...';
    state.statusBad = false;
end

local function goHome()
    issue('!dwp home');

    -- Placeholder so home's answer consumes its own queue entry rather than
    -- the next go's.
    state.goQueue:append(false);

    state.status    = 'Off home...';
    state.statusBad = false;
end

--[[
* Rendering.
--]]
local function starButton(tab, entry)
    local starred = isFavorite(tab, entry.id);
    local label   = starred and '*' or '-';

    if (imgui.SmallButton(string.format('%s##fav_%s_%d', label, tab, entry.id))) then
        toggleFavorite(tab, entry.id);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(starred and 'Unpin from the top' or 'Pin to the top');
    end
end

local function goButton(tab, entry, feeText)
    if (imgui.SmallButton(string.format('Go  %s##go_%s_%d', feeText, tab, entry.id))) then
        goTravel(tab, entry.id);
    end
end

local function lockedRow(entry, hint)
    imgui.TextDisabled(entry.name);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(hint);
    end
end

local function hereMarker(entry)
    if (entry.zone ~= nil and entry.zone == currentZone()) then
        imgui.SameLine();
        imgui.TextDisabled('(here)');
    end
end

local function destinationTable(tab, rows)
    -- WidthFixed and the flag set the other Driftwood addons already use:
    -- only those are proven to exist in this environment's ImGui bindings.
    if (not imgui.BeginTable('##dwport_' .. tab, 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY), { -1, -1 })) then
        return;
    end

    -- The Teleport tab is the wide case, and it is wide by a long way: its
    -- name column also carries the destination, the caster and the MP cost on
    -- the same line ('Teleport-Altep -> Eastern Altepa Desert, cast by
    -- Bigholder (100 MP)'), which 268 cut off at the zone name. The other three
    -- tabs put a bare crystal or outpost name here and keep the narrower width
    -- rather than gaining a column of empty space.
    -- 'sp', not 'tp': TAB_ORDER is { 'hp', 'sg', 'op', 'sp' } and TAB_LABEL.sp
    -- is 'Teleport'. There is no 'tp' key anywhere in this addon, so this
    -- branch was dead and the wide case had silently gone back to 268 -- the
    -- exact clipping the comment above says was fixed. The window is sized 650
    -- against 22 + 470 + 120, so the two had drifted apart as well.
    local nameWidth = (tab == 'sp') and 470 or 268;

    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 22, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, nameWidth, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 120, 0);

    for _, entry in ipairs(rows) do
        imgui.TableNextRow();
        imgui.TableNextColumn();
        starButton(tab, entry);
        imgui.TableNextColumn();

        if (tab == 'hp') then
            if (hpUnlocked(entry)) then
                imgui.Text(entry.name);
                hereMarker(entry);
                imgui.TableNextColumn();
                goButton(tab, entry, hpFeeText(entry));
            else
                lockedRow(entry, 'Not attuned. Touch this crystal once and it is yours for good.');
                imgui.TableNextColumn();
            end
        elseif (tab == 'sg') then
            if (sgUnlocked(entry)) then
                imgui.Text(entry.name);
                -- No hereMarker: this tab says "(you are here)" in the button
                -- column instead (a guide cannot teleport you to itself), and
                -- both at once said the same thing twice on one row.
                imgui.TableNextColumn();

                if (entry.zone == currentZone()) then
                    imgui.TextDisabled('(you are here)');
                else
                    goButton(tab, entry, '1000g');
                end
            else
                lockedRow(entry, 'Not registered. Read the survival guide in this zone once.');
                imgui.TableNextColumn();
            end
        elseif (tab == 'op') then
            if (opUnlocked(entry)) then
                imgui.Text(entry.name);
                imgui.TableNextColumn();
                goButton(tab, entry, string.format('%dg', entry.fee));
            else
                lockedRow(entry, string.format('Locked. Level %d, and this region\'s supply run opens it.', entry.lvl));
                imgui.TableNextColumn();
            end
        else
            local live = state.spells[entry.id];

            if (live ~= nil and live.ready) then
                imgui.Text(entry.name);
                imgui.SameLine();

                if (live.casterKind == 2) then
                    imgui.TextDisabled(string.format('-> %s, cast by %s (%d MP)', entry.dest, live.casterName, live.mpCost));
                else
                    imgui.TextDisabled(string.format('-> %s (%d MP)', entry.dest, live.mpCost));
                end

                imgui.TableNextColumn();
                goButton(tab, entry, 'Cast');
            else
                local why = 'Waiting for the first sync.';

                if (live ~= nil) then
                    if (not live.ki) then
                        why = string.format('Attune the telepoint: %s.', entry.ki);
                    elseif (live.casterKind == 0) then
                        why = string.format('Nobody in your party can cast this yet -- WHM %d, spell learned.', entry.lvl);
                    else
                        why = string.format('%s needs %d MP and has %d. Rest first.', live.casterName, live.mpCost, live.mp);
                    end
                end

                lockedRow(entry, why);
                imgui.SameLine();
                imgui.TextDisabled(string.format('-> %s (WHM %d, %d MP)', entry.dest, entry.lvl, entry.mp));
                imgui.TableNextColumn();
            end
        end
    end

    imgui.EndTable();
end

local function headerRow()
    if (imgui.Button('Home##dwport_home')) then
        goHome();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Your home nation, free -- the !home warp.');
    end

    imgui.SameLine();

    if (imgui.Button('Refresh##dwport_refresh')) then
        refresh();
    end

    imgui.SameLine();
    imgui.PushItemWidth(180);
    imgui.InputTextWithHint('##dwport_search', 'search every tab', state.search, 48);
    imgui.PopItemWidth();
    imgui.SameLine();

    if (state.gil >= 0) then
        imgui.TextDisabled(string.format('%d gil', state.gil));
    else
        imgui.TextDisabled('');
    end

    if (#queue > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d queued...', #queue));
    end

    -- The recent list: the five last journeys as one-click buttons.
    if (#state.recents > 0) then
        imgui.Text('Recent:');

        for at, recent in ipairs(state.recents) do
            local entry = byId[recent.tab] ~= nil and byId[recent.tab][recent.id] or nil;

            if (entry ~= nil) then
                imgui.SameLine();

                if (imgui.SmallButton(string.format('%s##recent_%d', entry.name, at))) then
                    goTravel(recent.tab, recent.id);
                end
            end
        end
    end

    if (state.serverCatalog ~= nil and state.serverCatalog > catalog.version) then
        imgui.TextColored(theme.colors.warn, 'The server knows destinations this addon does not. Update through the launcher.');
    elseif (state.serverCatalog ~= nil and state.serverCatalog < catalog.version) then
        -- The other direction of the same drift: an addon shipped ahead of a
        -- server deploy. Without this arm every destination the newer catalog
        -- added renders as an ordinary row whose go the server refuses with a
        -- bare sentence and no explanation.
        imgui.TextColored(theme.colors.warn, 'This server is older than this addon -- some listed destinations may not exist here yet.');
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Separator();
end

local function renderWindow()
    headerRow();

    if (imgui.BeginTabBar('##dwport_tabs')) then
        for _, tab in ipairs(TAB_ORDER) do
            if (imgui.BeginTabItem(string.format('%s##dwport_tab_%s', TAB_LABEL[tab], tab))) then
                destinationTable(tab, rowsFor(tab));
                imgui.EndTabItem();
            end
        end

        imgui.EndTabBar();
    end

    needSync();
end

--[[
* The render pass: pcall'd body, Begin/End and theme push/pop outside it so
* both stacks stay balanced; an error closes the window once, loudly, and
* the typed commands remain as the fallback.
--]]
ashita.events.register('d3d_present', 'dwport_present', function ()
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    -- 650 wide: the Teleport tab's row is 22 + 470 + 120 of fixed columns, and
    -- the point of widening it is not to trade a clipped line for a horizontal
    -- scrollbar.
    imgui.SetNextWindowSize({ 650, 480 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Travel##dwport', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwport'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwport'):append(chat.message('Window closed. Everything it does also works as !port commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1]   = true;
    state.reported  = false;
    state.status    = state.synced and '' or 'Loading...';
    state.statusBad = false;

    refresh();
end

--[[
* Watch what the player sends. Bare `!port` (and ui/window/gui) toggles the
* window and never leaves the client; every other !port line passes through
* and marks our state stale, because a typed go changes the purse under the
* window. Any other outgoing line stamps the throttle -- the client's rate
* limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwport_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!port' or lower == '!port ui' or lower == '!port window' or lower == '!port gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwp') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 5) == '!port') then
        refresh();
    end
end);

ashita.events.register('command', 'dwport_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwport' and args[1] ~= '/port')) then
        return;
    end

    e.blocked = true;

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

ashita.events.register('load', 'dwport_load', function ()
    print(chat.header('dwport'):append(chat.message('/port opens the travel window. Everything it does also works typed as !port commands.')));
end);

-- A login is a new character and a new account view; a zone line changes the
-- purse and the (here) markers. Re-sync either way -- but only once the
-- server has spoken this session (protocol discipline 1: an automatic line
-- against a dead verb is the player saying it in public).
ashita.events.register('packet_in', 'dwport_zonein', function (e)
    if (e.id == 0x000A) then
        state.synced = false;
        state.masks  = { hp = { 0, 0, 0, 0 }, sg = { 0, 0, 0, 0 }, op = 0 };
        state.spells = { };
        state.gil    = -1;
        state.status = 'Loading...';
        state.statusBad = false;
        state.goQueue   = T{ };

        if (state.serverSpoke) then
            refresh();
        end
    end
end);
