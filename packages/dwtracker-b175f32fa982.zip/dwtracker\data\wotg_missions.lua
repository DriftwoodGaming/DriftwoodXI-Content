-- dwtracker data -- Wings of the Goddess missions (2026-09-30). Names from
-- the enum (scripts/globals/missions.lua, xi.mission.id.wotg); steps
-- HAND-AUTHORED from scripts/missions/wotg/*.lua as ground truth, plus what
-- those scripts hand off to: the maw global (scripts/globals/maws.lua), the
-- one real battlefield (scripts/battlefields/La_Vaule_[S]/), the Her
-- Memories quests (scripts/quests/crystalWar/Her_Memories_*.lua) and the
-- NPC rows in sql/npc_list.sql. Pure data: numeric ids and display strings
-- only, no xi.*, no functions (DWTRACKER_FORMAT.md decisions T2/§3-4).
-- Loaded byte-identically by the server module and the dwtracker addon;
-- both hash these bytes, so an edit that reaches only one side makes the
-- addon refuse step rendering for this area until the copies agree again.
-- tools/dwtracker_lint.py must pass before any edit here ships.
--
-- SIX THINGS ABOUT THE WotG LOG THAT SHAPE EVERY ENTRY BELOW:
--
-- 1. PROGRESS MOSTLY LIVES IN THE MISSION'S OWN CONTAINER, NOT THE LOG
--    WORD. Only six entries (3, 6, 8, 9, 11, 13) call setMissionStatus(5);
--    the rest count in Mission[5][<id>]Status (or Prog, or Proof of
--    Valor's Option), which the `var` atom reads for the entry being
--    evaluated. Mission:complete zeroes the log word AND cleans the
--    container (interaction/mission.lua), so every threshold below is about
--    the mission that is current, and every var starts clean.
--
-- 2. NINE FIGHTS DO NOT EXIST, AND THE STEPS SAY WHAT YOU DO INSTEAD.
--    Upstream scripted entries 13, 22, 23, 30, 31, 32, 36, 45 and 50
--    (journal 14/23/24/31/32/33/37/46/51) around instances and battlefields
--    it never built. By owner decision (2026-09-24, PLANS/CONTENT_STATUS.md
--    §7) the entry NPC, examined in the exact stuck state with the entry key
--    item, does what the missing clear handler would -- same var write, key
--    item spent, same exit setPos -- and the ordinary zone-in scene then
--    finishes. Those steps tell you to examine the door, not to win a fight.
--    Purple, The New Black (6) is the one real battlefield in the line.
--
-- 3. THE CRYSTAL WAR GATES ARE OPEN. Every meetsMissionNReqs helper answers
--    true here (modules/custom/lua/wotg_decouple_story_missions_from_
--    nation_quests.lua), so no step asks for a nation quest -- and Campaign,
--    Allied Notes and the Arbiter teleports, absent on this server, are
--    never needed.
--
-- 4. MANY STATES ARE ONLY A ZONE-IN SCENE WAITING TO PLAY. A lot of these
--    missions end in a setPos into the same zone and a chain of onZoneIn
--    cutscenes keyed on the var. A step parked on one of those says "zone
--    back in if it did not play", because re-entering is what replays it.
--
-- 5. UNORDERED SETS. Traitor in the Midst's five pawprints are bits of one
--    var, readable only whole (31). Her Memories' four fragments come from
--    four Crystal War quests and 41_Her_Memories.lua names none of them, so
--    no atom can be checked against its script: one step. Fork in the Road's
--    seven dawndrops ARE named in its script, and are walked in route order:
--    step k is "you hold this dawndrop and every one before it", so the
--    bright step is always one you still lack, whatever order you gather
--    them in; the anyOf with mission 50 keeps the deletion at completion
--    from un-doing them. Timer, the other Options and must-zone flags are
--    not progress and are read nowhere.
--
-- 6. THE LOG RESTS ON 53, AND 50-53 REPEAT. Lest We Forget never calls
--    mission:complete. Its ??? (qm_reset) delMissions 50-53 and re-grants
--    Maiden of the Dusk at Status 2 with a fresh Primal Glow, so a repeat
--    reads straight past 50's first step; 51 and 52 were cleaned at their
--    first completion and start from nothing; 52's completion writes 53's
--    Status 1 and claiming the earring writes 0. Every path into those four
--    entries writes the var they read (FORMAT §6.8.1).
--
-- AND ONE THING THE ADDON DOES WITH THESE HINTS: the waypoint matches a
-- label word by word as a prefix, so "Batallia Downs" also matches Batallia
-- Downs [S] and vice versa. The maws and the Humus-rich Earth stand at the
-- same coordinates in both eras, which is why their hints name one.
return {
    kind = 'missions',
    log = 5,
    area = 'wotg_missions',
    label = "Wings of the Goddess",
    entries = {
        [0] = { -- CAVERNOUS_MAWS (M1)
            name = "Cavernous Maws",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    -- The log idles at 0 from character creation
                    -- (char_entity.cpp), and 0 IS this mission.
                    text = "Touch a Cavernous Maw in Batallia Downs, Rolanberry Fields or Sauromugue Champaign. The scene gives you the Pure White Feather and sends you through to one of the three maws in the past.",
                    pos  = "Batallia Downs (!pos -48 0.1 435) / Rolanberry Fields (!pos -198 8 361) / Sauromugue Champaign (!pos 369 8 -227)",
                },
            },
        },
        [1] = { -- BACK_TO_THE_BEGINNING (M2)
            name = "Back to the Beginning",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Touch any of the six Cavernous Maws -- Batallia, Rolanberry or Sauromugue, present or past. The scene gives you the Lightsworm and sends you through to the other side.",
                    pos  = "Batallia Downs (!pos -48 0.1 435) / Rolanberry Fields (!pos -198 8 361) / Sauromugue Champaign (!pos 369 8 -227)",
                },
            },
        },
        [2] = { -- CAIT_SITH (M3)
            name = "Cait Sith",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Walk from East Ronfaure [S] into Southern San d'Oria [S]. The scene as you enter the city is the whole mission.",
                    pos  = "Southern San d'Oria [S]",
                },
            },
        },
        [3] = { -- THE_QUEEN_OF_THE_DANCE (M4)
            name = "The Queen of the Dance",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Lion Springs door in Southern San d'Oria [S]. You are turned away without a ticket, and that is the point.",
                    pos  = "Southern San d'Oria [S], Lion Springs door (!pos 96 0 106)",
                    done = { missionStatus = { 5, gte = 1 } },
                },
                {
                    text = "Go back to the present and talk to Turlough in Upper Jeuno. He hands you the Mayakov Show Ticket.",
                    pos  = "Upper Jeuno, Turlough (!pos -58.697 0.000 103.553)",
                    done = { missionStatus = { 5, gte = 2 } },
                },
                {
                    text = "Take the ticket to the Lion Springs door. The scenes that follow play one after another and end the mission; zone back into Southern San d'Oria [S] if they stop.",
                    pos  = "Southern San d'Oria [S], Lion Springs door (!pos 96 0 106)",
                },
            },
        },
        [4] = { -- WHILE_THE_CAT_IS_AWAY (M5)
            name = "While the Cat is Away",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Walk out of Southern San d'Oria [S] into East Ronfaure [S]. The scene as you arrive is the whole mission.",
                    pos  = "East Ronfaure [S]",
                },
            },
        },
        [5] = { -- A_TIMESWEPT_BUTTERFLY (M6)
            name = "A Timeswept Butterfly",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Walk from Jugner Forest [S] into La Vaule [S]. The scene as you arrive is the whole mission.",
                    pos  = "La Vaule [S]",
                },
            },
        },
        [6] = { -- PURPLE_THE_NEW_BLACK (M7)
            name = "Purple, The New Black",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Reinforced Gateway in La Vaule [S] for the scene.",
                    pos  = "La Vaule [S], Reinforced Gateway (!pos -114.386 -3.599 -179.804)",
                    done = { missionStatus = { 5, gte = 1 } },
                },
                {
                    -- A real battlefield: scripts/battlefields/La_Vaule_[S]/
                    -- purple_the_new_black.lua, entered at missionStatus 1.
                    text = "Enter the battlefield through the same gateway and defeat Galarhigg. Up to six, trusts allowed, 30 minutes.",
                    pos  = "La Vaule [S], Reinforced Gateway (!pos -114.386 -3.599 -179.804)",
                    done = { missionStatus = { 5, gte = 2 } },
                },
                {
                    text = "The scene as you are set back down in La Vaule [S] ends the mission; zone back in if it did not play.",
                    pos  = "La Vaule [S]",
                },
            },
        },
        [7] = { -- IN_THE_NAME_OF_THE_FATHER (M8)
            name = "In the Name of the Father",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Lion Springs door in Southern San d'Oria [S]. The scene is the whole mission.",
                    pos  = "Southern San d'Oria [S], Lion Springs door (!pos 96 0 106)",
                },
            },
        },
        [8] = { -- DANCERS_IN_DISTRESS (M9)
            name = "Dancers in Distress",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Talk to Raustigne in Southern San d'Oria [S].",
                    pos  = "Southern San d'Oria [S], Raustigne (!pos 3.979 -1.999 44.456)",
                    done = { missionStatus = { 5, gte = 1 } },
                },
                {
                    text = "Examine the Elegant Footprints in Jugner Forest [S] and sit the dance troupe's quiz. It ends by naming the item you must bring.",
                    pos  = "Jugner Forest [S], Elegant Footprints (!pos 46.387 0.117 318.210)",
                    done = { missionStatus = { 5, gte = 2 } },
                },
                {
                    -- Which of the three is stored in `Option`; there is no
                    -- atom for "the one they named", so the text lists all.
                    text = "Zone out and back, then trade the footprints the item they named: Lynx Meat, a Gold Beastcoin or a Nyumomo Doll. Examine them again if you forget which.",
                    pos  = "Jugner Forest [S], Elegant Footprints (!pos 46.387 0.117 318.210)",
                },
            },
        },
        [9] = { -- DAUGHTER_OF_A_KNIGHT (M10)
            name = "Daughter of a Knight",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Talk to Amaura in present-day Southern San d'Oria.",
                    pos  = "Southern San d'Oria, Amaura (!pos -84.367 -6.949 91.148)",
                    done = { missionStatus = { 5, gte = 1 } },
                },
                {
                    text = "Trade Amaura a Cernunnos Bulb -- the trade only shows it, and you keep it. Wandering Saplings in Jugner Forest [S] drop them.",
                    pos  = "Southern San d'Oria, Amaura (!pos -84.367 -6.949 91.148)",
                    done = { missionStatus = { 5, gte = 2 } },
                },
                {
                    text = "Plant the bulb: trade it to the Humus-rich Earth by the spring in Jugner Forest [S].",
                    pos  = "Jugner Forest [S], Humus-rich Earth (!pos -510.535 7.568 289.283)",
                    done = { missionStatus = { 5, gte = 3 } },
                },
                {
                    text = "Go back to the present and examine the Humus-rich Earth at the same spot in Jugner Forest.",
                    pos  = "Jugner Forest, Humus-rich Earth (!pos -510.535 7.568 289.283)",
                    done = { missionStatus = { 5, gte = 4 } },
                },
                {
                    text = "Examine the earth again to call up Cernunnos and defeat it, then examine it once more for the scene and the Cernunnos Resin.",
                    pos  = "Jugner Forest, Humus-rich Earth (!pos -510.535 7.568 289.283)",
                    done = { missionStatus = { 5, gte = 5 } },
                },
                {
                    text = "Take the resin to Amaura in Southern San d'Oria.",
                    pos  = "Southern San d'Oria, Amaura (!pos -84.367 -6.949 91.148)",
                    done = { missionStatus = { 5, gte = 6 } },
                },
                {
                    text = "Let a Vana'diel day pass, zone out and back, then talk to Amaura again for the Bottle of Treant Tonic. Asking early means zoning out and back before you can ask again.",
                    pos  = "Southern San d'Oria, Amaura (!pos -84.367 -6.949 91.148)",
                },
            },
        },
        [10] = { -- A_SPOONFUL_OF_SUGAR (M11)
            name = "A Spoonful of Sugar",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Talk to Raustigne in Southern San d'Oria [S]. The scene is the whole mission.",
                    pos  = "Southern San d'Oria [S], Raustigne (!pos 3.979 -1.999 44.456)",
                },
            },
        },
        [11] = { -- AFFAIRS_OF_STATE (M12)
            name = "Affairs of State",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Talk to Velda-Galda in Windurst Waters [S] or Radford in Bastok Markets [S] -- either one first.",
                    pos  = "Windurst Waters [S], Velda-Galda (!pos 138.631 -2.112 61.658) / Bastok Markets [S], Radford (!pos -205.303 -8 26.874)",
                    done = { missionStatus = { 5, gte = 1 } },
                },
                {
                    -- Which one came first is `WindurstFirst`; the text
                    -- names both rather than read a dialogue branch.
                    text = "Now talk to the other one. The second scene hands you Count Borel's Letter and ends the mission.",
                    pos  = "Windurst Waters [S], Velda-Galda (!pos 138.631 -2.112 61.658) / Bastok Markets [S], Radford (!pos -205.303 -8 26.874)",
                },
            },
        },
        [12] = { -- BORNE_BY_THE_WIND (M13)
            name = "Borne by the Wind",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Bulwark Gate in Sauromugue Champaign [S]. The long scene there ends the mission and hands you the Underpass Hatch Key.",
                    pos  = "Sauromugue Champaign [S], Bulwark Gate (!pos -447.174 -1.831 342.417)",
                },
            },
        },
        [13] = { -- A_NATION_ON_THE_BRINK (M14)
            name = "A Nation on the Brink",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Underpass Hatch in one of the towers in Batallia Downs [S]. No key? The Bulwark Gate in Sauromugue Champaign [S] issues the Underpass Hatch Key.",
                    pos  = "Batallia Downs [S], Underpass Hatch (!pos 314.083 -1.160 -181.455)",
                    done = { missionStatus = { 5, gte = 1 } },
                },
                {
                    -- PASS-THROUGH (Everbloom Hollow instance unbuilt):
                    -- 14_A_Nation_on_the_Brink.lua, the hatch at status 1.
                    text = "Examine the hatch again holding the key. The Everbloom Hollow battle is not on this server, so that spends the key and passes you straight through.",
                    pos  = "Batallia Downs [S], Underpass Hatch (!pos 314.083 -1.160 -181.455)",
                    done = { missionStatus = { 5, gte = 2 } },
                },
                {
                    text = "A chain of scenes follows as you are moved about Batallia Downs [S]; the last ends the mission. Zone back into Batallia Downs [S] if they stop.",
                    pos  = "Batallia Downs [S]",
                },
            },
        },
        [14] = { -- CROSSROADS_OF_TIME (M15)
            name = "Crossroads of Time",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Walk from East Ronfaure [S] into Southern San d'Oria [S]. The scene as you enter the city is the whole mission.",
                    pos  = "Southern San d'Oria [S]",
                },
            },
        },
        [15] = { -- SANDSWEPT_MEMORIES (M16)
            name = "Sandswept Memories",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Lion Springs door in Southern San d'Oria [S]. The scene is the whole mission.",
                    pos  = "Southern San d'Oria [S], Lion Springs door (!pos 96 0 106)",
                },
            },
        },
        [16] = { -- NORTHLAND_EXPOSURE (M17)
            name = "Northland Exposure",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Travel to Beaucedine Glacier [S]. The scene as you arrive ends the mission and leaves you the Shadow Bug.",
                    pos  = "Beaucedine Glacier [S]",
                },
            },
        },
        [17] = { -- TRAITOR_IN_THE_MIDST (M18)
            name = "Traitor in the Midst",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    -- `Status` is a bitfield (bits 0-4, one per pawprint),
                    -- so only all five -- 31 -- is readable. Coordinates are
                    -- npc_list's Regal_Pawprints_3..7, rounded to fit.
                    text = "Find five sets of Regal Pawprints around Beaucedine Glacier [S] and pass the small test each one sets. A failed test can simply be tried again.",
                    pos  = "Beaucedine Glacier [S] (!pos -24 -60 -72)/(!pos 96 -20 128)/(!pos -168 -40 -224)/(!pos 272 0 -24)/(!pos -330 -100 130)",
                    done = { var = 'Status', gte = 31 },
                },
                {
                    text = "Examine the last set of Regal Pawprints for the scene that ends the mission.",
                    pos  = "Beaucedine Glacier [S], Regal Pawprints (!pos 53.812 0.307 -299.136)",
                },
            },
        },
        [18] = { -- BETRAYAL_AT_BEAUCEDINE (M19)
            name = "Betrayal at Beaucedine",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Regal Pawprints in Beaucedine Glacier [S] for the scene.",
                    pos  = "Beaucedine Glacier [S], Regal Pawprints (!pos -15.066 -40.249 -217.276)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Examine them again to call out Count Halphas, and defeat him.",
                    pos  = "Beaucedine Glacier [S], Regal Pawprints (!pos -15.066 -40.249 -217.276)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Examine the pawprints once more for the next scene.",
                    pos  = "Beaucedine Glacier [S], Regal Pawprints (!pos -15.066 -40.249 -217.276)",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "The scene as you are set down beside them ends the mission; zone back into Beaucedine Glacier [S] if it did not play.",
                    pos  = "Beaucedine Glacier [S]",
                },
            },
        },
        [19] = { -- ON_THIN_ICE (M20)
            name = "On Thin Ice",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Talk to Raustigne in Southern San d'Oria [S]. The scene is the whole mission.",
                    pos  = "Southern San d'Oria [S], Raustigne (!pos 3.979 -1.999 44.456)",
                },
            },
        },
        [20] = { -- PROOF_OF_VALOR (M21)
            name = "Proof of Valor",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    -- `Option` here is NOT a dialogue toggle: it is the
                    -- signature tally, raised only by incrementVar and
                    -- cleaned at completion, and Raustigne's own gate is
                    -- `Option < 20`.
                    text = "Collect at least 20 signatures from the knights around Southern San d'Oria [S]; some want a quiz answered or an item. More signatures earn a better reward.",
                    pos  = "Southern San d'Oria [S]",
                    done = { var = 'Option', gte = 20 },
                },
                {
                    text = "Hand the petition to Raustigne. Decline when asked and you have to zone out and back before trying again.",
                    pos  = "Southern San d'Oria [S], Raustigne (!pos 3.979 -1.999 44.456)",
                },
            },
        },
        [21] = { -- A_SANGUINARY_PRELUDE (M22)
            name = "A Sanguinary Prelude",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Go back to Beaucedine Glacier [S]. The scene as you arrive ends the mission and leaves you the Aroma Bug.",
                    pos  = "Beaucedine Glacier [S]",
                },
            },
        },
        [22] = { -- DUNGEONS_AND_DANCERS (M23)
            name = "Dungeons and Dancers",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Regal Pawprints in Beaucedine Glacier [S] for the scene.",
                    pos  = "Beaucedine Glacier [S], Regal Pawprints (!pos -145.266 -61.851 -174.171)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- PASS-THROUGH (Everbloom Hollow instance unbuilt):
                    -- Regal_Pawprints_8 at Status 1; Regal_Pawprints_1
                    -- re-issues the bug.
                    text = "Examine them again holding the Aroma Bug. The Everbloom Hollow battle is not on this server, so that spends the bug and passes you through. The pawprints that ended Traitor in the Midst re-issue it.",
                    pos  = "Beaucedine Glacier [S], Regal Pawprints (!pos -145.266 -61.851 -174.171)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "The scene as you are set down beside them ends the mission and leaves you the Umbra Bug; zone back into Beaucedine Glacier [S] if it did not play.",
                    pos  = "Beaucedine Glacier [S]",
                },
            },
        },
        [23] = { -- DISTORTER_OF_TIME (M24)
            name = "Distorter of Time",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    -- PASS-THROUGH (Ruhotz Silvermines instance unbuilt):
                    -- Regal_Pawprints_9 at Status 0 with the Umbra Bug.
                    text = "Examine the Regal Pawprints holding the Umbra Bug. The Ruhotz Silvermines battle is not on this server, so that spends the bug and passes you through. The pawprints that ended Traitor in the Midst re-issue it.",
                    pos  = "Beaucedine Glacier [S], Regal Pawprints (!pos 54.437 -41.904 104.974)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene as you are set down beside them ends the mission; zone back into Beaucedine Glacier [S] if it did not play.",
                    pos  = "Beaucedine Glacier [S]",
                },
            },
        },
        [24] = { -- THE_WILL_OF_THE_WORLD (M25)
            name = "The Will of the World",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Talk to Raustigne in Southern San d'Oria [S]. The scene is the whole mission.",
                    pos  = "Southern San d'Oria [S], Raustigne (!pos 3.979 -1.999 44.456)",
                },
            },
        },
        [25] = { -- FATE_IN_HAZE (M26)
            name = "Fate in Haze",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Lion Springs door in Southern San d'Oria [S].",
                    pos  = "Southern San d'Oria [S], Lion Springs door (!pos 96 0 106)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Two more scenes play one after another; the second ends the mission. Zone back into Southern San d'Oria [S] if they stop.",
                    pos  = "Southern San d'Oria [S]",
                },
            },
        },
        [26] = { -- THE_SCENT_OF_BATTLE (M27)
            name = "The Scent of Battle",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Bulwark Gate in Sauromugue Champaign [S]. The scene is the whole mission.",
                    pos  = "Sauromugue Champaign [S], Bulwark Gate (!pos -447.174 -1.831 342.417)",
                },
            },
        },
        [27] = { -- ANOTHER_WORLD (M28)
            name = "Another World",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Back in the present, walk from East Ronfaure into Southern San d'Oria for the scene.",
                    pos  = "Southern San d'Oria",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Talk to Halver inside Chateau d'Oraguille.",
                    pos  = "Chateau d'Oraguille, Halver (!pos 2 0.1 0.1)",
                },
            },
        },
        [28] = { -- A_HAWK_IN_REPOSE (M29)
            name = "A Hawk in Repose",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Weathered Gravestone in present-day Batallia Downs.",
                    pos  = "Batallia Downs, Weathered Gravestone (!pos 149.728 -5.109 -395.121)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Trade the gravestone a Lilac -- Areebah in Upper Jeuno and Dabih Jajalioh in Ru'Lude Gardens sell them. That ends the mission.",
                    pos  = "Batallia Downs, Weathered Gravestone (!pos 149.728 -5.109 -395.121)",
                },
            },
        },
        [29] = { -- THE_BATTLE_OF_XARCABARD (M30)
            name = "The Battle of Xarcabard",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Travel to Xarcabard [S]. The scene fires as you arrive.",
                    pos  = "Xarcabard [S]",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Report to Rally Point: Red for the scene that ends the mission.",
                    pos  = "Xarcabard [S], Rally Point: Red (!pos -106.071 -25.5 -52.841)",
                },
            },
        },
        [30] = { -- PRELUDE_TO_A_STORM (M31)
            name = "Prelude to a Storm",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Report to Rally Point: Green in Xarcabard [S]. The scene hands you the Magelight Signal Flare.",
                    pos  = "Xarcabard [S], Rally Point: Green (!pos 54.013 -23.402 -203.103)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- PASS-THROUGH (Ghoyu's Reverie instance unbuilt):
                    -- Spell-worked_Snow at Status 1 with the flare.
                    text = "Examine the Spell-worked Snow behind it holding the flare. The Ghoyu's Reverie battle is not on this server, so that spends the flare and passes you through. Rally Point: Green re-issues a lost flare.",
                    pos  = "Xarcabard [S], Spell-worked Snow (!pos 75.989 -24.249 -248.089)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "The scene as you are set down pays an Elixir and ends the mission. With no free slot it waits: make room and zone back into Xarcabard [S].",
                    pos  = "Xarcabard [S]",
                },
            },
        },
        [31] = { -- STORMS_CRESCENDO (M32)
            name = "Storm's Crescendo",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Report to Rally Point: Blue in Xarcabard [S]. The scene hands you the Alchemical Signal Flare.",
                    pos  = "Xarcabard [S], Rally Point: Blue (!pos 135.783 -17.151 -23.819)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- PASS-THROUGH (Ghoyu's Reverie instance unbuilt):
                    -- Excavated_Snow at Status 1 with the flare.
                    text = "Examine the Excavated Snow nearby holding the flare. The Ghoyu's Reverie battle is not on this server, so that spends the flare and passes you through. Rally Point: Blue re-issues a lost flare.",
                    pos  = "Xarcabard [S], Excavated Snow (!pos 147.791 -17.644 -14.919)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "The scene as you are set down follows; zone back into Xarcabard [S] if it did not play.",
                    pos  = "Xarcabard [S]",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    text = "Report to Rally Point: Red.",
                    pos  = "Xarcabard [S], Rally Point: Red (!pos -106.071 -25.5 -52.841)",
                    done = { var = 'Status', gte = 4 },
                },
                {
                    text = "The scene as you are moved ends the mission; zone back into Xarcabard [S] if it did not play.",
                    pos  = "Xarcabard [S]",
                },
            },
        },
        [32] = { -- INTO_THE_BEASTS_MAW (M33)
            name = "Into the Beast's Maw",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Make your way into Castle Zvahl Baileys [S]. The scene fires as you arrive.",
                    pos  = "Castle Zvahl Baileys [S]",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Examine the Peculiar Glint. The scenes that follow hand you the Distress Signal Flare; zone back into Castle Zvahl Baileys [S] if they stop.",
                    pos  = "Castle Zvahl Baileys [S], Peculiar Glint (!pos 179.439 -24.056 100.032)",
                    done = { var = 'Status', gte = 4 },
                },
                {
                    -- PASS-THROUGH (Ghoyu's Reverie instance unbuilt):
                    -- Peculiar_Glint at Status 4 with the flare.
                    text = "Examine the glint again holding the flare. The Ghoyu's Reverie battle is not on this server, so that spends the flare and passes you through. The Ornate Block beside it re-issues a lost flare.",
                    pos  = "Castle Zvahl Baileys [S], Peculiar Glint (!pos 179.439 -24.056 100.032)",
                    done = { var = 'Status', gte = 5 },
                },
                {
                    text = "The scene as you are set down ends the mission; zone back into Castle Zvahl Baileys [S] if it did not play.",
                    pos  = "Castle Zvahl Baileys [S]",
                },
            },
        },
        [33] = { -- THE_HUNTER_ENSNARED (M34)
            name = "The Hunter Ensnared",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Report to Rally Point: Red in Xarcabard [S]. The scene is the whole mission.",
                    pos  = "Xarcabard [S], Rally Point: Red (!pos -106.071 -25.5 -52.841)",
                },
            },
        },
        [34] = { -- FLIGHT_OF_THE_LION (M35)
            name = "Flight of the Lion",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Bulwark Gate in Sauromugue Champaign [S]. The scene is the whole mission.",
                    pos  = "Sauromugue Champaign [S], Bulwark Gate (!pos -447.174 -1.831 342.417)",
                },
            },
        },
        [35] = { -- FALL_OF_THE_HAWK (M36)
            name = "Fall of the Hawk",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Go back into Castle Zvahl Baileys [S]. The scene as you arrive is the whole mission.",
                    pos  = "Castle Zvahl Baileys [S]",
                },
            },
        },
        [36] = { -- DARKNESS_DESCENDS (M37)
            name = "Darkness Descends",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Make your way into the Throne Room [S]. The scene fires as you arrive.",
                    pos  = "Throne Room [S]",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- PASS-THROUGH (battlefield 353 unbuilt): _4c1 at
                    -- Status 1.
                    text = "Examine the Throne Room door. The battle behind it is not on this server, so that passes you straight through.",
                    pos  = "Throne Room [S], door (!pos -115.849 -8.657 0.000)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "The scene as you are set down ends the mission; zone back into the Throne Room [S] if it did not play.",
                    pos  = "Throne Room [S]",
                },
            },
        },
        [37] = { -- ADIEU_LILISETTE (M38)
            name = "Adieu, Lilisette",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Lion Springs door in Southern San d'Oria [S]. The scene is the whole mission.",
                    pos  = "Southern San d'Oria [S], Lion Springs door (!pos 96 0 106)",
                },
            },
        },
        [38] = { -- BY_THE_FADING_LIGHT (M39)
            name = "By the Fading Light",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Report to Rally Point: Red in Xarcabard [S]. The scene is the whole mission.",
                    pos  = "Xarcabard [S], Rally Point: Red (!pos -106.071 -25.5 -52.841)",
                },
            },
        },
        [39] = { -- EDGE_OF_EXISTENCE (M40)
            name = "Edge of Existence",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Touch any of the six Cavernous Maws, present or past. The scene ends the mission and sends you through to the other side.",
                    pos  = "Batallia Downs (!pos -48 0.1 435) / Rolanberry Fields (!pos -198 8 361) / Sauromugue Champaign (!pos 369 8 -227)",
                },
            },
        },
        [40] = { -- HER_MEMORIES (M41)
            name = "Her Memories",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    -- Completed by xi.wotg.helpers.checkMemoryFragments the
                    -- moment the fourth fragment lands. Fragment 4 is Azure
                    -- Footfalls for Bastok's allegiance and Carnelian for
                    -- everyone else (Verdure Footfalls is unscripted).
                    text = "Earn four memory fragments from the Her Memories quests: Homecoming Queen, Of Malign Maladies (Amaura), Operation Cupid (Batallia Downs [S]), and Azure Footfalls if Bastok-pledged, else Carnelian.",
                    pos  = "Southern San d'Oria, Amaura (!pos -84.367 -6.949 91.148)",
                },
            },
        },
        [41] = { -- FORGET_ME_NOT (M42)
            name = "Forget Me Not",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Touch any of the six Cavernous Maws, present or past. The scene carries you off to Grauberg [S].",
                    pos  = "Batallia Downs (!pos -48 0.1 435) / Rolanberry Fields (!pos -198 8 361) / Sauromugue Champaign (!pos 369 8 -227)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene as you arrive in Grauberg [S] sends you back through the maw; zone back into Grauberg [S] if it did not play.",
                    pos  = "Grauberg [S]",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Arriving back at the maw ends the mission. If it did not, walk into Batallia Downs, Rolanberry Fields or Sauromugue Champaign, present or past.",
                },
            },
        },
        [42] = { -- PILLAR_OF_HOPE (M43)
            name = "Pillar of Hope",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Put your weapons away, main and sub, then touch the Veridical Conflux in Grauberg [S]. If the scene ends without finishing the mission, touch it again.",
                    pos  = "Grauberg [S], Veridical Conflux (!pos -142.279 -6.749 585.239)",
                },
            },
        },
        [43] = { -- GLIMMER_OF_LIFE (M44)
            name = "Glimmer of Life",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Let a Vana'diel day pass, zone out and back, then touch the Veridical Conflux in Grauberg [S] again. Until then it does nothing.",
                    pos  = "Grauberg [S], Veridical Conflux (!pos -142.279 -6.749 585.239)",
                },
            },
        },
        [44] = { -- TIME_SLIPS_AWAY (M45)
            name = "Time Slips Away",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Get a Punch Bug. Quadav in Pashhow Marshlands [S] and Beadeaux [S] drop them.",
                    done = { item = 2977 }, -- PUNCH_BUG
                },
                {
                    text = "Trade the Punch Bug to the Veridical Conflux in Grauberg [S]. It comes back bottled, and the mission ends.",
                    pos  = "Grauberg [S], Veridical Conflux (!pos -142.279 -6.749 585.239)",
                },
            },
        },
        [45] = { -- WHEN_WILLS_COLLIDE (M46)
            name = "When Wills Collide",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Touch the Veridical Conflux in Grauberg [S] with the Bottled Punch Bug to go through to the Walk of Echoes, then examine the Ornate Door there.",
                    pos  = "Grauberg [S], Veridical Conflux (!pos -142.279 -6.749 585.239) / Walk of Echoes (!pos -700 -20.25 -303.398)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    -- PASS-THROUGH (battlefield unbuilt): _521 at Status 1
                    -- with the Bottled Punch Bug.
                    text = "Examine the door again holding the bottled bug. The battle is not on this server, so that spends the bug and passes you through. Lost it? Trade the Conflux a Punch Bug for another.",
                    pos  = "Walk of Echoes, Ornate Door (!pos -700 -20.25 -303.398)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "The scene as you are set down ends the mission. If it did not play, go back in through the Conflux -- which again takes a bottled Punch Bug.",
                    pos  = "Walk of Echoes",
                },
            },
        },
        [46] = { -- WHISPERS_OF_DAWN (M47)
            name = "Whispers of Dawn",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Put your weapons away, main and sub, then touch the Veridical Conflux in Grauberg [S]. If the scene ends without finishing the mission, touch it again.",
                    pos  = "Grauberg [S], Veridical Conflux (!pos -142.279 -6.749 585.239)",
                },
            },
        },
        [47] = { -- A_DREAMY_INTERLUDE (M48)
            name = "A Dreamy Interlude",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Let a Vana'diel day pass, zone out and back, then touch the Veridical Conflux in Grauberg [S]. Touching it early only plays a reminder.",
                    pos  = "Grauberg [S], Veridical Conflux (!pos -142.279 -6.749 585.239)",
                },
            },
        },
        [48] = { -- CAIT_IN_THE_WOODS (M49)
            name = "Cait in the Woods",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the nameless target at this spot in East Ronfaure [S]. Cait Sith's scene ends the mission and leaves you the Ronfaure Dawndrop.",
                    pos  = "East Ronfaure [S] (!pos 221.857 -49.213 176.24)",
                },
            },
        },
        [49] = { -- FORK_IN_THE_ROAD (M50)
            name = "Fork in the Road",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    -- Route order, not script order: see header item 5.
                    -- Mission 50 reached is the state that survives the
                    -- dawndrops' deletion at completion.
                    text = "Seven nameless targets each hold a dawndrop, one per zone, taken in any order. Examine the one in Jugner Forest [S].",
                    pos  = "Jugner Forest [S] (!pos 46.333 0.189 309.025)",
                    done = {
                        anyOf = {
                            { ki = 1724 }, -- JUGNER_DAWNDROP
                            { mission = { 5, 50 } },
                        },
                    },
                },
                {
                    text = "Take the dawndrop in La Vaule [S].",
                    pos  = "La Vaule [S] (!pos 294.982 3.497 -217.001)",
                    done = {
                        anyOf = {
                            {
                                allOf = {
                                    { ki = 1724 }, -- JUGNER_DAWNDROP
                                    { ki = 1723 }, -- LA_VAULE_DAWNDROP
                                },
                            },
                            { mission = { 5, 50 } },
                        },
                    },
                },
                {
                    text = "Take the dawndrop in Southern San d'Oria [S].",
                    pos  = "Southern San d'Oria [S] (!pos 89.343 0.999 99.789)",
                    done = {
                        anyOf = {
                            {
                                allOf = {
                                    { ki = 1724 }, -- JUGNER_DAWNDROP
                                    { ki = 1723 }, -- LA_VAULE_DAWNDROP
                                    { ki = 1729 }, -- SAN_DORIA_DAWNDROP
                                },
                            },
                            { mission = { 5, 50 } },
                        },
                    },
                },
                {
                    text = "Take the dawndrop in Beaucedine Glacier [S].",
                    pos  = "Beaucedine Glacier [S] (!pos -69.917 -39.928 -192.761)",
                    done = {
                        anyOf = {
                            {
                                allOf = {
                                    { ki = 1724 }, -- JUGNER_DAWNDROP
                                    { ki = 1723 }, -- LA_VAULE_DAWNDROP
                                    { ki = 1729 }, -- SAN_DORIA_DAWNDROP
                                    { ki = 1725 }, -- BEAUCEDINE_DAWNDROP
                                },
                            },
                            { mission = { 5, 50 } },
                        },
                    },
                },
                {
                    text = "Take the dawndrop in Xarcabard [S].",
                    pos  = "Xarcabard [S] (!pos -108.315 -25.605 -52.978)",
                    done = {
                        anyOf = {
                            {
                                allOf = {
                                    { ki = 1724 }, -- JUGNER_DAWNDROP
                                    { ki = 1723 }, -- LA_VAULE_DAWNDROP
                                    { ki = 1729 }, -- SAN_DORIA_DAWNDROP
                                    { ki = 1725 }, -- BEAUCEDINE_DAWNDROP
                                    { ki = 1726 }, -- XARCABARD_DAWNDROP
                                },
                            },
                            { mission = { 5, 50 } },
                        },
                    },
                },
                {
                    text = "Take the dawndrop in the Throne Room [S].",
                    pos  = "Throne Room [S] (!pos 19.003 0 -4.487)",
                    done = {
                        anyOf = {
                            {
                                allOf = {
                                    { ki = 1724 }, -- JUGNER_DAWNDROP
                                    { ki = 1723 }, -- LA_VAULE_DAWNDROP
                                    { ki = 1729 }, -- SAN_DORIA_DAWNDROP
                                    { ki = 1725 }, -- BEAUCEDINE_DAWNDROP
                                    { ki = 1726 }, -- XARCABARD_DAWNDROP
                                    { ki = 1727 }, -- THRONE_ROOM_DAWNDROP
                                },
                            },
                            { mission = { 5, 50 } },
                        },
                    },
                },
                {
                    text = "Take the dawndrop in the Walk of Echoes -- the Veridical Conflux in Grauberg [S] sends you there. The seventh you gather becomes the Primal Glow and ends the mission.",
                    pos  = "Walk of Echoes (!pos -702.325 0.399 -481.664)",
                },
            },
        },
        [50] = { -- MAIDEN_OF_THE_DUSK (M51)
            name = "Maiden of the Dusk",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    -- A repeat run is re-granted at Status 2 (54's qm_reset),
                    -- so it reads straight past this step.
                    text = "Touch the Veridical Conflux in Grauberg [S] and agree to go through. The scene as you arrive in the Walk of Echoes finishes this part.",
                    pos  = "Grauberg [S], Veridical Conflux (!pos -142.279 -6.749 585.239)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Examine the Ornate Door in the Walk of Echoes. Not in the zone? The Conflux in Grauberg [S] sends you back in.",
                    pos  = "Walk of Echoes, Ornate Door (!pos -700 -20.25 -303.398)",
                    done = { var = 'Status', gte = 3 },
                },
                {
                    -- PASS-THROUGH (battlefield 385 unbuilt): _521 at
                    -- Status 3 with the Primal Glow.
                    text = "Examine the door again holding the Primal Glow. The battle is not on this server, so that spends the Glow and passes you through. The Conflux re-issues a lost Glow, once a day.",
                    pos  = "Walk of Echoes, Ornate Door (!pos -700 -20.25 -303.398)",
                    done = { var = 'Status', gte = 4 },
                },
                {
                    text = "Scenes follow as you are moved about; the last ends the mission. If they stop, touch the Conflux in Grauberg [S] until it sends you back into the Walk of Echoes.",
                    pos  = "Walk of Echoes",
                },
            },
        },
        [51] = { -- WHERE_IT_ALL_BEGAN (M52)
            name = "Where It All Began",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Examine the Lion Springs door in Southern San d'Oria [S]. The scene ends the mission and hands you the Wedding Invitation.",
                    pos  = "Southern San d'Oria [S], Lion Springs door (!pos 96 0 106)",
                },
            },
        },
        [52] = { -- A_TOKEN_OF_TROTH (M53)
            name = "Token of Troth",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Unequip your main and sub weapons, then examine the Bulwark Gate in Sauromugue Champaign [S] for the scene.",
                    pos  = "Sauromugue Champaign [S], Bulwark Gate (!pos -447.174 -1.831 342.417)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Examine the gate again, still unarmed. The scene takes the Wedding Invitation and ends the mission.",
                    pos  = "Sauromugue Champaign [S], Bulwark Gate (!pos -447.174 -1.831 342.417)",
                },
            },
        },
        [53] = { -- LEST_WE_FORGET (M54)
            name = "Lest We Forget",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    -- 52's completion writes Status 1; a successful claim
                    -- writes 0, and nothing else touches it. eq, not gte:
                    -- the claim is the one step here that lowers the var.
                    text = "Touch the Veridical Conflux in Grauberg [S] and choose the two augments for your Moonshade Earring. Keep an inventory slot free, or nothing is handed over.",
                    pos  = "Grauberg [S], Veridical Conflux (!pos -142.279 -6.749 585.239)",
                    done = { var = 'Status', eq = 0 },
                },
                {
                    text = "The story rests here; this entry never completes. To replay Maiden of the Dusk onward for another earring, own no Moonshade Earring anywhere, zone into Grauberg [S] and examine the ???.",
                    pos  = "Grauberg [S], ??? (!pos -149.126 -7.434 576.582)",
                },
            },
        },
    },
}
