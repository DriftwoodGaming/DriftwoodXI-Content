-- dwtracker data -- Seekers of Adoulin missions (2026-09-30). Names from the
-- enum (scripts/globals/missions.lua, xi.mission.id.soa); steps HAND-AUTHORED
-- from scripts/missions/soa/*.lua as ground truth, plus the instance, zone and
-- NPC files those scripts hand off to (scripts/zones/**, scripts/globals/
-- instance.lua, scripts/globals/geomagnetic_fount.lua). Pure data: numeric ids
-- and display strings only, no xi.*, no functions (DWTRACKER_FORMAT.md
-- decisions T2/§3-4). Loaded byte-identically by the server module and the
-- dwtracker addon; both hash these bytes, so an edit that reaches only one
-- side makes the addon refuse step rendering for this area until the copies
-- agree again. tools/dwtracker_lint.py must pass before any edit here ships.
--
-- SoA IS CLOSED ON THIS SERVER (ENABLE_SOA = 0, PLANS/CONTENT_STATUS.md):
-- every entry is gated and none of it renders until that flag opens.
--
-- SEVEN THINGS ABOUT THE SoA LOG THAT SHAPE EVERY ENTRY BELOW:
--
-- 1. THE IDS ARE SPARSE AND THE LOG IDLES ON 1-1. Ids run 0..129 with gaps
--    (the journal's chapter rows carry no id). The constructor leaves
--    `current` at 0 and 0 IS Rumors from the West ("set on character
--    creation", says its script), so a fresh log renders 1-1; tracker_core's
--    zeroIdleCurrentMission tells that apart from "between missions" by 1-1's
--    own completion bit.
--
-- 2. COMPLETION PAST 63 IS DERIVED, NOT STORED. The engine keeps completion
--    bits only for ids under 64; for 64..129 hasCompletedMission answers
--    `id < current`. No step below uses a mission or completedMission atom --
--    every threshold is the entry's own state -- so that derivation never
--    decides a step here.
--
-- 3. PROGRESS LIVES IN TWO PLACES. The log's single missionStatus word (reset
--    to 0 by every Mission:complete, interaction/mission.lua:67) is read only
--    where the mission's own script writes it: 1-3, 2-5-1, 2-5-2, 2-7-1 and
--    3-1-2. 1-1 uses bits 0-2 of that word as "saw the city cutscene" flags,
--    which are not progress and are read nowhere. Everywhere else the steps
--    read the entry's own container var `Status` (Mission[12][<id>]Status),
--    which Mission:complete's cleanup wipes. 4-4-3 builds its `Status` from
--    three bits set in any order, so only "all three" (7) is readable.
--
-- 4. WHAT IS NOT TRACKED, deliberately: `Timer` (a Vana'diel day stamp -- a
--    mission that waits a day says so in its one step), `Option` (dialogue
--    toggles, and in 4-1-2 the index of a randomly chosen material set),
--    `mustZone`, `failCount`, 1-2's UNPREFIXED `SOA` charvar (the
--    Geomagnetron's charge, which the var atom cannot name), and 5-1-1's
--    "has read the note" flag (seenKeyItem is no whitelisted read).
--
-- 5. TWO SKIPS. Paying Darcia 1,000,000 gil at 1-1 or 1-2 completes 1-2 and
--    grants 1-3 directly; winning Teodor's dice game at 3-4-0 completes 3-4-1
--    and grants 3-4-2. Entries 1 and 52 may therefore never be active, and no
--    step anywhere asks about them.
--
-- 6. THE LOG DOES NOT END ON A COMPLETION. 129 The Light Within calls no
--    mission:complete; it is where the line rests. Its `Status` runs 1 -> 2
--    -> 3 (4 = "come back later") and is set back to 0 once the ring is
--    handed over. Undying Light writes the starting 1 in the same breath as it
--    grants 129, so a 0 on 129 is read as "finished" and lands on the resting
--    step (only GM tooling can put a character on 129 with a 0 that means
--    anything else).
--
-- 7. THE IMPRIMATUR GATE IS LIFTED. 1-6, 1-8 and 2-7-3 call
--    xi.soa.helpers.imprimaturGate, whose spent-imprimatur count is a TODO
--    hardwired to 0; with Adoulin fame capped at level 9 1-6 could never pass
--    it. modules/custom/lua/soa_remove_imprimatur_gate.lua (loaded through
--    modules/init.txt's custom/lua/ line) overrides it to true, so no step
--    mentions imprimaturs.
--
-- WHERE THE STORY STOPS ON THIS SERVER, and the step text says so plainly:
--
-- * Only ONE of the story's instances exists: Behind the Sluices (2-7-1,
--   Rala Waterways [U]). Stonewalled (3-6-3) and The Gates (4-3-0) in Cirdas
--   Caverns [U], Balamor's Ruse (4-6-0) and Watery Grave (5-3-2) in Rala
--   Waterways [U], and Yggdrasil Beckons (5-2-0) in Yorcia Weald [U] and
--   Cirdas Caverns [U] have no registered instance (instance.lua's lookup
--   lists them commented out), and Reckoning (5-4-0) and Abomination (5-4-1)
--   have no Ra'Kaznar Inner Court battlefield. Each stops at its fight.
-- * Delve, Skirmish, Incursion, Vagary and Sinister Reign do not exist here
--   either, but no mission script needs them.
--
-- COORDINATES are copied from the scripts' own `!pos` headers (the ones that
-- disagreed with sql/npc_list.sql -- 4-4-3, 3-6-2, 3-6-3 and 2-2-2 -- were
-- corrected to it on 2026-09-30), except where no header gives one (Elmric,
-- Signs of a Struggle, Wegellion, the Large Animal Track, both Wavering
-- Fluxes); those come from npc_list.sql. Trigger areas with no header
-- coordinate (the Western Adoulin airship docks, Foret de Hennetiel's Ergon
-- Locus) carry a place name only.
return {
    kind = 'missions',
    log = 12,
    area = 'soa_missions',
    label = "Seekers of Adoulin",
    entries = {
        [0] = { -- RUMORS_FROM_THE_WEST (M1-1)
            name = "Rumors from the West",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Darcia in Lower Jeuno and apply for the Adoulin expedition; she hands you the Geomagnetron. Paying her 1,000,000 gil instead skips The Geomagnetron outright.",
                    pos  = "Lower Jeuno, Darcia (!pos -36 -1 -15)",
                },
            },
        },
        [1] = { -- THE_GEOMAGNETRON (M1-2)
            name = "The Geomagnetron",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- One step: the fount's charge is the UNPREFIXED charvar
                    -- `SOA` (globals/geomagnetic_fount.lua), which the var
                    -- atom cannot reach.
                    text = "Attune the Geomagnetron at a Geomagnetic Fount in any old dungeon (Gusgen Mines, Ordelle's Caves, Maze of Shakhrami and others), then report to Darcia. She still takes 1,000,000 gil to skip it.",
                    pos  = "Lower Jeuno, Darcia (!pos -36 -1 -15)",
                },
            },
        },
        [3] = { -- ONWARD_TO_ADOULIN (M1-3)
            name = "Onward to Adoulin",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Waypoint in Lower Jeuno and agree to travel. It sets you down in Ceizak Battlegrounds.",
                    pos  = "Lower Jeuno, Waypoint (!pos -34.922 0 -30.966)",
                    done = { missionStatus = { 12, gte = 1 } },
                },
                {
                    text = "The scene as you land in Ceizak Battlegrounds ends the mission. If it was cut short, zone back into Ceizak.",
                    pos  = "Ceizak Battlegrounds",
                },
            },
        },
        [5] = { -- HEARTWINGS_AND_THE_KINDHEARTED (M1-4)
            name = "Heartwings and the Kindhearted",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Walk from Ceizak Battlegrounds into Western Adoulin. The welcome scene as you arrive is the whole mission.",
                    pos  = "Western Adoulin",
                },
            },
        },
        [6] = { -- PIONEER_REGISTRATION (M1-5)
            name = "Pioneer Registration",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Register with Brenton in Western Adoulin. It pays bayld, the Map of Adoulin and your Pioneer's Badge.",
                    pos  = "Western Adoulin, Brenton (!pos -86.036 3.349 18.121)",
                },
            },
        },
        [7] = { -- LIFE_ON_THE_FRONTIER (M1-6)
            name = "Life on the Frontier",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Passable only because soa_remove_imprimatur_gate.lua
                    -- lifts the imprimatur gate (header point 7).
                    text = "Talk to Brenton again for the next scene. It leaves you a Dinner Invitation.",
                    pos  = "Western Adoulin, Brenton (!pos -86.036 3.349 18.121)",
                },
            },
        },
        [8] = { -- MEETING_OF_THE_MINDS (M1-7)
            name = "Meeting of the Minds",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate between 15:00 and 22:59 Vana'diel time; the scene uses up the Dinner Invitation. Outside those hours he only chats.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [9] = { -- ARCIELA_APPEARS_AGAIN (M1-8)
            name = "Arciela Appears Again",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Declining event 6 sets status 1 and Levil re-asks in
                    -- event 7 (fixed 2026-09-30: the script used to complete
                    -- the mission whatever the answer).
                    text = "Talk to Levil in Western Adoulin and accept. Declining just means asking again.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [11] = { -- BUDDING_PROSPECTS (M2-1)
            name = "Budding Prospects",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Masad opens on a completed Flavors of Our Lives (Adoulin
                    -- quest 46) OR on the quest's own mid-point plus a day
                    -- (the mission Timer that quest writes); the text names
                    -- both, and only the completion is readable.
                    text = "Take Flavors of Our Lives from Berghent and finish it. Masad sees you early once you have reached Dewalt in that quest and a Vana'diel day has passed since you spoke to Masad for it.",
                    pos  = "Western Adoulin, Berghent (!pos 95.721 -0.148 -28.680)",
                    done = { completedQuest = { 9, 46 } }, -- FLAVORS_OF_OUR_LIVES
                },
                {
                    text = "Talk to Masad in the Mummers' Coalition for the scene that ends the mission.",
                    pos  = "Western Adoulin, Masad (!pos -28.182 -0.650 -91.991)",
                },
            },
        },
        [12] = { -- THE_LIGHT_SHINING_IN_YOUR_EYES (M2-1-1)
            name = "The Light Shining in Your Eyes",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Levil in Western Adoulin. The scene is the whole mission.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [13] = { -- THE_HEIRLOOM (M2-1-2)
            name = "The Heirloom",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Walk up to the castle gate in Eastern Adoulin, where Ploh Trishbahk stands. The scene fires as you arrive.",
                    pos  = "Eastern Adoulin, castle gate (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [14] = { -- AN_AIMLESS_JOURNEY (M2-2)
            name = "An Aimless Journey",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Make your way into Cirdas Caverns and walk up to the Ergon Locus there. The scene near it is the whole mission.",
                    pos  = "Cirdas Caverns, Ergon Locus (!pos -140 10 60)",
                },
            },
        },
        [15] = { -- ORTHARSYNE (M2-2-1)
            name = "Ortharsyne",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Go on into Yorcia Weald. The scene as you arrive is the whole mission.",
                    pos  = "Yorcia Weald",
                },
            },
        },
        [16] = { -- IN_THE_PRESENCE_OF_ROYALTY (M2-2-2)
            name = "In the Presence of Royalty",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- The tear is never taken back, and this is the step
                    -- before the done-less final.
                    text = "Find the Ergon Locus ??? in Yorcia Weald and examine it for Yorcia's Tear.",
                    pos  = "Yorcia Weald, Ergon Locus ??? (!pos 171.814 0.172 47.156)",
                    done = { ki = 2385 }, -- YORCIAS_TEAR
                },
                {
                    text = "Take the tear to Pellucid Afflusion. The scene there ends the mission with Rosulatia's Pome and the Queen's Confidante title.",
                    pos  = "Yorcia Weald, Pellucid Afflusion (!pos -175.100 1.700 387.700)",
                },
            },
        },
        [17] = { -- THE_TWIN_WORLD_TREES (M2-3)
            name = "The Twin World Trees",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass, then walk into the Peacekeepers' Coalition in Eastern Adoulin, by Oscairn. The scene fires as you arrive.",
                    pos  = "Eastern Adoulin, Oscairn (!pos -80.214 -0.150 30.717)",
                },
            },
        },
        [18] = { -- HONOR_AND_AUDACITY (M2-4)
            name = "Honor and Audacity",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Enter Rala Waterways from either half of Adoulin. The scene as you arrive is the whole mission.",
                    pos  = "Rala Waterways",
                },
            },
        },
        [19] = { -- THE_WATERGARDEN_COLISEUM (M2-4-1)
            name = "The Watergarden Coliseum",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Yeggha Dolashi in Rala Waterways. The scene is the whole mission.",
                    pos  = "Rala Waterways, Yeggha Dolashi (!pos 260 -5.768 60)",
                },
            },
        },
        [20] = { -- FRICTION_AND_FISSURES (M2-5)
            name = "Friction and Fissures",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass, then talk to Levil in Western Adoulin. Before the day is up he has nothing new.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [21] = { -- THE_CELENNIA_MEMORIAL_LIBRARY (M2-5-1)
            name = "The Celennia Memorial Library",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "In the Celennia Memorial Library, examine the History book and note the password it shows you.",
                    pos  = "Celennia Memorial Library, History (!pos -116.250 -3.650 -90.147)",
                    done = { missionStatus = { 12, gte = 1 } },
                },
                {
                    -- Levil's closing scene (event 125) needs the status the
                    -- History book writes; before it he only repeats event
                    -- 124. (Fixed 2026-09-30: the script read a nibble at
                    -- position 21, which always answered 0.)
                    text = "Report to Levil in Western Adoulin for the scene that ends the mission.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [23] = { -- FOR_WHOM_DO_WE_TOIL (M2-5-2)
            name = "For Whom Do We Toil?",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Enter Rala Waterways for a scene.",
                    pos  = "Rala Waterways",
                    done = { missionStatus = { 12, gte = 1 } },
                },
                {
                    text = "Examine Sluice Gate 6 and enter the library's password both times. After three wrong tries, read the History book again and wait a Vana'diel day. It ends with a Note Detailing Seditious Plans.",
                    pos  = "Rala Waterways, Sluice Gate (!pos -561.522 -7.500 60.002)",
                },
            },
        },
        [26] = { -- AIMING_FOR_YGNAS (M2-6)
            name = "Aiming for Ygnas",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate. The scene is the whole mission.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [27] = { -- CALAMITY_IN_THE_KITCHEN (M2-6-1)
            name = "Calamity in the Kitchen",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Chalvava in Rala Waterways and agree to help; turning her down just means asking again. It leaves you a Box of Adoulinian Tomatoes.",
                    pos  = "Rala Waterways, Chalvava (!pos -318.000 -1.000 -318.000)",
                },
            },
        },
        [29] = { -- ARCIELAS_PROMISE (M2-6-2)
            name = "Arciela's Promise",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Go back to Ploh Trishbahk at the Eastern Adoulin castle gate. The scene is the whole mission.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [30] = { -- PREDATOR_AND_PREY (M2-7)
            name = "Predators and Prey",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine Sluice Gate 6 in Rala Waterways. The scene is the whole mission.",
                    pos  = "Rala Waterways, Sluice Gate (!pos -561.522 -7.500 60.002)",
                },
            },
        },
        [31] = { -- BEHIND_THE_SLUICES (M2-7-1)
            name = "Behind the Sluices",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- The crank is taken when the instance registers
                    -- (Rala_Waterways_U/instances/behind_the_sluices.lua:69),
                    -- so it rides with the status that survives that.
                    text = "Examine the Storage Container in Rala Waterways for the Waterway Facility Crank.",
                    pos  = "Rala Waterways, Storage Container (!pos -150.198 -7.115 28.965)",
                    done = {
                        anyOf = {
                            { ki = 2450 }, -- WATERWAY_FACILITY_CRANK
                            { missionStatus = { 12, gte = 1 } },
                        },
                    },
                },
                {
                    text = "Take the crank to Sluice Gate 6 for a scene.",
                    pos  = "Rala Waterways, Sluice Gate (!pos -561.522 -7.500 60.002)",
                    done = { missionStatus = { 12, gte = 1 } },
                },
                {
                    text = "Examine Sluice Gate 6 again and agree to go through.",
                    pos  = "Rala Waterways, Sluice Gate (!pos -561.522 -7.500 60.002)",
                    done = { missionStatus = { 12, gte = 2 } },
                },
                {
                    -- Status 3 is written by the instance on a win
                    -- (behind_the_sluices.lua:160). A loss leaves status 2
                    -- and no crank; the Storage Container re-issues it at any
                    -- status below 3 (fixed 2026-09-30: it answered only at
                    -- 0, and the crank was never actually spent because the
                    -- registration hook died on a missing text id).
                    text = "Enter at the Antiquated Sluice Gate and win the fight beside Arciela. The crank is spent on entry; if you lose, examine the Storage Container for another and go back in.",
                    pos  = "Rala Waterways, Antiquated Sluice Gate (!pos -529.361 -7.000 59.988)",
                    done = { missionStatus = { 12, gte = 3 } },
                },
                {
                    text = "The scene as you arrive back in Rala Waterways ends the mission. If it was cut short, zone back in.",
                    pos  = "Rala Waterways",
                },
            },
        },
        [34] = { -- THE_LEAFKIN_MONARCH (M2-7-2)
            name = "The Leafkin Monarch",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Walk up to the castle gate in Eastern Adoulin. The scene fires as you arrive.",
                    pos  = "Eastern Adoulin, castle gate (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [35] = { -- YGGDRASIL (M2-7-3)
            name = "Yggdrasil",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass, then talk to Levil in Western Adoulin and accept. Declining just means asking again.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [37] = { -- RETURN_OF_THE_EXORCIST (M3-1)
            name = "Return of the Exorcist",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Head for the airship docks in Western Adoulin. The scene fires as you approach them.",
                    pos  = "Western Adoulin, airship docks",
                },
            },
        },
        [38] = { -- THE_MERCILESS_ONE (M3-1-1)
            name = "The Merciless One",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Walk up to the castle gate in Eastern Adoulin. The scene fires as you arrive.",
                    pos  = "Eastern Adoulin, castle gate (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [39] = { -- A_CURSE_FROM_THE_PAST (M3-1-2)
            name = "A Curse from the Past",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Rigobertine near the Eastern Adoulin castle gate for the Eternal Flame. Ploh Trishbahk has a word first if you want it.",
                    pos  = "Eastern Adoulin, Rigobertine (!pos 68.022 -40.150 10.703)",
                    done = { missionStatus = { 12, gte = 1 } },
                },
                {
                    text = "Collect two key items in Western Adoulin, in either order: holy water from Fontis Xanira and a Piece of a Stone Wall from the Sunrise Beacon.",
                    pos  = "Western Adoulin, Fontis Xanira (!pos 17.350 1 -21.248) / Western Adoulin, Sunrise Beacon (!pos 115.167 32 177.887)",
                    done = { missionStatus = { 12, gte = 2 } },
                },
                {
                    text = "Report to Erminold in Eastern Adoulin. The scene ends the mission and leaves you the Weather Vane Wings.",
                    pos  = "Eastern Adoulin, Erminold (!pos 50.949 -40 -90.942)",
                },
            },
        },
        [40] = { -- THE_PURGATION (M3-1-3)
            name = "The Purgation",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Walk up to the castle gate in Eastern Adoulin. The scene ends the mission and takes back the four key items from A Curse from the Past.",
                    pos  = "Eastern Adoulin, castle gate (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [41] = { -- THE_KEY (M3-1-4)
            name = "The Key",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass, then talk to Levil in Western Adoulin.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [42] = { -- THE_PRINCESSS_DILEMMA (M3-2)
            name = "The Princess's Dilemma",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Enter the Celennia Memorial Library for the scene. If it ends without advancing the mission, leave and come back in to see it again.",
                    pos  = "Celennia Memorial Library",
                },
            },
        },
        [43] = { -- DARK_CLOUDS_AHEAD (M3-2-1)
            name = "Dark Clouds Ahead",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Levil in Western Adoulin. The scene is the whole mission.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [44] = { -- THE_SMALLEST_OF_FAVORS (M3-2-2)
            name = "The Smallest of Favors",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass, then leave Western Adoulin into Ceizak Battlegrounds. The scene fires as you arrive; coming in from anywhere else does not trigger it.",
                    pos  = "Ceizak Battlegrounds",
                },
            },
        },
        [45] = { -- SUMMONED_BY_SPIRITS (M3-3)
            name = "Summoned by Spirits",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Enter the Celennia Memorial Library. The scene as you arrive is the whole mission.",
                    pos  = "Celennia Memorial Library",
                },
            },
        },
        [46] = { -- EVIL_ENTITIES (M3-3-1)
            name = "Evil Entities",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Find Elmric out in Ceizak Battlegrounds and talk to him. The scene is the whole mission.",
                    pos  = "Ceizak Battlegrounds, Elmric (!pos 355.703 0.539 184.263)",
                },
            },
        },
        [47] = { -- ADOULIN_CALLING (M3-3-2)
            name = "Adoulin Calling",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Knock at the Boarding House door in Eastern Adoulin. The scene is the whole mission.",
                    pos  = "Eastern Adoulin, Boarding House (!pos -41.693 -0.15 -38.29)",
                },
            },
        },
        [48] = { -- THE_DISAPPEARANCE_OF_NYLINE (M3-3-3)
            name = "The Disappearance of Nyline",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Travel into Foret de Hennetiel and walk up to its Ergon Locus. The scene there ends the mission; the Boarding House door only has a hint for you.",
                    pos  = "Foret de Hennetiel, Ergon Locus",
                },
            },
        },
        [49] = { -- SHARED_CONSCIOUSNESS (M3-3-4)
            name = "Shared Consciousness",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Knock at the Boarding House door in Eastern Adoulin again. The scene ends the mission with bayld, experience and the Sunshine Cadet title.",
                    pos  = "Eastern Adoulin, Boarding House (!pos -41.693 -0.15 -38.29)",
                },
            },
        },
        [50] = { -- CLEAR_SKIES (M3-3-5)
            name = "Clear Skies",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass, then talk to Levil in Western Adoulin. The scene is the whole mission and pays a little bayld.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [51] = { -- THE_MAN_IN_BLACK (M3-4)
            name = "The Man in Black",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Masad in the Mummers' Coalition and play Teodor's dice game. The mission ends however the game goes; a win also skips To the Victor.",
                    pos  = "Western Adoulin, Masad (!pos -28.182 -0.650 -91.991)",
                },
            },
        },
        [52] = { -- TO_THE_VICTOR (M3-4-1)
            name = "To the Victor",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- `Status` here is only the dialogue flavour for the
                    -- rematch (first try / after a loss), not progress.
                    text = "Talk to Masad again and beat Teodor at his dice game. A loss just means another game.",
                    pos  = "Western Adoulin, Masad (!pos -28.182 -0.650 -91.991)",
                },
            },
        },
        [53] = { -- AN_EXTRAORDINARY_GENTLEMAN (M3-4-2)
            name = "An Extraordinary Gentleman",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Levil in Western Adoulin. The scene is the whole mission.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [55] = { -- THE_ORDERS_TREASURES (M3-4-3)
            name = "The Order's Treasures",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Enter the Celennia Memorial Library. The scene as you arrive is the whole mission.",
                    pos  = "Celennia Memorial Library",
                },
            },
        },
        [56] = { -- AUGUSTS_HEIRLOOM (M3-4-4)
            name = "August's Heirloom",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate. The scene is the whole mission.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [57] = { -- BEAUTY_AND_THE_BEAST (M3-5)
            name = "Beauty and the Beast",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Signs of a Struggle in Ceizak Battlegrounds. The scene ends the mission and leaves you a Pristine Hair Ribbon.",
                    pos  = "Ceizak Battlegrounds, Signs of a Struggle (!pos 196.960 0.000 78.949)",
                },
            },
        },
        [58] = { -- WILDCAT_WITH_A_GOLD_PELT (M3-5-1)
            name = "Wildcat with a Gold Pelt",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Walk up to the castle gate in Eastern Adoulin. The scene fires as you arrive.",
                    pos  = "Eastern Adoulin, castle gate (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [59] = { -- IN_SEARCH_OF_ARCIELA (M3-5-2)
            name = "In Search of Arciela",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Levil in Western Adoulin; the scene ends the mission. Ploh Trishbahk has a scene at the castle gate too, but it is not required.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [61] = { -- LOOKING_FOR_LEADS (M3-5-3)
            name = "Looking for Leads",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Walk into the Scouts' Coalition in Eastern Adoulin, by Wegellion. The scene ends the mission and leaves you the Tintinnabulum.",
                    pos  = "Eastern Adoulin, Wegellion (!pos -94.478 -0.650 -51.173)",
                },
            },
        },
        [62] = { -- DRIFTING_NORTHWEST (M3-6)
            name = "Drifting Northwest",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Make your way into Kamihr Drifts. The scene as you arrive ends the mission and uses up the Tintinnabulum.",
                    pos  = "Kamihr Drifts",
                },
            },
        },
        [63] = { -- KUMHAU_THE_FLASHFROST_NAAKUAL (M3-6-1)
            name = "Kumhau, the Flashfrost Naakual",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Levil's briefing only flips `Option`; the cave does
                    -- not wait on it.
                    text = "Examine the Crawling Cave in Kamihr Drifts. Levil in Western Adoulin has a briefing first if you want it.",
                    pos  = "Kamihr Drifts, Crawling Cave (!pos -349.302 40.339 -379.79)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "You are sent to Ceizak Battlegrounds, and the scene there sends you back. If it was cut short, zone into Ceizak again.",
                    pos  = "Ceizak Battlegrounds",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "The scene as you arrive back in Kamihr Drifts ends the mission with the Aureate Ball of Fur. If it was cut short, zone into Kamihr Drifts again.",
                    pos  = "Kamihr Drifts",
                },
            },
        },
        [66] = { -- SOUL_SIPHON (M3-6-2)
            name = "Soul Siphon",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Hollowed Pathway in Kamihr Drifts and go through.",
                    pos  = "Kamihr Drifts, Hollowed Pathway (!pos -215.371 39.025 -446.368)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "You are sent into Cirdas Caverns, and the scene there returns you. If it was cut short, zone into Cirdas Caverns again.",
                    pos  = "Cirdas Caverns",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Arriving back in Kamihr Drifts ends the mission; there is no scene of its own. If you were not returned there, zone into Kamihr Drifts.",
                    pos  = "Kamihr Drifts",
                },
            },
        },
        [67] = { -- STONEWALLED (M3-6-3)
            name = "Stonewalled",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Status 1 would come from Cirdas Caverns [U] event 1000;
                    -- instance.lua registers no instance in that zone.
                    text = "Stonewalled is a battle in Cirdas Caverns [U]. No instance for it exists on this server, so the line stops here. (The Crawling Cave re-issues the Aureate Ball of Fur.)",
                    pos  = "Kamihr Drifts, Crawling Cave (!pos -349.302 40.339 -379.79)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene as you arrive back in Cirdas Caverns ends the mission and leaves you the Soul Siphon.",
                    pos  = "Cirdas Caverns",
                },
            },
        },
        [69] = { -- SALVATION (M3-6-4)
            name = "Salvation",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Crawling Cave in Kamihr Drifts and see the scene through; it spends the Soul Siphon. If it ends without advancing the mission, examine the cave again.",
                    pos  = "Kamihr Drifts, Crawling Cave (!pos -349.302 40.339 -379.79)",
                },
            },
        },
        [70] = { -- GLIMMER_OF_PORTENT (M3-6-5)
            name = "Glimmer of Portent",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass, then talk to Levil in Western Adoulin and agree.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [71] = { -- INTO_THE_FIRE (M4-1)
            name = "...Into the Fire",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Kipligg in Western Adoulin. The scene is the whole mission.",
                    pos  = "Western Adoulin, Kipligg (!pos -32 0 22)",
                },
            },
        },
        [72] = { -- MELVIEN_DE_MALECROIX (M4-1-1)
            name = "Melvien de Malecroix",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Port Storage in Western Adoulin. The scene ends the mission and names the materials you must bring for the next one.",
                    pos  = "Western Adoulin, Port Storage (!pos 85.578 30.5 180.639)",
                },
            },
        },
        [73] = { -- COURIER_CATASTROPHE (M4-1-2)
            name = "Courier Catastrophe",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Which set is owed is a random index in `Option`, not
                    -- progress, so the gather cannot be tracked by item.
                    text = "Bring the Port Storage what it named: 5 Eft Skins, 4 Locks of Manticore Hair, or one Buffalo Horn, Manticore Leather or Buffalo Leather. Examine it to re-check; trade to finish.",
                    pos  = "Western Adoulin, Port Storage (!pos 85.578 30.5 180.639)",
                },
            },
        },
        [74] = { -- DONE_AND_DELIVERED (M4-1-3)
            name = "Done and Delivered",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Kipligg in Western Adoulin. The scene is the whole mission.",
                    pos  = "Western Adoulin, Kipligg (!pos -32 0 22)",
                },
            },
        },
        [75] = { -- MINISTERIAL_WHISPERS (M4-1-4)
            name = "Ministerial Whispers",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Levil in Western Adoulin. The scene ends the mission and pays bayld.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [76] = { -- A_DAY_IN_THE_LIFE_OF_A_PIONEER (M4-1-5)
            name = "A Day in the Life of a Pioneer",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass and zone out and back, then talk to Levil in Western Adoulin.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [77] = { -- LIGHTING_THE_WAY (M4-2)
            name = "Lighting the Way",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Alpine Trail in Kamihr Drifts and agree to climb.",
                    pos  = "Kamihr Drifts, Alpine Trail (!pos -13.479 -1.047 488.863)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene on Mount Kamihr returns you to Kamihr Drifts.",
                    pos  = "Mount Kamihr",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Arriving back in Kamihr Drifts ends the mission; there is no scene of its own. If you were not returned there, zone into Kamihr Drifts.",
                    pos  = "Kamihr Drifts",
                },
            },
        },
        [78] = { -- SAJJAKA (M4-2-1)
            name = "Sajj'aka",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Enter the Celennia Memorial Library. The scene as you arrive is the whole mission.",
                    pos  = "Celennia Memorial Library",
                },
            },
        },
        [79] = { -- STUDYING_UP (M4-2-2)
            name = "Studying Up",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Alpine Trail in Kamihr Drifts and agree to climb.",
                    pos  = "Kamihr Drifts, Alpine Trail (!pos -13.479 -1.047 488.863)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene on Mount Kamihr returns you to Kamihr Drifts.",
                    pos  = "Mount Kamihr",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Arriving back in Kamihr Drifts ends the mission; there is no scene of its own. If you were not returned there, zone into Kamihr Drifts.",
                    pos  = "Kamihr Drifts",
                },
            },
        },
        [80] = { -- A_VOW_OF_TRUTH (M4-2-3)
            name = "A Vow of Truth",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Make your way into Woh Gates. The scene as you arrive is the whole mission.",
                    pos  = "Woh Gates",
                },
            },
        },
        [81] = { -- DARRCUILN (M4-2-4)
            name = "Darrcuiln",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Darkened Crevice in Woh Gates. The scene ends the mission and leaves you a Tuft of Golden Fur.",
                    pos  = "Woh Gates, Darkened Crevice (!pos 185.752 27.311 240.72)",
                },
            },
        },
        [82] = { -- THE_GATES (M4-3)
            name = "The Gates",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Status 1 would come from Cirdas Caverns [U] event 1000;
                    -- instance.lua registers no instance in that zone.
                    text = "The Gates is a battle in Cirdas Caverns [U]. No instance for it exists on this server, so the line stops here. (The Large Animal Track in Woh Gates re-issues the Tuft of Golden Fur.)",
                    pos  = "Woh Gates, Large Animal Track (!pos 462.116 10.380 172.504)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene as you arrive back in Woh Gates ends the mission.",
                    pos  = "Woh Gates",
                },
            },
        },
        [84] = { -- MORIMAR (M4-3-1)
            name = "Morimar",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Alpine Trail in Kamihr Drifts and agree to climb.",
                    pos  = "Kamihr Drifts, Alpine Trail (!pos -13.479 -1.047 488.863)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene on Mount Kamihr ends the mission with Sajj'aka's Protective Ward and returns you to Kamihr Drifts. If it was cut short, zone into Mount Kamihr again.",
                    pos  = "Mount Kamihr",
                },
            },
        },
        [85] = { -- A_NEW_FORCE_ARISES (M4-3-2)
            name = "A New Force Arises",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- The three scales are taken in the same handler that
                    -- completes the mission, and this is the step before the
                    -- done-less final.
                    text = "Through the Liseran Door in Kamihr Drifts, collect three scales in Outer Ra'Kaznar: at the Demonic Architrave and at both Effigies of Sealing.",
                    pos  = "Outer Ra'Kaznar (!pos 197 58 -20) / Outer Ra'Kaznar (!pos -496 -178 336) / Outer Ra'Kaznar (!pos -424 -178 -376)",
                    done = {
                        allOf = {
                            { ki = 2549 }, -- SUNKISSED_SCALE
                            { ki = 2550 }, -- MOONTOUCHED_SCALE
                            { ki = 2551 }, -- STARBLESSED_SCALE
                        },
                    },
                },
                {
                    text = "Take all three to the Alpine Trail in Kamihr Drifts and climb. The scene on Mount Kamihr takes them and ends the mission with the World Tree Sapling.",
                    pos  = "Kamihr Drifts, Alpine Trail (!pos -13.479 -1.047 488.863)",
                },
            },
        },
        [86] = { -- THE_SACRED_SAPLING (M4-3-3)
            name = "The Sacred Sapling",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate. The scene is the whole mission.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [87] = { -- TREE_GRAFTING (M4-3-4)
            name = "Tree Grafting",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Levil in Western Adoulin; the scene ends the mission. Ploh Trishbahk has a scene at the castle gate too, but it is not required.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [88] = { -- A_SHROUDED_CANOPY (M4-3-5)
            name = "A Shrouded Canopy",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Make your way into Leafallia, which opens off Kamihr Drifts. The scene as you arrive is the whole mission.",
                    pos  = "Leafallia",
                },
            },
        },
        [89] = { -- LEAFALLIA (M4-3-6)
            name = "Leafallia",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Aged Stump in Leafallia. The scene is the whole mission.",
                    pos  = "Leafallia, Aged Stump (!pos -27.233 -2 33.508)",
                },
            },
        },
        [90] = { -- ROSULATIAS_PROMISE (M4-3-7)
            name = "Rosulatia's Promise",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Heroic Footprints in Leafallia. The scene ends the mission and takes the World Tree Sapling.",
                    pos  = "Leafallia, Heroic Footprints (!pos -19.381 -0.403 17.465)",
                },
            },
        },
        [91] = { -- THE_LIGHTSLAND (M4-3-8)
            name = "The Lightsland",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate and choose a necklace: Adoulin's Refuge, Ygnas's Resolve or Arciela's Grace. With no free slot, come back when you have one.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [92] = { -- THE_LIGHT_OF_DAWN_COMES (M4-3-9)
            name = "The Light of Dawn Comes from the East",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass, then talk to Levil in Western Adoulin.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [93] = { -- CRIES_FROM_THE_DEEP (M4-4)
            name = "Cries from the Deep",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Walk up to the castle gate in Eastern Adoulin for a scene.",
                    pos  = "Eastern Adoulin, castle gate (!pos 100.580 -40.150 -63.830)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "A second scene follows as you are set back down at the gate and ends the mission. If it was cut short, zone into Eastern Adoulin again.",
                    pos  = "Eastern Adoulin",
                },
            },
        },
        [94] = { -- SEEDS_OF_DOUBT (M4-4-1)
            name = "Seeds of Doubt",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Chalvava in Rala Waterways; the scene ends the mission. Ploh Trishbahk has a scene at the castle gate too, but it is not required.",
                    pos  = "Rala Waterways, Chalvava (!pos -318.000 -1.000 -318.000)",
                },
            },
        },
        [95] = { -- THE_TOMATOES_OF_WRATH (M4-4-2)
            name = "The Tomatoes of Wrath",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate; the scene ends the mission. Chalvava in Rala Waterways has an optional scene first.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [96] = { -- A_GRAVE_MISTAKE (M4-4-3)
            name = "A Grave Mistake",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- `Status` is three bits (Sainene 1, Overlook 2, Stout
                    -- Weir 4) set in any order and never unset, so only the
                    -- full 7 -- the value Ploh checks -- orders anything.
                    text = "Visit three spots in Rala Waterways, in any order: talk to Sainene, examine the Stout Weir (for the Broken Fuse) and examine the Waterways Overlook.",
                    pos  = "Rala Waterways (!pos 308.443 -5.768 -68.803) / (!pos -427.506 -1 -148.217) / (!pos -17.995 -6.057 37.43)",
                    done = { var = 'Status', gte = 7 },
                },
                {
                    text = "Report to Ploh Trishbahk at the Eastern Adoulin castle gate. The scene ends the mission and takes the Broken Fuse.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [98] = { -- AN_EMERGENCY_CONVOCATION (M4-4-4)
            name = "An Emergency Convocation",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Leave Eastern Adoulin and come back, then talk to Ploh Trishbahk at the castle gate.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Two more scenes follow as you are set back down at the gate; the second ends the mission. If one was cut short, zone into Eastern Adoulin again.",
                    pos  = "Eastern Adoulin",
                },
            },
        },
        [99] = { -- BALAMOR_THE_DEATHBORNE_XOL (M4-5)
            name = "Balamor, The Deathborne Xol",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Let a Vana'diel day pass, then talk to Ploh Trishbahk at the Eastern Adoulin castle gate.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [100] = { -- ANAGNORISIS (M4-5-1)
            name = "Anagnorisis",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Trade Ploh Trishbahk the necklace you chose in The Lightsland. If you no longer have it, simply talk to him instead.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [101] = { -- JUST_THE_THING (M4-5-2)
            name = "Just the Thing",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Andreine in the Celennia Memorial Library. The scene ends the mission with the Suffering Sacchariferous.",
                    pos  = "Celennia Memorial Library, Andreine (!pos -91.944 -2.14 -91.538)",
                },
            },
        },
        [102] = { -- SUGARCOATED_SALVATION (M4-5-3)
            name = "Sugarcoated Salvation",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate. The scene spends the Suffering Sacchariferous and leaves you the Sepulcher Ensign.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [103] = { -- ARCIELAS_RESOLVE (M4-5-4)
            name = "Arciela's Resolve",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Royal Sepulcher in Rala Waterways. The scene is the whole mission; Ploh Trishbahk has an optional one first.",
                    pos  = "Rala Waterways, Royal Sepulcher (!pos 319 -7.5 -300)",
                },
            },
        },
        [104] = { -- BALAMORS_RUSE (M4-6)
            name = "Balamor's Ruse",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- The simulacrum is never taken by the script; the
                    -- status branch keeps the step done regardless.
                    text = "Hunt Duskbringer Bats, New Moon Bats, Skittering Spiders, Spoutdrenched Toads or Waterway Pugils in Rala Waterways until the Consummate Simulacrum drops (1 kill in 5).",
                    pos  = "Rala Waterways",
                    done = {
                        anyOf = {
                            { ki = 2600 }, -- CONSUMMATE_SIMULACRUM
                            { var = 'Status', gte = 1 },
                        },
                    },
                },
                {
                    -- Status 1 would come from Rala Waterways [U] event 1000;
                    -- the only instance registered there is Behind the Sluices.
                    text = "The simulacrum opens a battle in Rala Waterways [U]. No instance for it exists on this server, so the line stops here.",
                    pos  = "Rala Waterways",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene as you arrive back in Rala Waterways ends the mission.",
                    pos  = "Rala Waterways",
                },
            },
        },
        [105] = { -- THE_CHARLATAN (M4-6-1)
            name = "The Charlatan",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate and choose a +1 necklace. With no free slot, come back when you have one.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [107] = { -- ROYAL_BLESSINGS (M4-6-2)
            name = "Royal Blessings",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Levil in Western Adoulin. The scene is the whole mission.",
                    pos  = "Western Adoulin, Levil (!pos -87.204 3.350 12.655)",
                },
            },
        },
        [108] = { -- ARBOREAL_RUMORS (M5-1)
            name = "Arboreal Rumors",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate. The scene ends the mission with a Hastily Scribbled Note.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
        [109] = { -- ARCIELAS_MISSIVE (M5-1-1)
            name = "Arciela's Missive",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- The beacon checks seenKeyItem, which no atom reads.
                    text = "Read the Hastily Scribbled Note in your key item list, then examine the Sunrise Beacon in Western Adoulin. The beacon ignores you until the note has been read.",
                    pos  = "Western Adoulin, Sunrise Beacon (!pos 115.167 32 177.887)",
                },
            },
        },
        [110] = { -- HEROES_UNITE (M5-1-2)
            name = "Heroes, Unite!",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Alpine Trail in Kamihr Drifts and agree to climb.",
                    pos  = "Kamihr Drifts, Alpine Trail (!pos -13.479 -1.047 488.863)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene on Mount Kamihr returns you to Kamihr Drifts.",
                    pos  = "Mount Kamihr",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "Arriving back in Kamihr Drifts ends the mission; there is no scene of its own. If you were not returned there, zone into Kamihr Drifts.",
                    pos  = "Kamihr Drifts",
                },
            },
        },
        [111] = { -- A_PORTENT_MOST_OMINOUS (M5-1-3)
            name = "A Portent Most Ominous",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Aged Stump in Leafallia. The scene ends the mission with the Sky Blue and Sun Yellow Pomes.",
                    pos  = "Leafallia, Aged Stump (!pos -27.233 -2 33.508)",
                },
            },
        },
        [112] = { -- YGGDRASIL_BECKONS (M5-2)
            name = "Yggdrasil Beckons",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- One step on purpose: the fluxes set `Status` bits in
                    -- either order, and the two wins that finish it come from
                    -- Yorcia Weald [U] and Cirdas Caverns [U] event 1000,
                    -- neither of which has a registered instance.
                    text = "Touch the Wavering Flux in Yorcia Weald and the one in Cirdas Caverns (the Aged Stump re-issues the pomes). The battles behind them have no instance here, so the line stops at this point.",
                    pos  = "Yorcia Weald, Wavering Flux (!pos 44.852 -0.261 370.012) / Cirdas Caverns, Wavering Flux (!pos 300 28.65 -67)",
                },
            },
        },
        [113] = { -- RETURNING_TO_THE_TREES (M5-2-1)
            name = "Returning to the Trees",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Make your way into Leafallia. The scene as you arrive is the whole mission.",
                    pos  = "Leafallia",
                },
            },
        },
        [114] = { -- THE_KEY_TO_THE_TURRIS (M5-2-2)
            name = "The Key to the Turris",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Ominous Postern in Ra'Kaznar Turris.",
                    pos  = "Ra'Kaznar Turris, Ominous Postern (!pos 118 37.5 20)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "You are set down in Kamihr Drifts, and the scene there ends the mission. If it was cut short, zone into Kamihr Drifts again.",
                    pos  = "Kamihr Drifts",
                },
            },
        },
        [116] = { -- TEODORS_SUMMONS (M5-3)
            name = "Teodor's Summons",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Alpine Trail in Kamihr Drifts and agree to climb.",
                    pos  = "Kamihr Drifts, Alpine Trail (!pos -13.479 -1.047 488.863)",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene on Mount Kamihr ends the mission with the Ash Runic Board and returns you to Kamihr Drifts. If it was cut short, zone into Mount Kamihr again.",
                    pos  = "Mount Kamihr",
                },
            },
        },
        [117] = { -- THE_SEVENTH_GUARDIAN (M5-3-1)
            name = "The Seventh Guardian",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Talk to Yeggha Dolashi in Rala Waterways. The scene is the whole mission.",
                    pos  = "Rala Waterways, Yeggha Dolashi (!pos 260 -5.768 60)",
                },
            },
        },
        [118] = { -- WATERY_GRAVE (M5-3-2)
            name = "Watery Grave",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Status 1 would come from Rala Waterways [U] event 1000;
                    -- the only instance registered there is Behind the Sluices.
                    text = "Watery Grave is a battle in Rala Waterways [U] with the Ash Runic Board. No instance for it exists on this server, so the line stops here.",
                    pos  = "Rala Waterways",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene as you arrive back in Rala Waterways ends the mission with Teodor's Blood Sigil and the Crystallized Psyche.",
                    pos  = "Rala Waterways",
                },
            },
        },
        [120] = { -- BLOOD_FOR_BLOOD (M5-3-3)
            name = "Blood for Blood",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Ominous Postern in Ra'Kaznar Turris. The scene is the whole mission.",
                    pos  = "Ra'Kaznar Turris, Ominous Postern (!pos 118 37.5 20)",
                },
            },
        },
        [121] = { -- RECKONING (M5-4)
            name = "Reckoning",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Status 1 is written on battlefield exit (event 32001);
                    -- scripts/battlefields has no Ra'Kaznar Inner Court arena.
                    text = "Reckoning is a battle in Ra'Kaznar Inner Court with the Crystallized Psyche. No battlefield for it exists on this server, so the line stops here.",
                    pos  = "Ra'Kaznar Inner Court",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene as you arrive back in Ra'Kaznar Turris ends the mission with the Awakened Crystallized Psyche.",
                    pos  = "Ra'Kaznar Turris",
                },
            },
        },
        [123] = { -- ABOMINATION (M5-4-1)
            name = "Abomination",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- Same missing arena as Reckoning.
                    text = "Abomination is a battle in Ra'Kaznar Inner Court with the Awakened Crystallized Psyche. No battlefield for it exists on this server, so the line stops here.",
                    pos  = "Ra'Kaznar Inner Court",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "The scene as you arrive back in Ra'Kaznar Turris sends you on to Ceizak Battlegrounds.",
                    pos  = "Ra'Kaznar Turris",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "The scene as you arrive in Ceizak Battlegrounds ends the mission. If it was cut short, zone into Ceizak again.",
                    pos  = "Ceizak Battlegrounds",
                },
            },
        },
        [125] = { -- UNDYING_LIGHT (M5-5)
            name = "Undying Light",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Walk from Ceizak Battlegrounds into Western Adoulin for a scene. Arriving any other way does not trigger it.",
                    pos  = "Western Adoulin",
                    done = { var = 'Status', gte = 1 },
                },
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                    done = { var = 'Status', gte = 2 },
                },
                {
                    text = "The scene as you are set back down at the gate ends the mission. If it was cut short, zone into Eastern Adoulin again.",
                    pos  = "Eastern Adoulin",
                },
            },
        },
        [129] = { -- THE_LIGHT_WITHIN (M5-5-1)
            name = "The Light Within",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- `Status` starts at 1 (written by Undying Light as it
                    -- grants this mission) and is set back to 0 once the ring
                    -- is handed over (header point 6), so 0 rides every
                    -- earlier step as the survivor.
                    text = "Let a Vana'diel day pass, then enter Ceizak Battlegrounds. The scene there trades your Pristine Hair Ribbon for Arciela's Skirt and sends you to Leafallia.",
                    pos  = "Ceizak Battlegrounds",
                    done = {
                        anyOf = {
                            { var = 'Status', gte = 2 },
                            { var = 'Status', eq = 0 },
                        },
                    },
                },
                {
                    text = "The scene in Leafallia sends you back to Ceizak Battlegrounds. If it was cut short, zone into Leafallia again.",
                    pos  = "Leafallia",
                    done = {
                        anyOf = {
                            { var = 'Status', gte = 3 },
                            { var = 'Status', eq = 0 },
                        },
                    },
                },
                {
                    text = "Talk to Ploh Trishbahk at the Eastern Adoulin castle gate and pick one of twelve rings; Councilor's Garb and Cuffs come with it, so keep three inventory slots free.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                    done = { var = 'Status', eq = 0 },
                },
                {
                    text = "The story rests here. Nothing completes this mission -- it stays on your log as the end of the Adoulin line.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.580 -40.150 -63.830)",
                },
            },
        },
    },
}
