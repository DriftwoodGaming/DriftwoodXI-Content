-- dwtracker data -- Adoulin quests (quest log 9), authored 2026-09-30 while
-- Seekers of Adoulin is SHUT on this server (ENABLE_SOA = 0): every entry is
-- gated on that flag and pinned in tools/dwtracker_lint.py's GATED_PINS, so
-- none of this renders until the expansion opens. Names from the scripts'
-- own header comments and the enum (scripts/globals/quests.lua,
-- xi.quest.id.adoulin); steps HAND-AUTHORED from scripts/quests/adoulin/*.lua
-- and the legacy zone NPC scripts as ground truth.
-- Pure data: numeric ids and display strings only, no xi.*, no functions
-- (DWTRACKER_FORMAT.md decisions T2/§3-4). Loaded byte-identically by the
-- server module and the dwtracker addon; both hash these bytes, so an edit
-- that reaches only one side makes the addon refuse step rendering for
-- this area until the copies agree again. tools/dwtracker_lint.py must
-- pass before any edit here ships.
--
-- FIVE THINGS ABOUT THIS LOG THAT SHAPE THE ENTRIES BELOW:
--
-- 1. 21 OF THE 97 IDS ARE PLAYABLE AND CARRY STEPS. Fifteen have a framework
--    script. Six more -- F.A.I.L.ure Is Not an Option (29), Exotic
--    Delicacies (74), A Pioneer's Best (Imaginary) Friend (75), The Old Man
--    and the Harpoon (77), Always More Quoth the Ravenous (88) and Children
--    of the Rune (119) -- live in LEGACY ZONE NPC SCRIPTS and are recorded in
--    SCRIPT_ALIASES. Their state is raw charVars the `var` atom cannot reach,
--    so those six step on quest status, key items and items only. The other
--    76 are named only, with the reason on each row: most have no script at
--    all, and several have NPCs who answer while the quest is active but
--    nothing that offers or finishes it.
--
-- 2. TWO OF THE 21 CAN BE ACCEPTED BUT NOT FINISHED, and their steps say so
--    rather than pretend. A Stone's Throw Away (56): Morimar mining is
--    unimplemented and nothing else sets the flag Apolliane checks.
--    F.A.I.L.ure Is Not an Option (29): nothing hands out the Hunk of Bedrock.
--    Raptor Rapture (73) is worse -- it cannot even be accepted -- and is
--    named only. (Hunger Strikes (76) and The Starving (84) were on this list
--    until the same day: their turn-in sections were not keyed to a zone, so
--    Westerly Breeze never took the trade. Fixed 2026-09-30, and
--    scripts/tests/quests/adoulin_westerly_breeze.lua drives both turn-ins.)
--
-- 3. THE FAME CYCLE REALLY CYCLES. It Sets My Heart Aflutter (79), A Good
--    Pair of Crocs (93) and A Shot in the Dark (96) re-offer themselves in
--    turn once all three are done, and each re-offer delQuests the old
--    completion first. So every lap returns the entry to the Active list and
--    walks the same steps (repeatable = true).
--
-- 4. STORY GATES LIVE IN THE TEXT, NOT IN PREDICATES. The two patrol quests
--    and the Ruth / Shipilolo legs of two legacy quests wait on the Seekers
--    of Adoulin mission Life on the Frontier, and the fame cycle opens with
--    the Pioneer's Badge from Pioneer Registration. A mission or key-item
--    atom on an accept step could not be proven against the steps after it.
--    The one gate that IS a predicate is Transporting's fame 2, which the
--    linter reads off the script's own accept section (FORMAT §6.10).
--
-- 5. WHAT IS NOT HERE: no Delve, Skirmish, Incursion, Vagary or Sinister
--    Reign, and reives are thin; none of the stepped quests below needs
--    them. Bayld rewards are live. The DWQuest Special shelf sells the
--    Geomancer and Rune Fencer unlocks (Dances with Luopans, Children of the
--    Rune) for 100 Drift Coins each, behind the same ENABLE_SOA flag.
return {
    kind = 'quests',
    log = 9,
    area = 'adoulin_quests',
    label = "Adoulin",
    entries = {
        [0] = { -- TWITHERYM_DUST
            -- Name only: no script offers it on this server.
            name = "Twitherym Dust",
            gated = 'ENABLE_SOA',
        },
        [1] = { -- TO_CATCH_A_PREDATOR
            -- Name only: no script offers it on this server.
            name = "To Catch a Predator",
            gated = 'ENABLE_SOA',
        },
        [2] = { -- EMPTY_NEST
            -- Name only: no script offers it on this server.
            name = "Empty Nest",
            gated = 'ENABLE_SOA',
        },
        [5] = { -- DONT_CLAM_UP_ON_ME_NOW
            -- Name only: no script offers it on this server.
            name = "Don't Clam Up on Me Now",
            gated = 'ENABLE_SOA',
        },
        [6] = { -- HOP_TO_IT
            -- Name only: no script offers it on this server.
            name = "Hop to It",
            gated = 'ENABLE_SOA',
        },
        [9] = { -- BOILING_OVER
            -- Name only: no script offers it on this server.
            name = "Boiling Over",
            gated = 'ENABLE_SOA',
        },
        [10] = { -- POISONING_THE_WELL
            -- Name only: no script offers it on this server.
            name = "Poisoning the Well",
            gated = 'ENABLE_SOA',
        },
        [12] = { -- UNSULLIED_LANDS
            -- Name only: no script offers it on this server.
            name = "Unsullied Lands",
            gated = 'ENABLE_SOA',
        },
        [16] = { -- NO_RIME_LIKE_THE_PRESENT
            -- Name only: no script offers it on this server.
            name = "No Rime Like the Present",
            gated = 'ENABLE_SOA',
        },
        [18] = { -- A_GEOTHERMAL_EXPEDITION
            -- Name only: no script offers it on this server.
            name = "A Geothermal Expedition",
            gated = 'ENABLE_SOA',
        },
        [22] = { -- ENDEAVORING_TO_AWAKEN
            -- Name only: Rune Fencer limit-break quest; monstrosity.lua reads its status, but no script offers it.
            name = "Endeavoring to Awaken",
            gated = 'ENABLE_SOA',
        },
        [23] = { -- FORGING_NEW_BONDS
            -- Name only: a Records of Eminence objective reads its completion, but no script offers it.
            name = "Forging New Bonds",
            gated = 'ENABLE_SOA',
        },
        [24] = { -- LEGACIES_LOST_AND_FOUND
            -- Name only: a Records of Eminence objective reads its completion, but no script offers it.
            name = "Legacies Lost and Found",
            gated = 'ENABLE_SOA',
        },
        [25] = { -- DESTINYS_DEVICE
            -- Name only: a Records of Eminence objective reads its completion, but no script offers it.
            name = "Destiny's Device",
            gated = 'ENABLE_SOA',
        },
        [26] = { -- GRANDDADDY_DEAREST
            -- Name only: no script offers it on this server.
            name = "Granddaddy Dearest",
            gated = 'ENABLE_SOA',
        },
        [27] = { -- WAYWARD_WAYPOINTS
            -- Name only: Shipilolo hands out a recalibration kit while it is active, but nothing offers or completes it.
            name = "Wayward Waypoints",
            gated = 'ENABLE_SOA',
        },
        [28] = { -- ONE_GOOD_TURN
            -- Name only: no script offers it on this server.
            name = "One Good Turn",
            gated = 'ENABLE_SOA',
        },
        [29] = { -- FAILURE_IS_NOT_AN_OPTION
            -- Legacy NPC script (Clautaire); SCRIPT_ALIASES. Name from Clautaire.lua's header.
            name = "F.A.I.L.ure Is Not an Option",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Clautaire in Western Adoulin. He asks for Adoulin fame level 4 and the F.A.I.L. Badge that A Pioneer's Best (Imaginary) Friend rewards.",
                    pos  = "Western Adoulin, Clautaire (!pos 44 4 -159)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Hunk of Bedrock. Nothing on this server hands one out yet, so this quest cannot be finished for now.",
                    done = { ki = 2384 }, -- HUNK_OF_BEDROCK
                },
                {
                    text = "Bring the Hunk of Bedrock to Clautaire.",
                    pos  = "Western Adoulin, Clautaire (!pos 44 4 -159)",
                },
            },
        },
        [30] = { -- ORDER_UP
            -- Name only: five Western Adoulin NPCs mark progress while it is active, but nothing offers or completes it.
            name = "Order Up",
            gated = 'ENABLE_SOA',
        },
        [31] = { -- IT_NEVER_GOES_OUT_OF_STYLE
            -- Name only: no script offers it on this server.
            name = "It Never Goes Out of Style",
            gated = 'ENABLE_SOA',
        },
        [32] = { -- WATER_WATER_EVERYWHERE (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "Water Water Everywhere",
            gated = 'ENABLE_SOA',
        },
        [33] = { -- DIRT_CHEAP
            -- Name only: no script offers it on this server.
            name = "Dirt Cheap",
            gated = 'ENABLE_SOA',
        },
        [34] = { -- FLOWER_POWER
            -- Name only: no script offers it on this server.
            name = "Flower Power",
            gated = 'ENABLE_SOA',
        },
        [35] = { -- ELEMENTARY_MY_DEAR_SYLVIE (name from enum; retail punctuation unverified)
            -- Name only: Geomancer limit-break quest; monstrosity.lua reads its status, but no script offers it.
            name = "Elementary My Dear Sylvie",
            gated = 'ENABLE_SOA',
        },
        [36] = { -- FOR_WHOM_THE_BELL_TOLLS
            -- Name only: a Records of Eminence objective reads its completion, but no script offers it.
            name = "For Whom the Bell Tolls",
            gated = 'ENABLE_SOA',
        },
        [37] = { -- THE_BLOODLINE_OF_ZACARIAH
            -- Name only: a Records of Eminence objective reads its completion, but no script offers it.
            name = "The Bloodline of Zacariah",
            gated = 'ENABLE_SOA',
        },
        [38] = { -- THE_COMMUNION
            -- Name only: a Records of Eminence objective reads its completion, but no script offers it.
            name = "The Communion",
            gated = 'ENABLE_SOA',
        },
        [46] = { -- FLAVORS_OF_OUR_LIVES
            name = "Flavors of Our Lives",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Berghent by the big bridge in Western Adoulin and agree to help.",
                    pos  = "Western Adoulin, Berghent (!pos 95.721 -0.148 -28.680)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Masad inside the Mummers' Coalition.",
                    pos  = "Western Adoulin, Masad (!pos -28.182 -0.650 -91.991)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Speak to Dewalt inside the Couriers' Coalition.",
                    pos  = "Western Adoulin, Dewalt (!pos -23.099 -0.648 28.208)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Go down into Rala Waterways and speak to Chalvava.",
                    pos  = "Rala Waterways, Chalvava (!pos -318 -1 -318)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Trade a Sickle to a Harvesting Point in Yahse Hunting Grounds. A Blightberry comes with the harvest.",
                    pos  = "Yahse Hunting Grounds, Harvesting Point (!pos 196 0.001 289.5)",
                    done = { allOf = { { var = 'Prog', gte = 3 }, { ki = 2386 } } }, -- BLIGHTBERRY
                },
                {
                    text = "Bring the Blightberry back to Berghent.",
                    pos  = "Western Adoulin, Berghent (!pos 95.721 -0.148 -28.680)",
                },
            },
        },
        [50] = { -- WESTERN_WAYPOINTS_HO (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "Western Waypoints Ho",
            gated = 'ENABLE_SOA',
        },
        [51] = { -- WESEASTERN_WAYPOINTS_HO (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "Weseastern Waypoints Ho",
            gated = 'ENABLE_SOA',
        },
        [53] = { -- GRIND_TO_SAWDUST
            -- Name only: no script offers it on this server.
            name = "Grind to Sawdust",
            gated = 'ENABLE_SOA',
        },
        [54] = { -- BREAKING_THE_ICE
            name = "Breaking the Ice",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Traiffeaux in Kamihr Drifts and agree to his request.",
                    pos  = "Kamihr Drifts, Traiffeaux (!pos 437.451 63 -290.512)",
                    done = { status = 1 },
                },
                {
                    text = "Gather three Rabbit Hides and one Raaz Tusk.",
                    done = { allOf = { { item = 856, qty = 3 }, { item = 8709 } } }, -- RABBIT_HIDE, RAAZ_TUSK
                },
                {
                    text = "Trade all four to Traiffeaux in one trade. He gives you a Pair of Fuzzy Earmuffs, and you learn Fragmenting.",
                    pos  = "Kamihr Drifts, Traiffeaux (!pos 437.451 63 -290.512)",
                },
            },
        },
        [55] = { -- IM_ON_A_BOAT
            name = "I'm on a Boat",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Choubollet in Foret de Hennetiel.",
                    pos  = "Foret de Hennetiel, Choubollet (!pos 380.818 -2.094 290.792)",
                    done = { status = 1 },
                },
                {
                    text = "Trade Choubollet three Squares of Dhalmel Leather, an Umbril Ooze and a Twitherym Scale in one trade. He hands you the Watercraft.",
                    pos  = "Foret de Hennetiel, Choubollet (!pos 380.818 -2.094 290.792)",
                    done = { anyOf = { { ki = 2167 }, { var = 'Prog', gte = 1 } } }, -- WATERCRAFT
                },
                {
                    text = "With the Watercraft, examine Castoff Point #4 on the river and take the ride.",
                    pos  = "Foret de Hennetiel, Castoff Point #4 (!pos 220 0.800 146)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Do the same at Castoff Point #5, further along the river, until you have the hang of steering.",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Return to Choubollet to finish and learn Watercrafting.",
                    pos  = "Foret de Hennetiel, Choubollet (!pos 380.818 -2.094 290.792)",
                },
            },
        },
        [56] = { -- A_STONES_THROW_AWAY
            name = "A Stone's Throw Away",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Apolliane in Morimar Basalt Fields.",
                    pos  = "Morimar Basalt Fields, Apolliane (!pos 447.088 -15.846 -320)",
                    done = { status = 1 },
                },
                {
                    text = "Mine a Marble Nugget in Morimar Basalt Fields and trade it to Apolliane. Morimar mining is not implemented here and she refuses every nugget until it is, so this cannot be finished yet.",
                    pos  = "Morimar Basalt Fields, Apolliane (!pos 447.088 -15.846 -320)",
                },
            },
        },
        [57] = { -- HIDE_AND_GO_PEAK
            name = "Hide and Go Peak",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Examine the Toppled Tree in Marjami Ravine to take the quest.",
                    pos  = "Marjami Ravine, Toppled Tree (!pos 356.272 -59.701 149.99)",
                    done = { status = 1 },
                },
                {
                    text = "Search the Velkk Cache for a Large Strip of Velkk Hide.",
                    pos  = "Marjami Ravine, Velkk Cache (!pos 278.126 -0.378 -80.672)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Bring the hide back to the Toppled Tree.",
                    pos  = "Marjami Ravine, Toppled Tree (!pos 356.272 -59.701 149.99)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine Scalable Area #2 to finish. You learn Climbing and receive a Pair of Velkk Gloves.",
                    pos  = "Marjami Ravine, Scalable Area #2 (!pos 271.483 -59.917 92.095)",
                },
            },
        },
        [58] = { -- THE_WHOLE_PLACE_IS_ABUZZ
            -- Name only: no script offers it on this server.
            name = "The Whole Place Is Abuzz",
            gated = 'ENABLE_SOA',
        },
        [59] = { -- OROBON_APPETIT
            -- Name only: no script offers it on this server.
            name = "Orobon Appetit",
            gated = 'ENABLE_SOA',
        },
        [60] = { -- TALK_ABOUT_WRINKLY_SKIN
            -- Name only: no script offers it on this server.
            name = "Talk About Wrinkly Skin",
            gated = 'ENABLE_SOA',
        },
        [61] = { -- NO_LOVE_LOST
            -- Name only: no script offers it on this server.
            name = "No Love Lost",
            gated = 'ENABLE_SOA',
        },
        [62] = { -- DID_YOU_FEEL_THAT (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "Did You Feel That",
            gated = 'ENABLE_SOA',
        },
        [70] = { -- DONT_EVER_LEAF_ME
            -- Name only: Barenngo and Dewalt answer while it is active, but nothing offers or completes it.
            name = "Don't Ever Leaf Me",
            gated = 'ENABLE_SOA',
        },
        [71] = { -- KEEP_YOUR_BLOOMERS_ON_ERISA (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "Keep Your Bloomers on Erisa",
            gated = 'ENABLE_SOA',
        },
        [72] = { -- SCAREDYCATS (name from enum; the NPC scripts spell it "Scaredy-Cats")
            -- Name only: Bilp and Eamonn offer it only after a walk-in cutscene nothing here plays, and nothing completes it.
            name = "Scaredycats",
            gated = 'ENABLE_SOA',
        },
        [73] = { -- RAPTOR_RAPTURE
            -- Name only: legacy scripts (Pagnelle, Gontrain, Western Adoulin Zone.lua), but it cannot be accepted --
            -- the intro warps you to Rala Waterways and nothing there carries it on; its Rockberries have no source.
            name = "Raptor Rapture",
            gated = 'ENABLE_SOA',
        },
        [74] = { -- EXOTIC_DELICACIES
            -- Legacy NPC script (Flapano); SCRIPT_ALIASES. Saffron, Mussel and Barnacle are not in
            -- scripts/enum/item.lua, so the linter cannot resolve an item atom for them: no gather step.
            name = "Exotic Delicacies",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Flapano in Western Adoulin. He brings the quest up only every other time you talk to him and opens his shop in between, so talk to him again if you get the shop.",
                    pos  = "Western Adoulin, Flapano (!pos 70 0 -13)",
                    done = { status = 1 },
                },
                {
                    text = "Trade Flapano a Pinch of Saffron, a Mussel and two Barnacles in one trade. Keep a slot free for the Plate of Flapano's Paella he pays with.",
                    pos  = "Western Adoulin, Flapano (!pos 70 0 -13)",
                },
            },
        },
        [75] = { -- A_PIONEERS_BEST_IMAGINARY_FRIEND
            -- Legacy NPC scripts (Merleg, Ruth); SCRIPT_ALIASES. Name from Merleg.lua's header. Ionis is a
            -- status effect, which no atom reads, so the errand and the turn-in share the final step.
            name = "A Pioneer's Best (Imaginary) Friend",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Merleg in Western Adoulin.",
                    pos  = "Western Adoulin, Merleg (!pos 34 0 -131)",
                    done = { status = 1 },
                },
                {
                    text = "Have Ruth grant you Ionis (she will once your Seekers of Adoulin story reaches Life on the Frontier), then return to Merleg while it is still on you for the F.A.I.L. Badge.",
                    pos  = "Western Adoulin, Ruth (!pos -144 4 -10) / Merleg (!pos 34 0 -131)",
                },
            },
        },
        [76] = { -- HUNGER_STRIKES
            name = "Hunger Strikes",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Westerly Breeze in Western Adoulin; he wants something to eat.",
                    pos  = "Western Adoulin, Westerly Breeze (!pos 62 32 123)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Bowl of Wisdom Soup.",
                    done = { item = 4592 }, -- BOWL_OF_WISDOM_SOUP
                },
                {
                    text = "Trade the Bowl of Wisdom Soup to Westerly Breeze. Any other food you hand him, he eats, and it is gone.",
                    pos  = "Western Adoulin, Westerly Breeze (!pos 62 32 123)",
                },
            },
        },
        [77] = { -- THE_OLD_MAN_AND_THE_HARPOON
            -- Legacy NPC scripts (Jorin, Shipilolo); SCRIPT_ALIASES.
            name = "The Old Man and the Harpoon",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Jorin in Western Adoulin; he hands you a Broken Harpoon.",
                    pos  = "Western Adoulin, Jorin (!pos 92 32 152)",
                    done = { status = 1 },
                },
                {
                    text = "Show the Broken Harpoon to Shipilolo, who swaps it for an Extravagant Harpoon. He only helps once your Seekers of Adoulin story reaches Life on the Frontier.",
                    pos  = "Western Adoulin, Shipilolo (!pos 84 0 -60)",
                    done = { ki = 2193 }, -- EXTRAVAGANT_HARPOON
                },
                {
                    text = "Bring the Extravagant Harpoon back to Jorin.",
                    pos  = "Western Adoulin, Jorin (!pos 92 32 152)",
                },
            },
        },
        [78] = { -- A_CERTAIN_SUBSTITUTE_PATROLMAN
            name = "A Certain Substitute Patrolman",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Rising Solstice in Western Adoulin to stand in on the patrol. Offered once your Seekers of Adoulin story reaches Life on the Frontier.",
                    pos  = "Western Adoulin, Rising Solstice (!pos -154 4 -29)",
                    done = { status = 1 },
                },
                {
                    text = "Walk the route in order, starting with Zaoso. Anyone spoken to out of turn has nothing to say.",
                    pos  = "Western Adoulin, Zaoso (!pos -94 3 -11)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Next, Clemmar.",
                    pos  = "Western Adoulin, Clemmar (!pos -12 0 12)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Next, Kongramm.",
                    pos  = "Western Adoulin, Kongramm (!pos 61 32 138)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Next, Virsaint.",
                    pos  = "Western Adoulin, Virsaint (!pos 32 0 -5)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Next, Shipilolo.",
                    pos  = "Western Adoulin, Shipilolo (!pos 84 0 -60)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Next, Dangueubert.",
                    pos  = "Western Adoulin, Dangueubert (!pos 5 0 -136)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Last stop, Nylene.",
                    pos  = "Western Adoulin, Nylene (!pos 12 0 -82)",
                    done = { var = 'Prog', gte = 7 },
                },
                {
                    text = "Report back to Rising Solstice.",
                    pos  = "Western Adoulin, Rising Solstice (!pos -154 4 -29)",
                },
            },
        },
        [79] = { -- IT_SETS_MY_HEART_AFLUTTER
            name = "It Sets My Heart Aflutter",
            gated = 'ENABLE_SOA',
            repeatable = true,
            steps = {
                {
                    text = "Speak to Saldinor in Rala Waterways. He only asks holders of the Pioneer's Badge, from the Seekers of Adoulin mission Pioneer Registration.",
                    pos  = "Rala Waterways, Saldinor (!pos -338.882 -1.000 -308.252)",
                    done = { status = 1 },
                },
                {
                    text = "Get two Twitherym Wings.",
                    done = { item = 3930, qty = 2 }, -- TWITHERYM_WING
                },
                {
                    text = "Trade both wings to Saldinor. Once this, A Good Pair of Crocs and A Shot in the Dark are all done, the three re-open in turn, starting with Crocs.",
                    pos  = "Rala Waterways, Saldinor (!pos -338.882 -1.000 -308.252)",
                },
            },
        },
        [82] = { -- TRANSPORTING
            name = "Transporting",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Vaulois in Western Adoulin; he needs Adoulin fame level 2. He hands you a Misdelivered Parcel.",
                    pos  = "Western Adoulin, Vaulois (!pos 20 0 85)",
                    done = { allOf = { { status = 1 }, { fame = { area = 15, level = 2 } } } }, -- fameArea.ADOULIN
                },
                {
                    text = "Speak to Kongramm about the parcel.",
                    pos  = "Western Adoulin, Kongramm (!pos 61 32 138)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Deliver the parcel at the sluice gate ??? in Rala Waterways.",
                    pos  = "Rala Waterways, sluice gate ??? (!pos -563 -5.768 61.5)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Report back to Vaulois.",
                    pos  = "Western Adoulin, Vaulois (!pos 20 0 85)",
                },
            },
        },
        [84] = { -- THE_STARVING
            name = "The Starving",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- DriftwoodXI (2026-09-30): offered only once Hunger Strikes is done
                    -- (it used to be offered alongside it); HS's finish stamps a next-day wait.
                    text = "Once Hunger Strikes is done, speak to Westerly Breeze in Western Adoulin again from the next Vana'diel day; this time he wants a drink.",
                    pos  = "Western Adoulin, Westerly Breeze (!pos 62 32 123)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Bottle of Goblin Drink.",
                    done = { item = 4541 }, -- BOTTLE_OF_GOBLIN_DRINK
                },
                {
                    text = "Trade the Bottle of Goblin Drink to Westerly Breeze. Any other drink you hand him, he drinks, and it is gone.",
                    pos  = "Western Adoulin, Westerly Breeze (!pos 62 32 123)",
                },
            },
        },
        [85] = { -- FERTILE_GROUND
            -- Name only: Shipilolo hands out the fertilizer while it is active, but nothing offers or completes it.
            name = "Fertile Ground",
            gated = 'ENABLE_SOA',
        },
        [88] = { -- ALWAYS_MORE_QUOTH_THE_RAVENOUS (name from enum; retail punctuation unverified)
            -- Legacy NPC script (Westerly Breeze); SCRIPT_ALIASES.
            name = "Always More Quoth the Ravenous",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    -- DriftwoodXI (2026-09-30): The Starving's finish now writes the zone and
                    -- next-day wait this legacy script reads (Westerly_Breeze_Wait, needToZone).
                    text = "After The Starving, zone out and back, wait for the next Vana'diel day, then speak to Westerly Breeze in Western Adoulin; he asks for this at Adoulin fame level 3.",
                    pos  = "Western Adoulin, Westerly Breeze (!pos 62 32 123)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Bottle of Cursed Beverage. Do not hand him any other drink meanwhile: he drinks it and the item is gone.",
                    done = { item = 4234 }, -- BOTTLE_OF_CURSED_BEVERAGE
                },
                {
                    text = "Trade the Bottle of Cursed Beverage to Westerly Breeze.",
                    pos  = "Western Adoulin, Westerly Breeze (!pos 62 32 123)",
                },
            },
        },
        [89] = { -- MEGALOMANIAC
            -- Name only: no script offers it on this server.
            name = "Megalomaniac",
            gated = 'ENABLE_SOA',
        },
        [91] = { -- THE_LONGEST_WAY_ROUND
            name = "The Longest Way Round...",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Vastran in Eastern Adoulin to take over the patrol. Offered once your Seekers of Adoulin story reaches Life on the Frontier.",
                    pos  = "Eastern Adoulin, Vastran (!pos -118.93 -0.15 -8.813)",
                    done = { status = 1 },
                },
                {
                    text = "Walk the route in order, starting with Fostaig. Anyone spoken to out of turn has nothing to say.",
                    pos  = "Eastern Adoulin, Fostaig (!pos -84.806 -0.15 14.079)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Next, Lamaron.",
                    pos  = "Eastern Adoulin, Lamaron (!pos -52.352 -0.65 96.708)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Next, the Irate Destrier.",
                    pos  = "Eastern Adoulin, Irate Destrier (!pos -72.986 -0.15 -34.96)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Next, Nhili Uvolep.",
                    pos  = "Eastern Adoulin, Nhili Uvolep (!pos 24.06 -22.15 34.488)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Next, Ploh Trishbahk.",
                    pos  = "Eastern Adoulin, Ploh Trishbahk (!pos 100.58 -40.15 -63.83)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Next, Cunegonde.",
                    pos  = "Eastern Adoulin, Cunegonde (!pos -55.964 -0.15 -129.833)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Last stop, Ndah Tolohjin.",
                    pos  = "Eastern Adoulin, Ndah Tolohjin (!pos -86.808 0.001 -36.867)",
                    done = { var = 'Prog', gte = 7 },
                },
                {
                    text = "Report back to Vastran.",
                    pos  = "Eastern Adoulin, Vastran (!pos -118.93 -0.15 -8.813)",
                },
            },
        },
        [93] = { -- A_GOOD_PAIR_OF_CROCS
            name = "A Good Pair of Crocs",
            gated = 'ENABLE_SOA',
            repeatable = true,
            steps = {
                {
                    text = "Speak to Felmsy in Eastern Adoulin.",
                    pos  = "Eastern Adoulin, Felmsy (!pos -53.111 -0.150 88.456)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Velkk Necklace or a Velkk Mask; either one will do.",
                    done = { anyOf = { { item = 3928 }, { item = 3929 } } }, -- VELKK_NECKLACE, VELKK_MASK
                },
                {
                    text = "Trade it to Felmsy. This is the middle of the fame cycle with It Sets My Heart Aflutter and A Shot in the Dark.",
                    pos  = "Eastern Adoulin, Felmsy (!pos -53.111 -0.150 88.456)",
                },
            },
        },
        [94] = { -- CAFETERIA
            -- Name only: no script offers it on this server.
            name = "Cafeteria",
            gated = 'ENABLE_SOA',
        },
        [96] = { -- A_SHOT_IN_THE_DARK
            name = "A Shot in the Dark",
            gated = 'ENABLE_SOA',
            repeatable = true,
            steps = {
                {
                    text = "Speak to Pudith in Eastern Adoulin.",
                    pos  = "Eastern Adoulin, Pudith (!pos -109.533 -0.150 56.939)",
                    done = { status = 1 },
                },
                {
                    text = "Get an Umbril Ooze.",
                    done = { item = 3935 }, -- UMBRIL_OOZE
                },
                {
                    text = "Trade the Umbril Ooze to Pudith. That closes a lap of the fame cycle; once all three are done, It Sets My Heart Aflutter re-opens next.",
                    pos  = "Eastern Adoulin, Pudith (!pos -109.533 -0.150 56.939)",
                },
            },
        },
        [100] = { -- OPEN_THE_FLOODGATES (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "Open the Floodgates",
            gated = 'ENABLE_SOA',
        },
        [102] = { -- NO_LAUGHING_MATTER
            -- Name only: no script offers it on this server.
            name = "No Laughing Matter",
            gated = 'ENABLE_SOA',
        },
        [103] = { -- ALL_THE_WAY_TO_THE_BANK
            -- Name only: Defliaa, Hujette and Flapano take payments while it is active, but nothing offers it or issues the invoice.
            name = "All the Way to the Bank",
            gated = 'ENABLE_SOA',
        },
        [104] = { -- TO_LAUGH_IS_TO_LOVE
            -- Name only: no script offers it on this server.
            name = "To Laugh Is to Love",
            gated = 'ENABLE_SOA',
        },
        [105] = { -- A_BARREL_OF_LAUGHS
            -- Name only: no script offers it on this server.
            name = "A Barrel of Laughs",
            gated = 'ENABLE_SOA',
        },
        [108] = { -- VEGETABLE_VEGETABLE_REVOLUTION (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "Vegetable Vegetable Revolution",
            gated = 'ENABLE_SOA',
        },
        [109] = { -- VEGETABLE_VEGETABLE_EVOLUTION (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "Vegetable Vegetable Evolution",
            gated = 'ENABLE_SOA',
        },
        [110] = { -- VEGETABLE_VEGETABLE_CRISIS (name from enum; retail punctuation unverified)
            -- Name only: Chanteillie takes a trade while it is active, but nothing offers or completes it.
            name = "Vegetable Vegetable Crisis",
            gated = 'ENABLE_SOA',
        },
        [111] = { -- VEGETABLE_VEGETABLE_FRUSTRATION (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "Vegetable Vegetable Frustration",
            gated = 'ENABLE_SOA',
        },
        [114] = { -- A_THIRST_FOR_THE_AGES
            -- Name only: Nikkhail hands over a key item while it is active, but nothing offers or completes it.
            name = "A Thirst for the Ages",
            gated = 'ENABLE_SOA',
        },
        [115] = { -- A_THIRST_FOR_THE_EONS
            -- Name only: no script offers it on this server.
            name = "A Thirst for the Eons",
            gated = 'ENABLE_SOA',
        },
        [116] = { -- A_THIRST_FOR_ETERNITY
            -- Name only: no script offers it on this server.
            name = "A Thirst for Eternity",
            gated = 'ENABLE_SOA',
        },
        [117] = { -- A_THIRST_BEFORE_TIME
            -- Name only: no script offers it on this server.
            name = "A Thirst Before Time",
            gated = 'ENABLE_SOA',
        },
        [118] = { -- DANCES_WITH_LUOPANS
            name = "Dances with Luopans",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Sylvie in Western Adoulin and agree to learn geomancy. The DWQuest Special shelf also sells the Geomancer unlock for 100 Drift Coins.",
                    pos  = "Western Adoulin, Sylvie (!pos 78.094 32.000 135.725)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the Ergon Locus in your own nation's field for a Fistful of Homeland Soil: La Theine Plateau for San d'Oria, Konschtat Highlands for Bastok, Tahrongi Canyon for Windurst.",
                    done = { anyOf = { { ki = 2278 }, { ki = 2290 }, { var = 'Prog', gte = 1 } } }, -- FISTFUL_OF_HOMELAND_SOIL, LUOPAN
                },
                {
                    text = "Trade a Petrified Log to Sylvie while holding the soil. She gives you a Luopan.",
                    pos  = "Western Adoulin, Sylvie (!pos 78.094 32.000 135.725)",
                    done = { anyOf = { { ki = 2290 }, { var = 'Prog', gte = 1 } } }, -- LUOPAN
                },
                {
                    text = "Carry the Luopan into an Ergon Locus area in Ceizak Battlegrounds or Yahse Hunting Grounds, stand inside it and /heal until a mystical warmth comes over you (up to eight minutes).",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Return to Sylvie to become a Geomancer. Keep two inventory slots free for the Plate of Indi-Poison and the Matre Bell.",
                    pos  = "Western Adoulin, Sylvie (!pos 78.094 32.000 135.725)",
                },
            },
        },
        [119] = { -- CHILDREN_OF_THE_RUNE
            -- Legacy NPC scripts (Octavien, Yahse Wildflower); SCRIPT_ALIASES. Octavien's pos is npc_list
            -- 17830004; his script header gave Ploh Trishbahk's coordinates until 2026-09-30.
            name = "Children of the Rune",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Octavien, a palace guard in Eastern Adoulin, and accept. The DWQuest Special shelf also sells the Rune Fencer unlock for 100 Drift Coins.",
                    pos  = "Eastern Adoulin, Octavien (!pos 2.444 -11.439 -16.595)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the Yahse Wildflower in Yahse Hunting Grounds for a Yahse Wildflower Petal.",
                    pos  = "Yahse Hunting Grounds, Yahse Wildflower (!pos 370.6285 0.6692 153.3728)",
                    done = { ki = 2279 }, -- YAHSE_WILDFLOWER_PETAL
                },
                {
                    text = "Bring the petal back to Octavien and see his scene through; it halves your HP and MP. Keep a slot free for the Sowilo Claymore, or he holds the reward until you come back.",
                    pos  = "Eastern Adoulin, Octavien (!pos 2.444 -11.439 -16.595)",
                },
            },
        },
        [120] = { -- FLOWERS_FOR_SVENJA
            -- Name only: no script offers it on this server.
            name = "Flowers for Svenja",
            gated = 'ENABLE_SOA',
        },
        [121] = { -- THORN_IN_THE_SIDE
            -- Name only: no script offers it on this server.
            name = "Thorn in the Side",
            gated = 'ENABLE_SOA',
        },
        [122] = { -- DO_NOT_GO_INTO_THE_LIGHT
            -- Name only: Chanteillie takes a trade while it is active, but nothing offers or completes it.
            name = "Do Not Go Into the Light",
            gated = 'ENABLE_SOA',
        },
        [123] = { -- VELKKOVERT_OPERATIONS
            -- Name only: no script offers it on this server.
            name = "Velkkovert Operations",
            gated = 'ENABLE_SOA',
        },
        [124] = { -- HYPOCRITICAL_OATH
            -- Name only: Grevan reads it for dialogue only; no script offers it.
            name = "Hypocritical Oath",
            gated = 'ENABLE_SOA',
        },
        [125] = { -- THE_GOOD_THE_BAD_THE_CLEMENT (name from enum; retail punctuation unverified)
            -- Name only: no script offers it on this server.
            name = "The Good the Bad the Clement",
            gated = 'ENABLE_SOA',
        },
        [126] = { -- LERENES_LAMENT
            name = "Lerene's Lament",
            gated = 'ENABLE_SOA',
            steps = {
                {
                    text = "Speak to Lerene in Outer Ra'Kaznar and agree to help.",
                    pos  = "Outer Ra'Kaznar, Lerene (!pos -46.876 -179.334 -28.602)",
                    done = { status = 1 },
                },
                {
                    text = "Get two Squares of Ancestral Cloth.",
                    done = { item = 8751, qty = 2 }, -- SQUARE_OF_ANCESTRAL_CLOTH
                },
                {
                    text = "Trade both squares to Lerene. She gives you Lerene's Paten, and you learn Pulverizing.",
                    pos  = "Outer Ra'Kaznar, Lerene (!pos -46.876 -179.334 -28.602)",
                },
            },
        },
        [127] = { -- THE_SECRET_TO_SUCCESS
            -- Name only: no script offers it on this server.
            name = "The Secret to Success",
            gated = 'ENABLE_SOA',
        },
        [128] = { -- NO_MERCY_FOR_THE_WICKED
            -- Name only: no script offers it on this server.
            name = "No Mercy for the Wicked",
            gated = 'ENABLE_SOA',
        },
        [129] = { -- MISTRESS_OF_CEREMONIES
            -- Name only: no script offers it on this server.
            name = "Mistress of Ceremonies",
            gated = 'ENABLE_SOA',
        },
        [131] = { -- SAVED_BY_THE_BELL
            -- Name only: no script offers it on this server.
            name = "Saved by the Bell",
            gated = 'ENABLE_SOA',
        },
        [132] = { -- QUIESCENCE
            -- Name only: no script offers it on this server.
            name = "Quiescence",
            gated = 'ENABLE_SOA',
        },
        [133] = { -- SICK_AND_TIRED
            -- Name only: no script offers it on this server.
            name = "Sick and Tired",
            gated = 'ENABLE_SOA',
        },
        [134] = { -- GEOMANCERRIFIC
            -- Name only: no script offers it on this server.
            name = "Geomancerrific",
            gated = 'ENABLE_SOA',
        },
        [135] = { -- RUNE_FENCING_THE_NIGHT_AWAY
            -- Name only: no script offers it on this server.
            name = "Rune Fencing the Night Away",
            gated = 'ENABLE_SOA',
        },
        [136] = { -- THE_WEATHERSPOON_INQUISITION
            -- Name only: no script offers it on this server.
            name = "The Weatherspoon Inquisition",
            gated = 'ENABLE_SOA',
        },
        [137] = { -- EYE_OF_THE_BEHOLDER
            -- Name only: no script offers it on this server.
            name = "Eye of the Beholder",
            gated = 'ENABLE_SOA',
        },
        [138] = { -- THE_CURIOUS_CASE_OF_MELVIEN
            -- Name only: Mastan hands over a key item while it is active, but nothing offers or completes it.
            name = "The Curious Case of Melvien",
            gated = 'ENABLE_SOA',
        },
        [139] = { -- NOTSOCLEAN_BILL (name from enum; retail punctuation unverified)
            -- Name only: Grevan reads it for dialogue only; no script offers it.
            name = "Notsoclean Bill",
            gated = 'ENABLE_SOA',
        },
        [140] = { -- IN_THE_LAND_OF_THE_BLIND
            -- Name only: no script offers it on this server.
            name = "In the Land of the Blind",
            gated = 'ENABLE_SOA',
        },
        [141] = { -- THE_WEATHERSPOON_WAR
            -- Name only: Flapano answers at one stage while it is active, but nothing offers or completes it.
            name = "The Weatherspoon War",
            gated = 'ENABLE_SOA',
        },
        [142] = { -- TREASURES_OF_THE_EARTH
            -- Name only: no script offers it on this server.
            name = "Treasures of the Earth",
            gated = 'ENABLE_SOA',
        },
        [143] = { -- EPIPHANY
            -- Name only: no script offers it on this server.
            name = "Epiphany",
            gated = 'ENABLE_SOA',
        },
    },
}
