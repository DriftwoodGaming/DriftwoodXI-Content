-- dwtracker data -- Crystal War quests (quest log 7, Wings of the Goddess),
-- authored 2026-09-30 while the expansion is still SHUT. Names from the
-- scripts' own header comments and the enum (scripts/globals/quests.lua,
-- xi.quest.id.crystalWar); steps HAND-AUTHORED from
-- scripts/quests/crystalWar/*.lua as ground truth, plus the legacy zone NPC
-- scripts that run the five quests with no framework file.
-- Pure data: numeric ids and display strings only, no xi.*, no functions
-- (DWTRACKER_FORMAT.md decisions T2/§3-4). Loaded byte-identically by the
-- server module and the dwtracker addon; both hash these bytes, so an edit
-- that reaches only one side makes the addon refuse step rendering for
-- this area until the copies agree again. tools/dwtracker_lint.py must
-- pass before any edit here ships.
--
-- SIX THINGS ABOUT THIS LOG THAT SHAPE THE ENTRIES BELOW:
--
-- 1. WINGS OF THE GODDESS IS CLOSED (ENABLE_WOTG is 0 in settings/main.lua).
--    Every entry carries gated = 'ENABLE_WOTG' and GATED_PINS pins the whole
--    id range, so nothing here renders until the flag flips.
--
-- 2. 55 OF THE 95 IDS CARRY STEPS. 47 have a framework script. Five more --
--    Redeeming Rocks (4), Evil at the Inlet (21), Requiem for the Departed
--    (23), Beans Ahoy (29) and Say It with a Handbag (41) -- live in LEGACY
--    ZONE NPC SCRIPTS with raw charVars, and the three Her Memories errands
--    (65-67) are opened and closed from inside Homecoming Queen's file. All
--    eight are recorded in SCRIPT_ALIASES and step on quest status, key
--    items and items only: the var atom would read Quest[7][id]<name>,
--    which none of those files write. The other 40 ids are authored NAME
--    ONLY, each with its reason.
--
-- 3. THE FIGHTS UPSTREAM NEVER BUILT ARE PASSED THROUGH (owner decision,
--    2026-09-24; PLANS/CONTENT_STATUS.md §7). Fire in the Hole, In a Haze of
--    Glory, Honor Under Fire, Bonds That Never Die, What Price Loyalty, Blood
--    of Heroes, Face of the Future and Bonds of Mythril each wait on an
--    instance or battlefield that does not exist; the door NPC now does what
--    the win would have done and the after-battle cutscene plays. Songbirds
--    in a Snowstorm's key-item fishing is handed over at the Rocky Perch the
--    same way. The steps describe what a player actually does HERE.
--
-- 4. WHAT DEAD-ENDS, said in the step text where a player would meet it:
--    the Orcish Bloodletter (Songbirds in a Snowstorm) and Menechme (Chasing
--    Shadows) are level-150 placeholders, so the San d'Oria line is walled
--    at quest 9. The Windurst line stops after Knot Quite There (3): A
--    Manifest Problem and every later Windurst quest are unscripted. Her
--    Memories: Verdure Footfalls is unscripted, so Carnelian Footfalls opens
--    for every allegiance except Bastok's as a stopgap. Campaign is absent,
--    so nothing that needs Allied Notes or a Campaign rank is offered.
--
-- 5. THE NATION LINES ARE NOT NATION-LOCKED. Quest 1 of each line opens
--    once ANY nation's quest 0 is done (xi.wotg.helpers.hasCompletedFirstQuest);
--    only the quest-0 finish pledges an allegiance.
--
-- 6. TWO `Option` VARS ARE PROGRESS, NOT DIALOGUE TOGGLES: Gifts of the
--    Griffon and Carnelian Footfalls keep a bitmask of the NPCs already
--    visited there (setVarBit), full at 127 and 7. Everywhere else Option,
--    Timer and must-zone are left alone. Light in the Darkness writes Prog 7
--    for a FAILED run, above the win's 5, so its fight step reads eq, not gte.
return {
    kind = 'quests',
    log = 7,
    area = 'crystalwar_quests',
    label = "Crystal War",
    entries = {
        [0] = { -- LOST_IN_TRANSLOCATION
            name = "Lost in Translocation",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Thorben in Batallia Downs [S] to take the job.",
                    pos  = "Batallia Downs [S], Thorben (!pos 175.346 8.038 -419.244)",
                    done = { status = 1 },
                },
                {
                    text = "Collect the three map pieces in The Eldieme Necropolis [S], in any order: talk to Erik, and examine the Gravestone and the Sarcophagus.",
                    pos  = "The Eldieme Necropolis [S], Erik (!pos 258.643 -33.249 99.901) / Gravestone (!pos 254.428 -32.999 20.001)",
                    done = { allOf = { { ki = 912 }, { ki = 913 }, { ki = 914 } } }, -- LEFT/MIDDLE/RIGHT_MAP_PIECE
                },
                {
                    text = "Take all three pieces back to Thorben for the Map of Grauberg.",
                    pos  = "Batallia Downs [S], Thorben (!pos 175.346 8.038 -419.244)",
                },
            },
        },
        [1] = { -- MESSAGE_ON_THE_WINDS
            name = "Message on the Wind",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "At level 20 or higher, speak to Romualdo at the Metalworks cannonry, then find him again in Batallia Downs [S]. The quest enters your log there.",
                    pos  = "Metalworks, Romualdo (!pos 133 -19 -36) / Batallia Downs [S], Romualdo (!pos 54 -14 141)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Childerich at the house in Grauberg [S].",
                    pos  = "Grauberg [S], Childerich (!pos -313 16 -515)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the ??? in Grauberg [S].",
                    pos  = "Grauberg [S], ??? (!pos 439 -40 79)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Report back to Childerich.",
                    pos  = "Grauberg [S], Childerich (!pos -313 16 -515)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Return to Romualdo in Batallia Downs [S] to finish.",
                    pos  = "Batallia Downs [S], Romualdo (!pos 54 -14 141)",
                },
            },
        },
        [2] = { -- THE_WEEKLY_ADVENTURER
            name = "The Weekly Adventurer",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Naiko-Paneiko in Crawlers' Nest [S]. He hands you a linkpearl and sends you out as his reporter.",
                    pos  = "Crawlers' Nest [S], Naiko-Paneiko (!pos 294.030 -33.443 -28.637)",
                    done = { status = 1 },
                },
                {
                    text = "Interview Rakula-Motakula in Rolanberry Fields [S] and answer his quiz correctly (the script's own note gives 4, 4, 5). Got it wrong? Report to Naiko-Paneiko, then try again.",
                    pos  = "Rolanberry Fields [S], Rakula-Motakula (!pos -316.786 -12.448 -118.721)",
                    done = { var = 'Prog', eq = 1 },
                },
                {
                    text = "Report back to Naiko-Paneiko for the Map of Fort Karugo-Narugo.",
                    pos  = "Crawlers' Nest [S], Naiko-Paneiko (!pos 294.030 -33.443 -28.637)",
                },
            },
        },
        [3] = { -- HEALING_HERBS
            -- Name only: no script offers it on this server.
            name = "Healing Herbs",
            gated = 'ENABLE_WOTG',
        },
        [4] = { -- REDEEMING_ROCKS
            -- Legacy zone NPC scripts (Kocco Ehllek, Rohn Ehlbalna, Vunkerl qm4); aliased in dwtracker_lint.py.
            name = "Redeeming Rocks",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Kocco Ehllek in Windurst Waters [S] to take the job.",
                    pos  = "Windurst Waters [S], Kocco Ehllek (!pos -41.465 -2.125 -163.018)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Rohn Ehlbalna, then to Kocco Ehllek again, then examine the ??? in Vunkerl Inlet [S] for a Piece of Kionite.",
                    pos  = "Windurst Waters [S], Rohn Ehlbalna (!pos -43.473 -4.5 46.496) / Vunkerl Inlet [S], ??? (!pos -412 -29 -45)",
                    done = { ki = 953 }, -- PIECE_OF_KIONITE
                },
                {
                    text = "Take the Kionite to Kocco Ehllek, then speak to him again after the next Vana'diel day for Kocco's Earring.",
                    pos  = "Windurst Waters [S], Kocco Ehllek (!pos -41.465 -2.125 -163.018)",
                },
            },
        },
        [5] = { -- THE_DAWN_OF_DELECTABILITY
            name = "The Dawn of Delectability",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Ranpi-Monpi in Windurst Waters [S] to take the job.",
                    pos  = "Windurst Waters [S], Ranpi-Monpi (!pos -115 -3 43)",
                    done = { status = 1 },
                },
                {
                    text = "Find Ranpi-Monpi in present-day Windurst Waters; he names the ingredients he needs.",
                    pos  = "Windurst Waters, Ranpi-Monpi (!pos -116 -3 52)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Trade him a Pepperoni, a Walnut, a Dragon Fruit and a Bastore Sweeper, all in one trade.",
                    pos  = "Windurst Waters, Ranpi-Monpi (!pos -116 -3 52)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Wait for the next Vana'diel day, then speak to him again for Ranpi-Monpi's specialty.",
                    pos  = "Windurst Waters, Ranpi-Monpi (!pos -116 -3 52)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Carry the specialty back to Ranpi-Monpi in Windurst Waters [S].",
                    pos  = "Windurst Waters [S], Ranpi-Monpi (!pos -115 -3 43)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Return to Ranpi-Monpi in present-day Windurst Waters to finish.",
                    pos  = "Windurst Waters, Ranpi-Monpi (!pos -116 -3 52)",
                },
            },
        },
        [6] = { -- A_LITTLE_KNOWLEDGE
            name = "A Little Knowledge",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "At level 30 or higher, speak to Erlene in The Eldieme Necropolis [S] and agree to help. The DWQuest Special shelf sells the Scholar unlock for 100 Drift Coins.",
                    pos  = "The Eldieme Necropolis [S], Erlene (!pos 376.936 -39.999 17.914)",
                    done = { status = 1 },
                },
                {
                    text = "Gather twelve Sheets of Vellum. Tucker in Crawlers' Nest [S] trades them for Rolanberries: one sheet per stack of 12, up to four sheets a trade, three trades in all.",
                    done = { anyOf = { { var = 'Prog', gte = 1 }, { item = 2550, qty = 12 } } }, -- SHEET_OF_VELLUM
                },
                {
                    text = "Trade all twelve Sheets of Vellum to Erlene at once.",
                    pos  = "The Eldieme Necropolis [S], Erlene (!pos 376.936 -39.999 17.914)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Use Manafont, Chainspell, Astral Flow or Azure Lore and speak to Erlene while it is still active to unlock Scholar.",
                    pos  = "The Eldieme Necropolis [S], Erlene (!pos 376.936 -39.999 17.914)",
                },
            },
        },
        [7] = { -- THE_FIGHTING_FOURTH
            name = "The Fighting Fourth",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Get a Blue Recommendation Letter from Turbulent Storm in The Eldieme Necropolis [S], then enlist with Adelbrecht in Bastok Markets [S]. He swaps it for Battle Rations.",
                    pos  = "Bastok Markets [S], Adelbrecht (!pos -325.766 -12.601 -76.977)",
                    done = { status = 1 },
                },
                {
                    text = "Deliver the Battle Rations to Gebhardt in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], Gebhardt (!pos 206.299 -20.826 669.125)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Speak to Roderich in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], Roderich (!pos -400.039 39.991 -90.445)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the Barricade in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], Barricade (!pos -514.960 37.979 583.287)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Report to Adelbrecht. Finishing pledges you to Bastok; a first pledge also brings Sprinter's Shoes and the Bronze Ribbon of Service.",
                    pos  = "Bastok Markets [S], Adelbrecht (!pos -325.766 -12.601 -76.977)",
                },
            },
        },
        [8] = { -- SNAKE_ON_THE_PLAINS
            name = "Snake on the Plains",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Get a Green Recommendation Letter from Kalsu-Kalasu in Crawlers' Nest [S], then take it to Miah Riyuh in Windurst Waters [S] and accept. She gives you a pot of putty.",
                    pos  = "Windurst Waters [S], Miah Riyuh (!pos 5.323 -2 37.462)",
                    done = { status = 1 },
                },
                {
                    text = "Seal all three Sealed Entrances in West Sarutabaruta [S] with the putty, in any order.",
                    pos  = "West Sarutabaruta [S], Sealed Entrance (!pos -245.000 -18.100 660.000)",
                    done = { var = 'Doors', gte = 7 },
                },
                {
                    text = "Report to Miah Riyuh. Finishing pledges you to Windurst; a first pledge also brings Sprinter's Shoes and the Bronze Ribbon of Service.",
                    pos  = "Windurst Waters [S], Miah Riyuh (!pos 5.323 -2 37.462)",
                },
            },
        },
        [9] = { -- STEAMED_RAMS
            name = "Steamed Rams",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Get a Red Recommendation Letter from Randecque in Garlaige Citadel [S], then take it to Mainchelite in Southern San d'Oria [S] and accept.",
                    pos  = "Southern San d'Oria [S], Mainchelite (!pos -16 1 -30)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the three ??? in East Ronfaure [S], in any order, for a Charred Propeller, an Oxidized Plate and a Piece of Shattered Lumber.",
                    pos  = "East Ronfaure [S], ??? (!pos 312.821 -30.495 -67.15) / ??? (!pos 541.425 -49.83 178.563)",
                    done = { allOf = { { ki = 950 }, { ki = 951 }, { ki = 952 } } }, -- CHARRED_PROPELLER, PIECE_OF_SHATTERED_LUMBER, OXIDIZED_PLATE
                },
                {
                    text = "Bring all three to Mainchelite. Finishing pledges you to San d'Oria; a first pledge also brings Sprinter's Shoes and the Bronze Ribbon of Service.",
                    pos  = "Southern San d'Oria [S], Mainchelite (!pos -16 1 -30)",
                },
            },
        },
        [10] = { -- SEEING_SPOTS
            name = "Seeing Spots",
            gated = 'ENABLE_WOTG',
            repeatable = true,
            steps = {
                {
                    text = "Speak to Wyatt in Southern San d'Oria [S].",
                    pos  = "Southern San d'Oria [S], Wyatt (!pos 124 0 84)",
                    done = { status = 1 },
                },
                {
                    text = "Collect four Ladybug Wings.",
                    done = { item = 2506, qty = 4 }, -- LADYBUG_WING
                },
                {
                    text = "Trade all four Ladybug Wings to Wyatt for 3,000 gil. He keeps buying sets of four after the quest is done.",
                    pos  = "Southern San d'Oria [S], Wyatt (!pos 124 0 84)",
                },
            },
        },
        [11] = { -- THE_FLIPSIDE_OF_THINGS
            name = "The Flipside of Things",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Rarcasmeault in Garlaige Citadel [S] and agree to help.",
                    pos  = "Garlaige Citadel [S], Rarcasmeault (!pos 146.175 -6.000 93.04)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the ??? in Garlaige Citadel [S] for the Firepower Case.",
                    pos  = "Garlaige Citadel [S], ??? (!pos -69.588 -1.415 57.695)",
                    done = { ki = 949 }, -- FIREPOWER_CASE
                },
                {
                    text = "Bring the Firepower Case to Rarcasmeault for the Map of Vunkerl Inlet.",
                    pos  = "Garlaige Citadel [S], Rarcasmeault (!pos 146.175 -6.000 93.04)",
                },
            },
        },
        [12] = { -- BETTER_PART_OF_VALOR
            name = "Better Part of Valor",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "With any nation's first Crystal War quest done, walk from Bastok Markets [S] into North Gustaberg [S]. The cutscene starts this and hands you a Clump of Animal Hair.",
                    done = { status = 1 },
                },
                {
                    text = "Show the Clump of Animal Hair to Engelhart in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Engelhart (!pos -79 -4 -123)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the ??? in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], ??? (!pos -232 41 425)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Speak to Leadavox in Vunkerl Inlet [S].",
                    pos  = "Vunkerl Inlet [S], Leadavox (!pos 206 -32 316)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Trade Leadavox a Gnole Claw.",
                    pos  = "Vunkerl Inlet [S], Leadavox (!pos 206 -32 316)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Report to Engelhart in Bastok Markets [S] to finish.",
                    pos  = "Bastok Markets [S], Engelhart (!pos -79 -4 -123)",
                },
            },
        },
        [13] = { -- FIRES_OF_DISCONTENT
            name = "Fires of Discontent",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Engelhart in Bastok Markets [S] to take the job.",
                    pos  = "Bastok Markets [S], Engelhart (!pos -80.085 -4.425 -125.327)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Pagdako in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Pagdako (!pos -202.080 -6.000 -93.928)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Speak to Iron Eater in the present-day Metalworks.",
                    pos  = "Metalworks, Iron Eater (!pos 92.936 -19.532 1.814)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Report to Engelhart.",
                    pos  = "Bastok Markets [S], Engelhart (!pos -80.085 -4.425 -125.327)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the ??? in Grauberg [S].",
                    pos  = "Grauberg [S], ??? (!pos 259.793 33.192 515.257)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Report to Engelhart again.",
                    pos  = "Bastok Markets [S], Engelhart (!pos -80.085 -4.425 -125.327)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Speak to Gentle Tiger in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Return to Engelhart to finish.",
                    pos  = "Bastok Markets [S], Engelhart (!pos -80.085 -4.425 -125.327)",
                },
            },
        },
        [14] = { -- HAMMERING_HEARTS
            name = "Hammering Hearts",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Scarred Shark in Bastok Markets [S] and agree to help.",
                    pos  = "Bastok Markets [S], Scarred Shark (!pos -233.989 -2.000 67.638)",
                    done = { status = 1 },
                },
                {
                    text = "Trade him a Heavy Quadav Chestplate and a Heavy Quadav Backplate together.",
                    pos  = "Bastok Markets [S], Scarred Shark (!pos -233.989 -2.000 67.638)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Zone out and back, then speak to Scarred Shark again for the Trainee Hammer.",
                    pos  = "Bastok Markets [S], Scarred Shark (!pos -233.989 -2.000 67.638)",
                },
            },
        },
        [15] = { -- GIFTS_OF_THE_GRIFFON
            name = "Gifts of the Griffon",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "With any nation's first Crystal War quest done, speak to Louxiard in Southern San d'Oria [S], zone, speak to him again, then see Rholont for seven Plumes d'Or.",
                    pos  = "Southern San d'Oria [S], Louxiard (!pos -93 -4 49) / Rholont (!pos -168 -2 56)",
                    done = { status = 1 },
                },
                {
                    text = "Trade one Plume d'Or each to Elnonde, Illeuse, Loillie, Louxiard, Machionage, Rongelouts N Distaud and Sabiliont. Lost a plume? Rholont replaces them after the conquest tally.",
                    pos  = "Southern San d'Oria [S], Elnonde (!pos 86 2 -0) / Sabiliont (!pos 9 2 -87)",
                    done = { var = 'Option', gte = 127 },
                },
                {
                    text = "Report to Rholont for the Deathstone.",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56)",
                },
            },
        },
        [16] = { -- CLAWS_OF_THE_GRIFFON
            name = "Claws of the Griffon",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Rholont in Southern San d'Oria [S] on a Vana'diel day after Gifts of the Griffon.",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56)",
                    done = { status = 1 },
                },
                {
                    text = "Zone out and back, then speak to Rholont again.",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Walk from East Ronfaure [S] into Jugner Forest [S] for a cutscene.",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the ??? in Jugner Forest [S].",
                    pos  = "Jugner Forest [S], ??? (!pos 68 -0.5 324)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine it again to call Fingerfilcher Dradzad, and defeat it.",
                    pos  = "Jugner Forest [S], ??? (!pos 68 -0.5 324)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the ??? once more to finish and receive the Angelstone.",
                    pos  = "Jugner Forest [S], ??? (!pos 68 -0.5 324)",
                },
            },
        },
        [17] = { -- THE_TIGRESS_STIRS
            name = "The Tigress Stirs",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "With any nation's first Crystal War quest done, speak to Dhea Prandoleh in Windurst Waters [S].",
                    pos  = "Windurst Waters [S], Dhea Prandoleh (!pos 1 -1 15)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the ??? in West Sarutabaruta [S] for a Small Starfruit.",
                    pos  = "West Sarutabaruta [S], ??? (!pos 150 -39 331)",
                    done = { ki = 958 }, -- SMALL_STARFRUIT
                },
                {
                    text = "Take the starfruit to the lower Acolyte Hostel door in Windurst Waters [S] to finish.",
                    pos  = "Windurst Waters [S], Door: Acolyte Hostel (!pos 124 -3 222)",
                },
            },
        },
        [18] = { -- THE_TIGRESS_STRIKES
            name = "The Tigress Strikes",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Dhea Prandoleh in Windurst Waters [S] to take the job.",
                    pos  = "Windurst Waters [S], Dhea Prandoleh (!pos 1 -1 15)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Rotih Moalghett in Fort Karugo-Narugo [S].",
                    pos  = "Fort Karugo-Narugo [S], Rotih Moalghett (!pos -64 -75 4)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the ??? in Fort Karugo-Narugo [S].",
                    pos  = "Fort Karugo-Narugo [S], ??? (!pos 208 -30 54)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine it again to call the War Lynx, and defeat it.",
                    pos  = "Fort Karugo-Narugo [S], ??? (!pos 208 -30 54)",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 2 }, { var = 'LynxKilled', gte = 1 } } }, { var = 'Prog', gte = 3 } } },
                },
                {
                    text = "Examine the ??? once more.",
                    pos  = "Fort Karugo-Narugo [S], ??? (!pos 208 -30 54)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Report to Dhea Prandoleh in Windurst Waters [S] for the Star Globe.",
                    pos  = "Windurst Waters [S], Dhea Prandoleh (!pos 1 -1 15)",
                },
            },
        },
        [19] = { -- LIGHT_IN_THE_DARKNESS
            -- unclearOk, and why it is honest here: a FAILED Silvermines run
            -- writes Prog 7 -- numerically above the win's 5 and 6 -- so only
            -- `eq` can tell "won" from "lost, buy another key", and `eq` is not
            -- monotone. 7 is only ever written from 4 (the instance's failure
            -- path) and 5/6 only climb to the turn-in, so every real state is a
            -- clean suffix; the runtime check carries the proof the linter
            -- cannot make (Prog 7 reads step 6, the rebuy-and-refight step).
            name = "Light in the Darkness",
            gated = 'ENABLE_WOTG',
            unclearOk = true,
            steps = {
                {
                    text = "With Fires of Discontent and the mission Back to the Beginning done, speak to Gentle Tiger in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Pagdako in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Pagdako (!pos -202.080 -6.000 -93.928)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Speak to Blatherix in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Blatherix (!pos -309.824 -11.999 -42.791)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Pay Blatherix 30 Chunks of Goblin Chocolate or 5,000 gil for the Mine Shaft Key.",
                    pos  = "Bastok Markets [S], Blatherix (!pos -309.824 -11.999 -42.791)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Walk from Grauberg [S] into Pashhow Marshlands [S] for a cutscene.",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Open the Corroded Door with the key and win the Ruhotz Silvermines run: seven of the ten Quadav in 30 minutes. Failed? Blatherix sells a new key for 10 chocolate or 1,000 gil.",
                    pos  = "Pashhow Marshlands [S], Corroded Door (!pos -385.602 21.970 456.359)",
                    done = { anyOf = { { var = 'Prog', eq = 5 }, { var = 'Prog', eq = 6 } } },
                },
                {
                    text = "Come back out into Pashhow Marshlands [S] for the after-battle cutscene.",
                    done = { var = 'Prog', eq = 6 },
                },
                {
                    text = "Report to Gentle Tiger in Bastok Markets [S] for the Adaman Ingot.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                },
            },
        },
        [20] = { -- BURDEN_OF_SUSPICION
            name = "Burden of Suspicion",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Gentle Tiger in Bastok Markets [S] on a Vana'diel day after Light in the Darkness, having zoned since. He takes the Warning Letter.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203 -9 0)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Engelhart in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Engelhart (!pos -79 -4 -123)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the Sarcophagus in The Eldieme Necropolis [S].",
                    pos  = "The Eldieme Necropolis [S], Sarcophagus (!pos 346 -32 -125)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Report to Gentle Tiger to finish.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203 -9 0)",
                },
            },
        },
        [21] = { -- EVIL_AT_THE_INLET
            -- Legacy zone NPC scripts (Rodeupansat, Vunkerl qm6); aliased in dwtracker_lint.py.
            name = "Evil at the Inlet",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "At level 30 or higher, holding the Bronze Ribbon of Service, speak to Rodeupansat in Crawlers' Nest [S]. He gives you an Evil-Warding Seal.",
                    pos  = "Crawlers' Nest [S], Rodeupansat (!pos 129 -34 26)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the ??? in Vunkerl Inlet [S] to use the seal, then return to Rodeupansat for a Scroll of Recall-Jugner.",
                    pos  = "Vunkerl Inlet [S], ??? (!pos -636 -51 -454) / Crawlers' Nest [S], Rodeupansat (!pos 129 -34 26)",
                },
            },
        },
        [22] = { -- THE_FUMBLING_FRIAR
            name = "The Fumbling Friar",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "At level 30 or higher, holding the Bronze Ribbon of Service, speak to Fondactiont in Garlaige Citadel [S].",
                    pos  = "Garlaige Citadel [S], Fondactiont (!pos -95 0 196)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the ??? in Grauberg [S] for the Ornate Package.",
                    pos  = "Grauberg [S], ??? (!pos 80 -1 457)",
                    done = { ki = 969 }, -- ORNATE_PACKAGE
                },
                {
                    text = "Bring the package to Fondactiont for a Scroll of Recall-Pashh.",
                    pos  = "Garlaige Citadel [S], Fondactiont (!pos -95 0 196)",
                },
            },
        },
        [23] = { -- REQUIEM_FOR_THE_DEPARTED
            -- Legacy zone NPC scripts (Heptachiond, Pecca-Pocca); aliased in dwtracker_lint.py.
            name = "Requiem for the Departed",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "At level 30 or higher, holding the Bronze Ribbon of Service, speak to Heptachiond in The Eldieme Necropolis [S].",
                    pos  = "The Eldieme Necropolis [S], Heptachiond (!pos 256 -32 20)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Pecca-Pocca in Fort Karugo-Narugo [S] for a Sheaf of Handmade Incense.",
                    pos  = "Fort Karugo-Narugo [S], Pecca-Pocca (!pos -163 -68 -155)",
                    done = { ki = 970 }, -- SHEAF_OF_HANDMADE_INCENSE
                },
                {
                    text = "Bring the incense to Heptachiond for a Scroll of Recall-Meriph.",
                    pos  = "The Eldieme Necropolis [S], Heptachiond (!pos 256 -32 20)",
                },
            },
        },
        [24] = { -- BOY_AND_THE_BEAST
            name = "Boy and the Beast",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "With Claws of the Griffon and the mission Back to the Beginning done, speak to Raustigne and then Rholont in Southern San d'Oria [S], then examine the ??? in Vunkerl Inlet [S].",
                    pos  = "Vunkerl Inlet [S], ??? (!pos -26 -31 364)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the Leafy Patch in Vunkerl Inlet [S] and pick the right herb. A wrong one is taken back at the ??? and you try again.",
                    pos  = "Vunkerl Inlet [S], Leafy Patch (!pos -418 -33 576)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Take the herb to the ??? in Vunkerl Inlet [S] to finish.",
                    pos  = "Vunkerl Inlet [S], ??? (!pos -26 -31 364)",
                },
            },
        },
        [25] = { -- WRATH_OF_THE_GRIFFON
            name = "Wrath of the Griffon",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Rholont in Southern San d'Oria [S] to take the job.",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the ??? in Jugner Forest [S].",
                    pos  = "Jugner Forest [S], ??? (!pos -6 0 -295)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine it again to call Cobraclaw Buchzvotch, and defeat it.",
                    pos  = "Jugner Forest [S], ??? (!pos -6 0 -295)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the ??? once more.",
                    pos  = "Jugner Forest [S], ??? (!pos -6 0 -295)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Report to Rholont. His Military Scrip is worth 20,147 gil from Wyatt in Southern San d'Oria [S].",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56) / Wyatt (!pos 124 0 84)",
                },
            },
        },
        [26] = { -- THE_LOST_BOOK
            name = "The Lost Book",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "At level 30 or higher, holding the Bronze Ribbon of Service, examine the south door of the Rhinostery in Windurst Waters [S].",
                    pos  = "Windurst Waters [S], Rhinostery door (!pos -1 -4.00 -198)",
                    done = { status = 1 },
                },
                {
                    text = "Trade a Mythril Beastcoin to Quu Bokye in present-day Giddeus for a Leather-bound Book.",
                    pos  = "Giddeus, Quu Bokye (!pos -159 16 181)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the Rhinostery's south door again.",
                    pos  = "Windurst Waters [S], Rhinostery door (!pos -1 -4.00 -198)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Optistery door in Windurst Waters [S].",
                    pos  = "Windurst Waters [S], Optistery door (!pos -57 -5.0 89)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the ??? in Castle Oztroja [S] for a Lynx Pelt.",
                    pos  = "Castle Oztroja [S], ??? (!pos -141 1 -9)",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 4 }, { ki = 972 } } }, { var = 'Prog', gte = 5 } } }, -- LYNX_PELT
                },
                {
                    text = "Trade a Sheet of Vellum to the Optistery door.",
                    pos  = "Windurst Waters [S], Optistery door (!pos -57 -5.0 89)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Wait for the next Vana'diel day, then examine the Optistery door to finish.",
                    pos  = "Windurst Waters [S], Optistery door (!pos -57 -5.0 89)",
                },
            },
        },
        [27] = { -- KNOT_QUITE_THERE
            name = "Knot Quite There",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "With The Tigress Strikes and the mission Back to the Beginning done, examine the lower Acolyte Hostel door in Windurst Waters [S].",
                    pos  = "Windurst Waters [S], Door: Acolyte Hostel (!pos 124 -3 222)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the Bulwark Gate in Sauromugue Champaign [S].",
                    pos  = "Sauromugue Champaign [S], Bulwark Gate (!pos -447 -2 342)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Trade a 108-Knot Quipu to the Bulwark Gate.",
                    pos  = "Sauromugue Champaign [S], Bulwark Gate (!pos -447 -2 342)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Walk from East Ronfaure [S] into Southern San d'Oria [S] on foot for a cutscene.",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the house door in Southern San d'Oria [S] to finish. This is the last Windurst nation quest scripted on this server.",
                    pos  = "Southern San d'Oria [S], Door: House (!pos 148 -3 24)",
                },
            },
        },
        [28] = { -- A_MANIFEST_PROBLEM
            -- Name only: Windurst nation quest 4; unscripted here (CONTENT_STATUS §7).
            name = "A Manifest Problem",
            gated = 'ENABLE_WOTG',
        },
        [29] = { -- BEANS_AHOY
            -- Legacy zone NPC script (Thierride); aliased in dwtracker_lint.py.
            name = "Beans Ahoy",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Thierride in Southern San d'Oria [S].",
                    pos  = "Southern San d'Oria [S], Thierride (!pos -124 -2 14)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Chunk of Lufet Salt. Crabs in present-day West Ronfaure drop them.",
                    done = { item = 1019 }, -- CHUNK_OF_LUFET_SALT
                },
                {
                    text = "Trade Thierride one salt, zone out and back, then trade him a second to finish. After that he hands out an Angler's Cassoulet once per conquest week.",
                    pos  = "Southern San d'Oria [S], Thierride (!pos -124 -2 14)",
                },
            },
        },
        [30] = { -- BEAST_FROM_THE_EAST
            -- Name only: no script offers it on this server.
            name = "Beast from the East",
            gated = 'ENABLE_WOTG',
        },
        [31] = { -- THE_SWARM
            -- Name only: no script offers it on this server.
            name = "The Swarm",
            gated = 'ENABLE_WOTG',
        },
        [32] = { -- ON_SABBATICAL
            name = "On Sabbatical",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "As a level 40+ Scholar, speak to Erlene in The Eldieme Necropolis [S]. She gives you Ulbrecht's Sealed Letter.",
                    pos  = "The Eldieme Necropolis [S], Erlene (!pos 376.936 -39.999 17.914)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Gentle Tiger in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the Indescript Markings in Pashhow Marshlands [S].",
                    pos  = "Pashhow Marshlands [S], Indescript Markings (!pos -456.707 24.4385 -363.364)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Report to Erlene for the Klimaform schema.",
                    pos  = "The Eldieme Necropolis [S], Erlene (!pos 376.936 -39.999 17.914)",
                },
            },
        },
        [33] = { -- DOWNWARD_HELIX
            name = "Downward Helix",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "As a level 50+ Scholar, speak to Erlene in The Eldieme Necropolis [S] on a Vana'diel day after On Sabbatical.",
                    pos  = "The Eldieme Necropolis [S], Erlene (!pos 376.936 -39.999 17.914)",
                    done = { status = 1 },
                },
                {
                    text = "Walk from East Ronfaure [S] into Southern San d'Oria [S] for a cutscene.",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Report to Erlene.",
                    pos  = "The Eldieme Necropolis [S], Erlene (!pos 376.936 -39.999 17.914)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Walk from Rolanberry Fields [S] into Sauromugue Champaign [S] for a cutscene.",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Indescript Markings in Sauromugue Champaign [S] for Ulbrecht's Mortarboard.",
                    pos  = "Sauromugue Champaign [S], Indescript Markings (!pos 322 24 113)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Report to Erlene for the Scholar's Bracers.",
                    pos  = "The Eldieme Necropolis [S], Erlene (!pos 376.936 -39.999 17.914)",
                },
            },
        },
        [34] = { -- SEEING_BLOOD_RED
            -- Name only: Scholar AF3; no script offers it (Vingijard and the RoE table only read its completion).
            name = "Seeing Blood Red",
            gated = 'ENABLE_WOTG',
        },
        [35] = { -- STORM_ON_THE_HORIZON
            name = "Storm on the Horizon",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After Burden of Suspicion, speak to Blatherix in Bastok Markets [S] for an Elixir. On a later Vana'diel day, having zoned, walk from North Gustaberg [S] into Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Blatherix (!pos -310 -12 -43)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Gentle Tiger in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203 -9 0)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Monument in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], Monument (!pos 300 -63 497)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the ??? in Grauberg [S] to finish and receive an Icarus Wing.",
                    pos  = "Grauberg [S], ??? (!pos 260 33 515)",
                },
            },
        },
        [36] = { -- FIRE_IN_THE_HOLE
            name = "Fire in the Hole",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After Storm on the Horizon, with the mission In the Name of the Father reached, walk from North Gustaberg [S] into Bastok Markets [S]. The cutscene hands you the Silvermine Key.",
                    done = { status = 1 },
                },
                {
                    text = "Examine the Stonehoused Adit in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], Stonehoused Adit (!pos -434.655 36.708 279.983)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the adit again. The Silvermines fight is not built here, so it takes the key and plays the after-battle scene (cut short? zone back into North Gustaberg [S]).",
                    pos  = "North Gustaberg [S], Stonehoused Adit (!pos -434.655 36.708 279.983)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Walk from North Gustaberg [S] into Bastok Markets [S] for a cutscene.",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Speak to Gentle Tiger in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Speak to Gentle Tiger again to finish.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                },
            },
        },
        [37] = { -- PERILS_OF_THE_GRIFFON
            name = "Perils of the Griffon",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "With the mission Purple, the New Black done, speak to Rholont a day after Wrath of the Griffon, zone, speak to him again, then Daigraffeaux, then Rholont once more.",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56) / Daigraffeaux (!pos -7 2 -89)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the ??? in Jugner Forest [S] for the Orcish Warmachine Body.",
                    pos  = "Jugner Forest [S], ??? (!pos 68 -0.5 324)",
                    done = { ki = 1019 }, -- ORCISH_WARMACHINE_BODY
                },
                {
                    text = "Report to Rholont to finish.",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56)",
                },
            },
        },
        [38] = { -- IN_A_HAZE_OF_GLORY
            name = "In a Haze of Glory",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After Perils of the Griffon, speak to Diordinne in Garlaige Citadel [S]. She gives you the Number Eight Shelter Key.",
                    pos  = "Garlaige Citadel [S], Diordinne (!pos -107.785 0 193.665)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the Wooden Crates in Garlaige Citadel [S].",
                    pos  = "Garlaige Citadel [S], Wooden Crates (!pos -0.717 3.347 -99.535)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the crates again. The Ghoyu's Reverie fight is not built here, so it takes the key and plays the after-battle scene (cut short? zone back into the Citadel).",
                    pos  = "Garlaige Citadel [S], Wooden Crates (!pos -0.717 3.347 -99.535)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Speak to Rholont in Southern San d'Oria [S] between 18:00 and midnight, Vana'diel time, to finish.",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56)",
                },
            },
        },
        [39] = { -- WHEN_ONE_MAN_IS_NOT_ENOUGH
            -- Name only: no script offers it on this server.
            name = "When One Man Is Not Enough",
            gated = 'ENABLE_WOTG',
        },
        [40] = { -- A_FEAST_FOR_GNATS
            -- Name only: Windurst nation quest 6; unscripted here (CONTENT_STATUS §7).
            name = "A Feast for Gnats",
            gated = 'ENABLE_WOTG',
        },
        [41] = { -- SAY_IT_WITH_A_HANDBAG
            -- Legacy zone NPC scripts (Hampu-Kampu, Door: Acolyte Hostel up, Kipopo); aliased in dwtracker_lint.py.
            name = "Say It with a Handbag",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Hampu-Kampu in Windurst Waters [S].",
                    pos  = "Windurst Waters [S], Hampu-Kampu (!pos -115.597 -1.000 -158.703)",
                    done = { status = 1 },
                },
                {
                    text = "Answer at the upper Acolyte Hostel door, take Hampu-Kampu's Torn Patches of Leather to Kipopo in present-day Southern San d'Oria, trade him Laminated Ram Leather, Sheep Leather and Silk Thread, zone, and talk again.",
                    pos  = "Southern San d'Oria, Kipopo (!pos -191.050 -2.15 12.285)",
                    done = { ki = 1053 }, -- REPAIRED_HANDBAG
                },
                {
                    text = "Bring the Repaired Handbag to Hampu-Kampu for the Trainee's Needle.",
                    pos  = "Windurst Waters [S], Hampu-Kampu (!pos -115.597 -1.000 -158.703)",
                },
            },
        },
        [42] = { -- QUELLING_THE_STORM
            name = "Quelling the Storm",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After Fire in the Hole, with the mission Crossroads of Time reached, walk from North Gustaberg [S] into Bastok Markets [S].",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Gentle Tiger in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Speak to Paul, Biggorf and Wilhelmina in Bastok Markets [S], in any order.",
                    pos  = "Bastok Markets [S], Paul (!pos -192.880 -3.999 53.083) / Biggorf (!pos -210.139 1.999 -140.872)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Report to Gentle Tiger.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Speak to Blatherix in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Blatherix (!pos -309.824 -11.999 -42.791)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Trade Blatherix a Goblin Mess Tin, a Goblin Mushpot and a Pinch of Twinkle Powder, all in one trade.",
                    pos  = "Bastok Markets [S], Blatherix (!pos -309.824 -11.999 -42.791)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Speak to Gentle Tiger.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Examine the ??? in Vunkerl Inlet [S].",
                    pos  = "Vunkerl Inlet [S], ??? (!pos -356.278 -32.117 285.950)",
                    done = { var = 'Prog', gte = 7 },
                },
                {
                    text = "Report to Blatherix for the Goblin Belt.",
                    pos  = "Bastok Markets [S], Blatherix (!pos -309.824 -11.999 -42.791)",
                },
            },
        },
        [43] = { -- HONOR_UNDER_FIRE
            name = "Honor Under Fire",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After Quelling the Storm, with the mission Crossroads of Time reached, speak to Gentle Tiger in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the ??? in Vunkerl Inlet [S].",
                    pos  = "Vunkerl Inlet [S], ??? (!pos -356.278 -32.117 285.950)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the Beastman Ensign in Vunkerl Inlet [S].",
                    pos  = "Vunkerl Inlet [S], Beastman Ensign (!pos 241.000 -31.995 242.999)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Report to Gentle Tiger, who hands you a Flare Grenade.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Beastman Ensign again.",
                    pos  = "Vunkerl Inlet [S], Beastman Ensign (!pos 241.000 -31.995 242.999)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine it once more. The Everbloom Hollow fight is not built here, so it takes the grenade and plays the after-battle scene (cut short? zone back into Vunkerl Inlet [S]).",
                    pos  = "Vunkerl Inlet [S], Beastman Ensign (!pos 241.000 -31.995 242.999)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Report to Gentle Tiger for the Elixir Tank.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                },
            },
        },
        [44] = { -- THE_PRICE_OF_VALOR
            name = "The Price of Valor",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "See Rholont a day after In a Haze of Glory. Bring him Long-Life Biscuits (Tree Hollow), Kingdom Water (Well) and Maple Syrup (logging, East Ronfaure [S]), then examine the Felled Trees in Jugner Forest [S].",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56)",
                    done = { status = 1 },
                },
                {
                    text = "Examine both Toppled Cressets in Vunkerl Inlet [S]; only one answers first.",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the Underbrush in Vunkerl Inlet [S].",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Examine it again to call Madthrasher Zradbodd, defeat it, then examine the Underbrush once more without leaving the zone.",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Examine the Shimmering Pondweed in Pashhow Marshlands [S] to finish and receive a Peiste Skin.",
                },
            },
        },
        [45] = { -- BONDS_THAT_NEVER_DIE
            name = "Bonds That Never Die",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Rholont for a Letter to Count Aurchiat, then show it at the Shimmering Pondweed in Pashhow Marshlands [S].",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the Overgrown Mushrooms in Jugner Forest [S]; you are handed a Hatchet.",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Log in Jugner Forest [S] with a Hatchet until a Length of Jugner Ivy turns up.",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 1 }, { ki = 1075 } } }, { var = 'Prog', gte = 2 } } }, -- LENGTH_OF_JUGNER_IVY
                },
                {
                    text = "Examine the Overgrown Mushrooms again.",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the Mossy Stump in Jugner Forest [S].",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the stump again. The Everbloom Hollow fight is not built here, so the after-battle scene plays at once (cut short? zone back into Jugner Forest [S]).",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Speak to Rongelouts N Distaud in Southern San d'Oria [S] for the Behemoth Horn.",
                    pos  = "Southern San d'Oria [S], Rongelouts N Distaud (!pos 0.067 2 -22)",
                },
            },
        },
        [46] = { -- THE_LONG_MARCH_NORTH
            -- Name only: no script offers it on this server.
            name = "The Long March North",
            gated = 'ENABLE_WOTG',
        },
        [47] = { -- THE_FORBIDDEN_PATH
            -- Name only: Windurst nation quest 8; unscripted here (CONTENT_STATUS §7).
            name = "The Forbidden Path",
            gated = 'ENABLE_WOTG',
        },
        [48] = { -- A_JEWELERS_LAMENT
            -- Name only: no script offers it on this server.
            name = "A Jeweler's Lament",
            gated = 'ENABLE_WOTG',
        },
        [49] = { -- BENEATH_THE_MASK
            name = "Beneath the Mask",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After Honor Under Fire, with the mission Fate in Haze reached, speak to Gentle Tiger in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { status = 1 },
                },
                {
                    text = "Enter Beadeaux [S] for a cutscene.",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Report to Gentle Tiger.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Speak to Red Axe in The Eldieme Necropolis [S].",
                    pos  = "The Eldieme Necropolis [S], Red Axe (!pos 304.627 -27.500 13.955)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Trade Leadavox in Vunkerl Inlet [S] a Lump of Beeswax and a Jar of Red Textile Dye for a Wax Seal.",
                    pos  = "Vunkerl Inlet [S], Leadavox (!pos 207.081 -31.997 315.458)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Take the Wax Seal to Red Axe.",
                    pos  = "The Eldieme Necropolis [S], Red Axe (!pos 304.627 -27.500 13.955)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Report to Gentle Tiger.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Speak to Hoarfang in Beaucedine Glacier [S] to finish and receive a Super Reraiser.",
                    pos  = "Beaucedine Glacier [S], Hoarfang (!pos -263.577 -40.757 -329.347)",
                },
            },
        },
        [50] = { -- WHAT_PRICE_LOYALTY
            name = "What Price Loyalty",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After Beneath the Mask, with the mission Fate in Haze reached, speak to Gentle Tiger in Bastok Markets [S]. He gives you a Sack of Victuals.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { status = 1 },
                },
                {
                    text = "Deliver the sack to Roderich in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], Roderich (!pos -400.039 40.004 -90.445)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Report to Gentle Tiger.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Enter Xarcabard [S]; the cutscene hands you the Commander's Endorsement.",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Forbidding Portal in Xarcabard [S].",
                    pos  = "Xarcabard [S], Forbidding Portal (!pos 320.000 -10.835 158.699)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the portal again. The Everbloom Hollow fight is not built here, so it takes the endorsement and plays the after-battle scene (cut short? zone back into Xarcabard [S]).",
                    pos  = "Xarcabard [S], Forbidding Portal (!pos 320.000 -10.835 158.699)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Report to Gentle Tiger for the Fourth Staff.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                },
            },
        },
        [51] = { -- SONGBIRDS_IN_A_SNOWSTORM
            name = "Songbirds in a Snowstorm",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "With the mission The Will of the World done, speak to Rholont a Vana'diel day after Bonds That Never Die (having zoned), then to Daigraffeaux.",
                    pos  = "Southern San d'Oria [S], Rholont (!pos -168 -2 56) / Daigraffeaux (!pos -7 2 -89)",
                    done = { status = 1 },
                },
                {
                    text = "Enter Beaucedine Glacier [S] for a cutscene.",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the Colossal Footprint in Beaucedine Glacier [S].",
                    pos  = "Beaucedine Glacier [S], Colossal Footprint (!pos 82.144 -19.038 139.249)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Rocky Perch. Key-item fishing is not built here, so it hands you the Lance Fish, Paladin Lobster and Scutum Crab outright, with a Goliath Worm.",
                    pos  = "Beaucedine Glacier [S], Rocky Perch (!pos -106.321 0.282 -365.035)",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 3 }, { ki = 1181 }, { ki = 1182 }, { ki = 1183 } } }, { var = 'Prog', gte = 4 } } }, -- LANCE_FISH, PALADIN_LOBSTER, SCUTUM_CRAB
                },
                {
                    text = "Examine the Colossal Footprint again with all three catches.",
                    pos  = "Beaucedine Glacier [S], Colossal Footprint (!pos 82.144 -19.038 139.249)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Trade a Flint Stone to the Charred Firewood.",
                    pos  = "Beaucedine Glacier [S], Charred Firewood (!pos 83.296 -58.472 175.2)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Examine the Compressed Snow.",
                    pos  = "Beaucedine Glacier [S], Compressed Snow (!pos 46.437 -0.762 -370.178)",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Examine it again to call the Orcish Bloodletter and defeat it. It is a level-150 placeholder on this server, so for now the San d'Oria line stops at this fight.",
                    pos  = "Beaucedine Glacier [S], Compressed Snow (!pos 46.437 -0.762 -370.178)",
                    done = { var = 'Prog', gte = 7 },
                },
                {
                    text = "Examine the Compressed Snow once more to finish and receive an Icarus Wing.",
                    pos  = "Beaucedine Glacier [S], Compressed Snow (!pos 46.437 -0.762 -370.178)",
                },
            },
        },
        [52] = { -- BLOOD_OF_HEROES
            name = "Blood of Heroes",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After Songbirds in a Snowstorm, examine the Animal Spoor in Xarcabard [S].",
                    pos  = "Xarcabard [S], Animal Spoor (!pos 543.954 -0.522 -290.313)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the Wheel Rut in Xarcabard [S].",
                    pos  = "Xarcabard [S], Wheel Rut (!pos 345.162 -0.743 -309.161)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the Animal Spoor again for a Vial of Military Prism Powder.",
                    pos  = "Xarcabard [S], Animal Spoor (!pos 543.954 -0.522 -290.313)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the Forbidding Portal in Xarcabard [S].",
                    pos  = "Xarcabard [S], Forbidding Portal (!pos 320 -10.835 158.699)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the portal again. The Ghoyu's Reverie fight is not built here, so it takes the powder and plays the after-battle scene (cut short? zone back into Xarcabard [S]).",
                    pos  = "Xarcabard [S], Forbidding Portal (!pos 320 -10.835 158.699)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Examine the Wheel Rut to finish and receive the Ram Staff.",
                    pos  = "Xarcabard [S], Wheel Rut (!pos 345.162 -0.743 -309.161)",
                },
            },
        },
        [53] = { -- SINS_OF_THE_MOTHERS
            -- Name only: no script offers it on this server.
            name = "Sins of the Mothers",
            gated = 'ENABLE_WOTG',
        },
        [54] = { -- HOWL_FROM_THE_HEAVENS
            -- Name only: Windurst nation quest 10; unscripted here (CONTENT_STATUS §7).
            name = "Howl from the Heavens",
            gated = 'ENABLE_WOTG',
        },
        [55] = { -- SUCCOR_TO_THE_SIDHE
            -- Name only: no script offers it on this server.
            name = "Succor to the Sidhe",
            gated = 'ENABLE_WOTG',
        },
        [56] = { -- THE_YOUNG_AND_THE_THREADLESS
            -- Name only: no script offers it on this server.
            name = "The Young and the Threadless",
            gated = 'ENABLE_WOTG',
        },
        [57] = { -- SON_AND_FATHER
            -- Name only: no script offers it on this server.
            name = "Son and Father",
            gated = 'ENABLE_WOTG',
        },
        [58] = { -- THE_TRUTH_LIES_HID
            name = "The Truth Lies Hid",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After What Price Loyalty, with the mission Adieu, Lilisette reached, speak to Gentle Tiger in Bastok Markets [S].",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                    done = { status = 1 },
                },
                {
                    text = "Enter Castle Zvahl Baileys [S] for a cutscene.",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "In Castle Zvahl Keep [S], question the imps Rikke, Rakke and Rokke, then show an Elixir to the honest one. One guess per Vana'diel day; the Elixir is not taken.",
                    pos  = "Castle Zvahl Keep [S], Rikke (!pos -90.120 0.601 86.312) / Rakke (!pos -113.722 0.601 -149.880)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the ??? in Castle Zvahl Keep [S].",
                    pos  = "Castle Zvahl Keep [S], ??? (!pos -384.257 -51.999 -95.783)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Displaced Block to finish and receive the Sanctus Rosary.",
                    pos  = "Castle Zvahl Keep [S], Displaced Block (!pos -264.139 -52.999 82.333)",
                },
            },
        },
        [59] = { -- BONDS_OF_MYTHRIL
            name = "Bonds of Mythril",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "After The Truth Lies Hid, with the mission Adieu, Lilisette reached, walk from Castle Zvahl Keep [S] into Castle Zvahl Baileys [S].",
                    done = { status = 1 },
                },
                {
                    text = "Examine the ??? in Castle Zvahl Keep [S].",
                    pos  = "Castle Zvahl Keep [S], ??? (!pos -384.257 -51.999 -95.783)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Defeat four Keep Imps, examine the ??? to call the Gargouille Warden, and defeat it.",
                    pos  = "Castle Zvahl Keep [S], ??? (!pos -384.257 -51.999 -95.783)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the ??? again for the Zvahl Passkey.",
                    pos  = "Castle Zvahl Keep [S], ??? (!pos -384.257 -51.999 -95.783)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the door in Throne Room [S].",
                    pos  = "Throne Room [S], door (!pos -115.849 -8.657 0.000)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the door again. The battle behind it is not built here, so the quest moves on silently; nothing plays.",
                    pos  = "Throne Room [S], door (!pos -115.849 -8.657 0.000)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Speak to Gentle Tiger in Bastok Markets [S]. The cutscenes that follow carry you through the Metalworks to North Gustaberg [S], where the quest ends.",
                    pos  = "Bastok Markets [S], Gentle Tiger (!pos -203.932 -9.998 2.237)",
                },
            },
        },
        [60] = { -- CHASING_SHADOWS
            name = "Chasing Shadows",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Rongelouts N Distaud in Southern San d'Oria [S] on a Vana'diel day after Blood of Heroes.",
                    pos  = "Southern San d'Oria [S], Rongelouts N Distaud (!pos 0.067 2 -22)",
                    done = { status = 1 },
                },
                {
                    text = "Walk from Beaucedine Glacier [S] into Xarcabard [S] for a cutscene.",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the Backfilled Pit in Xarcabard [S].",
                    pos  = "Xarcabard [S], Backfilled Pit (!pos -172 -2.818 -85)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Examine the Compact Footprint.",
                    pos  = "Xarcabard [S], Compact Footprint (!pos 242.145 -15.42 -147.417)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Sunken Footprint.",
                    pos  = "Xarcabard [S], Sunken Footprint (!pos 188.429 -27.623 163.764)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the Compact Footprint again.",
                    pos  = "Xarcabard [S], Compact Footprint (!pos 242.145 -15.42 -147.417)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Walk from Beaucedine Glacier [S] into Batallia Downs [S] for a cutscene.",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Examine the Fresh Snowmelt in Batallia Downs [S].",
                    pos  = "Batallia Downs [S], Fresh Snowmelt (!pos -71.660 -2.58 450.114)",
                    done = { var = 'Prog', gte = 7 },
                },
                {
                    text = "Examine it again to call Menechme, and defeat it. Menechme is a level-150 placeholder on this server, so for now this fight is a wall.",
                    pos  = "Batallia Downs [S], Fresh Snowmelt (!pos -71.660 -2.58 450.114)",
                    done = { var = 'Prog', gte = 8 },
                },
                {
                    text = "Examine the Fresh Snowmelt once more to finish. It sets you down in present-day Batallia Downs with Face of the Future under way.",
                    pos  = "Batallia Downs [S], Fresh Snowmelt (!pos -71.660 -2.58 450.114)",
                },
            },
        },
        [61] = { -- FACE_OF_THE_FUTURE
            name = "Face of the Future",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Finishing Chasing Shadows opens this and leaves you in present-day Batallia Downs.",
                    done = { status = 1 },
                },
                {
                    text = "Walk from Batallia Downs into Jugner Forest for a cutscene.",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the Metallic Hodgepodge in Jugner Forest.",
                    pos  = "Jugner Forest, Metallic Hodgepodge (!pos -285.493 -7.819 -163.707)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Enter Ghelsba Outpost for a cutscene. While there, examine the Clandestine Marking for an Orcish Infiltration Kit; you need it later.",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Examine the Scrape Mark in Yughott Grotto.",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the Scrape Mark again holding the kit. The Everbloom Hollow fight is not built here, so it takes the kit and plays the after-battle scene (cut short? zone back into the Grotto).",
                    done = { var = 'Prog', gte = 6 },
                },
                {
                    text = "Examine the Cavernous Maw in Batallia Downs (its maw must be open to you). The cutscenes after it carry you to Xarcabard [S] and back, and the last one ends the quest.",
                },
            },
        },
        [62] = { -- MANIFEST_DESTINY
            -- Name only: no script offers it on this server.
            name = "Manifest Destiny",
            gated = 'ENABLE_WOTG',
        },
        [63] = { -- AT_JOURNEYS_END
            -- Name only: Windurst nation quest 12; unscripted here (CONTENT_STATUS §7).
            name = "At Journey's End",
            gated = 'ENABLE_WOTG',
        },
        [64] = { -- HER_MEMORIES_HOMECOMING_QUEEN
            name = "Her Memories: Homecoming Queen",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "While the mission Her Memories is current, walk from East Ronfaure into present-day Southern San d'Oria for a cutscene.",
                    done = { status = 1 },
                },
                {
                    text = "Finish the three errands this opens, each its own journal entry: Old Bean (Thierride), The Faux Pas (Abioleget) and The Grave Resolve (Halver). The third one ends this quest.",
                    pos  = "Port San d'Oria, Thierride (!pos -67 -5 -28) / Northern San d'Oria, Abioleget (!pos 128.771 0.000 118.538)",
                },
            },
        },
        [65] = { -- HER_MEMORIES_OLD_BEAN
            -- Run from Homecoming Queen's script (no file of its own); aliased in dwtracker_lint.py.
            name = "Her Memories: Old Bean",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Thierride in Port San d'Oria. He hands you Thierride's Bean Creation.",
                    pos  = "Port San d'Oria, Thierride (!pos -67 -5 -28)",
                    done = { status = 1 },
                },
                {
                    text = "Take the bean creation to Amaura in Southern San d'Oria, then go back to Thierride to finish.",
                    pos  = "Southern San d'Oria, Amaura (!pos -84.367 -6.949 91.148) / Port San d'Oria, Thierride (!pos -67 -5 -28)",
                },
            },
        },
        [66] = { -- HER_MEMORIES_THE_FAUX_PAS
            -- Run from Homecoming Queen's script (no file of its own); aliased in dwtracker_lint.py.
            name = "Her Memories: The Faux Pas",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Abioleget in Northern San d'Oria.",
                    pos  = "Northern San d'Oria, Abioleget (!pos 128.771 0.000 118.538)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Bertenont in Northern San d'Oria to finish.",
                    pos  = "Northern San d'Oria, Bertenont (!pos -165 0.1 226)",
                },
            },
        },
        [67] = { -- HER_MEMORIES_THE_GRAVE_RESOLVE
            -- Run from Homecoming Queen's script (no file of its own); aliased in dwtracker_lint.py.
            name = "Her Memories: The Grave Resolve",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "Speak to Halver in Chateau d'Oraguille.",
                    pos  = "Chateau d'Oraguille, Halver (!pos 2 0.1 0.1)",
                    done = { status = 1 },
                },
                {
                    text = "Get a Lilac.",
                    done = { item = 956 }, -- LILAC
                },
                {
                    text = "Examine the Weathered Gravestone in present-day Batallia Downs, then trade it the Lilac to finish.",
                    pos  = "Batallia Downs, Weathered Gravestone (!pos 149.728 -5.109 -395.121)",
                },
            },
        },
        [68] = { -- HER_MEMORIES_OPERATION_CUPID
            name = "Her Memories: Operation Cupid",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "While the mission Her Memories is current, walk from Jugner Forest [S] into Batallia Downs [S] for a cutscene.",
                    done = { status = 1 },
                },
                {
                    text = "Examine the Bulwark Gate in Sauromugue Champaign [S].",
                    pos  = "Sauromugue Champaign [S], Bulwark Gate (!pos -447.174 -1.831 342.417)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Trade Leadavox in Vunkerl Inlet [S] a Bottle of Rice Vinegar, a Jar of Ground Wasabi and a Sprig of Holy Basil for a Pot of Martial Relish.",
                    pos  = "Vunkerl Inlet [S], Leadavox (!pos 206 -32 316)",
                    done = { anyOf = { { allOf = { { var = 'Prog', gte = 1 }, { ki = 1603 } } }, { var = 'Prog', gte = 2 } } }, -- POT_OF_MARTIAL_RELISH
                },
                {
                    text = "Bring the relish to the Bulwark Gate.",
                    pos  = "Sauromugue Champaign [S], Bulwark Gate (!pos -447.174 -1.831 342.417)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Walk from Rolanberry Fields [S] into Batallia Downs [S] to finish.",
                },
            },
        },
        [69] = { -- HER_MEMORIES_CARNELIAN_FOOTFALLS
            name = "Her Memories: Carnelian Footfalls",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "On the mission Her Memories, walk from East Ronfaure [S] into Southern San d'Oria [S], then see Mainchelite. Open to all but Bastok's allies: it stands in for the unbuilt Verdure Footfalls.",
                    pos  = "Southern San d'Oria [S], Mainchelite (!pos -16 1 -30)",
                    done = { status = 1 },
                },
                {
                    text = "Examine the three ??? in East Ronfaure [S], in any order.",
                    pos  = "East Ronfaure [S], ??? (!pos 312.821 -30.495 -67.15) / ??? (!pos 541.425 -49.83 178.563)",
                    done = { var = 'Option', gte = 7 },
                },
                {
                    text = "Report to Mainchelite to finish.",
                    pos  = "Southern San d'Oria [S], Mainchelite (!pos -16 1 -30)",
                },
            },
        },
        [70] = { -- HER_MEMORIES_AZURE_FOOTFALLS
            name = "Her Memories: Azure Footfalls",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "As a Bastok ally on the mission Her Memories, walk from North Gustaberg [S] into Bastok Markets [S], then speak to Adelbrecht.",
                    pos  = "Bastok Markets [S], Adelbrecht (!pos -325.8 -12.6 -77.0)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Gebhardt in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], Gebhardt (!pos 206.3 -20.8 669.1)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "Speak to Roderich in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], Roderich (!pos -400.0 40.0 -90.4)",
                    done = { var = 'Prog', gte = 4 },
                },
                {
                    text = "Examine the Barricade in North Gustaberg [S].",
                    pos  = "North Gustaberg [S], Barricade (!pos -515.0 38.0 583.3)",
                    done = { var = 'Prog', gte = 5 },
                },
                {
                    text = "Report to Adelbrecht in Bastok Markets [S] to finish.",
                    pos  = "Bastok Markets [S], Adelbrecht (!pos -325.8 -12.6 -77.0)",
                },
            },
        },
        [71] = { -- HER_MEMORIES_VERDURE_FOOTFALLS
            -- Name only: unscripted here; Carnelian Footfalls (69) stands in for it (CONTENT_STATUS §7).
            name = "Her Memories: Verdure Footfalls",
            gated = 'ENABLE_WOTG',
        },
        [72] = { -- HER_MEMORIES_OF_MALIGN_MALADIES
            name = "Her Memories: Of Malign Maladies",
            gated = 'ENABLE_WOTG',
            steps = {
                {
                    text = "While the mission Her Memories is current, speak to Amaura in present-day Southern San d'Oria.",
                    pos  = "Southern San d'Oria, Amaura (!pos -84.367 -6.949 91.148)",
                    done = { status = 1 },
                },
                {
                    text = "Speak to Monberaux in Upper Jeuno.",
                    pos  = "Upper Jeuno, Monberaux (!pos -42 0 -2)",
                    done = { var = 'Prog', gte = 1 },
                },
                {
                    text = "Examine the library book in present-day Windurst Waters.",
                    pos  = "Windurst Waters, Library Book (!pos -16.17 -6.25 112.289)",
                    done = { var = 'Prog', gte = 2 },
                },
                {
                    text = "Trade a Philosopher's Stone to the Fey Blossoms in Grauberg [S].",
                    pos  = "Grauberg [S], Fey Blossoms (!pos -141.312 -6.75 564.417)",
                    done = { var = 'Prog', gte = 3 },
                },
                {
                    text = "After the next Vana'diel day, examine the Fey Blossoms again for the Fey Stone.",
                    pos  = "Grauberg [S], Fey Blossoms (!pos -141.312 -6.75 564.417)",
                    done = { allOf = { { var = 'Prog', gte = 3 }, { ki = 1607 } } }, -- FEY_STONE
                },
                {
                    text = "Take the Fey Stone to Raustigne in Southern San d'Oria [S] to finish.",
                    pos  = "Southern San d'Oria [S], Raustigne (!pos 3.979 -1.999 44.456)",
                },
            },
        },
        [73] = { -- CHAMPION_OF_THE_DAWN
            -- Name only: no script offers it (RoV 2-17 only reads its status).
            name = "Champion of the Dawn",
            gated = 'ENABLE_WOTG',
        },
        [74] = { -- THE_DAWN_ALSO_RISES
            -- Name only: no script offers it on this server.
            name = "The Dawn Also Rises",
            gated = 'ENABLE_WOTG',
        },
        [75] = { -- A_FORBIDDEN_REUNION
            -- Name only: no script offers it (RoV 2-17 only reads its status).
            name = "A Forbidden Reunion",
            gated = 'ENABLE_WOTG',
        },
        [80] = { -- GUARDIAN_OF_THE_VOID
            -- Name only: no script offers it on this server.
            name = "Guardian of the Void",
            gated = 'ENABLE_WOTG',
        },
        [81] = { -- DRAFTED_BY_THE_DUCHY
            -- Name only: no script offers it (Lamepaue's replay list only reads its completion).
            name = "Drafted by the Duchy",
            gated = 'ENABLE_WOTG',
        },
        [82] = { -- BATTLE_ON_A_NEW_FRONT
            -- Name only: no script offers it (Lamepaue's replay list only reads its completion).
            name = "Battle on a New Front",
            gated = 'ENABLE_WOTG',
        },
        [83] = { -- VOIDWALKER_OP_126
            -- Name only: no script offers it (Lamepaue's replay list only reads its completion). Name from enum.
            name = "Voidwalker Op 126",
            gated = 'ENABLE_WOTG',
        },
        [84] = { -- A_CAIT_CALLS
            -- Name only: no script offers it on this server.
            name = "A Cait Calls",
            gated = 'ENABLE_WOTG',
        },
        [85] = { -- THE_TRUTH_IS_OUT_THERE
            -- Name only: no script offers it on this server.
            name = "The Truth Is Out There",
            gated = 'ENABLE_WOTG',
        },
        [86] = { -- REDRAFTED_BY_THE_DUCHY
            -- Name only: no script offers it on this server.
            name = "Redrafted by the Duchy",
            gated = 'ENABLE_WOTG',
        },
        [87] = { -- A_NEW_MENACE
            -- Name only: no script offers it on this server.
            name = "A New Menace",
            gated = 'ENABLE_WOTG',
        },
        [88] = { -- NO_REST_FOR_THE_WEARY
            -- Name only: no script offers it on this server.
            name = "No Rest for the Weary",
            gated = 'ENABLE_WOTG',
        },
        [89] = { -- A_WORLD_IN_FLUX
            -- Name only: no script offers it on this server.
            name = "A World in Flux",
            gated = 'ENABLE_WOTG',
        },
        [90] = { -- BETWEEN_A_ROCK_AND_RIFT
            -- Name only: no script offers it on this server.
            name = "Between a Rock and Rift",
            gated = 'ENABLE_WOTG',
        },
        [91] = { -- A_FAREWELL_TO_FELINES
            -- Name only: no script offers it on this server.
            name = "A Farewell to Felines",
            gated = 'ENABLE_WOTG',
        },
        [92] = { -- THIRD_TOUR_OF_DUCHY
            -- Name only: no script offers it on this server.
            name = "Third Tour of Duchy",
            gated = 'ENABLE_WOTG',
        },
        [93] = { -- GLIMMER_OF_HOPE
            -- Name only: no script offers it on this server.
            name = "Glimmer of Hope",
            gated = 'ENABLE_WOTG',
        },
        [94] = { -- BRACE_FOR_THE_UNKNOWN
            -- Name only: no script offers it on this server.
            name = "Brace for the Unknown",
            gated = 'ENABLE_WOTG',
        },
        [95] = { -- PROVENANCE
            -- Name only: no script offers it on this server.
            name = "Provenance",
            gated = 'ENABLE_WOTG',
        },
        [96] = { -- CRYSTAL_GUARDIAN
            -- Name only: no script offers it on this server.
            name = "Crystal Guardian",
            gated = 'ENABLE_WOTG',
        },
        [97] = { -- ENDINGS_AND_BEGINNINGS
            -- Name only: no script offers it on this server.
            name = "Endings and Beginnings",
            gated = 'ENABLE_WOTG',
        },
        [98] = { -- AD_INFINITUM
            -- Name only: no script offers it on this server.
            name = "Ad Infinitum",
            gated = 'ENABLE_WOTG',
        },
    },
}
