--[[
* DriftwoodXI dwengage -- the client half of the server's widened auto-target.
*
* WHY THIS EXISTS. When your target dies mid-pull, the map server already picks
* the next mob holding enmity on the party (attack_state.cpp, policy
* party-enmity-v3) and keeps your attack state engaged on it. What the server
* cannot do is TURN you: the client owns player heading, and the server refuses
* every swing until you face the target (CCharEntity::CanAttack). Without this
* addon the widened pick is invisible -- you stand there, weapon out, swinging
* at nothing, while the mob behind you works on the healer.
*
* HOW IT WORKS. The server marks its auto-target 0x058 assist packets by
* setting the trailing padding word to 1 -- a field the retail client never
* reads, so an unpatched client is simply unchanged. On a marked packet this
* addon resolves the mob, sets your client target to it, and writes your
* heading to face it. Unmarked 0x058s (a /assist reply, an ordinary target
* change) are deliberately ignored, so /assist behaves exactly as retail.
*
* The work happens a few frames AFTER the packet, not inside the handler: the
* same server tick that sends the marked assist can also send a follow-up
* assist that clears the dead target, and acting after the whole chunk has
* been processed means nothing later in the chunk undoes us. A second pass a
* third of a second later re-checks the target stuck and the heading held,
* then the addon goes back to sleep.
*
* No window, no server traffic of its own. `/dwengage` toggles it for the
* session, `/dwengage on` and `/dwengage off` say which way rather than
* flipping whatever happens to be there, and `/dwengage status` says what the
* last marked pick actually did. That last one exists because "it did not turn
* me" has half a dozen causes in here -- the pick died before the pass ran, you
* were resting or on a mount, you had already tabbed onto something else -- and
* they are indistinguishable from the player's chair.
*
* Turning it off for good is the launcher's Addons tab, like any other addon.
* The in-client Auto Target config option disables the whole feature
* server-side (no marked packets are ever sent), and so does the map's own
* AUTO_TARGET_PARTY_ENMITY setting. Neither is readable from in here, which is
* why the status line names them instead of claiming the feature is live.
--]]

addon.name    = 'dwengage';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.0';
addon.desc    = 'Turns you onto the next enemy your party is fighting when your target dies.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat = require('chat');

-- Lua 5.4 renamed atan2 to the two-argument atan; Ashita's runtime still has
-- the old name. Either way this is atan2.
local atan2 = math.atan2 or math.atan;

-- The one marked assist we have not acted on yet. serverId is the mob the
-- server picked; at is os.clock() at packet time; passes counts how many
-- present-frames have acted on it (two, then it is dropped).
local pending = nil;

--[[
* What the last marked pick did, for `/dwengage status`.
*
* A pick that lands and a pick that is dropped look identical from the player's
* chair -- you are simply not turned -- and the reasons are all invisible from
* in there: the mob died inside the sixty milliseconds before the first pass,
* the player was resting or mounted, the player had already tabbed onto
* something else, the entity never resolved. Writing the reason down as it
* happens costs one table per pick (never per frame) and is the difference
* between a bug report that says "it did not work" and one that can be acted
* on.
--]]
local lastPick = nil;

--[[
* How many marked picks have arrived this session, and how many of them were
* let go without acting.
*
* Two integers, because the first question `/dwengage status` has to answer is
* not "what did the last one do" but "is the server sending them at all". Zero
* picks in an evening of pulls means the feature is switched off somewhere the
* client cannot see -- the in-client Auto Target option, or the map's
* AUTO_TARGET_PARTY_ENMITY -- and that is a completely different answer from
* fourteen picks of which fourteen were let go.
--]]
local picks   = 0;
local dropped = 0;

-- Why the pick was let go, in the player's words. Keyed and gathered here
-- rather than written inline at each `return`, so that adding a new way to
-- drop a pick means naming it as well as taking it.
local DROP_REASONS = {
    gone     = 'the mob was already gone or dead',
    standing = 'you were not standing (dead, resting, mounted or in a cutscene)',
    retarget = 'you had already picked a different target',
    stale    = 'the pick was never acted on inside its three-second window',
    zone     = 'a zone line landed first',
    off      = '/dwengage off was typed before the pass ran',
    read     = 'a read of the client\'s own memory failed',
    replaced = 'a newer pick arrived before the pass ran',
};

--[[
* Let the pending pick go, and write down why if nothing else has.
*
* A pick that has already been acted on is not a failure when a later frame
* lets it go -- it did the job it was sent for -- so only a pick that never
* landed records a reason.
--]]
local function dropPending(reason)
    if (pending ~= nil and lastPick ~= nil and lastPick.serverId == pending.serverId
        and lastPick.acted == nil and lastPick.dropped == nil) then
        lastPick.dropped = reason;
        dropped           = dropped + 1;
    end

    pending = nil;
end

-- Session toggle. Deliberately not persisted: the launcher's Addons tab is
-- the durable on/off for every dw addon, and a second saved switch inside
-- the addon would be a state nobody can see from outside.
local enabled = true;

-- Server cone is 64/256 of a circle (+/- 45 degrees). Re-facing on the second
-- pass only happens outside this margin, so a player already steering their
-- camera is not fought over a few degrees.
local FACING_SLACK = 0.60;

-- First pass waits this long after the packet so the rest of the same packet
-- chunk (including the assist that clears the dead target) lands first.
local FIRST_PASS_DELAY  = 0.06;
local SECOND_PASS_DELAY = 0.40;
local GIVE_UP_AFTER     = 3.0;

--[[
* Little-endian readers in the dwcraft style: offsets are 0-based and include
* the 4-byte packet header, string.byte is 1-based, hence the +1.
--]]
local function u16(data, off)
    return (string.byte(data, off + 1) or 0) + (string.byte(data, off + 2) or 0) * 256;
end

local function u32(data, off)
    return u16(data, off) + u16(data, off + 2) * 65536;
end

--[[
* Your own entity index, the dwreport way. nil rather than 0 on any failure so
* callers can bail with one check.
--]]
local function selfIndex()
    local party = AshitaCore:GetMemoryManager():GetParty();
    if (party == nil) then
        return nil;
    end
    local index = party:GetMemberTargetIndex(0);
    return (index ~= nil and index > 0) and index or nil;
end

--[[
* Entity index for a server id, the dwparse way: dynamic ids (mobs, trusts,
* pets; id >= 0x1000000) carry their targid OFFSET BY 0x100
* (`0x01000000 | zone << 12 | (targid + 0x0100)`, zone_entities.cpp), so the
* low twelve bits must be un-offset the way the server does it
* (zoneutils.cpp GetEntity) rather than used as an index directly. They are
* never cached; anything else (a charmed player could in principle be the
* pick) is found by scan.
--]]
local function indexForServerId(sid)
    local entity = AshitaCore:GetMemoryManager():GetEntity();
    if (entity == nil) then
        return nil;
    end

    if (sid >= 0x1000000) then
        local idx = sid % 0x1000;

        -- Dynamic targids start at 0x700, so the stored value lands in
        -- [0x800, 0x9FF] and can never collide with a static one. The upper
        -- bound covers the zone's targid = 0x900 overflow escape.
        if (idx >= 0x800) then
            idx = idx - 0x100;
        end

        if (idx <= 0x8FF and entity:GetServerId(idx) == sid) then
            return idx;
        end
        return nil;
    end

    for idx = 0x400, 0x8FF do
        if (entity:GetServerId(idx) == sid) then
            return idx;
        end
    end
    return nil;
end

--[[
* The heading that faces fromIdx at toIdx. Ashita's entity API exposes the
* ground plane as X and Y (Z is height -- see mobdb's compass math), and the
* client yaw float runs CLOCKWISE while math.atan2 runs counter-clockwise, so
* the angle is negated (MobCompass converts the same float with -heading).
* The server agrees end to end: radianToRotation() maps this yaw straight to
* the rotation byte its facing() check compares.
--]]
local function yawToFace(entity, fromIdx, toIdx)
    local dX = entity:GetLocalPositionX(toIdx) - entity:GetLocalPositionX(fromIdx);
    local dY = entity:GetLocalPositionY(toIdx) - entity:GetLocalPositionY(fromIdx);
    if (dX == 0 and dY == 0) then
        return nil;
    end
    return -atan2(dY, dX);
end

-- Smallest signed difference between two yaw values, in (-pi, pi].
local function yawDifference(a, b)
    local diff = a - b;
    while (diff > math.pi) do
        diff = diff - 2 * math.pi;
    end
    while (diff <= -math.pi) do
        diff = diff + 2 * math.pi;
    end
    return diff;
end

--[[
* One pass over the pending pick: validate everything, then set the target if
* it is not already ours and write the heading if we are not already facing.
* Returns false when the pick is dead/gone/finished and pending should drop.
--]]
local function actOnPending()
    local memory = AshitaCore:GetMemoryManager();
    local entity = memory:GetEntity();
    local target = memory:GetTarget();
    if (entity == nil or target == nil) then
        return false, DROP_REASONS.read;
    end

    local me = selfIndex();
    if (me == nil) then
        return false, DROP_REASONS.read;
    end

    --[[
    * ZONING IS NOT A STATE TO ACT IN. The 0x00A/0x00B handler lets the pick go,
    * but those packets can arrive after the frame that would have acted on it,
    * and the party slot and the entity array both stay readable across the
    * whole load screen -- so nothing above notices. Three things go wrong if
    * this frame acts: the entity array is being rebuilt under `indexForServerId`,
    * a heading written into a character the client is about to re-place is
    * thrown away, and the `/attack <t>` below reaches a command parser that is
    * not taking input yet and answers "A command error occurred." -- which this
    * addon carries no dwecho to swallow, because it is in the suite's NO_SEND
    * list on purpose. `GetIsZoning() == 0` is the client's own word for "the
    * world is real now" and the signal the stock timers addon gates on.
    --]]
    local player = memory:GetPlayer();

    if (player == nil or player:GetIsZoning() ~= 0) then
        return false, DROP_REASONS.zone;
    end

    -- Status 1 is "engaged" and 0 is passive -- and passive is NOT a reason
    -- to drop the pick: when the old target died the client may have
    -- declared the fight over on its own and dropped to passive stance
    -- locally (the exact state the /attack below exists to recover from --
    -- gating on engaged-only dropped the pick here, before the recovery
    -- could ever run). Anything else -- dead, a cutscene -- means forcing a
    -- target would be rude.
    local status = entity:GetStatus(me);

    if (status ~= 1 and status ~= 0) then
        return false, DROP_REASONS.standing;
    end

    local idx = indexForServerId(pending.serverId);
    if (idx == nil or entity:GetHPPercent(idx) <= 0) then
        return false, DROP_REASONS.gone;
    end

    -- The player may have deliberately targeted something else between our
    -- passes. First pass takes the pick regardless (the packet just told us
    -- the old target is gone); the second pass only refreshes its own work.
    local current   = (target:GetIsActive(0) ~= 0) and target:GetTargetIndex(0) or 0;
    if (pending.passes > 0 and current ~= 0 and current ~= idx) then
        return false, DROP_REASONS.retarget;
    end

    if (current ~= idx) then
        target:SetTarget(idx, true);

        if (lastPick ~= nil) then
            lastPick.targeted = true;
        end
    end

    -- The pick's NAME is read only once, and only for `/dwengage status`.
    -- Nothing in the repair itself needs it, so it is read after the index has
    -- resolved rather than in the packet handler, where there is no index yet.
    if (lastPick ~= nil and lastPick.name == nil) then
        local name = entity:GetName(idx);

        lastPick.name = (name ~= nil and name ~= '') and name or nil;
    end

    local yaw = yawToFace(entity, me, idx);
    if (yaw ~= nil) then
        local off = math.abs(yawDifference(yaw, entity:GetLocalPositionYaw(me)));
        if (pending.passes == 0 or off > FACING_SLACK) then
            -- Both yaw mirrors, or the client interpolates back to the old one.
            entity:SetLocalPositionYaw(me, yaw);
            entity:SetLastPositionYaw(me, yaw);

            -- How far the player was actually spun, for the status line. The
            -- offset BEFORE the write is the interesting number: it is the
            -- angle the server's cone would have refused every swing across.
            if (lastPick ~= nil) then
                lastPick.turned = off;
            end
        end
    end

    -- Snap the client back into attack stance. When its old target died the
    -- client may have declared the fight over on its own -- the server
    -- swallows exactly ONE such AttackOff inside two seconds of the hand-off
    -- (CPlayerController::TryConsumeAutoTargetShield, policy party-enmity-v3),
    -- so the engagement survives, but the client has already dropped to
    -- passive stance locally. /attack on the pick re-enters attack mode; if
    -- the client never left it, this is "switch target" to the target it
    -- already has, a no-op on both sides.
    if (pending.passes == 0) then
        -- The one call here that is not a memory read. The chat manager is
        -- absent for a frame or two around a zone line, and a missing one must
        -- not cost the target and the heading that have already landed -- so it
        -- is asked for rather than assumed. (Unguarded, this raised inside the
        -- caller's pcall and dropped the pick after doing the work.)
        local chatMgr = AshitaCore:GetChatManager();

        if (chatMgr ~= nil) then
            chatMgr:QueueCommand(1, '/attack <t>');

            if (lastPick ~= nil) then
                lastPick.engaged = true;
            end
        end
    end

    return true;
end

--[[
* GP_SERV_COMMAND_ASSIST, 0x058. Layout after the 4-byte header: UniqueNo u32
* at 0x04, AssistNo u32 at 0x08 (the entity to hand the player), ActIndex u16
* at 0x0C, and the padding word at 0x0E that the server sets to 1 for its
* auto-target picks. Anything unmarked is not ours to act on.
--]]
ashita.events.register('packet_in', 'dwengage_packet_in', function (e)
    if (e.id ~= 0x058) then
        return;
    end
    if (not enabled) then
        return;
    end
    if (u16(e.data, 0x0E) ~= 1) then
        return;
    end

    local sid = u32(e.data, 0x08);
    if (sid == 0) then
        return;
    end

    local at = os.clock();

    -- A pick still pending when the next one arrives was let go as well: it
    -- never ran its pass, and the status line's "let go" count is the number
    -- a bug report leans on. Overwriting it silently made a run of
    -- back-to-back deaths read as fourteen picks and none let go.
    if (pending ~= nil) then
        dropPending(DROP_REASONS.replaced);
    end

    pending  = { serverId = sid, at = at, passes = 0 };

    -- One table per marked pick, never per frame. Everything else on it is
    -- filled in by the passes; a pick that is dropped before pass one leaves
    -- this holding only the id and the clock, which is still enough for
    -- `/dwengage status` to name the reason.
    lastPick = { serverId = sid, at = at };
    picks    = picks + 1;
end);

--[[
* Zoning, zoning OUT, or logging in makes any pending pick meaningless.
*
* 0x00A is the login/zone-in packet and 0x00B is the client being told it is
* leaving (a zone change or a logout). Waiting for 0x00A alone left a pick
* alive across the whole load screen, walking an entity array the client is
* tearing down under it; the pick is let go at whichever of the two arrives
* first.
--]]
ashita.events.register('packet_in', 'dwengage_zonein', function (e)
    if (e.id == 0x00A or e.id == 0x00B) then
        dropPending(DROP_REASONS.zone);
    end
end);

ashita.events.register('d3d_present', 'dwengage_present', function ()
    -- The steady state is ONE comparison: for all but a few frames of a
    -- fight there is no pick, and this handler must cost nothing then. (It
    -- used to assign `pending = nil` on that path as well, which is a store
    -- sixty times a second to write a value that is already there.)
    if (pending == nil) then
        return;
    end

    -- `enabled` is re-checked here, not only at packet time: /dwengage off
    -- typed inside the 3-second window is the player saying stop NOW, and
    -- honouring the pick anyway spun them once more.
    if (not enabled) then
        dropPending(DROP_REASONS.off);
        return;
    end

    local now = os.clock();
    local age = now - pending.at;

    --[[
    * THE CLOCK CAN GO BACKWARDS. On Windows `os.clock()` is milliseconds in a
    * 32-bit long, so it wraps to negative after about twenty-four and a half
    * days of client uptime -- which the players who leave a client crafting or
    * fishing reach. Every gate below is a difference against it, and a pick
    * whose age has gone negative satisfies none of them: it would sit here
    * unacted and undropped until the next marked packet replaced it. Re-basing
    * costs the pick sixty milliseconds and nothing else.
    --]]
    if (age < 0) then
        pending.at = now;
        return;
    end

    if (age > GIVE_UP_AFTER) then
        dropPending(DROP_REASONS.stale);
        return;
    end
    if (pending.passes == 0 and age < FIRST_PASS_DELAY) then
        return;
    end
    if (pending.passes == 1 and age < SECOND_PASS_DELAY) then
        return;
    end
    if (pending.passes >= 2) then
        -- Both passes ran. That is the pick FINISHING, not being let go, so
        -- it is dropped without a reason being written over what it did.
        pending = nil;
        return;
    end

    -- A memory read must never take the frame down (house rule).
    local ok, keep, why = pcall(actOnPending);
    if (not ok) then
        dropPending(DROP_REASONS.read);
        return;
    end
    if (keep == false) then
        dropPending(why or DROP_REASONS.read);
        return;
    end

    if (lastPick ~= nil and lastPick.serverId == pending.serverId) then
        lastPick.acted = true;
    end

    pending.passes = pending.passes + 1;
end);

--[[
* What the last pick did, in one or two lines.
*
* Every number in here was written at pick time; nothing is computed on the
* frame the player asks. The line exists because a pick that landed and a pick
* that was let go are the same thing from the chair -- you are simply not
* facing the mob -- and the six reasons are all invisible from in there.
--]]
local function printStatus()
    if (enabled) then
        print(chat.header(addon.name):append(chat.message('On for this session: when your target dies you are turned onto the next enemy your party is fighting.')));
    else
        print(chat.header(addon.name):append(chat.message('Off for this session. /dwengage on turns it back on; the launcher\'s Addons tab is the durable switch.')));
    end

    if (lastPick == nil) then
        print(chat.header(addon.name):append(chat.message('No auto-target pick has arrived yet this session. The server sends one only when your target dies with something else still fighting your party, and only while the client\'s own Auto Target option and the map\'s AUTO_TARGET_PARTY_ENMITY setting are both on.')));
        return;
    end

    -- The counts come first, because "is the server sending these at all" is a
    -- different question from "what did the last one do" and only one of them
    -- has an answer the player can act on.
    print(chat.header(addon.name):append(chat.message(('%d pick(s) this session, %d let go without turning you.'):fmt(picks, dropped))));

    -- Clamped, because the same 32-bit wrap that re-bases a pending pick puts
    -- `now` behind the stamp of a pick that already finished, and "-2001698s
    -- ago" is not a sentence a player can use.
    local ago = math.max(0, os.clock() - lastPick.at);
    local who = lastPick.name or ('server id 0x%08X'):fmt(lastPick.serverId);

    if (lastPick.dropped ~= nil) then
        print(chat.header(addon.name):append(chat.message(('Last pick %.0fs ago (%s): let go -- %s.'):fmt(ago, who, lastPick.dropped))));
        return;
    end

    if (not lastPick.acted) then
        print(chat.header(addon.name):append(chat.message(('Last pick %.0fs ago (%s): still settling.'):fmt(ago, who))));
        return;
    end

    local turned = 'your heading was left alone';

    if (lastPick.turned ~= nil) then
        turned = ('turned you %d degree(s)'):fmt(math.floor((lastPick.turned * 180 / math.pi) + 0.5));
    end

    print(chat.header(addon.name):append(chat.message(('Last pick %.0fs ago (%s): %s, %s%s.'):fmt(
        ago,
        who,
        lastPick.targeted and 'targeted it' or 'it was already your target',
        turned,
        lastPick.engaged and ', attack stance restored' or ''))));
end

ashita.events.register('command', 'dwengage_command', function (e)
    local args = e.command:args();
    if (#args == 0 or args[1]:lower() ~= '/dwengage') then
        return;
    end
    e.blocked = true;

    -- No verb at all keeps the 1.1 behaviour -- a bare `/dwengage` flips it --
    -- because that is what the load line and the README have always told
    -- players to type. `on` and `off` exist because a blind flip cannot be
    -- used to REACH a state: a player who wanted it off and typed the toggle
    -- when it was already off turned it on.
    local verb = (#args > 1) and args[2]:lower() or '';

    if (verb == 'status') then
        printStatus();
        return;
    end

    if (verb == 'help') then
        print(chat.header(addon.name):append(chat.message('/dwengage flips it for this session. /dwengage on and /dwengage off say which way. /dwengage status says what the last pick did and why.')));
        return;
    end

    if (verb == 'on' or verb == 'off') then
        enabled = (verb == 'on');
    elseif (verb == '') then
        enabled = not enabled;
    else
        print(chat.header(addon.name):append(chat.error(('Unknown: %s. Try /dwengage help.'):fmt(args[2]))));
        return;
    end

    if (enabled) then
        print(chat.header(addon.name):append(chat.message('On: when your target dies, you are turned onto the next enemy your party is fighting.')));
    else
        print(chat.header(addon.name):append(chat.message('Off for this session. The launcher\'s Addons tab turns it off for good.')));
    end
end);

ashita.events.register('load', 'dwengage_load', function ()
    print(chat.header(addon.name):append(chat.message('Keeps you fighting when your target dies: the server picks the next enemy on the party, this turns you onto it. /dwengage toggles, /dwengage status says what the last pick did.')));
end);
