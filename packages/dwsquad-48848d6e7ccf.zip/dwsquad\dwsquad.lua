--[[
* DriftwoodXI -- dwsquad
*
* Your squad in a window: every character on the account listed by name, job
* and level, with the five squad slots beside them -- add and remove members
* by clicking instead of remembering names and typing !squad set.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It holds no roster of its own, caches nothing to disk, and has no way to
* change a squad the typed command surface could not. Every read is `!dws who`
* and every write is `!dws set|clear`, which reach exactly the same server
* functions `!squad set|clear` reach -- the only difference is that they
* answer in compact records under the sender name _DWSDATA, which this addon
* parses and blocks before the chat log sees them. The Call and Dismiss
* buttons send the literal `!squad call` and `!squad dismiss` a player would
* type, because their output is narrative and belongs in the chat log -- and
* the trust engage toggle sends the literal `!trustengage 0|1` the same way,
* drawn only when the roster's additive `t|` record has said what the mode
* currently is.
*
* ONE THING IT DOES THAT IS NOT RENDERING, since 1.4.1, and it is called out
* here so the claim above stays honest: it clears the collision bit on the
* trusts in your party AND ON THEIR PETS (1.5.0 -- the pets were the half
* that was missing, and a jug in a doorway blocks exactly as well as its
* master), so you walk through your own squad instead of into it.
* That is a write into your own client's memory and not a message to anybody,
* because the server has no say in it -- ghostSquad() below is the long
* version. Nobody else can see the difference and the server records none of
* it, which is why it sits inside a renderer without making it something else.
*
* The alliance row follows the same rule: Form sends the literal `!pally
* <name>`, Join sends `!join`, Dissolve sends `!pleave` -- the server's
* group command lane, which drives the REAL grouping packet handlers (the
* client greys its own grouping UI around squads, so the typed verbs are the
* reachable flow). The row is drawn only when the roster's additive `g|`
* record has said what the group state IS, which is also what tells it an
* invite is waiting to be Joined. Since 1.3.1 the row also states what an
* alliance COSTS -- two parties each earn half of what a kill pays, three
* each earn a third (charutils::AllianceShareDivisor, 2026-08-21) -- because
* the halving is otherwise a number that quietly got smaller.
*
* Since 1.4.0 that section carries a LEVEL SYNC row -- `!alliancesync <name>`,
* `!alliancesync off`, and the bare `!alliancesync` status question when the
* box is empty. It exists because retail's own level-sync menu is party-scoped
* and structurally cannot reach across an alliance (the 0x077 packet is gated
* to Kind == Party), so the typed command is the ONLY door to it and a door
* nobody can find is a door nobody uses. Note what the row does NOT do: it
* never displays the current sync level. No record carries one -- so the
* buttons send the command and the SERVER answers in the chat log, exactly as
* typing does, and showing a level this addon cannot verify would be the one
* thing a renderer must never do.
*
* AND THE REASON THIS PARAGRAPH USED TO GIVE FOR THAT WAS WRONG (corrected
* 1.7.0). It said "inventing one for a button would be a protocol change". It
* would not: an additive record is precisely what `t|`, `f|` and `g|` already
* are, and not one of them moved PROTOCOL -- the deployment-order rule those
* three follow IS the mechanism for adding one. The two reasons that actually
* hold are that nothing on the server emits it (the emitter would be
* squad_storage's `who`, and the C++ side already answers name and level
* through DwAllianceSyncStatus), and that a level another party's leader can
* change without this client hearing about it is a displayed FACT that goes
* stale -- a much higher bar than the `g|` record's pending flag, because a
* stale flag costs a refused button and a stale number is simply a lie. Both
* are answerable; neither is answered here.
*
* Since 1.6.0 the settings block also carries a FOLLOW DISTANCE slider --
* `!trustfollow <yalms>` underneath, how close each trust walks behind the
* one in front of it (the first behind you; since 1.6.2 the whole chain
* keeps the number, not only the first). Every number on the slider -- the
* range, the stock mark, the value -- rides the roster's additive `f|` record
* from the server's own clamp (cpp/squad_follow.cpp), so this file states no
* yalm of its own; the slider sends the typed line once it has rested for
* half a second (a chat line per drag tick would be the client's rate limit
* refusing you), and the roster is re-asked for the settled truth.
*
* Since 1.7.0 the alliance row also carries DECLINE beside Join. It sends the
* literal `!decline` the Join tooltip had been telling players to type since
* 1.3.0, which is this file admitting a button was missing: refusing an invite
* is exactly as much a decision as accepting one, and the client suppresses
* its own invite dialog for squad-holders, so there was no other way to say
* no. The characters panel carries a COPY button for the same kind of reason
* -- the whole account's jobs and levels sit in this one list and nowhere
* else, and "what are your alts" is a question players ask each other
* constantly.
*
* The characters panel also grew a SORT button in 1.7.0: creation order (the
* order the server keeps them in, and the only one that never moves), name,
* main job level highest first, and squad slot. It changes what this list
* looks like and nothing else -- nothing is sent, nothing is written to disk,
* and the server is never told -- and it exists because an account at the
* sixteen-character cap is a list nobody reads in creation order, while the
* question this window is open to answer is asked in terms of level and of
* who is already in.
*
* TWO RULES THIS FILE HAD BEEN BREAKING, both fixed in 1.7.0 and both worth
* stating here because they are about the whole window rather than one row:
*
*   AN ANSWER IS COMMITTED WHOLE, AT ITS `z|`. Every record is its own chat
*   packet, so an eight-character roster is fourteen packets and nothing
*   promises they all reach this addon inside one frame. `d|1|who` used to
*   empty the roster AND take the engage toggle, the follow slider and the
*   alliance row down with it, and the records behind it put them back -- so a
*   frame drawn in the gap was a window with no header block, two panels
*   jumping ninety pixels under the cursor, and a character list scrolled back
*   to the top. Records now fill a staging table and the close swaps it in.
*
*   LAYOUT IS MEASURED, NOT GUESSED (dwcraft's rule). The Status column was 76
*   pixels for a cell whose widest string is `[logged in]` -- eleven
*   characters, exactly as many as the widest thing the Jobs column beside it
*   holds, which was given 128. Whichever font a player runs, one of those two
*   numbers was wrong. Every fixed width in both tables, the character panel's
*   reserve and the window's own floor are now asked of the live font, once
*   per font rather than once per frame.
*
* AND 1.7.0 IS WHEN THIS FILE STOPPED BEING UNTESTED. Until then
* tools/dwsquad/ held source pins that read the file and no harness that ever
* LOADED it, which is how the 1.4.1 walk-through shipped without executing a
* line and how state.follow could be added to one reset list and not the
* other. harness_dwsquad_addon.py now runs the whole addon on LuaJIT 2.1 under
* Ashita stubs and drives the conversation -- every record, both packets, the
* clicks, the hovers, the ghost walk and the answer clock. A change to
* anything below that a player could notice should go red there first.
*
* That constraint is deliberate and it is the reason a UI could be shipped at
* all: a bug in here cannot register a character the server would have
* refused, because it is not doing anything the typed command does not do.
* The ownership check lives in the server's C++ and runs identically
* whichever way the command arrived.
*
* TYPING `!squad` ON ITS OWN NOW OPENS THIS WINDOW. The line is intercepted
* before it leaves the client, so the server never sees it; every other
* !squad command passes through untouched. With the addon off, `!squad`
* prints its usage text exactly as before.
*
* FOUR TABS SINCE 1.8.0 (owner's request), and the reason they exist is that
* this window had run out of vertical room. The header block alone -- the
* button row, the engage toggle, the follow slider, the alliance row and the
* level sync row -- is about 225 pixels before either panel is drawn, and the
* slot panel underneath it was being asked to carry a name, a job pair, a tag,
* an experience line AND a wrapped sentence of every status effect on that
* member, five rows deep. Everything fitted; nothing was readable.
*
*   MAIN is what the window has always been -- the slot panel and the
*   character table, unchanged, including the experience line and the buff
*   SENTENCE on each slot row. Nothing was moved out of it, because a player
*   who never touches a tab must lose nothing.
*
*   STATES is the same buff data drawn the way the CLIENT draws it: a
*   horizontal strip of the game's own status icons with the time left under
*   each one, `8m` and `2h` and a bare `55`, which is the spelling every FFXI
*   player already reads on the party list. The icons are the client's own
*   bitmaps (GetStatusIconByIndex), turned into D3D textures and cached by
*   icon id; a texture that cannot be made falls back to the effect's NAME in
*   that cell, so the tab still answers the question it exists for.
*
*   STATS is the `s|`/`k|` records: HP, MP, TP, the seven attributes and the
*   combat and magic numbers, one COLUMN per member out. It is the only place
*   these numbers exist at all -- a trust has no /check and no status window --
*   and it is what "is this alt actually carrying the party" is asked with.
*
*   EXP is the roster's own experience tail as a BAR rather than a fraction,
*   for every registered member and not only the ones out. `12,345 / 20,000
*   (61%)` is the same three numbers the Main tab's cell states in words; a
*   bar is what "how close is Cid" is actually asked with.
*
* THE STATS RECORDS ARE ADDITIVE, exactly like `t|`, `f|` and `g|` before
* them: a server that sends none leaves state.stats empty and the Stats tab
* says so. Deployment order does not matter in either direction.
*
* TURN IT OFF AND NOTHING IS LOST. `!squad set <slot> <name>`, `!squad clear
* <slot>`, `!squad list`, `!squad call` and `!squad dismiss` all work typed.
* This is friendlier; it is not required.
--]]

addon.name    = 'dwsquad';
addon.author  = 'DriftwoodXI';
addon.version = '1.8.0';
addon.desc    = 'Squad roster window for DriftwoodXI -- four tabs over your own characters: Main, States, Stats and Exp.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- The States tab draws the client's OWN status icons, which are DAT bitmaps
-- and not files: turning one into something imgui.Image can take means
-- D3DXCreateTextureFromFileInMemoryEx over the bytes the resource manager
-- hands back. Same two requires, same idiom and the same cache shape as
-- dwbags/dwraid's item icons -- see statusIconOf below. (1.8.0.)
local d3d   = require('d3d8');
local ffi   = require('ffi');

local C = ffi.C;

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. dwbags
-- owns _DWDATA and dwgambits owns _DWGDATA; this addon must never contend for
-- either, which is why !dws exists at all.
local DATA_SENDER = '_DWSDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

local MAX_SLOTS = 5;

--[[
* The per-slot strings, spelled once rather than string.format'd every frame
* for five sets of five strings that can never change. An ImGui widget id is
* part of the label, so `Remove##slot_3` and `##dwsquad_add_3` were being
* rebuilt sixty times a second exactly like the visible text was.
--]]
local SLOT_LABELS = { '1.', '2.', '3.', '4.', '5.' };
local SLOT_TEXT   = { 'slot 1', 'slot 2', 'slot 3', 'slot 4', 'slot 5' };
local SLOT_REMOVE = {
    'Remove##slot_1', 'Remove##slot_2', 'Remove##slot_3',
    'Remove##slot_4', 'Remove##slot_5',
};
local SLOT_COMBO  = {
    '##dwsquad_add_1', '##dwsquad_add_2', '##dwsquad_add_3',
    '##dwsquad_add_4', '##dwsquad_add_5',
};

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Character flag bits, as the server packs them.
local CHAR_ONLINE = 1;
local CHAR_LOCKED = 2;
local CHAR_SELF   = 4;

local state = T{
    open      = T{ false },

    -- Replaced wholesale by a `who` response, never merged, so a stale row
    -- cannot survive a refresh.
    chars     = T{ },

    -- Status effects on summoned members, keyed by charid -- replaced
    -- wholesale by a `buffs` response for the same reason. The `at` stamp on
    -- each entry is what lets the timers count down between refreshes.
    buffs     = T{ },

    -- Live parameters on summoned members, keyed by charid -- the `s|` and
    -- `k|` records, which ride the SAME `buffs` envelope the effects above do
    -- and are replaced wholesale by it for the same reason. Additive to
    -- protocol 1 like `t|`, `f|` and `g|`: a server that sends none leaves
    -- this empty and the Stats tab says so rather than drawing zeroes.
    --
    -- Each entry carries its own `at` stamp, which is what lets the tab say
    -- how old the numbers are -- these do NOT count down or extrapolate, and
    -- an HP figure quietly aged by arithmetic this addon invented would be
    -- exactly the confident lie the level-sync row refuses to tell.
    stats     = T{ },

    -- The caller's trust engage mode, from the `t|` record the roster carries
    -- (additive to protocol 1): 0 retail (trusts wait for your first swing),
    -- 1 attack (trusts engage the moment you draw your weapon). nil until a
    -- roster carries one -- a server from before the record, or one with the
    -- feature disabled, sends none, and the toggle is simply not drawn. That
    -- is the deployment-order rule every additive record follows here.
    trustEngage = nil,

    -- The caller's group state, from the additive `g|` record: whether their
    -- party stands in an alliance, and what invite (if any) is pending on
    -- them. Same lifecycle as trustEngage -- nil until a roster carries one,
    -- and the alliance row is simply not drawn against a server without the
    -- group command lane.
    group     = nil,

    -- The caller's trust follow distance, from the additive `f|` record:
    -- { tenths, min, max, stock }, all in tenths of a yalm, tenths 0 while
    -- stock. Same lifecycle as trustEngage -- nil until a roster carries
    -- one, and the slider is simply not drawn against a server without
    -- the follow-distance module.
    follow    = nil,

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its own
    -- cannot half-fill the UI.
    inbound   = nil,
    status    = 'Loading...',
    statusBad = false,
    statusAt  = 0,         -- os.clock() the banner was set; it expires
    statusStick = false,   -- ...unless it is a standing condition, not a note
    reported  = false,     -- a render error is worth saying once, not per frame

    -- True once a `d|` envelope this addon can read has arrived. It is what
    -- keeps the answer clock's "the server did not answer" from replacing an
    -- accurate refusal, or an accurate "Update dwsquad", about a server that
    -- had just answered twice (dwport, dwfame 2026-08-15). SESSION-SCOPED and
    -- deliberately not cleared on a zone line: it answers "is this a
    -- DriftwoodXI with dws.lua", which is settled once and does not become
    -- unsettled by walking through a door.
    serverSpoke = false,

    -- True once a `d|` announced a protocol this addon cannot read. Nothing
    -- is asked of such a server again on its own; a zone line, a login or the
    -- Refresh button re-probes it. See the mismatch branch for why the
    -- answered-flag alone was not enough.
    refused   = false,

    -- os.clock() the last roster ARRIVED at, which is the only honest answer
    -- to "how old is what I am looking at". Read on hover, never per frame.
    rosterAt  = nil,

    -- Set while the envelope being read is a refusal of the BACKGROUND buff
    -- poll, which the player never asked for. It keeps that one refusal out
    -- of the chat log without silencing any refusal the player provoked, and
    -- is cleared by the `z|` that closes the envelope.
    quietErr  = false,
};

--[[
* THE BANNER EXPIRES (1.7.0, dwarena's 1.1.0 shape).
*
* Every line below used to be set and cleared by nothing. `Calling the
* squad...` is the worst of them: `!squad call` is answered in NARRATIVE chat
* and never in a record, so nothing this addon reads could ever replace it --
* it stayed pinned green under both panels until the next click, which for a
* window left open is however long the player leaves it open. Twenty seconds
* is long enough to read and short enough that the window stops arguing about
* something already done.
*
* A STICKY line is exempt, and only two are: the protocol mismatch and the
* answer clock's give-up. Those are not progress notes, they are the state
* the window is IN -- and a player who looks away and comes back to an empty
* window with no explanation has been told nothing at all.
--]]
local STATUS_TTL = 20.0;

local function setStatus(text, bad, sticky)
    state.status      = text or '';
    state.statusBad   = bad and true or false;
    state.statusAt    = os.clock();
    state.statusStick = sticky and true or false;
end

-- The banner if it is still worth drawing, else nil.
local function statusText()
    if (state.status == nil or state.status == '') then
        return nil;
    end

    if (not state.statusStick and (os.clock() - state.statusAt) >= STATUS_TTL) then
        return nil;
    end

    return state.status;
end

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A
* TIME. The client rate-limits outgoing chat, and a !dws command is a chat
* line; anything over the limit is answered with "A command error occurred"
* before the server ever sees it. So everything queues here and drains at one
* command per SEND_INTERVAL, and duplicates collapse.
--]]
local SEND_INTERVAL = 1.2;

--[[
* AND THE QUEUE HAS A CEILING (1.7.0).
*
* `issue` collapses an identical command, which bounds every button in this
* window that sends a fixed line -- Call, Dismiss, Join, Decline, Dissolve,
* Lift. It bounds nothing that carries an argument: `!pally <name>` and
* `!alliancesync <name>` are a different command for every name typed into
* the box beside them, and the queue drains one line every 1.2 seconds, so a
* player clicking Form against a list of names -- or clicking anything at all
* while the load screen holds `canSend` shut -- grows this table without a
* stop. Sixteen lines is about twenty seconds of backlog, which is already
* longer than anybody would wait for a click to mean something.
*
* The NEWEST line is refused rather than the oldest dropped: the queue is a
* record of decisions in the order they were made, and silently discarding
* the first one to make room for the seventeenth is the one behaviour a
* player could not possibly predict. Saying so in the banner is the whole
* difference between a throttle and a black hole.
--]]
local QUEUE_MAX = 16;

-- '1 queued...' through '16 queued...', spelled once rather than
-- string.format'd sixty times a second for the whole of a drain -- which is
-- up to twenty seconds after a burst of clicks, and the counter is drawn for
-- every frame of it. `issueLatest` can push the queue one line past the
-- ceiling, so the render keeps a fallback for that one number.
local QUEUE_TEXT = { };

for n = 1, QUEUE_MAX do
    QUEUE_TEXT[n] = string.format('%d queued...', n);
end

local queue    = T{ };
local lastSend = 0;

-- True when the command is on its way (queued now, or already queued by an
-- earlier click); false when the ceiling refused it. Only the callers that
-- latch client-side state off a send have to care -- a latch set for a line
-- that never went out is a row that says "adding..." about nothing.
local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return true;
        end
    end

    if (#queue >= QUEUE_MAX) then
        setStatus('Too many commands are already waiting. Give the queue a moment.', true);

        return false;
    end

    queue:append(command);

    return true;
end

--[[
* Queue a command that SUPERSEDES any earlier one of its kind (1.7.0).
*
* `issue` above collapses an identical command; this collapses one the player
* has changed their mind about. The follow slider settles every half second
* and the queue drains one line every 1.2, so a player who spent half a minute
* finding the distance they wanted queued half a minute of distances they had
* already moved past -- each one landing, in order, long after they stopped
* touching it, with the trusts re-arranging themselves the whole way.
*
* Only the last value of a SETTING means anything, which is what makes the
* earlier ones safe to drop and is why this is not the rule for `!dws set`:
* two registrations are two different facts, and neither replaces the other.
--]]
local function issueLatest(prefix, command)
    for i = #queue, 1, -1 do
        if (queue[i]:sub(1, #prefix) == prefix) then
            table.remove(queue, i);
        end
    end

    queue:append(command);
end

--[[
* WALKING THROUGH YOUR OWN SQUAD (1.4.1; REWRITTEN 1.5.0 after it did not
* work).
*
* THE SERVER CANNOT DO THIS, and that is worth stating plainly because it is
* the obvious place to look. Collision between the player and another entity
* is decided entirely inside the client, from a render flag that lives in the
* client's own entity structure and is not built from any field the server
* sends -- not `status`, not `namevis`, and not the uint32 of EntityFlags the
* 0x00E packet carries at 0x21, whose seven bits are the whole set the server
* has (none, info_icon, hide_name, call_for_help, hide_model, hide_hp,
* untargetable -- build/generated/data/enums/entity_flags.h). There is no
* packet that says "you may walk through this". Ashita's own `casper` addon
* is the proof and the precedent: it does exactly this for other PLAYERS, by
* ORing 0x40 into Render.Flags0 after every 0x000D, and it exists precisely
* because no server can.
*
* WHAT 1.4.1 GOT WRONG. THE FEATURE NEVER RAN AT ALL. The write was gated on
* `SpawnFlags & 0x10` -- "is this entity mob-class" -- reasoning from the
* SERVER's C++ hierarchy (a trust is a CTrustEntity is a CMobEntity) to a
* CLIENT-side flag. The client has never heard of that hierarchy; it sets the
* flag from packet bits, and it keeps a DEDICATED bit for this:
*
*     Ashita-v4beta-2025_q3_update/plugins/sdk/ffxi/enums.h
*         Player 0x0001  Npc 0x0002  PartyMember 0x0004  AllianceMember 0x0008
*         Monster 0x0010 Object 0x0020 ... Fellow 0x0800  TRUST 0x1000
*
* A trust is not a Monster to the client -- it reads 0x0E (Npc | PartyMember |
* AllianceMember), which is exactly what Windower's own Trusts addon tests for
* (`mob.spawn_type == 14`) and what luashitacast's table calls "Party".
* `Monster` is a SEPARATE bit and a trust does not carry it. So the `== 0`
* early-out fired on every member of every squad, every pass, and the two
* lines below it -- the entire feature -- had never executed once.
*
* That is this tree's own named defect class landing at the client boundary:
* mirroring a taxonomy instead of asking the thing that owns the answer.
*
* THE SECOND GAP, which would have bitten the moment the first was fixed: THE
* PARTY LIST DOES NOT CONTAIN PETS. An alt-trust BST's jug, a squad summoner's
* avatar, a dragoon's wyvern and a puppetmaster's automaton are full-size
* bodies standing in the same doorway as their master, and not one of them
* could ever have been found this way. A squad of five fields up to five more
* bodies the old walk could not see.
*
* AND THE THIRD: IT WROTE THE BIT TWICE A SECOND. A trust following you pushes
* an 0x00E every 250ms (trust_entity.cpp's m_nextUpdateTimer), so the poll ran
* at half the rate of the packet that could clear it. `casper` does not poll
* at all -- it writes on the entity's own update packet, the moment the client
* has just touched that structure. The write now happens BOTH ways: on the
* update packet, casper's shape, and on the sweep as the backstop for anything
* standing still.
*
* HOW TARGETS ARE FOUND NOW, and why this cannot touch anything it should not:
*
*   TRUSTS come from the party list as before, but gated on the TARGET INDEX
*   RANGE rather than on a flag -- and the range is a fact THE SERVER
*   GUARANTEES rather than one the client reports. zone_entities.cpp hands
*   trusts and pets a dynamic targid in [0x700, 0x900)
*   (AssignDynamicTargIDandLongID), starts characters at 0x400
*   (GetNewCharTargID) and errors if one ever reaches 0x700. So "a party
*   member at 0x700 or above" IS "a party member who is not a person", with no
*   client flag to be wrong about a second time. Other players stay solid --
*   ghosting them is `casper`'s offer to make and not this addon's to make for
*   you -- and they are excluded structurally by the range, not by a test that
*   could quietly stop matching.
*
*   PETS come from their master, not from a scan: each entity carries the
*   target index of its own pet, so every ghosted trust is asked for one. That
*   is exact. The tempting alternative -- sweep [0x700, 0x900) for anything
*   whose owner is set -- would also catch a CLAIMED MOB, because a claimed
*   mob carries its claimer in the same packet field, and a DWRaid boss is a
*   dynamic entity sitting squarely in that range. Walking through the boss is
*   not a bug anybody would enjoy explaining.
*
* RE-APPLIED, NOT SET ONCE, because the flag is the client's and the client
* rebuilds it: a trust that zones, is dismissed and re-summoned, or drops out
* of render range comes back solid. Every read is wrapped -- a target index
* can go stale between the party list and the entity array on a zone line,
* which is the same reason dwparse's tracked-id walk wraps its pet read.
*
* AND IT REPORTS ITSELF. `/squad ghost` prints what this layer sees and what
* it wrote, per entity, including READING THE BIT BACK after the write. If a
* player still collides, that one line separates the three possible causes --
* nothing was found, the write did not stick, or the write stuck and 0x40 is
* not the lever for this entity class -- without another round of guessing.
--]]
local GHOST_INTERVAL = 0.5;
local GHOST_NO_CLIP  = 0x40;   -- Render.Flags0 bit: stop colliding with it
local GHOST_DYN_LOW  = 0x700;  -- first dynamic targid: trusts and pets
local GHOST_DYN_HIGH = 0x900;  -- one past the last

local ghostAt = 0;

-- The indices this layer decided are ghostable on the last sweep. The packet
-- hook re-applies to these and only these: it must not do a party walk on
-- every 0x00E (a busy zone sends hundreds a second), and an index that has
-- not been vetted by a sweep has no business being written to.
local ghostSet = { };

-- One write, and the truth about it. Returns nil when there is no entity at
-- this index, else a row the diagnostic prints: what was there before, what
-- was written, and WHAT IT READS BACK AS -- the read-back is the whole point,
-- because "wrote it and it did not stick" and "never wrote it" look identical
-- from outside and have completely different fixes.
local function ghostOne(idx)
    local row = nil;

    pcall(function ()
        local ent = GetEntity(idx);

        if (ent == nil) then
            return;
        end

        local before = ent.Render.Flags0;

        if (bit.band(before, GHOST_NO_CLIP) == 0) then
            ent.Render.Flags0 = bit.bor(before, GHOST_NO_CLIP);
        end

        row =
        {
            index  = idx,
            name   = ent.Name or '?',
            before = before,
            after  = ent.Render.Flags0,
            pet    = ent.PetTargetIndex or 0,
        };
    end);

    return row;
end

-- Walk the party, ghost every member that is not a person, then ghost that
-- member's pet. Returns the rows when asked to (the diagnostic), nil when not
-- -- the sweep runs 120 times a minute and must not build a table each time.
local function ghostWalk(collect)
    local rows  = collect and { } or nil;
    local party = AshitaCore:GetMemoryManager():GetParty();

    -- BOTH EARLY-OUTS EMPTY THE SET, and that is not tidiness (1.7.0). The
    -- set is what the 0x000E hook is allowed to write to; "there is nobody
    -- logged in" is precisely the state in which nothing should be written at
    -- all, and leaving yesterday's indices in it means the first packet after
    -- the next character loads is a write against whatever now owns them.
    if (party == nil) then
        ghostSet = { };

        return rows;
    end

    -- Slot 0 active is the tree-wide "there is a logged-in character" test
    -- (dwmacro, dwscan). Without it this walks a stale party array at the
    -- character-select screen and writes into whatever the last session left
    -- in the entity table.
    if (party:GetMemberIsActive(0) ~= 1) then
        ghostSet = { };

        return rows;
    end

    local seen = { };

    -- 1..17, not 0..17: slot 0 is the player, and a player who cannot collide
    -- with the world is a different and much worse bug.
    for i = 1, 17 do
        local idx = nil;

        pcall(function ()
            if (party:GetMemberIsActive(i) ~= 1) then
                return;
            end

            local at = party:GetMemberTargetIndex(i);

            -- The range IS the test. Below 0x700 is a real character (or an
            -- unfilled slot reading 0) and stays solid.
            if (at ~= nil and at >= GHOST_DYN_LOW and at < GHOST_DYN_HIGH) then
                idx = at;
            end
        end);

        if (idx ~= nil) then
            local row = ghostOne(idx);

            if (row ~= nil) then
                seen[idx] = true;

                if (rows ~= nil) then
                    row.kind = 'trust';
                    table.insert(rows, row);
                end

                -- The master's own pet, asked of the master rather than
                -- hunted for. Range-checked too: a pet is a dynamic entity
                -- exactly like its summoner, and anything answering outside
                -- that range is a stale read, not a pet.
                local pet = row.pet;

                if (pet >= GHOST_DYN_LOW and pet < GHOST_DYN_HIGH) then
                    local petRow = ghostOne(pet);

                    if (petRow ~= nil) then
                        seen[pet] = true;

                        if (rows ~= nil) then
                            petRow.kind = 'pet of ' .. tostring(row.name);
                            table.insert(rows, petRow);
                        end
                    end
                end
            end
        end
    end

    ghostSet = seen;

    return rows;
end

local function ghostSquad()
    local now = os.clock();

    if (now - ghostAt < GHOST_INTERVAL) then
        return;
    end

    ghostAt = now;

    ghostWalk(false);
end

-- casper's shape: the entity's own update packet is the moment the client has
-- just written that entity's structure, so it is the moment to write the bit
-- back. 0x000E is the packet trusts and pets arrive on (they are sent with
-- UPDATE_ALL_MOB, zone_entities.cpp), and ActIndex sits at 0x08 in it exactly
-- as it does in the 0x000D casper reads.
--
-- Gated on the sweep's verdict AND re-checked against the client's own trust
-- marker, and the second half is not belt-and-braces -- it is required.
--
-- THE SERVER RECYCLES DYNAMIC TARGIDS IN EXACTLY THE BAND THIS SET HOLDS.
-- `m_nextDynamicTargID` walks [0x700, 0x900) and reuses a freed index as soon
-- as it comes back round. Dismiss a squad member mid-fight -- or let its
-- avatar go -- and within the next half second a DWRaid arena can insert an
-- add that inherits that very targid. The sweep would not have run yet, the
-- stale `ghostSet` entry would still say yes, and the player would be able to
-- WALK THROUGH A RAID BOSS. Half a second is a small window and a fight is
-- exactly when it opens.
--
-- So the set narrows the work (this fires for every entity in the zone and
-- must stay cheap) and `TrustOwnerTargetIndex` decides. That field is the
-- client's own trust marker -- our entity_update stamps the trust flag and
-- the summoner as owner for trusts AND their pets -- and a recycled index
-- belonging to a mob reads 0 the moment the client rebuilds the entity.
ashita.events.register('packet_in', 'dwsquad_ghost', function (e)
    if (e.id ~= 0x000E) then
        return;
    end

    -- Nothing has been vetted, so there is nothing this hook can write:
    -- return BEFORE the pcall rather than inside it. A busy zone pushes
    -- hundreds of 0x000E a second, `pcall(function () ... end)` allocates a
    -- fresh closure on every one of them because the body captures `e`, and
    -- an empty set is the state of every player who has no squad out --
    -- which is most players, most of the time. (1.7.0.)
    if (next(ghostSet) == nil) then
        return;
    end

    pcall(function ()
        local idx = struct.unpack('H', e.data_modified, 0x08 + 1);

        if (not ghostSet[idx]) then
            return;
        end

        local entity = AshitaCore:GetMemoryManager():GetEntity();

        if (entity ~= nil and entity:GetTrustOwnerTargetIndex(idx) == 0) then
            -- The index was recycled onto something that is not a trust or a
            -- trust's pet. Drop it rather than write to it, and let the next
            -- sweep rebuild the set.
            ghostSet[idx] = nil;

            return;
        end

        ghostOne(idx);
    end);
end);

local function pumpQueue()
    -- THE EMPTY TEST COMES FIRST (1.7.0). An empty queue is the state of every
    -- player in every frame in which they have not just clicked something, and
    -- `echo.canSend()` is three calls across the memory-manager boundary
    -- (GetMemoryManager, GetPlayer, GetIsZoning) for a question nobody is
    -- waiting on the answer to. Nothing below reads canSend before this, so
    -- the order is free.
    if (#queue == 0) then
        return;
    end

    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a window drawn sixty times a second asks
* once. THE ANSWER IS TRACKED, NOT JUST THE QUESTION: a command issued in the
* same instant as something the player typed can be eaten by the client's
* chat throttle, and one lost command must not leave the panel stale for
* ever. An unanswered request is asked once more after ANSWER_TIMEOUT and
* then left alone -- a retry that never terminates is a command loop, which
* is worse than a stale panel.
*
* A PLAIN TABLE, NOT `T{ }`: this table is keyed by verb names, and a `T{ }`
* resolves unknown keys through its metatable to the sugar table methods --
* which is exactly the dwbags round-7 bug, paid for once already.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

-- True once the server has said it has no `buffs` verb -- one from before that
-- verb was added. `buffs` is ADDITIVE to protocol 1, so the `d|` version guard
-- cannot see this: the version did not change, and the only thing that says so
-- is the dispatch's own unknown-verb sentence. Without this flag the poll is
-- unstoppable -- it fires off cached roster flags every BUFFS_INTERVAL for as
-- long as anyone is out, and each refusal repaints the window's banner red for
-- a command the player never typed. Detected and reset exactly the way dwbags
-- does its three: off the sentence, cleared on every login line, so a server
-- upgraded underneath a running client gets asked again rather than never.
local buffsUnsupported = false;

local function refresh()
    requested = {};
end

-- A write's response carries the fresh roster, so the roster question is
-- registered as pending without being asked: if the write's answer is lost,
-- needRoster's retry covers it.
local function expectRoster()
    -- `write = true` marks this as a roster the PLAYER's own set/clear is about
    -- to bring back, which the `d|<v>|status` branch below uses to stand down.
    -- needRoster's plain read deliberately does not carry it.
    requested['who'] = { at = os.clock(), answered = false, tries = 1, write = true };
end

local function needRoster()
    -- A server whose protocol this addon cannot read is not asked again on
    -- its own: the one accurate thing on screen is "Update dwsquad", and
    -- another round trip cannot improve on it. Re-probed by a zone line or a
    -- login (a deploy can move underneath a running client) and by the
    -- Refresh button, which is the player asking.
    if (state.refused) then
        return;
    end

    local asked = requested['who'];

    if (asked ~= nil) then
        --[[
            AN ANSWERED READ IS THE COMMON CASE AND IT IS ANSWERED HERE, FIRST
            (1.7.0). Nothing below can act on a roster that has already
            arrived -- the give-up branch tests `not asked.answered` and the
            retry is unreachable -- and `echo.canSend()` is three calls across
            the memory-manager boundary (GetMemoryManager, GetPlayer,
            GetIsZoning). It was being asked sixty times a second for the
            whole time a window sat open on a roster it already had.
        --]]
        if (asked.answered) then
            return;
        end

        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout, and a false give-up.
        -- (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            --[[
                AND THE STOP HAS TO SAY SO (1.7.0). Until now this branch
                returned for ever with the window still reading `Loading...`,
                which is indistinguishable from a server about to answer: the
                one state a player cannot act on is the one they cannot tell
                from progress. Every sibling in the suite carries this banner
                (dwport, dwcpx, dwquest); this window was the one that did not.

                ONE-SHOT, via the latch, because this runs inside the render
                loop: re-asserted every frame it would overwrite every other
                status the window tried to show. And only when the server has
                never spoken -- a server that answered and then refused has
                already said something more useful than this sentence, and
                replacing it would be the answer-clock defect the whole suite
                closed on 2026-08-15.
            --]]
            if (not asked.answered and not asked.gaveUp
                    and asked.tries >= ANSWER_TRIES
                    and (os.clock() - asked.at) >= ANSWER_TIMEOUT
                    and not state.serverSpoke) then
                asked.gaveUp = true;

                setStatus('The server did not answer. Is this DriftwoodXI, and is the update installed?', true, true);
            end

            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['who'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dws who');
end

--[[
* Buffs are the one thing in this window that changes without the player
* clicking anything, so they are re-asked on an interval -- but only while a
* member is actually out, so an idle window sends nothing. The lost-answer
* rules are needRoster's; a fresh cycle starts clean rather than inheriting
* the retry count of the one before it.
--]]
local BUFFS_INTERVAL = 15.0;

local function anySummoned()
    for _, member in pairs(state.chars) do
        if (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
            return true;
        end
    end

    return false;
end

local function needBuffs()
    --[[
        THE POLL STOPS WITH THE READS (1.7.0). The `d|` version guard marks
        every outstanding request answered and returns, and for needRoster
        above that IS a stop -- it never re-asks an answered read. This
        function is a POLL, so an answered request is exactly what it re-asks
        on the next interval: the buff read carried on firing at a server
        whose answers this addon cannot parse, every fifteen seconds, for as
        long as the last roster it did understand claimed somebody was out.
        The header two functions up promised the opposite ("re-asking a server
        that speaks a layout this addon cannot read cannot help -- the
        background buff poll least of all"); this is the line that makes it
        true.
    --]]
    if (state.refused or buffsUnsupported or not anySummoned()) then
        return;
    end

    local asked = requested['buffs'];

    if (asked ~= nil) then
        if (asked.answered) then
            if ((os.clock() - asked.at) < BUFFS_INTERVAL) then
                return;
            end

            -- ...and the interval has passed, so this cycle is over and the
            -- one below starts. `echo.canSend()` is deliberately NOT consulted
            -- on this path (1.7.0): the poll's next line is only QUEUED here,
            -- and pumpQueue holds the queue shut while the load screen is up,
            -- so nothing is lost by asking -- while asking canSend here cost
            -- three calls across the memory-manager boundary on every frame of
            -- every fifteen-second wait, for the whole time a squad is out.
        else
            -- A held send (zone-in) leaves the line queued; aging the answer
            -- clock against it would be a false timeout. This is the path
            -- that ages one. (dwecho canSend; 2026-08-15.)
            if (not echo.canSend()) then
                return;
            end

            if (asked.tries >= ANSWER_TRIES) then
                -- A spent retry budget is a lost CYCLE, not a lost feature:
                -- left as a tombstone, this branch returns forever and the
                -- slot rows keep counting down a snapshot that only gets
                -- staler. Drop the tracker once the ordinary interval has
                -- passed and the next cycle starts clean, exactly as the
                -- header above promises.
                if ((os.clock() - asked.at) >= BUFFS_INTERVAL) then
                    requested['buffs'] = nil;
                end

                return;
            end

            if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
                return;
            end

            asked.at    = os.clock();
            asked.tries = asked.tries + 1;
            asked.quiet = true;

            issue('!dws buffs');

            return;
        end
    end

    -- `quiet` marks this as the one request in this addon that NOBODY ASKED
    -- FOR. It repeats on a timer off cached roster flags, so when those flags
    -- are stale -- the squad died, or was dismissed by something this window
    -- did not see -- the server's perfectly correct "nobody is out" refusal
    -- was printed into the player's chat log every fifteen seconds, for a
    -- command they never typed. See the `d|` handler for the other half.
    requested['buffs'] = { at = os.clock(), answered = false, tries = 1, quiet = true };

    issue('!dws buffs');
end

--[[
* Record parsing. Every record is pipe-separated with a single-character
* type. Anything this addon does not recognise is ignored rather than being
* an error: a server newer than the addon must not break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* A WHOLE NUMBER OFF THE WIRE, and the reason it is a function (1.7.0).
*
* Every numeric field this protocol carries is an integer -- squad_storage
* writes them all with `%i` -- and the parser below took each of them with a
* plain `tonumber(...) or 0`, which is the right shape for "the field might be
* absent" and the wrong one for "the field might be garbage". LuaJIT's
* `tonumber` accepts `75.5`, `nan`, `inf` and a twenty-digit run, and what
* happens next is not a parse error, because handleRecord is pcall'd and costs
* one record.
*
* WHAT ACTUALLY HAPPENS, MEASURED RATHER THAN REMEMBERED (corrected 1.7.0; the
* first draft of this note, written earlier the same day, had it wrong and the
* rest of the suite has it wrong the same way). The claim was that
* `string.format('%d', 75.5)` RAISES with "number has no integer
* representation". IT DOES NOT. That is Lua 5.3/5.4's error; `%d` keeps Lua
* 5.1 semantics on LuaJIT and truncates. Measured on the harness's own
* LuaJIT 2.1, which is the engine it loads this file into -- the client's and
* ext/luajit's 2.1.0-beta3 are the same interpreter family and this is
* behaviour LuaJIT has never changed, but the measurement is of the harness's
* build and the claim is no broader than that:
*
*     string.format('%d', 2.5)      -> '2'          (truncated, no error)
*     string.format('%d', 0/0)      -> '-9223372036854775808'
*     string.format('%d', math.huge)-> '-9223372036854775808'
*     string.format('%s', nil)      -> 'nil'        (the word, no error)
*
* So the damage is quieter than the note claimed and the guard is still
* needed, for the two reasons that survive measurement:
*
*   * A WRONG NUMBER STATED CONFIDENTLY. `nan` and `inf` and 1e20 all reach
*     the screen as -9223372036854775808, which a player reads as a level, an
*     experience total or a slot.
*   * A FRACTION IS NOT A KEY. A fractional `slot` passes
*     `>= 1 and <= MAX_SLOTS` and then indexes the slot view at 2.5, so the
*     row is stored where nothing looks for it -- and `SLOT_TEXT[2.5]` is nil,
*     which IS an error, at the ImGui binding rather than at string.format:
*     `imgui.TextDisabled(nil)` inside the render, where the pcall's answer is
*     to close the window.
*
* (A build that DID raise would make this guard more necessary, not less, so
* nothing below changes -- only the sentence explaining it. The harness pins
* the measured behaviour so the claim cannot drift back.)
*
* `n ~= n` is the NaN test written the way the tree's other integrality guards
* write it (squad_core's slot check), because every comparison against a NaN
* is false and a magnitude test alone would let it through. The clamp is what
* keeps a huge value representable at all: `math.floor(1e20)` is still 1e20.
--]]
local WIRE_MAX = 2147483647;

local function wholeOf(text, fallback)
    local n = tonumber(text);

    if (n == nil or n ~= n) then
        return fallback or 0;
    end

    if (n > WIRE_MAX) then
        return WIRE_MAX;
    end

    if (n < -WIRE_MAX) then
        return -WIRE_MAX;
    end

    return math.floor(n);
end

--[[
* Slots with an `!dws set` in flight: slot -> { at, name, label, tip }.
* `assign` never mutates state.chars (the fresh roster is the server's to
* send), so without this two Add clicks inside one send interval both read the
* same firstEmptySlot() and the second silently overwrites the first. Cleared
* when the next roster lands; the age test is the belt for a roster that never
* comes. A plain table: slot numbers are safe keys, but the T{} sugar rule is
* applied uniformly.
*
* IT CARRIES THE NAME SINCE 1.7.0, because the slot ROW was still lying about
* itself. A slot with a registration in flight kept drawing `(empty -- click
* to add)` and kept offering the dropdown, so a player who clicked Add for one
* character and then picked a second one out of that same slot's list did not
* replace an empty slot -- they replaced the registration already on its way
* to it, and SetSquadSlot happily obliged. The character panel had said
* `adding...` about this for a whole version; the panel the player is actually
* looking at said nothing at all.
*
* The label and the sentence are built ON THE CLICK rather than per frame: the
* row draws for as long as PENDING_SLOT_WINDOW, which is 360 frames.
--]]
local pendingSlots = { };

--[[
* And the same latch over the CHARACTER, which is not the same guard (1.7.0).
*
* SetSquadSlot DELETES any row that character already holds before it inserts
* one (cpp/squad_data.cpp: "re-registering a member that already sits in
* another slot MOVES it, rather than failing the unique (accid, charid) key").
* So two Add clicks on ONE character inside a single send interval were never
* an add and a refusal -- they were an add and a MOVE. The player who
* double-clicked a button that had not visibly reacted yet ended up with that
* character in the SECOND slot and the first one empty, which reads as the
* first click having been lost.
*
* charid -> { at = os.clock(), slot = n }. Cleared by the fresh roster with
* pendingSlots, and aged out by the same window for a roster that never comes.
--]]
local pendingChars = { };

local PENDING_SLOT_WINDOW = 6.0;

--[[
* THE VIEW REVISION. Everything both panels draw is derived from state.chars
* and changes only when a roster lands; the render pass rebuilt all of it
* sixty times a second. `modelRev` is bumped by every write to state.chars,
* and `viewOf` below -- which has to wait for the row formatters -- rebuilds
* against it. Declared here because handleRecord is the thing that writes.
--]]
local modelRev  = 0;
local viewCache = nil;

local function bumpModel()
    modelRev  = modelRev + 1;
    viewCache = nil;
end

--[[
* THE ANSWER IS COMMITTED WHOLE, AT `z|` (1.7.0; dwbags' SECTIONS shape, and
* the one house rule this file had never followed).
*
* Every record is its own GP_SERV_COMMAND_CHAT_STD packet -- squad_storage
* says so in the note explaining why the `who` response does not send
* per-container rows -- so an eight-character roster is fourteen packets and
* nothing guarantees the client hands them all to the addon inside one frame.
* Until now `d|1|who` emptied state.chars AND took the trust engage toggle,
* the follow slider and the whole alliance row down with it, and the records
* behind it put them back. A frame drawn in that gap showed:
*
*   * a window with NO header block -- the toggle, the slider and the alliance
*     row are about 90 pixels between them -- so both panels jumped up and
*     then back down, under the cursor, on every roster the window asked for;
*   * an empty character table, whose ScrollY position ImGui clamps to 0
*     against zero rows, so a player who had scrolled to their sixteenth
*     character was returned to the first;
*   * both panel captions in their "no roster yet" spelling.
*
* So the records now fill a STAGING table and `z|` swaps it in. Nothing on
* screen changes until the whole answer is in hand, and an envelope that
* never closes -- a dropped packet, a zone line mid-answer -- leaves the
* previous roster standing instead of a truncated one. That direction is
* deliberate: a character silently missing from the list reads as a character
* that is GONE, and stale-but-whole is the smaller lie. Refresh's hover says
* how old what is on screen is, which is the honest half of it.
--]]
local staging = nil;

-- The engage toggle's ImGui holder (Checkbox writes into a table), re-synced
-- from state.trustEngage every frame it is drawn -- the server's answer is
-- the truth, this is just the widget's clipboard.
local engageUi = T{ false };

-- The follow slider's holder (SliderFloat writes into a table), in yalms.
-- Re-synced from state.follow every frame the player is NOT dragging it;
-- while they are, followEdited holds the clock of their last move, and the
-- typed line goes out only once the slider has rested FOLLOW_SETTLE seconds
-- -- one command per decision, never one per drag tick.
local followUi     = T{ 0 };
local followEdited = nil;

local FOLLOW_SETTLE = 0.5;

-- The alliance row's name box (InputText writes into a table). Purely local
-- until Form is clicked: the name is the one argument !pally needs. 16 is
-- the buffer, not the rule -- FFXI names run 3-15 characters, and the server
-- answers a wrong name with words.
local allyName = T{ '' };

-- The level sync row's own name box, deliberately NOT shared with allyName
-- above: Form wants the other party's LEADER, level sync wants ANY member of
-- the alliance, and a player who typed one and clicked the other would get a
-- refusal they did not earn. Same 16-character buffer for the same reason.
local syncName = T{ '' };

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        -- Through the whole-number guard like every other numeric field
        -- (1.7.0): this one is FORMATTED into the mismatch banner, and a
        -- malformed `d|` carrying `nan` reads as "Server protocol
        -- -9223372036854775808" on the one line whose whole job is to tell a
        -- player what to do next. The comparison below is unaffected -- a
        -- garbage version is a mismatch either way.
        local version = wholeOf(parts[2]);

        if (version ~= PROTOCOL) then
            -- STICKY: this is a standing condition and not a progress note.
            -- A banner that expired here would leave an empty window and no
            -- reason for it, which is the state the banner exists to prevent.
            setStatus(string.format('Server protocol %d, addon expects %d. Update dwsquad.', version, PROTOCOL),
                true, true);

            state.inbound = nil;
            staging       = nil;

            -- A d| envelope IS the answer, whatever version it announced, and
            -- re-asking a server that speaks a layout this addon cannot read
            -- cannot help -- the background buff poll least of all. One shape
            -- across the suite (dwfame, 2026-08-15); gated in
            -- harness_dwsuite.py.
            --
            -- THE LATCH IS THE OTHER HALF, and 1.6.2 did not have it. Marking
            -- the asks answered stands the ROSTER down, because needRoster
            -- never re-asks an answered read -- but needBuffs is a poll, and
            -- an answered request is precisely what a poll re-asks on its next
            -- interval. So the sentence above was true of one read and false
            -- of the other, and the buff poll ran on against an unreadable
            -- server every fifteen seconds. `serverSpoke` deliberately stays
            -- false: this server does not speak a dwsquad this addon knows.
            state.refused = true;

            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.serverSpoke = true;
        state.inbound     = parts[3];

        -- A response replaces its own section outright, and the replacement
        -- happens at `z|`: nothing on screen moves until the whole answer is
        -- in hand (see the `staging` note above). The reset here is of the
        -- STAGING table, and it runs FIRST -- handleRecord is called under a
        -- pcall, and anything that throws after `state.inbound` is set must
        -- cost one record, not leave a half-built answer for the records
        -- behind it to append to.
        --[[
            NOTE WHAT IS NOT DONE HERE: THE ASK IS NOT MARKED ANSWERED (1.7.0).

            It used to be, and that was right while the `d|` was also the
            reset -- the envelope's arrival WAS the answer, because its first
            record had already changed the window. Now the answer is the `z|`,
            and an envelope whose close never arrives (a dropped packet, a
            zone line mid-answer) leaves the previous roster standing. If the
            ask were marked answered here, that stale roster would stand for
            ever: needRoster never re-asks an answered read, so nothing short
            of Refresh, a write or a zone line would ever correct it.

            Marked at the close instead, so a lost `z|` is a lost ANSWER and
            the ordinary five-second retry recovers it. `serverSpoke` is still
            set here, which is what keeps the give-up banner from accusing a
            server that plainly did answer.
        --]]
        if (state.inbound == 'who') then
            -- A plain table, not `T{ }`: its keys are field names, and a T{}
            -- resolves an unknown key through its metatable to the sugar
            -- table's methods (the dwbags round-7 bug `requested` carries the
            -- same note about). `chars` is the T{} -- it is the one this
            -- addon indexes by charid and hands to the view.
            staging = { chars = T{ } };
        end

        if (state.inbound == 'buffs') then
            -- The `s|`/`k|` parameters ride this same envelope, so they
            -- are staged with it and committed by the same `z|`: two halves
            -- of one answer must never be half-swapped, and a member whose
            -- effects came from this poll while its numbers came from the
            -- last one is exactly that.
            staging = { buffs = T{ }, stats = T{ } };
        end

        --[[
            A REFUSAL IS AN ANSWER. A bare `fail` arrives in its own
            `d|1|status` envelope, so the buff poll's outstanding request was
            never marked answered by anything -- it retried, exhausted its
            tries, and left the roster still claiming somebody was out, which
            is the state that made it poll in the first place.

            Only the quiet poll is treated this way: a refusal the PLAYER
            provoked belongs in the chat log, loudly.
        --]]
        if (state.inbound == 'status') then
            local writing = requested['who'];
            local asked   = requested['buffs'];

            -- ...and the shared writer wraps EVERY pre-envelope note or refusal
            -- in `d|<v>|status`, whichever command it was answering -- set and
            -- clear included. One of those is not the poll's answer, and
            -- swallowing it costs the player their own refusal sentence AND
            -- blanks every buff row. So a player-provoked write that is still
            -- outstanding takes precedence; the `who` envelope it brings back
            -- marks itself answered, so the shield drops on its own.
            if (type(writing) == 'table' and writing.write and not writing.answered) then
                asked = nil;
            end

            if (type(asked) == 'table' and asked.quiet and not asked.answered) then
                asked.answered = true;
                asked.at       = os.clock();

                --[[
                    THE CLEAR HAPPENS AT THE `z|`, NOT HERE (1.8.0, and the
                    suite's own rule -- harness_dwsuite's "a rendered section
                    is not wiped at `d|`").

                    This used to empty state.buffs on the spot. The refusal's
                    own prose arrives in the `e|` record BEHIND this one, so
                    every frame drawn in the gap was a States tab with no
                    icons, a Stats tab saying the server sends no parameters,
                    and no sentence anywhere saying why -- the empty-with-no-
                    reason state the banner exists to prevent, reached from
                    the other direction.

                    `quietErr` is already exactly the flag for it: set here,
                    read by the `e|` handler, and cleared by the `z|` that
                    closes this envelope. So the close does the emptying, in
                    the same instant the sentence lands.
                --]]
                state.quietErr = true;

                -- Re-ask the ROSTER only. A full refresh() would clear the
                -- entry just marked answered, needBuffs would fire again off
                -- the same stale rows, and that is a command loop.
                requested['who'] = nil;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- message saying why a change was refused is worth more than the response
    -- it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- The one refusal that is not worth a red banner: a server from before
        -- the buff read answering the background poll with its unknown-verb
        -- sentence. That means per-member buffs do not exist here yet, so the
        -- addon stops asking and draws no buff rows -- deployment order must
        -- not matter in either direction, and the rest of the window is
        -- untouched by it. Same shape as dwbags' three unsupported verbs.
        if (kind == 'e' and not buffsUnsupported
                and string.find(line, 'unknown verb "buffs"', 1, true) ~= nil) then
            buffsUnsupported = true;

            -- The outstanding request goes with it. Left behind it is an entry
            -- claiming a question is still in flight, and the `d|` handler's
            -- quiet-refusal branch would keep clearing the roster request off
            -- it -- a roster re-ask per refusal, for a poll that is now off.
            requested['buffs'] = nil;
            state.buffs        = T{ };
            state.stats        = T{ };

            return;
        end

        -- Everything after the first pipe, not parts[2]: these carry prose.
        setStatus(line:sub(3), kind == 'e');

        -- Errors also go to the chat log: the window may already be closed,
        -- and "nothing happened" is the worst possible feedback. The one
        -- exception is the background buff poll, which the player did not ask
        -- for -- its refusal still reaches the window's status bar, just not
        -- their chat log every fifteen seconds.
        if (kind == 'e' and not state.quietErr) then
            print(chat.header('dwsquad'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        --[[
            THE CLOSE HAS TO NAME THE ENVELOPE IT CLOSES (1.7.0).

            `z|` carried a verb from the day the writer was written and this
            reader had never read it -- any `z|` closed whatever happened to
            be open. That was survivable while the close only cleared a flag;
            it is not survivable now that the close COMMITS. A `z|status`
            arriving while a `who` envelope is open would swap an empty
            staging table in for the whole roster, which is precisely the
            blank window this change exists to prevent.

            Today's server cannot send one -- `open`/`close` are called in
            pairs with the same verb and `wrapped` emits neither mid-envelope
            -- so this is a guard over a shape rather than a fix for a
            sighting. It is one line, and the thing it protects is everything
            on screen.
        --]]
        if (parts[2] ~= nil and parts[2] ~= '' and parts[2] ~= state.inbound) then
            return;
        end

        --[[
            THE SWAP. Everything the answer said, in one instant, or nothing
            at all: a `staging` that is missing (an envelope this addon never
            opened) leaves what is on screen exactly where it is.
        --]]
        if (state.inbound == 'who' and staging ~= nil and staging.chars ~= nil) then
            -- THE CLOSE IS THE ANSWER (see the `d|` handler): a `who` whose
            -- `z|` never arrived has to be re-asked, and needRoster never
            -- re-asks a read it believes was answered.
            local asked = requested['who'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end

            state.chars = staging.chars;

            -- Wholesale-replace, like the rows: a roster from a server that
            -- stopped sending `t|` (feature turned off) must also take the
            -- toggle with it, not leave a stale one clickable. The `g|` group
            -- state and the `f|` follow record follow for the same reason --
            -- and staging them means the rows do not blink out and back in
            -- while the records that rebuild them are still arriving.
            state.trustEngage = staging.trustEngage;
            state.group       = staging.group;
            state.follow      = staging.follow;

            -- The fresh roster is the truth about which slots are taken and
            -- who holds them, so both in-flight latches have done their job.
            -- Cleared HERE and not at the `d|`: between the two the roster on
            -- screen is still the old one, and a latch dropped early hands a
            -- slot out twice or offers an Add for a registration already gone.
            pendingSlots = { };
            pendingChars = { };

            bumpModel();

            -- The roster arriving is the moment "Loading..." stops being true.
            if (state.status == 'Loading...') then
                setStatus('');
            end

            -- ...and the moment the window can honestly say how old what it
            -- is showing is. Refresh's hover reads this; nothing per frame
            -- does.
            state.rosterAt = os.clock();
        elseif (state.inbound == 'buffs' and staging ~= nil and staging.buffs ~= nil) then
            local asked = requested['buffs'];

            if (type(asked) == 'table') then
                asked.answered = true;

                -- The poll's interval runs from the answer, not from the ask:
                -- a slow server must not shorten the next fifteen seconds.
                asked.at = os.clock();
            end

            state.buffs = staging.buffs;

            -- Committed with the effects and never on their own. `or T{ }` is
            -- the deployment-order contract and not tidiness: a server from
            -- before these records opens the envelope, sends no `s|` at all
            -- and closes it, and the swap has to leave an EMPTY table rather
            -- than a nil the Stats tab would index.
            state.stats = staging.stats or T{ };
        end

        --[[
            AND A REFUSED BACKGROUND POLL EMPTIES ITS OWN SECTIONS HERE, for
            the reason the `d|` handler's quiet branch gives: the refusal and
            the sentence explaining it land together, rather than the rows
            going dark one packet before anybody is told why.

            Both sections and not just one: `s|`/`k|` ride the same envelope
            the `b|` records do, so a refusal that leaves the parameters
            standing is a Stats tab describing members the server just said
            are not out.
        --]]
        if (state.quietErr) then
            state.buffs = T{ };
            state.stats = T{ };
        end

        staging        = nil;
        state.inbound  = nil;
        state.quietErr = false;

        return;
    end

    -- Every record below belongs to an envelope, and an envelope that opened
    -- built a staging table. No staging is a record for a `d|` this addon
    -- never accepted; there is nowhere honest to put it.
    if (staging == nil) then
        return;
    end

    -- t|<0|1> -- the caller's trust engage mode, riding the roster.
    if (kind == 't' and state.inbound == 'who') then
        staging.trustEngage = (tonumber(parts[2]) == 1) and 1 or 0;

        return;
    end

    -- f|<tenths>|<min>|<max>|<stock> -- the caller's trust follow distance,
    -- riding the roster (1.6.0). Tenths of a yalm throughout; tenths 0 is
    -- "stock". A record whose range does not bracket anything is dropped
    -- rather than drawn: a slider with no honest ends is worse than none.
    if (kind == 'f' and state.inbound == 'who') then
        local follow = T{
            tenths = wholeOf(parts[2]),
            min    = wholeOf(parts[3]),
            max    = wholeOf(parts[4]),
            stock  = wholeOf(parts[5]),
        };

        if (follow.min > 0 and follow.max > follow.min and follow.stock >= follow.min and follow.stock <= follow.max) then
            staging.follow = follow;
        end

        return;
    end

    -- g|<in alliance 0|1>|<pending kind party|alliance|''>|<inviter or ''> --
    -- the caller's group state, riding the roster. The pending half is what
    -- draws the "an invite is waiting" line; an empty inviter name (a
    -- cross-process inviter the server could not resolve) still names the
    -- kind, which is the load-bearing part.
    if (kind == 'g' and state.inbound == 'who') then
        local pendingKind = parts[3];

        if (pendingKind ~= 'party' and pendingKind ~= 'alliance') then
            pendingKind = nil;
        end

        local from = parts[4];

        if (from == nil or from == '') then
            from = 'another player';
        end

        staging.group = T{
            alliance    = (tonumber(parts[2]) == 1),
            pendingKind = pendingKind,

            -- The waiting line, spelled once here rather than string.format'd
            -- sixty times a second for the whole time an invite stands open.
            -- Only meaningful when there IS one, so nil otherwise.
            pendingLine = pendingKind ~= nil and string.format(
                '%s invite from %s is waiting -- Join accepts it, Decline refuses it.',
                pendingKind == 'alliance' and 'An alliance' or 'A party', from) or nil,
        };

        return;
    end

    if (kind == 'c' and state.inbound == 'who') then
        local charid = wholeOf(parts[2]);

        --[[
            THE SLOT IS CLAMPED TO A SLOT THAT EXISTS (1.7.0), and this is a
            crash and not tidiness. Two places decide "is this a real squad
            slot" and they used DIFFERENT tests: `viewOf` takes a member into
            the slot view only for `>= 1 and <= MAX_SLOTS`, while the
            character panel's own Status cell tests `> 0` and then indexes
            `SLOT_TEXT[member.slot]`. Those two agree on every value the
            server sends and disagree on exactly the ones it does not: a `c|`
            carrying 6 draws `imgui.TextDisabled(nil)`, which is a Lua error
            at the ImGui binding, inside the render, where the pcall's answer
            is to close the whole window -- and the Copy button beside it
            quietly writes the word `nil` into the clipboard on the same row
            (LuaJIT's `string.format('%s', nil)` prints it rather than
            raising). `wholeOf` made a garbage field a whole number; it cannot
            make it a slot.

            Clamped to 0 -- "registered nowhere" -- rather than to MAX_SLOTS,
            because inventing a membership is worse than showing none, and 0
            is what every other absent field on this record reads as.
        --]]
        local slot = wholeOf(parts[11]);

        if (slot < 0 or slot > MAX_SLOTS) then
            slot = 0;
        end

        -- Fields 9 and 10 are bag used/size, which this window has no use
        -- for; field 11 is the squad slot, which is its whole subject.
        --
        -- Fields 12-14 are the experience tail (1.5.0). `or 0` is not
        -- defensive tidiness here, it is the compatibility contract: a server
        -- from before the tail sends ten fields, this reads three absences as
        -- three zeroes, and xpTextOf below renders that as NO CELL AT ALL
        -- rather than as a confident 0 / 0.
        staging.chars[charid] = T{
            charid = charid,

            -- `or '?'` is the render's guard, not the parser's: handleRecord
            -- is pcall'd and a nil name costs it nothing, but three functions
            -- later imgui.Text(nil) is a Lua error inside the render, which
            -- closes the window over one malformed line. (1.7.0.)
            name   = parts[3] or '?',
            mjob   = wholeOf(parts[4]),
            mlvl   = wholeOf(parts[5]),
            sjob   = wholeOf(parts[6]),
            slvl   = wholeOf(parts[7]),
            flags  = wholeOf(parts[8]),
            slot   = slot,
            exp    = wholeOf(parts[12]),
            next   = wholeOf(parts[13]),
            xflags = wholeOf(parts[14]),
        };

        return;
    end

    -- b|<charid>|<name>|<id>:<icon>:<remaining>,... -- status effects on one
    -- summoned member. A member's effects can span several records (the
    -- server packs to its line budget), so entries append to the member and
    -- the wholesale reset happens at the `d|` above. A bare record with no
    -- entries is the member announcing it has nothing, which still replaces
    -- whatever was showing.
    if (kind == 'b' and state.inbound == 'buffs') then
        local charid = wholeOf(parts[2]);

        -- A HIRED MERCENARY HOLDS NO SQUAD CHARID and the server sends its
        -- record under 0 (squad_core's `b|` prefix is built from
        -- getLocalVar('dwSquadCharId')). Nothing in this window can render a
        -- charid the roster does not carry, so those rows were never drawn --
        -- but every merc out shared that one key and appended to the same
        -- list, which grew for as long as the envelope did. Dropped here
        -- rather than rendered, because a renderer with no row for it has
        -- nothing honest to do with it. (1.7.0.)
        if (charid == 0) then
            return;
        end

        local entry = staging.buffs[charid];

        if (entry == nil) then
            entry = T{ name = parts[3] or '?', at = os.clock(), list = T{ } };
            staging.buffs[charid] = entry;
        end

        if (parts[4] ~= nil and parts[4] ~= '') then
            for id, icon, rem in string.gmatch(parts[4], '(%-?%d+):(%-?%d+):(%-?%d+)') do
                entry.list:append(T{
                    id   = wholeOf(id),
                    icon = wholeOf(icon),
                    rem  = wholeOf(rem, -1),
                });
            end
        end

        -- The rendered sentence is cached against the whole second below; a
        -- record that changes the list has to take it with it, or the window
        -- would show the old effects until the next second ticked over.
        entry.text = nil;

        return;
    end

    --[[
        THE TWO PARAMETER RECORDS (1.8.0), which are ONE fact split across two
        lines for the only reason any record in this protocol is split: the
        150-byte chat line. Twenty-two numbers plus a charid do not fit in
        one, and a record truncated by the writer is a record the reader
        cannot tell from a short one.

            s|<charid>|<hp>|<hpmax>|<mp>|<mpmax>|<tp>|<str>|<dex>|<vit>|<agi>|<int>|<mnd>|<chr>
            k|<charid>|<att>|<def>|<acc>|<eva>|<ratt>|<racc>|<matt>|<macc>|<mdef>|<meva>

        THE ORDER IS THE CONTRACT and there is no field name on the wire, so
        the two sides agree by position or not at all -- which is why every
        one of these goes through `wholeOf` like every other numeric field
        this protocol carries, and why a MISSING trailing field reads as 0
        rather than as nil. A server that grows the tail later sends more
        fields and this reader ignores them; a server from before half of it
        sends fewer and this reader draws zeroes for the half it did not get.
        Both are survivable; a nil three functions later inside the render
        pcall is not (the `c|` record's `or '?'` note, same reasoning).

        THE TWO RECORDS SHARE ONE ENTRY rather than each owning its own,
        because the Stats tab draws both halves in one column and a member
        described twice would be two columns for one trust. Whichever arrives
        first creates the entry and the other fills the rest of it; a half
        that never arrives -- a dropped packet, a server that grew one record
        before the other -- reads as zeroes in its own rows, which is the same
        contract a missing trailing FIELD has and is stated here so that
        `0 / 0` in the Vitals block is understood as "not told" rather than as
        a member with no hit points. The `at` stamp is taken by whichever
        record came first, so the age on the header is the age of the sample
        and not of its second line.
    --]]
    if (kind == 's' and state.inbound == 'buffs') then
        local charid = wholeOf(parts[2]);

        -- A hired mercenary holds no squad charid and rides under 0, exactly
        -- as its `b|` record does. There is no roster row to draw it against.
        if (charid == 0) then
            return;
        end

        local entry = staging.stats[charid];

        if (entry == nil) then
            entry = T{ };
            staging.stats[charid] = entry;
        end

        entry.at    = os.clock();
        entry.hp    = wholeOf(parts[3]);
        entry.hpmax = wholeOf(parts[4]);
        entry.mp    = wholeOf(parts[5]);
        entry.mpmax = wholeOf(parts[6]);
        entry.tp    = wholeOf(parts[7]);
        entry.str   = wholeOf(parts[8]);
        entry.dex   = wholeOf(parts[9]);
        entry.vit   = wholeOf(parts[10]);
        entry.agi   = wholeOf(parts[11]);
        entry.int   = wholeOf(parts[12]);
        entry.mnd   = wholeOf(parts[13]);
        entry.chr   = wholeOf(parts[14]);

        return;
    end

    if (kind == 'k' and state.inbound == 'buffs') then
        local charid = wholeOf(parts[2]);

        if (charid == 0) then
            return;
        end

        local entry = staging.stats[charid];

        if (entry == nil) then
            entry = T{ };
            staging.stats[charid] = entry;
        end

        entry.at   = entry.at or os.clock();
        entry.att  = wholeOf(parts[3]);
        entry.def  = wholeOf(parts[4]);
        entry.acc  = wholeOf(parts[5]);
        entry.eva  = wholeOf(parts[6]);
        entry.ratt = wholeOf(parts[7]);
        entry.racc = wholeOf(parts[8]);
        entry.matt = wholeOf(parts[9]);
        entry.macc = wholeOf(parts[10]);
        entry.mdef = wholeOf(parts[11]);
        entry.meva = wholeOf(parts[12]);

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Layout after the 4-byte header: sName[15]
* at 0x08, Mes at 0x17. Any line whose sender is _DWSDATA is ours: it is
* consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwsquad_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    -- ONE BYTE BEFORE TWO SUBSTRINGS. Every Driftwood data sender is an
    -- underscore followed by capitals and no FFXI character name can begin
    -- with one, so this rejects every ordinary say, shout, tell and linkshell
    -- line in the zone without allocating the sender string and then the
    -- gsub'd copy of it. The exact comparison below is unchanged and still
    -- decides. (1.7.0.)
    if (e.data_modified:byte(0x09) ~= 0x5F) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwsquad'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Helpers over the roster.
--]]

--[[
* THE ORDER OF THE CHARACTER LIST (sorting added 1.7.0).
*
* Creation order is the only order the SERVER has an opinion about and it
* stays the default, because it is the one that never moves: a row is where it
* was the last time the window was open. But an account at the sixteen-
* character cap is a list nobody reads that way, and the question this window
* exists to answer -- who should I bring? -- is asked in terms of level, and
* of who is already in. So the list can be re-ordered, and the re-ordering is
* LOCAL in every sense: nothing is sent, the server is not told, and nothing
* is written to disk, because this addon caches nothing to disk on purpose.
*
* EVERY COMPARATOR ENDS ON charid, WHICH IS UNIQUE. LuaJIT's table.sort raises
* "invalid order function for sorting" when handed a comparator that is not a
* strict weak ordering, and two rows that compare false in both directions --
* two characters at the same level, two characters not in the squad -- is
* exactly the shape that finds it. A unique final key makes that impossible.
*
* All four are hoisted to file locals for the reason the first one was:
* `table.sort` was being handed a freshly allocated closure on every frame
* that drew the character list.
--]]
local function byCharId(a, b)
    return a.charid < b.charid;
end

local function byName(a, b)
    if (a.name ~= b.name) then
        return a.name < b.name;
    end

    return a.charid < b.charid;
end

local function byLevel(a, b)
    -- Highest first: the question a level answers here is which of these
    -- could carry a fight, and the answer is read from the top.
    if (a.mlvl ~= b.mlvl) then
        return a.mlvl > b.mlvl;
    end

    return a.charid < b.charid;
end

local function bySquad(a, b)
    -- Registered members first in slot order, everybody else behind them.
    -- Slot 0 means "registered nowhere", so it has to sort LAST -- a plain
    -- `a.slot < b.slot` puts every unregistered character at the top, which
    -- is the opposite of what the column is being sorted for.
    local aslot = a.slot > 0 and a.slot or (MAX_SLOTS + 1);
    local bslot = b.slot > 0 and b.slot or (MAX_SLOTS + 1);

    if (aslot ~= bslot) then
        return aslot < bslot;
    end

    return a.charid < b.charid;
end

--[[
* The cycle the Sort button walks. THE LABELS ARE PADDED TO ONE WIDTH on
* purpose: a button whose text changes width shoves everything to its right
* along the row every time it is pressed, and this one shares a line with a
* caption and the Copy button. The `##` tail keeps the widget id stable across
* all four so ImGui sees one button being relabelled rather than four buttons
* taking turns.
--]]
local SORTS = {
    {
        label = 'Sort: age  ##dwsquad_sort',
        order = byCharId,
        tip   = 'Ordered by when each character was created -- the order the server keeps\n' ..
                'them in, and the only one that never moves. Click for name.',
    },
    {
        label = 'Sort: name ##dwsquad_sort',
        order = byName,
        tip   = 'Ordered by name, A to Z. Click for level.',
    },
    {
        label = 'Sort: level##dwsquad_sort',
        order = byLevel,
        tip   = 'Ordered by main job level, highest first -- who could carry a fight.\n' ..
                'Click for squad slot.',
    },
    {
        label = 'Sort: squad##dwsquad_sort',
        order = bySquad,
        tip   = 'Registered members first, in slot order, then everybody else.\n' ..
                'Click to go back to creation order.',
    },
};

-- Which one is on. Session-scoped and client-local; the roster arrives in the
-- server's order and is re-ordered here, so nothing about this can disagree
-- with the server about anything.
local sortAt = 1;

local function jobsOf(member)
    local text = string.format('%s%d', JOB_NAMES[member.mjob] or '?', member.mlvl);

    if (member.sjob ~= 0 and member.slvl ~= 0) then
        text = text .. string.format('/%s%d', JOB_NAMES[member.sjob] or '?', member.slvl);
    end

    return text;
end

local function isSelf(member)
    return bit.band(member.flags, CHAR_SELF) ~= 0;
end

--[[
* THE EXPERIENCE CELL (1.5.0, owner request: see everyone's EXP and TNL in
* /squad). Three states, and the two that are NOT a bar matter more than the
* one that is:
*
*   AT CAP -- a character sitting at its own genkai is not 55999 points from
*   anywhere, it is finished until a limit break. Drawing the number would
*   read as "one point to go" forever, which is the most confidently wrong
*   thing this cell could say.
*
*   MERIT MODE -- the bar is frozen because the experience is going somewhere
*   else entirely (charutils routes the whole award into limit points once a
*   master is past 74 with the mode on). A number here would be a lie about a
*   bar that is never going to move again.
*
*   OTHERWISE -- earned / needed for the MAIN JOB THIS CHARACTER IS WEARING,
*   which is the job its alt-trust fights as and therefore the one the owner
*   is deciding about.
*
* A zero `next` means either the tail was absent (an older server) or the
* character is outside the exp table's 1..99 range. Both draw nothing, which
* is the honest answer for both.
--]]
local XP_CAPPED = 1;
local XP_MERITS = 2;

--[[
* A WHOLE NUMBER WITH THOUSANDS SEPARATORS (1.8.0), for the Exp tab's bar
* overlay and nowhere else. `41000 / 55000` is two numbers a player has to
* count the digits of; `41,000 / 55,000` is two numbers they read. The Main
* tab's cell keeps the bare spelling deliberately -- it is a narrow table
* cell and the commas cost it two characters of a width that is already
* measured.
*
* The loop is the standard one and it terminates because gsub reports how many
* it replaced: three digits at a time from the right, never inside the first
* group. Built once per roster in viewOf below, never per frame.
--]]
local function commaOf(n)
    local text = string.format('%d', n or 0);
    local done;

    repeat
        text, done = text:gsub('^(-?%d+)(%d%d%d)', '%1,%2');
    until done == 0;

    return text;
end

local function xpTextOf(member)
    if (bit.band(member.xflags or 0, XP_MERITS) ~= 0) then
        return 'merit points';
    end

    if (bit.band(member.xflags or 0, XP_CAPPED) ~= 0) then
        return 'at cap';
    end

    if ((member.next or 0) <= 0) then
        return nil;
    end

    return string.format('%d / %d', member.exp or 0, member.next);
end

-- The same fact at length, for a hover. `next - exp` is the number a player is
-- actually asking for when they ask about TNL, and it is computed here rather
-- than sent: it is the difference of two numbers already on the wire, and a
-- third field would be a third thing free to disagree with the other two.
local function xpTooltipOf(member)
    if (bit.band(member.xflags or 0, XP_MERITS) ~= 0) then
        return 'In merit mode -- experience is going to limit points, not to the next level.';
    end

    if (bit.band(member.xflags or 0, XP_CAPPED) ~= 0) then
        return string.format('%s is at its level cap. A limit break raises it.', member.name);
    end

    if ((member.next or 0) <= 0) then
        return nil;
    end

    return string.format('%s: %d of %d experience as %s%d -- %d to the next level.',
        member.name, member.exp or 0, member.next,
        JOB_NAMES[member.mjob] or '?', member.mlvl,
        math.max(member.next - (member.exp or 0), 0));
end

local function tagOf(member)
    if (isSelf(member)) then
        return '(you)';
    elseif (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
        return '[summoned]';
    elseif (bit.band(member.flags, CHAR_ONLINE) ~= 0) then
        return '[logged in]';
    end

    return '';
end

--[[
* THE VIEW, BUILT ONCE PER ROSTER RATHER THAN ONCE PER FRAME (1.7.0).
*
* Everything the two panels draw is derived from state.chars and changes only
* when a roster lands, which is at most once a second and usually far less --
* but the render pass rebuilt all of it sixty times a second. Per frame, for
* an account at the sixteen-character cap: an ordered copy of the table and a
* fresh sort closure, TWO more tables for the slot view (squadPanel wanted
* one and firstEmptySlot wanted another), and then per character a jobs
* string, a tag, an experience cell and the six-argument experience SENTENCE
* -- which was formatted whether or not the row was hovered, because the tip
* was computed before IsItemHovered was asked. That came to about fifty
* string.format calls and four table allocations every frame, for text
* identical in all sixty of them.
*
* The cache is keyed on `modelRev`, which every write to state.chars bumps,
* so it cannot go stale: a roster landing between two frames rebuilds it on
* the next one. Nothing here caches anything that moves on its own -- the
* buff countdown is cached against the second, further down, and the
* pending-write latches are read live because a click changes them.
--]]
local function viewOf()
    -- Keyed on the sort as well as the roster: pressing the button changes
    -- what is drawn without changing a byte of the model, so a cache keyed on
    -- the model alone would keep handing back the old order for ever.
    if (viewCache ~= nil and viewCache.rev == modelRev and viewCache.sort == sortAt) then
        return viewCache;
    end

    local ordered  = T{ };
    local slots    = T{ };
    local filled   = 0;
    local summoned = 0;

    for _, member in pairs(state.chars) do
        ordered:append(member);

        if (member.slot >= 1 and member.slot <= MAX_SLOTS) then
            slots[member.slot] = member;
            filled = filled + 1;
        end

        -- Out RIGHT NOW, which is not the same question as registered: the
        -- lock survives a slot being cleared underneath a member that is
        -- already standing beside you, and it is the number that says whether
        -- Call and Dismiss have anything to do.
        if (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
            summoned = summoned + 1;
        end
    end

    table.sort(ordered, SORTS[sortAt].order);

    for _, member in ipairs(ordered) do
        member.jobsText = jobsOf(member);
        member.tagText  = tagOf(member);
        member.xpText   = xpTextOf(member);
        member.xpTip    = xpTooltipOf(member);

        -- The squad panel prefixes the cell; the character table does not, so
        -- both spellings are built here rather than one of them per frame.
        member.xpLabel  = member.xpText ~= nil and ('XP ' .. member.xpText) or nil;

        --[[
            THE EXP TAB'S BAR, decided here rather than in the render (1.8.0):
            a ProgressBar wants a fraction and an overlay string, and both are
            derived from three fields that change only when a roster lands.
            Formatted per frame for sixteen characters this would be thirty-two
            allocations a frame for text identical in all sixty of them, which
            is the exact shape this cache was built to remove.

            THREE STATES AND ONLY ONE OF THEM IS A BAR THAT MOVES, which is
            xpTextOf's rule and this follows it rather than restating it:

              AT CAP -- a FULL bar, because the character has finished the
              level it is on and an empty bar would read as no progress at
              all. The overlay says what raises it, so a full bar that never
              moves is not mistaken for one about to tick over.

              MERIT MODE -- NO bar. The experience is going to limit points
              and the bar would be frozen wherever it happened to stand; a
              frozen bar is a lie a number is not.

              NO TAIL (`next` 0) -- no bar, for a server from before the
              experience tail or a character outside the exp table's range.
              The Main tab's cell draws nothing for the same reason.
        --]]
        if (bit.band(member.xflags or 0, XP_MERITS) ~= 0) then
            member.xpFrac    = nil;
            member.xpOverlay = 'merit points -- experience is going to limit points';
        elseif (bit.band(member.xflags or 0, XP_CAPPED) ~= 0) then
            member.xpFrac    = 1.0;
            member.xpOverlay = 'at cap -- limit break raises it';
        elseif ((member.next or 0) > 0) then
            local earned = member.exp or 0;
            local frac   = earned / member.next;

            -- Clamped because the wire is not trusted to be sane: a `c|`
            -- carrying an exp above its own next draws a bar past its end,
            -- and ImGui does not clamp it for us.
            if (frac < 0) then
                frac = 0;
            elseif (frac > 1) then
                frac = 1;
            end

            member.xpFrac    = frac;
            member.xpOverlay = string.format('%s / %s (%d%%)',
                commaOf(earned), commaOf(member.next), math.floor(frac * 100));
        else
            member.xpFrac    = nil;
            member.xpOverlay = nil;
        end

        -- The two button ids. An ImGui widget id is part of its label, so
        -- these were two more string.format calls per row per frame for a
        -- string that only changes when the charid does -- which is never.
        member.addId    = 'Add##c_' .. member.charid;
        member.removeId = 'Remove##c_' .. member.charid;
    end

    -- A PLAIN TABLE, not `T{ }`: the keys here are names, and a `T{ }`
    -- resolves an unknown key through its metatable to the sugar table's
    -- methods -- the dwbags round-7 bug, which `requested` above carries the
    -- same note about. Every key below is set, so nothing would reach the
    -- metatable today; the rule is applied uniformly so that adding a key
    -- later cannot be the thing that finds out.
    viewCache = {
        rev      = modelRev,
        sort     = sortAt,
        ordered  = ordered,
        slots    = slots,
        filled   = filled,
        summoned = summoned,

        --[[
            The two panel captions, which carry a count and would otherwise be
            a string.format each per frame for a number that changes with the
            roster and nothing else. Before the first roster there is no count
            to state, and "0 characters on this account" is a worse thing to
            say while loading than saying nothing.

            AND THEY BOTH HAD TO GET SHORTER (1.7.0), which is a sizing fix
            and not a wording preference. The slot panel is 416 pixels wide at
            the window's own 880 minimum -- about 398 inside the child's
            border and padding -- and `Your squad` plus `-- 2 of 5 registered,
            summoned as trusts by !squad call` measures about 449, so the end
            of the sentence was clipped off mid-word by the child drawing it.
            (The count added earlier this version is what pushed it over; the
            old caption fitted.) The character panel's line is fixed at 440
            however wide the window is, and the Sort button added below needs
            room on it. Both explanations moved to the captions' own hovers,
            which is where a sentence that long belongs.
        --]]
        squadCaption = #ordered > 0
            and (summoned > 0
                    and string.format('-- %d of %d registered, %d out', filled, MAX_SLOTS, summoned)
                    or  string.format('-- %d of %d registered', filled, MAX_SLOTS))
            or  '-- summoned as trusts by !squad call',

        charsCaption = #ordered > 0
            and string.format('-- %d character%s', #ordered, #ordered == 1 and '' or 's')
            or  '-- everyone on this account',
    };

    return viewCache;
end

-- The registration on its way into this slot, or nil once it has landed or
-- aged out. One reader for both panels, so the row and the Add button can
-- never disagree about whether a slot is free.
local function pendingInSlot(slot)
    local pending = pendingSlots[slot];

    if (pending == nil or (os.clock() - pending.at) >= PENDING_SLOT_WINDOW) then
        return nil;
    end

    return pending;
end

-- Is any slot mid-write? Asked only from a hover, never per frame: it is
-- the difference between "all five are taken" and "wait a second".
local function anyPendingSlot()
    for slot = 1, MAX_SLOTS do
        if (pendingInSlot(slot) ~= nil) then
            return true;
        end
    end

    return false;
end

local function firstEmptySlot()
    local slots = viewOf().slots;

    for slot = 1, MAX_SLOTS do
        if (slots[slot] == nil and pendingInSlot(slot) == nil) then
            return slot;
        end
    end

    return nil;
end

-- The slot a character is on its way into, or nil. Both panels ask before
-- offering to add anybody: the click has gone out, the roster has not come
-- back, and a second registration for the same character MOVES the first.
local function pendingSlotOf(member)
    -- Empty is the state this table is in almost always -- there is a write in
    -- flight for at most six seconds after a click -- and this is asked once
    -- per character per frame, so the empty case answers with a table lookup
    -- rather than a clock read.
    if (next(pendingChars) == nil) then
        return nil;
    end

    local pending = pendingChars[member.charid];

    if (pending == nil or (os.clock() - pending.at) >= PENDING_SLOT_WINDOW) then
        return nil;
    end

    return pending.slot;
end

--[[
* Writes. Every one is the same server command a player could type, queued
* through the throttle, with the roster registered as an expected answer so a
* lost response is re-asked rather than trusted.
--]]
local function assign(slot, member)
    if (not issue(string.format('!dws set %d %s', slot, member.name))) then
        -- The ceiling refused the line. Latching a write that never left
        -- would grey the Add button and pin `adding...` on a row for six
        -- seconds over a command the server is never going to hear.
        return;
    end

    expectRoster();

    --[[
        THE WINDOW OPENS WHEN THE LINE CAN LEAVE, NOT WHEN IT WAS CLICKED
        (1.7.0). Both latches are belts against a roster that never comes, and
        both were stamped with the click -- but the queue drains one line every
        SEND_INTERVAL, so a click made behind four others is still SITTING IN
        THE QUEUE when a six-second window measured from the click has already
        run out. The moment it does, firstEmptySlot offers that same slot to
        the next character, two `!dws set` lines for one slot go out in order,
        and the second one wins: exactly the double-registration these latches
        exist to prevent, arriving through the throttle instead of through a
        double click.

        `#queue` already counts the line just queued, so the wait ahead of it
        is everything before it. Nothing here needs to be exact -- it is a
        belt, and being a second generous is the safe direction.
    --]]
    local at = os.clock() + math.max(#queue - 1, 0) * SEND_INTERVAL;

    -- Both latches, one stamp: the slot cannot be handed out twice, and the
    -- character cannot be registered twice (which would MOVE it, not add it).
    -- The slot's row draws the label and the sentence, so both are spelled
    -- here rather than sixty times a second for the six seconds they last.
    pendingSlots[slot] = {
        at    = at,
        name  = member.name,
        label = string.format('adding %s...', member.name),
        tip   = string.format(
            '%s is being registered into slot %d. The command has gone out and the\n' ..
            'server has not answered yet -- picking somebody else for this slot now\n' ..
            'would REPLACE that registration rather than add a second one, so the\n' ..
            'dropdown waits.', member.name, slot),
    };

    pendingChars[member.charid] = { at = at, slot = slot };

    setStatus(string.format('Adding %s to slot %d...', member.name, slot), false);
end

local function unassign(slot, member)
    if (not issue(string.format('!dws clear %d', slot))) then
        return;
    end

    expectRoster();

    setStatus(string.format('Removing %s from slot %d...', member.name, slot), false);
end

--[[
* Rendering.
--]]

--[[
* The one-line hover, hoisted (dwquest's `tip`). It exists for ONE reason the
* inline `if imgui.IsItemHovered()` below cannot serve: a tab header's hover
* has to be asked OUTSIDE the `if` that tests whether the tab opened, because
* ImGui submits the tab as an item inside BeginTabItem whether it opened or
* not -- and the first widget the tab BODY draws takes the "last item" away.
* Written inside the branch, three of the four tab tips would only ever be
* reachable on the tab already open, which is the one that needs no
* explaining.
--]]
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

--[[
* THE HOVER SENTENCES that are not built from a row's own data (1.7.0).
*
* A table rather than forty literals scattered through the render, for two
* reasons: the harness can read it, and two controls that mean the same thing
* cannot drift apart. The ones with a `%` in them are formatted INSIDE the
* IsItemHovered branch and never before it -- the experience tip was built for
* every row of every frame and thrown away unless the mouse happened to be
* over that row, which is the shape this file's perf pass exists to remove.
*
* Every claim here is one the server's own code makes: a logged-in character
* is refused by `PlayerHasValidSession` in squad_core's call, a member above
* the summoner's level is synced DOWN by squad_spawn.cpp's paint, and the
* character being played is refused by xi.squad.set before ownership is even
* checked. Nothing here states a rule this addon invented.
--]]
local TIPS = {
    call    = 'Summon every registered member as a trust -- same as typing !squad call.\n' ..
              'Refused in a fight already in progress, while the zone is still loading,\n' ..
              'and anywhere the squad is not allowed out.',
    dismiss = 'Send the whole squad home -- same as typing !squad dismiss.\n' ..
              'Real trusts you summoned alongside them are left alone.',
    refresh = 'Ask the server for the roster again. The window re-asks on its own after\n' ..
              'every change it makes; this is for something that moved where it could\n' ..
              'not see -- a member dismissed by a level sync, or a slot set on another\n' ..
              'character.',
    queue   = 'Commands waiting to go out. The client accepts about one chat line a second\n' ..
              'and a ! command is a chat line, so clicks are queued and sent one at a\n' ..
              'time instead of being refused.',
    empty   = 'Register one of your other characters in this slot. It is summoned as a\n' ..
              'trust by Call squad and fights at its own job and level -- synced DOWN to\n' ..
              'yours if it is higher, never up.',
    self    = 'This is the character you are playing. It cannot be its own trust, and the\n' ..
              'server refuses that whichever way the command arrives.',
    full    = 'All five squad slots are taken. Remove somebody before adding anybody.',

    -- ...which is NOT the same state as "every free slot has a registration
    -- on its way into it", and firstEmptySlot answers nil to both. Telling a
    -- player to remove somebody when what they have to do is wait a second is
    -- advice that makes the window look broken.
    fullWait= 'Every squad slot is either taken or has a registration on its way into it.\n' ..
              'Give the server a moment to answer, or Remove somebody.',
    member  = 'A summoned member walks with you and you walk THROUGH it: dwsquad clears\n' ..
              'the collision bit on your own trusts and on their pets, inside your own\n' ..
              'client. /squad ghost reports what it wrote.',
    buffs   = 'What is on this member right now. The timers count down here between\n' ..
              'refreshes, and the list is re-read every fifteen seconds while anybody\n' ..
              'is out.',
    copy    = 'Copy the whole roster -- names, jobs, levels, experience and squad slots --\n' ..
              'to the clipboard, as plain text, in the order shown.',
    decline = 'Refuse the pending invite -- same as typing !decline.',
    nameCol = 'Every character on this account, including the one you are playing.\n' ..
              'The Sort button beside the panel title decides the order; it changes\n' ..
              'nothing but this list.',
    jobsCol = 'Main job and level, then support job and level -- what the member fights as.',
    stateCol= 'The squad slot the character holds, or what it is doing instead.',

    -- The action column has no header text to explain itself, and what it
    -- draws differs per row: a button, a dash, or nothing at all.
    actCol  = 'Add registers the character in the first free squad slot; Remove takes it\n' ..
              'out again. The character you are playing shows a dash instead -- it cannot\n' ..
              'be its own trust.',

    -- The two panel captions carry a count and nothing else since 1.7.0 (they
    -- were being clipped); the sentence they used to carry lives here.
    squadCap= 'Your five squad slots. Call squad summons every registered member as a\n' ..
              'trust and Dismiss sends them home; `out` counts the ones standing beside\n' ..
              'you right now, which is not always the same as the ones registered.',
    charsCap= 'Every character on this account -- the one you are playing included.\n' ..
              'This list is the only place they are all shown together.',

    -- A slot held by the character being played: registered, and permanently
    -- refused by Call squad for exactly the reason [logged in] is.
    selfSlot= 'This slot holds the character you are PLAYING. Call squad cannot summon it\n' ..
              '-- a character cannot be in two places at once -- so the slot does nothing\n' ..
              'until you play somebody else or Remove it.',

    -- The blank Status cell. A cell that draws nothing explains nothing, and
    -- "nothing" here is a real and useful state: this character is available.
    idle    = 'Not in the squad and not logged in anywhere -- free to be added to a slot\n' ..
              'and called out.',

    -- THE FOUR TAB HEADERS (1.8.0). Each says what the tab is FOR rather than
    -- what it contains -- a player reading a tab bar is choosing, not
    -- browsing -- and each names where its numbers come from, because three
    -- of the four are only true while the squad is out.
    tabMain  = 'The squad itself: your five slots, every character on the account, and the\n' ..
               'buttons that register, call and dismiss them. Everything this window has\n' ..
               'always done is on this tab, and nothing moved off it.',
    tabStates= 'What is on each summoned member right now, drawn the way the game draws\n' ..
               'your own party: the status icon with the time left under it. The timers\n' ..
               'count down here between refreshes, and the list is re-read every fifteen\n' ..
               'seconds while anybody is out.',
    tabStats = 'Live HP, MP, TP, attributes and combat numbers for each member that is OUT.\n' ..
               'A trust has no /check and no status window, so this is the only place they\n' ..
               'exist -- and they are a SAMPLE, not a stream: how old is on each header.',
    tabExp   = 'Experience to the next level for every REGISTERED member, whether or not it\n' ..
               'is out -- the same numbers the Main tab states in words, as a bar. A\n' ..
               'character at its cap shows a full bar until a limit break raises it.',

    -- The States and Stats tabs when nobody is out. Not an error: it is the
    -- ordinary state of both tabs for a player who has not clicked Call squad
    -- yet, and the sentence has to say what to DO rather than what is
    -- missing.
    noneOut  = 'Nobody is out. Call squad on the Main tab summons every registered member,\n' ..
               'and what is on them appears here within fifteen seconds.',

    -- The Stats tab against a server that sends no `s|`/`k|` at all. Told
    -- apart from "nobody is out" deliberately: one is a thing the player can
    -- fix by clicking a button, and the other is not.
    noStats  = 'This server does not send member parameters yet. Everything else in this\n' ..
               'window still works; the numbers appear on their own once it does.',
};

-- The character table's four headers, in column order, each with the sentence
-- its header cell raises on hover. A table rather than four literals for the
-- reason TIPS is one: the harness can read it, and the header and the cells
-- under it cannot drift apart.
local CHAR_COLUMNS = {
    { label = 'Name',   tip = TIPS.nameCol  },
    { label = 'Jobs',   tip = TIPS.jobsCol  },
    { label = 'Status', tip = TIPS.stateCol },
    { label = '',       tip = TIPS.actCol   },
};

-- The one-line meanings of the tags a row can carry. Keyed by the tag itself
-- so the row does not have to decide twice what it is.
local TAG_TIPS = {
    ['(you)']       = 'The character you are playing right now.',
    ['[summoned]']  = 'Out right now as one of your trusts.',
    ['[logged in]'] = 'Logged in somewhere else on this account. A character cannot be in two\n' ..
                      'places at once, so Call squad will refuse this one until it logs out.',
};

-- The dropdown a click on an empty slot opens: every character that is
-- neither the one being played nor already in a slot. EVERY WIDGET ID
-- CARRIES THE CHARACTER ID, because two Selectables with the same label in
-- one combo would merge their click handling.
local function emptySlotCombo(slot)
    imgui.PushItemWidth(-1);

    -- The open flag first and the hover immediately after it, which is
    -- dwtoau's shape for every combo in the suite: once the popup is open,
    -- ImGui's "last item" is the popup's own window and a hover asked after
    -- EndCombo is asking about something else.
    local open = imgui.BeginCombo(SLOT_COMBO[slot], '(empty -- click to add)');

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.empty);
    end

    if (open) then
        local offered = 0;

        for _, member in ipairs(viewOf().ordered) do
            -- `pendingSlotOf` as well as `slot == 0`: a character whose
            -- registration is already in flight still reads slot 0 on the
            -- roster this frame is drawn from, and offering it a second slot
            -- would MOVE it out of the first (see pendingChars above).
            if (not isSelf(member) and member.slot == 0 and pendingSlotOf(member) == nil) then
                offered = offered + 1;

                if (imgui.Selectable(string.format('%s  %s##add_%d_%d',
                        member.name, member.jobsText, slot, member.charid))) then
                    assign(slot, member);
                end
            end
        end

        if (offered == 0) then
            -- THREE REASONS FOR AN EMPTY LIST AND THEY ARE NOT
            -- INTERCHANGEABLE (1.7.0): nobody has arrived yet, everybody is
            -- already registered, or the only ones left have a registration
            -- in flight. The old sentence stated the middle one for all
            -- three, and stated it to a player whose roster simply had not
            -- landed -- which reads as "you have no other characters".
            if (#viewOf().ordered == 0) then
                imgui.TextDisabled('The roster has not arrived yet.');
            else
                imgui.TextDisabled('Everybody else is already in the squad, or on the way into it.');
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();
end

--[[
* Buff display. Names come from the client's own resources -- the server
* sends ids, not strings, for the same reason dwbags' item records do: the
* client already owns the string table. The icon id is looked up first (it is
* the client status id), the server effect id second, and an id neither side
* can name still shows as something rather than vanishing.
--]]
local buffNames = {};

local function buffName(entry)
    local lookup = entry.icon ~= 0 and entry.icon or entry.id;

    if (buffNames[lookup] == nil) then
        local ok, name = pcall(function ()
            return AshitaCore:GetResourceManager():GetString('buffs.names', lookup);
        end);

        if (ok and name ~= nil and #name > 0) then
            buffNames[lookup] = name;
        else
            buffNames[lookup] = string.format('effect %d', entry.id);
        end
    end

    return buffNames[lookup];
end

-- "12:30" under an hour, "2h05" over it; -1 is an effect with no timer and
-- shows bare. The countdown runs client-side off the response's own arrival
-- stamp, so the numbers move between the 15-second refreshes.
local function buffPiece(entry, elapsed)
    if (entry.rem < 0) then
        return buffName(entry);
    end

    local seconds = math.max(entry.rem - math.floor(elapsed), 0);

    if (seconds >= 3600) then
        return string.format('%s %dh%02d', buffName(entry), math.floor(seconds / 3600), math.floor((seconds % 3600) / 60));
    end

    return string.format('%s %d:%02d', buffName(entry), math.floor(seconds / 60), seconds % 60);
end

local function buffTextOf(member)
    if (bit.band(member.flags, CHAR_LOCKED) == 0) then
        return nil;
    end

    local entry = state.buffs[member.charid];

    if (entry == nil or #entry.list == 0) then
        return nil;
    end

    --[[
        THE SENTENCE CHANGES WHEN A SECOND TICKS OVER AND AT NO OTHER TIME, so
        it is built once a second instead of sixty times (1.7.0). A squad of
        five carrying six effects each was paying thirty string.format calls,
        five table allocations and five concats every frame for text identical
        in 59 of every 60 of them.

        The stamp is the FLOORED second and the same value is handed to
        buffPiece, which floored it internally anyway -- so the text is
        byte-for-byte what it was before, and the countdown still moves.
        `entry.text` is cleared by the `b|` record that appends to the list,
        so a fresh answer replaces the sentence in the instant it lands rather
        than at the next tick.
    --]]
    local second = math.floor(os.clock() - entry.at);

    if (entry.text ~= nil and entry.textAt == second) then
        return entry.text;
    end

    local pieces = T{ };

    for _, buff in ipairs(entry.list) do
        pieces:append(buffPiece(buff, second));
    end

    entry.text   = pieces:concat(', ');
    entry.textAt = second;

    return entry.text;
end

--[[
* THE STATES TAB'S ICONS (1.8.0).
*
* The client owns the status icon bitmaps and the resource manager hands them
* out by INDEX -- which is the icon id the `b|` record already carries, the
* same number buffName looks the string up by. What comes back is a DAT
* bitmap and not a file, so the only way to reach imgui.Image with it is
* D3DXCreateTextureFromFileInMemoryEx over those bytes: dwbags' item-icon
* idiom, kept verbatim including its reasoning, and the same one two
* third-party addons (statustimers/HXUI, partybuffs) reached for
* independently.
*
* CACHED BY ICON ID, because a squad of five carrying six effects each is
* thirty draws a frame and creating a texture is not free -- and, more to the
* point, creating thirty of them a frame would leak thirty textures a frame.
* `gc_safe_release` hands back a texture that releases itself when Lua
* collects it, which is what makes dropping the table on unload a real free
* and not a wish.
*
* A FAILURE IS A REMEMBERED FAILURE. `false` is stored for an icon that could
* not be made -- an id the client has no bitmap for, a device that is not up
* yet -- so the miss costs one attempt and not one per frame forever. The
* caller draws the effect's NAME in that cell instead: this tab exists to say
* what is on a member, and an icon is how it says it, not what it says.
*
* AND THE HANDLE IS MEMOISED BESIDE THE TEXTURE (dwraid 1.12.0's note, the
* same defect one addon over): imgui.Image takes a plain number, and
* `tonumber(ffi.cast('uint32_t', texture))` allocates a cdata every time it is
* asked. Filled where the texture is created and dropped with it, so the two
* tables cannot disagree.
--]]
local statusIcons   = { };
local statusHandles = { };

-- Resolved on first use rather than at load: d3d8.get_device() before the
-- device exists answers nil, and a nil cached at load is cached forever.
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The client's own status ids run 0..0x3FF; 255 is the "no effect" filler the
-- party packet uses and is never a real icon. Both are the third-party
-- addons' own bounds, and a bad id here would be a create call over garbage.
local ICON_MAX = 0x3FF;

local function statusIconHandle(iconId)
    if (iconId == nil or iconId <= 0 or iconId == 255 or iconId > ICON_MAX) then
        return nil;
    end

    if (statusIcons[iconId] ~= nil) then
        return statusIcons[iconId] ~= false and statusHandles[iconId] or nil;
    end

    local dev = device();

    if (dev == nil) then
        -- NOT remembered as a failure: the device comes up once and this is
        -- the one miss that fixes itself.
        return nil;
    end

    local icon = AshitaCore:GetResourceManager():GetStatusIconByIndex(iconId);

    if (icon == nil or icon.Bitmap == nil or icon.ImageSize == 0) then
        statusIcons[iconId] = false;

        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, icon.Bitmap, icon.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        statusIcons[iconId] = false;

        return nil;
    end

    statusIcons[iconId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    -- Guarded rather than trusted (dwraid's note): a handle that came back as
    -- anything but a number reaches imgui.Image as a nil and takes the render
    -- pcall down sixty times a second, and falling back to the effect NAME
    -- costs nothing but a picture.
    local handle = tonumber(ffi.cast('uint32_t', statusIcons[iconId]));

    if (type(handle) ~= 'number') then
        statusIcons[iconId]   = false;
        statusHandles[iconId] = nil;

        return nil;
    end

    statusHandles[iconId] = handle;

    return handle;
end

-- Every texture this addon made, released. The tables are dropped rather than
-- each entry released by hand: `gc_safe_release` is what owns the release and
-- it fires when Lua collects the object, so dropping the last reference IS
-- the free -- and the collection is asked for here rather than waited for,
-- because an unload has no next frame to be lazy in.
local function releaseIcons()
    statusIcons   = { };
    statusHandles = { };

    collectgarbage('collect');
end

--[[
* THE RETAIL TIMER SPELLING (1.8.0), which is deliberately NOT buffPiece's.
*
* The Main tab's sentence says `Protect 2:00` because it is a SENTENCE and a
* colon-separated clock reads as one. Under an icon there is room for three
* characters and the player is not reading, they are glancing -- so this is
* the client's own spelling on its own party list: `2h` over an hour, `8m`
* over a minute, bare seconds under one, and NOTHING at all for an effect
* with no timer.
*
* An effect with no timer draws an empty cell rather than a dash or an
* infinity sign, which is what the client does: the absence of a number under
* an icon already means "this one is not counting down", and a mark invented
* for it would be one more thing to learn.
--]]
local function stateTimerOf(remaining)
    if (remaining == nil or remaining < 0) then
        return '';
    end

    local seconds = math.max(math.floor(remaining), 0);

    if (seconds >= 3600) then
        return string.format('%dh', math.floor(seconds / 3600));
    end

    if (seconds >= 60) then
        return string.format('%dm', math.floor(seconds / 60));
    end

    return string.format('%d', seconds);
end

-- The seconds left on one entry, counted down from the record's own arrival
-- stamp exactly as buffPiece does -- one clock for both spellings, so the
-- Main tab and the States tab can never disagree about the same effect.
local function stateSecondsOf(entry, elapsed)
    if (entry.rem < 0) then
        return -1;
    end

    return math.max(entry.rem - math.floor(elapsed), 0);
end

--[[
* WHICH PANEL GETS THE EXTRA WIDTH (1.7.0).
*
* The slot panel used to be a hard 410 and the character panel took whatever
* was left, so every pixel a player added by widening the window went to the
* table whose needs are BOUNDED -- four columns, three of them fixed -- while
* the slot rows, which carry a name plus jobs plus a tag plus an experience
* line plus a wrapped list of status effects, stayed exactly as cramped as
* they were. Reserved the other way round: the character panel keeps the width
* it actually needs -- MEASURED, see columnWidths below -- and the slot panel
* takes the rest.
*
* A negative child width is "available minus this", so the character panel
* ends up at the reserve minus one item spacing whatever the window is doing,
* and every pixel above the minimum is new and goes where the text is.
--]]

--[[
* LAYOUT IS MEASURED, NOT GUESSED (1.7.0, second pass; dwcraft's shape and its
* lesson -- "hand-tuned pixel widths are how `next rank test at 8` shipped cut
* off at `next rank te`").
*
* THE DEFECT THAT MADE THIS NECESSARY. The character table's Status column was
* 76 pixels. The widest thing it can say is `[logged in]` -- ELEVEN
* characters, exactly as many as the widest thing the Jobs column beside it
* can say (`WHM99/RDM49`), which was given 128. Two numbers for one length:
* whichever font the player is running, one of them is wrong, and the one that
* is wrong clips the tag that says WHY Call squad will refuse that character.
*
* So every fixed width in both tables, and the character panel's own reserve,
* is asked of the live font. MEASURED ONCE PER FONT and not once per frame:
* nothing in the answer can move except the font, so the font size is the
* cache key.
*
* MAX_LEVEL is 99 on this server (settings/default/main.lua), so a job pair is
* at most three letters, two digits, a slash and the same again; an FFXI name
* is at most fifteen characters; an account holds at most sixteen of them.
--]]
local JOBS_TEMPLATE    = 'WHM99/RDM99';
local NAME_TEMPLATE    = 'Wwwwwwwwwwwwwww';
local CAPTION_TEMPLATE = '-- 16 characters';

-- Everything the Status cell can ever say, at its longest.
local STATUS_TEMPLATES = { '[logged in]', '[summoned]', 'adding...', 'slot 5', '(you)' };

-- ImGui's default ScrollbarSize. The style field is not read for it: this
-- environment's binding is proven for the padding and spacing members the
-- suite already uses, and one unproven field access is a Lua error per frame.
local SCROLLBAR_WIDTH = 16;

local columnCache = { font = nil, widths = nil };

local function columnWidths()
    local font = imgui.GetFontSize();

    if (columnCache.font ~= font) then
        local style  = imgui.GetStyle();
        local status = 0;

        for _, text in ipairs(STATUS_TEMPLATES) do
            local width = imgui.CalcTextSize(text);

            if (width > status) then
                status = width;
            end
        end

        local jobs = imgui.CalcTextSize(JOBS_TEMPLATE);

        -- A SmallButton is its label plus one FramePadding.x each side --
        -- ImGui::SmallButton pushes a zero-HEIGHT frame padding and keeps the
        -- horizontal one, which is why this is not GetFrameHeight's business.
        local action = imgui.CalcTextSize('Remove') + style.FramePadding.x * 2;

        -- The States tab's icon square, spelled once because two of the
        -- widths below are built out of it and a second copy of the
        -- expression is a second place for it to drift.
        local iconSize = math.floor(font * 1.6 + 0.5);

        -- What the character panel's TABLE needs: four columns and the cell
        -- padding either side of each of them, a scroll bar, and the child's
        -- own padding.
        local tableNeed = jobs + status + action + imgui.CalcTextSize(NAME_TEMPLATE)
                        + style.CellPadding.x * 8
                        + SCROLLBAR_WIDTH
                        + style.WindowPadding.x * 2;

        -- ...and what its CAPTION LINE needs, which is a different number and
        -- the larger of the two in the default font: a title, a count, and
        -- the Copy and Sort buttons. A panel sized only to its columns clips
        -- its own header, which is the mistake this whole block is about.
        local captionNeed = imgui.CalcTextSize('Your characters')
                          + imgui.CalcTextSize(CAPTION_TEMPLATE)
                          + imgui.CalcTextSize('Copy') + style.FramePadding.x * 2
                          + imgui.CalcTextSize('Sort: level') + style.FramePadding.x * 2
                          + style.ItemSpacing.x * 3
                          + style.WindowPadding.x * 2;

        columnCache.font   = font;
        columnCache.widths = {
            jobs   = jobs,
            status = status,
            action = action,

            -- The slot number cell: '5.' and nothing else, ever.
            number = imgui.CalcTextSize('5.'),

            -- The character panel is the one that CANNOT grow when the player
            -- widens the window -- the slot panel takes all the slack -- so
            -- its width has to be right at every font rather than right at
            -- one. `+ 4` is the child's border and a pixel of slop.
            reserve = math.max(tableNeed, captionNeed) + 4,

            --[[
                THE THREE NEW TABS ARE MEASURED TOO (1.8.0), by the same rule
                and for the same reason -- a hand-tuned 20-pixel icon is
                exactly the `next rank te` defect one font size later.

                `icon` is the status icon's drawn square. A status icon's own
                bitmap is 24x24, but the number that matters is how it sits
                against the text UNDER it, so it is derived from the font
                rather than from the bitmap -- about one and a half line
                heights, which is the proportion the client's own party list
                draws them at, and which grows with a player's font instead of
                shrinking into it.

                `iconCell` is the whole cell including that text -- the widest
                thing the timer can ever say is three characters (`59m`,
                `24h`) -- and it is what the strip wraps against.
            --]]
            icon     = iconSize,
            iconCell = math.max(iconSize, imgui.CalcTextSize('00m')) + style.ItemSpacing.x,

            -- The Stats tab's label column: the widest row label it draws,
            -- indented under its section heading. `Ranged Atk` and
            -- `Ranged Acc` are the joint widest and are the same length; the
            -- two leading spaces are the indent the rows are drawn with.
            statLabel = imgui.CalcTextSize('  Ranged Acc') + style.CellPadding.x * 2,

            -- The Exp tab's member column: a 15-character name and a job pair
            -- on one line, which is what that cell draws. (The bar column
            -- stretches, so it needs no number of its own -- and must not
            -- have one, or a wide window would leave it short.)
            expName  = imgui.CalcTextSize(NAME_TEMPLATE .. ' ' .. JOBS_TEMPLATE)
                     + style.CellPadding.x * 2,
        };

        --[[
            AND THE WINDOW'S OWN FLOOR MOVES WITH THE FONT, for the same
            reason and as the other half of it: a reserve that grows inside a
            minimum that does not is a SLOT panel squeezed to nothing, which
            is the panel carrying the names, the experience lines and the
            wrapped buff text.

            NEVER BELOW TODAY'S 880x400, which is a considered number for the
            default font (the header block is about 225 pixels before either
            panel is drawn) and which every saved ini is already clamped up to.
            This can only raise it.

            The slot panel's own need is its two measured columns plus a member
            cell wide enough for the widest single line that cell ever draws --
            a fifteen-character name, a job pair and a tag, side by side.
        --]]
        local slotNeed = columnCache.widths.number + columnCache.widths.action
                       + imgui.CalcTextSize(NAME_TEMPLATE .. ' ' .. JOBS_TEMPLATE .. ' [logged in]')
                       + style.CellPadding.x * 6
                       + style.WindowPadding.x * 2;

        -- Five rows of controls (the buttons, the engage toggle, the follow
        -- slider, the alliance row, the level sync row), eleven lines of text
        -- (two captions, two section headings, the waiting line, the banner
        -- and the separators), and one row of panel underneath all of it.
        local rowH  = imgui.GetFrameHeightWithSpacing();
        local lineH = imgui.GetTextLineHeightWithSpacing();

        columnCache.widths.minWidth  = math.max(880,
            columnCache.widths.reserve + slotNeed + style.ItemSpacing.x + style.WindowPadding.x * 2 + 4);

        -- ROW SEVEN IS THE TAB BAR (1.8.0). It sits between the banner and
        -- the panels and it is a frame row like the buttons above it, so the
        -- floor owes it one -- otherwise every pixel the tab bar takes comes
        -- out of the panels, which is the squeeze this whole block exists to
        -- stop. At the default font the considered 880x400 still wins; in a
        -- large one it does not, which is the case that matters.
        columnCache.widths.minHeight = math.max(400, rowH * 7 + lineH * 11);
    end

    return columnCache.widths;
end

--[[
* The window's floor, and WHY IT IS A MUTABLE TABLE (1.7.0).
*
* It starts at the considered 880x400 -- the numbers chosen for the default
* font, which columnWidths never answers below -- and renderWindow writes the
* measured floor into it for the NEXT frame to apply. Next frame, and not this
* one, because SetNextWindowSizeConstraints has to be called BEFORE Begin and
* the measurement has to happen AFTER it: ImGui's font size is a property of
* the current window, so CalcTextSize asked between two windows is asked with
* no font at all -- and a cache keyed on that answer would thrash twice a
* frame, recomputing a dozen text measurements each time. One frame of lag on
* a font change nobody makes mid-session is invisible; a zero-width layout is
* not.
*
* Written in place rather than replaced: this is read sixty times a second.
--]]
local WINDOW_MIN = { 880, 400 };
local WINDOW_MAX = { 99999, 99999 };

local constraintsBroken = false;

local function squadPanel()
    local widths = columnWidths();

    -- NOTE: the third argument is ImGuiChildFlags, not a bool -- Ashita ships
    -- ImGui 1.90+, and a bool here raises a Lua error on every frame.
    imgui.BeginChild('##dwsquad_slots', { -widths.reserve, 0 }, ImGuiChildFlags_Borders);

    local view = viewOf();

    imgui.Text('Your squad');
    imgui.SameLine();
    imgui.TextDisabled(view.squadCaption);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.squadCap);
    end

    imgui.Separator();

    local slots = view.slots;

    if (imgui.BeginTable('##dwsquad_slot_table', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, widths.number, 0);
        --[[
            THE MEMBER COLUMN STRETCHES, and 1.7.0 is the third attempt at
            this number. It was 310, then 290 (2026-08-16) because at 310 the
            three columns plus the table's cell padding came to more than the
            child's 410 and the overflow was paid by the LAST column -- every
            Remove button drew clipped to 'Remov'. But 290 + 18 + 62 + three
            cells of padding is 394 against 392 of usable child width, so the
            same two pixels came off the same button; a fixed number that has
            to be re-derived every time the child or the style moves is the
            wrong shape for it.

            A stretch column takes what is left instead of claiming a width,
            which makes the button column unclippable by construction at every
            window size, saved inis included. Third argument 0 is the stretch
            WEIGHT, not a pixel width -- the dwah/dwbags idiom.
        --]]
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, widths.action, 0);

        for slot = 1, MAX_SLOTS do
            local member = slots[slot];

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(SLOT_LABELS[slot]);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format(
                    'Squad slot %d. The number is where this member sits in the party\n' ..
                    'and what !squad list calls it.', slot));
            end

            imgui.TableNextColumn();

            if (member ~= nil) then
                imgui.Text(member.name);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.member);
                end

                imgui.SameLine();
                imgui.TextDisabled(member.jobsText);

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.jobsCol);
                end

                local tag = member.tagText;

                if (tag ~= '') then
                    imgui.SameLine();
                    imgui.TextDisabled(tag);

                    if (TAG_TIPS[tag] ~= nil and imgui.IsItemHovered()) then
                        imgui.SetTooltip(TAG_TIPS[tag]);
                    end
                end

                -- Experience goes BELOW the name rather than beside it: the
                -- widest single line this cell already holds -- a
                -- 15-character name plus WHM71/RDM51 plus [logged in] -- is
                -- about 275 pixels, which is most of the cell at the window's
                -- default width. So it joins the buffs on the second line the
                -- cell is already shaped to carry, instead of becoming a
                -- fourth thing competing for the first.
                if (member.xpText ~= nil) then
                    imgui.TextDisabled(member.xpLabel);

                    if (member.xpTip ~= nil and imgui.IsItemHovered()) then
                        imgui.SetTooltip(member.xpTip);
                    end
                end

                -- What is on them right now, wrapped inside the column.
                -- PushTextWrapPos(0) wraps at the available width, which in
                -- a table cell is the cell.
                local buffText = buffTextOf(member);

                if (buffText ~= nil) then
                    imgui.PushTextWrapPos(0);
                    imgui.TextDisabled(buffText);
                    imgui.PopTextWrapPos();

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(TIPS.buffs);
                    end
                end
            else
                -- A slot with a registration on its way into it is NOT an
                -- empty slot, and drawing the dropdown over one let a second
                -- pick replace the first (see pendingSlots). The row says
                -- whose it is; the Remove column stays blank, because there
                -- is nothing registered here yet to remove.
                local pending = pendingInSlot(slot);

                if (pending ~= nil) then
                    imgui.TextDisabled(pending.label);

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(pending.tip);
                    end
                else
                    emptySlotCombo(slot);
                end
            end

            imgui.TableNextColumn();

            if (member ~= nil) then
                if (imgui.SmallButton(SLOT_REMOVE[slot])) then
                    unassign(slot, member);
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format(
                        'Un-register %s from slot %d. It stops being part of the squad;\n' ..
                        'nothing on the character itself changes.', member.name, slot));
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

--[[
* The roster as plain text, for the clipboard (1.7.0). Built on the click and
* never before it -- nothing about this belongs in a render pass.
*
* It says exactly what the panel says and nothing the panel does not: the
* window is where a player's whole account sits in one list, and "what are
* your alts" is a question players ask each other constantly. No header line
* and no decoration, because the thing being pasted is usually one line of a
* linkshell message.
--]]
local function rosterText(view)
    local lines = T{ };

    for _, member in ipairs(view.ordered) do
        local where = '';

        if (member.slot > 0) then
            where = string.format('  %s', SLOT_TEXT[member.slot]);
        elseif (member.tagText ~= '') then
            where = string.format('  %s', member.tagText);
        end

        lines:append(string.format('%-15s %-12s %s%s',
            member.name, member.jobsText, member.xpText or '', where));
    end

    return lines:concat('\n');
end

local function charactersPanel()
    local widths = columnWidths();

    imgui.BeginChild('##dwsquad_chars', { 0, 0 }, ImGuiChildFlags_Borders);

    local view = viewOf();

    imgui.Text('Your characters');
    imgui.SameLine();
    imgui.TextDisabled(view.charsCaption);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.charsCap);
    end

    imgui.SameLine();

    if (imgui.SmallButton('Copy##dwsquad_copy')) then
        -- PCALL'D, the dwtoau/dwwarehouse shape: SetClipboardText is in
        -- Ashita's SDK annotations, but a player's install is frozen at
        -- whatever build they first installed, and calling a missing binding
        -- inside the render pcall closes the whole window over a button that
        -- was only ever a courtesy. A refusal is said rather than a copy
        -- claimed.
        if (pcall(imgui.SetClipboardText, rosterText(view))) then
            setStatus('Roster copied to the clipboard.', false);
        else
            setStatus('This Ashita build has no clipboard call -- nothing was copied.', true);
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.copy);
    end

    imgui.SameLine();

    -- THE SORT CYCLE (1.7.0). One button rather than four, because four
    -- would not fit on this line and a combo would open a popup over the
    -- table it re-orders. The label is fixed-width so pressing it moves
    -- nothing; the current mode is what it reads.
    local sorting = SORTS[sortAt];

    if (imgui.SmallButton(sorting.label)) then
        sortAt = (sortAt % #SORTS) + 1;

        -- The order is not part of the model, so nothing bumped the model
        -- revision -- the view cache is keyed on the sort too, and reads the
        -- new value on its own next call. Nothing to invalidate by hand.
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(sorting.tip);
    end

    imgui.Separator();

    local empty = firstEmptySlot();

    if (imgui.BeginTable('##dwsquad_char_table', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY), { -1, -1 })) then
        --[[
            THE NAME COLUMN STRETCHES (1.7.0). Every column here was fixed and
            they came to 376 pixels plus four cells of padding plus the scroll
            bar -- about 440 -- against the ~416 this panel actually gets at
            the window's old 850 default. The window carries
            ImGuiWindowFlags_NoScrollbar so the overflow could not be scrolled
            away; it was clipped, and with everything fixed the LAST column
            pays, which is the Add/Remove button. (The same defect the slot
            table's own 2026-08-16 note describes, in the panel beside it,
            never fixed there.) A stretch column absorbs the difference
            instead, at every window width and for every saved ini.
        --]]
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        -- Both of these were hand-tuned numbers, 128 and 76, for two strings
        -- of the SAME eleven characters -- see columnWidths above for why one
        -- of them had to be wrong and which tag it was clipping.
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, widths.jobs, 0);
        imgui.TableSetupColumn('Status', ImGuiTableColumnFlags_WidthFixed, widths.status, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, widths.action, 0);
        imgui.TableSetupScrollFreeze(0, 1);

        --[[
            THE HEADER ROW IS DRAWN BY HAND so each column can say what it
            means on hover (dwleaderboard's note, 2026-09-05, and the same
            reason): `TableHeadersRow()` draws all four headers as ONE item,
            so `IsItemHovered` afterwards is asking about the row and not
            about a column, and there is nothing to attach a per-column
            sentence to. The cells underneath carry these sentences already --
            but the header is the thing a player points at when they want to
            know what a column IS, and it was the one part of this table that
            answered nothing.

            The nameless action column still gets a header cell: without it
            the frozen row is short of the table's width and the freeze line
            stops in mid-air.
        --]]
        imgui.TableNextRow(ImGuiTableRowFlags_Headers, 0);

        for _, column in ipairs(CHAR_COLUMNS) do
            imgui.TableNextColumn();
            imgui.TableHeader(column.label);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(column.tip);
            end
        end

        for _, member in ipairs(view.ordered) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(member.name);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.nameCol);
            end

            imgui.TableNextColumn();
            imgui.TextDisabled(member.jobsText);

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.jobsCol);
            end

            -- A SECOND LINE INSIDE THE SAME CELL RATHER THAN A FIFTH COLUMN.
            -- There is no slack across this table to spend on one, and a row
            -- that grows taller costs nobody a clipped button; this panel
            -- already scrolls vertically.
            if (member.xpText ~= nil) then
                imgui.TextDisabled(member.xpText);

                if (member.xpTip ~= nil and imgui.IsItemHovered()) then
                    imgui.SetTooltip(member.xpTip);
                end
            end

            imgui.TableNextColumn();

            local pendingAt = pendingSlotOf(member);

            if (member.slot > 0) then
                imgui.TextDisabled(SLOT_TEXT[member.slot]);

                if (imgui.IsItemHovered()) then
                    -- A slot held by the character being PLAYED is a slot that
                    -- does nothing, and the reason is worth a sentence: a
                    -- character cannot be in two places at once, so Call squad
                    -- refuses it exactly as it refuses one logged in
                    -- elsewhere. Reachable by registering a character on one
                    -- session and then logging in as it.
                    imgui.SetTooltip(isSelf(member) and TIPS.selfSlot or TIPS.stateCol);
                end
            elseif (pendingAt ~= nil) then
                imgui.TextDisabled('adding...');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format(
                        '%s is being registered into slot %d. The command has gone out and\n' ..
                        'the server has not answered yet -- adding it again would MOVE it\n' ..
                        'rather than add it twice, so the button waits.', member.name, pendingAt));
                end
            elseif (member.tagText ~= '') then
                imgui.TextDisabled(member.tagText);

                if (TAG_TIPS[member.tagText] ~= nil and imgui.IsItemHovered()) then
                    imgui.SetTooltip(TAG_TIPS[member.tagText]);
                end
            else
                -- A character in no slot, not logged in and not the one being
                -- played drew an EMPTY cell with no hover on it -- the only
                -- row in this table that said nothing at all, in a column
                -- headed Status. It is a real state and a useful one (this
                -- character is free), so it gets a mark and a sentence like
                -- every other. The dash is the character panel's own spelling
                -- for "nothing here", the same one the action column uses.
                imgui.TextDisabled('--');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.idle);
                end
            end

            imgui.TableNextColumn();

            --[[
                A REGISTERED CHARACTER ALWAYS OFFERS REMOVE, INCLUDING THE ONE
                YOU ARE PLAYING (1.7.0). `isSelf` was tested FIRST, so a
                character that was registered on another session and then
                logged in as drew a dash and a tooltip about not being able to
                ADD it -- while its own Status cell beside it said `slot 3`.
                The row stated a membership and offered no way to end it, and
                the slot panel two hundred pixels to the left offered Remove
                for the very same slot. Registration is the question this
                column answers; who is logged in is the Status column's.
            --]]
            if (member.slot > 0) then
                if (imgui.SmallButton(member.removeId)) then
                    unassign(member.slot, member);
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format(
                        'Un-register %s from slot %d. It stops being part of the squad;\n' ..
                        'nothing on the character itself changes.', member.name, member.slot));
                end
            elseif (isSelf(member)) then
                -- The character being played cannot be its own trust; the
                -- server refuses it, so the button is not offered -- and the
                -- hover says which of the two reasons this is.
                imgui.TextDisabled('--');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(TIPS.self);
                end
            elseif (pendingAt ~= nil) then
                -- Deliberately not a greyed button: a button that cannot be
                -- pressed for a second and a half reads as a broken one, and
                -- the Status cell beside this already says what is happening.
                imgui.TextDisabled('');
            elseif (empty ~= nil) then
                if (imgui.SmallButton(member.addId)) then
                    assign(empty, member);
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format(
                        'Register %s in squad slot %d -- the first one free.\n' ..
                        'Call squad summons it from there.', member.name, empty));
                end
            else
                imgui.TextDisabled('full');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(anyPendingSlot() and TIPS.fullWait or TIPS.full);
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end


--[[
* THE THREE NEW TABS (1.8.0). All three share one rule with the two panels
* above them and it is worth stating once here rather than three times below:
* THEY RENDER WHAT THE SERVER SAID AND NOTHING ELSE. No stat is derived, no
* timer is extrapolated past its own record, and a member the server has not
* described draws a sentence saying so rather than a row of zeroes. The
* level-sync row's rule -- a displayed FACT that goes stale is a lie, and a
* much worse one than a blank -- applies to every number on these tabs.
--]]

-- Just the members standing beside you right now. Every one of these tabs but
-- Exp is about live state, and live state exists only for a summoned member.
local function summonedOf(view)
    local out = T{ };

    for _, member in ipairs(view.ordered) do
        if (bit.band(member.flags, CHAR_LOCKED) ~= 0) then
            out:append(member);
        end
    end

    return out;
end

-- ImGui wants a size as a table and the strip draws one per icon per frame,
-- so the square is memoised by its pixel size (dwraid's sizeVec, same reason:
-- thirty allocations a frame for two numbers that move only with the font).
local iconSizes = { };

local function iconVec(size)
    local vec = iconSizes[size];

    if (vec == nil) then
        vec = { size, size };
        iconSizes[size] = vec;
    end

    return vec;
end

--[[
* One icon cell: the picture with the time left under it, centred.
*
* THE FALLBACK IS THE POINT. An icon that could not be turned into a texture
* -- an id the client has no bitmap for, a device that has gone away -- draws
* the effect's NAME in that cell instead. This tab exists to say what is on a
* member; the icon is how it says it, not what it says, and a blank square
* would turn a missing picture into a missing FACT.
--]]
local function stateCell(entry, seconds, widths)
    local handle = statusIconHandle(entry.icon);
    local timer  = stateTimerOf(seconds);
    local width;

    imgui.BeginGroup();

    if (handle ~= nil) then
        imgui.Image(handle, iconVec(widths.icon));
        width = widths.icon;
    else
        local name = buffName(entry);

        imgui.TextDisabled(name);
        width = imgui.CalcTextSize(name);
    end

    -- The timer under the picture, centred on it: the client's own layout,
    -- and the reason it is worth the two calls is that a left-aligned `8m`
    -- under a 20-pixel square reads as belonging to the icon to its left.
    local textWidth = imgui.CalcTextSize(timer);

    if (textWidth < width) then
        imgui.SetCursorPosX(imgui.GetCursorPosX() + (width - textWidth) / 2);
    end

    -- Drawn even when empty (an effect with no timer): the blank line is what
    -- keeps every cell in the strip the same height, so the row below it does
    -- not step up under half the icons.
    imgui.TextDisabled(timer);

    imgui.EndGroup();

    return math.max(width, textWidth);
end

--[[
* THE STATES TAB. One row per summoned member -- name, jobs -- and under it a
* horizontal strip of the client's own status icons with the time left under
* each, which is the shape every FFXI player already reads on their own party
* list.
*
* THE STRIP WRAPS ON MEASURED WIDTH rather than on a count. A count would be
* right at one font and one window width and wrong at every other, and this
* window is resizable; the accumulator below asks the region how much room is
* left and starts a new line when the next cell would not fit. Fallback cells
* are as wide as the effect's name, which is exactly why the wrap cannot be a
* grid.
--]]
local function statesPanel()
    local widths = columnWidths();
    local view   = viewOf();
    local out    = summonedOf(view);

    imgui.BeginChild('##dwsquad_states', { 0, 0 }, ImGuiChildFlags_Borders);

    if (#out == 0) then
        imgui.TextDisabled('Nobody is out -- call the squad to see what is on them.');
        tip(TIPS.noneOut);

        imgui.EndChild();

        return;
    end

    for _, member in ipairs(out) do
        imgui.Text(member.name);
        tip(TIPS.member);

        imgui.SameLine();
        imgui.TextDisabled(member.jobsText);
        tip(TIPS.jobsCol);

        local entry = state.buffs[member.charid];

        if (entry == nil or #entry.list == 0) then
            -- A member out with nothing on it is a real and useful answer, and
            -- it is NOT the same as a member the poll has not reached yet --
            -- the server sends a bare `b|` for the first and no record at all
            -- for the second.
            imgui.TextDisabled(entry == nil and '   waiting for the next read...' or '   nothing');
        else
            -- One clock for the whole strip, floored to the second exactly as
            -- the Main tab's sentence is: the two spellings of the same
            -- countdown must never disagree by a second.
            local elapsed = math.floor(os.clock() - entry.at);
            local avail   = imgui.GetContentRegionAvail();
            local used    = 0;

            for _, buff in ipairs(entry.list) do
                local seconds = stateSecondsOf(buff, elapsed);

                -- The wrap: a cell that would not fit starts the next line.
                -- `widths.iconCell` is the measured cell, which is the right
                -- guess for the icon case and a floor for the fallback one.
                if (used > 0 and (used + widths.iconCell) > avail) then
                    used = 0;
                elseif (used > 0) then
                    imgui.SameLine();
                end

                local drawn = stateCell(buff, seconds, widths);

                -- THE HOVER IS THE NAME AND THE EXACT TIME, because the cell
                -- itself is deliberately three characters: `8m` is what a
                -- glance needs and `Protect -- 8:04 left` is what a decision
                -- needs, and neither one can be the other.
                if (imgui.IsItemHovered()) then
                    if (seconds < 0) then
                        imgui.SetTooltip(string.format('%s -- no timer on this one.', buffName(buff)));
                    else
                        imgui.SetTooltip(string.format('%s -- %d:%02d left.',
                            buffName(buff), math.floor(seconds / 60), seconds % 60));
                    end
                end

                used = used + drawn + widths.iconCell - widths.icon;
            end
        end

        imgui.Separator();
    end

    imgui.EndChild();
end

--[[
* THE STATS TAB, and the layout question the owner left open: a column per
* member, or a block of rows per member?
*
* ONE COLUMN PER MEMBER, ALWAYS, INCLUDING WHEN THERE IS ONLY ONE. The
* question this tab is open to answer is comparative -- who is carrying the
* party, which of these two alts should hold the front -- and a comparison is
* what a shared row of labels down the left makes possible: STR is on one
* line and every member's STR is on it. Rows-per-member would put a member's
* Attack twenty lines below its HP and force the player to hold five numbers
* in their head to compare one. The other half of the answer is that a layout
* which changes SHAPE with the number of members is one the player has to
* re-learn every time they call a different squad; this one is learned once.
*
* The squad is at most five, so five value columns plus a label is a table
* that fits the panel at every window size this window allows.
--]]
local STAT_SECTIONS = {
    {
        title = 'Vitals',
        tip   = 'Hit points, magic points and the TP the member has banked toward its next\n' ..
                'weapon skill. A member at low HP is one the squad is about to lose.',
        rows  = {
            { label = 'HP',  pair = { 'hp', 'hpmax' } },
            { label = 'MP',  pair = { 'mp', 'mpmax' } },
            { label = 'TP',  one  = 'tp' },
        },
    },
    {
        title = 'Attributes',
        tip   = 'The seven base attributes. A squad member\'s are a live player\'s of the\n' ..
                'same race, job, subjob, level and gear -- that parity is a server rule and\n' ..
                'not a coincidence, which is why these are worth reading.',
        rows  = {
            { label = 'STR', one = 'str' },
            { label = 'DEX', one = 'dex' },
            { label = 'VIT', one = 'vit' },
            { label = 'AGI', one = 'agi' },
            { label = 'INT', one = 'int' },
            { label = 'MND', one = 'mnd' },
            { label = 'CHR', one = 'chr' },
        },
    },
    {
        title = 'Combat',
        tip   = 'What the member swings and what it takes. Ranged Atk and Ranged Acc are\n' ..
                'meaningless without a ranged weapon equipped and read as its melee\n' ..
                'numbers would if it had none.',
        rows  = {
            { label = 'Attack',     one = 'att'  },
            { label = 'Defense',    one = 'def'  },
            { label = 'Accuracy',   one = 'acc'  },
            { label = 'Evasion',    one = 'eva'  },
            { label = 'Ranged Atk', one = 'ratt' },
            { label = 'Ranged Acc', one = 'racc' },
        },
    },
    {
        title = 'Magic',
        tip   = 'Magic attack and accuracy, and what the member resists with. A mage\n' ..
                'member with low M.Acc is one whose spells are landing for less than the\n' ..
                'spell says.\n' ..
                'These four are the member\'s MODIFIER TOTALS -- gear, buffs and traits\n' ..
                'added up (/checkparam has no line for them) -- not a computed value,\n' ..
                'because the engine keeps none to ask.',
        rows  = {
            { label = 'M.Atk', one = 'matt' },
            { label = 'M.Acc', one = 'macc' },
            { label = 'M.Def', one = 'mdef' },
            { label = 'M.Eva', one = 'meva' },
        },
    },
};

--[[
* THE CELLS OF ONE MEMBER, FORMATTED ONCE PER SAMPLE (1.8.0).
*
* Twenty-two numbers times five members is a hundred and ten string.formats a
* frame for text that changes once every fifteen seconds, which is the exact
* shape viewOf and the buff sentence were both rewritten to remove. The cache
* hangs off the ENTRY, and a fresh `buffs` envelope builds fresh entry tables
* -- so there is nothing to invalidate and nothing that can go stale.
--]]
local function statCellsOf(entry)
    if (entry.cells ~= nil) then
        return entry.cells;
    end

    local cells = { };

    for _, section in ipairs(STAT_SECTIONS) do
        for _, row in ipairs(section.rows) do
            if (row.pair ~= nil) then
                cells[row.label] = string.format('%d / %d',
                    entry[row.pair[1]] or 0, entry[row.pair[2]] or 0);
            else
                cells[row.label] = string.format('%d', entry[row.one] or 0);
            end
        end
    end

    entry.cells = cells;

    return cells;
end

local function statsPanel()
    local widths = columnWidths();
    local view   = viewOf();
    local out    = summonedOf(view);

    imgui.BeginChild('##dwsquad_stats', { 0, 0 }, ImGuiChildFlags_Borders);

    if (#out == 0) then
        imgui.TextDisabled('Call the squad to see live stats.');
        tip(TIPS.noneOut);

        imgui.EndChild();

        return;
    end

    -- Every member out, and not one of them described. That is a server
    -- without the parameter records rather than a squad without numbers, and
    -- the two are worth telling apart: one is fixed by a deploy and the other
    -- by a button.
    local described = 0;

    for _, member in ipairs(out) do
        if (state.stats[member.charid] ~= nil) then
            described = described + 1;
        end
    end

    if (described == 0) then
        imgui.TextDisabled('This server does not send member parameters yet.');
        tip(TIPS.noStats);

        imgui.EndChild();

        return;
    end

    if (imgui.BeginTable('##dwsquad_stat_table', #out + 1,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY),
            { -1, -1 })) then
        -- The label column is fixed and every member column stretches: the
        -- labels are a known set of strings and the numbers are what a player
        -- widening this window is asking for more room for.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, widths.statLabel, 0);

        for _, member in ipairs(out) do
            imgui.TableSetupColumn(member.name, ImGuiTableColumnFlags_WidthStretch, 0, 0);
        end

        imgui.TableSetupScrollFreeze(1, 1);

        -- The header row by hand, so each member's column can raise its own
        -- sentence -- TableHeadersRow draws the whole row as ONE item and
        -- there is nothing to attach a per-column hover to (the character
        -- table's own note, same reason).
        imgui.TableNextRow(ImGuiTableRowFlags_Headers, 0);
        imgui.TableNextColumn();
        imgui.TableHeader('');

        for _, member in ipairs(out) do
            imgui.TableNextColumn();
            imgui.TableHeader(member.name);

            if (imgui.IsItemHovered()) then
                local entry = state.stats[member.charid];

                if (entry == nil) then
                    imgui.SetTooltip(string.format(
                        '%s is out, but the server has not described it yet.\nThe read runs every fifteen seconds.',
                        member.name));
                else
                    -- THE AGE, and it is the whole reason the record carries a
                    -- stamp. These numbers are a SAMPLE: HP moves every second
                    -- of a fight and this window is told every fifteen. Saying
                    -- how old they are is the difference between a reading and
                    -- a claim.
                    imgui.SetTooltip(string.format('%s %s -- as of %d s ago.',
                        member.name, member.jobsText,
                        math.floor(os.clock() - (entry.at or os.clock()))));
                end
            end
        end

        for _, section in ipairs(STAT_SECTIONS) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(section.title);
            tip(section.tip);

            for _, row in ipairs(section.rows) do
                imgui.TableNextRow();
                imgui.TableNextColumn();

                -- Indented, so the section heading reads as a heading rather
                -- than as another row with a blank value.
                imgui.TextDisabled('  ' .. row.label);
                tip(section.tip);

                for _, member in ipairs(out) do
                    imgui.TableNextColumn();

                    local entry = state.stats[member.charid];

                    if (entry == nil) then
                        -- The dash is this window's own spelling for "nothing
                        -- here" (the character table's idle cell), and it is
                        -- what a member the poll has not described yet gets --
                        -- never a 0, which is a number and would be read as one.
                        imgui.TextDisabled('--');
                    else
                        imgui.Text(statCellsOf(entry)[row.label]);
                    end
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

--[[
* THE EXP TAB. A bar per character, for EVERY character on the account and not
* only the five that are registered -- which is a deliberate superset of what
* was asked for, and the reason is that the question this tab answers is "who
* should I bring next", which is asked about the ones that are NOT in the
* squad. The roster carries exp/next/xflags for all sixteen; restricting the
* tab to slot-holders would make it a strictly smaller view of a cell the Main
* tab already draws.
*
* The order is the Sort button's, shared with the character panel, so the two
* lists never disagree about where a character is.
--]]
-- The bar's size, spelled once. A negative width is "available minus this",
-- so one table serves every row at every window width -- and the binding
-- reads it rather than keeping it, which is what makes a shared one safe.
-- Sixteen characters is sixteen allocations a frame otherwise, for two
-- numbers that never change (iconVec's note, one panel over).
local BAR_SIZE = { -1, 0 };

local function expPanel()
    local widths = columnWidths();
    local view   = viewOf();

    imgui.BeginChild('##dwsquad_exp', { 0, 0 }, ImGuiChildFlags_Borders);

    if (#view.ordered == 0) then
        imgui.TextDisabled('The roster has not arrived yet.');

        imgui.EndChild();

        return;
    end

    if (imgui.BeginTable('##dwsquad_exp_table', 2,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY),
            { -1, -1 })) then
        imgui.TableSetupColumn('Character', ImGuiTableColumnFlags_WidthFixed, widths.expName, 0);
        imgui.TableSetupColumn('To the next level', ImGuiTableColumnFlags_WidthStretch, 0, 0);
        imgui.TableSetupScrollFreeze(0, 1);

        imgui.TableNextRow(ImGuiTableRowFlags_Headers, 0);
        imgui.TableNextColumn();
        imgui.TableHeader('Character');
        tip(TIPS.nameCol);
        imgui.TableNextColumn();
        imgui.TableHeader('To the next level');
        tip(TIPS.tabExp);

        for _, member in ipairs(view.ordered) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(member.name);
            tip(TIPS.nameCol);

            imgui.SameLine();
            imgui.TextDisabled(member.jobsText);
            tip(TIPS.jobsCol);

            imgui.TableNextColumn();

            if (member.xpFrac ~= nil) then
                -- A negative width is "available minus this", so the bar fills
                -- the column at every window width without a number in here
                -- that has to be re-derived when the column moves.
                imgui.ProgressBar(member.xpFrac, BAR_SIZE, member.xpOverlay);

                if (member.xpTip ~= nil and imgui.IsItemHovered()) then
                    imgui.SetTooltip(member.xpTip);
                end
            elseif (member.xpOverlay ~= nil) then
                -- Merit mode: no bar, because the bar would be frozen wherever
                -- it happened to stand, and a frozen bar is a lie a sentence
                -- is not.
                imgui.TextDisabled(member.xpOverlay);

                if (member.xpTip ~= nil and imgui.IsItemHovered()) then
                    imgui.SetTooltip(member.xpTip);
                end
            else
                -- No experience tail: a server from before it, or a character
                -- outside the exp table's 1..99 range. The Main tab's cell
                -- draws nothing for the same reason; this says so out loud,
                -- because a blank row in a tab about experience reads as a
                -- character with none.
                imgui.TextDisabled('--');

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('No experience figures for this character. An older server sends none,\n' ..
                        'and a character outside the experience table\'s range has none to send.');
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

--[[
* The follow distance row (1.6.0): a slider in yalms between the server's
* own ends, the stock mark named beside it, and a Default button while
* something is set. Dragging edits the holder only; the typed `!trustfollow`
* line goes out once the slider has rested, snapped to half a yalm (the
* resolution the command speaks), and only when it differs from what the
* server said -- so a drag that lands where it started sends nothing.
--]]
local function followTenthsOf(yalms)
    -- To tenths -- the server's own unit, and since 1.6.1 its floor is a
    -- tenth (0.1 yalms), so nothing rounds to half yalms any more.
    return math.floor(yalms * 10 + 0.5);
end

local function followRow()
    local follow = state.follow;

    if (followEdited == nil) then
        followUi[1] = (follow.tenths > 0 and follow.tenths or follow.stock) / 10;
    end

    imgui.Text('Trusts follow at');
    imgui.SameLine();
    imgui.PushItemWidth(180);

    if (imgui.SliderFloat('##dwsquad_follow', followUi, follow.min / 10, follow.max / 10, '%.1f yalms')) then
        followEdited = os.clock();
    end

    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(string.format(
            'How close each trust walks behind the one in front of it -- the first behind you, the rest behind each other.\n' ..
            'Stock is %.1f yalms. Takes effect on their next step -- no dismiss, no re-call.\n' ..
            'Same as typing !trustfollow <yalms>.', follow.stock / 10));
    end

    imgui.SameLine();

    if (follow.tenths > 0) then
        if (imgui.SmallButton('Default##dwsquad_follow_default')) then
            followEdited  = nil;
            follow.tenths = 0;

            issueLatest('!trustfollow', '!trustfollow default');

            requested['who'] = nil;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Put the distance back to the server\'s stock %.1f yalms --\n' ..
                'same as typing !trustfollow default.', follow.stock / 10));
        end
    else
        imgui.TextDisabled('(stock)');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(string.format(
                'Nothing is set: your trusts are walking at the server\'s own %.1f yalms.',
                follow.stock / 10));
        end
    end

    -- The slider has rested: one line, if it moved anywhere.
    if (followEdited ~= nil and (os.clock() - followEdited) >= FOLLOW_SETTLE) then
        followEdited = nil;

        local tenths = followTenthsOf(followUi[1]);

        if (tenths < follow.min) then
            tenths = follow.min;
        elseif (tenths > follow.max) then
            tenths = follow.max;
        end

        if (tenths ~= follow.tenths and not (follow.tenths == 0 and tenths == follow.stock)) then
            -- Optimistic, like the engage toggle; the roster re-ask below
            -- brings back the server's own `f|` as the settled truth.
            follow.tenths = tenths;

            -- SUPERSEDING, not queueing (1.7.0): the settle fires every half
            -- second and the queue drains one line every 1.2, so a player
            -- hunting for the distance they wanted was queueing two lines for
            -- every one that could go out -- and every one of them landed,
            -- in order, with the squad re-arranging itself the whole way,
            -- long after they had stopped touching the slider.
            issueLatest('!trustfollow', string.format('!trustfollow %.1f', tenths / 10));

            requested['who'] = nil;
        end
    end
end

--[[
* The two name-box senders. HOISTED OUT OF THE RENDER (1.7.0): they were
* `local function`s inside the alliance block, so two closures were allocated
* on every frame the block was drawn -- which is every frame, for every player
* whose server has the group command lane. Nothing in either one closes over
* anything the render pass owns; they read the file-level name buffers.
--]]
local function sendForm()
    local target = allyName[1]:gsub('^%s+', ''):gsub('%s+$', '');

    if (target == '') then
        setStatus('Type the name of the other party\'s leader, then Form.', true);

        return;
    end

    if (issue(string.format('!pally %s', target))) then
        setStatus(string.format('Inviting %s\'s party into an alliance...', target), false);
    end
end

local function sendSync()
    local target = syncName[1]:gsub('^%s+', ''):gsub('%s+$', '');

    if (target == '') then
        -- Bare !alliancesync is the status question. Answering it in chat
        -- beats a status line here that could go stale.
        if (issue('!alliancesync')) then
            setStatus('Asking what the alliance is synced to...', false);
        end

        return;
    end

    if (issue(string.format('!alliancesync %s', target))) then
        setStatus(string.format('Syncing the alliance to %s...', target), false);
    end
end

local function renderWindow()
    -- The floor for the NEXT frame's constraints call, measured here because
    -- here is inside the window and CalcTextSize needs a font (see
    -- WINDOW_MIN). columnWidths answers from its cache on every frame but the
    -- one after a font change.
    local widths = columnWidths();

    WINDOW_MIN[1] = widths.minWidth;
    WINDOW_MIN[2] = widths.minHeight;

    if (imgui.Button('Call squad')) then
        -- The literal typed command: its narrative -- who answered, who was
        -- refused and why -- belongs in the chat log. The outgoing watcher
        -- below sees the line and refreshes the roster behind it.
        if (issue('!squad call')) then
            setStatus('Calling the squad...', false);
        end
    end

    if (imgui.IsItemHovered()) then
        --[[
            AND WHETHER IT WOULD DO ANYTHING (1.7.0). Neither of these buttons
            is greyed and neither should be -- the server owns the gate and a
            greyed button here is a courtesy, never the authority -- but a
            player who clicks Call with an empty squad, or Dismiss with
            nothing out, gets a refusal in the chat log for a reason the
            window already knew. Said here rather than by disabling the
            button, and built ON HOVER: the counts come from the view, which
            is rebuilt once per roster, but the sentence is only interesting
            to somebody already asking.
        --]]
        local view = viewOf();

        if (view.filled == 0) then
            imgui.SetTooltip(TIPS.call .. '\n\nNothing is registered right now, so this would summon nobody.');
        else
            imgui.SetTooltip(TIPS.call);
        end
    end

    imgui.SameLine();

    if (imgui.Button('Dismiss')) then
        if (issue('!squad dismiss')) then
            setStatus('Dismissing...', false);
        end
    end

    if (imgui.IsItemHovered()) then
        local view = viewOf();

        if (view.summoned == 0) then
            imgui.SetTooltip(TIPS.dismiss .. '\n\nNobody is out right now, so this would send nobody home.');
        else
            imgui.SetTooltip(TIPS.dismiss);
        end
    end

    imgui.SameLine();

    if (imgui.Button('Refresh')) then
        refresh();

        -- A REFRESH IS A RE-PROBE, including of the version verdict. `refused`
        -- is a latch over "this server answered in a layout this addon cannot
        -- read", and a deploy can move underneath a running client -- which is
        -- why the zone line clears it too. Here it is the player asking, which
        -- is the strongest reason there is. If the server is still mismatched
        -- the banner is back one round trip later, at the cost of one command.
        state.refused = false;

        -- And the standing banner goes with it: it describes the LAST
        -- attempt, and leaving it up over a fresh ask is the same lie the
        -- answer clock tells when it overwrites a refusal.
        if (state.statusStick) then
            setStatus('');
        end
    end

    if (imgui.IsItemHovered()) then
        -- Built HERE and not per frame: the age is only interesting to
        -- somebody already asking about it, and this is the only honest
        -- answer to "how old is what I am looking at".
        if (state.rosterAt ~= nil) then
            imgui.SetTooltip(string.format('%s\n\nThe roster on screen answered %d seconds ago.',
                TIPS.refresh, math.floor(os.clock() - state.rosterAt)));
        else
            imgui.SetTooltip(TIPS.refresh);
        end
    end

    imgui.SameLine();

    -- A throttled queue has to look like progress rather than like nothing
    -- happening.
    local waiting = #queue;

    if (waiting > 0) then
        imgui.TextDisabled(QUEUE_TEXT[waiting] or string.format('%d queued...', waiting));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.queue);
        end
    else
        imgui.TextDisabled('');
    end

    -- The trust engage toggle -- drawn only when a roster has said what the
    -- current mode IS (the `t|` record). A server without the feature sends
    -- none, and this row simply does not exist, exactly like the buff rows
    -- on a server from before the buff read.
    if (state.trustEngage ~= nil) then
        engageUi[1] = (state.trustEngage == 1);

        if (imgui.Checkbox('Trusts engage when you draw your weapon', engageUi)) then
            local mode = engageUi[1] and 1 or 0;

            -- Optimistic, so the box does not snap back for the second or two
            -- the round trip takes; the literal typed command does the write
            -- (its confirmation belongs in the chat log, like !squad call),
            -- and the roster re-ask below brings back the server's own `t|`
            -- as the settled truth.
            state.trustEngage = mode;

            -- Superseding for the same reason the follow slider does: a
            -- checkbox toggled twice is one decision, and only the last
            -- value of a setting means anything.
            issueLatest('!trustengage', string.format('!trustengage %i', mode));

            requested['who'] = nil;
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'ON:  your trusts attack the moment you engage a mob -- as soon as your weapon comes out.\n' ..
                'OFF: retail behavior -- your trusts hold back until your first swing actually lands.\n' ..
                'Same as typing !trustengage 1 or !trustengage 0.');
        end
    end

    -- The follow distance slider -- drawn only when a roster has said what
    -- the distance IS and what its range is (the `f|` record), the toggle's
    -- deployment-order rule. The value, the ends and the stock mark are all
    -- the server's; this row invents no yalm.
    if (state.follow ~= nil) then
        followRow();
    end

    -- The alliance row -- drawn only when a roster has said what the group
    -- state IS (the `g|` record), the same deployment-order rule as the
    -- toggle above: a server without the group command lane sends none, and
    -- this row simply does not exist. The buttons send the lane's literal
    -- typed commands; their narrative belongs in the chat log, and the
    -- packet_out watcher below re-asks the roster behind every one of them
    -- so the row keeps telling the truth.
    if (state.group ~= nil) then
        imgui.Separator();

        imgui.Text('Alliance');
        imgui.SameLine();
        imgui.TextDisabled('-- up to three parties, eighteen strong with squads out');

        imgui.PushItemWidth(140);

        if (imgui.InputTextWithHint('##dwsquad_ally_name', 'their leader', allyName, 16,
                ImGuiInputTextFlags_EnterReturnsTrue)) then
            sendForm();
        end

        imgui.PopItemWidth();

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('The name of the other party\'s leader -- the player you want to ally with.');
        end

        imgui.SameLine();

        if (imgui.Button('Form')) then
            sendForm();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'Invite that player\'s party into an alliance with yours -- same as typing !pally <name>.\n' ..
                'Both of you must lead a party; a summoned squad\'s own party counts.\n' ..
                'An alliance splits what a kill pays: two parties each earn half the experience,\n' ..
                'limit points and capacity points, three parties each earn a third.');
        end

        imgui.SameLine();

        if (imgui.Button('Join')) then
            if (issue('!join')) then
                setStatus('Accepting the invite...', false);
            end
        end

        if (imgui.IsItemHovered()) then
            -- The state half is built on hover, so a row that says nothing
            -- interesting costs nothing to draw. NOT a greyed button: the
            -- pending half of the `g|` record can go stale between rosters
            -- (an invite answered elsewhere), and a stale nil would lock a
            -- player out of an invite that really is waiting. The server
            -- refuses a stale !join with words, which costs a sentence.
            imgui.SetTooltip(
                'Accept the pending invite -- same as typing !join.\n' ..
                (state.group.pendingKind ~= nil
                    and 'An invite is waiting right now.'
                    or  'Nothing is waiting right now, so this would be refused.'));
        end

        imgui.SameLine();

        -- DECLINE, 1.7.0. The Join tooltip had been telling players to type
        -- !decline since 1.3.0, which is the addon admitting there was a
        -- button missing: refusing an invite is exactly as much a decision as
        -- accepting one, and the client suppresses its own dialog for
        -- squad-holders, so there was no other way to say no.
        if (imgui.Button('Decline')) then
            if (issue('!decline')) then
                setStatus('Declining the invite...', false);
            end
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                TIPS.decline .. '\n' ..
                (state.group.pendingKind ~= nil
                    and 'An invite is waiting right now.'
                    or  'Nothing is waiting right now, so this would be refused.'));
        end

        imgui.SameLine();

        if (imgui.Button('Dissolve')) then
            if (issue('!pleave')) then
                setStatus('Withdrawing from the alliance...', false);
            end
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'Withdraw your party from the alliance -- same as typing !pleave.\n' ..
                'If only one party would remain, the whole alliance dissolves.\n' ..
                (state.group.alliance
                    and 'Your party stands in an alliance right now.'
                    or  'Your party is not in an alliance, so this would be refused.'));
        end

        -- LEVEL SYNC, its own row (owner's request 2026-08-23: "so players
        -- don't have to memorize the command"). Retail's own level-sync menu
        -- is party-scoped and cannot reach across an alliance -- the 0x077
        -- packet is gated to Kind == Party -- so !alliancesync is the only
        -- door to it, and a door nobody can find is a door nobody uses.
        --
        -- The addon is told nothing about the sync state: no record carries
        -- it. (NOT because one would be a protocol change -- an additive
        -- record is what `t|`, `f|` and `g|` already are and none of them
        -- moved PROTOCOL; the file header carries the correction and the
        -- reason that actually holds.) So this row does not TRY to show the current
        -- level -- it sends the typed command and lets the server answer in
        -- the chat log, which is exactly what typing it does. An empty box is
        -- the status question, which is the honest way to ask "what are we
        -- synced to?" without inventing state the addon cannot verify.
        -- A breath between the two rows: Form/Join/Decline/Dissolve and
        -- Level Sync/Lift are different verbs against the same alliance, and
        -- they ran together as one undifferentiated block of buttons.
        imgui.Spacing();

        imgui.Text('Level sync');
        imgui.SameLine();
        imgui.TextDisabled('-- the whole alliance fights at one member\'s level');

        imgui.PushItemWidth(140);

        if (imgui.InputTextWithHint('##dwsquad_sync_name', 'any member', syncName, 16,
                ImGuiInputTextFlags_EnterReturnsTrue)) then
            sendSync();
        end

        imgui.PopItemWidth();

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'The character everyone should sync DOWN to -- any member of the alliance.\n' ..
                'Leave it empty and press Level Sync to be told what the alliance is synced to now.');
        end

        imgui.SameLine();

        if (imgui.Button('Level Sync')) then
            sendSync();
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'Sync every party in the alliance down to that character\'s level --\n' ..
                'same as typing !alliancesync <name>.  Empty box: !alliancesync (asks).\n' ..
                'So friends of different levels can fight the same monsters together.\n' ..
                'Only the alliance leader can set it, the character must be in the\n' ..
                'alliance and at least level 10, and it can never be a trust.\n' ..
                'Syncing dismisses your summons -- call them back and they return\n' ..
                'at the synced level.');
        end

        imgui.SameLine();

        if (imgui.Button('Lift')) then
            if (issue('!alliancesync off')) then
                setStatus('Lifting the alliance level sync...', false);
            end
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(
                'Remove the alliance level sync -- same as typing !alliancesync off.\n' ..
                'It wears off over the next thirty seconds, as retail\'s does.\n' ..
                'Summons already out stay at the synced level until you call them again.');
        end

        -- What is waiting or standing, one quiet line. The invite line is the
        -- reason the record exists: the client suppresses its own dialog for
        -- squad-holders, so without this a pending invite is invisible. The
        -- sentence itself is built when the `g|` record lands, not here.
        if (state.group.pendingLine ~= nil) then
            imgui.TextColored(theme.colors.ok, state.group.pendingLine);
        elseif (state.group.alliance) then
            imgui.TextDisabled('Your party stands in an alliance -- Dissolve withdraws it.');
            imgui.TextDisabled('Rewards are split between the alliance\'s parties while it stands.');
        end
    end

    --[[
        The message line, and errors are red: the reason a change was refused
        is the only thing telling a player what to do instead.

        IT KEEPS ITS ROW WHETHER OR NOT THERE IS A MESSAGE (1.7.0). The line
        used to appear and disappear, which moved both panels down and back up
        by a text row every time anything was clicked -- and the panels are
        what the player is actually reading. One empty line of height is
        cheaper than the whole window shifting under the cursor.
    --]]
    local banner = statusText();

    if (banner ~= nil) then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, banner);
    else
        imgui.TextDisabled('');
    end

    imgui.Separator();

    --[[
        THE TAB BAR (1.8.0), and it sits HERE -- under the whole header block
        and over the panels -- for one reason: everything above it is about
        the squad as a WHOLE (call it, dismiss it, how it walks, who it is
        allied with, what it is synced to) and everything below it is about
        the members one at a time. A tab bar higher up would put the alliance
        row inside one tab and out of the other three, which is the header
        block moving under the cursor -- the exact defect the banner's kept
        row and the staged `z|` commit both exist to prevent.

        THE SELECTED TAB IS IMGUI'S OWN AND NOT A LOCAL. ImGui keeps a tab
        bar's selection across frames and imgui.ini keeps it across sessions,
        so a mirror in here would be a second truth free to disagree with what
        was actually drawn -- dwquest's note, and the reason its own flags are
        set FROM the BeginTabItem results rather than from a click handler.
        Nothing in this window reads "which tab is open" anyway: the buff poll
        runs off the roster's flags whichever tab is showing, so a player
        watching the States tab and a player watching Main see the same data
        arrive at the same moment.
    --]]
    if (imgui.BeginTabBar('##dwsquad_tabs')) then
        --[[
            EVERY TAB TIP HANGS OUTSIDE ITS `if` (dwquest's shape, dwbags'
            before it). ImGui submits the tab as an item inside BeginTabItem
            whether or not it opened, so IsItemHovered reads the TAB there --
            and the first widget the body draws takes the "last item" away.
            Written inside the branch, three of these four would only ever be
            reachable on the tab already open, which is the one that needs no
            explaining.
        --]]
        local onMain = imgui.BeginTabItem('Main##dwsquad_tab_main');

        tip(TIPS.tabMain);

        if (onMain) then
            squadPanel();
            imgui.SameLine();
            charactersPanel();

            imgui.EndTabItem();
        end

        local onStates = imgui.BeginTabItem('States##dwsquad_tab_states');

        tip(TIPS.tabStates);

        if (onStates) then
            statesPanel();

            imgui.EndTabItem();
        end

        local onStats = imgui.BeginTabItem('Stats##dwsquad_tab_stats');

        tip(TIPS.tabStats);

        if (onStats) then
            statsPanel();

            imgui.EndTabItem();
        end

        local onExp = imgui.BeginTabItem('Exp##dwsquad_tab_exp');

        tip(TIPS.tabExp);

        if (onExp) then
            expPanel();

            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    needRoster();
    needBuffs();
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather
* than the addon: an error thrown inside d3d_present is raised sixty times a
* second and the addon host answers a long enough run by unloading the addon.
* Begin and End stay outside the pcall to keep ImGui's window stack balanced;
* the error is reported once and the window closes itself. Everything it does
* is still reachable as !squad commands, so closing it is a real fallback.
--]]
ashita.events.register('d3d_present', 'dwsquad_present', function ()
    -- Before the visibility check: a click issued a moment before the window
    -- was closed still has to reach the server, and walking through your own
    -- squad is not a property of having the window open.
    pumpQueue();
    ghostSquad();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    --[[
        THE DEFAULT SIZE, AND WHY IT MOVED (1.7.0).

        850x340 was chosen when this window was a button row, a status line
        and two panels. Since then it has grown a trust engage toggle (1.2), a
        four-button alliance row (1.3), a three-button level sync row (1.4)
        and a follow-distance slider (1.6), which is about 225 pixels of
        header before either panel is drawn -- against 304 of content height
        at 340. The two panels were sharing eighty pixels: two slot rows, and
        the character list a scroll bar deep.

        And 850 was never wide enough either: 410 for the slot panel leaves
        about 416 for a character table that wants 440 with its scroll bar,
        and with every column fixed the overflow came off the LAST one.
        (Both tables now stretch their text column, which is the real fix for
        the width; this is the size that does not make them work for it.)
    --]]
    imgui.SetNextWindowSize({ 880, 560 }, ImGuiCond_FirstUseEver);

    --[[
        AND A FLOOR UNDER IT, which this window had never had.

        ImGuiCond_FirstUseEver means the saved ini wins for everyone who has
        opened the window once, which by now is everyone -- so the paragraph
        above fixes nothing for the players who already have 850x340 saved.
        A minimum is applied on EVERY frame and clamps a saved size up, so it
        is the half of this that reaches them. 880x400 keeps the header block
        whole and leaves both panels a usable few rows.

        PCALL'D AND LATCHED (dwmerits 1.1.4's shape). This call sits OUTSIDE
        the render pcall, a player's Ashita is frozen at whatever they
        installed, and a binding that wants a third callback argument would
        throw here sixty times a second with no window to close. One refusal
        and the window simply has no minimum, which is exactly 1.6.2.
    --]]
    if (not constraintsBroken) then
        --[[
            AND THE FLOOR IS MEASURED TOO (1.7.0, second pass). 880x400 is a
            considered number for the DEFAULT font and a squeezed window in a
            larger one: the character panel's reserve grows with the font
            (columnWidths) and the minimum did not, so every pixel the reserve
            took came out of the slot panel -- the one carrying the names, the
            experience lines and the wrapped buff text. WINDOW_MIN carries the
            measurement renderWindow took inside the window on the previous
            frame, and columnWidths never answers below 880x400, so this can
            only raise it.
        --]]
        if (not pcall(imgui.SetNextWindowSizeConstraints, WINDOW_MIN, WINDOW_MAX)) then
            constraintsBroken = true;
        end
    end

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Squad##dwsquad', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwsquad'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwsquad'):append(chat.message('Window closed. Everything it does also works as !squad commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1] = true;

    -- Reopening is a fresh start for error reporting too: `reported` only
    -- exists to stop one bad frame printing sixty lines a second.
    state.reported = false;

    -- ...and for the envelope reader. A window closed mid-answer left
    -- `inbound` naming a verb whose `z|` never arrived and `quietErr` still
    -- suppressing the next refusal the player DID ask for. The half-built
    -- answer under it goes too: it belongs to an envelope nothing will now
    -- close, and holding it costs a table for as long as the window is shut.
    state.inbound  = nil;
    state.quietErr = false;
    staging        = nil;

    setStatus('Loading...', false);

    refresh();
end

--[[
* Watch what the player sends.
*
* Bare `!squad` (and `!squad ui`) is intercepted and opens this window
* instead of printing the server's usage text -- that line is blocked and
* never leaves the client. Every other `!squad` command passes through and
* invalidates the roster behind it, so `!squad set` typed by hand keeps the
* window honest.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped. Stamping
* the player's own line as a send makes the follow-up wait its interval.
--]]
ashita.events.register('packet_out', 'dwsquad_packet_out', function (e)
    -- A native invite answer (0x074) moves the group state without a chat
    -- line ever being typed -- the client's own dialog, where it still
    -- offers one. Re-ask the roster so the `g|` record catches up.
    if (e.id == 0x0074) then
        requested['who'] = nil;

        return;
    end

    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!squad' or lower == '!squad ui' or lower == '!squad window' or lower == '!squad gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dws') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 6) == '!squad') then
        refresh();
    end

    -- A typed !trustengage moves the state behind the toggle, so the next
    -- roster is re-asked to bring the fresh `t|` back -- the same keeping-
    -- honest rule the !squad line above follows. This also fires for the
    -- toggle's own queued send, which costs one redundant re-ask and nothing
    -- else (the toggle already cleared the tracker when it was clicked).
    if (lower:sub(1, 12) == '!trustengage') then
        requested['who'] = nil;
    end

    -- A typed !trustfollow moves the state behind the slider the same way;
    -- the slider's own queued send fires this too, one redundant re-ask.
    if (lower:sub(1, 12) == '!trustfollow') then
        requested['who'] = nil;
    end

    -- Every grouping command moves the state behind the alliance row -- and
    -- because the row's own buttons send these same literal lines through
    -- the queue, this one watcher keeps the `g|` record honest for clicked
    -- and typed alike.
    -- `!alliancesync` rides the same list, and it is the one that matters most:
    -- a sync that LANDS re-levels everyone and, through the LevelSync effect
    -- script, dismisses every summoned member (scripts/effects/level_sync.lua
    -- clearTrusts). Without the re-ask the window would keep drawing the squad
    -- as `[summoned]`, with live buff rows counting down, for characters that
    -- are no longer out -- the most confidently wrong thing a renderer can do.
    for _, prefix in ipairs({ '!pally', '!padd', '!join', '!decline', '!pleave', '!alliancesync' }) do
        if (lower:sub(1, #prefix) == prefix) then
            requested['who'] = nil;

            break;
        end
    end
end);

ashita.events.register('command', 'dwsquad_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Squad`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwsquad' and first ~= '/squad') then
        return;
    end

    e.blocked = true;

    --[[
        `/squad help` -- what THIS side of the window does (1.7.0). It exists
        because `/squad ghost` did not: a diagnostic nobody can find is a
        diagnostic that never gets run, and the one thing support needs from a
        player who still walks into their own squad is that command's output.
        Deliberately short and deliberately about the CLIENT half only --
        `!squad help` is the server's own listing and this must not compete
        with it.
    --]]
    if (#args > 1 and args[2]:lower() == 'help') then
        print(chat.header('dwsquad'):append(chat.message('/squad          -- open or close the squad window')));
        print(chat.header('dwsquad'):append(chat.message('/squad ghost    -- report the walk-through-your-own-squad layer, per entity')));
        print(chat.header('dwsquad'):append(chat.message('!squad help     -- the server\'s own command listing; everything the window does is typed there too')));

        return;
    end

    -- `/squad ghost` -- the walk-through layer, out loud. Client-side and
    -- local: it sends nothing, because there is nothing on the server to ask.
    -- It exists because the 1.4.1 version of this layer looked correct and
    -- did nothing, and the only way to tell the three failure modes apart is
    -- to read the numbers off the running client. `after` is read back AFTER
    -- the write, so a row showing `no-clip=no` on the after column means the
    -- client refused or overwrote it, and a row showing `yes` that still
    -- blocks means 0x40 is not the lever for that entity class.
    if (#args > 1 and args[2]:lower() == 'ghost') then
        local rows = ghostWalk(true);

        if (rows == nil or #rows == 0) then
            print(chat.header('dwsquad'):append(chat.error(
                'ghost: nothing to walk through -- no party member sits in the dynamic entity range (0x700-0x8FF). Summon the squad first.')));

            return;
        end

        for _, row in ipairs(rows) do
            print(chat.header('dwsquad'):append(chat.message(string.format(
                '%s %s (0x%03X): flags0 %08X -> %08X, no-clip=%s, pet 0x%03X',
                row.kind, tostring(row.name), row.index, row.before, row.after,
                bit.band(row.after, GHOST_NO_CLIP) ~= 0 and 'yes' or 'NO',
                row.pet))));
        end

        return;
    end

    --[[
        AN UNKNOWN SUBCOMMAND SAYS SO RATHER THAN TOGGLING THE WINDOW (1.7.0).
        `/squad list` is a thing a player types -- the SERVER's surface spells
        it `!squad list` and the two prefixes are one character apart -- and
        until now it silently opened or closed the window, which is the least
        informative thing it could have done with a line it did not
        understand. Both help lines are named, because the answer is on one
        side or the other and this command cannot know which.
    --]]
    if (#args > 1) then
        print(chat.header('dwsquad'):append(chat.error(
            string.format('Unknown: /squad %s', tostring(args[2])))));
        print(chat.header('dwsquad'):append(chat.message(
            '/squad help for this window\'s own commands, !squad help for the server\'s.')));

        return;
    end

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

ashita.events.register('load', 'dwsquad_load', function ()
    print(chat.header('dwsquad'):append(chat.message('!squad (or /squad) opens the squad window. Everything it does also works typed as !squad commands.')));
end);

--[[
* THE TEXTURES GO BACK (1.8.0), and this handler exists for nothing else.
*
* The States tab creates one D3D texture per status icon it has ever drawn and
* keeps it for the session, which is right -- creating thirty a frame would be
* the alternative. But an addon is unloaded and re-loaded constantly during a
* play session (`/addon reload dwsquad`, the launcher's own sync, a zone line
* on some builds), and a texture whose last Lua reference is dropped by the
* interpreter going away is a texture nobody released.
*
* `gc_safe_release` is what owns the release; dropping the tables is what lets
* it fire, and the collection is ASKED FOR rather than waited for, because an
* unload has no next frame to be lazy in. Nothing else is done here: this
* addon caches nothing to disk and has nothing to say goodbye to the server
* about (dwcon's unload sends `!dwo bye` because the server is holding
* something for it; nothing on the server is holding anything for this one).
--]]
ashita.events.register('unload', 'dwsquad_unload', function ()
    releaseIcons();
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new account view. An incoming invite (0x0DC, the
-- native "X invites you" solicit) moves the group state the moment it lands,
-- so the roster is re-asked and the alliance row's waiting line appears
-- without anyone clicking Refresh -- event-driven, not polled.
ashita.events.register('packet_in', 'dwsquad_zonein', function (e)
    if (e.id == 0x00DC) then
        requested['who'] = nil;

        return;
    end

    if (e.id == 0x000A) then
        state.chars       = T{ };
        state.buffs       = T{ };
        state.stats       = T{ };
        state.trustEngage = nil;
        state.group       = nil;

        --[[
            `follow` BELONGS ON THIS LIST AND WAS MISSING FROM IT (1.7.0).

            1.6.0 added state.follow to the `d|who` reset -- where it is
            correct -- and not to this one. The tenths are the CHARACTER's own
            setting, so a login carried the previous character's distance into
            the new one's slider, and carried it for the whole session if that
            character's first roster was ever lost. A drag left half-finished
            by the zone line goes with it: the settle would otherwise fire a
            !trustfollow for whoever logged in next.
        --]]
        state.follow      = nil;
        followEdited      = nil;

        -- A login mid-envelope leaves the reader naming a verb whose `z|`
        -- will never arrive, and a `quietErr` still shielding the chat log
        -- from the next refusal the player DOES ask for. The staged answer
        -- under them is the PREVIOUS character's roster half-built; a `z|`
        -- from a record still in flight would commit it over the new one.
        state.inbound     = nil;
        state.quietErr    = false;
        staging           = nil;

        -- ...and the version verdict, which a map restart or a deploy can have
        -- moved underneath a running client -- 0x000A is a zone line as well
        -- as a login, and both are moments to ask again (dwarena's `refused`,
        -- same reasoning).
        --
        -- `serverSpoke` DELIBERATELY SURVIVES, exactly as dwport's does. It
        -- answers "has this server ever spoken dwsquad to this client", which
        -- is a question about the install and is settled for the session the
        -- first time an envelope arrives. Clearing it here would let a single
        -- roster lost on a zone line raise "Is this DriftwoodXI, and is the
        -- update installed?" against a server that had been answering all
        -- evening.
        state.refused     = false;
        state.rosterAt    = nil;

        -- Write latches over a squad that belonged to the character who
        -- logged out; either would suppress a slot or an Add on the new one.
        pendingSlots      = { };
        pendingChars      = { };

        --[[
            AND THE GHOST SET, whose every index names an entity in a zone
            that is gone. The server hands the SAME dynamic band out again in
            the new one (m_nextDynamicTargID walks [0x700,0x900) and reuses a
            freed index), so a stale entry is a write into whatever inherited
            it. The packet hook's own guard catches a recycled MOB -- it reads
            no trust owner -- but another player's trust in the new zone
            answers that guard perfectly, and the sweep that would have
            rebuilt the set from a real party has not run yet. Emptied here;
            the next sweep refills it within half a second.
        --]]
        ghostSet          = { };

        bumpModel();
        setStatus('Loading...', false);

        -- A login is the one moment a server may have been updated underneath
        -- this client, so the capability latch is re-probed rather than held
        -- for the session.
        buffsUnsupported = false;

        refresh();
    end
end);
