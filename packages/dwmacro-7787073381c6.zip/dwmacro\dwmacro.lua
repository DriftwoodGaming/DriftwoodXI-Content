--[[
* DriftwoodXI -- dwmacro
*
* Stops the client losing your macro book and set on a zone line and on a
* fresh login.
*
* WHY THIS IS AN ADDON AND NOT A SERVER PATCH.
*
* The macro palette is not server state, and this was re-checked rather than
* inherited. It is not in the database, it is not in any packet, and the map
* server has never been told about it: the string "macro" does not appear
* anywhere in atom0s's packet reference (XiPackets), which is the complete
* documented protocol, and it appears nowhere in this server's own source
* outside of unrelated C preprocessor macros. The one place the client's own
* saved configuration comes back to it from the server -- `ConfData` in the
* 0x000A login packet, the PS2 `SAVE_CONF` block -- carries chat filters, the
* language flags, anonymity, auto-target and the head-display bit, and nothing
* else; there is no macro field in it to get wrong. `LoginState` on that same
* packet is already the correct `SAVE_LOGIN_STATE_GAME`, so the client is not
* being told a zone line is a fresh login either.
*
* Macro books, their contents, and the book/set you are currently looking at
* all live in the client, in `<PlayOnline>/SquareEnix/FINAL FANTASY XI/USER/
* <charid-in-hex>/`, as `mcr.dat` and `mcr<book>.dat`. There is nothing on the
* server to fix. The only place the behaviour can be corrected is in the
* client, which is what this is.
*
* WHAT THE CLIENT ACTUALLY GETS WRONG.
*
* `FsMacroContainer` is not a copy of your macro books. It holds exactly ONE
* loaded page -- twenty macro records of 380 bytes each, from `this+4` to
* `this+0x1DB4`, which is the arithmetic Ashita's own `macrolib.set` uses to
* write one (`obj + 380 * idx + 4`) -- and then, past the end of them, the
* number of the book that page came out of, at `this+0x1DC0`.
*
* Those twenty records ARE the macro bar. There is no second copy of your
* macro names and lines for the bar to draw from; `FsMacroContainer::getName`
* and `::getLine` read them straight out of the container at that same stride.
*
* On a zone line the client reloads the records -- and reloads them from Book
* 1, Set 1 -- WITHOUT putting Book 1 into the book field. The container is
* left holding book 1's macros while its book field still says book 5. That
* single inconsistency is the whole of "the client forgot":
*
*   - the bar shows Book 1, Set 1, because that is what is loaded;
*   - anything that asks the client which book you are on is told book 5,
*     because that is what the field says;
*   - and `FsMacroContainer::setBook(5)` -- what `/macro book 5` and every
*     addon reaches for -- opens by comparing 5 against the field, finds them
*     equal, and returns without loading anything:
*
*         8B 44 24 04        mov  eax, [esp+4]        ; the requested book
*         56                 push esi
*         8B F1              mov  esi, ecx            ; this
*         8B 8E C0 1D 00 00  mov  ecx, [esi+1DC0h]    ; the current book
*         3B C8              cmp  ecx, eax
*         75 ??              jne  short               ; ... only then does the work
*         8B C1              mov  eax, ecx
*         5E                 pop  esi
*         C2 04 00           ret  4
*
*     so the one call that would put the records back is precisely the one the
*     client refuses to run. Being on the wrong page is what makes you unable
*     to ask for the right one.
*
* HOW IT IS PUT RIGHT.
*
* By making the container consistent again, through the client's own loader:
* ask for a NEIGHBOURING book first so the comparison above fails and the load
* actually happens, then ask for the book that is wanted. Same for the set.
* Four calls, no typing, no packets, nothing the server hears about.
*
* AND -- this is the part every earlier build could not do -- by CHECKING. The
* records are the bar, and the records are readable, so what the player is
* looking at is readable. A fingerprint of those 7,600 bytes is kept beside the
* remembered book and set, taken while the player was sitting on that palette
* and playing normally. After a zone line the live fingerprint is compared
* against it:
*
*   - they match: the client did not forget this time, and nothing is touched.
*   - they differ: the palette is wrong, and it is put back -- and then checked
*     again on the next poll, and put back again if the client's own late
*     rebuild has clobbered it.
*
* So there is no longer a guess about WHEN the client finishes rebuilding. The
* addon watches the whole settling window and acts only when the bar is
* actually wrong, instead of firing blind at fixed times and hoping one of them
* landed after the rebuild. 1.1 stood down because it asked the book FIELD
* whether it was needed and the field lied; the fingerprint is the same
* question asked of the thing the player can see, and it cannot lie, because it
* is read from the same bytes the bar is drawn from.
*
* WHY THE TYPED-COMMAND PATH IS STILL HERE.
*
* 1.3 restored by queueing the client's own `/macro book` / `/macro set` text
* commands. That worked, but it buys the wrong thing at a real price: the
* command parser refuses input for several seconds after a zone line -- long
* after the party list is live -- and answers a command it will not take with
* "A command error occurred." and no action. Restoring that way means racing a
* parser, swallowing its error lines out of the player's log, and retrying.
*
* The direct calls have none of that: `FsMacroContainer::setBook` does not care
* whether the client is taking typed input yet, so the repair can land at the
* first frame the container exists. But the typed path is retail-proven in a
* way a direct call is not, so it is kept as a FALLBACK: if two direct repairs
* go by and the fingerprint still refuses to come right, the addon stops
* trusting the direct calls and switches to typed commands for the rest of the
* window, bounce-watcher and all. It is also the channel used when there is no
* remembered fingerprint to check against -- the first zone line on a job it
* has never seen -- because an unverifiable repair should use the mechanism
* with the longer field record.
*
* THE SELECTION IS REMEMBERED PER JOB, not per character. That is the way the
* game already thinks about macro books -- changing job switches your book --
* so keying on the job is what stops the two features fighting: come back as
* BLM and you are put on the book and set you last used as BLM, not on whatever
* WAR was looking at. Per-character separation is free; Ashita's settings
* library already files everything under `<charname>_<serverid>`.
*
* TURN IT OFF AND NOTHING IS LOST. `/macro book <n>` and `/macro set <n>` work
* exactly as they always did. This addon only ever puts back a book and set the
* player had already chosen for that job on that character; it never invents
* one, and with no remembered entry it does nothing at all.
--]]

addon.name    = 'dwmacro';
addon.author  = 'DriftwoodXI';
addon.version = '2.0';
addon.desc    = 'Stops the client losing your macro book and set when you zone or log back in.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local settings = require('settings');

--[[
* The macro library is a signature scan over the client and it raises rather
* than returning nil when a scan misses. A client build it does not know must
* leave the player with a working game and one line of explanation, not an
* addon that failed to load, so it is required defensively and every use of it
* is behind `macrolib ~= nil`.
--]]
local macrolib = nil;

do
    local ok, lib = pcall(require, 'ffxi.macros');

    if (ok and type(lib) == 'table') then
        macrolib = lib;
    end
end

--[[
* The loaded page: twenty macro records of 380 bytes, starting four bytes into
* the container.
*
* This is not a guess and it is not this addon's arithmetic. Ashita's own
* `macrolib.set` writes a macro at `obj + 380 * idx + 4`, and the client's
* `FsMacroContainer::getName` computes the same address from the same stride
* (`lea edx,[eax+eax*2]; shl edx,5; sub edx,eax; lea ecx,[ecx+edx*4+4]` is
* `idx * 380 + 4`). Everything the macro bar draws lives in this block, which
* is what makes it worth fingerprinting.
--]]
local RECORD_BASE   = 4;
local RECORD_STRIDE = 380;
local RECORD_COUNT  = 20;
local RECORD_END    = RECORD_BASE + (RECORD_STRIDE * RECORD_COUNT);

--[[
* Where the book field lives inside the macro container.
*
* The offset is the four bytes at +9 from the address Ashita matched for
* `setBook` (see the disassembly in the header). Taking it from there rather
* than writing 0x1DC0 down means this and the library can only ever agree:
* they are reading the same matched bytes.
--]]
local BOOK_OFFSET_IMM = 9;

-- A sanity range for that offset. The macro records occupy everything below
-- RECORD_END, so a plausible book offset is a little past that and nowhere
-- near zero. Anything outside this is a bad match, not a client we do not know
-- about, and is refused.
local BOOK_OFFSET_MIN = 0x1000;
local BOOK_OFFSET_MAX = 0x4000;

--[[
* How far past the book field to look when measuring the set field.
*
* Above the book field is the only speculative part of the scan, and it is
* speculative in the way that matters -- reading past the end of the allocation
* is a crash, not a failed measurement. A quarter of a kilobyte past the last
* member anyone has ever named is a long way for a sibling field and a short
* way into a heap block this size.
--]]
local SCAN_PAST_BOOK = 0x100;

--[[
* The sets the measurement drives through, as set numbers 0-9.
*
* Four values, so that a byte which merely happens to be 1 when the set is 1 is
* gone by the second probe, and chosen so the two candidate encodings can never
* be confused: as rows these are 2, 18, 8, 0 and as plain sets 1, 9, 4, 0, which
* differ everywhere they can. The list ends on set 1 because that is where the
* client has just put the player when this runs, so a measurement that fails
* outright leaves the palette exactly where the client left it.
*
* CONFIRM_SET took no part in choosing the candidates, which is the point of it:
* a byte that survived four probes and then also predicted a fifth is the set.
--]]
local PROBE_SETS  = T{ 1, 9, 4, 0 };
local CONFIRM_SET = 6;

local MAX_SET  = 9;
local MAX_BOOK = 39;

--[[
* The two ways the container could plausibly hold the selection: the row index
* the client's `setPage` is handed, or the set number behind it. Which one it
* actually is gets decided by the measurement rather than by assumption.
--]]
local ENCODINGS = T{
    T{
        name   = 'row',
        encode = function (set) return set * 2; end,
        decode = function (raw)
            if (raw % 2 ~= 0) then
                return nil;
            end

            return math.floor(raw / 2);
        end,
    },
    T{
        name   = 'set',
        encode = function (set) return set; end,
        decode = function (raw) return raw; end,
    },
};

--[[
* How long after a zone line the palette is watched, and how often.
*
* The window is NOT a schedule any more. Nothing fires at a fixed offset inside
* it; the addon looks at the bar every CHECK_INTERVAL and only acts when the
* bar is wrong. What the window's length still has to cover is the client's own
* late rebuild -- observed on 2026-08-07 arriving a good six seconds after the
* party list went live, and refusing typed input for most of that -- because a
* rebuild that lands after the addon has stopped watching is a rebuild that
* wins. Fifteen seconds straddles every one anyone here has seen.
*
* Everything inside the window is also held out of the recorder (see `tick`):
* the client's post-zone default is not a choice the player made, and writing
* it down is how a repair that missed turns into "puts me on Set 1 for ever".
--]]
local RECORD_HOLD    = 15.0;
local CHECK_INTERVAL = 0.5;

--[[
* How long a repair is given to land before the next one is allowed, and how
* many are allowed at all.
*
* A direct call has landed by the time it returns; a typed command takes a
* frame or two to be parsed, so the check that follows one must not be taken
* immediately. Two seconds is far past either.
*
* The ceiling exists for the case the addon cannot distinguish from the outside:
* a player who spends the settling window working the macro menu themselves
* looks exactly like a client that keeps clobbering the palette. Eight repairs
* spread across the window is more coverage than 1.3's three blind passes had,
* and still stops rather than fighting for ever.
--]]
local APPLY_SETTLE = 2.0;
local MAX_APPLIES  = 8;

--[[
* How many unverified direct repairs are allowed before the addon stops
* believing in them and falls back to typed commands for the rest of the
* window. Two: one to be unlucky with, one to be sure.
--]]
local DIRECT_TRIES = 2;

--[[
* How long after a typed repair a "command error" line in the chat log is taken
* to be that repair bouncing off a client that was not ready, rather than the
* player's own typing going wrong. Inside this window the line is swallowed --
* it is this addon's plumbing -- and counted, so `/dwmacro debug` can say the
* repair was rejected instead of leaving "ran and changed nothing" and "never
* landed" looking identical. Only ever armed for the typed fallback; a direct
* repair produces no chat line at all, so the player's own command errors stay
* their own for as long as the fallback is not in use.
--]]
local BOUNCE_WINDOW = 2.5;

-- How often the palette is read while playing. Often enough that a set chosen
-- and then immediately zoned away from is caught, rare enough to be free.
local POLL_INTERVAL = 0.5;

-- And how many of those polls in a row have to agree before a new selection is
-- believed. A single read that disagrees with the one beside it is the palette
-- mid-move, not a decision; two costs half a second of lag and cannot be one.
local RECORD_AGREE = 2;

--[[
* Measuring needs a macro container the client has actually finished filling in.
* `inGame()` goes true the moment the player has a party slot, which on a slow
* login -- a server still loading, a zone still streaming in -- is earlier than
* the palette being ready. Probing then drives sets that do not take, no byte
* counts along, and the measurement comes back empty.
*
* So a failure is never final on the strength of one login. MEASURE_RETRIES is
* the budget for a single arming: spend it and the addon goes quiet until the
* next zone line, which re-arms it with a fresh budget and a client that has
* just rebuilt its macro state. Only MEASURE_MAX_ATTEMPTS, across the whole
* session, ends it for good -- because a client that genuinely cannot be read
* should say so once rather than probe the palette for ever.
--]]
local MEASURE_SETTLE         = 2.0;
local MEASURE_RETRIES        = 4;
local MEASURE_RETRY_INTERVAL = 3.0;
local MEASURE_MAX_ATTEMPTS   = 24;

local default_settings = T{
    -- Repairing can be turned off without unloading the addon; the palette is
    -- still remembered while it is off, so turning it back on picks up where
    -- it left off.
    enabled = true,

    -- Keyed by main job id. Each entry is { book = <0-39>, set = <0-9>,
    -- fp = <fingerprint of the twenty records that were loaded there> }, in
    -- the numbering the macro menu shows minus one.
    jobs    = T{ },
};

local config = settings.load(default_settings);

--[[
* Builds before 1.1 stored the client's doubled row value under `page`. Nothing
* is thrown away for it: the row halves cleanly into the set it always meant.
* Entries written before 2.0 carry no fingerprint, which is not a migration
* problem -- an entry without one simply cannot be checked until the recorder
* has seen that palette once, and takes the typed fallback in the meantime.
--]]
do
    if (type(config.jobs) == 'table') then
        for _, entry in pairs(config.jobs) do
            if (type(entry) == 'table' and entry.set == nil and type(entry.page) == 'number') then
                entry.set  = math.floor(entry.page / 2);
                entry.page = nil;
            end
        end
    end
end

local state = T{
    -- What was measured. `bookOffset` is an offset; `page` is a table of
    -- { offset = <byte offset>, enc = <encoding> } and is nil until proven.
    bookOffset = nil,
    page       = nil,

    -- Measurement bookkeeping. `attempts` is the budget for the current arming
    -- and `total` is the session ceiling; `gaveUp` is set only once the ceiling
    -- is reached, and is what makes the failure final and worth saying aloud.
    attempts   = 0,
    total      = 0,
    nextTry    = 0,
    gaveUp     = false,

    -- What the last measurement saw, for `/dwmacro debug`. "Nothing happens" has
    -- several causes and they are not distinguishable from the outside.
    scan       = nil,

    -- Repair bookkeeping. `armed` is set by the zone-in packet and cleared when
    -- the settling window closes; while it is up nothing read from the palette
    -- is recorded, because immediately after a zone the client is sitting on its
    -- own Book 1 / Set 1 default and writing that over the player's real choice
    -- is the one bug this addon must not have.
    armed      = false,
    zonedAt    = 0,
    nextCheck  = 0,

    -- `applies` is how many repairs have gone out this zone, `nextApply` when
    -- the next one is allowed, `appliedFp` the fingerprint the last one left
    -- behind (used to notice a later clobber when there is nothing remembered
    -- to check against), `verified` whether the bar has ever been seen to agree
    -- with what was remembered, and `channel` which mechanism is in use.
    applies    = 0,
    nextApply  = 0,
    appliedFp  = nil,
    verified   = false,
    channel    = 'direct',

    -- What the last zone line actually did, for `/dwmacro debug`. A repair that
    -- ran and did not show up on screen and a repair that never ran look the
    -- same to the player and want completely different answers.
    trail      = nil,

    -- When the last typed repair went out, and how many of its commands the
    -- client has bounced this zone. `sentAt` arms the text_in watcher; a
    -- "command error" line inside BOUNCE_WINDOW of it is ours, not the player's.
    sentAt     = nil,
    bounced    = 0,

    -- The previous poll's reading, for the agreement rule.
    lastSeen   = nil,
    agreed     = 0,

    lastPoll   = 0,
};

settings.register('settings', 'dwmacro_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end

    settings.save();
end);

--[[
* Whether the player is actually in the world -- past character select, past
* the zone screen, with a party slot of their own, and NOT mid-zone. Every
* read and write below is gated on this; the macro container exists before
* this is true and holds nothing worth reading.
*
* The zoning check is load-bearing: login status and the party slot both go
* live while the load screen is still up, so a clock started on them alone
* starts several seconds early. `GetIsZoning() == 0` is the same signal the
* stock timers and statustimers addons gate on for "the world is real now".
--]]
local function inGame()
    local player = AshitaCore:GetMemoryManager():GetPlayer();

    if (player == nil or player:GetLoginStatus() ~= 2) then
        return false;
    end

    if (player:GetIsZoning() ~= 0) then
        return false;
    end

    local party = AshitaCore:GetMemoryManager():GetParty();

    if (party == nil or party:GetMemberIsActive(0) == 0) then
        return false;
    end

    return true;
end

local function mainJob()
    local player = AshitaCore:GetMemoryManager():GetPlayer();

    if (player == nil) then
        return 0;
    end

    return player:GetMainJob();
end

--[[
* The live macro container, or 0. This is re-read every time rather than cached
* because it is a pointer through two indirections and the object behind it does
* not survive a zone.
--]]
local function container()
    if (macrolib == nil) then
        return 0;
    end

    local ok, obj = pcall(macrolib.get_fsmacro);

    if (not ok or type(obj) ~= 'number') then
        return 0;
    end

    return obj;
end

--[[
* A fingerprint of the loaded page -- which is to say, of the macro bar.
*
* THIS IS THE ONLY HONEST ANSWER TO "IS THE PLAYER LOOKING AT THE RIGHT
* MACROS", and having it is the whole difference between 2.0 and everything
* before it. The book field says what the client believes; these bytes are what
* it drew. After a zone line the two disagree, and only one of them is the bug.
*
* Two independent rolling hashes rather than one, and returned as a string so
* the settings file holds something legible: a single 32-bit hash over 7,600
* bytes will collide on some pair of pages eventually, and a collision here is
* an addon that declares the bar correct while the player stares at the wrong
* macros. Both would have to collide at once for that.
*
* Cheap enough to run twice a second: `read_array` fetches the block in one
* call and the loop is arithmetic on a LuaJIT number.
--]]
local function fingerprint(obj)
    if (obj == nil or obj == 0) then
        return nil;
    end

    -- Never read past the book field, whatever the client says the layout is.
    local length = RECORD_END - RECORD_BASE;

    if (state.bookOffset ~= nil and state.bookOffset < RECORD_END) then
        length = state.bookOffset - RECORD_BASE;
    end

    if (length <= 0) then
        return nil;
    end

    local ok, bytes = pcall(ashita.memory.read_array, obj + RECORD_BASE, length);

    if (not ok or type(bytes) ~= 'table') then
        return nil;
    end

    local h1 = 0;
    local h2 = 0;

    for index = 1, length do
        local value = bytes[index];

        if (value == nil) then
            return nil;
        end

        h1 = (h1 * 31 + value) % 4294967291;
        h2 = (h2 * 131 + value + index) % 4294967279;
    end

    return ('%d.%d'):fmt(h1, h2);
end

--[[
* The book field's offset, taken out of the bytes Ashita matched for setBook.
--]]
local function findBookOffset()
    if (macrolib == nil or macrolib.ptrs == nil) then
        return nil;
    end

    local ptr = macrolib.ptrs.set_book;

    if (ptr == nil or ptr == 0) then
        return nil;
    end

    local ok, offset = pcall(ashita.memory.read_uint32, ptr + BOOK_OFFSET_IMM);

    if (not ok or type(offset) ~= 'number') then
        return nil;
    end

    if (offset < BOOK_OFFSET_MIN or offset > BOOK_OFFSET_MAX or offset % 4 ~= 0) then
        return nil;
    end

    return offset;
end

--[[
* The probing half of the measurement. Kept separate from the repair so that
* the repair can be guaranteed: this is allowed to fail in the middle, and the
* caller still puts the player's set back.
*
* THE SCAN STARTS ABOVE THE MACRO RECORDS and that is not an optimisation. The
* records change when the page changes -- that is the entire premise of the
* fingerprint above -- so a byte inside them tracks the set just as faithfully
* as the set field does, and a scan that includes them is choosing between
* thousands of bytes that all "count along" rather than looking for a field.
* The set field cannot be inside the loaded page, so it is not looked for
* there.
--]]
local function probePageField(obj, bookOffset, before)
    local size  = bookOffset + SCAN_PAST_BOOK;
    local first = RECORD_END;

    if (first > bookOffset) then
        first = 0;
    end

    -- Probe one, from the full snapshot.
    macrolib.set_page(PROBE_SETS[1]);

    local snapshot = ashita.memory.read_array(obj, size);

    if (type(snapshot) ~= 'table') then
        return nil;
    end

    local candidates = { };

    for offset = first, size - 1 do
        local value = snapshot[offset + 1];

        if (value == nil) then
            break;
        end

        -- The book field is known, and is not the set field.
        if (offset < bookOffset or offset > bookOffset + 3) then
            for index = 1, #ENCODINGS do
                if (value == ENCODINGS[index].encode(PROBE_SETS[1])) then
                    candidates[#candidates + 1] = { offset = offset, enc = ENCODINGS[index] };
                end
            end
        end
    end

    local seeded = #candidates;

    -- The remaining probes, plus the confirming one. A candidate has to predict
    -- every single one of them.
    local rounds = T{ };

    for index = 2, #PROBE_SETS do
        rounds:append(PROBE_SETS[index]);
    end

    rounds:append(CONFIRM_SET);

    for index = 1, #rounds do
        if (#candidates == 0) then
            break;
        end

        macrolib.set_page(rounds[index]);

        local survivors = { };

        for entry = 1, #candidates do
            local candidate = candidates[entry];
            local ok, value = pcall(ashita.memory.read_uint8, obj + candidate.offset);

            if (ok and value == candidate.enc.encode(rounds[index])) then
                survivors[#survivors + 1] = candidate;
            end
        end

        candidates = survivors;
    end

    --[[
    * Nearest the book field wins. Several survivors is not ambiguity to be
    * refused -- all of them track the set, and the offset is only ever read --
    * but the choice still has to be the same one every session, so it is made
    * on distance and then on offset and encoding to break any remaining tie.
    --]]
    table.sort(candidates, function (a, b)
        local da = math.abs(a.offset - bookOffset);
        local db = math.abs(b.offset - bookOffset);

        if (da ~= db) then
            return da < db;
        end

        if (a.offset ~= b.offset) then
            return a.offset < b.offset;
        end

        return a.enc.name < b.enc.name;
    end);

    return {
        seeded    = seeded,
        survivors = #candidates,
        chosen    = candidates[1],
        before    = before,
    };
end

--[[
* Measure the set field, and put the player back on the set they were on.
*
* The restore runs whether the probing succeeded, failed, or raised: the probe
* moves the palette, and a probe that dies halfway through must not leave the
* player looking at somebody else's macros. Where the original set is unknown --
* nothing was found, so there is no byte to read it back out of -- what this job
* was last seen on is the player's own choice rather than the client's default,
* so it is asked first, and 0 is only the answer when there is nothing
* remembered at all -- which is also where the client has just put them.
--]]
local function measurePageField(obj, bookOffset)
    local before = ashita.memory.read_array(obj, bookOffset + SCAN_PAST_BOOK);

    if (type(before) ~= 'table') then
        return nil;
    end

    local ok, result = pcall(probePageField, obj, bookOffset, before);

    local restore = nil;

    if (ok and type(result) == 'table' and result.chosen ~= nil) then
        local original = before[result.chosen.offset + 1];

        if (type(original) == 'number') then
            local decoded = result.chosen.enc.decode(original);

            if (decoded ~= nil and decoded >= 0 and decoded <= MAX_SET) then
                restore = decoded;
            end
        end
    end

    if (restore == nil) then
        local job        = mainJob();
        local remembered = (job ~= 0) and config.jobs[job] or nil;

        if (remembered ~= nil and type(remembered.set) == 'number'
            and remembered.set >= 0 and remembered.set <= MAX_SET) then
            restore = remembered.set;
        else
            restore = 0;
        end
    end

    pcall(macrolib.set_page, restore);

    if (not ok) then
        error(result, 0);
    end

    return result;
end

--[[
* Read the palette FIELDS. Returns nil unless the measurement is done, the
* container is live, and both values are ones the client could actually be
* holding -- a set outside 0-9 means the offset is wrong and the read is thrown
* away rather than remembered.
*
* Note what this is and is not for. It says which book and set the player
* CHOSE, which is what has to be written down. It does NOT say what the client
* is showing them -- after a zone line it happily reports the old selection
* while the bar sits on Book 1 -- so nothing about whether a repair is needed
* is ever decided from it. That is the fingerprint's job.
--]]
local function readPalette()
    if (state.bookOffset == nil or state.page == nil) then
        return nil;
    end

    local obj = container();

    if (obj == 0) then
        return nil;
    end

    local ok, book = pcall(ashita.memory.read_uint32, obj + state.bookOffset);

    if (not ok or type(book) ~= 'number' or book < 0 or book > MAX_BOOK) then
        return nil;
    end

    local okRaw, raw = pcall(ashita.memory.read_uint8, obj + state.page.offset);

    if (not okRaw or type(raw) ~= 'number') then
        return nil;
    end

    local set = state.page.enc.decode(raw);

    if (set == nil or set < 0 or set > MAX_SET) then
        return nil;
    end

    return { book = book, set = set };
end

--[[
* Put the palette back through the client's own loader.
*
* EACH OF THE BOOK AND THE SET GOES THROUGH A NEIGHBOUR FIRST, and that is the
* fix rather than a flourish: `FsMacroContainer::setBook` returns immediately
* when asked for the book its field already claims to hold (the disassembly is
* in the header), and after a zone line that field claims to hold the right
* book while the bar shows Book 1. A no-op is not a repair. The extra
* transition is only ever visible if the player is holding Ctrl or Alt inside
* the settling window, and costs nothing otherwise.
*
* The book goes first and the set second, and that order is not cosmetic: the
* client resets the set whenever the book actually changes, so a set put back
* first would be thrown away by the book change.
*
* Two channels, same four transitions.
*
*   direct  `FsMacroContainer::setBook` / `::setPage`, through Ashita's macro
*           library. Nothing is written to the container; these are the
*           client's own methods, called the way the client calls them. They do
*           not care whether the command parser is up yet, which is why this is
*           the default -- a repair can land at the first frame the container
*           exists instead of waiting out a parser that answers "A command
*           error occurred." for several seconds after a zone line.
*
*   text    the client's own `/macro book <n>` / `/macro set <n>`, queued. The
*           mechanism players and job-change macros have driven for years, kept
*           for when the direct calls cannot be shown to have worked. The
*           commands carry the menu's 1-based numbering, because that is what
*           the client's command parser takes; everything else here is 0-based.
*           A slash command is client-local and reaches no server, so there is
*           no echo to swallow and dwecho stays unnecessary.
*
* The four steps are written out rather than folded into a loop: read as four
* lines it is obvious what happens if one of them is ever removed.
--]]
local function applyPalette(palette, channel)
    if (palette == nil) then
        return false;
    end

    if (palette.book < 0 or palette.book > MAX_BOOK or palette.set < 0 or palette.set > MAX_SET) then
        return false;
    end

    local otherBook = (palette.book + 1) % (MAX_BOOK + 1);
    local otherSet  = (palette.set  + 1) % (MAX_SET  + 1);

    if (channel == 'text') then
        local mgr = AshitaCore:GetChatManager();

        if (mgr == nil) then
            return false;
        end

        return pcall(function ()
            mgr:QueueCommand(1, ('/macro book %d'):fmt(otherBook + 1));
            mgr:QueueCommand(1, ('/macro book %d'):fmt(palette.book + 1));
            mgr:QueueCommand(1, ('/macro set %d'):fmt(otherSet + 1));
            mgr:QueueCommand(1, ('/macro set %d'):fmt(palette.set + 1));
        end);
    end

    if (macrolib == nil) then
        return false;
    end

    return pcall(function ()
        macrolib.set_book(otherBook);
        macrolib.set_book(palette.book);
        macrolib.set_page(otherSet);
        macrolib.set_page(palette.set);
    end);
end

--[[
* Human-facing numbering. The client counts books and sets from zero; the macro
* menu counts them from one.
--]]
local function describe(palette)
    if (palette == nil) then
        return 'nothing yet';
    end

    return ('book %d, set %d'):fmt(palette.book + 1, palette.set + 1);
end

--[[
* Measure the palette, spending one budget of attempts per arming and conceding
* only once the session ceiling is reached. Once the measurement is done this is
* a single comparison per frame; once it has given up it is the same.
--]]
local function ensureMeasured()
    if (state.gaveUp or (state.bookOffset ~= nil and state.page ~= nil)) then
        return;
    end

    -- This arming's budget is spent. Wait for the next zone line, which re-arms
    -- with a client that has just rebuilt its macro state.
    if (state.attempts >= MEASURE_RETRIES) then
        return;
    end

    local now = os.clock();

    -- Let the client finish building the palette before touching it, and space
    -- the retries out rather than re-probing every frame.
    if (state.nextTry == 0) then
        state.nextTry = now + MEASURE_SETTLE;
        return;
    end

    if (now < state.nextTry) then
        return;
    end

    -- No container yet is not an attempt, but it must still cost a wait, or a
    -- client that is slow to build one is probed sixty times a second.
    local obj = container();

    if (obj == 0) then
        state.nextTry = now + MEASURE_RETRY_INTERVAL;
        return;
    end

    state.attempts = state.attempts + 1;
    state.total    = state.total + 1;
    state.nextTry  = now + MEASURE_RETRY_INTERVAL;

    -- Whether there is anything left to try after this, ever. Everything below
    -- reports a failure only then; otherwise it goes quiet and waits.
    local final = state.total >= MEASURE_MAX_ATTEMPTS;

    -- Note that this does not throw the book offset away. Nothing keys off it
    -- alone -- every gate below wants both halves -- and keeping it is what lets
    -- `/dwmacro debug` distinguish "the book field was never found" from "the
    -- book field was found and the set field was not", which are the same
    -- silence from the outside and want completely different answers.
    local function giveUp(message)
        state.page = nil;

        if (final) then
            state.gaveUp = true;
            print(chat.header(addon.name):append(chat.error(message)));
            print(chat.header(addon.name):append(chat.message('Your macro palette is untouched; /macro book and /macro set work as normal.')));
        end
    end

    state.bookOffset = findBookOffset();

    if (state.bookOffset == nil) then
        state.scan = { error = 'no book field' };

        giveUp('Could not locate the macro book field in this client. Macro sets will not be remembered.');
        return;
    end

    local ok, result = pcall(measurePageField, obj, state.bookOffset);

    if (not ok or type(result) ~= 'table') then
        state.scan = { error = tostring(result) };

        giveUp('Could not read this client\'s macro palette. Macro sets will not be remembered.');
        return;
    end

    state.scan = { seeded = result.seeded, survivors = result.survivors, chosen = result.chosen };

    if (result.chosen == nil) then
        giveUp('Could not identify the macro set field in this client. Macro sets will not be remembered.');
        return;
    end

    state.page = result.chosen;
end

--[[
* Forget what the last few polls saw. Called whenever the palette is about to be
* moved by something that is not the player -- a zone line, a repair -- so that
* the reading taken before it can never be half of an agreeing pair with the one
* taken after.
--]]
local function forgetSeen()
    state.lastSeen = nil;
    state.agreed   = 0;
end

--[[
* Record the palette against the job currently being played -- both which book
* and set it is, and what the twenty records loaded there look like.
*
* The fingerprint is the half that matters after the next zone line, and it is
* taken HERE, while the player is sitting on their own choice playing normally,
* because that is the only moment the bar is known to be right. It also tracks
* macro edits for free: change a macro and the fingerprint moves within a poll
* or two, so what gets checked after the next zone is what the page actually
* looks like now rather than what it looked like when the set was first picked.
*
* A selection has to read the same RECORD_AGREE polls running before it is
* written down, fingerprint included. The palette is moved by the client and by
* this addon as well as by the player, and a single reading taken while it is in
* motion is not a choice; the settling window keeps the worst of that out (see
* `tick`) and this is the cheap guard against everything else.
--]]
local function record()
    local job = mainJob();

    if (job == 0) then
        forgetSeen();
        return;
    end

    local palette = readPalette();

    if (palette == nil) then
        forgetSeen();
        return;
    end

    local fp   = fingerprint(container());
    local seen = state.lastSeen;

    if (seen ~= nil and seen.job == job and seen.book == palette.book
        and seen.set == palette.set and seen.fp == fp) then
        state.agreed = state.agreed + 1;
    else
        state.agreed = 1;
    end

    state.lastSeen = { job = job, book = palette.book, set = palette.set, fp = fp };

    if (state.agreed < RECORD_AGREE) then
        return;
    end

    local known = config.jobs[job];

    if (known ~= nil and known.book == palette.book and known.set == palette.set and known.fp == fp) then
        return;
    end

    config.jobs[job] = T{ book = palette.book, set = palette.set, fp = fp };

    settings.save();
end

--[[
* Arm the watch. Called for the login packet, which the server sends both on a
* real login and on every zone line -- the two cases this addon exists for are
* the same packet.
*
* The clock starts when the player is next seen in the world, not here: the
* packet arrives while the zone screen is still up.
--]]
local function armRestore()
    state.armed     = true;
    state.zonedAt   = 0;
    state.nextCheck = 0;
    state.applies   = 0;
    state.nextApply = 0;
    state.appliedFp = nil;
    state.verified  = false;
    state.channel   = 'direct';
    state.trail     = nil;
    state.sentAt    = nil;
    state.bounced   = 0;

    forgetSeen();

    -- A zone line rebuilds the client's macro state, so if the palette still has
    -- not been measured this is a fresh chance at it -- and a better one than the
    -- frame that just failed. A fresh budget with it: the failure that matters is
    -- a client that cannot be read at all, not a login that was busy.
    if (not state.gaveUp and (state.bookOffset == nil or state.page == nil)) then
        state.attempts = 0;
        state.nextTry  = 0;
    end
end

--[[
* One look at the macro bar, and a repair if it is wrong. Returns whether the
* settling window is still open; while it is, recording is off (see `tick`).
*
* `apply` is the enabled flag, and it silences the repairs WITHOUT shortening
* the window. Turning the feature off does not stop the client losing the
* palette on a zone line, and this addon's promise while it is off is that the
* palette is still remembered so that turning it back on picks up where it left
* off -- which it would not, if the first thing recorded after every zone were
* the client's own Book 1, Set 1.
*
* NOTHING IN HERE FIRES ON A CLOCK. The window is a watch, not a schedule: the
* only thing that makes a repair happen is the bar being wrong, and the only
* thing that makes it stop is the bar being right. That is why the client's
* late rebuild -- six seconds after the party list went live, on the client
* this was diagnosed against -- is no longer something to be straddled by
* guesswork. It clobbers the palette, the next check sees the fingerprint move,
* and it is put back.
--]]
local function restoreWindow(now, apply)
    local since = now - state.zonedAt;

    if (since >= RECORD_HOLD) then
        return false;
    end

    if (not apply or now < state.nextCheck) then
        return true;
    end

    state.nextCheck = now + CHECK_INTERVAL;

    local job = mainJob();

    if (job == 0) then
        return true;
    end

    local wanted = config.jobs[job];

    -- Nothing remembered for this job is not a failure, it is the first time
    -- this job has been played. Leave the palette completely alone and let the
    -- recorder learn it once the window closes.
    if (wanted == nil or wanted.book == nil or wanted.set == nil) then
        state.trail = { job = job, skipped = 'nothing remembered for this job' };
        return true;
    end

    local obj = container();

    -- No container yet means the client has not built one, which is not the
    -- same as the bar being wrong. Wait; the window is long enough.
    if (obj == 0) then
        return true;
    end

    local fp = fingerprint(obj);

    -- The fingerprint the last repair left behind, sampled once it has had time
    -- to land. It is what stands in for a remembered fingerprint when there is
    -- none: it cannot say whether the bar is RIGHT, but it can say whether
    -- anything has moved it since, which is all that is needed to notice the
    -- client's late rebuild.
    if (state.applies > 0 and state.appliedFp == nil and now >= state.nextApply) then
        state.appliedFp = fp;
    end

    local target = wanted.fp or state.appliedFp;

    if (target ~= nil and fp ~= nil and fp == target) then
        if (wanted.fp ~= nil) then
            state.verified = true;
        end

        return true;
    end

    if (now < state.nextApply or state.applies >= MAX_APPLIES) then
        return true;
    end

    --[[
    * Which mechanism to repair with. Direct calls unless they cannot be
    * checked (no remembered fingerprint) or have been checked and found
    * wanting (DIRECT_TRIES repairs and the bar still has not come right). The
    * fallback is one-way for the rest of the window: a channel that has failed
    * twice is not worth going back to.
    --]]
    if (wanted.fp == nil or (state.applies >= DIRECT_TRIES and not state.verified)) then
        state.channel = 'text';
    end

    -- The watcher and the trail are armed BEFORE the send: the client answers a
    -- rejected command on its own schedule, and an answer that arrives before
    -- the bookkeeping exists would be neither swallowed nor counted. Only the
    -- typed channel can bounce, so only it arms the watcher.
    if (state.channel == 'text') then
        state.sentAt = now;
    end

    state.trail = {
        job     = job,
        wanted  = wanted,
        channel = state.channel,
        before  = (state.trail ~= nil and state.trail.before) or readPalette(),
    };

    state.trail.ok = applyPalette(wanted, state.channel);

    state.applies   = state.applies + 1;
    state.nextApply = now + APPLY_SETTLE;
    state.appliedFp = nil;

    -- The palette has just been moved by this addon, so nothing read across it
    -- is a choice the player made.
    forgetSeen();

    return true;
end

local function tick()
    -- Out of the world -- a zone screen, character select -- the palette is not
    -- the player's and the readings either side of the gap are not a pair.
    if (not inGame()) then
        forgetSeen();
        return;
    end

    ensureMeasured();

    local now = os.clock();

    --[[
    * The repair runs whether or not the measurement has succeeded. What to put
    * back comes from the settings file, and checking it needs only the record
    * block, whose layout comes from the client's own stride rather than from
    * anything measured. Gating the repair on the measurement meant a client
    * whose set field could not be found lost the book repair too, which needs
    * nothing measured at all, and lost it silently.
    --]]
    if (state.armed) then
        -- The clock starts on the first frame the player is actually in the
        -- world -- inGame() includes the client's own zoning flag, so "in the
        -- world" is the client's word for it, not the party list's.
        if (state.zonedAt == 0) then
            state.zonedAt = now;
        end

        -- Recording stays shut off for the whole window, so the client's
        -- post-zone default is never mistaken for a choice -- whether or not
        -- repairing is the thing putting it right.
        if (restoreWindow(now, config.enabled)) then
            return;
        end

        state.armed = false;

        -- Every repair has landed (or bounced); what the fields say now is the
        -- honest "after" for `/dwmacro debug`.
        if (state.trail ~= nil and state.trail.skipped == nil) then
            state.trail.after = readPalette();
        end
    end

    -- Recording, unlike repairing, has nothing without the measurement: it
    -- exists to READ what the player picked.
    if (state.bookOffset == nil or state.page == nil) then
        return;
    end

    if (now - state.lastPoll < POLL_INTERVAL) then
        return;
    end

    state.lastPoll = now;

    record();
end

--[[
* Everything above runs once a frame, which is the reason for the pcall: an
* error raised inside `d3d_present` is raised sixty times a second, and the
* addon host answers a long enough run of them by unloading the addon. One bad
* frame costs one line of chat and the feature, not the addon -- and the
* feature going quiet leaves a completely normal macro palette behind.
--]]
local failed = false;

ashita.events.register('d3d_present', 'dwmacro_present', function ()
    if (macrolib == nil or failed) then
        return;
    end

    local ok, err = pcall(tick);

    if (not ok) then
        failed = true;

        print(chat.header(addon.name):append(chat.error('Stopped after an error: ' .. tostring(err))));
        print(chat.header(addon.name):append(chat.message('Your macro palette is untouched; /macro book and /macro set work as normal.')));
    end
end);

--[[
* The login packet. The client's macro state does not survive it, and it is
* sent for a zone line as well as a login, so this one hook covers both cases.
--]]
ashita.events.register('packet_in', 'dwmacro_zonein', function (e)
    if (e.id == 0x000A) then
        armRestore();
    end
end);

--[[
* The bounce watcher, for the typed fallback only. A `/macro` command handed to
* a client that is not ready to take input comes back as one "A command error
* occurred." line per command, and nothing happens -- the repair never landed.
* Inside a short window after this addon's own send, that line is this addon's
* plumbing: it is swallowed so the player stops seeing unexplained errors, and
* counted so `/dwmacro debug` can tell a rejected repair from one that ran. No
* control flow hangs off it -- the next check was always going to notice.
*
* `sentAt` is only ever set by the typed channel, so while the direct calls are
* doing the work this handler is one nil-check deep and touches nothing: the
* player's own command errors remain the player's.
--]]
ashita.events.register('text_in', 'dwmacro_text_in', function (e)
    if (state.sentAt == nil or e.blocked) then
        return;
    end

    if (os.clock() - state.sentAt > BOUNCE_WINDOW) then
        state.sentAt = nil;
        return;
    end

    local line = e.message;

    if (type(line) ~= 'string') then
        return;
    end

    if (line:find('command error', 1, true) ~= nil) then
        e.blocked     = true;
        state.bounced = state.bounced + 1;

        if (state.trail ~= nil) then
            state.trail.bounced = (state.trail.bounced or 0) + 1;
        end
    end
end);

--[[
* What the measurement saw, and what the last zone line did. This exists because
* every way this addon can fail quietly looks identical from the outside -- no
* set field found, several found and none confirmed, the container never
* readable -- and they want different answers.
--]]
local function printDebug()
    print(chat.header(addon.name):append(chat.message(('macros lib: %s   container: 0x%08X'):fmt(macrolib ~= nil and 'loaded' or 'MISSING', container()))));
    print(chat.header(addon.name):append(chat.message(('book offset: %s   attempts: %d this zone, %d of %d this session'):fmt(
        state.bookOffset ~= nil and ('0x%04X'):fmt(state.bookOffset) or 'unknown',
        state.attempts, state.total, MEASURE_MAX_ATTEMPTS))));

    if (state.page ~= nil) then
        local obj = container();
        local raw = 'unreadable';

        if (obj ~= 0) then
            local ok, value = pcall(ashita.memory.read_uint8, obj + state.page.offset);

            if (ok) then
                raw = tostring(value);
            end
        end

        print(chat.header(addon.name):append(chat.message(('set field: 0x%04X (%+d from book), encoding %s, reads %s'):fmt(
            state.page.offset, state.page.offset - state.bookOffset, state.page.enc.name, raw))));
    else
        print(chat.header(addon.name):append(chat.message('set field: not identified')));
    end

    if (state.scan == nil) then
        print(chat.header(addon.name):append(chat.message('last scan: has not run yet')));
    elseif (state.scan.error ~= nil) then
        print(chat.header(addon.name):append(chat.message('last scan: failed -- ' .. state.scan.error)));
    else
        print(chat.header(addon.name):append(chat.message(('last scan: %d candidate(s) seeded, %d confirmed'):fmt(state.scan.seeded or 0, state.scan.survivors or 0))));
    end

    --[[
    * The bar, as opposed to what the client claims about it. `live` is what the
    * twenty loaded records hash to right now and `remembered` is what they
    * hashed to when the player was last sitting on their own choice; the two
    * agreeing is the addon's whole definition of "the palette is right", so it
    * is the first thing to look at when it is not.
    --]]
    local job        = mainJob();
    local remembered = (job ~= 0) and config.jobs[job] or nil;

    print(chat.header(addon.name):append(chat.message(('macro bar: live %s, remembered %s%s'):fmt(
        fingerprint(container()) or 'unreadable',
        (remembered ~= nil and remembered.fp) or 'nothing yet',
        state.verified and ' (matched this zone)' or ''))));

    --[[
    * What the last zone line did. A repair that ran and did not show up on
    * screen, a repair that never ran because nothing was remembered, and a zone
    * line the addon never noticed are three different faults that look
    * identical from the player's chair, so all three are named here.
    --]]
    if (state.trail == nil) then
        if (state.armed) then
            print(chat.header(addon.name):append(chat.message('last zone: settling, the bar has not needed putting back yet')));
        else
            print(chat.header(addon.name):append(chat.message('last zone: nothing needed putting back')));
        end
    elseif (state.trail.skipped ~= nil) then
        print(chat.header(addon.name):append(chat.message(('last zone: left alone -- %s'):fmt(state.trail.skipped))));
    else
        print(chat.header(addon.name):append(chat.message(('last zone: put back %s via %s calls (read %s before, %s after, queueing %s, %d command(s) bounced)'):fmt(
            describe(state.trail.wanted),
            state.trail.channel == 'text' and '/macro command' or 'setBook/setPage',
            describe(state.trail.before),
            describe(state.trail.after),
            state.trail.ok and 'ok' or 'FAILED',
            state.bounced))));
        print(chat.header(addon.name):append(chat.message(('%d of %d repair(s) used; the before/after reads are the container fields, which lie after a zone -- the macro bar line above is the one that counts.'):fmt(state.applies, MAX_APPLIES))));
    end
end

ashita.events.register('command', 'dwmacro_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwmacro' and args[1] ~= '/macro')) then
        return;
    end

    local verb = (#args > 1) and args[2]:lower() or 'status';

    --[[
    * /macro IS A RETAIL CLIENT COMMAND, and this addon's whole contract is
    * that `/macro book <n>` and `/macro set <n>` keep working exactly as they
    * always did (see the header). So the alias only claims the verbs dwmacro
    * itself owns and hands anything else straight back to the client --
    * blocking an unknown verb here would eat a client feature this addon has
    * promised not to touch. `debug` is deliberately not on that list; it is a
    * /dwmacro verb only.
    --]]
    if (args[1] == '/macro' and verb ~= 'status' and verb ~= 'on' and verb ~= 'off' and verb ~= 'forget') then
        return;
    end

    e.blocked = true;

    if (verb == 'on' or verb == 'off') then
        config.enabled = (verb == 'on');
        settings.save();

        print(chat.header(addon.name):append(chat.message('Putting your palette back is now ')):append(chat.success(verb)):append(chat.message('.')));
        return;
    end

    if (verb == 'forget') then
        config.jobs = T{ };
        settings.save();

        print(chat.header(addon.name):append(chat.message('Forgot every remembered macro book and set.')));
        return;
    end

    if (verb == 'debug') then
        printDebug();
        return;
    end

    -- Status. Says what it measured as well as what it remembers, because
    -- "nothing happens" has two causes and they need different answers.
    if (macrolib == nil) then
        print(chat.header(addon.name):append(chat.error("Ashita's macro library did not load; nothing is being remembered.")));
        return;
    end

    if (failed) then
        print(chat.header(addon.name):append(chat.error('Stopped after an error earlier this session; nothing is being remembered. Reload with /addon reload dwmacro.')));
        return;
    end

    if (state.bookOffset == nil or state.page == nil) then
        if (state.gaveUp) then
            print(chat.header(addon.name):append(chat.error('Could not read this client\'s macro palette; nothing is being remembered.')));
            print(chat.header(addon.name):append(chat.message('/dwmacro debug says what it saw.')));
        else
            print(chat.header(addon.name):append(chat.message(('Still reading the macro palette (%d attempt(s) so far). It tries again after each zone line.'):fmt(state.total))));
        end

        return;
    end

    local job     = mainJob();
    local current = readPalette();

    print(chat.header(addon.name):append(chat.message('Putting your palette back is ')):append(chat.success(config.enabled and 'on' or 'off')):append(chat.message('. Currently on ' .. describe(current) .. '.')));

    local remembered = (job ~= 0) and config.jobs[job] or nil;

    if (remembered ~= nil and remembered.book ~= nil and remembered.set ~= nil) then
        print(chat.header(addon.name):append(chat.message('Remembered for this job: ' .. describe(remembered) .. '.')));
    else
        print(chat.header(addon.name):append(chat.message('Nothing remembered for this job yet.')));
    end
end);

ashita.events.register('load', 'dwmacro_load', function ()
    if (macrolib == nil) then
        print(chat.header(addon.name):append(chat.error("Ashita's macro library did not load on this client build; macro sets will not be remembered.")));
        return;
    end

    print(chat.header(addon.name):append(chat.message('Your macro book and set are remembered per job and put back when the client loses them. /dwmacro (or plain /macro) for status.')));
end);

ashita.events.register('unload', 'dwmacro_unload', function ()
    settings.save();
end);
