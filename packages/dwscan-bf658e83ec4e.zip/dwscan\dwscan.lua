--[[
* DriftwoodXI -- dwscan
*
* Everything the server knows about the thing you are looking at, in one
* window, one click away. Level and the con it wears for you, the spawn band
* it rolls inside, what it drops and how often -- at THIS server's rates, with
* the icons -- what magic it resists and what it is simply immune to, how far
* away it notices you and by what sense, what it pays in exp and gil, its TP
* moves by name, and which of your quests want it dead.
*
* THE NUMBERS HERE ARE NOT THE WIKI'S, AND THAT IS THE POINT. DriftwoodXI
* doubles drop rates, triples exp, halves aggro bubbles and link radii, and
* runs its own con curve. Every figure in this window is read off the running
* server, through the same code that rolls the loot -- so it is the only place
* those numbers are true. Every one of them was computed server-side: this
* addon does no arithmetic on anything it is told (dwn_protocol.md client
* discipline 2 -- if the window computes a number, it is a bug).
*
* IT ASKS ONLY WHEN YOU ASK. There is no polling, no tick and no server push.
* Scan is a button and `/dwscan` is a window; a scan is one chat line, and the
* client rate-limits those. A scan on a timer would be a line per tick and a
* server answer nobody read.
*
* WHAT IT WILL NOT TELL YOU. The server refuses to gauge notorious monsters,
* battlefield mobs and anything flagged CheckAsNm -- exactly as `/check` does
* -- so their level and difficulty arrive withheld and this window says so
* rather than inventing them. The quest list is what the server's own
* interaction index holds for this mob: things that want it DEAD. It is not a
* claim that nothing else wants it.
*
* TURN IT OFF AND NOTHING IS LOST. `!scan` works typed, on whatever you have
* selected, and says the same things in sentences. This is friendlier; it is
* not required.
--]]

addon.name    = 'dwscan';
addon.author  = 'DriftwoodXI';
addon.version = '1.1.4';
addon.desc    = 'Scan your target: level, drops with this server\'s real rates, resistances, aggro and quests.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the `!dwn` lines sent below; installed
-- before any other text_in handler in this file (dwecho.lua). Without it the
-- player reads `Blaster : !dwn scan 42` in their own log on every scan.
echo.install();

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load.
*
* This addon is loaded from the launcher's boot script, which runs long before
* the client has a rendering device -- and `d3d.get_device()` at file scope
* makes the whole addon fail to load when it answers nothing (the dwbags
* lesson). Nothing here needs a device until the first item icon is drawn.
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; the fifteenth `_DW*DATA` name,
-- and nothing else on the server uses it, so matching it exactly is a safe
-- filter.
local DATA_SENDER = '_DWNDATA';

-- Protocol version the server announces in its `d|` record. An unknown one is
-- HARD REFUSED (one message, then silence) rather than guessed at: a scan
-- rendered from a record layout this addon does not understand is a confident
-- lie about how dangerous something is, which is worse than no scan at all.
local PROTOCOL = 1;

-- The server withholds a field by sending -1. Rendering that as a number would
-- be the window stating something the server refused to state.
local WITHHELD = -1;

--[[
* Element order on the `r|` record, and the two pseudo-elements the physical
* lanes ride on. Index is the wire's element id.
--]]
local ELEMENTS = {
    [1] = { name = 'Fire',      r = 236, g = 98,  b = 62  },
    [2] = { name = 'Ice',       r = 132, g = 214, b = 236 },
    [3] = { name = 'Wind',      r = 126, g = 214, b = 152 },
    [4] = { name = 'Earth',     r = 197, g = 160, b = 96  },
    [5] = { name = 'Lightning', r = 190, g = 138, b = 236 },
    [6] = { name = 'Water',     r = 96,  g = 156, b = 236 },
    [7] = { name = 'Light',     r = 240, g = 236, b = 208 },
    [8] = { name = 'Dark',      r = 168, g = 140, b = 190 },
};

local ELEMENT_ORDER = { 1, 2, 3, 4, 5, 6, 7, 8 };

--[[
* Con tiers, the dwcon palette, so the two windows cannot disagree about what
* a colour means. Tier 1 is absent on purpose: the DriftwoodXI curve retires
* Incredibly Easy Prey, so a row for it is a legend nobody can ever see.
--]]
local TIERS = {
    [0] = { short = 'Too Weak',         r = 150, g = 150, b = 150 },
    [2] = { short = 'Easy Prey',        r = 60,  g = 180, b = 75  },
    [3] = { short = 'Decent Challenge', r = 240, g = 200, b = 40  },
    [4] = { short = 'Even Match',       r = 245, g = 130, b = 32  },
    [5] = { short = 'Tough',            r = 220, g = 50,  b = 47  },
    [6] = { short = 'Very Tough',       r = 230, g = 60,  b = 230 },
    [7] = { short = 'Incredibly Tough', r = 120, g = 50,  b = 200 },
};

-- `h|` flag bits.
local FLAG_GAUGED      = 1;
local FLAG_NM          = 2;
local FLAG_UNDEAD      = 4;
local FLAG_BATTLEFIELD = 8;
local FLAG_ALIVE       = 16;

-- `a|` detection bits, the server's own xi.detects.
local DETECTS = {
    { bit = 0x0001, name = 'sight' },
    { bit = 0x0002, name = 'sound' },
    { bit = 0x0004, name = 'low HP' },
    { bit = 0x0020, name = 'magic' },
    { bit = 0x0040, name = 'job abilities' },
    { bit = 0x0100, name = 'scent' },
};

-- `a|` spawn-type bits, the server's own xi.spawnType.
local SPAWN_TYPES = {
    { bit = 0x0001, name = 'at night' },
    { bit = 0x0002, name = 'evenings' },
    { bit = 0x0004, name = 'in weather' },
    { bit = 0x0008, name = 'in fog' },
    { bit = 0x0010, name = 'on a moon phase' },
    { bit = 0x0020, name = 'lottery' },
    { bit = 0x0040, name = 'on a window' },
    { bit = 0x0080, name = 'scripted' },
};

--[[
* Persisted presentation state, through Ashita's settings library (the dwport
* shape). Flat scalars only -- the settings serializer takes booleans, numbers
* and strings, and a nested table here would be a silent loss on save.
--]]
local defaultConfig = T{
    icons     = true,      -- draw item icons beside drop rows
    autoScan  = false,     -- re-scan when the target changes, window open only
    minRate   = 0.0,       -- hide drops under this percent
    thLevel   = 0,         -- Treasure Hunter level scans are asked at; sticky across targets
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

pcall(settings.register, 'settings', 'dwscan_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end
end);

--[[
* ImGui widget holders. Every ImGui input wants a table it can write into, so
* the window edits these and copies back into `config` on the frame the widget
* reports a change. Keeping the two apart is what lets `config` stay flat
* scalars for the serializer.
--]]
local ui = {
    icons    = T{ config.icons    ~= false },
    autoScan = T{ config.autoScan == true  },
    minRate  = T{ config.minRate  or 0.0   },
    thLevel  = T{ config.thLevel  or 0     },
};

local function commit()
    config.icons    = ui.icons[1];
    config.autoScan = ui.autoScan[1];
    config.minRate  = ui.minRate[1];
    config.thLevel  = ui.thLevel[1];

    pcall(settings.save);
end

--[[
* Session state.
*
* Everything under `scan` is REPLACED wholesale by an answer, never merged, so
* a row from the last mob cannot survive into this one's table. `targid` is the
* identity of what is being shown; a window still holding it after a zone line
* is describing a stranger, which is why the zone handler clears it.
--]]
local state = {
    open     = T{ false },

    scan     = nil,        -- the finished answer being rendered
    building = nil,        -- the answer currently arriving

    inbound  = nil,        -- the verb of the envelope currently open
    refused  = false,      -- an unknown protocol version was seen; stay silent
    spoke    = false,      -- a d| has arrived this session
    helloed  = false,      -- the blind handshake has already gone out
    reported = false,      -- a render error has already been reported once

    status    = 'Select a monster and press Scan.',
    statusBad = false,

    asked     = nil,       -- targid of the scan we are waiting on
    askedAt   = 0,
    tries     = 0,
    lastAuto  = nil,       -- targid the auto-scan last fired for

    -- A scan asked for before the server had spoken. Held rather than sent, and
    -- released by pumpPending on the first `d|` -- see requestScan.
    pending   = nil,
    pendingAt = 0,
};

--[[
* Outbound: one line per 1.2s with duplicate collapse -- the client rate-limits
* chat and a `!dwn` command IS a chat line. `readyAt` holds the queue shut for a
* moment after a zone line so a scan is not the first thing sent into a
* half-built zone.
--]]
local SEND_INTERVAL  = 1.2;
local ZONE_SETTLE    = 3.0;
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local queue    = T{ };
local lastSend = 0;
local readyAt  = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now < readyAt or now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* The handshake. This is the ONE line the addon sends blind, and it is sent on
* window open rather than on load: an unknown `!command` falls through to
* ordinary /say, so an automatic hello against a server without the module is
* the player publicly saying "!dwn hello".
--]]
local function hello()
    -- LATCHED, because `issue`'s duplicate collapse only sees what is still IN
    -- the queue: a hello that has already been sent and popped would be sent
    -- again by the next caller. This is the one line the addon puts on the wire
    -- blind, so sending it twice is twice the cost of the only thing that can
    -- cost anything. Cleared on the zone line, where the server's per-session
    -- state dies and a fresh handshake is owed.
    if (state.helloed) then
        return;
    end

    state.helloed = true;

    issue('!dwn hello');
end

--[[
* Record parsing. Every record is pipe-separated with a single-character kind.
* Anything this addon does not recognise falls off the end of the chain rather
* than being an error: a server newer than the addon must not break it, which
* is the whole reason the `d|` record carries a version at all. Additive record
* kinds therefore never bump PROTOCOL.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function num(text, fallback)
    return tonumber(text or '') or fallback or 0;
end

local function blank()
    return {
        targid  = nil,
        name    = '?',
        level   = WITHHELD,
        lo      = WITHHELD,
        hi      = WITHHELD,
        con     = WITHHELD,
        flags   = 0,
        maxhp   = 0,
        maxmp   = 0,

        familyId = 0,
        ecoId    = 0,
        crystal  = 0,
        eco      = '',
        family   = '',

        detects    = 0,
        sight      = 0,
        sound      = 0,
        magic      = 0,
        aggro      = 0,
        link       = 0,
        linkRadius = 0,
        trueDetect = 0,
        respawn    = 0,
        spawnType  = 0,

        exp     = WITHHELD,
        gilMin  = 0,
        gilMax  = 0,
        shown   = 0,
        total   = 0,
        mult    = 100,
        th      = 0,       -- the TH level the server says it computed the rates at

        -- PLAIN tables keyed by data. T{}'s sugar method names would shadow a
        -- key, which is the dwbags trap.
        resists = {},
        physical = {},
        immunities = {},
        drops   = {},
        skills  = {},
        quests  = {},
        notes   = {},
    };
end

local function applyIdentity(b, parts)
    -- tonumber directly, NOT num(..., nil): `x or nil or 0` collapses to
    -- `x or 0`, so num can never actually answer nil -- and 0 slips past the
    -- `targid ~= nil` re-scan guard as if it named a mob.
    b.targid = tonumber(parts[2] or '');
    b.level  = num(parts[3], WITHHELD);
    b.lo     = num(parts[4], WITHHELD);
    b.hi     = num(parts[5], WITHHELD);
    b.con    = num(parts[6], WITHHELD);
    b.flags  = num(parts[7], 0);
    b.maxhp  = num(parts[8], 0);
    b.maxmp  = num(parts[9], 0);
    b.name   = parts[10] or '?';
end

local function applyTaxonomy(b, parts)
    b.familyId = num(parts[2], 0);
    b.ecoId    = num(parts[3], 0);
    b.crystal  = num(parts[4], 0);
    b.eco      = parts[5] or '';
    b.family   = parts[6] or '';
end

local function applyAwareness(b, parts)
    b.detects    = num(parts[2], 0);
    b.sight      = num(parts[3], 0);
    b.sound      = num(parts[4], 0);
    b.magic      = num(parts[5], 0);
    b.aggro      = num(parts[6], 0);
    b.link       = num(parts[7], 0);
    b.linkRadius = num(parts[8], 0);
    b.trueDetect = num(parts[9], 0);
    b.respawn    = num(parts[10], 0);
    b.spawnType  = num(parts[11], 0);
end

local function applyYield(b, parts)
    b.exp    = num(parts[2], WITHHELD);
    b.gilMin = num(parts[3], 0);
    b.gilMax = num(parts[4], 0);
    b.shown  = num(parts[5], 0);
    b.total  = num(parts[6], 0);
    b.mult   = num(parts[7], 100);

    -- The TH level the server COMPUTED at, which is the only number the label
    -- may state. A server from before this field (or one that ignored the
    -- argument) reads as 0 here, and the window then says TH 0 no matter what
    -- the dropdown asked for -- honest rather than flattering.
    b.th     = num(parts[8], 0);
end

--[[
* `r|` carries `<element>:<sdt>:<rank>` entries. Element 0 and 9 are the
* physical lanes rather than elements -- 0 is slash/pierce and 9 is
* hand-to-hand/impact -- so they are kept apart from the eight rather than
* being drawn as if they had a resistance rank they do not have.
--]]
local function applyResists(b, packed)
    for _, entry in ipairs(split(packed or '', ',')) do
        if (entry ~= '') then
            local bits    = split(entry, ':');
            local element = num(bits[1], -1);
            local sdt     = num(bits[2], 0);
            local rank    = num(bits[3], 0);

            if (element == 0) then
                b.physical.slash  = sdt;
                b.physical.pierce = rank;
            elseif (element == 9) then
                b.physical.hth    = sdt;
                b.physical.impact = rank;
            elseif (ELEMENTS[element] ~= nil) then
                b.resists[element] = { sdt = sdt, rank = rank };
            end
        end
    end
end

local function applyImmunities(b, packed)
    for _, entry in ipairs(split(packed or '', ',')) do
        if (entry ~= '') then
            b.immunities[#b.immunities + 1] = entry;
        end
    end
end

local function applyDrops(b, packed)
    for _, entry in ipairs(split(packed or '', ',')) do
        if (entry ~= '') then
            local bits = split(entry, ':');

            b.drops[#b.drops + 1] = {
                itemid = num(bits[1], 0),
                kind   = bits[2] or 'n',
                rate   = num(bits[3], 0),
                group  = num(bits[4], 0),
            };
        end
    end
end

local function applySkills(b, packed)
    for _, entry in ipairs(split(packed or '', ',')) do
        if (entry ~= '') then
            b.skills[#b.skills + 1] = entry;
        end
    end
end

local function applyQuest(b, parts)
    b.quests[#b.quests + 1] = {
        kind  = parts[2] or 'q',
        area  = num(parts[3], 0),
        id    = num(parts[4], 0),
        state = parts[5] or '-',
        name  = parts[6] or '?',
    };
end

local function handleRecord(line)
    -- A refusal is silence. The packets are still blocked (that happens before
    -- this function is reached), so a mismatched server cannot spill records
    -- into the chat log either.
    if (state.refused) then
        return;
    end

    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.refused   = true;
            state.inbound   = nil;
            state.building  = nil;
            state.status    = 'This server speaks a scan protocol this addon does not.';
            state.statusBad = true;

            print(chat.header('dwscan'):append(chat.error(string.format(
                'server scan protocol %d, addon expects %d. Update dwscan through the launcher.',
                version, PROTOCOL))));

            return;
        end

        state.spoke   = true;
        state.inbound = parts[3];

        -- A scan replaces the whole model, and the reset runs FIRST: this
        -- function is called under a pcall, and a throw after `inbound` is set
        -- must cost one record rather than leave half of the last mob's answer
        -- in place for the records behind it to merge into.
        if (state.inbound == 'scan') then
            state.building = blank();
        end

        return;
    end

    -- Records outside an envelope are not ours to act on.
    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        if (state.inbound == 'scan' and state.building ~= nil) then
            state.scan      = state.building;
            state.building  = nil;
            state.asked     = nil;
            state.status    = '';
            state.statusBad = false;
        end

        state.inbound = nil;

        return;
    end

    -- `m|` and `e|` may arrive anywhere, including in a `status` envelope of
    -- their own when the refusal was raised before a scan ever opened.
    if (kind == 'm') then
        if (state.building ~= nil) then
            state.building.notes[#state.building.notes + 1] = parts[2] or '';
        else
            state.status    = parts[2] or '';
            state.statusBad = false;
        end

        return;
    end

    if (kind == 'e') then
        state.status    = parts[2] or 'The server refused.';
        state.statusBad = true;
        state.asked     = nil;

        return;
    end

    if (kind == 'f') then
        -- Capabilities. A section whose binding is missing is greyed with the
        -- reason rather than drawn empty, so "the server cannot answer this"
        -- never looks like "there is nothing here".
        state.caps = {
            drops  = num(parts[2], 0) == 1,
            facts  = num(parts[3], 0) == 1,
            quests = num(parts[4], 0) == 1,

            -- The highest TH tier the server's bracket table holds. The
            -- dropdown is built from THIS, never from a local copy of the
            -- table -- a retune server-side resizes the dropdown by itself.
            -- 0 from an older server collapses the dropdown to TH 0, which is
            -- the only level that server can answer anyway.
            maxth  = num(parts[5], 0),
        };

        return;
    end

    local b = state.building;

    if (b == nil) then
        return;
    end

    if     (kind == 'h') then applyIdentity(b, parts);
    elseif (kind == 't') then applyTaxonomy(b, parts);
    elseif (kind == 'a') then applyAwareness(b, parts);
    elseif (kind == 'y') then applyYield(b, parts);
    elseif (kind == 'r') then applyResists(b, parts[2]);
    elseif (kind == 'x') then applyImmunities(b, parts[2]);
    elseif (kind == 'p') then applyDrops(b, parts[2]);
    elseif (kind == 'k') then applySkills(b, parts[2]);
    elseif (kind == 'q') then applyQuest(b, parts);
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017.
*
* Layout after the 4-byte header: Kind at 0x04, Attr at 0x05, Data at 0x06,
* sName[15] at 0x08, Mes at 0x17. Any line whose sender is _DWNDATA is ours.
*
* The addon owns the line WHATEVER happens to be in it, so it is blocked before
* parsing rather than after: a malformed record must not leak into the chat log
* as noise, and a record that throws must not leak either.
--]]
ashita.events.register('packet_in', 'dwscan_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwscan'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* A zone line is a new entity table: every targid means a different mob, or
* nothing. The answer on screen is about a stranger now, so it goes.
*
* The refusal latch is cleared here too. A map restart logs everyone out, so
* the server on the other side of a zone line may well be the updated one.
--]]
ashita.events.register('packet_in', 'dwscan_zonein', function (e)
    if (e.id ~= 0x000A) then
        return;
    end

    state.scan      = nil;
    state.building  = nil;
    state.inbound   = nil;
    state.refused   = false;
    state.asked     = nil;
    state.pending   = nil;
    state.helloed   = false;
    state.lastAuto  = nil;
    state.status    = 'Select a monster and press Scan.';
    state.statusBad = false;

    -- AND THE OUTBOUND QUEUE, which the reset above forgot. Every line this
    -- addon queues is targid-scoped, and a targid means nothing across a zone
    -- line -- so a scan queued just before zoning fired into the new zone and
    -- asked about whatever now happens to hold that number. Drained in place
    -- rather than reassigned: issue() and pumpQueue close over this upvalue.
    -- Dropping a queued `!dwn hello` is safe and self-healing; helloed was
    -- just set false above, so the next request re-issues it.
    while (#queue > 0) do
        table.remove(queue);
    end

    readyAt = os.clock() + ZONE_SETTLE;
end);

--[[
* The client's current target, as a targid.
*
* Ashita's entity index IS the server targid, which is what makes a scan
* addressable at all: the client already knows the number the server will
* resolve. Index 0 is "nothing selected" and no mob is ever index 0.
--]]
local function currentTarget()
    local memory = AshitaCore:GetMemoryManager();

    if (memory == nil) then
        return 0;
    end

    local target = memory:GetTarget();

    if (target == nil or target:GetIsActive(0) == 0) then
        return 0;
    end

    return target:GetTargetIndex(0);
end

local function targetName(index)
    if (index == nil or index == 0) then
        return nil;
    end

    local memory = AshitaCore:GetMemoryManager();
    local entity = memory ~= nil and memory:GetEntity() or nil;

    if (entity == nil) then
        return nil;
    end

    local name = entity:GetName(index);

    if (name == nil or name == '') then
        return nil;
    end

    return name;
end

--[[
* Ask. Every click issues a line a player could type, and the server re-resolves
* the targid in its own zone whichever way the command arrived -- so a bug in
* this window cannot make it answer about anything `!scan` would refuse.
--]]
local function requestScan(targid)
    if (state.refused) then
        return;
    end

    if (targid == nil or targid == 0) then
        state.status    = 'Select a monster first.';
        state.statusBad = true;

        return;
    end

    --[[
    * NOT SENT UNTIL THE SERVER HAS SPOKEN, and the scan is HELD rather than
    * dropped so the happy path is unchanged.
    *
    * `hello` is the one line this addon is sanctioned to send blind. Everything
    * else waits for a `d|`, because an unknown `!command` falls through to
    * ordinary /say (0x0b5_chat_std.cpp:121) -- so on a server whose dwn.lua is
    * absent, a launcher release that landed ahead of a server deploy, or any
    * non-Driftwood server the boot script loaded this into, an ungated scan is
    * the player publicly saying "!dwn scan 4242" to the whole zone. Worse, they
    * never see it: dwecho blocks the local echo of our own lines, so the only
    * thing on their screen is "The server did not answer."
    *
    * Holding it costs one round trip on the very first scan of a session and
    * nothing afterwards -- and it is the rule dwn_protocol.md's client
    * discipline 1 states, which pumpAutoScan already honours and this path did
    * not.
    --]]
    if (not state.spoke) then
        state.pending   = targid;
        state.pendingAt = os.clock();
        state.status    = 'Waiting for the server...';
        state.statusBad = false;

        hello();

        return;
    end

    state.pending   = nil;
    state.asked     = targid;
    state.askedAt   = os.clock();
    state.tries     = 1;
    state.status    = 'Scanning...';
    state.statusBad = false;

    -- The TH level rides the QUESTION, because the server owns the arithmetic:
    -- this addon never rescales a rate, it asks for the table at a different
    -- level and renders what comes back (client discipline 2). The server
    -- clamps it against its own bracket table.
    --
    -- A scan of the CURRENT target rides the cursor path (`scan 0`), which
    -- the server deliberately leaves ungated: a mob that died while still
    -- selected keeps answering (its alive bit going dark is a real thing to
    -- be told, and the by-id path refuses before the 'dead' mark can ever be
    -- seen), and the by-id path refuses past 50 yalms with "...or just
    -- target it" -- advice that is useless when the thing IS targeted. An
    -- explicit id is kept for everything else.
    local wireId = (targid == currentTarget()) and 0 or targid;

    issue(string.format('!dwn scan %d %d', wireId, config.thLevel or 0));
end

--[[
* Answer tracking: ask once, retry once on a 5s silence, then stop and say so.
* A retry that never terminates is a command loop, and this one is a chat line
* per attempt.
--]]
local function pumpAnswer()
    if (state.asked == nil) then
        return;
    end

    -- A held send (zone-in) leaves the line queued; aging the answer clock
    -- against it would be a false timeout, and after ANSWER_TRIES a false
    -- "The server did not answer." (dwecho canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local waited = os.clock() - state.askedAt;

    if (waited < ANSWER_TIMEOUT) then
        return;
    end

    if (state.tries >= ANSWER_TRIES) then
        state.asked = nil;

        if (not state.spoke) then
            state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
            state.statusBad = true;
        else
            state.status    = 'No answer. Try again.';
            state.statusBad = true;
        end

        return;
    end

    state.tries   = state.tries + 1;
    state.askedAt = os.clock();

    -- Same cursor-path election as requestScan.
    local wireId = (state.asked == currentTarget()) and 0 or state.asked;

    issue(string.format('!dwn scan %d %d', wireId, config.thLevel or 0));
end

--[[
* Release a scan that was asked for before the server had spoken.
*
* It terminates in both directions, which is the only thing that makes holding
* it safe: the first `d|` sends it, and a hello that is never answered gives up
* after the same 5s the answer tracker uses and says so. A pending scan that
* could sit forever would be a window stuck on "Waiting for the server..." with
* no way out but a reload.
--]]
local function pumpPending()
    if (state.pending == nil) then
        return;
    end

    if (state.refused) then
        state.pending = nil;

        return;
    end

    if (state.spoke) then
        local targid = state.pending;

        state.pending = nil;

        requestScan(targid);

        return;
    end

    -- While a send is held (zone-in) the hello cannot go out, so measure the
    -- give-up from when a line can actually be sent rather than from the queued
    -- ask -- there is no retry here to re-stamp it. (dwecho canSend; 2026-08-15.)
    if (not echo.canSend()) then
        state.pendingAt = os.clock();
    elseif (os.clock() - state.pendingAt >= ANSWER_TIMEOUT) then
        state.pending   = nil;
        state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
        state.statusBad = true;
    end
end

--[[
* Item names and icons come out of the CLIENT's own resources, which is why no
* item name is ever on the wire: the server's `item_basic.name` is the internal
* snake_case form, and the client already holds the real one -- and the icon.
--]]
local icons = T{ };

local function itemName(itemId)
    local item = AshitaCore:GetResourceManager():GetItemById(itemId);

    if (item == nil or item.Name[1] == nil or item.Name[1]:len() == 0) then
        return string.format('item %d', itemId);
    end

    return item.Name[1];
end

--[[
* Cached, because a drop table is forty rows redrawn every frame and
* D3DXCreateTextureFromFileInMemoryEx is not free. gc_safe_release hands back a
* texture that releases itself when Lua collects it, which is what keeps this
* from leaking across a reload. (The dwbags implementation, unchanged.)
--]]
local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);

    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* Rendering helpers.
--]]
local function colorOf(entry, alpha)
    return { entry.r / 255, entry.g / 255, entry.b / 255, alpha or 1.0 };
end

local function hasFlag(scan, flag)
    return bit.band(scan.flags, flag) == flag;
end

-- The server sent hundredths of a percent. Dividing by 100 to print it is
-- formatting, not arithmetic on the answer.
local function ratePercent(rate)
    return rate / 100.0;
end

local function bitList(value, table_, joiner)
    local names = {};

    for _, entry in ipairs(table_) do
        if (bit.band(value, entry.bit) == entry.bit) then
            names[#names + 1] = entry.name;
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, joiner or ', ');
end

--[[
* SDT reads as a damage multiplier and its sign runs one way; the resistance
* rank reads as a magic-evasion tier and its sign runs the OTHER way. They are
* rendered as separate columns with separate words for exactly that reason --
* one scale over both would be backwards for one of them, confidently.
--]]
local function sdtWord(sdt)
    if (sdt <= -5000) then return 'halves it or better', theme.colors.ok;   end
    if (sdt <= -1000) then return 'resists',             theme.colors.ok;   end
    if (sdt <   0)    then return 'shrugs slightly',     theme.colors.dim;  end
    if (sdt ==  0)    then return 'neutral',             theme.colors.dim;  end
    if (sdt <  1000)  then return 'slightly weak',       theme.colors.warn; end
    if (sdt <  5000)  then return 'weak',                theme.colors.warn; end

    return 'very weak', theme.colors.err;
end

local function rankWord(rank)
    if (rank >= 11) then return 'always resists', theme.colors.err;  end
    if (rank >= 5)  then return 'very hard',      theme.colors.err;  end
    if (rank >= 1)  then return 'hard',           theme.colors.warn; end
    if (rank == 0)  then return 'normal',         theme.colors.dim;  end

    return 'easy', theme.colors.ok;
end

local function secondsWord(seconds)
    if (seconds <= 0) then
        return 'not on a timer';
    end

    if (seconds < 60) then
        return string.format('%d sec', seconds);
    end

    if (seconds < 3600) then
        return string.format('%d min %d sec', math.floor(seconds / 60), seconds % 60);
    end

    return string.format('%.1f hours', seconds / 3600);
end

--[[
* Tabs.
--]]
local function tabOverview(scan)
    if (hasFlag(scan, FLAG_GAUGED)) then
        local tier = TIERS[scan.con];

        if (tier ~= nil) then
            imgui.TextColored(colorOf(tier), tier.short);
        else
            -- A tier from a server newer than this addon. Say the number rather
            -- than falling back to one we do know, which would be a lie with a
            -- colour on it.
            imgui.TextColored(theme.colors.warn, string.format('difficulty %d', scan.con));
        end

        imgui.SameLine();
        imgui.Text(string.format('-- level %d', scan.level));

        if (scan.lo >= 0 and scan.hi >= 0 and scan.lo ~= scan.hi) then
            imgui.SameLine();
            imgui.TextDisabled(string.format('(this one spawns %d-%d)', scan.lo, scan.hi));
        end
    else
        imgui.TextColored(theme.colors.warn, 'Impossible to gauge.');
        imgui.TextDisabled('The game withholds the level and the difficulty for notorious monsters and');
        imgui.TextDisabled('battlefield mobs, so this window does not guess at them either.');
    end

    imgui.Separator();

    imgui.Text(string.format('%d HP', scan.maxhp));

    if (scan.maxmp > 0) then
        imgui.SameLine();
        imgui.Text(string.format('/ %d MP', scan.maxmp));
    end

    if (scan.family ~= '') then
        imgui.SameLine();
        imgui.TextDisabled(string.format('-- %s, %s', scan.family, scan.eco));
    end

    local marks = {};

    if (hasFlag(scan, FLAG_NM))          then marks[#marks + 1] = 'notorious';   end
    if (hasFlag(scan, FLAG_UNDEAD))      then marks[#marks + 1] = 'undead';      end
    if (hasFlag(scan, FLAG_BATTLEFIELD)) then marks[#marks + 1] = 'battlefield'; end
    if (not hasFlag(scan, FLAG_ALIVE))   then marks[#marks + 1] = 'dead';        end

    if (#marks > 0) then
        imgui.TextDisabled(table.concat(marks, ', '));
    end

    imgui.Separator();

    if (scan.exp ~= WITHHELD) then
        imgui.Text(string.format('%d exp', scan.exp));
        imgui.SameLine();
        imgui.TextDisabled('solo, no chain or signet');
    else
        imgui.TextDisabled('Experience withheld with the rest of the gauge.');
    end

    if (scan.gilMax > 0) then
        if (scan.gilMin == scan.gilMax) then
            imgui.Text(string.format('%d gil', scan.gilMin));
        else
            imgui.Text(string.format('%d-%d gil', scan.gilMin, scan.gilMax));
        end
    else
        imgui.TextDisabled('No gil.');
    end

    imgui.Separator();
    imgui.Text('How it notices you');

    local senses = bitList(scan.detects, DETECTS, ', ');

    if (scan.aggro == 0) then
        imgui.TextColored(theme.colors.ok, 'Never aggressive -- it will not start a fight.');
    elseif (senses == nil) then
        imgui.TextDisabled('Aggressive, but by no sense this addon knows.');
    else
        imgui.TextColored(theme.colors.warn, string.format('Aggressive by %s.', senses));
    end

    local ranges = {};

    if (scan.sight > 0 and bit.band(scan.detects, 0x0001) ~= 0) then
        ranges[#ranges + 1] = string.format('sight %d', scan.sight);
    end

    if (scan.sound > 0 and bit.band(scan.detects, 0x0002) ~= 0) then
        ranges[#ranges + 1] = string.format('sound %d', scan.sound);
    end

    if (scan.magic > 0 and bit.band(scan.detects, 0x0020) ~= 0) then
        ranges[#ranges + 1] = string.format('magic %d', scan.magic);
    end

    if (#ranges > 0) then
        imgui.TextDisabled(string.format('Ranges in yalms: %s.', table.concat(ranges, ', ')));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('These are this server\'s ranges, already halved from retail. A mob keeps\nfull retail range once it has you -- these decide whether it starts.');
        end
    end

    if (scan.trueDetect == 1) then
        imgui.TextColored(theme.colors.err, 'True detection -- sneak and invisible will not hide you.');
    end

    if (scan.link == 1) then
        imgui.Text(string.format('Links, within %d yalms.', scan.linkRadius));
    else
        imgui.TextDisabled('Does not link.');
    end

    imgui.Separator();

    local spawn = bitList(scan.spawnType, SPAWN_TYPES, ', ');

    if (spawn ~= nil) then
        imgui.Text(string.format('Spawns %s.', spawn));
    end

    imgui.Text(string.format('Respawn: %s.', secondsWord(scan.respawn)));
end

local function tabDrops(scan)
    if (state.caps ~= nil and not state.caps.drops) then
        imgui.TextColored(theme.colors.err, 'This server build has no drop binding, so nothing can be listed.');

        return;
    end

    -- The TH in this label is the one the SERVER answered at (`y|`'s th
    -- field), never the dropdown's -- on a server that ignored or predates the
    -- argument it stays 0, and the window then cannot flatter the rates with a
    -- level nobody applied.
    -- Counted against the LOCAL filter too (client discipline 7: say what
    -- did not fit): "48 of 61 rows" over a table showing three, because
    -- "Hide under" ate the rest, read as a broken table.
    local hidden = 0;

    for _, row in ipairs(scan.drops) do
        if (ratePercent(row.rate) < (config.minRate or 0.0)) then
            hidden = hidden + 1;
        end
    end

    imgui.Text(string.format('%d of %d rows', scan.shown, scan.total));
    imgui.SameLine();

    if (hidden > 0) then
        imgui.TextDisabled(string.format('(%d hidden by the rate filter)', hidden));
        imgui.SameLine();
    end

    imgui.TextDisabled(string.format('-- rates include this server\'s %.2fx drop multiplier, at TH %d',
        scan.mult / 100.0, scan.th or 0));

    -- The truncation is the SERVER's cap, so there is nowhere else to look: the
    -- rows past it never left the map. Saying "type !scan for the rest" -- which
    -- 1.0 did -- sent the player to a tier that shows eight rows and points back
    -- here. Say what is true instead.
    if (scan.total > scan.shown) then
        imgui.TextColored(theme.colors.warn,
            string.format('%d more rows exist. The server sends the best %d and stops.',
                scan.total - scan.shown, scan.shown));
    end

    imgui.PushItemWidth(160);
    if (imgui.SliderFloat('Hide under', ui.minRate, 0.0, 25.0, '%.1f percent')) then
        commit();
    end
    imgui.PopItemWidth();

    imgui.SameLine();

    if (imgui.Checkbox('Icons', ui.icons)) then
        commit();
    end

    --[[
    * The Treasure Hunter dropdown. Its entries run 0..maxth where maxth came
    * off the server's own hello (`f|`), so the list resizes itself if the
    * bracket table is ever retuned -- this addon holds no copy of it. Picking
    * a level re-asks the server about the mob already on screen; the addon
    * still computes nothing, it just asks a different question. The choice is
    * persisted, so it survives target changes, reloads and sessions.
    --]]
    imgui.SameLine();
    imgui.PushItemWidth(72);

    local maxTh = 0;

    if (state.caps ~= nil and state.caps.maxth ~= nil) then
        maxTh = state.caps.maxth;
    end

    if (imgui.BeginCombo('##dwscan_th', string.format('TH %d', config.thLevel or 0))) then
        for level = 0, maxTh do
            if (imgui.Selectable(string.format('TH %d##dwscan_th_%d', level, level), (config.thLevel or 0) == level)) then
                ui.thLevel[1] = level;
                commit();

                if (state.scan ~= nil and state.scan.targid ~= nil) then
                    requestScan(state.scan.targid);
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Show drop rates as if this Treasure Hunter level lands the kill.\nThe server recomputes the whole table -- nothing here is scaled locally.');
    end

    imgui.Separator();

    if (#scan.drops == 0) then
        imgui.TextDisabled('Nothing drops from this one.');

        return;
    end

    -- WidthFixed and the flag set the other Driftwood addons already use: only
    -- those are proven to exist in this environment's ImGui bindings.
    if (not imgui.BeginTable('##dwscan_drops', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit, ImGuiTableFlags_ScrollY), { -1, -1 })) then
        return;
    end

    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 26, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 250, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 150, 0);

    for _, row in ipairs(scan.drops) do
        local percent = ratePercent(row.rate);

        if (percent >= (config.minRate or 0.0)) then
            imgui.TableNextRow();
            imgui.TableNextColumn();

            if (config.icons ~= false) then
                drawIcon(row.itemid, 20);
            end

            imgui.TableNextColumn();
            imgui.Text(itemName(row.itemid));

            imgui.TableNextColumn();

            if (row.kind == 's') then
                imgui.TextColored(theme.colors.info, string.format('steal %.2f percent', percent));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('One item is taken per successful Steal, picked at random from the\nsteal pool. This is that share -- it assumes the Steal lands.');
                end
            elseif (row.kind == 'd') then
                imgui.TextColored(theme.colors.info, string.format('despoil %.2f percent', percent));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('The despoil pool, same rule as Steal: this share assumes it lands.');
                end
            elseif (row.kind == 'g') then
                imgui.Text(string.format('%.2f percent', percent));
                imgui.SameLine();
                imgui.TextDisabled(string.format('(group %d)', row.group));

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('Exactly one item from a group drops, never two. This is the chance\nthat item is the one.');
                end
            else
                imgui.Text(string.format('%.2f percent', percent));
            end
        end
    end

    imgui.EndTable();
end

local function tabMagic(scan)
    imgui.Text('Elements');
    imgui.TextDisabled('Damage taken, and how well it resists being hit at all.');
    imgui.Separator();

    if (not imgui.BeginTable('##dwscan_elements', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 90,  0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 170, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 150, 0);

    for _, id in ipairs(ELEMENT_ORDER) do
        local element = ELEMENTS[id];
        local row     = scan.resists[id];

        imgui.TableNextRow();
        imgui.TableNextColumn();
        imgui.TextColored(colorOf(element), element.name);

        imgui.TableNextColumn();

        if (row == nil) then
            imgui.TextDisabled('-');
            imgui.TableNextColumn();
            imgui.TextDisabled('-');
        else
            local word, color = sdtWord(row.sdt);

            imgui.TextColored(color, string.format('%s (%+.0f percent)', word, row.sdt / 100.0));

            imgui.TableNextColumn();

            local rword, rcolor = rankWord(row.rank);

            imgui.TextColored(rcolor, string.format('%s to land', rword));
        end
    end

    imgui.EndTable();

    imgui.Separator();
    imgui.Text('Weapons');

    local lanes = {
        { name = 'Slashing',      value = scan.physical.slash  },
        { name = 'Piercing',      value = scan.physical.pierce },
        { name = 'Hand-to-hand',  value = scan.physical.hth    },
        { name = 'Blunt',         value = scan.physical.impact },
    };

    for _, lane in ipairs(lanes) do
        if (lane.value ~= nil) then
            local word, color = sdtWord(lane.value);

            imgui.Text(string.format('%-14s', lane.name));
            imgui.SameLine();
            imgui.TextColored(color, string.format('%s (%+.0f percent)', word, lane.value / 100.0));
        end
    end

    imgui.Separator();
    imgui.Text('Cannot be given at all');

    if (#scan.immunities == 0) then
        imgui.TextDisabled('Nothing -- every status effect can land on this one.');
    else
        imgui.TextColored(theme.colors.err, table.concat(scan.immunities, ', '));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Immunity is not resistance. These will never land, at any accuracy.');
        end
    end
end

--[[
* THE TP MOVES ARE DRAWN FIRST, and the ordering is load-bearing rather than
* cosmetic. They arrive on `k|` from the FACTS binding, which has nothing to do
* with the quest index -- so a `return` above them (which is what 1.0 did) meant
* a server missing its interaction index also silently swallowed a move list the
* server had sent and the addon had already parsed. A refusal must only refuse
* the thing it is about.
--]]
local function tabQuests(scan)
    imgui.Text('TP moves');

    if (#scan.skills == 0) then
        imgui.TextDisabled('None listed.');
    else
        imgui.TextWrapped(table.concat(scan.skills, ', '));
    end

    imgui.Separator();

    if (state.caps ~= nil and not state.caps.quests) then
        imgui.TextColored(theme.colors.err, 'The server\'s quest index is not loaded, so nothing is claimed here.');

        return;
    end

    if (#scan.quests == 0) then
        imgui.TextDisabled('No quest or mission on this server watches for this one\'s death.');
    else
        for _, row in ipairs(scan.quests) do
            local color = theme.colors.dim;
            local label = 'not started';

            if (row.state == 'active') then
                color = theme.colors.ok;
                label = 'in progress';
            elseif (row.state == 'done') then
                color = theme.colors.badge;
                label = 'completed';
            elseif (row.state == '-') then
                label = 'unknown';
            end

            imgui.TextColored(color, string.format('[%s]', label));
            imgui.SameLine();
            imgui.Text(string.format('%s %s', row.kind == 'm' and 'Mission:' or 'Quest:', row.name));
        end
    end

    imgui.Separator();
    imgui.TextDisabled('This is read from the server\'s own kill handlers -- what wants this thing');
    imgui.TextDisabled('DEAD. A quest that wants an item it drops will not appear here.');
end

local TABS = {
    { label = 'Overview', draw = tabOverview },
    { label = 'Drops',    draw = tabDrops    },
    { label = 'Magic',    draw = tabMagic    },
    { label = 'Quests',   draw = tabQuests   },
};

--[[
* The window.
--]]
local function headerRow()
    local targid = currentTarget();
    local name   = targetName(targid);

    if (imgui.Button('Scan##dwscan_scan')) then
        requestScan(targid);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Reads whatever you have targeted. Also works typed, as !scan.');
    end

    imgui.SameLine();

    if (name ~= nil) then
        imgui.Text(name);
    else
        imgui.TextDisabled('nothing selected');
    end

    imgui.SameLine();

    if (imgui.Checkbox('Follow target', ui.autoScan)) then
        commit();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Scan automatically when you change target, while this window is open.\nOne chat line per change -- leave it off in a crowd.');
    end

    if (#queue > 0) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('%d queued...', #queue));
    end

    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Separator();
end

local function renderWindow()
    headerRow();

    local scan = state.scan;

    if (scan == nil) then
        imgui.TextDisabled('Target a monster and press Scan.');
        imgui.Separator();
        imgui.TextWrapped('Everything here is read off this server, not a wiki: drop rates carry the ' ..
            'server multiplier, exp carries the server rate, and aggro ranges are the ones actually used.');

        return;
    end

    imgui.Text(scan.name);

    for _, note in ipairs(scan.notes) do
        imgui.TextColored(theme.colors.warn, note);
    end

    if (imgui.BeginTabBar('##dwscan_tabs')) then
        for index, tab in ipairs(TABS) do
            if (imgui.BeginTabItem(string.format('%s##dwscan_tab_%d', tab.label, index))) then
                tab.draw(scan);
                imgui.EndTabItem();
            end
        end

        imgui.EndTabBar();
    end
end

--[[
* Follow-target. Fires at most once per target change and never while a scan is
* already in flight -- one chat line per change is the budget, and a player
* sweeping a camp with the tab key must not queue twelve of them.
--]]
local function pumpAutoScan()
    if (not config.autoScan or state.refused or not state.spoke) then
        return;
    end

    local targid = currentTarget();

    if (targid == 0) then
        state.lastAuto = nil;

        return;
    end

    if (state.lastAuto == targid or state.asked ~= nil) then
        return;
    end

    state.lastAuto = targid;

    -- Only monsters (dwcon's spawn-flag gate, 0x10): the budget is one chat
    -- line per target CHANGE, and tabbing through a town spent it asking the
    -- server about NPCs and players it refuses by sentence -- a red status
    -- bar per click. The latch above still records the target, so a non-mob
    -- costs one decision and no line.
    local isMob = false;

    pcall(function ()
        local entity = AshitaCore:GetMemoryManager():GetEntity();

        isMob = bit.band(entity:GetSpawnFlags(targid), 0x10) ~= 0;
    end);

    if (not isMob) then
        return;
    end

    requestScan(targid);
end

--[[
* The frame. The queue is pumped first so a line goes out whether or not
* anything is being drawn, then the window -- Begin/End and the theme push/pop
* sit OUTSIDE the render pcall so both stacks stay balanced whatever the render
* pass does.
--]]
ashita.events.register('d3d_present', 'dwscan_present', function ()
    pumpQueue();
    pumpPending();
    pumpAnswer();

    if (not state.open[1]) then
        return;
    end

    pumpAutoScan();

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 540, 520 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads.
    local visible = imgui.Begin('DriftwoodXI Scan##dwscan', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwscan'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwscan'):append(chat.message('Window closed. !scan still works, typed.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1]  = true;
    state.reported = false;

    -- The handshake goes on window open, not on load: an automatic line against
    -- a server without the module is the player saying it in /say.
    hello();
end

--[[
* `/dwscan` (and `/scan`) opens the window; `/dwscan now` scans immediately
* without opening anything, which is the one-key version for a hotkey.
--]]
ashita.events.register('command', 'dwscan_command', function (e)
    local args = e.command:args();

    if (#args == 0) then
        return;
    end

    local first = args[1]:lower();

    if (first ~= '/dwscan' and first ~= '/scan') then
        return;
    end

    e.blocked = true;

    local verb = (args[2] or ''):lower();

    -- requestScan handshakes for itself when the server has not spoken yet and
    -- holds the scan until it has, so there is no hello to send by hand here --
    -- doing it separately is what put a blind `!dwn scan` on the wire in 1.0.
    if (verb == 'now') then
        requestScan(currentTarget());

        return;
    end

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

--[[
* Watch what the player sends. A bare `!scan` typed by hand opens the window
* instead, the way `!port` and `!warehouse` do -- and any other outgoing chat
* line stamps the throttle, because the client's rate limit is on chat and not
* on this addon.
--]]
ashita.events.register('packet_out', 'dwscan_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!scan ui' or lower == '!scan window' or lower == '!scan gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwn') then
        lastSend = os.clock();
    end
end);

ashita.events.register('load', 'dwscan_load', function ()
    print(chat.header('dwscan'):append(chat.message('/dwscan reads your target -- level, drops at this server\'s rates, resistances, quests. !scan does it typed.')));
end);
