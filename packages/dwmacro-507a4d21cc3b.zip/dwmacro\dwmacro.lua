--[[
* DriftwoodXI -- dwmacro
*
* Remembers which macro book and set you were on, and puts you back on it
* after a zone line and after a fresh login.
*
* WHY THIS IS AN ADDON AND NOT A SERVER PATCH.
*
* The macro palette is not server state. It is not in the database, it is not
* in any packet, and the map server has never been told about it: the string
* "macro" does not appear anywhere in atom0s's packet reference (XiPackets),
* which is the complete documented protocol, and it appears nowhere in this
* server's own source outside of unrelated C preprocessor macros. Macro books,
* their contents, and the book/set you are currently looking at all live in the
* client, in `<PlayOnline>/SquareEnix/FINAL FANTASY XI/USER/<charid-in-hex>/`,
* as `mcr.dat` and `mcr<book><set>.dat`.
*
* Losing the selection on a zone line is a retail client bug -- it was reported
* on Square Enix's own bug forum with exactly the symptom seen here, "macro
* books reset to Book 1, Page 1 when zoning, accept the change back, and reset
* again on the next zone". There is nothing on the server to fix. The only
* place the behaviour can be corrected is in the client, which is what this is.
*
* HOW IT KNOWS WHERE YOU WERE.
*
* Ashita ships `libs/ffxi/macros.lua`, which locates the client's
* `FsMacroContainer` and its `setBook` / `setPage` methods by signature scan.
* Two things are read out of that:
*
*   - The current book. `FsMacroContainer::setBook` opens by comparing its
*     argument against the container's book field, so the field's offset is an
*     immediate inside the very signature Ashita matched. It is read out of the
*     matched bytes rather than hardcoded, which means it cannot drift out of
*     step with the library: if the signature stops matching, the library fails
*     first and this addon reports itself inert.
*
*   - The current set. There is no such shortcut -- `setPage` does not expose
*     the field as an immediate, and Ashita's SDK headers describe no layout for
*     the container -- so the offset is measured instead of guessed. Once per
*     arming the container is snapshotted, the page is driven to four known
*     values, and every byte that counted along with it is a candidate. A fifth
*     value that took no part in choosing the candidates is then used to confirm
*     them, and the original set is put back, so the palette ends where it
*     started. If nothing survives, the addon says so and stays out of the way.
*
* WHAT THE MEASUREMENT ASSUMES, AND WHAT IT DELIBERATELY DOES NOT.
*
* It does not assume a width. The set is small enough to fit in a byte whatever
* the client declares the field as, and on a little-endian machine the low byte
* of a dword field is the field for values this size, so the scan walks bytes.
* An earlier version walked 4-byte-aligned dwords and so could only ever see a
* field that was both dword-wide and dword-aligned.
*
* It does not assume an encoding. The client's `setPage` takes a row index --
* a "set" on screen is two rows of ten macros, Ctrl and Alt, so set 3 is 4 --
* and Ashita's `set_page` doubles for you. Whether the container then stores
* that doubled row or the plain set number is not documented anywhere, so both
* are tried and whichever one actually counted is remembered. Everything above
* the read is in plain set numbers, 0-9.
*
* It does not treat more than one answer as no answer. The offset is only ever
* READ; books and sets are changed by calling the client's own `setBook` and
* `setPage`, never by writing the field. So a second byte that tracks the set
* just as faithfully is not a hazard to be refused, it is a second correct
* answer, and the one nearest the book field is taken.
*
* THE SELECTION IS REMEMBERED PER JOB, not per character. That is the way the
* game already thinks about macro books -- changing job switches your book --
* so keying on the job is what stops the two features fighting: come back as
* BLM and you are put on the book and set you last used as BLM, not on whatever
* WAR was looking at. Per-character separation is free; Ashita's settings
* library already files everything under `<charname>_<serverid>`.
*
* TURN IT OFF AND NOTHING IS LOST. `/macro book <n>` and `/macro set <n>` work
* exactly as they always did. This addon only ever puts back a book and set the
* player had already chosen for that job on that character; it never invents
* one, and with no remembered entry it does nothing at all.
--]]

addon.name    = 'dwmacro';
addon.author  = 'DriftwoodXI';
addon.version = '1.1';
addon.desc    = 'Remembers your macro book and set across zoning and logging back in.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local settings = require('settings');

--[[
* The macro library is a signature scan over the client and it raises rather
* than returning nil when a scan misses. A client build it does not know must
* leave the player with a working game and one line of explanation, not an
* addon that failed to load, so it is required defensively and every use of it
* is behind `macrolib ~= nil`.
--]]
local macrolib = nil;

do
    local ok, lib = pcall(require, 'ffxi.macros');

    if (ok and type(lib) == 'table') then
        macrolib = lib;
    end
end

--[[
* Where the book field lives inside the macro container.
*
* `FsMacroContainer::setBook` begins:
*
*     8B 44 24 04        mov  eax, [esp+4]        ; the requested book
*     56                 push esi
*     8B F1              mov  esi, ecx            ; this
*     8B 8E C0 1D 00 00  mov  ecx, [esi+1DC0h]    ; the current book
*     3B C8              cmp  ecx, eax
*
* so the offset is the four bytes at +9 from the address Ashita matched. Taking
* it from there rather than writing 0x1DC0 down means this and the library can
* only ever agree: they are reading the same matched bytes.
--]]
local BOOK_OFFSET_IMM = 9;

-- A sanity range for that offset. The macro records themselves occupy the
-- first ~7.6KB of the container, so a plausible book offset is a little past
-- that and nowhere near zero. Anything outside this is a bad match, not a
-- client we do not know about, and is refused.
local BOOK_OFFSET_MIN = 0x1000;
local BOOK_OFFSET_MAX = 0x4000;

--[[
* How far past the book field to look when measuring the set field.
*
* Everything below the book field is macro record data the client is known to
* have allocated, so scanning down to zero costs nothing but time. Above it is
* the only speculative part, and it is speculative in the way that matters --
* reading past the end of the allocation is a crash, not a failed measurement.
* A quarter of a kilobyte past the last member anyone has ever named is a long
* way for a sibling field and a short way into a heap block this size.
--]]
local SCAN_PAST_BOOK = 0x100;

--[[
* The sets the measurement drives through, as set numbers 0-9.
*
* Four values, so that a byte which merely happens to be 1 when the set is 1 is
* gone by the second probe, and chosen so the two candidate encodings can never
* be confused: as rows these are 2, 18, 8, 0 and as plain sets 1, 9, 4, 0, which
* differ everywhere they can. The list ends on set 1 because that is where the
* client has just put the player when this runs, so a measurement that fails
* outright leaves the palette exactly where the client left it.
*
* CONFIRM_SET took no part in choosing the candidates, which is the point of it:
* a byte that survived four probes and then also predicted a fifth is the set.
--]]
local PROBE_SETS  = T{ 1, 9, 4, 0 };
local CONFIRM_SET = 6;

local MAX_SET  = 9;
local MAX_BOOK = 39;

--[[
* The two ways the container could plausibly hold the selection: the row index
* the client's `setPage` is handed, or the set number behind it. Which one it
* actually is gets decided by the measurement rather than by assumption.
--]]
local ENCODINGS = T{
    T{
        name   = 'row',
        encode = function (set) return set * 2; end,
        decode = function (raw)
            if (raw % 2 ~= 0) then
                return nil;
            end

            return math.floor(raw / 2);
        end,
    },
    T{
        name   = 'set',
        encode = function (set) return set; end,
        decode = function (raw) return raw; end,
    },
};

-- How long after a zone line to wait before putting the palette back. The
-- client finishes rebuilding its macro state some time after the login packet
-- lands, and a restore that arrives first is simply overwritten by it.
local RESTORE_DELAY = 2.0;

-- A restore is verified by reading the palette back. If the client moved it
-- again the restore is repeated, but a fixed number of times: a retry that
-- never gives up is a loop, and a loop that writes to the macro palette is
-- worse than a wrong palette.
local RESTORE_RETRIES  = 3;
local RESTORE_INTERVAL = 1.0;

-- And a hard stop on the whole attempt. A restore that can never complete --
-- because the palette will not read, say -- must not sit armed for ever, since
-- an armed restore is also what suppresses recording.
local RESTORE_TIMEOUT = 20.0;

-- How often the palette is read while playing. Often enough that a set chosen
-- and then immediately zoned away from is caught, rare enough to be free.
local POLL_INTERVAL = 0.5;

--[[
* Measuring needs a macro container the client has actually finished filling in.
* `inGame()` goes true the moment the player has a party slot, which on a slow
* login -- a server still loading, a zone still streaming in -- is earlier than
* the palette being ready. Probing then drives sets that do not take, no byte
* counts along, and the measurement comes back empty.
*
* So a failure is never final on the strength of one login. MEASURE_RETRIES is
* the budget for a single arming: spend it and the addon goes quiet until the
* next zone line, which re-arms it with a fresh budget and a client that has
* just rebuilt its macro state. Only MEASURE_MAX_ATTEMPTS, across the whole
* session, ends it for good -- because a client that genuinely cannot be read
* should say so once rather than probe the palette for ever.
*
* The earlier build spent a single four-attempt budget in the first fourteen
* seconds of the session and never took another, so one unlucky login meant
* "macro sets will not be remembered" until the game was restarted.
--]]
local MEASURE_SETTLE         = 2.0;
local MEASURE_RETRIES        = 4;
local MEASURE_RETRY_INTERVAL = 3.0;
local MEASURE_MAX_ATTEMPTS   = 24;

local default_settings = T{
    -- Restoring can be turned off without unloading the addon; the palette is
    -- still remembered while it is off, so turning it back on picks up where
    -- it left off.
    enabled = true,

    -- Keyed by main job id. Each entry is { book = <0-39>, set = <0-9> }, in
    -- the numbering the macro menu shows minus one.
    jobs    = T{ },
};

local config = settings.load(default_settings);

--[[
* Builds before 1.1 stored the client's doubled row value under `page`. Nothing
* is thrown away for it: the row halves cleanly into the set it always meant.
--]]
do
    if (type(config.jobs) == 'table') then
        for _, entry in pairs(config.jobs) do
            if (type(entry) == 'table' and entry.set == nil and type(entry.page) == 'number') then
                entry.set  = math.floor(entry.page / 2);
                entry.page = nil;
            end
        end
    end
end

local state = T{
    -- What was measured. `bookOffset` is an offset; `page` is a table of
    -- { offset = <byte offset>, enc = <encoding> } and is nil until proven.
    bookOffset = nil,
    page       = nil,

    -- Measurement bookkeeping. `attempts` is the budget for the current arming
    -- and `total` is the session ceiling; `gaveUp` is set only once the ceiling
    -- is reached, and is what makes the failure final and worth saying aloud.
    attempts   = 0,
    total      = 0,
    nextTry    = 0,
    gaveUp     = false,

    -- What the last measurement saw, for `/dwmacro debug`. "Nothing happens" has
    -- several causes and they are not distinguishable from the outside.
    scan       = nil,

    -- Restore bookkeeping. `pending` suppresses recording: immediately after a
    -- zone the client is sitting on its own Book 1 / Set 1 default, and writing
    -- that over the player's real choice is the one bug this addon must not
    -- have.
    pending    = false,
    pendingAt  = 0,
    tries      = 0,
    lastTry    = 0,

    lastPoll   = 0,
};

settings.register('settings', 'dwmacro_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end

    settings.save();
end);

--[[
* Whether the player is actually in the world -- past character select, past
* the zone screen, with a party slot of their own. Every read and write below
* is gated on this; the macro container exists before this is true and holds
* nothing worth reading.
--]]
local function inGame()
    local player = AshitaCore:GetMemoryManager():GetPlayer();

    if (player == nil or player:GetLoginStatus() ~= 2) then
        return false;
    end

    local party = AshitaCore:GetMemoryManager():GetParty();

    if (party == nil or party:GetMemberIsActive(0) == 0) then
        return false;
    end

    return true;
end

local function mainJob()
    local player = AshitaCore:GetMemoryManager():GetPlayer();

    if (player == nil) then
        return 0;
    end

    return player:GetMainJob();
end

--[[
* The live macro container, or 0. This is re-read every time rather than cached
* because it is a pointer through two indirections and the object behind it does
* not survive a zone.
--]]
local function container()
    if (macrolib == nil) then
        return 0;
    end

    local ok, obj = pcall(macrolib.get_fsmacro);

    if (not ok or type(obj) ~= 'number') then
        return 0;
    end

    return obj;
end

--[[
* The book field's offset, taken out of the bytes Ashita matched for setBook.
--]]
local function findBookOffset()
    if (macrolib == nil or macrolib.ptrs == nil) then
        return nil;
    end

    local ptr = macrolib.ptrs.set_book;

    if (ptr == nil or ptr == 0) then
        return nil;
    end

    local ok, offset = pcall(ashita.memory.read_uint32, ptr + BOOK_OFFSET_IMM);

    if (not ok or type(offset) ~= 'number') then
        return nil;
    end

    if (offset < BOOK_OFFSET_MIN or offset > BOOK_OFFSET_MAX or offset % 4 ~= 0) then
        return nil;
    end

    return offset;
end

--[[
* The probing half of the measurement. Kept separate from the restore so that
* the restore can be guaranteed: this is allowed to fail in the middle, and the
* caller still puts the player's set back.
*
* The first probe is the expensive one -- a whole snapshot of the container,
* compared byte for byte -- and it is the only one, because the handful of bytes
* that survive it are then read individually. Every later probe costs a few
* reads rather than eight thousand.
--]]
local function probePageField(obj, bookOffset, before)
    local size = bookOffset + SCAN_PAST_BOOK;

    -- Probe one, from the full snapshot.
    macrolib.set_page(PROBE_SETS[1]);

    local first = ashita.memory.read_array(obj, size);

    if (type(first) ~= 'table') then
        return nil;
    end

    local candidates = { };

    for offset = 0, size - 1 do
        local value = first[offset + 1];

        if (value == nil) then
            break;
        end

        -- The book field is known, and is not the set field.
        if (offset < bookOffset or offset > bookOffset + 3) then
            for index = 1, #ENCODINGS do
                if (value == ENCODINGS[index].encode(PROBE_SETS[1])) then
                    candidates[#candidates + 1] = { offset = offset, enc = ENCODINGS[index] };
                end
            end
        end
    end

    local seeded = #candidates;

    -- The remaining probes, plus the confirming one. A candidate has to predict
    -- every single one of them.
    local rounds = T{ };

    for index = 2, #PROBE_SETS do
        rounds:append(PROBE_SETS[index]);
    end

    rounds:append(CONFIRM_SET);

    for index = 1, #rounds do
        if (#candidates == 0) then
            break;
        end

        macrolib.set_page(rounds[index]);

        local survivors = { };

        for entry = 1, #candidates do
            local candidate = candidates[entry];
            local ok, value = pcall(ashita.memory.read_uint8, obj + candidate.offset);

            if (ok and value == candidate.enc.encode(rounds[index])) then
                survivors[#survivors + 1] = candidate;
            end
        end

        candidates = survivors;
    end

    --[[
    * Nearest the book field wins. Several survivors is not ambiguity to be
    * refused -- all of them track the set, and the offset is only ever read --
    * but the choice still has to be the same one every session, so it is made
    * on distance and then on offset and encoding to break any remaining tie.
    --]]
    table.sort(candidates, function (a, b)
        local da = math.abs(a.offset - bookOffset);
        local db = math.abs(b.offset - bookOffset);

        if (da ~= db) then
            return da < db;
        end

        if (a.offset ~= b.offset) then
            return a.offset < b.offset;
        end

        return a.enc.name < b.enc.name;
    end);

    return {
        seeded    = seeded,
        survivors = #candidates,
        chosen    = candidates[1],
        before    = before,
    };
end

--[[
* Measure the set field, and put the player back on the set they were on.
*
* The restore runs whether the probing succeeded, failed, or raised: the probe
* moves the palette, and a probe that dies halfway through must not leave the
* player looking at somebody else's macros. Where the original set is unknown --
* nothing was found, so there is no byte to read it back out of -- set 1 is the
* honest fallback, and is where the last probe already left things.
--]]
local function measurePageField(obj, bookOffset)
    local before = ashita.memory.read_array(obj, bookOffset + SCAN_PAST_BOOK);

    if (type(before) ~= 'table') then
        return nil;
    end

    local ok, result = pcall(probePageField, obj, bookOffset, before);

    local restore = 0;

    if (ok and type(result) == 'table' and result.chosen ~= nil) then
        local original = before[result.chosen.offset + 1];

        if (type(original) == 'number') then
            local decoded = result.chosen.enc.decode(original);

            if (decoded ~= nil and decoded >= 0 and decoded <= MAX_SET) then
                restore = decoded;
            end
        end
    end

    pcall(macrolib.set_page, restore);

    if (not ok) then
        error(result, 0);
    end

    return result;
end

--[[
* Read the palette. Returns nil unless the measurement is done, the container is
* live, and both values are ones the client could actually be holding -- a set
* outside 0-9 means the offset is wrong and the read is thrown away rather than
* remembered.
--]]
local function readPalette()
    if (state.bookOffset == nil or state.page == nil) then
        return nil;
    end

    local obj = container();

    if (obj == 0) then
        return nil;
    end

    local ok, book = pcall(ashita.memory.read_uint32, obj + state.bookOffset);

    if (not ok or type(book) ~= 'number' or book < 0 or book > MAX_BOOK) then
        return nil;
    end

    local okRaw, raw = pcall(ashita.memory.read_uint8, obj + state.page.offset);

    if (not okRaw or type(raw) ~= 'number') then
        return nil;
    end

    local set = state.page.enc.decode(raw);

    if (set == nil or set < 0 or set > MAX_SET) then
        return nil;
    end

    return { book = book, set = set };
end

--[[
* Put the palette back. The book goes first and the set second, and that order
* is not cosmetic: the client resets the set whenever the book actually changes,
* so a set written first would be thrown away by the book write. (It early-outs
* when the book is already correct, which is why the common case of "same book,
* wrong set" costs nothing.)
*
* Both writes go through the client's own functions. Nothing here ever writes
* the fields the measurement found; those are read-only to this addon.
--]]
local function applyPalette(palette)
    if (macrolib == nil or palette == nil) then
        return false;
    end

    if (palette.book < 0 or palette.book > MAX_BOOK or palette.set < 0 or palette.set > MAX_SET) then
        return false;
    end

    local ok = pcall(function ()
        macrolib.set_book(palette.book);
        macrolib.set_page(palette.set);
    end);

    return ok;
end

--[[
* Human-facing numbering. The client counts books and sets from zero; the macro
* menu counts them from one.
--]]
local function describe(palette)
    if (palette == nil) then
        return 'nothing yet';
    end

    return ('book %d, set %d'):fmt(palette.book + 1, palette.set + 1);
end

--[[
* Measure the palette, spending one budget of attempts per arming and conceding
* only once the session ceiling is reached. Once the measurement is done this is
* a single comparison per frame; once it has given up it is the same.
--]]
local function ensureMeasured()
    if (state.gaveUp or (state.bookOffset ~= nil and state.page ~= nil)) then
        return;
    end

    -- This arming's budget is spent. Wait for the next zone line, which re-arms
    -- with a client that has just rebuilt its macro state.
    if (state.attempts >= MEASURE_RETRIES) then
        return;
    end

    local now = os.clock();

    -- Let the client finish building the palette before touching it, and space
    -- the retries out rather than re-probing every frame.
    if (state.nextTry == 0) then
        state.nextTry = now + MEASURE_SETTLE;
        return;
    end

    if (now < state.nextTry) then
        return;
    end

    -- No container yet is not an attempt, but it must still cost a wait, or a
    -- client that is slow to build one is probed sixty times a second.
    local obj = container();

    if (obj == 0) then
        state.nextTry = now + MEASURE_RETRY_INTERVAL;
        return;
    end

    state.attempts = state.attempts + 1;
    state.total    = state.total + 1;
    state.nextTry  = now + MEASURE_RETRY_INTERVAL;

    -- Whether there is anything left to try after this, ever. Everything below
    -- reports a failure only then; otherwise it goes quiet and waits.
    local final = state.total >= MEASURE_MAX_ATTEMPTS;

    -- Note that this does not throw the book offset away. Nothing keys off it
    -- alone -- every gate below wants both halves -- and keeping it is what lets
    -- `/dwmacro debug` distinguish "the book field was never found" from "the
    -- book field was found and the set field was not", which are the same
    -- silence from the outside and want completely different answers.
    local function giveUp(message)
        state.page = nil;

        if (final) then
            state.gaveUp = true;
            print(chat.header(addon.name):append(chat.error(message)));
            print(chat.header(addon.name):append(chat.message('Your macro palette is untouched; /macro book and /macro set work as normal.')));
        end
    end

    state.bookOffset = findBookOffset();

    if (state.bookOffset == nil) then
        state.scan = { error = 'no book field' };

        giveUp('Could not locate the macro book field in this client. Macro sets will not be remembered.');
        return;
    end

    local ok, result = pcall(measurePageField, obj, state.bookOffset);

    if (not ok or type(result) ~= 'table') then
        state.scan = { error = tostring(result) };

        giveUp('Could not read this client\'s macro palette. Macro sets will not be remembered.');
        return;
    end

    state.scan = { seeded = result.seeded, survivors = result.survivors, chosen = result.chosen };

    if (result.chosen == nil) then
        giveUp('Could not identify the macro set field in this client. Macro sets will not be remembered.');
        return;
    end

    state.page = result.chosen;
end

--[[
* Record the palette against the job currently being played.
--]]
local function record()
    local job = mainJob();

    if (job == 0) then
        return;
    end

    local palette = readPalette();

    if (palette == nil) then
        return;
    end

    local known = config.jobs[job];

    if (known ~= nil and known.book == palette.book and known.set == palette.set) then
        return;
    end

    config.jobs[job] = T{ book = palette.book, set = palette.set };

    settings.save();
end

--[[
* Arm a restore. Called for the login packet, which the server sends both on a
* real login and on every zone line -- the two cases this addon exists for are
* the same packet.
*
* The clock starts when the player is next seen in the world, not here: the
* packet arrives while the zone screen is still up, and the delay that matters
* is the one after the client has finished rebuilding.
--]]
local function armRestore()
    state.pending   = true;
    state.pendingAt = 0;
    state.tries     = 0;
    state.lastTry   = 0;

    -- A zone line rebuilds the client's macro state, so if the palette still has
    -- not been measured this is a fresh chance at it -- and a better one than the
    -- frame that just failed. A fresh budget with it: the failure that matters is
    -- a client that cannot be read at all, not a login that was busy.
    if (not state.gaveUp and (state.bookOffset == nil or state.page == nil)) then
        state.attempts = 0;
        state.nextTry  = 0;
    end
end

local function attemptRestore()
    local now = os.clock();

    if (state.pendingAt == 0) then
        state.pendingAt = now;
        return;
    end

    if (now - state.pendingAt > RESTORE_TIMEOUT) then
        state.pending = false;
        return;
    end

    if (now - state.pendingAt < RESTORE_DELAY) then
        return;
    end

    if (state.tries > 0 and now - state.lastTry < RESTORE_INTERVAL) then
        return;
    end

    local job = mainJob();

    if (job == 0) then
        return;
    end

    local wanted = config.jobs[job];

    -- Nothing remembered for this job is not a failure, it is the first time
    -- this job has been played. Stand down and let the poller learn it.
    if (wanted == nil or wanted.book == nil or wanted.set == nil) then
        state.pending = false;
        return;
    end

    local current = readPalette();

    if (current == nil) then
        return;
    end

    if (current.book == wanted.book and current.set == wanted.set) then
        state.pending = false;
        return;
    end

    state.tries   = state.tries + 1;
    state.lastTry = now;

    applyPalette(wanted);

    -- Read it back in the same frame rather than waiting for the next attempt
    -- to notice. An armed restore is what suppresses recording, so leaving it
    -- armed a second longer than necessary is a second in which a set the
    -- player chose right after zoning would be forced back.
    local settled = readPalette();

    if (settled ~= nil and settled.book == wanted.book and settled.set == wanted.set) then
        state.pending = false;
        return;
    end

    if (state.tries >= RESTORE_RETRIES) then
        state.pending = false;
    end
end

local function tick()
    if (not inGame()) then
        return;
    end

    ensureMeasured();

    if (state.bookOffset == nil or state.page == nil) then
        return;
    end

    if (state.pending) then
        if (config.enabled) then
            attemptRestore();
        else
            state.pending = false;
        end

        -- Recording stays shut off until the restore has settled, so the
        -- client's post-zone default is never mistaken for a choice.
        return;
    end

    local now = os.clock();

    if (now - state.lastPoll < POLL_INTERVAL) then
        return;
    end

    state.lastPoll = now;

    record();
end

--[[
* Everything above runs once a frame, which is the reason for the pcall: an
* error raised inside `d3d_present` is raised sixty times a second, and the
* addon host answers a long enough run of them by unloading the addon. One bad
* frame costs one line of chat and the feature, not the addon -- and the
* feature going quiet leaves a completely normal macro palette behind.
--]]
local failed = false;

ashita.events.register('d3d_present', 'dwmacro_present', function ()
    if (macrolib == nil or failed) then
        return;
    end

    local ok, err = pcall(tick);

    if (not ok) then
        failed = true;

        print(chat.header(addon.name):append(chat.error('Stopped after an error: ' .. tostring(err))));
        print(chat.header(addon.name):append(chat.message('Your macro palette is untouched; /macro book and /macro set work as normal.')));
    end
end);

--[[
* The login packet. The client's macro state does not survive it, and it is
* sent for a zone line as well as a login, so this one hook covers both cases.
--]]
ashita.events.register('packet_in', 'dwmacro_zonein', function (e)
    if (e.id == 0x000A) then
        armRestore();
    end
end);

--[[
* What the measurement saw. This exists because every way this addon can fail
* quietly looks identical from the outside -- no set field found, several found
* and none confirmed, the container never readable -- and they want different
* answers.
--]]
local function printDebug()
    print(chat.header(addon.name):append(chat.message(('macros lib: %s   container: 0x%08X'):fmt(macrolib ~= nil and 'loaded' or 'MISSING', container()))));
    print(chat.header(addon.name):append(chat.message(('book offset: %s   attempts: %d this zone, %d of %d this session'):fmt(
        state.bookOffset ~= nil and ('0x%04X'):fmt(state.bookOffset) or 'unknown',
        state.attempts, state.total, MEASURE_MAX_ATTEMPTS))));

    if (state.page ~= nil) then
        local obj = container();
        local raw = 'unreadable';

        if (obj ~= 0) then
            local ok, value = pcall(ashita.memory.read_uint8, obj + state.page.offset);

            if (ok) then
                raw = tostring(value);
            end
        end

        print(chat.header(addon.name):append(chat.message(('set field: 0x%04X (%+d from book), encoding %s, reads %s'):fmt(
            state.page.offset, state.page.offset - state.bookOffset, state.page.enc.name, raw))));
    else
        print(chat.header(addon.name):append(chat.message('set field: not identified')));
    end

    if (state.scan == nil) then
        print(chat.header(addon.name):append(chat.message('last scan: has not run yet')));
    elseif (state.scan.error ~= nil) then
        print(chat.header(addon.name):append(chat.message('last scan: failed -- ' .. state.scan.error)));
    else
        print(chat.header(addon.name):append(chat.message(('last scan: %d candidate(s) seeded, %d confirmed'):fmt(state.scan.seeded or 0, state.scan.survivors or 0))));
    end
end

ashita.events.register('command', 'dwmacro_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwmacro' and args[1] ~= '/macro')) then
        return;
    end

    local verb = (#args > 1) and args[2]:lower() or 'status';

    --[[
    * /macro IS A RETAIL CLIENT COMMAND, and this addon's whole contract is
    * that `/macro book <n>` and `/macro set <n>` keep working exactly as they
    * always did (see the header). So the alias only claims the verbs dwmacro
    * itself owns and hands anything else straight back to the client --
    * blocking an unknown verb here would eat a client feature this addon has
    * promised not to touch. `debug` is deliberately not on that list; it is a
    * /dwmacro verb only.
    --]]
    if (args[1] == '/macro' and verb ~= 'status' and verb ~= 'on' and verb ~= 'off' and verb ~= 'forget') then
        return;
    end

    e.blocked = true;

    if (verb == 'on' or verb == 'off') then
        config.enabled = (verb == 'on');
        settings.save();

        print(chat.header(addon.name):append(chat.message('Restoring is now ')):append(chat.success(verb)):append(chat.message('.')));
        return;
    end

    if (verb == 'forget') then
        config.jobs = T{ };
        settings.save();

        print(chat.header(addon.name):append(chat.message('Forgot every remembered macro book and set.')));
        return;
    end

    if (verb == 'debug') then
        printDebug();
        return;
    end

    -- Status. Says what it measured as well as what it remembers, because
    -- "nothing happens" has two causes and they need different answers.
    if (macrolib == nil) then
        print(chat.header(addon.name):append(chat.error("Ashita's macro library did not load; nothing is being remembered.")));
        return;
    end

    if (failed) then
        print(chat.header(addon.name):append(chat.error('Stopped after an error earlier this session; nothing is being remembered. Reload with /addon reload dwmacro.')));
        return;
    end

    if (state.bookOffset == nil or state.page == nil) then
        if (state.gaveUp) then
            print(chat.header(addon.name):append(chat.error('Could not read this client\'s macro palette; nothing is being remembered.')));
            print(chat.header(addon.name):append(chat.message('/dwmacro debug says what it saw.')));
        else
            print(chat.header(addon.name):append(chat.message(('Still reading the macro palette (%d attempt(s) so far). It tries again after each zone line.'):fmt(state.total))));
        end

        return;
    end

    local job     = mainJob();
    local current = readPalette();

    print(chat.header(addon.name):append(chat.message('Restoring is ')):append(chat.success(config.enabled and 'on' or 'off')):append(chat.message('. Currently on ' .. describe(current) .. '.')));

    local remembered = (job ~= 0) and config.jobs[job] or nil;

    if (remembered ~= nil and remembered.book ~= nil and remembered.set ~= nil) then
        print(chat.header(addon.name):append(chat.message('Remembered for this job: ' .. describe(remembered) .. '.')));
    else
        print(chat.header(addon.name):append(chat.message('Nothing remembered for this job yet.')));
    end
end);

ashita.events.register('load', 'dwmacro_load', function ()
    if (macrolib == nil) then
        print(chat.header(addon.name):append(chat.error("Ashita's macro library did not load on this client build; macro sets will not be remembered.")));
        return;
    end

    print(chat.header(addon.name):append(chat.message('Your macro book and set are remembered per job and put back after zoning. /dwmacro (or plain /macro) for status.')));
end);

ashita.events.register('unload', 'dwmacro_unload', function ()
    settings.save();
end);
