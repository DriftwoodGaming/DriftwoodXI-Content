--[[
* DriftwoodXI -- dwecho
*
* Swallows the client's local echo of the `!` commands a Driftwood addon
* sends, so the chat log stops showing the plumbing.
*
* WHAT THE PLAYER WAS SEEING. Lines like these, unprompted, for something
* they never typed -- two of them on every login before dwtracker was fixed
* on 2026-07-30, and a couple more every time somebody opened a window:
*
*     Blaster : !dwt hello
*     Blaster : !dwq bags 1
*
* It reads like a bug. On a login it is the first thing a new character sees.
*
* IT IS NOT A FAILED COMMAND, which is exactly what it looks like. That was
* checked properly rather than assumed: a `!` command the server does not
* recognise leaves TWO traces -- a `cmdhandler::call: Function does not
* exist` error in the map log AND a SAY row in the audit_chat table. Real
* leaks have that pair (`!gambits` and `!mercdebug` from earlier sessions do).
* The addon lines have neither, because the server took the commands and
* answered them. Nothing was ever broadcast.
*
* WHERE IT ACTUALLY COMES FROM. `QueueCommand(1, ...)` is CommandMode::Typed,
* "forward the command as if a player typed it" (Ashita.h, CommandMode). It
* has to be that: a `!` command IS a chat line -- that is the only way one
* reaches an LSB server -- so the suite sends them the way a player would.
* The client then renders the line locally, the way it renders anything you
* type. The server consumes the command instead of broadcasting it, so that
* local copy is never replaced or matched by a real say. One orphan line per
* command, and nothing upstream is wrong.
*
* THE MATCH IS DELIBERATELY NARROW, because the cost of a false positive is
* eating a player's chat. A line is swallowed only if it ENDS with a command
* string this addon put on the wire within the last few seconds, and each
* send is consumed by at most one line. The echo renders as `<name> : !dwq
* bags 1`, so the suffix test is exact against the part we control, and a
* passing mention ("!dwq bags 1 is broken") never matches. Worst case, a
* player types one of our commands by hand at the same moment and loses a
* duplicate echo of their own typing.
*
* USAGE -- two lines of setup, then send through here instead of the chat
* manager:
*
*     local echo = require('dwecho');
*     echo.install();
*
*     echo.send(command);   -- was AshitaCore:GetChatManager():QueueCommand(1, command)
*
* `send` is the whole point of the shape: recording and sending cannot drift
* apart if they are the same call. An addon that sends around it just keeps
* its echo, which is the old behaviour and harmless.
*
* A COPY PER ADDON FOLDER, exactly like dwtheme.lua, because an addon folder
* is the unit of distribution. `dwbags/dwecho.lua` is the master -- edit
* there and re-copy to the others. Each addon runs in its own Lua state, so
* each copy keeps its own table and its own handler; they never see each
* other's commands, which is what makes the narrow match safe.
*
* dwmacro does not carry this file. It is the one addon that never talks to
* the server -- no commands, no echo.
--]]

local echo = { };

-- Generous next to a 1.2s send interval and short enough that a stale entry
-- cannot sit around waiting to eat an unrelated line.
local WINDOW = 3.0;

-- command string -> os.clock() when it went out. A plain table: the keys are
-- arbitrary command text, and T{}'s sugar method names would shadow them.
local sent = { };

local installed = false;

--[[
* Put a command on the wire and remember it long enough to recognise its echo.
--]]
function echo.send(command)
    if (type(command) ~= 'string' or command == '') then
        return;
    end

    sent[command] = os.clock();

    AshitaCore:GetChatManager():QueueCommand(1, command);
end

--[[
* Register the one text_in handler. Idempotent -- calling it twice would
* otherwise register two handlers that both try to block the same line.
*
* Handlers that read the chat log for their own purposes (dwreport's report
* buffer) must skip lines where `e.blocked` is already set: a line the player
* never saw does not belong in a bug report either.
--]]
function echo.install()
    if (installed) then
        return;
    end

    installed = true;

    ashita.events.register('text_in', 'dwecho_text_in', function (e)
        if (e.blocked or e.message == nil) then
            return;
        end

        local line = e.message:gsub('[^\032-\126]', '');

        line = line:gsub('%s+$', '');

        if (line == '') then
            return;
        end

        local now = os.clock();

        -- Clearing the current key inside pairs() is the one table mutation
        -- Lua guarantees is safe, so the expiry sweep rides along with the
        -- search instead of needing a pass of its own.
        for command, at in pairs(sent) do
            if (now - at > WINDOW) then
                sent[command] = nil;
            elseif (#line >= #command and line:sub(-#command) == command) then
                sent[command] = nil;
                e.blocked = true;

                return;
            end
        end
    end);
end

--[[
* ZONE-IN STAGGER. (Added 2026-08-14 for the login-time "A command error
* occurred." spam.)
*
* Two client facts, each of which answers an outgoing chat line with "A command
* error occurred." and then DROPS it -- the line never reaches the server, so
* the map log is clean and the failure is invisible from the server side:
*
*   1. The client refuses chat while it is still zoning. dwtracker/dwfame/
*      dwraid already wait out `GetIsZoning()` before their zone-in sync; this
*      file does not touch that, and dwcon now does it too.
*   2. The client rate-limits chat. Several lines in the same beat lose all but
*      one -- and every addon runs in its own Lua state (see the header), so the
*      packet_out back-off that spaces STEADY-STATE traffic cannot see a
*      sibling's send until the client has already put it on the wire, a frame
*      or more later. On a login every auto-syncing addon's zone-in hello is
*      armed at once and fires the instant the zoning flag clears -- the SAME
*      frame for all of them -- so that back-off is blind to exactly the burst
*      it exists to prevent. That is the 3-6 lines players saw per login.
*
* The fix needs no shared memory the isolated states do not have: each
* auto-syncing addon takes a SLOT in one canonical order and holds its zone-in
* sync `slot * SEND_INTERVAL` past the moment the client stops zoning. No two
* slots land in the same throttle window, so the burst serialises into one line
* per window with nothing dropped. Steady-state traffic is unchanged -- the slot
* only gates the automatic zone-in sync, never a line the player asked for.
*
* ADDITIVE: a new zone-in auto-syncer APPENDS its name here (reordering only
* changes who waits longest). harness_dwsuite.py gates both halves -- every name
* here is called by exactly its own addon, every caller is named here, no dups,
* and the list does not shrink.
--]]
echo.SEND_INTERVAL = 1.2;

echo.ZONE_ORDER = {
    'dwtracker',
    'dwcon',
    'dwfame',
    'dwraid',
};

--[[
* MAY A LINE GO OUT AT ALL RIGHT NOW? (Added 2026-08-15.)
*
* The ZONE_ORDER stagger above fixed the LOGIN burst: the four addons that sync
* on zone-in with their windows CLOSED. It did not fix the other half of the
* same client fact, because that half only shows when a window is open.
*
* Fourteen of the eighteen sending addons ask lazily -- `need*()` runs from the
* render loop and only when the window is drawn -- and every one of them clears
* its "what have I asked for" table in the 0x000A handler. So a player who
* zones with two or three dw windows open re-arms those requests on the zone-in
* packet and the queues drain on the very next frame, while the client is still
* on the load screen. None of those fourteen had a GetIsZoning() gate of any
* kind. The client answers each of those lines with "A command error occurred."
* and drops it before the server sees it -- the same visible spam the stagger
* was written to end, arriving by a different door, and then a five-second
* ANSWER_TIMEOUT before the retry repaints the window (dwport goes further and
* blames the server: "The server did not answer. Is this DriftwoodXI?").
*
* One test, in the one file all eighteen already carry, consulted from each
* addon's pumpQueue. The line stays QUEUED rather than being dropped, so the
* answer arrives a moment later instead of after a timeout.
*
* Note this is deliberately NOT called inside `echo.send`: a caller that has
* already recorded the send would then believe it went out. The queue is the
* right place to hold, and the queue is what every addon has.
--]]
function echo.canSend()
    local memory = AshitaCore:GetMemoryManager();

    if (memory == nil) then
        return false;
    end

    local player = memory:GetPlayer();

    -- No player object is not "safe to send"; it is "we cannot tell", and the
    -- cost of waiting a frame is nothing while the cost of guessing is a lost
    -- line and a visible error.
    if (player == nil) then
        return false;
    end

    return player:GetIsZoning() == 0;
end

--[[
* This addon's stagger slot: its 0-based position in ZONE_ORDER. A name not in
* the list answers 0, which the suite gate refuses, so an unlisted auto-syncer
* never ships.
--]]
function echo.zoneSlot(name)
    for i = 1, #echo.ZONE_ORDER do
        if (echo.ZONE_ORDER[i] == name) then
            return i - 1;
        end
    end

    return 0;
end

return echo;
