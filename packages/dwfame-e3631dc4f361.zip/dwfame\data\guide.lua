--[[
* dwfame guide data -- the fastest reliable way to raise each fame, authored
* against THIS server's own quest scripts (scripts/quests/...), not a wiki.
* Every NPC, town, item, count and fame amount below was read out of the
* script that pays it, so the guide can never promise a turn-in the server
* does not honour. Amounts are base points, before the server's fame
* multiplier -- the window states the live rate beside them.
*
* WHY THIS FILE CARRIES A SECOND TABLE.
*
* The paragraph above was already the promise on 2026-08-04, and the file
* broke it anyway: it sent players to Secodiand in SOUTHERN San d'Oria (he
* stands in Northern), named three San d'Oria NPCs that do not exist, sold
* "Groceries" as a repeatable when its only fame award sits in a section
* that stops running the moment the quest completes, and offered eight
* Abyssea areas a path no script on this server implements. Prose cannot be
* checked, so nothing checked it, and the addon's 40 green harness checks
* went on being green for every one of those days.
*
* So each claim now carries its provenance. `sources` names, per line, the
* quest script that pays it, the NPC key that script keys on, the zone that
* NPC's section lives under, and the fame area and amount it awards.
* `tools/dwfame/check_guide.py` reads BOTH tables and refuses to agree
* unless the script still says so AND the prose still names the same NPC and
* town -- so a sentence and its provenance cannot drift apart, and a quest
* rewritten under us fails the deploy instead of shipping a lie.
*
* THE PROSE IS STILL THE PRODUCT. `sources` is not rendered anywhere; the
* addon reads `entries` and nothing else. If you add a line, add its source
* row too, or the checker will tell you the line is unbacked.
*
* Shape: { entries = { [areaKey] = { 'line', ... } },
*          sources = { { area, line, quest, npc, zone, town, fame, fameArea }, ... } }
* Area keys match fame_core.lua's AREAS table. `line` is the 1-based index
* into entries[area] that the row backs.
--]]

return {
    kind = 'guide',

    entries = {
        sandoria = {
            'Fastest to start: "Fear of the Dark" -- trade 2 Bat Wings to Secodiand (Northern San d\'Oria). No fame needed to begin, and it repeats forever with no zoning in between: 10 fame + 200 gil per trade.',
            'Best once San d\'Oria fame reaches 3: "Warding Vampires" -- trade 2 Bulbs of Shaman Garlic to Maloquedil (Northern San d\'Oria). 16 fame + 900 gil per trade, also with no zoning in between.',
            'Equal payer, different drop: "Tiger\'s Teeth" -- trade 3 Black Tiger Fangs to Taumila (Southern San d\'Oria) for 16 fame a run.',
            'Ten a run, all in Southern San d\'Oria: "Lizard Skins" (3 Lizard Skins to Hanaa Punaa), "The Sweetest Things" (5 Pots of Honey to Raimbroy), and "Starting a Flame" (4 Flint Stones to Legata).',
            'Bat Wings drop from bats across Ronfaure; Bat Wings, Lizard Skins, Pots of Honey, Flint Stones and Black Tiger Fangs are all stocked on the auction house here.',
            'Trial-size Trial by Ice (Cloister of Frost) pays 20 San d\'Oria fame per win, and Trial by Wind pays 10 here and 10 in Bastok -- but every trial-size fight is SUMMONER ONLY, solo, capped at level 20.',
            'Every Jeuno city quest also pays 5-17 San d\'Oria fame, so a Jeuno session raises all three nations at once.',
        },

        bastok = {
            'Fastest: "Fallen Comrades" -- trade a Silver Name Tag to Pavvke (Bastok Mines). Needs Bastok fame 2 to begin. After the first completion every tag pays 20 fame -- the 10-point completion reward plus a 10-point repeat bonus -- and 550 gil, with no zoning in between.',
            'Steady alternative: "Gourmet" -- trade ONE Sleepshroom, Treant Bulb or Wild Onion to Salimah (Bastok Markets) for 10 fame. You must zone before she will take another.',
            'Gourmet\'s hour only changes the gil: Treant Bulb 06:00-12:00, Wild Onion 12:00-18:00, Sleepshroom 18:00-06:00 pay best. Bring the wrong one and the fame is still 10.',
            '"Chips" pays 5 Bastok AND 5 San d\'Oria per run of the three colored chips -- Carmine, Cyan and Gray -- traded to Cid (Metalworks), and it repeats. It only opens during Chains of Promathia "One To Be Feared", from Ghebi Damomohe in Lower Jeuno, and Cid refuses the trade unless you have a free bag slot and no CCB Polymer already.',
            '"Groceries" pays its 10 Bastok fame ONCE. Its fame award lives in a section that stops running the moment the quest completes, so it is not a repeatable on this server whatever a wiki says.',
            'Trial-size Trial by Earth (Cloister of Tremors) pays 20 Bastok fame per win -- summoner only, solo, capped at level 20.',
            'Every Jeuno city quest also pays 5-17 Bastok fame.',
        },

        windurst = {
            'Fastest to start: "Say It with Flowers" -- needs Windurst fame 2 to begin. Break a free Tahrongi Cactus off the cacti in Tahrongi Canyon and trade it to Moari-Kaaori (Windurst Waters): 10 fame + 400 gil.',
            'The repeat loop is a round trip: after each turn-in you must zone, then talk to Moari-Kaaori again to re-arm the trade. Cacti are free and unlimited, so gather a stack before you start.',
            'Best at Windurst fame 6: "Toraimarai Turmoil" -- trade 3 Starmite Shells to Ohbiru-Dohbiru (Windurst Waters) for 16 fame a run. It also wants "Blue Ribbon Blues" finished first.',
            'Mhaura and Kazham quests pay Windurst fame too -- the server maps all three to the same fame area.',
            'Trial-size Trial by Fire and Trial by Lightning each pay 20 Windurst fame per win -- summoner only, solo, capped at level 20.',
            'Every Jeuno city quest also pays 5-17 Windurst fame.',
        },

        jeuno = {
            'On this server Jeuno fame is ENTIRELY the average of your three nation fames. The client has a Jeuno counter of its own, but no quest here ever adds to it -- so raise San d\'Oria, Bastok and Windurst and this bar follows by itself.',
            'Jeuno\'s own quests all pay 5-17 fame to ALL THREE nations per completion, which is why they move this bar: "Candle Making" pays 13 each, "The Clockmaster" and "Save the Clock Tower" 17 each.',
            'Notable doors this fame opens: "Tenshodo Membership" and "The Goblin Tailor" at level 3, "The Clockmaster" and "Save the Clock Tower" at level 5.',
        },

        selbina = {
            'Selbina and Rabao have no fame counter of their own: your standing there is the AVERAGE of San d\'Oria and Bastok fame. Raise those two and this bar moves by itself.',
            'The one quest that pays this area directly is "Open Sesame" -- Lokpix, in the Eastern Altepa Desert. It awards 30, and the server spends that as 30 San d\'Oria AND 30 Bastok, so the whole 30 lands on this bar.',
            'The quickest repeatable pair: "Warding Vampires" (San d\'Oria, 2 Bulbs of Shaman Garlic) and "Fallen Comrades" (Bastok, a Silver Name Tag).',
            'Trial-size Trial by Wind (Cloister of Gales) pays 10 to both nations in one win -- the most efficient single fight for this bar, if you are a summoner.',
        },

        norg = {
            'Fastest: "Mihgo\'s Amigo" -- trade 4 Yagudo Bead Necklaces to Nanaa Mihgo (Windurst Woods). 30 fame the first time, 15 per repeat -- and it is Norg fame, despite the Windurst address. You must zone between repeats.',
            'Necklaces drop from Yagudo in Giddeus, and the auction house stocks them here.',
            '"A Job for the Consortium" (San d\'Oria) pays 20, but wants San d\'Oria fame 5 as well as Norg fame 1; "Shady Business" (Bastok) pays 30 once.',
            'Trial-size Trial by Water (Cloister of Tides) pays 20 Norg fame per win -- summoner only, solo, capped at level 20.',
            'Doors this fame opens: the Damp Scroll line and "Like Shining Subligar/Leggings" at level 3, "The Sahagin\'s Stash" and "Stop Your Whining" at level 4.',
        },

        -- Abyssea. Only La Theine has a fame source implemented on this
        -- server today; the other eight bars are real, cap at 6, and nothing
        -- currently moves them. Saying so is the whole point of this file --
        -- the old text promised all nine "the quests taken inside that zone".
        latheine = {
            'The one Abyssea fame you can raise today: "Fear of the Dark III" -- trade 3 Clionid Wings to Secodiand (Abyssea - La Theine) for 10 fame + 200 cruor, repeatable.',
            '"Lost Memories" opens once La Theine fame reaches level 5.',
            'Abyssea standing is tracked per zone and caps at level 6.',
        },

        konschtat  = { 'No quest on this server awards Abyssea - Konschtat fame yet. The bar is real and caps at level 6, but nothing currently moves it.' },
        tahrongi   = { 'No quest on this server awards Abyssea - Tahrongi fame yet. The bar is real and caps at level 6, but nothing currently moves it.' },
        misareaux  = { 'No quest on this server awards Abyssea - Misareaux fame yet. The bar is real and caps at level 6, but nothing currently moves it.' },
        vunkerl    = { 'No quest on this server awards Abyssea - Vunkerl fame yet. The bar is real and caps at level 6, but nothing currently moves it.' },
        attohwa    = { 'No quest on this server awards Abyssea - Attohwa fame yet. The bar is real and caps at level 6, but nothing currently moves it.' },
        altepa     = { 'No quest on this server awards Abyssea - Altepa fame yet. The bar is real and caps at level 6, but nothing currently moves it.' },
        grauberg   = { 'No quest on this server awards Abyssea - Grauberg fame yet. The bar is real and caps at level 6, but nothing currently moves it.' },
        uleguerand = { 'No quest on this server awards Abyssea - Uleguerand fame yet. The bar is real and caps at level 6, but nothing currently moves it.' },

        adoulin = {
            'Adoulin quests pay 30 fame per completion unless the script says otherwise, so a sweep of the city\'s quest lines climbs levels quickly.',
            'The three that pay less are "A Good Pair of Crocs", "A Shot in the Dark" and "It Sets My Heart Aflutter", at 6 apiece.',
            '"Transporting" and several other Adoulin quests open at fame level 2, so the first few completions unlock the next wave.',
        },
    },

    --[[
    * Provenance. One row per checkable claim; `line` is the index into
    * entries[area] whose sentence the row backs. check_guide.py asserts, for
    * every row: the quest file exists; the NPC key appears inside that
    * file's section for `zone`; the file awards `fame` points of `fameArea`;
    * and entries[area][line] still contains both `npc` and `town`.
    *
    * Lines carrying only flavour, thresholds or cross-references (auction
    * house notes, "doors this opens", the Jeuno 5-17 reminders) have no row
    * and are not checked -- the checker reports its own coverage so that
    * stays a visible number rather than a silent gap.
    --]]
    sources =
    {
        -- San d'Oria
        { area = 'sandoria', line = 1, quest = 'sandoria/Fear_of_the_Dark.lua',
          npc = 'Secodiand',   zone = 'NORTHERN_SAN_DORIA', town = "Northern San d'Oria",
          fame = 10, fameArea = 'SANDORIA' },
        { area = 'sandoria', line = 2, quest = 'sandoria/Warding_Vampires.lua',
          npc = 'Maloquedil',  zone = 'NORTHERN_SAN_DORIA', town = "Northern San d'Oria",
          fame = 16, fameArea = 'SANDORIA' },
        { area = 'sandoria', line = 3, quest = 'sandoria/Tigers_Teeth.lua',
          npc = 'Taumila',     zone = 'SOUTHERN_SAN_DORIA', town = "Southern San d'Oria",
          fame = 16, fameArea = 'SANDORIA' },
        { area = 'sandoria', line = 4, quest = 'sandoria/Lizard_Skins.lua',
          npc = 'Hanaa_Punaa', zone = 'SOUTHERN_SAN_DORIA', town = "Southern San d'Oria",
          fame = 10, fameArea = 'SANDORIA' },
        { area = 'sandoria', line = 4, quest = 'sandoria/The_Sweetest_Things.lua',
          npc = 'Raimbroy',    zone = 'SOUTHERN_SAN_DORIA', town = "Southern San d'Oria",
          fame = 10, fameArea = 'SANDORIA' },
        { area = 'sandoria', line = 4, quest = 'sandoria/Starting_a_Flame.lua',
          npc = 'Legata',      zone = 'SOUTHERN_SAN_DORIA', town = "Southern San d'Oria",
          fame = 10, fameArea = 'SANDORIA' },

        -- Bastok
        { area = 'bastok', line = 1, quest = 'bastok/Fallen_Comrades.lua',
          npc = 'Pavvke',  zone = 'BASTOK_MINES',   town = 'Bastok Mines',
          fame = 10, fameArea = 'BASTOK' },
        { area = 'bastok', line = 2, quest = 'bastok/Gourmet.lua',
          npc = 'Salimah', zone = 'BASTOK_MARKETS', town = 'Bastok Markets',
          fame = 10, fameArea = 'BASTOK' },
        { area = 'bastok', line = 4, quest = 'bastok/Chips.lua',
          npc = 'Cid',     zone = 'METALWORKS',     town = 'Metalworks',
          fame = 5,  fameArea = 'BASTOK' },
        { area = 'bastok', line = 4, quest = 'bastok/Chips.lua',
          npc = 'Cid',     zone = 'METALWORKS',     town = 'Metalworks',
          fame = 5,  fameArea = 'SANDORIA' },

        -- Windurst
        { area = 'windurst', line = 1, quest = 'windurst/Say_It_With_Flowers.lua',
          npc = 'Moari-Kaaori',   zone = 'WINDURST_WATERS', town = 'Windurst Waters',
          fame = 10, fameArea = 'WINDURST' },
        { area = 'windurst', line = 3, quest = 'windurst/Toraimarai_Turmoil.lua',
          npc = 'Ohbiru-Dohbiru', zone = 'WINDURST_WATERS', town = 'Windurst Waters',
          fame = 16, fameArea = 'WINDURST' },

        -- Jeuno. Every Jeuno quest pays the three nations, never Jeuno; the
        -- three named here are the ones the prose quotes amounts for.
        { area = 'jeuno', line = 2, quest = 'jeuno/Candle_Making.lua',
          npc = false, zone = false, town = false, fame = 13, fameArea = 'SANDORIA' },
        { area = 'jeuno', line = 2, quest = 'jeuno/The_Clockmaster.lua',
          npc = false, zone = false, town = false, fame = 17, fameArea = 'WINDURST' },
        { area = 'jeuno', line = 2, quest = 'jeuno/Save_the_Clock_Tower.lua',
          npc = false, zone = false, town = false, fame = 17, fameArea = 'BASTOK' },

        -- Selbina / Rabao
        { area = 'selbina', line = 2, quest = 'outlands/Open_Sesame.lua',
          npc = 'Lokpix', zone = 'EASTERN_ALTEPA_DESERT', town = 'Eastern Altepa Desert',
          fame = 30, fameArea = 'SELBINA_RABAO' },

        -- Norg
        { area = 'norg', line = 1, quest = 'windurst/Mihgos_Amigo.lua',
          npc = 'Nanaa_Mihgo', zone = 'WINDURST_WOODS', town = 'Windurst Woods',
          fame = 15, fameArea = 'NORG' },
        { area = 'norg', line = 3, quest = 'sandoria/A_Job_for_the_Consortium.lua',
          npc = false, zone = false, town = false, fame = 20, fameArea = 'NORG' },
        { area = 'norg', line = 3, quest = 'bastok/Shady_Business.lua',
          npc = false, zone = false, town = false, fame = 30, fameArea = 'NORG' },

        -- Abyssea
        { area = 'latheine', line = 1, quest = 'abyssea/Fear_of_the_Dark_III.lua',
          npc = 'Secodiand', zone = 'ABYSSEA_LA_THEINE', town = 'Abyssea - La Theine',
          fame = 10, fameArea = 'ABYSSEA_LATHEINE' },

        -- Adoulin. The three that undercut the npcUtil default of 30.
        { area = 'adoulin', line = 2, quest = 'adoulin/A_Good_Pair_of_Crocs.lua',
          npc = false, zone = false, town = false, fame = 6, fameArea = 'ADOULIN' },
        { area = 'adoulin', line = 2, quest = 'adoulin/A_Shot_in_the_Dark.lua',
          npc = false, zone = false, town = false, fame = 6, fameArea = 'ADOULIN' },
        { area = 'adoulin', line = 2, quest = 'adoulin/It_Sets_My_Heart_Aflutter.lua',
          npc = false, zone = false, town = false, fame = 6, fameArea = 'ADOULIN' },
    },

    --[[
    * Claims that are true by ABSENCE, which no per-quest row can express: a
    * search that must come back empty. check_guide.py runs each `area` over
    * every .lua under scripts/ looking for the two shapes that AWARD fame --
    * `addFame(xi.fameArea.X, n)` and a `fameArea = xi.fameArea.X` reward
    * block (which pays npcUtil's default 30 when no amount is given) -- and
    * fails if either is found. Reads (`getFame`, `getFameLevel`) match
    * neither, so a gate that merely tests the bar does not trip it. The day
    * someone implements Konschtat fame, the guide stops calling it
    * unreachable instead of quietly staying wrong.
    --]]
    absences =
    {
        { area = 'jeuno',      line = 1, fameArea = 'JEUNO',
          why  = 'Jeuno fame is described as purely derived; a direct award would make that false.' },
        { area = 'konschtat',  line = 1, fameArea = 'ABYSSEA_KONSCHTAT',
          why  = 'Guide says nothing raises Konschtat fame.' },
        { area = 'tahrongi',   line = 1, fameArea = 'ABYSSEA_TAHRONGI',
          why  = 'Guide says nothing raises Tahrongi fame.' },
        { area = 'misareaux',  line = 1, fameArea = 'ABYSSEA_MISAREAUX',
          why  = 'Guide says nothing raises Misareaux fame.' },
        { area = 'vunkerl',    line = 1, fameArea = 'ABYSSEA_VUNKERL',
          why  = 'Guide says nothing raises Vunkerl fame.' },
        { area = 'attohwa',    line = 1, fameArea = 'ABYSSEA_ATTOHWA',
          why  = 'Guide says nothing raises Attohwa fame.' },
        { area = 'altepa',     line = 1, fameArea = 'ABYSSEA_ALTEPA',
          why  = 'Guide says nothing raises Altepa fame.' },
        { area = 'grauberg',   line = 1, fameArea = 'ABYSSEA_GRAUBERG',
          why  = 'Guide says nothing raises Grauberg fame.' },
        { area = 'uleguerand', line = 1, fameArea = 'ABYSSEA_ULEGUERAND',
          why  = 'Guide says nothing raises Uleguerand fame.' },
    },
}
