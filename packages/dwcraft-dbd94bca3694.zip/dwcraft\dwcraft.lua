--[[
* DriftwoodXI -- dwcraft
*
* The crafting ledger: every craft's level, rank and next rank test; the
* specialization budget -- how many points you have spent past the free cap,
* how many are left, and which craft pays first when the budget runs dry --
* and the house rules crafting actually runs under on this server, stated
* from live settings rather than folklore.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It computes no skill, no cap and no arithmetic of its own. The server reads
* your real rows and answers `!dwc sync` in compact records under the sender
* name _DWCDATA (documentation/dwc_protocol.md), which this addon parses and
* blocks before the chat log sees them. The specialization numbers arrive
* computed by the same formula the skill-up code enforces; if the window
* shows a number, the server said that number. The one derivation permitted
* is display sugar the protocol doc explicitly grants: "next rank test at
* cap - 2", below Expert only.
*
* TURN IT OFF AND NOTHING IS LOST. Everything here works typed: !craft
* skills, !craft points, !craft rules. This window is the same answers with
* a table around them.
--]]

addon.name    = 'dwcraft';
addon.author  = 'DriftwoodXI';
addon.version = '1.0';
addon.desc    = 'Crafting ledger for DriftwoodXI -- skills, ranks, and the specialization budget.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. Nine
-- other addons own nine other senders; this addon must never contend for any
-- of them, which is why !dwc exists at all.
local DATA_SENDER = '_DWCDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout.
local PROTOCOL = 1;

-- Names for the ids the wire carries (dwc_protocol.md: ids only, names are
-- the addon's). Same order the server emits: Fishing first, then the eight
-- crafts the specialization budget counts.
local CRAFT_ORDER = { 48, 49, 50, 51, 52, 53, 54, 55, 56 };

local CRAFT_NAMES = {
    [48] = 'Fishing',
    [49] = 'Woodworking',
    [50] = 'Smithing',
    [51] = 'Goldsmithing',
    [52] = 'Clothcraft',
    [53] = 'Leathercraft',
    [54] = 'Bonecraft',
    [55] = 'Alchemy',
    [56] = 'Cooking',
};

-- xi.craftRank ordinals, server-side scripts/enum/craft_rank.lua.
local RANK_NAMES = {
    [0]  = 'Amateur',    [1]  = 'Recruit',  [2]  = 'Initiate',    [3]  = 'Novice',
    [4]  = 'Apprentice', [5]  = 'Journeyman', [6] = 'Craftsman',  [7]  = 'Artisan',
    [8]  = 'Adept',      [9]  = 'Veteran',  [10] = 'Expert',      [11] = 'Authority',
    [12] = 'Luminary',   [13] = 'Master',   [14] = 'Grandmaster', [15] = 'Legend',
};

-- The guild masters' ladder stops at Expert; the server derives the same
-- bound (dwc_protocol.md `k|`).
local LAST_TESTED_RANK = 10;

local state = T{
    open      = T{ false },

    -- skillid -> { raw, rank, cap, bonus }. A PLAIN TABLE keyed by id, not
    -- `T{ }` -- unknown keys on a T{} resolve through its metatable to the
    -- sugar methods, which is the dwbags round-7 bug, paid for once already.
    crafts    = { },

    -- The `p|` ledger record, parsed. nil until the first sync lands.
    ledger    = nil,

    -- rule key -> parts, from `r|` records. Only keys the server sent exist,
    -- so the panel cannot state a rule the server did not assert.
    rules     = { },

    -- The verb whose response is currently arriving. Records are only
    -- accepted between a `d|` and its `z|`, so a line that arrives on its
    -- own cannot half-fill the UI.
    inbound   = nil,

    status    = 'Loading...',
    statusBad = false,
    reported  = false,     -- a render error is worth saying once, not per frame
};

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A
* TIME. The client rate-limits outgoing chat, and a !dwc command is a chat
* line; anything over the limit is answered with "A command error occurred"
* before the server ever sees it. So everything queues here and drains at one
* command per SEND_INTERVAL, and duplicates collapse.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a window drawn sixty times a second
* asks once. The answer is tracked, not just the question: one lost command
* must not leave the panel stale for ever, and a retry that never terminates
* is a command loop, which is worse than a stale panel.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

local function refresh()
    requested = {};
end

local function needSync()
    local asked = requested['sync'];

    if (asked ~= nil) then
        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['sync'] = { at = os.clock(), answered = false, tries = 1 };
    end

    issue('!dwc sync');
end

--[[
* Record parsing. Every record is pipe-separated with a single-character
* type. Anything this addon does not recognise is ignored rather than being
* an error: a server newer than the addon must not break it.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwcraft.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            return;
        end

        state.inbound = parts[3];

        -- A response replaces its own section outright, and the reset runs
        -- FIRST: handleRecord is called under a pcall, and anything that
        -- throws after `state.inbound` is set must cost one record, not
        -- leave old rows for the records behind it to append to.
        if (state.inbound == 'sync') then
            state.crafts = { };
            state.ledger = nil;
            state.rules  = { };

            local asked = requested['sync'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        end

        return;
    end

    -- Status and error lines are accepted whatever the envelope state: the
    -- message saying why something was refused is worth more than the
    -- response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- Everything after the first pipe, not parts[2]: these carry prose.
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        -- Errors also go to the chat log: the window may already be closed,
        -- and "nothing happened" is the worst possible feedback.
        if (kind == 'e') then
            print(chat.header('dwcraft'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        if (state.inbound == 'sync' and state.status == 'Loading...') then
            state.status = '';
        end

        state.inbound = nil;

        return;
    end

    if (kind == 'k' and state.inbound == 'sync') then
        local id = tonumber(parts[2]) or 0;

        state.crafts[id] = {
            raw   = tonumber(parts[3]) or 0,
            rank  = tonumber(parts[4]) or 0,
            cap   = tonumber(parts[5]) or 0,
            bonus = tonumber(parts[6]) or 0,
        };

        return;
    end

    if (kind == 'p' and state.inbound == 'sync') then
        state.ledger = {
            used    = tonumber(parts[2]) or 0,
            left    = tonumber(parts[3]) or 0,
            budget  = tonumber(parts[4]) or 0,
            freeCap = tonumber(parts[5]) or 0,
            payer   = tonumber(parts[6]) or 0,
        };

        return;
    end

    if (kind == 'r' and state.inbound == 'sync') then
        local key = parts[2];

        if (key ~= nil and key ~= '') then
            state.rules[key] = { parts[3], parts[4], parts[5] };
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017. Layout after the 4-byte header: sName[15]
* at 0x08, Mes at 0x17. Any line whose sender is _DWCDATA is ours: it is
* consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwcraft_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is
    -- blocked before parsing rather than after: a malformed record must not
    -- leak into the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwcraft'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering.
--]]

local function fmtLevel(raw)
    return string.format('%.1f', raw / 10);
end

local function skillsPanel()
    -- NOTE: the third argument is ImGuiChildFlags, not a bool -- Ashita
    -- ships ImGui 1.90+, and a bool here raises a Lua error on every frame.
    imgui.BeginChild('##dwcraft_skills', { 0, 236 }, ImGuiChildFlags_Borders);

    imgui.Text('Your crafts');
    imgui.SameLine();
    imgui.TextDisabled('-- level, rank, and where the next wall is');
    imgui.Separator();

    if (imgui.BeginTable('##dwcraft_skills_table', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        -- WidthFixed throughout, like the other Driftwood addons: only the
        -- flags they already use are proven to exist in this environment's
        -- ImGui bindings, and a nil flag global is a Lua error per frame.
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 104, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 52, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 96, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 176, 0);

        for _, id in ipairs(CRAFT_ORDER) do
            local row = state.crafts[id];

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(CRAFT_NAMES[id]);

            if (row == nil) then
                imgui.TableNextColumn();
                imgui.TextDisabled('-');
                imgui.TableNextColumn();
                imgui.TableNextColumn();
            else
                local specialized = state.ledger ~= nil and id ~= 48 and row.raw > state.ledger.freeCap;

                imgui.TableNextColumn();

                if (specialized) then
                    -- Past the free cap: these are the levels the shared
                    -- budget is paying for.
                    imgui.TextColored(theme.colors.pin, fmtLevel(row.raw));
                else
                    imgui.Text(fmtLevel(row.raw));
                end

                if (row.bonus ~= 0 and imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('+%d from gear or guild image support', row.bonus));
                end

                imgui.TableNextColumn();
                imgui.Text(RANK_NAMES[row.rank] or string.format('rank %d', row.rank));

                imgui.TableNextColumn();

                if (row.raw >= row.cap * 10) then
                    -- At this rank's cap: skill-ups have stopped until the
                    -- guild test (synthutils hard-stops there).
                    if (row.rank < LAST_TESTED_RANK) then
                        imgui.TextColored(theme.colors.warn, string.format('at cap %d -- see your guild for the test', row.cap));
                    else
                        imgui.TextColored(theme.colors.ok, string.format('at cap %d', row.cap));
                    end
                elseif (row.rank < LAST_TESTED_RANK) then
                    -- The derivation the protocol doc grants: the guild
                    -- offers the next test from cap - 2.
                    imgui.TextDisabled(string.format('cap %d, next rank test at %d', row.cap, row.cap - 2));
                else
                    imgui.TextDisabled(string.format('cap %d', row.cap));
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();
end

local function ledgerPanel()
    imgui.BeginChild('##dwcraft_ledger', { 0, 96 }, ImGuiChildFlags_Borders);

    imgui.Text('Specialization');
    imgui.SameLine();
    imgui.TextDisabled('-- the budget past the free cap, shared by all crafts');
    imgui.Separator();

    local led = state.ledger;

    if (led == nil) then
        imgui.TextDisabled('Waiting for the server...');
    else
        imgui.Text(string.format('%d of %d points used, %d free.', led.used, led.budget, led.left));
        imgui.SameLine();
        imgui.TextDisabled('(a point is 0.1 craft levels)');

        imgui.TextDisabled(string.format('Every craft levels freely to %s -- enough budget for three crafts at 110. Fishing never counts.',
            fmtLevel(led.freeCap)));

        if (led.payer ~= 0) then
            imgui.TextColored(theme.colors.hint, string.format('%s is your highest specialized craft -- it pays first if the budget runs dry.',
                CRAFT_NAMES[led.payer] or ('craft ' .. led.payer)));
        end
    end

    imgui.EndChild();
end

local function rulesPanel()
    imgui.BeginChild('##dwcraft_rules', { 0, 0 }, ImGuiChildFlags_Borders);

    imgui.Text('House rules');
    imgui.SameLine();
    imgui.TextDisabled('-- from the server\'s live settings, not folklore');
    imgui.Separator();

    -- Only rules the server asserted exist here (dwc_protocol.md r|): a line
    -- the server did not send is not rendered, so this panel cannot claim a
    -- tuning the box is not running.
    local said = false;

    if (state.rules.hq ~= nil) then
        imgui.Text(string.format('HQ chance: %sx retail, skill-based only.', state.rules.hq[1] or '?'));
        said = true;
    end

    if (state.rules.skill ~= nil) then
        imgui.Text(string.format('Skill-ups: %sx chance, %sx amount.', state.rules.skill[1] or '?', state.rules.skill[2] or '?'));
        said = true;
    end

    if (state.rules.modern ~= nil and state.rules.modern[1] == '1') then
        imgui.Text('Modern skill-up rules: recipes up to 11 levels below you still teach.');
        imgui.TextColored(theme.colors.hint, 'Day and moon folklore does nothing here. Craft when you like.');
        said = true;
    end

    if (not said) then
        imgui.TextDisabled('Waiting for the server...');
    end

    imgui.EndChild();
end

local function renderWindow()
    if (state.status ~= '') then
        if (state.statusBad) then
            imgui.PushStyleColor(ImGuiCol_Text, theme.colors.err);
            imgui.TextWrapped(state.status);
            imgui.PopStyleColor();
        else
            imgui.TextDisabled(state.status);
        end
    end

    skillsPanel();
    ledgerPanel();
    rulesPanel();

    needSync();
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather
* than the addon: an error thrown inside d3d_present is raised sixty times a
* second and the addon host answers a long enough run by unloading the addon.
* Begin and End stay outside the pcall to keep ImGui's window stack balanced;
* the error is reported once and the window closes itself. Everything it does
* is still reachable as !craft commands, so closing it is a real fallback.
--]]
ashita.events.register('d3d_present', 'dwcraft_present', function ()
    -- Before the visibility check: a request issued a moment before the
    -- window was closed still has to reach the server.
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    imgui.SetNextWindowSize({ 452, 470 }, ImGuiCond_FirstUseEver);

    local visible = imgui.Begin('DriftwoodXI Crafting##dwcraft', state.open, ImGuiWindowFlags_NoScrollbar);

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwcraft'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwcraft'):append(chat.message('Window closed. Everything it does also works as !craft commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

local function openWindow()
    state.open[1] = true;

    -- Reopening is a fresh start for error reporting too: `reported` only
    -- exists to stop one bad frame printing sixty lines a second.
    state.reported  = false;
    state.status    = 'Loading...';
    state.statusBad = false;

    refresh();
end

--[[
* Watch what the player sends.
*
* Bare `!craft` (and `!craft ui`) is intercepted and opens this window
* instead of printing the server's summary -- that line is blocked and never
* leaves the client. Every other `!craft` command passes through untouched:
* they are read-only prose and the window has nothing to learn from them.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE: the client's
* rate limit is on chat, not on this addon, so a query fired in the same
* frame as something the player typed is the one that gets dropped. Stamping
* the player's own line as a send makes the follow-up wait its interval.
--]]
ashita.events.register('packet_out', 'dwcraft_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!craft' or lower == '!craft ui' or lower == '!craft window' or lower == '!craft gui') then
        e.blocked = true;

        if (state.open[1]) then
            state.open[1] = false;
        else
            openWindow();
        end

        return;
    end

    if (lower:sub(1, 4) ~= '!dwc') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwcraft_command', function (e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwcraft' and args[1] ~= '/craft')) then
        return;
    end

    e.blocked = true;

    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end);

ashita.events.register('load', 'dwcraft_load', function ()
    print(chat.header('dwcraft'):append(chat.message('!craft (or /craft) opens the crafting ledger. Everything it shows also works typed: !craft skills | points | rules.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new ledger -- and a synth mid-session moves the
-- numbers too, which is why reopening the window always re-asks.
ashita.events.register('packet_in', 'dwcraft_zonein', function (e)
    if (e.id == 0x000A) then
        state.crafts    = { };
        state.ledger    = nil;
        state.rules     = { };
        state.status    = 'Loading...';
        state.statusBad = false;

        refresh();
    end
end);
