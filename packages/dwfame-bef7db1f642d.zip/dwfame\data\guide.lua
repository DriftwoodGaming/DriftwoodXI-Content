--[[
* dwfame guide data -- the fastest reliable way to raise each fame, authored
* against THIS server's own quest scripts (scripts/quests/...), not a wiki.
* Every NPC, item, count and fame amount below was read out of the script
* that pays it, so the guide can never promise a turn-in the server does not
* honour. Amounts are base points, before the server's fame multiplier --
* the window states the live rate beside them.
*
* Pure data: { entries = { [areaKey] = { 'line', ... } } }. The addon renders
* these lines under the matching area in the Guide tab and nothing else
* reads this file. Area keys match fame_core.lua's AREAS table.
--]]

return {
    kind = 'guide',

    entries = {
        sandoria = {
            'Fastest: "Fear of the Dark" -- trade 2 Bat Wings to Secodiand (Southern San d\'Oria). Repeats forever: 10 fame + 200 gil per trade.',
            'Bat Wings drop from bats all over Ronfaure and the Ranguemont Pass, and are usually cheap on the Auction House in stacks.',
            'Also repeatable in town: "Lizard Skins" (Lusiane), "The Sweetest Things" (Portaure), and "Starting a Flame" (Guilberdrier) each pay 10 per run.',
            'Trial-size Trial by Ice (Cloister of Frost) pays 20 San d\'Oria fame per win; Trial by Wind pays 10 here and 10 in Bastok.',
            'Every Jeuno city quest also pays 5-17 San d\'Oria fame, so a Jeuno session raises all three nations at once.',
        },

        bastok = {
            'Fastest: "Gourmet" -- trade a Sleepshroom, a Treant Bulb and a Wild Onion to Salimah (Bastok Mines). Repeats forever: 10 fame per trade.',
            'Steady alternative: "Groceries" -- Meat Jerky to Tami (Bastok Mines), 10 fame per repeat. Jerky is craftable and cheap in stacks.',
            '"Chips" (Metalworks, Cid\'s lab) pays 5 Bastok AND 5 San d\'Oria per run of the three colored chips -- Carmine, Cyan and Gray.',
            'Trial-size Trial by Earth (Cloister of Tremors) pays 20 Bastok fame per win.',
            'Every Jeuno city quest also pays 5-17 Bastok fame.',
        },

        windurst = {
            'Fastest: "Say It with Flowers" -- after the first flower delivery for Moari-Kaaori (Windurst Waters), every Tahrongi Cactus you trade her pays 10 fame.',
            'Cactus stems are all over Tahrongi Canyon\'s cacti -- an evening of gathering funds a long stretch of turn-ins.',
            'Mhaura and Kazham quests pay Windurst fame too (they share the same fame area).',
            'Trial-size Trial by Fire and Trial by Lightning each pay 20 Windurst fame per win.',
            'Every Jeuno city quest also pays 5-17 Windurst fame.',
        },

        jeuno = {
            'Jeuno fame rises two ways at once: it has its own counter, and it adds the AVERAGE of your three nation fames on top. Raise the nations and Jeuno follows for free.',
            'Jeuno\'s own quests all pay 5-17 fame to ALL THREE nations per completion -- "Candle Making" (13 each) and "The Clockmaster" (17 each, needs Jeuno fame 5) are the standouts.',
            'Notable doors this fame opens: "Tenshodo Membership" and "The Goblin Tailor" at level 3, "The Clockmaster" and "Save the Clock Tower" at level 5.',
        },

        selbina = {
            'Selbina and Rabao have no fame counter of their own: your standing there is the AVERAGE of San d\'Oria and Bastok fame. Raise those two and this bar moves by itself.',
            'The quickest pair: "Fear of the Dark" (San d\'Oria, 2 Bat Wings) and "Gourmet" (Bastok, three cheap drops), 10 each per repeat.',
            'Trial-size Trial by Wind (Cloister of Gales) pays 10 to both nations in one win -- the single most efficient fight for this bar.',
        },

        norg = {
            'Fastest: "Mihgo\'s Amigo" -- trade 4 Yagudo Bead Necklaces to Nanaa Mihgo (Windurst Woods). 30 fame the first time, 15 per repeat -- and it is Norg fame, despite the Windurst address.',
            'Necklaces drop steadily from Yagudo in Giddeus; stacks are common on the Auction House.',
            '"A Job for the Consortium" (San d\'Oria, needs Norg fame 1) pays 20; "Shady Business" (Bastok) pays 30 once.',
            'Trial-size Trial by Water (Cloister of Tides) pays 20 Norg fame per win.',
            'Doors this fame opens: the Damp Scroll line and "Like Shining Subligar/Leggings" at level 3, "The Sahagin\'s Stash" and "Stop Your Whining" at level 4.',
        },

        konschtat  = { 'Abyssea fame comes from the quests taken inside that Abyssea zone -- each zone tracks its own standing and caps at level 6.' },
        tahrongi   = { 'Abyssea fame comes from the quests taken inside that Abyssea zone -- each zone tracks its own standing and caps at level 6.' },
        latheine   = {
            'Abyssea fame comes from the quests taken inside that Abyssea zone -- each zone tracks its own standing and caps at level 6.',
            '"Fear of the Dark III" here pays 10 per completion, and "Lost Memories" opens at fame level 5.',
        },
        misareaux  = { 'Abyssea fame comes from the quests taken inside that Abyssea zone -- each zone tracks its own standing and caps at level 6.' },
        vunkerl    = { 'Abyssea fame comes from the quests taken inside that Abyssea zone -- each zone tracks its own standing and caps at level 6.' },
        attohwa    = { 'Abyssea fame comes from the quests taken inside that Abyssea zone -- each zone tracks its own standing and caps at level 6.' },
        altepa     = { 'Abyssea fame comes from the quests taken inside that Abyssea zone -- each zone tracks its own standing and caps at level 6.' },
        grauberg   = { 'Abyssea fame comes from the quests taken inside that Abyssea zone -- each zone tracks its own standing and caps at level 6.' },
        uleguerand = { 'Abyssea fame comes from the quests taken inside that Abyssea zone -- each zone tracks its own standing and caps at level 6.' },

        adoulin = {
            'Adoulin fame comes from the city\'s own quest lines -- most pay the standard 30 fame per completion, so a sweep of the quest board climbs levels quickly.',
            '"Transporting" and several other Adoulin quests open at fame level 2, so the first few completions unlock the next wave.',
        },
    },
}
