--[[
* DriftwoodXI -- dwesper
*
* Magicite, Espers and attunement, in a window (PLANS/DWESPER_PLAN.md). Kills
* pay Magicite -- a wallet of thirty counters, eight elements and twenty-two
* jobs -- and Magicite plus Esper Cores make Espers: the thirty-one Final
* Fantasy VI Espers and a thirty-second, Driftwood. One Esper is equipped at a
* time (two once Driftwood is mastered), fighting with it equipped attunes it,
* and an equipped or mastered Esper lends its spells and job abilities to
* whatever job the player is on.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited whole
* through dwspoils). It carries no roster, no price table and no rate: every
* name, tier, price, grant and line of prose it draws arrived on the wire as a
* record, and the addon authors only navigation tokens -- the eight element
* words and the tier words, which are the game's own. The seven lines it can
* send (`sync`, `roster`, `create`, `equip`, `unequip`, `cast`, `use`) reach
* exactly the dispatch `!esper` typed reaches, and the server enforces every
* rule: the prices are re-read from the roster at confirm, the engaged gate,
* the Core count, the Driftwood condition. A greyed button here is a courtesy.
*
* THREE TABS. Espers is a 4x8 grid of the thirty-two, each tile its name in
* its tier's colour, its element, an attunement bar for an owned one and a
* badge for equipped or mastered; selecting a tile shows what it grants, its
* line, its price against the Magicite you hold, its Cores against the Cores
* you hold, and Create / Equip / Unequip. Magicite is the wallet: eight element
* rows then twenty-two job rows, amount and lifetime. Grants is every spell and
* ability the ACTIVE Espers -- equipped or mastered -- lend, with a Cast or Use
* button that asks the server to cast it at your current target.
*
* CASTING GOES THROUGH THE SERVER (T10). The stock client builds its magic
* menu from the current main and sub job, so a granted Blizzard III on a WAR is
* not something the client can send. The Grants buttons send `!dwes cast
* <spellId> <targetIndex>`, and the `command` hook below rewrites a typed or
* macro'd `/ma "Blizzard III" <t>` -- for a GRANTED spell only -- into the same
* line, so macros work. Everything that is not a granted spell or ability
* passes through untouched. The `intercept` setting turns the hook off.
*
* IT TAKES NO ZONE-IN SLOT. The first ask is LAZY -- the first frame the
* window is actually shown in a zone -- so a player who never opens it never
* handshakes and the login burst is exactly as long as it was before (the
* dwspoils decision; see dwecho.lua's ZONE_ORDER, which this addon is
* deliberately absent from). While shown it re-asks `sync` every sixty
* seconds and after every answered create, equip or unequip; the static
* roster is asked ONCE per session and cached, re-asked on a zone line only
* when the cache is empty (T15: bursts need ceilings).
*
* ONE ASK IN FLIGHT. Reads are queued and deduplicated; writes -- create,
* equip, unequip, cast, use -- go out one at a time, never collapsed, never
* retried, and the buttons disarm until the envelope's `z|` (or a refusal, or
* five seconds) clears the latch. A refusal is drawn in the window's status
* line and never printed to chat.
*
* TURN IT OFF AND NOTHING IS LOST. `!esper` typed says all of it in prose, and
* `!esper cast <spell>` is the same door the buttons press.
*
* Over `!dwes` (`documentation/dwes_protocol.md`, sender `_DWESDATA`); the
* offline guard is tools/dwesper/harness_dwesper.py.
--]]

addon.name    = 'dwesper';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.0';
addon.desc    = 'DriftwoodXI Espers: your Magicite, the Espers you can make and have made, and the spells and abilities they lend you.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line. The
-- THIRD two-letter door (`dwsp`, `dwto`, now `dwes`): dwa.lua through dwz.lua
-- are all doors already, and the registry is dww.lua's header.
local DATA_SENDER = '_DWESDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

--[[
* EVERY NUMBER OFF THE WIRE COMES THROUGH HERE (the dwnemesis shape). LuaJIT
* -- which is what Ashita runs -- answers `tonumber` for 'inf', 'nan', '0x10'
* and '2.5' as readily as for '7', and everything downstream is a pile of
* string.format('%d'). A field that is not a plain integer inside the wire's
* own range is not a number this window can draw, so it reads as the record's
* default and the rest of the record still lands.
--]]
local WIRE_MAX = 2147483647;

local function wireInt(text, default)
    local value = tonumber(text);

    if (value == nil
            or value ~= value                            -- nan
            or value < -WIRE_MAX or value > WIRE_MAX     -- inf, and anything absurd
            or value ~= math.floor(value)) then
        return default or 0;
    end

    return value;
end

--[[
* THE NAVIGATION TOKENS THIS ADDON AUTHORS, and the whole of them. Magicite
* kinds 1..8 are the eight elements in the engine's own order; kinds 9..30 are
* 8 + the job id (WAR = 1 .. RUN = 22). The job short names are asked of the
* client's own resource manager first (`jobs.names_abbr`) and fall back to
* these twenty-two three-letter words -- the same list dwmerits carries --
* only on an install whose string table does not answer. The tier words are
* the plan's (T8). Nothing else here is a name: Esper names, prices and grants
* all ride the `r|` record.
--]]
local ELEMENT_NAMES = { 'Fire', 'Ice', 'Wind', 'Earth', 'Thunder', 'Water', 'Light', 'Dark' };

local JOB_ABBR = {
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK', 'BST', 'BRD',
    'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU', 'COR', 'PUP', 'DNC', 'SCH',
    'GEO', 'RUN',
};

local TIER_NAMES = { [1] = 'Minor', [2] = 'Major', [3] = 'Greater', [4] = 'Driftwood' };

local ELEMENT_COUNT = 8;
local JOB_COUNT     = 22;
local KIND_COUNT    = ELEMENT_COUNT + JOB_COUNT;
local ESPER_COUNT   = 32;
local GRID_COLUMNS  = 4;

-- Attunement units per T1: MASTERY = 100000 units is 100 percent. A mirror of
-- the plan's constant, used only to draw the bar; the server judges mastery.
local MASTERY_UNITS = 100000;

-- Job abilities live at DAT ids 512..1535 in the client's resource table and
-- the wire carries the SERVER id (dwgambits' ABILITY_CLIENT_OFFSET, the same
-- offset dwg_protocol.md documents).
local ABILITY_CLIENT_OFFSET = 512;

--[[
* Persisted presentation state, through Ashita's settings library (the
* dwspoils shape). Two scalars: which tab this character was last looking at,
* and whether the `/ma` / `/ja` hook is on. Nothing the server said is ever
* written to disk -- a cached wallet is a wallet that can be wrong, and this
* one is cheap to ask for again.
*
* THE DEFAULTS ARE A SUGAR TABLE, and that `T` is load-bearing rather than
* decorative: settings.lua calls `defaults:copy(true)` (:180) and
* `settings:merge(defaults)` (:338), both sugar-table methods, so a plain
* table raises 'attempt to call a nil value'. The pcall below hides it at
* load; the library's own UNGUARDED packet_in handler re-loads on the
* zone-enter packet (:538) and Ashita answers a raise inside an event callback
* by UNLOADING THE ADDON -- so a missing `T` works at the desk and then the
* window disappears on the player's next zone line.
--]]
local defaultConfig = T{
    tab       = 'espers',
    intercept = true,
};

local config = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and type(loaded) == 'table') then
    config = loaded;
end

local TABS = { 'espers', 'magicite', 'grants' };

local function rememberedTab(cfg)
    if (type(cfg) ~= 'table' or type(cfg.tab) ~= 'string') then
        return 'espers';
    end

    for _, key in ipairs(TABS) do
        if (cfg.tab == key) then
            return key;
        end
    end

    return 'espers';
end

local function rememberedIntercept(cfg)
    if (type(cfg) ~= 'table') then
        return true;
    end

    -- Absent (a file from before the setting existed) reads as ON, the
    -- default; only an explicit false turns the hook off.
    return cfg.intercept ~= false;
end

--[[
* Outbound: `!dwes` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat.
--]]
local SEND_INTERVAL = 1.2;

-- The answer clock, per read (the dwfame shape): one retry after five
-- seconds, then the silent latch. An unknown `!` command falls through to
-- PUBLIC /say on a server without dwes.lua, and the latch is what contains
-- that to two lines rather than one every send interval, forever.
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- A write's own clock: no retry, just the buttons back. The next sync shows
-- whatever really happened.
local WRITE_TIMEOUT = 5.0;

-- How often an OPEN window re-asks `sync`. Magicite moves on every paid kill
-- and attunement with it, so a minute is the backstop between the re-asks
-- every answered write already fires.
local POLL_INTERVAL = 60.0;

--[[
* THE LINES THIS ADDON EVER SENDS, SPELLED OUT IN FULL.
*
* Written as whole literals rather than built with `'!dwes ' .. verb`, and
* the reason is a gate rather than taste: harness_dwsuite.py discovers every
* verb every addon sends by reading its `'!dwX <verb>'` literals and proves
* some module under modules/driftwoodxi spells that word. A concatenated verb
* is invisible to that scan -- so the addon would be exempt from the one check
* that catches an addon newer than its server sending a verb the doorway has
* never heard of, whose refusal is a PUBLIC line in chat on every window open.
--]]
local LINES = {
    sync   = '!dwes sync',
    roster = '!dwes roster',
};

local WRITE_LINES = {
    create  = '!dwes create %d',
    equip   = '!dwes equip %d %d',
    unequip = '!dwes unequip %d',
    cast    = '!dwes cast %d %d',
    use     = '!dwes use %d %d',
};

local state = T{
    open = T{ false },

    -- The committed picture, swapped in at `z|` from staging copies so a
    -- half-arrived reply can never half-fill the window (dwbags' rule).
    sheet   = nil,       -- the s| record, as one table
    sheetAt = nil,
    wallet  = { },       -- [kind] = { amount, lifetime }, merged per w|
    owned   = { },       -- [id] = { attune, mastered, slot }, merged per p|
    roster  = nil,       -- [id] = { name, tier, elem, jobA, jobB, ... } committed whole
    rosterAt = nil,

    pendingSheet  = nil,
    pendingWallet = nil,
    pendingOwned  = nil,
    pendingRoster = nil,

    inbound   = nil,     -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    reported  = false,   -- a render error is worth saying once, not per frame

    -- The answer clock for READS, keyed by verb: { [verb] = { at, tries } }.
    requested    = T{ },
    serverSilent = false,

    -- The one WRITE in flight: { verb, at }. Buttons and the hook disarm
    -- while set; cleared by the envelope's z|, by any refusal, or by
    -- WRITE_TIMEOUT.
    pendingWrite = nil,

    -- An unknown d| version was seen: one warning, then silence until a zone
    -- line re-probes it. A click does NOT lift this one.
    refused = false,

    -- Per-verb unknown-verb latches (the dwbags shape): a server older than
    -- this addon answers a verb it lacks with its unknown-verb sentence, and
    -- that verb is then not asked again until a zone line.
    unsupported = { },

    -- The lazy hello has fired in THIS zone, and the roster has been asked
    -- for this session.
    helloSent   = false,
    rosterAsked = false,
    polledAt    = nil,

    -- Which tile is selected on the Espers tab, by esper id.
    selected = nil,

    -- The Grants tab's rows, rebuilt when owned/roster commit rather than
    -- walked sixty times a second: { kind, id, name, from, buttonId }, plus
    -- the two name maps the command hook reads.
    grants          = { },
    grantSpellByName   = { },
    grantAbilityByName = { },

    -- Which tab is drawn, restored from the settings file; `wantTab` is a tab
    -- the player named on the command line and is spent the frame it is taken.
    tab     = rememberedTab(config),
    wantTab = nil,

    -- The `/ma` / `/ja` hook switch, as the checkbox buffer.
    intercept = T{ rememberedIntercept(config) },
};

-- The settings profile changes when the CHARACTER does, and the library hands
-- the new one over here.
pcall(settings.register, 'settings', 'dwesper_settings_update', function (s)
    if (type(s) ~= 'table') then
        return;
    end

    config             = s;
    state.tab          = rememberedTab(config);
    state.intercept[1] = rememberedIntercept(config);
end);

local function saveConfig()
    config.tab       = state.tab;
    config.intercept = state.intercept[1] == true;

    pcall(settings.save);
end

--[[
* THE TOOLTIPS, in one table rather than one literal per call site, so two
* controls that mean the same thing cannot drift into two sentences.
--]]
local TIPS = {
    refresh      = 'Ask the server again, now. Works even after "No answer from the server".',
    refreshStale = 'This addon is not the version the server speaks, and Refresh cannot fix that -- update dwesper through the launcher.',
    intercept    = 'When on, a typed or macro\'d /ma or /ja naming a spell or ability an active Esper lends you is sent to the server to cast instead of to the client, which does not know your job can cast it. Anything not lent by an Esper passes through untouched.',
    tile         = 'Click to see what this Esper grants, what it costs, and the buttons.',
    attune       = 'Attunement. It accrues only while this Esper is equipped and only on kills that paid experience; 100 percent is mastered, forever.',
    cores        = 'Esper Cores are a wallet counter, never an item. They drop from Unleashed kills, once per paid account per kill.',
    wallet       = 'Magicite is currency, never an item: every kill that pays you experience pays the element of what died, its job, and your own job.',
    lifetime     = 'Everything this character has ever earned of this kind, spent or not.',
    grants       = 'Every spell and job ability the Espers you have EQUIPPED or MASTERED lend you right now, whatever job you are on.',
    cast         = 'Ask the server to cast this at your current target (or at yourself when nothing is targeted). Your recast is honoured.',
    use          = 'Ask the server to use this on your current target (or on yourself when nothing is targeted).',
    create       = 'Make this Esper. The Magicite and the Cores are spent by the server, which re-reads the price from its own roster.',
    equip1       = 'Equip this Esper in slot 1. Not while engaged.',
    equip2       = 'Equip this Esper in slot 2, opened by mastering Driftwood. Not while engaged.',
    unequip      = 'Take this Esper off. Attunement is KEPT; only what it lends you stops until it is equipped again. Not while engaged.',
    pending      = 'One action is in flight. Buttons come back when the server answers, or after five seconds.',
};

--[[
* Record parsing (dwes protocol, client disciplines 1-3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

-- A comma-separated id list off one record field, as a plain array of ints.
-- An empty field is an empty list; a token that is not an integer is skipped.
local function csvIds(text)
    local ids = { };

    if (type(text) ~= 'string' or text == '') then
        return ids;
    end

    for token in string.gmatch(text, '[^,]+') do
        local id = wireInt(token, -1);

        if (id > 0) then
            ids[#ids + 1] = id;
        end
    end

    return ids;
end

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST. This runs on every rendered frame for
    -- the life of the session and the queue is empty in almost all of them,
    -- while echo.canSend() is three calls across the C++ boundary.
    if (#queue == 0) then
        return;
    end

    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

-- Is a read outstanding? Deliberately NOT a render helper: the suite's
-- `d|`-wipe gate judges a name by whether some imgui-drawing function reads
-- it, and the ask table is bookkeeping rather than a pane.
local function asking()
    return next(state.requested) ~= nil;
end

local function latched()
    return state.refused or state.serverSilent;
end

-- Anything in flight at all -- a read or a write. ONE ask at a time.
local function busy()
    return asking() or state.pendingWrite ~= nil;
end

-- `force` is the Refresh button: a click is the player asking, and the silent
-- latch exists to contain AUTOMATIC re-asks, not to ignore the player. The
-- PROTOCOL refusal and the unknown-verb latches are not lifted by a click.
local function ask(verb, force)
    if (state.refused) then
        return;
    end

    if (LINES[verb] == nil or state.unsupported[verb]) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    if (not force and busy()) then
        return;
    end

    -- A CLICK REPLACES THE OLD ANSWER. Only a REFUSAL is dropped; a note is
    -- still true.
    if (force and state.statusBad) then
        state.status    = '';
        state.statusBad = false;
    end

    state.requested[verb] = { at = os.clock(), tries = 1 };

    if (verb == 'sync') then
        state.polledAt = os.clock();
    elseif (verb == 'roster') then
        state.rosterAsked = true;
    end

    issue(LINES[verb]);
end

--[[
* The one WRITE path (dwmerits' sendEdit shape). Never queued with the reads,
* never deduplicated, never retried: one in flight, buttons and the hook
* disarmed until its envelope closes. `line` is one of WRITE_LINES already
* formatted; `verb` names it for the clock.
--]]
local function sendWrite(verb, line)
    if (state.refused or state.unsupported[verb]) then
        return false;
    end

    if (busy()) then
        state.status    = 'One action at a time -- the last one has not been answered yet.';
        state.statusBad = true;

        return false;
    end

    -- A click handed to a zoning client is not delayed, it is lost -- and a
    -- write is never queued, so there is nothing to hold it in. Say so.
    if (not echo.canSend()) then
        state.status    = 'Not while the client is zoning -- that was not sent. Try again in a moment.';
        state.statusBad = true;

        return false;
    end

    state.pendingWrite = { verb = verb, at = os.clock() };
    lastSend           = os.clock();

    echo.send(line);

    return true;
end

local function checkAnswers()
    local now = os.clock();

    for verb, asked in pairs(state.requested) do
        -- THE CLOCK DOES NOT AGE WHILE THE CLIENT IS ZONING -- it is
        -- RE-STAMPED, not merely skipped (dwspoils' note).
        if (not echo.canSend()) then
            asked.at = now;
        elseif ((now - asked.at) >= ANSWER_TIMEOUT) then
            if (asked.tries >= ANSWER_TRIES) then
                -- NO SENTENCE IS WRITTEN HERE: the header draws the silent
                -- latch in preference to state.status.
                state.requested[verb] = nil;
                state.serverSilent    = true;
            else
                asked.at    = now;
                asked.tries = asked.tries + 1;

                issue(LINES[verb]);
            end
        end
    end

    if (state.pendingWrite ~= nil and (now - state.pendingWrite.at) >= WRITE_TIMEOUT) then
        state.pendingWrite = nil;
        state.status       = 'No answer to that one -- nothing retried. Refresh to see where things stand.';
        state.statusBad    = true;
    end
end

--[[
* The client's own names, asked ONCE PER ID (the dwspoils resourceOf shape).
* The DATs are static from load, so an id that answers nil now answers nil
* forever and a negative result caches as safely as a positive one. `false`
* is "the client does not know this id"; nil is "not asked yet".
--]]
local spellNames   = { };
local abilityNames = { };
local jobNames     = { };

local function spellName(id)
    local hit = spellNames[id];

    if (hit ~= nil) then
        return hit ~= false and hit or string.format('spell %d', id);
    end

    local ok, name = pcall(function ()
        local spell = AshitaCore:GetResourceManager():GetSpellById(id);

        return spell ~= nil and spell.Name ~= nil and spell.Name[1] or nil;
    end);

    if (ok and type(name) == 'string' and name ~= '') then
        spellNames[id] = name;

        return name;
    end

    spellNames[id] = false;

    return string.format('spell %d', id);
end

local function abilityName(id)
    local hit = abilityNames[id];

    if (hit ~= nil) then
        return hit ~= false and hit or string.format('ability %d', id);
    end

    local ok, name = pcall(function ()
        local ability = AshitaCore:GetResourceManager():GetAbilityById(id + ABILITY_CLIENT_OFFSET);

        return ability ~= nil and ability.Name ~= nil and ability.Name[1] or nil;
    end);

    if (ok and type(name) == 'string' and name ~= '') then
        abilityNames[id] = name;

        return name;
    end

    abilityNames[id] = false;

    return string.format('ability %d', id);
end

-- A job's three-letter name: the client's string table first, the local
-- list second, the bare number last.
local function jobName(jobId)
    local hit = jobNames[jobId];

    if (hit ~= nil) then
        return hit;
    end

    local ok, name = pcall(function ()
        return AshitaCore:GetResourceManager():GetString('jobs.names_abbr', jobId);
    end);

    if (not (ok and type(name) == 'string' and name ~= '')) then
        name = JOB_ABBR[jobId] or string.format('job %d', jobId);
    end

    jobNames[jobId] = name;

    return name;
end

-- A Magicite kind's name: an element word for 1..8, a job word for 9..30.
local function kindName(kind)
    if (kind >= 1 and kind <= ELEMENT_COUNT) then
        return ELEMENT_NAMES[kind];
    end

    if (kind > ELEMENT_COUNT and kind <= KIND_COUNT) then
        return jobName(kind - ELEMENT_COUNT);
    end

    return string.format('kind %d', kind);
end

local function tierName(tier)
    return TIER_NAMES[tier] or string.format('tier %d', tier);
end

local function tierColour(tier)
    if (tier == 4) then
        return theme.colors.pin;
    elseif (tier == 3) then
        return theme.colors.warn;
    elseif (tier == 2) then
        return theme.colors.hint;
    end

    return theme.colors.text;
end

--[[
* THE GRANTS, REBUILT ON COMMIT -- never per frame. The union of every spell
* and ability lent by an ACTIVE Esper: one that is equipped (slot 1 or 2) or
* mastered. Walked in roster id order so the tab reads the way the grid does;
* an id lent by two Espers appears once, credited to the first. The two name
* maps are what the `/ma` / `/ja` hook consults, lowercased once here rather
* than on every command the player types.
--]]
local function rebuildGrants()
    local rows      = { };
    local bySpell   = { };
    local byAbility = { };
    local seenSpell = { };
    local seenAbil  = { };

    if (state.roster ~= nil) then
        for id = 1, ESPER_COUNT do
            local row   = state.roster[id];
            local owned = state.owned[id];

            if (row ~= nil and owned ~= nil and (owned.mastered or owned.slot > 0)) then
                for _, spellId in ipairs(row.spells) do
                    if (not seenSpell[spellId]) then
                        seenSpell[spellId] = true;

                        local name = spellName(spellId);

                        rows[#rows + 1] = {
                            kind     = 'spell',
                            id       = spellId,
                            name     = name,
                            from     = row.name,
                            buttonId = string.format('Cast##dwes_cast_%d', spellId),
                        };

                        bySpell[name:lower()] = spellId;
                    end
                end

                for _, abilityId in ipairs(row.abilities) do
                    if (not seenAbil[abilityId]) then
                        seenAbil[abilityId] = true;

                        local name = abilityName(abilityId);

                        rows[#rows + 1] = {
                            kind     = 'ability',
                            id       = abilityId,
                            name     = name,
                            from     = row.name,
                            buttonId = string.format('Use##dwes_use_%d', abilityId),
                        };

                        byAbility[name:lower()] = abilityId;
                    end
                end
            end
        end
    end

    state.grants             = rows;
    state.grantSpellByName   = bySpell;
    state.grantAbilityByName = byAbility;
end

--[[
* Commit helpers.
*
* A `sync` answer that arrived WHOLE replaces the wallet and the owned set
* wholesale (dwtracker's rule: never merged, so a stale row cannot survive a
* refresh -- and the row that matters is an alt's, after a relog under a
* window that was never reloaded: this wire carries no charid, so the full
* picture is the only thing that can retire the previous character's).
* "Whole" is judged by the server's own counts: thirty `w|` rows, and as
* many `p|` rows as the `s|` line says are owned. Anything short of that --
* the client's chat rate limit drops lines, which is the whole reason this
* addon carries an answer clock -- is MERGED by key instead, so a dropped
* line costs one stale figure until the next poll rather than an Esper that
* reads "not made" for a minute.
*
* A write's answer (create / equip / unequip) carries only the rows it
* touched and is always merged.
--]]
local function countKeys(tbl)
    local count = 0;

    for _ in pairs(tbl) do
        count = count + 1;
    end

    return count;
end

local function commitSheet(sheet)
    if (sheet ~= nil and sheet.seen) then
        state.sheet   = sheet;
        state.sheetAt = os.clock();
    end
end

local function commitWallet(pending, whole)
    if (pending == nil) then
        return;
    end

    if (whole and countKeys(pending) == KIND_COUNT) then
        state.wallet = pending;

        return;
    end

    for kind, row in pairs(pending) do
        state.wallet[kind] = row;
    end
end

local function commitOwned(pending, sheet, whole)
    if (pending == nil) then
        return;
    end

    if (whole and sheet ~= nil and sheet.seen and countKeys(pending) == sheet.owned) then
        state.owned = pending;

        return;
    end

    for id, row in pairs(pending) do
        state.owned[id] = row;
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = wireInt(parts[2], -1);

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            --[[
            * THE REFUSAL RETIRES THE ASKS (dwspoils' note, kept whole). A
            * mismatched `d|` IS an answer -- the server spoke, in a dialect
            * this addon does not read -- and leaving the clock running
            * against it costs twice: the retry goes out against the protocol
            * document's own promise to stop asking, and the silent latch then
            * paints "No answer from the server" over the accurate "Update
            * dwesper" banner. The staging copies go too, and so does the
            * queue: a line already sitting in the pump would go out a beat
            * later and be answered in the same dialect.
            --]]
            state.requested     = T{ };
            state.pendingWrite  = nil;
            state.pendingSheet  = nil;
            state.pendingWallet = nil;
            state.pendingOwned  = nil;
            state.pendingRoster = nil;
            state.serverSilent  = false;

            for index = #queue, 1, -1 do
                table.remove(queue, index);
            end

            print(chat.header('dwesper'):append(chat.error(string.format(
                'Server protocol %d, addon expects %d. Update dwesper.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope proves the server is there (the silent
        -- latch lifts), but only the MATCHING verb retires its own ask.
        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.requested[state.inbound] ~= nil) then
            state.requested[state.inbound] = nil;
        end

        -- A NEW ANSWER CLEARS THE OLD BANNER. Whatever the server wants to
        -- say about THIS answer rides inside this envelope as m| or e|.
        state.status    = '';
        state.statusBad = false;

        -- Every verb but roster may carry s|, w| and p| rows: sync sends the
        -- whole picture, a write sends what it touched. Staged here, swapped
        -- at z|.
        if (state.inbound ~= 'roster') then
            state.pendingSheet  = { seen = false };
            state.pendingWallet = { };
            state.pendingOwned  = { };
        end

        if (state.inbound == 'roster') then
            state.pendingRoster = { };
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        if (kind == 'e') then
            --[[
            * A REFUSAL INSIDE AN OPEN ENVELOPE KILLS THAT ANSWER (dwspoils'
            * rule): a door emits exactly `d|1|sync`, `e|Espers are not loaded
            * on this build.`, `z|sync` when the core did not load, and
            * committing that staging copy would leave the window drawing a
            * confident false picture of a server that answered nothing.
            --]]
            state.pendingSheet  = nil;
            state.pendingWallet = nil;
            state.pendingOwned  = nil;
            state.pendingRoster = nil;

            -- A refusal answers the write in flight, whatever the envelope
            -- says: the buttons come back now rather than in five seconds.
            local pending = state.pendingWrite;

            state.pendingWrite = nil;

            --[[
            * THE UNKNOWN-VERB LATCH (the dwbags shape, per verb). A server
            * older than this addon answers a verb it lacks with its
            * unknown-verb sentence, once per ask, forever -- so the verb the
            * sentence names is latched and not asked again until a zone line
            * re-probes it. Matched on the QUOTED verb and the word `verb`,
            * which is how squad_storage.lua and every door since spell it;
            * a refusal that quotes no verb latches nothing.
            --]]
            local lowered = text:lower();

            if (string.find(lowered, 'verb', 1, true) ~= nil) then
                for verb in pairs(LINES) do
                    if (string.find(lowered, '"' .. verb .. '"', 1, true) ~= nil) then
                        state.unsupported[verb] = true;
                        state.requested[verb]   = nil;
                    end
                end

                for verb in pairs(WRITE_LINES) do
                    if (string.find(lowered, '"' .. verb .. '"', 1, true) ~= nil) then
                        state.unsupported[verb] = true;
                    end
                end

                -- The verb the refused write named is latched even when the
                -- sentence does not quote it in full: the ask and the answer
                -- are one pair.
                if (pending ~= nil and string.find(lowered, 'unknown', 1, true) ~= nil) then
                    state.unsupported[pending.verb] = true;
                end
            end
        end

        -- A NOTE WITH NO SENTENCE IN IT SAYS NOTHING. The bookkeeping above
        -- still ran: a refusal with nothing to say is still a refusal.
        if (text == '') then
            return;
        end

        -- DRAWN, NEVER PRINTED. A refusal is the window's status line and
        -- nothing else: a macro that presses a granted spell six times inside
        -- its recast would otherwise print six red lines into the chat log.
        state.status    = text;
        state.statusBad = (kind == 'e');

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    -- s| -- the state line: the two slots, how many slots are open, the Core
    -- count, and the owned/mastered tallies.
    if (kind == 's' and state.pendingSheet ~= nil) then
        state.pendingSheet.seen     = true;
        state.pendingSheet.slot1    = wireInt(parts[2]);
        state.pendingSheet.slot2    = wireInt(parts[3]);
        state.pendingSheet.slots    = math.max(1, math.min(2, wireInt(parts[4], 1)));
        state.pendingSheet.cores    = wireInt(parts[5]);
        state.pendingSheet.owned    = wireInt(parts[6]);
        state.pendingSheet.mastered = wireInt(parts[7]);

        return;
    end

    -- w| -- one Magicite kind: amount held and lifetime earned.
    if (kind == 'w' and state.pendingWallet ~= nil) then
        local which = wireInt(parts[2]);

        if (which >= 1 and which <= KIND_COUNT) then
            state.pendingWallet[which] = {
                amount   = wireInt(parts[3]),
                lifetime = wireInt(parts[4]),
            };
        end

        return;
    end

    -- p| -- one OWNED Esper: attunement units, mastered, the slot it sits in.
    if (kind == 'p' and state.pendingOwned ~= nil) then
        local id = wireInt(parts[2]);

        if (id >= 1 and id <= ESPER_COUNT) then
            local attune = math.max(0, math.min(MASTERY_UNITS, wireInt(parts[3])));

            state.pendingOwned[id] = {
                attune   = attune,
                mastered = wireInt(parts[4]) ~= 0,
                slot     = math.max(0, math.min(2, wireInt(parts[5]))),
                -- Drawn every frame, built once here.
                fraction = attune / MASTERY_UNITS,
                percent  = string.format('%d%%', math.floor(attune / (MASTERY_UNITS / 100))),
            };
        end

        return;
    end

    -- r| -- one roster row: everything static about an Esper.
    if (kind == 'r' and state.pendingRoster ~= nil) then
        local id = wireInt(parts[2]);

        if (id >= 1 and id <= ESPER_COUNT) then
            local row = state.pendingRoster[id] or { grants = '', line = '' };

            row.id        = id;
            row.name      = parts[3] ~= '' and parts[3] or string.format('Esper %d', id);
            row.tier      = wireInt(parts[4], 1);
            row.elem      = wireInt(parts[5]);
            row.jobA      = wireInt(parts[6]);
            row.jobB      = wireInt(parts[7]);
            row.priceE    = wireInt(parts[8]);
            row.priceA    = wireInt(parts[9]);
            row.priceB    = wireInt(parts[10]);
            row.cores     = wireInt(parts[11]);
            row.spells    = csvIds(parts[12]);
            row.abilities = csvIds(parts[13]);

            -- Drawn every frame, built once here.
            row.tileId   = string.format('%s##dwes_tile_%d', row.name, id);
            row.tierText = tierName(row.tier);
            row.elemText = row.elem >= 1 and row.elem <= ELEMENT_COUNT and ELEMENT_NAMES[row.elem] or 'any';
            row.jobsText = (row.jobA >= 1 and row.jobB >= 1)
                and string.format('%s / %s', jobName(row.jobA), jobName(row.jobB))
                or 'any';
            row.subText  = string.format('%s  %s', row.tierText, row.elemText);

            state.pendingRoster[id] = row;
        end

        return;
    end

    -- q| -- the grant text for one roster row; l| -- its line of prose. Either
    -- may arrive before its r| under the rate limit, so a shell is made.
    if ((kind == 'q' or kind == 'l') and state.pendingRoster ~= nil) then
        local id = wireInt(parts[2]);

        if (id >= 1 and id <= ESPER_COUNT) then
            local row = state.pendingRoster[id] or { grants = '', line = '' };

            if (kind == 'q') then
                row.grants = line:sub(#parts[1] + #parts[2] + 3);
            else
                row.line = line:sub(#parts[1] + #parts[2] + 3);
            end

            state.pendingRoster[id] = row;
        end

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        --[[
        * ONLY A COMPLETE ANSWER COMMITS. The staging copies are nil when a
        * refusal killed the envelope. A roster with no rows is not committed
        * either -- the door answered and there was nothing in it, and the
        * grid keeps saying "Waiting for the roster" rather than drawing
        * thirty-two empty tiles.
        --]]
        local sheet = state.pendingSheet;
        local whole = closed == 'sync';

        commitSheet(sheet);
        commitWallet(state.pendingWallet, whole);
        commitOwned(state.pendingOwned, sheet, whole);

        state.pendingSheet  = nil;
        state.pendingWallet = nil;
        state.pendingOwned  = nil;

        if (closed == 'roster') then
            local pending = state.pendingRoster;

            state.pendingRoster = nil;

            if (pending ~= nil and next(pending) ~= nil) then
                -- A shell made by a q|/l| that never got its r| is not a
                -- row the grid can draw; only complete rows commit.
                local roster = { };
                local count  = 0;

                for id, row in pairs(pending) do
                    if (row.name ~= nil) then
                        roster[id] = row;
                        count      = count + 1;
                    end
                end

                if (count > 0) then
                    state.roster   = roster;
                    state.rosterAt = os.clock();
                end
            end
        end

        rebuildGrants();

        -- A write's envelope closing is what re-arms the buttons -- and, for
        -- the three that move the wallet or the slots, what re-asks sync so
        -- the picture on screen is the server's rather than this addon's
        -- guess at it.
        if (state.pendingWrite ~= nil and closed == state.pendingWrite.verb) then
            state.pendingWrite = nil;

            if (closed == 'create' or closed == 'equip' or closed == 'unequip') then
                ask('sync');
            end
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwesper_packet_in', function (e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        -- BLOCKED BEFORE IT IS PARSED (the dwbags rule), and ONLY for this
        -- sender. A record that throws inside handleRecord must still not
        -- reach the chat log.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwesper'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line re-probes every latch and re-arms the lazy hello. The
    -- roster CACHE survives it -- the roster is static for the session and
    -- was asked once -- but a roster that never arrived is asked again. A
    -- half-arrived envelope dies with the zone.
    if (e.id == 0x000A) then
        state.requested     = T{ };
        state.serverSilent  = false;
        state.refused       = false;
        state.unsupported   = { };
        state.inbound       = nil;
        state.pendingSheet  = nil;
        state.pendingWallet = nil;
        state.pendingOwned  = nil;
        state.pendingRoster = nil;
        state.pendingWrite  = nil;
        state.helloSent     = false;
        state.polledAt      = nil;
        state.rosterAsked   = state.roster ~= nil;

        -- A RED REFUSAL DOES NOT OUTLIVE THE PLACE IT WAS ABOUT.
        if (state.statusBad) then
            state.status    = '';
            state.statusBad = false;
        end
    end
end);

--[[
* THE TARGET INDEX THE DOOR IS HANDED. The current target when one is active,
* else 0 -- which the server reads as "the default for this action": the
* player's battle target for something offensive, the player for something
* beneficial (T10). The `<me>` word resolves to the player's own index off the
* party list, the way dwengage and dwtracker read it. Every call is pcall'd:
* the memory manager can answer nil for a frame around a zone line.
--]]
local function currentTargetIndex()
    local ok, index = pcall(function ()
        local target = AshitaCore:GetMemoryManager():GetTarget();

        if (target == nil or target:GetIsActive(0) == 0) then
            return 0;
        end

        return target:GetTargetIndex(0);
    end);

    if (ok and type(index) == 'number' and index > 0) then
        return index;
    end

    return 0;
end

local function selfIndex()
    local ok, index = pcall(function ()
        return AshitaCore:GetMemoryManager():GetParty():GetMemberTargetIndex(0);
    end);

    if (ok and type(index) == 'number' and index > 0) then
        return index;
    end

    return 0;
end

-- The target word of a `/ma` or `/ja` line to an index. `<me>` is the
-- player; `<bt>` is sent as 0, because the house has no helper for the
-- client's own battle target and 0 IS the server's "your battle target for
-- an offensive action, yourself for a beneficial one" (T10; esper_core's
-- resolveTarget honours only an index above zero) -- the cursor target would
-- be wrong exactly when it differs from the thing being fought; `<t>`, `<st>`
-- and the sub-target words are read as the current target. A bare number is
-- passed through.
local function resolveTargetWord(word)
    if (type(word) ~= 'string' or word == '') then
        return currentTargetIndex();
    end

    local lowered = word:lower();

    if (lowered == '<me>') then
        return selfIndex();
    end

    if (lowered == '<bt>') then
        return 0;
    end

    local number = tonumber(lowered);

    if (number ~= nil and number == math.floor(number) and number >= 0) then
        return number;
    end

    return currentTargetIndex();
end

-- The Grants tab's buttons and the hook share one door.
local function castSpell(spellId, targetIndex)
    return sendWrite('cast', string.format(WRITE_LINES.cast, spellId, targetIndex));
end

local function useAbility(abilityId, targetIndex)
    return sendWrite('use', string.format(WRITE_LINES.use, abilityId, targetIndex));
end

--[[
* Rendering.
*
* MEASURED LAYOUT, NOT GUESSED (dwcraft's rule, reached here through
* dwspoils). Both helpers read the LIVE font each frame and fall back to a
* conservative constant when a binding does not answer.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

local function textWidth(sample, fallback)
    if (type(imgui.CalcTextSize) ~= 'function') then
        return fallback;
    end

    local ok, width = pcall(imgui.CalcTextSize, sample);

    if (ok and type(width) == 'number' and width > 0) then
        return width;
    end

    return fallback;
end

-- What a scrolling region must leave below itself (the dwnemesis
-- footerReserve shape): a NEGATIVE outer height reads as "available minus
-- this".
local function footerReserve()
    return -(metric('GetFrameHeightWithSpacing', 26) + 12);
end

-- One short tip on the item just drawn.
local function tip(text)
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local SZ_BAR   = { -1, 6 };
local SZ_FILL  = { 0, 0 };
local SZ_MAX   = { 99999, 99999 };
local SZ_MIN   = { 720, 420 };
local SZ_FIRST = { 780, 480 };

local function esperNameOf(id)
    if (id == nil or id == 0) then
        return '--';
    end

    local row = state.roster ~= nil and state.roster[id] or nil;

    return row ~= nil and row.name or string.format('Esper %d', id);
end

local function refreshTip()
    if (state.refused) then
        return TIPS.refreshStale;
    end

    if (state.sheetAt == nil) then
        return TIPS.refresh;
    end

    return string.format('%s\nWhat is on screen arrived about %d second(s) ago.',
        TIPS.refresh, math.max(0, math.floor(os.clock() - state.sheetAt)));
end

local function renderHeader()
    if (imgui.Button('Refresh##dwes_refresh')) then
        ask('sync', true);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(refreshTip());
    end

    imgui.SameLine();

    -- REFUSED OUTRANKS SILENT, and the status line outranks the sheet line.
    if (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwesper through the launcher.');
    elseif (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server. Refresh to ask again.');
    elseif (state.status ~= nil and state.status ~= '') then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, state.status);
    elseif (#queue > 0 or busy()) then
        imgui.TextDisabled('asking...');
    elseif (state.sheet ~= nil) then
        local sheet = state.sheet;

        imgui.Text(string.format('Slot 1: %s', esperNameOf(sheet.slot1)));

        if (sheet.slots >= 2) then
            imgui.SameLine();
            imgui.Text(string.format('   Slot 2: %s', esperNameOf(sheet.slot2)));
        end

        imgui.SameLine();
        imgui.TextColored(theme.colors.warn, string.format('   Cores %d', sheet.cores));
        tip(TIPS.cores);

        imgui.SameLine();
        imgui.TextDisabled(string.format('   %d owned, %d mastered', sheet.owned, sheet.mastered));
    else
        imgui.TextDisabled('Kills that pay experience pay Magicite. Magicite and Cores make Espers.');
    end

    imgui.SameLine();

    -- The settings row: one switch, right of the status. Saved on change.
    if (imgui.Checkbox('Route /ma and /ja##dwes_intercept', state.intercept)) then
        saveConfig();
    end

    tip(TIPS.intercept);

    imgui.Separator();
end

-- Can a kind's price be paid, by the wallet on screen? A courtesy: the
-- server re-reads both sides at confirm.
local function held(kind)
    local row = state.wallet[kind];

    return row ~= nil and row.amount or 0;
end

local function priceLine(kind, price)
    local have = held(kind);

    imgui.TextColored(have >= price and theme.colors.ok or theme.colors.err,
        string.format('%s Magicite %d  (you hold %d)', kindName(kind), price, have));
end

-- The Create button's greyed reason, built on hover only.
local function createReason(row)
    if (state.sheet == nil) then
        return 'Waiting for the server.';
    end

    if (state.pendingWrite ~= nil) then
        return TIPS.pending;
    end

    if (state.unsupported.create) then
        return 'This server does not answer the create verb -- it is older than dwesper.';
    end

    if (row.cores > 0 and state.sheet.cores < row.cores) then
        return string.format('Needs %d Esper Core(s); you hold %d.', row.cores, state.sheet.cores);
    end

    if (row.elem >= 1 and held(row.elem) < row.priceE) then
        return string.format('Needs %d %s Magicite; you hold %d.', row.priceE, kindName(row.elem), held(row.elem));
    end

    if (row.jobA >= 1 and held(ELEMENT_COUNT + row.jobA) < row.priceA) then
        return string.format('Needs %d %s Magicite; you hold %d.', row.priceA, jobName(row.jobA), held(ELEMENT_COUNT + row.jobA));
    end

    if (row.jobB >= 1 and held(ELEMENT_COUNT + row.jobB) < row.priceB) then
        return string.format('Needs %d %s Magicite; you hold %d.', row.priceB, jobName(row.jobB), held(ELEMENT_COUNT + row.jobB));
    end

    return TIPS.create;
end

local function canCreate(row)
    return state.sheet ~= nil
        and state.pendingWrite == nil
        and not latched()
        and not state.unsupported.create
        and (row.cores <= 0 or state.sheet.cores >= row.cores)
        and (row.elem < 1 or held(row.elem) >= row.priceE)
        and (row.jobA < 1 or held(ELEMENT_COUNT + row.jobA) >= row.priceA)
        and (row.jobB < 1 or held(ELEMENT_COUNT + row.jobB) >= row.priceB);
end

-- A button that greys itself and explains why on hover (dwmerits' shape:
-- hovered OUTSIDE the disabled block, because ImGui does not report a hover
-- over a disabled item and "why is this grey" is the question).
local function actionButton(label, enabled, why, onPress)
    if (not enabled) then imgui.BeginDisabled(); end

    local pressed = imgui.Button(label);

    if (not enabled) then imgui.EndDisabled(); end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(why);
    end

    if (pressed and enabled) then
        onPress();
    end
end

local function renderDetail()
    local row = state.selected ~= nil and state.roster ~= nil and state.roster[state.selected] or nil;

    if (row == nil) then
        imgui.TextDisabled('Select an Esper.');

        return;
    end

    local owned = state.owned[row.id];

    imgui.TextColored(tierColour(row.tier), row.name);
    imgui.TextDisabled(string.format('%s Esper  --  %s  --  %s', row.tierText, row.elemText, row.jobsText));

    if (owned ~= nil) then
        imgui.ProgressBar(owned.fraction, SZ_BAR, '');
        tip(TIPS.attune);

        if (owned.mastered) then
            imgui.TextColored(theme.colors.ok, 'Mastered');
        else
            imgui.Text(string.format('Attunement %s', owned.percent));
        end

        if (owned.slot > 0) then
            imgui.SameLine();
            imgui.TextColored(theme.colors.warn, string.format('   Equipped (slot %d)', owned.slot));
        end
    else
        imgui.TextDisabled('Not yet made.');
    end

    imgui.Separator();

    if (row.grants ~= '') then
        imgui.PushTextWrapPos(0);
        imgui.Text(row.grants);
        imgui.PopTextWrapPos();
    end

    if (row.line ~= '') then
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled(row.line);
        imgui.PopTextWrapPos();
    end

    imgui.Separator();

    if (owned == nil) then
        imgui.Text('Price:');
        tip(TIPS.wallet);

        if (row.elem >= 1 and row.priceE > 0) then
            priceLine(row.elem, row.priceE);
        end

        if (row.jobA >= 1 and row.priceA > 0) then
            priceLine(ELEMENT_COUNT + row.jobA, row.priceA);
        end

        if (row.jobB >= 1 and row.priceB > 0) then
            priceLine(ELEMENT_COUNT + row.jobB, row.priceB);
        end

        if (row.cores > 0) then
            local have = state.sheet ~= nil and state.sheet.cores or 0;

            imgui.TextColored(have >= row.cores and theme.colors.ok or theme.colors.err,
                string.format('Esper Cores %d  (you hold %d)', row.cores, have));
            tip(TIPS.cores);
        end

        actionButton(string.format('Create##dwes_create_%d', row.id), canCreate(row), createReason(row), function ()
            sendWrite('create', string.format(WRITE_LINES.create, row.id));
        end);

        return;
    end

    local slots = state.sheet ~= nil and state.sheet.slots or 1;
    local free  = state.pendingWrite == nil and not latched();
    local why   = state.pendingWrite ~= nil and TIPS.pending or nil;

    if (owned.slot ~= 1) then
        local can = free and not state.unsupported.equip;

        actionButton(string.format('Equip slot 1##dwes_equip1_%d', row.id), can, why or TIPS.equip1, function ()
            sendWrite('equip', string.format(WRITE_LINES.equip, row.id, 1));
        end);

        imgui.SameLine();
    end

    if (slots >= 2 and owned.slot ~= 2) then
        local can = free and not state.unsupported.equip;

        actionButton(string.format('Equip slot 2##dwes_equip2_%d', row.id), can, why or TIPS.equip2, function ()
            sendWrite('equip', string.format(WRITE_LINES.equip, row.id, 2));
        end);

        imgui.SameLine();
    end

    if (owned.slot > 0) then
        local slot = owned.slot;
        local can  = free and not state.unsupported.unequip;

        actionButton(string.format('Unequip##dwes_unequip_%d', row.id), can, why or TIPS.unequip, function ()
            sendWrite('unequip', string.format(WRITE_LINES.unequip, slot));
        end);
    end
end

local function renderTile(row)
    local owned    = state.owned[row.id];
    local selected = state.selected == row.id;

    if (imgui.Selectable(row.tileId, selected)) then
        state.selected = row.id;
    end

    tip(TIPS.tile);

    imgui.TextColored(tierColour(row.tier), row.subText);

    if (owned ~= nil) then
        if (owned.mastered) then
            imgui.TextColored(theme.colors.ok, 'Mastered');
        else
            imgui.TextDisabled(string.format('Attunement %s', owned.percent));
        end

        if (owned.slot > 0) then
            imgui.SameLine();
            imgui.TextColored(theme.colors.warn, string.format(' Equipped %d', owned.slot));
        end

        imgui.ProgressBar(owned.fraction, SZ_BAR, '');
        tip(TIPS.attune);
    else
        imgui.TextDisabled('not made');
    end
end

local function renderEspers()
    if (state.roster == nil) then
        if (state.unsupported.roster) then
            imgui.TextDisabled('This server does not answer the roster verb -- it is older than dwesper.');
        else
            imgui.TextDisabled('Waiting for the roster...');
        end

        return;
    end

    if (imgui.BeginTable('dwes_espers', 2, ImGuiTableFlags_SizingStretchProp, { 0, footerReserve() })) then
        imgui.TableSetupColumn('##dwes_grid_col', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('##dwes_detail_col', ImGuiTableColumnFlags_WidthStretch, 2.0);

        imgui.TableNextRow();
        imgui.TableNextColumn();

        -- The grid scrolls in its own child; the detail pane beside it does
        -- not move when it does. EndChild is Begin's kind of pair: always
        -- called, whatever BeginChild answered.
        if (imgui.BeginChild('dwes_gridpane', SZ_FILL, false)) then
            if (imgui.BeginTable('dwes_grid', GRID_COLUMNS,
                    bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingStretchSame))) then
                for id = 1, ESPER_COUNT do
                    if ((id - 1) % GRID_COLUMNS == 0) then
                        imgui.TableNextRow();
                    end

                    imgui.TableNextColumn();

                    local row = state.roster[id];

                    if (row ~= nil) then
                        renderTile(row);
                    else
                        imgui.TextDisabled(string.format('Esper %d', id));
                    end
                end

                imgui.EndTable();
            end
        end

        imgui.EndChild();

        imgui.TableNextColumn();

        if (imgui.BeginChild('dwes_detailpane', SZ_FILL, false)) then
            renderDetail();
        end

        imgui.EndChild();

        imgui.EndTable();
    end
end

local function renderMagicite()
    if (state.sheet == nil and next(state.wallet) == nil) then
        imgui.TextDisabled('Waiting for the server...');

        return;
    end

    imgui.Text('Your Magicite:');
    tip(TIPS.wallet);
    imgui.Separator();

    if (imgui.BeginTable('dwes_wallet', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad = textWidth('nn', 14);

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Kind', ImGuiTableColumnFlags_WidthStretch, 2.0);
        imgui.TableSetupColumn('Held', ImGuiTableColumnFlags_WidthFixed, textWidth('9999999', 60) + pad);
        imgui.TableSetupColumn('Lifetime', ImGuiTableColumnFlags_WidthFixed, textWidth('9999999', 60) + pad);
        imgui.TableHeadersRow();

        for kind = 1, KIND_COUNT do
            local row = state.wallet[kind];

            imgui.TableNextRow();

            imgui.TableNextColumn();

            if (kind <= ELEMENT_COUNT) then
                imgui.TextColored(theme.colors.hint, kindName(kind));
            else
                imgui.Text(kindName(kind));
            end

            imgui.TableNextColumn();

            if (row ~= nil) then
                imgui.Text(string.format('%d', row.amount));
            else
                imgui.TextDisabled('--');
            end

            imgui.TableNextColumn();

            if (row ~= nil) then
                imgui.TextDisabled(string.format('%d', row.lifetime));
                tip(TIPS.lifetime);
            else
                imgui.TextDisabled('--');
            end
        end

        imgui.EndTable();
    end
end

local function renderGrants()
    if (state.roster == nil) then
        imgui.TextDisabled('Waiting for the roster...');

        return;
    end

    local rows = state.grants;

    if (#rows == 0) then
        imgui.TextWrapped('Nothing yet. Equip an Esper and everything it lends -- spells and job '
            .. 'abilities alike -- lands here with a button, whatever job you are on. A mastered '
            .. 'Esper lends its set forever.');

        return;
    end

    imgui.Text(string.format('%d granted:', #rows));
    tip(TIPS.grants);
    imgui.Separator();

    if (imgui.BeginTable('dwes_grants', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_ScrollY, ImGuiTableFlags_SizingStretchProp),
            { 0, footerReserve() })) then
        local pad = textWidth('nn', 14);

        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableSetupColumn('Kind', ImGuiTableColumnFlags_WidthFixed, textWidth('Ability', 50) + pad);
        imgui.TableSetupColumn('Name', ImGuiTableColumnFlags_WidthStretch, 3.0);
        imgui.TableSetupColumn('From', ImGuiTableColumnFlags_WidthStretch, 2.0);
        imgui.TableSetupColumn('##dwes_press', ImGuiTableColumnFlags_WidthFixed, textWidth('Cast', 40) + pad * 2);
        imgui.TableHeadersRow();

        local free = state.pendingWrite == nil and not latched();

        for _, row in ipairs(rows) do
            imgui.TableNextRow();

            imgui.TableNextColumn();
            imgui.TextDisabled(row.kind == 'spell' and 'Spell' or 'Ability');

            imgui.TableNextColumn();
            imgui.Text(row.name);

            imgui.TableNextColumn();
            imgui.TextDisabled(row.from);

            imgui.TableNextColumn();

            if (row.kind == 'spell') then
                local can = free and not state.unsupported.cast;

                actionButton(row.buttonId, can, can and TIPS.cast or TIPS.pending, function ()
                    castSpell(row.id, currentTargetIndex());
                end);
            else
                local can = free and not state.unsupported.use;

                actionButton(row.buttonId, can, can and TIPS.use or TIPS.pending, function ()
                    useAbility(row.id, currentTargetIndex());
                end);
            end
        end

        imgui.EndTable();
    end
end

--[[
* One tab. The remembered choice is written back only when the PLAYER moves,
* never when a `wantTab` from the command line takes the window somewhere for
* one frame -- and SetSelected is spent the frame it lands (the dwparse note).
--]]
local function tabItem(key, label, body)
    local flags = ImGuiTabItemFlags_None;

    if (state.wantTab == key) then
        flags = ImGuiTabItemFlags_SetSelected;
    end

    if (imgui.BeginTabItem(label, nil, flags)) then
        if (state.wantTab == key) then
            state.wantTab = nil;
        end

        if (state.wantTab == nil and state.tab ~= key) then
            state.tab = key;

            saveConfig();
        end

        body();
        imgui.EndTabItem();
    end
end

local function renderWindow()
    renderHeader();

    if (imgui.BeginTabBar('dwes_tabs')) then
        tabItem('espers', string.format('Espers %d###dwes_tab_espers',
            state.sheet ~= nil and state.sheet.owned or 0), renderEspers);
        tabItem('magicite', 'Magicite###dwes_tab_magicite', renderMagicite);
        tabItem('grants', string.format('Grants %d###dwes_tab_grants', #state.grants), renderGrants);

        imgui.EndTabBar();
    end
end

ashita.events.register('d3d_present', 'dwesper_present', function ()
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    -- THE FIRST ASK IS LAZY AND IT IS ASKED HERE, the first frame the window
    -- is actually shown in this zone -- never on the zone line, never at load.
    -- Every latch is consulted here as well as inside ask(): this test runs
    -- sixty times a second and the call it saves is not free.
    if (not state.helloSent and not latched() and not busy()) then
        state.helloSent = true;

        ask('sync');
    elseif (not latched() and not busy()) then
        if (state.roster == nil and not state.rosterAsked) then
            -- ONCE PER SESSION. The roster is static; it is asked the first
            -- time the sync has been answered and the cache is empty.
            ask('roster');
        elseif (state.polledAt == nil or (os.clock() - state.polledAt) >= POLL_INTERVAL) then
            ask('sync');
        end
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize(SZ_FIRST, ImGuiCond_FirstUseEver);

    -- A MINIMUM SIZE. Nothing in ImGui stops a window being dragged to
    -- nothing, and this one carries a three-tab bar, a four-column grid and a
    -- detail pane beside it. 720x420 is the plan's floor.
    imgui.SetNextWindowSizeConstraints(SZ_MIN, SZ_MAX);

    local visible = imgui.Begin('DriftwoodXI Espers##dwesper', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwesper'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwesper'):append(chat.message('Window closed. Everything it shows also works typed as !esper.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

ashita.events.register('packet_out', 'dwesper_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    -- THE THROTTLE IS STAMPED BY WHAT THE PLAYER SENDS, NOT ONLY BY US. The
    -- limit it exists to respect is the CLIENT's, on chat, and that counts the
    -- player's own typing.
    if (message:sub(1, 5):lower() ~= '!dwes') then
        lastSend = os.clock();
    end
end);

--[[
* A command line into words, quote-aware: `/ma "Blizzard III" <t>` is three
* words, the middle one without its quotes. Written here rather than through
* the sugar library's `:args()` so the split is one this file can be judged
* on -- the spell name is the whole of the hook's match key.
--]]
local function splitCommand(text)
    local words = { };

    text = tostring(text);

    local at  = 1;
    local len = #text;

    while (at <= len) do
        local c = text:sub(at, at);

        if (c == ' ' or c == '\t') then
            at = at + 1;
        elseif (c == '"') then
            local close = text:find('"', at + 1, true);

            if (close == nil) then
                words[#words + 1] = text:sub(at + 1);

                break;
            end

            words[#words + 1] = text:sub(at + 1, close - 1);
            at = close + 1;
        else
            local stop = text:find('[ \t]', at) or (len + 1);

            words[#words + 1] = text:sub(at, stop - 1);
            at = stop;
        end
    end

    return words;
end

--[[
* THE COMMAND HOOK (T10). Two jobs in one handler: `/esper` opens the window,
* and a `/ma` or `/ja` naming a spell or ability an active Esper lends is
* rewritten into the server door -- for GRANTED names only. Everything else is
* left exactly as typed. The names are matched lowercased against the maps
* rebuildGrants filled, so the client's own spelling is the key.
--]]
ashita.events.register('command', 'dwesper_command', function (e)
    local args = splitCommand(e.command);

    -- LOWERCASED: what was typed is what arrives, and a player who
    -- capitalises is not making a mistake.
    local first = #args > 0 and args[1]:lower() or '';

    if (first == '/esper' or first == '/dwesper') then
        e.blocked = true;

        -- `/esper grants` OPENS the window on that tab rather than toggling
        -- it: a player who named a tab has already said what they want.
        if (#args > 1) then
            local word = args[2]:lower();

            if (word == 'espers' or word == 'magicite' or word == 'grants') then
                state.wantTab  = word;
                state.open[1]  = true;
                state.reported = false;

                return;
            end

            print(chat.header('dwesper'):append(chat.message('/esper opens the window; /esper magicite or /esper grants opens it on that tab.')));

            return;
        end

        state.open[1] = not state.open[1];

        if (state.open[1]) then
            state.reported = false;
        end

        return;
    end

    if (not state.intercept[1]) then
        return;
    end

    if (first ~= '/ma' and first ~= '/ja') then
        return;
    end

    local name = args[2];

    if (type(name) ~= 'string' or name == '') then
        return;
    end

    local id;

    if (first == '/ma') then
        id = state.grantSpellByName[name:lower()];
    else
        id = state.grantAbilityByName[name:lower()];
    end

    -- Not granted: the client's own business, untouched.
    if (id == nil) then
        return;
    end

    e.blocked = true;

    local targetIndex = resolveTargetWord(args[3]);

    if (first == '/ma') then
        castSpell(id, targetIndex);
    else
        useAbility(id, targetIndex);
    end
end);

ashita.events.register('load', 'dwesper_load', function ()
    print(chat.header('dwesper'):append(chat.message('/esper opens the Espers window: your Magicite, the Espers you can make, and the spells they lend you. Everything it shows also works typed as !esper.')));
end);
