--[[
* DriftwoodXI -- dwecho
*
* Swallows the client's local echo of the `!` commands a Driftwood addon
* sends, so the chat log stops showing the plumbing.
*
* WHAT THE PLAYER WAS SEEING. Lines like these, unprompted, for something
* they never typed -- two of them on every login before dwtracker was fixed
* on 2026-07-30, and a couple more every time somebody opened a window:
*
*     Blaster : !dwt hello
*     Blaster : !dwq bags 1
*
* It reads like a bug. On a login it is the first thing a new character sees.
*
* IT IS NOT A FAILED COMMAND, which is exactly what it looks like. That was
* checked properly rather than assumed: a `!` command the server does not
* recognise leaves TWO traces -- a `cmdhandler::call: Function does not
* exist` error in the map log AND a SAY row in the audit_chat table. Real
* leaks have that pair (`!gambits` and `!mercdebug` from earlier sessions do).
* The addon lines have neither, because the server took the commands and
* answered them. Nothing was ever broadcast.
*
* WHERE IT ACTUALLY COMES FROM. `QueueCommand(1, ...)` is CommandMode::Typed,
* "forward the command as if a player typed it" (Ashita.h, CommandMode). It
* has to be that: a `!` command IS a chat line -- that is the only way one
* reaches an LSB server -- so the suite sends them the way a player would.
* The client then renders the line locally, the way it renders anything you
* type. The server consumes the command instead of broadcasting it, so that
* local copy is never replaced or matched by a real say. One orphan line per
* command, and nothing upstream is wrong.
*
* THE MATCH IS DELIBERATELY NARROW, because the cost of a false positive is
* eating a player's chat. A line is swallowed only if it ENDS with a command
* string this addon put on the wire within the last few seconds, and each
* send is consumed by at most one line. The echo renders as `<name> : !dwq
* bags 1`, so the suffix test is exact against the part we control, and a
* passing mention ("!dwq bags 1 is broken") never matches. Worst case, a
* player types one of our commands by hand at the same moment and loses a
* duplicate echo of their own typing.
*
* WHAT ARRIVES IN text_in IS NOT WHAT THE CLIENT EMITTED. Every other addon on
* the machine has had the line first, and the marks they leave are TWO bytes
* wide: a control byte and an argument byte that is very often an ordinary
* letter or digit. The timestamp addon's stamp is `\30\81[HH:MM:SS]\30\01`
* and 81 is the letter Q; the client's own end-of-message marker is `\127\49`
* and 49 is the digit 1 (the bundled enternity addon strips exactly that
* pair); Ashita's libs/chat.lua colours words with `\30\67` (C), `\30\68` (D),
* `\30\69` (E). A strip that deletes only the bytes that cannot be drawn
* leaves the argument standing in the sentence -- the echo line ends in
* `!dwt sync1` and the suffix test misses, or a highlighted word turns
* "command error" into "command Eerror" and the refusal leaks. So the tags go
* as PAIRS first, and the printable blanket runs BEHIND them; `plainText`
* below is that routine, exported so the addons that read chat for their own
* purposes (dwquest's rewards, dwmacro's bounce watcher, dwreport's buffer)
* can stop carrying copies of it. Cleaning the line does not widen the match:
* the suffix must still equal the command byte for byte.
*
* USAGE -- two lines of setup, then send through here instead of the chat
* manager:
*
*     local echo = require('dwecho');
*     echo.install();
*
*     echo.send(command);   -- was AshitaCore:GetChatManager():QueueCommand(1, command)
*
* `send` is the whole point of the shape: recording and sending cannot drift
* apart if they are the same call. An addon that sends around it just keeps
* its echo, which is the old behaviour and harmless.
*
* WHICH GATE AN ADDON CONSULTS. Two kinds of sender, two questions:
*
*   * A LAZY ASKER -- its `need*()` runs from the render loop, so it only
*     sends while its window is open -- consults `canSend()` (or
*     `holdReason()`, the same test with a name for the hold) from its
*     pumpQueue and takes NO stagger slot. A read queue may be held while the
*     window is closed as well: a read has nobody to show its answer to, and
*     a line the player cannot see is a line worth not sending.
*   * A ZONE-IN AUTO-SYNCER -- it sends on 0x000A with its window closed --
*     takes a slot in `ZONE_ORDER` and holds its zone-in sync
*     `zoneSlot(name) * SEND_INTERVAL` past the moment the client stops
*     zoning, on top of the canSend() gate every pump already has.
*
*   dwnemesis is the worked example of the first kind: it handshakes on the
*   first frame the window is open, so it correctly has no slot, and a later
*   round must not add one by pattern-matching.
*
* A GOODBYE ON UNLOAD CANNOT BE SWALLOWED, and no API in this file can change
* that. Ashita hands the addon its `unload` event, then tears down every
* handler it registered -- this file's text_in handler included -- and
* destroys the Lua state. A command queued from `unload` goes out after that,
* and its local echo arrives in a text_in nobody in this state is listening
* to. Each addon's copy of this file is its own table in its own state (see
* below), so a sibling cannot be told to take the line either. An addon that
* says goodbye to the server on unload pays one visible echo line for it;
* keep the goodbye short and do not try to hide it from here.
*
* A COPY PER ADDON FOLDER, exactly like dwtheme.lua, because an addon folder
* is the unit of distribution. `dwbags/dwecho.lua` is the master -- edit
* there and re-copy to the others. Each addon runs in its own Lua state, so
* each copy keeps its own table and its own handler; they never see each
* other's commands, which is what makes the narrow match safe.
*
* dwmacro does not carry this file. It is the one addon that never talks to
* the server -- no commands, no echo.
--]]

local echo = { };

-- Generous next to a 1.2s send interval and short enough that a stale entry
-- cannot sit around waiting to eat an unrelated line.
local WINDOW = 3.0;

-- The client answers a REFUSED outgoing command with "...A command error
-- occurred." and drops it. That refusal is swallowed only inside this window of
-- one of OUR sends -- matched to WINDOW because the refusal and the local echo
-- are the client's two answers to the SAME processed command and arrive
-- together, so whatever delay the echo tolerates, the error needs too.
local ERROR_WINDOW = 3.0;
local ERROR_MARK   = 'command error occurred';

-- command string -> os.clock() when it went out. A plain table: the keys are
-- arbitrary command text, and T{}'s sugar method names would shadow them.
local sent = { };

-- os.clock() of the most recent send, NEVER cleared by the echo match. The
-- error swallow rides THIS rather than `sent`: a REFUSED command still prints
-- its local echo first, the echo match below consumes that command's `sent`
-- entry, and the "command error" line arrives a beat AFTER -- when the entry is
-- already gone. `sent` answers "was this line an echo of a command we sent";
-- lastSentAt answers "did we just send anything", which is what the error needs.
local lastSentAt = 0;

-- os.clock() of the most recent outgoing chat line this addon was TOLD about
-- through `stamp()` -- the wire-side moment, from a packet_out 0x00B5 handler,
-- for lines the player typed as much as for ours. Zero until the addon calls
-- stamp(); holdReason() then knows only about our own sends.
local wireAt = 0;

local installed = false;

--[[
* Seconds since `stamp`, and math.huge when the clock reads EARLIER than the
* stamp. os.clock() on Windows is the C runtime's clock() in seconds, and that
* counter is a signed 32-bit millisecond count: after ~24.8 days of client
* uptime it wraps negative, so every stamp taken before the wrap sits in the
* future forever. A gate written `now - stamp < INTERVAL` then holds a queue
* shut, or `now - stamp <= WINDOW` swallows every command error, until the
* next send moves the stamp -- which it never does while the queue is held.
* "Before the wrap" is at least the interval ago for any interval an addon
* uses, so the honest answer is "a very long time", and math.huge compares
* the right way against every timeout and throttle in the suite.
*
* `now` is optional; pass the one reading a handler already took so one call
* is judged against one clock.
--]]
function echo.elapsed(stamp, now)
    if (type(stamp) ~= 'number') then
        return math.huge;
    end

    if (type(now) ~= 'number') then
        now = os.clock();
    end

    if (now < stamp) then
        return math.huge;
    end

    return now - stamp;
end

--[[
* The bytes of a text_in line that a player can actually read, in the order
* the header explains: the two-byte tags with their arguments first, then the
* line-break bytes as a seam SPACE (a `<br>` in a dat message renders as \7,
* and deleting it glues the halves together -- "...target.(Progress: 2/2)"),
* then everything else that cannot be drawn (NUL padding, a tag byte at the
* very end with no argument left to take), and last the timestamp addon's
* clocks -- off every seam, where that addon stamps each RENDERED line of a
* two-line message, and off the front. The seam form must follow whitespace,
* so a sentence that merely contains a bracketed clock hard against a word
* keeps it, and nothing the client renders begins with a clock, so the
* anchored form is safe. The seam form runs first because the anchored strip
* eats the whitespace after itself and would leave a second clock at the
* front with nothing for the seam form to match on.
*
* Trailing whitespace is left alone: a caller that compares suffixes trims
* it, a caller that re-prints keeps it, and this routine does not decide.
--]]
function echo.plainText(raw)
    local text = tostring(raw):gsub('[\030\031\127\239].', '');

    text = text:gsub('[\007\010\013]+', ' ');
    text = text:gsub('[^\032-\126]', '');
    text = text:gsub('%s%[%d%d?:%d%d:%d%d%]%s*', ' ');
    text = text:gsub('^%s*%[%d%d?:%d%d:%d%d%]%s*', '');

    return text;
end

--[[
* Put a command on the wire and remember it long enough to recognise its echo.
--]]
function echo.send(command)
    if (type(command) ~= 'string' or command == '') then
        return;
    end

    local at = os.clock();

    sent[command] = at;
    lastSentAt    = at;

    AshitaCore:GetChatManager():QueueCommand(1, command);
end

--[[
* Register the one text_in handler. Idempotent -- calling it twice would
* otherwise register two handlers that both try to block the same line.
*
* Handlers that read the chat log for their own purposes (dwreport's report
* buffer) must skip lines where `e.blocked` is already set: a line the player
* never saw does not belong in a bug report either.
--]]
function echo.install()
    if (installed) then
        return;
    end

    installed = true;

    ashita.events.register('text_in', 'dwecho_text_in', function (e)
        if (e.blocked or e.message == nil) then
            return;
        end

        -- Tags WITH their argument bytes first, then the printable blanket:
        -- the header's "what arrives here is not what the client emitted".
        local line = echo.plainText(e.message);

        line = line:gsub('%s+$', '');

        if (line == '') then
            return;
        end

        local now = os.clock();

        -- Clearing the current key inside pairs() is the one table mutation
        -- Lua guarantees is safe, so the expiry sweep rides along with the
        -- search instead of needing a pass of its own. A stamp the clock has
        -- wrapped past (echo.elapsed) is expired too, never live forever.
        for command, at in pairs(sent) do
            if (echo.elapsed(at, now) > WINDOW) then
                sent[command] = nil;
            elseif (#line >= #command and line:sub(-#command) == command) then
                sent[command] = nil;
                e.blocked = true;

                return;
            end
        end

        -- THE OTHER FACE OF THE SAME PLUMBING: the client's own rejection of a
        -- line we sent. When it refuses an outgoing command -- it rate-limits
        -- chat, and the four zone-in auto-syncers can space closer than that
        -- limit no matter how they are staggered -- it answers "...A command
        -- error occurred." in the log and drops the line. The retry paths
        -- recover the data; this is the visible residue the player never caused.
        --
        -- Gated on lastSentAt, NOT `sent`: a refused command prints its local
        -- echo FIRST, the echo match above consumed that command's `sent` entry,
        -- and this line arrives after -- so `sent` no longer holds it. lastSentAt
        -- survives the echo match and answers the real question, "did we just
        -- send". The window keeps a genuine command error the player typed, away
        -- from our traffic, out of the net: our sends cluster on zone-in, where
        -- the player is not typing a command of their own.
        --
        -- Spelled inline rather than through echo.elapsed because
        -- harness_dwsuite.py reads this exact comparison out of the master to
        -- prove the swallow rides lastSentAt. The `now >= lastSentAt` half is
        -- the clock-wrap guard: a stamp the clock has wrapped past must read
        -- as "long ago", or every command error the player ever types after
        -- day 25 is eaten until our next send.
        if (line:find(ERROR_MARK, 1, true) ~= nil and now >= lastSentAt and (now - lastSentAt) <= ERROR_WINDOW) then
            e.blocked = true;

            return;
        end
    end);
end

--[[
* ZONE-IN STAGGER. (Added 2026-08-14 for the login-time "A command error
* occurred." spam.)
*
* Two client facts, each of which answers an outgoing chat line with "A command
* error occurred." and then DROPS it -- the line never reaches the server, so
* the map log is clean and the failure is invisible from the server side:
*
*   1. The client refuses chat while it is still zoning. dwtracker/dwfame/
*      dwraid already wait out `GetIsZoning()` before their zone-in sync; this
*      file does not touch that, and dwcon now does it too.
*   2. The client rate-limits chat. Several lines in the same beat lose all but
*      one -- and every addon runs in its own Lua state (see the header), so the
*      packet_out back-off that spaces STEADY-STATE traffic cannot see a
*      sibling's send until the client has already put it on the wire, a frame
*      or more later. On a login every auto-syncing addon's zone-in hello is
*      armed at once and fires the instant the zoning flag clears -- the SAME
*      frame for all of them -- so that back-off is blind to exactly the burst
*      it exists to prevent. That is the 3-6 lines players saw per login.
*
* The fix needs no shared memory the isolated states do not have: each
* auto-syncing addon takes a SLOT in one canonical order and holds its zone-in
* sync `slot * SEND_INTERVAL` past the moment the client stops zoning. No two
* slots land in the same throttle window, so the burst serialises into one line
* per window with nothing dropped. Steady-state traffic is unchanged -- the slot
* only gates the automatic zone-in sync, never a line the player asked for.
*
* ADDITIVE: a new zone-in auto-syncer APPENDS its name here (reordering only
* changes who waits longest). harness_dwsuite.py gates both halves -- every name
* here is called by exactly its own addon, every caller is named here, no dups,
* and the list does not shrink.
--]]

--[[
* THE send interval: the one fact about the client's chat rate limit, and this
* is where it lives. A line per 1.2 seconds is what the client accepts without
* answering "A command error occurred."; the zone stagger multiplies it, a
* self-paced drain (dwah's market collect) doubles it, and every pumpQueue
* spaces its sends by it. Every addon in the suite still declares a
* `local SEND_INTERVAL = 1.2` of its own beside this one -- twenty-five copies
* of a shared number that agree today and are checked by nothing. Read this
* field instead (dwcon, dwfame, dwraid and dwtracker already do, for the
* stagger arithmetic); a retune here then reaches every carrier on the next
* copy, and a copy that still spells its own number is the odd one out.
--]]
echo.SEND_INTERVAL = 1.2;

echo.ZONE_ORDER = {
    'dwtracker',
    'dwcon',
    'dwfame',
    'dwraid',
};

--[[
* The player object, or nil. Three calls cross the memory-manager boundary
* here and any of them can be nil for a frame around a zone line -- and
* canSend() is called from every pumpQueue, one of the few places in the
* suite outside a render pcall, so a throw there unloads the addon rather
* than costing a frame. pcall'd for that reason: an answer of nil means "we
* cannot tell", never "safe".
--]]
function echo.player()
    local ok, player = pcall(function ()
        local memory = AshitaCore:GetMemoryManager();

        if (memory == nil) then
            return nil;
        end

        return memory:GetPlayer();
    end);

    if (not ok) then
        return nil;
    end

    return player;
end

--[[
* MAY A LINE GO OUT AT ALL RIGHT NOW? (Added 2026-08-15.)
*
* The ZONE_ORDER stagger above fixed the LOGIN burst: the four addons that sync
* on zone-in with their windows CLOSED. It did not fix the other half of the
* same client fact, because that half only shows when a window is open.
*
* Fourteen of the eighteen sending addons ask lazily -- `need*()` runs from the
* render loop and only when the window is drawn -- and every one of them clears
* its "what have I asked for" table in the 0x000A handler. So a player who
* zones with two or three dw windows open re-arms those requests on the zone-in
* packet and the queues drain on the very next frame, while the client is still
* on the load screen. None of those fourteen had a GetIsZoning() gate of any
* kind. The client answers each of those lines with "A command error occurred."
* and drops it before the server sees it -- the same visible spam the stagger
* was written to end, arriving by a different door, and then a five-second
* ANSWER_TIMEOUT before the retry repaints the window (dwport goes further and
* blames the server: "The server did not answer. Is this DriftwoodXI?").
*
* One test, in the one file all eighteen already carry, consulted from each
* addon's pumpQueue. The line stays QUEUED rather than being dropped, so the
* answer arrives a moment later instead of after a timeout.
*
* Note this is deliberately NOT called inside `echo.send`: a caller that has
* already recorded the send would then believe it went out. The queue is the
* right place to hold, and the queue is what every addon has.
--]]
function echo.canSend()
    local player = echo.player();

    -- No player object is not "safe to send"; it is "we cannot tell", and the
    -- cost of waiting a frame is nothing while the cost of guessing is a lost
    -- line and a visible error.
    if (player == nil) then
        return false;
    end

    local ok, zoning = pcall(function ()
        return player:GetIsZoning();
    end);

    if (not ok) then
        return false;
    end

    return zoning == 0;
end

--[[
* This addon's stagger slot: its 0-based position in ZONE_ORDER. A name not in
* the list answers 0, which the suite gate refuses, so an unlisted auto-syncer
* never ships.
--]]
function echo.zoneSlot(name)
    for i = 1, #echo.ZONE_ORDER do
        if (echo.ZONE_ORDER[i] == name) then
            return i - 1;
        end
    end

    return 0;
end

--[[
* THE THROTTLE STAMP. Every addon's packet_out 0x00B5 handler moves its own
* `lastSend` for each outgoing chat line EXCEPT one that starts with the
* addon's own `!` prefix -- and that exclusion is the same small bug in every
* one of them: a player who types the addon's own diagnostic command by hand
* (`!dwi sync`, which the header of that addon advertises) does not push the
* queue back, so the next queued line races it into the client's rate limit
* and one of the two is dropped. The client does not care who typed a line;
* neither does this stamp. Call it from packet_out for EVERY 0x00B5 -- own
* prefix included -- and holdReason() below counts the line. A second stamp
* for a line echo.send already recorded costs the throttle one frame, which
* is the right direction.
--]]
function echo.stamp(now)
    if (type(now) ~= 'number') then
        now = os.clock();
    end

    wireAt = now;
end

--[[
* os.clock() of the last line this addon put through echo.send, or 0 when it
* never has. This is the moment the command was handed to the client, not
* the moment it reached the wire -- that one is the addon's packet_out
* handler, a frame or so later -- but it is the reading an answer clock
* should start from: measured from the click, a clock ages against a line
* still sitting in a held queue and times out an answer that was never asked
* for. dwport grew a stillQueued() loop over its own queue for exactly this.
--]]
function echo.sentAt()
    return lastSentAt;
end

--[[
* WHY a line may not go out right now: nil (it may), 'zoning' (the client
* would refuse it, see canSend) or 'throttle' (a line went out less than
* `interval` ago -- ours through echo.send, or any line the addon reported
* through stamp()). canSend() is unchanged and stays the yes/no; this is the
* same test with a name, for the addon that wants to say "waiting for the
* zone" on screen and say nothing about the throttle, which is not worth a
* sentence.
*
* `interval` defaults to SEND_INTERVAL; `now` is optional, as in elapsed().
* Until an addon calls stamp() from its packet_out handler this answers
* 'throttle' for its own sends only, which is a subset of what its `lastSend`
* knows -- so a pumpQueue that has not adopted stamp() keeps its own
* interval test beside this one.
--]]
function echo.holdReason(interval, now)
    if (not echo.canSend()) then
        return 'zoning';
    end

    if (type(interval) ~= 'number') then
        interval = echo.SEND_INTERVAL;
    end

    if (type(now) ~= 'number') then
        now = os.clock();
    end

    local last = lastSentAt;

    if (wireAt > last) then
        last = wireAt;
    end

    if (echo.elapsed(last, now) < interval) then
        return 'throttle';
    end

    return nil;
end

--[[
* The `d|...z|` record splitter every wire addon carried byte-identically:
* every piece between separators, EMPTY pieces kept (a blank field is a
* field), and one trailing piece after the last separator -- so 'a|b|' gives
* 'a', 'b', '' and '' gives one empty piece, exactly what the old
* `string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep)` gave. The
* separator is matched as plain text, so a `%` or `]` separator cannot break
* the pattern the way it would have. Answers a T{} where Ashita's sugar is
* loaded (the addons call :append and friends on it) and a plain table
* elsewhere.
--]]
function echo.split(text, sep)
    local parts = { };

    text = tostring(text);

    if (type(sep) ~= 'string' or sep == '') then
        sep = '|';
    end

    local at = 1;

    while (true) do
        local from, to = text:find(sep, at, true);

        if (from == nil) then
            parts[#parts + 1] = text:sub(at);

            break;
        end

        parts[#parts + 1] = text:sub(at, from - 1);

        at = to + 1;
    end

    if (type(T) == 'function') then
        return T(parts);
    end

    return parts;
end

return echo;
