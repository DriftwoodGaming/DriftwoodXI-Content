--[[
* DriftwoodXI -- dwarena
*
* The Gauntlet in a window: which of Qu'bia Arena's three battlegrounds are
* running and for how long, one button that warps your whole party or
* alliance in (up to eighteen seats, alt-trusts welcome inside), and one
* that takes you back to the tile you left. Waves rise every minute, one
* level higher each floor from 101 to 150; every floor cleared pays its
* number in Burst Tokens -- the Weapon Burst currency on the Drift Board --
* plus experience and capacity points. Dying costs nothing.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE (the dwbags rule, inherited
* whole). It holds no data of its own: occupancy arrives as `a|` records,
* live runs as `r|` records and the caller's own re-entry lockout as `l|`,
* and every button is a real typed command (`!dwz enter` reaches exactly the
* dispatch `!arena enter` reaches). The server gates entry -- the whole raid
* refusal battery, re-checked server-side -- and this window can never do
* anything a player cannot.
*
* NOTHING HERE IS GREYED OUT ON A SERVER RULE, and the one control that
* looked safe to grey is why the rule is written down. Leave refuses in
* words unless you are standing in Qu'Bia Arena -- but arena_core's
* verbLeave clears a stuck `[arena]pending` charvar BEFORE it decides
* whether to refuse, so pressing Leave from anywhere is the only way out of
* an entry whose warp never fired. Mirroring half a handler would have
* removed a recovery path -- mirror every check of the handler, side effects
* included. The buttons stay live and the server keeps the last word; the
* window explains itself on hover instead.
*
* THE BOARD IS LIVE, NOT A SNAPSHOT (1.1.0). It used to be asked for exactly
* once -- the first frame the window opened -- and then never again: the
* three run clocks ticked locally forever off that one answer, so a
* battleground freed ten minutes ago still read "running -- 12:04 in" and a
* player waiting for a slot was watching a lie. The window now re-asks every
* REFRESH_SECONDS while it is open, says how old the answer is, and stands
* down on the silent latch like every other read in the suite.
*
* TURN IT OFF AND NOTHING IS LOST. `!arena` does all of it typed, and
* /port or !home leave the Gauntlet from inside exactly like the button.
--]]

addon.name    = 'dwarena';
addon.author  = 'DriftwoodXI';
-- 1.1.1 (2026-09-24): dwecho.lua only -- the shared command-error swallow no
-- longer eats another player's chat line that happens to quote the error.
addon.version = '1.1.1';
addon.desc    = 'The DriftwoodXI Gauntlet: wave survival for the whole alliance, floors 1 to 50.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; installed
-- before any other text_in handler in this file (dwecho.lua).
echo.install();

-- The sender name the server stamps on every machine-readable line.
local DATA_SENDER = '_DWZDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout; additive records never move it.
local PROTOCOL = 1;

-- Qu'Bia Arena, the Gauntlet's one venue (scripts/enum/zone.lua's
-- QUBIA_ARENA, pinned against it by this addon's harness). Read for a single
-- line of courtesy -- "you are standing inside" -- and never to gate a
-- button; see the header.
local QUBIA_ARENA = 206;

local state = T{
    open      = T{ false },

    -- Occupancy (a|), the live runs (r|) and the caller's own re-entry
    -- lockout (l|), COMMITTED ON z| from pending copies so a half-arrived
    -- reply can never half-fill the window.
    areas     = nil,        -- { busy1, busy2, busy3 } as booleans
    runs      = {},         -- { [area] = seconds since the run began }
    lockedFor = nil,        -- seconds of re-entry lockout left at syncedAt
    summary   = nil,        -- the occupancy sentence, built once per commit
    syncedAt  = nil,        -- os.clock() the last status landed, for the tickers

    pendingAreas = nil,
    pendingRuns  = nil,
    pendingLock  = nil,
    pendingSeen  = false,   -- an a| record actually arrived in this envelope

    inbound   = nil,        -- the verb of the envelope currently open
    status    = '',
    statusBad = false,
    statusAt  = 0,          -- os.clock() the banner was set; it expires
    reported  = false,      -- a render error is worth saying once, not per frame

    -- The answer clock, per read (the dwfame shape): one retry after five
    -- seconds, then the silent latch -- an unknown ! command falls through to
    -- PUBLIC /say on a server without dwz.lua, and the latch contains that.
    requested    = nil,     -- { at, tries }
    serverSilent = false,

    -- An unknown d| version was seen: one warning, then silence until the
    -- zone line re-probes it (a map restart is also a login).
    refused   = false,

    askedAt   = nil,        -- os.clock() of the last board ask, for the re-ask clock
    enterAt   = nil,        -- the Enter debounce stamp
    leaveAt   = nil,        -- the Leave debounce stamp

    zone      = -1,         -- the client's own zone, polled on an interval
    zoneAt    = nil,
};

--[[
* THE STATUS BANNER EXPIRES, which it did not before 1.1.0. It was set and
* never cleared by anything: a refusal ("Cid: Not from the floor. Get up
* first.") stayed pinned red through zone lines, relogs and the entry it had
* already been answered by -- and because it outranks the "asking..." line in
* the header, pressing Refresh underneath one gave no feedback at all.
* Twenty seconds is long enough to read and short enough that the window
* stops arguing about something the player has already fixed. A zone line
* clears it outright.
--]]
local STATUS_TTL = 20.0;

-- Seconds since a stamp, and a stamp from the FUTURE reads as very old rather
-- than very fresh. os.clock() on Windows is a 32-bit clock_t and wraps
-- negative after about 24.8 days of client uptime; every gate in this file
-- is written as `now - stamp`, and one wrap would have frozen the re-ask,
-- pinned a pressed button on "Already sent" and kept a banner up until a zone
-- line happened to clear the stamps. Erring permissive is the only safe side
-- for each of those. Finite, not math.huge: a drift built from it still
-- reaches `%d` through the clock caches below.
local WRAPPED = 2147483647;

local function elapsed(stamp)
    local now = os.clock();

    if (now < stamp) then
        return WRAPPED;
    end

    return now - stamp;
end

local function setStatus(text, bad)
    state.status    = text or '';
    state.statusBad = bad and true or false;
    state.statusAt  = os.clock();
end

-- The banner if it is still worth drawing, else nil.
local function statusText()
    if (state.status == nil or state.status == '') then
        return nil;
    end

    if (elapsed(state.statusAt) >= STATUS_TTL) then
        return nil;
    end

    return state.status;
end

--[[
* Outbound: `!dwz` lines, one per interval through the same queue-and-pump
* every sending sibling runs -- the client rate-limits outgoing chat and
* answers a burst with "A command error occurred" before the server sees it.
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

local function issue(command)
    -- Duplicates collapse: a double-clicked Enter must reach the server
    -- once. There is exactly one write on this wire and it is idempotent
    -- server-side anyway (a pending entry refuses a second one).
    for _, queued in ipairs(queue) do
        if (queued == command) then
            return;
        end
    end

    queue:append(command);
end

local function pumpQueue()
    -- THE EMPTY-QUEUE TEST COMES FIRST (2026-09-06): this runs on every
    -- rendered frame for the life of the session and the queue is empty in
    -- almost all of them, while echo.canSend() is three calls across the
    -- C++ boundary (GetMemoryManager, GetPlayer, GetIsZoning). Asking it
    -- first spent a hundred and eighty of those a second to decide to do
    -- nothing. An empty queue has no line to hold or to drop, so the order
    -- is free.
    if (#queue == 0) then
        return;
    end

    -- Held, not dropped, while the client is zoning (dwecho's canSend).
    if (not echo.canSend()) then
        return;
    end

    -- Wrap-tolerant (elapsed, above): a stamp from the future would otherwise
    -- hold every line in this queue until the player's own next chat line
    -- happened to re-stamp lastSend from the packet_out handler.
    if (elapsed(lastSend) < SEND_INTERVAL) then
        return;
    end

    lastSend = os.clock();

    echo.send(table.remove(queue, 1));
end

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

--[[
* `force` is the Refresh button, and it is the whole reason this function
* grew an argument. A click is the player asking, and the silent latch
* exists to contain AUTOMATIC re-asks, not to ignore the player: before
* 1.1.0 `askStatus` returned early on `serverSilent`, so once the latch
* closed the Refresh button was a control that did nothing at all, forever,
* and the only way back was a zone line (the dwnemesis 1.1.0 finding, which
* dwleaderboard already carries).
*
* The PROTOCOL refusal is deliberately not lifted by a click: an addon that
* cannot read this server's records would only earn the same banner again,
* and the zone line re-probes it anyway once a map restart could have
* changed the answer.
--]]
local function askStatus(force)
    if (state.refused) then
        return;
    end

    if (state.serverSilent) then
        if (not force) then
            return;
        end

        state.serverSilent = false;
    end

    -- A deliberate press clears the old banner so the "asking..." line can
    -- be seen: the banner outranks it, and a sticky refusal used to make
    -- Refresh look broken even when it was working.
    if (force) then
        setStatus('', false);
    end

    state.requested = { at = os.clock(), tries = 1 };
    state.askedAt   = os.clock();

    issue('!dwz status');
end

-- The retry pass, from the render loop.
local function checkAnswers()
    local asked = state.requested;

    if (asked == nil) then
        return;
    end

    -- THE CLOCK IS RE-STAMPED WHILE THE CLIENT IS ZONING, NOT MERELY
    -- SKIPPED. This used to `return` here under a comment claiming the clock
    -- "never ages while the client is zoning" -- it does: os.clock() runs
    -- regardless and only the TEST was skipped, so the instant the zoning
    -- flag cleared the elapsed time was the whole load screen, the retry
    -- fired immediately, and the two sends landed 1.2 s apart inside the
    -- client's post-zone chat settle window -- both dropped, and the latch
    -- set against a server that was never asked (the dwscan/dwfishing
    -- "freeze" shape, fixed in dwnemesis and dwleaderboard first).
    if (not echo.canSend()) then
        asked.at = os.clock();

        return;
    end

    if (elapsed(asked.at) < ANSWER_TIMEOUT) then
        return;
    end

    if (asked.tries >= ANSWER_TRIES) then
        state.requested    = nil;
        state.serverSilent = true;

        setStatus('No answer from the server. Is DriftwoodXI up to date?', true);

        return;
    end

    asked.at    = os.clock();
    asked.tries = asked.tries + 1;

    issue('!dwz status');
end

--[[
* Record parsing. Records are accepted only between a `d|` and its `z|`;
* anything unrecognised falls off the chain rather than being an error,
* which is what lets the server grow record kinds without breaking this
* addon (dwz protocol, client discipline 3).
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

-- The occupancy sentence, built ONCE PER COMMIT rather than once per frame:
-- it only changes when the board does.
local function boardSummary(areas)
    local busy = 0;

    for area = 1, 3 do
        if (areas[area]) then
            busy = busy + 1;
        end
    end

    if (busy == 0) then
        return 'All three battlegrounds are free.';
    end

    if (busy == 3) then
        return 'All three battlegrounds are running.';
    end

    return string.format('%d of 3 battlegrounds running.', busy);
end

-- A wire field that must be a finite number of seconds, or nil. tonumber
-- accepts 'inf', 'nan' and '1e999'; math.floor keeps inf as inf, and `%d` on
-- it draws a twenty-digit clock in the client (LuaJIT casts rather than
-- raising). A field this helper refuses is skipped like an unknown record.
local function wireSeconds(text)
    local n = tonumber(text);

    if (n == nil or n ~= n or n == math.huge or n == -math.huge) then
        return nil;
    end

    return n;
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.refused = true;
            state.inbound = nil;

            -- THE PENDING ASK IS RETIRED HERE, and it was not before 1.1.0.
            -- The server has answered -- badly, but it answered -- and
            -- leaving the clock running meant it re-issued `!dwz status`
            -- five seconds later, earned a second copy of the line below in
            -- the player's chat, and then latched serverSilent. That latch's
            -- banner outranks this one in the header, so the accurate
            -- "Update dwarena through the launcher." was replaced by the
            -- flatly wrong "No answer from the server." about ten seconds
            -- after the server had in fact answered.
            state.requested = nil;

            print(chat.header('dwarena'):append(chat.error(string.format(
                'server protocol %d, addon expects %d. Update dwarena through the launcher.',
                version, PROTOCOL))));

            return;
        end

        -- Any well-versioned envelope proves the server is there (the silent
        -- latch lifts), but only a STATUS envelope answers the STATUS ask:
        -- an enter or leave answer arriving while a board request is still
        -- outstanding must not mark it answered, or a status line the client
        -- dropped is never retried and the window reads "Waiting for the
        -- arena board..." until the next zone line (the dwnemesis rule).
        state.serverSilent = false;
        state.inbound      = parts[3];

        if (state.inbound == 'status') then
            state.requested    = nil;
            state.pendingAreas = { false, false, false };
            state.pendingRuns  = {};
            state.pendingLock  = nil;
            state.pendingSeen  = false;
        end

        return;
    end

    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        setStatus(text, kind == 'e');

        -- A REFUSAL IS AN ANSWER. The bare form -- an `e|` with no `d|`
        -- around it -- is what dwz.lua hand-rolls when arena_core did not
        -- load at all, and leaving the ask outstanding underneath one let
        -- the answer clock replace the server's own sentence with "No answer
        -- from the server" five seconds later. Only the ask this envelope
        -- could plausibly be answering is retired, for the dwnemesis reason
        -- above.
        state.serverSilent = false;

        if (state.inbound == nil or state.inbound == 'status') then
            state.requested = nil;
        end

        if (kind == 'e') then
            -- A REFUSED WRITE RE-ARMS ITS BUTTON. The debounce guards a write
            -- that is still in flight, and this record is the answer: without
            -- this, "Every arena is occupied. Try again shortly." was
            -- followed by five seconds in which pressing Enter answered
            -- "Already sent -- the server is working on it.", which is
            -- exactly the opposite of true, and which is precisely the moment
            -- a player wants to try again.
            if (state.inbound == 'enter') then
                state.enterAt = nil;
            elseif (state.inbound == 'leave') then
                state.leaveAt = nil;
            end

            print(chat.header('dwarena'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    -- a| -- the three areas, busy flags in area order.
    if (kind == 'a' and state.pendingAreas ~= nil) then
        for area = 1, 3 do
            state.pendingAreas[area] = (tonumber(parts[area + 1]) or 0) ~= 0;
        end

        state.pendingSeen = true;

        return;
    end

    -- r| -- one live run: area, seconds since it began.
    if (kind == 'r' and state.pendingRuns ~= nil) then
        local area = tonumber(parts[2]) or 0;

        if (area >= 1 and area <= 3) then
            state.pendingRuns[area] = wireSeconds(parts[3]) or 0;
        end

        return;
    end

    -- l| -- the caller's OWN re-entry lockout, seconds remaining, and only
    -- while one is running. Additive on protocol 1 (dwz protocol, client
    -- discipline 2): a server too old to send it simply never draws the
    -- line, which is exactly what every dwarena before 1.1.0 saw.
    if (kind == 'l' and state.pendingAreas ~= nil) then
        state.pendingLock = wireSeconds(parts[2]) or 0;

        return;
    end

    -- k| -- the enter acknowledgement; the zone line that follows the warp
    -- re-probes everything, so nothing else needs doing here.
    if (kind == 'k') then
        setStatus('The Gauntlet rises.', false);

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        -- COMMITTED ONLY IF AN a| ACTUALLY ARRIVED. `d|` stages
        -- {false,false,false}, and before 1.1.0 `z|` committed that staging
        -- whatever else the envelope had carried -- so an answer made of
        -- nothing but a refusal drew THREE FREE BATTLEGROUNDS and a live
        -- Enter button. That is not a theoretical envelope: it is exactly
        -- what dwz.lua sends when arena_core did not load ("The Gauntlet is
        -- not loaded on this build."), and what squad_storage's writer wraps
        -- any bare `fail` in.
        if (closed == 'status') then
            if (state.pendingSeen) then
                state.areas     = state.pendingAreas;
                state.runs      = state.pendingRuns or {};
                state.lockedFor = state.pendingLock;
                state.summary   = boardSummary(state.pendingAreas);
                state.syncedAt  = os.clock();
            end

            state.pendingAreas = nil;
            state.pendingRuns  = nil;
            state.pendingLock  = nil;
            state.pendingSeen  = false;
        end

        return;
    end
end

ashita.events.register('packet_in', 'dwarena_packet_in', function (e)
    if (e.id == 0x0017) then
        -- The first byte of the sender field, before the two substrings the
        -- real test needs: every dw* data sender is `_DW...` and no
        -- character name may begin with an underscore, so one byte read
        -- skips both allocations for every ordinary chat line in a busy
        -- town. A packet too short to have a sender field answers nil here
        -- and is skipped for the same reason.
        if (e.data_modified:byte(0x09) ~= 0x5F) then
            return;
        end

        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender ~= DATA_SENDER) then
            return;
        end

        local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

        -- Blocked before parsing: a malformed record must not leak into the
        -- chat log as noise.
        e.blocked = true;

        local ok, err = pcall(handleRecord, message);

        if (not ok) then
            print(chat.header('dwarena'):append(chat.error('bad record: ' .. tostring(err))));
        end

        return;
    end

    -- A zone line invalidates the whole picture -- entering, leaving and
    -- being evicted are all zone changes -- and re-probes both latches:
    -- 0x000A is also a login, and the server on the far side of a map
    -- restart may be the updated one.
    if (e.id == 0x000A) then
        state.requested    = nil;
        state.serverSilent = false;
        state.refused      = false;
        state.areas        = nil;
        state.runs         = {};
        state.lockedFor    = nil;
        state.summary      = nil;
        state.syncedAt     = nil;
        state.askedAt      = nil;

        -- THE HALF-ARRIVED ENVELOPE GOES WITH THE PICTURE IT BELONGED TO. A
        -- zone line landing between a `d|` and its `z|` used to leave
        -- `inbound` open and the staging tables alive, so the stale `z|`
        -- arriving afterwards committed whatever the NEXT envelope had
        -- filled in so far.
        state.inbound      = nil;
        state.pendingAreas = nil;
        state.pendingRuns  = nil;
        state.pendingLock  = nil;
        state.pendingSeen  = false;

        -- The banner belongs to the picture too: a refusal earned before the
        -- zone line ("Every arena is occupied. Try again shortly.") used to
        -- stay pinned red through the warp that had already answered it.
        setStatus('', false);

        -- Both writes have landed, whatever they were: a zone line is what
        -- entering and leaving both look like from here, so neither button
        -- has anything left in flight to be debounced against.
        state.enterAt = nil;
        state.leaveAt = nil;

        -- Where the player is standing has certainly changed.
        state.zoneAt = nil;
    end
end);

--[[
* Rendering.
*
* THE HOVER TEXT LIVES IN ONE TABLE so the wording is in one place and the
* harness can assert that every line is actually reachable. One short
* sentence each, in the suite's voice; a control whose label already says
* everything gets no entry.
--]]
local TIPS = {
    refresh = 'Ask the server for the board again. Works even after "No answer from the server".',
    refused = 'Nothing here can refresh: this addon reads an older wire than the server speaks. Update dwarena through the launcher -- the two buttons below still work, and !arena status prints the board in chat meanwhile.',
    fresh   = 'How long ago the server last answered. The run clocks tick locally in between, and the board asks again by itself every half minute while this window is open.',
    board   = 'Qu\'Bia Arena runs three battlegrounds at once, so three groups can be in the Gauntlet together. Entering needs one of them free.',
    busy    = 'A group is inside this battleground. The clock is how long their run has been going, not how far they have got -- what happens inside a run belongs to the people in it.',
    free    = 'Nobody is in this battleground. A group entering now would be put here.',
    blurb   = 'Burst Tokens buy Weapon Burst augments in the Drift Board Exchange, beside Drift Coins.',
    waiting = 'The board has not arrived from the server yet. Refresh asks again.',
    enter   = 'Warps your whole party or alliance in together, up to eighteen seats. The server checks every one of you first and refuses the whole group by name if one of you cannot go.',
    leave   = 'Back to the tile your run began on. /port and !home do the same from inside -- and pressing this anywhere clears an entry that never finished warping.',
    lockout = 'Every exit closes the door on you for fifteen minutes -- winning, wiping, leaving, /port and being evicted all count. Three battlegrounds are a shared resource.',
    inside  = 'You are standing in Qu\'Bia Arena. Leave takes you back to the tile your run began on.',
};

-- The explainer paragraph, built ONCE. It was four string concatenations
-- inside the render body, which runs sixty times a second.
local BLURB = 'A trio of foes rises every minute, one level higher each floor, 101 to 150. '
    .. 'Every floor cleared pays its number in Burst Tokens -- spend them with Drift Coins on '
    .. 'Weapon Burst augments in the Drift Board Exchange. Dying costs no experience. '
    .. 'The whole party or alliance enters together, up to eighteen seats; alt-trusts can be '
    .. 'summoned inside.';

-- Built once for the same reason: three string.format calls a frame for
-- three labels that never change.
local AREA_LABEL = { 'Arena 1', 'Arena 2', 'Arena 3' };

-- Floored on BOTH halves even though every caller below already hands it a
-- whole second: `%d` on a non-integral number is a LuaJIT error, not a
-- rounding, and this is the one helper a future caller is likely to reach for
-- with a raw elapsed time.
local function clockText(seconds)
    return string.format('%d:%02d', math.floor(seconds / 60), math.floor(seconds) % 60);
end

--[[
* EVERYTHING THAT CHANGES WITH THE CLOCK IS REBUILT ONCE A SECOND, not sixty
* times. This window is otherwise completely static, so the three run clocks
* and the freshness line were its entire allocation cost -- about five
* hundred throwaway strings a second while it sat open. Each cache is one
* table, mutated in place, keyed on the whole second it was built for.
--]]
local runCache  = { {}, {}, {} };
local freshCache = {};
local lockCache  = {};

local function runText(area, seconds)
    local whole = math.max(0, math.floor(seconds));
    local cache = runCache[area];

    if (cache.second ~= whole) then
        cache.second = whole;
        cache.text   = string.format('running -- %s in', clockText(whole));
    end

    return cache.text;
end

local function freshText(seconds)
    local whole = math.max(0, math.floor(seconds));

    if (freshCache.second ~= whole) then
        freshCache.second = whole;
        freshCache.text   = whole < 60
            and string.format('as of %ds ago', whole)
            or string.format('as of %s ago', clockText(whole));
    end

    return freshCache.text;
end

local function lockText(seconds)
    local whole = math.max(0, math.floor(seconds));

    if (lockCache.second ~= whole) then
        lockCache.second = whole;
        lockCache.text   = string.format(
            'You left the Gauntlet recently -- the door opens for you in %s.', clockText(whole));
    end

    return lockCache.text;
end

--[[
* Where the player is standing, polled at most once a second (dwport's
* currentZone shape, pcall'd: the party memory is not there during a login or
* a zone load, and "we cannot tell" must never read as "no"). Used for one
* line of courtesy and never to gate a button -- see the header.
--]]
local ZONE_POLL = 1.0;

local function readZone()
    return AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0);
end

local function currentZone()
    if (state.zoneAt ~= nil and elapsed(state.zoneAt) < ZONE_POLL) then
        return state.zone;
    end

    state.zoneAt = os.clock();

    local ok, zone = pcall(readZone);

    state.zone = (ok and type(zone) == 'number') and zone or -1;

    return state.zone;
end

--[[
* A LIVE FONT METRIC, OR A CONSERVATIVE CONSTANT (dwcpx's helper, copied with
* its lesson: a hand-tuned pixel reserve drew that window's Confirm and
* Cancel off the bottom edge where they could not be clicked, 2026-08-30).
* A fallback that is too big spends a few pixels of board; one that is too
* small hides the buttons again.
--]]
local function metric(name, fallback)
    local fn = imgui[name];

    if (type(fn) ~= 'function') then
        return fallback;
    end

    local ok, value = pcall(fn);

    if (ok and type(value) == 'number' and value > 0) then
        return value;
    end

    return fallback;
end

--[[
* One press per debounce window, and a SWALLOWED PRESS SAYS SO. The queue's
* dupe-collapse only sees lines still waiting, so a second click landing
* after the first one pumped used to reach the server -- a needless refusal
* in the player's chat -- and the debounce that stopped it then ate the click
* in total silence, which reads exactly like a broken button.
--]]
local PRESS_DEBOUNCE = 5.0;

local function press(key, command, said)
    local at = state[key];

    if (at ~= nil and elapsed(at) <= PRESS_DEBOUNCE) then
        setStatus('Already sent -- the server is working on it.', false);

        return;
    end

    state[key] = os.clock();

    issue(command);
    setStatus(said, false);
end

local function renderHeader()
    if (imgui.Button('Refresh##dwz_refresh')) then
        askStatus(true);
    end

    -- The one control that CAN be inert, and it says so rather than being
    -- greyed: a protocol refusal is not lifted by a click, so under one the
    -- button is a control that genuinely does nothing. ImGui does not report
    -- a hover on a disabled item without a flag this suite does not use, so
    -- a greyed button here could not have explained itself at all.
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(state.refused and TIPS.refused or TIPS.refresh);
    end

    imgui.SameLine();

    -- WRAPPED: a refusal names a member and quotes the raid battery's own
    -- sentence, which runs well past the width left beside the button and
    -- used to be simply cut off at the window edge.
    imgui.PushTextWrapPos(0);

    local said = statusText();

    if (state.serverSilent) then
        imgui.TextColored(theme.colors.err, 'No answer from the server.');
    elseif (state.refused) then
        imgui.TextColored(theme.colors.err, 'Update dwarena through the launcher.');
    elseif (said ~= nil) then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.ok, said);
    elseif (#queue > 0 or state.requested ~= nil) then
        imgui.TextDisabled('asking...');
    else
        imgui.TextDisabled('Floor cleared = tokens earned.');
    end

    imgui.PopTextWrapPos();
end

local function renderBoard()
    imgui.TextWrapped(BLURB);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.blurb);
    end

    imgui.Separator();

    if (state.areas == nil) then
        -- "Waiting" is only true while something is still coming. Under a
        -- protocol refusal nothing is: saying "Refresh asks again" there
        -- would be the window's own tooltip telling a lie.
        if (state.refused) then
            imgui.TextDisabled('The board cannot be read until dwarena is updated.');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.refused);
            end
        else
            imgui.TextDisabled('Waiting for the arena board...');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(TIPS.waiting);
            end
        end

        return;
    end

    -- The three battlegrounds. Times tick locally off the last sync; the
    -- server is asked on the slow re-ask clock, never per frame.
    local drift = state.syncedAt ~= nil and elapsed(state.syncedAt) or 0;

    imgui.Text(state.summary or '');

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.board);
    end

    imgui.SameLine();
    imgui.TextDisabled(freshText(drift));

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.fresh);
    end

    imgui.Spacing();

    for area = 1, 3 do
        local busy = state.areas[area];

        imgui.TextColored(busy and theme.colors.warn or theme.colors.ok, AREA_LABEL[area]);

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(busy and TIPS.busy or TIPS.free);
        end

        imgui.SameLine();

        if (busy) then
            imgui.Text(runText(area, (state.runs[area] or 0) + drift));
        else
            imgui.TextDisabled('free');
        end
    end

    -- The re-entry lockout, ticked DOWN locally off the same sync: a locally
    -- ticked countdown only ever becomes more permissive, so this line can
    -- disappear early but can never claim a door is shut that the server has
    -- already opened.
    if (state.lockedFor ~= nil and (state.lockedFor - drift) > 0) then
        imgui.Spacing();
        imgui.TextColored(theme.colors.warn, lockText(state.lockedFor - drift));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.lockout);
        end
    end

    if (currentZone() == QUBIA_ARENA) then
        imgui.Spacing();
        imgui.TextDisabled('You are in Qu\'Bia Arena.');

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip(TIPS.inside);
        end
    end
end

local function renderWindow()
    renderHeader();

    imgui.Separator();

    -- THE FOOTER IS ALWAYS REACHABLE. The board used to be laid straight
    -- into the window under ImGuiWindowFlags_NoScrollbar, so dragging the
    -- window small pushed Enter and Leave off the bottom edge with nothing
    -- left to scroll -- one window over from the dwcpx report that named the
    -- shape. The board scrolls in its own child and the buttons keep the
    -- room they need. The reserve is the button row's own live height plus
    -- fourteen for the separator above it and the spacing the child itself
    -- costs on the way out; erring a few pixels large spends board, erring
    -- one pixel small clips a button, which is the whole lesson.
    local footer = metric('GetFrameHeightWithSpacing', 26) + 14;

    imgui.BeginChild('##dwz_body', { 0, -footer }, ImGuiChildFlags_None);

    -- The body runs under its OWN pcall so EndChild is reached on every
    -- path: an unbalanced child would survive to the window's End(), which
    -- is outside the render pcall entirely. The error is re-raised the
    -- instant the child is closed, so the outer handler still reports it and
    -- still shuts the window.
    local ok, err = pcall(renderBoard);

    imgui.EndChild();

    if (not ok) then
        error(err, 0);
    end

    imgui.Separator();

    if (imgui.Button('Enter the Gauntlet##dwz_enter')) then
        press('enterAt', '!dwz enter', 'Entering...');
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.enter);
    end

    imgui.SameLine();

    if (imgui.Button('Leave##dwz_leave')) then
        -- The Gauntlet's own leave answers a MACHINE writer with nothing at
        -- all -- squad_storage's `line` is a no-op in raw mode -- so a
        -- successful leave used to be completely silent in this window while
        -- a failed one shouted red. The optimistic sentence is retired by
        -- the zone line the warp brings, or by the banner's own clock.
        press('leaveAt', '!dwz leave', 'Leaving...');
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip(TIPS.leave);
    end
end

--[[
* HOW OFTEN THE OPEN WINDOW RE-ASKS. Three battlegrounds are a shared
* resource and they change hands while somebody is watching them, so a board
* asked for once and then ticked locally forever is a board that lies. Half a
* minute is one chat line per thirty seconds -- swallowed by dwecho, invisible
* to the player -- and bounds the worst case staleness to thirty seconds
* rather than the whole session. Both latches stop it, so a silent or
* too-new server is asked twice and then left alone.
--]]
local REFRESH_SECONDS = 30.0;

ashita.events.register('d3d_present', 'dwarena_present', function ()
    -- Before the visibility check: a request issued a moment before the
    -- window was closed still has to reach the server.
    pumpQueue();
    checkAnswers();

    if (not state.open[1]) then
        return;
    end

    -- The board is asked for LAZILY -- the first frame the window is
    -- actually open -- so a player who never opens it never handshakes; and
    -- then re-asked on the slow clock above for as long as it stays open.
    -- The clock is measured from the ASK, not from the answer, so an
    -- envelope that carried nothing usable cannot turn this into a request
    -- storm.
    if (state.requested == nil and not state.serverSilent and not state.refused
            and (state.askedAt == nil or elapsed(state.askedAt) >= REFRESH_SECONDS)) then
        askStatus();
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 440, 350 }, ImGuiCond_FirstUseEver);

    -- A FLOOR UNDER THE SIZE. This window is a header, a paragraph, three
    -- board rows and two buttons; dragged below about this it used to hide
    -- the buttons entirely, and with NoScrollbar there was nothing to scroll
    -- back to them. The board's own child scrolls now, so the floor only has
    -- to keep the header, a line of board and the footer on screen.
    imgui.SetNextWindowSizeConstraints({ 360, 220 }, { 99999, 99999 });

    -- NoDocking: the suite-wide flag (fused dw windows survive imgui.ini).
    local visible = imgui.Begin('DriftwoodXI Gauntlet##dwarena', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwarena'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwarena'):append(chat.message('Window closed. Everything it shows also works typed as !arena.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

-- Anything the player types counts against the client's chat rate limit, so
-- a queued line behind a typed one waits its interval instead of racing it.
ashita.events.register('packet_out', 'dwarena_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dwz') then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwarena_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed (the suite-wide
    -- /Warehouse lesson).
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/arena' and first ~= '/dwarena') then
        return;
    end

    e.blocked = true;

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        state.reported = false;
    end
end);

ashita.events.register('load', 'dwarena_load', function ()
    print(chat.header('dwarena'):append(chat.message('/arena opens the Gauntlet board. Everything it shows also works typed as !arena.')));
end);
