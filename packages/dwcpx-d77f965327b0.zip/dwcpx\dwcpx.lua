--[[
* DriftwoodXI -- dwcpx
*
* The Conquest Point Exchange in a window: every gate guard's conquest-point
* shelf -- all three nations, every rank, plus the allied sundries -- and
* every regular merchant's gil counter in Vana'diel, browsable and buyable
* from anywhere. `/cpx` opens it; there is no guard to walk to, because the
* window IS the counter.
*
* Nation tabs page by rank the way the guards' menus do, so what comes from
* where is still legible -- but nothing GATES on it: any nation's gear at any
* rank, bought with your own conquest points, no trading partner required.
* The merchant tabs (Weapons / Armor / Scrolls / Goods) fold every zone shop
* and the 24/8 guild counters into the sections the auction house would file
* them under, priced in gil OR conquest points -- which is most of the reason
* to keep signet on and keep slaying.
*
* Every row draws the client's own item icon and a hover card: name, level,
* jobs, slots, Rare/Ex, stack size, both prices, how many you already carry,
* and the item's real description. A search box on the Search tab asks the
* SERVER (!dwv find), so it sees every shelf at once, fetched or not.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It ships no stock and no arithmetic. Every tab, every dropdown, every row
* and every price arrives as _DWVDATA records answering `!dwv` reads
* (documentation/dwv_protocol.md); the tabs themselves are server records, so
* a new shelf needs no addon update. A click issues a line a player could
* type (`!dwv buy 104609 gil 12`), and THE CLIENT NEVER SENDS A PRICE -- it
* sends a shelf number. The Confirm button exists only while a quote is
* armed, a quote is armed only by a `t|` record, and the click that sends
* `confirm` disarms it in the same statement -- so one quote can buy at most
* one thing, and a window that never asked can buy nothing at all. Funds,
* bag space, the item-level ceiling and the Rare re-buy are all re-checked
* server-side at confirm time.
*
* TYPING `!cpx` ON ITS OWN OPENS THIS WINDOW. The line is intercepted before
* it leaves the client; every other !cpx command passes through.
*
* TURN IT OFF AND NOTHING IS LOST. `!cpx list sandoria rank3`, `!cpx list
* weapons sword`, `!cpx find bronze`, `!cpx buy <number> [cp|gil] [qty]` and
* `!cpx confirm` all work typed. This is friendlier; it is not required.
--]]

addon.name    = 'dwcpx';
addon.author  = 'DriftwoodXI';
addon.version = '1.0.0';
addon.desc    = 'The Conquest Point Exchange for DriftwoodXI -- every nation\'s CP shelf and every merchant\'s counter, from anywhere, for conquest points or gil.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local theme    = require('dwtheme');
local echo     = require('dwecho');
local settings = require('settings');

local C = ffi.C;

echo.install();

local PROTOCOL    = 1;
local DATA_SENDER = '_DWVDATA';

--[[
* Settings: the one thing kept is the shared quantity the Buy buttons quote
* for stackables. Everything else is server state, re-asked on open.
--]]
local defaultConfig = T{ qty = T{ 1 } };
local config        = defaultConfig;

local okLoad, loaded = pcall(settings.load, defaultConfig);

if (okLoad and loaded ~= nil) then
    config = loaded;
end

pcall(settings.register, 'settings', 'dwcpx_settings_update', function (s)
    if (s ~= nil) then
        config = s;
    end
end);

--[[
* The D3D device, fetched on first use rather than at load: this addon is
* loaded from the launcher's boot script, long before the client has a
* rendering device, and a file-scope d3d.get_device() would make the whole
* addon fail to load (dwbags' lesson, kept verbatim via dwquest).
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        local ok, dev = pcall(d3d.get_device);

        if (ok) then
            d3d8dev = dev;
        end
    end

    return d3d8dev;
end

--[[
* Item icons, from the client's own resources -- dwbags' iconOf/drawIcon by
* way of dwquest, kept verbatim, reasoning and all: cached because the shelf
* is rows redrawn every frame and D3DXCreateTextureFromFileInMemoryEx is not
* free; gc_safe_release hands back a texture that releases itself when Lua
* collects it, which is what keeps this from leaking across a reload.
--]]
local icons = T{ };

local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* The hover card's vocabulary -- dwbags' by way of dwquest, kept verbatim:
* client DAT bitmasks decoded to the words a player reads. All of it is
* presentation; the server re-checks everything that matters at confirm time.
--]]
local FLAG_EX   = 0x4000;
local FLAG_RARE = 0x8000;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

local SLOT_LABELS = {
    [0]  = 'Main',  [1]  = 'Sub',   [2]  = 'Ranged', [3]  = 'Ammo',
    [4]  = 'Head',  [5]  = 'Body',  [6]  = 'Hands',  [7]  = 'Legs',
    [8]  = 'Feet',  [9]  = 'Neck',  [10] = 'Waist',  [11] = 'Ear',
    [12] = 'Ear',   [13] = 'Ring',  [14] = 'Ring',   [15] = 'Back',
};

local function jobsText(mask)
    local names = T{ };

    for jobId = 1, #JOB_NAMES do
        if (bit.band(mask, bit.lshift(1, jobId)) ~= 0) then
            names:append(JOB_NAMES[jobId]);
        end
    end

    if (#names == 0) then
        return nil;
    end

    if (#names >= #JOB_NAMES) then
        return 'All jobs';
    end

    return table.concat(names, ' ');
end

local function slotsText(mask)
    local names = T{ };
    local seen  = { };

    for slot = 0, 15 do
        if (bit.band(mask, bit.lshift(1, slot)) ~= 0) then
            local label = SLOT_LABELS[slot];

            if (not seen[label]) then
                seen[label] = true;
                names:append(label);
            end
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, '/');
end

--[[
* The eight elemental-resist icons in the client's item descriptions are
* FFXI-private Shift-JIS pairs -- 0xEF then 0x1F..0x26, in wheel order
* fire ice wind earth lightning water light dark. ImGui wants UTF-8, so the
* raw pair renders as the '?' players reported. Each icon (and the '+' that
* usually follows it) folds to a three-letter tag. Mirrored BY HAND from
* dwbags 1.17.0 -- edit one, revisit the others.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function(b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

-- The row's display name: the client resource's (with its apostrophes) when
-- the client knows the id, the wire label when it does not.
local function itemName(itemId, fallback)
    local item = itemId ~= nil and AshitaCore:GetResourceManager():GetItemById(itemId) or nil;

    if (item ~= nil and item.Name ~= nil and item.Name[1] ~= nil and #item.Name[1] > 0) then
        return item.Name[1];
    end

    return fallback;
end

--[[
* How many of an item this CHARACTER is carrying, counted from the client's
* own containers. Display only (the server re-checks everything at confirm),
* cached for a second because the card redraws every frame, and pcall'd
* because a hover card must never be the reason the window closes.
--]]
local OWNED_CONTAINERS = { 0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12 };

local ownedCache = { at = 0, counts = { } };

local function ownedCount(itemId)
    local now = os.clock();

    if (now - ownedCache.at > 1.0) then
        ownedCache = { at = now, counts = { } };

        local ok = pcall(function ()
            local inventory = AshitaCore:GetMemoryManager():GetInventory();

            for _, containerId in ipairs(OWNED_CONTAINERS) do
                local max = inventory:GetContainerCountMax(containerId);

                for slot = 1, max do
                    local entry = inventory:GetContainerItem(containerId, slot);

                    if (entry ~= nil and entry.Id > 0 and entry.Id < 65535 and entry.Count > 0) then
                        ownedCache.counts[entry.Id] = (ownedCache.counts[entry.Id] or 0) + entry.Count;
                    end
                end
            end
        end);

        if (not ok) then
            ownedCache.counts = { };
        end
    end

    return ownedCache.counts[itemId] or 0;
end

--[[
* State. Everything here is a rendering of server records; the only numbers
* that move locally are countdowns.
--]]
local state = {
    open        = { false, },
    now         = os.clock(),
    reported    = false,
    status      = '',
    statusBad   = false,
    serverSpoke = false,
    synced      = false,
    inbound     = nil,

    purse       = nil,      -- { cp, gil, rank, nation } from g|
    tabs        = { },      -- j| order: { key, label, kind }
    drops       = { },      -- [tabkey] = { { key, label, count }, ... }
    selected    = { },      -- [tabkey] = selected drop key
    lists       = { },      -- [tab/drop] = { rows, page, pages, total, synced }
    quote       = nil,      -- t| arms it; nothing else can
    find        = { text = { '' }, results = { }, synced = false, asked = false },

    filter      = { '' },   -- client-side row filter, shared across tabs
    fitsMe      = { false },
    fitsBroken  = false,
};

local NATION_NAMES = { [0] = 'San d\'Oria', [1] = 'Bastok', [2] = 'Windurst' };

local function listKey(tabKey, dropKey)
    return tabKey .. '/' .. dropKey;
end

--[[
* Sending: one command per interval, reads deduplicated, WRITES NEVER
* COLLAPSED AND NEVER RETRIED (the dwmerc rule). A lost `buy` re-sent could
* re-quote after the player moved on; a lost `confirm` re-sent is the double
* purchase the whole two-step exists to prevent. Writes drain first.
--]]
local SEND_INTERVAL = 1.2;

local readQueue    = { };
local writeQueue   = { };
local lastSend     = 0;
local writePending = nil;

local WRITE_TIMEOUT = 10.0;

local function issueRead(command)
    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

local function beginWrite(what, label, command)
    writePending = { what = what, label = label, at = os.clock() };
    table.insert(writeQueue, command);
end

local function pumpQueue(now)
    if (not echo.canSend()) then
        return;
    end

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#writeQueue > 0) then
        lastSend = now;
        echo.send(table.remove(writeQueue, 1));

        return;
    end

    if (#readQueue > 0) then
        lastSend = now;
        echo.send(table.remove(readQueue, 1));
    end
end

--[[
* Ask-once-retry-once (the dwquest discipline): one ask, one retry on a 5s
* silence, then stop and say so -- a retry that never terminates is a command
* loop, and on a server without this module an unknown ! command falls
* through to public /say.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = { };

local function refresh()
    requested = { };
end

local function askOnce(key, command, now)
    local asked = requested[key];

    if (asked ~= nil) then
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or (now - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (not asked.gaveUp) then
                asked.gaveUp = true;

                if (not state.serverSpoke) then
                    state.status    = 'The server did not answer. Is this DriftwoodXI, and is the update installed?';
                    state.statusBad = true;
                end
            end

            return;
        end

        asked.at    = now;
        asked.tries = asked.tries + 1;
    else
        requested[key] = { at = now, answered = false, tries = 1 };
    end

    issueRead(command);
end

local function needHello(now)
    askOnce('hello', '!dwv hello', now);
end

-- The visible tab/drop's rows, page by page: the h| header says how many
-- pages there are, and the next page is asked only after the last answered.
local function needList(tabKey, dropKey, now)
    local key  = listKey(tabKey, dropKey);
    local list = state.lists[key];

    if (list ~= nil and list.synced) then
        if (list.pages ~= nil and list.page ~= nil and list.page < list.pages) then
            askOnce(string.format('list:%s:%d', key, list.page + 1),
                string.format('!dwv list %s %s %d', tabKey, dropKey, list.page + 1), now);
        end

        return;
    end

    askOnce(string.format('list:%s:1', key),
        string.format('!dwv list %s %s 1', tabKey, dropKey), now);
end

--[[
* Record intake. A reader accepts records only between d| and z|; the
* version handshake is a HARD refusal (this window must never render prices
* off a wire it half-understands), and every reset runs FIRST because the
* handler runs under a pcall.
--]]
local function split(line, sep)
    local parts = { };

    for part in string.gmatch(line, '([^' .. sep .. ']+)') do
        table.insert(parts, part);
    end

    return parts;
end

local function num(text, fallback)
    local value = tonumber(text);

    if (value == nil) then
        return fallback;
    end

    return value;
end

-- Which list fetch the f| records now arriving belong to: named by the h|
-- header, cleared with the envelope.
local currentList = nil;

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = num(parts[2], 0);

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwcpx.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.serverSpoke = true;
        state.inbound     = parts[3];

        if (state.inbound == 'hello') then
            state.tabs  = { };
            state.drops = { };

            local asked = requested['hello'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (state.inbound == 'find') then
            state.find.results = { };
            state.find.synced  = false;
        end

        -- `list` is deliberately not reset here: the rows belong to whichever
        -- tab/drop the h| header names, and the header does the resetting.

        return;
    end

    if (kind == 'm' or kind == 'e') then
        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwcpx'):append(chat.error(state.status)));
        end

        local endsWrite = state.inbound == 'buy' or state.inbound == 'confirm'
            or (state.inbound == 'status' and writePending ~= nil);

        -- A REFUSED CONFIRM IS A REFUSAL, NOT A RETRY PROMPT: every reason it
        -- can fail is fixed by a fresh quote and none by re-sending the word.
        if (kind == 'e' and (state.inbound == 'confirm'
                or (state.inbound == 'status' and writePending ~= nil
                    and writePending.what == 'confirm'))) then
            state.quote = nil;
        end

        if (endsWrite) then
            writePending = nil;
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closing = state.inbound;

        state.inbound = nil;

        if (closing == 'hello') then
            state.synced = true;

            if (state.status == 'Loading...') then
                state.status = '';
            end
        elseif (closing == 'list') then
            if (currentList ~= nil) then
                local list = state.lists[currentList];

                if (list ~= nil) then
                    list.synced = true;
                end

                local asked = requested[string.format('list:%s:%d',
                    currentList, list ~= nil and list.page or 1)];

                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            currentList = nil;
        elseif (closing == 'find') then
            state.find.synced = true;

            local asked = requested['find'];

            if (type(asked) == 'table') then
                asked.answered = true;
            end
        elseif (closing == 'buy' or closing == 'confirm') then
            writePending = nil;

            if (closing == 'confirm') then
                -- Armed or not, this quote is spent; the g| that came with
                -- the answer already moved the purse on screen.
                state.quote = nil;
                -- The counts a purchase changes are re-read lazily.
                ownedCache.at = 0;
            end
        end

        return;
    end

    if (kind == 'g') then
        state.purse = {
            cp     = num(parts[2], 0),
            gil    = num(parts[3], 0),
            rank   = num(parts[4], 0),
            nation = num(parts[5], 0),
        };

        return;
    end

    if (kind == 'j') then
        table.insert(state.tabs, {
            key   = parts[3] or '',
            label = parts[4] or '',
            kind  = parts[5] or 'cp',
        });

        return;
    end

    if (kind == 'k') then
        local tabKey = parts[2] or '';

        if (state.drops[tabKey] == nil) then
            state.drops[tabKey] = { };
        end

        table.insert(state.drops[tabKey], {
            key   = parts[3] or '',
            label = parts[4] or '',
            count = num(parts[5], 0),
        });

        return;
    end

    if (kind == 'h') then
        local tabKey  = parts[2] or '';
        local dropKey = parts[3] or '';
        local page    = num(parts[4], 1);

        currentList = listKey(tabKey, dropKey);

        local list = state.lists[currentList];

        if (page <= 1 or list == nil) then
            list = { rows = { }, synced = false };
            state.lists[currentList] = list;
        end

        list.page   = page;
        list.pages  = num(parts[5], 1);
        list.total  = num(parts[6], 0);
        list.synced = false;

        return;
    end

    if (kind == 'f') then
        if (currentList == nil or state.lists[currentList] == nil) then
            return;
        end

        table.insert(state.lists[currentList].rows, {
            index  = num(parts[2], 0),
            itemid = num(parts[3], 0),
            cp     = num(parts[4], 0),
            gil    = num(parts[5], 0),
            level  = num(parts[6], 0),
            stack  = num(parts[7], 1),
            label  = parts[8] or '',
        });

        return;
    end

    if (kind == 'r') then
        table.insert(state.find.results, {
            index  = num(parts[2], 0),
            itemid = num(parts[3], 0),
            cp     = num(parts[4], 0),
            gil    = num(parts[5], 0),
            level  = num(parts[6], 0),
            stack  = num(parts[7], 1),
            tab    = parts[8] or '',
            label  = parts[9] or '',
        });

        return;
    end

    if (kind == 't') then
        state.quote = {
            index    = num(parts[2], 0),
            qty      = num(parts[3], 1),
            currency = parts[4] or 'gil',
            total    = num(parts[5], 0),
            holds    = num(parts[6], 60),
            label    = parts[7] or '',
            at       = os.clock(),
        };

        writePending = nil;

        return;
    end
end

ashita.events.register('packet_in', 'dwcpx_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwcpx'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Reads over the synced state.
--]]
local function ticked(base, at, now)
    if (base == nil or at == nil) then
        return nil;
    end

    local left = base - (now - at);

    return left > 0 and left or 0;
end

local function fmtNumber(value)
    local text  = tostring(math.floor(value));
    local out   = '';
    local count = 0;

    for i = #text, 1, -1 do
        out   = text:sub(i, i) .. out;
        count = count + 1;

        if (count % 3 == 0 and i > 1) then
            out = ',' .. out;
        end
    end

    return out;
end

-- Can my main job wear this, at my level? Display-only sugar for the
-- "Fits me" filter; guarded, and latched off on the first error.
local function fitsMe(itemId)
    if (state.fitsBroken) then
        return true;
    end

    local ok, fits = pcall(function ()
        local player = AshitaCore:GetMemoryManager():GetPlayer();
        local item   = AshitaCore:GetResourceManager():GetItemById(itemId);

        if (player == nil or item == nil) then
            return true;
        end

        local jobs = item.Jobs;

        if (jobs == nil or jobs == 0) then
            return true; -- not equipment: everything fits
        end

        local job   = player:GetMainJob();
        local level = player:GetMainJobLevel();

        if (job == nil or job == 0) then
            return true;
        end

        if (bit.band(jobs, bit.lshift(1, job)) == 0) then
            return false;
        end

        return item.Level == nil or item.Level <= level;
    end);

    if (not ok) then
        state.fitsBroken = true;

        return true;
    end

    return fits;
end

--[[
* The hover card: the client's own item knowledge plus this shelf's prices.
--]]
local function itemCard(row, tabLabel)
    imgui.BeginTooltip();

    local item = nil;

    if (row.itemid ~= nil and row.itemid ~= 0) then
        item = AshitaCore:GetResourceManager():GetItemById(row.itemid);

        drawIcon(row.itemid, 32);
    end

    imgui.Text(itemName(row.itemid, row.label));

    if (item ~= nil) then
        local tags = T{ };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags:append(string.format('iLvl %d', item.ItemLevel));
        end

        if (item.Level ~= nil and item.Level > 0) then
            tags:append(string.format('Lv.%d', item.Level));
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_RARE) ~= 0) then
            tags:append('Rare');
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_EX) ~= 0) then
            tags:append('Ex');
        end

        if (row.stack ~= nil and row.stack > 1) then
            tags:append(string.format('Stack %d', row.stack));
        end

        if (#tags > 0) then
            imgui.TextColored(theme.colors.info, table.concat(tags, '  '));
        end

        local slots = item.Slots ~= nil and slotsText(item.Slots) or nil;
        local jobs  = item.Jobs ~= nil and jobsText(item.Jobs) or nil;

        if (slots ~= nil and jobs ~= nil) then
            imgui.TextDisabled(slots .. '  --  ' .. jobs);
        elseif (slots ~= nil or jobs ~= nil) then
            imgui.TextDisabled(slots or jobs);
        end
    end

    -- The prices, colored by whether the purse on screen covers them.
    local purse = state.purse;

    if (row.gil ~= nil and row.gil > 0) then
        imgui.TextColored(
            (purse ~= nil and purse.gil >= row.gil) and theme.colors.ok or theme.colors.err,
            string.format('%s gil', fmtNumber(row.gil)));
        imgui.SameLine();
        imgui.TextDisabled('or');
        imgui.SameLine();
    end

    imgui.TextColored(
        (purse ~= nil and purse.cp >= (row.cp or 0)) and theme.colors.ok or theme.colors.err,
        string.format('%s CP', fmtNumber(row.cp or 0)));

    if (tabLabel ~= nil) then
        imgui.SameLine();
        imgui.TextDisabled('-- ' .. tabLabel);
    end

    local owned = ownedCount(row.itemid);

    if (owned > 0) then
        imgui.TextDisabled(string.format('You are carrying %d.', owned));
    end

    if (item ~= nil) then
        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            -- A fixed wrap width, not one derived from imgui state: the
            -- card must render the same whatever window it floats over.
            imgui.PushTextWrapPos(320.0);
            imgui.Text(cleanDescription(desc));
            imgui.PopTextWrapPos();
        end
    end

    imgui.EndTooltip();
end

--[[
* Actions. Every one is a line a player could type.
--]]
local function quoteBuy(row, currency)
    local qty = 1;

    if (row.stack ~= nil and row.stack > 1) then
        qty = math.max(1, math.min(config.qty[1] or 1, row.stack));
    end

    beginWrite('buy', row.label,
        string.format('!dwv buy %d %s %d', row.index, currency, qty));
end

--[[
* One shelf row: icon, name, level, prices, Buy. The hover card rides the
* icon and the name (drawIcon leaves the cursor on the same line, and
* IsItemHovered reads the LAST item, so the icon's hover is taken first).
--]]
local function shelfRow(row, tabLabel, rowId)
    drawIcon(row.itemid, 20);

    local hoveredIcon = imgui.IsItemHovered();

    imgui.Text(itemName(row.itemid, row.label));

    if (imgui.IsItemHovered() or hoveredIcon) then
        itemCard(row, tabLabel);
    end

    if (row.level ~= nil and row.level > 1) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('Lv.%d', row.level));
    end

    local purse = state.purse;

    imgui.SameLine();

    if (row.gil > 0) then
        imgui.TextColored(
            (purse ~= nil and purse.gil >= row.gil) and theme.colors.ok or theme.colors.err,
            fmtNumber(row.gil) .. 'g');
        imgui.SameLine();
        imgui.TextDisabled('/');
        imgui.SameLine();
    end

    imgui.TextColored(
        (purse ~= nil and purse.cp >= row.cp) and theme.colors.ok or theme.colors.err,
        fmtNumber(row.cp) .. 'cp');

    imgui.SameLine();

    if (writePending ~= nil) then
        imgui.TextDisabled('busy...');
    elseif (state.quote == nil) then
        if (row.gil > 0) then
            if (imgui.SmallButton(string.format('Gil##dwcpx_buy_g_%s', rowId))) then
                quoteBuy(row, 'gil');
            end

            imgui.SameLine();

            if (imgui.SmallButton(string.format('CP##dwcpx_buy_c_%s', rowId))) then
                quoteBuy(row, 'cp');
            end
        else
            if (imgui.SmallButton(string.format('Buy##dwcpx_buy_%s', rowId))) then
                quoteBuy(row, 'cp');
            end
        end
    end
end

--[[
* The armed quote, and the ONLY place Confirm exists. Local teardown on
* Cancel: the server's quote ages out on its own clock, and nothing un-asks
* a price.
--]]
local function quoteStrip()
    if (state.quote == nil) then
        return;
    end

    imgui.Separator();

    local left = ticked(state.quote.holds, state.quote.at, state.now);

    if (left ~= nil and left <= 0) then
        state.quote = nil;

        return;
    end

    imgui.TextColored(theme.colors.hint, string.format('%s%s -- %s %s   (%ds to confirm)',
        state.quote.label,
        state.quote.qty > 1 and string.format(' x%d', state.quote.qty) or '',
        fmtNumber(state.quote.total),
        state.quote.currency == 'gil' and 'gil' or 'CP',
        left or 0));

    if (writePending ~= nil) then
        imgui.TextDisabled('buying...');
    else
        if (imgui.SmallButton('Confirm##dwcpx_confirm')) then
            state.quote = nil;
            beginWrite('confirm', 'confirm', '!dwv confirm');
        end

        imgui.SameLine();

        if (imgui.SmallButton('Cancel##dwcpx_cancel')) then
            state.quote = nil;
        end
    end
end

--[[
* One tab's pane: the dropdown the server sent, the client-side filter, and
* the fetched rows. The fetch itself is armed by the render (lazy: a tab
* nobody looks at is never fetched).
--]]
local wantedList = nil;

local function shelfPane(tab)
    local drops = state.drops[tab.key] or { };

    if (#drops == 0) then
        imgui.TextDisabled('Nothing is stocked here.');

        return;
    end

    -- The selected section, defaulting to the first stocked one.
    local selectedKey = state.selected[tab.key];

    if (selectedKey == nil) then
        for _, drop in ipairs(drops) do
            if (drop.count > 0) then
                selectedKey = drop.key;
                break;
            end
        end

        selectedKey             = selectedKey or drops[1].key;
        state.selected[tab.key] = selectedKey;
    end

    local current = nil;

    for _, drop in ipairs(drops) do
        if (drop.key == selectedKey) then
            current = drop;
        end
    end

    imgui.SetNextItemWidth(170);

    if (imgui.BeginCombo('##dwcpx_drop_' .. tab.key,
            current ~= nil and string.format('%s (%d)', current.label, current.count) or 'Pick a section...')) then
        for _, drop in ipairs(drops) do
            if (imgui.Selectable(string.format('%s (%d)##dwcpx_drop_%s_%s',
                    drop.label, drop.count, tab.key, drop.key), drop.key == selectedKey)) then
                state.selected[tab.key] = drop.key;
            end
        end

        imgui.EndCombo();
    end

    imgui.SameLine();
    imgui.SetNextItemWidth(140);
    imgui.InputTextWithHint('##dwcpx_filter', 'filter...', state.filter, 48);

    imgui.SameLine();
    imgui.Checkbox('Fits me##dwcpx_fits', state.fitsMe);

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Only rows your current main job could equip at its level.\nGoods and scrolls always show.');
    end

    imgui.SameLine();
    imgui.SetNextItemWidth(70);

    if (imgui.InputInt('Qty##dwcpx_qty', config.qty)) then
        if (config.qty[1] == nil or config.qty[1] < 1) then
            config.qty[1] = 1;
        elseif (config.qty[1] > 99) then
            config.qty[1] = 99;
        end

        pcall(settings.save);
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('How many a Buy click quotes, for stackable rows.\nSingle items always quote one.');
    end

    imgui.Separator();

    selectedKey = state.selected[tab.key];
    wantedList  = { tab = tab.key, drop = selectedKey };

    local list = state.lists[listKey(tab.key, selectedKey)];

    if (not imgui.BeginChild('##dwcpx_rows_' .. tab.key, { -1, -32 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (list == nil or (#list.rows == 0 and not list.synced)) then
        imgui.TextDisabled('Fetching the shelf...');
        imgui.EndChild();

        return;
    end

    local filterText = string.lower(state.filter[1] or '');
    local shown      = 0;

    for n, row in ipairs(list.rows) do
        local visible = true;

        if (#filterText > 0 and
                string.find(string.lower(itemName(row.itemid, row.label)), filterText, 1, true) == nil) then
            visible = false;
        end

        if (visible and state.fitsMe[1] and not fitsMe(row.itemid)) then
            visible = false;
        end

        if (visible) then
            shown = shown + 1;
            shelfRow(row, nil, string.format('%s_%d', tab.key, n));
        end
    end

    if (shown == 0) then
        imgui.TextDisabled(list.total == 0 and 'Nothing is stocked in this section.'
            or 'Nothing here matches the filter.');
    end

    if (list.pages ~= nil and list.page ~= nil and list.page < list.pages) then
        imgui.TextDisabled(string.format('Fetching more... (%d of %d pages)', list.page, list.pages));
    end

    imgui.EndChild();
end

--[[
* The Search pane: the server-side find, so it sees shelves this session
* never fetched. Results name the tab they live on.
--]]
local function searchPane()
    imgui.SetNextItemWidth(220);

    local enterPressed = imgui.InputTextWithHint('##dwcpx_find', 'search every shelf...',
        state.find.text, 48, ImGuiInputTextFlags_EnterReturnsTrue);

    imgui.SameLine();

    local clicked = imgui.SmallButton('Search##dwcpx_find_go');

    if ((enterPressed or clicked) and #(state.find.text[1] or '') >= 3) then
        state.find.results = { };
        state.find.synced  = false;
        state.find.asked   = true;
        requested['find']  = nil;

        askOnce('find', '!dwv find ' .. state.find.text[1], state.now);
    end

    imgui.Separator();

    if (not imgui.BeginChild('##dwcpx_find_rows', { -1, -32 }, ImGuiChildFlags_None)) then
        imgui.EndChild();

        return;
    end

    if (not state.find.asked) then
        imgui.TextDisabled('Three letters or more, then Search. Every shelf is looked at, fetched or not.');
    elseif (not state.find.synced) then
        imgui.TextDisabled('Searching...');
    elseif (#state.find.results == 0) then
        imgui.TextDisabled('Nothing on any shelf matches that.');
    else
        for n, row in ipairs(state.find.results) do
            shelfRow(row, row.tab, string.format('find_%d', n));
        end
    end

    imgui.EndChild();
end

--[[
* The window.
--]]
local function renderWindow()
    -- The purse header: what you hold, where you rank.
    if (state.purse ~= nil) then
        imgui.TextColored(theme.colors.badge, fmtNumber(state.purse.cp) .. ' CP');
        imgui.SameLine();
        imgui.TextDisabled('|');
        imgui.SameLine();
        imgui.TextColored(theme.colors.badge, fmtNumber(state.purse.gil) .. ' gil');
        imgui.SameLine();
        imgui.TextDisabled(string.format('Rank %d, %s', state.purse.rank,
            NATION_NAMES[state.purse.nation] or 'Vana\'diel'));
    else
        imgui.TextDisabled('Reading your purse...');
    end

    imgui.SameLine(imgui.GetWindowWidth() - 70);

    if (imgui.SmallButton('Refresh##dwcpx_refresh')) then
        state.lists = { };
        refresh();
    end

    wantedList = nil;

    if (imgui.BeginTabBar('##dwcpx_tabs')) then
        for _, tab in ipairs(state.tabs) do
            if (imgui.BeginTabItem(string.format('%s##dwcpx_tab_%s', tab.label, tab.key))) then
                local ok, err = pcall(shelfPane, tab);

                if (not ok) then
                    imgui.TextDisabled('This shelf failed to draw: ' .. tostring(err));
                end

                imgui.EndTabItem();
            end
        end

        if (imgui.BeginTabItem('Search##dwcpx_tab_find')) then
            local ok, err = pcall(searchPane);

            if (not ok) then
                imgui.TextDisabled('The search failed to draw: ' .. tostring(err));
            end

            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    quoteStrip();

    if (state.status ~= '' and state.status ~= nil) then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.hint, state.status);
    end
end

ashita.events.register('d3d_present', 'dwcpx_present', function ()
    state.now = os.clock();

    if (writePending ~= nil and (state.now - writePending.at) > WRITE_TIMEOUT) then
        writePending    = nil;
        state.status    = 'No answer from the server. Nothing was re-sent -- Refresh shows where you stand.';
        state.statusBad = true;
    end

    pumpQueue(state.now);

    if (not state.open[1]) then
        return;
    end

    -- The reads, armed by what is on screen (lazy: a session that never
    -- opens the window never handshakes).
    needHello(state.now);

    if (state.synced and wantedList ~= nil) then
        needList(wantedList.tab, wantedList.drop, state.now);
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 680, 540 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse
    -- them into a single unthemed dock that imgui.ini kept across reloads.
    local visible = imgui.Begin('DriftwoodXI Conquest Point Exchange##dwcpx', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwcpx'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwcpx'):append(chat.message('Window closed. Everything it does also works as !cpx commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Open, close, toggle.
--]]
local function openWindow()
    state.open[1]   = true;
    state.reported  = false;
    state.status    = state.synced and '' or 'Loading...';
    state.statusBad = false;

    refresh();
end

local function toggleWindow()
    if (state.open[1]) then
        state.open[1] = false;
    else
        openWindow();
    end
end

--[[
* Watch what the player sends. Bare `!cpx` (and ui/window/gui) toggles the
* window and never leaves the client; every other !cpx line passes through
* and marks our state stale, because a typed buy changes the purse under
* the window. Any other outgoing line stamps the throttle -- the client's
* rate limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwcpx_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = message:lower():gsub('^%s+', ''):gsub('%s+$', '');

    if (lower == '!cpx' or lower == '!cpx ui' or lower == '!cpx window' or lower == '!cpx gui') then
        e.blocked = true;

        toggleWindow();

        return;
    end

    if (lower:sub(1, 4) ~= '!dwv') then
        lastSend = os.clock();
    end

    if (lower:sub(1, 4) == '!cpx') then
        refresh();
    end
end);

ashita.events.register('command', 'dwcpx_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Cpx`
    -- matched nothing and fell through to the game as an unknown command.
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/dwcpx' and first ~= '/cpx') then
        return;
    end

    e.blocked = true;

    toggleWindow();
end);

ashita.events.register('load', 'dwcpx_load', function ()
    print(chat.header('dwcpx'):append(chat.message('/cpx opens the Conquest Point Exchange: every nation\'s CP shelf and every merchant\'s counter, from anywhere. Everything it does also works typed as !cpx commands.')));
end);

--[[
* A login is a new character; a zone line is a new session as far as the
* server's answers are concerned. Reset, and re-ask only once the server has
* spoken this session (an automatic line against a dead verb is the player
* saying it in public).
--]]
ashita.events.register('packet_in', 'dwcpx_zonein', function (e)
    if (e.id == 0x000A) then
        state.synced    = false;
        state.tabs      = { };
        state.drops     = { };
        state.lists     = { };
        state.purse     = nil;
        state.status    = 'Loading...';
        state.statusBad = false;

        -- A write cannot survive the zone line it was in flight across, and
        -- NEITHER CAN A QUOTE: it was priced against a purse and a bag this
        -- window can no longer vouch for.
        writePending = nil;
        state.quote  = nil;

        ownedCache.at = 0;

        if (state.serverSpoke and state.open[1]) then
            refresh();
        end
    end
end);
