--[[
* dwhub's catalog: every DriftwoodXI addon a player can open, grouped by when
* they will want it, with the sentence the server says about it.
*
* THIS IS A COPY, AND IT IS A CHECKED ONE. `blurb` is modules/driftwoodxi/
* addons.lua's one-line description of the addon, BYTE FOR BYTE, and `cmd` is
* its slash shortcut. tools/dwhub/harness_dwhub.py reads both files and fails
* when a row here says anything `!addons` does not, when `!addons` lists an
* addon this file lacks, or when this file lists one `!addons` does not. The
* hub runs on the player's machine and cannot ask the server for its text; a
* copy nothing compares is how the login hint came to say "nine addons" on a
* server that ships twenty-nine.
*
* WHAT THIS FILE OWNS is everything `!addons` does not say: which GROUP a row
* is drawn under, the `first` sentence (what to do the first time the window
* is open), and `typed` -- the chat command that does the same job with no
* addon at all, stored WITHOUT its leading `!` so that nothing in this folder
* looks like a line for the wire (harness_dwsuite.py scans for exactly that).
* The harness holds `typed` to a command file that really exists under
* modules/driftwoodxi.
*
* `window = false` marks the two that draw nothing (dwmacro, dwengage): their
* button says Help rather than Open, because their slash command prints usage.
*
* dwgmpanel IS DELIBERATELY ABSENT, for addons.lua's own reason: it is staff
* tooling and advertising it to every player undoes three decisions at once.
--]]

local catalog = { };

-- In drawing order. `open` is whether the group starts expanded.
catalog.groups = {
    { key = 'start', label = 'Start here',          open = true,
      note = 'The windows this server is played through. New here? The Primer tab in /quests is a one-time checklist of first steps, and each one pays Drift Coins.' },
    { key = 'trade', label = 'Bags, trade and crafts', open = false,
      note = 'Where your items live, and how they turn into gil.' },
    { key = 'field', label = 'In the field',        open = false,
      note = 'Small tools for the fight in front of you.' },
    { key = 'end',   label = 'Endgame and the long game', open = false,
      note = 'What level 75 and beyond is for.' },
    { key = 'help',  label = 'When something is wrong', open = false,
      note = 'A bug report from in game reaches the people who can fix it, with your real state attached.' },
};

catalog.rows = {
    -- Start here -----------------------------------------------------------
    { id = 'dwsquad',     cmd = '/squad',     group = 'start', typed = 'squad help',
      blurb = 'Your own characters as party members -- add, call, dismiss, sort.',
      first = 'Make a second character on your account, add it to a squad slot, then call the squad.' },
    { id = 'dwjobs',      cmd = '/jobs',      group = 'start', typed = 'jobs',
      blurb = 'Main and support jobs for you, every squad slot, and the rest of the account.',
      first = 'Change your own jobs here first; your squad members\' jobs are set from the same window.' },
    { id = 'dwgambits',   cmd = '/gambits',   group = 'start', typed = 'squad rules',
      blurb = 'Build the rules your squad fights by, from dropdowns.',
      first = 'Assign one of the shipped sets to a squad member, then open it to see how a rule is built.' },
    { id = 'dwquest',     cmd = '/quests',    group = 'start', typed = 'drift',
      blurb = 'The Drift Board: daily and weekly contracts, live counters, Drift Coins.',
      first = 'Accept a contract on the Board tab. The Primer tab is a one-time checklist of first steps, and each one pays.' },
    { id = 'dwport',      cmd = '/port',      group = 'start', typed = 'port',
      blurb = 'Travel anywhere you have unlocked -- crystals, books, outposts, teleports, warps.',
      first = 'The town home points are already open to a new character. Pick one and go.' },
    { id = 'dwtracker',   cmd = '/tracker',   group = 'start',
      blurb = 'Your quest and mission journal, with the step you are on.',
      first = 'Open it while a quest or mission is active to see what it wants next.' },

    -- Bags, trade and crafts ------------------------------------------------
    { id = 'dwbags',      cmd = '/bags',      group = 'trade',
      blurb = 'Every bag on your account in one searchable window.' },
    { id = 'dwwarehouse', cmd = '/warehouse', group = 'trade', typed = 'warehouse',
      blurb = 'A thousand storage slots your whole account shares -- stash a full bag in one click.' },
    { id = 'dwah',        cmd = '/dwah',      group = 'trade', typed = 'market',
      blurb = 'The player market: browse real prices, sell from anywhere, post buy orders, claim your gil.' },
    { id = 'dwcpx',       cmd = '/cpx',       group = 'trade', typed = 'cpx',
      blurb = 'The Conquest Point Exchange: every nation\'s CP shelf and every merchant\'s counter, from anywhere, for CP or gil.' },
    { id = 'dwmerc',      cmd = '/merc',      group = 'trade', typed = 'merc',
      blurb = 'The mercenary board: hire, list your own, collect the gil.' },
    { id = 'dwcraft',     cmd = '/craft',     group = 'trade', typed = 'craft',
      blurb = 'Your crafting ledger, recipe book, ladder, session tally -- and every character on your account, craft by craft.' },
    { id = 'dwfishing',   cmd = '/dwfishing', group = 'trade', typed = 'fish',
      blurb = 'The fishing guide: every fish, the bait that hooks it, where it swims, and what to catch next.' },

    -- In the field ----------------------------------------------------------
    { id = 'dwcon',       cmd = '/dwcon',     group = 'field',
      blurb = 'Con colors over every enemy near you -- what you can take, without checking them one at a time.' },
    { id = 'dwscan',      cmd = '/dwscan',    group = 'field', typed = 'scan',
      blurb = 'Scan your target: level, drops at THIS server\'s rates, resistances, aggro range, quests.' },
    { id = 'dwtod',       cmd = '/tod',       group = 'field', typed = 'tod',
      blurb = 'Time of Death: every timer-pop notorious monster -- up or dead, dead for how long, back in how long -- with search and a watchlist.',
      first = 'Search a notorious monster by name, then pin it to the watchlist so its clock is the first thing the window shows.' },
    { id = 'dwparse',     cmd = '/parse',     group = 'field',
      blurb = 'Damage, healing, accuracy, crit and a live threat meter for the whole party.' },
    { id = 'dwchat',      cmd = '/dwchat',    group = 'field',
      blurb = 'Cleaner chat: battle lines colour-coded, and exp, skill-up and melee spam folded into fewer lines -- off until you turn it on.',
      first = 'Tick "DWChat is on" (or type /dwchat on), then fight something: hits, heals and payouts arrive colour-coded, and repeats fold into one line.' },
    { id = 'dwfame',      cmd = '/fame',      group = 'field', typed = 'fame',
      blurb = 'Your fame in every area as bars, with the fastest way to raise each.' },
    { id = 'dwtoau',      cmd = '/toau',      group = 'field', typed = 'toau',
      blurb = 'The ToAU job kit: set a squad blue mage\'s spells, build a squad puppetmaster\'s automaton, press a corsair\'s rolls.' },
    { id = 'dwmacro',     cmd = '/dwmacro',   group = 'field', window = false,
      blurb = 'Keeps your macro book and set across zoning and logout.' },
    { id = 'dwengage',    cmd = '/dwengage',  group = 'field', window = false,
      blurb = 'Spins you onto the next enemy your party is fighting when your target dies.' },

    -- Endgame and the long game ----------------------------------------------
    { id = 'dwmerits',    cmd = '/merits',    group = 'end', typed = 'merits',
      blurb = 'The merit sheet with this server\'s true totals -- and assignment past the stock menu\'s caps.' },
    { id = 'dwraid',      cmd = '/raid',      group = 'end', typed = 'raid',
      blurb = 'The raid board: fourteen boss trials across nine venues, from anywhere, no orb -- clears pay Driftmarks, spent on iLvl gear.' },
    { id = 'dwarena',     cmd = '/arena',     group = 'end', typed = 'arena',
      blurb = 'The Gauntlet: wave survival for the whole alliance, floors 1-50 -- floors pay Burst Tokens, your lockout counts down.' },
    { id = 'dwnemesis',   cmd = '/nemesis',   group = 'end', typed = 'nemesis',
      blurb = 'Nemesis: two hundred and forty-seven famous NMs at +100 in a private arena -- your own chest, their real drops, one to four random augments.' },
    { id = 'dwunleashed', cmd = '/unleashed', group = 'end', typed = 'unleashed',
      blurb = 'The world boss: where it is standing, how long until it wakes, how much of it is left, and who answered the last five.' },
    { id = 'dwspoils',    cmd = '/spoils',    group = 'end', typed = 'spoils',
      blurb = 'Spoils: any monster that pays experience can hand each real player gear with one to four augments, levelled to it -- and the hall of fours.' },
    { id = 'dwpolitics',  cmd = '/politics',  group = 'end', typed = 'politics',
      blurb = 'The seats of power: run for the Crown, a Mayoralty or the Treasury, vote, pledge, and read the Chronicle.' },
    { id = 'dwleaderboard', cmd = '/leaderboard', group = 'end', typed = 'leaderboard',
      blurb = 'The bragging boards: job levels, gil, kills, crafts, market deeds -- ties share first.' },

    -- When something is wrong ------------------------------------------------
    { id = 'dwreport',    cmd = '/report',    group = 'help',
      blurb = 'File a bug from in game, with your real state attached.' },
};

return catalog;
