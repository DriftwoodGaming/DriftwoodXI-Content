--[[
* DriftwoodXI -- dwmerc
*
* The mercenary board as a storefront: browse who is for hire, read the frozen
* snapshot you would be paying for, hire with a quoted price and a deliberate
* second click, call and dismiss what you have under contract, and collect what
* your own listings have earned -- all without typing a command.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* Every read is a `!dwm` line and every write is a `!dwm` line -- the same
* dispatch, the same verbs, the same C++ store that `!merc ...` reaches
* (documentation/dwm_protocol.md is the contract). Ownership, prices, caps and
* contract state all live server-side and are re-checked on every call
* whichever way the command arrived, which is what makes shipping a UI over a
* gil channel safe at all: a bug in here cannot spend anything the server
* would have refused a typed player.
*
* THIS ONE MOVES MONEY, so the one paragraph that matters most: THERE IS NO
* RECORD AND NO COMMAND ON THIS WIRE THAT BOTH QUOTES AND BUYS. `hire` returns
* a quote and arms nothing but a 90-second window in server module state; a
* second, separately issued command spends, with the price re-taken from the
* store on that issue too. The protocol guarantees no one-click hire is
* POSSIBLE; this window owes the player the same honesty anyway, so the
* confirm button appears only after the server's quote has arrived, in its own
* place, quoting the gross and the end time it would be consenting to. The one
* sharp edge the protocol leaves -- the SAME hire line re-issued inside the
* window IS the consent -- is guarded here with a lockout: the quote button
* will not re-issue a line that could still land on an armed quote, whichever
* tier armed it (see matchesArmed).
*
* NEVER RENDER A PRICE THIS FILE COMPUTED. `gross` is on the wire because the
* server worked it out from the listing at the moment it answered; the confirm
* button quotes the h| record's numbers and nothing else.
*
* THE LISTING TAB IS THE SAME BARGAIN ON THE SELLER'S SIDE. `!merc list` takes
* a character, a rate, an hour cap and up to three rule set names, and until the
* server grew `!merc options` there was nowhere on this wire to learn what any
* of those could be -- so the tab is a form over that one read and two writes
* (`list` and `unlist`), with every name in every picker coming off the wire and
* none of it invented here. It spends nothing and earns nothing: listing is free
* and the house takes its cut at settlement.
*
* TURN IT OFF AND NOTHING IS LOST. `!merc board`, `!merc hire`, `!merc call`,
* `!merc list`, `!merc claim` and the rest do everything this window does,
* typed, and `!merc menu` covers the bounded picks as client dialogs. This is
* faster; it is not required, and the Commands button says so with the whole
* list.
--]]

addon.name    = 'dwmerc';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.8';
addon.desc    = 'The mercenary board storefront for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat  = require('chat');
local imgui = require('imgui');
local theme = require('dwtheme');
local echo  = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this
-- file, so a blocked line is already flagged by the time they see it.
echo.install();

-- The sender name the server stamps on every machine-readable line. This is
-- _DWMDATA and never _DWDATA or _DWGDATA: dwbags and dwgambits own those, and
-- two addons contending to block one sender is a load-order bug where the
-- loser eats the winner's records (dwm_protocol.md says so at length).
local DATA_SENDER = '_DWMDATA';

-- Protocol version the server announces in every `d|` record.
local PROTOCOL = 1;

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Equip slot ids as the i| record carries them, in the order a player reads
-- them (the dwbags table).
local SLOT_NAMES = {
    [0]  = 'main',  [1]  = 'sub',   [2]  = 'ranged', [3]  = 'ammo',
    [4]  = 'head',  [5]  = 'body',  [6]  = 'hands',  [7]  = 'legs',
    [8]  = 'feet',  [9]  = 'neck',  [10] = 'waist',  [11] = 'ear1',
    [12] = 'ear2',  [13] = 'ring1', [14] = 'ring2',  [15] = 'back',
};

-- b| flags bits, as dwm_protocol.md defines them. Neither WORKING nor OFF
-- means the listing is open; bit 2 is also what says `remaining` is a real
-- countdown rather than a sentinel.
local LISTING_MINE    = 1;
local LISTING_WORKING = 2;
local LISTING_OFF     = 4;

-- n| flags. These describe the CHARACTER rather than a listing against it:
-- whether a fresh photograph can be taken of it this second. Bit 1 is the one
-- that matters most -- M10 refuses listing the character being played, because
-- the snapshot is copied out of saved rows and a live session has not written
-- them -- and it is why the Listing tab explains rather than just disabling.
local CAND_SELF   = 1;
local CAND_ONLINE = 2;
local CAND_BUSY   = 4;

-- The protocol's "this response did not measure that" sentinel. Not zero: a
-- board row that has not counted gear is not a listing with no gear.
local UNMEASURED = -1;

--[[
* The armed-quote lockout, and why it is 100 seconds.
*
* The server holds one pending quote per player for 90 seconds, and the SAME
* hire line issued again inside that window is the purchase -- that is the
* typed tier's two-word consent working as designed. For a button it is a
* misclick trap: quote, cancel, quote again would buy. So the quote button
* refuses to issue any hire line that could still match an armed quote,
* whichever tier armed it (packet_out watches typed `!merc hire` too), for the
* server's window plus a margin for the send queue. Confirming is always the
* separate `!dwm confirm` line, which can never quote.
--]]
local ARMED_WINDOW = 100;

-- How long a displayed quote is treated as confirmable, held a few seconds
-- inside the server's own window so the button disappears before the server
-- would start refusing it.
local QUOTE_MARGIN = 5;

-- All of these live in dwtheme and follow the launcher's Appearance theme.
local COLOR_ERROR = theme.colors.err;
local COLOR_OK    = theme.colors.ok;
local COLOR_WARN  = theme.colors.warn;
local COLOR_BADGE = theme.colors.badge;
local COLOR_HINT  = theme.colors.hint;

local state = T{
    open      = T{ false },

    --[[
    * World state. `listings` is ONE table keyed by listingid, filled in as
    * better-measured copies arrive -- the protocol sends the same b| shape
    * from board, info, listings and a quote, with -1 wherever that binding
    * did not measure, so a board row and an info row are the same object
    * here rather than two that can disagree. Everything else is replaced
    * wholesale by the response that owns it, never merged across responses.
    --]]
    listings  = {},         -- [listingid] = merged b| + l| fields
    loadouts  = {},         -- [listingid] = { [ordinal] = name }; never cleared
                            -- on t| -- o| records are deduplicated per envelope
                            -- and a client that dropped names on each t| would
                            -- lose them (dwm_protocol.md on o|)
    board     = nil,        -- { page, pages, total, job, rows = { listingid } }
    mine      = {},         -- listingids of the account's own listings, in order
    contracts = { active = {}, recent = {} },
    purse     = nil,        -- { balance, lifetime }
    ledger    = nil,        -- array of w|r rows
    claim     = nil,        -- the last w|c outcome

    -- The listing form's three, all from `options` and all replaced wholesale
    -- by it: the account's characters, the rule sets it could publish, and the
    -- bounds a listing has to satisfy. `limits` stays nil until that verb has
    -- answered, and its fields may be -1 on a server whose store predates the
    -- caps binding -- which means an input with no ceiling, never a guess.
    candidates = {},        -- array of n| rows, roster order
    sets       = {},        -- array of s| rows, the account's own first
    limits     = nil,       -- the c| record

    selected  = nil,        -- listingid the info pane describes

    -- The envelope being read. Records buffer between `d|` and `z|` and are
    -- processed as one response, so a torn or foreign line can never
    -- half-fill the UI. m| and e| are handled the moment they arrive -- a
    -- refusal is the one thing a player must never lose.
    inbound   = nil,
    buffer    = {},

    status    = 'Fetching...',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame
};

-- The hire dialog. One at a time, deliberately: a second dialog would be a
-- second pending quote and the server holds one.
local dialog = nil;

-- The last hire line seen leaving this client -- OURS OR TYPED. Either tier
-- arms the same server-side window (MERC_PLAN.md proved it in game: a quote
-- armed by `!dwm hire` was confirmed by a typed line 22 seconds later), so the
-- lockout has to watch both.
local armedHire = nil;

-- The last h|quote received, held OUTSIDE the dialog so that closing it does
-- not throw the quote away: reopening the same purchase inside the armed
-- window shows this copy instead of re-issuing a line the server would read
-- as the consent. Display only -- the confirm re-takes the price server-side
-- on its own issue regardless.
local heldQuote = nil;

-- A claim in flight, so the button cannot be double-clicked into a second
-- claim line. Harmless if it were -- the second finds an empty ledger -- but a
-- disabled button is the honest rendering of "already doing that".
local claimPending = false;

-- True once the server has said it has no `quote` verb -- one from before the
-- storefront's quote-only line existed. Detected off the dispatch's own
-- unknown-verb sentence and reset on every login line, the dwbags arrangement,
-- so deployment order cannot matter: a current server gets the line that can
-- never spend, an older one gets the guarded hire path below.
local quoteUnsupported = false;

-- The same arrangement for the Listing tab's one read. A server from before
-- `!merc options` existed answers it with the dispatch's unknown-verb sentence,
-- and the tab's honest response is to say so once and print the typed line --
-- not to leave a red banner up and a form full of empty pickers.
local optionsUnsupported = false;

-- The listing form for the character currently picked, rebuilt when the pick
-- changes. Its inputs are the player's; every name in every picker came off the
-- wire, and the command it composes is one a player could type.
local form = nil;

-- A list or unlist line in flight. Neither moves gil, and the store re-checks
-- ownership on both, but a button clicked twice while the first click is still
-- queued would take two photographs of the same character -- so the button says
-- what it is doing instead of accepting the second click.
local writePending = nil;

-- Listings the Contracts tab has already asked `info` about this pass, so a
-- pane drawn sixty times a second asks once per listing rather than looping.
-- Cleared with the answer tracker: Refresh re-asks.
local infoAsked = {};

-- Contracts whose expiry has already triggered the one settlement re-ask,
-- keyed by contractid. Same shape and lifetime as infoAsked, and outside the
-- rows for the same reason: the rows are rebuilt by every answer.
local expiryAsked = {};

--[[
* Sending: one command per interval, queued, reads deduplicated, writes never
* collapsed and never retried.
*
* THE CLIENT RATE-LIMITS OUTGOING CHAT AND A !dwm COMMAND IS A CHAT LINE.
* Fire two in one frame and the second is answered "A command error occurred"
* before the server ever sees it -- the dwbags lesson, applied from day one.
*
* Writes drain first: a purchase confirmation stuck behind three queued board
* reads would spend its quote window waiting in line. A write is queued at
* most once per click and NEVER re-sent on silence -- a lost `confirm` that
* was re-sent could be a purchase made twice, which is exactly the class of
* bug this addon exists to make impossible.
--]]
local SEND_INTERVAL = 1.2;

local readQueue  = {};
local writeQueue = {};
local lastSend   = 0;

local function issueRead(command)
    for _, queued in ipairs(readQueue) do
        if (queued == command) then
            return;
        end
    end

    table.insert(readQueue, command);
end

local function issueWrite(command)
    table.insert(writeQueue, command);
end

local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    if (#writeQueue > 0) then
        lastSend = now;

        echo.send(table.remove(writeQueue, 1));

        return;
    end

    if (#readQueue > 0) then
        lastSend = now;

        echo.send(table.remove(readQueue, 1));
    end
end

--[[
* Answered-question tracking, keyed by envelope verb. A PLAIN TABLE, NOT T{}:
* string keys on a T{} resolve through the sugar metatable and `find` is both
* a table method and a plausible verb name -- the collision that cost dwbags a
* round. An unanswered ask is retried once and then left alone; a retry that
* never terminates is a command loop, which is worse than a stale panel.
--]]
local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local requested = {};

local function forget()
    requested   = {};
    infoAsked   = {};
    expiryAsked = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

-- Ask for one verb about one qualifier at most once, twice if never answered.
-- Called from whatever pane needs the data, every frame, so the guard is the
-- entire point.
local function need(verb, qualifier, command)
    local asked = requested[verb];

    if (asked ~= nil and asked.qualifier == qualifier) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered or asked.tries >= ANSWER_TRIES or (os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested[verb] = { qualifier = qualifier, at = os.clock(), answered = false, tries = 1 };
    end

    issueRead(command);
end

--[[
* Text helpers.
--]]
local function split(text, sep)
    local parts = {};

    for piece in string.gmatch((text or '') .. sep, '([^' .. sep .. ']*)' .. sep) do
        table.insert(parts, piece);
    end

    return parts;
end

local function gilText(amount)
    local value = math.floor(tonumber(amount) or 0);
    local sign  = value < 0 and '-' or '';
    local text  = string.format('%d', math.abs(value));

    while true do
        local replaced;

        text, replaced = string.gsub(text, '^(%d+)(%d%d%d)', '%1,%2');

        if (replaced == 0) then
            break;
        end
    end

    return sign .. text;
end

local function spanText(seconds)
    seconds = math.max(math.floor(tonumber(seconds) or 0), 0);

    if (seconds >= 3600) then
        return string.format('%dh %02dm', math.floor(seconds / 3600), math.floor((seconds % 3600) / 60));
    end

    if (seconds >= 60) then
        return string.format('%dm %02ds', math.floor(seconds / 60), seconds % 60);
    end

    return string.format('%ds', seconds);
end

-- Coarse on purpose, like the server's own `ago`: the useful question about a
-- snapshot is whether it is from today or from a month ago.
local function agoText(seconds)
    seconds = math.floor(tonumber(seconds) or 0);

    if (seconds < 90) then
        return 'just now';
    end

    if (seconds < 5400) then
        return string.format('%d minutes ago', math.floor(seconds / 60));
    end

    if (seconds < 129600) then
        return string.format('%d hours ago', math.floor(seconds / 3600));
    end

    return string.format('%d days ago', math.floor(seconds / 86400));
end

--[[
* Durations off the wire are counts of seconds the server worked out at the
* moment it answered -- no record carries a timestamp and this client never
* subtracts two clocks (dwm_protocol.md, Clocks). Each one is stored with its
* arrival time so display can run it forward or down LOCALLY, for display
* only: every number that gates anything is re-taken from the server by the
* command that needs it.
--]]
local function stamp(value)
    if (value == nil or value < 0) then
        return nil;
    end

    return { value = value, at = os.clock() };
end

local function liveDown(stamped)
    if (stamped == nil) then
        return nil;
    end

    return math.max(stamped.value - (os.clock() - stamped.at), 0);
end

local function liveUp(stamped)
    if (stamped == nil) then
        return nil;
    end

    return stamped.value + (os.clock() - stamped.at);
end

local function jobsText(entry)
    local main = string.format('%s%d', JOB_NAMES[entry.mjob] or '?', entry.mlvl or 0);

    if ((entry.sjob or 0) > 0) then
        return string.format('%s/%s%d', main, JOB_NAMES[entry.sjob] or '?', entry.slvl or 0);
    end

    return main;
end

local function loadoutName(listingid, ordinal)
    local names = state.loadouts[listingid];

    if (names ~= nil and names[ordinal] ~= nil) then
        return names[ordinal];
    end

    return string.format('loadout %d', ordinal or 0);
end

-- The item name out of the client's own resources -- names never ride this
-- wire (the dwbags rule; the i| record carries ids only).
local function itemName(itemid)
    local item = AshitaCore:GetResourceManager():GetItemById(itemid);

    if (item == nil or item.Name[1] == nil or #item.Name[1] == 0) then
        return string.format('item %d', itemid);
    end

    return item.Name[1];
end

-- The frozen kit as display lines, slot order, from an i|-filled listing.
local function kitLines(entry)
    if (entry == nil or entry.gearlist == nil) then
        return nil;
    end

    local bySlot = {};

    for _, piece in ipairs(entry.gearlist) do
        bySlot[piece.slot] = piece.itemid;
    end

    local lines = {};

    for slot = 0, 15 do
        if (bySlot[slot] ~= nil) then
            table.insert(lines, string.format('%-7s %s', SLOT_NAMES[slot], itemName(bySlot[slot])));
        end
    end

    return lines;
end

local function loadoutCount(listingid)
    local names = state.loadouts[listingid];
    local count = 0;

    for _ in pairs(names or {}) do
        count = count + 1;
    end

    return count;
end

--[[
* Record parsing. Field positions are dwm_protocol.md's and the split is the
* parser -- fixed counts per record type is the protocol's one promise.
--]]
local function parseListing(parts)
    return {
        listingid = tonumber(parts[2]) or 0,
        name      = parts[3] or '?',
        mjob      = tonumber(parts[4]) or 0,
        mlvl      = tonumber(parts[5]) or 0,
        sjob      = tonumber(parts[6]) or 0,
        slvl      = tonumber(parts[7]) or 0,
        rate      = tonumber(parts[8]) or 0,
        maxhours  = tonumber(parts[9]) or 0,
        loadouts  = tonumber(parts[10]) or 0,
        flags     = tonumber(parts[11]) or 0,
        gear      = tonumber(parts[12]) or UNMEASURED,
        spells    = tonumber(parts[13]) or UNMEASURED,
        age       = tonumber(parts[14]) or UNMEASURED,
        hires     = tonumber(parts[15]) or UNMEASURED,
        remaining = tonumber(parts[16]) or UNMEASURED,
    };
end

--[[
* Merge a b| into the one listing table. Fields the response did not measure
* arrive as -1 and MUST NOT overwrite a measured copy -- that is the whole
* point of one shape for one thing. `remaining` is gated by flags bit 2 first
* (the protocol's own reading order): with the bit clear there is no contract,
* so any held countdown is cleared rather than left ticking at nothing.
--]]
local function mergeListing(rec)
    local entry = state.listings[rec.listingid];

    if (entry == nil) then
        entry = { listingid = rec.listingid };
        state.listings[rec.listingid] = entry;
    end

    entry.name     = rec.name;
    entry.mjob     = rec.mjob;
    entry.mlvl     = rec.mlvl;
    entry.sjob     = rec.sjob;
    entry.slvl     = rec.slvl;
    entry.rate     = rec.rate;
    entry.maxhours = rec.maxhours;
    entry.count    = rec.loadouts;
    entry.flags    = rec.flags;

    if (rec.gear ~= UNMEASURED) then
        entry.gear = rec.gear;
    end

    if (rec.spells ~= UNMEASURED) then
        entry.spells = rec.spells;
    end

    if (rec.age ~= UNMEASURED) then
        entry.age = stamp(rec.age);
    end

    if (rec.hires ~= UNMEASURED) then
        entry.hires = rec.hires;
    end

    if (bit.band(rec.flags, LISTING_WORKING) == 0) then
        entry.remaining = nil;
    elseif (rec.remaining ~= UNMEASURED) then
        entry.remaining = stamp(rec.remaining);
    end

    return entry;
end

-- The l| overlay: the owner's own facts, kept on the same listing entry but
-- rendered only in the My mercs tab -- the split is the privacy line and this
-- client keeps it (dwm_protocol.md on l|).
local function mergeOverlay(parts)
    local listingid = tonumber(parts[2]) or 0;
    local entry     = state.listings[listingid];

    if (entry == nil) then
        return;
    end

    entry.pending = (tonumber(parts[3]) or 0) ~= 0;

    local earned = tonumber(parts[4]) or UNMEASURED;

    if (earned ~= UNMEASURED) then
        entry.earned = earned;
    end

    entry.hirer = (parts[5] ~= nil and parts[5] ~= '-' and parts[5] ~= '') and parts[5] or nil;
end

local function parseContract(parts)
    return {
        contractid = tonumber(parts[2]) or 0,
        listingid  = tonumber(parts[3]) or 0,
        name       = parts[4] or '?',
        hours      = tonumber(parts[5]) or 0,
        gross      = tonumber(parts[6]) or 0,
        bought     = tonumber(parts[7]) or 0,
        running    = tonumber(parts[8]) or UNMEASURED,
        remaining  = stamp(tonumber(parts[9]) or 0),
        state      = parts[10] or 'active',
    };
end

local function parseHire(parts)
    return {
        stage      = parts[2] or '?',
        listingid  = tonumber(parts[3]) or 0,
        name       = parts[4] or '?',
        hours      = tonumber(parts[5]) or 0,
        loadout    = tonumber(parts[6]) or 0,
        gross      = tonumber(parts[7]) or 0,
        gil        = tonumber(parts[8]) or 0,
        ends       = tonumber(parts[9]) or 0,
        expires    = tonumber(parts[10]) or 0,
        contractid = tonumber(parts[11]) or 0,
    };
end

--[[
* The hire dialog's state machine. Stages: pick -> quoting -> quoted ->
* paying -> done, with every failure path landing back on pick and the
* player's inputs intact. The only line `pick` can send is a quote, and the
* only line `quoted` can send is `!dwm confirm` -- the two are different
* buttons in different places, and the second cannot exist until the server
* has answered the first.
--]]
local function dialogKey(listingid, hours, ordinal)
    return string.format('%d|%d|%d', listingid, hours, ordinal);
end

local function openDialog(listingid)
    local entry = state.listings[listingid];

    dialog = {
        listingid = listingid,
        name      = entry ~= nil and entry.name or '?',
        stage     = 'pick',
        stageAt   = os.clock(),
        hours     = T{ 1 },
        ordinal   = 1,
        quote     = nil,
        result    = nil,
        error     = nil,
    };

    state.selected = listingid;
end

--[[
* Could this exact purchase still land on an armed quote? True means a hire
* line for it must not be sent, because the server would read it as the
* confirming issue. The armed record comes from packet_out -- typed lines
* included -- and holds the raw typed name, which may be a prefix of the
* resolved one, so the name check matches either direction. A loadout token
* this client cannot resolve is treated as a match: when the lockout cannot
* tell, it locks.
--]]
local function matchesArmed(listingid, name, hours, ordinal)
    if (armedHire == nil or (os.clock() - armedHire.at) > ARMED_WINDOW) then
        return false;
    end

    if (armedHire.hours ~= hours) then
        return false;
    end

    local typed    = armedHire.name;
    local resolved = string.lower(name or '');

    if (typed ~= resolved and string.sub(resolved, 1, #typed) ~= typed) then
        return false;
    end

    local armedOrdinal;

    if (armedHire.loadout == nil) then
        armedOrdinal = 1;
    elseif (tonumber(armedHire.loadout) ~= nil) then
        armedOrdinal = tonumber(armedHire.loadout);
    else
        for index, label in pairs(state.loadouts[listingid] or {}) do
            if (string.lower(label) == armedHire.loadout) then
                armedOrdinal = index;
            end
        end
    end

    if (armedOrdinal == nil) then
        return true;
    end

    return armedOrdinal == ordinal;
end

local function armedSecondsLeft()
    if (armedHire == nil) then
        return 0;
    end

    return math.max(ARMED_WINDOW - (os.clock() - armedHire.at), 0);
end

--[[
* Envelope processing. Wholesale resets happen per verb -- a response replaces
* its own section outright, never merges with it -- with one deliberate
* exception: `call`, `dismiss` and `hire` replace the contracts pane only when
* they actually carried t| records, because a quote envelope carries none and
* must not blank a pane it did not re-describe.
--]]
local function processEnvelope(verb, records)
    local envelopeListings = {};
    local loadoutRows      = {};
    local gearRows         = {};
    local contractRows     = {};
    local boardMeta        = nil;
    local purse            = nil;
    local ledgerRows       = nil;
    local claimResult      = nil;
    local hireRecords      = {};
    local candidateRows    = nil;
    local setRows          = nil;
    local limitsRow        = nil;

    for _, parts in ipairs(records) do
        local kind = parts[1];

        if (kind == 'b') then
            local rec = parseListing(parts);

            mergeListing(rec);
            table.insert(envelopeListings, rec.listingid);
        elseif (kind == 'l') then
            mergeOverlay(parts);
        elseif (kind == 'o') then
            local listingid = tonumber(parts[2]) or 0;
            local ordinal   = tonumber(parts[3]) or 0;

            loadoutRows[listingid] = loadoutRows[listingid] or {};
            loadoutRows[listingid][ordinal] = parts[4];
        elseif (kind == 'i') then
            -- A kit spans records, so pairs APPEND per listing within the
            -- envelope (dwm_protocol.md on i|) -- the wholesale replace
            -- happens once below, per listing the envelope described.
            local listingid = tonumber(parts[2]) or 0;

            gearRows[listingid] = gearRows[listingid] or {};

            for pair in string.gmatch(parts[3] or '', '([^,]+)') do
                local slot, itemid = string.match(pair, '^(%d+):(%d+)$');

                if (slot ~= nil) then
                    table.insert(gearRows[listingid], { slot = tonumber(slot), itemid = tonumber(itemid) });
                end
            end
        elseif (kind == 'g') then
            boardMeta = {
                page  = tonumber(parts[2]) or 1,
                pages = tonumber(parts[3]) or 1,
                total = tonumber(parts[4]) or 0,
                job   = tonumber(parts[5]) or 0,
            };
        elseif (kind == 't') then
            table.insert(contractRows, parseContract(parts));
        elseif (kind == 'w') then
            local sub = parts[2];

            if (sub == 'h') then
                purse = {
                    balance  = tonumber(parts[3]) or 0,
                    lifetime = tonumber(parts[4]) or 0,
                    rows     = tonumber(parts[5]) or UNMEASURED,
                };
            elseif (sub == 'r') then
                ledgerRows = ledgerRows or {};

                table.insert(ledgerRows, {
                    rowid      = tonumber(parts[3]) or 0,
                    contractid = tonumber(parts[4]) or 0,
                    amount     = tonumber(parts[5]) or 0,
                    gross      = tonumber(parts[6]) or 0,
                    tax        = tonumber(parts[7]) or 0,
                    merc       = (parts[8] ~= '-' and parts[8] ~= '') and parts[8] or nil,
                    hirer      = (parts[9] ~= '-' and parts[9] ~= '') and parts[9] or nil,
                    claimed    = (tonumber(parts[10]) or 0) ~= 0,
                    age        = stamp(tonumber(parts[11]) or 0),
                });
            elseif (sub == 'c') then
                claimResult = {
                    claimed = tonumber(parts[3]) or 0,
                    rows    = tonumber(parts[4]) or 0,
                    held    = tonumber(parts[5]) or 0,
                    capped  = (tonumber(parts[6]) or 0) ~= 0,
                };
            end
        elseif (kind == 'h') then
            table.insert(hireRecords, parseHire(parts));
        elseif (kind == 'n') then
            candidateRows = candidateRows or {};

            table.insert(candidateRows, {
                charid    = tonumber(parts[2]) or 0,
                name      = parts[3] or '?',
                mjob      = tonumber(parts[4]) or 0,
                mlvl      = tonumber(parts[5]) or 0,
                sjob      = tonumber(parts[6]) or 0,
                slvl      = tonumber(parts[7]) or 0,
                flags     = tonumber(parts[8]) or 0,
                listingid = tonumber(parts[9]) or 0,
            });
        elseif (kind == 's') then
            setRows = setRows or {};

            table.insert(setRows, {
                kind    = parts[2] or 'own',
                name    = parts[3] or '?',
                rules   = tonumber(parts[4]) or UNMEASURED,
                summary = (parts[5] ~= nil and parts[5] ~= '-') and parts[5] or nil,
            });
        elseif (kind == 'c') then
            limitsRow = {
                minrate  = tonumber(parts[2]) or UNMEASURED,
                maxrate  = tonumber(parts[3]) or UNMEASURED,
                maxhours = tonumber(parts[4]) or UNMEASURED,
                loadouts = tonumber(parts[5]) or 3,
                tax      = tonumber(parts[6]) or UNMEASURED,
            };
        end
    end

    -- Loadout names replace per listing, and only for listings this envelope
    -- named -- the o| dedup means a t| for a listing already described sends
    -- no group, and clearing on its behalf would lose the names.
    for listingid, names in pairs(loadoutRows) do
        state.loadouts[listingid] = names;
    end

    -- The frozen kit, same arrangement: replaced per listing the envelope
    -- measured, kept for every listing it did not.
    for listingid, pieces in pairs(gearRows) do
        local entry = state.listings[listingid];

        if (entry ~= nil) then
            entry.gearlist = pieces;
        end
    end

    if (verb == 'board' and boardMeta ~= nil) then
        -- THE ANSWER MUST BE THE ONE ASKED FOR (the 2026-08-09 review's first
        -- backlog item). The g| record carries the job and page the server
        -- answered; the ask's qualifier is `job:page`. A slow answer to an
        -- OLDER ask -- the filter changed while it was in flight -- used to
        -- land here, replace the board, and leave the pane on "Fetching the
        -- board..." for good: the d| had already marked the current ask
        -- answered, so nothing ever re-asked. Now a board that is not the one
        -- asked for is dropped and the ask is put back to unanswered, so
        -- need() re-asks on its clock (bounded by ANSWER_TRIES as always).
        local asked   = requested['board'];
        local arrived = string.format('%d:%d', boardMeta.job or 0, boardMeta.page or 1);

        if (asked ~= nil and asked.qualifier ~= arrived) then
            asked.answered = false;
        else
            boardMeta.rows = envelopeListings;
            state.board    = boardMeta;
        end
    end

    -- Every b| on these envelopes is one of the account's own listings, and
    -- each of them describes the whole shelf -- so the list is replaced rather
    -- than merged.
    if (verb == 'merc' or verb == 'listings' or verb == 'unlist' or verb == 'options') then
        state.mine = envelopeListings;
    elseif (verb == 'list') then
        -- EXCEPT `list`, WHICH ANSWERS WITH THE ONE LISTING IT JUST FROZE.
        -- Replacing here would empty the My mercs tab down to whichever
        -- character was published last -- harmless while nothing but a typed
        -- line could reach this verb (a typed !merc re-asks everything), and a
        -- real bug the moment the Listing tab's button sends one.
        local seen = {};

        for _, listingid in ipairs(state.mine) do
            seen[listingid] = true;
        end

        for _, listingid in ipairs(envelopeListings) do
            if (not seen[listingid]) then
                table.insert(state.mine, listingid);
            end
        end
    end

    -- The listing form's own sections, each replaced outright by the verb that
    -- owns it. Guarded on the verb rather than on "did any arrive", because an
    -- account with no rule sets of its own and no characters left to list is a
    -- real answer and has to be able to empty these.
    if (verb == 'options') then
        state.candidates = candidateRows or {};
        state.sets       = setRows or {};

        if (limitsRow ~= nil) then
            state.limits = limitsRow;
        end
    end

    if (verb == 'merc' or verb == 'contracts') then
        state.contracts = { active = {}, recent = {} };
    elseif ((verb == 'call' or verb == 'dismiss' or verb == 'hire') and #contractRows > 0) then
        state.contracts = { active = {}, recent = {} };
    end

    if (#contractRows > 0 or verb == 'merc' or verb == 'contracts') then
        for _, entry in ipairs(contractRows) do
            if (entry.state == 'active') then
                table.insert(state.contracts.active, entry);
            else
                table.insert(state.contracts.recent, entry);
            end
        end
    end

    if (purse ~= nil) then
        state.purse = { balance = purse.balance, lifetime = purse.lifetime };
    end

    if (verb == 'earnings') then
        state.ledger = ledgerRows or {};
    end

    -- A write that has answered is a write that is no longer in flight. Both
    -- verbs answer with the state they produced, so the envelope IS the
    -- refresh and the form needs no re-ask of its own.
    if (verb == 'list' or verb == 'unlist') then
        writePending = nil;

        if (form ~= nil) then
            form.confirm = nil;
            form.error   = nil;
        end
    end

    if (claimResult ~= nil) then
        state.claim  = claimResult;
        claimPending = false;

        -- What a claim moved changes what listings and earnings show; the
        -- panes re-ask on their next frame.
        if (state.purse ~= nil) then
            state.purse.balance = claimResult.held;
        end

        requested['listings'] = nil;
        requested['earnings'] = nil;
    end

    -- The hire dialog's transitions. The h| record is matched by listing id,
    -- and everything the quoted stage displays comes from it -- never from
    -- this file's own arithmetic.
    for _, rec in ipairs(hireRecords) do
        if (rec.stage == 'quote') then
            -- Held whether or not a dialog is watching: a quote is a fact
            -- about an armed window, and the window outlives a closed dialog.
            rec.key = dialogKey(rec.listingid, rec.hours, rec.loadout);
            rec.at  = os.clock();

            heldQuote = rec;
        elseif (rec.stage == 'hired') then
            -- The listing just left the open market, and the board and info
            -- panes are showing the world from before the purchase -- the
            -- owner's first pass found Mars still listed until a manual
            -- Refresh. Their asks are forgotten so the next frame re-asks.
            requested['board'] = nil;
            requested['info']  = nil;

            -- The quote is spent with the purchase: held past this point, a
            -- re-opened dialog on the same listing/hours inside the quote's
            -- window jumped straight to a live Pay button for a contract the
            -- player already owns.
            heldQuote = nil;
        end

        if (dialog ~= nil and rec.listingid == dialog.listingid) then
            if (rec.stage == 'quote') then
                dialog.quote = rec;

                if (dialog.stage == 'quoting') then
                    dialog.stage   = 'quoted';
                    dialog.stageAt = os.clock();
                    dialog.error   = nil;
                end
            elseif (rec.stage == 'hired') then
                dialog.stage   = 'done';
                dialog.stageAt = os.clock();
                dialog.result  = rec;
                dialog.error   = nil;
            end
        end
    end

    -- A hire envelope that closed on a waiting dialog without delivering its
    -- record: the refusal sentence (if any) arrived as e| and was shown; the
    -- stage must not sit on a spinner forever.
    if (verb == 'hire' and dialog ~= nil) then
        if (dialog.stage == 'quoting' and dialog.quote == nil) then
            dialog.stage   = 'pick';
            dialog.stageAt = os.clock();
        elseif (dialog.stage == 'paying' and dialog.result == nil) then
            dialog.stage   = 'pick';
            dialog.stageAt = os.clock();
            dialog.error   = dialog.error or 'The purchase did not go through. Nothing further was charged.';
        end
    end

    answered(verb);
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwmerc.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- A d| envelope IS the answer, whatever version it announced, and
            -- re-asking a server that speaks a layout this addon cannot read
            -- cannot help. One shape across the suite (dwfame, 2026-08-15);
            -- gated in harness_dwsuite.py.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.inbound = parts[3];
        state.buffer  = {};

        return;
    end

    -- Status lines land whatever the envelope state -- they are the one thing
    -- a player must never lose -- and a refusal also has to reach the dialog
    -- before its next frame renders a spinner over a dead purchase.
    if (kind == 'm' or kind == 'e') then
        -- The one refusal that is not worth a red banner: a server from
        -- before the quote-only verb answering with its unknown-verb
        -- sentence. The dialog falls back to the guarded hire path and asks
        -- once more on the next click -- deployment order must not matter in
        -- either direction (the dwbags arrangement).
        if (kind == 'e' and not quoteUnsupported
                and string.find(line, 'no mercenary command called "quote"', 1, true) ~= nil) then
            quoteUnsupported = true;

            -- The refused line armed nothing, so the lockout it stamped on
            -- the way out is a lock on a window that never opened.
            armedHire = nil;

            if (dialog ~= nil and dialog.stage == 'quoting') then
                dialog.stage   = 'pick';
                dialog.stageAt = os.clock();
                dialog.error   = 'This server is older than this window -- click once more to ask the older way.';
            end

            return;
        end

        -- The Listing tab's own version of the same fallback, and it is not
        -- worth a red banner either: the tab prints the typed line and gets on
        -- with it. Reset on every login line, so deployment order cannot matter
        -- in either direction.
        if (kind == 'e' and not optionsUnsupported
                and string.find(line, 'no mercenary command called "options"', 1, true) ~= nil) then
            optionsUnsupported = true;

            return;
        end

        state.status    = line:sub(3);
        state.statusBad = (kind == 'e');

        if (kind == 'e') then
            print(chat.header('dwmerc'):append(chat.error(state.status)));

            claimPending = false;

            -- The refused line was a list or an unlist: nothing was frozen and
            -- nothing came off the board, the sentence above says which, and
            -- the form keeps every input so it can be fixed and sent again.
            if (writePending ~= nil) then
                writePending = nil;

                if (form ~= nil) then
                    form.error = state.status;
                end
            end

            if (dialog ~= nil) then
                if (dialog.stage == 'quoting') then
                    -- The hire line was refused, so no quote was armed --
                    -- clearing the lockout is what lets the player fix the
                    -- input and ask again without serving out a window that
                    -- never opened.
                    armedHire = nil;

                    dialog.stage   = 'pick';
                    dialog.stageAt = os.clock();
                    dialog.error   = state.status;
                elseif (dialog.stage == 'paying') then
                    dialog.stage   = 'pick';
                    dialog.stageAt = os.clock();
                    dialog.error   = state.status;
                end
            end
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local verb    = state.inbound;
        local records = state.buffer;

        state.inbound = nil;
        state.buffer  = {};

        processEnvelope(verb, records);

        return;
    end

    table.insert(state.buffer, parts);
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017: sName[15] at 0x08, Mes at 0x17. Any line
* whose sender is _DWMDATA is ours: consumed and blocked before parsing, so a
* malformed record cannot leak into the chat log as noise.
--]]
ashita.events.register('packet_in', 'dwmerc_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwmerc'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Rendering.
--]]

-- Per-widget scratch. PLAIN tables keyed by strings the code chooses -- T{}'s
-- sugar metatable answers unknown string keys with functions.
local buffers = {};

local function bufferOf(id, initial)
    if (buffers[id] == nil) then
        buffers[id] = T{ initial };
    end

    return buffers[id];
end

local function tooltipOnHover(text)
    if (text ~= nil and text ~= '' and imgui.IsItemHovered()) then
        imgui.SetTooltip(text);
    end
end

local function statusOf(entry)
    if (bit.band(entry.flags or 0, LISTING_MINE) ~= 0) then
        return 'yours';
    end

    if (bit.band(entry.flags or 0, LISTING_OFF) ~= 0) then
        return 'off the board';
    end

    if (bit.band(entry.flags or 0, LISTING_WORKING) ~= 0) then
        return 'working';
    end

    return 'open';
end

--[[
* The hire dialog, drawn in place of the info pane while it is open. See the
* state-machine comment above for the shape; the load-bearing properties are
* that `pick` sends only a quote (and not even that, when the lockout says the
* line could confirm instead), that Pay does not exist until the server's
* quote is on screen, and that Pay is `!dwm confirm` -- a line that can never
* quote, sitting in a different place from the button that did.
--]]
local function hireDialog()
    local entry = state.listings[dialog.listingid];

    imgui.TextColored(COLOR_BADGE, string.format('Hiring %s', dialog.name));

    if (entry ~= nil) then
        imgui.TextDisabled(string.format('%s -- %s gil an hour, contracts up to %dh.',
            jobsText(entry), gilText(entry.rate), entry.maxhours or 0));
    end

    imgui.Separator();

    if (dialog.error ~= nil) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_ERROR, dialog.error);
        imgui.PopTextWrapPos();
    end

    if (dialog.stage == 'pick' or dialog.stage == 'quoting') then
        local cap = entry ~= nil and math.max(entry.maxhours or 1, 1) or 24;

        imgui.Text('Hours');
        imgui.SameLine();
        imgui.PushItemWidth(90);
        imgui.InputInt('##dwm_hours', dialog.hours, 1, 1);
        imgui.PopItemWidth();

        -- Clamped every frame AND at send: InputInt takes any integer it is
        -- given, including negative ones (the dwbags quantity lesson).
        local hours = math.floor(tonumber(dialog.hours[1]) or 1);

        hours = math.max(math.min(hours, cap), 1);
        dialog.hours[1] = hours;

        local published = loadoutCount(dialog.listingid);

        if (published > 1) then
            if (dialog.ordinal > published) then
                dialog.ordinal = 1;
            end

            imgui.SameLine();
            imgui.Text('Fights by');
            imgui.SameLine();
            imgui.PushItemWidth(160);

            if (imgui.BeginCombo('##dwm_loadout', loadoutName(dialog.listingid, dialog.ordinal))) then
                for ordinal = 1, published do
                    if (imgui.Selectable(string.format('%s##dwm_lo_%d', loadoutName(dialog.listingid, ordinal), ordinal),
                            dialog.ordinal == ordinal)) then
                        dialog.ordinal = ordinal;
                    end
                end

                imgui.EndCombo();
            end

            imgui.PopItemWidth();
        elseif (published == 1) then
            imgui.SameLine();
            imgui.TextDisabled(string.format('Fights by %s.', loadoutName(dialog.listingid, 1)));
        end

        imgui.Spacing();
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled('The server quotes the price first. Nothing is charged until you press Pay on that quote.');
        imgui.PopTextWrapPos();
        imgui.Spacing();

        if (dialog.stage == 'quoting') then
            imgui.TextDisabled('Asking the server for the price...');

            -- A quote that never answers must not hold the dialog hostage;
            -- nothing was charged either way, and the ask is NOT re-sent.
            if (os.clock() - dialog.stageAt > 8.0) then
                dialog.stage   = 'pick';
                dialog.stageAt = os.clock();
                dialog.error   = 'No answer from the server. Nothing was charged -- ask again.';
            end
        elseif (heldQuote ~= nil and heldQuote.listingid == dialog.listingid
                and heldQuote.key == dialogKey(dialog.listingid, hours, dialog.ordinal)
                and (os.clock() - heldQuote.at) < (heldQuote.expires - QUOTE_MARGIN)) then
            -- This exact purchase was quoted moments ago and the quote is
            -- still good -- show it rather than asking the server again.
            dialog.quote   = heldQuote;
            dialog.stage   = 'quoted';
            dialog.stageAt = os.clock();
        elseif (quoteUnsupported and matchesArmed(dialog.listingid, dialog.name, hours, dialog.ordinal)) then
            -- The fallback path's sharp edge, guarded: on a server without
            -- the quote verb this asks through `hire`, and that line
            -- re-issued into its own armed window IS the purchase -- so with
            -- no fresh quote to show, the button waits the window out.
            imgui.TextDisabled(string.format('That exact quote was just asked for -- again in %ds.',
                math.ceil(armedSecondsLeft())));
            tooltipOnHover('Asking twice for the same quote inside its window would be read as the purchase,\nso the button waits it out. !merc confirm (typed) pays it on purpose.');
        else
            if (imgui.Button('Request quote##dwm_quote')) then
                dialog.quote   = nil;
                dialog.stage   = 'quoting';
                dialog.stageAt = os.clock();
                dialog.error   = nil;

                -- `quote` can never spend, whatever this client has
                -- forgotten -- a reload inside the window made the fallback
                -- line below buy on what looked like a first click, which is
                -- why the verb exists (dwm_protocol.md, No line buys
                -- anything). The guarded `hire` form stays only for servers
                -- from before it.
                issueWrite(string.format('!dwm %s %s %d %d',
                    quoteUnsupported and 'hire' or 'quote', dialog.name, hours, dialog.ordinal));
            end

            tooltipOnHover('Asks the server what this contract costs. Spends nothing.');
        end
    elseif (dialog.stage == 'quoted') then
        local quote = dialog.quote;

        -- Inputs changed under the quote: it no longer describes what the
        -- player is asking for, so back to pick -- the quote itself is kept
        -- for the lockout's reuse check.
        local hours = math.floor(tonumber(dialog.hours[1]) or 1);

        if (quote.key ~= dialogKey(dialog.listingid, hours, dialog.ordinal)) then
            dialog.stage   = 'pick';
            dialog.stageAt = os.clock();
        else
            local left = quote.expires - (os.clock() - quote.at);

            if (left <= QUOTE_MARGIN) then
                dialog.stage   = 'pick';
                dialog.stageAt = os.clock();
                dialog.error   = 'The quote expired -- ask again and the price will be fresh.';
            else
                -- Everything below comes off the h| record: the resolved
                -- name, the server's gross, the server's durations.
                imgui.PushTextWrapPos(0);
                imgui.Text(string.format('%s for %d %s, fighting by %s.',
                    quote.name, quote.hours, quote.hours == 1 and 'hour' or 'hours',
                    loadoutName(quote.listingid, quote.loadout)));
                imgui.TextColored(COLOR_WARN, string.format('%s gil, paid now, not refundable.', gilText(quote.gross)));
                imgui.Text(string.format('Runs %s from the moment you pay -- until about %s, your clock.',
                    spanText(quote.ends), os.date('%H:%M', os.time() + quote.ends)));
                imgui.TextDisabled(string.format('You are carrying %s gil.', gilText(quote.gil)));
                imgui.PopTextWrapPos();
                imgui.Spacing();

                if (quote.gil < quote.gross) then
                    imgui.TextColored(COLOR_ERROR, string.format('That is %s gil short, so this one is not affordable yet.',
                        gilText(quote.gross - quote.gil)));
                else
                    -- The deliberate second click. It cannot exist until the
                    -- server has answered the first, so no double-click can
                    -- reach it -- and the line it sends can only confirm.
                    if (imgui.Button(string.format('Pay %s gil -- hire %s##dwm_pay', gilText(quote.gross), quote.name))) then
                        dialog.stage   = 'paying';
                        dialog.stageAt = os.clock();
                        dialog.error   = nil;

                        issueWrite('!dwm confirm');
                    end

                    tooltipOnHover('The same thing as typing: !merc confirm');
                end

                imgui.TextDisabled(string.format('This quote is good for another %ds.', math.floor(left)));
            end
        end
    elseif (dialog.stage == 'paying') then
        imgui.Text('Paying...');

        -- Silence here is the one outcome that may NOT be retried: a confirm
        -- that was sent and lost could also be a confirm that landed. The
        -- contracts list is the ground truth and the server holds no second
        -- charge -- a second confirm meets an empty pending and refuses.
        if (os.clock() - dialog.stageAt > 10.0) then
            dialog.stage   = 'lost';
            dialog.stageAt = os.clock();
        end
    elseif (dialog.stage == 'lost') then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_WARN,
            'No answer from the server. If the hire landed it is on the Contracts tab; nothing is re-sent automatically.');
        imgui.PopTextWrapPos();

        if (imgui.Button('Check contracts##dwm_lostck')) then
            requested['contracts'] = nil;

            dialog = nil;

            return;
        end
    elseif (dialog.stage == 'done') then
        local result = dialog.result;

        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_OK, string.format('Hired %s for %d %s -- %s gil.',
            result.name, result.hours, result.hours == 1 and 'hour' or 'hours', gilText(result.gross)));
        imgui.Text(string.format('The contract runs %s from now. The Contracts tab calls them into your party.',
            spanText(result.ends)));
        imgui.TextDisabled('Zoning sends a summoned mercenary home; calling again brings them back while the contract runs.');
        imgui.PopTextWrapPos();
    end

    imgui.Spacing();

    if (dialog.stage ~= 'paying') then
        local label = (dialog.stage == 'done' or dialog.stage == 'lost') and 'Close' or 'Cancel -- keep your gil';

        if (imgui.Button(label .. '##dwm_cancel')) then
            dialog = nil;
        end
    end
end

--[[
* The info pane: one listing in full. `age` is the single most useful fact a
* hirer cannot see any other way (M1: staleness is a feature), so selecting a
* listing asks for the measured copy.
--]]
local function infoPane()
    local entry = state.selected ~= nil and state.listings[state.selected] or nil;

    if (entry == nil) then
        imgui.TextDisabled('Click a listing for the detail.');

        return;
    end

    need('info', entry.listingid, string.format('!dwm info %s', entry.name));

    imgui.TextColored(COLOR_BADGE, string.format('%s -- %s', entry.name, jobsText(entry)));
    imgui.Text(string.format('%s gil an hour, contracts up to %dh.', gilText(entry.rate), entry.maxhours or 0));

    local published = loadoutCount(entry.listingid);

    if (published > 0) then
        local names = {};

        for ordinal = 1, published do
            table.insert(names, loadoutName(entry.listingid, ordinal));
        end

        imgui.PushTextWrapPos(0);
        imgui.Text(string.format('Fights by: %s -- you pick one when you summon them.', table.concat(names, ', ')));
        imgui.PopTextWrapPos();
    end

    if (entry.gear ~= nil and entry.spells ~= nil) then
        local age = liveUp(entry.age);

        imgui.PushTextWrapPos(0);
        imgui.Text(string.format('Frozen %s: %d pieces of gear and %d spells.',
            age ~= nil and agoText(age) or 'at listing time', entry.gear, entry.spells));
        imgui.TextDisabled('The snapshot is what you get -- nothing the owner does afterwards changes it.');
        imgui.PopTextWrapPos();
    else
        imgui.TextDisabled('Measuring the snapshot...');
    end

    if (entry.hires ~= nil and entry.hires > 0) then
        imgui.Text(string.format('Hired %d %s so far.', entry.hires, entry.hires == 1 and 'time' or 'times'));
    end

    -- The kit itself, piece by piece -- what the gear count is counting. Names
    -- come from the client's own resources; the wire carries ids (i|).
    local kit = kitLines(entry);

    if (kit ~= nil and #kit > 0) then
        imgui.Spacing();
        imgui.TextDisabled('Wearing, exactly as frozen:');

        for _, lineText in ipairs(kit) do
            imgui.Text('  ' .. lineText);
        end
    end

    imgui.Spacing();

    if (bit.band(entry.flags or 0, LISTING_MINE) ~= 0) then
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled('This one is yours. Your own squad summons it free; hiring it would only pay the house.');
        imgui.PopTextWrapPos();
    elseif (bit.band(entry.flags or 0, LISTING_OFF) ~= 0) then
        imgui.TextDisabled('Off the board right now.');
    elseif (bit.band(entry.flags or 0, LISTING_WORKING) ~= 0) then
        local left = liveDown(entry.remaining);

        imgui.Text(string.format('Working a contract just now%s.',
            left ~= nil and string.format(' -- about %s left', spanText(left)) or ''));
    else
        if (imgui.Button(string.format('Hire %s...##dwm_hire_%d', entry.name, entry.listingid))) then
            openDialog(entry.listingid);
        end

        tooltipOnHover('Opens the hire dialog. Nothing is charged without a quoted price and a second click.');
    end
end

local function boardTab()
    local job  = tonumber(bufferOf('boardjob', 0)[1]) or 0;
    local page = tonumber(bufferOf('boardpage', 1)[1]) or 1;

    -- The ask carries the filter and the page; the g| record carries them
    -- back, so a response for an older ask is visibly not this one's.
    local command = '!dwm board';

    if (job > 0) then
        command = command .. ' ' .. string.lower(JOB_NAMES[job]);
    end

    if (page > 1) then
        command = command .. ' ' .. page;
    end

    need('board', string.format('%d:%d', job, page), command);

    imgui.Text('Job');
    imgui.SameLine();
    imgui.PushItemWidth(90);

    if (imgui.BeginCombo('##dwm_jobfilter', job > 0 and JOB_NAMES[job] or 'All')) then
        if (imgui.Selectable('All##dwm_jf_all', job == 0)) then
            bufferOf('boardjob', 0)[1]  = 0;
            bufferOf('boardpage', 1)[1] = 1;
            requested['board'] = nil;
        end

        for id = 1, 22 do
            if (imgui.Selectable(string.format('%s##dwm_jf_%d', JOB_NAMES[id], id), job == id)) then
                bufferOf('boardjob', 0)[1]  = id;
                bufferOf('boardpage', 1)[1] = 1;
                requested['board'] = nil;
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    local board = state.board;

    -- Filter by selection: records arrive for whatever was asked about, not
    -- for what is on screen now. A page of white mages must not land in a
    -- pane showing everything (client discipline 3).
    local current = board ~= nil and board.job == job or false;

    if (board ~= nil and current) then
        imgui.SameLine();

        if (board.pages > 1) then
            if (imgui.SmallButton('< Prev##dwm_bprev') and board.page > 1) then
                bufferOf('boardpage', 1)[1] = board.page - 1;
                requested['board'] = nil;
            end

            imgui.SameLine();
        end

        imgui.TextDisabled(string.format('page %d of %d -- %d for hire', board.page, board.pages, board.total));

        if (board.pages > 1) then
            imgui.SameLine();

            if (imgui.SmallButton('Next >##dwm_bnext') and board.page < board.pages) then
                bufferOf('boardpage', 1)[1] = board.page + 1;
                requested['board'] = nil;
            end
        end
    end

    imgui.BeginChild('##dwm_boardlist', { 430, 0 }, ImGuiChildFlags_Borders);

    if (board == nil or not current) then
        imgui.Text('Fetching the board...');
    elseif (#board.rows == 0) then
        imgui.Text(job > 0 and string.format('No %s is for hire right now.', JOB_NAMES[job])
            or 'The mercenary board is empty right now.');
        imgui.TextDisabled('The Listing tab puts a character of your own up for hire.');
    elseif (imgui.BeginTable('##dwm_board', 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Mercenary', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Gil / h', ImGuiTableColumnFlags_WidthFixed, 75, 0);
        imgui.TableSetupColumn('Up to', ImGuiTableColumnFlags_WidthFixed, 45, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 85, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, listingid in ipairs(board.rows) do
            local entry = state.listings[listingid];

            if (entry ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();

                if (imgui.Selectable(string.format('%s##dwm_row_%d', entry.name, listingid),
                        state.selected == listingid)) then
                    state.selected = listingid;
                end

                imgui.TableNextColumn();
                imgui.Text(jobsText(entry));

                imgui.TableNextColumn();
                imgui.Text(gilText(entry.rate));

                imgui.TableNextColumn();
                imgui.Text(string.format('%dh', entry.maxhours or 0));

                imgui.TableNextColumn();

                local mark = statusOf(entry);

                if (mark == 'yours') then
                    imgui.TextColored(COLOR_BADGE, '(yours)');
                elseif (mark == 'working') then
                    imgui.TextDisabled('working');
                elseif (mark == 'off the board') then
                    imgui.TextDisabled('off');
                end
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();

    imgui.SameLine();

    imgui.BeginChild('##dwm_boardinfo', { 0, 0 }, ImGuiChildFlags_Borders);

    if (dialog ~= nil) then
        hireDialog();
    else
        infoPane();
    end

    imgui.EndChild();
end

--[[
* The Contracts tab: what this account is paying for, live. Every duration on
* screen is the server's own count run down locally for display; the buttons
* emit only lines a player could type, and the server re-checks the contract,
* the fight gate and the party arithmetic on each one regardless.
--]]
local function contractsTab()
    need('contracts', 0, '!dwm contracts');

    local active = state.contracts.active;
    local recent = state.contracts.recent;

    if (#active == 0 and #recent == 0) then
        imgui.Text('You have no mercenaries under contract.');
        imgui.TextDisabled('The Board tab shows who is for hire.');

        return;
    end

    imgui.TextDisabled('Time is approximate; the server\'s clock decides. A mercenary already out fights on past the');
    imgui.TextDisabled('hour and refuses the next call -- dismissing early refunds nothing, you booked the hours.');

    if (#active > 0 and imgui.BeginTable('##dwm_contracts', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Mercenary', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Fighting by', ImGuiTableColumnFlags_WidthFixed, 170, 0);
        imgui.TableSetupColumn('Time left', ImGuiTableColumnFlags_WidthFixed, 100, 0);
        imgui.TableSetupColumn('Paid', ImGuiTableColumnFlags_WidthFixed, 85, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 150, 0);
        imgui.TableHeadersRow();

        for _, entry in ipairs(active) do
            local listing = state.listings[entry.listingid];

            -- The t| record deliberately carries no jobs -- the listing does.
            -- One info per unknown listing fills jobs AND the kit below, and
            -- a contract from before this session is unknown by definition.
            if ((listing == nil or listing.mjob == nil) and not infoAsked[entry.listingid]) then
                infoAsked[entry.listingid] = true;

                issueRead(string.format('!dwm info %s', entry.name));
            end

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(entry.name);

            local kit = kitLines(listing);

            if (kit ~= nil and #kit > 0) then
                tooltipOnHover('The frozen kit they arrive in:\n' .. table.concat(kit, '\n'));
            end

            imgui.TableNextColumn();

            if (listing ~= nil and listing.mjob ~= nil) then
                imgui.Text(jobsText(listing));
            else
                imgui.TextDisabled('...');
            end

            imgui.TableNextColumn();

            local out       = (entry.running or 0) > 0;
            local published = loadoutCount(entry.listingid);

            if (out and published > 1) then
                -- The switch: a re-call on another loadout (M7 picks at
                -- summon, a re-call is a re-paint). Refused mid-fight
                -- server-side, with the sentence saying so.
                imgui.PushItemWidth(160);

                if (imgui.BeginCombo(string.format('##dwm_sw_%d', entry.contractid),
                        loadoutName(entry.listingid, entry.running))) then
                    for ordinal = 1, published do
                        if (imgui.Selectable(string.format('%s##dwm_sw_%d_%d',
                                loadoutName(entry.listingid, ordinal), entry.contractid, ordinal),
                                ordinal == entry.running)) then
                            if (ordinal ~= entry.running) then
                                issueWrite(string.format('!dwm call %s %d', entry.name, ordinal));
                            end
                        end
                    end

                    imgui.EndCombo();
                end

                imgui.PopItemWidth();
                tooltipOnHover(string.format('Switch loadouts -- the same thing as: !merc call %s <loadout>', entry.name));
            elseif (out) then
                imgui.Text(loadoutName(entry.listingid, entry.running));
            else
                imgui.TextDisabled(string.format('%s (at home)', loadoutName(entry.listingid, entry.bought)));
            end

            imgui.TableNextColumn();

            local left = liveDown(entry.remaining);

            imgui.Text(string.format('~%s', spanText(left or 0)));

            -- A countdown that hit zero is a contract due to settle; one
            -- re-ask shows it where it now belongs, in the finished list --
            -- and the listing goes back on the open market, so the board's
            -- ask is forgotten with it. The one-shot flag lives OUTSIDE the
            -- row (like infoAsked): every `contracts` envelope rebuilds
            -- state.contracts wholesale, so a flag on the row was destroyed
            -- by the very re-read it triggered -- and a mercenary still
            -- fighting past expiry ("expiry gates the door, not the room")
            -- kept the pane in a contracts+board command loop at 1.2s a line
            -- until the settlement job ran.
            if (left ~= nil and left <= 0 and not expiryAsked[entry.contractid]) then
                expiryAsked[entry.contractid] = true;
                requested['contracts'] = nil;
                requested['board']     = nil;
            end

            imgui.TableNextColumn();
            imgui.Text(gilText(entry.gross));

            imgui.TableNextColumn();

            -- Neither button re-asks: a verb that writes answers with the
            -- state it produced, so the call/dismiss envelope IS the refresh
            -- (dwm_protocol.md's mutation-answers-with-state rule).
            if (out) then
                if (imgui.SmallButton(string.format('Dismiss##dwm_dis_%d', entry.contractid))) then
                    issueWrite(string.format('!dwm dismiss %s', entry.name));
                end

                tooltipOnHover(string.format('Send them home -- the clock keeps running.\nThe same thing as: !merc dismiss %s', entry.name));
            else
                if (imgui.SmallButton(string.format('Call##dwm_call_%d', entry.contractid))) then
                    issueWrite(string.format('!dwm call %s', entry.name));
                end

                tooltipOnHover(string.format('Summon them into your party, on the loadout you bought.\nThe same thing as: !merc call %s', entry.name));
            end
        end

        imgui.EndTable();
    end

    if (#recent > 0) then
        imgui.Separator();
        imgui.TextDisabled('Recently finished -- the hours you booked are up:');

        for _, entry in ipairs(recent) do
            imgui.Text(string.format('  %s -- %d %s, %s gil.',
                entry.name, entry.hours, entry.hours == 1 and 'hour' or 'hours', gilText(entry.gross)));
            imgui.SameLine();

            if (imgui.SmallButton(string.format('Hire again...##dwm_re_%d', entry.contractid))) then
                openDialog(entry.listingid);

                -- The dialog draws in the Board tab's info pane; the name may
                -- be all this tab knows about the listing, so the dialog
                -- fetches the rest itself via the info ask.
                dialog.name = entry.name;
            end

            tooltipOnHover('Opens the hire dialog on the Board tab. Nothing is charged without a quote and a second click.');
        end
    end

    if (dialog ~= nil) then
        imgui.Separator();
        hireDialog();
    end
end

--[[
* The My mercs tab: the lister's side. Everything here except Claim is a read;
* Claim moves ledger gil to the character standing here, which the server does
* in C++ inside the transaction that marks the rows -- the button just says
* the word.
--]]
local function myMercsTab()
    need('listings', 0, '!dwm listings');
    need('earnings', 0, '!dwm earnings');

    if (#state.mine == 0) then
        imgui.Text('You have nothing on the mercenary board.');
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled('The Listing tab puts one up: pick a character you are NOT playing -- the photograph is taken '
            .. 'from the saved record -- set what it asks an hour, and pick the rule sets it fights by.');
        imgui.PopTextWrapPos();
    elseif (imgui.BeginTable('##dwm_mine', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        imgui.TableSetupColumn('Mercenary', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, 110, 0);
        imgui.TableSetupColumn('Gil / h', ImGuiTableColumnFlags_WidthFixed, 70, 0);
        imgui.TableSetupColumn('Status', ImGuiTableColumnFlags_WidthFixed, 230, 0);
        imgui.TableSetupColumn('Snapshot', ImGuiTableColumnFlags_WidthFixed, 180, 0);
        imgui.TableSetupColumn('Earned', ImGuiTableColumnFlags_WidthFixed, 85, 0);
        imgui.TableHeadersRow();

        for _, listingid in ipairs(state.mine) do
            local entry = state.listings[listingid];

            if (entry ~= nil) then
                imgui.TableNextRow();
                imgui.TableNextColumn();

                if (imgui.Selectable(string.format('%s##dwm_my_%d', entry.name, listingid),
                        state.selected == listingid)) then
                    -- Selection asks for the measured copy -- the listings
                    -- read counts the snapshot without reading its timestamp,
                    -- so "frozen N hours ago" needs an info per listing
                    -- (Phase 5's deliberate split).
                    state.selected = listingid;
                end

                imgui.TableNextColumn();
                imgui.Text(jobsText(entry));

                imgui.TableNextColumn();
                imgui.Text(gilText(entry.rate));

                imgui.TableNextColumn();

                if (entry.pending) then
                    imgui.TextColored(COLOR_WARN, 'withdrawal waits for the contract to settle');
                elseif (bit.band(entry.flags or 0, LISTING_OFF) ~= 0) then
                    imgui.TextDisabled('off the board (snapshot kept)');
                elseif (bit.band(entry.flags or 0, LISTING_WORKING) ~= 0) then
                    local left = liveDown(entry.remaining);

                    imgui.TextColored(COLOR_HINT, string.format('hired by %s%s',
                        entry.hirer or 'somebody',
                        left ~= nil and string.format(' -- ~%s left', spanText(left)) or ''));
                else
                    imgui.Text(string.format('on the board, up to %dh', entry.maxhours or 0));
                end

                imgui.TableNextColumn();

                if (state.selected == listingid) then
                    need('info', listingid, string.format('!dwm info %s', entry.name));
                end

                if (entry.gear ~= nil and entry.spells ~= nil) then
                    local age = liveUp(entry.age);

                    imgui.Text(string.format('%d gear, %d spells%s', entry.gear, entry.spells,
                        age ~= nil and string.format(', frozen %s', agoText(age)) or ''));

                    local kit = kitLines(entry);

                    if (kit ~= nil and #kit > 0) then
                        tooltipOnHover('The frozen copy hirers get -- re-listing takes a fresh one:\n'
                            .. table.concat(kit, '\n'));
                    else
                        tooltipOnHover('The frozen copy hirers get. Re-listing the character takes a fresh one;\nnothing else changes it.');
                    end
                else
                    imgui.TextDisabled('click the name to measure');
                end

                imgui.TableNextColumn();

                if (entry.earned ~= nil) then
                    imgui.Text(gilText(entry.earned));
                    tooltipOnHover('Lifetime net -- after the house cut, which the Earnings rows show in full.');
                else
                    imgui.TextDisabled('--');
                end
            end
        end

        imgui.EndTable();
    end

    imgui.Separator();

    -- The purse and the claim. The three zero-claim outcomes are told apart
    -- from the w|c fields, because "nothing is waiting" said about gil that
    -- IS waiting tells a player their earnings are gone (dwm_protocol.md).
    local purse = state.purse;

    if (purse ~= nil) then
        imgui.Text(string.format('%s gil waiting on your ledger -- %s earned lifetime.',
            gilText(purse.balance), gilText(purse.lifetime)));
    else
        imgui.TextDisabled('Reading the ledger...');
    end

    imgui.SameLine();

    if (claimPending) then
        imgui.TextDisabled('claiming...');
    elseif (purse ~= nil and purse.balance > 0) then
        if (imgui.SmallButton('Claim##dwm_claim')) then
            claimPending = true;
            state.claim  = nil;

            issueWrite('!dwm claim');
        end

        tooltipOnHover('Collects the balance to the character you are playing.\nThe same thing as: !merc claim');
    end

    local claim = state.claim;

    if (claim ~= nil) then
        if (claim.claimed > 0) then
            imgui.TextColored(COLOR_OK, string.format('Collected %s gil%s.', gilText(claim.claimed),
                claim.held > 0 and string.format(' -- %s more waits on purse room', gilText(claim.held)) or ''));
        elseif (claim.held > 0 and claim.capped) then
            imgui.TextColored(COLOR_WARN, string.format('Your purse is too full to take it. %s gil waits, and none is lost.', gilText(claim.held)));
        elseif (claim.held > 0) then
            imgui.TextColored(COLOR_ERROR, 'The claim did not go through -- the gil is still safely on the ledger. Try again.');
        else
            imgui.TextDisabled('Nothing has been earned yet.');
        end
    end

    local ledger = state.ledger;

    if (ledger ~= nil and #ledger > 0) then
        imgui.Separator();
        imgui.TextDisabled('Earnings, contract by contract -- gross, the house cut, and yours:');

        if (imgui.BeginTable('##dwm_ledger', 6,
                bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                        ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
            imgui.TableSetupColumn('Mercenary', ImGuiTableColumnFlags_WidthFixed, 105, 0);
            imgui.TableSetupColumn('Hirer', ImGuiTableColumnFlags_WidthFixed, 105, 0);
            imgui.TableSetupColumn('Gross', ImGuiTableColumnFlags_WidthFixed, 85, 0);
            imgui.TableSetupColumn('House cut', ImGuiTableColumnFlags_WidthFixed, 85, 0);
            imgui.TableSetupColumn('Yours', ImGuiTableColumnFlags_WidthFixed, 85, 0);
            imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 130, 0);
            imgui.TableSetupScrollFreeze(0, 1);
            imgui.TableHeadersRow();

            for _, row in ipairs(ledger) do
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.Text(row.merc or '?');
                imgui.TableNextColumn();
                imgui.Text(row.hirer or '?');
                imgui.TableNextColumn();
                imgui.Text(gilText(row.gross));
                imgui.TableNextColumn();
                imgui.Text(gilText(row.tax));
                imgui.TableNextColumn();
                imgui.Text(gilText(row.amount));
                imgui.TableNextColumn();

                local when = liveUp(row.age);

                imgui.TextDisabled(string.format('%s%s', row.claimed and 'claimed, ' or '',
                    when ~= nil and agoText(when) or ''));
            end

            imgui.EndTable();
        end
    end
end

--[[
* The Listing tab: the seller's side, as a form.
*
* `!merc list <char> <rate> <maxhours> <set> [set] [set]` is the only verb in
* this command whose arguments come from nowhere else on the wire -- a character
* off the account's roster and up to three rule set names off its shelf -- which
* is why listing stayed typed through Phase 6 and why the server grew `options`
* before this tab could exist. EVERY NAME IN EVERY PICKER HERE CAME OFF THE
* WIRE. Nothing is hardcoded: not the roster, not the rule sets, not the caps,
* and not the house cut.
*
* THE TWO WRITES ARE `list` AND `unlist` AND NEITHER IS MONEY. Listing is free,
* withdrawing refunds nothing because nothing was paid, and the house takes its
* cut at settlement out of what a hirer paid -- so this tab has none of the hire
* dialog's two-act machinery. What it does have is a confirm on the two clicks
* that throw something away: re-freezing replaces the photograph hirers are
* being shown, and withdrawing takes a character off the market.
*
* WHAT IT WILL NOT DO IS PREDICT A REFUSAL. The store owns the caps, M10 owns
* "not the character you are playing", and a shipped set that flattens past 24
* rules for a wide job is a refusal no client can work out in advance. Where the
* c| record says what a bound is, the input respects it; where it says -1, the
* input has no ceiling and the server's own sentence is what says so. A guess
* would be the drift the caps were centralised to prevent.
--]]

-- The server's own example numbers, out of the sentence `!merc list` prints
-- when it is typed without a rate ("Try: !merc list Ayame 5000 4 defensive").
-- A starting value for an input box is not a cap and gates nothing.
local LIST_RATE_DEFAULT  = 5000;
local LIST_HOURS_DEFAULT = 4;

-- What the client will carry as one outgoing chat line. A list command with
-- three quoted set names is the longest thing this addon ever sends, and a line
-- the client truncated would be a listing published with a set name cut in
-- half -- so an over-long one is refused here, with the typed form printed.
local COMMAND_BUDGET = 120;

-- How long a confirm button stays armed. Long enough to read what it is about
-- to do, short enough that it is never still armed when somebody comes back.
local CONFIRM_HOLD = 8.0;

--[[
* Which listing, if any, belongs to a character.
*
* `listingid` is the protocol's join and is used whenever it resolves. It is 0
* for a character that had never been listed AT THE MOMENT `options` answered,
* so a character listed since is found by name instead -- exact, because the
* store freezes the roster's own charname and holds one listing per character.
* That fallback is what lets a brand new listing appear on this tab the instant
* the `list` envelope lands, rather than after another round trip.
--]]
local function candidateListing(cand)
    if (cand.listingid ~= 0 and state.listings[cand.listingid] ~= nil) then
        return state.listings[cand.listingid];
    end

    local wanted = string.lower(cand.name or '');

    for _, listingid in ipairs(state.mine) do
        local entry = state.listings[listingid];

        if (entry ~= nil and string.lower(entry.name or '') == wanted) then
            return entry;
        end
    end

    return nil;
end

-- A bound off the c| record, or the fallback when this server did not report
-- one. NEVER a hardcoded cap: the fallback for a ceiling is nil, meaning the
-- input does not clamp and the store refuses what it will not take.
local function limitOf(field, fallback)
    local limits = state.limits;

    if (limits == nil) then
        return fallback;
    end

    local value = limits[field];

    if (value == nil or value == UNMEASURED) then
        return fallback;
    end

    return value;
end

-- The set as the server spelled it, or nil. Matching is case-insensitive only
-- so that a loadout published earlier can be found again in the picker; what
-- goes back out is always the wire's own spelling.
local function knownSet(name)
    if (name == nil) then
        return nil;
    end

    local wanted = string.lower(name);

    for _, entry in ipairs(state.sets) do
        if (string.lower(entry.name or '') == wanted) then
            return entry;
        end
    end

    return nil;
end

local function buildForm(cand)
    local listing = candidateListing(cand);
    local picks   = {};

    -- Prefilled from what this character is already published with, so
    -- re-freezing is one click and changing a rate does not mean retyping the
    -- loadouts. A published name with no matching set left on the shelf -- it
    -- was deleted since it was published -- is deliberately NOT prefilled: the
    -- picker would be offering something `list` is going to refuse.
    if (listing ~= nil) then
        for ordinal = 1, 3 do
            local published = (state.loadouts[listing.listingid] or {})[ordinal];
            local match     = knownSet(published);

            picks[ordinal] = match ~= nil and match.name or nil;
        end
    end

    form = {
        charid  = cand.charid,
        name    = cand.name,
        rate    = T{ listing ~= nil and listing.rate or LIST_RATE_DEFAULT },
        hours   = T{ listing ~= nil and listing.maxhours or LIST_HOURS_DEFAULT },
        picks   = picks,
        confirm = nil,
        error   = nil,
    };
end

-- The line a button sends, built the way a player would type it.
--
-- The server reads a quoted run of tokens as one argument (its takeRef), which
-- is what makes a set called "Chain Crew" one name rather than two. A name
-- carrying a quote of its own cannot be quoted, so it goes bare and the
-- server's longest-run match resolves it -- the same way it would for somebody
-- typing the line.
local function listCommand(name, rate, hours, chosen)
    local parts = { string.format('!dwm list %s %d %d', name, rate, hours) };

    for _, setName in ipairs(chosen) do
        if (string.find(setName, ' ', 1, true) == nil or string.find(setName, '"', 1, true) ~= nil) then
            table.insert(parts, setName);
        else
            table.insert(parts, '"' .. setName .. '"');
        end
    end

    return table.concat(parts, ' ');
end

-- A button that has to be clicked twice, with the second click inside the hold.
-- Returns true on the confirming click and never on the arming one.
local function confirmButton(id, label, armedLabel, what, tip)
    local armed = form.confirm ~= nil and form.confirm.what == what
        and (os.clock() - form.confirm.at) < CONFIRM_HOLD;

    if (imgui.Button(string.format('%s##%s', armed and armedLabel or label, id))) then
        if (armed) then
            form.confirm = nil;

            return true;
        end

        form.confirm = { what = what, at = os.clock() };

        return false;
    end

    tooltipOnHover(tip);

    if (armed) then
        imgui.SameLine();
        imgui.TextDisabled('...click again to confirm');
    end

    return false;
end

-- One rule set picker. `ordinal` is only the slot in this form -- the server
-- assigns the published ordinals from the order the names arrive on the line.
local function loadoutPicker(ordinal)
    local current = form.picks[ordinal];

    imgui.PushItemWidth(230);

    if (imgui.BeginCombo(string.format('##dwm_set_%d', ordinal), current or '(none)')) then
        if (imgui.Selectable(string.format('(none)##dwm_set_%d_none', ordinal), current == nil)) then
            form.picks[ordinal] = nil;
        end

        -- A set already published in another slot is not offered again: two
        -- identical loadouts on one listing is a choice the hirer cannot tell
        -- apart, and it spends one of the three for nothing.
        local taken = {};

        for slot = 1, 3 do
            if (slot ~= ordinal and form.picks[slot] ~= nil) then
                taken[form.picks[slot]] = true;
            end
        end

        local heading = nil;

        for index, entry in ipairs(state.sets) do
            if (not taken[entry.name]) then
                -- The two kinds are not interchangeable and the wire says
                -- which is which, so the picker says so too: a stored set is
                -- published as it stands, a shipped one is flattened against
                -- this character's job first and can come out over the cap.
                if (entry.kind ~= heading) then
                    heading = entry.kind;

                    imgui.Separator();
                    imgui.TextDisabled(heading == 'preset' and 'Shipped sets' or 'Your rule sets');
                end

                if (imgui.Selectable(string.format('%s##dwm_set_%d_%d', entry.name, ordinal, index),
                        current == entry.name)) then
                    form.picks[ordinal] = entry.name;
                end

                if (entry.summary ~= nil) then
                    tooltipOnHover(entry.summary);
                elseif (entry.rules ~= UNMEASURED) then
                    tooltipOnHover(string.format('One of yours -- %d %s.', entry.rules,
                        entry.rules == 1 and 'rule' or 'rules'));
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    local entry = knownSet(current);

    if (entry ~= nil and entry.kind == 'preset') then
        imgui.SameLine();
        imgui.TextDisabled('shipped');
        tooltipOnHover(string.format('%s\n\nA shipped set is trimmed to what this character\'s job can use\nbefore it is published. If that comes out over the limit the\nserver says so and nothing is frozen.',
            entry.summary or 'A shipped rule set.'));
    end
end

local function listingForm(cand)
    local listing = candidateListing(cand);
    local playing = bit.band(cand.flags or 0, CAND_SELF) ~= 0;
    local slots   = math.max(math.min(limitOf('loadouts', 3), 3), 1);

    imgui.TextColored(COLOR_BADGE, string.format('%s -- %s', cand.name, jobsText(cand)));

    if (listing ~= nil) then
        local published = loadoutCount(listing.listingid);

        imgui.TextDisabled(string.format('Up at %s gil an hour, contracts up to %dh, %d %s published.',
            gilText(listing.rate), listing.maxhours or 0, published,
            published == 1 and 'loadout' or 'loadouts'));

        local age = liveUp(listing.age);

        if (age ~= nil) then
            imgui.TextDisabled(string.format('The photograph hirers are buying was taken %s.', agoText(age)));
        end
    else
        imgui.TextDisabled('Not on the board. Listing freezes it exactly as it stands right now.');
    end

    imgui.Separator();

    if (form.error ~= nil) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_ERROR, form.error);
        imgui.PopTextWrapPos();
        imgui.Spacing();
    end

    -- Rate. Clamped every frame AND at send, and only where the server said
    -- what the bounds are.
    local minRate = limitOf('minrate', 1);
    local maxRate = limitOf('maxrate', nil);

    imgui.Text('Gil an hour');
    imgui.SameLine();
    imgui.PushItemWidth(150);
    imgui.InputInt('##dwm_rate', form.rate, 100, 1000);
    imgui.PopItemWidth();

    local rate = math.floor(tonumber(form.rate[1]) or minRate);

    rate = math.max(rate, minRate);

    if (maxRate ~= nil) then
        rate = math.min(rate, maxRate);
    end

    form.rate[1] = rate;

    imgui.SameLine();
    imgui.TextDisabled(maxRate ~= nil and string.format('(%s to %s)', gilText(minRate), gilText(maxRate))
        or '(the server sets the ceiling)');

    -- The hour cap, which is the LONGEST single contract this owner will take
    -- rather than how long the listing stands.
    local maxHours = limitOf('maxhours', nil);

    imgui.Text('Longest contract');
    imgui.SameLine();
    imgui.PushItemWidth(150);
    imgui.InputInt('##dwm_maxhours', form.hours, 1, 1);
    imgui.PopItemWidth();

    local hours = math.floor(tonumber(form.hours[1]) or LIST_HOURS_DEFAULT);

    hours = math.max(hours, 1);

    if (maxHours ~= nil) then
        hours = math.min(hours, maxHours);
    end

    form.hours[1] = hours;

    imgui.SameLine();
    imgui.TextDisabled(string.format('hours%s', maxHours ~= nil and string.format(' (up to %d)', maxHours) or ''));
    tooltipOnHover('The most a single hire can book. A hirer pays for whole hours up front,\nand the contract runs from the moment they pay whether they summon or not.');

    imgui.Spacing();
    imgui.Text('Fights by');
    tooltipOnHover('Up to three published rule sets. The hirer picks one when they summon,\nand can edit none of them -- how the mercenary fights is your authorship.');

    for ordinal = 1, slots do
        loadoutPicker(ordinal);
    end

    local chosen = {};

    for ordinal = 1, slots do
        if (form.picks[ordinal] ~= nil) then
            table.insert(chosen, form.picks[ordinal]);
        end
    end

    -- What a contract at this rate would come to, and what the house would keep
    -- of it. AN ILLUSTRATION AND LABELLED AS ONE: the cut is the server's own
    -- number off the c| record and the settlement does the real arithmetic, at
    -- whatever the cut is on the day the contract ends. Nothing here gates
    -- anything, and no hirer is ever shown a price this file worked out.
    local tax = limitOf('tax', nil);

    if (tax ~= nil) then
        local gross = rate * hours;
        local yours = gross - math.floor(gross * tax / 100);

        imgui.Spacing();
        imgui.PushTextWrapPos(0);
        imgui.TextDisabled(string.format('A full %dh hire costs %s gil. The house keeps %d percent, so about %s would reach your ledger -- the settlement does the real sum.',
            hours, gilText(gross), tax, gilText(yours)));
        imgui.PopTextWrapPos();
    end

    imgui.Spacing();
    imgui.Separator();

    -- Held on the write rather than on the form, so switching characters
    -- mid-flight cannot orphan a spinner on a form that never sent anything.
    if (writePending ~= nil) then
        imgui.TextDisabled(string.format('%s %s...',
            writePending.what == 'unlist' and 'Taking' or 'Freezing',
            writePending.name));

        -- Silence must not hold the form hostage. Nothing was charged either
        -- way and nothing is re-sent: the server answers a write with the state
        -- it produced, so if it landed, the rows say so.
        if (os.clock() - writePending.at > 10.0) then
            writePending = nil;
            form.error   = 'No answer from the server. Nothing was re-sent -- Refresh shows where this character stands.';
        end

        return;
    end

    if (playing) then
        imgui.PushTextWrapPos(0);
        imgui.TextColored(COLOR_WARN, string.format('You are playing %s.', cand.name));
        imgui.TextDisabled('A listing is a photograph of the SAVED character, and a session you are sitting in has not written one yet. Log in as another character on the account and list this one from there.');
        imgui.PopTextWrapPos();
    elseif (#chosen == 0) then
        imgui.TextDisabled('Pick at least one rule set -- how the mercenary fights is what a hirer is paying for.');
    else
        local command = listCommand(cand.name, rate, hours, chosen);

        if (#command > COMMAND_BUDGET) then
            imgui.PushTextWrapPos(0);
            imgui.TextColored(COLOR_ERROR, 'Those set names come to more than one chat line can carry, so this one has to be typed:');
            imgui.TextDisabled((string.gsub(command, '^!dwm', '!merc')));
            imgui.PopTextWrapPos();
        elseif (listing ~= nil and bit.band(listing.flags or 0, LISTING_OFF) == 0) then
            -- Already up. Re-listing takes a FRESH photograph and throws the
            -- one hirers are looking at away, which is worth the second click.
            if (confirmButton('dwm_relist', string.format('Re-freeze %s', cand.name),
                    'Take a new photograph -- the old one goes', 'list',
                    string.format('Freezes %s again as it stands now, at these numbers.\nThe same thing as: %s',
                        cand.name, (string.gsub(command, '^!dwm', '!merc'))))) then
                writePending = { what = 'list', name = cand.name, at = os.clock() };

                issueWrite(command);
            end
        else
            if (imgui.Button(string.format('Put %s on the board##dwm_list', cand.name))) then
                writePending = { what = 'list', name = cand.name, at = os.clock() };

                issueWrite(command);
            end

            tooltipOnHover(string.format('Freezes %s as it stands and puts it up for hire.\nThe same thing as: %s',
                cand.name, (string.gsub(command, '^!dwm', '!merc'))));
        end
    end

    -- Withdrawal, which is a state change rather than a purchase and is
    -- deliberately not offered for a listing already coming off (M4 defers a
    -- withdrawal made during a contract; saying it twice would only be noise).
    if (listing ~= nil and bit.band(listing.flags or 0, LISTING_OFF) == 0 and not listing.pending
            and writePending == nil) then
        imgui.Spacing();

        if (confirmButton('dwm_unlist', 'Take it off the board', 'Take it off -- sure?', 'unlist',
                string.format('Stops new hires. A contract already running is honoured to the hour\nand the listing comes off when it settles.\nThe same thing as: !merc unlist %s', cand.name))) then
            writePending = { what = 'unlist', name = cand.name, at = os.clock() };

            issueWrite(string.format('!dwm unlist %s', cand.name));
        end

        imgui.PushTextWrapPos(0);
        imgui.TextDisabled('The snapshot survives a withdrawal, so putting it back up is one click -- with a fresh photograph.');
        imgui.PopTextWrapPos();
    end
end

local function listingTab()
    if (optionsUnsupported) then
        imgui.PushTextWrapPos(0);
        imgui.Text('This server is older than the Listing tab -- it has no !merc options to answer with.');
        imgui.TextDisabled('Listing still works typed, from a character you are NOT playing:');
        imgui.TextDisabled('  !merc list <char> <rate> <maxhours> <set> [set] [set]');
        imgui.TextDisabled('  !merc unlist <char>');
        imgui.PopTextWrapPos();

        return;
    end

    need('options', 0, '!dwm options');

    if (#state.candidates == 0) then
        imgui.Text('Reading your characters...');

        return;
    end

    imgui.PushTextWrapPos(0);
    imgui.TextDisabled('Put a character of your own up for hire. It keeps earning while you are logged out, '
        .. 'and what it earns waits on the ledger under My mercs.');
    imgui.PopTextWrapPos();

    -- 385 so the three columns below fit inside it: at 330 the table was wider
    -- than its own child, which clipped the right-hand status text mid-word.
    imgui.BeginChild('##dwm_candlist', { 385, 0 }, ImGuiChildFlags_Borders);

    if (imgui.BeginTable('##dwm_cands', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Character', ImGuiTableColumnFlags_WidthFixed, 105, 0);
        -- 128: the widest live pair is a two-digit main and a two-digit sub
        -- ('WHM71/RDM51'), which 95 clipped the sub level off.
        imgui.TableSetupColumn('Jobs', ImGuiTableColumnFlags_WidthFixed, 128, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 120, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, cand in ipairs(state.candidates) do
            local listing = candidateListing(cand);

            imgui.TableNextRow();
            imgui.TableNextColumn();

            if (imgui.Selectable(string.format('%s##dwm_cand_%d', cand.name, cand.charid),
                    form ~= nil and form.charid == cand.charid)) then
                buildForm(cand);
            end

            imgui.TableNextColumn();

            -- The LIVE jobs, unlike everywhere else in this window: this column
            -- is answering "what would a photograph taken now capture".
            imgui.Text(jobsText(cand));

            imgui.TableNextColumn();

            if (listing == nil) then
                if (bit.band(cand.flags or 0, CAND_SELF) ~= 0) then
                    imgui.TextDisabled('playing this');
                elseif (bit.band(cand.flags or 0, CAND_BUSY) ~= 0) then
                    imgui.TextDisabled('with your squad');
                else
                    imgui.TextDisabled('not listed');
                end
            elseif (listing.pending) then
                imgui.TextColored(COLOR_WARN, 'coming off');
            elseif (bit.band(listing.flags or 0, LISTING_OFF) ~= 0) then
                imgui.TextDisabled('off the board');
            elseif (bit.band(listing.flags or 0, LISTING_WORKING) ~= 0) then
                imgui.TextColored(COLOR_HINT, 'hired out');
            else
                imgui.TextColored(COLOR_OK, 'on the board');
            end
        end

        imgui.EndTable();
    end

    imgui.EndChild();

    imgui.SameLine();

    imgui.BeginChild('##dwm_candform', { 0, 0 }, ImGuiChildFlags_Borders);

    -- The form follows the pick, and a pick that has gone -- a character
    -- renamed or deleted between reads -- drops back to the prompt rather than
    -- to a form describing nobody.
    local picked = nil;

    if (form ~= nil) then
        for _, cand in ipairs(state.candidates) do
            if (cand.charid == form.charid) then
                picked = cand;
            end
        end
    end

    if (picked == nil) then
        imgui.TextDisabled('Click one of your characters to put it up, change what it asks, or take it off.');

        if (#state.sets == 0) then
            imgui.Spacing();
            imgui.PushTextWrapPos(0);
            imgui.TextColored(COLOR_WARN, 'No rule sets have reached this window yet.');
            imgui.TextDisabled('A mercenary is listed by the rules it fights by. !squad rules list shows yours and !squad rules presets the shipped ones.');
            imgui.PopTextWrapPos();
        end
    else
        listingForm(picked);
    end

    imgui.EndChild();
end

--[[
* Every typed verb, in one place. The window covers all of them now, but the
* commands are the tier that keeps working when an addon does not -- and a
* player who knows they exist is a player who can still list a mercenary from a
* client with no addons loaded at all.
--]]
local HELP_LINES =
{
    { '!merc board [job] [page]', 'who is for hire' },
    { '!merc info <name>', 'one mercenary in full' },
    { '!merc quote <name> <hours>', 'what a contract would cost -- spends nothing' },
    { '!merc hire <name> <hours>', 'the same quote; type it again to pay' },
    { '!merc confirm', 'pays the quote you were just shown' },
    { '!merc call <name> [loadout]', 'put a hired mercenary in your party' },
    { '!merc dismiss <name>', 'send one home -- the contract keeps running' },
    { '!merc contracts', 'what you have running' },
    { '!merc options', 'which of yours could be listed, and with what' },
    { '!merc list <char> <rate> <maxhours> <set>', 'put one of yours up for hire' },
    { '!merc unlist <char>', 'take it back off the board' },
    { '!merc listings', 'what you have up, and what each has earned' },
    { '!merc earnings', 'contract by contract, where that gil came from' },
    { '!merc claim', 'collect what you are owed, to the character here' },
    { '!merc menu', 'the same picks as a game menu, no addon needed' },
    { '!merc help', 'all of this, in chat' },
};

local function helpPopup()
    if (not imgui.BeginPopup('##dwm_help')) then
        return;
    end

    imgui.TextColored(COLOR_BADGE, 'Everything this window does, typed');
    imgui.PushTextWrapPos(400);
    imgui.TextDisabled('The commands are the real tier and this window is a renderer over them. '
        .. 'Nothing here can do anything they cannot.');
    imgui.PopTextWrapPos();
    imgui.Separator();

    if (imgui.BeginTable('##dwm_helptable', 2, ImGuiTableFlags_SizingFixedFit, { 0, 0 })) then
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 270, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 290, 0);

        for _, row in ipairs(HELP_LINES) do
            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(row[1]);
            imgui.TableNextColumn();
            imgui.TextDisabled(row[2]);
        end

        imgui.EndTable();
    end

    imgui.Separator();
    imgui.TextDisabled('/merc opens and closes this window. /merc refresh re-reads everything.');

    imgui.EndPopup();
end

local function renderWindow()
    if (imgui.Button('Refresh')) then
        forget();
    end

    imgui.SameLine();

    if (imgui.Button('Commands')) then
        imgui.OpenPopup('##dwm_help');
    end

    tooltipOnHover('Every !merc command, and what each one does.');

    helpPopup();

    imgui.SameLine();

    local pending = #readQueue + #writeQueue;

    if (pending > 0) then
        imgui.TextDisabled(string.format('%d queued...', pending));
    else
        imgui.TextDisabled('');
    end

    -- The message line gets its own row and errors are red: a refusal's
    -- reason is the only thing telling the player what to do instead.
    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(COLOR_ERROR, state.status);
        else
            imgui.TextColored(COLOR_OK, state.status);
        end
    end

    imgui.Separator();

    if (imgui.BeginTabBar('##dwm_tabs')) then
        if (imgui.BeginTabItem('Board')) then
            boardTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Contracts')) then
            contractsTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('My mercs')) then
            myMercsTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Listing')) then
            listingTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so a mistake costs one frame rather than the addon:
* an error thrown inside d3d_present is raised sixty times a second and the
* host answers a long enough run of them by unloading the addon. Begin/End
* stay outside the pcall to keep ImGui's stack balanced; the theme wraps
* Begin/End the same way; the error is reported once; the window closes
* itself. Everything it does is still reachable as !merc commands, so closing
* it is a fallback rather than a dead end.
--]]
ashita.events.register('d3d_present', 'dwmerc_present', function ()
    -- Before the visibility check: a confirm issued a moment before closing
    -- the window still has to reach the server.
    pumpQueue();

    if (not state.open[1]) then
        return;
    end

    local pushed = theme.push();

    imgui.SetNextWindowSize({ 900, 520 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Mercenaries##dwmerc', state.open, bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwmerc'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwmerc'):append(chat.message('Window closed. Everything it does also works typed as !merc commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Watch what the player sends, for two money-shaped reasons beyond the usual
* throttle bookkeeping. A typed `!merc` line can change everything this window
* shows, so the asks are forgotten and re-made. And a typed HIRE line arms the
* same server-side quote window this addon's own quote button does -- the
* proof is in MERC_PLAN.md's phase log, where a `!dwm` quote was confirmed by
* a typed line -- so it feeds the same lockout, whichever tier it came from.
* Every other outgoing line still counts against the chat throttle: the
* client's rate limit is on chat, not on this addon.
--]]
ashita.events.register('packet_out', 'dwmerc_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');
    local lower   = string.lower(message);

    if (lower:sub(1, 4) ~= '!dwm') then
        lastSend = os.clock();
    end

    if (lower:match('^!merc%s') ~= nil or lower:match('^!dwm%s') ~= nil) then
        local tokens = {};

        for token in string.gmatch(lower, '%S+') do
            table.insert(tokens, token);
        end

        local verb = tokens[2];

        if (verb == 'buy' or verb == 'rent') then
            verb = 'hire';
        elseif (verb == 'price' or verb == 'cost') then
            verb = 'quote';
        end

        -- `hire <name>` with no hours falls through to info server-side and
        -- arms nothing, which is why the hours token has to be numeric here.
        -- A quote line arms the same window a hire line does (that is what
        -- makes `confirm` able to pay it), so both feed the lockout -- and
        -- both REPLACE the server's one pending slot, so a quote this window
        -- is still showing no longer describes what confirm would buy. The
        -- held copy goes, and a dialog sitting on it drops back to ask again.
        if ((verb == 'hire' or verb == 'quote') and tokens[3] ~= nil and tonumber(tokens[4]) ~= nil) then
            armedHire = {
                name    = tokens[3],
                hours   = tonumber(tokens[4]),
                loadout = tokens[5] ~= nil and table.concat(tokens, ' ', 5) or nil,
                at      = os.clock(),
            };

            heldQuote = nil;

            if (dialog ~= nil and dialog.stage == 'quoted') then
                dialog.stage   = 'pick';
                dialog.stageAt = os.clock();
                dialog.quote   = nil;
                dialog.error   = 'A newer quote was asked for outside this dialog -- ask again to see the price.';
            end
        end
    end

    if (lower:sub(1, 5) == '!merc') then
        forget();
    end
end);

ashita.events.register('command', 'dwmerc_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Merc`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/merc' and first ~= '/dwmerc') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        forget();

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported`
        -- exists to stop one bad frame printing sixty lines a second, not to
        -- silence a different error a week later.
        state.reported = false;

        forget();
    end
end);

ashita.events.register('load', 'dwmerc_load', function ()
    print(chat.header('dwmerc'):append(chat.message('/merc opens the mercenary board. Everything it does also works typed as !merc.')));
end);

-- A login is a different account view; the world state resets. The armed-hire
-- lockout deliberately survives -- it is time-bounded and keyed to the last
-- hire line sent, and a server-side quote window does not care that the
-- client zoned.
ashita.events.register('packet_in', 'dwmerc_zonein', function (e)
    if (e.id == 0x000A) then
        state.listings  = {};
        state.loadouts  = {};
        state.board     = nil;
        state.mine      = {};
        state.contracts = { active = {}, recent = {} };
        state.purse      = nil;
        state.ledger     = nil;
        state.claim      = nil;
        state.selected   = nil;
        state.inbound    = nil;
        state.buffer     = {};
        state.status     = 'Fetching...';
        state.statusBad  = false;
        state.candidates = {};
        state.sets       = {};
        state.limits     = nil;

        dialog       = nil;
        heldQuote    = nil;
        claimPending = false;

        -- The listing form describes an account, and this is a different one
        -- until the reads say otherwise. A write in flight goes with it: its
        -- answer was addressed to a session that no longer exists, and the
        -- Listing tab's own rows are what say whether it landed.
        form         = nil;
        writePending = nil;

        -- Asked again on the other side: the server may have grown the quote
        -- verb, or the options verb, since the last look (a map restart logs
        -- everyone out).
        quoteUnsupported   = false;
        optionsUnsupported = false;

        forget();
    end
end);
