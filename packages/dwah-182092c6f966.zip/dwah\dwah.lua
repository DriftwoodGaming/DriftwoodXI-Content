--[[
* dwah -- the Driftwood market window (DWAH_PLAN.md)
*
* WHAT THIS IS. The player-only market, drawn: every active listing on the
* server -- the classic Auction House rows AND the blob lane -- in one
* searchable, sortable window, with real prices, one-click selling from the
* bag with no listing fee, player buy orders that escrow gil until a crafter
* fills them, and the account wallet every sale pays into. It is the same
* market the Jeuno counter shows, because it is the same tables: this window
* adds no rules, holds no secrets and owns no state the server does not.
*
* WHAT THIS IS NOT. A renderer, only. Every decision -- who owns a listing,
* what a fill pays, whether a price moved -- is re-made server-side in
* cpp/market_store.cpp, and the economics live one layer further down, in
* the auction_house_buy trigger. Anything this file sends is a CLAIM the
* server re-checks; anything it draws is a fact the server sent.
*
* THE WIRE (documentation/dwa_protocol.md): requests are typed chat lines
* (`!dwa page 0 3`) sent through dwecho at one per 1.2 s; answers are 0x017
* lines from sender _DWADATA, records between `d|1|<verb>` and `z|<verb>`.
* The model is a DRAWER sync (1.1.0; the full-market sweep died the day the
* kept legacy shelf put 5,000 rows behind it -- a 122-page walk and an fps
* sink): sweep the pages of ONE retail-AH drawer, sort and search locally
* within it, patch in place from this window's own mutations, and re-sweep
* only when the k| generation says another window moved the market.
*
* TURN IT OFF AND NOTHING IS LOST. `!market` does all of it typed.
--]]

addon.name    = 'dwah';
addon.author  = 'DriftwoodXI';
addon.version = '1.2.0';
addon.desc    = 'The Driftwood player market for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this file,
-- so a blocked line is already flagged by the time they see it.
echo.install();

local C = ffi.C;

-- The D3D device, fetched on first use rather than at load: this addon loads
-- from the launcher's boot script, long before the client has a rendering
-- device, and a file-scope get_device() makes the whole addon fail to load
-- (dwbags.lua:107-116).
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line.
local DATA_SENDER = '_DWADATA';

-- Protocol version the server announces in its `d|` record. Bumped only for
-- a breaking change to the record layout; additive fields never move it.
local PROTOCOL = 1;

-- `l|` flag bits, as the server packs them. Bit 4 marks a blob-lane row (a
-- signed or charge-carrying copy); rare/EX this addon reads off the client
-- DAT for itself.
local L_EXDATA = 4;

local INVENTORY_CONTAINER = 0;
local INVENTORY_SLOTS     = 80;

-- The gil cap, for previews only; the server clamps for real.
local MAX_PRICE = 999999999;

--[[
* The retail Auction House tree, exactly as the client's own counter menu
* has drilled it into players for two decades: nine drawers, most opening a
* sub-list. The numbers are item_basic.aH, VERIFIED AGAINST THE LIVE TABLE
* (2026-08-20) -- never the wiki's (the dwscan lesson); the server filters
* pages by the same column, and folds the drawerless (aH 0, which only the
* blob lane can carry) into Others > Misc. (46) so nothing is unreachable.
--]]
local CATEGORIES = {
    { label = 'Weapons', subs = {
        { label = 'Hand-to-Hand', cat = 1 },
        { label = 'Daggers',      cat = 2 },
        { label = 'Swords',       cat = 3 },
        { label = 'Great Swords', cat = 4 },
        { label = 'Axes',         cat = 5 },
        { label = 'Great Axes',   cat = 6 },
        { label = 'Scythes',      cat = 7 },
        { label = 'Polearms',     cat = 8 },
        { label = 'Katana',       cat = 9 },
        { label = 'Great Katana', cat = 10 },
        { label = 'Clubs',        cat = 11 },
        { label = 'Staves',       cat = 12 },
        { label = 'Ranged',       cat = 13 },
        { label = 'Instruments',  cat = 14 },
        { label = 'Ammunition',   cat = 15 },
        { label = 'Grips',        cat = 62 },
        { label = 'Fishing Gear', cat = 47 },
        { label = 'Pet Items',    cat = 48 },
    } },
    { label = 'Armor', subs = {
        { label = 'Shields',  cat = 16 },
        { label = 'Head',     cat = 17 },
        { label = 'Body',     cat = 18 },
        { label = 'Hands',    cat = 19 },
        { label = 'Legs',     cat = 20 },
        { label = 'Feet',     cat = 21 },
        { label = 'Neck',     cat = 22 },
        { label = 'Waist',    cat = 23 },
        { label = 'Earrings', cat = 24 },
        { label = 'Rings',    cat = 25 },
        { label = 'Back',     cat = 26 },
    } },
    { label = 'Scrolls', subs = {
        { label = 'White Magic', cat = 28 },
        { label = 'Black Magic', cat = 29 },
        { label = 'Songs',       cat = 32 },
        { label = 'Ninjutsu',    cat = 31 },
        { label = 'Summoning',   cat = 30 },
        { label = 'Geomancy',    cat = 45 },
    } },
    { label = 'Medicines',   cat = 33 },
    { label = 'Furnishings', cat = 34 },
    { label = 'Materials', subs = {
        { label = 'Smithing',     cat = 38 },
        { label = 'Goldsmithing', cat = 39 },
        { label = 'Clothcraft',   cat = 40 },
        { label = 'Leathercraft', cat = 41 },
        { label = 'Bonecraft',    cat = 42 },
        { label = 'Woodworking',  cat = 43 },
        { label = 'Alchemy',      cat = 44 },
    } },
    { label = 'Food', subs = {
        { label = 'Meat & Eggs',   cat = 52 },
        { label = 'Seafood',       cat = 53 },
        { label = 'Vegetables',    cat = 54 },
        { label = 'Soups',         cat = 55 },
        { label = 'Breads & Rice', cat = 56 },
        { label = 'Sweets',        cat = 57 },
        { label = 'Drinks',        cat = 58 },
        { label = 'Ingredients',   cat = 59 },
        { label = 'Fish',          cat = 51 },
    } },
    { label = 'Crystals', cat = 35 },
    { label = 'Others', subs = {
        { label = 'Misc.',        cat = 46 },
        { label = 'Beast-Made',   cat = 50 },
        { label = 'Cards',        cat = 36 },
        { label = 'Ninja Tools',  cat = 49 },
        { label = 'Cursed Items', cat = 37 },
        { label = 'Dice',         cat = 60 },
        { label = 'Automaton',    cat = 61 },
        { label = 'Fireworks',    cat = 63 },
        { label = 'Skirmish',     cat = 64 },
        { label = 'Spoils',       cat = 65 },
    } },
};

-- The Misc. drawer id, where the server files the drawerless (aH 0).
local MISC_CAT = 46;

--[[
* The server's numbers, replaced field-by-field by the `h|` handshake --
* these fallbacks exist so the fee preview is drawable before the first
* answer, each `tonumber or` so a short record degrades rather than zeroes
* (the dwreport limits pattern).
--]]
local limits = {
    fee      = 5,
    bounty   = 2000,
    cap      = 200,
    ordercap = 50,
};

local function netOf(price)
    return price - math.floor(price * limits.fee / 100);
end

-----------------------------------
-- State: everything the server said, plus what the window is doing about it.
-----------------------------------
local state = {
    open   = { false },
    synced = false,

    -- The account line (k|).
    mine    = 0,
    cap     = 200,
    wallet  = 0,
    orders  = 0,
    boxrows = 0,
    gen     = 0,

    -- The browse model: every listing of the CURRENT SCOPE -- one retail-AH
    -- drawer, or the account's own rows -- keyed by ref ('a1042'). The whole
    -- market never loads at once any more: 5,000 rows in one frame was the
    -- fps sink this window shipped with (2026-08-20).
    listings = {},
    pages    = 1,
    total    = 0,

    -- What the model is OF: nil (nothing picked yet), { mine = true } (the
    -- Activity tab's view), or { cat = N, label = 'Weapons > Swords' }.
    scope    = nil,

    -- The category combos (indices into CATEGORIES / its subs).
    catTop = nil,
    catSub = nil,

    -- Which fifty of the sorted rows the screen shows (pagedRows).
    viewPage   = 1,
    lastSearch = '',

    -- The order board, keyed by order id.
    orderRows = {},

    -- Sweep state (browse and orders walk their pages independently).
    syncing        = false,
    nextPage       = nil,
    repaired       = false,
    ordersSyncing  = false,
    ordersNextPage = nil,

    -- Which generation the model was built at. The reconcile runs at z|
    -- (see handleRecord): a closed envelope whose k| generation disagrees
    -- with the model's -- a refusal, a hello after the counter sold
    -- something, a sweep another window raced -- re-sweeps once per
    -- generation value, so the window heals itself instead of asking the
    -- player to press Refresh (the 2026-08-19 live finding).
    syncGen        = nil,
    envelopeFailed = false,
    resyncFor      = nil,

    -- The History tab's model (1.2.0): the item asked about, the y| rows
    -- that came back, when the ask left (the tab's loading line), and the
    -- session's recent lookups (ids, newest first, at most eight).
    -- Populated by the tab's own lookup box and by the History button every
    -- listing and order row carries; all of it is this window's bookkeeping
    -- over the same `history` verb the typed tier has always had.
    history = { itemid = nil, name = nil, rows = {}, pendingAt = nil, recent = {} },

    -- A click asked for the History tab: the next frame's BeginTabItem
    -- carries ImGuiTabItemFlags_SetSelected, once. tabSelectBroken latches
    -- if the client's sol binding refuses the three-argument overload --
    -- see beginHistoryTab for why that is a live possibility.
    historyFocus    = false,
    tabSelectBroken = false,

    -- Which envelope is arriving (the verb from d|), nil between envelopes.
    inbound = nil,

    -- One status line, and whether it is a refusal.
    status    = nil,
    statusBad = false,

    -- The protocol latch and the silence latch (dwa_protocol.md discipline).
    protocolBad  = false,
    serverSilent = false,

    -- UI: tab, search text, sort mode, pending confirmations.
    search     = { '' },
    sortMode   = 1, -- 1 level, 2 price, 3 name, 4 newest
    onlyMine   = { false },
    confirmBuy = nil, -- { ref, price, name }
    sellSlot   = nil, -- selected bag slot on the Sell tab
    sellPrice  = { '' },

    -- The order form.
    orderText  = { '' },
    orderId    = nil, -- resolved item id
    orderQty   = { 1 },
    orderPrice = { '' },
    orderStack = { false },
    confirmOrder = false,
    confirmFill  = nil, -- { id, name, price, count, slot }

    -- History search box.
    historyText = { '' },
};

-----------------------------------
-- Client DAT lookups (names, levels, icons, cards)
-----------------------------------

local function resourceOf(itemId)
    if (itemId == nil or itemId <= 0) then
        return nil;
    end

    return AshitaCore:GetResourceManager():GetItemById(itemId);
end

local function itemName(itemId)
    local item = resourceOf(itemId);

    if (item == nil) then
        return string.format('item %d', itemId or 0);
    end

    return item.Name[1];
end

-- The level-sort key (D8): item level where the DAT has one, equip level
-- otherwise; materials and consumables read 0 and sort together.
local function levelOf(itemId)
    local item = resourceOf(itemId);

    if (item == nil) then
        return 0;
    end

    local ilvl = item.ItemLevel or 0;

    if (ilvl > 0) then
        return ilvl;
    end

    return item.Level or 0;
end

--[[
* Item icons, cached per id -- dwbags' iconOf/drawIcon, kept verbatim (the
* dwraid copy of the same recipe). `false` memoises a failure so a bad id is
* asked of D3D once, not sixty times a second.
--]]
local icons = {};

local function iconOf(itemId)
    local cached = icons[itemId];

    if (cached ~= nil) then
        return cached ~= false and cached or nil;
    end

    local item = resourceOf(itemId);

    if (item == nil or item.Bitmap == nil) then
        icons[itemId] = false;

        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    local result = C.D3DXCreateTextureFromFileInMemoryEx(
        dev, item.Bitmap, item.ImageSize, 0xFFFFFFFF, 0xFFFFFFFF, 1, 0,
        C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED, C.D3DX_DEFAULT, C.D3DX_DEFAULT,
        0xFF000000, nil, nil, ptr);

    if (result ~= 0) then
        icons[itemId] = false;

        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

-- Draws the icon (or a spacer) and leaves the cursor on the same line.
local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

local JOB_NAMES = {
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK', 'BST', 'BRD',
    'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU', 'COR', 'PUP', 'DNC', 'SCH',
    'GEO', 'RUN',
};

local FLAG_RARE = 0x8000;
local FLAG_EX   = 0x4000;

local function jobsText(mask)
    if (mask == nil or mask == 0) then
        return nil;
    end

    local names = {};

    for index, name in ipairs(JOB_NAMES) do
        if (bit.band(mask, bit.lshift(1, index)) ~= 0) then
            names[#names + 1] = name;
        end
    end

    if (#names == 0 or #names == #JOB_NAMES) then
        return nil;
    end

    return table.concat(names, ' ');
end

-- The hover card: icon, tags decoded from the client DAT, description under
-- a fixed wrap width (dwraid.lua:238-306 -- the card must render the same
-- whatever window it floats over).
local function itemCard(itemId)
    local item = resourceOf(itemId);

    imgui.BeginTooltip();

    drawIcon(itemId, 32);
    imgui.Text(itemName(itemId));

    if (item ~= nil) then
        local tags = {};

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags[#tags + 1] = string.format('iLvl %d', item.ItemLevel);
        elseif (item.Level ~= nil and item.Level > 0) then
            tags[#tags + 1] = string.format('Lv %d', item.Level);
        end

        if (bit.band(item.Flags or 0, FLAG_RARE) ~= 0) then
            tags[#tags + 1] = 'Rare';
        end

        if (bit.band(item.Flags or 0, FLAG_EX) ~= 0) then
            tags[#tags + 1] = 'Ex';
        end

        if (#tags > 0) then
            imgui.TextDisabled(table.concat(tags, '  '));
        end

        local jobs = jobsText(item.Jobs);

        if (jobs ~= nil) then
            imgui.TextDisabled(jobs);
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            imgui.PushTextWrapPos(320.0);
            imgui.Text(desc);
            imgui.PopTextWrapPos();
        end
    end

    imgui.EndTooltip();
end

-- drawIcon leaves the cursor on the same line, and IsItemHovered reads the
-- LAST item, so the icon's hover is taken before the label is drawn
-- (dwraid.lua:1097-1108).
local function cardOnHover(itemId, hoveredIcon)
    if (imgui.IsItemHovered() or hoveredIcon == true) then
        itemCard(itemId);
    end
end

-----------------------------------
-- The send queue (the dwbags/dwwarehouse machinery, kept whole)
-----------------------------------

local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

-- A query is machinery traffic -- a sweep's page walk, a re-asked hello.
-- Everything else left the player's own finger: a Buy confirm, a Post
-- order, a Claim. The two classes get opposite treatment twice below.
local function isQuery(command)
    return command == '!dwa hello'
        or command:match('^!dwa page ') ~= nil
        or command:match('^!dwa orders ') ~= nil
        or command:match('^!dwa history ') ~= nil;
end

-- ONLY QUERIES COLLAPSE (dwwarehouse.lua:487-506): asking twice for a page
-- is never useful, but two identical Buy clicks are two commands the player
-- asked for, and collapsing a write silently loses one.
local function issue(command)
    if (isQuery(command)) then
        for _, queued in ipairs(queue) do
            if (queued == command) then
                return;
            end
        end
    end

    queue:append(command);
end

-- Drains one queued command per interval. Called every frame from
-- d3d_present, including while the window is shut: a sweep started just
-- before closing still has to finish.
local function pumpQueue()
    -- The client refuses outgoing chat while zoning and answers with
    -- "A command error occurred." before the server ever sees the line, so
    -- the queue holds shut -- held, not dropped -- until the load screen is
    -- gone (dwecho.canSend, 2026-08-15).
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    -- The protocol latch parks EVERYTHING: a version mismatch has no safe
    -- line to send.
    if (state.protocolBad) then
        queue = T{ };

        return;
    end

    -- The silence latch parks only the MACHINERY: on a server without
    -- dwa.lua an unknown ! command falls through to public /say, and a
    -- sweep's auto-sends would be the player chatting at bystanders. But a
    -- MUTATION is one line the player asked for by clicking through a
    -- confirm -- exactly the deliberate act pressing Refresh is -- and
    -- dropping it here, silently, was the 2026-08-20 order-post bug: the
    -- latch ate the Post order and nothing said so.
    if (state.serverSilent) then
        local kept = T{ };

        for _, queued in ipairs(queue) do
            if (not isQuery(queued)) then
                kept:append(queued);
            end
        end

        queue = kept;

        if (#queue == 0) then
            return;
        end
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

-----------------------------------
-- The answer clock (dwwarehouse.lua:539-623, kept whole)
-----------------------------------

-- A PLAIN TABLE, NOT T{ } -- keyed by verb, and T{}'s metatable resolves
-- unknown keys to the sugar methods (the dwbags lesson).
local requested = {};

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

-- One exact sentence, so the d| revival below can tell its own stale status
-- line from anything else worth keeping.
local SILENCE_STATUS = 'The server is not answering -- press Refresh to try again.';

local function forget()
    requested = {};
end

local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

-- Ask for one thing, at most once -- twice if the first was never answered;
-- then say so and stand down (a silent give-up disarmed dwwarehouse's
-- self-repair for a whole session once).
local function need(verb, key, command, onDead)
    local asked = requested[verb];

    if (asked ~= nil and asked.key == key) then
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered) then
            return;
        end

        -- THE CLOCK STARTS WHEN THE LINE LEAVES, not when the need was
        -- registered: the queue drains one line per 1.2 s, and an ask born
        -- behind a backlog -- collect clicks, the orders sweep, another
        -- window's traffic moving the shared throttle -- used to age past
        -- five seconds before its first send. The silence latch then read
        -- the queue's own depth as a dead server (the 2026-08-20 live
        -- report, 42 of 5,090 loaded and 'not answering').
        for _, queued in ipairs(queue) do
            if (queued == command) then
                asked.at = os.clock();

                return;
            end
        end

        -- The window is checked BEFORE the try count: in the other order the
        -- sweep is declared dead on the frame after the second send.
        if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        if (asked.tries >= ANSWER_TRIES) then
            if (onDead ~= nil) then
                onDead();
            end

            state.serverSilent = true;
            state.status       = SILENCE_STATUS;
            state.statusBad    = true;

            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested[verb] = { key = key, at = os.clock(), answered = false, tries = 1 };
    end

    issue(command);
end

-----------------------------------
-- Sweeps: the browse pages and the order board
-----------------------------------

-- The scope's wire spelling: the drawer number, or -1 for mine -- the same
-- value the server's q| tail echoes back, which is how a page answer racing
-- a drawer switch is told from the sweep actually running.
local function scopeCat()
    if (state.scope == nil) then
        return nil;
    end

    if (state.scope.mine) then
        return -1;
    end

    return state.scope.cat;
end

-- Whether a model row belongs to the current scope. Rows can only be off
-- scope through a mutation's patch-in-place (a sell files into whatever
-- drawer the item lives in) or a raced answer; both stay held but unseen,
-- and the next sweep clears them.
local function scopeMatches(row)
    if (state.scope == nil) then
        return false;
    end

    if (state.scope.mine) then
        return row.mine;
    end

    return row.cat == state.scope.cat
        or (state.scope.cat == MISC_CAT and row.cat == 0);
end

-- Cleared rather than merged into (the dwwarehouse sweep rule): a row this
-- window holds that the server no longer has would survive any number of
-- merges, and a ghost row is a Buy button that fails. No scope, no sweep:
-- until a drawer is picked there is nothing to ask for, which is the whole
-- fix -- the full-market walk was 122 pages and 2.5 minutes.
local function startSync()
    state.listings = {};
    state.syncGen  = nil;

    if (state.scope == nil) then
        state.syncing  = false;
        state.nextPage = nil;
    else
        state.syncing  = true;
        state.nextPage = 0;
    end

    requested['page'] = nil;
end

local function startOrdersSync()
    state.orderRows      = {};
    state.ordersSyncing  = true;
    state.ordersNextPage = 0;

    requested['orders'] = nil;
end

local function refreshAll()
    state.serverSilent = false;
    state.repaired     = false;

    issue('!dwa hello');
    startSync();
    startOrdersSync();
end

-- Counts only the rows OF THE SCOPE: the server's q| total is the scope's
-- total, and an off-scope row a mutation patched in must not read as a
-- miscount (verifySweep re-sweeps on exactly that disagreement).
local function listingCount()
    local count = 0;

    for _, row in pairs(state.listings) do
        if (scopeMatches(row)) then
            count = count + 1;
        end
    end

    return count;
end

-- The count repair (the dwwarehouse verify shape): a completed sweep whose
-- model disagrees with the server's own total re-sweeps ONCE, never a loop.
local function verifySweep()
    if (listingCount() == state.total) then
        state.repaired = false;

        return;
    end

    if (state.repaired) then
        state.status    = string.format('Showing %d of %d listings -- press Refresh.', listingCount(), state.total);
        state.statusBad = true;

        return;
    end

    state.repaired = true;

    startSync();
end

-- Points the model at a scope, re-sweeping only on an actual change: the
-- tabs call this every frame they are visible (Browse with its picked
-- drawer, Activity with mine), and a no-op must cost nothing.
local function ensureScope(scope)
    local oldKey = state.scope ~= nil and (state.scope.mine and 'mine' or tostring(state.scope.cat)) or '';
    local newKey = scope ~= nil and (scope.mine and 'mine' or tostring(scope.cat)) or '';

    if (oldKey == newKey) then
        return;
    end

    state.scope    = scope;
    state.viewPage = 1;
    state.repaired = false;

    startSync();
end

-----------------------------------
-- Record parsing
-----------------------------------

local function split(text, sep)
    local out = {};

    for piece in string.gmatch(text .. sep, '(.-)' .. sep) do
        out[#out + 1] = piece;
    end

    return out;
end

-- `<ref>:<itemid>:<stk>:<price>:<flags>:<mine>:<seller>:<cat>,...` -- cat
-- is the retail-AH drawer, appended 1.1.0; a seven-field entry from an
-- older server reads cat 0, which files under Misc. (the server's own fold).
local function parseListings(packed)
    for _, entry in ipairs(split(packed, ',')) do
        local bits = split(entry, ':');

        if (#bits >= 7) then
            local ref = bits[1];
            local src = ref:sub(1, 1);
            local id  = tonumber(ref:sub(2)) or 0;

            if ((src == 'a' or src == 'm') and id > 0) then
                -- Upsert by ref: a row from a delta replaces the row a page
                -- walk put there, and the two can never disagree.
                state.listings[ref] = {
                    ref    = ref,
                    src    = src,
                    id     = id,
                    itemid = tonumber(bits[2]) or 0,
                    stack  = tonumber(bits[3]) or 0,
                    price  = tonumber(bits[4]) or 0,
                    flags  = tonumber(bits[5]) or 0,
                    mine   = (tonumber(bits[6]) or 0) == 1,
                    seller = bits[7] or '?',
                    cat    = tonumber(bits[8]) or 0,
                };
            end
        end
    end
end

-- `<id>:<itemid>:<stk>:<qty>:<price>:<mine>:<owner>,...`
local function parseOrders(packed)
    for _, entry in ipairs(split(packed, ',')) do
        local bits = split(entry, ':');

        if (#bits >= 7) then
            local id = tonumber(bits[1]) or 0;

            if (id > 0) then
                -- A patch row may not re-carry the item (a fill response
                -- names only what changed, itemid 0): keep what the sweep
                -- knew rather than forgetting it under the upsert.
                local itemid   = tonumber(bits[2]) or 0;
                local existing = state.orderRows[id];

                if (itemid == 0 and existing ~= nil) then
                    itemid = existing.itemid;
                end

                state.orderRows[id] = {
                    id     = id,
                    itemid = itemid,
                    stack  = tonumber(bits[3]) or 0,
                    qty    = tonumber(bits[4]) or 0,
                    price  = tonumber(bits[5]) or 0,
                    mine   = (tonumber(bits[6]) or 0) == 1,
                    owner  = bits[7] or '?',
                };
            end
        end
    end
end

-- `r|<ref>,...` -- listings by lane letter, orders by 'o'. An unknown prefix
-- is ignored: an older addon against a newer server must shrug, not throw.
local function parseRemoved(packed)
    for _, ref in ipairs(split(packed, ',')) do
        local prefix = ref:sub(1, 1);

        if (prefix == 'a' or prefix == 'm') then
            state.listings[ref] = nil;
        elseif (prefix == 'o') then
            local id = tonumber(ref:sub(2)) or 0;

            if (id > 0) then
                state.orderRows[id] = nil;
            end
        end
    end
end

-- `y|<price>:<date>:<stk>:<seller>:<buyer>` -- one per record.
local function parseHistory(line)
    local bits = split(line:sub(3), ':');

    if (#bits >= 5) then
        state.history.rows[#state.history.rows + 1] = {
            price  = tonumber(bits[1]) or 0,
            date   = tonumber(bits[2]) or 0,
            stack  = tonumber(bits[3]) or 0,
            seller = bits[4] or '?',
            buyer  = bits[5] or '?',
        };
    end
end

local MUTATION_VERBS = {
    sell        = true,
    buy         = true,
    cancel      = true,
    order       = true,
    fill        = true,
    cancelorder = true,
    claim       = true,
    collect     = true,
};

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status      = string.format('Server protocol %d, addon expects %d. Update dwah.', version, PROTOCOL);
            state.statusBad   = true;
            state.protocolBad = true;
            state.inbound     = nil;

            return;
        end

        state.inbound        = parts[3];
        state.serverSilent   = false;
        state.envelopeFailed = false;

        -- The server just spoke: any ask the silence latch declared dead
        -- gets a fresh clock and re-asks by itself, so the sweep a backlog
        -- killed resumes the moment ANY answer proves the road open --
        -- typically the mutation the player pushed through the latch
        -- (2026-08-20). The stale silence sentence goes with it.
        for _, asked in pairs(requested) do
            if (type(asked) == 'table' and not asked.answered and asked.tries >= ANSWER_TRIES) then
                asked.tries = 0;
                asked.at    = os.clock() - ANSWER_TIMEOUT;
            end
        end

        if (state.status == SILENCE_STATUS) then
            state.status    = nil;
            state.statusBad = false;
        end

        -- A history answer is a full refresh of the panel, emptied here
        -- rather than on the first y| -- and BEFORE anything below can
        -- throw, since handleRecord runs under pcall (the dwbags rule).
        if (state.inbound == 'history') then
            state.history.rows = {};
        end

        answered(state.inbound);

        return;
    end

    -- Status and refusals are accepted whatever the envelope state: the
    -- sentence saying why a buy was refused is worth more than the response
    -- it arrived with.
    if (kind == 'm' or kind == 'e') then
        local text = line:sub(3);

        state.status    = text;
        state.statusBad = (kind == 'e');

        -- A refusal inside an envelope marks it failed: the z| reconcile
        -- must not stamp the model current off a mutation that did nothing.
        if (kind == 'e' and state.inbound ~= nil) then
            state.envelopeFailed = true;
        end

        if (kind == 'e') then
            print(chat.header('dwah'):append(chat.error(text)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'h') then
        limits.fee      = tonumber(parts[3]) or limits.fee;
        limits.bounty   = tonumber(parts[4]) or limits.bounty;
        limits.cap      = tonumber(parts[5]) or limits.cap;
        limits.ordercap = tonumber(parts[6]) or limits.ordercap;

        return;
    end

    if (kind == 'k') then
        state.mine    = tonumber(parts[2]) or 0;
        state.cap     = tonumber(parts[3]) or state.cap;
        state.wallet  = tonumber(parts[4]) or 0;
        state.orders  = tonumber(parts[5]) or 0;
        state.boxrows = tonumber(parts[6]) or 0;

        state.gen = tonumber(parts[7]) or 0;

        -- The first generation a sweep sees is the one that sweep is OF.
        -- Everything else about generations is decided at z|, where success
        -- and failure can be told apart.
        if (state.syncing and state.syncGen == nil) then
            state.syncGen = state.gen;
        end

        return;
    end

    if (kind == 'l') then
        parseListings(line:sub(3));

        return;
    end

    if (kind == 'o') then
        parseOrders(line:sub(3));

        return;
    end

    if (kind == 'r') then
        parseRemoved(line:sub(3));

        return;
    end

    if (kind == 'y') then
        parseHistory(line);

        return;
    end

    if (kind == 'q') then
        local page  = tonumber(parts[2]) or 0;
        local pages = tonumber(parts[3]) or 1;
        local total = tonumber(parts[4]) or 0;
        local qcat  = tonumber(parts[5]);

        if (state.inbound == 'page') then
            -- A page of a drawer this window is no longer sweeping -- the
            -- player switched drawers while an answer was in flight -- must
            -- not steer THIS sweep's walk or totals. An old server sends no
            -- tail and is believed as-is.
            if (qcat ~= nil and qcat ~= scopeCat()) then
                return;
            end

            state.pages = pages;
            state.total = total;

            if (state.syncing) then
                if (page + 1 < pages) then
                    state.nextPage = page + 1;
                else
                    state.nextPage = nil;
                end
            end
        elseif (state.inbound == 'orders') then
            if (state.ordersSyncing) then
                if (page + 1 < pages) then
                    state.ordersNextPage = page + 1;
                else
                    state.ordersNextPage = nil;
                end
            end
        end

        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;
        local failed = state.envelopeFailed;

        state.inbound        = nil;
        state.envelopeFailed = false;

        -- A closed history envelope ends the History tab's loading line,
        -- success and refusal alike (the rows were emptied at its d|).
        if (closed == 'history') then
            state.history.pendingAt = nil;
        end

        if (closed == 'page' and state.syncing and state.nextPage == nil) then
            state.syncing = false;

            verifySweep();
        end

        if (closed == 'orders' and state.ordersSyncing and state.ordersNextPage == nil) then
            state.ordersSyncing = false;
        end

        -- A SUCCESSFUL mutation patched the model in the same envelope
        -- (r|/l|/o| rode it), so the model is current at the new generation.
        if (MUTATION_VERBS[closed] and not failed) then
            state.syncGen = state.gen;
        end

        -- THE RECONCILE. Any closed envelope whose generation disagrees
        -- with the model's -- a refused buy (the row sold under the click,
        -- 2026-08-19), a hello fired on window-open after a counter sale,
        -- a history ask that happened to carry fresher numbers -- re-sweeps
        -- once per generation value. resyncFor is the loop guard: the sweep
        -- itself closes envelopes, and a sweep that re-triggered on its own
        -- traffic would never land.
        if (not state.syncing and not state.ordersSyncing
                and state.syncGen ~= nil and state.gen ~= state.syncGen
                and state.resyncFor ~= state.gen) then
            state.resyncFor = state.gen;
            state.status    = (state.status ~= nil and (state.status .. '  ') or '') .. 'The market moved -- re-syncing.';
            state.statusBad = false;

            startSync();
            startOrdersSync();
        end

        return;
    end

    -- An unknown kind from a newer server: ignored, never an error.
end

-----------------------------------
-- Sorting and filtering, all local (the whole point of the full sync)
-----------------------------------

local SORT_LABELS = { 'Level', 'Price', 'Name', 'Newest' };

local function sortedListings()
    local rows = {};

    local needle = state.search[1]:lower();

    for _, row in pairs(state.listings) do
        -- Scope first: a row a mutation patched in from another drawer is
        -- held for the model's bookkeeping but never drawn off scope.
        local keep = scopeMatches(row);

        if (keep and state.onlyMine[1] and not row.mine) then
            keep = false;
        end

        if (keep and #needle > 0) then
            keep = itemName(row.itemid):lower():find(needle, 1, true) ~= nil;
        end

        if (keep) then
            rows[#rows + 1] = row;
        end
    end

    local mode = state.sortMode;

    table.sort(rows, function(a, b)
        if (mode == 2) then
            if (a.price ~= b.price) then
                return a.price < b.price;
            end
        elseif (mode == 3) then
            local an, bn = itemName(a.itemid), itemName(b.itemid);

            if (an ~= bn) then
                return an < bn;
            end
        elseif (mode == 4) then
            if (a.id ~= b.id) then
                return a.id > b.id;
            end
        else
            -- The server default (D8): item level, descending; ties by name
            -- so the list is stable under the eye.
            local al, bl = levelOf(a.itemid), levelOf(b.itemid);

            if (al ~= bl) then
                return al > bl;
            end

            local an, bn = itemName(a.itemid), itemName(b.itemid);

            if (an ~= bn) then
                return an < bn;
            end
        end

        -- The final tiebreak is the ref, so equal rows never flicker.
        return a.ref < b.ref;
    end);

    return rows;
end

local function sortedOrders()
    local rows = {};

    for _, row in pairs(state.orderRows) do
        rows[#rows + 1] = row;
    end

    table.sort(rows, function(a, b)
        if (a.mine ~= b.mine) then
            return a.mine;
        end

        return a.id > b.id;
    end);

    return rows;
end

-----------------------------------
-- Bag reading (the Sell tab's source of truth is the client's own memory;
-- the server re-reads the slot before anything moves)
-----------------------------------

local function bagRows()
    local inventory = AshitaCore:GetMemoryManager():GetInventory();
    local rows      = {};

    for slot = 1, INVENTORY_SLOTS do
        local entry = inventory:GetContainerItem(INVENTORY_CONTAINER, slot);

        if (entry ~= nil and entry.Id > 0 and entry.Id < 65535 and entry.Count > 0) then
            rows[#rows + 1] = {
                slot   = slot,
                itemid = entry.Id,
                count  = entry.Count,
            };
        end
    end

    return rows;
end

local function slotHolding(itemId)
    for _, row in ipairs(bagRows()) do
        if (row.itemid == itemId) then
            return row.slot, row.count;
        end
    end

    return nil, 0;
end

-- Resolve the order form's text to an item id: a number is an id, anything
-- else is asked of the client's own resource manager by name.
local function resolveItemText(text)
    local id = tonumber(text);

    if (id ~= nil and id > 0 and id < 65536) then
        return math.floor(id);
    end

    if (#text < 3) then
        return nil;
    end

    local mgr = AshitaCore:GetResourceManager();

    for _, lang in ipairs({ 0, 2 }) do
        local ok, item = pcall(function()
            return mgr:GetItemByName(text, lang);
        end);

        if (ok and item ~= nil and item.Id ~= nil and item.Id > 0) then
            return item.Id;
        end
    end

    return nil;
end

-- One history ask, shared by the History tab's lookup box and the History
-- button every listing and order row carries. It is a QUERY on the wire --
-- isQuery already names it -- so the queue collapses duplicate clicks and
-- the silence latch may park it; no gil moves, so no confirm.
local function askHistory(itemId, focus)
    state.history.itemid    = itemId;
    state.history.name      = itemName(itemId);
    state.history.pendingAt = os.clock();

    -- The recent list: newest first, deduplicated, at most eight. Chips the
    -- History tab redraws, so comparing two items is two clicks, not two
    -- typed names.
    local recent = { itemId };

    for _, known in ipairs(state.history.recent) do
        if (known ~= itemId and #recent < 8) then
            recent[#recent + 1] = known;
        end
    end

    state.history.recent = recent;

    if (focus) then
        state.historyFocus = true;
    end

    issue(string.format('!dwa history %d', itemId));
end

-----------------------------------
-- The window
-----------------------------------

local function gilText(amount)
    -- 1234567 -> 1,234,567: prices are the whole point of this window, and
    -- an ungrouped million is a misread waiting to happen.
    local text = tostring(amount);
    local out  = '';

    while #text > 3 do
        out  = ',' .. text:sub(-3) .. out;
        text = text:sub(1, -4);
    end

    return text .. out;
end

-- 1787180000 -> 'just now' / '2h ago' / '3d ago' / '2026-07-04': sale dates
-- are unix stamps from the server's own clock, and a small skew against the
-- client's is invisible at this grain. A zero -- an ancient row minted
-- before dates were kept -- reads as '?', never as 1970.
local function agoText(epoch)
    if (epoch == nil or epoch <= 0) then
        return '?';
    end

    local delta = os.time() - epoch;

    if (delta < 0) then
        delta = 0;
    end

    if (delta < 60) then
        return 'just now';
    elseif (delta < 3600) then
        return string.format('%dm ago', math.floor(delta / 60));
    elseif (delta < 86400) then
        return string.format('%dh ago', math.floor(delta / 3600));
    elseif (delta < 2592000) then
        return string.format('%dd ago', math.floor(delta / 86400));
    end

    return os.date('%Y-%m-%d', epoch);
end

--[[
* Render errors are CONTAINED PER TAB, and imgui.End() runs whatever
* happened. The first live client run threw from inside a tab body (a sol
* signature this file guessed wrong) and the throw skipped End/EndTabBar --
* the DEAR IMGUI assert box over the whole client, sixty times a second.
* Structure, not hope: Begin's End is unconditional, each tab body runs
* under its own pcall inside the BeginTabItem/EndTabItem pair, and a
* repeated error prints once rather than every frame.
--]]
local lastRenderError = nil;

local function guarded(fn)
    local ok, err = pcall(fn);

    if (not ok) then
        local text = tostring(err);

        if (text ~= lastRenderError) then
            lastRenderError = text;

            print(chat.header('dwah'):append(chat.error(text)));
        end
    end
end

local function headerStrip()
    imgui.Text(string.format('Listings %d / %d', state.mine, state.cap));
    imgui.SameLine();
    imgui.TextDisabled('|');
    imgui.SameLine();
    imgui.TextColored(theme.colors.ok, string.format('Wallet %s gil', gilText(state.wallet)));

    if (state.wallet > 0) then
        imgui.SameLine();

        if (imgui.Button('Claim##wallet')) then
            issue('!dwa claim');
        end
    end

    imgui.SameLine();
    imgui.TextDisabled('|');
    imgui.SameLine();
    imgui.Text(string.format('Box %d', state.boxrows));

    if (state.boxrows > 0) then
        imgui.SameLine();

        if (imgui.Button(string.format('Collect (%d)##box', state.boxrows))) then
            -- One collect per box row, drained at the queue's own pace; the
            -- server hands back one row per ask, oldest first.
            for _ = 1, state.boxrows do
                issue('!dwa collect');
            end
        end
    end

    imgui.SameLine();

    if (imgui.Button('Refresh##all')) then
        refreshAll();
    end

    if (state.syncing) then
        imgui.TextDisabled(string.format('Loading %s %d / %d...',
            state.scope ~= nil and state.scope.label or 'listings',
            listingCount(), math.max(state.total, listingCount())));
    end

    if (state.status ~= nil) then
        imgui.TextColored(state.statusBad and theme.colors.err or theme.colors.hint, state.status);
    end

    imgui.Separator();
end

-- Draws the pager strip and returns the slice of the sorted rows the current
-- view page holds. The MODEL may hold a whole drawer; the SCREEN holds at
-- most VIEW_ROWS of it -- thousands of rows in one BeginTable, every frame,
-- was the client's fps sink (2026-08-20).
local VIEW_ROWS = 50;

local function pagedRows(rows)
    if (#rows <= VIEW_ROWS) then
        state.viewPage = 1;

        return rows;
    end

    local pages = math.ceil(#rows / VIEW_ROWS);

    if (state.viewPage > pages) then
        state.viewPage = pages;
    end

    if (imgui.Button('<##dwah_viewprev')) then
        state.viewPage = math.max(1, state.viewPage - 1);
    end

    imgui.SameLine();
    imgui.Text(string.format('Page %d / %d (%d items)', state.viewPage, pages, #rows));
    imgui.SameLine();

    if (imgui.Button('>##dwah_viewnext')) then
        state.viewPage = math.min(pages, state.viewPage + 1);
    end

    local out   = {};
    local first = (state.viewPage - 1) * VIEW_ROWS;

    for index = first + 1, math.min(first + VIEW_ROWS, #rows) do
        out[#out + 1] = rows[index];
    end

    return out;
end

--[[
* One listings table, shared by Browse and by Activity's "your listings"
* view. THE LAYOUT IS A TABLE, NOT SameLine(offset): the dwcraft grid shape,
* because it is the column idiom every sibling addon has already proven
* against Ashita's sol bindings -- the offset overload of SameLine and the
* BeginChild region this window shipped with on day one are exactly the two
* calls the client refused ("no matching function call"), and neither
* appears anywhere else in the tree. Columns are measured over exactly what
* this call renders (the dwcraft rule), so nothing can truncate.
--]]
local function listingTable(rows, tag, cancelPrefix)
    if (#rows == 0) then
        return;
    end

    if (not imgui.BeginTable('##dwah_table_' .. tag, 5,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    local nameW   = (imgui.CalcTextSize('Item'));
    local priceW  = (imgui.CalcTextSize('999,999,999'));
    local sellerW = (imgui.CalcTextSize('Sellername'));
    local histW   = (imgui.CalcTextSize('History'));

    for _, row in ipairs(rows) do
        local label = itemName(row.itemid)
            .. (row.stack == 1 and ' (stack)' or '')
            .. (bit.band(row.flags, L_EXDATA) ~= 0 and ' (signed)' or '');

        row.label = label;

        nameW   = math.max(nameW, (imgui.CalcTextSize(label)));
        sellerW = math.max(sellerW, (imgui.CalcTextSize(row.mine and 'yours' or row.seller)));
    end

    -- The name cell carries a 20px icon and its SameLine gap.
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, nameW + 30, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, priceW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, sellerW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 70, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, histW + 16, 0);

    for _, row in ipairs(rows) do
        imgui.TableNextRow();
        imgui.TableNextColumn();

        drawIcon(row.itemid, 20);

        local hovered = imgui.IsItemHovered();

        imgui.Text(row.label);
        cardOnHover(row.itemid, hovered);

        imgui.TableNextColumn();
        imgui.TextColored(theme.colors.badge, gilText(row.price));

        imgui.TableNextColumn();
        imgui.TextDisabled(row.mine and 'yours' or row.seller);

        imgui.TableNextColumn();

        if (row.mine) then
            if (imgui.Button(string.format('Cancel##%s%s', cancelPrefix, row.ref))) then
                issue(string.format('!dwa cancel %s', row.ref));
            end
        else
            if (imgui.Button(string.format('Buy##%s', row.ref))) then
                state.confirmBuy = { ref = row.ref, price = row.price, name = itemName(row.itemid) };
            end
        end

        imgui.TableNextColumn();

        -- Free and confirm-less -- a history ask moves no gil -- and it
        -- fronts the History tab (askHistory's focus flag), so the answer
        -- lands where the player is already looking.
        if (row.itemid > 0 and imgui.Button(string.format('History##h_%s%s', tag, row.ref))) then
            askHistory(row.itemid, true);
        end
    end

    imgui.EndTable();
end

-- The money question, asked twice and answered above the table: the price it
-- repeats is the one the server will be held to (the echo in the buy verb).
local function confirmBuyStrip()
    if (state.confirmBuy == nil) then
        return;
    end

    imgui.TextColored(theme.colors.warn,
        string.format('Buy %s for %s gil?', state.confirmBuy.name, gilText(state.confirmBuy.price)));
    imgui.SameLine();

    if (imgui.Button(string.format('Confirm##buy_%s', state.confirmBuy.ref))) then
        issue(string.format('!dwa buy %s %d', state.confirmBuy.ref, state.confirmBuy.price));

        state.confirmBuy = nil;
    elseif (state.confirmBuy ~= nil) then
        imgui.SameLine();

        if (imgui.Button(string.format('No##buy_%s', state.confirmBuy.ref))) then
            state.confirmBuy = nil;
        end
    end
end

local function browseTab()
    -- The drawer pair, the retail counter's own tree: nine categories every
    -- player already knows, most opening a sub-list. Listings load only once
    -- a leaf is picked -- the drawer IS the fix, for the sweep length and
    -- the frame rate both.
    imgui.SetNextItemWidth(110);

    if (imgui.BeginCombo('##dwah_cat', state.catTop ~= nil and CATEGORIES[state.catTop].label or 'Category...')) then
        for index, entry in ipairs(CATEGORIES) do
            if (imgui.Selectable(entry.label .. '##dwah_cat' .. index, index == state.catTop)) then
                state.catTop = index;
                state.catSub = nil;
            end
        end

        imgui.EndCombo();
    end

    local top = state.catTop ~= nil and CATEGORIES[state.catTop] or nil;

    if (top ~= nil and top.subs ~= nil) then
        imgui.SameLine();
        imgui.SetNextItemWidth(120);

        local subLabel = state.catSub ~= nil and top.subs[state.catSub].label or 'Which...';

        if (imgui.BeginCombo('##dwah_subcat', subLabel)) then
            for index, entry in ipairs(top.subs) do
                if (imgui.Selectable(entry.label .. '##dwah_sub' .. index, index == state.catSub)) then
                    state.catSub = index;
                end
            end

            imgui.EndCombo();
        end
    end

    imgui.SameLine();
    imgui.SetNextItemWidth(140);
    imgui.InputText('##dwah_search', state.search, 48);
    imgui.SameLine();
    imgui.SetNextItemWidth(90);

    if (imgui.BeginCombo('##dwah_sort', SORT_LABELS[state.sortMode])) then
        for index, label in ipairs(SORT_LABELS) do
            if (imgui.Selectable(label, index == state.sortMode)) then
                state.sortMode = index;
            end
        end

        imgui.EndCombo();
    end

    imgui.SameLine();
    imgui.Checkbox('Mine', state.onlyMine);

    -- A new search starts the pager over; typing lands on page one.
    if (state.search[1] ~= state.lastSearch) then
        state.lastSearch = state.search[1];
        state.viewPage   = 1;
    end

    -- The selection resolves to a leaf drawer, and the model follows it.
    -- Half a selection (Weapons picked, no sub yet) keeps whatever was
    -- loaded rather than blanking the window under the player.
    if (top ~= nil) then
        if (top.subs == nil) then
            ensureScope({ cat = top.cat, label = top.label });
        elseif (state.catSub ~= nil) then
            local sub = top.subs[state.catSub];

            ensureScope({ cat = sub.cat, label = top.label .. ' > ' .. sub.label });
        end
    end

    confirmBuyStrip();

    if (state.scope == nil or state.scope.mine) then
        imgui.TextDisabled('Pick a category -- the drawers are the auction counter\'s own.');

        return;
    end

    local rows = sortedListings();

    if (#rows == 0) then
        if (state.total == 0 and not state.syncing) then
            imgui.TextDisabled(string.format('Nothing is listed under %s. The Sell tab lists straight from your bag, free.', state.scope.label));
        else
            imgui.TextDisabled('Nothing matches.');
        end

        return;
    end

    listingTable(pagedRows(rows), 'browse', '');
end

local function sellTab()
    imgui.TextDisabled(string.format('Listing is free; the house takes %d%% when it sells. First-ever sale of an item pays %s gil.',
        limits.fee, gilText(limits.bounty)));

    -- The selected cell's price strip, above the table so it cannot collide
    -- with the row that opened it.
    if (state.sellSlot ~= nil) then
        local cell = nil;

        for _, row in ipairs(bagRows()) do
            if (row.slot == state.sellSlot) then
                cell = row;
            end
        end

        if (cell == nil) then
            -- The bag changed under the strip; the claim would be stale.
            state.sellSlot = nil;
        else
            local item = resourceOf(cell.itemid);

            imgui.Text(string.format('Selling %s:', itemName(cell.itemid)));
            imgui.SameLine();
            imgui.SetNextItemWidth(120);
            imgui.InputText(string.format('##price%d', state.sellSlot), state.sellPrice, 10);
            imgui.SameLine();

            local price = tonumber(state.sellPrice[1]) or 0;

            if (price > 0 and price <= MAX_PRICE) then
                imgui.TextDisabled(string.format('you get %s', gilText(netOf(price))));
                imgui.SameLine();

                if (imgui.Button(string.format('List single##%d', state.sellSlot))) then
                    issue(string.format('!dwa sell %d %d', state.sellSlot, price));

                    state.sellSlot = nil;
                end

                local stackSize = item ~= nil and item.StackSize or 1;

                if (state.sellSlot ~= nil and stackSize > 1 and cell.count == stackSize) then
                    imgui.SameLine();

                    if (imgui.Button(string.format('List stack##%d', state.sellSlot))) then
                        issue(string.format('!dwa sell %d %d stack', state.sellSlot, price));

                        state.sellSlot = nil;
                    end
                end
            else
                imgui.TextDisabled('price?');
            end

            if (state.sellSlot ~= nil) then
                imgui.SameLine();

                if (imgui.Button('Never mind##sell')) then
                    state.sellSlot = nil;
                end
            end
        end
    end

    local rows = bagRows();

    if (#rows == 0) then
        imgui.TextDisabled('Your bag is empty.');

        return;
    end

    if (not imgui.BeginTable('##dwah_table_bag', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    local nameW = (imgui.CalcTextSize('Item'));

    for _, row in ipairs(rows) do
        nameW = math.max(nameW, (imgui.CalcTextSize(itemName(row.itemid))));
    end

    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, nameW + 30, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 40, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 60, 0);

    for _, row in ipairs(rows) do
        imgui.TableNextRow();
        imgui.TableNextColumn();

        drawIcon(row.itemid, 20);

        local hovered = imgui.IsItemHovered();

        imgui.Text(itemName(row.itemid));
        cardOnHover(row.itemid, hovered);

        imgui.TableNextColumn();
        imgui.TextDisabled(string.format('x%d', row.count));

        imgui.TableNextColumn();

        if (imgui.Button(string.format('Sell##slot%d', row.slot))) then
            state.sellSlot     = row.slot;
            state.sellPrice[1] = '';
        end
    end

    imgui.EndTable();
end

local function confirmFillStrip()
    if (state.confirmFill == nil) then
        return;
    end

    imgui.TextColored(theme.colors.warn,
        string.format('Fill %d unit(s) of %s at %s each (you receive %s)?',
            state.confirmFill.count, state.confirmFill.name,
            gilText(state.confirmFill.price),
            gilText(netOf(state.confirmFill.price) * state.confirmFill.count)));
    imgui.SameLine();

    if (imgui.Button(string.format('Confirm##fill%d', state.confirmFill.id))) then
        issue(string.format('!dwa fill %d %d %d',
            state.confirmFill.id, state.confirmFill.slot, state.confirmFill.count));

        state.confirmFill = nil;
    elseif (state.confirmFill ~= nil) then
        imgui.SameLine();

        if (imgui.Button(string.format('No##fill%d', state.confirmFill.id))) then
            state.confirmFill = nil;
        end
    end
end

local function ordersTab()
    -- The form first: posting demand is the feature (DWAH_PLAN.md: buy
    -- orders CAUSE an economy; sell listings only display one).
    imgui.SetNextItemWidth(180);
    imgui.InputText('##dwah_orderitem', state.orderText, 32);
    imgui.SameLine();

    state.orderId = resolveItemText(state.orderText[1]);

    if (state.orderId ~= nil) then
        drawIcon(state.orderId, 18);
        imgui.Text(itemName(state.orderId));
    else
        imgui.TextDisabled('item name or id');
    end

    imgui.SetNextItemWidth(80);
    imgui.InputInt('qty##dwah_orderqty', state.orderQty, 1, 10);
    imgui.SameLine();
    imgui.SetNextItemWidth(110);
    imgui.InputText('each##dwah_orderprice', state.orderPrice, 10);
    imgui.SameLine();
    imgui.Checkbox('stacks##dwah_orderstack', state.orderStack);

    local qty   = math.max(1, math.min(99, state.orderQty[1] or 1));
    local price = tonumber(state.orderPrice[1]) or 0;

    if (state.orderId ~= nil and price > 0 and price <= MAX_PRICE) then
        imgui.SameLine();

        if (not state.confirmOrder) then
            if (imgui.Button('Post order##dwah')) then
                state.confirmOrder = true;
            end
        else
            imgui.TextColored(theme.colors.warn, string.format('Escrow %s gil?', gilText(qty * price)));
            imgui.SameLine();

            if (imgui.Button('Confirm##order')) then
                issue(string.format('!dwa order %d %d %d%s', state.orderId, price, qty,
                    state.orderStack[1] and ' stack' or ''));

                state.confirmOrder = false;
            end

            imgui.SameLine();

            if (imgui.Button('No##order')) then
                state.confirmOrder = false;
            end
        end
    end

    imgui.Separator();

    confirmFillStrip();

    local rows = sortedOrders();

    if (#rows == 0) then
        imgui.TextDisabled('No open orders. Post one above -- your gil waits in escrow until a seller fills it.');

        return;
    end

    if (not imgui.BeginTable('##dwah_table_orders', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    local nameW  = (imgui.CalcTextSize('Item'));
    local ownerW = (imgui.CalcTextSize('Sellername'));
    local histW  = (imgui.CalcTextSize('History'));

    for _, row in ipairs(rows) do
        local label = itemName(row.itemid) .. (row.stack == 1 and ' (stacks)' or '');

        row.label = label;

        nameW  = math.max(nameW, (imgui.CalcTextSize(label)));
        ownerW = math.max(ownerW, (imgui.CalcTextSize(row.mine and 'yours' or row.owner)));
    end

    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, nameW + 30, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 60, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 100, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, ownerW + 8, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 70, 0);
    imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, histW + 16, 0);

    for _, row in ipairs(rows) do
        imgui.TableNextRow();
        imgui.TableNextColumn();

        drawIcon(row.itemid, 20);

        local hovered = imgui.IsItemHovered();

        imgui.Text(row.label);
        cardOnHover(row.itemid, hovered);

        imgui.TableNextColumn();
        imgui.Text(string.format('x%d', row.qty));

        imgui.TableNextColumn();
        imgui.TextColored(theme.colors.badge, string.format('%s each', gilText(row.price)));

        imgui.TableNextColumn();
        imgui.TextDisabled(row.mine and 'yours' or row.owner);

        imgui.TableNextColumn();

        if (row.mine) then
            if (imgui.Button(string.format('Cancel##o%d', row.id))) then
                issue(string.format('!dwa cancelorder %d', row.id));
            end
        else
            local slot, held = slotHolding(row.itemid);

            if (slot ~= nil) then
                if (imgui.Button(string.format('Fill##o%d', row.id))) then
                    local count = math.min(held, row.qty, 12);

                    state.confirmFill = {
                        id    = row.id,
                        name  = itemName(row.itemid),
                        price = row.price,
                        count = row.stack == 1 and 1 or count,
                        slot  = slot,
                    };
                end
            else
                imgui.TextDisabled('none held');
            end
        end

        imgui.TableNextColumn();

        -- What has this item actually sold for? The question every order
        -- price is set against, one click from the row itself.
        if (row.itemid > 0 and imgui.Button(string.format('History##h_o%d', row.id))) then
            askHistory(row.itemid, true);
        end
    end

    imgui.EndTable();
end

--[[
* The History tab (1.2.0): the last sales of one item, straight off the same
* auction_house rows the classic counter's own history window reads.
* Populated by its lookup box, by the recent-lookup chips, or by the History
* button every listing and order row carries; the summary and the dates are
* local arithmetic over what the server sent. The tab asks for nothing on
* its own -- it renders the one ask the player's last click made.
--]]
local function historyTab()
    imgui.SetNextItemWidth(180);
    imgui.InputText('##dwah_history', state.historyText, 32);
    imgui.SameLine();

    local lookupId = resolveItemText(state.historyText[1]);

    if (lookupId ~= nil) then
        if (imgui.Button('Look up##history')) then
            askHistory(lookupId, false);
        end
    else
        imgui.TextDisabled('item name or id');
    end

    -- The session's recent lookups, one chip each: comparing two prices is
    -- two clicks, not two typed names.
    if (#state.history.recent > 1) then
        imgui.TextDisabled('Recent:');

        for index, id in ipairs(state.history.recent) do
            imgui.SameLine();

            if (imgui.Button(string.format('%s##dwah_recent%d', itemName(id), index))) then
                askHistory(id, false);
            end
        end
    end

    if (state.history.itemid == nil) then
        imgui.TextDisabled('Look up an item above, or press History beside any listing or order.');

        return;
    end

    imgui.Separator();

    drawIcon(state.history.itemid, 24);

    local hovered = imgui.IsItemHovered();

    imgui.Text(string.format('Last sales of %s', state.history.name or '?'));
    cardOnHover(state.history.itemid, hovered);

    if (state.history.pendingAt ~= nil and os.clock() - state.history.pendingAt < 6.0) then
        imgui.TextDisabled('Asking the server...');

        return;
    end

    local rows = state.history.rows;

    if (#rows == 0) then
        imgui.TextDisabled('None yet. The first player to sell one earns the pioneer bounty.');

        return;
    end

    -- Singles and stacks summarised APART: a stack price beside a single
    -- price is a twelvefold misread waiting to happen.
    local singles = { low = nil, high = nil, last = nil };
    local stacks  = { low = nil, high = nil, last = nil };

    for _, row in ipairs(rows) do
        local pot = row.stack == 1 and stacks or singles;

        pot.low  = math.min(pot.low or row.price, row.price);
        pot.high = math.max(pot.high or row.price, row.price);

        -- Rows arrive newest first; the first seen of each kind is latest.
        if (pot.last == nil) then
            pot.last = row.price;
        end
    end

    if (singles.low ~= nil) then
        imgui.TextDisabled(string.format('Singles: %s to %s gil, last sold %s',
            gilText(singles.low), gilText(singles.high), gilText(singles.last)));
    end

    if (stacks.low ~= nil) then
        imgui.TextDisabled(string.format('Stacks: %s to %s gil, last sold %s',
            gilText(stacks.low), gilText(stacks.high), gilText(stacks.last)));
    end

    if (not imgui.BeginTable('##dwah_table_history', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit), { -1, 0 })) then
        return;
    end

    local priceW  = (imgui.CalcTextSize('999,999,999 (stack)'));
    local whenW   = (imgui.CalcTextSize('2026-07-04'));
    local sellerW = (imgui.CalcTextSize('Sellername'));
    local buyerW  = (imgui.CalcTextSize('Sellername'));

    for _, row in ipairs(rows) do
        -- Measured over exactly what this call renders (the dwcraft rule).
        row.priceLabel = gilText(row.price) .. (row.stack == 1 and ' (stack)' or '');
        row.whenLabel  = agoText(row.date);

        priceW  = math.max(priceW, (imgui.CalcTextSize(row.priceLabel)));
        whenW   = math.max(whenW, (imgui.CalcTextSize(row.whenLabel)));
        sellerW = math.max(sellerW, (imgui.CalcTextSize(row.seller)));
        buyerW  = math.max(buyerW, (imgui.CalcTextSize(row.buyer)));
    end

    -- Labeled headers, unlike the listing tables: seller and buyer are both
    -- bare names here, and without the header row there is no telling which
    -- side of the sale a name was on (the dwwarehouse header idiom).
    imgui.TableSetupColumn('Price', ImGuiTableColumnFlags_WidthFixed, priceW + 8, 0);
    imgui.TableSetupColumn('When', ImGuiTableColumnFlags_WidthFixed, whenW + 8, 0);
    imgui.TableSetupColumn('Seller', ImGuiTableColumnFlags_WidthFixed, sellerW + 8, 0);
    imgui.TableSetupColumn('Buyer', ImGuiTableColumnFlags_WidthFixed, buyerW + 8, 0);
    imgui.TableHeadersRow();

    for _, row in ipairs(rows) do
        imgui.TableNextRow();
        imgui.TableNextColumn();
        imgui.TextColored(theme.colors.badge, row.priceLabel);

        imgui.TableNextColumn();
        imgui.TextDisabled(row.whenLabel);

        imgui.TableNextColumn();
        imgui.Text(row.seller);

        imgui.TableNextColumn();
        imgui.Text(row.buyer);
    end

    imgui.EndTable();
end

local function activityTab()
    -- This tab owns the 'mine' scope: the account's own listings, whatever
    -- drawer they file under, swept as their own (small) page walk. Browse
    -- takes the model back the moment its drawer is looked at again.
    -- (Price history lived here before 1.2.0 gave it a tab of its own.)
    ensureScope({ mine = true, label = 'your listings' });

    imgui.Text('Your listings');

    confirmBuyStrip();

    local mine = sortedListings();

    if (#mine == 0) then
        imgui.TextDisabled('Nothing up. Any character on your account can cancel any of these, wherever it was listed.');

        return;
    end

    listingTable(pagedRows(mine), 'mine', 'act_');
end

--[[
* The History tab's Begin, honouring a pending focus request from a History
* button. The three-argument BeginTabItem (label, open table, flags) is in
* Ashita's own annotations, but NO sibling addon has proven it against the
* live sol bindings -- and those same annotations also promise
* SameLine(offset) and two-argument InputInt, both of which the client
* REFUSED on this window's first live run (the 5a lesson: the offline
* harness's permissive stubs cannot see a signature). So the flagged call
* runs under pcall, once per request: refused, tabSelectBroken latches and
* the plain form serves forever -- the tab still populates, the player just
* clicks it themselves.
--]]
local function beginHistoryTab()
    if (state.historyFocus) then
        state.historyFocus = false;

        if (not state.tabSelectBroken) then
            local ok, opened = pcall(imgui.BeginTabItem, 'History##dwah', nil, ImGuiTabItemFlags_SetSelected);

            if (ok) then
                return opened;
            end

            state.tabSelectBroken = true;
        end
    end

    return imgui.BeginTabItem('History##dwah');
end

local function windowBody()
    headerStrip();

    if (imgui.BeginTabBar('##dwah_tabs')) then
        if (imgui.BeginTabItem('Browse##dwah')) then
            guarded(browseTab);
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Sell##dwah')) then
            guarded(sellTab);
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem(string.format('Orders (%d)###dwah_orders_tab', state.orders))) then
            guarded(ordersTab);
            imgui.EndTabItem();
        end

        if (beginHistoryTab()) then
            guarded(historyTab);
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Activity##dwah')) then
            guarded(activityTab);
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

local function renderWindow()
    imgui.SetNextWindowSize({ 620, 460 }, ImGuiCond_FirstUseEver);

    if (imgui.Begin('DriftwoodXI Market##dwah', state.open, ImGuiWindowFlags_NoDocking)) then
        guarded(windowBody);
    end

    -- ALWAYS, whatever the body did: a Begin without its End is the DEAR
    -- IMGUI assert box over the whole client, once per frame.
    imgui.End();
end

-----------------------------------
-- Events
-----------------------------------

ashita.events.register('d3d_present', 'dwah_present', function()
    -- The queue pumps BEFORE the visibility early-out: a sweep or a Buy
    -- issued just before closing the window still completes.
    pumpQueue();

    -- The sweep drivers live here rather than in the record handler, so a
    -- command lost on the way out is re-asked (the answer clock). The page
    -- walk names its drawer ('mine' for the Activity view); the key carries
    -- it too, so a drawer switch is a new ask, never a stale answer's.
    if (state.syncing and state.nextPage ~= nil) then
        local cat     = scopeCat();
        local spelled = cat == -1 and 'mine' or tostring(cat);

        need('page', string.format('%d/%s', state.nextPage, spelled),
            string.format('!dwa page %d %s', state.nextPage, spelled));
    end

    if (state.ordersSyncing and state.ordersNextPage ~= nil) then
        need('orders', state.ordersNextPage, string.format('!dwa orders %d', state.ordersNextPage));
    end

    if (not state.open[1]) then
        return;
    end

    -- First open of the session: ask for everything once.
    if (not state.synced) then
        state.synced = true;

        refreshAll();
    end

    local pushed = theme.push();
    local ok, err = pcall(renderWindow);
    theme.pop(pushed);

    if (not ok) then
        print(chat.header('dwah'):append(chat.error(tostring(err))));
    end
end);

ashita.events.register('packet_in', 'dwah_packet_in', function(e)
    if (e.id == 0x0017) then
        local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

        if (sender == DATA_SENDER) then
            local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

            -- Blocked BEFORE parsing: a record that throws must still never
            -- reach the chat log as line noise.
            e.blocked = true;

            local ok, err = pcall(handleRecord, message);

            if (not ok) then
                print(chat.header('dwah'):append(chat.error(tostring(err))));
            end
        end

        return;
    end

    -- Zone-in wipes all server-derived state: the next open re-syncs once
    -- the client's own zoning flag clears (the queue is already held shut by
    -- echo.canSend until then).
    if (e.id == 0x000A) then
        forget();

        state.synced       = false;
        state.syncing      = false;
        state.nextPage     = nil;
        state.ordersSyncing = false;
        state.ordersNextPage = nil;
        state.inbound      = nil;
        state.serverSilent = false;
    end
end);

-- The player's own typing moves the throttle too: a hand-typed !dwa line is
-- a send this addon did not queue, and pacing off it keeps the client's
-- outgoing chat limiter honest (the dwsuite contract).
ashita.events.register('packet_out', 'dwah_packet_out', function(e)
    if (e.id == 0x00B5) then
        lastSend = os.clock();
    end
end);

ashita.events.register('command', 'dwah_command', function(e)
    local args = e.command:args();

    if (#args == 0 or (args[1] ~= '/dwah' and args[1] ~= '/market')) then
        return;
    end

    e.blocked = true;

    if (#args > 1 and args[2]:lower() == 'refresh') then
        refreshAll();

        return;
    end

    state.open[1] = not state.open[1];

    -- Re-opening asks for a fresh account line: if the market moved while
    -- the window was shut (a counter sale, an alt's fill), the hello's k|
    -- disagrees with the model and the z| reconcile re-sweeps by itself.
    if (state.open[1] and state.synced) then
        issue('!dwa hello');
    end
end);
