--[[
* DriftwoodXI -- dwwarehouse
*
* One account-wide pool of storage, from whichever character you are logged in
* on. Search it, take things out of it, put things into it, and pull a named
* bundle of materials in one click.
*
* THIS ADDON IS A RENDERER AND NOTHING ELSE.
*
* It is a sibling of dwbags (`addons/dwbags/dwbags.lua:8-21`) and inherits that
* rule unchanged. It holds no item data of its own, caches nothing to disk
* except the player's own kit names, and has no way to move an item that the
* typed command surface does not already have. Every read is `!dww who|page`
* and every write is `!dww put|take|trash|stack|stashall|pull|pin|unpin|buy|sell`,
* which are the same server-side functions `!warehouse` reaches -- the only
* difference is that they answer in compact records under the sender name
* _DWWDATA, which this addon parses and blocks before the chat log sees them.
*
* THE MARKET LANE (1.9.0, server 2026-09-01). A Sell button on every shelf row
* lists it on the DWAH market straight from the warehouse -- no bag slot, no
* second window. The server's `sell` verb hands the row to the market store's
* OWN listing gate (the one the /dwah Sell tab and the Jeuno counter run), so
* nothing sells from here that could not sell from a bag; the fee is charged
* when it sells, exactly as any other listing. The `s|` record carries the
* account's market standing, and a server that never sends one gets no Sell
* button drawn at all -- the honest rendering of a server without the lane.
*
* WHY THAT MATTERS HERE MORE THAN ANYWHERE. The warehouse is the one container
* whose capacity the server owns outright, so a client that could invent a row
* would be inventing storage. Every rule -- the Rare re-check on the way out,
* the deposit refusals, the capacity ceiling -- lives in the server's C++ and
* runs identically whichever way the command arrived. Nothing below is trusted
* by anything.
*
* THERE IS NO BOUND LANE ANY MORE (2026-08-08). An EX, augmented or NoDelivery
* item used to be stored FOR ITS DEPOSITOR: the row carried that charid and no
* other character on the account could take it back out. The warehouse exists
* to move gear around an account, so that rule was working against the feature
* it lived in, and it is gone -- every row belongs to the account and any
* character on it may withdraw any row. What this addon lost with it: the two
* wire flag bits below, and the disabled Take button they drew.
*
* WHY THE SERVER DOES NOT SEND ITEM NAMES. Same answer as dwbags: this addon is
* inside the client, and the client already has the name, the icon and the type
* of every item in its own DAT resources. Sending them would be paying twice,
* and it is what keeps a packed `w|` record inside the chat buffer the whole
* protocol has to fit through.
*
* THE MODEL IS PAGED, NOT PUSHED. A thousand rows do not fit in one chat line,
* so a full sync is `page 0..N` walked on this addon's own 1.2s pump with a
* progressive render behind it. After that, deltas keep it current: every
* mutation answers with the `w|`/`r|` rows it changed plus a `k|` carrying the
* account's generation counter. A generation this addon did not cause -- a
* second client on the same account moving something -- is a gap, and a gap
* repages rather than guessing.
*
* THE DEPOSIT TAB READS CLIENT MEMORY, WHICH IS THE ONE PLACE IT CAN. Nothing
* on the wire says what is in your own inventory right now; the client knows,
* and `!dww put` names the slot AND the item id precisely so the server can
* refuse a claim that has gone stale ("bag changed"). A wrong read here costs a
* refusal sentence, never a wrong item.
*
* KITS ARE LOCAL AND ALWAYS WILL BE. A kit is a name for a list of item ids and
* quantities; pulling one emits ordinary `!dww pull` lines. The server never
* hears the name and stores nothing about it. They live in Ashita's settings
* library, which already files everything under `<charname>_<serverid>`, so
* per-character separation is free (the dwmacro precedent,
* `addons/dwmacro/dwmacro.lua:85-90`).
*
* TURN IT OFF AND NOTHING IS LOST. `!warehouse` does all of it typed.
--]]

addon.name    = 'dwwarehouse';
addon.author  = 'DriftwoodXI';
addon.version = '1.11.0';
addon.desc    = 'Account-wide virtual storage for DriftwoodXI.';
addon.link    = 'https://driftwoodgaming.com';

require('common');

local chat     = require('chat');
local d3d      = require('d3d8');
local ffi      = require('ffi');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('dwtheme');
local echo     = require('dwecho');

-- Swallows the client's local echo of the ! commands sent below; see
-- dwecho.lua. Installed here, before any other text_in handler in this file,
-- so a blocked line is already flagged by the time they see it.
echo.install();

local C = ffi.C;

--[[
* The D3D device, fetched on first use rather than at load.
*
* This addon is loaded from the launcher's boot script, which runs long before
* the client has a rendering device -- and `d3d.get_device()` at file scope
* makes the whole addon fail to load when it answers nothing. Nothing here
* needs a device until the first icon is drawn, by which point there certainly
* is one. (dwbags.lua:107-116.)
--]]
local d3d8dev = nil;

local function device()
    if (d3d8dev == nil) then
        d3d8dev = d3d.get_device();
    end

    return d3d8dev;
end

-- The sender name the server stamps on every machine-readable line. Fifteen
-- bytes of sName on GP_SERV_COMMAND_CHAT_STD; nothing else on the server uses
-- it, so matching it exactly is a safe filter.
local DATA_SENDER = '_DWWDATA';

-- Protocol version the server announces in its `d|` record. Bumped only for a
-- breaking change to the record layout.
local PROTOCOL = 1;

--[[
* `w|` flag bits, as the server packs them (DWWAREHOUSE_PLAN.md, wire section).
*
* BITS 8 AND 16 ARE NOT DEFINED HERE AND THAT IS THE POINT. They were
* BOUND_OTHER and BOUND_MINE, two halves of one fact: which side of a bound
* row's lane this character was on. The lane is retired (see the header) and
* the server sets neither bit, so a constant for them here would be a name for
* something that never arrives -- and the next reader would have to disprove it
* before trusting the Take button. They are not re-used for anything else, so
* an addon of any age against a server of any age reads a row the same way.
--]]
local WH_RARE        = 1;
local WH_EX          = 2;
local WH_AUGMENTED   = 4;

-- The client's own inventory, which is the only container `put` reads from.
-- Slot 0 is gil and is deliberately skipped: currency is a deposit refusal on
-- the server (R3) and a row for it would only ever be a button that fails.
local INVENTORY_CONTAINER = 0;
local INVENTORY_SLOTS     = 80;

--[[
* Category chips, keyed on the client DAT item type (Ashita's
* `plugins/sdk/ffxi/enums.h` ItemType).
*
* THESE ARE A FILTER, NOT A TAXONOMY, and the DAT does not have the categories
* a player has in their head. There is no "food" type -- food and medicine are
* both UsableItem -- so the Food chip shows both, which is the honest rendering
* of what the client actually knows. Nothing on the server turns on any of
* this; it narrows a list and that is all.
--]]
local CATEGORIES = {
    { name = 'All',       all   = true },
    { name = 'Weapons',   types = { [4] = true } },
    { name = 'Armor',     types = { [5] = true } },
    { name = 'Materials', types = { [1] = true, [3] = true, [8] = true } },
    { name = 'Food',      types = { [7] = true } },
    { name = 'Other',     other = true },
};

local SORTS = {
    { name = 'Name' },
    { name = 'Qty' },
    -- No timestamp rides the wire. `id` is AUTO_INCREMENT on the warehouse
    -- table, so a bigger row id IS a later deposit -- newest-first is rowid
    -- descending and needs nothing added to the protocol to be true.
    { name = 'Newest' },
    -- Both local (1.9.0): the DAT's item type and the equip level, read from
    -- the client's own resources like the name is. Level puts the highest
    -- gear first, which is how a shelf of spares is actually browsed.
    { name = 'Type' },
    { name = 'Level' },
};

-- The market's own price ceiling (market_core.lua MAX_PRICE): a price the
-- strip would send past it is refused there, so it is not offered here.
local MAX_PRICE = 999999999;

-- How long one `!dww pull` line may be. RAW_LINE_BUDGET on the server is 130;
-- this leaves room for the verb and a margin, and a kit longer than one line
-- becomes several lines rather than a truncated one.
local PULL_BUDGET = 120;

-- A kit name is a local label and a settings key. Bounded so a pathological
-- one cannot make the settings file unreadable.
local KIT_NAME_MAX = 24;

local state = T{
    open      = T{ false },

    -- The warehouse model. `rows` is keyed by row id and `pins` by item id, so
    -- BOTH ARE PLAIN TABLES -- see the note on `requested` below; a T{} keyed
    -- by data resolves misses through the sugar metatable and hands back a
    -- function where nil was meant.
    rows      = {},
    pins      = {},

    used      = 0,
    cap       = 0,
    gen       = 0,

    -- Moves on EVERY write to `rows` (1.10.0): the filtered, sorted view
    -- and the per-item stored counts are cached against it, so a frame
    -- that changed nothing re-sorts nothing. See visibleRows.
    modelRev  = 0,

    -- Paging. `syncGen` is the generation the model on screen was built FROM;
    -- when it falls behind `gen` the model is stale and repages itself.
    -- `sweepGen` is the generation the sweep in flight started under, so a
    -- second client mutating halfway through a twelve-page walk is caught
    -- rather than stitched into a list that was never true at any one moment.
    syncing   = false,
    syncGen   = -1,
    sweepGen  = nil,
    resweeps  = 0,
    nextPage  = nil,
    pages     = nil,
    pagesSeen = 0,
    synced    = false,      -- a full sweep has been asked for this login

    -- Latched by the row-count repair below, so the repage it forces cannot
    -- force another one. See verifyRowCount.
    repaired  = false,

    -- The verb whose response is currently arriving. Records are only accepted
    -- between a `d|` and its `z|`, so a line that arrives on its own -- a
    -- response to something typed by hand, say -- cannot half-fill the UI.
    inbound   = nil,
    status    = 'Press Refresh.',
    statusBad = false,
    reported  = false,      -- a render error is worth saying once, not per frame

    --[[
        The Trash confirmation's pending row: { rowid, itemid, qty, flags }.
        Non-nil is what keeps the popup open -- ImGui closes a popup on an
        outside click, and the render pass re-opens it while this is set, so
        the only ways past the question are its two buttons. Destroying an
        item is the one click in this window that cannot be taken back.
    ]]
    trashAsk  = nil,

    --[[
        Latched when the server answers that it has no trash verb -- an older
        server core, or a binary older than its Lua. The verb is additive and
        the protocol version deliberately did not move (an old addon reads a
        new server fine either way), so the server's own refusal sentence is
        the only signal there is; once seen, the Trash buttons stop drawing
        rather than every click re-earning the same red banner (the dwbags
        unknown-verb lesson).
    ]]
    noTrash   = false,

    -- The stack verb's twin of the latch above, for the same reason: the verb
    -- is additive, the protocol version did not move, and the server's own
    -- refusal sentence is the only signal an older server or binary has no
    -- restack. Once seen, the button stops drawing for the session.
    noStack   = false,

    -- The buy verb's latch, same family. And the purchase tier's standing
    -- from the `b|` record: nil until a `who` answers, which is also what an
    -- old binary looks like -- the confirmation then simply says less.
    noBuy     = false,
    buyAsk    = false,
    bought    = nil,
    buyMax    = 1000,

    --[[
        The market lane (1.9.0). `market` is the `s|` record -- { fee,
        listings, cap } -- and nil until a `who` carries one, which is also
        what a server without the lane looks like: no record, no Sell button,
        no refusal to earn. `noSell` is the refusal latch for the case the
        record cannot cover (a core newer than its binary answers the verb
        with a sentence). `sellAsk` is the row whose price strip is open --
        { rowid, itemid, qty, flags, augs } -- and the strip's price box.
    ]]
    market    = nil,
    noSell    = false,
    sellAsk   = nil,
    sellPrice = T{ '' },

    -- Header controls.
    search    = T{ '' },
    category  = 1,
    sort      = 1,
    takeQty   = T{ 1 },
    takeAll   = T{ true },  -- move the whole stack unless told otherwise

    -- Kits.
    kitName   = T{ '' },

    -- Which kit's Delete button is armed, and when it was armed. A kit is
    -- player-authored text this window is the only copy of, and it was the one
    -- destructive click here that fired on the first press -- beside a Trash
    -- button that opens a modal and a Stash All that opens another. dwjobs
    -- says why its preset delete asks twice in as many words ("a preset is
    -- cheap to remake, but an accidental single click should still not cost
    -- one"), and a kit is the same kind of thing. The hold is dwmerc's
    -- CONFIRM_HOLD reasoning: long enough to read, short enough that it is
    -- never still armed when somebody comes back to the window.
    kitArmed  = nil,
    kitArmAt  = 0,
};

-- How long a kit's Delete stays armed after the first click.
local KIT_CONFIRM_HOLD = 8.0;

--[[
* Which deposit rows are ticked, keyed by ITEM ID.
*
* A PLAIN TABLE, NOT `T{ }`, for the reason documented at dwbags.lua:427-442: a
* table indexed by names the caller chooses must not be one that already has
* names of its own. Item ids are numbers here rather than strings, so the
* specific trap is different -- but the rule is the rule, and the next edit
* that keys something by name is the one that pays for breaking it.
--]]
local selection = {};

local icons = T{ };

--[[
* The item icon out of the client's own resources.
*
* Cached because a page is a hundred rows redrawn every frame and
* D3DXCreateTextureFromFileInMemoryEx is not free. gc_safe_release hands back a
* texture that releases itself when Lua collects it, which is what keeps this
* from leaking across a reload. (dwbags.lua:289-330.)
--]]
local function iconOf(itemId)
    if (itemId == nil or itemId == 0 or itemId == 65535) then
        return nil;
    end

    if (icons[itemId] ~= nil) then
        return icons[itemId];
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        icons[itemId] = false;
        return nil;
    end

    local dev = device();

    if (dev == nil) then
        return nil;
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');

    if (C.D3DXCreateTextureFromFileInMemoryEx(dev, item.Bitmap, item.ImageSize,
            0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
            C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= C.S_OK) then
        icons[itemId] = false;
        return nil;
    end

    icons[itemId] = d3d.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));

    return icons[itemId];
end

--[[
* Names and types CACHED per item id (1.10.0, the owner's frame-rate report:
* a thousand-row warehouse tanked the fps). The DAT never changes under a
* running client, and the old shape asked the resource manager for the same
* name several times per row per frame -- once to draw it, once to filter
* it, and once per comparison inside the sort. `lowerName` is the search
* key, lowercased once rather than sixty times a second per row.
--]]
local nameCache  = { };
local lowerCache = { };
local typeCache  = { };

local function itemName(itemId)
    local cached = nameCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    local name;

    if (item == nil or item.Name[1] == nil or item.Name[1]:len() == 0) then
        name = string.format('item %d', itemId);
    else
        name = item.Name[1];
    end

    nameCache[itemId] = name;

    return name;
end

local function lowerName(itemId)
    local cached = lowerCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local lowered = itemName(itemId):lower();

    lowerCache[itemId] = lowered;

    return lowered;
end

local function itemType(itemId)
    local cached = typeCache[itemId];

    if (cached ~= nil) then
        return cached;
    end

    local item = AshitaCore:GetResourceManager():GetItemById(itemId);
    local kind = item ~= nil and (item.Type or 0) or 0;

    typeCache[itemId] = kind;

    return kind;
end

local function drawIcon(itemId, size)
    local texture = iconOf(itemId);

    if (texture ~= nil and texture ~= false) then
        imgui.Image(tonumber(ffi.cast('uint32_t', texture)), { size, size });
    else
        imgui.Dummy({ size, size });
    end

    imgui.SameLine();
end

--[[
* The item card (1.4.0): the hover pop-up on every item row -- name, iLvl,
* level, Rare/Ex, slots, jobs, augments where the bytes are readable, and
* the item's own description text with the elemental-resist icons folded to
* readable tags, all read from the client's OWN resources by id, so nobody
* has to alt-tab to a wiki to learn what a row in the warehouse is.
* Mirrored BY HAND from dwbags 1.17.0 (an addon folder is the unit of
* distribution, the dwtheme rule, so the lines are duplicated rather than
* shared) -- edit one, revisit the others (dwbags is the master; dwah,
* dwraid, dwquest carry siblings). The DAT flag bits are the same ones
* sql/item_basic.sql spells @FLAG_RARE and @FLAG_EX; everything here is
* presentation, and the server re-checks anything that matters.
--]]
local FLAG_EX   = 0x4000;
local FLAG_RARE = 0x8000;

--[[
* The eight elemental-resist icons in the client's item descriptions are
* FFXI-private Shift-JIS pairs -- 0xEF then 0x1F..0x26, in wheel order
* fire ice wind earth lightning water light dark (read straight out of
* ROM/118/107.DAT: item 6272 carries fire as EF 1F, item 4488 dark as
* EF 26, and the JP DAT spells the same slots 耐火/耐風/耐土). ImGui wants
* UTF-8, so the raw pair renders as the '?' players reported. Each icon
* (and the '+' that usually follows it) folds to a three-letter tag:
* '<fire>+20' reads FiR:20, '<dark>-10' reads DkR:-10.
--]]
local RESIST_TAGS = {
    [0x1F] = 'FiR', [0x20] = 'IcR', [0x21] = 'WiR', [0x22] = 'EaR',
    [0x23] = 'LtR', [0x24] = 'WaR', [0x25] = 'LiR', [0x26] = 'DkR',
};

local function cleanDescription(desc)
    return (desc:gsub('\239([\31-\38])%+?', function(b)
        return RESIST_TAGS[b:byte()] .. ':';
    end));
end

--[[
* Augment names -- augcatalog.lua beside this file, the same GENERATED
* catalog dwquest carries (tools/dwquest/gen_augment_catalog.py;
* Check-QuestAugments.ps1 keeps every copy byte-identical to dwquest's).
* pcall'd because a half-synced folder is a real deployment state: without
* the catalog the card still lists augments, as the raw ids they are.
--]]
local haveAugCatalog, augcatalog = pcall(require, 'augcatalog');

if (not haveAugCatalog or type(augcatalog) ~= 'table' or type(augcatalog.augments) ~= 'table') then
    augcatalog = { augments = { } };
end

-- dwquest's augmentText (dwquest.lua:168) without the exchange id suffix:
-- a hover card names the augment, the Exchange window is where ids matter.
local function augmentText(augid, rank)
    local entry = augcatalog.augments[augid];

    if (entry == nil) then
        return string.format('augment %d rank %d', augid, rank);
    end

    local label  = entry.l;
    local stored = rank - 1;

    if (entry.m ~= nil) then
        if (stored > 0) then
            local k = 0;

            label = string.gsub(label, '%d+', function(digits)
                k = k + 1;

                local term = entry.m[k];

                if (term == nil) then
                    return digits;
                end

                if (type(term) == 'table') then
                    return tostring(term[1] + stored * term[2]);
                end

                return tostring(term + stored);
            end);
        end
    elseif (rank > 1) then
        label = string.format('%s (rank %d)', label, rank);
    end

    return label;
end

--[[
* The four augment slots out of an item's exdata bytes, decoded the way
* quest_store.cpp augmentsOf does: byte one is the kind (0x02 = carries
* augments), byte two the sub-kind (any special bit 0x08..0x80 --
* escutcheon, serialized, mezzotint, trial, evolith -- is a DIFFERENT byte
* layout and is refused, quest_store.cpp extraIsAugmentable), then four
* packed uint16s -- id in the low 11 bits, stored value in the high 5, and
* the rank a player reads is stored + 1. Returns nil when there is nothing
* honest to say.
--]]
local function extraAugments(extra)
    if (type(extra) ~= 'string' or #extra < 12) then
        return nil;
    end

    if (extra:byte(1) ~= 0x02 or bit.band(extra:byte(2), 0xF8) ~= 0) then
        return nil;
    end

    local augs = T{ };

    for slot = 0, 3 do
        local packed = extra:byte(3 + slot * 2) + extra:byte(4 + slot * 2) * 256;
        local augid  = bit.band(packed, 0x07FF);

        if (augid ~= 0) then
            augs:append({ id = augid, rank = bit.band(bit.rshift(packed, 11), 0x1F) + 1 });
        end
    end

    if (#augs == 0) then
        return nil;
    end

    return augs;
end

local JOB_NAMES = {
    [0] = '---',
    'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK',
    'BST', 'BRD', 'RNG', 'SAM', 'NIN', 'DRG', 'SMN', 'BLU',
    'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN',
};

-- Display names for the card's slot line: ear and ring pairs fold into one
-- word each.
local CARD_SLOTS = {
    [0]  = 'Main',  [1]  = 'Sub',   [2]  = 'Ranged', [3]  = 'Ammo',
    [4]  = 'Head',  [5]  = 'Body',  [6]  = 'Hands',  [7]  = 'Legs',
    [8]  = 'Feet',  [9]  = 'Neck',  [10] = 'Waist',  [11] = 'Ear',
    [12] = 'Ear',   [13] = 'Ring',  [14] = 'Ring',   [15] = 'Back',
};

local function jobsText(mask)
    local names = T{ };

    for jobId = 1, #JOB_NAMES do
        if (bit.band(mask, bit.lshift(1, jobId)) ~= 0) then
            names:append(JOB_NAMES[jobId]);
        end
    end

    if (#names == 0) then
        return nil;
    end

    if (#names >= #JOB_NAMES) then
        return 'All jobs';
    end

    return table.concat(names, ' ');
end

local function slotsText(mask)
    local names = T{ };
    local seen  = { };

    for slot = 0, 15 do
        if (bit.band(mask, bit.lshift(1, slot)) ~= 0) then
            local label = CARD_SLOTS[slot];

            if (not seen[label]) then
                seen[label] = true;
                names:append(label);
            end
        end
    end

    if (#names == 0) then
        return nil;
    end

    return table.concat(names, '/');
end

--[[
* Whether the player already knows the spell a scroll teaches (1.10.0, the
* owner's request): true, false, or nil when the item is not a scroll or
* the client cannot say. A scroll is recognised by its own description --
* every spell scroll's opens "Teaches the ..." -- and the spell is looked
* up by the scroll's DAT name (which IS the spell's name: the item is
* "Auspice", the log name "scroll of Auspice"), falling back to the last
* words of the description. The player's spell list is the client's own
* memory (IPlayer:HasSpell), read under pcall: the sol bindings for it are
* promised by Ashita's annotations and proven by no sibling, so a refusal
* costs one missing line rather than a card that throws. Mirrored BY HAND
* from dwah (edit one, revisit dwbags and this one).
--]]
local function scrollStatus(item)
    if (item == nil) then
        return nil;
    end

    local desc = item.Description ~= nil and item.Description[1] or nil;

    if (type(desc) ~= 'string' or desc:sub(1, 12) ~= 'Teaches the ') then
        return nil;
    end

    local ok, known = pcall(function()
        local mgr    = AshitaCore:GetResourceManager();
        local player = AshitaCore:GetMemoryManager():GetPlayer();

        if (mgr == nil or player == nil) then
            return nil;
        end

        local names = { item.Name ~= nil and item.Name[1] or nil };
        local tail  = desc:match('^Teaches the [%a%-]+ [%a%-]+ (.-)%.') or desc:match('^Teaches the [%a%-]+ (.-)%.');

        if (tail ~= nil and tail ~= names[1]) then
            names[#names + 1] = tail;
        end

        for _, name in ipairs(names) do
            local spell = mgr:GetSpellByName(name, 0);

            if (spell ~= nil and spell.Index ~= nil) then
                return player:HasSpell(spell.Index) == true;
            end
        end

        return nil;
    end);

    if (not ok) then
        return nil;
    end

    return known;
end

local function drawScrollStatus(item)
    local known = scrollStatus(item);

    if (known == true) then
        imgui.TextColored(theme.colors.ok, 'You already know this spell.');
    elseif (known == false) then
        imgui.TextColored(theme.colors.warn, 'Not learned yet.');
    end
end

-- `aug` is one of three honest states: a list of { id, rank } (the bytes
-- were readable and decoded), `true` (the server said "augmented" about an
-- item whose bytes live in the warehouse -- say so without inventing
-- values), or nil.
local function itemCard(itemId, aug)
    imgui.BeginTooltip();

    local item = nil;

    if (itemId ~= nil and itemId ~= 0 and itemId ~= 65535) then
        item = AshitaCore:GetResourceManager():GetItemById(itemId);

        drawIcon(itemId, 32);
    end

    imgui.Text(itemName(itemId));

    if (item ~= nil) then
        local tags = T{ };

        if (item.ItemLevel ~= nil and item.ItemLevel > 0) then
            tags:append(string.format('iLvl %d', item.ItemLevel));
        end

        if (item.Level ~= nil and item.Level > 0) then
            tags:append(string.format('Lv.%d', item.Level));
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_RARE) ~= 0) then
            tags:append('Rare');
        end

        if (item.Flags ~= nil and bit.band(item.Flags, FLAG_EX) ~= 0) then
            tags:append('Ex');
        end

        if (#tags > 0) then
            imgui.TextColored(theme.colors.info, table.concat(tags, '  '));
        end

        local slots = item.Slots ~= nil and slotsText(item.Slots) or nil;
        local jobs  = item.Jobs ~= nil and jobsText(item.Jobs) or nil;

        if (slots ~= nil and jobs ~= nil) then
            imgui.TextDisabled(slots .. '  --  ' .. jobs);
        elseif (slots ~= nil or jobs ~= nil) then
            imgui.TextDisabled(slots or jobs);
        end

        drawScrollStatus(item);

        if (type(aug) == 'table') then
            imgui.Separator();
            imgui.TextColored(theme.colors.info, 'Augments');

            for _, a in ipairs(aug) do
                imgui.Text('  ' .. augmentText(a.id, a.rank));
            end
        elseif (aug == true) then
            imgui.Separator();
            imgui.TextColored(theme.colors.info, 'Augmented');
            imgui.TextDisabled('Values are readable where the item sits -- hover it there.');
        end

        local desc = item.Description ~= nil and item.Description[1] or nil;

        if (desc ~= nil and #desc > 0) then
            imgui.Separator();
            -- A fixed wrap width, not one derived from imgui state: the
            -- card must render the same whatever window it floats over.
            imgui.PushTextWrapPos(320.0);
            imgui.Text(cleanDescription(desc));
            imgui.PopTextWrapPos();
        end
    end

    imgui.EndTooltip();
end

-- Call after an icon-and-name pair: `hoveredIcon` is IsItemHovered read
-- between the two draws (drawIcon leaves the cursor on the same line, and
-- IsItemHovered reads the LAST item, so the icon's hover must be taken
-- before the name is drawn). `aug` passes through to the card.
local function cardOnHover(itemId, hoveredIcon, aug)
    if (imgui.IsItemHovered() or hoveredIcon == true) then
        itemCard(itemId, aug);
    end
end

--[[
* Send a command to the server, exactly as if it had been typed -- ONE AT A TIME.
*
* THE CLIENT RATE-LIMITS OUTGOING CHAT, AND A !dww COMMAND IS A CHAT LINE.
* Firing four of them in a single frame -- which is what a naive "sync
* everything" does, and this addon's whole first sync is a run of them -- gets
* the first one sent and the rest answered with "A command error occurred" by
* the client, before the server ever sees them. So everything queues here and
* drains at one command per SEND_INTERVAL. Duplicates collapse, because asking
* twice for the same page is never useful and the queue is the one place that
* can know. (dwbags.lua:354-403.)
--]]
local SEND_INTERVAL = 1.2;

local queue    = T{ };
local lastSend = 0;

--[[
* ONLY QUERIES COLLAPSE. The note above is about reads -- `page` and `who` --
* and asking twice for either really is never useful (needPage and startSync
* both lean on that). But this same queue carries every WRITE the window makes:
* take, trash, put and the kit `pull` lines. Two identical `!dww take 41 12`
* clicks are two commands the player asked for, and issue() has no way to
* report a refusal, so collapsing them silently loses one -- with the queue
* draining at one line per 1.2s, that window is wide enough to click twice in.
--]]
local function issue(command)
    if (command == '!dww who' or command:match('^!dww page ') ~= nil) then
        for _, queued in ipairs(queue) do
            if (queued == command) then
                return;
            end
        end
    end

    queue:append(command);
end

--[[
* Drains one queued command. Called every frame from d3d_present, including
* while the window is shut: a page walk started just before closing it still
* has to finish, and a Take issued a moment before closing still has to reach
* the server.
--]]
local function pumpQueue()
    -- The client refuses outgoing chat while it is still zoning and answers the
    -- line with "A command error occurred." before the server ever sees it, so
    -- hold the queue shut until the load screen is gone. Held, not dropped: the
    -- line goes out a moment later instead of after an ANSWER_TIMEOUT retry.
    -- (dwecho.lua's canSend; 2026-08-15.)
    if (not echo.canSend()) then
        return;
    end

    if (#queue == 0) then
        return;
    end

    local now = os.clock();

    if (now - lastSend < SEND_INTERVAL) then
        return;
    end

    lastSend = now;

    echo.send(table.remove(queue, 1));
end

--[[
* What has already been asked for, so a frame drawn sixty times a second asks
* once, and so a command lost on the way out is asked again exactly once.
*
* A PLAIN TABLE, NOT `T{ }`, AND IN dwbags THIS COST A ROUND
* (dwbags.lua:427-442): the table is keyed by VERB, and a `T{ }` resolves
* unknown keys through its metatable to the sugar table methods -- so
* `requested['find']` answered a FUNCTION rather than nil, and writing a field
* to it threw. A table indexed by names the caller chooses must not be one that
* already has names of its own.
*
* THE ANSWER IS TRACKED, NOT JUST THE QUESTION, and here that is load-bearing
* rather than defensive: a lost `page` command does not leave one panel stale,
* it stalls the whole sweep and the list simply stops filling in. One retry,
* then left alone -- a retry that never terminates would be a command loop,
* which is worse than a short list.
--]]
local requested = {};

local ANSWER_TIMEOUT = 5.0;
local ANSWER_TRIES   = 2;

local function forget()
    requested = {};
end

-- Called from the `d|` record: whatever response is arriving answers the
-- outstanding question for that verb.
local function answered(verb)
    local asked = requested[verb];

    if (type(asked) == 'table') then
        asked.answered = true;
    end
end

-- Ask for one page, at most once -- twice if the first one was never answered.
local function needPage(page)
    local asked = requested['page'];

    if (asked ~= nil and asked.page == page) then
        -- A held send (zone-in) leaves the line queued; aging the answer clock
        -- against it would be a false timeout. (dwecho canSend; 2026-08-15.)
        if (not echo.canSend()) then
            return;
        end

        if (asked.answered) then
            return;
        end

        -- The answer window is checked BEFORE the try count, deliberately. In
        -- the other order the sweep would be declared dead on the very frame
        -- after the second send, with the retry still in flight.
        if ((os.clock() - asked.at) < ANSWER_TIMEOUT) then
            return;
        end

        --[[
            A SWEEP THAT GIVES UP HAS TO SAY SO AND STAND DOWN. The try count
            used to sit in the `or` chain above, which made running out of
            tries a silent `return` -- so needPage did nothing, forever, and
            `state.syncing` stayed TRUE for the rest of the session. That flag
            gates both self-repair paths (the row-count verify and the
            generation-gap repage), so the one state the addon could not
            recover from was the one it entered by failing. Nothing on screen
            said anything either: the "loading N/M" note simply stopped moving.
        --]]
        if (asked.tries >= ANSWER_TRIES) then
            state.syncing   = false;
            state.nextPage  = nil;
            state.status    = string.format('The list stopped at page %d -- press Refresh.', page + 1);
            state.statusBad = true;

            return;
        end

        asked.at    = os.clock();
        asked.tries = asked.tries + 1;
    else
        requested['page'] = { page = page, at = os.clock(), answered = false, tries = 1 };
    end

    issue(string.format('!dww page %d', page));
end

--[[
* Start a full page sweep.
*
* THE MODEL IS CLEARED HERE RATHER THAN MERGED INTO. A sweep is the answer to
* "what is actually in there", and a row this addon holds that the server no
* longer has -- an alt on the same account took it -- would survive any number
* of merges. Clearing costs a rebuilding list for the length of the sweep,
* which is what the "loading N/M" note is for; keeping a ghost row costs a
* Take button that fails.
--]]
local function startSync()
    forget();

    state.rows      = {};
    state.modelRev  = state.modelRev + 1;
    state.syncing   = true;
    state.syncGen   = state.gen;
    state.sweepGen  = nil;
    state.nextPage  = 0;
    state.pages     = nil;
    state.pagesSeen = 0;
    state.synced    = true;
    state.status    = 'Reading your warehouse...';
    state.statusBad = false;

    issue('!dww who');
end

-- How many times a sweep may restart itself because the account moved under
-- it. Three is generous for two clients; a fourth means something is churning
-- the account faster than a 1.2s pump can read it, and the honest answer is a
-- sentence rather than a page walk that never ends.
local MAX_RESWEEPS = 3;

--[[
* Does the model hold as many rows as the server says are used?
*
* WHY THIS EXISTS, AND WHY THE GENERATION CHECK CANNOT COVER IT. A response is
* capped at 14 packed `w|` lines (warehouse_core.lua:57-58), which is four to
* six rows each depending on how wide the numbers happen to be. A `stashall`
* that deposits more rows than that produces MORE delta rows than fit, and the
* ones past the cap are simply not sent -- the Mes buffer truncates silently,
* which is the same reason the server packs to well under it in the first
* place. The envelope that arrives is well-formed, its `k|` carries the NEW
* generation, and this addon dutifully records that generation as the one its
* model was built from. So the freshness check agrees with itself while the
* rows it never received are missing: staleness that looks exactly like health.
*
* THE COUNTS ARE THE SAME UNIT, WHICH IS THE WHOLE TRICK. One warehouse row is
* one used slot -- `used` in the `k|` record IS a row count
* (warehouse_core.lua:331) -- so the model disagreeing with it is proof of a
* gap without needing to know what was dropped or why. That makes this a
* general repair rather than a stashall special case: any future response that
* loses a row, for any reason, is caught by the same arithmetic.
*
* ONE REPAGE, NEVER A LOOP. If the sweep that repairs it comes back still
* disagreeing, the honest answer is a sentence -- a repage that re-arms itself
* on a disagreement it cannot fix is a twelve-command page walk every time the
* player touches anything. The latch clears the moment the counts agree, so a
* transient gap costs one sweep and nothing after it.
--]]
local function modelRowCount()
    local count = 0;

    for _ in pairs(state.rows) do
        count = count + 1;
    end

    return count;
end

local function verifyRowCount()
    -- OFF DURING THE INITIAL SWEEP, and off before one has ever been asked
    -- for. A page walk holds a legitimately partial model the whole way
    -- through -- every page's `k|` carries the account's FULL used count while
    -- only the pages seen so far are in `rows` -- so this arithmetic is
    -- guaranteed to disagree and would fire a sweep from inside a sweep.
    if (state.syncing or not state.synced) then
        return;
    end

    local held = modelRowCount();

    if (held == state.used) then
        state.repaired = false;

        return;
    end

    if (state.repaired) then
        -- statusBad, because headerStrip has exactly two colours and this
        -- sentence is a WARNING: rows the server holds are missing from the
        -- list in front of the player. Drawn in the confirmation green it read
        -- like 'Pulled 5.' -- the same failure dwbags.lua:581-587 records
        -- against its protocol-mismatch banner.
        state.status    = string.format('Showing %d of %d stored slots -- press Refresh.', held, state.used);
        state.statusBad = true;

        return;
    end

    state.repaired = true;

    startSync();
end

--[[
* Record parsing.
*
* Every record is pipe-separated with a single-character type. Anything this
* addon does not recognise is ignored rather than being an error: a server
* newer than the addon must not break it, which is the whole reason the `d|`
* record carries a protocol version.
--]]
local function split(text, sep)
    local parts = T{ };

    for piece in string.gmatch(text .. sep, '([^' .. sep .. ']*)' .. sep) do
        parts:append(piece);
    end

    return parts;
end

--[[
* The verbs whose response leaves the model current at whatever generation it
* carries -- this addon's own write landing, with the `w|`/`r|` rows that made
* it in the same envelope. A generation arriving with one of these is not a gap
* and must not trigger a repage of everything.
*
* `pin` and `unpin` are in the list defensively. R8 says every MUTATION bumps
* the counter and a pin changes no warehouse row, so they should not move it at
* all -- but if a future server counts them, a pin click must not cost a
* twelve-command page walk to discover that nothing changed.
--]]
local DELTA_VERBS = {
    put      = true,
    take     = true,
    trash    = true,
    stack    = true,
    stashall = true,
    pull     = true,
    pin      = true,
    unpin    = true,

    -- `buy` moves no rows but DOES bump the generation (capacity changed),
    -- and its own envelope carries the new `k|` -- so it is this addon's own
    -- write, not a gap another window caused. Without this a purchase would
    -- cost a twelve-command repage to rediscover an unchanged list.
    buy      = true,

    -- `sell` (1.9.0) trims or removes the row it listed and rides the delta
    -- in its own envelope, exactly as `trash` does.
    sell     = true,
};

--[[
* The subset of those that actually move rows, and so the ones whose closing
* `z|` is worth counting the model against the `k|` line (verifyRowCount).
*
* `pin` and `unpin` are deliberately NOT here even though they are delta verbs.
* A pin changes no warehouse row, so its envelope carries no `w|` at all and
* has nothing to truncate -- counting after one would only be asking the same
* question the last real mutation already answered.
--]]
local MUTATION_VERBS = {
    put      = true,
    take     = true,
    trash    = true,
    stack    = true,
    stashall = true,
    pull     = true,
    sell     = true,
};

-- `<rowid>:<itemid>:<qty>:<flags>:<bound>,...`
local function parsePacked(packed)
    state.modelRev = state.modelRev + 1;

    for _, entry in ipairs(split(packed, ',')) do
        local bits = split(entry, ':');

        if (#bits >= 5) then
            local rowid = tonumber(bits[1]) or 0;

            if (rowid > 0) then
                -- Upsert by row id: a `w|` from a delta replaces the row a
                -- page walk put there, and the two can never disagree about
                -- which row they mean.
                --
                -- `bound` is a legacy field: it used to be the charid a row
                -- was bound to, and since the lane was retired on 2026-08-08
                -- a migrated server always sends 0. It is still PARSED, and
                -- deliberately -- the record is five fields wide and reading
                -- four of them would silently accept a truncated line as a
                -- whole one. Nothing is drawn from it.
                state.rows[rowid] = {
                    rowid  = rowid,
                    itemid = tonumber(bits[2]) or 0,
                    qty    = tonumber(bits[3]) or 0,
                    flags  = tonumber(bits[4]) or 0,
                    bound  = tonumber(bits[5]) or 0,
                };
            end
        end
    end
end

local function handleRecord(line)
    local parts = split(line, '|');
    local kind  = parts[1];

    if (kind == 'd') then
        local version = tonumber(parts[2]) or 0;

        if (version ~= PROTOCOL) then
            state.status    = string.format('Server protocol %d, addon expects %d. Update dwwarehouse.', version, PROTOCOL);
            state.statusBad = true;
            state.inbound   = nil;

            -- A d| envelope IS the answer, whatever version it announced, and
            -- re-asking a server that speaks a layout this addon cannot read
            -- cannot help -- a page walk least of all. One shape across the
            -- suite (dwfame, 2026-08-15); gated in harness_dwsuite.py.
            for _, asked in pairs(requested) do
                if (type(asked) == 'table') then
                    asked.answered = true;
                end
            end

            return;
        end

        state.inbound = parts[3];

        -- The pin list is a full refresh, so it is emptied here rather than
        -- being rebuilt from the first `p|` line -- a list long enough to be
        -- split across two lines would otherwise only ever show its tail.
        -- THIS RUNS BEFORE ANYTHING ELSE THE `d|` RECORD DOES, because
        -- handleRecord is called under a pcall: anything that throws above
        -- this line leaves the old rows in place and the records behind it
        -- append to them (dwbags.lua:567-571).
        if (state.inbound == 'who' or state.inbound == 'pin' or state.inbound == 'unpin') then
            state.pins = {};
        end

        answered(state.inbound);

        return;
    end

    -- Status and error lines are accepted whatever the envelope state. They are
    -- the one thing a player must never lose: the sentence saying why a deposit
    -- was refused is worth more than the response it happened to arrive with.
    if (kind == 'm' or kind == 'e') then
        -- Everything after the first pipe, not parts[2]: these carry prose and
        -- an item name may contain anything.
        local text = line:sub(3);

        -- The server saying it cannot trash: either sentence latches the
        -- feature off for the session, so the buttons stop drawing instead of
        -- every click re-earning the same refusal. 'unknown verb "trash"' is
        -- an older server core; 'no trash verb' is a newer core over an older
        -- binary. Both mean the same thing to this window.
        if (kind == 'e' and (text:find('unknown verb "trash"', 1, true) ~= nil
                or text:find('no trash verb', 1, true) ~= nil)) then
            state.noTrash  = true;
            state.trashAsk = nil;
        end

        -- The stack verb's twin, same two sentences one verb over: 'unknown
        -- verb "stack"' is an older server core, 'no stack verb' a newer core
        -- over an older binary. Either latches the button off for the session.
        if (kind == 'e' and (text:find('unknown verb "stack"', 1, true) ~= nil
                or text:find('no stack verb', 1, true) ~= nil)) then
            state.noStack = true;
        end

        -- And the buy verb's, one verb over again. A pending confirmation is
        -- dropped with it -- the question it asks can no longer be answered.
        if (kind == 'e' and (text:find('unknown verb "buy"', 1, true) ~= nil
                or text:find('no buy verb', 1, true) ~= nil)) then
            state.noBuy  = true;
            state.buyAsk = false;
        end

        -- And the sell verb's (1.9.0). 'unknown verb "sell"' is an older
        -- server core; 'cannot sell to the market' is a newer core over an
        -- older binary. The open price strip goes with it.
        if (kind == 'e' and (text:find('unknown verb "sell"', 1, true) ~= nil
                or text:find('cannot sell to the market', 1, true) ~= nil)) then
            state.noSell  = true;
            state.sellAsk = nil;
        end

        -- A pull shortfall arrives as wire text -- 'short 4102:3,4238:1' --
        -- because the server does not own the name table; this addon does
        -- (the header's naming rule). Translate it before anyone reads it.
        if (kind == 'e') then
            local packed = text:match('^short (.+)$');

            if (packed ~= nil) then
                local names = {};

                for entry in string.gmatch(packed .. ',', '([^,]*),') do
                    local id, qty = entry:match('^(%d+):(%d+)$');

                    if (id ~= nil) then
                        names[#names + 1] = string.format('%s x%s', itemName(tonumber(id)), qty);
                    end
                end

                if (#names > 0) then
                    text = 'The warehouse came up short: ' .. table.concat(names, ', ')
                        .. '. Everything else was pulled.';
                end
            end
        end

        state.status    = text;
        state.statusBad = (kind == 'e');

        -- Also to the chat log: the window may not be open, and "nothing
        -- happened" is the worst possible feedback for a refused deposit.
        if (kind == 'e') then
            print(chat.header('dwwarehouse'):append(chat.error(state.status)));
        end

        return;
    end

    if (state.inbound == nil) then
        return;
    end

    if (kind == 'z') then
        local closed = state.inbound;

        state.inbound = nil;

        -- The sale-history envelope (1.11.0) commits here, the protocol's own
        -- discipline: a half-arrived list never reaches the tooltip.
        if (closed == 'history' and state.historyArriving ~= nil) then
            state.saleHistory = state.saleHistory or {};
            state.saleHistory[state.historyArriving.itemid] = { rows = state.historyArriving.rows, at = os.clock() };
            state.historyArriving = nil;
        end

        -- The envelope is complete, so this is the first moment the model can
        -- be counted against what the server just said it holds. Cleared
        -- FIRST: verifyRowCount may start a sweep, and a sweep must not begin
        -- with a stale verb still marked as arriving.
        if (MUTATION_VERBS[closed]) then
            verifyRowCount();
        end

        return;
    end

    if (kind == 'k') then
        state.used = tonumber(parts[2]) or 0;
        state.cap  = tonumber(parts[3]) or 0;

        local gen = tonumber(parts[4]) or 0;

        state.gen = gen;

        -- This addon's own write: the same response carries the rows that
        -- changed, so the model is current at the new generation already.
        if (DELTA_VERBS[state.inbound]) then
            state.syncGen = gen;
        end

        -- The first generation a sweep sees is the one that sweep is OF. Later
        -- pages may carry a higher one -- that is another client writing while
        -- this one reads -- and the pages already collected are then a list of
        -- a moment that has passed.
        if (state.syncing and state.sweepGen == nil) then
            state.sweepGen = gen;
        end

        return;
    end

    if (kind == 'w') then
        parsePacked(parts[2]);

        return;
    end

    -- b| -- the purchase tier's standing (1.7.0, server 2026-08-27; ADDITIVE,
    -- protocol still 1 -- an older server never sends it and the confirmation
    -- simply says less). On `who` and `buy` responses.
    if (kind == 'b') then
        state.bought = tonumber(parts[2]);
        state.buyMax = tonumber(parts[3]) or 1000;

        return;
    end

    -- s| -- the account's market standing (1.9.0, server 2026-09-01;
    -- ADDITIVE, protocol still 1). On `who` and `sell` responses. Its
    -- presence is what draws the Sell buttons: an older server never sends
    -- it, and a button that could only ever earn a refusal is not drawn.
    -- i| / y| -- an item's recent sales (1.11.0, server 2026-09-04): the Sell
    -- row's History button. i| names the item, the y| rows follow
    -- (price:date:stack:seller:buyer), and the list commits at z|.
    if (kind == 'i') then
        state.historyArriving = { itemid = tonumber(parts[2]) or 0, rows = {} };

        return;
    end

    if (kind == 'y') then
        if (state.historyArriving ~= nil) then
            local bits = split(parts[2] or '', ':');

            state.historyArriving.rows[#state.historyArriving.rows + 1] = {
                price  = tonumber(bits[1]) or 0,
                date   = tonumber(bits[2]) or 0,
                stack  = (tonumber(bits[3]) or 0) == 1,
                seller = bits[4] or '',
                buyer  = bits[5] or '',
            };
        end

        return;
    end

    if (kind == 's') then
        state.market = {
            fee      = tonumber(parts[2]) or 5,
            listings = tonumber(parts[3]) or 0,
            cap      = tonumber(parts[4]) or 0,
        };

        return;
    end

    -- a| -- augment values for rows THIS response carried (1.5.0, server
    -- 2026-08-25; ADDITIVE, protocol still 1 -- an older server never sends
    -- it and the card keeps its flag-4 "Augmented" note). Emitted after the
    -- w| lines, so the row exists by the time this runs; an entry that
    -- matches no row decorates nothing, the v|-to-c| rule.
    if (kind == 'a') then
        state.modelRev = state.modelRev + 1;

        for _, entry in ipairs(split(parts[2] or '', ',')) do
            local bits  = split(entry, ':');
            local rowid = tonumber(bits[1]) or 0;
            local row   = state.rows[rowid];

            if (row ~= nil) then
                local augs = T{ };

                -- Flat id:rank pairs; a torn pair at the end is dropped
                -- rather than half-read, and the server sends at most four.
                for index = 2, #bits - 1, 2 do
                    local id   = tonumber(bits[index]) or 0;
                    local rank = tonumber(bits[index + 1]) or 0;

                    if (id > 0 and rank > 0 and #augs < 4) then
                        augs:append({ id = id, rank = rank });
                    end
                end

                if (#augs > 0) then
                    row.augs = augs;
                end
            end
        end

        return;
    end

    if (kind == 'r') then
        state.modelRev = state.modelRev + 1;

        for _, entry in ipairs(split(parts[2], ',')) do
            local rowid = tonumber(entry) or 0;

            if (rowid > 0) then
                state.rows[rowid] = nil;
            end
        end

        return;
    end

    if (kind == 'p') then
        for _, entry in ipairs(split(parts[2], ',')) do
            local itemid = tonumber(entry) or 0;

            if (itemid > 0) then
                state.pins[itemid] = true;
            end
        end

        return;
    end

    if (kind == 'q') then
        local page  = tonumber(parts[2]) or 0;
        local pages = tonumber(parts[3]) or 0;

        state.pages     = pages;
        state.pagesSeen = page + 1;

        -- CLAMPED BEFORE IT BECOMES A COMMAND. A page count the addon
        -- misparsed would otherwise become an unbounded run of `!dww page N`
        -- lines at one every 1.2 seconds, which is a command loop wearing a
        -- sync's clothes. 1000 rows at 14 per page is 72 pages; 256 is room
        -- for a capacity grant several times over and still terminates.
        if (page + 1 < math.min(pages, 256)) then
            state.nextPage = page + 1;
        else
            state.nextPage = nil;
            state.syncing  = false;

            -- THE SWEEP IS ONLY EVER CLAIMED FOR THE GENERATION IT STARTED
            -- UNDER. If the account moved while it was walking, `gen` is now
            -- ahead of this and the render pass repages -- see MAX_RESWEEPS.
            -- The start generation is spent here (1.10.0): a page answer
            -- that lands OUTSIDE a sweep -- a `!warehouse page` typed by
            -- hand, a late page of a sweep already finished -- used to claim
            -- the model at a sweep long over and cost a twelve-command
            -- repage to learn nothing had moved.
            state.syncGen  = state.sweepGen or state.gen;
            state.sweepGen = nil;

            if (state.syncGen == state.gen) then
                state.resweeps = 0;
            end

            -- A sweep FORCED by the row-count check answers that check the
            -- moment it lands, rather than the answer waiting for whenever the
            -- player next moves something. Agreement clears the latch; a
            -- disagreement that survived a full repage takes the sentence,
            -- because `repaired` is already set and verifyRowCount will not
            -- sweep twice for it.
            if (state.repaired) then
                verifyRowCount();
            end
        end

        return;
    end
end

--[[
* GP_SERV_COMMAND_CHAT_STD, 0x017.
*
* Layout after the 4-byte header: Kind at 0x04, Attr at 0x05, Data at 0x06,
* sName[15] at 0x08, Mes at 0x17. Any line whose sender is _DWWDATA is ours: it
* is consumed here and the packet is blocked so the chat log never sees it.
--]]
ashita.events.register('packet_in', 'dwwarehouse_packet_in', function (e)
    if (e.id ~= 0x0017) then
        return;
    end

    local sender = e.data_modified:sub(0x09, 0x17):gsub('%z.*$', '');

    if (sender ~= DATA_SENDER) then
        return;
    end

    local message = e.data_modified:sub(0x18, e.size):gsub('%z.*$', '');

    -- The addon owns this line whatever happens to be in it, so it is blocked
    -- before parsing rather than after: a malformed record must not leak into
    -- the chat log as noise.
    e.blocked = true;

    local ok, err = pcall(handleRecord, message);

    if (not ok) then
        print(chat.header('dwwarehouse'):append(chat.error('bad record: ' .. tostring(err))));
    end
end);

--[[
* Kits.
*
* Stored as the `id:qty,id:qty` string `pull` already takes, keyed by name. One
* level of nesting with a scalar leaf, which is the shape dwmacro proved the
* settings serializer round-trips (`dwmacro.lua:270-296`) -- a kit is not worth
* finding out where the serializer's nested-array support ends, and the string
* IS the wire form, so there is one representation rather than two.
--]]
local default_settings = T{
    kits = T{ },

    -- The view (1.9.0): which sort, which category chip and whether Take
    -- moves the whole stack, remembered across sessions. One level of
    -- nesting with scalar leaves, the shape the serializer is known to
    -- round-trip. Client-side chrome, never world state: the server hears
    -- nothing about any of it.
    view = T{
        sort       = 1,
        category   = 1,
        wholeStack = true,
    },
};

local config = settings.load(default_settings);

-- The remembered view onto the live controls. Every field is clamped on the
-- way in -- the settings file is a text file a player can edit, and a sort
-- index past the table would index nil sixty times a second.
local function applyView()
    local view = type(config.view) == 'table' and config.view or { };

    local sort     = math.floor(tonumber(view.sort) or 1);
    local category = math.floor(tonumber(view.category) or 1);

    state.sort       = (sort >= 1 and sort <= #SORTS) and sort or 1;
    state.category   = (category >= 1 and category <= #CATEGORIES) and category or 1;
    state.takeAll[1] = view.wholeStack ~= false;
end

-- Called on a change, never per frame: settings.save writes a file.
local function saveView()
    if (type(config.view) ~= 'table') then
        config.view = T{ };
    end

    config.view.sort       = state.sort;
    config.view.category   = state.category;
    config.view.wholeStack = state.takeAll[1] and true or false;

    settings.save();
end

applyView();

settings.register('settings', 'dwwarehouse_settings_update', function (s)
    if (s ~= nil) then
        config = s;

        applyView();
    end

    settings.save();
end);

-- 1234567 -> 1,234,567 (dwah.lua's gilText): a price is the whole point of
-- the strip below, and an ungrouped million is a misread waiting to happen.
local function gilText(amount)
    local text = tostring(math.floor(tonumber(amount) or 0));
    local out  = '';

    while #text > 3 do
        out  = ',' .. text:sub(-3) .. out;
        text = text:sub(1, -4);
    end

    return text .. out;
end

-- What the seller keeps after the house's cut, from the fee the `s|` record
-- carried. Presentation only: the fee is charged in the server's trigger
-- when the listing sells, whichever door listed it.
local function netOf(price)
    local fee = state.market ~= nil and state.market.fee or 5;

    return price - math.floor(price * fee / 100);
end

-- How many of each item the model holds across every row, as one map -- the
-- number the Deposit tab's Stored column and the Kits tab's shortfall read.
-- Built once per MODEL CHANGE (cached against modelRev, 1.10.0), never per
-- row or per frame: eighty bag rows against a thousand-row model is eighty
-- thousand comparisons a frame the other way.
local countsCache = { rev = nil, counts = { } };

local function storedCounts()
    if (countsCache.rev == state.modelRev) then
        return countsCache.counts;
    end

    local counts = { };

    for _, row in pairs(state.rows) do
        counts[row.itemid] = (counts[row.itemid] or 0) + (tonumber(row.qty) or 0);
    end

    countsCache.rev    = state.modelRev;
    countsCache.counts = counts;

    return counts;
end

-- The client DAT's stack size and equip level for an item, for the sell
-- strip and the Level sort. Both default when the resource has nothing to
-- say, and neither is ever sent anywhere.
local function stackSizeOf(itemid)
    local item = AshitaCore:GetResourceManager():GetItemById(itemid);

    return (item ~= nil and tonumber(item.StackSize)) or 1;
end

local function itemLevel(itemid)
    local item = AshitaCore:GetResourceManager():GetItemById(itemid);

    if (item == nil) then
        return 0;
    end

    -- Item level outranks equip level where both exist: a 119 piece is a
    -- 99 piece with more on it, and it belongs above the plain 99s.
    local ilvl = tonumber(item.ItemLevel) or 0;

    if (ilvl > 0) then
        return ilvl;
    end

    return tonumber(item.Level) or 0;
end

local function kitNames()
    local names = T{ };

    if (type(config.kits) == 'table') then
        for name, _ in pairs(config.kits) do
            if (type(name) == 'string' and type(config.kits[name]) == 'string') then
                names:append(name);
            end
        end
    end

    table.sort(names);

    return names;
end

-- A kit name is a settings key and a widget id. Anything outside plain text
-- would make one of those two ambiguous, so it is trimmed to plain text here
-- rather than being rejected with a sentence nobody would read.
local function cleanKitName(raw)
    local name = tostring(raw or ''):gsub('[^%w%s%-]', ''):gsub('^%s+', ''):gsub('%s+$', '');

    return name:sub(1, KIT_NAME_MAX);
end

--[[
* Turn `id:qty,...` into `!dww pull` lines, none longer than PULL_BUDGET.
*
* SPLITTING IS THE POINT. The server's line budget is 130 bytes and a kit is
* whatever the player put in it, so a twenty-item kit has to become several
* commands. They queue like everything else, one per interval, and each one is
* answered on its own terms -- a shortfall in the second line does not undo the
* first, which is exactly what `pull`'s per-item shortfall reporting is for.
--]]
local function pullCommands(entries)
    local commands = T{ };
    local prefix   = '!dww pull ';
    local current  = '';

    for _, entry in ipairs(entries) do
        local piece     = string.format('%d:%d', entry.id, entry.qty);
        local candidate = (current == '') and piece or (current .. ',' .. piece);

        if (#prefix + #candidate > PULL_BUDGET) then
            if (current ~= '') then
                commands:append(prefix .. current);
            end

            current = piece;
        else
            current = candidate;
        end
    end

    if (current ~= '') then
        commands:append(prefix .. current);
    end

    return commands;
end

-- `id:qty,...` -> { { id, qty }, ... }, every field clamped. R7 applies to the
-- addon's own settings file too: it is a text file a player can edit.
local function parseKit(packed)
    local entries = T{ };

    for _, entry in ipairs(split(tostring(packed or ''), ',')) do
        local bits = split(entry, ':');

        if (#bits >= 2) then
            local id  = math.floor(tonumber(bits[1]) or 0);
            local qty = math.floor(tonumber(bits[2]) or 0);

            if (id > 0 and id < 65535) then
                entries:append({ id = id, qty = math.max(math.min(qty, 99), 1) });
            end
        end
    end

    return entries;
end

local function saveKit(name, entries)
    local clean = cleanKitName(name);

    if (clean == '' or #entries == 0) then
        -- SAY WHY. Both call sites put every side effect inside
        -- `if (saveKit(...))` with no else, so a bare `return false` made the
        -- button look dead -- and these two are the likeliest first attempts:
        -- an empty name box (its default) and a name typed with nothing ticked.
        state.status    = (clean == '') and 'Name the kit first.'
            or 'Nothing to save -- tick items on the Deposit tab.';
        state.statusBad = true;

        return false;
    end

    -- The settings file is a text file a player can edit, and an edit that
    -- removed the `kits` table would otherwise throw inside the render pcall
    -- and close the window. A missing table is an empty one.
    if (type(config.kits) ~= 'table') then
        config.kits = T{ };
    end

    local parts = T{ };

    for _, entry in ipairs(entries) do
        parts:append(string.format('%d:%d', entry.id, entry.qty));
    end

    config.kits[clean] = table.concat(parts, ',');
    settings.save();

    return true;
end

--[[
* Rendering
--]]

--[[
* Your own inventory, read straight out of client memory.
*
* THE SLOT AND THE ITEM ID BOTH GO ON THE WIRE and the server checks them
* against each other (R3, "bag changed"). This read can be stale -- a trade
* completing between the frame that drew the row and the frame that clicked it
* is enough -- and that staleness is precisely what the pair catches. So there
* is no cache here: the rows are re-read every frame the tab is open, and the
* worst outcome of a race is a refusal sentence.
--]]
local function inventoryRows()
    local rows = T{ };

    local memory = AshitaCore:GetMemoryManager();

    if (memory == nil) then
        return rows;
    end

    local inventory = memory:GetInventory();

    if (inventory == nil) then
        return rows;
    end

    for slot = 1, INVENTORY_SLOTS do
        local item = inventory:GetContainerItem(INVENTORY_CONTAINER, slot);

        if (item ~= nil and item.Id ~= nil and item.Id ~= 0 and item.Id ~= 65535
                and (item.Count or 0) > 0) then
            rows:append(T{
                slot   = slot,
                itemid = item.Id,
                qty    = item.Count,
                flags  = item.Flags or 0,
                -- The raw exdata bytes, kept for the hover card's augment
                -- lines (1.4.0). Nothing else reads them and nothing sends
                -- them anywhere.
                extra  = item.Extra,
            });
        end
    end

    return rows;
end

--[[
* Kit entries for the bag, MERGED BY ITEM rather than one per inventory slot.
*
* The selection model is by item id -- `selection[row.itemid]` -- but both Save
* buttons walked inventory ROWS, so an item spread over three slots wrote three
* entries with the same id from a single tick, and a kit that said "99 arrows"
* was really three lines that happened to add up. The stated contract further
* up this file ("one entry per item, at the quantity you hold") was the thing
* that was true of neither button.
*
* Merged and then re-split into <=99 chunks, because a single id:qty pair is
* capped at 99 on BOTH sides (this addon clamps, and the server's pull caps at
* 99 too). A plain merge-then-clamp would quietly turn two full stacks into
* one. `filter` nil means the whole bag.
--]]
local function kitEntriesFromBag(filter)
    local order  = T{ };
    local totals = { };

    for _, row in ipairs(inventoryRows()) do
        if (filter == nil or filter[row.itemid]) then
            if (totals[row.itemid] == nil) then
                order:append(row.itemid);
            end

            totals[row.itemid] = (totals[row.itemid] or 0)
                + math.max(math.floor(tonumber(row.qty) or 1), 1);
        end
    end

    local entries = T{ };

    for _, id in ipairs(order) do
        local left = totals[id];

        while (left > 0) do
            entries:append({ id = id, qty = math.min(left, 99) });
            left = left - 99;
        end
    end

    return entries;
end

--[[
* How many of a row to move: the whole stack by default, or the spin box.
*
* THE FLOOR IS 1 AND IT IS APPLIED HERE AS WELL AS AT THE WIDGET. `InputInt`
* takes any integer it is given, including negative ones, and a negative
* quantity has no meaning in either direction -- it is not "move backwards", it
* is a number that lands in a `uint32` on the server as four billion. The
* widget clamps what the player can see and this clamps what the command can
* carry, so the two would both have to fail for a nonsense number to be sent.
* (dwbags.lua:996-1016; the map-side lesson is R7.)
--]]
local function moveCount(qty)
    local held = math.max(math.floor(tonumber(qty) or 1), 1);

    if (state.takeAll[1]) then
        return held;
    end

    local wanted = math.floor(tonumber(state.takeQty[1]) or 1);

    return math.max(math.min(wanted, held), 1);
end

local function matchesCategory(itemid)
    local category = CATEGORIES[state.category];

    if (category == nil or category.all) then
        return true;
    end

    local kind = itemType(itemid);

    if (category.other) then
        for _, other in ipairs(CATEGORIES) do
            if (other.types ~= nil and other.types[kind]) then
                return false;
            end
        end

        return true;
    end

    return category.types[kind] == true;
end

local function matchesSearch(itemid)
    local query = tostring(state.search[1] or '');

    if (query == '') then
        return true;
    end

    -- Plain find, not a pattern: an item name may contain '(' or '-' and a
    -- player typing one must not get a Lua pattern error for their trouble.
    return lowerName(itemid):find(query:lower(), 1, true) ~= nil;
end

--[[
    Render pagination (1.8.0, owner report: a warehouse holding hundreds to
    thousands of rows tanked the frame rate -- every filtered row was ~7
    widgets a frame). The DRAW is sliced to RENDER_PAGE rows; filtering and
    sorting still run over the WHOLE model inside visibleRows, so Find and
    the category chips search every page -- only what is submitted to ImGui
    is bounded. The page number is client-side chrome, not world state
    (dwgambits' presetPage rule): a plain local, surviving Refresh, never in
    `state`, reset to 1 whenever the filter, category or sort changes so a
    narrowed list is never left staring at an empty late page.

    300 rows a page since 1.10.0 (500 before): the owner's second report,
    with the list still heavy at hundreds of items. Find still searches
    every page -- the filter runs over the whole model, only the draw is
    sliced.
--]]
local RENDER_PAGE = 300;
local viewPage    = 1;

-- What the view was filtered by last frame; a change from anywhere -- typing,
-- the clear x, a chip -- resets the page in one place.
local lastFilterKey = '';

--[[
    The model, filtered and ordered -- REBUILT ONLY WHEN SOMETHING CHANGED
    (1.10.0). It used to be rebuilt every frame, and at a thousand rows that
    was a thousand filter tests and a ten-thousand-comparison sort sixty
    times a second, each comparison two resource-manager lookups: the frame
    rate the owner reported. `state.modelRev` moves on every write to the
    model (a page landing, a delta, a removal, an augment decoration, a
    reset), and the view is cached against it and the filter key; typing in
    Find changes the key and rebuilds at once, so the search still filters
    as you type -- it just does not re-sort an unchanged list in between
    keystrokes.
--]]
local viewCache = { key = nil, rows = T{ } };

local function visibleRows()
    local mode = SORTS[state.sort] ~= nil and SORTS[state.sort].name or 'Name';
    local key  = string.format('%d|%s|%d|%s', state.modelRev, tostring(state.search[1] or ''), state.category or 1, mode);

    if (viewCache.key == key) then
        return viewCache.rows;
    end

    local rows = T{ };

    for _, row in pairs(state.rows) do
        if (matchesCategory(row.itemid) and matchesSearch(row.itemid)) then
            rows:append(row);
        end
    end

    -- Every comparator ends on row id. Lua's table.sort is not stable, so two
    -- rows that compare equal can swap places on every sort -- and sorting in
    -- the render pass means that is sixty times a second, which is the flicker
    -- that made dwbags' Gear tab unreadable (dwbags.lua:781-787).
    table.sort(rows, function (a, b)
        if (mode == 'Newest') then
            return a.rowid > b.rowid;
        end

        if (mode == 'Qty' and a.qty ~= b.qty) then
            return a.qty > b.qty;
        end

        if (mode == 'Level') then
            local levelA = itemLevel(a.itemid);
            local levelB = itemLevel(b.itemid);

            if (levelA ~= levelB) then
                return levelA > levelB;
            end
        end

        if (mode == 'Type') then
            local typeA = itemType(a.itemid);
            local typeB = itemType(b.itemid);

            if (typeA ~= typeB) then
                return typeA < typeB;
            end
        end

        local nameA = itemName(a.itemid);
        local nameB = itemName(b.itemid);

        if (nameA ~= nameB) then
            return nameA < nameB;
        end

        return a.rowid < b.rowid;
    end);

    viewCache.key  = key;
    viewCache.rows = rows;

    return rows;
end

-- The greyed tags beside a name, rendered the way dwbags renders 'worn' and
-- 'placed' (dwbags.lua:1077-1095): a fact about the row, in the place a button
-- would otherwise be misread as available.
local function rowTags(row)
    local tags = T{ };

    if (bit.band(row.flags, WH_RARE) ~= 0) then
        tags:append('rare');
    end

    if (bit.band(row.flags, WH_EX) ~= 0) then
        tags:append('ex');
    end

    if (bit.band(row.flags, WH_AUGMENTED) ~= 0) then
        tags:append('aug');
    end

    -- A 'bound' tag stood here, drawn from bits 8/16. Both retired with the
    -- lane on 2026-08-08; the 'ex' and 'aug' tags above still say everything
    -- true about such a row, and neither of them implies it cannot move.

    return table.concat(tags, ' ');
end

local function capacityBar()
    local cap      = math.max(state.cap, 1);
    local fraction = math.min(state.used / cap, 1.0);

    imgui.PushItemWidth(220);
    -- 22 tall rather than 14: the overlay text is drawn at the font's full
    -- line height, so a bar shorter than that clipped the '323 / 1000 slots'
    -- label top and bottom.
    imgui.ProgressBar(fraction, { 220, 22 }, string.format('%d / %d slots', state.used, state.cap));
    imgui.PopItemWidth();

    imgui.SameLine();
end

--[[
* The header strip: capacity, freshness, and the three controls that narrow the
* list. They live above the tab bar rather than inside the Warehouse tab
* because the search box is the fastest way to find a row to Take AND the
* fastest way to check whether something is already stored before stashing a
* second copy -- it belongs to both tabs, so it belongs to neither.
--]]
local function headerStrip()
    capacityBar();

    -- The purchase button (1.7.0, server 2026-08-27). NEVER SENDS ON ITS
    -- OWN, the Trash rule for money: the click only opens the question, and
    -- the command is issued by the confirmation popup below -- 100,000 gil
    -- on a misclick would be this window's worst bug. Gated by its latch
    -- exactly as the Trash buttons are; at the ceiling it stops drawing and
    -- the tooltip's fact moves into the bar's own hover.
    if (not state.noBuy) then
        if (state.bought ~= nil and state.bought >= state.buyMax) then
            imgui.TextDisabled('all bought');

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format(
                    'Your account owns all %d purchasable slots.', state.buyMax));
            end
        else
            if (imgui.SmallButton('Buy Slot##dww_buy')) then
                state.buyAsk = true;
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Buy +1 maximum warehouse slot for 100,000 gil.\n'
                    .. 'Asks first. Up to 1,000 slots can be bought, ever.');
            end
        end

        imgui.SameLine();
    end

    if (imgui.Button('Refresh##dww_refresh')) then
        -- A player pressing this is saying "try again", so the resweep budget
        -- AND the row-count latch both start over: neither give-up sentence
        -- may be permanent.
        state.resweeps = 0;
        state.repaired = false;

        startSync();
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Ask the server for the whole list again.\n'
            .. 'Normally unnecessary -- every change answers with the rows it changed.');
    end

    imgui.SameLine();

    -- A generation this addon did not cause: another client on the same
    -- account moved something. Said out loud AND repaired on the next frame,
    -- because a number that is quietly wrong is the worst shape a bug has.
    if (state.gen ~= state.syncGen and not state.syncing) then
        imgui.TextColored(theme.colors.warn, 'Changed elsewhere -- refreshing.');
    elseif (state.syncing) then
        imgui.TextDisabled(string.format('loading %d/%s...',
            state.pagesSeen, state.pages ~= nil and tostring(state.pages) or '?'));
    elseif (#queue > 0) then
        imgui.TextDisabled(string.format('%d queued...', #queue));
    else
        imgui.TextDisabled('');
    end

    -- The market standing (1.9.0), beside the freshness note: how many
    -- listings the account has up and the cap the Sell buttons work under.
    -- Drawn only from a real `s|` record -- a server without the lane says
    -- nothing here, and so does this.
    if (state.market ~= nil and not state.noSell) then
        imgui.SameLine();
        imgui.TextDisabled(string.format('Market: %d of %d listed, fee %d%%',
            state.market.listings, state.market.cap, state.market.fee));

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Listings your account has up on the market, across both stores.\n'
                .. 'Every shelf row has a Sell button: it lists straight from the warehouse,\n'
                .. 'free, and the house takes its cut only when it sells. /dwah shows them.');
        end
    end

    -- THE MESSAGE LINE GETS ITS OWN ROW, AND ERRORS ARE RED. Every refusal is a
    -- rule with a reason -- capacity, Rare on the way out, a full inventory --
    -- and that reason is the only thing telling a player what to do instead
    -- (dwbags.lua:1777-1783).
    if (state.status ~= nil and state.status ~= '') then
        if (state.statusBad) then
            imgui.TextColored(theme.colors.err, state.status);
        else
            imgui.TextColored(theme.colors.ok, state.status);
        end
    end

    imgui.Text('Find:');
    imgui.SameLine();
    imgui.PushItemWidth(200);

    -- No EnterReturnsTrue: the filter is local, so it applies as it is typed
    -- and nothing is sent for it. The one control in this window that costs
    -- the server nothing should also cost the player no keystroke.
    imgui.InputText('##dww_search', state.search, 64);
    imgui.PopItemWidth();

    -- One click back to the whole list. Only drawn while there is something to
    -- clear, so the header does not carry a dead button the rest of the time.
    if (state.search[1] ~= '') then
        imgui.SameLine();

        if (imgui.SmallButton('x##dww_search_clear')) then
            state.search[1] = '';
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Clear the search.');
        end
    end

    for index, category in ipairs(CATEGORIES) do
        imgui.SameLine();

        local label = category.name;

        if (state.category == index) then
            label = '[' .. label .. ']';
        end

        if (imgui.SmallButton(string.format('%s##dww_cat_%d', label, index))) then
            if (state.category ~= index) then
                state.category = index;

                saveView();
            end
        end
    end

    imgui.SameLine();
    imgui.PushItemWidth(90);

    local sortName = SORTS[state.sort] ~= nil and SORTS[state.sort].name or 'Name';

    if (imgui.BeginCombo('##dww_sort', sortName)) then
        for index, sort in ipairs(SORTS) do
            if (imgui.Selectable(sort.name, state.sort == index)) then
                if (state.sort ~= index) then
                    state.sort = index;

                    saveView();
                end
            end
        end

        imgui.EndCombo();
    end

    imgui.PopItemWidth();

    imgui.SameLine();

    if (imgui.Checkbox('Whole stack##dww_all', state.takeAll)) then
        saveView();
    end

    if (not state.takeAll[1]) then
        imgui.SameLine();
        imgui.PushItemWidth(90);
        imgui.InputInt('##dww_qty', state.takeQty, 1, 10);
        imgui.PopItemWidth();

        -- ImGui's InputInt has no lower bound of its own -- the minus button
        -- and the keyboard will both take it below zero and leave it there --
        -- so the bound is applied to the buffer every frame. Done here as well
        -- as inside moveCount so the player never sees a number the window
        -- would not act on.
        if ((tonumber(state.takeQty[1]) or 1) < 1) then
            state.takeQty[1] = 1;
        end
    end

    --[[
        The purchase confirmation. OPENED EVERY FRAME THE QUESTION IS PENDING,
        the trash popup's modality: ImGui closes a popup on any outside click,
        and a silently dropped money question would leave the player unsure
        whether they just spent 100k. The copy is the contract, spelled out:
        what it costs, exactly what it buys (+1 slot, nothing else), and how
        many times it can ever be done -- the owner's requirement that nobody
        finds out AFTER paying that 100,000 gil bought one slot.
    ]]
    if (state.buyAsk) then
        imgui.OpenPopup('##dww_confirm_buy');
    end

    if (imgui.BeginPopup('##dww_confirm_buy')) then
        if (not state.buyAsk) then
            imgui.CloseCurrentPopup();
        else
            imgui.Text('Buy one warehouse slot for 100,000 gil?');
            imgui.TextDisabled('You get exactly +1 maximum warehouse storage. Nothing else.');
            imgui.TextDisabled(string.format('An account can buy at most %d slots, ever.', state.buyMax));

            if (state.bought ~= nil) then
                imgui.TextDisabled(string.format('This account has bought %d of %d so far.',
                    state.bought, state.buyMax));
            end

            imgui.TextDisabled('The gil is spent for good. This cannot be refunded.');

            if (imgui.Button('Buy for 100,000 gil##dww_buy_yes')) then
                issue('!dww buy');

                state.buyAsk = false;
                imgui.CloseCurrentPopup();
            end

            imgui.SameLine();

            if (imgui.Button('Cancel##dww_buy_no')) then
                state.buyAsk = false;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end
end

local function warehouseTab()
    local rows = visibleRows();

    -- NON-DESTRUCTIVE, SO NO CONFIRMATION. Nothing is created or lost -- the
    -- server shuffles quantities between rows of the same item and deletes
    -- only rows the shuffle emptied -- so unlike Trash and Stash All this is
    -- a plain click. Gated by its latch exactly as the Trash buttons are.
    if (not state.noStack) then
        if (imgui.Button('Stack Items##dww_stack')) then
            issue('!dww stack');
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Combine partial stacks of the same item into full ones --\n'
                .. '11 and 6 become 12 and 5, and rows left empty are freed.\n'
                .. 'Signed and augmented copies keep their own rows.');
        end

        imgui.SameLine();
        imgui.TextDisabled('Combine partial stacks of the same item.');
    end

    if (state.cap == 0 and not state.syncing) then
        imgui.TextDisabled('Nothing loaded yet. Refresh asks the server for the list.');
    end

    --[[
        The sell strip (1.9.0): the row whose Sell button was pressed, its
        price box, what the seller keeps, and the List buttons -- dwah's own
        Sell tab shape, above the table so it cannot collide with the row
        that opened it. THE STRIP IS THE DELIBERATE ACT: a price typed and a
        List button pressed. There is no popup on top, because a listing is
        reversible (the market's Cancel puts it back in a bag) -- unlike Trash,
        where the popup exists because nothing brings the item back.

        The row is re-read from the model every frame: a delta from another
        window may have trimmed or removed it between the click and the
        press, and the strip then closes rather than sending a stale row id
        (the server would refuse it anyway; this just says so sooner).
    ]]
    if (state.sellAsk ~= nil) then
        local ask = state.sellAsk;
        local row = state.rows[ask.rowid];

        if (row == nil or state.noSell or state.market == nil) then
            state.sellAsk = nil;
        else
            drawIcon(row.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(string.format('Selling %s%s:', itemName(row.itemid),
                row.qty > 1 and string.format(' (x%d stored)', row.qty) or ''));
            cardOnHover(row.itemid, hovered,
                bit.band(row.flags or 0, WH_AUGMENTED) ~= 0 and (row.augs or true) or nil);

            imgui.SameLine();
            imgui.PushItemWidth(120);
            imgui.InputText(string.format('##dww_price%d', row.rowid), state.sellPrice, 10);
            imgui.PopItemWidth();

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('The asking price, in gil, for the whole listing.');
            end

            imgui.SameLine();

            -- Digits only: a comma or a space typed into the box would read
            -- as zero and the buttons would simply not appear, which is the
            -- honest answer but not a helpful one, so the strip says why.
            local typed = tostring(state.sellPrice[1] or '');
            local price = math.floor(tonumber(typed) or 0);

            if (typed ~= '' and typed:match('^%d+$') == nil) then
                imgui.TextColored(theme.colors.err, 'digits only');
            elseif (price > 0 and price <= MAX_PRICE) then
                imgui.TextDisabled(string.format('you get %s', gilText(netOf(price))));
                imgui.SameLine();

                if (imgui.Button(string.format('List single##dww_sell1_%d', row.rowid))) then
                    issue(string.format('!dww sell %d %d', row.rowid, price));

                    state.sellAsk = nil;
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('List one %s at %s gil.%s',
                        itemName(row.itemid), gilText(price),
                        row.qty > 1 and ' The rest stays on the shelf.' or ''));
                end

                -- A stack listing is the WHOLE stack or nothing (the market's
                -- full-stack rule), so the button exists only for a row that
                -- holds exactly one.
                local stackSize = stackSizeOf(row.itemid);

                if (state.sellAsk ~= nil and stackSize > 1 and row.qty == stackSize) then
                    imgui.SameLine();

                    if (imgui.Button(string.format('List stack##dww_sell12_%d', row.rowid))) then
                        issue(string.format('!dww sell %d %d stack', row.rowid, price));

                        state.sellAsk = nil;
                    end

                    if (imgui.IsItemHovered()) then
                        imgui.SetTooltip(string.format('List the whole stack of %d at %s gil for the lot.',
                            stackSize, gilText(price)));
                    end
                end
            elseif (price > MAX_PRICE) then
                imgui.TextColored(theme.colors.err, 'too high -- 999,999,999 at most');
            else
                imgui.TextDisabled('price?');
            end

            if (state.sellAsk ~= nil) then
                imgui.SameLine();

                if (imgui.Button('Never mind##dww_sell_no')) then
                    state.sellAsk = nil;
                end
            end

            -- History (1.11.0, owner request): hover = the last five sales,
            -- asked once over this wire (`!dww history`, the market's own rows
            -- served by the warehouse core); click = the market window's
            -- History tab on this item, through dwah's own command.
            if (state.sellAsk ~= nil) then
                imgui.SameLine();

                if (imgui.Button('History##dww_sell_hist')) then
                    -- Through dwecho, like every line this addon sends (the
                    -- suite-wide rule); a slash command rides the same queue.
                    echo.send(string.format('/dwah history %d', row.itemid));
                end

                if (imgui.IsItemHovered()) then
                    local known = state.saleHistory and state.saleHistory[row.itemid] or nil;

                    if (known == nil) then
                        state.historyAsked = state.historyAsked or {};

                        if ((os.clock() - (state.historyAsked[row.itemid] or -100)) > 20) then
                            state.historyAsked[row.itemid] = os.clock();
                            issue(string.format('!dww history %d', row.itemid));
                        end

                        imgui.SetTooltip('Asking the market for recent sales... Click to open the full history in the market window.');
                    elseif (#known.rows == 0) then
                        imgui.SetTooltip('No recorded sales yet. Click to open the market window on its History tab.');
                    else
                        local lines = {};

                        for i, sale in ipairs(known.rows) do
                            if (i > 5) then break; end

                            lines[#lines + 1] = string.format('%s gil%s -- %s', gilText(sale.price),
                                sale.stack and ' (stack)' or '', os.date('%Y-%m-%d', sale.date));
                        end

                        lines[#lines + 1] = 'Click for the full history in the market window.';
                        imgui.SetTooltip(table.concat(lines, '\n'));
                    end
                end
            end
        end
    end

    -- Any change to what the list is filtered or ordered by resets the page.
    -- Watched here rather than at each widget because the search box has no
    -- reliable change return across imgui bindings, and the clear x, the
    -- chips and the sort all funnel through the same three fields anyway.
    local filterKey = string.format('%s|%d|%d', state.search[1] or '', state.category or 1, state.sort or 1);

    if (filterKey ~= lastFilterKey) then
        lastFilterKey = filterKey;
        viewPage      = 1;
    end

    -- The render slice. Clamped both ends every frame (dwgambits' shape):
    -- a list that shrank -- a trash, a narrower search -- pulls the page
    -- back into range instead of stranding the view past the end.
    local pages = math.max(1, math.ceil(#rows / RENDER_PAGE));

    if (viewPage > pages) then
        viewPage = pages;
    end

    if (viewPage < 1) then
        viewPage = 1;
    end

    local first = (viewPage - 1) * RENDER_PAGE + 1;
    local last  = math.min(#rows, first + RENDER_PAGE - 1);

    -- Said when the filter is hiding something ('showing all N' is noise,
    -- but a search that matched nothing looks exactly like an empty
    -- warehouse), AND whenever there is more than one render page -- a
    -- bounded view with no count line reads as the whole warehouse.
    local held = modelRowCount();

    if (#rows < held or pages > 1) then
        if (pages > 1) then
            imgui.TextDisabled(string.format('Showing %d-%d of %d%s.', first, last, #rows,
                #rows < held and ' matching (filtered)' or ' stored items'));
        else
            imgui.TextDisabled(string.format('Showing %d of %d stored items (filtered).', #rows, held));
        end
    end

    if (pages > 1) then
        imgui.SameLine();

        if (imgui.SmallButton('<##dww_page_prev') and viewPage > 1) then
            viewPage = viewPage - 1;
        end

        imgui.SameLine();
        imgui.TextDisabled(string.format('page %d of %d', viewPage, pages));
        imgui.SameLine();

        if (imgui.SmallButton('>##dww_page_next') and viewPage < pages) then
            viewPage = viewPage + 1;
        end
    end

    if (imgui.BeginTable('##dww_rows', 4,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthFixed, 300, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 45, 0);
        imgui.TableSetupColumn('Tags', ImGuiTableColumnFlags_WidthFixed, 130, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 150, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for rowIndex = first, last do
            local row = rows[rowIndex];

            imgui.TableNextRow();
            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(itemName(row.itemid));
            -- A shelf row's values ride the a| record when the blob is a
            -- standard augment blob (1.5.0); a flagged row the server sent
            -- no values for -- old server, signed or charged copy -- still
            -- says "Augmented" and invents nothing.
            cardOnHover(row.itemid, hovered,
                bit.band(row.flags or 0, WH_AUGMENTED) ~= 0 and (row.augs or true) or nil);

            imgui.TableNextColumn();
            imgui.Text(row.qty > 1 and string.format('x%d', row.qty) or '');

            imgui.TableNextColumn();

            local tags = rowTags(row);

            if (tags ~= '') then
                imgui.TextDisabled(tags);
            else
                imgui.Text('');
            end

            imgui.TableNextColumn();

            -- EVERY WIDGET ID CARRIES THE ROW ID. Two rows of the same item --
            -- which is the normal outcome of depositing a stack twice -- would
            -- otherwise share a `##<itemid>` suffix, and ImGui answers a
            -- conflicting id by merging their click handling
            -- (dwbags.lua:1018-1026).
            --
            -- EVERY ROW GETS A TAKE BUTTON NOW. A row whose bit 8 was set used
            -- to draw the words 'another character' and a tooltip instead, and
            -- that branch went with the lane on 2026-08-08: the server refuses
            -- no row on ownership grounds short of the account itself, and the
            -- account's rows are the only rows this window is ever sent.
            local count = moveCount(row.qty);

            if (imgui.SmallButton(string.format('Take##t%d', row.rowid))) then
                issue(string.format('!dww take %d %d', row.rowid, count));
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Take %d into your inventory.', count));
            end

            -- NEVER SENDS ON ITS OWN. The click only records what the player
            -- pointed at; the command is issued by the confirmation popup
            -- below, which is the whole reason the popup exists -- this is the
            -- one button in the window whose mistake cannot be undone.
            if (not state.noTrash) then
                imgui.SameLine();

                if (imgui.SmallButton(string.format('Trash##x%d', row.rowid))) then
                    state.trashAsk = {
                        rowid  = row.rowid,
                        itemid = row.itemid,
                        qty    = count,
                        flags  = row.flags,
                        augs   = row.augs,
                    };
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip(string.format('Throw %d away, straight from the warehouse.\n'
                        .. 'No inventory space needed. Asks first -- this cannot be undone.', count));
                end
            end

            --[[
                The Sell button (1.9.0). Drawn only when the server has said
                it can (the `s|` record) and not latched off, and not for a
                row the market's gate would refuse on sight: an EX copy never
                lists, and a row whose blob decoded to real augments is
                account-exclusive (D9). A flag-4 row WITHOUT decoded augments
                -- a signed or charged copy -- still draws it: those list
                legally, into the market's blob lane. The server re-decides
                every one of these from the bytes; this is only the addon
                declining to draw a button it knows would fail.
            ]]
            local sellable = state.market ~= nil and not state.noSell
                and bit.band(row.flags or 0, WH_EX) == 0
                and row.augs == nil;

            if (sellable) then
                imgui.SameLine();

                if (imgui.SmallButton(string.format('Sell##s%d', row.rowid))) then
                    state.sellAsk      = { rowid = row.rowid, itemid = row.itemid };
                    state.sellPrice[1] = '';
                end

                if (imgui.IsItemHovered()) then
                    imgui.SetTooltip('List it on the market straight from the warehouse --\n'
                        .. 'no bag slot needed. Listing is free; the house takes its cut when it sells.\n'
                        .. 'Cancel it later from /dwah and it comes back into a bag.');
                end
            end
        end

        imgui.EndTable();
    end

    --[[
        The trash confirmation. OPENED EVERY FRAME THE QUESTION IS PENDING:
        ImGui closes a popup on any outside click, and silently dropping the
        question would leave the player unsure whether the item is gone. While
        `trashAsk` is set the popup re-opens, so the only ways out are the two
        buttons -- which is exactly the modality a destructive action wants.
        Opened HERE, outside the table, because BeginTable pushes an ID scope
        and a popup opened inside it could not be begun outside it.
    ]]
    if (state.trashAsk ~= nil) then
        imgui.OpenPopup('##dww_confirm_trash');
    end

    if (imgui.BeginPopup('##dww_confirm_trash')) then
        local ask = state.trashAsk;

        if (ask == nil) then
            imgui.CloseCurrentPopup();
        else
            drawIcon(ask.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(string.format('Throw away %s x%d?', itemName(ask.itemid), ask.qty));
            -- The card inside the trash confirmation is the last look at
            -- what is about to be deleted -- exactly where it earns itself,
            -- values included when the shelf row carried them.
            cardOnHover(ask.itemid, hovered,
                bit.band(ask.flags or 0, WH_AUGMENTED) ~= 0 and (ask.augs or true) or nil);

            -- The tags are the last chance to notice this is the irreplaceable
            -- copy. Red, because 'rare' next to a delete button is a warning,
            -- not a fact.
            if (bit.band(ask.flags, WH_RARE + WH_EX + WH_AUGMENTED) ~= 0) then
                local tags = T{ };

                if (bit.band(ask.flags, WH_RARE) ~= 0) then tags:append('rare'); end
                if (bit.band(ask.flags, WH_EX) ~= 0) then tags:append('ex'); end
                if (bit.band(ask.flags, WH_AUGMENTED) ~= 0) then tags:append('augmented'); end

                imgui.TextColored(theme.colors.err,
                    string.format('This item is %s. It may be hard or impossible to replace.',
                        table.concat(tags, ', ')));
            end

            imgui.TextDisabled('It is destroyed for good. Nothing can bring it back.');

            if (imgui.Button(string.format('Throw away##dww_trash_yes'))) then
                issue(string.format('!dww trash %d %d', ask.rowid, ask.qty));

                state.trashAsk = nil;
                imgui.CloseCurrentPopup();
            end

            imgui.SameLine();

            if (imgui.Button('Cancel##dww_trash_no')) then
                state.trashAsk = nil;
                imgui.CloseCurrentPopup();
            end
        end

        imgui.EndPopup();
    end
end

local function depositTab()
    local rows = inventoryRows();

    -- The header strip's Find box filters HERE too (2026-08-26, player
    -- request) -- the box always belonged to both tabs (see headerStrip),
    -- it just never reached this one. Filtered at the DRAW loop and never
    -- inside inventoryRows(): "Save whole bag" and Stash All read the real
    -- bag, and a filter that quietly shrank a kit or a stash-all would be
    -- moving items the player never asked about. The count line says when
    -- the list is narrowed, exactly as the Warehouse tab's does.
    local shown = rows;

    if (state.search[1] ~= '') then
        shown = T{ };

        for _, row in ipairs(rows) do
            if (matchesSearch(row.itemid)) then
                shown:append(row);
            end
        end
    end

    if (imgui.Button('Stash All##dww_stashall')) then
        imgui.OpenPopup('##dww_confirm_stashall');
    end

    imgui.SameLine();
    imgui.TextDisabled('Everything the server will take, in one command.');

    -- The confirmation is a popup rather than a second click on the same
    -- button, because the list this empties is the one a player is holding and
    -- the copy below is the only place the exceptions are written down.
    if (imgui.BeginPopup('##dww_confirm_stashall')) then
        imgui.Text('Stash everything in your inventory?');
        imgui.TextDisabled('Skipped, and left in your bag:');
        imgui.TextDisabled('  equipped, bazaared or reserved items');
        imgui.TextDisabled('  rare, EX and augmented copies');
        imgui.TextDisabled('  linkshells you are wearing, gil and currency');
        imgui.TextDisabled('  anything you have pinned on this tab');
        imgui.TextDisabled('It stops at capacity and says how many it took.');

        if (imgui.Button('Stash All##dww_confirm_yes')) then
            issue('!dww stashall');
            imgui.CloseCurrentPopup();
        end

        imgui.SameLine();

        if (imgui.Button('Cancel##dww_confirm_no')) then
            imgui.CloseCurrentPopup();
        end

        imgui.EndPopup();
    end

    --[[
        Stash ticked (1.9.0): every ticked item, every slot that holds it,
        one `!dww put` per slot -- the tick that used to exist only to save a
        kit now moves things too. Whole slots always, whatever the Whole
        stack box says: a tick is "this item", not "some of this item", and
        a partial move of five slots would be five refusals to read. Each
        line is its own command with its own answer, so one refused slot
        (a rare copy, a full shelf) never undoes the others. Reads the REAL
        bag, never the filtered view -- the Stash All rule.
    ]]
    local ticked = 0;

    for _, row in ipairs(rows) do
        if (selection[row.itemid] == true) then
            ticked = ticked + 1;
        end
    end

    if (ticked > 0) then
        imgui.SameLine();

        -- Counted in SLOTS, because that is how many commands the press
        -- sends: two slots of the same ticked arrow are two puts.
        if (imgui.Button(string.format('Stash ticked (%d slot%s)##dww_stash_ticked',
                ticked, ticked == 1 and '' or 's'))) then
            for _, row in ipairs(rows) do
                if (selection[row.itemid] == true) then
                    issue(string.format('!dww put %d %d %d', row.slot, row.itemid,
                        math.max(math.floor(tonumber(row.qty) or 1), 1)));
                end
            end

            selection = {};
        end

        if (imgui.IsItemHovered()) then
            imgui.SetTooltip('Put every ticked item into the warehouse, whole slots,\n'
                .. 'one command per slot -- a refused slot never stops the rest.');
        end

        imgui.SameLine();

        if (imgui.SmallButton('Clear ticks##dww_clear_ticks')) then
            selection = {};
        end
    end

    if (#shown < #rows) then
        imgui.TextDisabled(string.format('Showing %d of %d bag items (filtered).', #shown, #rows));
    end

    local stored = storedCounts();

    if (imgui.BeginTable('##dww_deposit', 6,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 26, 0);
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthFixed, 280, 0);
        imgui.TableSetupColumn('#', ImGuiTableColumnFlags_WidthFixed, 45, 0);
        -- How many the shelf already holds (1.9.0): the answer to "do I
        -- already have some of these stashed", read off the model rather
        -- than off a second search box.
        imgui.TableSetupColumn('Stored', ImGuiTableColumnFlags_WidthFixed, 70, 0);
        imgui.TableSetupColumn('Pin', ImGuiTableColumnFlags_WidthFixed, 60, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 90, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        for _, row in ipairs(shown) do
            imgui.TableNextRow();
            imgui.TableNextColumn();

            -- The tick is what "save selection as kit" reads. Keyed by SLOT in
            -- the widget id and by ITEM ID in the set: two slots holding the
            -- same item are one line in a kit, and a kit names items.
            local ticked = T{ selection[row.itemid] == true };

            if (imgui.Checkbox(string.format('##dww_sel_%d', row.slot), ticked)) then
                selection[row.itemid] = ticked[1] and true or nil;
            end

            imgui.TableNextColumn();

            drawIcon(row.itemid, 20);

            local hovered = imgui.IsItemHovered();

            imgui.Text(itemName(row.itemid));
            -- A deposit row is the client's own item: the card gets the
            -- decoded augment slots, values included.
            cardOnHover(row.itemid, hovered, extraAugments(row.extra));

            imgui.TableNextColumn();
            imgui.Text(row.qty > 1 and string.format('x%d', row.qty) or '');

            imgui.TableNextColumn();

            local held = stored[row.itemid] or 0;

            if (held > 0) then
                imgui.TextDisabled(string.format('%d stored', held));
            else
                imgui.Text('');
            end

            imgui.TableNextColumn();

            local pinned = state.pins[row.itemid] == true;

            if (imgui.SmallButton(string.format('%s##dww_pin_%d', pinned and 'unpin' or 'pin', row.slot))) then
                issue(string.format('!dww %s %d', pinned and 'unpin' or 'pin', row.itemid));
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Pinned items are never taken by Stash All.\n'
                    .. 'Pins are per character -- a mule and a main stash differently.');
            end

            imgui.TableNextColumn();

            local count = moveCount(row.qty);

            if (imgui.SmallButton(string.format('Stash##d%d', row.slot))) then
                issue(string.format('!dww put %d %d %d', row.slot, row.itemid, count));
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip(string.format('Put %d into the warehouse.', count));
            end
        end

        imgui.EndTable();
    end
end

local function kitsTab()
    imgui.TextDisabled('A kit is a name for a list of items. Pulling one sends ordinary pull');
    imgui.TextDisabled('commands -- the server never hears the name, and nothing is stored there.');
    imgui.TextDisabled('Kits are kept per character, on this machine only.');

    imgui.PushItemWidth(200);
    imgui.InputText('##dww_kitname', state.kitName, KIT_NAME_MAX + 1);
    imgui.PopItemWidth();

    imgui.SameLine();

    if (imgui.Button('Save selection##dww_kit_sel')) then
        local entries = kitEntriesFromBag(selection);

        if (saveKit(state.kitName[1], entries)) then
            state.status    = string.format('Saved kit "%s".', cleanKitName(state.kitName[1]));
            state.statusBad = false;
            state.kitName[1] = '';
        end
    end

    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Everything ticked on the Deposit tab, at the quantities you hold.');
    end

    imgui.SameLine();

    if (imgui.Button('Save whole bag##dww_kit_bag')) then
        local entries = kitEntriesFromBag(nil);

        if (saveKit(state.kitName[1], entries)) then
            state.status     = string.format('Saved kit "%s".', cleanKitName(state.kitName[1]));
            state.statusBad  = false;
            state.kitName[1] = '';
        end
    end

    imgui.Separator();

    local names = kitNames();

    if (#names == 0) then
        imgui.Text('No kits yet. Name one above and save it.');

        return;
    end

    if (imgui.BeginTable('##dww_kits', 3,
            bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_BordersH, ImGuiTableFlags_ScrollY,
                    ImGuiTableFlags_SizingFixedFit), { -1, -1 })) then
        imgui.TableSetupColumn('Kit', ImGuiTableColumnFlags_WidthFixed, 180, 0);
        imgui.TableSetupColumn('Contents', ImGuiTableColumnFlags_WidthFixed, 380, 0);
        imgui.TableSetupColumn('', ImGuiTableColumnFlags_WidthFixed, 140, 0);
        imgui.TableSetupScrollFreeze(0, 1);
        imgui.TableHeadersRow();

        local stored = storedCounts();

        for index, name in ipairs(names) do
            local entries = parseKit(config.kits[name]);

            imgui.TableNextRow();
            imgui.TableNextColumn();
            imgui.Text(name);

            imgui.TableNextColumn();

            local shown = T{ };

            for position = 1, math.min(#entries, 6) do
                shown:append(string.format('%s x%d', itemName(entries[position].id), entries[position].qty));
            end

            if (#entries > 6) then
                shown:append(string.format('and %d more', #entries - 6));
            end

            imgui.TextDisabled(table.concat(shown, ', '));

            --[[
                The shortfall preview (1.9.0): what the shelf is short of
                for this kit, counted off the model BEFORE anything is sent,
                so a kit that cannot be filled says so on the row instead of
                after a pull. The server's own shortfall sentence still
                arrives on a real pull -- the model can be a moment behind --
                this is the earlier, cheaper warning. Totals are summed per
                item first: a kit that asks for 24 arrows as two lines of 12
                is short by the pair, not by each line.
            ]]
            local wanted = { };

            for _, entry in ipairs(entries) do
                wanted[entry.id] = (wanted[entry.id] or 0) + entry.qty;
            end

            local short = T{ };

            for id, qty in pairs(wanted) do
                local held = stored[id] or 0;

                if (held < qty) then
                    short:append({ id = id, missing = qty - held });
                end
            end

            if (#short > 0 and (state.synced and not state.syncing)) then
                table.sort(short, function (a, b) return a.id < b.id; end);

                local words = T{ };

                for position = 1, math.min(#short, 4) do
                    words:append(string.format('%s x%d', itemName(short[position].id), short[position].missing));
                end

                if (#short > 4) then
                    words:append(string.format('and %d more', #short - 4));
                end

                imgui.TextColored(theme.colors.warn, 'short: ' .. table.concat(words, ', '));
            end

            imgui.TableNextColumn();

            -- Widget ids carry the kit's INDEX, not its name: a name is player
            -- text and '##' inside one would split the id ImGui parses.
            if (imgui.SmallButton(string.format('Pull##dww_pull_%d', index))) then
                for _, command in ipairs(pullCommands(entries)) do
                    issue(command);
                end
            end

            if (imgui.IsItemHovered()) then
                imgui.SetTooltip('Take everything in this kit out of the warehouse.\n'
                    .. 'Long kits become several commands, one per 1.2 seconds.\n'
                    .. 'Anything short is reported item by item.');
            end

            imgui.SameLine();

            -- Two clicks, the second inside the hold. Armed by NAME rather
            -- than by row index: the list is re-sorted by every save, and an
            -- armed "Really delete?" that stayed with row 3 while a new kit
            -- moved a different one into row 3 would delete the wrong one --
            -- the same reason dwgmpanel keys its Jail confirmation by name.
            local armed = state.kitArmed == name
                and (os.clock() - state.kitArmAt) < KIT_CONFIRM_HOLD;

            if (imgui.SmallButton(string.format('%s##dww_del_%d',
                    armed and 'Really delete?' or 'Delete', index))) then
                if (armed) then
                    config.kits[name] = nil;
                    settings.save();

                    state.kitArmed = nil;

                    state.status    = string.format('Deleted kit "%s".', name);
                    state.statusBad = false;
                else
                    state.kitArmed = name;
                    state.kitArmAt = os.clock();
                end
            end

            if (not armed and imgui.IsItemHovered()) then
                imgui.SetTooltip('Forget this kit. Asks once more before it goes --\n'
                    .. 'the list is kept here and nowhere else.');
            end
        end

        imgui.EndTable();
    end
end

local function renderWindow()
    headerStrip();

    imgui.Separator();

    if (imgui.BeginTabBar('##dww_tabs')) then
        if (imgui.BeginTabItem('Warehouse')) then
            warehouseTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Deposit')) then
            depositTab();
            imgui.EndTabItem();
        end

        if (imgui.BeginTabItem('Kits')) then
            kitsTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end
end

--[[
* The render pass, wrapped so that a mistake in it costs one frame rather than
* the addon.
*
* An error thrown inside a d3d_present handler is raised on EVERY frame -- sixty
* times a second -- and the addon host answers a long enough run of them by
* unloading the addon. So: Begin and End stay OUTSIDE the pcall, which is what
* keeps ImGui's window stack balanced whatever happens in between; the error is
* reported once; and the window closes itself. Everything the window does is
* still reachable as !warehouse commands, so closing it is a real fallback
* rather than a dead end. (dwbags.lua:1875-1889.)
--]]
ashita.events.register('d3d_present', 'dwwarehouse_present', function ()
    -- Before the visibility check: a page walk started a moment before the
    -- window was closed still has to finish, and a Take still has to be sent.
    pumpQueue();

    -- The sweep drives itself from here rather than from the record handler, so
    -- a page command lost on the way out is re-asked (once) instead of leaving
    -- the list half-filled forever.
    if (state.syncing and state.nextPage ~= nil) then
        needPage(state.nextPage);
    end

    -- A generation the model on screen was not built from: another client on
    -- this account moved something, or moved it while the last sweep was
    -- walking. Repaired here rather than on a timer -- the gap is only visible
    -- once a response has landed, and startSync is idempotent because issue()
    -- collapses duplicate commands.
    if (not state.syncing and state.synced and state.gen ~= state.syncGen) then
        if (state.resweeps < MAX_RESWEEPS) then
            state.resweeps = state.resweeps + 1;

            startSync();
        else
            state.status    = 'The account is being changed elsewhere. Press Refresh when it settles.';
            state.statusBad = true;
            state.syncGen   = state.gen;
        end
    end

    if (not state.open[1]) then
        return;
    end

    -- The theme wraps Begin/End the way Begin wraps the pcall: pushed and
    -- popped outside anything that can throw, so the style stack stays
    -- balanced no matter what the render pass does.
    local pushed = theme.push();

    imgui.SetNextWindowSize({ 840, 480 }, ImGuiCond_FirstUseEver);

    -- NoDocking: dragging one Driftwood window onto another used to fuse them
    -- into a single unthemed dock that imgui.ini kept across reloads. The flag
    -- refuses new docking, and ImGui undocks a saved-docked window whose flags
    -- carry it, so windows linked before this flag separate on their next load.
    local visible = imgui.Begin('DriftwoodXI Warehouse##dwwarehouse', state.open,
        bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_NoDocking));

    if (visible) then
        local ok, err = pcall(renderWindow);

        if (not ok) then
            state.open[1] = false;

            if (not state.reported) then
                state.reported = true;

                print(chat.header('dwwarehouse'):append(chat.error('render error: ' .. tostring(err))));
                print(chat.header('dwwarehouse'):append(chat.message('Window closed. Everything it does also works as !warehouse commands.')));
            end
        end
    end

    imgui.End();
    theme.pop(pushed);
end);

--[[
* Watch what the player sends, so the window keeps up with commands typed
* outside it. 0x00B5 is Kind at 0x04, a pad byte, then the message at 0x06.
*
* Only `!warehouse` is matched for invalidation, not `!dww`: the addon's own
* commands already answer with what they changed.
*
* EVERY OTHER OUTGOING LINE STILL COUNTS AGAINST THE THROTTLE, though. The
* client's rate limit is on chat, not on this addon, so a page request fired in
* the same frame as something the player typed is the one that gets dropped --
* and on this addon that costs a whole sweep, not one panel. Stamping the
* player's own line as a send makes the follow-up wait its interval instead of
* racing it. (dwbags.lua:1935-1953.)
--]]
ashita.events.register('packet_out', 'dwwarehouse_packet_out', function (e)
    if (e.id ~= 0x00B5) then
        return;
    end

    local message = e.data_modified:sub(0x07):gsub('%z.*$', '');

    if (message:lower():sub(1, 4) ~= '!dww') then
        lastSend = os.clock();
    end

    if (message:lower():sub(1, 10) == '!warehouse') then
        startSync();
    end
end);

ashita.events.register('command', 'dwwarehouse_command', function (e)
    local args = e.command:args();

    -- LOWERCASED: `:args()` hands back exactly what was typed, so `/Warehouse`
    -- matched nothing and fell through to the game as an unknown command.
    -- (Stock Ashita tests with `:any()`, which lowercases both sides.)
    local first = #args > 0 and args[1]:lower() or '';

    if (first ~= '/warehouse' and first ~= '/wh') then
        return;
    end

    e.blocked = true;

    if (#args >= 2 and args[2]:lower() == 'refresh') then
        state.resweeps = 0;
        state.repaired = false;

        startSync();

        return;
    end

    state.open[1] = not state.open[1];

    if (state.open[1]) then
        -- Reopening is a fresh start for error reporting too: `reported` only
        -- exists to stop one bad frame printing sixty lines a second, not to
        -- silence a different error a week later in the same session.
        state.reported = false;

        -- ONCE PER LOGIN, not once per open. The model is kept current by the
        -- deltas every command answers with, so a second open has nothing to
        -- ask for -- and asking anyway would be a twelve-command page walk for
        -- a window the player only wanted to glance at. Refresh is the button
        -- for doing it on purpose; a generation gap does it automatically.
        if (not state.synced) then
            startSync();
        end
    end
end);

ashita.events.register('load', 'dwwarehouse_load', function ()
    print(chat.header('dwwarehouse'):append(chat.message('/warehouse opens your account storage. Everything it does also works typed as !warehouse.')));
end);

-- A zone line invalidates nothing the server told us, but a login is a new
-- character and therefore a new pin list and a new view. (The pool itself is
-- the account's and does not change with the character -- pins are per
-- character, which is what makes this reset necessary rather than tidy.)
ashita.events.register('packet_in', 'dwwarehouse_zonein', function (e)
    if (e.id == 0x000A) then
        state.rows      = {};
        state.modelRev  = state.modelRev + 1;
        state.pins      = {};
        state.used      = 0;
        state.cap       = 0;
        state.gen       = 0;
        state.syncing   = false;
        state.syncGen   = -1;
        state.sweepGen  = nil;
        state.resweeps  = 0;
        state.nextPage  = nil;
        state.pages     = nil;
        state.pagesSeen = 0;
        state.synced    = false;
        state.repaired  = false;
        state.inbound   = nil;
        state.status    = 'Press Refresh.';
        state.statusBad = false;

        -- A pending trash question is about a row id from before the zone
        -- line; the model it referred to has just been wiped.
        state.trashAsk  = nil;

        -- AND THE CAPABILITY LATCH IS RE-PROBED. This used to say "the server
        -- on the other side of a zone line is the same server", which is true
        -- of a zone line and NOT of the other thing 0x000A means: a login. A
        -- map restart logs everyone out, so a player who relogs after the
        -- trash verb was deployed was still being told it does not exist --
        -- for the rest of the client session, with the buttons simply not
        -- drawn and nothing on screen to say why. Every sibling latch in the
        -- suite is cleared here for exactly this reason (dwbags' three,
        -- dwgambits' two, dwmerc's two, dwscan and dwfishing's refusals), and
        -- the cost of being wrong is one refusal sentence the player earns
        -- back by clicking Trash once.
        state.noTrash   = false;
        state.noStack   = false;
        state.noBuy     = false;
        state.buyAsk    = false;

        -- The market lane's three, same reason: the standing is re-learned
        -- from the next `who`, and a strip open across a login names a row
        -- the wiped model no longer has.
        state.noSell    = false;
        state.market    = nil;
        state.sellAsk   = nil;

        selection = {};
        forget();

        -- An open window restarts its own sweep: this reset just disarmed
        -- both self-repair paths (the open transition only fires on a
        -- toggle, and the generation-gap repair is gated on `synced`), so
        -- without this the window sits on an empty model until the player
        -- clicks Refresh.
        if (state.open[1]) then
            startSync();
        end
    end
end);
